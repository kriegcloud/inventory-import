import * as Contributions from "alchemy/Contributions";
declare const _default: {
    readonly name: "1password";
    readonly auth: Contributions.Lazy<import("effect/Layer").Layer<never, never, import("alchemy/Auth/Registry").AuthProviders | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("effect/crypto/SecureRandom").SecureRandom>>;
};
export default _default;
//# sourceMappingURL=Contributions.d.ts.map