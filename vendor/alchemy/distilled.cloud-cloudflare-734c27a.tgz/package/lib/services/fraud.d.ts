import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const FraudDetectionNotEntitled_base: S.TaggedErrorClass<"FraudDetectionNotEntitled", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class FraudDetectionNotEntitled extends /*@__PURE__*/ FraudDetectionNotEntitled_base {
}
export interface GetFraudRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResponseAuthenticationSettingsFailureCriteriaKind = "status_code";
export type GetResponseAuthenticationSettingsFailureCriteriaStatusCodesList = Array<number>;
export interface GetResponseAuthenticationSettingsFailureCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: GetResponseAuthenticationSettingsFailureCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: GetResponseAuthenticationSettingsFailureCriteriaStatusCodesList | null | undefined;
}
export type GetResponseAuthenticationSettingsSuccessCriteriaKind = "status_code";
export type GetResponseAuthenticationSettingsSuccessCriteriaStatusCodesList = Array<number>;
export interface GetResponseAuthenticationSettingsSuccessCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: GetResponseAuthenticationSettingsSuccessCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: GetResponseAuthenticationSettingsSuccessCriteriaStatusCodesList | null | undefined;
}
export interface GetResponseAuthenticationSettings {
    /** Criterion for identifying failed login responses. */
    failureCriteria?: GetResponseAuthenticationSettingsFailureCriteria | null | undefined;
    /** Criterion for identifying successful login responses. */
    successCriteria?: GetResponseAuthenticationSettingsSuccessCriteria | null | undefined;
}
export type GetResponseUserProfiles = "enabled" | "disabled";
export type GetResponseUsernameExpressionsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetFraudResponse {
    /** Configuration for classifying login authentication outcomes based on the origin response. Requires `user_profiles` to be enabled. */
    authenticationSettings?: GetResponseAuthenticationSettings | null | undefined;
    /** Whether Fraud User Profiles is enabled for the zone. */
    userProfiles?: GetResponseUserProfiles | null | undefined;
    /** List of expressions to detect usernames in write HTTP requests. */
    usernameExpressions?: GetResponseUsernameExpressionsList | null | undefined;
}
export type UpdateRequestAuthenticationSettingsFailureCriteriaKind = "status_code";
export type UpdateRequestAuthenticationSettingsFailureCriteriaStatusCodesList = Array<number>;
export interface UpdateRequestAuthenticationSettingsFailureCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateRequestAuthenticationSettingsFailureCriteriaKind | (string & {});
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateRequestAuthenticationSettingsFailureCriteriaStatusCodesList | undefined;
}
export type UpdateRequestAuthenticationSettingsSuccessCriteriaKind = "status_code";
export type UpdateRequestAuthenticationSettingsSuccessCriteriaStatusCodesList = Array<number>;
export interface UpdateRequestAuthenticationSettingsSuccessCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateRequestAuthenticationSettingsSuccessCriteriaKind | (string & {});
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateRequestAuthenticationSettingsSuccessCriteriaStatusCodesList | undefined;
}
export interface UpdateRequestAuthenticationSettings {
    /** Criterion for identifying failed login responses. */
    failureCriteria?: UpdateRequestAuthenticationSettingsFailureCriteria | undefined;
    /** Criterion for identifying successful login responses. */
    successCriteria?: UpdateRequestAuthenticationSettingsSuccessCriteria | undefined;
}
export type UpdateRequestUserProfiles = "enabled" | "disabled";
export type UpdateRequestUsernameExpressionsList = Array<string>;
export interface PutFraudRequest {
    /** Identifier. */
    zoneId: string;
    /** Configuration for classifying login authentication outcomes based on the origin response. Requires `user_profiles` to be enabled. */
    authenticationSettings?: UpdateRequestAuthenticationSettings | undefined;
    /** Whether Fraud User Profiles is enabled for the zone. */
    userProfiles?: UpdateRequestUserProfiles | (string & {}) | undefined;
    /** List of expressions to detect usernames in write HTTP requests. */
    usernameExpressions?: UpdateRequestUsernameExpressionsList | undefined;
}
export type UpdateResponseAuthenticationSettingsFailureCriteriaKind = "status_code";
export type UpdateResponseAuthenticationSettingsFailureCriteriaStatusCodesList = Array<number>;
export interface UpdateResponseAuthenticationSettingsFailureCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateResponseAuthenticationSettingsFailureCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateResponseAuthenticationSettingsFailureCriteriaStatusCodesList | null | undefined;
}
export type UpdateResponseAuthenticationSettingsSuccessCriteriaKind = "status_code";
export type UpdateResponseAuthenticationSettingsSuccessCriteriaStatusCodesList = Array<number>;
export interface UpdateResponseAuthenticationSettingsSuccessCriteria {
    /** The type of criterion. Currently only `status_code` is supported. */
    kind: UpdateResponseAuthenticationSettingsSuccessCriteriaKind;
    /** HTTP status codes to match against the origin response. */
    statusCodes?: UpdateResponseAuthenticationSettingsSuccessCriteriaStatusCodesList | null | undefined;
}
export interface UpdateResponseAuthenticationSettings {
    /** Criterion for identifying failed login responses. */
    failureCriteria?: UpdateResponseAuthenticationSettingsFailureCriteria | null | undefined;
    /** Criterion for identifying successful login responses. */
    successCriteria?: UpdateResponseAuthenticationSettingsSuccessCriteria | null | undefined;
}
export type UpdateResponseUserProfiles = "enabled" | "disabled";
export type UpdateResponseUsernameExpressionsList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PutFraudResponse {
    /** Configuration for classifying login authentication outcomes based on the origin response. Requires `user_profiles` to be enabled. */
    authenticationSettings?: UpdateResponseAuthenticationSettings | null | undefined;
    /** Whether Fraud User Profiles is enabled for the zone. */
    userProfiles?: UpdateResponseUserProfiles | null | undefined;
    /** List of expressions to detect usernames in write HTTP requests. */
    usernameExpressions?: UpdateResponseUsernameExpressionsList | null | undefined;
}
export type GetFraudError = Forbidden | CloudflareOpError;
/** Retrieve Fraud Detection settings for a zone. */
export declare const getFraud: API.OperationMethod<GetFraudRequest, GetFraudResponse, GetFraudError, CloudflareOpContext>;
export type PutFraudError = Forbidden | FraudDetectionNotEntitled | CloudflareOpError;
/** Update Fraud Detection settings for a zone. Notes on `username_expressions` behavior: - If omitted or set to null, expressions are not modified. - If provided as an empty array `[]`, all expressions will be cleared. */
export declare const putFraud: API.OperationMethod<PutFraudRequest, PutFraudResponse, PutFraudError, CloudflareOpContext>;
//# sourceMappingURL=fraud.d.ts.map