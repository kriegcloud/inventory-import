import * as Effect from "effect/Effect";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
/**
 * Generic REST protocol machinery, shared by SDK protocol layers.
 *
 * Everything here is driven purely by the trait annotations in
 * `core/trait.ts` -- nothing is provider-specific. An SDK protocol (e.g.
 * cloudflare's) supplies credentials/base-URL, calls {@link buildRequest} to
 * encode, and layers its own response-envelope handling on top of the
 * decode-side helpers ({@link getProps}/{@link mapKeys}/
 * {@link matchTypedError}).
 */
import type * as AST from "effect/SchemaAST";
import { isOpaqueValue } from "./plain-values.ts";
import * as Schema from "./schema-lite-typed.ts";
import { SdkError } from "./sdk-error.ts";
import { type ErrorMatcher, type HttpTrait, type KeyDictionaryEntries } from "./trait.ts";
export { getAnn, getProps, resolveNode } from "./annotations.ts";
export declare const getPropAnn: (prop: AST.PropertySignature, symbol: symbol) => unknown;
export declare const hasPropAnn: (prop: AST.PropertySignature, symbol: symbol) => boolean;
export declare const nameOf: (prop: AST.PropertySignature, symbol: symbol) => string;
/** An output member read from a response header (`T.Header`). */
export interface ResponseHeaderMember {
    readonly key: string;
    /** Lowercase header name. */
    readonly wire: string;
    /** The member is a number; the header's text is parsed. */
    readonly number: boolean;
}
/** The output's header-bound members, read from the schema once. */
export declare const responseHeaderMembers: (outputAst: AST.AST) => ReadonlyArray<ResponseHeaderMember>;
/**
 * Copy the response headers an output declares onto its decoded body. A
 * number member gets the header parsed; text that is not a number is kept
 * as sent, so strict validation reports it. A body that is not an object
 * (a raw root) is returned as is -- generators bind no headers there.
 */
export declare const withResponseHeaders: (members: ReadonlyArray<ResponseHeaderMember>, body: unknown, headers: Record<string, string | undefined>) => unknown;
export { isOpaqueValue };
/**
 * Deep-rename keys via a plain dictionary (see `T.KeyDictionary`). An entry
 * may list several wire spellings; encode uses the first (canonical) one and
 * decode maps every listed spelling back to the TS name.
 */
export declare const mapKeysByDictionary: (dict: KeyDictionaryEntries, value: unknown, direction: "encode" | "decode") => unknown;
/**
 * Whether {@link mapKeys} returns every value of `root` unchanged (as a deep
 * copy) in `direction` with no fallback dictionary: no member is renamed,
 * string-encoded (encode) or picked by `T.UnionCases` (decode, or encode for
 * a union whose cases carry member dictionaries), and no
 * `T.KeyDictionary` is in scope anywhere below `root`. Protocols use it to
 * skip the walk. Computed once per schema node and direction.
 */
export declare const mapsVerbatim: (root: AST.AST, direction: "encode" | "decode") => boolean;
export declare const mapKeys: (ast: AST.AST, value: unknown, direction: "encode" | "decode", fallback?: KeyDictionaryEntries) => unknown;
export interface BuildRequestOptions {
    readonly input: unknown;
    readonly inputAst: AST.AST;
    /** Base URL the operation's URI template is appended to. */
    readonly baseUrl: string;
    /** Headers applied before member-bound headers (credentials etc.). */
    readonly headers?: Record<string, string>;
    /**
     * Transform a member-bound header value before it is set (e.g.
     * Bearer-prefixing a raw token supplied as an Authorization member).
     */
    readonly mapMemberHeader?: (name: string, value: string) => string;
    /**
     * Wire name for input keys the schema doesn't declare (spec drift --
     * unknown keys pass through as body fields rather than being dropped).
     * Defaults to the key verbatim.
     */
    readonly unknownKeyToWire?: (key: string) => string;
    /**
     * Send `{}` on a method that takes a body even when the input declares no
     * body members. Connect unary RPCs (E2B's envd) POST JSON for every call,
     * and refuse a bodyless one with 415.
     */
    readonly emptyJsonBody?: boolean;
    /**
     * How a query member spells a nested object or an array.
     *
     * - `"dotted"` (default): `created.gte=1`; an array repeats the key
     *   (`expand=a&expand=b`).
     * - `"brackets"`: `created[gte]=1`; an array indexes the key
     *   (`expand[0]=a&expand[1]=b`), the same rule as form-urlencoded bodies.
     *   Stripe needs this: its v2 API refuses `key[]` and repeated keys.
     *
     * `T.CommaDelimited` and `T.DeepQuery` members keep their own spelling.
     */
    readonly queryStyle?: "dotted" | "brackets";
}
/**
 * Encode a greedy `{name+}` label: the value may span several path
 * segments (e.g. an Azure scope `/subscriptions/{id}/resourceGroups/{rg}`),
 * so each segment is encoded on its own and the `/` separators are kept.
 * Leading slashes are dropped because the URI template already supplies one.
 */
export declare const encodeGreedyLabel: (value: string) => string;
/**
 * `HttpClientRequest.make(method)(url)` with `headers` set, in one object:
 * the same request as `make(...).pipe(setHeaders(headers))` without the
 * intermediate copies. `url` may carry a query string.
 */
export declare const makeRequest: (method: HttpTrait["method"], url: string, headers: Record<string, string>) => HttpClientRequest.HttpClientRequest;
declare const InvalidInput_base: Schema.TaggedErrorClass<"InvalidInput", {
    readonly member: import("effect/Schema").String;
    readonly message: import("effect/Schema").String;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
/**
 * The input cannot be sent: a path label whose value would address another
 * resource (`.` or `..`, which the URL parser resolves to the parent path).
 * Raised before anything is sent.
 */
export declare class InvalidInput extends /*@__PURE__*/ InvalidInput_base {
}
/**
 * The refusal for a path label value that would address another resource,
 * or `undefined`. The URL parser resolves a `.` or `..` segment,
 * percent-encoded or not, so no encoding can carry one
 * (`/projects/p1/branches/..` -> `/projects/p1/`). A greedy label keeps its
 * `/`, so each of its segments counts.
 */
export declare const invalidLabel: (member: string, value: unknown, greedy?: boolean) => InvalidInput | undefined;
/**
 * Build an HTTP request from an operation input and its schema, driven by
 * the trait annotations: `Http()` supplies method + URI template, `Label()`
 * members fill URI placeholders, `Header()`/`Query()` members bind to
 * headers/query params, `DeepQuery()` struct members expand into dotted
 * query params, `HttpBody()` sends the member as the whole body,
 * `FormDataFile()` members become multipart file parts, and everything else
 * is a JSON body field (wire-named via `Body()` / `KeyDictionary`).
 *
 * The schema is read once per input schema (see `planFor`); later calls only
 * walk the input value.
 *
 * Fails with {@link InvalidInput}, before anything is sent, when a label is
 * `.` or `..` (for a greedy `{name+}` label, when any of its segments is).
 * Fails with {@link SdkError} when the input schema is missing the `Http()`
 * trait (a codegen bug the generator refuses).
 */
export declare const buildRequest: (options: BuildRequestOptions) => Effect.Effect<HttpClientRequest.HttpClientRequest, InvalidInput | SdkError>;
/** Parsed response metadata supplied by a protocol after it detects a failure. */
export interface ErrorResponse {
    readonly body?: unknown;
    readonly headers?: Readonly<Record<string, string | undefined>>;
    /**
     * JSON pointer to the object that holds the error's fields when the
     * provider nests them, e.g. `"/error"` for `{ error: { status, details } }`.
     */
    readonly fieldsAt?: string;
}
/** Every supplied constraint must match; an unconstrained matcher matches nothing. */
export declare const matchesExpression: (m: ErrorMatcher, code: number | undefined, status: number, message: string, response?: ErrorResponse) => boolean;
/**
 * The fields every error built from a response gets, when its class declares
 * them: the body (keys mapped to TS names when the class types it), the
 * headers, and the server's retry hint from `Retry-After` or `RateLimit`.
 */
export declare const responseErrorFields: (fields: Record<string, unknown> | undefined, response: ErrorResponse) => Record<string, unknown>;
/**
 * Pick the operation's typed error class for a failed response: among all
 * declared classes whose matchers (see `applyErrorMatchers`) match the wire
 * failure, the most specific matcher wins (ties break by declaration order).
 * Empty error lists use an HTTP-status message so body/header-only failures can
 * still match. The constructor receives the raw body and headers as well as
 * code/message; error schemas can declare these fields to expose them to callers.
 * Any other field the class declares is read from the JSON body's key of the
 * same name -- at `response.fieldsAt` first, then at the top level -- so a
 * patch that adds `requestId` to an error gets the body's `requestId`. A
 * declared `retryAfter` gets the `Retry-After` / `RateLimit` header hint. The
 * matched `code` and `message` always win over the body's.
 */
export declare const matchTypedError: (errorClasses: ReadonlyArray<unknown>, status: number, errors: ReadonlyArray<{
    code?: number;
    message: string;
}>, response?: ErrorResponse) => unknown | undefined;
//# sourceMappingURL=protocol-http.d.ts.map