import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly QuotaCode: any;
    readonly ServiceCode: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly Fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TopicArn = string;
export interface SnsChannelConfig {
    TopicArn?: string | undefined;
}
export type InsightSeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type InsightSeverities = InsightSeverity[];
export type NotificationMessageType = "NEW_INSIGHT" | "CLOSED_INSIGHT" | "NEW_ASSOCIATION" | "SEVERITY_UPGRADED" | "NEW_RECOMMENDATION" | (string & {});
export type NotificationMessageTypes = NotificationMessageType[];
export interface NotificationFilterConfig {
    Severities?: InsightSeverity[] | undefined;
    MessageTypes?: NotificationMessageType[] | undefined;
}
export interface NotificationChannelConfig {
    Sns: SnsChannelConfig;
    Filters?: NotificationFilterConfig | undefined;
}
export interface AddNotificationChannelRequest {
    Config: NotificationChannelConfig;
}
export type NotificationChannelId = string;
export interface AddNotificationChannelResponse {
    Id: string;
}
export type InsightId = string;
export interface DeleteInsightRequest {
    Id: string;
}
export interface DeleteInsightResponse {
}
export interface DescribeAccountHealthRequest {
}
export type NumOpenReactiveInsights = number;
export type NumOpenProactiveInsights = number;
export type NumMetricsAnalyzed = number;
export type ResourceHours = number;
export type AnalyzedResourceCount = number;
export interface DescribeAccountHealthResponse {
    OpenReactiveInsights: number;
    OpenProactiveInsights: number;
    MetricsAnalyzed: number;
    ResourceHours: number;
    AnalyzedResourceCount?: number | undefined;
}
export interface DescribeAccountOverviewRequest {
    FromTime: Date;
    ToTime?: Date | undefined;
}
export type NumReactiveInsights = number;
export type NumProactiveInsights = number;
export type MeanTimeToRecoverInMilliseconds = number;
export interface DescribeAccountOverviewResponse {
    ReactiveInsights: number;
    ProactiveInsights: number;
    MeanTimeToRecoverInMilliseconds: number;
}
export type AnomalyId = string;
export type AwsAccountId = string;
export interface DescribeAnomalyRequest {
    Id: string;
    AccountId?: string | undefined;
}
export type AnomalySeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type AnomalyStatus = "ONGOING" | "CLOSED" | (string & {});
export interface AnomalyTimeRange {
    StartTime: Date;
    EndTime?: Date | undefined;
}
export interface AnomalyReportedTimeRange {
    OpenTime: Date;
    CloseTime?: Date | undefined;
}
export interface PredictionTimeRange {
    StartTime: Date;
    EndTime?: Date | undefined;
}
export type CloudWatchMetricsMetricName = string;
export type CloudWatchMetricsNamespace = string;
export type CloudWatchMetricsDimensionName = string;
export type CloudWatchMetricsDimensionValue = string;
export interface CloudWatchMetricsDimension {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type CloudWatchMetricsDimensions = CloudWatchMetricsDimension[];
export type CloudWatchMetricsStat = "Sum" | "Average" | "SampleCount" | "Minimum" | "Maximum" | "p99" | "p90" | "p50" | (string & {});
export type CloudWatchMetricsUnit = string;
export type CloudWatchMetricsPeriod = number;
export type MetricValue = number;
export interface TimestampMetricValuePair {
    Timestamp?: Date | undefined;
    MetricValue?: number | undefined;
}
export type TimestampMetricValuePairList = TimestampMetricValuePair[];
export type CloudWatchMetricDataStatusCode = "Complete" | "InternalError" | "PartialData" | (string & {});
export interface CloudWatchMetricsDataSummary {
    TimestampMetricValuePairList?: TimestampMetricValuePair[] | undefined;
    StatusCode?: CloudWatchMetricDataStatusCode | undefined;
}
export interface CloudWatchMetricsDetail {
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Dimensions?: CloudWatchMetricsDimension[] | undefined;
    Stat?: CloudWatchMetricsStat | undefined;
    Unit?: string | undefined;
    Period?: number | undefined;
    MetricDataSummary?: CloudWatchMetricsDataSummary | undefined;
}
export type CloudWatchMetricsDetails = CloudWatchMetricsDetail[];
export type PerformanceInsightsMetricDisplayName = string;
export type PerformanceInsightsMetricUnit = string;
export type PerformanceInsightsMetricName = string;
export type PerformanceInsightsMetricGroup = string;
export type PerformanceInsightsMetricDimension = string;
export type PerformanceInsightsMetricDimensions = string[];
export type PerformanceInsightsMetricLimitInteger = number;
export interface PerformanceInsightsMetricDimensionGroup {
    Group?: string | undefined;
    Dimensions?: string[] | undefined;
    Limit?: number | undefined;
}
export type PerformanceInsightsMetricFilterKey = string;
export type PerformanceInsightsMetricFilterValue = string;
export type PerformanceInsightsMetricFilterMap = {
    [key: string]: string | undefined;
};
export interface PerformanceInsightsMetricQuery {
    Metric?: string | undefined;
    GroupBy?: PerformanceInsightsMetricDimensionGroup | undefined;
    Filter?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PerformanceInsightsReferenceName = string;
export type PerformanceInsightsValueDouble = number;
export interface PerformanceInsightsReferenceScalar {
    Value?: number | undefined;
}
export interface PerformanceInsightsReferenceMetric {
    MetricQuery?: PerformanceInsightsMetricQuery | undefined;
}
export interface PerformanceInsightsReferenceComparisonValues {
    ReferenceScalar?: PerformanceInsightsReferenceScalar | undefined;
    ReferenceMetric?: PerformanceInsightsReferenceMetric | undefined;
}
export interface PerformanceInsightsReferenceData {
    Name?: string | undefined;
    ComparisonValues?: PerformanceInsightsReferenceComparisonValues | undefined;
}
export type PerformanceInsightsReferenceDataList = PerformanceInsightsReferenceData[];
export type PerformanceInsightsStatType = string;
export interface PerformanceInsightsStat {
    Type?: string | undefined;
    Value?: number | undefined;
}
export type PerformanceInsightsStats = PerformanceInsightsStat[];
export interface PerformanceInsightsMetricsDetail {
    MetricDisplayName?: string | undefined;
    Unit?: string | undefined;
    MetricQuery?: PerformanceInsightsMetricQuery | undefined;
    ReferenceData?: PerformanceInsightsReferenceData[] | undefined;
    StatsAtAnomaly?: PerformanceInsightsStat[] | undefined;
    StatsAtBaseline?: PerformanceInsightsStat[] | undefined;
}
export type PerformanceInsightsMetricsDetails = PerformanceInsightsMetricsDetail[];
export interface AnomalySourceDetails {
    CloudWatchMetrics?: CloudWatchMetricsDetail[] | undefined;
    PerformanceInsightsMetrics?: PerformanceInsightsMetricsDetail[] | undefined;
}
export type StackName = string;
export type StackNames = string[];
export interface CloudFormationCollection {
    StackNames?: string[] | undefined;
}
export type AppBoundaryKey = string;
export type TagValue = string;
export type TagValues = string[];
export interface TagCollection {
    AppBoundaryKey: string;
    TagValues: string[];
}
export type TagCollections = TagCollection[];
export interface ResourceCollection {
    CloudFormation?: CloudFormationCollection | undefined;
    Tags?: TagCollection[] | undefined;
}
export type AnomalyLimit = number;
export type AnomalySource = string;
export type ResourceName = string;
export type ResourceType = string;
export interface AnomalySourceMetadata {
    Source?: string | undefined;
    SourceResourceName?: string | undefined;
    SourceResourceType?: string | undefined;
}
export interface AnomalyResource {
    Name?: string | undefined;
    Type?: string | undefined;
}
export type AnomalyResources = AnomalyResource[];
export type AnomalyDescription = string;
export interface ProactiveAnomaly {
    Id?: string | undefined;
    Severity?: AnomalySeverity | undefined;
    Status?: AnomalyStatus | undefined;
    UpdateTime?: Date | undefined;
    AnomalyTimeRange?: AnomalyTimeRange | undefined;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange | undefined;
    PredictionTimeRange?: PredictionTimeRange | undefined;
    SourceDetails?: AnomalySourceDetails | undefined;
    AssociatedInsightId?: string | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    Limit?: number | undefined;
    SourceMetadata?: AnomalySourceMetadata | undefined;
    AnomalyResources?: AnomalyResource[] | undefined;
    Description?: string | undefined;
}
export type AnomalyType = "CAUSAL" | "CONTEXTUAL" | (string & {});
export type AnomalyName = string;
export interface ReactiveAnomaly {
    Id?: string | undefined;
    Severity?: AnomalySeverity | undefined;
    Status?: AnomalyStatus | undefined;
    AnomalyTimeRange?: AnomalyTimeRange | undefined;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange | undefined;
    SourceDetails?: AnomalySourceDetails | undefined;
    AssociatedInsightId?: string | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    Type?: AnomalyType | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CausalAnomalyId?: string | undefined;
    AnomalyResources?: AnomalyResource[] | undefined;
}
export interface DescribeAnomalyResponse {
    ProactiveAnomaly?: ProactiveAnomaly | undefined;
    ReactiveAnomaly?: ReactiveAnomaly | undefined;
}
export interface DescribeEventSourcesConfigRequest {
}
export type EventSourceOptInStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AmazonCodeGuruProfilerIntegration {
    Status?: EventSourceOptInStatus | undefined;
}
export interface EventSourcesConfig {
    AmazonCodeGuruProfiler?: AmazonCodeGuruProfilerIntegration | undefined;
}
export interface DescribeEventSourcesConfigResponse {
    EventSources?: EventSourcesConfig | undefined;
}
export interface DescribeFeedbackRequest {
    InsightId?: string | undefined;
}
export type InsightFeedbackOption = "VALID_COLLECTION" | "RECOMMENDATION_USEFUL" | "ALERT_TOO_SENSITIVE" | "DATA_NOISY_ANOMALY" | "DATA_INCORRECT" | (string & {});
export interface InsightFeedback {
    Id?: string | undefined;
    Feedback?: InsightFeedbackOption | undefined;
}
export interface DescribeFeedbackResponse {
    InsightFeedback?: InsightFeedback | undefined;
}
export interface DescribeInsightRequest {
    Id: string;
    AccountId?: string | undefined;
}
export type InsightName = string;
export type InsightStatus = "ONGOING" | "CLOSED" | (string & {});
export interface InsightTimeRange {
    StartTime: Date;
    EndTime?: Date | undefined;
}
export type SsmOpsItemId = string;
export type InsightDescription = string;
export interface ProactiveInsight {
    Id?: string | undefined;
    Name?: string | undefined;
    Severity?: InsightSeverity | undefined;
    Status?: InsightStatus | undefined;
    InsightTimeRange?: InsightTimeRange | undefined;
    PredictionTimeRange?: PredictionTimeRange | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    SsmOpsItemId?: string | undefined;
    Description?: string | undefined;
}
export interface ReactiveInsight {
    Id?: string | undefined;
    Name?: string | undefined;
    Severity?: InsightSeverity | undefined;
    Status?: InsightStatus | undefined;
    InsightTimeRange?: InsightTimeRange | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    SsmOpsItemId?: string | undefined;
    Description?: string | undefined;
}
export interface DescribeInsightResponse {
    ProactiveInsight?: ProactiveInsight | undefined;
    ReactiveInsight?: ReactiveInsight | undefined;
}
export type AccountIdList = string[];
export type OrganizationalUnitId = string;
export type OrganizationalUnitIdList = string[];
export interface DescribeOrganizationHealthRequest {
    AccountIds?: string[] | undefined;
    OrganizationalUnitIds?: string[] | undefined;
}
export interface DescribeOrganizationHealthResponse {
    OpenReactiveInsights: number;
    OpenProactiveInsights: number;
    MetricsAnalyzed: number;
    ResourceHours: number;
}
export interface DescribeOrganizationOverviewRequest {
    FromTime: Date;
    ToTime?: Date | undefined;
    AccountIds?: string[] | undefined;
    OrganizationalUnitIds?: string[] | undefined;
}
export interface DescribeOrganizationOverviewResponse {
    ReactiveInsights: number;
    ProactiveInsights: number;
}
export type OrganizationResourceCollectionType = "AWS_CLOUD_FORMATION" | "AWS_SERVICE" | "AWS_ACCOUNT" | "AWS_TAGS" | (string & {});
export type UuidNextToken = string;
export type OrganizationResourceCollectionMaxResults = number;
export interface DescribeOrganizationResourceCollectionHealthRequest {
    OrganizationResourceCollectionType: OrganizationResourceCollectionType;
    AccountIds?: string[] | undefined;
    OrganizationalUnitIds?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface InsightHealth {
    OpenProactiveInsights?: number | undefined;
    OpenReactiveInsights?: number | undefined;
    MeanTimeToRecoverInMilliseconds?: number | undefined;
}
export interface CloudFormationHealth {
    StackName?: string | undefined;
    Insight?: InsightHealth | undefined;
    AnalyzedResourceCount?: number | undefined;
}
export type CloudFormationHealths = CloudFormationHealth[];
export type ServiceName = "API_GATEWAY" | "APPLICATION_ELB" | "AUTO_SCALING_GROUP" | "CLOUD_FRONT" | "DYNAMO_DB" | "EC2" | "ECS" | "EKS" | "ELASTIC_BEANSTALK" | "ELASTI_CACHE" | "ELB" | "ES" | "KINESIS" | "LAMBDA" | "NAT_GATEWAY" | "NETWORK_ELB" | "RDS" | "REDSHIFT" | "ROUTE_53" | "S3" | "SAGE_MAKER" | "SNS" | "SQS" | "STEP_FUNCTIONS" | "SWF" | (string & {});
export interface ServiceInsightHealth {
    OpenProactiveInsights?: number | undefined;
    OpenReactiveInsights?: number | undefined;
}
export interface ServiceHealth {
    ServiceName?: ServiceName | undefined;
    Insight?: ServiceInsightHealth | undefined;
    AnalyzedResourceCount?: number | undefined;
}
export type ServiceHealths = ServiceHealth[];
export interface AccountInsightHealth {
    OpenProactiveInsights?: number | undefined;
    OpenReactiveInsights?: number | undefined;
}
export interface AccountHealth {
    AccountId?: string | undefined;
    Insight?: AccountInsightHealth | undefined;
}
export type AccountHealths = AccountHealth[];
export interface TagHealth {
    AppBoundaryKey?: string | undefined;
    TagValue?: string | undefined;
    Insight?: InsightHealth | undefined;
    AnalyzedResourceCount?: number | undefined;
}
export type TagHealths = TagHealth[];
export interface DescribeOrganizationResourceCollectionHealthResponse {
    CloudFormation?: CloudFormationHealth[] | undefined;
    Service?: ServiceHealth[] | undefined;
    Account?: AccountHealth[] | undefined;
    NextToken?: string | undefined;
    Tags?: TagHealth[] | undefined;
}
export type ResourceCollectionType = "AWS_CLOUD_FORMATION" | "AWS_SERVICE" | "AWS_TAGS" | (string & {});
export interface DescribeResourceCollectionHealthRequest {
    ResourceCollectionType: ResourceCollectionType;
    NextToken?: string | undefined;
}
export interface DescribeResourceCollectionHealthResponse {
    CloudFormation?: CloudFormationHealth[] | undefined;
    Service?: ServiceHealth[] | undefined;
    NextToken?: string | undefined;
    Tags?: TagHealth[] | undefined;
}
export interface DescribeServiceIntegrationRequest {
}
export type OptInStatus = "ENABLED" | "DISABLED" | (string & {});
export interface OpsCenterIntegration {
    OptInStatus?: OptInStatus | undefined;
}
export interface LogsAnomalyDetectionIntegration {
    OptInStatus?: OptInStatus | undefined;
}
export type KMSKeyId = string;
export type ServerSideEncryptionType = "CUSTOMER_MANAGED_KEY" | "AWS_OWNED_KMS_KEY" | (string & {});
export interface KMSServerSideEncryptionIntegration {
    KMSKeyId?: string | undefined;
    OptInStatus?: OptInStatus | undefined;
    Type?: ServerSideEncryptionType | undefined;
}
export interface ServiceIntegrationConfig {
    OpsCenter?: OpsCenterIntegration | undefined;
    LogsAnomalyDetection?: LogsAnomalyDetectionIntegration | undefined;
    KMSServerSideEncryption?: KMSServerSideEncryptionIntegration | undefined;
}
export interface DescribeServiceIntegrationResponse {
    ServiceIntegration?: ServiceIntegrationConfig | undefined;
}
export interface GetCostEstimationRequest {
    NextToken?: string | undefined;
}
export type CostEstimationStackNames = string[];
export interface CloudFormationCostEstimationResourceCollectionFilter {
    StackNames?: string[] | undefined;
}
export type CostEstimationTagValues = string[];
export interface TagCostEstimationResourceCollectionFilter {
    AppBoundaryKey: string;
    TagValues: string[];
}
export type TagCostEstimationResourceCollectionFilters = TagCostEstimationResourceCollectionFilter[];
export interface CostEstimationResourceCollectionFilter {
    CloudFormation?: CloudFormationCostEstimationResourceCollectionFilter | undefined;
    Tags?: TagCostEstimationResourceCollectionFilter[] | undefined;
}
export type CostEstimationStatus = "ONGOING" | "COMPLETED" | (string & {});
export type CostEstimationServiceResourceState = "ACTIVE" | "INACTIVE" | (string & {});
export type CostEstimationServiceResourceCount = number;
export type Cost = number;
export interface ServiceResourceCost {
    Type?: string | undefined;
    State?: CostEstimationServiceResourceState | undefined;
    Count?: number | undefined;
    UnitCost?: number | undefined;
    Cost?: number | undefined;
}
export type ServiceResourceCosts = ServiceResourceCost[];
export interface CostEstimationTimeRange {
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface GetCostEstimationResponse {
    ResourceCollection?: CostEstimationResourceCollectionFilter | undefined;
    Status?: CostEstimationStatus | undefined;
    Costs?: ServiceResourceCost[] | undefined;
    TimeRange?: CostEstimationTimeRange | undefined;
    TotalCost?: number | undefined;
    NextToken?: string | undefined;
}
export interface GetResourceCollectionRequest {
    ResourceCollectionType: ResourceCollectionType;
    NextToken?: string | undefined;
}
export interface CloudFormationCollectionFilter {
    StackNames?: string[] | undefined;
}
export interface TagCollectionFilter {
    AppBoundaryKey: string;
    TagValues: string[];
}
export type TagCollectionFilters = TagCollectionFilter[];
export interface ResourceCollectionFilter {
    CloudFormation?: CloudFormationCollectionFilter | undefined;
    Tags?: TagCollectionFilter[] | undefined;
}
export interface GetResourceCollectionResponse {
    ResourceCollection?: ResourceCollectionFilter | undefined;
    NextToken?: string | undefined;
}
export interface StartTimeRange {
    FromTime?: Date | undefined;
    ToTime?: Date | undefined;
}
export type ListAnomaliesForInsightMaxResults = number;
export type ServiceNames = ServiceName[];
export interface ServiceCollection {
    ServiceNames?: ServiceName[] | undefined;
}
export interface ListAnomaliesForInsightFilters {
    ServiceCollection?: ServiceCollection | undefined;
}
export interface ListAnomaliesForInsightRequest {
    InsightId: string;
    StartTimeRange?: StartTimeRange | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
    Filters?: ListAnomaliesForInsightFilters | undefined;
}
export interface ProactiveAnomalySummary {
    Id?: string | undefined;
    Severity?: AnomalySeverity | undefined;
    Status?: AnomalyStatus | undefined;
    UpdateTime?: Date | undefined;
    AnomalyTimeRange?: AnomalyTimeRange | undefined;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange | undefined;
    PredictionTimeRange?: PredictionTimeRange | undefined;
    SourceDetails?: AnomalySourceDetails | undefined;
    AssociatedInsightId?: string | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    Limit?: number | undefined;
    SourceMetadata?: AnomalySourceMetadata | undefined;
    AnomalyResources?: AnomalyResource[] | undefined;
    Description?: string | undefined;
}
export type ProactiveAnomalies = ProactiveAnomalySummary[];
export interface ReactiveAnomalySummary {
    Id?: string | undefined;
    Severity?: AnomalySeverity | undefined;
    Status?: AnomalyStatus | undefined;
    AnomalyTimeRange?: AnomalyTimeRange | undefined;
    AnomalyReportedTimeRange?: AnomalyReportedTimeRange | undefined;
    SourceDetails?: AnomalySourceDetails | undefined;
    AssociatedInsightId?: string | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    Type?: AnomalyType | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CausalAnomalyId?: string | undefined;
    AnomalyResources?: AnomalyResource[] | undefined;
}
export type ReactiveAnomalies = ReactiveAnomalySummary[];
export interface ListAnomaliesForInsightResponse {
    ProactiveAnomalies?: ProactiveAnomalySummary[] | undefined;
    ReactiveAnomalies?: ReactiveAnomalySummary[] | undefined;
    NextToken?: string | undefined;
}
export type ListAnomalousLogGroupsMaxResults = number;
export interface ListAnomalousLogGroupsRequest {
    InsightId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type LogGroupName = string;
export type NumberOfLogLinesScanned = number;
export type LogStreamName = string;
export type LogAnomalyType = "KEYWORD" | "KEYWORD_TOKEN" | "FORMAT" | "HTTP_CODE" | "BLOCK_FORMAT" | "NUMERICAL_POINT" | "NUMERICAL_NAN" | "NEW_FIELD_NAME" | (string & {});
export type LogAnomalyToken = string;
export type LogEventId = string;
export type Explanation = string;
export type NumberOfLogLinesOccurrences = number;
export interface LogAnomalyClass {
    LogStreamName?: string | undefined;
    LogAnomalyType?: LogAnomalyType | undefined;
    LogAnomalyToken?: string | undefined;
    LogEventId?: string | undefined;
    Explanation?: string | undefined;
    NumberOfLogLinesOccurrences?: number | undefined;
    LogEventTimestamp?: Date | undefined;
}
export type LogAnomalyClasses = LogAnomalyClass[];
export interface LogAnomalyShowcase {
    LogAnomalyClasses?: LogAnomalyClass[] | undefined;
}
export type LogAnomalyShowcases = LogAnomalyShowcase[];
export interface AnomalousLogGroup {
    LogGroupName?: string | undefined;
    ImpactStartTime?: Date | undefined;
    ImpactEndTime?: Date | undefined;
    NumberOfLogLinesScanned?: number | undefined;
    LogAnomalyShowcases?: LogAnomalyShowcase[] | undefined;
}
export type AnomalousLogGroups = AnomalousLogGroup[];
export interface ListAnomalousLogGroupsResponse {
    InsightId: string;
    AnomalousLogGroups: AnomalousLogGroup[];
    NextToken?: string | undefined;
}
export interface EventTimeRange {
    FromTime: Date;
    ToTime: Date;
}
export type EventClass = "INFRASTRUCTURE" | "DEPLOYMENT" | "SECURITY_CHANGE" | "CONFIG_CHANGE" | "SCHEMA_CHANGE" | (string & {});
export type EventSource = string;
export type EventDataSource = "AWS_CLOUD_TRAIL" | "AWS_CODE_DEPLOY" | (string & {});
export interface ListEventsFilters {
    InsightId?: string | undefined;
    EventTimeRange?: EventTimeRange | undefined;
    EventClass?: EventClass | undefined;
    EventSource?: string | undefined;
    DataSource?: EventDataSource | undefined;
    ResourceCollection?: ResourceCollection | undefined;
}
export type ListEventsMaxResults = number;
export interface ListEventsRequest {
    Filters: ListEventsFilters;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type EventId = string;
export type EventName = string;
export type EventResourceType = string;
export type EventResourceName = string;
export type EventResourceArn = string;
export interface EventResource {
    Type?: string | undefined;
    Name?: string | undefined;
    Arn?: string | undefined;
}
export type EventResources = EventResource[];
export interface Event {
    ResourceCollection?: ResourceCollection | undefined;
    Id?: string | undefined;
    Time?: Date | undefined;
    EventSource?: string | undefined;
    Name?: string | undefined;
    DataSource?: EventDataSource | undefined;
    EventClass?: EventClass | undefined;
    Resources?: EventResource[] | undefined;
}
export type Events = Event[];
export interface ListEventsResponse {
    Events: Event[];
    NextToken?: string | undefined;
}
export type InsightType = "REACTIVE" | "PROACTIVE" | (string & {});
export interface ListInsightsOngoingStatusFilter {
    Type: InsightType;
}
export interface EndTimeRange {
    FromTime?: Date | undefined;
    ToTime?: Date | undefined;
}
export interface ListInsightsClosedStatusFilter {
    Type: InsightType;
    EndTimeRange: EndTimeRange;
}
export interface ListInsightsAnyStatusFilter {
    Type: InsightType;
    StartTimeRange: StartTimeRange;
}
export interface ListInsightsStatusFilter {
    Ongoing?: ListInsightsOngoingStatusFilter | undefined;
    Closed?: ListInsightsClosedStatusFilter | undefined;
    Any?: ListInsightsAnyStatusFilter | undefined;
}
export type ListInsightsMaxResults = number;
export interface ListInsightsRequest {
    StatusFilter: ListInsightsStatusFilter;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ResourceArn = string;
export type AssociatedResourceArns = string[];
export interface ProactiveInsightSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Severity?: InsightSeverity | undefined;
    Status?: InsightStatus | undefined;
    InsightTimeRange?: InsightTimeRange | undefined;
    PredictionTimeRange?: PredictionTimeRange | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    ServiceCollection?: ServiceCollection | undefined;
    AssociatedResourceArns?: string[] | undefined;
}
export type ProactiveInsights = ProactiveInsightSummary[];
export interface ReactiveInsightSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Severity?: InsightSeverity | undefined;
    Status?: InsightStatus | undefined;
    InsightTimeRange?: InsightTimeRange | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    ServiceCollection?: ServiceCollection | undefined;
    AssociatedResourceArns?: string[] | undefined;
}
export type ReactiveInsights = ReactiveInsightSummary[];
export interface ListInsightsResponse {
    ProactiveInsights?: ProactiveInsightSummary[] | undefined;
    ReactiveInsights?: ReactiveInsightSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ResourcePermission = "FULL_PERMISSION" | "MISSING_PERMISSION" | (string & {});
export type ResourceTypeFilter = "LOG_GROUPS" | "CLOUDFRONT_DISTRIBUTION" | "DYNAMODB_TABLE" | "EC2_NAT_GATEWAY" | "ECS_CLUSTER" | "ECS_SERVICE" | "EKS_CLUSTER" | "ELASTIC_BEANSTALK_ENVIRONMENT" | "ELASTIC_LOAD_BALANCER_LOAD_BALANCER" | "ELASTIC_LOAD_BALANCING_V2_LOAD_BALANCER" | "ELASTIC_LOAD_BALANCING_V2_TARGET_GROUP" | "ELASTICACHE_CACHE_CLUSTER" | "ELASTICSEARCH_DOMAIN" | "KINESIS_STREAM" | "LAMBDA_FUNCTION" | "OPEN_SEARCH_SERVICE_DOMAIN" | "RDS_DB_INSTANCE" | "RDS_DB_CLUSTER" | "REDSHIFT_CLUSTER" | "ROUTE53_HOSTED_ZONE" | "ROUTE53_HEALTH_CHECK" | "S3_BUCKET" | "SAGEMAKER_ENDPOINT" | "SNS_TOPIC" | "SQS_QUEUE" | "STEP_FUNCTIONS_ACTIVITY" | "STEP_FUNCTIONS_STATE_MACHINE" | (string & {});
export type ResourceTypeFilters = ResourceTypeFilter[];
export interface ListMonitoredResourcesFilters {
    ResourcePermission: ResourcePermission;
    ResourceTypeFilters: ResourceTypeFilter[];
}
export type ListMonitoredResourcesMaxResults = number;
export interface ListMonitoredResourcesRequest {
    Filters?: ListMonitoredResourcesFilters | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type MonitoredResourceName = string;
export interface MonitoredResourceIdentifier {
    MonitoredResourceName?: string | undefined;
    Type?: string | undefined;
    ResourcePermission?: ResourcePermission | undefined;
    LastUpdated?: Date | undefined;
    ResourceCollection?: ResourceCollection | undefined;
}
export type MonitoredResourceIdentifiers = MonitoredResourceIdentifier[];
export interface ListMonitoredResourcesResponse {
    MonitoredResourceIdentifiers: MonitoredResourceIdentifier[];
    NextToken?: string | undefined;
}
export interface ListNotificationChannelsRequest {
    NextToken?: string | undefined;
}
export interface NotificationChannel {
    Id?: string | undefined;
    Config?: NotificationChannelConfig | undefined;
}
export type Channels = NotificationChannel[];
export interface ListNotificationChannelsResponse {
    Channels?: NotificationChannel[] | undefined;
    NextToken?: string | undefined;
}
export type ListInsightsAccountIdList = string[];
export type ListInsightsOrganizationalUnitIdList = string[];
export interface ListOrganizationInsightsRequest {
    StatusFilter: ListInsightsStatusFilter;
    MaxResults?: number | undefined;
    AccountIds?: string[] | undefined;
    OrganizationalUnitIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ProactiveOrganizationInsightSummary {
    Id?: string | undefined;
    AccountId?: string | undefined;
    OrganizationalUnitId?: string | undefined;
    Name?: string | undefined;
    Severity?: InsightSeverity | undefined;
    Status?: InsightStatus | undefined;
    InsightTimeRange?: InsightTimeRange | undefined;
    PredictionTimeRange?: PredictionTimeRange | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    ServiceCollection?: ServiceCollection | undefined;
}
export type ProactiveOrganizationInsights = ProactiveOrganizationInsightSummary[];
export interface ReactiveOrganizationInsightSummary {
    Id?: string | undefined;
    AccountId?: string | undefined;
    OrganizationalUnitId?: string | undefined;
    Name?: string | undefined;
    Severity?: InsightSeverity | undefined;
    Status?: InsightStatus | undefined;
    InsightTimeRange?: InsightTimeRange | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    ServiceCollection?: ServiceCollection | undefined;
}
export type ReactiveOrganizationInsights = ReactiveOrganizationInsightSummary[];
export interface ListOrganizationInsightsResponse {
    ProactiveInsights?: ProactiveOrganizationInsightSummary[] | undefined;
    ReactiveInsights?: ReactiveOrganizationInsightSummary[] | undefined;
    NextToken?: string | undefined;
}
export type Locale = "DE_DE" | "EN_US" | "EN_GB" | "ES_ES" | "FR_FR" | "IT_IT" | "JA_JP" | "KO_KR" | "PT_BR" | "ZH_CN" | "ZH_TW" | (string & {});
export interface ListRecommendationsRequest {
    InsightId: string;
    NextToken?: string | undefined;
    Locale?: Locale | undefined;
    AccountId?: string | undefined;
}
export type RecommendationDescription = string;
export type RecommendationLink = string;
export type RecommendationName = string;
export type RecommendationReason = string;
export type RecommendationRelatedEventName = string;
export type RecommendationRelatedEventResourceName = string;
export type RecommendationRelatedEventResourceType = string;
export interface RecommendationRelatedEventResource {
    Name?: string | undefined;
    Type?: string | undefined;
}
export type RecommendationRelatedEventResources = RecommendationRelatedEventResource[];
export interface RecommendationRelatedEvent {
    Name?: string | undefined;
    Resources?: RecommendationRelatedEventResource[] | undefined;
}
export type RecommendationRelatedEvents = RecommendationRelatedEvent[];
export type RecommendationRelatedAnomalyResourceName = string;
export type RecommendationRelatedAnomalyResourceType = string;
export interface RecommendationRelatedAnomalyResource {
    Name?: string | undefined;
    Type?: string | undefined;
}
export type RecommendationRelatedAnomalyResources = RecommendationRelatedAnomalyResource[];
export type RecommendationRelatedCloudWatchMetricsSourceMetricName = string;
export type RecommendationRelatedCloudWatchMetricsSourceNamespace = string;
export interface RecommendationRelatedCloudWatchMetricsSourceDetail {
    MetricName?: string | undefined;
    Namespace?: string | undefined;
}
export type RecommendationRelatedCloudWatchMetricsSourceDetails = RecommendationRelatedCloudWatchMetricsSourceDetail[];
export interface RecommendationRelatedAnomalySourceDetail {
    CloudWatchMetrics?: RecommendationRelatedCloudWatchMetricsSourceDetail[] | undefined;
}
export type RelatedAnomalySourceDetails = RecommendationRelatedAnomalySourceDetail[];
export interface RecommendationRelatedAnomaly {
    Resources?: RecommendationRelatedAnomalyResource[] | undefined;
    SourceDetails?: RecommendationRelatedAnomalySourceDetail[] | undefined;
    AnomalyId?: string | undefined;
}
export type RecommendationRelatedAnomalies = RecommendationRelatedAnomaly[];
export type RecommendationCategory = string;
export interface Recommendation {
    Description?: string | undefined;
    Link?: string | undefined;
    Name?: string | undefined;
    Reason?: string | undefined;
    RelatedEvents?: RecommendationRelatedEvent[] | undefined;
    RelatedAnomalies?: RecommendationRelatedAnomaly[] | undefined;
    Category?: string | undefined;
}
export type Recommendations = Recommendation[];
export interface ListRecommendationsResponse {
    Recommendations?: Recommendation[] | undefined;
    NextToken?: string | undefined;
}
export interface PutFeedbackRequest {
    InsightFeedback?: InsightFeedback | undefined;
}
export interface PutFeedbackResponse {
}
export interface RemoveNotificationChannelRequest {
    Id: string;
}
export interface RemoveNotificationChannelResponse {
}
export type InsightStatuses = InsightStatus[];
export interface SearchInsightsFilters {
    Severities?: InsightSeverity[] | undefined;
    Statuses?: InsightStatus[] | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    ServiceCollection?: ServiceCollection | undefined;
}
export type SearchInsightsMaxResults = number;
export interface SearchInsightsRequest {
    StartTimeRange: StartTimeRange;
    Filters?: SearchInsightsFilters | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Type: InsightType;
}
export interface SearchInsightsResponse {
    ProactiveInsights?: ProactiveInsightSummary[] | undefined;
    ReactiveInsights?: ReactiveInsightSummary[] | undefined;
    NextToken?: string | undefined;
}
export type SearchInsightsAccountIdList = string[];
export interface SearchOrganizationInsightsFilters {
    Severities?: InsightSeverity[] | undefined;
    Statuses?: InsightStatus[] | undefined;
    ResourceCollection?: ResourceCollection | undefined;
    ServiceCollection?: ServiceCollection | undefined;
}
export type SearchOrganizationInsightsMaxResults = number;
export interface SearchOrganizationInsightsRequest {
    AccountIds: string[];
    StartTimeRange: StartTimeRange;
    Filters?: SearchOrganizationInsightsFilters | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Type: InsightType;
}
export interface SearchOrganizationInsightsResponse {
    ProactiveInsights?: ProactiveInsightSummary[] | undefined;
    ReactiveInsights?: ReactiveInsightSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ClientToken = string;
export interface StartCostEstimationRequest {
    ResourceCollection: CostEstimationResourceCollectionFilter;
    ClientToken?: string | undefined;
}
export interface StartCostEstimationResponse {
}
export interface UpdateEventSourcesConfigRequest {
    EventSources?: EventSourcesConfig | undefined;
}
export interface UpdateEventSourcesConfigResponse {
}
export type UpdateResourceCollectionAction = "ADD" | "REMOVE" | (string & {});
export type UpdateStackNames = string[];
export interface UpdateCloudFormationCollectionFilter {
    StackNames?: string[] | undefined;
}
export type UpdateTagValues = string[];
export interface UpdateTagCollectionFilter {
    AppBoundaryKey: string;
    TagValues: string[];
}
export type UpdateTagCollectionFilters = UpdateTagCollectionFilter[];
export interface UpdateResourceCollectionFilter {
    CloudFormation?: UpdateCloudFormationCollectionFilter | undefined;
    Tags?: UpdateTagCollectionFilter[] | undefined;
}
export interface UpdateResourceCollectionRequest {
    Action: UpdateResourceCollectionAction;
    ResourceCollection: UpdateResourceCollectionFilter;
}
export interface UpdateResourceCollectionResponse {
}
export interface OpsCenterIntegrationConfig {
    OptInStatus?: OptInStatus | undefined;
}
export interface LogsAnomalyDetectionIntegrationConfig {
    OptInStatus?: OptInStatus | undefined;
}
export interface KMSServerSideEncryptionIntegrationConfig {
    KMSKeyId?: string | undefined;
    OptInStatus?: OptInStatus | undefined;
    Type?: ServerSideEncryptionType | undefined;
}
export interface UpdateServiceIntegrationConfig {
    OpsCenter?: OpsCenterIntegrationConfig | undefined;
    LogsAnomalyDetection?: LogsAnomalyDetectionIntegrationConfig | undefined;
    KMSServerSideEncryption?: KMSServerSideEncryptionIntegrationConfig | undefined;
}
export interface UpdateServiceIntegrationRequest {
    ServiceIntegration: UpdateServiceIntegrationConfig;
}
export interface UpdateServiceIntegrationResponse {
}
export type ErrorMessageString = string;
export type ResourceIdString = string;
export type ResourceIdType = string;
export type RetryAfterSeconds = number;
export type ErrorQuotaCodeString = string;
export type ErrorServiceCodeString = string;
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "OTHER" | "INVALID_PARAMETER_COMBINATION" | "PARAMETER_INCONSISTENT_WITH_SERVICE_STATE" | (string & {});
export type ErrorNameString = string;
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFields = ValidationExceptionField[];
export type AddNotificationChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a notification channel to DevOps Guru. A notification channel is used to notify you
 * about important DevOps Guru events, such as when an insight is generated.
 *
 * If you use an Amazon SNS topic in another account, you must attach a policy to it that grants DevOps Guru permission
 * to send it notifications. DevOps Guru adds the required policy on your behalf to send notifications using Amazon SNS in your account. DevOps Guru only supports standard SNS topics.
 * For more information, see Permissions
 * for Amazon SNS topics.
 *
 * If you use an Amazon SNS topic that is encrypted by an Amazon Web Services Key Management Service customer-managed key (CMK), then you must add permissions
 * to the CMK. For more information, see Permissions for
 * Amazon Web Services KMS-encrypted Amazon SNS topics.
 */
export declare const addNotificationChannel: API.OperationMethod<AddNotificationChannelRequest & RegionInput, AddNotificationChannelResponse, AddNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteInsightError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the insight along with the associated anomalies, events and recommendations.
 */
export declare const deleteInsight: API.OperationMethod<DeleteInsightRequest & RegionInput, DeleteInsightResponse, DeleteInsightError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the number of open reactive insights, the number of open proactive insights,
 * and the number of metrics analyzed in your Amazon Web Services account. Use these numbers to gauge the
 * health of operations in your Amazon Web Services account.
 */
export declare const describeAccountHealth: API.OperationMethod<DescribeAccountHealthRequest & RegionInput, DescribeAccountHealthResponse, DescribeAccountHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountOverviewError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * For the time range passed in, returns the number of open reactive insight that were
 * created, the number of open proactive insights that were created, and the Mean Time to Recover (MTTR) for all
 * closed reactive insights.
 */
export declare const describeAccountOverview: API.OperationMethod<DescribeAccountOverviewRequest & RegionInput, DescribeAccountOverviewResponse, DescribeAccountOverviewError, Credentials | HttpClient.HttpClient>;
export type DescribeAnomalyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about an anomaly that you specify using its ID.
 */
export declare const describeAnomaly: API.OperationMethod<DescribeAnomalyRequest & RegionInput, DescribeAnomalyResponse, DescribeAnomalyError, Credentials | HttpClient.HttpClient>;
export type DescribeEventSourcesConfigError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the integration status of services that are integrated with DevOps Guru as Consumer
 * via EventBridge. The one service that can be integrated with DevOps Guru is Amazon CodeGuru
 * Profiler, which can produce proactive recommendations which can be stored and viewed in
 * DevOps Guru.
 */
export declare const describeEventSourcesConfig: API.OperationMethod<DescribeEventSourcesConfigRequest & RegionInput, DescribeEventSourcesConfigResponse, DescribeEventSourcesConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the most recent feedback submitted in the current Amazon Web Services account and Region.
 */
export declare const describeFeedback: API.OperationMethod<DescribeFeedbackRequest & RegionInput, DescribeFeedbackResponse, DescribeFeedbackError, Credentials | HttpClient.HttpClient>;
export type DescribeInsightError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about an insight that you specify using its ID.
 */
export declare const describeInsight: API.OperationMethod<DescribeInsightRequest & RegionInput, DescribeInsightResponse, DescribeInsightError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns active insights, predictive insights, and resource hours analyzed in last
 * hour.
 */
export declare const describeOrganizationHealth: API.OperationMethod<DescribeOrganizationHealthRequest & RegionInput, DescribeOrganizationHealthResponse, DescribeOrganizationHealthError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationOverviewError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an overview of your organization's history based on the specified time range.
 * The overview includes the total reactive and proactive insights.
 */
export declare const describeOrganizationOverview: API.OperationMethod<DescribeOrganizationOverviewRequest & RegionInput, DescribeOrganizationOverviewResponse, DescribeOrganizationOverviewError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationResourceCollectionHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides an overview of your system's health. If additional member accounts are part
 * of your organization, you can filter those accounts using the `AccountIds`
 * field.
 */
export declare const describeOrganizationResourceCollectionHealth: API.PaginatedOperationMethod<DescribeOrganizationResourceCollectionHealthRequest & RegionInput, DescribeOrganizationResourceCollectionHealthResponse, DescribeOrganizationResourceCollectionHealthError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeResourceCollectionHealthError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the number of open proactive insights, open reactive insights, and the Mean Time to Recover (MTTR)
 * for all closed insights in resource collections in your account. You specify the type of
 * Amazon Web Services resources collection. The two types of Amazon Web Services resource collections supported are Amazon Web Services CloudFormation stacks and
 * Amazon Web Services resources that contain the same Amazon Web Services tag. DevOps Guru can be configured to analyze
 * the Amazon Web Services resources that are defined in the stacks or that are tagged using the same tag *key*. You can specify up to 500 Amazon Web Services CloudFormation stacks.
 */
export declare const describeResourceCollectionHealth: API.PaginatedOperationMethod<DescribeResourceCollectionHealthRequest & RegionInput, DescribeResourceCollectionHealthResponse, DescribeResourceCollectionHealthError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeServiceIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the integration status of services that are integrated with DevOps Guru.
 * The one service that can be integrated with DevOps Guru
 * is Amazon Web Services Systems Manager, which can be used to create an OpsItem for each generated insight.
 */
export declare const describeServiceIntegration: API.OperationMethod<DescribeServiceIntegrationRequest & RegionInput, DescribeServiceIntegrationResponse, DescribeServiceIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetCostEstimationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an estimate of the monthly cost for DevOps Guru to analyze your Amazon Web Services resources.
 * For more information,
 * see Estimate your
 * Amazon DevOps Guru costs and
 * Amazon DevOps Guru pricing.
 */
export declare const getCostEstimation: API.PaginatedOperationMethod<GetCostEstimationRequest & RegionInput, GetCostEstimationResponse, GetCostEstimationError, Credentials | HttpClient.HttpClient, unknown>;
export type GetResourceCollectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns lists Amazon Web Services resources that are of the specified resource collection type.
 * The two types of Amazon Web Services resource collections supported are Amazon Web Services CloudFormation stacks and
 * Amazon Web Services resources that contain the same Amazon Web Services tag. DevOps Guru can be configured to analyze
 * the Amazon Web Services resources that are defined in the stacks or that are tagged using the same tag *key*. You can specify up to 500 Amazon Web Services CloudFormation stacks.
 */
export declare const getResourceCollection: API.PaginatedOperationMethod<GetResourceCollectionRequest & RegionInput, GetResourceCollectionResponse, GetResourceCollectionError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAnomaliesForInsightError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the anomalies that belong to an insight that you specify using its
 * ID.
 */
export declare const listAnomaliesForInsight: API.PaginatedOperationMethod<ListAnomaliesForInsightRequest & RegionInput, ListAnomaliesForInsightResponse, ListAnomaliesForInsightError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAnomalousLogGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of log groups that contain log anomalies.
 */
export declare const listAnomalousLogGroups: API.PaginatedOperationMethod<ListAnomalousLogGroupsRequest & RegionInput, ListAnomalousLogGroupsResponse, ListAnomalousLogGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the events emitted by the resources that are evaluated by DevOps Guru.
 * You can use filters to specify which events are returned.
 */
export declare const listEvents: API.PaginatedOperationMethod<ListEventsRequest & RegionInput, ListEventsResponse, ListEventsError, Credentials | HttpClient.HttpClient, Event>;
export type ListInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights in your Amazon Web Services account. You can specify which insights are
 * returned by their start time and status (`ONGOING`, `CLOSED`, or
 * `ANY`).
 */
export declare const listInsights: API.PaginatedOperationMethod<ListInsightsRequest & RegionInput, ListInsightsResponse, ListInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMonitoredResourcesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of all log groups that are being monitored and tagged by DevOps Guru.
 */
export declare const listMonitoredResources: API.PaginatedOperationMethod<ListMonitoredResourcesRequest & RegionInput, ListMonitoredResourcesResponse, ListMonitoredResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNotificationChannelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of notification channels configured for DevOps Guru. Each notification
 * channel is used to notify you when DevOps Guru generates an insight that contains information
 * about how to improve your operations. The one
 * supported notification channel is Amazon Simple Notification Service (Amazon SNS).
 */
export declare const listNotificationChannels: API.PaginatedOperationMethod<ListNotificationChannelsRequest & RegionInput, ListNotificationChannelsResponse, ListNotificationChannelsError, Credentials | HttpClient.HttpClient, NotificationChannel>;
export type ListOrganizationInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights associated with the account or OU Id.
 */
export declare const listOrganizationInsights: API.PaginatedOperationMethod<ListOrganizationInsightsRequest & RegionInput, ListOrganizationInsightsResponse, ListOrganizationInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of a specified insight's recommendations. Each recommendation includes
 * a list of related metrics and a list of related events.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest & RegionInput, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, Recommendation>;
export type PutFeedbackError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Collects customer feedback about the specified insight.
 */
export declare const putFeedback: API.OperationMethod<PutFeedbackRequest & RegionInput, PutFeedbackResponse, PutFeedbackError, Credentials | HttpClient.HttpClient>;
export type RemoveNotificationChannelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a notification channel from DevOps Guru. A notification channel is used to notify
 * you when DevOps Guru generates an insight that contains information about how to improve your
 * operations.
 */
export declare const removeNotificationChannel: API.OperationMethod<RemoveNotificationChannelRequest & RegionInput, RemoveNotificationChannelResponse, RemoveNotificationChannelError, Credentials | HttpClient.HttpClient>;
export type SearchInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights in your Amazon Web Services account. You can specify which insights are
 * returned by their start time, one or more statuses (`ONGOING` or `CLOSED`), one or more severities
 * (`LOW`, `MEDIUM`, and `HIGH`), and type
 * (`REACTIVE` or `PROACTIVE`).
 *
 * Use the `Filters` parameter to specify status and severity search
 * parameters. Use the `Type` parameter to specify `REACTIVE` or
 * `PROACTIVE` in your search.
 */
export declare const searchInsights: API.PaginatedOperationMethod<SearchInsightsRequest & RegionInput, SearchInsightsResponse, SearchInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type SearchOrganizationInsightsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of insights in your organization. You can specify which insights are
 * returned by their start time, one or more statuses (`ONGOING`,
 * `CLOSED`, and `CLOSED`), one or more severities
 * (`LOW`, `MEDIUM`, and `HIGH`), and type
 * (`REACTIVE` or `PROACTIVE`).
 *
 * Use the `Filters` parameter to specify status and severity search
 * parameters. Use the `Type` parameter to specify `REACTIVE` or
 * `PROACTIVE` in your search.
 */
export declare const searchOrganizationInsights: API.PaginatedOperationMethod<SearchOrganizationInsightsRequest & RegionInput, SearchOrganizationInsightsResponse, SearchOrganizationInsightsError, Credentials | HttpClient.HttpClient, unknown>;
export type StartCostEstimationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the creation of an estimate of the monthly cost to analyze your Amazon Web Services
 * resources.
 */
export declare const startCostEstimation: API.OperationMethod<StartCostEstimationRequest & RegionInput, StartCostEstimationResponse, StartCostEstimationError, Credentials | HttpClient.HttpClient>;
export type UpdateEventSourcesConfigError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables or disables integration with a service that can be integrated with DevOps Guru. The
 * one service that can be integrated with DevOps Guru is Amazon CodeGuru Profiler, which
 * can produce proactive recommendations which can be stored and viewed in DevOps Guru.
 */
export declare const updateEventSourcesConfig: API.OperationMethod<UpdateEventSourcesConfigRequest & RegionInput, UpdateEventSourcesConfigResponse, UpdateEventSourcesConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceCollectionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the collection of resources that DevOps Guru analyzes.
 * The two types of Amazon Web Services resource collections supported are Amazon Web Services CloudFormation stacks and
 * Amazon Web Services resources that contain the same Amazon Web Services tag. DevOps Guru can be configured to analyze
 * the Amazon Web Services resources that are defined in the stacks or that are tagged using the same tag *key*. You can specify up to 500 Amazon Web Services CloudFormation stacks. This method also creates the IAM role required for
 * you to use DevOps Guru.
 */
export declare const updateResourceCollection: API.OperationMethod<UpdateResourceCollectionRequest & RegionInput, UpdateResourceCollectionResponse, UpdateResourceCollectionError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables or disables integration with a service that can be integrated with DevOps Guru. The
 * one service that can be integrated with DevOps Guru is Amazon Web Services Systems Manager, which can be used to create
 * an OpsItem for each generated insight.
 */
export declare const updateServiceIntegration: API.OperationMethod<UpdateServiceIntegrationRequest & RegionInput, UpdateServiceIntegrationResponse, UpdateServiceIntegrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=devops-guru.d.ts.map