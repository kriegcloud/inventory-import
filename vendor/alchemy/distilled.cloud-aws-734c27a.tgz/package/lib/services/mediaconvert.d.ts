import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
export interface AssociateCertificateRequest {
    Arn?: string | undefined;
}
export interface AssociateCertificateResponse {
}
export interface CancelJobRequest {
    Id: string;
}
export interface CancelJobResponse {
}
export type AccelerationMode = "DISABLED" | "ENABLED" | "PREFERRED" | (string & {});
export interface AccelerationSettings {
    Mode?: AccelerationMode | undefined;
}
export type BillingTagsSource = "QUEUE" | "PRESET" | "JOB_TEMPLATE" | "JOB" | (string & {});
export type __stringPatternArnAwsElementalInferenceFeedAZ0919 = string;
export interface ElementalInferenceFeedConfigurationSource {
    FeedArn?: string | undefined;
}
export interface ElementalInferenceSettings {
    FeedConfigurationSource?: ElementalInferenceFeedConfigurationSource | undefined;
}
export type __integerMinNegative50Max50 = number;
export interface HopDestination {
    Priority?: number | undefined;
    Queue?: string | undefined;
    WaitMinutes?: number | undefined;
}
export type __listOfHopDestination = HopDestination[];
export type __integerMinNegative1000Max1000 = number;
export type __stringMin14PatternS3BmpBMPPngPNGHttpsBmpBMPPngPNG = string;
export interface AvailBlanking {
    AvailBlankingImage?: string | undefined;
}
export type __stringMin14PatternS3CubeCUBEHttpsCubeCUBE = string;
export type ColorSpace = "FOLLOW" | "REC_601" | "REC_709" | "HDR10" | "HLG_2020" | "P3DCI" | "P3D65_SDR" | "P3D65_HDR" | (string & {});
export type __integerMin0Max2147483647 = number;
export interface ColorConversion3DLUTSetting {
    FileInput?: string | undefined;
    InputColorSpace?: ColorSpace | undefined;
    InputMasteringLuminance?: number | undefined;
    OutputColorSpace?: ColorSpace | undefined;
    OutputMasteringLuminance?: number | undefined;
}
export type __listOfColorConversion3DLUTSetting = ColorConversion3DLUTSetting[];
export type __stringPatternSNManifestConfirmConditionNotificationNS = string;
export interface EsamManifestConfirmConditionNotification {
    MccXml?: string | undefined;
}
export type __integerMin0Max30000 = number;
export type __stringPatternSNSignalProcessingNotificationNS = string;
export interface EsamSignalProcessingNotification {
    SccXml?: string | undefined;
}
export interface EsamSettings {
    ManifestConfirmConditionNotification?: EsamManifestConfirmConditionNotification | undefined;
    ResponseSignalPreroll?: number | undefined;
    SignalProcessingNotification?: EsamSignalProcessingNotification | undefined;
}
export type CopyProtectionAction = "PASSTHROUGH" | "STRIP" | (string & {});
export type VchipAction = "PASSTHROUGH" | "STRIP" | (string & {});
export interface ExtendedDataServices {
    CopyProtectionAction?: CopyProtectionAction | undefined;
    VchipAction?: VchipAction | undefined;
}
export type __integerMin1Max150 = number;
export type AdvancedInputFilter = "ENABLED" | "DISABLED" | (string & {});
export type AdvancedInputFilterAddTexture = "ENABLED" | "DISABLED" | (string & {});
export type AdvancedInputFilterSharpen = "OFF" | "LOW" | "HIGH" | (string & {});
export interface AdvancedInputFilterSettings {
    AddTexture?: AdvancedInputFilterAddTexture | undefined;
    Sharpening?: AdvancedInputFilterSharpen | undefined;
}
export type __stringMin1 = string;
export type __listOf__stringMin1 = string[];
export interface AudioSelectorGroup {
    AudioSelectorNames?: string[] | undefined;
}
export type __mapOfAudioSelectorGroup = {
    [key: string]: AudioSelectorGroup | undefined;
};
export type AudioDurationCorrection = "DISABLED" | "AUTO" | "TRACK" | "FRAME" | "FORCE" | (string & {});
export type __stringMin3Max3PatternAZaZ3 = string;
export type AudioDefaultSelection = "DEFAULT" | "NOT_DEFAULT" | (string & {});
export type __stringPatternS3Https = string;
export type LanguageCode = "ENG" | "SPA" | "FRA" | "DEU" | "GER" | "ZHO" | "ARA" | "HIN" | "JPN" | "RUS" | "POR" | "ITA" | "URD" | "VIE" | "KOR" | "PAN" | "ABK" | "AAR" | "AFR" | "AKA" | "SQI" | "AMH" | "ARG" | "HYE" | "ASM" | "AVA" | "AVE" | "AYM" | "AZE" | "BAM" | "BAK" | "EUS" | "BEL" | "BEN" | "BIH" | "BIS" | "BOS" | "BRE" | "BUL" | "MYA" | "CAT" | "KHM" | "CHA" | "CHE" | "NYA" | "CHU" | "CHV" | "COR" | "COS" | "CRE" | "HRV" | "CES" | "DAN" | "DIV" | "NLD" | "DZO" | "ENM" | "EPO" | "EST" | "EWE" | "FAO" | "FIJ" | "FIN" | "FRM" | "FUL" | "GLA" | "GLG" | "LUG" | "KAT" | "ELL" | "GRN" | "GUJ" | "HAT" | "HAU" | "HEB" | "HER" | "HMO" | "HUN" | "ISL" | "IDO" | "IBO" | "IND" | "INA" | "ILE" | "IKU" | "IPK" | "GLE" | "JAV" | "KAL" | "KAN" | "KAU" | "KAS" | "KAZ" | "KIK" | "KIN" | "KIR" | "KOM" | "KON" | "KUA" | "KUR" | "LAO" | "LAT" | "LAV" | "LIM" | "LIN" | "LIT" | "LUB" | "LTZ" | "MKD" | "MLG" | "MSA" | "MAL" | "MLT" | "GLV" | "MRI" | "MAR" | "MAH" | "MON" | "NAU" | "NAV" | "NDE" | "NBL" | "NDO" | "NEP" | "SME" | "NOR" | "NOB" | "NNO" | "OCI" | "OJI" | "ORI" | "ORM" | "OSS" | "PLI" | "FAS" | "POL" | "PUS" | "QUE" | "QAA" | "RON" | "ROH" | "RUN" | "SMO" | "SAG" | "SAN" | "SRD" | "SRB" | "SNA" | "III" | "SND" | "SIN" | "SLK" | "SLV" | "SOM" | "SOT" | "SUN" | "SWA" | "SSW" | "SWE" | "TGL" | "TAH" | "TGK" | "TAM" | "TAT" | "TEL" | "THA" | "BOD" | "TIR" | "TON" | "TSO" | "TSN" | "TUR" | "TUK" | "TWI" | "UIG" | "UKR" | "UZB" | "VEN" | "VOL" | "WLN" | "CYM" | "FRY" | "WOL" | "XHO" | "YID" | "YOR" | "ZHA" | "ZUL" | "ORJ" | "QPC" | "TNG" | "SRP" | (string & {});
export interface HlsRenditionGroupSettings {
    RenditionGroupId?: string | undefined;
    RenditionLanguageCode?: LanguageCode | undefined;
    RenditionName?: string | undefined;
}
export type __integerMinNegative2147483648Max2147483647 = number;
export type __integerMin1Max2147483647 = number;
export type __listOf__integerMin1Max2147483647 = number[];
export type __integerMin0Max8 = number;
export type __integerMin1Max64 = number;
export type __integerMinNegative60Max6 = number;
export type __listOf__integerMinNegative60Max6 = number[];
export type __doubleMinNegative60Max6 = number;
export type __listOf__doubleMinNegative60Max6 = number[];
export interface OutputChannelMapping {
    InputChannels?: number[] | undefined;
    InputChannelsFineTune?: number[] | undefined;
}
export type __listOfOutputChannelMapping = OutputChannelMapping[];
export interface ChannelMapping {
    OutputChannels?: OutputChannelMapping[] | undefined;
}
export interface RemixSettings {
    AudioDescriptionAudioChannel?: number | undefined;
    AudioDescriptionDataChannel?: number | undefined;
    ChannelMapping?: ChannelMapping | undefined;
    ChannelsIn?: number | undefined;
    ChannelsOut?: number | undefined;
}
export type AudioSelectorType = "PID" | "TRACK" | "LANGUAGE_CODE" | "HLS_RENDITION_GROUP" | "ALL_PCM" | "STREAM" | (string & {});
export type AudioSmpte337Passthrough = "ENABLED" | "DISABLED" | (string & {});
export interface AudioSelector {
    AudioDurationCorrection?: AudioDurationCorrection | undefined;
    CustomLanguageCode?: string | undefined;
    DefaultSelection?: AudioDefaultSelection | undefined;
    ExternalAudioFileInput?: string | undefined;
    HlsRenditionGroupSettings?: HlsRenditionGroupSettings | undefined;
    LanguageCode?: LanguageCode | undefined;
    Offset?: number | undefined;
    Pids?: number[] | undefined;
    ProgramSelection?: number | undefined;
    RemixSettings?: RemixSettings | undefined;
    SelectorType?: AudioSelectorType | undefined;
    Smpte337Passthrough?: AudioSmpte337Passthrough | undefined;
    Streams?: number[] | undefined;
    Tracks?: number[] | undefined;
}
export type __mapOfAudioSelector = {
    [key: string]: AudioSelector | undefined;
};
export type AncillaryConvert608To708 = "UPCONVERT" | "DISABLED" | (string & {});
export type __integerMin1Max4 = number;
export type AncillaryTerminateCaptions = "END_OF_INPUT" | "DISABLED" | (string & {});
export interface AncillarySourceSettings {
    Convert608To708?: AncillaryConvert608To708 | undefined;
    SourceAncillaryChannelNumber?: number | undefined;
    TerminateCaptions?: AncillaryTerminateCaptions | undefined;
}
export interface DvbSubSourceSettings {
    Pid?: number | undefined;
}
export type EmbeddedConvert608To708 = "UPCONVERT" | "DISABLED" | (string & {});
export type __integerMin1Max1 = number;
export type EmbeddedTerminateCaptions = "END_OF_INPUT" | "DISABLED" | (string & {});
export interface EmbeddedSourceSettings {
    Convert608To708?: EmbeddedConvert608To708 | undefined;
    Source608ChannelNumber?: number | undefined;
    Source608TrackNumber?: number | undefined;
    TerminateCaptions?: EmbeddedTerminateCaptions | undefined;
}
export type CaptionSourceByteRateLimit = "ENABLED" | "DISABLED" | (string & {});
export type FileSourceConvert608To708 = "UPCONVERT" | "DISABLED" | (string & {});
export type CaptionSourceConvertPaintOnToPopOn = "ENABLED" | "DISABLED" | (string & {});
export type __integerMin1Max1001 = number;
export type __integerMin1Max60000 = number;
export interface CaptionSourceFramerate {
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
}
export type __stringMin14PatternS3SccSCCTtmlTTMLDfxpDFXPStlSTLSrtSRTXmlXMLSmiSMIVttVTTWebvttWEBVTTHttpsSccSCCTtmlTTMLDfxpDFXPStlSTLSrtSRTXmlXMLSmiSMIVttVTTWebvttWEBVTT = string;
export type FileSourceTimeDeltaUnits = "SECONDS" | "MILLISECONDS" | (string & {});
export type CaptionSourceUpconvertSTLToTeletext = "UPCONVERT" | "DISABLED" | (string & {});
export interface FileSourceSettings {
    ByteRateLimit?: CaptionSourceByteRateLimit | undefined;
    Convert608To708?: FileSourceConvert608To708 | undefined;
    ConvertPaintToPop?: CaptionSourceConvertPaintOnToPopOn | undefined;
    Framerate?: CaptionSourceFramerate | undefined;
    SourceFile?: string | undefined;
    TimeDelta?: number | undefined;
    TimeDeltaUnits?: FileSourceTimeDeltaUnits | undefined;
    UpconvertSTLToTeletext?: CaptionSourceUpconvertSTLToTeletext | undefined;
}
export type CaptionSourceType = "ANCILLARY" | "DVB_SUB" | "EMBEDDED" | "SCTE20" | "SCC" | "TTML" | "STL" | "SRT" | "SMI" | "SMPTE_TT" | "TELETEXT" | "NULL_SOURCE" | "IMSC" | "WEBVTT" | "TT_3GPP" | (string & {});
export type __stringMin3Max3Pattern1809aFAF09aEAE = string;
export interface TeletextSourceSettings {
    PageNumber?: string | undefined;
}
export interface TrackSourceSettings {
    StreamNumber?: number | undefined;
    TrackNumber?: number | undefined;
}
export interface WebvttHlsSourceSettings {
    RenditionGroupId?: string | undefined;
    RenditionLanguageCode?: LanguageCode | undefined;
    RenditionName?: string | undefined;
}
export interface CaptionSourceSettings {
    AncillarySourceSettings?: AncillarySourceSettings | undefined;
    DvbSubSourceSettings?: DvbSubSourceSettings | undefined;
    EmbeddedSourceSettings?: EmbeddedSourceSettings | undefined;
    FileSourceSettings?: FileSourceSettings | undefined;
    SourceType?: CaptionSourceType | undefined;
    TeletextSourceSettings?: TeletextSourceSettings | undefined;
    TrackSourceSettings?: TrackSourceSettings | undefined;
    WebvttHlsSourceSettings?: WebvttHlsSourceSettings | undefined;
}
export interface CaptionSelector {
    CustomLanguageCode?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    SourceSettings?: CaptionSourceSettings | undefined;
}
export type __mapOfCaptionSelector = {
    [key: string]: CaptionSelector | undefined;
};
export type __integerMin2Max2147483647 = number;
export interface Rectangle {
    Height?: number | undefined;
    Width?: number | undefined;
    X?: number | undefined;
    Y?: number | undefined;
}
export type InputDeblockFilter = "ENABLED" | "DISABLED" | (string & {});
export type DecryptionMode = "AES_CTR" | "AES_CBC" | "AES_GCM" | (string & {});
export type __stringMin24Max512PatternAZaZ0902 = string;
export type __stringMin16Max24PatternAZaZ0922AZaZ0916 = string;
export type __stringMin9Max19PatternAZ26EastWestCentralNorthSouthEastWest1912 = string;
export interface InputDecryptionSettings {
    DecryptionMode?: DecryptionMode | undefined;
    EncryptedDecryptionKey?: string | undefined;
    InitializationVector?: string | undefined;
    KmsKeyRegion?: string | undefined;
}
export type InputDenoiseFilter = "ENABLED" | "DISABLED" | (string & {});
export type __stringMin14PatternS3XmlXMLHttpsXmlXML = string;
export type DynamicAudioSelectorType = "ALL_TRACKS" | "LANGUAGE_CODE" | (string & {});
export interface DynamicAudioSelector {
    AudioDurationCorrection?: AudioDurationCorrection | undefined;
    ExternalAudioFileInput?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    Offset?: number | undefined;
    SelectorType?: DynamicAudioSelectorType | undefined;
}
export type __mapOfDynamicAudioSelector = {
    [key: string]: DynamicAudioSelector | undefined;
};
export type __stringMax2048PatternS3Https = string;
export type InputFilterEnable = "AUTO" | "DISABLE" | "FORCE" | (string & {});
export type __integerMin0Max5 = number;
export type __stringMin14PatternS3BmpBMPPngPNGTgaTGAHttpsBmpBMPPngPNGTgaTGA = string;
export type __integerMin0Max99 = number;
export type __integerMin0Max100 = number;
export type __stringPattern01D20305D205D = string;
export interface InsertableImage {
    Duration?: number | undefined;
    FadeIn?: number | undefined;
    FadeOut?: number | undefined;
    Height?: number | undefined;
    ImageInserterInput?: string | undefined;
    ImageX?: number | undefined;
    ImageY?: number | undefined;
    Layer?: number | undefined;
    Opacity?: number | undefined;
    StartTime?: string | undefined;
    Width?: number | undefined;
}
export type __listOfInsertableImage = InsertableImage[];
export type __integerMin100Max1000 = number;
export interface ImageInserter {
    InsertableImages?: InsertableImage[] | undefined;
    SdrReferenceWhiteLevel?: number | undefined;
}
export type __stringPattern010920405090509092090909 = string;
export interface InputClipping {
    EndTimecode?: string | undefined;
    StartTimecode?: string | undefined;
}
export type __listOfInputClipping = InputClipping[];
export type InputScanType = "AUTO" | "PSF" | (string & {});
export interface MultiViewInput {
    FileInput?: string | undefined;
}
export interface MultiViewSettings {
    Input?: MultiViewInput | undefined;
}
export type __listOfMultiViewSettings = MultiViewSettings[];
export type InputPsiControl = "IGNORE_PSI" | "USE_PSI" | (string & {});
export type __stringPatternS3ASSETMAPXml = string;
export type __listOf__stringPatternS3ASSETMAPXml = string[];
export type __stringPatternArnAwsAZ09EventsAZ090912ConnectionAZAZ09AF0936 = string;
export type TamsGapHandling = "SKIP_GAPS" | "FILL_WITH_BLACK" | "HOLD_LAST_FRAME" | (string & {});
export type __stringPattern019090190908019090190908 = string;
export interface InputTamsSettings {
    AuthConnectionArn?: string | undefined;
    GapHandling?: TamsGapHandling | undefined;
    SourceId?: string | undefined;
    Timerange?: string | undefined;
}
export type InputTimecodeSource = "EMBEDDED" | "ZEROBASED" | "SPECIFIEDSTART" | (string & {});
export type __stringMin11Max11Pattern01D20305D205D = string;
export type __integerMin1Max32 = number;
export type __integerMin1Max86400000 = number;
export type __integerMin32Max8192 = number;
export type __integerMin32000Max48000 = number;
export interface InputVideoGenerator {
    Channels?: number | undefined;
    Duration?: number | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    Height?: number | undefined;
    ImageInput?: string | undefined;
    SampleRate?: number | undefined;
    Width?: number | undefined;
}
export type VideoOverlayUnit = "PIXELS" | "PERCENTAGE" | (string & {});
export interface VideoOverlayCrop {
    Height?: number | undefined;
    Unit?: VideoOverlayUnit | undefined;
    Width?: number | undefined;
    X?: number | undefined;
    Y?: number | undefined;
}
export type __stringPattern010920405090509092 = string;
export type __integerMinNegative1Max2147483647 = number;
export interface VideoOverlayPosition {
    Height?: number | undefined;
    Opacity?: number | undefined;
    Unit?: VideoOverlayUnit | undefined;
    Width?: number | undefined;
    XPosition?: number | undefined;
    YPosition?: number | undefined;
}
export interface VideoOverlayInputClipping {
    EndTimecode?: string | undefined;
    StartTimecode?: string | undefined;
}
export type __listOfVideoOverlayInputClipping = VideoOverlayInputClipping[];
export interface VideoOverlayInput {
    AudioSelectors?: {
        [key: string]: AudioSelector | undefined;
    } | undefined;
    FileInput?: string | undefined;
    InputClippings?: VideoOverlayInputClipping[] | undefined;
    TimecodeSource?: InputTimecodeSource | undefined;
    TimecodeStart?: string | undefined;
}
export type VideoOverlayPlayBackMode = "ONCE" | "REPEAT" | (string & {});
export interface VideoOverlayTransition {
    EndPosition?: VideoOverlayPosition | undefined;
    EndTimecode?: string | undefined;
    StartTimecode?: string | undefined;
}
export type __listOfVideoOverlayTransition = VideoOverlayTransition[];
export interface VideoOverlay {
    Crop?: VideoOverlayCrop | undefined;
    EndTimecode?: string | undefined;
    InitialPosition?: VideoOverlayPosition | undefined;
    Input?: VideoOverlayInput | undefined;
    Playback?: VideoOverlayPlayBackMode | undefined;
    StartTimecode?: string | undefined;
    Transitions?: VideoOverlayTransition[] | undefined;
}
export type __listOfVideoOverlay = VideoOverlay[];
export type AlphaBehavior = "DISCARD" | "REMAP_TO_LUMA" | (string & {});
export type ColorSpaceUsage = "FORCE" | "FALLBACK" | (string & {});
export type EmbeddedTimecodeOverride = "NONE" | "USE_MDPM" | (string & {});
export type __integerMin0Max50000 = number;
export type __integerMin0Max65535 = number;
export interface Hdr10Metadata {
    BluePrimaryX?: number | undefined;
    BluePrimaryY?: number | undefined;
    GreenPrimaryX?: number | undefined;
    GreenPrimaryY?: number | undefined;
    MaxContentLightLevel?: number | undefined;
    MaxFrameAverageLightLevel?: number | undefined;
    MaxLuminance?: number | undefined;
    MinLuminance?: number | undefined;
    RedPrimaryX?: number | undefined;
    RedPrimaryY?: number | undefined;
    WhitePointX?: number | undefined;
    WhitePointY?: number | undefined;
}
export type PadVideo = "DISABLED" | "BLACK" | (string & {});
export type InputRotate = "DEGREE_0" | "DEGREES_90" | "DEGREES_180" | "DEGREES_270" | "AUTO" | (string & {});
export type InputSampleRange = "FOLLOW" | "FULL_RANGE" | "LIMITED_RANGE" | (string & {});
export type VideoSelectorType = "AUTO" | "STREAM" | (string & {});
export interface VideoSelector {
    AlphaBehavior?: AlphaBehavior | undefined;
    ColorSpace?: ColorSpace | undefined;
    ColorSpaceUsage?: ColorSpaceUsage | undefined;
    EmbeddedTimecodeOverride?: EmbeddedTimecodeOverride | undefined;
    Hdr10Metadata?: Hdr10Metadata | undefined;
    MaxLuminance?: number | undefined;
    PadVideo?: PadVideo | undefined;
    Pid?: number | undefined;
    ProgramNumber?: number | undefined;
    Rotate?: InputRotate | undefined;
    SampleRange?: InputSampleRange | undefined;
    SelectorType?: VideoSelectorType | undefined;
    Streams?: number[] | undefined;
}
export interface Input {
    AdvancedInputFilter?: AdvancedInputFilter | undefined;
    AdvancedInputFilterSettings?: AdvancedInputFilterSettings | undefined;
    AudioSelectorGroups?: {
        [key: string]: AudioSelectorGroup | undefined;
    } | undefined;
    AudioSelectors?: {
        [key: string]: AudioSelector | undefined;
    } | undefined;
    CaptionSelectors?: {
        [key: string]: CaptionSelector | undefined;
    } | undefined;
    Crop?: Rectangle | undefined;
    DeblockFilter?: InputDeblockFilter | undefined;
    DecryptionSettings?: InputDecryptionSettings | undefined;
    DenoiseFilter?: InputDenoiseFilter | undefined;
    DolbyVisionMetadataXml?: string | undefined;
    DynamicAudioSelectors?: {
        [key: string]: DynamicAudioSelector | undefined;
    } | undefined;
    FileInput?: string | undefined;
    FilterEnable?: InputFilterEnable | undefined;
    FilterStrength?: number | undefined;
    ImageInserter?: ImageInserter | undefined;
    InputClippings?: InputClipping[] | undefined;
    InputScanType?: InputScanType | undefined;
    MultiViewSettings?: MultiViewSettings[] | undefined;
    Position?: Rectangle | undefined;
    ProgramNumber?: number | undefined;
    PsiControl?: InputPsiControl | undefined;
    SupplementalImps?: string[] | undefined;
    TamsSettings?: InputTamsSettings | undefined;
    TimecodeSource?: InputTimecodeSource | undefined;
    TimecodeStart?: string | undefined;
    VideoGenerator?: InputVideoGenerator | undefined;
    VideoOverlays?: VideoOverlay[] | undefined;
    VideoSelector?: VideoSelector | undefined;
}
export type __listOfInput = Input[];
export type __stringMin1Max20 = string;
export type __stringMin1Max50PatternAZAZ09 = string;
export type __stringMin1Max2048PatternArnAZSecretsmanagerWD12SecretAZAZ09 = string;
export type __doubleMin0 = number;
export type __stringPatternHttpsKantarmedia55Prod = string;
export type __stringPatternS3 = string;
export type __stringMin1Max50 = string;
export interface KantarWatermarkSettings {
    ChannelName?: string | undefined;
    ContentReference?: string | undefined;
    CredentialsSecretName?: string | undefined;
    FileOffset?: number | undefined;
    KantarLicenseId?: number | undefined;
    KantarServerUrl?: string | undefined;
    LogDestination?: string | undefined;
    Metadata3?: string | undefined;
    Metadata4?: string | undefined;
    Metadata5?: string | undefined;
    Metadata6?: string | undefined;
    Metadata7?: string | undefined;
    Metadata8?: string | undefined;
}
export type __integerMin1Max17895697 = number;
export type __integerMin1Max2147483640 = number;
export interface MotionImageInsertionFramerate {
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
}
export type __stringMin14PatternS3Mov09PngHttpsMov09Png = string;
export type MotionImageInsertionMode = "MOV" | "PNG" | (string & {});
export interface MotionImageInsertionOffset {
    ImageX?: number | undefined;
    ImageY?: number | undefined;
}
export type MotionImagePlayback = "ONCE" | "REPEAT" | (string & {});
export interface MotionImageInserter {
    Framerate?: MotionImageInsertionFramerate | undefined;
    Input?: string | undefined;
    InsertionMode?: MotionImageInsertionMode | undefined;
    Offset?: MotionImageInsertionOffset | undefined;
    Playback?: MotionImagePlayback | undefined;
    StartTime?: string | undefined;
}
export type __listOfMotionImageInserter = MotionImageInserter[];
export type __integerMin0Max0 = number;
export interface NielsenConfiguration {
    BreakoutCode?: number | undefined;
    DistributorId?: string | undefined;
}
export type NielsenActiveWatermarkProcessType = "NAES2_AND_NW" | "CBET" | "NAES2_AND_NW_AND_CBET" | (string & {});
export type __stringPattern0xAFaF0908190908 = string;
export type __integerMin0Max65534 = number;
export type NielsenSourceWatermarkStatusType = "CLEAN" | "WATERMARKED" | (string & {});
export type __stringPatternHttps = string;
export type NielsenUniqueTicPerAudioTrackType = "RESERVE_UNIQUE_TICS_PER_TRACK" | "SAME_TICS_PER_TRACK" | (string & {});
export interface NielsenNonLinearWatermarkSettings {
    ActiveWatermarkProcess?: NielsenActiveWatermarkProcessType | undefined;
    AdiFilename?: string | undefined;
    AssetId?: string | undefined;
    AssetName?: string | undefined;
    CbetSourceId?: string | undefined;
    EpisodeId?: string | undefined;
    MetadataDestination?: string | undefined;
    SourceId?: number | undefined;
    SourceWatermarkStatus?: NielsenSourceWatermarkStatusType | undefined;
    TicServerUrl?: string | undefined;
    UniqueTicPerAudioTrack?: NielsenUniqueTicPerAudioTrackType | undefined;
}
export type __integerMin100000Max100000000 = number;
export type __doubleMin1Max10 = number;
export type __integerMin3Max15 = number;
export type RequiredFlag = "ENABLED" | "DISABLED" | (string & {});
export interface AllowedRenditionSize {
    Height?: number | undefined;
    Required?: RequiredFlag | undefined;
    Width?: number | undefined;
}
export type __listOfAllowedRenditionSize = AllowedRenditionSize[];
export interface ForceIncludeRenditionSize {
    Height?: number | undefined;
    Width?: number | undefined;
}
export type __listOfForceIncludeRenditionSize = ForceIncludeRenditionSize[];
export interface MinBottomRenditionSize {
    Height?: number | undefined;
    Width?: number | undefined;
}
export interface MinTopRenditionSize {
    Height?: number | undefined;
    Width?: number | undefined;
}
export type RuleType = "MIN_TOP_RENDITION_SIZE" | "MIN_BOTTOM_RENDITION_SIZE" | "FORCE_INCLUDE_RENDITIONS" | "ALLOWED_RENDITIONS" | (string & {});
export interface AutomatedAbrRule {
    AllowedRenditions?: AllowedRenditionSize[] | undefined;
    ForceIncludeRenditions?: ForceIncludeRenditionSize[] | undefined;
    MinBottomRenditionSize?: MinBottomRenditionSize | undefined;
    MinTopRenditionSize?: MinTopRenditionSize | undefined;
    Type?: RuleType | undefined;
}
export type __listOfAutomatedAbrRule = AutomatedAbrRule[];
export interface AutomatedAbrSettings {
    MaxAbrBitrate?: number | undefined;
    MaxQualityLevel?: number | undefined;
    MaxRenditions?: number | undefined;
    MinAbrBitrate?: number | undefined;
    Rules?: AutomatedAbrRule[] | undefined;
}
export interface AutomatedEncodingSettings {
    AbrSettings?: AutomatedAbrSettings | undefined;
}
export type __stringMax2048 = string;
export interface CmafAdditionalManifest {
    ManifestNameModifier?: string | undefined;
    SelectedOutputs?: string[] | undefined;
}
export type __listOfCmafAdditionalManifest = CmafAdditionalManifest[];
export type CmafClientCache = "DISABLED" | "ENABLED" | (string & {});
export type CmafCodecSpecification = "RFC_6381" | "RFC_4281" | (string & {});
export type DashAdaptationSetGrouping = "CODEC" | (string & {});
export type __listOfDashAdaptationSetGrouping = DashAdaptationSetGrouping[];
export type __stringMin1Max256 = string;
export type DashManifestStyle = "BASIC" | "COMPACT" | "DISTINCT" | "FULL" | (string & {});
export type S3ObjectCannedAcl = "PUBLIC_READ" | "AUTHENTICATED_READ" | "BUCKET_OWNER_READ" | "BUCKET_OWNER_FULL_CONTROL" | (string & {});
export interface S3DestinationAccessControl {
    CannedAcl?: S3ObjectCannedAcl | undefined;
}
export type S3ServerSideEncryptionType = "SERVER_SIDE_ENCRYPTION_S3" | "SERVER_SIDE_ENCRYPTION_KMS" | (string & {});
export type __stringPatternAZaZ0902 = string;
export type __stringPatternArnAwsUsGovCnKmsAZ26EastWestCentralNorthSouthEastWest1912D12KeyAFAF098AFAF094AFAF094AFAF094AFAF0912MrkAFAF0932 = string;
export interface S3EncryptionSettings {
    EncryptionType?: S3ServerSideEncryptionType | undefined;
    KmsEncryptionContext?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export type S3StorageClass = "STANDARD" | "REDUCED_REDUNDANCY" | "STANDARD_IA" | "ONEZONE_IA" | "INTELLIGENT_TIERING" | "GLACIER" | "DEEP_ARCHIVE" | "GLACIER_IR" | (string & {});
export interface S3DestinationSettings {
    AccessControl?: S3DestinationAccessControl | undefined;
    Encryption?: S3EncryptionSettings | undefined;
    StorageClass?: S3StorageClass | undefined;
}
export interface DestinationSettings {
    S3Settings?: S3DestinationSettings | undefined;
}
export type __integerMin1Max9999 = number;
export type __stringMin32Max32Pattern09aFAF32 = string;
export type CmafEncryptionType = "SAMPLE_AES" | "AES_CTR" | (string & {});
export type CmafInitializationVectorInManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type __stringPatternArnAwsUsGovAcm = string;
export type __stringMin36Max36Pattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string;
export type __listOf__stringMin36Max36Pattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string[];
export type PresetSpeke20Audio = "PRESET_AUDIO_1" | "PRESET_AUDIO_2" | "PRESET_AUDIO_3" | "SHARED" | "UNENCRYPTED" | (string & {});
export type PresetSpeke20Video = "PRESET_VIDEO_1" | "PRESET_VIDEO_2" | "PRESET_VIDEO_3" | "PRESET_VIDEO_4" | "PRESET_VIDEO_5" | "PRESET_VIDEO_6" | "PRESET_VIDEO_7" | "PRESET_VIDEO_8" | "SHARED" | "UNENCRYPTED" | (string & {});
export interface EncryptionContractConfiguration {
    SpekeAudioPreset?: PresetSpeke20Audio | undefined;
    SpekeVideoPreset?: PresetSpeke20Video | undefined;
}
export type __stringPatternW = string;
export type __stringPatternHttpsD = string;
export interface SpekeKeyProviderCmaf {
    CertificateArn?: string | undefined;
    DashSignaledSystemIds?: string[] | undefined;
    EncryptionContractConfiguration?: EncryptionContractConfiguration | undefined;
    HlsSignaledSystemIds?: string[] | undefined;
    ResourceId?: string | undefined;
    Url?: string | undefined;
}
export type __stringPatternIdentityAZaZ26AZaZ09163 = string;
export type __stringPatternDD = string;
export type __stringPatternAZaZ0932 = string;
export interface StaticKeyProvider {
    KeyFormat?: string | undefined;
    KeyFormatVersions?: string | undefined;
    StaticKeyValue?: string | redacted.Redacted<string> | undefined;
    Url?: string | undefined;
}
export type CmafKeyProviderType = "SPEKE" | "STATIC_KEY" | (string & {});
export interface CmafEncryptionSettings {
    ClearLeadSegments?: number | undefined;
    ConstantInitializationVector?: string | undefined;
    EncryptionMethod?: CmafEncryptionType | undefined;
    InitializationVectorInManifest?: CmafInitializationVectorInManifest | undefined;
    SpekeKeyProvider?: SpekeKeyProviderCmaf | undefined;
    StaticKeyProvider?: StaticKeyProvider | undefined;
    Type?: CmafKeyProviderType | undefined;
}
export type CmafImageBasedTrickPlay = "NONE" | "THUMBNAIL" | "THUMBNAIL_AND_FULLFRAME" | "ADVANCED" | "VARIANTS" | (string & {});
export type CmafIntervalCadence = "FOLLOW_IFRAME" | "FOLLOW_CUSTOM" | "FOLLOW_SEGMENTATION" | (string & {});
export type __integerMin2Max4096 = number;
export type __doubleMin0Max2147483647 = number;
export type __integerMin8Max4096 = number;
export type __integerMin1Max2048 = number;
export type __integerMin1Max512 = number;
export interface CmafImageBasedTrickPlaySettings {
    IntervalCadence?: CmafIntervalCadence | undefined;
    ThumbnailHeight?: number | undefined;
    ThumbnailInterval?: number | undefined;
    ThumbnailWidth?: number | undefined;
    TileHeight?: number | undefined;
    TileWidth?: number | undefined;
}
export interface CmafImageBasedTrickPlayVariant {
    IntervalCadence?: CmafIntervalCadence | undefined;
    ThumbnailHeight?: number | undefined;
    ThumbnailInterval?: number | undefined;
    ThumbnailWidth?: number | undefined;
    TileHeight?: number | undefined;
    TileWidth?: number | undefined;
}
export type __listOfCmafImageBasedTrickPlayVariant = CmafImageBasedTrickPlayVariant[];
export type CmafManifestCompression = "GZIP" | "NONE" | (string & {});
export type CmafManifestDurationFormat = "FLOATING_POINT" | "INTEGER" | (string & {});
export type CmafMpdManifestBandwidthType = "AVERAGE" | "MAX" | (string & {});
export type CmafMpdProfile = "MAIN_PROFILE" | "ON_DEMAND_PROFILE" | (string & {});
export type CmafPtsOffsetHandlingForBFrames = "ZERO_BASED" | "MATCH_INITIAL_PTS" | (string & {});
export type CmafSegmentControl = "SINGLE_FILE" | "SEGMENTED_FILES" | (string & {});
export type CmafSegmentLengthControl = "EXACT" | "GOP_MULTIPLE" | "MATCH" | (string & {});
export type CmafStreamInfResolution = "INCLUDE" | "EXCLUDE" | (string & {});
export type CmafTargetDurationCompatibilityMode = "LEGACY" | "SPEC_COMPLIANT" | (string & {});
export type CmafVideoCompositionOffsets = "SIGNED" | "UNSIGNED" | (string & {});
export type CmafWriteDASHManifest = "DISABLED" | "ENABLED" | (string & {});
export type CmafWriteHLSManifest = "DISABLED" | "ENABLED" | (string & {});
export type CmafWriteSegmentTimelineInRepresentation = "ENABLED" | "DISABLED" | (string & {});
export interface CmafGroupSettings {
    AdditionalManifests?: CmafAdditionalManifest[] | undefined;
    BaseUrl?: string | undefined;
    ClientCache?: CmafClientCache | undefined;
    CodecSpecification?: CmafCodecSpecification | undefined;
    DashAdaptationSetGrouping?: DashAdaptationSetGrouping[] | undefined;
    DashIFrameTrickPlayNameModifier?: string | undefined;
    DashManifestStyle?: DashManifestStyle | undefined;
    Destination?: string | undefined;
    DestinationSettings?: DestinationSettings | undefined;
    Encryption?: CmafEncryptionSettings | undefined;
    FragmentLength?: number | undefined;
    ImageBasedTrickPlay?: CmafImageBasedTrickPlay | undefined;
    ImageBasedTrickPlaySettings?: CmafImageBasedTrickPlaySettings | undefined;
    ImageBasedTrickPlayVariants?: CmafImageBasedTrickPlayVariant[] | undefined;
    ManifestCompression?: CmafManifestCompression | undefined;
    ManifestDurationFormat?: CmafManifestDurationFormat | undefined;
    MinBufferTime?: number | undefined;
    MinFinalSegmentLength?: number | undefined;
    MpdManifestBandwidthType?: CmafMpdManifestBandwidthType | undefined;
    MpdProfile?: CmafMpdProfile | undefined;
    PtsOffsetHandlingForBFrames?: CmafPtsOffsetHandlingForBFrames | undefined;
    SegmentControl?: CmafSegmentControl | undefined;
    SegmentLength?: number | undefined;
    SegmentLengthControl?: CmafSegmentLengthControl | undefined;
    StreamInfResolution?: CmafStreamInfResolution | undefined;
    TargetDurationCompatibilityMode?: CmafTargetDurationCompatibilityMode | undefined;
    VideoCompositionOffsets?: CmafVideoCompositionOffsets | undefined;
    WriteDashManifest?: CmafWriteDASHManifest | undefined;
    WriteHlsManifest?: CmafWriteHLSManifest | undefined;
    WriteSegmentTimelineInRepresentation?: CmafWriteSegmentTimelineInRepresentation | undefined;
}
export interface DashAdditionalManifest {
    ManifestNameModifier?: string | undefined;
    SelectedOutputs?: string[] | undefined;
}
export type __listOfDashAdditionalManifest = DashAdditionalManifest[];
export type DashIsoGroupAudioChannelConfigSchemeIdUri = "MPEG_CHANNEL_CONFIGURATION" | "DOLBY_CHANNEL_CONFIGURATION" | (string & {});
export type DashIsoPlaybackDeviceCompatibility = "CENC_V1" | "UNENCRYPTED_SEI" | "CENC_V1_UNENCRYPTED_HEADERS" | (string & {});
export type __stringPattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string;
export type __listOf__stringPattern09aFAF809aFAF409aFAF409aFAF409aFAF12 = string[];
export interface SpekeKeyProvider {
    CertificateArn?: string | undefined;
    EncryptionContractConfiguration?: EncryptionContractConfiguration | undefined;
    ResourceId?: string | undefined;
    SystemIds?: string[] | undefined;
    Url?: string | undefined;
}
export interface DashIsoEncryptionSettings {
    PlaybackDeviceCompatibility?: DashIsoPlaybackDeviceCompatibility | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export type DashIsoHbbtvCompliance = "HBBTV_1_5" | "NONE" | (string & {});
export type DashIsoImageBasedTrickPlay = "NONE" | "THUMBNAIL" | "THUMBNAIL_AND_FULLFRAME" | "ADVANCED" | "VARIANTS" | (string & {});
export type DashIsoIntervalCadence = "FOLLOW_IFRAME" | "FOLLOW_CUSTOM" | "FOLLOW_SEGMENTATION" | (string & {});
export type __integerMin1Max4096 = number;
export interface DashIsoImageBasedTrickPlaySettings {
    IntervalCadence?: DashIsoIntervalCadence | undefined;
    ThumbnailHeight?: number | undefined;
    ThumbnailInterval?: number | undefined;
    ThumbnailWidth?: number | undefined;
    TileHeight?: number | undefined;
    TileWidth?: number | undefined;
}
export interface DashIsoImageBasedTrickPlayVariant {
    IntervalCadence?: DashIsoIntervalCadence | undefined;
    ThumbnailHeight?: number | undefined;
    ThumbnailInterval?: number | undefined;
    ThumbnailWidth?: number | undefined;
    TileHeight?: number | undefined;
    TileWidth?: number | undefined;
}
export type __listOfDashIsoImageBasedTrickPlayVariant = DashIsoImageBasedTrickPlayVariant[];
export type DashIsoMpdManifestBandwidthType = "AVERAGE" | "MAX" | (string & {});
export type DashIsoMpdProfile = "MAIN_PROFILE" | "ON_DEMAND_PROFILE" | (string & {});
export type DashIsoPtsOffsetHandlingForBFrames = "ZERO_BASED" | "MATCH_INITIAL_PTS" | (string & {});
export type DashIsoSegmentControl = "SINGLE_FILE" | "SEGMENTED_FILES" | (string & {});
export type DashIsoSegmentLengthControl = "EXACT" | "GOP_MULTIPLE" | "MATCH" | (string & {});
export type DashIsoVideoCompositionOffsets = "SIGNED" | "UNSIGNED" | (string & {});
export type DashIsoWriteSegmentTimelineInRepresentation = "ENABLED" | "DISABLED" | (string & {});
export interface DashIsoGroupSettings {
    AdditionalManifests?: DashAdditionalManifest[] | undefined;
    AudioChannelConfigSchemeIdUri?: DashIsoGroupAudioChannelConfigSchemeIdUri | undefined;
    BaseUrl?: string | undefined;
    DashAdaptationSetGrouping?: DashAdaptationSetGrouping[] | undefined;
    DashIFrameTrickPlayNameModifier?: string | undefined;
    DashManifestStyle?: DashManifestStyle | undefined;
    Destination?: string | undefined;
    DestinationSettings?: DestinationSettings | undefined;
    Encryption?: DashIsoEncryptionSettings | undefined;
    FragmentLength?: number | undefined;
    HbbtvCompliance?: DashIsoHbbtvCompliance | undefined;
    ImageBasedTrickPlay?: DashIsoImageBasedTrickPlay | undefined;
    ImageBasedTrickPlaySettings?: DashIsoImageBasedTrickPlaySettings | undefined;
    ImageBasedTrickPlayVariants?: DashIsoImageBasedTrickPlayVariant[] | undefined;
    MinBufferTime?: number | undefined;
    MinFinalSegmentLength?: number | undefined;
    MpdManifestBandwidthType?: DashIsoMpdManifestBandwidthType | undefined;
    MpdProfile?: DashIsoMpdProfile | undefined;
    PtsOffsetHandlingForBFrames?: DashIsoPtsOffsetHandlingForBFrames | undefined;
    SegmentControl?: DashIsoSegmentControl | undefined;
    SegmentLength?: number | undefined;
    SegmentLengthControl?: DashIsoSegmentLengthControl | undefined;
    VideoCompositionOffsets?: DashIsoVideoCompositionOffsets | undefined;
    WriteSegmentTimelineInRepresentation?: DashIsoWriteSegmentTimelineInRepresentation | undefined;
}
export interface FileGroupSettings {
    Destination?: string | undefined;
    DestinationSettings?: DestinationSettings | undefined;
}
export type HlsAdMarkers = "ELEMENTAL" | "ELEMENTAL_SCTE35" | (string & {});
export type __listOfHlsAdMarkers = HlsAdMarkers[];
export interface HlsAdditionalManifest {
    ManifestNameModifier?: string | undefined;
    SelectedOutputs?: string[] | undefined;
}
export type __listOfHlsAdditionalManifest = HlsAdditionalManifest[];
export type HlsAudioOnlyHeader = "INCLUDE" | "EXCLUDE" | (string & {});
export interface HlsCaptionLanguageMapping {
    CaptionChannel?: number | undefined;
    CustomLanguageCode?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LanguageDescription?: string | undefined;
}
export type __listOfHlsCaptionLanguageMapping = HlsCaptionLanguageMapping[];
export type HlsCaptionLanguageSetting = "INSERT" | "OMIT" | "NONE" | (string & {});
export type HlsCaptionSegmentLengthControl = "LARGE_SEGMENTS" | "MATCH_VIDEO" | (string & {});
export type HlsClientCache = "DISABLED" | "ENABLED" | (string & {});
export type HlsCodecSpecification = "RFC_6381" | "RFC_4281" | (string & {});
export type HlsDirectoryStructure = "SINGLE_DIRECTORY" | "SUBDIRECTORY_PER_STREAM" | (string & {});
export type HlsEncryptionType = "AES128" | "SAMPLE_AES" | (string & {});
export type HlsInitializationVectorInManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type HlsOfflineEncrypted = "ENABLED" | "DISABLED" | (string & {});
export type HlsKeyProviderType = "SPEKE" | "STATIC_KEY" | (string & {});
export interface HlsEncryptionSettings {
    ConstantInitializationVector?: string | undefined;
    EncryptionMethod?: HlsEncryptionType | undefined;
    InitializationVectorInManifest?: HlsInitializationVectorInManifest | undefined;
    OfflineEncrypted?: HlsOfflineEncrypted | undefined;
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
    StaticKeyProvider?: StaticKeyProvider | undefined;
    Type?: HlsKeyProviderType | undefined;
}
export type HlsImageBasedTrickPlay = "NONE" | "THUMBNAIL" | "THUMBNAIL_AND_FULLFRAME" | "ADVANCED" | "VARIANTS" | (string & {});
export type HlsIntervalCadence = "FOLLOW_IFRAME" | "FOLLOW_CUSTOM" | "FOLLOW_SEGMENTATION" | (string & {});
export interface HlsImageBasedTrickPlaySettings {
    IntervalCadence?: HlsIntervalCadence | undefined;
    ThumbnailHeight?: number | undefined;
    ThumbnailInterval?: number | undefined;
    ThumbnailWidth?: number | undefined;
    TileHeight?: number | undefined;
    TileWidth?: number | undefined;
}
export interface HlsImageBasedTrickPlayVariant {
    IntervalCadence?: HlsIntervalCadence | undefined;
    ThumbnailHeight?: number | undefined;
    ThumbnailInterval?: number | undefined;
    ThumbnailWidth?: number | undefined;
    TileHeight?: number | undefined;
    TileWidth?: number | undefined;
}
export type __listOfHlsImageBasedTrickPlayVariant = HlsImageBasedTrickPlayVariant[];
export type HlsManifestCompression = "GZIP" | "NONE" | (string & {});
export type HlsManifestDurationFormat = "FLOATING_POINT" | "INTEGER" | (string & {});
export type HlsOutputSelection = "MANIFESTS_AND_SEGMENTS" | "SEGMENTS_ONLY" | (string & {});
export type HlsProgramDateTime = "INCLUDE" | "EXCLUDE" | (string & {});
export type __integerMin0Max3600 = number;
export type HlsProgressiveWriteHlsManifest = "ENABLED" | "DISABLED" | (string & {});
export type HlsSegmentControl = "SINGLE_FILE" | "SEGMENTED_FILES" | (string & {});
export type HlsSegmentLengthControl = "EXACT" | "GOP_MULTIPLE" | "MATCH" | (string & {});
export type HlsStreamInfResolution = "INCLUDE" | "EXCLUDE" | (string & {});
export type HlsTargetDurationCompatibilityMode = "LEGACY" | "SPEC_COMPLIANT" | (string & {});
export type HlsTimedMetadataId3Frame = "NONE" | "PRIV" | "TDRL" | (string & {});
export interface HlsGroupSettings {
    AdMarkers?: HlsAdMarkers[] | undefined;
    AdditionalManifests?: HlsAdditionalManifest[] | undefined;
    AudioOnlyHeader?: HlsAudioOnlyHeader | undefined;
    BaseUrl?: string | undefined;
    CaptionLanguageMappings?: HlsCaptionLanguageMapping[] | undefined;
    CaptionLanguageSetting?: HlsCaptionLanguageSetting | undefined;
    CaptionSegmentLengthControl?: HlsCaptionSegmentLengthControl | undefined;
    ClientCache?: HlsClientCache | undefined;
    CodecSpecification?: HlsCodecSpecification | undefined;
    Destination?: string | undefined;
    DestinationSettings?: DestinationSettings | undefined;
    DirectoryStructure?: HlsDirectoryStructure | undefined;
    Encryption?: HlsEncryptionSettings | undefined;
    ImageBasedTrickPlay?: HlsImageBasedTrickPlay | undefined;
    ImageBasedTrickPlaySettings?: HlsImageBasedTrickPlaySettings | undefined;
    ImageBasedTrickPlayVariants?: HlsImageBasedTrickPlayVariant[] | undefined;
    ManifestCompression?: HlsManifestCompression | undefined;
    ManifestDurationFormat?: HlsManifestDurationFormat | undefined;
    MinFinalSegmentLength?: number | undefined;
    MinSegmentLength?: number | undefined;
    OutputSelection?: HlsOutputSelection | undefined;
    ProgramDateTime?: HlsProgramDateTime | undefined;
    ProgramDateTimePeriod?: number | undefined;
    ProgressiveWriteHlsManifest?: HlsProgressiveWriteHlsManifest | undefined;
    SegmentControl?: HlsSegmentControl | undefined;
    SegmentLength?: number | undefined;
    SegmentLengthControl?: HlsSegmentLengthControl | undefined;
    SegmentsPerSubdirectory?: number | undefined;
    StreamInfResolution?: HlsStreamInfResolution | undefined;
    TargetDurationCompatibilityMode?: HlsTargetDurationCompatibilityMode | undefined;
    TimedMetadataId3Frame?: HlsTimedMetadataId3Frame | undefined;
    TimedMetadataId3Period?: number | undefined;
    TimestampDeltaMilliseconds?: number | undefined;
}
export interface MsSmoothAdditionalManifest {
    ManifestNameModifier?: string | undefined;
    SelectedOutputs?: string[] | undefined;
}
export type __listOfMsSmoothAdditionalManifest = MsSmoothAdditionalManifest[];
export type MsSmoothAudioDeduplication = "COMBINE_DUPLICATE_STREAMS" | "NONE" | (string & {});
export interface MsSmoothEncryptionSettings {
    SpekeKeyProvider?: SpekeKeyProvider | undefined;
}
export type MsSmoothFragmentLengthControl = "EXACT" | "GOP_MULTIPLE" | (string & {});
export type MsSmoothManifestEncoding = "UTF8" | "UTF16" | (string & {});
export interface MsSmoothGroupSettings {
    AdditionalManifests?: MsSmoothAdditionalManifest[] | undefined;
    AudioDeduplication?: MsSmoothAudioDeduplication | undefined;
    Destination?: string | undefined;
    DestinationSettings?: DestinationSettings | undefined;
    Encryption?: MsSmoothEncryptionSettings | undefined;
    FragmentLength?: number | undefined;
    FragmentLengthControl?: MsSmoothFragmentLengthControl | undefined;
    ManifestEncoding?: MsSmoothManifestEncoding | undefined;
}
export type FrameMetricType = "PSNR" | "SSIM" | "MS_SSIM" | "PSNR_HVS" | "VMAF" | "QVBR" | "SHOT_CHANGE" | (string & {});
export type __listOfFrameMetricType = FrameMetricType[];
export type OutputGroupType = "HLS_GROUP_SETTINGS" | "DASH_ISO_GROUP_SETTINGS" | "FILE_GROUP_SETTINGS" | "MS_SMOOTH_GROUP_SETTINGS" | "CMAF_GROUP_SETTINGS" | (string & {});
export interface OutputGroupSettings {
    CmafGroupSettings?: CmafGroupSettings | undefined;
    DashIsoGroupSettings?: DashIsoGroupSettings | undefined;
    FileGroupSettings?: FileGroupSettings | undefined;
    HlsGroupSettings?: HlsGroupSettings | undefined;
    MsSmoothGroupSettings?: MsSmoothGroupSettings | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    Type?: OutputGroupType | undefined;
}
export type AudioChannelTag = "L" | "R" | "C" | "LFE" | "LS" | "RS" | "LC" | "RC" | "CS" | "LSD" | "RSD" | "TCS" | "VHL" | "VHC" | "VHR" | "TBL" | "TBC" | "TBR" | "RSL" | "RSR" | "LW" | "RW" | "LFE2" | "LT" | "RT" | "HI" | "NAR" | "M" | (string & {});
export type __listOfAudioChannelTag = AudioChannelTag[];
export interface AudioChannelTaggingSettings {
    ChannelTag?: AudioChannelTag | undefined;
    ChannelTags?: AudioChannelTag[] | undefined;
}
export type AudioNormalizationAlgorithm = "ITU_BS_1770_1" | "ITU_BS_1770_2" | "ITU_BS_1770_3" | "ITU_BS_1770_4" | (string & {});
export type AudioNormalizationAlgorithmControl = "CORRECT_AUDIO" | "MEASURE_ONLY" | (string & {});
export type __integerMinNegative70Max0 = number;
export type AudioNormalizationLoudnessLogging = "LOG" | "DONT_LOG" | (string & {});
export type AudioNormalizationPeakCalculation = "TRUE_PEAK" | "NONE" | (string & {});
export type __doubleMinNegative59Max0 = number;
export type __doubleMinNegative8Max0 = number;
export interface AudioNormalizationSettings {
    Algorithm?: AudioNormalizationAlgorithm | undefined;
    AlgorithmControl?: AudioNormalizationAlgorithmControl | undefined;
    CorrectionGateLevel?: number | undefined;
    LoudnessLogging?: AudioNormalizationLoudnessLogging | undefined;
    PeakCalculation?: AudioNormalizationPeakCalculation | undefined;
    TargetLkfs?: number | undefined;
    TruePeakLimiterThreshold?: number | undefined;
}
export type SlowPalPitchCorrection = "DISABLED" | "ENABLED" | (string & {});
export interface AudioPitchCorrectionSettings {
    SlowPalPitchCorrection?: SlowPalPitchCorrection | undefined;
}
export type __integerMin0Max255 = number;
export type AudioTypeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type AacAudioDescriptionBroadcasterMix = "BROADCASTER_MIXED_AD" | "NORMAL" | (string & {});
export type __integerMin6000Max1024000 = number;
export type AacCodecProfile = "LC" | "HEV1" | "HEV2" | "XHE" | (string & {});
export type AacCodingMode = "AD_RECEIVER_MIX" | "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_5_1" | "CODING_MODE_AUTO" | (string & {});
export type AacLoudnessMeasurementMode = "PROGRAM" | "ANCHOR" | (string & {});
export type AacPassthroughControl = "WHEN_POSSIBLE" | "NO_PASSTHROUGH" | (string & {});
export type __integerMin2000Max30000 = number;
export type AacRateControlMode = "CBR" | "VBR" | (string & {});
export type AacRawFormat = "LATM_LOAS" | "NONE" | (string & {});
export type __integerMin8000Max96000 = number;
export type AacSpecification = "MPEG2" | "MPEG4" | (string & {});
export type __integerMin6Max16 = number;
export type AacVbrQuality = "LOW" | "MEDIUM_LOW" | "MEDIUM_HIGH" | "HIGH" | (string & {});
export interface AacSettings {
    AudioDescriptionBroadcasterMix?: AacAudioDescriptionBroadcasterMix | undefined;
    Bitrate?: number | undefined;
    CodecProfile?: AacCodecProfile | undefined;
    CodingMode?: AacCodingMode | undefined;
    LoudnessMeasurementMode?: AacLoudnessMeasurementMode | undefined;
    PassthroughControl?: AacPassthroughControl | undefined;
    RapInterval?: number | undefined;
    RateControlMode?: AacRateControlMode | undefined;
    RawFormat?: AacRawFormat | undefined;
    SampleRate?: number | undefined;
    Specification?: AacSpecification | undefined;
    TargetLoudnessRange?: number | undefined;
    VbrQuality?: AacVbrQuality | undefined;
}
export type __integerMin64000Max640000 = number;
export type Ac3BitstreamMode = "COMPLETE_MAIN" | "COMMENTARY" | "DIALOGUE" | "EMERGENCY" | "HEARING_IMPAIRED" | "MUSIC_AND_EFFECTS" | "VISUALLY_IMPAIRED" | "VOICE_OVER" | (string & {});
export type Ac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_1_1" | "CODING_MODE_2_0" | "CODING_MODE_3_2_LFE" | "CODING_MODE_AUTO" | (string & {});
export type __integerMin1Max31 = number;
export type Ac3DynamicRangeCompressionLine = "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | "NONE" | (string & {});
export type Ac3DynamicRangeCompressionProfile = "FILM_STANDARD" | "NONE" | (string & {});
export type Ac3DynamicRangeCompressionRf = "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | "NONE" | (string & {});
export type Ac3LfeFilter = "ENABLED" | "DISABLED" | (string & {});
export type Ac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __integerMin48000Max48000 = number;
export interface Ac3Settings {
    Bitrate?: number | undefined;
    BitstreamMode?: Ac3BitstreamMode | undefined;
    CodingMode?: Ac3CodingMode | undefined;
    Dialnorm?: number | undefined;
    DynamicRangeCompressionLine?: Ac3DynamicRangeCompressionLine | undefined;
    DynamicRangeCompressionProfile?: Ac3DynamicRangeCompressionProfile | undefined;
    DynamicRangeCompressionRf?: Ac3DynamicRangeCompressionRf | undefined;
    LfeFilter?: Ac3LfeFilter | undefined;
    MetadataControl?: Ac3MetadataControl | undefined;
    SampleRate?: number | undefined;
}
export type __integerMin48000Max768000 = number;
export type Ac4BitstreamMode = "COMPLETE_MAIN" | "EMERGENCY" | (string & {});
export type Ac4CodingMode = "CODING_MODE_2_0" | "CODING_MODE_3_2_LFE" | "CODING_MODE_5_1_4" | (string & {});
export type Ac4DynamicRangeCompressionDrcProfile = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type __doubleMinNegative1000Max3 = number;
export type __doubleMinNegative1000MaxNegative1 = number;
export type Ac4StereoDownmix = "NOT_INDICATED" | "LO_RO" | "LT_RT" | "DPL2" | (string & {});
export interface Ac4Settings {
    Bitrate?: number | undefined;
    BitstreamMode?: Ac4BitstreamMode | undefined;
    CodingMode?: Ac4CodingMode | undefined;
    DynamicRangeCompressionFlatPanelTv?: Ac4DynamicRangeCompressionDrcProfile | undefined;
    DynamicRangeCompressionHomeTheater?: Ac4DynamicRangeCompressionDrcProfile | undefined;
    DynamicRangeCompressionPortableHeadphones?: Ac4DynamicRangeCompressionDrcProfile | undefined;
    DynamicRangeCompressionPortableSpeakers?: Ac4DynamicRangeCompressionDrcProfile | undefined;
    LoRoCenterMixLevel?: number | undefined;
    LoRoSurroundMixLevel?: number | undefined;
    LtRtCenterMixLevel?: number | undefined;
    LtRtSurroundMixLevel?: number | undefined;
    SampleRate?: number | undefined;
    StereoDownmix?: Ac4StereoDownmix | undefined;
}
export type __integerMin16Max24 = number;
export type __integerMin0Max64 = number;
export type __integerMin8000Max192000 = number;
export interface AiffSettings {
    BitDepth?: number | undefined;
    Channels?: number | undefined;
    SampleRate?: number | undefined;
}
export type AudioCodec = "AAC" | "MP2" | "MP3" | "WAV" | "AIFF" | "AC3" | "AC4" | "EAC3" | "EAC3_ATMOS" | "VORBIS" | "OPUS" | "PASSTHROUGH" | "FLAC" | (string & {});
export type __integerMin384000Max1024000 = number;
export type Eac3AtmosBitstreamMode = "COMPLETE_MAIN" | (string & {});
export type Eac3AtmosCodingMode = "CODING_MODE_AUTO" | "CODING_MODE_5_1_4" | "CODING_MODE_7_1_4" | "CODING_MODE_9_1_6" | (string & {});
export type Eac3AtmosDialogueIntelligence = "ENABLED" | "DISABLED" | (string & {});
export type Eac3AtmosDownmixControl = "SPECIFIED" | "INITIALIZE_FROM_SOURCE" | (string & {});
export type Eac3AtmosDynamicRangeCompressionLine = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3AtmosDynamicRangeCompressionRf = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3AtmosDynamicRangeControl = "SPECIFIED" | "INITIALIZE_FROM_SOURCE" | (string & {});
export type __doubleMinNegative6Max3 = number;
export type __doubleMinNegative60MaxNegative1 = number;
export type Eac3AtmosMeteringMode = "LEQ_A" | "ITU_BS_1770_1" | "ITU_BS_1770_2" | "ITU_BS_1770_3" | "ITU_BS_1770_4" | (string & {});
export type Eac3AtmosStereoDownmix = "NOT_INDICATED" | "STEREO" | "SURROUND" | "DPL2" | (string & {});
export type Eac3AtmosSurroundExMode = "NOT_INDICATED" | "ENABLED" | "DISABLED" | (string & {});
export interface Eac3AtmosSettings {
    Bitrate?: number | undefined;
    BitstreamMode?: Eac3AtmosBitstreamMode | undefined;
    CodingMode?: Eac3AtmosCodingMode | undefined;
    DialogueIntelligence?: Eac3AtmosDialogueIntelligence | undefined;
    DownmixControl?: Eac3AtmosDownmixControl | undefined;
    DynamicRangeCompressionLine?: Eac3AtmosDynamicRangeCompressionLine | undefined;
    DynamicRangeCompressionRf?: Eac3AtmosDynamicRangeCompressionRf | undefined;
    DynamicRangeControl?: Eac3AtmosDynamicRangeControl | undefined;
    LoRoCenterMixLevel?: number | undefined;
    LoRoSurroundMixLevel?: number | undefined;
    LtRtCenterMixLevel?: number | undefined;
    LtRtSurroundMixLevel?: number | undefined;
    MeteringMode?: Eac3AtmosMeteringMode | undefined;
    SampleRate?: number | undefined;
    SpeechThreshold?: number | undefined;
    StereoDownmix?: Eac3AtmosStereoDownmix | undefined;
    SurroundExMode?: Eac3AtmosSurroundExMode | undefined;
}
export type Eac3AttenuationControl = "ATTENUATE_3_DB" | "NONE" | (string & {});
export type __integerMin32000Max3024000 = number;
export type Eac3BitstreamMode = "COMPLETE_MAIN" | "COMMENTARY" | "EMERGENCY" | "HEARING_IMPAIRED" | "VISUALLY_IMPAIRED" | (string & {});
export type Eac3CodingMode = "CODING_MODE_1_0" | "CODING_MODE_2_0" | "CODING_MODE_3_2" | "CODING_MODE_AUTO" | (string & {});
export type Eac3DcFilter = "ENABLED" | "DISABLED" | (string & {});
export type Eac3DynamicRangeCompressionLine = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3DynamicRangeCompressionRf = "NONE" | "FILM_STANDARD" | "FILM_LIGHT" | "MUSIC_STANDARD" | "MUSIC_LIGHT" | "SPEECH" | (string & {});
export type Eac3LfeControl = "LFE" | "NO_LFE" | (string & {});
export type Eac3LfeFilter = "ENABLED" | "DISABLED" | (string & {});
export type __doubleMinNegative60Max3 = number;
export type Eac3MetadataControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type Eac3PassthroughControl = "WHEN_POSSIBLE" | "NO_PASSTHROUGH" | (string & {});
export type Eac3PhaseControl = "SHIFT_90_DEGREES" | "NO_SHIFT" | (string & {});
export type Eac3StereoDownmix = "NOT_INDICATED" | "LO_RO" | "LT_RT" | "DPL2" | (string & {});
export type Eac3SurroundExMode = "NOT_INDICATED" | "ENABLED" | "DISABLED" | (string & {});
export type Eac3SurroundMode = "NOT_INDICATED" | "ENABLED" | "DISABLED" | (string & {});
export interface Eac3Settings {
    AttenuationControl?: Eac3AttenuationControl | undefined;
    Bitrate?: number | undefined;
    BitstreamMode?: Eac3BitstreamMode | undefined;
    CodingMode?: Eac3CodingMode | undefined;
    DcFilter?: Eac3DcFilter | undefined;
    Dialnorm?: number | undefined;
    DynamicRangeCompressionLine?: Eac3DynamicRangeCompressionLine | undefined;
    DynamicRangeCompressionRf?: Eac3DynamicRangeCompressionRf | undefined;
    LfeControl?: Eac3LfeControl | undefined;
    LfeFilter?: Eac3LfeFilter | undefined;
    LoRoCenterMixLevel?: number | undefined;
    LoRoSurroundMixLevel?: number | undefined;
    LtRtCenterMixLevel?: number | undefined;
    LtRtSurroundMixLevel?: number | undefined;
    MetadataControl?: Eac3MetadataControl | undefined;
    PassthroughControl?: Eac3PassthroughControl | undefined;
    PhaseControl?: Eac3PhaseControl | undefined;
    SampleRate?: number | undefined;
    StereoDownmix?: Eac3StereoDownmix | undefined;
    SurroundExMode?: Eac3SurroundExMode | undefined;
    SurroundMode?: Eac3SurroundMode | undefined;
}
export type __integerMin22050Max192000 = number;
export interface FlacSettings {
    BitDepth?: number | undefined;
    Channels?: number | undefined;
    SampleRate?: number | undefined;
}
export type Mp2AudioDescriptionMix = "BROADCASTER_MIXED_AD" | "NONE" | (string & {});
export type __integerMin32000Max384000 = number;
export type __integerMin0Max2 = number;
export interface Mp2Settings {
    AudioDescriptionMix?: Mp2AudioDescriptionMix | undefined;
    Bitrate?: number | undefined;
    Channels?: number | undefined;
    SampleRate?: number | undefined;
}
export type __integerMin16000Max320000 = number;
export type Mp3RateControlMode = "CBR" | "VBR" | (string & {});
export type __integerMin22050Max48000 = number;
export type __integerMin0Max9 = number;
export interface Mp3Settings {
    Bitrate?: number | undefined;
    Channels?: number | undefined;
    RateControlMode?: Mp3RateControlMode | undefined;
    SampleRate?: number | undefined;
    VbrQuality?: number | undefined;
}
export type __integerMin32000Max192000 = number;
export type __integerMin16000Max48000 = number;
export interface OpusSettings {
    Bitrate?: number | undefined;
    Channels?: number | undefined;
    SampleRate?: number | undefined;
}
export type __integerMinNegative1Max10 = number;
export interface VorbisSettings {
    Channels?: number | undefined;
    SampleRate?: number | undefined;
    VbrQuality?: number | undefined;
}
export type WavFormat = "RIFF" | "RF64" | "EXTENSIBLE" | (string & {});
export interface WavSettings {
    BitDepth?: number | undefined;
    Channels?: number | undefined;
    Format?: WavFormat | undefined;
    SampleRate?: number | undefined;
}
export interface AudioCodecSettings {
    AacSettings?: AacSettings | undefined;
    Ac3Settings?: Ac3Settings | undefined;
    Ac4Settings?: Ac4Settings | undefined;
    AiffSettings?: AiffSettings | undefined;
    Codec?: AudioCodec | undefined;
    Eac3AtmosSettings?: Eac3AtmosSettings | undefined;
    Eac3Settings?: Eac3Settings | undefined;
    FlacSettings?: FlacSettings | undefined;
    Mp2Settings?: Mp2Settings | undefined;
    Mp3Settings?: Mp3Settings | undefined;
    OpusSettings?: OpusSettings | undefined;
    VorbisSettings?: VorbisSettings | undefined;
    WavSettings?: WavSettings | undefined;
}
export type __stringPatternAZaZ23AZaZ09 = string;
export type AudioLanguageCodeControl = "FOLLOW_INPUT" | "USE_CONFIGURED" | (string & {});
export type __stringPatternWS = string;
export interface AudioDescription {
    AudioChannelTaggingSettings?: AudioChannelTaggingSettings | undefined;
    AudioNormalizationSettings?: AudioNormalizationSettings | undefined;
    AudioPitchCorrectionSettings?: AudioPitchCorrectionSettings | undefined;
    AudioSourceName?: string | undefined;
    AudioType?: number | undefined;
    AudioTypeControl?: AudioTypeControl | undefined;
    CodecSettings?: AudioCodecSettings | undefined;
    CustomLanguageCode?: string | undefined;
    LanguageCode?: LanguageCode | undefined;
    LanguageCodeControl?: AudioLanguageCodeControl | undefined;
    RemixSettings?: RemixSettings | undefined;
    StreamName?: string | undefined;
}
export type __listOfAudioDescription = AudioDescription[];
export type __stringPatternAZaZ23AZaZ = string;
export type BurninSubtitleAlignment = "CENTERED" | "LEFT" | "AUTO" | (string & {});
export type BurninSubtitleApplyFontColor = "WHITE_TEXT_ONLY" | "ALL_TEXT" | (string & {});
export type BurninSubtitleBackgroundColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type BurninSubtitleFallbackFont = "BEST_MATCH" | "MONOSPACED_SANSSERIF" | "MONOSPACED_SERIF" | "PROPORTIONAL_SANSSERIF" | "PROPORTIONAL_SERIF" | (string & {});
export type BurninSubtitleFontColor = "WHITE" | "BLACK" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "HEX" | "AUTO" | (string & {});
export type __stringPatternS3TtfHttpsTtf = string;
export type __integerMin96Max600 = number;
export type FontScript = "AUTOMATIC" | "HANS" | "HANT" | (string & {});
export type __integerMin0Max96 = number;
export type __stringMin6Max8Pattern09aFAF609aFAF2 = string;
export type BurninSubtitleOutlineColor = "BLACK" | "WHITE" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "AUTO" | (string & {});
export type __integerMin0Max10 = number;
export type RemoveRubyReserveAttributes = "DISABLED" | "ENABLED" | (string & {});
export type BurninSubtitleShadowColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type BurnInSubtitleStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export type BurninSubtitleTeletextSpacing = "FIXED_GRID" | "PROPORTIONAL" | "AUTO" | (string & {});
export interface BurninDestinationSettings {
    Alignment?: BurninSubtitleAlignment | undefined;
    ApplyFontColor?: BurninSubtitleApplyFontColor | undefined;
    BackgroundColor?: BurninSubtitleBackgroundColor | undefined;
    BackgroundOpacity?: number | undefined;
    FallbackFont?: BurninSubtitleFallbackFont | undefined;
    FontColor?: BurninSubtitleFontColor | undefined;
    FontFileBold?: string | undefined;
    FontFileBoldItalic?: string | undefined;
    FontFileItalic?: string | undefined;
    FontFileRegular?: string | undefined;
    FontOpacity?: number | undefined;
    FontResolution?: number | undefined;
    FontScript?: FontScript | undefined;
    FontSize?: number | undefined;
    HexFontColor?: string | undefined;
    OutlineColor?: BurninSubtitleOutlineColor | undefined;
    OutlineSize?: number | undefined;
    RemoveRubyReserveAttributes?: RemoveRubyReserveAttributes | undefined;
    ShadowColor?: BurninSubtitleShadowColor | undefined;
    ShadowOpacity?: number | undefined;
    ShadowXOffset?: number | undefined;
    ShadowYOffset?: number | undefined;
    StylePassthrough?: BurnInSubtitleStylePassthrough | undefined;
    TeletextSpacing?: BurninSubtitleTeletextSpacing | undefined;
    XPosition?: number | undefined;
    YPosition?: number | undefined;
}
export type CaptionDestinationType = "BURN_IN" | "DVB_SUB" | "EMBEDDED" | "EMBEDDED_PLUS_SCTE20" | "IMSC" | "SCTE20_PLUS_EMBEDDED" | "SCC" | "SRT" | "SMI" | "TELETEXT" | "TTML" | "WEBVTT" | (string & {});
export type DvbSubtitleAlignment = "CENTERED" | "LEFT" | "AUTO" | (string & {});
export type DvbSubtitleApplyFontColor = "WHITE_TEXT_ONLY" | "ALL_TEXT" | (string & {});
export type DvbSubtitleBackgroundColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type DvbddsHandling = "NONE" | "SPECIFIED" | "NO_DISPLAY_WINDOW" | "SPECIFIED_OPTIMAL" | (string & {});
export type DvbSubSubtitleFallbackFont = "BEST_MATCH" | "MONOSPACED_SANSSERIF" | "MONOSPACED_SERIF" | "PROPORTIONAL_SANSSERIF" | "PROPORTIONAL_SERIF" | (string & {});
export type DvbSubtitleFontColor = "WHITE" | "BLACK" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "HEX" | "AUTO" | (string & {});
export type DvbSubtitleOutlineColor = "BLACK" | "WHITE" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "AUTO" | (string & {});
export type DvbSubtitleShadowColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type DvbSubtitleStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export type DvbSubtitlingType = "HEARING_IMPAIRED" | "STANDARD" | (string & {});
export type DvbSubtitleTeletextSpacing = "FIXED_GRID" | "PROPORTIONAL" | "AUTO" | (string & {});
export interface DvbSubDestinationSettings {
    Alignment?: DvbSubtitleAlignment | undefined;
    ApplyFontColor?: DvbSubtitleApplyFontColor | undefined;
    BackgroundColor?: DvbSubtitleBackgroundColor | undefined;
    BackgroundOpacity?: number | undefined;
    DdsHandling?: DvbddsHandling | undefined;
    DdsXCoordinate?: number | undefined;
    DdsYCoordinate?: number | undefined;
    FallbackFont?: DvbSubSubtitleFallbackFont | undefined;
    FontColor?: DvbSubtitleFontColor | undefined;
    FontFileBold?: string | undefined;
    FontFileBoldItalic?: string | undefined;
    FontFileItalic?: string | undefined;
    FontFileRegular?: string | undefined;
    FontOpacity?: number | undefined;
    FontResolution?: number | undefined;
    FontScript?: FontScript | undefined;
    FontSize?: number | undefined;
    Height?: number | undefined;
    HexFontColor?: string | undefined;
    OutlineColor?: DvbSubtitleOutlineColor | undefined;
    OutlineSize?: number | undefined;
    ShadowColor?: DvbSubtitleShadowColor | undefined;
    ShadowOpacity?: number | undefined;
    ShadowXOffset?: number | undefined;
    ShadowYOffset?: number | undefined;
    StylePassthrough?: DvbSubtitleStylePassthrough | undefined;
    SubtitlingType?: DvbSubtitlingType | undefined;
    TeletextSpacing?: DvbSubtitleTeletextSpacing | undefined;
    Width?: number | undefined;
    XPosition?: number | undefined;
    YPosition?: number | undefined;
}
export type __integerMin1Max6 = number;
export interface EmbeddedDestinationSettings {
    Destination608ChannelNumber?: number | undefined;
    Destination708ServiceNumber?: number | undefined;
}
export type ImscAccessibilitySubs = "DISABLED" | "ENABLED" | (string & {});
export type ImscStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export interface ImscDestinationSettings {
    Accessibility?: ImscAccessibilitySubs | undefined;
    StylePassthrough?: ImscStylePassthrough | undefined;
}
export type SccDestinationFramerate = "FRAMERATE_23_97" | "FRAMERATE_24" | "FRAMERATE_25" | "FRAMERATE_29_97_DROPFRAME" | "FRAMERATE_29_97_NON_DROPFRAME" | (string & {});
export interface SccDestinationSettings {
    Framerate?: SccDestinationFramerate | undefined;
}
export type SrtStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export interface SrtDestinationSettings {
    StylePassthrough?: SrtStylePassthrough | undefined;
}
export type TeletextPageType = "PAGE_TYPE_INITIAL" | "PAGE_TYPE_SUBTITLE" | "PAGE_TYPE_ADDL_INFO" | "PAGE_TYPE_PROGRAM_SCHEDULE" | "PAGE_TYPE_HEARING_IMPAIRED_SUBTITLE" | (string & {});
export type __listOfTeletextPageType = TeletextPageType[];
export interface TeletextDestinationSettings {
    PageNumber?: string | undefined;
    PageTypes?: TeletextPageType[] | undefined;
}
export type TtmlBackgroundColor = "NONE" | "BLACK" | "WHITE" | "AUTO" | (string & {});
export type TtmlFontColor = "WHITE" | "BLACK" | "YELLOW" | "RED" | "GREEN" | "BLUE" | "AUTO" | (string & {});
export type TtmlFontStyle = "NORMAL" | "ITALIC" | (string & {});
export type TtmlFontWeight = "NORMAL" | "BOLD" | (string & {});
export type TtmlStylePassthrough = "ENABLED" | "DISABLED" | (string & {});
export type TtmlTextDecoration = "NONE" | "UNDERLINE" | (string & {});
export interface TtmlDestinationSettings {
    BackgroundColor?: TtmlBackgroundColor | undefined;
    BackgroundOpacity?: number | undefined;
    FontColor?: TtmlFontColor | undefined;
    FontOpacity?: number | undefined;
    FontSize?: number | undefined;
    FontStyle?: TtmlFontStyle | undefined;
    FontWeight?: TtmlFontWeight | undefined;
    StylePassthrough?: TtmlStylePassthrough | undefined;
    TextDecoration?: TtmlTextDecoration | undefined;
}
export type WebvttAccessibilitySubs = "DISABLED" | "ENABLED" | (string & {});
export type WebvttStylePassthrough = "ENABLED" | "DISABLED" | "STRICT" | "MERGE" | (string & {});
export interface WebvttDestinationSettings {
    Accessibility?: WebvttAccessibilitySubs | undefined;
    StylePassthrough?: WebvttStylePassthrough | undefined;
}
export interface CaptionDestinationSettings {
    BurninDestinationSettings?: BurninDestinationSettings | undefined;
    DestinationType?: CaptionDestinationType | undefined;
    DvbSubDestinationSettings?: DvbSubDestinationSettings | undefined;
    EmbeddedDestinationSettings?: EmbeddedDestinationSettings | undefined;
    ImscDestinationSettings?: ImscDestinationSettings | undefined;
    SccDestinationSettings?: SccDestinationSettings | undefined;
    SrtDestinationSettings?: SrtDestinationSettings | undefined;
    TeletextDestinationSettings?: TeletextDestinationSettings | undefined;
    TtmlDestinationSettings?: TtmlDestinationSettings | undefined;
    WebvttDestinationSettings?: WebvttDestinationSettings | undefined;
}
export type CaptionSource = "INPUT_CAPTION_SELECTOR" | "SMART_SUBTITLE" | (string & {});
export interface CaptionDescription {
    AudioSourceNames?: string[] | undefined;
    CaptionSelectorName?: string | undefined;
    CustomLanguageCode?: string | undefined;
    DestinationSettings?: CaptionDestinationSettings | undefined;
    LanguageCode?: LanguageCode | undefined;
    LanguageDescription?: string | undefined;
    Source?: CaptionSource | undefined;
}
export type __listOfCaptionDescription = CaptionDescription[];
export type CmfcAudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type CmfcAudioTrackType = "ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT" | "ALTERNATE_AUDIO_AUTO_SELECT" | "ALTERNATE_AUDIO_NOT_AUTO_SELECT" | "AUDIO_ONLY_VARIANT_STREAM" | (string & {});
export type CmfcC2paManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type CmfcDescriptiveVideoServiceFlag = "DONT_FLAG" | "FLAG" | (string & {});
export type CmfcIFrameOnlyManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type CmfcKlvMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type CmfcManifestMetadataSignaling = "ENABLED" | "DISABLED" | (string & {});
export type CmfcScte35Esam = "INSERT" | "NONE" | (string & {});
export type CmfcScte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type __stringMin1PatternArnAwsUsGovCnKmsAZ26EastWestCentralNorthSouthEastWest1912D12KeyAFAF098AFAF094AFAF094AFAF094AFAF0912MrkAFAF0932 = string;
export type CmfcTimedMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type CmfcTimedMetadataBoxVersion = "VERSION_0" | "VERSION_1" | (string & {});
export type __stringMax1000 = string;
export interface CmfcSettings {
    AudioDuration?: CmfcAudioDuration | undefined;
    AudioGroupId?: string | undefined;
    AudioRenditionSets?: string | undefined;
    AudioTrackType?: CmfcAudioTrackType | undefined;
    C2paManifest?: CmfcC2paManifest | undefined;
    CertificateSecret?: string | undefined;
    DescriptiveVideoServiceFlag?: CmfcDescriptiveVideoServiceFlag | undefined;
    IFrameOnlyManifest?: CmfcIFrameOnlyManifest | undefined;
    KlvMetadata?: CmfcKlvMetadata | undefined;
    ManifestMetadataSignaling?: CmfcManifestMetadataSignaling | undefined;
    Scte35Esam?: CmfcScte35Esam | undefined;
    Scte35Source?: CmfcScte35Source | undefined;
    SigningKmsKey?: string | undefined;
    TimedMetadata?: CmfcTimedMetadata | undefined;
    TimedMetadataBoxVersion?: CmfcTimedMetadataBoxVersion | undefined;
    TimedMetadataSchemeIdUri?: string | undefined;
    TimedMetadataValue?: string | undefined;
}
export type ContainerType = "F4V" | "GIF" | "ISMV" | "M2TS" | "M3U8" | "CMFC" | "MOV" | "MP4" | "MPD" | "MXF" | "OGG" | "WEBM" | "RAW" | "Y4M" | (string & {});
export type F4vMoovPlacement = "PROGRESSIVE_DOWNLOAD" | "NORMAL" | (string & {});
export interface F4vSettings {
    MoovPlacement?: F4vMoovPlacement | undefined;
}
export type M2tsAudioBufferModel = "DVB" | "ATSC" | (string & {});
export type M2tsAudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type __integerMin32Max8182 = number;
export type __listOf__integerMin32Max8182 = number[];
export type __integerMinNegative10000Max10000 = number;
export type M2tsBufferModel = "MULTIPLEX" | "NONE" | (string & {});
export type M2tsDataPtsControl = "AUTO" | "ALIGN_TO_VIDEO" | (string & {});
export type __integerMin25Max10000 = number;
export interface DvbNitSettings {
    NetworkId?: number | undefined;
    NetworkName?: string | undefined;
    NitInterval?: number | undefined;
}
export type OutputSdt = "SDT_FOLLOW" | "SDT_FOLLOW_IF_PRESENT" | "SDT_MANUAL" | "SDT_NONE" | (string & {});
export type __integerMin25Max2000 = number;
export interface DvbSdtSettings {
    OutputSdt?: OutputSdt | undefined;
    SdtInterval?: number | undefined;
    ServiceName?: string | undefined;
    ServiceProviderName?: string | undefined;
}
export type __integerMin1000Max30000 = number;
export interface DvbTdtSettings {
    TdtInterval?: number | undefined;
}
export type M2tsEbpAudioInterval = "VIDEO_AND_FIXED_INTERVALS" | "VIDEO_INTERVAL" | (string & {});
export type M2tsEbpPlacement = "VIDEO_AND_AUDIO_PIDS" | "VIDEO_PID" | (string & {});
export type M2tsEsRateInPes = "INCLUDE" | "EXCLUDE" | (string & {});
export type M2tsForceTsVideoEbpOrder = "FORCE" | "DEFAULT" | (string & {});
export type M2tsKlvMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type __integerMin0Max500 = number;
export type __integerMin0Max10000 = number;
export type M2tsNielsenId3 = "INSERT" | "NONE" | (string & {});
export type __integerMin0Max1000 = number;
export type M2tsPcrControl = "PCR_EVERY_PES_PACKET" | "CONFIGURED_PCR_PERIOD" | (string & {});
export type M2tsPreventBufferUnderflow = "DISABLED" | "ENABLED" | (string & {});
export type TsPtsOffset = "AUTO" | "SECONDS" | "MILLISECONDS" | (string & {});
export type M2tsRateMode = "VBR" | "CBR" | (string & {});
export interface M2tsScte35Esam {
    Scte35EsamPid?: number | undefined;
}
export type M2tsScte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type M2tsSegmentationMarkers = "NONE" | "RAI_SEGSTART" | "RAI_ADAPT" | "PSI_SEGSTART" | "EBP" | "EBP_LEGACY" | (string & {});
export type M2tsSegmentationStyle = "MAINTAIN_CADENCE" | "RESET_CADENCE" | (string & {});
export interface M2tsSettings {
    AudioBufferModel?: M2tsAudioBufferModel | undefined;
    AudioDuration?: M2tsAudioDuration | undefined;
    AudioFramesPerPes?: number | undefined;
    AudioPids?: number[] | undefined;
    AudioPtsOffsetDelta?: number | undefined;
    Bitrate?: number | undefined;
    BufferModel?: M2tsBufferModel | undefined;
    DataPTSControl?: M2tsDataPtsControl | undefined;
    DvbNitSettings?: DvbNitSettings | undefined;
    DvbSdtSettings?: DvbSdtSettings | undefined;
    DvbSubPids?: number[] | undefined;
    DvbTdtSettings?: DvbTdtSettings | undefined;
    DvbTeletextPid?: number | undefined;
    EbpAudioInterval?: M2tsEbpAudioInterval | undefined;
    EbpPlacement?: M2tsEbpPlacement | undefined;
    EsRateInPes?: M2tsEsRateInPes | undefined;
    ForceTsVideoEbpOrder?: M2tsForceTsVideoEbpOrder | undefined;
    FragmentTime?: number | undefined;
    KlvMetadata?: M2tsKlvMetadata | undefined;
    MaxPcrInterval?: number | undefined;
    MinEbpInterval?: number | undefined;
    NielsenId3?: M2tsNielsenId3 | undefined;
    NullPacketBitrate?: number | undefined;
    PatInterval?: number | undefined;
    PcrControl?: M2tsPcrControl | undefined;
    PcrPid?: number | undefined;
    PmtInterval?: number | undefined;
    PmtPid?: number | undefined;
    PreventBufferUnderflow?: M2tsPreventBufferUnderflow | undefined;
    PrivateMetadataPid?: number | undefined;
    ProgramNumber?: number | undefined;
    PtsOffset?: number | undefined;
    PtsOffsetMode?: TsPtsOffset | undefined;
    RateMode?: M2tsRateMode | undefined;
    Scte35Esam?: M2tsScte35Esam | undefined;
    Scte35Pid?: number | undefined;
    Scte35Source?: M2tsScte35Source | undefined;
    SegmentationMarkers?: M2tsSegmentationMarkers | undefined;
    SegmentationStyle?: M2tsSegmentationStyle | undefined;
    SegmentationTime?: number | undefined;
    TimedMetadataPid?: number | undefined;
    TransportStreamId?: number | undefined;
    VideoPid?: number | undefined;
}
export type M3u8AudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type M3u8DataPtsControl = "AUTO" | "ALIGN_TO_VIDEO" | (string & {});
export type M3u8NielsenId3 = "INSERT" | "NONE" | (string & {});
export type M3u8PcrControl = "PCR_EVERY_PES_PACKET" | "CONFIGURED_PCR_PERIOD" | (string & {});
export type M3u8Scte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type TimedMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export interface M3u8Settings {
    AudioDuration?: M3u8AudioDuration | undefined;
    AudioFramesPerPes?: number | undefined;
    AudioPids?: number[] | undefined;
    AudioPtsOffsetDelta?: number | undefined;
    DataPTSControl?: M3u8DataPtsControl | undefined;
    MaxPcrInterval?: number | undefined;
    NielsenId3?: M3u8NielsenId3 | undefined;
    PatInterval?: number | undefined;
    PcrControl?: M3u8PcrControl | undefined;
    PcrPid?: number | undefined;
    PmtInterval?: number | undefined;
    PmtPid?: number | undefined;
    PrivateMetadataPid?: number | undefined;
    ProgramNumber?: number | undefined;
    PtsOffset?: number | undefined;
    PtsOffsetMode?: TsPtsOffset | undefined;
    Scte35Pid?: number | undefined;
    Scte35Source?: M3u8Scte35Source | undefined;
    TimedMetadata?: TimedMetadata | undefined;
    TimedMetadataPid?: number | undefined;
    TransportStreamId?: number | undefined;
    VideoPid?: number | undefined;
}
export type MovClapAtom = "INCLUDE" | "EXCLUDE" | (string & {});
export type MovCslgAtom = "INCLUDE" | "EXCLUDE" | (string & {});
export type MovMpeg2FourCCControl = "XDCAM" | "MPEG" | (string & {});
export type MovPaddingControl = "OMNEON" | "NONE" | (string & {});
export type MovReference = "SELF_CONTAINED" | "EXTERNAL" | (string & {});
export interface MovSettings {
    AudioDuration?: CmfcAudioDuration | undefined;
    ClapAtom?: MovClapAtom | undefined;
    CslgAtom?: MovCslgAtom | undefined;
    Mpeg2FourCCControl?: MovMpeg2FourCCControl | undefined;
    PaddingControl?: MovPaddingControl | undefined;
    Reference?: MovReference | undefined;
}
export type Mp4C2paManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type Mp4CslgAtom = "INCLUDE" | "EXCLUDE" | (string & {});
export type __integerMin0Max1 = number;
export type Mp4FreeSpaceBox = "INCLUDE" | "EXCLUDE" | (string & {});
export type Mp4MoovPlacement = "PROGRESSIVE_DOWNLOAD" | "NORMAL" | (string & {});
export interface Mp4Settings {
    AudioDuration?: CmfcAudioDuration | undefined;
    C2paManifest?: Mp4C2paManifest | undefined;
    CertificateSecret?: string | undefined;
    CslgAtom?: Mp4CslgAtom | undefined;
    CttsVersion?: number | undefined;
    FreeSpaceBox?: Mp4FreeSpaceBox | undefined;
    MoovPlacement?: Mp4MoovPlacement | undefined;
    Mp4MajorBrand?: string | undefined;
    SigningKmsKey?: string | undefined;
}
export type MpdAccessibilityCaptionHints = "INCLUDE" | "EXCLUDE" | (string & {});
export type MpdAudioDuration = "DEFAULT_CODEC_DURATION" | "MATCH_VIDEO_DURATION" | (string & {});
export type MpdC2paManifest = "INCLUDE" | "EXCLUDE" | (string & {});
export type MpdCaptionContainerType = "RAW" | "FRAGMENTED_MP4" | (string & {});
export type MpdKlvMetadata = "NONE" | "PASSTHROUGH" | (string & {});
export type MpdManifestMetadataSignaling = "ENABLED" | "DISABLED" | (string & {});
export type MpdScte35Esam = "INSERT" | "NONE" | (string & {});
export type MpdScte35Source = "PASSTHROUGH" | "NONE" | "MANIFEST_CUES" | (string & {});
export type MpdTimedMetadata = "PASSTHROUGH" | "NONE" | (string & {});
export type MpdTimedMetadataBoxVersion = "VERSION_0" | "VERSION_1" | (string & {});
export interface MpdSettings {
    AccessibilityCaptionHints?: MpdAccessibilityCaptionHints | undefined;
    AudioDuration?: MpdAudioDuration | undefined;
    C2paManifest?: MpdC2paManifest | undefined;
    CaptionContainerType?: MpdCaptionContainerType | undefined;
    CertificateSecret?: string | undefined;
    KlvMetadata?: MpdKlvMetadata | undefined;
    ManifestMetadataSignaling?: MpdManifestMetadataSignaling | undefined;
    Scte35Esam?: MpdScte35Esam | undefined;
    Scte35Source?: MpdScte35Source | undefined;
    SigningKmsKey?: string | undefined;
    TimedMetadata?: MpdTimedMetadata | undefined;
    TimedMetadataBoxVersion?: MpdTimedMetadataBoxVersion | undefined;
    TimedMetadataSchemeIdUri?: string | undefined;
    TimedMetadataValue?: string | undefined;
}
export type MxfAfdSignaling = "NO_COPY" | "COPY_FROM_VIDEO" | (string & {});
export type MxfProfile = "D_10" | "XDCAM" | "OP1A" | "XAVC" | "XDCAM_RDD9" | (string & {});
export type MxfUncompressedAudioWrapping = "AUTO" | "AES3" | (string & {});
export type MxfXavcDurationMode = "ALLOW_ANY_DURATION" | "DROP_FRAMES_FOR_COMPLIANCE" | (string & {});
export interface MxfXavcProfileSettings {
    DurationMode?: MxfXavcDurationMode | undefined;
    MaxAncDataSize?: number | undefined;
}
export interface MxfSettings {
    AfdSignaling?: MxfAfdSignaling | undefined;
    Profile?: MxfProfile | undefined;
    UncompressedAudioWrapping?: MxfUncompressedAudioWrapping | undefined;
    XavcProfileSettings?: MxfXavcProfileSettings | undefined;
}
export interface ContainerSettings {
    CmfcSettings?: CmfcSettings | undefined;
    Container?: ContainerType | undefined;
    F4vSettings?: F4vSettings | undefined;
    M2tsSettings?: M2tsSettings | undefined;
    M3u8Settings?: M3u8Settings | undefined;
    MovSettings?: MovSettings | undefined;
    Mp4Settings?: Mp4Settings | undefined;
    MpdSettings?: MpdSettings | undefined;
    MxfSettings?: MxfSettings | undefined;
}
export type __stringMax256 = string;
export type HlsAudioOnlyContainer = "AUTOMATIC" | "M2TS" | (string & {});
export type HlsAudioTrackType = "ALTERNATE_AUDIO_AUTO_SELECT_DEFAULT" | "ALTERNATE_AUDIO_AUTO_SELECT" | "ALTERNATE_AUDIO_NOT_AUTO_SELECT" | "AUDIO_ONLY_VARIANT_STREAM" | (string & {});
export type HlsDescriptiveVideoServiceFlag = "DONT_FLAG" | "FLAG" | (string & {});
export type HlsIFrameOnlyManifest = "INCLUDE" | "INCLUDE_AS_TS" | "EXCLUDE" | (string & {});
export interface HlsSettings {
    AudioGroupId?: string | undefined;
    AudioOnlyContainer?: HlsAudioOnlyContainer | undefined;
    AudioRenditionSets?: string | undefined;
    AudioTrackType?: HlsAudioTrackType | undefined;
    DescriptiveVideoServiceFlag?: HlsDescriptiveVideoServiceFlag | undefined;
    IFrameOnlyManifest?: HlsIFrameOnlyManifest | undefined;
    SegmentModifier?: string | undefined;
}
export interface OutputSettings {
    HlsSettings?: HlsSettings | undefined;
}
export type __stringMin0 = string;
export type AfdSignaling = "NONE" | "AUTO" | "FIXED" | (string & {});
export type AntiAlias = "DISABLED" | "ENABLED" | (string & {});
export type ChromaPositionMode = "AUTO" | "FORCE_CENTER" | "FORCE_TOP_LEFT" | (string & {});
export type Av1AdaptiveQuantization = "OFF" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | (string & {});
export type Av1BitDepth = "BIT_8" | "BIT_10" | (string & {});
export type __integerMin1000Max1152000000 = number;
export type Av1FilmGrainSynthesis = "DISABLED" | "ENABLED" | (string & {});
export type Av1FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Av1FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type __integerMin0Max15 = number;
export type __integerMin1Max10 = number;
export type __doubleMin0Max1 = number;
export interface Av1QvbrSettings {
    QvbrQualityLevel?: number | undefined;
    QvbrQualityLevelFineTune?: number | undefined;
}
export type Av1RateControlMode = "CBR" | "QVBR" | (string & {});
export type Av1SceneChangeDetect = "DISABLED" | "ENABLED" | "TRANSITION_DETECTION" | (string & {});
export type __integerMin1000Max3000 = number;
export type Av1SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export interface Av1Settings {
    AdaptiveQuantization?: Av1AdaptiveQuantization | undefined;
    BitDepth?: Av1BitDepth | undefined;
    Bitrate?: number | undefined;
    FilmGrainSynthesis?: Av1FilmGrainSynthesis | undefined;
    FramerateControl?: Av1FramerateControl | undefined;
    FramerateConversionAlgorithm?: Av1FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopSize?: number | undefined;
    MaxBitrate?: number | undefined;
    NumberBFramesBetweenReferenceFrames?: number | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    QvbrSettings?: Av1QvbrSettings | undefined;
    RateControlMode?: Av1RateControlMode | undefined;
    SceneChangeDetect?: Av1SceneChangeDetect | undefined;
    Slices?: number | undefined;
    SlidingWindowMs?: number | undefined;
    SlidingWindowPeakBitrate?: number | undefined;
    SpatialAdaptiveQuantization?: Av1SpatialAdaptiveQuantization | undefined;
}
export type AvcIntraClass = "CLASS_50" | "CLASS_100" | "CLASS_200" | "CLASS_4K_2K" | (string & {});
export type AvcIntraUhdQualityTuningLevel = "SINGLE_PASS" | "MULTI_PASS" | (string & {});
export interface AvcIntraUhdSettings {
    QualityTuningLevel?: AvcIntraUhdQualityTuningLevel | undefined;
}
export type AvcIntraFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type AvcIntraFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type __integerMin24Max60000 = number;
export type AvcIntraInterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type AvcIntraScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type AvcIntraSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type AvcIntraTelecine = "NONE" | "HARD" | (string & {});
export interface AvcIntraSettings {
    AvcIntraClass?: AvcIntraClass | undefined;
    AvcIntraUhdSettings?: AvcIntraUhdSettings | undefined;
    FramerateControl?: AvcIntraFramerateControl | undefined;
    FramerateConversionAlgorithm?: AvcIntraFramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    InterlaceMode?: AvcIntraInterlaceMode | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    ScanTypeConversionMode?: AvcIntraScanTypeConversionMode | undefined;
    SlowPal?: AvcIntraSlowPal | undefined;
    Telecine?: AvcIntraTelecine | undefined;
}
export type VideoCodec = "AV1" | "AVC_INTRA" | "FRAME_CAPTURE" | "GIF" | "H_264" | "H_265" | "MPEG2" | "PASSTHROUGH" | "PRORES" | "UNCOMPRESSED" | "VC3" | "VP8" | "VP9" | "XAVC" | (string & {});
export type __integerMin1Max10000000 = number;
export type __integerMin1Max100 = number;
export interface FrameCaptureSettings {
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    MaxCaptures?: number | undefined;
    Quality?: number | undefined;
}
export type GifFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type GifFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | (string & {});
export interface GifSettings {
    FramerateControl?: GifFramerateControl | undefined;
    FramerateConversionAlgorithm?: GifFramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
}
export type H264AdaptiveQuantization = "OFF" | "AUTO" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | (string & {});
export type BandwidthReductionFilterSharpening = "LOW" | "MEDIUM" | "HIGH" | "OFF" | (string & {});
export type BandwidthReductionFilterStrength = "LOW" | "MEDIUM" | "HIGH" | "AUTO" | "OFF" | (string & {});
export interface BandwidthReductionFilter {
    Sharpening?: BandwidthReductionFilterSharpening | undefined;
    Strength?: BandwidthReductionFilterStrength | undefined;
}
export type H264CodecLevel = "AUTO" | "LEVEL_1" | "LEVEL_1_1" | "LEVEL_1_2" | "LEVEL_1_3" | "LEVEL_2" | "LEVEL_2_1" | "LEVEL_2_2" | "LEVEL_3" | "LEVEL_3_1" | "LEVEL_3_2" | "LEVEL_4" | "LEVEL_4_1" | "LEVEL_4_2" | "LEVEL_5" | "LEVEL_5_1" | "LEVEL_5_2" | (string & {});
export type H264CodecProfile = "BASELINE" | "HIGH" | "HIGH_10BIT" | "HIGH_422" | "HIGH_422_10BIT" | "MAIN" | (string & {});
export type H264DynamicSubGop = "ADAPTIVE" | "STATIC" | (string & {});
export type H264EndOfStreamMarkers = "INCLUDE" | "SUPPRESS" | (string & {});
export type H264EntropyEncoding = "CABAC" | "CAVLC" | (string & {});
export type H264ExplicitWeightedPrediction = "DISABLED" | "ENABLED" | (string & {});
export type H264FieldEncoding = "PAFF" | "FORCE_FIELD" | "MBAFF" | (string & {});
export type H264FlickerAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H264FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type H264GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type H264GopSizeUnits = "FRAMES" | "SECONDS" | "AUTO" | (string & {});
export type __integerMin0Max1152000000 = number;
export type H264InterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type __integerMin0Max30 = number;
export type __integerMin0Max7 = number;
export type H264ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H264QualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export interface H264QvbrSettings {
    MaxAverageBitrate?: number | undefined;
    QvbrQualityLevel?: number | undefined;
    QvbrQualityLevelFineTune?: number | undefined;
}
export type H264RateControlMode = "VBR" | "CBR" | "QVBR" | (string & {});
export type H264RepeatPps = "DISABLED" | "ENABLED" | (string & {});
export type H264SaliencyAwareEncoding = "DISABLED" | "PREFERRED" | (string & {});
export type H264ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type H264SceneChangeDetect = "DISABLED" | "ENABLED" | "TRANSITION_DETECTION" | (string & {});
export type H264SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin0Max128 = number;
export type H264SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H264Syntax = "DEFAULT" | "RP2027" | (string & {});
export type H264Telecine = "NONE" | "SOFT" | "HARD" | (string & {});
export type H264TemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H264UnregisteredSeiTimecode = "DISABLED" | "ENABLED" | (string & {});
export type H264WriteMp4PackagingType = "AVC1" | "AVC3" | (string & {});
export interface H264Settings {
    AdaptiveQuantization?: H264AdaptiveQuantization | undefined;
    BandwidthReductionFilter?: BandwidthReductionFilter | undefined;
    Bitrate?: number | undefined;
    CodecLevel?: H264CodecLevel | undefined;
    CodecProfile?: H264CodecProfile | undefined;
    DynamicSubGop?: H264DynamicSubGop | undefined;
    EndOfStreamMarkers?: H264EndOfStreamMarkers | undefined;
    EntropyEncoding?: H264EntropyEncoding | undefined;
    ExplicitWeightedPrediction?: H264ExplicitWeightedPrediction | undefined;
    FieldEncoding?: H264FieldEncoding | undefined;
    FlickerAdaptiveQuantization?: H264FlickerAdaptiveQuantization | undefined;
    FramerateControl?: H264FramerateControl | undefined;
    FramerateConversionAlgorithm?: H264FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopBReference?: H264GopBReference | undefined;
    GopClosedCadence?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: H264GopSizeUnits | undefined;
    HrdBufferFinalFillPercentage?: number | undefined;
    HrdBufferInitialFillPercentage?: number | undefined;
    HrdBufferSize?: number | undefined;
    InterlaceMode?: H264InterlaceMode | undefined;
    MaxBitrate?: number | undefined;
    MinIInterval?: number | undefined;
    NumberBFramesBetweenReferenceFrames?: number | undefined;
    NumberReferenceFrames?: number | undefined;
    ParControl?: H264ParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    QualityTuningLevel?: H264QualityTuningLevel | undefined;
    QvbrSettings?: H264QvbrSettings | undefined;
    RateControlMode?: H264RateControlMode | undefined;
    RepeatPps?: H264RepeatPps | undefined;
    SaliencyAwareEncoding?: H264SaliencyAwareEncoding | undefined;
    ScanTypeConversionMode?: H264ScanTypeConversionMode | undefined;
    SceneChangeDetect?: H264SceneChangeDetect | undefined;
    Slices?: number | undefined;
    SlidingWindowMs?: number | undefined;
    SlidingWindowPeakBitrate?: number | undefined;
    SlowPal?: H264SlowPal | undefined;
    Softness?: number | undefined;
    SpatialAdaptiveQuantization?: H264SpatialAdaptiveQuantization | undefined;
    Syntax?: H264Syntax | undefined;
    Telecine?: H264Telecine | undefined;
    TemporalAdaptiveQuantization?: H264TemporalAdaptiveQuantization | undefined;
    UnregisteredSeiTimecode?: H264UnregisteredSeiTimecode | undefined;
    WriteMp4PackagingType?: H264WriteMp4PackagingType | undefined;
}
export type H265AdaptiveQuantization = "OFF" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | "AUTO" | (string & {});
export type H265AlternateTransferFunctionSei = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin1000Max1466400000 = number;
export type H265CodecLevel = "AUTO" | "LEVEL_1" | "LEVEL_2" | "LEVEL_2_1" | "LEVEL_3" | "LEVEL_3_1" | "LEVEL_4" | "LEVEL_4_1" | "LEVEL_5" | "LEVEL_5_1" | "LEVEL_5_2" | "LEVEL_6" | "LEVEL_6_1" | "LEVEL_6_2" | (string & {});
export type H265CodecProfile = "MAIN_MAIN" | "MAIN_HIGH" | "MAIN10_MAIN" | "MAIN10_HIGH" | "MAIN_422_8BIT_MAIN" | "MAIN_422_8BIT_HIGH" | "MAIN_422_10BIT_MAIN" | "MAIN_422_10BIT_HIGH" | (string & {});
export type H265Deblocking = "ENABLED" | "DISABLED" | (string & {});
export type H265DynamicSubGop = "ADAPTIVE" | "STATIC" | (string & {});
export type H265EndOfStreamMarkers = "INCLUDE" | "SUPPRESS" | (string & {});
export type H265FlickerAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H265FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H265FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type H265GopBReference = "DISABLED" | "ENABLED" | (string & {});
export type H265GopSizeUnits = "FRAMES" | "SECONDS" | "AUTO" | (string & {});
export type __integerMin0Max1466400000 = number;
export type H265InterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type H265MvOverPictureBoundaries = "ENABLED" | "DISABLED" | (string & {});
export type H265MvTemporalPredictor = "ENABLED" | "DISABLED" | (string & {});
export type H265ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type H265QualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export interface H265QvbrSettings {
    MaxAverageBitrate?: number | undefined;
    QvbrQualityLevel?: number | undefined;
    QvbrQualityLevelFineTune?: number | undefined;
}
export type H265RateControlMode = "VBR" | "CBR" | "QVBR" | (string & {});
export type H265SampleAdaptiveOffsetFilterMode = "DEFAULT" | "ADAPTIVE" | "OFF" | (string & {});
export type H265ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type H265SceneChangeDetect = "DISABLED" | "ENABLED" | "TRANSITION_DETECTION" | (string & {});
export type H265SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type H265SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H265Telecine = "NONE" | "SOFT" | "HARD" | (string & {});
export type H265TemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type H265TemporalIds = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin64Max2160 = number;
export type H265TilePadding = "NONE" | "PADDED" | (string & {});
export type __integerMin256Max3840 = number;
export type H265Tiles = "DISABLED" | "ENABLED" | (string & {});
export type H265TreeBlockSize = "AUTO" | "TREE_SIZE_32X32" | (string & {});
export type H265UnregisteredSeiTimecode = "DISABLED" | "ENABLED" | (string & {});
export type H265WriteMp4PackagingType = "HVC1" | "HEV1" | (string & {});
export interface H265Settings {
    AdaptiveQuantization?: H265AdaptiveQuantization | undefined;
    AlternateTransferFunctionSei?: H265AlternateTransferFunctionSei | undefined;
    BandwidthReductionFilter?: BandwidthReductionFilter | undefined;
    Bitrate?: number | undefined;
    CodecLevel?: H265CodecLevel | undefined;
    CodecProfile?: H265CodecProfile | undefined;
    Deblocking?: H265Deblocking | undefined;
    DynamicSubGop?: H265DynamicSubGop | undefined;
    EndOfStreamMarkers?: H265EndOfStreamMarkers | undefined;
    FlickerAdaptiveQuantization?: H265FlickerAdaptiveQuantization | undefined;
    FramerateControl?: H265FramerateControl | undefined;
    FramerateConversionAlgorithm?: H265FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopBReference?: H265GopBReference | undefined;
    GopClosedCadence?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: H265GopSizeUnits | undefined;
    HrdBufferFinalFillPercentage?: number | undefined;
    HrdBufferInitialFillPercentage?: number | undefined;
    HrdBufferSize?: number | undefined;
    InterlaceMode?: H265InterlaceMode | undefined;
    MaxBitrate?: number | undefined;
    MinIInterval?: number | undefined;
    MvOverPictureBoundaries?: H265MvOverPictureBoundaries | undefined;
    MvTemporalPredictor?: H265MvTemporalPredictor | undefined;
    NumberBFramesBetweenReferenceFrames?: number | undefined;
    NumberReferenceFrames?: number | undefined;
    ParControl?: H265ParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    QualityTuningLevel?: H265QualityTuningLevel | undefined;
    QvbrSettings?: H265QvbrSettings | undefined;
    RateControlMode?: H265RateControlMode | undefined;
    SampleAdaptiveOffsetFilterMode?: H265SampleAdaptiveOffsetFilterMode | undefined;
    ScanTypeConversionMode?: H265ScanTypeConversionMode | undefined;
    SceneChangeDetect?: H265SceneChangeDetect | undefined;
    Slices?: number | undefined;
    SlidingWindowMs?: number | undefined;
    SlidingWindowPeakBitrate?: number | undefined;
    SlowPal?: H265SlowPal | undefined;
    SpatialAdaptiveQuantization?: H265SpatialAdaptiveQuantization | undefined;
    Telecine?: H265Telecine | undefined;
    TemporalAdaptiveQuantization?: H265TemporalAdaptiveQuantization | undefined;
    TemporalIds?: H265TemporalIds | undefined;
    TileHeight?: number | undefined;
    TilePadding?: H265TilePadding | undefined;
    TileWidth?: number | undefined;
    Tiles?: H265Tiles | undefined;
    TreeBlockSize?: H265TreeBlockSize | undefined;
    UnregisteredSeiTimecode?: H265UnregisteredSeiTimecode | undefined;
    WriteMp4PackagingType?: H265WriteMp4PackagingType | undefined;
}
export type Mpeg2AdaptiveQuantization = "OFF" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type __integerMin1000Max288000000 = number;
export type Mpeg2CodecLevel = "AUTO" | "LOW" | "MAIN" | "HIGH1440" | "HIGH" | (string & {});
export type Mpeg2CodecProfile = "MAIN" | "PROFILE_422" | (string & {});
export type Mpeg2DynamicSubGop = "ADAPTIVE" | "STATIC" | (string & {});
export type Mpeg2FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Mpeg2FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Mpeg2GopSizeUnits = "FRAMES" | "SECONDS" | (string & {});
export type __integerMin0Max47185920 = number;
export type Mpeg2InterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type Mpeg2IntraDcPrecision = "AUTO" | "INTRA_DC_PRECISION_8" | "INTRA_DC_PRECISION_9" | "INTRA_DC_PRECISION_10" | "INTRA_DC_PRECISION_11" | (string & {});
export type __integerMin1000Max300000000 = number;
export type Mpeg2ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Mpeg2QualityTuningLevel = "SINGLE_PASS" | "MULTI_PASS" | (string & {});
export type Mpeg2RateControlMode = "VBR" | "CBR" | (string & {});
export type Mpeg2ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type Mpeg2SceneChangeDetect = "DISABLED" | "ENABLED" | (string & {});
export type Mpeg2SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type Mpeg2SpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type Mpeg2Syntax = "DEFAULT" | "D_10" | (string & {});
export type Mpeg2Telecine = "NONE" | "SOFT" | "HARD" | (string & {});
export type Mpeg2TemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export interface Mpeg2Settings {
    AdaptiveQuantization?: Mpeg2AdaptiveQuantization | undefined;
    Bitrate?: number | undefined;
    CodecLevel?: Mpeg2CodecLevel | undefined;
    CodecProfile?: Mpeg2CodecProfile | undefined;
    DynamicSubGop?: Mpeg2DynamicSubGop | undefined;
    FramerateControl?: Mpeg2FramerateControl | undefined;
    FramerateConversionAlgorithm?: Mpeg2FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopClosedCadence?: number | undefined;
    GopSize?: number | undefined;
    GopSizeUnits?: Mpeg2GopSizeUnits | undefined;
    HrdBufferFinalFillPercentage?: number | undefined;
    HrdBufferInitialFillPercentage?: number | undefined;
    HrdBufferSize?: number | undefined;
    InterlaceMode?: Mpeg2InterlaceMode | undefined;
    IntraDcPrecision?: Mpeg2IntraDcPrecision | undefined;
    MaxBitrate?: number | undefined;
    MinIInterval?: number | undefined;
    NumberBFramesBetweenReferenceFrames?: number | undefined;
    ParControl?: Mpeg2ParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    QualityTuningLevel?: Mpeg2QualityTuningLevel | undefined;
    RateControlMode?: Mpeg2RateControlMode | undefined;
    ScanTypeConversionMode?: Mpeg2ScanTypeConversionMode | undefined;
    SceneChangeDetect?: Mpeg2SceneChangeDetect | undefined;
    SlidingWindowMs?: number | undefined;
    SlidingWindowPeakBitrate?: number | undefined;
    SlowPal?: Mpeg2SlowPal | undefined;
    Softness?: number | undefined;
    SpatialAdaptiveQuantization?: Mpeg2SpatialAdaptiveQuantization | undefined;
    Syntax?: Mpeg2Syntax | undefined;
    Telecine?: Mpeg2Telecine | undefined;
    TemporalAdaptiveQuantization?: Mpeg2TemporalAdaptiveQuantization | undefined;
}
export type FrameControl = "NEAREST_IDRFRAME" | "NEAREST_IFRAME" | (string & {});
export type PassthroughSegmentationMode = "AUTO" | "DURATION_BASED" | "GOP_COUNT" | (string & {});
export type VideoSelectorMode = "AUTO" | "REMUX_ALL" | (string & {});
export interface PassthroughSettings {
    FrameControl?: FrameControl | undefined;
    GopsPerSegment?: number | undefined;
    SegmentationMode?: PassthroughSegmentationMode | undefined;
    VideoSelectorMode?: VideoSelectorMode | undefined;
}
export type ProresChromaSampling = "PRESERVE_444_SAMPLING" | "SUBSAMPLE_TO_422" | (string & {});
export type ProresCodecProfile = "APPLE_PRORES_422" | "APPLE_PRORES_422_HQ" | "APPLE_PRORES_422_LT" | "APPLE_PRORES_422_PROXY" | "APPLE_PRORES_4444" | "APPLE_PRORES_4444_XQ" | (string & {});
export type ProresFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type ProresFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type ProresInterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type ProresParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type ProresScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type ProresSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type ProresTelecine = "NONE" | "HARD" | (string & {});
export interface ProresSettings {
    ChromaSampling?: ProresChromaSampling | undefined;
    CodecProfile?: ProresCodecProfile | undefined;
    FramerateControl?: ProresFramerateControl | undefined;
    FramerateConversionAlgorithm?: ProresFramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    InterlaceMode?: ProresInterlaceMode | undefined;
    ParControl?: ProresParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    ScanTypeConversionMode?: ProresScanTypeConversionMode | undefined;
    SlowPal?: ProresSlowPal | undefined;
    Telecine?: ProresTelecine | undefined;
}
export type UncompressedFourcc = "I420" | "I422" | "I444" | (string & {});
export type UncompressedFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type UncompressedFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type UncompressedInterlaceMode = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type UncompressedScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type UncompressedSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type UncompressedTelecine = "NONE" | "HARD" | (string & {});
export interface UncompressedSettings {
    Fourcc?: UncompressedFourcc | undefined;
    FramerateControl?: UncompressedFramerateControl | undefined;
    FramerateConversionAlgorithm?: UncompressedFramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    InterlaceMode?: UncompressedInterlaceMode | undefined;
    ScanTypeConversionMode?: UncompressedScanTypeConversionMode | undefined;
    SlowPal?: UncompressedSlowPal | undefined;
    Telecine?: UncompressedTelecine | undefined;
}
export type Vc3FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vc3FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Vc3InterlaceMode = "INTERLACED" | "PROGRESSIVE" | (string & {});
export type Vc3ScanTypeConversionMode = "INTERLACED" | "INTERLACED_OPTIMIZE" | (string & {});
export type Vc3SlowPal = "DISABLED" | "ENABLED" | (string & {});
export type Vc3Telecine = "NONE" | "HARD" | (string & {});
export type Vc3Class = "CLASS_145_8BIT" | "CLASS_220_8BIT" | "CLASS_220_10BIT" | (string & {});
export interface Vc3Settings {
    FramerateControl?: Vc3FramerateControl | undefined;
    FramerateConversionAlgorithm?: Vc3FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    InterlaceMode?: Vc3InterlaceMode | undefined;
    ScanTypeConversionMode?: Vc3ScanTypeConversionMode | undefined;
    SlowPal?: Vc3SlowPal | undefined;
    Telecine?: Vc3Telecine | undefined;
    Vc3Class?: Vc3Class | undefined;
}
export type Vp8FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp8FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Vp8ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp8QualityTuningLevel = "MULTI_PASS" | "MULTI_PASS_HQ" | (string & {});
export type Vp8RateControlMode = "VBR" | (string & {});
export interface Vp8Settings {
    Bitrate?: number | undefined;
    FramerateControl?: Vp8FramerateControl | undefined;
    FramerateConversionAlgorithm?: Vp8FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopSize?: number | undefined;
    HrdBufferSize?: number | undefined;
    MaxBitrate?: number | undefined;
    ParControl?: Vp8ParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    QualityTuningLevel?: Vp8QualityTuningLevel | undefined;
    RateControlMode?: Vp8RateControlMode | undefined;
}
export type __integerMin1000Max480000000 = number;
export type Vp9FramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp9FramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type Vp9ParControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type Vp9QualityTuningLevel = "MULTI_PASS" | "MULTI_PASS_HQ" | (string & {});
export type Vp9RateControlMode = "VBR" | (string & {});
export interface Vp9Settings {
    Bitrate?: number | undefined;
    FramerateControl?: Vp9FramerateControl | undefined;
    FramerateConversionAlgorithm?: Vp9FramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    GopSize?: number | undefined;
    HrdBufferSize?: number | undefined;
    MaxBitrate?: number | undefined;
    ParControl?: Vp9ParControl | undefined;
    ParDenominator?: number | undefined;
    ParNumerator?: number | undefined;
    QualityTuningLevel?: Vp9QualityTuningLevel | undefined;
    RateControlMode?: Vp9RateControlMode | undefined;
}
export type XavcAdaptiveQuantization = "OFF" | "AUTO" | "LOW" | "MEDIUM" | "HIGH" | "HIGHER" | "MAX" | (string & {});
export type XavcEntropyEncoding = "AUTO" | "CABAC" | "CAVLC" | (string & {});
export type XavcFramerateControl = "INITIALIZE_FROM_SOURCE" | "SPECIFIED" | (string & {});
export type XavcFramerateConversionAlgorithm = "DUPLICATE_DROP" | "INTERPOLATE" | "FRAMEFORMER" | "MAINTAIN_FRAME_COUNT" | (string & {});
export type XavcProfile = "XAVC_HD_INTRA_CBG" | "XAVC_4K_INTRA_CBG" | "XAVC_4K_INTRA_VBR" | "XAVC_HD" | "XAVC_4K" | (string & {});
export type XavcSlowPal = "DISABLED" | "ENABLED" | (string & {});
export type XavcSpatialAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type XavcTemporalAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type Xavc4kIntraCbgProfileClass = "CLASS_100" | "CLASS_300" | "CLASS_480" | (string & {});
export interface Xavc4kIntraCbgProfileSettings {
    XavcClass?: Xavc4kIntraCbgProfileClass | undefined;
}
export type Xavc4kIntraVbrProfileClass = "CLASS_100" | "CLASS_300" | "CLASS_480" | (string & {});
export interface Xavc4kIntraVbrProfileSettings {
    XavcClass?: Xavc4kIntraVbrProfileClass | undefined;
}
export type Xavc4kProfileBitrateClass = "BITRATE_CLASS_100" | "BITRATE_CLASS_140" | "BITRATE_CLASS_200" | (string & {});
export type Xavc4kProfileCodecProfile = "HIGH" | "HIGH_422" | (string & {});
export type XavcFlickerAdaptiveQuantization = "DISABLED" | "ENABLED" | (string & {});
export type XavcGopBReference = "DISABLED" | "ENABLED" | (string & {});
export type Xavc4kProfileQualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export type __integerMin8Max12 = number;
export interface Xavc4kProfileSettings {
    BitrateClass?: Xavc4kProfileBitrateClass | undefined;
    CodecProfile?: Xavc4kProfileCodecProfile | undefined;
    FlickerAdaptiveQuantization?: XavcFlickerAdaptiveQuantization | undefined;
    GopBReference?: XavcGopBReference | undefined;
    GopClosedCadence?: number | undefined;
    HrdBufferSize?: number | undefined;
    QualityTuningLevel?: Xavc4kProfileQualityTuningLevel | undefined;
    Slices?: number | undefined;
}
export type XavcInterlaceMode = "PROGRESSIVE" | "TOP_FIELD" | "BOTTOM_FIELD" | "FOLLOW_TOP_FIELD" | "FOLLOW_BOTTOM_FIELD" | (string & {});
export type XavcHdIntraCbgProfileClass = "CLASS_50" | "CLASS_100" | "CLASS_200" | (string & {});
export interface XavcHdIntraCbgProfileSettings {
    InterlaceMode?: XavcInterlaceMode | undefined;
    XavcClass?: XavcHdIntraCbgProfileClass | undefined;
}
export type XavcHdProfileBitrateClass = "BITRATE_CLASS_25" | "BITRATE_CLASS_35" | "BITRATE_CLASS_50" | (string & {});
export type XavcHdProfileQualityTuningLevel = "SINGLE_PASS" | "SINGLE_PASS_HQ" | "MULTI_PASS_HQ" | (string & {});
export type __integerMin4Max12 = number;
export type XavcHdProfileTelecine = "NONE" | "HARD" | (string & {});
export interface XavcHdProfileSettings {
    BitrateClass?: XavcHdProfileBitrateClass | undefined;
    FlickerAdaptiveQuantization?: XavcFlickerAdaptiveQuantization | undefined;
    GopBReference?: XavcGopBReference | undefined;
    GopClosedCadence?: number | undefined;
    HrdBufferSize?: number | undefined;
    InterlaceMode?: XavcInterlaceMode | undefined;
    QualityTuningLevel?: XavcHdProfileQualityTuningLevel | undefined;
    Slices?: number | undefined;
    Telecine?: XavcHdProfileTelecine | undefined;
}
export interface XavcSettings {
    AdaptiveQuantization?: XavcAdaptiveQuantization | undefined;
    EntropyEncoding?: XavcEntropyEncoding | undefined;
    FramerateControl?: XavcFramerateControl | undefined;
    FramerateConversionAlgorithm?: XavcFramerateConversionAlgorithm | undefined;
    FramerateDenominator?: number | undefined;
    FramerateNumerator?: number | undefined;
    PerFrameMetrics?: FrameMetricType[] | undefined;
    Profile?: XavcProfile | undefined;
    SlowPal?: XavcSlowPal | undefined;
    Softness?: number | undefined;
    SpatialAdaptiveQuantization?: XavcSpatialAdaptiveQuantization | undefined;
    TemporalAdaptiveQuantization?: XavcTemporalAdaptiveQuantization | undefined;
    Xavc4kIntraCbgProfileSettings?: Xavc4kIntraCbgProfileSettings | undefined;
    Xavc4kIntraVbrProfileSettings?: Xavc4kIntraVbrProfileSettings | undefined;
    Xavc4kProfileSettings?: Xavc4kProfileSettings | undefined;
    XavcHdIntraCbgProfileSettings?: XavcHdIntraCbgProfileSettings | undefined;
    XavcHdProfileSettings?: XavcHdProfileSettings | undefined;
}
export interface VideoCodecSettings {
    Av1Settings?: Av1Settings | undefined;
    AvcIntraSettings?: AvcIntraSettings | undefined;
    Codec?: VideoCodec | undefined;
    FrameCaptureSettings?: FrameCaptureSettings | undefined;
    GifSettings?: GifSettings | undefined;
    H264Settings?: H264Settings | undefined;
    H265Settings?: H265Settings | undefined;
    Mpeg2Settings?: Mpeg2Settings | undefined;
    PassthroughSettings?: PassthroughSettings | undefined;
    ProresSettings?: ProresSettings | undefined;
    UncompressedSettings?: UncompressedSettings | undefined;
    Vc3Settings?: Vc3Settings | undefined;
    Vp8Settings?: Vp8Settings | undefined;
    Vp9Settings?: Vp9Settings | undefined;
    XavcSettings?: XavcSettings | undefined;
}
export type ColorMetadata = "IGNORE" | "INSERT" | (string & {});
export type DropFrameTimecode = "DISABLED" | "ENABLED" | (string & {});
export type RespondToAfd = "NONE" | "RESPOND" | "PASSTHROUGH" | (string & {});
export type ScalingBehavior = "DEFAULT" | "STRETCH_TO_OUTPUT" | "FIT" | "FIT_NO_UPSCALE" | "FILL" | "SMART_CROP" | (string & {});
export type VideoTimecodeInsertion = "DISABLED" | "PIC_TIMING_SEI" | (string & {});
export type TimecodeTrack = "DISABLED" | "ENABLED" | (string & {});
export type __integerMin90Max105 = number;
export type __integerMin920Max1023 = number;
export type __integerMinNegative5Max10 = number;
export interface ClipLimits {
    MaximumRGBTolerance?: number | undefined;
    MaximumYUV?: number | undefined;
    MinimumRGBTolerance?: number | undefined;
    MinimumYUV?: number | undefined;
}
export type ColorSpaceConversion = "NONE" | "FORCE_601" | "FORCE_709" | "FORCE_HDR10" | "FORCE_HLG_2020" | "FORCE_P3DCI" | "FORCE_P3D65_SDR" | "FORCE_P3D65_HDR" | (string & {});
export type HDRToSDRToneMapper = "PRESERVE_DETAILS" | "VIBRANT" | (string & {});
export type __integerMinNegative180Max180 = number;
export type SampleRangeConversion = "LIMITED_RANGE_SQUEEZE" | "NONE" | "LIMITED_RANGE_CLIP" | (string & {});
export interface ColorCorrector {
    Brightness?: number | undefined;
    ClipLimits?: ClipLimits | undefined;
    ColorSpaceConversion?: ColorSpaceConversion | undefined;
    Contrast?: number | undefined;
    Hdr10Metadata?: Hdr10Metadata | undefined;
    HdrToSdrToneMapper?: HDRToSDRToneMapper | undefined;
    Hue?: number | undefined;
    MaxLuminance?: number | undefined;
    SampleRangeConversion?: SampleRangeConversion | undefined;
    Saturation?: number | undefined;
    SdrReferenceWhiteLevel?: number | undefined;
}
export type DeinterlaceAlgorithm = "INTERPOLATE" | "INTERPOLATE_TICKER" | "BLEND" | "BLEND_TICKER" | "LINEAR_INTERPOLATION" | (string & {});
export type DeinterlacerControl = "FORCE_ALL_FRAMES" | "NORMAL" | (string & {});
export type DeinterlacerMode = "DEINTERLACE" | "INVERSE_TELECINE" | "ADAPTIVE" | (string & {});
export interface Deinterlacer {
    Algorithm?: DeinterlaceAlgorithm | undefined;
    Control?: DeinterlacerControl | undefined;
    Mode?: DeinterlacerMode | undefined;
}
export type DolbyVisionCompatibility = "DUPLICATE_STREAM" | "SUPPLEMENTAL_CODECS" | (string & {});
export interface DolbyVisionLevel6Metadata {
    MaxCll?: number | undefined;
    MaxFall?: number | undefined;
}
export type DolbyVisionLevel6Mode = "PASSTHROUGH" | "RECALCULATE" | "SPECIFY" | (string & {});
export type DolbyVisionMapping = "HDR10_NOMAP" | "HDR10_1000" | (string & {});
export type DolbyVisionProfile = "PROFILE_5" | "PROFILE_8_1" | (string & {});
export interface DolbyVision {
    Compatibility?: DolbyVisionCompatibility | undefined;
    L6Metadata?: DolbyVisionLevel6Metadata | undefined;
    L6Mode?: DolbyVisionLevel6Mode | undefined;
    Mapping?: DolbyVisionMapping | undefined;
    Profile?: DolbyVisionProfile | undefined;
}
export interface DurationControl {
    IntegerDurationMaximumCompressionDenominator?: number | undefined;
    IntegerDurationMaximumCompressionNumerator?: number | undefined;
    IntegerDurationTrimThresholdMilliseconds?: number | undefined;
}
export type __integerMin0Max4000 = number;
export interface Hdr10Plus {
    MasteringMonitorNits?: number | undefined;
    TargetMonitorNits?: number | undefined;
}
export type NoiseReducerFilter = "BILATERAL" | "MEAN" | "GAUSSIAN" | "LANCZOS" | "SHARPEN" | "CONSERVE" | "SPATIAL" | "TEMPORAL" | "PERCEPTUAL" | "NONE" | (string & {});
export type __integerMin0Max3 = number;
export interface NoiseReducerFilterSettings {
    Strength?: number | undefined;
}
export type __integerMinNegative2Max3 = number;
export type __integerMin0Max16 = number;
export interface NoiseReducerSpatialFilterSettings {
    PostFilterSharpenStrength?: number | undefined;
    Speed?: number | undefined;
    Strength?: number | undefined;
}
export type __integerMin0Max4 = number;
export type NoiseFilterPostTemporalSharpening = "DISABLED" | "ENABLED" | "AUTO" | (string & {});
export type NoiseFilterPostTemporalSharpeningStrength = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type __integerMinNegative1Max3 = number;
export interface NoiseReducerTemporalFilterSettings {
    AggressiveMode?: number | undefined;
    PostTemporalSharpening?: NoiseFilterPostTemporalSharpening | undefined;
    PostTemporalSharpeningStrength?: NoiseFilterPostTemporalSharpeningStrength | undefined;
    Speed?: number | undefined;
    Strength?: number | undefined;
}
export interface NoiseReducer {
    Filter?: NoiseReducerFilter | undefined;
    FilterSettings?: NoiseReducerFilterSettings | undefined;
    SpatialFilterSettings?: NoiseReducerSpatialFilterSettings | undefined;
    TemporalFilterSettings?: NoiseReducerTemporalFilterSettings | undefined;
}
export type __stringMin1Max100000 = string;
export type __integerMin0Max4194303 = number;
export type WatermarkingStrength = "LIGHTEST" | "LIGHTER" | "DEFAULT" | "STRONGER" | "STRONGEST" | (string & {});
export interface NexGuardFileMarkerSettings {
    License?: string | undefined;
    Payload?: number | undefined;
    Preset?: string | undefined;
    Strength?: WatermarkingStrength | undefined;
}
export interface PartnerWatermarking {
    NexguardFileMarkerSettings?: NexGuardFileMarkerSettings | undefined;
}
export type __integerMin10Max48 = number;
export type TimecodeBurninPosition = "TOP_CENTER" | "TOP_LEFT" | "TOP_RIGHT" | "MIDDLE_LEFT" | "MIDDLE_CENTER" | "MIDDLE_RIGHT" | "BOTTOM_LEFT" | "BOTTOM_CENTER" | "BOTTOM_RIGHT" | (string & {});
export type __stringPattern = string;
export interface TimecodeBurnin {
    FontSize?: number | undefined;
    Position?: TimecodeBurninPosition | undefined;
    Prefix?: string | undefined;
}
export interface VideoPreprocessor {
    ColorCorrector?: ColorCorrector | undefined;
    Deinterlacer?: Deinterlacer | undefined;
    DolbyVision?: DolbyVision | undefined;
    DurationControl?: DurationControl | undefined;
    Hdr10Plus?: Hdr10Plus | undefined;
    ImageInserter?: ImageInserter | undefined;
    NoiseReducer?: NoiseReducer | undefined;
    PartnerWatermarking?: PartnerWatermarking | undefined;
    TimecodeBurnin?: TimecodeBurnin | undefined;
}
export interface VideoDescription {
    AfdSignaling?: AfdSignaling | undefined;
    AntiAlias?: AntiAlias | undefined;
    ChromaPositionMode?: ChromaPositionMode | undefined;
    CodecSettings?: VideoCodecSettings | undefined;
    ColorMetadata?: ColorMetadata | undefined;
    Crop?: Rectangle | undefined;
    DropFrameTimecode?: DropFrameTimecode | undefined;
    FixedAfd?: number | undefined;
    Height?: number | undefined;
    Position?: Rectangle | undefined;
    RespondToAfd?: RespondToAfd | undefined;
    ScalingBehavior?: ScalingBehavior | undefined;
    Sharpness?: number | undefined;
    TimecodeInsertion?: VideoTimecodeInsertion | undefined;
    TimecodeTrack?: TimecodeTrack | undefined;
    VideoPreprocessors?: VideoPreprocessor | undefined;
    Width?: number | undefined;
}
export interface Output {
    AudioDescriptions?: AudioDescription[] | undefined;
    CaptionDescriptions?: CaptionDescription[] | undefined;
    ContainerSettings?: ContainerSettings | undefined;
    Extension?: string | undefined;
    NameModifier?: string | undefined;
    OutputSettings?: OutputSettings | undefined;
    Preset?: string | undefined;
    VideoDescription?: VideoDescription | undefined;
}
export type __listOfOutput = Output[];
export interface OutputGroup {
    AutomatedEncodingSettings?: AutomatedEncodingSettings | undefined;
    CustomName?: string | undefined;
    Name?: string | undefined;
    OutputGroupSettings?: OutputGroupSettings | undefined;
    Outputs?: Output[] | undefined;
}
export type __listOfOutputGroup = OutputGroup[];
export type TimecodeSource = "EMBEDDED" | "ZEROBASED" | "SPECIFIEDSTART" | (string & {});
export type __stringPattern0940191020191209301 = string;
export interface TimecodeConfig {
    Anchor?: string | undefined;
    Source?: TimecodeSource | undefined;
    Start?: string | undefined;
    TimestampOffset?: string | undefined;
}
export interface Id3Insertion {
    Id3?: string | undefined;
    Timecode?: string | undefined;
}
export type __listOfId3Insertion = Id3Insertion[];
export interface TimedMetadataInsertion {
    Id3Insertions?: Id3Insertion[] | undefined;
}
export interface JobSettings {
    AdAvailOffset?: number | undefined;
    AvailBlanking?: AvailBlanking | undefined;
    ColorConversion3DLUTSettings?: ColorConversion3DLUTSetting[] | undefined;
    Esam?: EsamSettings | undefined;
    ExtendedDataServices?: ExtendedDataServices | undefined;
    FollowSource?: number | undefined;
    Inputs?: Input[] | undefined;
    KantarWatermark?: KantarWatermarkSettings | undefined;
    MotionImageInserter?: MotionImageInserter | undefined;
    MotionImageInserters?: MotionImageInserter[] | undefined;
    NielsenConfiguration?: NielsenConfiguration | undefined;
    NielsenNonLinearWatermark?: NielsenNonLinearWatermarkSettings | undefined;
    OutputGroups?: OutputGroup[] | undefined;
    TimecodeConfig?: TimecodeConfig | undefined;
    TimedMetadataInsertion?: TimedMetadataInsertion | undefined;
}
export type SimulateReservedQueue = "DISABLED" | "ENABLED" | (string & {});
export type StatusUpdateInterval = "SECONDS_10" | "SECONDS_12" | "SECONDS_15" | "SECONDS_20" | "SECONDS_30" | "SECONDS_60" | "SECONDS_120" | "SECONDS_180" | "SECONDS_240" | "SECONDS_300" | "SECONDS_360" | "SECONDS_420" | "SECONDS_480" | "SECONDS_540" | "SECONDS_600" | (string & {});
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface CreateJobRequest {
    AccelerationSettings?: AccelerationSettings | undefined;
    BillingTagsSource?: BillingTagsSource | undefined;
    ClientRequestToken?: string | undefined;
    ElementalInferenceSettings?: ElementalInferenceSettings | undefined;
    HopDestinations?: HopDestination[] | undefined;
    JobEngineVersion?: string | undefined;
    JobTemplate?: string | undefined;
    Priority?: number | undefined;
    Queue?: string | undefined;
    Role?: string | undefined;
    Settings?: JobSettings | undefined;
    SimulateReservedQueue?: SimulateReservedQueue | undefined;
    StatusUpdateInterval?: StatusUpdateInterval | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UserMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AccelerationStatus = "NOT_APPLICABLE" | "IN_PROGRESS" | "ACCELERATED" | "NOT_ACCELERATED" | (string & {});
export type __timestampUnix = Date;
export type JobPhase = "PROBING" | "TRANSCODING" | "UPLOADING" | (string & {});
export type ElementalInferenceFeature = "SMART_CROP" | "SMART_SUBTITLE" | (string & {});
export type __listOfElementalInferenceFeature = ElementalInferenceFeature[];
export type ElementalInferenceFeedManagementState = "CREATED" | "ASSOCIATED" | "PENDING_DELETION" | "DELETED" | (string & {});
export interface ElementalInferenceFeed {
    Arn?: string | undefined;
    FeedManagementState?: ElementalInferenceFeedManagementState | undefined;
}
export type __listOfElementalInferenceFeed = ElementalInferenceFeed[];
export interface ElementalInferenceConfiguration {
    Features?: ElementalInferenceFeature[] | undefined;
    Feeds?: ElementalInferenceFeed[] | undefined;
}
export type __listOf__string = string[];
export interface JobMessages {
    Info?: string[] | undefined;
    Warning?: string[] | undefined;
}
export interface VideoDetail {
    HeightInPx?: number | undefined;
    WidthInPx?: number | undefined;
}
export interface OutputDetail {
    DurationInMs?: number | undefined;
    VideoDetails?: VideoDetail | undefined;
}
export type __listOfOutputDetail = OutputDetail[];
export interface OutputGroupDetail {
    OutputDetails?: OutputDetail[] | undefined;
}
export type __listOfOutputGroupDetail = OutputGroupDetail[];
export interface QueueTransition {
    DestinationQueue?: string | undefined;
    SourceQueue?: string | undefined;
    Timestamp?: Date | undefined;
}
export type __listOfQueueTransition = QueueTransition[];
export type ShareStatus = "NOT_SHARED" | "INITIATED" | "SHARED" | (string & {});
export type JobStatus = "SUBMITTED" | "PROGRESSING" | "COMPLETE" | "CANCELED" | "ERROR" | (string & {});
export interface Timing {
    FinishTime?: Date | undefined;
    StartTime?: Date | undefined;
    SubmitTime?: Date | undefined;
}
export interface WarningGroup {
    Code?: number | undefined;
    Count?: number | undefined;
}
export type __listOfWarningGroup = WarningGroup[];
export interface Job {
    AccelerationSettings?: AccelerationSettings | undefined;
    AccelerationStatus?: AccelerationStatus | undefined;
    Arn?: string | undefined;
    BillingTagsSource?: BillingTagsSource | undefined;
    ClientRequestToken?: string | undefined;
    CreatedAt?: Date | undefined;
    CurrentPhase?: JobPhase | undefined;
    ElementalInferenceConfiguration?: ElementalInferenceConfiguration | undefined;
    ElementalInferenceSettings?: ElementalInferenceSettings | undefined;
    ErrorCode?: number | undefined;
    ErrorMessage?: string | undefined;
    HopDestinations?: HopDestination[] | undefined;
    Id?: string | undefined;
    JobEngineVersionRequested?: string | undefined;
    JobEngineVersionUsed?: string | undefined;
    JobPercentComplete?: number | undefined;
    JobTemplate?: string | undefined;
    LastShareDetails?: string | undefined;
    Messages?: JobMessages | undefined;
    OutputGroupDetails?: OutputGroupDetail[] | undefined;
    Priority?: number | undefined;
    Queue?: string | undefined;
    QueueTransitions?: QueueTransition[] | undefined;
    RetryCount?: number | undefined;
    Role?: string | undefined;
    Settings?: JobSettings | undefined;
    ShareStatus?: ShareStatus | undefined;
    SimulateReservedQueue?: SimulateReservedQueue | undefined;
    Status?: JobStatus | undefined;
    StatusUpdateInterval?: StatusUpdateInterval | undefined;
    Timing?: Timing | undefined;
    UserMetadata?: {
        [key: string]: string | undefined;
    } | undefined;
    Warnings?: WarningGroup[] | undefined;
}
export interface CreateJobResponse {
    Job?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    }) | undefined;
}
export interface InputTemplate {
    AdvancedInputFilter?: AdvancedInputFilter | undefined;
    AdvancedInputFilterSettings?: AdvancedInputFilterSettings | undefined;
    AudioSelectorGroups?: {
        [key: string]: AudioSelectorGroup | undefined;
    } | undefined;
    AudioSelectors?: {
        [key: string]: AudioSelector | undefined;
    } | undefined;
    CaptionSelectors?: {
        [key: string]: CaptionSelector | undefined;
    } | undefined;
    Crop?: Rectangle | undefined;
    DeblockFilter?: InputDeblockFilter | undefined;
    DenoiseFilter?: InputDenoiseFilter | undefined;
    DolbyVisionMetadataXml?: string | undefined;
    DynamicAudioSelectors?: {
        [key: string]: DynamicAudioSelector | undefined;
    } | undefined;
    FilterEnable?: InputFilterEnable | undefined;
    FilterStrength?: number | undefined;
    ImageInserter?: ImageInserter | undefined;
    InputClippings?: InputClipping[] | undefined;
    InputScanType?: InputScanType | undefined;
    MultiViewSettings?: MultiViewSettings[] | undefined;
    Position?: Rectangle | undefined;
    ProgramNumber?: number | undefined;
    PsiControl?: InputPsiControl | undefined;
    TimecodeSource?: InputTimecodeSource | undefined;
    TimecodeStart?: string | undefined;
    VideoOverlays?: VideoOverlay[] | undefined;
    VideoSelector?: VideoSelector | undefined;
}
export type __listOfInputTemplate = InputTemplate[];
export interface JobTemplateSettings {
    AdAvailOffset?: number | undefined;
    AvailBlanking?: AvailBlanking | undefined;
    ColorConversion3DLUTSettings?: ColorConversion3DLUTSetting[] | undefined;
    Esam?: EsamSettings | undefined;
    ExtendedDataServices?: ExtendedDataServices | undefined;
    FollowSource?: number | undefined;
    Inputs?: InputTemplate[] | undefined;
    KantarWatermark?: KantarWatermarkSettings | undefined;
    MotionImageInserter?: MotionImageInserter | undefined;
    MotionImageInserters?: MotionImageInserter[] | undefined;
    NielsenConfiguration?: NielsenConfiguration | undefined;
    NielsenNonLinearWatermark?: NielsenNonLinearWatermarkSettings | undefined;
    OutputGroups?: OutputGroup[] | undefined;
    TimecodeConfig?: TimecodeConfig | undefined;
    TimedMetadataInsertion?: TimedMetadataInsertion | undefined;
}
export interface CreateJobTemplateRequest {
    AccelerationSettings?: AccelerationSettings | undefined;
    Category?: string | undefined;
    Description?: string | undefined;
    ElementalInferenceSettings?: ElementalInferenceSettings | undefined;
    HopDestinations?: HopDestination[] | undefined;
    Name?: string | undefined;
    Priority?: number | undefined;
    Queue?: string | undefined;
    Settings?: JobTemplateSettings | undefined;
    StatusUpdateInterval?: StatusUpdateInterval | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Type = "SYSTEM" | "CUSTOM" | (string & {});
export interface JobTemplate {
    AccelerationSettings?: AccelerationSettings | undefined;
    Arn?: string | undefined;
    Category?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    ElementalInferenceSettings?: ElementalInferenceSettings | undefined;
    HopDestinations?: HopDestination[] | undefined;
    LastUpdated?: Date | undefined;
    Name?: string | undefined;
    Priority?: number | undefined;
    Queue?: string | undefined;
    Settings?: JobTemplateSettings | undefined;
    StatusUpdateInterval?: StatusUpdateInterval | undefined;
    Type?: Type | undefined;
}
export interface CreateJobTemplateResponse {
    JobTemplate?: (JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    }) | undefined;
}
export interface CaptionDescriptionPreset {
    CustomLanguageCode?: string | undefined;
    DestinationSettings?: CaptionDestinationSettings | undefined;
    LanguageCode?: LanguageCode | undefined;
    LanguageDescription?: string | undefined;
}
export type __listOfCaptionDescriptionPreset = CaptionDescriptionPreset[];
export interface PresetSettings {
    AudioDescriptions?: AudioDescription[] | undefined;
    CaptionDescriptions?: CaptionDescriptionPreset[] | undefined;
    ContainerSettings?: ContainerSettings | undefined;
    VideoDescription?: VideoDescription | undefined;
}
export interface CreatePresetRequest {
    Category?: string | undefined;
    Description?: string | undefined;
    Name?: string | undefined;
    Settings?: PresetSettings | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface Preset {
    Arn?: string | undefined;
    Category?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    LastUpdated?: Date | undefined;
    Name?: string | undefined;
    Settings?: PresetSettings | undefined;
    Type?: Type | undefined;
}
export interface CreatePresetResponse {
    Preset?: (Preset & {
        Name: string;
        Settings: PresetSettings;
    }) | undefined;
}
export type __integerMin0 = number;
export type PricingPlan = "ON_DEMAND" | "RESERVED" | (string & {});
export type Commitment = "ONE_YEAR" | (string & {});
export type RenewalType = "AUTO_RENEW" | "EXPIRE" | (string & {});
export interface ReservationPlanSettings {
    Commitment?: Commitment | undefined;
    RenewalType?: RenewalType | undefined;
    ReservedSlots?: number | undefined;
}
export type QueueStatus = "ACTIVE" | "PAUSED" | (string & {});
export interface CreateQueueRequest {
    ConcurrentJobs?: number | undefined;
    Description?: string | undefined;
    MaximumConcurrentFeeds?: number | undefined;
    Name?: string | undefined;
    PricingPlan?: PricingPlan | undefined;
    ReservationPlanSettings?: ReservationPlanSettings | undefined;
    Status?: QueueStatus | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ReservationPlanStatus = "ACTIVE" | "EXPIRED" | (string & {});
export interface ReservationPlan {
    Commitment?: Commitment | undefined;
    ExpiresAt?: Date | undefined;
    PurchasedAt?: Date | undefined;
    RenewalType?: RenewalType | undefined;
    ReservedSlots?: number | undefined;
    Status?: ReservationPlanStatus | undefined;
}
export interface ServiceOverride {
    Message?: string | undefined;
    Name?: string | undefined;
    OverrideValue?: string | undefined;
    Value?: string | undefined;
}
export type __listOfServiceOverride = ServiceOverride[];
export interface Queue {
    Arn?: string | undefined;
    ConcurrentJobs?: number | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    LastUpdated?: Date | undefined;
    MaximumConcurrentFeeds?: number | undefined;
    Name?: string | undefined;
    PricingPlan?: PricingPlan | undefined;
    ProgressingJobsCount?: number | undefined;
    ReservationPlan?: ReservationPlan | undefined;
    ServiceOverrides?: ServiceOverride[] | undefined;
    Status?: QueueStatus | undefined;
    SubmittedJobsCount?: number | undefined;
    Type?: Type | undefined;
}
export interface CreateQueueResponse {
    Queue?: (Queue & {
        Name: string;
    }) | undefined;
}
export interface CreateResourceShareRequest {
    JobId?: string | undefined;
    SupportCaseId?: string | undefined;
}
export interface CreateResourceShareResponse {
}
export interface DeleteJobTemplateRequest {
    Name: string;
}
export interface DeleteJobTemplateResponse {
}
export interface DeletePolicyRequest {
}
export interface DeletePolicyResponse {
}
export interface DeletePresetRequest {
    Name: string;
}
export interface DeletePresetResponse {
}
export interface DeleteQueueRequest {
    Name: string;
}
export interface DeleteQueueResponse {
}
export type DescribeEndpointsMode = "DEFAULT" | "GET_ONLY" | (string & {});
export interface DescribeEndpointsRequest {
    MaxResults?: number | undefined;
    Mode?: DescribeEndpointsMode | undefined;
    NextToken?: string | undefined;
}
export interface Endpoint {
    Url?: string | undefined;
}
export type __listOfEndpoint = Endpoint[];
export interface DescribeEndpointsResponse {
    Endpoints?: Endpoint[] | undefined;
    NextToken?: string | undefined;
}
export interface DisassociateCertificateRequest {
    Arn: string;
}
export interface DisassociateCertificateResponse {
}
export interface GetJobRequest {
    Id: string;
}
export interface GetJobResponse {
    Job?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    }) | undefined;
}
export interface GetJobsQueryResultsRequest {
    Id: string;
}
export type __listOfJob = Job[];
export type JobsQueryStatus = "SUBMITTED" | "PROGRESSING" | "COMPLETE" | "ERROR" | (string & {});
export interface GetJobsQueryResultsResponse {
    Jobs?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
    Status?: JobsQueryStatus | undefined;
}
export interface GetJobTemplateRequest {
    Name: string;
}
export interface GetJobTemplateResponse {
    JobTemplate?: (JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    }) | undefined;
}
export interface GetPolicyRequest {
}
export type InputPolicy = "ALLOWED" | "DISALLOWED" | (string & {});
export interface Policy {
    HttpInputs?: InputPolicy | undefined;
    HttpsInputs?: InputPolicy | undefined;
    S3Inputs?: InputPolicy | undefined;
}
export interface GetPolicyResponse {
    Policy?: Policy | undefined;
}
export interface GetPresetRequest {
    Name: string;
}
export interface GetPresetResponse {
    Preset?: (Preset & {
        Name: string;
        Settings: PresetSettings;
    }) | undefined;
}
export interface GetQueueRequest {
    Name: string;
}
export interface GetQueueResponse {
    Queue?: (Queue & {
        Name: string;
    }) | undefined;
}
export type __integerMin1Max20 = number;
export type Order = "ASCENDING" | "DESCENDING" | (string & {});
export interface ListJobsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Order?: Order | undefined;
    Queue?: string | undefined;
    Status?: JobStatus | undefined;
}
export interface ListJobsResponse {
    Jobs?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type JobTemplateListBy = "NAME" | "CREATION_DATE" | "SYSTEM" | (string & {});
export interface ListJobTemplatesRequest {
    Category?: string | undefined;
    ListBy?: JobTemplateListBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Order?: Order | undefined;
}
export type __listOfJobTemplate = JobTemplate[];
export interface ListJobTemplatesResponse {
    JobTemplates?: (JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type PresetListBy = "NAME" | "CREATION_DATE" | "SYSTEM" | (string & {});
export interface ListPresetsRequest {
    Category?: string | undefined;
    ListBy?: PresetListBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Order?: Order | undefined;
}
export type __listOfPreset = Preset[];
export interface ListPresetsResponse {
    NextToken?: string | undefined;
    Presets?: (Preset & {
        Name: string;
        Settings: PresetSettings;
    })[] | undefined;
}
export type QueueListBy = "NAME" | "CREATION_DATE" | (string & {});
export interface ListQueuesRequest {
    ListBy?: QueueListBy | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Order?: Order | undefined;
}
export type __listOfQueue = Queue[];
export interface ListQueuesResponse {
    NextToken?: string | undefined;
    Queues?: (Queue & {
        Name: string;
    })[] | undefined;
    TotalConcurrentJobs?: number | undefined;
    UnallocatedConcurrentJobs?: number | undefined;
}
export interface ListTagsForResourceRequest {
    Arn: string;
}
export interface ResourceTags {
    Arn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTagsForResourceResponse {
    ResourceTags?: ResourceTags | undefined;
}
export interface ListVersionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface JobEngineVersion {
    ExpirationDate?: Date | undefined;
    Version?: string | undefined;
}
export type __listOfJobEngineVersion = JobEngineVersion[];
export interface ListVersionsResponse {
    NextToken?: string | undefined;
    Versions?: JobEngineVersion[] | undefined;
}
export interface ProbeInputFile {
    FileUrl?: string | undefined;
}
export type __listOfProbeInputFile = ProbeInputFile[];
export interface ProbeRequest {
    InputFiles?: ProbeInputFile[] | undefined;
}
export type Format = "mp4" | "quicktime" | "matroska" | "webm" | "mxf" | "wave" | "avi" | "mpegts" | "mpegps" | "mp3" | "flac" | "asf" | "ogg" | "three_gp" | "three_g2" | "aac" | "ac3" | "eac3" | (string & {});
export interface FrameRate {
    Denominator?: number | undefined;
    Numerator?: number | undefined;
}
export interface AudioProperties {
    BitDepth?: number | undefined;
    BitRate?: number | undefined;
    ChannelLayout?: string | undefined;
    Channels?: number | undefined;
    FrameRate?: FrameRate | undefined;
    LanguageCode?: string | undefined;
    ObjectCount?: number | undefined;
    SampleRate?: number | undefined;
}
export type Codec = "UNKNOWN" | "AAC" | "AC3" | "AMR" | "EAC3" | "FLAC" | "MP2" | "MP3" | "OPUS" | "PCM" | "VORBIS" | "WMA" | "WMA2" | "WMAPRO" | "AV1" | "AVC" | "DV" | "H263" | "HEVC" | "JPEG2000" | "MJPEG" | "MPEG1" | "MP4V" | "MPEG2" | "PRORES" | "QTRLE" | "THEORA" | "UNCOMPRESSED" | "VC1" | "VC3" | "VFW" | "VP8" | "VP9" | "C608" | "C708" | "WEBVTT" | (string & {});
export interface DataProperties {
    LanguageCode?: string | undefined;
}
export type TrackType = "video" | "audio" | "data" | (string & {});
export type ColorPrimaries = "ITU_709" | "UNSPECIFIED" | "RESERVED" | "ITU_470M" | "ITU_470BG" | "SMPTE_170M" | "SMPTE_240M" | "GENERIC_FILM" | "ITU_2020" | "SMPTE_428_1" | "SMPTE_431_2" | "SMPTE_EG_432_1" | "IPT" | "SMPTE_2067XYZ" | "EBU_3213_E" | "LAST" | (string & {});
export interface ContentLightLevel {
    MaxContentLightLevel?: number | undefined;
    MaxFrameAverageLightLevel?: number | undefined;
}
export interface AspectRatio {
    Denominator?: number | undefined;
    Numerator?: number | undefined;
}
export type DolbyVisionPresence = "PRESENT" | "ABSENT" | (string & {});
export interface DolbyVisionMetadata {
    BaseLayer?: DolbyVisionPresence | undefined;
    EnhancementLayer?: DolbyVisionPresence | undefined;
    Level?: number | undefined;
    Profile?: number | undefined;
    Rpu?: DolbyVisionPresence | undefined;
}
export type Hdr10PlusPresence = "PRESENT" | (string & {});
export type MatrixCoefficients = "RGB" | "ITU_709" | "UNSPECIFIED" | "RESERVED" | "FCC" | "ITU_470BG" | "SMPTE_170M" | "SMPTE_240M" | "YCgCo" | "ITU_2020_NCL" | "ITU_2020_CL" | "SMPTE_2085" | "CD_NCL" | "CD_CL" | "ITU_2100ICtCp" | "IPT" | "EBU3213" | "LAST" | (string & {});
export type TransferCharacteristics = "ITU_709" | "UNSPECIFIED" | "RESERVED" | "ITU_470M" | "ITU_470BG" | "SMPTE_170M" | "SMPTE_240M" | "LINEAR" | "LOG10_2" | "LOC10_2_5" | "IEC_61966_2_4" | "ITU_1361" | "IEC_61966_2_1" | "ITU_2020_10bit" | "ITU_2020_12bit" | "SMPTE_2084" | "SMPTE_428_1" | "ARIB_B67" | "LAST" | (string & {});
export interface CodecMetadata {
    BitDepth?: number | undefined;
    ChromaSubsampling?: string | undefined;
    CodedFrameRate?: FrameRate | undefined;
    ColorPrimaries?: ColorPrimaries | undefined;
    ContentLightLevel?: ContentLightLevel | undefined;
    DisplayAspectRatio?: AspectRatio | undefined;
    DolbyVision?: DolbyVisionMetadata | undefined;
    FieldOrder?: string | undefined;
    Hdr10PlusPresence?: Hdr10PlusPresence | undefined;
    Height?: number | undefined;
    Level?: string | undefined;
    MatrixCoefficients?: MatrixCoefficients | undefined;
    Profile?: string | undefined;
    Rotation?: number | undefined;
    SampleAspectRatio?: AspectRatio | undefined;
    ScanType?: string | undefined;
    TransferCharacteristics?: TransferCharacteristics | undefined;
    Width?: number | undefined;
}
export interface MasteringDisplayColorVolume {
    BluePrimaryX?: number | undefined;
    BluePrimaryY?: number | undefined;
    GreenPrimaryX?: number | undefined;
    GreenPrimaryY?: number | undefined;
    MaxLuminance?: number | undefined;
    MinLuminance?: number | undefined;
    RedPrimaryX?: number | undefined;
    RedPrimaryY?: number | undefined;
    WhitePointX?: number | undefined;
    WhitePointY?: number | undefined;
}
export interface HdrMetadata {
    ContentLightLevel?: ContentLightLevel | undefined;
    MasteringDisplayColorVolume?: MasteringDisplayColorVolume | undefined;
}
export interface VideoProperties {
    BitDepth?: number | undefined;
    BitRate?: number | undefined;
    CodecMetadata?: CodecMetadata | undefined;
    ColorPrimaries?: ColorPrimaries | undefined;
    DisplayAspectRatio?: AspectRatio | undefined;
    FrameRate?: FrameRate | undefined;
    HdrMetadata?: HdrMetadata | undefined;
    Height?: number | undefined;
    MatrixCoefficients?: MatrixCoefficients | undefined;
    Rotation?: number | undefined;
    SampleAspectRatio?: AspectRatio | undefined;
    TransferCharacteristics?: TransferCharacteristics | undefined;
    Width?: number | undefined;
}
export interface Track {
    AudioProperties?: AudioProperties | undefined;
    Codec?: Codec | undefined;
    DataProperties?: DataProperties | undefined;
    Duration?: number | undefined;
    Index?: number | undefined;
    TrackType?: TrackType | undefined;
    VideoProperties?: VideoProperties | undefined;
}
export type __listOfTrack = Track[];
export interface Container {
    BitRate?: number | undefined;
    Duration?: number | undefined;
    Format?: Format | undefined;
    StartTimecode?: string | undefined;
    Tracks?: Track[] | undefined;
}
export interface Metadata {
    ETag?: string | undefined;
    FileSize?: number | undefined;
    LastModified?: Date | undefined;
    MimeType?: string | undefined;
}
export type __listOf__integer = number[];
export interface TrackMapping {
    AudioTrackIndexes?: number[] | undefined;
    DataTrackIndexes?: number[] | undefined;
    VideoTrackIndexes?: number[] | undefined;
}
export type __listOfTrackMapping = TrackMapping[];
export interface ProbeResult {
    Container?: Container | undefined;
    Metadata?: Metadata | undefined;
    TrackMappings?: TrackMapping[] | undefined;
}
export type __listOfProbeResult = ProbeResult[];
export interface ProbeResponse {
    ProbeResults?: ProbeResult[] | undefined;
}
export interface PutPolicyRequest {
    Policy?: Policy | undefined;
}
export interface PutPolicyResponse {
    Policy?: Policy | undefined;
}
export interface SearchJobsRequest {
    InputFile?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Order?: Order | undefined;
    Queue?: string | undefined;
    Status?: JobStatus | undefined;
}
export interface SearchJobsResponse {
    Jobs?: (Job & {
        Role: string;
        Settings: JobSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
        Warnings: (WarningGroup & {
            Code: number;
            Count: number;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type JobsQueryFilterKey = "queue" | "status" | "fileInput" | "jobEngineVersionRequested" | "jobEngineVersionUsed" | "audioCodec" | "videoCodec" | "errorCode" | (string & {});
export type __stringMax100 = string;
export type __listOf__stringMax100 = string[];
export interface JobsQueryFilter {
    Key?: JobsQueryFilterKey | undefined;
    Values?: string[] | undefined;
}
export type __listOfJobsQueryFilter = JobsQueryFilter[];
export interface StartJobsQueryRequest {
    FilterList?: JobsQueryFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Order?: Order | undefined;
}
export interface StartJobsQueryResponse {
    Id?: string | undefined;
}
export interface TagResourceRequest {
    Arn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    Arn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateJobTemplateRequest {
    AccelerationSettings?: AccelerationSettings | undefined;
    Category?: string | undefined;
    Description?: string | undefined;
    ElementalInferenceSettings?: ElementalInferenceSettings | undefined;
    HopDestinations?: HopDestination[] | undefined;
    Name: string;
    Priority?: number | undefined;
    Queue?: string | undefined;
    Settings?: JobTemplateSettings | undefined;
    StatusUpdateInterval?: StatusUpdateInterval | undefined;
}
export interface UpdateJobTemplateResponse {
    JobTemplate?: (JobTemplate & {
        Name: string;
        Settings: JobTemplateSettings;
        AccelerationSettings: AccelerationSettings & {
            Mode: AccelerationMode;
        };
    }) | undefined;
}
export interface UpdatePresetRequest {
    Category?: string | undefined;
    Description?: string | undefined;
    Name: string;
    Settings?: PresetSettings | undefined;
}
export interface UpdatePresetResponse {
    Preset?: (Preset & {
        Name: string;
        Settings: PresetSettings;
    }) | undefined;
}
export interface UpdateQueueRequest {
    ConcurrentJobs?: number | undefined;
    Description?: string | undefined;
    MaximumConcurrentFeeds?: number | undefined;
    Name: string;
    ReservationPlanSettings?: ReservationPlanSettings | undefined;
    Status?: QueueStatus | undefined;
}
export interface UpdateQueueResponse {
    Queue?: (Queue & {
        Name: string;
    }) | undefined;
}
export type AssociateCertificateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Associates an AWS Certificate Manager (ACM) Amazon Resource Name (ARN) with AWS Elemental MediaConvert.
 */
export declare const associateCertificate: API.OperationMethod<AssociateCertificateRequest & RegionInput, AssociateCertificateResponse, AssociateCertificateError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently cancel a job. Once you have canceled a job, you can't start it again.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest & RegionInput, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new transcoding job. For information about jobs and job settings, see the User Guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const createJob: API.OperationMethod<CreateJobRequest & RegionInput, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new job template. For information about job templates see the User Guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const createJobTemplate: API.OperationMethod<CreateJobTemplateRequest & RegionInput, CreateJobTemplateResponse, CreateJobTemplateError, Credentials | HttpClient.HttpClient>;
export type CreatePresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new preset. For information about job templates see the User Guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const createPreset: API.OperationMethod<CreatePresetRequest & RegionInput, CreatePresetResponse, CreatePresetError, Credentials | HttpClient.HttpClient>;
export type CreateQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new transcoding queue. For information about queues, see Working With Queues in the User Guide at https://docs.aws.amazon.com/mediaconvert/latest/ug/working-with-queues.html
 */
export declare const createQueue: API.OperationMethod<CreateQueueRequest & RegionInput, CreateQueueResponse, CreateQueueError, Credentials | HttpClient.HttpClient>;
export type CreateResourceShareError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new resource share request for MediaConvert resources with AWS Support.
 */
export declare const createResourceShare: API.OperationMethod<CreateResourceShareRequest & RegionInput, CreateResourceShareResponse, CreateResourceShareError, Credentials | HttpClient.HttpClient>;
export type DeleteJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a job template you have created.
 */
export declare const deleteJobTemplate: API.OperationMethod<DeleteJobTemplateRequest & RegionInput, DeleteJobTemplateResponse, DeleteJobTemplateError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a policy that you created.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest & RegionInput, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a preset you have created.
 */
export declare const deletePreset: API.OperationMethod<DeletePresetRequest & RegionInput, DeletePresetResponse, DeletePresetError, Credentials | HttpClient.HttpClient>;
export type DeleteQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Permanently delete a queue you have created.
 */
export declare const deleteQueue: API.OperationMethod<DeleteQueueRequest & RegionInput, DeleteQueueResponse, DeleteQueueError, Credentials | HttpClient.HttpClient>;
export type DescribeEndpointsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Send a request with an empty body to the regional API endpoint to get your account API endpoint. Note that DescribeEndpoints is no longer required. We recommend that you send your requests directly to the regional endpoint instead.
 */
export declare const describeEndpoints: API.PaginatedOperationMethod<DescribeEndpointsRequest & RegionInput, DescribeEndpointsResponse, DescribeEndpointsError, Credentials | HttpClient.HttpClient, Endpoint>;
export type DisassociateCertificateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Removes an association between the Amazon Resource Name (ARN) of an AWS Certificate Manager (ACM) certificate and an AWS Elemental MediaConvert resource.
 */
export declare const disassociateCertificate: API.OperationMethod<DisassociateCertificateRequest & RegionInput, DisassociateCertificateResponse, DisassociateCertificateError, Credentials | HttpClient.HttpClient>;
export type GetJobError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific transcoding job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest & RegionInput, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetJobsQueryResultsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your most recent jobs matched by a jobs query.
 */
export declare const getJobsQueryResults: API.OperationMethod<GetJobsQueryResultsRequest & RegionInput, GetJobsQueryResultsResponse, GetJobsQueryResultsError, Credentials | HttpClient.HttpClient>;
export type GetJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific job template.
 */
export declare const getJobTemplate: API.OperationMethod<GetJobTemplateRequest & RegionInput, GetJobTemplateResponse, GetJobTemplateError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for your policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest & RegionInput, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific preset.
 */
export declare const getPreset: API.OperationMethod<GetPresetRequest & RegionInput, GetPresetResponse, GetPresetError, Credentials | HttpClient.HttpClient>;
export type GetQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the JSON for a specific queue.
 */
export declare const getQueue: API.OperationMethod<GetQueueRequest & RegionInput, GetQueueResponse, GetQueueError, Credentials | HttpClient.HttpClient>;
export type ListJobsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your most recently created jobs. This array includes in-process, completed, and errored jobs. This will return the jobs themselves, not just a list of the jobs. To retrieve the twenty next most recent jobs, use the nextToken string returned with the array.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, Job>;
export type ListJobTemplatesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your job templates. This will return the templates themselves, not just a list of them. To retrieve the next twenty templates, use the nextToken string returned with the array
 */
export declare const listJobTemplates: API.PaginatedOperationMethod<ListJobTemplatesRequest & RegionInput, ListJobTemplatesResponse, ListJobTemplatesError, Credentials | HttpClient.HttpClient, JobTemplate>;
export type ListPresetsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your presets. This will return the presets themselves, not just a list of them. To retrieve the next twenty presets, use the nextToken string returned with the array.
 */
export declare const listPresets: API.PaginatedOperationMethod<ListPresetsRequest & RegionInput, ListPresetsResponse, ListPresetsError, Credentials | HttpClient.HttpClient, Preset>;
export type ListQueuesError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of up to twenty of your queues. This will return the queues themselves, not just a list of them. To retrieve the next twenty queues, use the nextToken string returned with the array.
 */
export declare const listQueues: API.PaginatedOperationMethod<ListQueuesRequest & RegionInput, ListQueuesResponse, ListQueuesError, Credentials | HttpClient.HttpClient, Queue>;
export type ListTagsForResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the tags for a MediaConvert resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVersionsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array of all available Job engine versions and the date they expire.
 */
export declare const listVersions: API.PaginatedOperationMethod<ListVersionsRequest & RegionInput, ListVersionsResponse, ListVersionsError, Credentials | HttpClient.HttpClient, JobEngineVersion>;
export type ProbeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | UnprocessableEntityException | CommonErrors;
/**
 * Use Probe to obtain detailed information about your input media files. Probe returns a JSON that includes container, codec, frame rate, resolution, track count, audio layout, captions, and more. You can use this information to learn more about your media files, or to help make decisions while automating your transcoding workflow. Probe supports the following input container formats: MP4, QuickTime (MOV), 3GP, 3G2, Matroska (MKV), WebM, MXF, MPEG-TS, MPEG-PS, AVI, WAV, MP3, FLAC, Ogg, and ASF (Windows Media / WMA). The fields that Probe returns vary by container and codec. A field isn't returned when the source doesn't contain it, or when it isn't available for that container and codec.
 */
export declare const probe: API.OperationMethod<ProbeRequest & RegionInput, ProbeResponse, ProbeError, Credentials | HttpClient.HttpClient>;
export type PutPolicyError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create or change your policy. For more information about policies, see the user guide at http://docs.aws.amazon.com/mediaconvert/latest/ug/what-is.html
 */
export declare const putPolicy: API.OperationMethod<PutPolicyRequest & RegionInput, PutPolicyResponse, PutPolicyError, Credentials | HttpClient.HttpClient>;
export type SearchJobsError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a JSON array that includes job details for up to twenty of your most recent jobs. Optionally filter results further according to input file, queue, or status. To retrieve the twenty next most recent jobs, use the nextToken string returned with the array.
 */
export declare const searchJobs: API.PaginatedOperationMethod<SearchJobsRequest & RegionInput, SearchJobsResponse, SearchJobsError, Credentials | HttpClient.HttpClient, Job>;
export type StartJobsQueryError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Start an asynchronous jobs query using the provided filters. To receive the list of jobs that match your query, call the GetJobsQueryResults API using the query ID returned by this API.
 */
export declare const startJobsQuery: API.OperationMethod<StartJobsQueryRequest & RegionInput, StartJobsQueryResponse, StartJobsQueryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Add tags to a MediaConvert queue, preset, job, or job template. For information about tagging, see the User Guide at https://docs.aws.amazon.com/mediaconvert/latest/ug/tagging-mediaconvert-resources.html.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Remove tags from a MediaConvert queue, preset, job, or job template. For information about tagging, see the User Guide at https://docs.aws.amazon.com/mediaconvert/latest/ug/tagging-mediaconvert-resources.html.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateJobTemplateError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Modify one of your existing job templates.
 */
export declare const updateJobTemplate: API.OperationMethod<UpdateJobTemplateRequest & RegionInput, UpdateJobTemplateResponse, UpdateJobTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdatePresetError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Modify one of your existing presets.
 */
export declare const updatePreset: API.OperationMethod<UpdatePresetRequest & RegionInput, UpdatePresetResponse, UpdatePresetError, Credentials | HttpClient.HttpClient>;
export type UpdateQueueError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceQuotaExceededException | TooManyRequestsException | CommonErrors;
/**
 * Modify one of your existing queues.
 */
export declare const updateQueue: API.OperationMethod<UpdateQueueRequest & RegionInput, UpdateQueueResponse, UpdateQueueError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mediaconvert.d.ts.map