import * as Effect from "effect/Effect";
import * as Compare from "./Compare.ts";
import type { Term } from "./Smt.ts";
import type { Eval, Run, Site, V } from "./Value.ts";
import * as Value from "./Value.ts";
/** What the library models need from the interpreter. */
export interface Host {
    readonly current: {
        run: Run;
    };
    /** Take one side of a condition of the inputs: only a side some inputs reach. */
    readonly branch: (condition: string) => Eval<boolean>;
    readonly call: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<V>;
    /** What `yield*` on the value gives. */
    readonly settle: (value: V, site: Site) => Eval<V>;
    /** Whether a value is truthy on this path. */
    readonly decide: (value: V, site: Site) => Eval<boolean>;
    /** Whether a value is truthy, known or as a formula: the path is not split. */
    readonly truth: (value: V, site: Site) => Eval<boolean | string>;
    /** Whether two values are `===`, as a value: known, or a condition of the inputs. */
    readonly equal: (a: V, b: V, site: Site) => Eval<V>;
    /** `a + b` and the like, and `a < b` and the like, as the code's own operators give them. */
    readonly arithmetic: (operator: string, a: V, b: V, site: Site) => Eval<V>;
    /** A property of a value, as the code reads one. */
    readonly member: (value: V, key: string, site: Site) => Eval<V>;
    /** What `typeof` gives, for the values it is known of. */
    readonly kind: (value: V) => string | undefined;
    /** A list with its items, when the value is one. */
    readonly force: (value: V) => V;
    /** An array's method that takes a function, such as `map`. */
    readonly array: (name: string, items: ReadonlyArray<V>, fn: V, initial: V | undefined, site: Site) => Eval<V>;
    /** The request contexts provided around the code being run, by tag. */
    readonly provided: Map<unknown, V>;
    /** The time the command being decided is handled at: none outside `decide`. */
    readonly now: () => V | undefined;
    /** Models a caller adds, by `module:path`. They come before the prover's own. */
    readonly extra: ReadonlyMap<string, Model>;
}
/** What a library function does to symbolic values. */
export type Model = (args: ReadonlyArray<V>, site: Site) => Eval<V>;
/** The models of one part of the library, by `module:path`. */
export type Models = Readonly<Record<string, Model>>;
export declare const native: (name: string, call: Model) => V;
export declare const effect: (run: Eval<V>) => V;
export declare const done: V;
/** An effect that does what `run` gives, each time it is run. */
export declare const lazy: (run: () => Eval<V>) => V;
export declare const arr: (items: ReadonlyArray<V>) => V;
export declare const wrongArguments: (site: Site, name: string) => Effect.Effect<never, Value.NotTranslated, never>;
export declare const str: (v: V | undefined) => string | undefined;
/** Whether a value is something the code can call. */
export declare const callable: (v: V | undefined) => v is V;
/**
 * A function written both ways: with what it works on first (`f(self, x)`),
 * or without it, to be given it by `pipe` (`f(x)` then `self`).
 */
export declare const dual: (name: string, arity: number, body: Model) => Model;
/**
 * A function written both ways, where the number of arguments does not say
 * which: it is called with what it works on first when `first` takes its
 * first argument.
 */
export declare const dualBy: (name: string, first: (v: V) => boolean, body: Model) => Model;
/**
 * A function of an effect, called with the effect first (`f(effect, x)`) or
 * later through `pipe` (`f(x)` then the effect).
 */
export declare const onEffect: (name: string, extra: number, run: (self: Eval<V>, args: ReadonlyArray<V>, site: Site) => Eval<V>) => Model;
/** An effect that only a failure leaves: a rejection the code can handle, never a defect. */
export declare const onFailure: <A>(self: Eval<A>, handle: (error: V) => Eval<A>) => Eval<A>;
export declare const tagsOf: (v: V | undefined) => ReadonlyArray<string> | undefined;
/** The `_tag` of an object, when the prover sees it. */
export declare const tagOf: (v: V | undefined) => string | undefined;
/** A whole number: one the prover knows, or a formula for one. */
export type Whole = number | Term;
export declare const wholeOf: (v: V | undefined) => Whole | undefined;
export declare const termOf: (n: Whole) => Term;
export declare const valueOfWhole: (n: Whole) => V;
export declare const sum: (a: Whole, b: Whole) => Whole;
export declare const difference: (a: Whole, b: Whole) => Whole;
export declare const product: (a: Whole, b: Whole) => Whole;
declare const ORDER: {
    "<": (a: number, b: number) => boolean;
    "<=": (a: number, b: number) => boolean;
    ">": (a: number, b: number) => boolean;
    ">=": (a: number, b: number) => boolean;
    "=": (a: number, b: number) => boolean;
};
export declare const ordered: (order: keyof typeof ORDER, a: Whole, b: Whole) => V;
/** The smaller of two, or the larger: the first where they are the same, as the library gives. */
export declare const picked: (order: "<=" | ">=", a: Whole, b: Whole) => Whole;
/** A key the code names: one the prover cannot see is not translated. */
export declare const keyed: (name: string, key: V | undefined, site: Site) => Eval<string>;
export declare const keysOf: (name: string, keys: V | undefined, site: Site) => Eval<ReadonlyArray<string>>;
/** A number the code writes, where the prover has to see one: a count, an index. */
export declare const counted: (name: string, n: V | undefined, site: Site) => Eval<number>;
/** A function of an `Option`. */
export declare const onOption: (name: string, arity: number, body: (option: NonNullable<ReturnType<typeof Value.optionOf>>, rest: ReadonlyArray<V>, site: Site, self: V) => Eval<V>) => Model;
/** A function of an object whose keys the prover sees. */
export declare const onRecord: (name: string, arity: number, body: (fields: Readonly<Record<string, V>>, rest: ReadonlyArray<V>, site: Site) => Eval<V>) => Model;
/** The most items of a hash set or a hash map the prover reads in every order. */
export declare const MAX_ORDERED = 4;
/** The helpers that need the interpreter. */
export declare const make: (host: Host) => {
    host: Host;
    order: (name: string, less: (a: V, b: V, site: Site) => Eval<V>) => V;
    lessThan: (by: V | undefined, a: V, b: V, site: Site) => Eval<V>;
    before: (by: V | undefined, a: V, b: V, site: Site) => Eval<boolean>;
    sorted: (items: ReadonlyArray<V>, by: V | undefined, site: Site) => Eval<ReadonlyArray<V>>;
    after: (next: V, value: V, site: Site) => Eval<V>;
    ran: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<V>;
    either: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<V>;
    itemsOf: (v: V | undefined) => ReadonlyArray<V> | undefined;
    onArray: (name: string, arity: number, body: (items: ReadonlyArray<V>, rest: ReadonlyArray<V>, site: Site) => Eval<V>) => Model;
    known: (what: Compare.Known, site: Site, reason: string) => Eval<V>;
    equality: (a: V, b: V, site: Site) => Eval<Compare.Known>;
    equals: (a: V, b: V, site: Site) => Eval<V>;
    holds: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<boolean>;
    truthOf: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<boolean | string>;
    inOrder: (kind: "HashSet" | "HashMap", items: ReadonlyArray<V>, site: Site) => Eval<ReadonlyArray<V>>;
    setItems: (v: V | undefined) => ReadonlyArray<V> | undefined;
    mapEntries: (v: V | undefined) => ReadonlyArray<readonly [V, V]> | undefined;
    iterate: (v: V, site: Site) => Eval<ReadonlyArray<V> | undefined>;
};
export type Kit = ReturnType<typeof make>;
export {};
//# sourceMappingURL=Kit.d.ts.map