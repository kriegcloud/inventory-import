import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import { StateStoreError } from "./State.ts";
/** A logical store name; stores derive physical names from it. */
export declare const storeName: (name: string) => Effect.Effect<string, never, never> | Effect.Effect<never, StateStoreError, never>;
export interface StoreRef {
    readonly backend: string;
    /** The `alchemy state` flags that address this store, e.g. `{ name, domain }`. */
    readonly flags?: Readonly<Record<string, string | undefined>>;
    /** e.g. `Cloudflare State Store 'alchemy-state-store'`. */
    readonly label: string;
    /**
     * Only the stack's config describes this store, e.g. a custom bucket name
     * or a pinned account, so `--backend` and its flags can't address it.
     */
    readonly configured?: boolean;
}
/** Deploy a missing (or half-bootstrapped) store; in CI, only with `--yes`. */
export declare const deployMissing: <A, E, R>(store: StoreRef & {
    readonly incomplete?: boolean;
}, deploy: Effect.Effect<A, E, R>) => Effect.Effect<A, E | Config.ConfigError | StateStoreError, R>;
/**
 * Bring an existing store's settings up to date, e.g. its encryption: done
 * outside CI and, in CI, with `--yes`. Otherwise CI logs a warning and goes
 * on, since the store still works without the change.
 */
export declare const convergeSettings: <A, E, R>(store: StoreRef & {
    readonly problem: string;
}, converge: Effect.Effect<A, E, R>) => Effect.Effect<void, E | Config.ConfigError, R>;
/** Upgrade an outdated store with `--yes` or on confirmation; in CI, only with `--yes`. */
export declare const upgradeOutdated: <A, E, R>(store: StoreRef & {
    readonly observed: number | undefined;
    readonly expected: number;
}, upgrade: Effect.Effect<A, E, R>) => Effect.Effect<A, E | Config.ConfigError | StateStoreError, R>;
//# sourceMappingURL=Provisioning.d.ts.map