import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DependencyException_base: S.TaggedErrorClass<"DependencyException", {
    readonly message: any;
    readonly parameterName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class DependencyException extends /*@__PURE__*/ DependencyException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly parameterName: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
    readonly parameterName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly parameterName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
export type Uuid = string;
export interface CancelContactRequest {
    contactId: string;
}
export type VersionId = number;
export interface ContactIdResponse {
    contactId?: string | undefined;
    versionId?: number | undefined;
}
export type SafeName = string;
export type FrequencyUnits = "GHz" | "MHz" | "kHz" | (string & {});
export interface Frequency {
    value: number;
    units: FrequencyUnits;
}
export type BandwidthUnits = "GHz" | "MHz" | "kHz" | (string & {});
export interface FrequencyBandwidth {
    value: number;
    units: BandwidthUnits;
}
export type Polarization = "RIGHT_HAND" | "LEFT_HAND" | "NONE" | (string & {});
export interface SpectrumConfig {
    centerFrequency: Frequency;
    bandwidth: FrequencyBandwidth;
    polarization?: Polarization | undefined;
}
export interface AntennaDownlinkConfig {
    spectrumConfig: SpectrumConfig;
}
export type Criticality = "REQUIRED" | "PREFERRED" | "REMOVED" | (string & {});
export interface TrackingConfig {
    autotrack: Criticality;
}
export interface DataflowEndpointConfig {
    dataflowEndpointName: string;
    dataflowEndpointRegion?: string | undefined;
}
export type JsonString = string;
export interface DemodulationConfig {
    unvalidatedJSON: string;
}
export interface DecodeConfig {
    unvalidatedJSON: string;
}
export interface AntennaDownlinkDemodDecodeConfig {
    spectrumConfig: SpectrumConfig;
    demodulationConfig: DemodulationConfig;
    decodeConfig: DecodeConfig;
}
export interface UplinkSpectrumConfig {
    centerFrequency: Frequency;
    polarization?: Polarization | undefined;
}
export type EirpUnits = "dBW" | (string & {});
export interface Eirp {
    value: number;
    units: EirpUnits;
}
export interface AntennaUplinkConfig {
    transmitDisabled?: boolean | undefined;
    spectrumConfig: UplinkSpectrumConfig;
    targetEirp: Eirp;
}
export type ConfigArn = string;
export interface UplinkEchoConfig {
    enabled: boolean;
    antennaUplinkConfigArn: string;
}
export type BucketArn = string;
export type RoleArn = string;
export type S3KeyPrefix = string;
export interface S3RecordingConfig {
    bucketArn: string;
    roleArn: string;
    prefix?: string | undefined;
}
export type TelemetrySinkType = "KINESIS_DATA_STREAM" | (string & {});
export type KinesisDataStreamArn = string;
export interface KinesisDataStreamData {
    kinesisRoleArn: string;
    kinesisDataStreamArn: string;
}
export type TelemetrySinkData = {
    kinesisDataStreamData: KinesisDataStreamData;
};
export interface TelemetrySinkConfig {
    telemetrySinkType: TelemetrySinkType;
    telemetrySinkData: TelemetrySinkData;
}
export type ConfigTypeData = {
    antennaDownlinkConfig: AntennaDownlinkConfig;
    trackingConfig?: undefined;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig: TrackingConfig;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig?: undefined;
    dataflowEndpointConfig: DataflowEndpointConfig;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig?: undefined;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig: AntennaDownlinkDemodDecodeConfig;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig?: undefined;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig: AntennaUplinkConfig;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig?: undefined;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig: UplinkEchoConfig;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig?: undefined;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig: S3RecordingConfig;
    telemetrySinkConfig?: undefined;
} | {
    antennaDownlinkConfig?: undefined;
    trackingConfig?: undefined;
    dataflowEndpointConfig?: undefined;
    antennaDownlinkDemodDecodeConfig?: undefined;
    antennaUplinkConfig?: undefined;
    uplinkEchoConfig?: undefined;
    s3RecordingConfig?: undefined;
    telemetrySinkConfig: TelemetrySinkConfig;
};
export type TagsMap = {
    [key: string]: string | undefined;
};
export interface CreateConfigRequest {
    name: string;
    configData: ConfigTypeData;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfigCapabilityType = "antenna-downlink" | "antenna-downlink-demod-decode" | "tracking" | "dataflow-endpoint" | "antenna-uplink" | "uplink-echo" | "s3-recording" | "telemetry-sink" | (string & {});
export interface ConfigIdResponse {
    configId?: string | undefined;
    configType?: ConfigCapabilityType | undefined;
    configArn?: string | undefined;
}
export type SubnetList = string[];
export type SecurityGroupIdList = string[];
export interface SecurityDetails {
    subnetIds: string[];
    securityGroupIds: string[];
    roleArn: string;
}
export interface SocketAddress {
    name: string;
    port: number;
}
export type EndpointStatus = "created" | "creating" | "deleted" | "deleting" | "failed" | (string & {});
export interface DataflowEndpoint {
    name?: string | undefined;
    address?: SocketAddress | undefined;
    status?: EndpointStatus | undefined;
    mtu?: number | undefined;
}
export interface ConnectionDetails {
    socketAddress: SocketAddress;
    mtu?: number | undefined;
}
export type IpV4Address = string;
export interface IntegerRange {
    minimum: number;
    maximum: number;
}
export interface RangedSocketAddress {
    name: string;
    portRange: IntegerRange;
}
export interface RangedConnectionDetails {
    socketAddress: RangedSocketAddress;
    mtu?: number | undefined;
}
export type AgentStatus = "SUCCESS" | "FAILED" | "ACTIVE" | "INACTIVE" | (string & {});
export type AuditResults = "HEALTHY" | "UNHEALTHY" | (string & {});
export interface AwsGroundStationAgentEndpoint {
    name: string;
    egressAddress: ConnectionDetails;
    ingressAddress: RangedConnectionDetails;
    agentStatus?: AgentStatus | undefined;
    auditResults?: AuditResults | undefined;
}
export interface UplinkConnectionDetails {
    ingressAddressAndPort: ConnectionDetails;
    agentIpAndPortAddress: RangedConnectionDetails;
}
export type UplinkDataflowDetails = {
    agentConnectionDetails: UplinkConnectionDetails;
};
export interface UplinkAwsGroundStationAgentEndpointDetails {
    name: string;
    dataflowDetails: UplinkDataflowDetails;
    agentStatus?: AgentStatus | undefined;
    auditResults?: AuditResults | undefined;
}
export interface DownlinkConnectionDetails {
    agentIpAndPortAddress: RangedConnectionDetails;
    egressAddressAndPort: ConnectionDetails;
}
export type DownlinkDataflowDetails = {
    agentConnectionDetails: DownlinkConnectionDetails;
};
export interface DownlinkAwsGroundStationAgentEndpointDetails {
    name: string;
    dataflowDetails: DownlinkDataflowDetails;
    agentStatus?: AgentStatus | undefined;
    auditResults?: AuditResults | undefined;
}
export type CapabilityHealth = "HEALTHY" | "UNHEALTHY" | (string & {});
export type CapabilityHealthReason = "NO_REGISTERED_AGENT" | "INVALID_IP_OWNERSHIP" | "NOT_AUTHORIZED_TO_CREATE_SLR" | "UNVERIFIED_IP_OWNERSHIP" | "INITIALIZING_DATAPLANE" | "DATAPLANE_FAILURE" | "HEALTHY" | (string & {});
export type CapabilityHealthReasonList = CapabilityHealthReason[];
export interface EndpointDetails {
    securityDetails?: SecurityDetails | undefined;
    endpoint?: DataflowEndpoint | undefined;
    awsGroundStationAgentEndpoint?: AwsGroundStationAgentEndpoint | undefined;
    uplinkAwsGroundStationAgentEndpoint?: UplinkAwsGroundStationAgentEndpointDetails | undefined;
    downlinkAwsGroundStationAgentEndpoint?: DownlinkAwsGroundStationAgentEndpointDetails | undefined;
    healthStatus?: CapabilityHealth | undefined;
    healthReasons?: CapabilityHealthReason[] | undefined;
}
export type EndpointDetailsList = EndpointDetails[];
export type DataflowEndpointGroupDurationInSeconds = number;
export interface CreateDataflowEndpointGroupRequest {
    endpointDetails: EndpointDetails[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    contactPrePassDurationSeconds?: number | undefined;
    contactPostPassDurationSeconds?: number | undefined;
}
export interface DataflowEndpointGroupIdResponse {
    dataflowEndpointGroupId?: string | undefined;
}
export interface UplinkAwsGroundStationAgentEndpoint {
    name: string;
    dataflowDetails: UplinkDataflowDetails;
}
export interface DownlinkAwsGroundStationAgentEndpoint {
    name: string;
    dataflowDetails: DownlinkDataflowDetails;
}
export type CreateEndpointDetails = {
    uplinkAwsGroundStationAgentEndpoint: UplinkAwsGroundStationAgentEndpoint;
    downlinkAwsGroundStationAgentEndpoint?: undefined;
} | {
    uplinkAwsGroundStationAgentEndpoint?: undefined;
    downlinkAwsGroundStationAgentEndpoint: DownlinkAwsGroundStationAgentEndpoint;
};
export type CreateEndpointDetailsList = CreateEndpointDetails[];
export interface CreateDataflowEndpointGroupV2Request {
    endpoints: CreateEndpointDetails[];
    contactPrePassDurationSeconds?: number | undefined;
    contactPostPassDurationSeconds?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDataflowEndpointGroupV2Response {
    dataflowEndpointGroupId?: string | undefined;
}
export type CustomerEphemerisPriority = number;
export type KeyArn = string;
export type S3BucketName = string;
export type S3ObjectKey = string;
export type S3VersionId = string;
export interface S3Object {
    bucket?: string | undefined;
    key?: string | undefined;
    version?: string | undefined;
}
export type TleLineOne = string;
export type TleLineTwo = string;
export interface TimeRange {
    startTime: Date;
    endTime: Date;
}
export interface TLEData {
    tleLine1: string;
    tleLine2: string;
    validTimeRange: TimeRange;
}
export type TLEDataList = TLEData[];
export interface TLEEphemeris {
    s3Object?: S3Object | undefined;
    tleData?: TLEData[] | undefined;
}
export type UnboundedString = string;
export interface OEMEphemeris {
    s3Object?: S3Object | undefined;
    oemData?: string | undefined;
}
export type GroundStationName = string;
export type AngleUnits = "DEGREE_ANGLE" | "RADIAN" | (string & {});
export interface ISO8601TimeRange {
    startTime: Date;
    endTime: Date;
}
export interface TimeAzEl {
    dt: number;
    az: number;
    el: number;
}
export type TimeAzElList = TimeAzEl[];
export interface AzElSegment {
    referenceEpoch: Date;
    validTimeRange: ISO8601TimeRange;
    azElList: TimeAzEl[];
}
export type AzElSegmentList = AzElSegment[];
export interface AzElSegments {
    angleUnit: AngleUnits;
    azElSegmentList: AzElSegment[];
}
export type AzElSegmentsData = {
    s3Object: S3Object;
    azElData?: undefined;
} | {
    s3Object?: undefined;
    azElData: AzElSegments;
};
export interface AzElEphemeris {
    groundStation: string;
    data: AzElSegmentsData;
}
export type EphemerisData = {
    tle: TLEEphemeris;
    oem?: undefined;
    azEl?: undefined;
} | {
    tle?: undefined;
    oem: OEMEphemeris;
    azEl?: undefined;
} | {
    tle?: undefined;
    oem?: undefined;
    azEl: AzElEphemeris;
};
export interface CreateEphemerisRequest {
    satelliteId?: string | undefined;
    enabled?: boolean | undefined;
    priority?: number | undefined;
    expirationTime?: Date | undefined;
    name: string;
    kmsKeyArn?: string | undefined;
    ephemeris?: EphemerisData | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EphemerisIdResponse {
    ephemerisId?: string | undefined;
}
export type DurationInSeconds = number;
export type PositiveDurationInSeconds = number;
export type DataflowEdge = string[];
export type DataflowEdgeList = string[][];
export type KeyAliasArn = string;
export type KeyAliasName = string;
export type KmsKey = {
    kmsKeyArn: string;
    kmsAliasArn?: undefined;
    kmsAliasName?: undefined;
} | {
    kmsKeyArn?: undefined;
    kmsAliasArn: string;
    kmsAliasName?: undefined;
} | {
    kmsKeyArn?: undefined;
    kmsAliasArn?: undefined;
    kmsAliasName: string;
};
export interface CreateMissionProfileRequest {
    name: string;
    contactPrePassDurationSeconds?: number | undefined;
    contactPostPassDurationSeconds?: number | undefined;
    minimumViableContactDurationSeconds: number;
    dataflowEdges: string[][];
    trackingConfigArn: string;
    telemetrySinkConfigArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    streamsKmsKey?: KmsKey | undefined;
    streamsKmsRole?: string | undefined;
}
export interface MissionProfileIdResponse {
    missionProfileId?: string | undefined;
}
export interface DeleteConfigRequest {
    configId: string;
    configType: ConfigCapabilityType;
}
export interface DeleteDataflowEndpointGroupRequest {
    dataflowEndpointGroupId: string;
}
export interface DeleteEphemerisRequest {
    ephemerisId: string;
}
export interface DeleteMissionProfileRequest {
    missionProfileId: string;
}
export interface DescribeContactRequest {
    contactId: string;
}
export type MissionProfileArn = string;
export type SatelliteArn = string;
export type ContactStatus = "SCHEDULING" | "FAILED_TO_SCHEDULE" | "SCHEDULED" | "CANCELLED" | "AWS_CANCELLED" | "PREPASS" | "PASS" | "POSTPASS" | "COMPLETED" | "FAILED" | "AVAILABLE" | "CANCELLING" | "AWS_FAILED" | (string & {});
export interface Elevation {
    value: number;
    unit: AngleUnits;
}
export interface AntennaDemodDecodeDetails {
    outputNode?: string | undefined;
}
export interface S3RecordingDetails {
    bucketArn?: string | undefined;
    keyTemplate?: string | undefined;
}
export type ConfigDetails = {
    endpointDetails: EndpointDetails;
    antennaDemodDecodeDetails?: undefined;
    s3RecordingDetails?: undefined;
} | {
    endpointDetails?: undefined;
    antennaDemodDecodeDetails: AntennaDemodDecodeDetails;
    s3RecordingDetails?: undefined;
} | {
    endpointDetails?: undefined;
    antennaDemodDecodeDetails?: undefined;
    s3RecordingDetails: S3RecordingDetails;
};
export interface Source {
    configType?: ConfigCapabilityType | undefined;
    configId?: string | undefined;
    configDetails?: ConfigDetails | undefined;
    dataflowSourceRegion?: string | undefined;
}
export interface Destination {
    configType?: ConfigCapabilityType | undefined;
    configId?: string | undefined;
    configDetails?: ConfigDetails | undefined;
    dataflowDestinationRegion?: string | undefined;
}
export interface DataflowDetail {
    source?: Source | undefined;
    destination?: Destination | undefined;
    errorMessage?: string | undefined;
}
export type DataflowList = DataflowDetail[];
export interface AzElProgramTrackSettings {
    ephemerisId: string;
}
export interface OemProgramTrackSettings {
    ephemerisId: string;
}
export interface TleProgramTrackSettings {
    ephemerisId: string;
}
export type ProgramTrackSettings = {
    azEl: AzElProgramTrackSettings;
    oem?: undefined;
    tle?: undefined;
} | {
    azEl?: undefined;
    oem: OemProgramTrackSettings;
    tle?: undefined;
} | {
    azEl?: undefined;
    oem?: undefined;
    tle: TleProgramTrackSettings;
};
export interface TrackingOverrides {
    programTrackSettings?: ProgramTrackSettings | undefined;
}
export type EphemerisType = "TLE" | "OEM" | "AZ_EL" | "SERVICE_MANAGED" | (string & {});
export interface EphemerisResponseData {
    ephemerisId?: string | undefined;
    ephemerisType: EphemerisType;
}
export type VersionStatus = "UPDATING" | "ACTIVE" | "SUPERSEDED" | "FAILED_TO_UPDATE" | (string & {});
export type VersionFailureReasonCode = "INTERNAL_ERROR" | "INVALID_SATELLITE_ARN" | "INVALID_UPDATE_CONTACT_REQUEST" | "EPHEMERIS_NOT_FOUND" | "EPHEMERIS_TIME_RANGE_INVALID" | "EPHEMERIS_NOT_ENABLED" | "SATELLITE_DOES_NOT_MATCH_EPHEMERIS" | "NOT_ONBOARDED_TO_AZEL_EPHEMERIS" | "AZEL_EPHEMERIS_NOT_FOUND" | "AZEL_EPHEMERIS_WRONG_GROUND_STATION" | "AZEL_EPHEMERIS_INVALID_STATUS" | "AZEL_EPHEMERIS_TIME_RANGE_INVALID" | (string & {});
export type VersionFailureReasonCodes = VersionFailureReasonCode[];
export interface ContactVersion {
    versionId?: number | undefined;
    created?: Date | undefined;
    activated?: Date | undefined;
    superseded?: Date | undefined;
    lastUpdated?: Date | undefined;
    status?: VersionStatus | undefined;
    failureCodes?: VersionFailureReasonCode[] | undefined;
    failureMessage?: string | undefined;
}
export interface DescribeContactResponse {
    contactId?: string | undefined;
    missionProfileArn?: string | undefined;
    satelliteArn?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    prePassStartTime?: Date | undefined;
    postPassEndTime?: Date | undefined;
    groundStation?: string | undefined;
    contactStatus?: ContactStatus | undefined;
    errorMessage?: string | undefined;
    maximumElevation?: Elevation | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    region?: string | undefined;
    dataflowList?: DataflowDetail[] | undefined;
    visibilityStartTime?: Date | undefined;
    visibilityEndTime?: Date | undefined;
    trackingOverrides?: TrackingOverrides | undefined;
    ephemeris?: EphemerisResponseData | undefined;
    version?: ContactVersion | undefined;
}
export interface DescribeContactVersionRequest {
    contactId: string;
    versionId: number;
}
export interface DescribeContactVersionResponse {
    contactId?: string | undefined;
    missionProfileArn?: string | undefined;
    satelliteArn?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    prePassStartTime?: Date | undefined;
    postPassEndTime?: Date | undefined;
    groundStation?: string | undefined;
    contactStatus?: ContactStatus | undefined;
    errorMessage?: string | undefined;
    maximumElevation?: Elevation | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    region?: string | undefined;
    dataflowList?: DataflowDetail[] | undefined;
    visibilityStartTime?: Date | undefined;
    visibilityEndTime?: Date | undefined;
    trackingOverrides?: TrackingOverrides | undefined;
    ephemeris?: EphemerisResponseData | undefined;
    version?: ContactVersion | undefined;
}
export interface DescribeEphemerisRequest {
    ephemerisId: string;
}
export type EphemerisStatus = "VALIDATING" | "INVALID" | "ERROR" | "ENABLED" | "DISABLED" | "EXPIRED" | (string & {});
export type EphemerisPriority = number;
export interface EphemerisDescription {
    sourceS3Object?: S3Object | undefined;
    ephemerisData?: string | undefined;
}
export type EphemerisTypeDescription = {
    tle: EphemerisDescription;
    oem?: undefined;
    azEl?: undefined;
} | {
    tle?: undefined;
    oem: EphemerisDescription;
    azEl?: undefined;
} | {
    tle?: undefined;
    oem?: undefined;
    azEl: EphemerisDescription;
};
export type EphemerisInvalidReason = "METADATA_INVALID" | "TIME_RANGE_INVALID" | "TRAJECTORY_INVALID" | "KMS_KEY_INVALID" | "VALIDATION_ERROR" | (string & {});
export type EphemerisErrorCode = "INTERNAL_ERROR" | "MISMATCHED_SATCAT_ID" | "OEM_VERSION_UNSUPPORTED" | "ORIGINATOR_MISSING" | "CREATION_DATE_MISSING" | "OBJECT_NAME_MISSING" | "OBJECT_ID_MISSING" | "REF_FRAME_UNSUPPORTED" | "REF_FRAME_EPOCH_UNSUPPORTED" | "TIME_SYSTEM_UNSUPPORTED" | "CENTER_BODY_UNSUPPORTED" | "INTERPOLATION_MISSING" | "INTERPOLATION_DEGREE_INVALID" | "AZ_EL_SEGMENT_LIST_MISSING" | "INSUFFICIENT_TIME_AZ_EL" | "START_TIME_IN_FUTURE" | "END_TIME_IN_PAST" | "EXPIRATION_TIME_TOO_EARLY" | "START_TIME_METADATA_TOO_EARLY" | "STOP_TIME_METADATA_TOO_LATE" | "AZ_EL_SEGMENT_END_TIME_BEFORE_START_TIME" | "AZ_EL_SEGMENT_TIMES_OVERLAP" | "AZ_EL_SEGMENTS_OUT_OF_ORDER" | "TIME_AZ_EL_ITEMS_OUT_OF_ORDER" | "MEAN_MOTION_INVALID" | "TIME_AZ_EL_AZ_RADIAN_RANGE_INVALID" | "TIME_AZ_EL_EL_RADIAN_RANGE_INVALID" | "TIME_AZ_EL_AZ_DEGREE_RANGE_INVALID" | "TIME_AZ_EL_EL_DEGREE_RANGE_INVALID" | "TIME_AZ_EL_ANGLE_UNITS_INVALID" | "INSUFFICIENT_KMS_PERMISSIONS" | "FILE_FORMAT_INVALID" | "AZ_EL_SEGMENT_REFERENCE_EPOCH_INVALID" | "AZ_EL_SEGMENT_START_TIME_INVALID" | "AZ_EL_SEGMENT_END_TIME_INVALID" | "AZ_EL_SEGMENT_VALID_TIME_RANGE_INVALID" | "AZ_EL_SEGMENT_END_TIME_TOO_LATE" | "AZ_EL_TOTAL_DURATION_EXCEEDED" | (string & {});
export type ErrorString = string;
export interface EphemerisErrorReason {
    errorCode: EphemerisErrorCode;
    errorMessage: string;
}
export type EphemerisErrorReasonList = EphemerisErrorReason[];
export interface DescribeEphemerisResponse {
    ephemerisId?: string | undefined;
    satelliteId?: string | undefined;
    status?: EphemerisStatus | undefined;
    priority?: number | undefined;
    creationTime?: Date | undefined;
    enabled?: boolean | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    suppliedData?: EphemerisTypeDescription | undefined;
    invalidReason?: EphemerisInvalidReason | undefined;
    errorReasons?: EphemerisErrorReason[] | undefined;
}
export interface GetAgentConfigurationRequest {
    agentId: string;
}
export interface GetAgentConfigurationResponse {
    agentId?: string | undefined;
    taskingDocument?: string | undefined;
}
export interface GetAgentTaskResponseUrlRequest {
    agentId: string;
    taskId: string;
}
export interface GetAgentTaskResponseUrlResponse {
    agentId: string;
    taskId: string;
    presignedLogUrl: string;
}
export interface GetConfigRequest {
    configId: string;
    configType: ConfigCapabilityType;
}
export interface GetConfigResponse {
    configId: string;
    configArn: string;
    name: string;
    configType?: ConfigCapabilityType | undefined;
    configData: ConfigTypeData;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDataflowEndpointGroupRequest {
    dataflowEndpointGroupId: string;
}
export type DataflowEndpointGroupArn = string;
export interface GetDataflowEndpointGroupResponse {
    dataflowEndpointGroupId?: string | undefined;
    dataflowEndpointGroupArn?: string | undefined;
    endpointsDetails?: EndpointDetails[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    contactPrePassDurationSeconds?: number | undefined;
    contactPostPassDurationSeconds?: number | undefined;
}
export type Month = number;
export type Year = number;
export interface GetMinuteUsageRequest {
    month: number;
    year: number;
}
export interface GetMinuteUsageResponse {
    isReservedMinutesCustomer?: boolean | undefined;
    totalReservedMinuteAllocation?: number | undefined;
    upcomingMinutesScheduled?: number | undefined;
    totalScheduledMinutes?: number | undefined;
    estimatedMinutesRemaining?: number | undefined;
}
export interface GetMissionProfileRequest {
    missionProfileId: string;
}
export type AWSRegion = string;
export interface GetMissionProfileResponse {
    missionProfileId?: string | undefined;
    missionProfileArn?: string | undefined;
    name?: string | undefined;
    region?: string | undefined;
    contactPrePassDurationSeconds?: number | undefined;
    contactPostPassDurationSeconds?: number | undefined;
    minimumViableContactDurationSeconds?: number | undefined;
    dataflowEdges?: string[][] | undefined;
    trackingConfigArn?: string | undefined;
    telemetrySinkConfigArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    streamsKmsKey?: KmsKey | undefined;
    streamsKmsRole?: string | undefined;
}
export interface GetSatelliteRequest {
    satelliteId: string;
}
export type NoradSatelliteID = number;
export type GroundStationIdList = string[];
export type EphemerisSource = "CUSTOMER_PROVIDED" | "SPACE_TRACK" | (string & {});
export interface EphemerisMetaData {
    source: EphemerisSource;
    ephemerisId?: string | undefined;
    epoch?: Date | undefined;
    name?: string | undefined;
}
export interface GetSatelliteResponse {
    satelliteId?: string | undefined;
    satelliteArn?: string | undefined;
    noradSatelliteID?: number | undefined;
    groundStations?: string[] | undefined;
    currentEphemeris?: EphemerisMetaData | undefined;
}
export type PaginationMaxResults = number;
export type PaginationToken = string;
export interface ListAntennasRequest {
    groundStationId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AntennaName = string;
export interface AntennaListItem {
    groundStationName: string;
    antennaName: string;
    region: string;
}
export type AntennaList = AntennaListItem[];
export interface ListAntennasResponse {
    antennaList: AntennaListItem[];
    nextToken?: string | undefined;
}
export interface ListConfigsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ConfigListItem {
    configId?: string | undefined;
    configType?: ConfigCapabilityType | undefined;
    configArn?: string | undefined;
    name?: string | undefined;
}
export type ConfigList = ConfigListItem[];
export interface ListConfigsResponse {
    nextToken?: string | undefined;
    configList?: ConfigListItem[] | undefined;
}
export type StatusList = ContactStatus[];
export interface AzElEphemerisFilter {
    id: string;
}
export type EphemerisFilter = {
    azEl: AzElEphemerisFilter;
};
export interface ListContactsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    statusList: ContactStatus[];
    startTime: Date;
    endTime: Date;
    groundStation?: string | undefined;
    satelliteArn?: string | undefined;
    missionProfileArn?: string | undefined;
    ephemeris?: EphemerisFilter | undefined;
}
export interface ContactData {
    contactId?: string | undefined;
    missionProfileArn?: string | undefined;
    satelliteArn?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    prePassStartTime?: Date | undefined;
    postPassEndTime?: Date | undefined;
    groundStation?: string | undefined;
    contactStatus?: ContactStatus | undefined;
    errorMessage?: string | undefined;
    maximumElevation?: Elevation | undefined;
    region?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    visibilityStartTime?: Date | undefined;
    visibilityEndTime?: Date | undefined;
    ephemeris?: EphemerisResponseData | undefined;
    version?: ContactVersion | undefined;
}
export type ContactList = ContactData[];
export interface ListContactsResponse {
    nextToken?: string | undefined;
    contactList?: ContactData[] | undefined;
}
export interface ListContactVersionsRequest {
    contactId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ContactVersionsList = ContactVersion[];
export interface ListContactVersionsResponse {
    nextToken?: string | undefined;
    contactVersionsList?: ContactVersion[] | undefined;
}
export interface ListDataflowEndpointGroupsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DataflowEndpointListItem {
    dataflowEndpointGroupId?: string | undefined;
    dataflowEndpointGroupArn?: string | undefined;
}
export type DataflowEndpointGroupList = DataflowEndpointListItem[];
export interface ListDataflowEndpointGroupsResponse {
    nextToken?: string | undefined;
    dataflowEndpointGroupList?: DataflowEndpointListItem[] | undefined;
}
export type EphemerisStatusList = EphemerisStatus[];
export interface ListEphemeridesRequest {
    satelliteId?: string | undefined;
    ephemerisType?: EphemerisType | undefined;
    startTime: Date;
    endTime: Date;
    statusList?: EphemerisStatus[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EphemerisItem {
    ephemerisId?: string | undefined;
    ephemerisType?: EphemerisType | undefined;
    status?: EphemerisStatus | undefined;
    priority?: number | undefined;
    enabled?: boolean | undefined;
    creationTime?: Date | undefined;
    name?: string | undefined;
    sourceS3Object?: S3Object | undefined;
}
export type EphemeridesList = EphemerisItem[];
export interface ListEphemeridesResponse {
    nextToken?: string | undefined;
    ephemerides?: EphemerisItem[] | undefined;
}
export type ReservationType = "MAINTENANCE" | "CONTACT" | (string & {});
export type ReservationTypeFilterList = ReservationType[];
export interface ListGroundStationReservationsRequest {
    groundStationId: string;
    startTime: Date;
    endTime: Date;
    reservationTypes?: ReservationType[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type MaintenanceType = "PLANNED" | "UNPLANNED" | (string & {});
export interface MaintenanceReservationDetails {
    maintenanceType: MaintenanceType;
}
export interface ContactReservationDetails {
    contactId?: string | undefined;
}
export type ReservationDetails = {
    maintenance: MaintenanceReservationDetails;
    contact?: undefined;
} | {
    maintenance?: undefined;
    contact: ContactReservationDetails;
};
export interface GroundStationReservationListItem {
    reservationType: ReservationType;
    groundStationId: string;
    antennaName: string;
    startTime: Date;
    endTime: Date;
    reservationDetails: ReservationDetails;
}
export type GroundStationReservationList = GroundStationReservationListItem[];
export interface ListGroundStationReservationsResponse {
    reservationList: GroundStationReservationListItem[];
    nextToken?: string | undefined;
}
export interface ListGroundStationsRequest {
    satelliteId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GroundStationData {
    groundStationId?: string | undefined;
    groundStationName?: string | undefined;
    region?: string | undefined;
}
export type GroundStationList = GroundStationData[];
export interface ListGroundStationsResponse {
    nextToken?: string | undefined;
    groundStationList?: GroundStationData[] | undefined;
}
export interface ListMissionProfilesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface MissionProfileListItem {
    missionProfileId?: string | undefined;
    missionProfileArn?: string | undefined;
    region?: string | undefined;
    name?: string | undefined;
}
export type MissionProfileList = MissionProfileListItem[];
export interface ListMissionProfilesResponse {
    nextToken?: string | undefined;
    missionProfileList?: MissionProfileListItem[] | undefined;
}
export interface ListSatellitesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SatelliteListItem {
    satelliteId?: string | undefined;
    satelliteArn?: string | undefined;
    noradSatelliteID?: number | undefined;
    groundStations?: string[] | undefined;
    currentEphemeris?: EphemerisMetaData | undefined;
}
export type SatelliteList = SatelliteListItem[];
export interface ListSatellitesResponse {
    nextToken?: string | undefined;
    satellites?: SatelliteListItem[] | undefined;
}
export type AnyArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type IpAddressList = string[];
export type CapabilityArn = string;
export type CapabilityArnList = string[];
export interface DiscoveryData {
    publicIpAddresses: string[];
    privateIpAddresses: string[];
    capabilityArns: string[];
}
export type VersionString = string;
export type InstanceId = string;
export type InstanceType = string;
export type AgentCpuCoresList = number[];
export type ComponentTypeString = string;
export type VersionStringList = string[];
export interface ComponentVersion {
    componentType: string;
    versions: string[];
}
export type ComponentVersionList = ComponentVersion[];
export interface AgentDetails {
    agentVersion: string;
    instanceId: string;
    instanceType: string;
    reservedCpuCores?: number[] | undefined;
    agentCpuCores?: number[] | undefined;
    componentVersions: ComponentVersion[];
}
export interface RegisterAgentRequest {
    discoveryData: DiscoveryData;
    agentDetails: AgentDetails;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RegisterAgentResponse {
    agentId?: string | undefined;
}
export interface ReserveContactRequest {
    missionProfileArn: string;
    satelliteArn?: string | undefined;
    startTime: Date;
    endTime: Date;
    groundStation: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    trackingOverrides?: TrackingOverrides | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type SignatureMap = {
    [key: string]: boolean | undefined;
};
export interface AggregateStatus {
    status: AgentStatus;
    signatureMap?: {
        [key: string]: boolean | undefined;
    } | undefined;
}
export interface ComponentStatusData {
    componentType: string;
    capabilityArn: string;
    status: AgentStatus;
    bytesSent?: number | undefined;
    bytesReceived?: number | undefined;
    packetsDropped?: number | undefined;
    dataflowId: string;
}
export type ComponentStatusList = ComponentStatusData[];
export interface UpdateAgentStatusRequest {
    agentId: string;
    taskId: string;
    aggregateStatus: AggregateStatus;
    componentStatuses: ComponentStatusData[];
}
export interface UpdateAgentStatusResponse {
    agentId: string;
}
export interface UpdateConfigRequest {
    configId: string;
    name: string;
    configType: ConfigCapabilityType;
    configData: ConfigTypeData;
}
export type ClientToken = string;
export interface UpdateContactRequest {
    contactId: string;
    clientToken?: string | undefined;
    trackingOverrides?: TrackingOverrides | undefined;
    satelliteArn?: string | undefined;
}
export interface UpdateContactResponse {
    contactId?: string | undefined;
    versionId?: number | undefined;
}
export interface UpdateEphemerisRequest {
    ephemerisId: string;
    enabled: boolean;
    name?: string | undefined;
    priority?: number | undefined;
}
export interface UpdateMissionProfileRequest {
    missionProfileId: string;
    name?: string | undefined;
    contactPrePassDurationSeconds?: number | undefined;
    contactPostPassDurationSeconds?: number | undefined;
    minimumViableContactDurationSeconds?: number | undefined;
    dataflowEdges?: string[][] | undefined;
    trackingConfigArn?: string | undefined;
    telemetrySinkConfigArn?: string | undefined;
    streamsKmsKey?: KmsKey | undefined;
    streamsKmsRole?: string | undefined;
}
export type CancelContactError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels or stops a contact with a specified contact ID based on its position in the contact lifecycle.
 *
 * For contacts that:
 *
 * - Have yet to start, the contact will be cancelled.
 *
 * - Have started but have yet to finish, the contact will be stopped.
 */
export declare const cancelContact: API.OperationMethod<CancelContactRequest & RegionInput, ContactIdResponse, CancelContactError, Credentials | HttpClient.HttpClient>;
export type CreateConfigError = DependencyException | InvalidParameterException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a `Config` with the specified `configData` parameters.
 *
 * Only one type of `configData` can be specified.
 */
export declare const createConfig: API.OperationMethod<CreateConfigRequest & RegionInput, ConfigIdResponse, CreateConfigError, Credentials | HttpClient.HttpClient>;
export type CreateDataflowEndpointGroupError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a `DataflowEndpoint` group containing the specified list of ` DataflowEndpoint` objects.
 *
 * The `name` field in each endpoint is used in your mission profile ` DataflowEndpointConfig` to specify which endpoints to use during a contact.
 *
 * When a contact uses multiple `DataflowEndpointConfig` objects, each ` Config` must match a `DataflowEndpoint` in the same group.
 */
export declare const createDataflowEndpointGroup: API.OperationMethod<CreateDataflowEndpointGroupRequest & RegionInput, DataflowEndpointGroupIdResponse, CreateDataflowEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDataflowEndpointGroupV2Error = DependencyException | InvalidParameterException | ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Creates a `DataflowEndpoint` group containing the specified list of Ground Station Agent based endpoints.
 *
 * The `name` field in each endpoint is used in your mission profile ` DataflowEndpointConfig` to specify which endpoints to use during a contact.
 *
 * When a contact uses multiple `DataflowEndpointConfig` objects, each ` Config` must match a `DataflowEndpoint` in the same group.
 */
export declare const createDataflowEndpointGroupV2: API.OperationMethod<CreateDataflowEndpointGroupV2Request & RegionInput, CreateDataflowEndpointGroupV2Response, CreateDataflowEndpointGroupV2Error, Credentials | HttpClient.HttpClient>;
export type CreateEphemerisError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Create an ephemeris with your specified EphemerisData.
 */
export declare const createEphemeris: API.OperationMethod<CreateEphemerisRequest & RegionInput, EphemerisIdResponse, CreateEphemerisError, Credentials | HttpClient.HttpClient>;
export type CreateMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a mission profile.
 *
 * `dataflowEdges` is a list of lists of strings. Each lower level list of strings has two elements: a *from* ARN and a *to* ARN.
 */
export declare const createMissionProfile: API.OperationMethod<CreateMissionProfileRequest & RegionInput, MissionProfileIdResponse, CreateMissionProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a `Config`.
 */
export declare const deleteConfig: API.OperationMethod<DeleteConfigRequest & RegionInput, ConfigIdResponse, DeleteConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDataflowEndpointGroupError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataflow endpoint group.
 */
export declare const deleteDataflowEndpointGroup: API.OperationMethod<DeleteDataflowEndpointGroupRequest & RegionInput, DataflowEndpointGroupIdResponse, DeleteDataflowEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEphemerisError = DependencyException | InvalidParameterException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Delete an ephemeris.
 */
export declare const deleteEphemeris: API.OperationMethod<DeleteEphemerisRequest & RegionInput, EphemerisIdResponse, DeleteEphemerisError, Credentials | HttpClient.HttpClient>;
export type DeleteMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a mission profile.
 */
export declare const deleteMissionProfile: API.OperationMethod<DeleteMissionProfileRequest & RegionInput, MissionProfileIdResponse, DeleteMissionProfileError, Credentials | HttpClient.HttpClient>;
export type DescribeContactError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an existing contact.
 */
export declare const describeContact: API.OperationMethod<DescribeContactRequest & RegionInput, DescribeContactResponse, DescribeContactError, Credentials | HttpClient.HttpClient>;
export type DescribeContactVersionError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a specific version of a contact.
 */
export declare const describeContactVersion: API.OperationMethod<DescribeContactVersionRequest & RegionInput, DescribeContactVersionResponse, DescribeContactVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeEphemerisError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieve information about an existing ephemeris.
 */
export declare const describeEphemeris: API.OperationMethod<DescribeEphemerisRequest & RegionInput, DescribeEphemerisResponse, DescribeEphemerisError, Credentials | HttpClient.HttpClient>;
export type GetAgentConfigurationError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Gets the latest configuration information for a registered agent.
 */
export declare const getAgentConfiguration: API.OperationMethod<GetAgentConfigurationRequest & RegionInput, GetAgentConfigurationResponse, GetAgentConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetAgentTaskResponseUrlError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Gets a presigned URL for uploading agent task response logs.
 */
export declare const getAgentTaskResponseUrl: API.OperationMethod<GetAgentTaskResponseUrlRequest & RegionInput, GetAgentTaskResponseUrlResponse, GetAgentTaskResponseUrlError, Credentials | HttpClient.HttpClient>;
export type GetConfigError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns `Config` information.
 *
 * Only one `Config` response can be returned.
 */
export declare const getConfig: API.OperationMethod<GetConfigRequest & RegionInput, GetConfigResponse, GetConfigError, Credentials | HttpClient.HttpClient>;
export type GetDataflowEndpointGroupError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the dataflow endpoint group.
 */
export declare const getDataflowEndpointGroup: API.OperationMethod<GetDataflowEndpointGroupRequest & RegionInput, GetDataflowEndpointGroupResponse, GetDataflowEndpointGroupError, Credentials | HttpClient.HttpClient>;
export type GetMinuteUsageError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the number of reserved minutes used by account.
 */
export declare const getMinuteUsage: API.OperationMethod<GetMinuteUsageRequest & RegionInput, GetMinuteUsageResponse, GetMinuteUsageError, Credentials | HttpClient.HttpClient>;
export type GetMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a mission profile.
 */
export declare const getMissionProfile: API.OperationMethod<GetMissionProfileRequest & RegionInput, GetMissionProfileResponse, GetMissionProfileError, Credentials | HttpClient.HttpClient>;
export type GetSatelliteError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a satellite.
 */
export declare const getSatellite: API.OperationMethod<GetSatelliteRequest & RegionInput, GetSatelliteResponse, GetSatelliteError, Credentials | HttpClient.HttpClient>;
export type ListAntennasError = DependencyException | InvalidParameterException | CommonErrors;
/**
 * Returns a list of antennas at a specified ground station.
 */
export declare const listAntennas: API.PaginatedOperationMethod<ListAntennasRequest & RegionInput, ListAntennasResponse, ListAntennasError, Credentials | HttpClient.HttpClient, AntennaListItem>;
export type ListConfigsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of `Config` objects.
 */
export declare const listConfigs: API.PaginatedOperationMethod<ListConfigsRequest & RegionInput, ListConfigsResponse, ListConfigsError, Credentials | HttpClient.HttpClient, ConfigListItem>;
export type ListContactsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of contacts.
 *
 * If `statusList` contains AVAILABLE, the request must include ` groundStation`, `missionprofileArn`, and `satelliteArn`.
 */
export declare const listContacts: API.PaginatedOperationMethod<ListContactsRequest & RegionInput, ListContactsResponse, ListContactsError, Credentials | HttpClient.HttpClient, ContactData>;
export type ListContactVersionsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of versions for a specified contact.
 */
export declare const listContactVersions: API.PaginatedOperationMethod<ListContactVersionsRequest & RegionInput, ListContactVersionsResponse, ListContactVersionsError, Credentials | HttpClient.HttpClient, ContactVersion>;
export type ListDataflowEndpointGroupsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of `DataflowEndpoint` groups.
 */
export declare const listDataflowEndpointGroups: API.PaginatedOperationMethod<ListDataflowEndpointGroupsRequest & RegionInput, ListDataflowEndpointGroupsResponse, ListDataflowEndpointGroupsError, Credentials | HttpClient.HttpClient, DataflowEndpointListItem>;
export type ListEphemeridesError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * List your existing ephemerides.
 */
export declare const listEphemerides: API.PaginatedOperationMethod<ListEphemeridesRequest & RegionInput, ListEphemeridesResponse, ListEphemeridesError, Credentials | HttpClient.HttpClient, EphemerisItem>;
export type ListGroundStationReservationsError = DependencyException | InvalidParameterException | CommonErrors;
/**
 * Returns a list of reservations for a specified ground station.
 */
export declare const listGroundStationReservations: API.PaginatedOperationMethod<ListGroundStationReservationsRequest & RegionInput, ListGroundStationReservationsResponse, ListGroundStationReservationsError, Credentials | HttpClient.HttpClient, GroundStationReservationListItem>;
export type ListGroundStationsError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of ground stations.
 */
export declare const listGroundStations: API.PaginatedOperationMethod<ListGroundStationsRequest & RegionInput, ListGroundStationsResponse, ListGroundStationsError, Credentials | HttpClient.HttpClient, GroundStationData>;
export type ListMissionProfilesError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of mission profiles.
 */
export declare const listMissionProfiles: API.PaginatedOperationMethod<ListMissionProfilesRequest & RegionInput, ListMissionProfilesResponse, ListMissionProfilesError, Credentials | HttpClient.HttpClient, MissionProfileListItem>;
export type ListSatellitesError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of satellites.
 */
export declare const listSatellites: API.PaginatedOperationMethod<ListSatellitesRequest & RegionInput, ListSatellitesResponse, ListSatellitesError, Credentials | HttpClient.HttpClient, SatelliteListItem>;
export type ListTagsForResourceError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterAgentError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Registers a new agent with AWS Ground Station.
 */
export declare const registerAgent: API.OperationMethod<RegisterAgentRequest & RegionInput, RegisterAgentResponse, RegisterAgentError, Credentials | HttpClient.HttpClient>;
export type ReserveContactError = DependencyException | InvalidParameterException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Reserves a contact using specified parameters.
 */
export declare const reserveContact: API.OperationMethod<ReserveContactRequest & RegionInput, ContactIdResponse, ReserveContactError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns a tag to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Deassigns a resource tag.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentStatusError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * For use by AWS Ground Station Agent and shouldn't be called directly.
 *
 * Update the status of the agent.
 */
export declare const updateAgentStatus: API.OperationMethod<UpdateAgentStatusRequest & RegionInput, UpdateAgentStatusResponse, UpdateAgentStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the `Config` used when scheduling contacts.
 *
 * Updating a `Config` will not update the execution parameters for existing future contacts scheduled with this `Config`.
 */
export declare const updateConfig: API.OperationMethod<UpdateConfigRequest & RegionInput, ConfigIdResponse, UpdateConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateContactError = DependencyException | InvalidParameterException | ResourceLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a specific contact.
 */
export declare const updateContact: API.OperationMethod<UpdateContactRequest & RegionInput, UpdateContactResponse, UpdateContactError, Credentials | HttpClient.HttpClient>;
export type UpdateEphemerisError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Update an existing ephemeris.
 */
export declare const updateEphemeris: API.OperationMethod<UpdateEphemerisRequest & RegionInput, EphemerisIdResponse, UpdateEphemerisError, Credentials | HttpClient.HttpClient>;
export type UpdateMissionProfileError = DependencyException | InvalidParameterException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a mission profile.
 *
 * Updating a mission profile will not update the execution parameters for existing future contacts.
 */
export declare const updateMissionProfile: API.OperationMethod<UpdateMissionProfileRequest & RegionInput, MissionProfileIdResponse, UpdateMissionProfileError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=groundstation.d.ts.map