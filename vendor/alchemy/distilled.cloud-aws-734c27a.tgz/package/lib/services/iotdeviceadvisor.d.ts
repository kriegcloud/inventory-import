import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SuiteDefinitionName = string;
export type AmazonResourceName = string;
export interface DeviceUnderTest {
    thingArn?: string | undefined;
    certificateArn?: string | undefined;
    deviceRoleArn?: string | undefined;
}
export type DeviceUnderTestList = DeviceUnderTest[];
export type IntendedForQualificationBoolean = boolean;
export type IsLongDurationTestBoolean = boolean;
export type RootGroup = string;
export type Protocol = "MqttV3_1_1" | "MqttV5" | "MqttV3_1_1_OverWebSocket" | "MqttV5_OverWebSocket" | (string & {});
export interface SuiteDefinitionConfiguration {
    suiteDefinitionName?: string | undefined;
    devices?: DeviceUnderTest[] | undefined;
    intendedForQualification?: boolean | undefined;
    isLongDurationTest?: boolean | undefined;
    rootGroup?: string | undefined;
    devicePermissionRoleArn?: string | undefined;
    protocol?: Protocol | undefined;
}
export type String128 = string;
export type String256 = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export interface CreateSuiteDefinitionRequest {
    suiteDefinitionConfiguration?: SuiteDefinitionConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type UUID = string;
export interface CreateSuiteDefinitionResponse {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionArn?: string | undefined;
    suiteDefinitionName?: string | undefined;
    createdAt?: Date | undefined;
}
export interface DeleteSuiteDefinitionRequest {
    suiteDefinitionId: string;
}
export interface DeleteSuiteDefinitionResponse {
}
export type AuthenticationMethod = "X509ClientCertificate" | "SignatureVersion4" | (string & {});
export interface GetEndpointRequest {
    thingArn?: string | undefined;
    certificateArn?: string | undefined;
    deviceRoleArn?: string | undefined;
    authenticationMethod?: AuthenticationMethod | undefined;
}
export type Endpoint = string;
export interface GetEndpointResponse {
    endpoint?: string | undefined;
}
export type SuiteDefinitionVersion = string;
export interface GetSuiteDefinitionRequest {
    suiteDefinitionId: string;
    suiteDefinitionVersion?: string | undefined;
}
export interface GetSuiteDefinitionResponse {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionArn?: string | undefined;
    suiteDefinitionVersion?: string | undefined;
    latestVersion?: string | undefined;
    suiteDefinitionConfiguration?: (SuiteDefinitionConfiguration & {
        suiteDefinitionName: SuiteDefinitionName;
        rootGroup: RootGroup;
        devicePermissionRoleArn: AmazonResourceName;
    }) | undefined;
    createdAt?: Date | undefined;
    lastModifiedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSuiteRunRequest {
    suiteDefinitionId: string;
    suiteRunId: string;
}
export type SelectedTestList = string[];
export type ParallelRun = boolean;
export interface SuiteRunConfiguration {
    primaryDevice?: DeviceUnderTest | undefined;
    selectedTestList?: string[] | undefined;
    parallelRun?: boolean | undefined;
}
export type GroupName = string;
export type TestCaseDefinitionName = string;
export type Status = "PASS" | "FAIL" | "CANCELED" | "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | "PASS_WITH_WARNINGS" | "ERROR" | (string & {});
export type LogUrl = string;
export type Warnings = string;
export type Failure = string;
export type TestCaseScenarioId = string;
export type TestCaseScenarioType = "Advanced" | "Basic" | (string & {});
export type TestCaseScenarioStatus = "PASS" | "FAIL" | "CANCELED" | "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | "PASS_WITH_WARNINGS" | "ERROR" | (string & {});
export type SystemMessage = string;
export interface TestCaseScenario {
    testCaseScenarioId?: string | undefined;
    testCaseScenarioType?: TestCaseScenarioType | undefined;
    status?: TestCaseScenarioStatus | undefined;
    failure?: string | undefined;
    systemMessage?: string | undefined;
}
export type TestCaseScenariosList = TestCaseScenario[];
export interface TestCaseRun {
    testCaseRunId?: string | undefined;
    testCaseDefinitionId?: string | undefined;
    testCaseDefinitionName?: string | undefined;
    status?: Status | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    logUrl?: string | undefined;
    warnings?: string | undefined;
    failure?: string | undefined;
    testScenarios?: TestCaseScenario[] | undefined;
}
export type TestCaseRuns = TestCaseRun[];
export interface GroupResult {
    groupId?: string | undefined;
    groupName?: string | undefined;
    tests?: TestCaseRun[] | undefined;
}
export type GroupResultList = GroupResult[];
export interface TestResult {
    groups?: GroupResult[] | undefined;
}
export type SuiteRunStatus = "PASS" | "FAIL" | "CANCELED" | "PENDING" | "RUNNING" | "STOPPING" | "STOPPED" | "PASS_WITH_WARNINGS" | "ERROR" | (string & {});
export type ErrorReason = string;
export interface GetSuiteRunResponse {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionVersion?: string | undefined;
    suiteRunId?: string | undefined;
    suiteRunArn?: string | undefined;
    suiteRunConfiguration?: (SuiteRunConfiguration & {
        primaryDevice: DeviceUnderTest;
    }) | undefined;
    testResult?: TestResult | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    status?: SuiteRunStatus | undefined;
    errorReason?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSuiteRunReportRequest {
    suiteDefinitionId: string;
    suiteRunId: string;
}
export type QualificationReportDownloadUrl = string;
export interface GetSuiteRunReportResponse {
    qualificationReportDownloadUrl?: string | undefined;
}
export type MaxResults = number;
export type Token = string;
export interface ListSuiteDefinitionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SuiteDefinitionInformation {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionName?: string | undefined;
    defaultDevices?: DeviceUnderTest[] | undefined;
    intendedForQualification?: boolean | undefined;
    isLongDurationTest?: boolean | undefined;
    protocol?: Protocol | undefined;
    createdAt?: Date | undefined;
}
export type SuiteDefinitionInformationList = SuiteDefinitionInformation[];
export interface ListSuiteDefinitionsResponse {
    suiteDefinitionInformationList?: SuiteDefinitionInformation[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSuiteRunsRequest {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionVersion?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type SuiteRunResultCount = number;
export interface SuiteRunInformation {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionVersion?: string | undefined;
    suiteDefinitionName?: string | undefined;
    suiteRunId?: string | undefined;
    createdAt?: Date | undefined;
    startedAt?: Date | undefined;
    endAt?: Date | undefined;
    status?: SuiteRunStatus | undefined;
    passed?: number | undefined;
    failed?: number | undefined;
}
export type SuiteRunsList = SuiteRunInformation[];
export interface ListSuiteRunsResponse {
    suiteRunsList?: SuiteRunInformation[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartSuiteRunRequest {
    suiteDefinitionId: string;
    suiteDefinitionVersion?: string | undefined;
    suiteRunConfiguration?: SuiteRunConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartSuiteRunResponse {
    suiteRunId?: string | undefined;
    suiteRunArn?: string | undefined;
    createdAt?: Date | undefined;
    endpoint?: string | undefined;
}
export interface StopSuiteRunRequest {
    suiteDefinitionId: string;
    suiteRunId: string;
}
export interface StopSuiteRunResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateSuiteDefinitionRequest {
    suiteDefinitionId: string;
    suiteDefinitionConfiguration?: SuiteDefinitionConfiguration | undefined;
}
export interface UpdateSuiteDefinitionResponse {
    suiteDefinitionId?: string | undefined;
    suiteDefinitionArn?: string | undefined;
    suiteDefinitionName?: string | undefined;
    suiteDefinitionVersion?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type Message = string;
export type CreateSuiteDefinitionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Creates a Device Advisor test suite.
 *
 * Requires permission to access the CreateSuiteDefinition action.
 */
export declare const createSuiteDefinition: API.OperationMethod<CreateSuiteDefinitionRequest & RegionInput, CreateSuiteDefinitionResponse, CreateSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteSuiteDefinitionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Deletes a Device Advisor test suite.
 *
 * Requires permission to access the DeleteSuiteDefinition action.
 */
export declare const deleteSuiteDefinition: API.OperationMethod<DeleteSuiteDefinitionRequest & RegionInput, DeleteSuiteDefinitionResponse, DeleteSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about an Device Advisor endpoint.
 */
export declare const getEndpoint: API.OperationMethod<GetEndpointRequest & RegionInput, GetEndpointResponse, GetEndpointError, Credentials | HttpClient.HttpClient>;
export type GetSuiteDefinitionError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about a Device Advisor test suite.
 *
 * Requires permission to access the GetSuiteDefinition action.
 */
export declare const getSuiteDefinition: API.OperationMethod<GetSuiteDefinitionRequest & RegionInput, GetSuiteDefinitionResponse, GetSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSuiteRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets information about a Device Advisor test suite run.
 *
 * Requires permission to access the GetSuiteRun action.
 */
export declare const getSuiteRun: API.OperationMethod<GetSuiteRunRequest & RegionInput, GetSuiteRunResponse, GetSuiteRunError, Credentials | HttpClient.HttpClient>;
export type GetSuiteRunReportError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Gets a report download link for a successful Device Advisor qualifying test suite run.
 *
 * Requires permission to access the GetSuiteRunReport action.
 */
export declare const getSuiteRunReport: API.OperationMethod<GetSuiteRunReportRequest & RegionInput, GetSuiteRunReportResponse, GetSuiteRunReportError, Credentials | HttpClient.HttpClient>;
export type ListSuiteDefinitionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the Device Advisor test suites you have created.
 *
 * Requires permission to access the ListSuiteDefinitions action.
 */
export declare const listSuiteDefinitions: API.PaginatedOperationMethod<ListSuiteDefinitionsRequest & RegionInput, ListSuiteDefinitionsResponse, ListSuiteDefinitionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSuiteRunsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists runs of the specified Device Advisor test suite. You can list all runs of the test
 * suite, or the runs of a specific version of the test suite.
 *
 * Requires permission to access the ListSuiteRuns action.
 */
export declare const listSuiteRuns: API.PaginatedOperationMethod<ListSuiteRunsRequest & RegionInput, ListSuiteRunsResponse, ListSuiteRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags attached to an IoT Device Advisor resource.
 *
 * Requires permission to access the ListTagsForResource action.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartSuiteRunError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Starts a Device Advisor test suite run.
 *
 * Requires permission to access the StartSuiteRun action.
 */
export declare const startSuiteRun: API.OperationMethod<StartSuiteRunRequest & RegionInput, StartSuiteRunResponse, StartSuiteRunError, Credentials | HttpClient.HttpClient>;
export type StopSuiteRunError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops a Device Advisor test suite run that is currently running.
 *
 * Requires permission to access the StopSuiteRun action.
 */
export declare const stopSuiteRun: API.OperationMethod<StopSuiteRunRequest & RegionInput, StopSuiteRunResponse, StopSuiteRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds to and modifies existing tags of an IoT Device Advisor resource.
 *
 * Requires permission to access the TagResource action.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes tags from an IoT Device Advisor resource.
 *
 * Requires permission to access the UntagResource action.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateSuiteDefinitionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Updates a Device Advisor test suite.
 *
 * Requires permission to access the UpdateSuiteDefinition action.
 */
export declare const updateSuiteDefinition: API.OperationMethod<UpdateSuiteDefinitionRequest & RegionInput, UpdateSuiteDefinitionResponse, UpdateSuiteDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=iotdeviceadvisor.d.ts.map