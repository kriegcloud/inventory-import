import * as Layer from "effect/Layer";
import { Terminals } from "../Terminal.ts";
/**
 * The package `TerminalsNode` opens terminals with: `node-pty` with prebuilt
 * Linux binaries (glibc, x64 and arm64), so images need no compiler. Node.js
 * has no pseudo-terminals of its own, so an image whose program opens them
 * installs it beside the bundle, which leaves it external.
 */
export declare const NODE_PTY_PACKAGE = "@lydell/node-pty";
/** The version images install. */
export declare const NODE_PTY_VERSION = "1.2.0-beta.18";
/** Pseudo-terminals on Node.js, from {@link NODE_PTY_PACKAGE}. */
export declare const TerminalsNode: Layer.Layer<Terminals, never, never>;
//# sourceMappingURL=TerminalNode.d.ts.map