import * as Contributions from "alchemy/Contributions";
import * as CliError from "effect/cli/CliError";
import * as Effect from "effect/Effect";
declare const mainEffect: Effect.Effect<void, import("../Alchemist/Errors.ts").AlchemistInvalidInput | import("../Alchemist/Errors.ts").AlchemistNotFound | import("effect/Config").ConfigError | import("./commands/confirm.ts").ConfirmationDeclined | Contributions.ContributionFailure | import("../Auth/Demand.ts").CredentialsRequired | import("../Apply.ts").DestroyError | import("../Output.ts").InvalidReferenceError | import("../Output.ts").MissingSourceError | import("../Auth/AuthProvider.ts").NeedsReauth | import("alchemy/Auth/Profile").ProfileError | import("../Provider.ts").ProviderError | {
    readonly "~effect/Runtime/errorReported": false;
    readonly cause: unknown;
} | import("effect/Schema").SchemaError | import("effect/http/HttpServerError").ServeError | import("../Alchemist/Entrypoint.ts").StackEntrypointError | import("../State/State.ts").StateStoreError | import("./commands/errors.ts").UserInputError | CliError.CliError | import("../Alchemist/AuthRegistry.ts").CollectAuthProvidersError | import("../Interaction.ts").InteractionError, never>;
/** Fully wired CLI program. */
export declare const main: Effect.Effect<void, Effect.Error<typeof mainEffect>>;
export {};
//# sourceMappingURL=main.d.ts.map