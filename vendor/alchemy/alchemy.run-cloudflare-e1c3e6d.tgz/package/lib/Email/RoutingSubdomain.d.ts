import * as dns from "@distilled.cloud/cloudflare/dns";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const RoutingSubdomainTypeId: "Cloudflare.Email.RoutingSubdomain";
type RoutingSubdomainTypeId = typeof RoutingSubdomainTypeId;
export interface RoutingSubdomainProps {
    /**
     * Zone the subdomain belongs to. Email Routing must be enabled on the zone
     * (see {@link Routing}).
     *
     * Stable — moving the subdomain to another zone triggers a replacement.
     */
    zoneId: string;
    /**
     * The fully-qualified subdomain to receive mail on (e.g.
     * `in.example.com`). Must be within the zone.
     *
     * Stable — a rename is a delete + create.
     */
    name: string;
}
export interface RoutingSubdomainAttributes {
    /** Zone the subdomain belongs to. */
    zoneId: string;
    /** The subdomain receiving mail. */
    name: string;
    /** The Email Routing MX hosts the subdomain's records point at. */
    mx: string[];
}
export type RoutingSubdomain = Resource<RoutingSubdomainTypeId, RoutingSubdomainProps, RoutingSubdomainAttributes, never, Providers>;
/**
 * Extends Email Routing on a zone to one of its subdomains, so literal
 * routing rules (see {@link Rule}) can match addresses on it, as the
 * dashboard's Email Routing > Settings > Subdomains does. Cloudflare adds and
 * locks the subdomain's MX and SPF records. Catch-all rules stay apex-only.
 *
 * Deleting it unlocks and removes the subdomain's Email Routing records
 * only. It never disables Email Routing on the zone: the zone-level
 * `DELETE /email/routing/dns` takes no subdomain and would turn routing off
 * for the apex too.
 *
 * Safety: Email Routing records carry no ownership markers. When there is no
 * prior state, `read` reports a subdomain that already routes mail as
 * `Unowned`, so the engine refuses to take it over unless `--adopt` (or
 * `adopt(true)`) is set.
 *
 * ### Receiving on a subdomain
 * **Example:** Route `docs@in.example.com` to a Worker
 * ```typescript
 * const routing = yield* Cloudflare.Email.Routing("Routing", {
 *   zone: "example.com",
 * });
 * yield* Cloudflare.Email.RoutingSubdomain("Inbound", {
 *   zoneId: routing.zoneId,
 *   name: "in.example.com",
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/email-service/configuration/subdomains/
 *
 * @resource
 * @product Email
 * @category Email
 */
export declare const RoutingSubdomain: import("alchemy").ResourceClass<RoutingSubdomain>;
/**
 * Returns true if the given value is a RoutingSubdomain resource.
 */
export declare const isRoutingSubdomain: (value: unknown) => value is RoutingSubdomain;
export declare const RoutingSubdomainProvider: () => import("effect/Layer").Layer<Provider.Provider<RoutingSubdomain>, never, CloudflareEnvironment | dns.CloudflareOpContext>;
export {};
//# sourceMappingURL=RoutingSubdomain.d.ts.map