import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AuthorizationErrorException_base: S.TaggedErrorClass<"AuthorizationErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AuthorizationErrorException extends /*@__PURE__*/ AuthorizationErrorException_base {
}
declare const ConflictErrorException_base: S.TaggedErrorClass<"ConflictErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictErrorException extends /*@__PURE__*/ ConflictErrorException_base {
}
declare const HomeRegionNotSetException_base: S.TaggedErrorClass<"HomeRegionNotSetException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HomeRegionNotSetException extends /*@__PURE__*/ HomeRegionNotSetException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OperationNotPermittedException_base: S.TaggedErrorClass<"OperationNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServerInternalErrorException_base: S.TaggedErrorClass<"ServerInternalErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerInternalErrorException extends /*@__PURE__*/ ServerInternalErrorException_base {
}
export type ApplicationId = string;
export type ConfigurationId = string;
export type ConfigurationIdList = string[];
export interface AssociateConfigurationItemsToApplicationRequest {
    applicationConfigurationId: string;
    configurationIds: string[];
}
export interface AssociateConfigurationItemsToApplicationResponse {
}
export type AgentId = string;
export interface DeleteAgent {
    agentId: string;
    force?: boolean | undefined;
}
export type DeleteAgents = DeleteAgent[];
export interface BatchDeleteAgentsRequest {
    deleteAgents: DeleteAgent[];
}
export type DeleteAgentErrorCode = "NOT_FOUND" | "INTERNAL_SERVER_ERROR" | "AGENT_IN_USE" | (string & {});
export interface BatchDeleteAgentError {
    agentId: string;
    errorMessage: string;
    errorCode: DeleteAgentErrorCode;
}
export type BatchDeleteAgentErrors = BatchDeleteAgentError[];
export interface BatchDeleteAgentsResponse {
    errors?: BatchDeleteAgentError[] | undefined;
}
export type ImportTaskIdentifier = string;
export type ToDeleteIdentifierList = string[];
export interface BatchDeleteImportDataRequest {
    importTaskIds: string[];
    deleteHistory?: boolean | undefined;
}
export type BatchDeleteImportDataErrorCode = "NOT_FOUND" | "INTERNAL_SERVER_ERROR" | "OVER_LIMIT" | (string & {});
export type BatchDeleteImportDataErrorDescription = string;
export interface BatchDeleteImportDataError_ {
    importTaskId?: string | undefined;
    errorCode?: BatchDeleteImportDataErrorCode | undefined;
    errorDescription?: string | undefined;
}
export type BatchDeleteImportDataErrorList = BatchDeleteImportDataError_[];
export interface BatchDeleteImportDataResponse {
    errors?: BatchDeleteImportDataError_[] | undefined;
}
export type ApplicationName = string;
export type ApplicationDescription = string;
export type ApplicationWave = string;
export interface CreateApplicationRequest {
    name: string;
    description?: string | undefined;
    wave?: string | undefined;
}
export interface CreateApplicationResponse {
    configurationId?: string | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagSet = Tag[];
export interface CreateTagsRequest {
    configurationIds: string[];
    tags: Tag[];
}
export interface CreateTagsResponse {
}
export type ApplicationIdsList = string[];
export interface DeleteApplicationsRequest {
    configurationIds: string[];
}
export interface DeleteApplicationsResponse {
}
export interface DeleteTagsRequest {
    configurationIds: string[];
    tags?: Tag[] | undefined;
}
export interface DeleteTagsResponse {
}
export type AgentIds = string[];
export type FilterValue = string;
export type FilterValues = string[];
export type Condition = string;
export interface Filter {
    name: string;
    values: string[];
    condition: string;
}
export type Filters = Filter[];
export type NextToken = string;
export interface DescribeAgentsRequest {
    agentIds?: string[] | undefined;
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentNetworkInfo {
    ipAddress?: string | undefined;
    macAddress?: string | undefined;
}
export type AgentNetworkInfoList = AgentNetworkInfo[];
export type AgentStatus = "HEALTHY" | "UNHEALTHY" | "RUNNING" | "UNKNOWN" | "BLACKLISTED" | "SHUTDOWN" | (string & {});
export interface AgentInfo {
    agentId?: string | undefined;
    hostName?: string | undefined;
    agentNetworkInfoList?: AgentNetworkInfo[] | undefined;
    connectorId?: string | undefined;
    version?: string | undefined;
    health?: AgentStatus | undefined;
    lastHealthPingTime?: string | undefined;
    collectionStatus?: string | undefined;
    agentType?: string | undefined;
    registeredTime?: string | undefined;
}
export type AgentsInfo = AgentInfo[];
export interface DescribeAgentsResponse {
    agentsInfo?: AgentInfo[] | undefined;
    nextToken?: string | undefined;
}
export type UUID = string;
export interface DescribeBatchDeleteConfigurationTaskRequest {
    taskId: string;
}
export type BatchDeleteConfigurationTaskStatus = "INITIALIZING" | "VALIDATING" | "DELETING" | "COMPLETED" | "FAILED" | (string & {});
export type DeletionConfigurationItemType = "SERVER" | (string & {});
export type ErrorStatusCode = number;
export type ErrorMessage = string;
export interface FailedConfiguration {
    configurationId?: string | undefined;
    errorStatusCode?: number | undefined;
    errorMessage?: string | undefined;
}
export type FailedConfigurationList = FailedConfiguration[];
export type WarningCode = number;
export type WarningText = string;
export interface DeletionWarning {
    configurationId?: string | undefined;
    warningCode?: number | undefined;
    warningText?: string | undefined;
}
export type DeletionWarningsList = DeletionWarning[];
export interface BatchDeleteConfigurationTask {
    taskId?: string | undefined;
    status?: BatchDeleteConfigurationTaskStatus | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    configurationType?: DeletionConfigurationItemType | undefined;
    requestedConfigurations?: string[] | undefined;
    deletedConfigurations?: string[] | undefined;
    failedConfigurations?: FailedConfiguration[] | undefined;
    deletionWarnings?: DeletionWarning[] | undefined;
}
export interface DescribeBatchDeleteConfigurationTaskResponse {
    task?: BatchDeleteConfigurationTask | undefined;
}
export interface DescribeConfigurationsRequest {
    configurationIds: string[];
}
export type DescribeConfigurationsAttribute = {
    [key: string]: string | undefined;
};
export type DescribeConfigurationsAttributes = {
    [key: string]: string | undefined;
}[];
export interface DescribeConfigurationsResponse {
    configurations?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export type ConfigurationsExportId = string;
export type ContinuousExportIds = string[];
export type DescribeContinuousExportsMaxResults = number;
export interface DescribeContinuousExportsRequest {
    exportIds?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ContinuousExportStatus = "START_IN_PROGRESS" | "START_FAILED" | "ACTIVE" | "ERROR" | "STOP_IN_PROGRESS" | "STOP_FAILED" | "INACTIVE" | (string & {});
export type StringMax255 = string;
export type S3Bucket = string;
export type DataSource = "AGENT" | (string & {});
export type DatabaseName = string;
export type SchemaStorageConfig = {
    [key: string]: string | undefined;
};
export interface ContinuousExportDescription {
    exportId?: string | undefined;
    status?: ContinuousExportStatus | undefined;
    statusDetail?: string | undefined;
    s3Bucket?: string | undefined;
    startTime?: Date | undefined;
    stopTime?: Date | undefined;
    dataSource?: DataSource | undefined;
    schemaStorageConfig?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ContinuousExportDescriptions = ContinuousExportDescription[];
export interface DescribeContinuousExportsResponse {
    descriptions?: ContinuousExportDescription[] | undefined;
    nextToken?: string | undefined;
}
export type ExportIds = string[];
export interface DescribeExportConfigurationsRequest {
    exportIds?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ExportStatus = "FAILED" | "SUCCEEDED" | "IN_PROGRESS" | (string & {});
export type ExportStatusMessage = string;
export type ConfigurationsDownloadUrl = string;
export type ExportRequestTime = Date;
export interface ExportInfo {
    exportId: string;
    exportStatus: ExportStatus;
    statusMessage: string;
    configurationsDownloadUrl?: string | undefined;
    exportRequestTime: Date;
    isTruncated?: boolean | undefined;
    requestedStartTime?: Date | undefined;
    requestedEndTime?: Date | undefined;
}
export type ExportsInfo = ExportInfo[];
export interface DescribeExportConfigurationsResponse {
    exportsInfo?: ExportInfo[] | undefined;
    nextToken?: string | undefined;
}
export type FilterName = string;
export interface ExportFilter {
    name: string;
    values: string[];
    condition: string;
}
export type ExportFilters = ExportFilter[];
export interface DescribeExportTasksRequest {
    exportIds?: string[] | undefined;
    filters?: ExportFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DescribeExportTasksResponse {
    exportsInfo?: ExportInfo[] | undefined;
    nextToken?: string | undefined;
}
export type ImportTaskFilterName = "IMPORT_TASK_ID" | "STATUS" | "NAME" | "FILE_CLASSIFICATION" | (string & {});
export type ImportTaskFilterValue = string;
export type ImportTaskFilterValueList = string[];
export interface ImportTaskFilter {
    name?: ImportTaskFilterName | undefined;
    values?: string[] | undefined;
}
export type DescribeImportTasksFilterList = ImportTaskFilter[];
export type DescribeImportTasksMaxResults = number;
export interface DescribeImportTasksRequest {
    filters?: ImportTaskFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ClientRequestToken = string;
export type ImportTaskName = string;
export type ImportURL = string;
export type ImportStatus = "IMPORT_IN_PROGRESS" | "IMPORT_COMPLETE" | "IMPORT_COMPLETE_WITH_ERRORS" | "IMPORT_FAILED" | "IMPORT_FAILED_SERVER_LIMIT_EXCEEDED" | "IMPORT_FAILED_RECORD_LIMIT_EXCEEDED" | "IMPORT_FAILED_UNSUPPORTED_FILE_TYPE" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "DELETE_FAILED_LIMIT_EXCEEDED" | "INTERNAL_ERROR" | (string & {});
export type FileClassification = "MODELIZEIT_EXPORT" | "RVTOOLS_EXPORT" | "VMWARE_NSX_EXPORT" | "IMPORT_TEMPLATE" | (string & {});
export type S3PresignedUrl = string;
export interface ImportTask {
    importTaskId?: string | undefined;
    clientRequestToken?: string | undefined;
    name?: string | undefined;
    importUrl?: string | undefined;
    status?: ImportStatus | undefined;
    importRequestTime?: Date | undefined;
    importCompletionTime?: Date | undefined;
    importDeletedTime?: Date | undefined;
    fileClassification?: FileClassification | undefined;
    serverImportSuccess?: number | undefined;
    serverImportFailure?: number | undefined;
    applicationImportSuccess?: number | undefined;
    applicationImportFailure?: number | undefined;
    errorsAndFailedEntriesZip?: string | undefined;
}
export type ImportTaskList = ImportTask[];
export interface DescribeImportTasksResponse {
    nextToken?: string | undefined;
    tasks?: ImportTask[] | undefined;
}
export interface TagFilter {
    name: string;
    values: string[];
}
export type TagFilters = TagFilter[];
export interface DescribeTagsRequest {
    filters?: TagFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ConfigurationItemType = "SERVER" | "PROCESS" | "CONNECTION" | "APPLICATION" | (string & {});
export interface ConfigurationTag {
    configurationType?: ConfigurationItemType | undefined;
    configurationId?: string | undefined;
    key?: string | undefined;
    value?: string | undefined;
    timeOfCreation?: Date | undefined;
}
export type ConfigurationTagSet = ConfigurationTag[];
export interface DescribeTagsResponse {
    tags?: ConfigurationTag[] | undefined;
    nextToken?: string | undefined;
}
export interface DisassociateConfigurationItemsFromApplicationRequest {
    applicationConfigurationId: string;
    configurationIds: string[];
}
export interface DisassociateConfigurationItemsFromApplicationResponse {
}
export interface ExportConfigurationsRequest {
}
export interface ExportConfigurationsResponse {
    exportId?: string | undefined;
}
export interface GetDiscoverySummaryRequest {
}
export interface CustomerAgentInfo {
    activeAgents: number;
    healthyAgents: number;
    blackListedAgents: number;
    shutdownAgents: number;
    unhealthyAgents: number;
    totalAgents: number;
    unknownAgents: number;
}
export interface CustomerConnectorInfo {
    activeConnectors: number;
    healthyConnectors: number;
    blackListedConnectors: number;
    shutdownConnectors: number;
    unhealthyConnectors: number;
    totalConnectors: number;
    unknownConnectors: number;
}
export interface CustomerMeCollectorInfo {
    activeMeCollectors: number;
    healthyMeCollectors: number;
    denyListedMeCollectors: number;
    shutdownMeCollectors: number;
    unhealthyMeCollectors: number;
    totalMeCollectors: number;
    unknownMeCollectors: number;
}
export interface CustomerAgentlessCollectorInfo {
    activeAgentlessCollectors: number;
    healthyAgentlessCollectors: number;
    denyListedAgentlessCollectors: number;
    shutdownAgentlessCollectors: number;
    unhealthyAgentlessCollectors: number;
    totalAgentlessCollectors: number;
    unknownAgentlessCollectors: number;
}
export interface GetDiscoverySummaryResponse {
    servers?: number | undefined;
    applications?: number | undefined;
    serversMappedToApplications?: number | undefined;
    serversMappedtoTags?: number | undefined;
    agentSummary?: CustomerAgentInfo | undefined;
    connectorSummary?: CustomerConnectorInfo | undefined;
    meCollectorSummary?: CustomerMeCollectorInfo | undefined;
    agentlessCollectorSummary?: CustomerAgentlessCollectorInfo | undefined;
}
export type OrderByElementFieldName = string;
export type OrderString = "ASC" | "DESC" | (string & {});
export interface OrderByElement {
    fieldName: string;
    sortOrder?: OrderString | undefined;
}
export type OrderByList = OrderByElement[];
export interface ListConfigurationsRequest {
    configurationType: ConfigurationItemType;
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    orderBy?: OrderByElement[] | undefined;
}
export type Configuration = {
    [key: string]: string | undefined;
};
export type Configurations = {
    [key: string]: string | undefined;
}[];
export interface ListConfigurationsResponse {
    configurations?: {
        [key: string]: string | undefined;
    }[] | undefined;
    nextToken?: string | undefined;
}
export interface ListServerNeighborsRequest {
    configurationId: string;
    portInformationNeeded?: boolean | undefined;
    neighborConfigurationIds?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type BoxedInteger = number;
export interface NeighborConnectionDetail {
    sourceServerId: string;
    destinationServerId: string;
    destinationPort?: number | undefined;
    transportProtocol?: string | undefined;
    connectionsCount: number;
}
export type NeighborDetailsList = NeighborConnectionDetail[];
export interface ListServerNeighborsResponse {
    neighbors: NeighborConnectionDetail[];
    nextToken?: string | undefined;
    knownDependencyCount?: number | undefined;
}
export interface StartBatchDeleteConfigurationTaskRequest {
    configurationType: DeletionConfigurationItemType;
    configurationIds: string[];
}
export interface StartBatchDeleteConfigurationTaskResponse {
    taskId?: string | undefined;
}
export interface StartContinuousExportRequest {
}
export interface StartContinuousExportResponse {
    exportId?: string | undefined;
    s3Bucket?: string | undefined;
    startTime?: Date | undefined;
    dataSource?: DataSource | undefined;
    schemaStorageConfig?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartDataCollectionByAgentIdsRequest {
    agentIds: string[];
}
export interface AgentConfigurationStatus {
    agentId?: string | undefined;
    operationSucceeded?: boolean | undefined;
    description?: string | undefined;
}
export type AgentConfigurationStatusList = AgentConfigurationStatus[];
export interface StartDataCollectionByAgentIdsResponse {
    agentsConfigurationStatus?: AgentConfigurationStatus[] | undefined;
}
export type ExportDataFormat = "CSV" | (string & {});
export type ExportDataFormats = ExportDataFormat[];
export type ExportEnabled = boolean;
export type UsageMetricBasisName = string;
export type UsageMetricPercentageAdjust = number;
export interface UsageMetricBasis {
    name?: string | undefined;
    percentageAdjust?: number | undefined;
}
export type Tenancy = "DEDICATED" | "SHARED" | (string & {});
export type EC2InstanceType = string;
export type ExcludedInstanceTypes = string[];
export type UserPreferredRegion = string;
export type PurchasingOption = "ALL_UPFRONT" | "PARTIAL_UPFRONT" | "NO_UPFRONT" | (string & {});
export type OfferingClass = "STANDARD" | "CONVERTIBLE" | (string & {});
export type TermLength = "ONE_YEAR" | "THREE_YEAR" | (string & {});
export interface ReservedInstanceOptions {
    purchasingOption: PurchasingOption;
    offeringClass: OfferingClass;
    termLength: TermLength;
}
export interface Ec2RecommendationsExportPreferences {
    enabled?: boolean | undefined;
    cpuPerformanceMetricBasis?: UsageMetricBasis | undefined;
    ramPerformanceMetricBasis?: UsageMetricBasis | undefined;
    tenancy?: Tenancy | undefined;
    excludedInstanceTypes?: string[] | undefined;
    preferredRegion?: string | undefined;
    reservedInstanceOptions?: ReservedInstanceOptions | undefined;
}
export type ExportPreferences = {
    ec2RecommendationsPreferences: Ec2RecommendationsExportPreferences;
};
export interface StartExportTaskRequest {
    exportDataFormat?: ExportDataFormat[] | undefined;
    filters?: ExportFilter[] | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    preferences?: ExportPreferences | undefined;
}
export interface StartExportTaskResponse {
    exportId?: string | undefined;
}
export interface StartImportTaskRequest {
    clientRequestToken?: string | undefined;
    name: string;
    importUrl: string;
}
export interface StartImportTaskResponse {
    task?: ImportTask | undefined;
}
export interface StopContinuousExportRequest {
    exportId: string;
}
export interface StopContinuousExportResponse {
    startTime?: Date | undefined;
    stopTime?: Date | undefined;
}
export interface StopDataCollectionByAgentIdsRequest {
    agentIds: string[];
}
export interface StopDataCollectionByAgentIdsResponse {
    agentsConfigurationStatus?: AgentConfigurationStatus[] | undefined;
}
export interface UpdateApplicationRequest {
    configurationId: string;
    name?: string | undefined;
    description?: string | undefined;
    wave?: string | undefined;
}
export interface UpdateApplicationResponse {
}
export type Message = string;
export type AssociateConfigurationItemsToApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Associates one or more configuration items with an application.
 */
export declare const associateConfigurationItemsToApplication: API.OperationMethod<AssociateConfigurationItemsToApplicationRequest & RegionInput, AssociateConfigurationItemsToApplicationResponse, AssociateConfigurationItemsToApplicationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteAgentsError = AuthorizationErrorException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes one or more agents or collectors as specified by ID. Deleting an agent or collector does not
 * delete the previously discovered data.
 * To delete the data collected, use `StartBatchDeleteConfigurationTask`.
 */
export declare const batchDeleteAgents: API.OperationMethod<BatchDeleteAgentsRequest & RegionInput, BatchDeleteAgentsResponse, BatchDeleteAgentsError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteImportDataError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes one or more import tasks, each identified by their import ID. Each import task has
 * a number of records that can identify servers or applications.
 *
 * Amazon Web Services Application Discovery Service has built-in matching logic that will identify when
 * discovered servers match existing entries that you've previously discovered, the information
 * for the already-existing discovered server is updated. When you delete an import task that
 * contains records that were used to match, the information in those matched records that comes
 * from the deleted records will also be deleted.
 */
export declare const batchDeleteImportData: API.OperationMethod<BatchDeleteImportDataRequest & RegionInput, BatchDeleteImportDataResponse, BatchDeleteImportDataError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Creates an application with the given name and description.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Creates one or more tags for configuration items. Tags are metadata that help you
 * categorize IT assets. This API accepts a list of multiple configuration items.
 *
 * Do not store sensitive information (like personal data) in tags.
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest & RegionInput, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes a list of applications and their associations with configuration
 * items.
 */
export declare const deleteApplications: API.OperationMethod<DeleteApplicationsRequest & RegionInput, DeleteApplicationsResponse, DeleteApplicationsError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Deletes the association between configuration items and one or more tags. This API
 * accepts a list of multiple configuration items.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest & RegionInput, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeAgentsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Lists agents or collectors as specified by ID or other filters. All agents/collectors
 * associated with your user can be listed if you call `DescribeAgents` as is
 * without passing any parameters.
 */
export declare const describeAgents: API.PaginatedOperationMethod<DescribeAgentsRequest & RegionInput, DescribeAgentsResponse, DescribeAgentsError, Credentials | HttpClient.HttpClient, AgentInfo>;
export type DescribeBatchDeleteConfigurationTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Takes a unique deletion task identifier as input and returns metadata about a configuration deletion task.
 */
export declare const describeBatchDeleteConfigurationTask: API.OperationMethod<DescribeBatchDeleteConfigurationTaskRequest & RegionInput, DescribeBatchDeleteConfigurationTaskResponse, DescribeBatchDeleteConfigurationTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves attributes for a list of configuration item IDs.
 *
 * All of the supplied IDs must be for the same asset type from one of the
 * following:
 *
 * - server
 *
 * - application
 *
 * - process
 *
 * - connection
 *
 * Output fields are specific to the asset type specified. For example, the output for a
 * *server* configuration item includes a list of attributes about the
 * server, such as host name, operating system, number of network cards, etc.
 *
 * For a complete list of outputs for each asset type, see Using the DescribeConfigurations Action in the Amazon Web Services Application
 * Discovery Service User Guide.
 */
export declare const describeConfigurations: API.OperationMethod<DescribeConfigurationsRequest & RegionInput, DescribeConfigurationsResponse, DescribeConfigurationsError, Credentials | HttpClient.HttpClient>;
export type DescribeContinuousExportsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Lists exports as specified by ID. All continuous exports associated with your user
 * can be listed if you call `DescribeContinuousExports` as is without passing
 * any parameters.
 */
export declare const describeContinuousExports: API.PaginatedOperationMethod<DescribeContinuousExportsRequest & RegionInput, DescribeContinuousExportsResponse, DescribeContinuousExportsError, Credentials | HttpClient.HttpClient, ContinuousExportDescription>;
export type DescribeExportConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * `DescribeExportConfigurations` is deprecated. Use DescribeExportTasks, instead.
 */
export declare const describeExportConfigurations: API.PaginatedOperationMethod<DescribeExportConfigurationsRequest & RegionInput, DescribeExportConfigurationsResponse, DescribeExportConfigurationsError, Credentials | HttpClient.HttpClient, ExportInfo>;
export type DescribeExportTasksError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieve status of one or more export tasks. You can retrieve the status of up to 100
 * export tasks.
 */
export declare const describeExportTasks: API.PaginatedOperationMethod<DescribeExportTasksRequest & RegionInput, DescribeExportTasksResponse, DescribeExportTasksError, Credentials | HttpClient.HttpClient, ExportInfo>;
export type DescribeImportTasksError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Returns an array of import tasks for your account, including status information, times,
 * IDs, the Amazon S3 Object URL for the import file, and more.
 */
export declare const describeImportTasks: API.PaginatedOperationMethod<DescribeImportTasksRequest & RegionInput, DescribeImportTasksResponse, DescribeImportTasksError, Credentials | HttpClient.HttpClient, ImportTask>;
export type DescribeTagsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a list of configuration items that have tags as specified by the key-value
 * pairs, name and value, passed to the optional parameter `filters`.
 *
 * There are three valid tag filter names:
 *
 * - tagKey
 *
 * - tagValue
 *
 * - configurationId
 *
 * Also, all configuration items associated with your user that have tags can be
 * listed if you call `DescribeTags` as is without passing any parameters.
 */
export declare const describeTags: API.PaginatedOperationMethod<DescribeTagsRequest & RegionInput, DescribeTagsResponse, DescribeTagsError, Credentials | HttpClient.HttpClient, ConfigurationTag>;
export type DisassociateConfigurationItemsFromApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Disassociates one or more configuration items from an application.
 */
export declare const disassociateConfigurationItemsFromApplication: API.OperationMethod<DisassociateConfigurationItemsFromApplicationRequest & RegionInput, DisassociateConfigurationItemsFromApplicationResponse, DisassociateConfigurationItemsFromApplicationError, Credentials | HttpClient.HttpClient>;
export type ExportConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ServerInternalErrorException | CommonErrors;
/**
 * Deprecated. Use `StartExportTask` instead.
 *
 * Exports all discovered configuration data to an Amazon S3 bucket or an application that
 * enables you to view and evaluate the data. Data includes tags and tag associations, processes,
 * connections, servers, and system performance. This API returns an export ID that you can query
 * using the *DescribeExportConfigurations* API. The system imposes a limit of
 * two configuration exports in six hours.
 */
export declare const exportConfigurations: API.OperationMethod<ExportConfigurationsRequest & RegionInput, ExportConfigurationsResponse, ExportConfigurationsError, Credentials | HttpClient.HttpClient>;
export type GetDiscoverySummaryError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a short summary of discovered assets.
 *
 * This API operation takes no request parameters and is called as is at the command
 * prompt as shown in the example.
 */
export declare const getDiscoverySummary: API.OperationMethod<GetDiscoverySummaryRequest & RegionInput, GetDiscoverySummaryResponse, GetDiscoverySummaryError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a list of configuration items as specified by the value passed to the
 * required parameter `configurationType`. Optional filtering may be applied to refine
 * search results.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest & RegionInput, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient, {
    [key: string]: string | undefined;
}>;
export type ListServerNeighborsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Retrieves a list of servers that are one network hop away from a specified
 * server.
 */
export declare const listServerNeighbors: API.OperationMethod<ListServerNeighborsRequest & RegionInput, ListServerNeighborsResponse, ListServerNeighborsError, Credentials | HttpClient.HttpClient>;
export type StartBatchDeleteConfigurationTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | LimitExceededException | OperationNotPermittedException | ServerInternalErrorException | CommonErrors;
/**
 * Takes a list of configurationId as input and starts an asynchronous deletion
 * task to remove the configurationItems. Returns a unique deletion task identifier.
 */
export declare const startBatchDeleteConfigurationTask: API.OperationMethod<StartBatchDeleteConfigurationTaskRequest & RegionInput, StartBatchDeleteConfigurationTaskResponse, StartBatchDeleteConfigurationTaskError, Credentials | HttpClient.HttpClient>;
export type StartContinuousExportError = AuthorizationErrorException | ConflictErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ResourceInUseException | ServerInternalErrorException | CommonErrors;
/**
 * Start the continuous flow of agent's discovered data into Amazon Athena.
 */
export declare const startContinuousExport: API.OperationMethod<StartContinuousExportRequest & RegionInput, StartContinuousExportResponse, StartContinuousExportError, Credentials | HttpClient.HttpClient>;
export type StartDataCollectionByAgentIdsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Instructs the specified agents to start collecting data.
 */
export declare const startDataCollectionByAgentIds: API.OperationMethod<StartDataCollectionByAgentIdsRequest & RegionInput, StartDataCollectionByAgentIdsResponse, StartDataCollectionByAgentIdsError, Credentials | HttpClient.HttpClient>;
export type StartExportTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ServerInternalErrorException | CommonErrors;
/**
 * Begins the export of a discovered data report to an Amazon S3 bucket managed by Amazon Web Services.
 *
 * Exports might provide an estimate of fees and savings based on certain information
 * that you provide. Fee estimates do not include any taxes that might apply.
 * Your actual fees and savings depend on a variety of factors, including your actual usage of Amazon Web Services
 * services, which might vary from the estimates provided in this report.
 *
 * If you do not specify `preferences` or `agentIds` in the filter, a
 * summary of all servers, applications, tags, and performance is generated. This data is an
 * aggregation of all server data collected through on-premises tooling, file import, application
 * grouping and applying tags.
 *
 * If you specify `agentIds` in a filter, the task exports up to 72 hours of
 * detailed data collected by the identified Application Discovery Agent, including network,
 * process, and performance details. A time range for exported agent data may be set by using
 * `startTime` and `endTime`. Export of detailed agent data is limited to
 * five concurrently running exports.
 * Export of detailed agent data is limited to two exports per day.
 *
 * If you enable `ec2RecommendationsPreferences` in `preferences`
 * , an
 * Amazon EC2 instance matching the characteristics of each server in Application Discovery Service is generated.
 * Changing the attributes of the `ec2RecommendationsPreferences` changes the
 * criteria of the recommendation.
 */
export declare const startExportTask: API.OperationMethod<StartExportTaskRequest & RegionInput, StartExportTaskResponse, StartExportTaskError, Credentials | HttpClient.HttpClient>;
export type StartImportTaskError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ResourceInUseException | ServerInternalErrorException | CommonErrors;
/**
 * Starts an import task, which allows you to import details of your on-premises environment
 * directly into Amazon Web Services Migration Hub without having to use the Amazon Web Services Application Discovery
 * Service (Application Discovery Service) tools such as the Amazon Web Services Application Discovery Service Agentless Collector
 * or Application Discovery Agent. This gives you the option to
 * perform migration assessment and planning directly from your imported data, including the
 * ability to group your devices as applications and track their migration status.
 *
 * To start an import request, do this:
 *
 * - Download the specially formatted comma separated value (CSV) import template, which
 * you can find here: https://s3.us-west-2.amazonaws.com/templates-7cffcf56-bd96-4b1c-b45b-a5b42f282e46/import_template.csv.
 *
 * - Fill out the template with your server and application data.
 *
 * - Upload your import file to an Amazon S3 bucket, and make a note of it's Object URL.
 * Your import file must be in the CSV format.
 *
 * - Use the console or the `StartImportTask` command with the Amazon Web Services CLI or one
 * of the Amazon Web Services SDKs to import the records from your file.
 *
 * For more information, including step-by-step procedures, see Migration Hub
 * Import in the Amazon Web Services Application Discovery Service User
 * Guide.
 *
 * There are limits to the number of import tasks you can create (and delete) in an Amazon Web Services
 * account. For more information, see Amazon Web Services Application
 * Discovery Service Limits in the Amazon Web Services Application Discovery Service User
 * Guide.
 */
export declare const startImportTask: API.OperationMethod<StartImportTaskRequest & RegionInput, StartImportTaskResponse, StartImportTaskError, Credentials | HttpClient.HttpClient>;
export type StopContinuousExportError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | ServerInternalErrorException | CommonErrors;
/**
 * Stop the continuous flow of agent's discovered data into Amazon Athena.
 */
export declare const stopContinuousExport: API.OperationMethod<StopContinuousExportRequest & RegionInput, StopContinuousExportResponse, StopContinuousExportError, Credentials | HttpClient.HttpClient>;
export type StopDataCollectionByAgentIdsError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Instructs the specified agents to stop collecting data.
 */
export declare const stopDataCollectionByAgentIds: API.OperationMethod<StopDataCollectionByAgentIdsRequest & RegionInput, StopDataCollectionByAgentIdsResponse, StopDataCollectionByAgentIdsError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AuthorizationErrorException | HomeRegionNotSetException | InvalidParameterException | InvalidParameterValueException | ServerInternalErrorException | CommonErrors;
/**
 * Updates metadata about an application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-discovery-service.d.ts.map