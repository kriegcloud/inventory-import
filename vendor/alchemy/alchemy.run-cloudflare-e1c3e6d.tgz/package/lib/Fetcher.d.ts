import type * as cf from "@cloudflare/workers-types";
import { type TcpSocket } from "alchemy/Workers/Workerd/Socket";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import { HttpClientError } from "effect/http/HttpClientError";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import * as HttpClientResponse from "effect/http/HttpClientResponse";
import type { HttpServerError } from "effect/http/HttpServerError";
import * as HttpServerRequest from "effect/http/HttpServerRequest";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
export type { TcpSocket } from "alchemy/Workers/Workerd/Socket";
export type SocketAddress = cf.SocketAddress;
export type SocketOptions = cf.SocketOptions;
export interface Fetcher {
    raw: cf.Fetcher;
    fetch(request: HttpClientRequest.HttpClientRequest): Effect.Effect<HttpClientResponse.HttpClientResponse, HttpClientError>;
    fetch(request: HttpServerRequest.HttpServerRequest): Effect.Effect<HttpServerResponse.HttpServerResponse, HttpServerError>;
    connect(address: SocketAddress | string, options?: SocketOptions): TcpSocket;
}
export declare const toCloudflareFetcher: (fetcher: Fetcher) => Effect.Effect<{
    fetch: (input: cf.URL | cf.RequestInfo<unknown, cf.CfProperties<unknown>>, init: cf.RequestInit<cf.CfProperties<unknown>> | undefined) => Promise<cf.Response>;
    connect(): never;
}, never, never>;
export declare const fromCloudflareFetcher: (fetcher: cf.Fetcher | globalThis.Fetcher) => Fetcher;
export declare const toHttpClient: (fetcher: {
    fetch: (request: HttpServerRequest.HttpServerRequest) => Effect.Effect<HttpServerResponse.HttpServerResponse, HttpServerError>;
}) => HttpClient.HttpClient;
/**
 * Wrap a workerd `Socket` as an Effect socket that keeps the native one on
 * `raw`. See {@link TcpSocket}.
 */
export declare const fromCloudflareSocket: (cfSocket: globalThis.Socket | cf.Socket) => TcpSocket;
//# sourceMappingURL=Fetcher.d.ts.map