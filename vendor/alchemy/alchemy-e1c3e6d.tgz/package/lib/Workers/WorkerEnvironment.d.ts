import * as Context from "effect/Context";
declare const WorkerEnvironment_base: Context.ServiceClass<WorkerEnvironment, "Cloudflare.Workers.WorkerEnvironment", Record<string, any>>;
/**
 * The runtime environment record the worker was deployed with — workerd's
 * `env` object.
 */
export declare class WorkerEnvironment extends WorkerEnvironment_base {
}
export {};
//# sourceMappingURL=WorkerEnvironment.d.ts.map