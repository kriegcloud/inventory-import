import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const EksClusterConnectionUpdating_base: S.TaggedErrorClass<"EksClusterConnectionUpdating", {
    readonly message: any;
}>;
export declare class EksClusterConnectionUpdating extends /*@__PURE__*/ EksClusterConnectionUpdating_base {
}
declare const EKSRequestThrottledException_base: S.TaggedErrorClass<"EKSRequestThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class EKSRequestThrottledException extends /*@__PURE__*/ EKSRequestThrottledException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidResourceArn_base: S.TaggedErrorClass<"InvalidResourceArn", {
    readonly message: any;
}>;
export declare class InvalidResourceArn extends /*@__PURE__*/ InvalidResourceArn_base {
}
declare const RequestThrottledException_base: S.TaggedErrorClass<"RequestThrottledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestThrottledException extends /*@__PURE__*/ RequestThrottledException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceIdString = string;
export interface CancelJobRunRequest {
    id: string;
    virtualClusterId: string;
}
export interface CancelJobRunResponse {
    id?: string | undefined;
    virtualClusterId?: string | undefined;
}
export type ResourceNameString = string;
export type ClientToken = string;
export type ParametricIAMRoleArn = string;
export type ParametricReleaseLabel = string;
export type String1024 = string;
export type SensitivePropertiesMap = {
    [key: string]: string | undefined;
};
export interface Configuration {
    classification: string;
    properties?: {
        [key: string]: string | undefined;
    } | undefined;
    configurations?: Configuration[] | undefined;
}
export type ConfigurationList = Configuration[];
export type TemplateParameter = string;
export type String256 = string;
export interface ParametricCloudWatchMonitoringConfiguration {
    logGroupName?: string | undefined;
    logStreamNamePrefix?: string | undefined;
}
export type UriString = string;
export interface ParametricS3MonitoringConfiguration {
    logUri?: string | undefined;
}
export interface ParametricMonitoringConfiguration {
    persistentAppUI?: string | undefined;
    cloudWatchMonitoringConfiguration?: ParametricCloudWatchMonitoringConfiguration | undefined;
    s3MonitoringConfiguration?: ParametricS3MonitoringConfiguration | undefined;
}
export interface ParametricConfigurationOverrides {
    applicationConfiguration?: Configuration[] | undefined;
    monitoringConfiguration?: ParametricMonitoringConfiguration | undefined;
}
export type EntryPointPath = string | redacted.Redacted<string>;
export type EntryPointArgument = string | redacted.Redacted<string>;
export type EntryPointArguments = (string | redacted.Redacted<string>)[];
export type SparkSubmitParameters = string | redacted.Redacted<string>;
export interface SparkSubmitJobDriver {
    entryPoint: string | redacted.Redacted<string>;
    entryPointArguments?: (string | redacted.Redacted<string>)[] | undefined;
    sparkSubmitParameters?: string | redacted.Redacted<string> | undefined;
}
export type SparkSqlParameters = string | redacted.Redacted<string>;
export interface SparkSqlJobDriver {
    entryPoint?: string | redacted.Redacted<string> | undefined;
    sparkSqlParameters?: string | redacted.Redacted<string> | undefined;
}
export interface JobDriver {
    sparkSubmitJobDriver?: SparkSubmitJobDriver | undefined;
    sparkSqlJobDriver?: SparkSqlJobDriver | undefined;
}
export type TemplateParameterName = string;
export type TemplateParameterDataType = "NUMBER" | "STRING" | (string & {});
export interface TemplateParameterConfiguration {
    type?: TemplateParameterDataType | undefined;
    defaultValue?: string | undefined;
}
export type TemplateParameterConfigurationMap = {
    [key: string]: TemplateParameterConfiguration | undefined;
};
export type String128 = string;
export type StringEmpty256 = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface JobTemplateData {
    executionRoleArn: string;
    releaseLabel: string;
    configurationOverrides?: ParametricConfigurationOverrides | undefined;
    jobDriver: JobDriver;
    parameterConfiguration?: {
        [key: string]: TemplateParameterConfiguration | undefined;
    } | undefined;
    jobTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type KmsKeyArn = string;
export interface CreateJobTemplateRequest {
    name: string;
    clientToken: string;
    jobTemplateData: JobTemplateData;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
}
export type JobTemplateArn = string;
export interface CreateJobTemplateResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
}
export type EndpointType = string;
export type ReleaseLabel = string;
export type IAMRoleArn = string;
export type ACMCertArn = string;
export type AllowAWSToRetainLogs = "ENABLED" | "DISABLED" | (string & {});
export interface ManagedLogs {
    allowAWSToRetainLogs?: AllowAWSToRetainLogs | undefined;
    encryptionKeyArn?: string | undefined;
}
export type PersistentAppUI = "ENABLED" | "DISABLED" | (string & {});
export type LogGroupName = string;
export interface CloudWatchMonitoringConfiguration {
    logGroupName: string;
    logStreamNamePrefix?: string | undefined;
}
export interface S3MonitoringConfiguration {
    logUri: string;
    encryptionKeyArn?: string | undefined;
}
export type RotationSize = string;
export type MaxFilesToKeep = number;
export interface ContainerLogRotationConfiguration {
    rotationSize: string;
    maxFilesToKeep: number;
}
export interface MonitoringConfiguration {
    managedLogs?: ManagedLogs | undefined;
    persistentAppUI?: PersistentAppUI | undefined;
    cloudWatchMonitoringConfiguration?: CloudWatchMonitoringConfiguration | undefined;
    s3MonitoringConfiguration?: S3MonitoringConfiguration | undefined;
    containerLogRotationConfiguration?: ContainerLogRotationConfiguration | undefined;
}
export interface ConfigurationOverrides {
    applicationConfiguration?: Configuration[] | undefined;
    monitoringConfiguration?: MonitoringConfiguration | undefined;
}
export type SessionIdleTimeoutInMinutes = number;
export interface CreateManagedEndpointRequest {
    name: string;
    virtualClusterId: string;
    type: string;
    releaseLabel: string;
    executionRoleArn: string;
    certificateArn?: string | undefined;
    configurationOverrides?: ConfigurationOverrides | undefined;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    sessionIdleTimeoutInMinutes?: number | undefined;
}
export type EndpointArn = string;
export interface CreateManagedEndpointResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    virtualClusterId?: string | undefined;
}
export type ContainerProviderType = "EKS" | (string & {});
export type ClusterId = string;
export type KubernetesNamespace = string;
export type NodeLabelString = string;
export interface EksInfo {
    namespace?: string | undefined;
    nodeLabel?: string | undefined;
}
export type ContainerInfo = {
    eksInfo: EksInfo;
};
export interface ContainerProvider {
    type: ContainerProviderType;
    id: string;
    info?: ContainerInfo | undefined;
}
export type SessionTagValue = string;
export interface SecureNamespaceInfo {
    clusterId?: string | undefined;
    namespace?: string | undefined;
}
export interface LakeFormationConfiguration {
    authorizedSessionTagValue?: string | undefined;
    secureNamespaceInfo?: SecureNamespaceInfo | undefined;
    queryEngineRoleArn?: string | undefined;
}
export type CertificateProviderType = "PEM" | (string & {});
export type SecretsManagerArn = string;
export interface TLSCertificateConfiguration {
    certificateProviderType?: CertificateProviderType | undefined;
    publicCertificateSecretArn?: string | undefined;
    privateCertificateSecretArn?: string | undefined;
}
export interface InTransitEncryptionConfiguration {
    tlsCertificateConfiguration?: TLSCertificateConfiguration | undefined;
}
export interface EncryptionConfiguration {
    inTransitEncryptionConfiguration?: InTransitEncryptionConfiguration | undefined;
}
export interface AuthorizationConfiguration {
    lakeFormationConfiguration?: LakeFormationConfiguration | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
}
export type IdentityCenterInstanceARN = string;
export type EmrIdentityCenterApplicationARN = string;
export interface IdentityCenterConfiguration {
    enableIdentityCenter?: boolean | undefined;
    identityCenterApplicationAssignmentRequired?: boolean | undefined;
    identityCenterInstanceARN?: string | undefined;
    emrIdentityCenterApplicationARN?: string | undefined;
}
export interface IAMConfiguration {
    systemRole?: string | undefined;
}
export interface AuthenticationConfiguration {
    identityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    iamConfiguration?: IAMConfiguration | undefined;
}
export interface SecurityConfigurationData {
    authorizationConfiguration?: AuthorizationConfiguration | undefined;
    authenticationConfiguration?: AuthenticationConfiguration | undefined;
}
export interface CreateSecurityConfigurationRequest {
    clientToken: string;
    name: string;
    containerProvider?: ContainerProvider | undefined;
    securityConfigurationData: SecurityConfigurationData;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SecurityConfigurationArn = string;
export interface CreateSecurityConfigurationResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
}
export type InQueueJobLimitInteger = number;
export type JobLimitInteger = number;
export interface SchedulerConfiguration {
    maxInQueueJobRuns?: number | undefined;
    maxConcurrentJobRuns?: number | undefined;
}
export interface CreateVirtualClusterRequest {
    name: string;
    containerProvider: ContainerProvider;
    clientToken: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    securityConfigurationId?: string | undefined;
    sessionEnabled?: boolean | undefined;
    schedulerConfiguration?: SchedulerConfiguration | undefined;
}
export type VirtualClusterArn = string;
export interface CreateVirtualClusterResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
}
export interface DeleteJobTemplateRequest {
    id: string;
}
export interface DeleteJobTemplateResponse {
    id?: string | undefined;
}
export interface DeleteManagedEndpointRequest {
    id: string;
    virtualClusterId: string;
}
export interface DeleteManagedEndpointResponse {
    id?: string | undefined;
    virtualClusterId?: string | undefined;
}
export interface DeleteSecurityConfigurationRequest {
    id: string;
}
export interface DeleteSecurityConfigurationResponse {
    id?: string | undefined;
}
export interface DeleteVirtualClusterRequest {
    id: string;
}
export interface DeleteVirtualClusterResponse {
    id?: string | undefined;
}
export interface DescribeJobRunRequest {
    id: string;
    virtualClusterId: string;
}
export type JobArn = string;
export type JobRunState = "PENDING" | "SUBMITTED" | "RUNNING" | "FAILED" | "CANCELLED" | "CANCEL_PENDING" | "COMPLETED" | (string & {});
export type RequestIdentityUserArn = string;
export type FailureReason = "INTERNAL_ERROR" | "USER_ERROR" | "VALIDATION_ERROR" | "CLUSTER_UNAVAILABLE" | (string & {});
export type JavaInteger = number;
export interface RetryPolicyConfiguration {
    maxAttempts: number;
}
export interface RetryPolicyExecution {
    currentAttemptCount: number;
}
export interface JobRun {
    id?: string | undefined;
    name?: string | undefined;
    virtualClusterId?: string | undefined;
    arn?: string | undefined;
    state?: JobRunState | undefined;
    clientToken?: string | undefined;
    executionRoleArn?: string | undefined;
    releaseLabel?: string | undefined;
    configurationOverrides?: ConfigurationOverrides | undefined;
    jobDriver?: JobDriver | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    finishedAt?: Date | undefined;
    stateDetails?: string | undefined;
    failureReason?: FailureReason | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    retryPolicyConfiguration?: RetryPolicyConfiguration | undefined;
    retryPolicyExecution?: RetryPolicyExecution | undefined;
}
export interface DescribeJobRunResponse {
    jobRun?: JobRun | undefined;
}
export interface DescribeJobTemplateRequest {
    id: string;
}
export type String2048 = string;
export interface JobTemplate {
    name?: string | undefined;
    id?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    jobTemplateData: JobTemplateData;
    kmsKeyArn?: string | undefined;
    decryptionError?: string | undefined;
}
export interface DescribeJobTemplateResponse {
    jobTemplate?: JobTemplate | undefined;
}
export interface DescribeManagedEndpointRequest {
    id: string;
    virtualClusterId: string;
}
export type EndpointState = "CREATING" | "ACTIVE" | "TERMINATING" | "TERMINATED" | "TERMINATED_WITH_ERRORS" | (string & {});
export type Base64Encoded = string;
export interface Certificate {
    certificateArn?: string | undefined;
    certificateData?: string | undefined;
}
export type SubnetIds = string[];
export interface Endpoint {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    virtualClusterId?: string | undefined;
    type?: string | undefined;
    state?: EndpointState | undefined;
    releaseLabel?: string | undefined;
    executionRoleArn?: string | undefined;
    certificateArn?: string | undefined;
    certificateAuthority?: Certificate | undefined;
    configurationOverrides?: ConfigurationOverrides | undefined;
    serverUrl?: string | undefined;
    authProxyUrl?: string | undefined;
    createdAt?: Date | undefined;
    securityGroup?: string | undefined;
    subnetIds?: string[] | undefined;
    stateDetails?: string | undefined;
    failureReason?: FailureReason | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeManagedEndpointResponse {
    endpoint?: Endpoint | undefined;
}
export interface DescribeSecurityConfigurationRequest {
    id: string;
}
export interface SecurityConfiguration {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    securityConfigurationData?: SecurityConfigurationData | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeSecurityConfigurationResponse {
    securityConfiguration?: SecurityConfiguration | undefined;
}
export interface DescribeVirtualClusterRequest {
    id: string;
}
export type VirtualClusterState = "RUNNING" | "TERMINATING" | "TERMINATED" | "ARRESTED" | (string & {});
export type NonNegativeInteger = number;
export interface SchedulerStatus {
    currentInQueueJobRuns?: number | undefined;
    currentConcurrentJobRuns?: number | undefined;
}
export interface VirtualCluster {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    state?: VirtualClusterState | undefined;
    containerProvider?: ContainerProvider | undefined;
    createdAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    securityConfigurationId?: string | undefined;
    sessionEnabled?: boolean | undefined;
    schedulerConfiguration?: SchedulerConfiguration | undefined;
    schedulerStatus?: SchedulerStatus | undefined;
}
export interface DescribeVirtualClusterResponse {
    virtualCluster?: VirtualCluster | undefined;
}
export type CredentialType = string;
export type LogContext = string;
export interface GetManagedEndpointSessionCredentialsRequest {
    endpointIdentifier: string;
    virtualClusterIdentifier: string;
    executionRoleArn: string;
    credentialType: string;
    durationInSeconds?: number | undefined;
    logContext?: string | undefined;
    clientToken?: string | undefined;
}
export type Token = string | redacted.Redacted<string>;
export type Credentials = {
    token: string | redacted.Redacted<string>;
};
export interface GetManagedEndpointSessionCredentialsResponse {
    id?: string | undefined;
    credentials?: Credentials | undefined;
    endpointCredentials?: Credentials | undefined;
    expiresAt?: Date | undefined;
}
export type JobRunStates = JobRunState[];
export type NextToken = string;
export interface ListJobRunsRequest {
    virtualClusterId: string;
    createdBefore?: Date | undefined;
    createdAfter?: Date | undefined;
    name?: string | undefined;
    states?: JobRunState[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type JobRuns = JobRun[];
export interface ListJobRunsResponse {
    jobRuns?: JobRun[] | undefined;
    nextToken?: string | undefined;
}
export interface ListJobTemplatesRequest {
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type JobTemplates = JobTemplate[];
export interface ListJobTemplatesResponse {
    templates?: JobTemplate[] | undefined;
    nextToken?: string | undefined;
}
export type EndpointTypes = string[];
export type EndpointStates = EndpointState[];
export interface ListManagedEndpointsRequest {
    virtualClusterId: string;
    createdBefore?: Date | undefined;
    createdAfter?: Date | undefined;
    types?: string[] | undefined;
    states?: EndpointState[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Endpoints = Endpoint[];
export interface ListManagedEndpointsResponse {
    endpoints?: Endpoint[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSecurityConfigurationsRequest {
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type SecurityConfigurations = SecurityConfiguration[];
export interface ListSecurityConfigurationsResponse {
    securityConfigurations?: SecurityConfiguration[] | undefined;
    nextToken?: string | undefined;
}
export type RsiArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VirtualClusterStates = VirtualClusterState[];
export interface ListVirtualClustersRequest {
    containerProviderId?: string | undefined;
    containerProviderType?: ContainerProviderType | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    states?: VirtualClusterState[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    eksAccessEntryIntegrated?: boolean | undefined;
}
export type VirtualClusters = VirtualCluster[];
export interface ListVirtualClustersResponse {
    virtualClusters?: VirtualCluster[] | undefined;
    nextToken?: string | undefined;
}
export type TemplateParameterInputMap = {
    [key: string]: string | undefined;
};
export interface StartJobRunRequest {
    name?: string | undefined;
    virtualClusterId: string;
    clientToken: string;
    executionRoleArn?: string | undefined;
    releaseLabel?: string | undefined;
    jobDriver?: JobDriver | undefined;
    configurationOverrides?: ConfigurationOverrides | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    jobTemplateId?: string | undefined;
    jobTemplateParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    retryPolicyConfiguration?: RetryPolicyConfiguration | undefined;
}
export interface StartJobRunResponse {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    virtualClusterId?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateVirtualClusterRequest {
    id: string;
    schedulerConfiguration?: SchedulerConfiguration | undefined;
    clientToken: string;
}
export interface UpdateVirtualClusterResponse {
    virtualCluster?: VirtualCluster | undefined;
}
export type CancelJobRunError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Cancels a job run. A job run is a unit of work, such as a Spark jar, PySpark script, or
 * SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const cancelJobRun: API.OperationMethod<CancelJobRunRequest & RegionInput, CancelJobRunResponse, CancelJobRunError, Creds | HttpClient.HttpClient>;
export type CreateJobTemplateError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a job template. Job template stores values of StartJobRun API request in a
 * template and can be used to start a job run. Job template allows two use cases: avoid
 * repeating recurring StartJobRun API request values, enforcing certain values in StartJobRun
 * API request.
 */
export declare const createJobTemplate: API.OperationMethod<CreateJobTemplateRequest & RegionInput, CreateJobTemplateResponse, CreateJobTemplateError, Creds | HttpClient.HttpClient>;
export type CreateManagedEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a managed endpoint. A managed endpoint is a gateway that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can
 * communicate with your virtual cluster.
 */
export declare const createManagedEndpoint: API.OperationMethod<CreateManagedEndpointRequest & RegionInput, CreateManagedEndpointResponse, CreateManagedEndpointError, Creds | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Creates a security configuration. Security configurations in Amazon EMR on EKS are
 * templates for different security setups. You can use security configurations to configure
 * the Lake Formation integration setup. You can also create a security configuration
 * to re-use a security setup each time you create a virtual cluster.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationRequest & RegionInput, CreateSecurityConfigurationResponse, CreateSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type CreateVirtualClusterError = EKSRequestThrottledException | InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | EksClusterConnectionUpdating | CommonErrors;
/**
 * Creates a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const createVirtualCluster: API.OperationMethod<CreateVirtualClusterRequest & RegionInput, CreateVirtualClusterResponse, CreateVirtualClusterError, Creds | HttpClient.HttpClient>;
export type DeleteJobTemplateError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a job template. Job template stores values of StartJobRun API request in a
 * template and can be used to start a job run. Job template allows two use cases: avoid
 * repeating recurring StartJobRun API request values, enforcing certain values in StartJobRun
 * API request.
 */
export declare const deleteJobTemplate: API.OperationMethod<DeleteJobTemplateRequest & RegionInput, DeleteJobTemplateResponse, DeleteJobTemplateError, Creds | HttpClient.HttpClient>;
export type DeleteManagedEndpointError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a managed endpoint. A managed endpoint is a gateway that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can
 * communicate with your virtual cluster.
 */
export declare const deleteManagedEndpoint: API.OperationMethod<DeleteManagedEndpointRequest & RegionInput, DeleteManagedEndpointResponse, DeleteManagedEndpointError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = InternalServerException | ValidationException | CommonErrors;
/**
 * Deletes a security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationRequest & RegionInput, DeleteSecurityConfigurationResponse, DeleteSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DeleteVirtualClusterError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const deleteVirtualCluster: API.OperationMethod<DeleteVirtualClusterRequest & RegionInput, DeleteVirtualClusterResponse, DeleteVirtualClusterError, Creds | HttpClient.HttpClient>;
export type DescribeJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a job run. A job run is a unit of work, such as a
 * Spark jar, PySpark script, or SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const describeJobRun: API.OperationMethod<DescribeJobRunRequest & RegionInput, DescribeJobRunResponse, DescribeJobRunError, Creds | HttpClient.HttpClient>;
export type DescribeJobTemplateError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified job template. Job template stores values
 * of StartJobRun API request in a template and can be used to start a job run. Job template
 * allows two use cases: avoid repeating recurring StartJobRun API request values, enforcing
 * certain values in StartJobRun API request.
 */
export declare const describeJobTemplate: API.OperationMethod<DescribeJobTemplateRequest & RegionInput, DescribeJobTemplateResponse, DescribeJobTemplateError, Creds | HttpClient.HttpClient>;
export type DescribeManagedEndpointError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a managed endpoint. A managed endpoint is a gateway
 * that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can communicate with your virtual cluster.
 */
export declare const describeManagedEndpoint: API.OperationMethod<DescribeManagedEndpointRequest & RegionInput, DescribeManagedEndpointResponse, DescribeManagedEndpointError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityConfigurationError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified security configuration. Security
 * configurations in Amazon EMR on EKS are templates for different security setups. You
 * can use security configurations to configure the Lake Formation integration setup.
 * You can also create a security configuration to re-use a security setup each time you
 * create a virtual cluster.
 */
export declare const describeSecurityConfiguration: API.OperationMethod<DescribeSecurityConfigurationRequest & RegionInput, DescribeSecurityConfigurationResponse, DescribeSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeVirtualClusterError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Displays detailed information about a specified virtual cluster. Virtual cluster is a
 * managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual
 * clusters. They do not consume any additional resource in your system. A single virtual
 * cluster maps to a single Kubernetes namespace. Given this relationship, you can model
 * virtual clusters the same way you model Kubernetes namespaces to meet your
 * requirements.
 */
export declare const describeVirtualCluster: API.OperationMethod<DescribeVirtualClusterRequest & RegionInput, DescribeVirtualClusterResponse, DescribeVirtualClusterError, Creds | HttpClient.HttpClient>;
export type GetManagedEndpointSessionCredentialsError = InternalServerException | RequestThrottledException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Generate a session token to connect to a managed endpoint.
 */
export declare const getManagedEndpointSessionCredentials: API.OperationMethod<GetManagedEndpointSessionCredentialsRequest & RegionInput, GetManagedEndpointSessionCredentialsResponse, GetManagedEndpointSessionCredentialsError, Creds | HttpClient.HttpClient>;
export type ListJobRunsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists job runs based on a set of parameters. A job run is a unit of work, such as a
 * Spark jar, PySpark script, or SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const listJobRuns: API.PaginatedOperationMethod<ListJobRunsRequest & RegionInput, ListJobRunsResponse, ListJobRunsError, Creds | HttpClient.HttpClient, JobRun>;
export type ListJobTemplatesError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists job templates based on a set of parameters. Job template stores values of
 * StartJobRun API request in a template and can be used to start a job run. Job template
 * allows two use cases: avoid repeating recurring StartJobRun API request values, enforcing
 * certain values in StartJobRun API request.
 */
export declare const listJobTemplates: API.PaginatedOperationMethod<ListJobTemplatesRequest & RegionInput, ListJobTemplatesResponse, ListJobTemplatesError, Creds | HttpClient.HttpClient, JobTemplate>;
export type ListManagedEndpointsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists managed endpoints based on a set of parameters. A managed endpoint is a gateway
 * that connects Amazon EMR Studio to Amazon EMR on EKS so that Amazon EMR Studio can communicate with your virtual cluster.
 */
export declare const listManagedEndpoints: API.PaginatedOperationMethod<ListManagedEndpointsRequest & RegionInput, ListManagedEndpointsResponse, ListManagedEndpointsError, Creds | HttpClient.HttpClient, Endpoint>;
export type ListSecurityConfigurationsError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists security configurations based on a set of parameters. Security configurations in
 * Amazon EMR on EKS are templates for different security setups. You can use security
 * configurations to configure the Lake Formation integration setup. You can also
 * create a security configuration to re-use a security setup each time you create a virtual
 * cluster.
 */
export declare const listSecurityConfigurations: API.PaginatedOperationMethod<ListSecurityConfigurationsRequest & RegionInput, ListSecurityConfigurationsResponse, ListSecurityConfigurationsError, Creds | HttpClient.HttpClient, SecurityConfiguration>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists the tags assigned to the resources.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Creds | HttpClient.HttpClient>;
export type ListVirtualClustersError = InternalServerException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Lists information about the specified virtual cluster. Virtual cluster is a managed
 * entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual
 * clusters. They do not consume any additional resource in your system. A single virtual
 * cluster maps to a single Kubernetes namespace. Given this relationship, you can model
 * virtual clusters the same way you model Kubernetes namespaces to meet your
 * requirements.
 */
export declare const listVirtualClusters: API.PaginatedOperationMethod<ListVirtualClustersRequest & RegionInput, ListVirtualClustersResponse, ListVirtualClustersError, Creds | HttpClient.HttpClient, VirtualCluster>;
export type StartJobRunError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | CommonErrors;
/**
 * Starts a job run. A job run is a unit of work, such as a Spark jar, PySpark script, or
 * SparkSQL query, that you submit to Amazon EMR on EKS.
 */
export declare const startJobRun: API.OperationMethod<StartJobRunRequest & RegionInput, StartJobRunResponse, StartJobRunError, Creds | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | InvalidResourceArn | CommonErrors;
/**
 * Assigns tags to resources. A tag is a label that you assign to an Amazon Web Services
 * resource. Each tag consists of a key and an optional value, both of which you define. Tags
 * enable you to categorize your Amazon Web Services resources by attributes such as purpose,
 * owner, or environment. When you have many resources of the same type, you can quickly
 * identify a specific resource based on the tags you've assigned to it. For example, you can
 * define a set of tags for your Amazon EMR on EKS clusters to help you track each
 * cluster's owner and stack level. We recommend that you devise a consistent set of tag keys
 * for each resource type. You can then search and filter the resources based on the tags that
 * you add.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Creds | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | TooManyRequestsException | InvalidResourceArn | CommonErrors;
/**
 * Removes tags from resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Creds | HttpClient.HttpClient>;
export type UpdateVirtualClusterError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a virtual cluster. Virtual cluster is a managed entity on Amazon EMR on EKS. You can create, update, describe, list and delete virtual clusters. They do not consume any
 * additional resource in your system. A single virtual cluster maps to a single Kubernetes
 * namespace. Given this relationship, you can model virtual clusters the same way you model
 * Kubernetes namespaces to meet your requirements.
 */
export declare const updateVirtualCluster: API.OperationMethod<UpdateVirtualClusterRequest & RegionInput, UpdateVirtualClusterResponse, UpdateVirtualClusterError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr-containers.d.ts.map