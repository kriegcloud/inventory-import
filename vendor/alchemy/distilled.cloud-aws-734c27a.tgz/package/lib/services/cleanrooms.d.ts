import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly quotaName: any;
    readonly quotaValue: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CollaborationIdentifier = string;
export type AnalysisTemplateArn = string;
export type AnalysisTemplateArnList = string[];
export interface BatchGetCollaborationAnalysisTemplateInput {
    collaborationIdentifier: string;
    analysisTemplateArns: string[];
}
export type AnalysisTemplateIdentifier = string;
export type UUID = string;
export type CollaborationArn = string;
export type ResourceDescription = string;
export type AccountId = string;
export type ResourceAlias = string;
export type TableAlias = string;
export type QueryTables = string[];
export interface AnalysisSchema {
    referencedTables?: string[] | undefined;
}
export type AnalysisFormat = "SQL" | "PYSPARK_1_0" | "PYSPARK_2_0" | (string & {});
export type AnalysisTemplateText = string | redacted.Redacted<string>;
export interface S3Location {
    bucket: string;
    key: string;
}
export interface AnalysisTemplateArtifact {
    location: S3Location;
}
export type AnalysisTemplateArtifactList = AnalysisTemplateArtifact[];
export type RoleArn = string;
export interface AnalysisTemplateArtifacts {
    entryPoint: AnalysisTemplateArtifact;
    additionalArtifacts?: AnalysisTemplateArtifact[] | undefined;
    roleArn: string;
}
export type AnalysisSource = {
    text: string | redacted.Redacted<string>;
    artifacts?: undefined;
} | {
    text?: undefined;
    artifacts: AnalysisTemplateArtifacts;
};
export interface Hash {
    sha256?: string | undefined;
}
export type HashList = Hash[];
export interface AnalysisTemplateArtifactMetadata {
    entryPointHash: Hash;
    additionalArtifactHashes?: Hash[] | undefined;
}
export type AnalysisSourceMetadata = {
    artifacts: AnalysisTemplateArtifactMetadata;
};
export type ParameterName = string;
export type ParameterType = "SMALLINT" | "INTEGER" | "BIGINT" | "DECIMAL" | "REAL" | "DOUBLE_PRECISION" | "BOOLEAN" | "CHAR" | "VARCHAR" | "DATE" | "TIMESTAMP" | "TIMESTAMPTZ" | "TIME" | "TIMETZ" | "VARBYTE" | "BINARY" | "BYTE" | "CHARACTER" | "DOUBLE" | "FLOAT" | "INT" | "LONG" | "NUMERIC" | "SHORT" | "STRING" | "TIMESTAMP_LTZ" | "TIMESTAMP_NTZ" | "TINYINT" | (string & {});
export type ParameterValue = string;
export interface AnalysisParameter {
    name: string;
    type: ParameterType;
    defaultValue?: string | undefined;
}
export type AnalysisParameterList = AnalysisParameter[];
export type AnalysisTemplateValidationType = "DIFFERENTIAL_PRIVACY" | (string & {});
export type AnalysisTemplateValidationStatus = "VALID" | "INVALID" | "UNABLE_TO_VALIDATE" | (string & {});
export interface AnalysisTemplateValidationStatusReason {
    message: string;
}
export type AnalysisTemplateValidationStatusReasonList = AnalysisTemplateValidationStatusReason[];
export interface AnalysisTemplateValidationStatusDetail {
    type: AnalysisTemplateValidationType;
    status: AnalysisTemplateValidationStatus;
    reasons?: AnalysisTemplateValidationStatusReason[] | undefined;
}
export type AnalysisTemplateValidationStatusDetailList = AnalysisTemplateValidationStatusDetail[];
export type ErrorMessageType = "DETAILED" | (string & {});
export interface ErrorMessageConfiguration {
    type: ErrorMessageType;
}
export type MaxMembershipInferenceAttackScore = number;
export type SyntheticDataColumnName = string;
export type SyntheticDataColumnType = "CATEGORICAL" | "NUMERICAL" | (string & {});
export interface SyntheticDataColumnProperties {
    columnName: string;
    columnType: SyntheticDataColumnType;
    isPredictiveValue: boolean;
}
export type ColumnMappingList = SyntheticDataColumnProperties[];
export interface ColumnClassificationDetails {
    columnMapping: SyntheticDataColumnProperties[];
}
export interface MLSyntheticDataParameters {
    epsilon: number;
    maxMembershipInferenceAttackScore: number;
    columnClassification: ColumnClassificationDetails;
}
export type SyntheticDataParameters = {
    mlSyntheticDataParameters: MLSyntheticDataParameters;
};
export interface CollaborationAnalysisTemplate {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    description?: string | undefined;
    creatorAccountId: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    schema: AnalysisSchema;
    format: AnalysisFormat;
    source?: AnalysisSource | undefined;
    sourceMetadata?: AnalysisSourceMetadata | undefined;
    analysisParameters?: AnalysisParameter[] | undefined;
    validations?: AnalysisTemplateValidationStatusDetail[] | undefined;
    errorMessageConfiguration?: ErrorMessageConfiguration | undefined;
    syntheticDataParameters?: SyntheticDataParameters | undefined;
}
export type CollaborationAnalysisTemplateList = CollaborationAnalysisTemplate[];
export interface BatchGetCollaborationAnalysisTemplateError_ {
    arn: string;
    code: string;
    message: string;
}
export type BatchGetCollaborationAnalysisTemplateErrorList = BatchGetCollaborationAnalysisTemplateError_[];
export interface BatchGetCollaborationAnalysisTemplateOutput {
    collaborationAnalysisTemplates: CollaborationAnalysisTemplate[];
    errors: BatchGetCollaborationAnalysisTemplateError_[];
}
export type TableAliasList = string[];
export interface BatchGetSchemaInput {
    collaborationIdentifier: string;
    names: string[];
}
export type ColumnName = string;
export type ColumnTypeString = string;
export interface Column {
    name: string;
    type: string;
}
export type ColumnList = Column[];
export type AnalysisRuleType = "AGGREGATION" | "LIST" | "CUSTOM" | "ID_MAPPING_TABLE" | (string & {});
export type AnalysisRuleTypeList = AnalysisRuleType[];
export type AnalysisMethod = "DIRECT_QUERY" | "DIRECT_JOB" | "MULTIPLE" | (string & {});
export type SelectedAnalysisMethod = "DIRECT_QUERY" | "DIRECT_JOB" | (string & {});
export type SelectedAnalysisMethods = SelectedAnalysisMethod[];
export type TableDescription = string;
export type SchemaType = "TABLE" | "ID_MAPPING_TABLE" | "INTERMEDIATE_TABLE" | (string & {});
export type SchemaStatus = "READY" | "NOT_READY" | (string & {});
export type SchemaStatusReasonCode = "ANALYSIS_RULE_MISSING" | "ANALYSIS_TEMPLATES_NOT_CONFIGURED" | "ANALYSIS_PROVIDERS_NOT_CONFIGURED" | "DIFFERENTIAL_PRIVACY_POLICY_NOT_CONFIGURED" | "ID_MAPPING_TABLE_NOT_POPULATED" | "COLLABORATION_ANALYSIS_RULE_NOT_CONFIGURED" | "ADDITIONAL_ANALYSES_NOT_CONFIGURED" | "RESULT_RECEIVERS_NOT_CONFIGURED" | "ADDITIONAL_ANALYSES_NOT_ALLOWED" | "RESULT_RECEIVERS_NOT_ALLOWED" | "ANALYSIS_RULE_TYPES_NOT_COMPATIBLE" | "INTERMEDIATE_TABLE_NOT_POPULATED" | "INTERMEDIATE_TABLE_ANALYSIS_RULE_MISSING" | "INTERMEDIATE_TABLE_BASE_TABLE_REMOVED" | "INTERMEDIATE_TABLE_INHERITED_CONSTRAINTS_VIOLATED" | "INTERMEDIATE_TABLE_DISALLOWED_BY_DATA_PROVIDER" | "INTERMEDIATE_TABLE_RETENTION_PERIOD_EXPIRED" | (string & {});
export interface SchemaStatusReason {
    code: SchemaStatusReasonCode;
    message: string;
}
export type SchemaStatusReasonList = SchemaStatusReason[];
export type SchemaConfiguration = "DIFFERENTIAL_PRIVACY" | (string & {});
export type SchemaConfigurationList = SchemaConfiguration[];
export type AnalysisType = "DIRECT_ANALYSIS" | "ADDITIONAL_ANALYSIS" | (string & {});
export interface SchemaStatusDetail {
    status: SchemaStatus;
    reasons?: SchemaStatusReason[] | undefined;
    analysisRuleType?: AnalysisRuleType | undefined;
    configurations?: SchemaConfiguration[] | undefined;
    analysisType: AnalysisType;
}
export type SchemaStatusDetailList = SchemaStatusDetail[];
export type SchemaResourceArn = string;
export type IdNamespaceType = "SOURCE" | "TARGET" | (string & {});
export interface IdMappingTableInputSource {
    idNamespaceAssociationId: string;
    type: IdNamespaceType;
}
export type IdMappingTableInputSourceList = IdMappingTableInputSource[];
export interface IdMappingTableSchemaTypeProperties {
    idMappingTableInputSource: IdMappingTableInputSource[];
    idMappingTableId?: string | undefined;
}
export interface IntermediateTableSchemaTypeProperties {
    intermediateTableId: string;
}
export interface ConfiguredTableAssociationSchemaTypeProperties {
    configuredTableAssociationId: string;
}
export type SchemaTypeProperties = {
    idMappingTable: IdMappingTableSchemaTypeProperties;
    intermediateTable?: undefined;
    configuredTableAssociation?: undefined;
} | {
    idMappingTable?: undefined;
    intermediateTable: IntermediateTableSchemaTypeProperties;
    configuredTableAssociation?: undefined;
} | {
    idMappingTable?: undefined;
    intermediateTable?: undefined;
    configuredTableAssociation: ConfiguredTableAssociationSchemaTypeProperties;
};
export interface Schema {
    columns: Column[];
    partitionKeys: Column[];
    analysisRuleTypes: AnalysisRuleType[];
    analysisMethod?: AnalysisMethod | undefined;
    selectedAnalysisMethods?: SelectedAnalysisMethod[] | undefined;
    creatorAccountId: string;
    name: string;
    collaborationId: string;
    collaborationArn: string;
    description: string;
    createTime: Date;
    updateTime: Date;
    type: SchemaType;
    schemaStatusDetails: SchemaStatusDetail[];
    resourceArn?: string | undefined;
    schemaTypeProperties?: SchemaTypeProperties | undefined;
}
export type SchemaList = Schema[];
export interface BatchGetSchemaError_ {
    name: string;
    code: string;
    message: string;
}
export type BatchGetSchemaErrorList = BatchGetSchemaError_[];
export interface BatchGetSchemaOutput {
    schemas: Schema[];
    errors: BatchGetSchemaError_[];
}
export interface SchemaAnalysisRuleRequest {
    name: string;
    type: AnalysisRuleType;
}
export type SchemaAnalysisRuleRequestList = SchemaAnalysisRuleRequest[];
export interface BatchGetSchemaAnalysisRuleInput {
    collaborationIdentifier: string;
    schemaAnalysisRuleRequests: SchemaAnalysisRuleRequest[];
}
export type AnalysisRuleColumnName = string;
export type AnalysisRuleColumnList = string[];
export type JoinOperator = string;
export type JoinOperatorsList = string[];
export type AdditionalAnalyses = "ALLOWED" | "REQUIRED" | "NOT_ALLOWED" | (string & {});
export interface AnalysisRuleList {
    joinColumns: string[];
    allowedJoinOperators?: string[] | undefined;
    listColumns: string[];
    additionalAnalyses?: AdditionalAnalyses | undefined;
}
export type AnalysisRuleColumnNameList = string[];
export type AggregateFunctionName = string;
export interface AggregateColumn {
    columnNames: string[];
    function: string;
}
export type AggregateColumnList = AggregateColumn[];
export type JoinRequiredOption = string;
export type ScalarFunctions = string;
export type ScalarFunctionsList = string[];
export type AggregationType = string;
export interface AggregationConstraint {
    columnName: string;
    minimum: number;
    type: string;
}
export type AggregationConstraints = AggregationConstraint[];
export interface AnalysisRuleAggregation {
    aggregateColumns: AggregateColumn[];
    joinColumns: string[];
    joinRequired?: string | undefined;
    allowedJoinOperators?: string[] | undefined;
    dimensionColumns: string[];
    scalarFunctions: string[];
    outputConstraints: AggregationConstraint[];
    additionalAnalyses?: AdditionalAnalyses | undefined;
}
export type AnalysisTemplateArnOrQueryWildcard = string;
export type AllowedAnalysesList = string[];
export type AllowedAnalysisProviderList = string[];
export interface DifferentialPrivacyColumn {
    name: string;
}
export type DifferentialPrivacyColumnList = DifferentialPrivacyColumn[];
export interface DifferentialPrivacyConfiguration {
    columns: DifferentialPrivacyColumn[];
}
export type AggregationThresholdType = "COUNT_DISTINCT" | (string & {});
export interface OutputColumnThreshold {
    outputColumnName: string;
    minimumIdentityCount: number;
}
export type OutputColumnThresholdList = OutputColumnThreshold[];
export type AllowedAggregateExpressionType = "COLUMNS_ONLY" | "ANY_EXPRESSION" | (string & {});
export interface AggregationThreshold {
    identityColumns: string[];
    minimumIdentityCount: number;
    type: AggregationThresholdType;
    outputColumnThresholds?: OutputColumnThreshold[] | undefined;
    allowedAggregateExpressionType: AllowedAggregateExpressionType;
}
export type AggregationThresholdList = AggregationThreshold[];
export interface ComparisonControls {
    allowedLiteralComparisonColumns: string[];
    allowedColumnComparisonColumns: string[];
}
export type AllowedResultReceivers = string[];
export type AdditionalAnalysesResourceArn = string;
export type AllowedAdditionalAnalyses = string[];
export interface AnalysisRuleCustom {
    allowedAnalyses: string[];
    allowedAnalysisProviders?: string[] | undefined;
    additionalAnalyses?: AdditionalAnalyses | undefined;
    disallowedOutputColumns?: string[] | undefined;
    differentialPrivacy?: DifferentialPrivacyConfiguration | undefined;
    aggregationThresholds?: AggregationThreshold[] | undefined;
    comparisonControls?: ComparisonControls | undefined;
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export interface QueryConstraintRequireOverlap {
    columns?: string[] | undefined;
}
export type QueryConstraint = {
    requireOverlap: QueryConstraintRequireOverlap;
};
export type QueryConstraintList = QueryConstraint[];
export interface AnalysisRuleIdMappingTable {
    joinColumns: string[];
    queryConstraints: QueryConstraint[];
    dimensionColumns?: string[] | undefined;
}
export type AnalysisRulePolicyV1 = {
    list: AnalysisRuleList;
    aggregation?: undefined;
    custom?: undefined;
    idMappingTable?: undefined;
} | {
    list?: undefined;
    aggregation: AnalysisRuleAggregation;
    custom?: undefined;
    idMappingTable?: undefined;
} | {
    list?: undefined;
    aggregation?: undefined;
    custom: AnalysisRuleCustom;
    idMappingTable?: undefined;
} | {
    list?: undefined;
    aggregation?: undefined;
    custom?: undefined;
    idMappingTable: AnalysisRuleIdMappingTable;
};
export type AnalysisRulePolicy = {
    v1: AnalysisRulePolicyV1;
};
export interface ConfiguredTableAssociationAnalysisRuleList {
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export interface ConfiguredTableAssociationAnalysisRuleAggregation {
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export interface ConfiguredTableAssociationAnalysisRuleCustom {
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export type ConfiguredTableAssociationAnalysisRulePolicyV1 = {
    list: ConfiguredTableAssociationAnalysisRuleList;
    aggregation?: undefined;
    custom?: undefined;
} | {
    list?: undefined;
    aggregation: ConfiguredTableAssociationAnalysisRuleAggregation;
    custom?: undefined;
} | {
    list?: undefined;
    aggregation?: undefined;
    custom: ConfiguredTableAssociationAnalysisRuleCustom;
};
export type ConfiguredTableAssociationAnalysisRulePolicy = {
    v1: ConfiguredTableAssociationAnalysisRulePolicyV1;
};
export interface ConsolidatedPolicyList {
    joinColumns: string[];
    allowedJoinOperators?: string[] | undefined;
    listColumns: string[];
    additionalAnalyses?: AdditionalAnalyses | undefined;
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export interface ConsolidatedPolicyAggregation {
    aggregateColumns: AggregateColumn[];
    joinColumns: string[];
    joinRequired?: string | undefined;
    allowedJoinOperators?: string[] | undefined;
    dimensionColumns: string[];
    scalarFunctions: string[];
    outputConstraints: AggregationConstraint[];
    additionalAnalyses?: AdditionalAnalyses | undefined;
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export interface ConsolidatedPolicyCustom {
    allowedAnalyses: string[];
    allowedAnalysisProviders?: string[] | undefined;
    additionalAnalyses?: AdditionalAnalyses | undefined;
    disallowedOutputColumns?: string[] | undefined;
    differentialPrivacy?: DifferentialPrivacyConfiguration | undefined;
    aggregationThresholds?: AggregationThreshold[] | undefined;
    comparisonControls?: ComparisonControls | undefined;
    allowedResultReceivers?: string[] | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
}
export type ConsolidatedPolicyV1 = {
    list: ConsolidatedPolicyList;
    aggregation?: undefined;
    custom?: undefined;
} | {
    list?: undefined;
    aggregation: ConsolidatedPolicyAggregation;
    custom?: undefined;
} | {
    list?: undefined;
    aggregation?: undefined;
    custom: ConsolidatedPolicyCustom;
};
export type ConsolidatedPolicy = {
    v1: ConsolidatedPolicyV1;
};
export interface AnalysisRule {
    collaborationId: string;
    type: AnalysisRuleType;
    name: string;
    createTime: Date;
    updateTime: Date;
    policy: AnalysisRulePolicy;
    collaborationPolicy?: ConfiguredTableAssociationAnalysisRulePolicy | undefined;
    consolidatedPolicy?: ConsolidatedPolicy | undefined;
}
export type SchemaAnalysisRuleList = AnalysisRule[];
export interface BatchGetSchemaAnalysisRuleError_ {
    name: string;
    type: AnalysisRuleType;
    code: string;
    message: string;
}
export type BatchGetSchemaAnalysisRuleErrorList = BatchGetSchemaAnalysisRuleError_[];
export interface BatchGetSchemaAnalysisRuleOutput {
    analysisRules: AnalysisRule[];
    errors: BatchGetSchemaAnalysisRuleError_[];
}
export type MembershipIdentifier = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAnalysisTemplateInput {
    description?: string | undefined;
    membershipIdentifier: string;
    name: string;
    format: AnalysisFormat;
    source: AnalysisSource;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    analysisParameters?: AnalysisParameter[] | undefined;
    schema?: AnalysisSchema | undefined;
    errorMessageConfiguration?: ErrorMessageConfiguration | undefined;
    syntheticDataParameters?: SyntheticDataParameters | undefined;
}
export type MembershipArn = string;
export interface AnalysisTemplate {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    membershipId: string;
    membershipArn: string;
    description?: string | undefined;
    name: string;
    createTime: Date;
    updateTime: Date;
    schema: AnalysisSchema;
    format: AnalysisFormat;
    source: AnalysisSource;
    sourceMetadata?: AnalysisSourceMetadata | undefined;
    analysisParameters?: AnalysisParameter[] | undefined;
    validations?: AnalysisTemplateValidationStatusDetail[] | undefined;
    errorMessageConfiguration?: ErrorMessageConfiguration | undefined;
    syntheticDataParameters?: SyntheticDataParameters | undefined;
}
export interface CreateAnalysisTemplateOutput {
    analysisTemplate: AnalysisTemplate;
}
export type MemberAbility = "CAN_QUERY" | "CAN_RECEIVE_RESULTS" | "CAN_RUN_JOB" | "CAN_EXPORT_QUERY_ANALYSIS_LOG" | (string & {});
export type MemberAbilities = MemberAbility[];
export type CustomMLMemberAbility = "CAN_RECEIVE_MODEL_OUTPUT" | "CAN_RECEIVE_INFERENCE_OUTPUT" | (string & {});
export type CustomMLMemberAbilities = CustomMLMemberAbility[];
export interface MLMemberAbilities {
    customMLMemberAbilities: CustomMLMemberAbility[];
}
export type DisplayName = string;
export interface QueryComputePaymentConfig {
    isResponsible: boolean;
}
export interface ModelTrainingPaymentConfig {
    isResponsible: boolean;
}
export interface ModelInferencePaymentConfig {
    isResponsible: boolean;
}
export interface SyntheticDataGenerationPaymentConfig {
    isResponsible: boolean;
}
export interface MLPaymentConfig {
    modelTraining?: ModelTrainingPaymentConfig | undefined;
    modelInference?: ModelInferencePaymentConfig | undefined;
    syntheticDataGeneration?: SyntheticDataGenerationPaymentConfig | undefined;
}
export interface JobComputePaymentConfig {
    isResponsible: boolean;
}
export interface PaymentConfiguration {
    queryCompute: QueryComputePaymentConfig;
    machineLearning?: MLPaymentConfig | undefined;
    jobCompute?: JobComputePaymentConfig | undefined;
}
export interface MemberSpecification {
    accountId: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities | undefined;
    displayName: string;
    paymentConfiguration?: PaymentConfiguration | undefined;
}
export type MemberList = MemberSpecification[];
export type CollaborationName = string;
export type CollaborationDescription = string;
export interface DataEncryptionMetadata {
    allowCleartext: boolean;
    allowDuplicates: boolean;
    allowJoinsOnColumnsWithDifferentNames: boolean;
    preserveNulls: boolean;
}
export type CollaborationQueryLogStatus = "ENABLED" | "DISABLED" | (string & {});
export type CollaborationJobLogStatus = "ENABLED" | "DISABLED" | (string & {});
export type AnalyticsEngine = "SPARK" | "CLEAN_ROOMS_SQL" | (string & {});
export type AutoApprovedChangeType = "ADD_MEMBER" | "GRANT_RECEIVE_RESULTS_ABILITY" | "REVOKE_RECEIVE_RESULTS_ABILITY" | "GRANT_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | "REVOKE_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | (string & {});
export type AutoApprovedChangeTypeList = AutoApprovedChangeType[];
export type SupportedS3Region = "us-west-1" | "us-west-2" | "us-east-1" | "us-east-2" | "af-south-1" | "ap-east-1" | "ap-east-2" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-southeast-5" | "ap-southeast-4" | "ap-southeast-7" | "ap-south-1" | "ap-northeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ca-central-1" | "ca-west-1" | "eu-south-1" | "eu-west-3" | "eu-south-2" | "eu-central-2" | "eu-central-1" | "eu-north-1" | "eu-west-1" | "eu-west-2" | "me-south-1" | "me-central-1" | "il-central-1" | "sa-east-1" | "mx-central-1" | (string & {});
export type AllowedResultRegions = SupportedS3Region[];
export interface CreateCollaborationInput {
    members: MemberSpecification[];
    name: string;
    description?: string | undefined;
    creatorMemberAbilities: MemberAbility[];
    creatorMLMemberAbilities?: MLMemberAbilities | undefined;
    creatorDisplayName: string;
    dataEncryptionMetadata?: DataEncryptionMetadata | undefined;
    queryLogStatus: CollaborationQueryLogStatus;
    jobLogStatus?: CollaborationJobLogStatus | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    creatorPaymentConfiguration?: PaymentConfiguration | undefined;
    analyticsEngine?: AnalyticsEngine | undefined;
    autoApprovedChangeRequestTypes?: AutoApprovedChangeType[] | undefined;
    allowedResultRegions?: SupportedS3Region[] | undefined;
    isMetricsEnabled?: boolean | undefined;
}
export type MemberStatus = string;
export interface Collaboration {
    id: string;
    arn: string;
    name: string;
    description?: string | undefined;
    creatorAccountId: string;
    creatorDisplayName: string;
    createTime: Date;
    updateTime: Date;
    memberStatus: string;
    membershipId?: string | undefined;
    membershipArn?: string | undefined;
    dataEncryptionMetadata?: DataEncryptionMetadata | undefined;
    queryLogStatus: CollaborationQueryLogStatus;
    jobLogStatus?: CollaborationJobLogStatus | undefined;
    analyticsEngine?: AnalyticsEngine | undefined;
    autoApprovedChangeTypes?: AutoApprovedChangeType[] | undefined;
    allowedResultRegions?: SupportedS3Region[] | undefined;
    isMetricsEnabled?: boolean | undefined;
}
export interface CreateCollaborationOutput {
    collaboration: Collaboration;
}
export type ChangeSpecificationType = "MEMBER" | "COLLABORATION" | (string & {});
export interface MemberChangeSpecification {
    accountId: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities | undefined;
    paymentConfiguration?: PaymentConfiguration | undefined;
    displayName?: string | undefined;
}
export interface CollaborationChangeSpecification {
    autoApprovedChangeTypes?: AutoApprovedChangeType[] | undefined;
}
export type ChangeSpecification = {
    member: MemberChangeSpecification;
    collaboration?: undefined;
} | {
    member?: undefined;
    collaboration: CollaborationChangeSpecification;
};
export interface ChangeInput {
    specificationType: ChangeSpecificationType;
    specification: ChangeSpecification;
}
export type ChangeInputList = ChangeInput[];
export interface CreateCollaborationChangeRequestInput {
    collaborationIdentifier: string;
    changes: ChangeInput[];
}
export type ChangeRequestStatus = "PENDING" | "APPROVED" | "CANCELLED" | "DENIED" | "COMMITTED" | (string & {});
export type ChangeType = "ADD_MEMBER" | "GRANT_RECEIVE_RESULTS_ABILITY" | "REVOKE_RECEIVE_RESULTS_ABILITY" | "EDIT_AUTO_APPROVED_CHANGE_TYPES" | "ADD_PAYER_CANDIDATE" | "REMOVE_PAYER_CANDIDATE" | "GRANT_CAN_RECEIVE_MODEL_OUTPUT" | "GRANT_CAN_RECEIVE_INFERENCE_OUTPUT" | "REVOKE_CAN_RECEIVE_MODEL_OUTPUT" | "REVOKE_CAN_RECEIVE_INFERENCE_OUTPUT" | "GRANT_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | "REVOKE_EXPORT_QUERY_ANALYSIS_LOG_ABILITY" | (string & {});
export type ChangeTypeList = ChangeType[];
export interface Change {
    specificationType: ChangeSpecificationType;
    specification: ChangeSpecification;
    types: ChangeType[];
}
export type ChangeList = Change[];
export type ApprovalStatus = "APPROVED" | "DENIED" | "PENDING" | (string & {});
export interface ApprovalStatusDetails {
    status: ApprovalStatus;
}
export type ApprovalStatuses = {
    [key: string]: ApprovalStatusDetails | undefined;
};
export interface CollaborationChangeRequest {
    id: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    status: ChangeRequestStatus;
    isAutoApproved: boolean;
    changes: Change[];
    approvals?: {
        [key: string]: ApprovalStatusDetails | undefined;
    } | undefined;
}
export interface CreateCollaborationChangeRequestOutput {
    collaborationChangeRequest: CollaborationChangeRequest;
}
export type ConfiguredAudienceModelArn = string;
export type ConfiguredAudienceModelAssociationName = string;
export interface CreateConfiguredAudienceModelAssociationInput {
    membershipIdentifier: string;
    configuredAudienceModelArn: string;
    configuredAudienceModelAssociationName: string;
    manageResourcePolicies: boolean;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    description?: string | undefined;
}
export type ConfiguredAudienceModelAssociationIdentifier = string;
export type ConfiguredAudienceModelAssociationArn = string;
export interface ConfiguredAudienceModelAssociation {
    id: string;
    arn: string;
    configuredAudienceModelArn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    name: string;
    manageResourcePolicies: boolean;
    description?: string | undefined;
    createTime: Date;
    updateTime: Date;
}
export interface CreateConfiguredAudienceModelAssociationOutput {
    configuredAudienceModelAssociation: ConfiguredAudienceModelAssociation;
}
export type CommercialRegion = "us-west-1" | "us-west-2" | "us-east-1" | "us-east-2" | "af-south-1" | "ap-east-1" | "ap-south-2" | "ap-southeast-1" | "ap-southeast-2" | "ap-southeast-3" | "ap-southeast-5" | "ap-southeast-4" | "ap-southeast-7" | "ap-south-1" | "ap-northeast-3" | "ap-northeast-1" | "ap-northeast-2" | "ca-central-1" | "ca-west-1" | "eu-south-1" | "eu-west-3" | "eu-south-2" | "eu-central-2" | "eu-central-1" | "eu-north-1" | "eu-west-1" | "eu-west-2" | "me-south-1" | "me-central-1" | "il-central-1" | "sa-east-1" | "mx-central-1" | "ap-east-2" | (string & {});
export type GlueTableName = string;
export type GlueDatabaseName = string;
export interface GlueTableReference {
    region?: CommercialRegion | undefined;
    tableName: string;
    databaseName: string;
}
export type SecretsManagerArn = string;
export type SnowflakeAccountIdentifier = string;
export type SnowflakeDatabaseName = string;
export type SnowflakeTableName = string;
export type SnowflakeSchemaName = string;
export interface SnowflakeTableSchemaV1 {
    columnName: string;
    columnType: string;
}
export type SnowflakeTableSchemaList = SnowflakeTableSchemaV1[];
export type SnowflakeTableSchema = {
    v1: SnowflakeTableSchemaV1[];
};
export interface SnowflakeTableReference {
    secretArn: string;
    accountIdentifier: string;
    databaseName: string;
    tableName: string;
    schemaName: string;
    tableSchema: SnowflakeTableSchema;
}
export type AthenaWorkGroup = string;
export type AthenaOutputLocation = string;
export type AthenaDatabaseName = string;
export type AthenaTableName = string;
export type AthenaCatalogName = string;
export interface AthenaTableReference {
    region?: CommercialRegion | undefined;
    workGroup: string;
    outputLocation?: string | undefined;
    databaseName: string;
    tableName: string;
    catalogName?: string | undefined;
}
export type DatabricksObject = string;
export type DatabricksWorkspaceUrl = string;
export type DatabricksEndpointUrl = string;
export interface DatabricksDeltaSharingConnection {
    deltaShareEndpoint: string;
    shareName: string;
}
export type DatabricksConnectionType = {
    deltaSharing: DatabricksDeltaSharingConnection;
};
export interface DatabricksTableReference {
    schemaName: string;
    tableName: string;
    workspaceUrl: string;
    connectionType: DatabricksConnectionType;
}
export type TableReference = {
    glue: GlueTableReference;
    snowflake?: undefined;
    athena?: undefined;
    databricks?: undefined;
} | {
    glue?: undefined;
    snowflake: SnowflakeTableReference;
    athena?: undefined;
    databricks?: undefined;
} | {
    glue?: undefined;
    snowflake?: undefined;
    athena: AthenaTableReference;
    databricks?: undefined;
} | {
    glue?: undefined;
    snowflake?: undefined;
    athena?: undefined;
    databricks: DatabricksTableReference;
};
export type AllowedColumnList = string[];
export interface CreateConfiguredTableInput {
    name: string;
    description?: string | undefined;
    tableReference: TableReference;
    allowedColumns: string[];
    analysisMethod: AnalysisMethod;
    selectedAnalysisMethods?: SelectedAnalysisMethod[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfiguredTableArn = string;
export type TableReferenceType = "GLUE" | "SNOWFLAKE" | "ATHENA" | "DATABRICKS" | (string & {});
export type ConfiguredTableAnalysisRuleType = "AGGREGATION" | "LIST" | "CUSTOM" | (string & {});
export type ConfiguredTableAnalysisRuleTypeList = ConfiguredTableAnalysisRuleType[];
export interface ConfiguredTable {
    id: string;
    arn: string;
    name: string;
    description?: string | undefined;
    tableReference: TableReference;
    tableType?: TableReferenceType | undefined;
    createTime: Date;
    updateTime: Date;
    analysisRuleTypes: ConfiguredTableAnalysisRuleType[];
    analysisMethod: AnalysisMethod;
    allowedColumns: string[];
    selectedAnalysisMethods?: SelectedAnalysisMethod[] | undefined;
}
export interface CreateConfiguredTableOutput {
    configuredTable: ConfiguredTable;
}
export type ConfiguredTableIdentifier = string;
export type ConfiguredTableAnalysisRulePolicyV1 = {
    list: AnalysisRuleList;
    aggregation?: undefined;
    custom?: undefined;
} | {
    list?: undefined;
    aggregation: AnalysisRuleAggregation;
    custom?: undefined;
} | {
    list?: undefined;
    aggregation?: undefined;
    custom: AnalysisRuleCustom;
};
export type ConfiguredTableAnalysisRulePolicy = {
    v1: ConfiguredTableAnalysisRulePolicyV1;
};
export interface CreateConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAnalysisRulePolicy;
}
export interface ConfiguredTableAnalysisRule {
    configuredTableId: string;
    configuredTableArn: string;
    policy: ConfiguredTableAnalysisRulePolicy;
    type: ConfiguredTableAnalysisRuleType;
    createTime: Date;
    updateTime: Date;
}
export interface CreateConfiguredTableAnalysisRuleOutput {
    analysisRule: ConfiguredTableAnalysisRule;
}
export interface CreateConfiguredTableAssociationInput {
    name: string;
    description?: string | undefined;
    membershipIdentifier: string;
    configuredTableIdentifier: string;
    roleArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfiguredTableAssociationArn = string;
export type ConfiguredTableAssociationAnalysisRuleType = "AGGREGATION" | "LIST" | "CUSTOM" | (string & {});
export type ConfiguredTableAssociationAnalysisRuleTypeList = ConfiguredTableAssociationAnalysisRuleType[];
export type ChildResourceType = "INTERMEDIATE_TABLE" | (string & {});
export type ResourceStatus = "CREATED" | "POPULATE_STARTED" | "POPULATE_SUCCESS" | "POPULATE_FAILED" | "DISALLOWED_BY_DATA_PROVIDER" | "BASE_TABLE_REMOVED" | "RETENTION_PERIOD_EXPIRED" | (string & {});
export interface ChildResource {
    resourceId?: string | undefined;
    resourceType: ChildResourceType;
    resourceName: string;
    ownerAccountId: string;
    resourceStatus?: ResourceStatus | undefined;
}
export type ChildResourceList = ChildResource[];
export interface ConfiguredTableAssociation {
    arn: string;
    id: string;
    configuredTableId: string;
    configuredTableArn: string;
    membershipId: string;
    membershipArn: string;
    roleArn: string;
    name: string;
    description?: string | undefined;
    analysisRuleTypes?: ConfiguredTableAssociationAnalysisRuleType[] | undefined;
    createTime: Date;
    updateTime: Date;
    childResources?: ChildResource[] | undefined;
}
export interface CreateConfiguredTableAssociationOutput {
    configuredTableAssociation: ConfiguredTableAssociation;
}
export type ConfiguredTableAssociationIdentifier = string;
export interface CreateConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAssociationAnalysisRulePolicy;
}
export interface ConfiguredTableAssociationAnalysisRule {
    membershipIdentifier: string;
    configuredTableAssociationId: string;
    configuredTableAssociationArn: string;
    policy: ConfiguredTableAssociationAnalysisRulePolicy;
    type: ConfiguredTableAssociationAnalysisRuleType;
    createTime: Date;
    updateTime: Date;
}
export interface CreateConfiguredTableAssociationAnalysisRuleOutput {
    analysisRule: ConfiguredTableAssociationAnalysisRule;
}
export type IdMappingTableInputReferenceArn = string;
export interface IdMappingTableInputReferenceConfig {
    inputReferenceArn: string;
    manageResourcePolicies: boolean;
}
export type KMSKeyArn = string;
export interface CreateIdMappingTableInput {
    membershipIdentifier: string;
    name: string;
    description?: string | undefined;
    inputReferenceConfig: IdMappingTableInputReferenceConfig;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
}
export type IdMappingTableArn = string;
export interface IdMappingTableInputReferenceProperties {
    idMappingTableInputSource: IdMappingTableInputSource[];
}
export interface IdMappingTable {
    id: string;
    arn: string;
    inputReferenceConfig: IdMappingTableInputReferenceConfig;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    description?: string | undefined;
    name: string;
    createTime: Date;
    updateTime: Date;
    inputReferenceProperties: IdMappingTableInputReferenceProperties;
    kmsKeyArn?: string | undefined;
    childResources?: ChildResource[] | undefined;
}
export interface CreateIdMappingTableOutput {
    idMappingTable: IdMappingTable;
}
export type IdNamespaceAssociationInputReferenceArn = string;
export interface IdNamespaceAssociationInputReferenceConfig {
    inputReferenceArn: string;
    manageResourcePolicies: boolean;
}
export type GenericResourceName = string;
export interface IdMappingConfig {
    allowUseAsDimensionColumn: boolean;
}
export interface CreateIdNamespaceAssociationInput {
    membershipIdentifier: string;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    name: string;
    description?: string | undefined;
    idMappingConfig?: IdMappingConfig | undefined;
}
export type IdNamespaceAssociationIdentifier = string;
export type IdNamespaceAssociationArn = string;
export type IdMappingWorkflowsSupported = any[];
export interface IdNamespaceAssociationInputReferenceProperties {
    idNamespaceType: IdNamespaceType;
    idMappingWorkflowsSupported: any[];
}
export interface IdNamespaceAssociation {
    id: string;
    arn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    name: string;
    description?: string | undefined;
    createTime: Date;
    updateTime: Date;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    inputReferenceProperties: IdNamespaceAssociationInputReferenceProperties;
    idMappingConfig?: IdMappingConfig | undefined;
}
export interface CreateIdNamespaceAssociationOutput {
    idNamespaceAssociation: IdNamespaceAssociation;
}
export interface PopulationAnalysisSqlParameters {
    queryString?: string | undefined;
    analysisTemplateArn?: string | undefined;
}
export type PopulationAnalysisConfiguration = {
    sqlParameters: PopulationAnalysisSqlParameters;
};
export interface CreateIntermediateTableInput {
    membershipIdentifier: string;
    name: string;
    description?: string | undefined;
    populationAnalysisConfiguration: PopulationAnalysisConfiguration;
    kmsKeyArn?: string | undefined;
    retentionInDays?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type IntermediateTableArn = string;
export type IntermediateTableStatus = "CREATED" | "POPULATE_STARTED" | "POPULATE_SUCCESS" | "POPULATE_FAILED" | "DISALLOWED_BY_DATA_PROVIDER" | "BASE_TABLE_REMOVED" | "RETENTION_PERIOD_EXPIRED" | (string & {});
export type BaseTableDependencyType = "TABLE" | "INTERMEDIATE_TABLE" | "ID_MAPPING_TABLE" | (string & {});
export type BaseTableParentType = "DIRECT" | "INDIRECT" | (string & {});
export interface IntermediateTableDependency {
    id: string;
    name: string;
    type: BaseTableDependencyType;
    parentType: BaseTableParentType;
    creatorAccountId: string;
}
export type DependencyList = IntermediateTableDependency[];
export type AnalysisIdentifier = string;
export type PopulateIntermediateTableAnalysisType = "QUERY" | (string & {});
export type ParameterMap = {
    [key: string]: string | undefined;
};
export interface InheritedAdditionalAnalysesSource {
    name: string;
    id: string;
    type: BaseTableDependencyType;
    value: AdditionalAnalyses;
    sourceAccountId: string;
}
export type InheritedAdditionalAnalysesSourceList = InheritedAdditionalAnalysesSource[];
export interface InheritedAdditionalAnalyses {
    value: AdditionalAnalyses;
    sources: InheritedAdditionalAnalysesSource[];
}
export interface InheritedAllowedAdditionalAnalysesSource {
    name: string;
    id: string;
    type: BaseTableDependencyType;
    value: string[];
    sourceAccountId: string;
}
export type InheritedAllowedAdditionalAnalysesSourceList = InheritedAllowedAdditionalAnalysesSource[];
export interface InheritedAllowedAdditionalAnalyses {
    value: string[];
    sources: InheritedAllowedAdditionalAnalysesSource[];
}
export type AccountIdList = string[];
export interface InheritedAllowedResultReceiversSource {
    name: string;
    id: string;
    type: BaseTableDependencyType;
    value: string[];
    sourceAccountId: string;
}
export type InheritedAllowedResultReceiversSourceList = InheritedAllowedResultReceiversSource[];
export interface InheritedAllowedResultReceivers {
    value: string[];
    sources: InheritedAllowedResultReceiversSource[];
}
export interface ColumnLineageEntry {
    column: string;
    sourceColumn: string;
    sourceName: string;
    sourceId: string;
    sourceType: BaseTableDependencyType;
    sourceAccountId: string;
}
export type ColumnLineageList = ColumnLineageEntry[];
export interface InheritedDisallowedOutputColumns {
    value: string[];
    columnLineage: ColumnLineageEntry[];
}
export interface IntermediateTableInheritedConstraints {
    additionalAnalyses?: InheritedAdditionalAnalyses | undefined;
    allowedAdditionalAnalyses?: InheritedAllowedAdditionalAnalyses | undefined;
    allowedResultReceivers?: InheritedAllowedResultReceivers | undefined;
    disallowedOutputColumns?: InheritedDisallowedOutputColumns | undefined;
}
export interface IntermediateTableActiveVersion {
    versionId: string;
    analysisId: string;
    analysisType: PopulateIntermediateTableAnalysisType;
    kmsKeyArn?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    inheritedConstraints: IntermediateTableInheritedConstraints;
    expirationTime?: Date | undefined;
}
export type IntermediateTableAnalysisRuleType = "CUSTOM" | (string & {});
export type IntermediateTableAnalysisRuleTypeList = IntermediateTableAnalysisRuleType[];
export interface IntermediateTableSchema {
    columns: Column[];
}
export interface IntermediateTable {
    id: string;
    arn: string;
    name: string;
    description?: string | undefined;
    membershipArn: string;
    membershipId: string;
    collaborationArn: string;
    collaborationId: string;
    childResources?: ChildResource[] | undefined;
    createTime: Date;
    updateTime: Date;
    status: IntermediateTableStatus;
    statusReason?: string | undefined;
    kmsKeyArn?: string | undefined;
    populationAnalysisConfiguration: PopulationAnalysisConfiguration;
    retentionInDays?: number | undefined;
    tableDependencies?: IntermediateTableDependency[] | undefined;
    intermediateTableVersion?: IntermediateTableActiveVersion | undefined;
    analysisRuleTypes?: IntermediateTableAnalysisRuleType[] | undefined;
    schema?: IntermediateTableSchema | undefined;
}
export interface CreateIntermediateTableOutput {
    intermediateTable: IntermediateTable;
}
export type IntermediateTableIdentifier = string;
export interface IntermediateTableAnalysisRuleCustom {
    allowedAnalyses?: string[] | undefined;
    additionalAnalyses?: AdditionalAnalyses | undefined;
    allowedAdditionalAnalyses?: string[] | undefined;
    allowedAnalysisProviders?: string[] | undefined;
    allowedResultReceivers?: string[] | undefined;
    differentialPrivacy?: DifferentialPrivacyConfiguration | undefined;
    disallowedOutputColumns?: string[] | undefined;
    aggregationThresholds?: AggregationThreshold[] | undefined;
    comparisonControls?: ComparisonControls | undefined;
}
export type IntermediateTableAnalysisRulePolicyV1 = {
    custom: IntermediateTableAnalysisRuleCustom;
};
export type IntermediateTableAnalysisRulePolicy = {
    v1: IntermediateTableAnalysisRulePolicyV1;
};
export interface CreateIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
    analysisRulePolicy: IntermediateTableAnalysisRulePolicy;
}
export interface IntermediateTableAnalysisRule {
    intermediateTableIdentifier: string;
    intermediateTableArn: string;
    analysisRulePolicy: IntermediateTableAnalysisRulePolicy;
    analysisRuleType: IntermediateTableAnalysisRuleType;
    createTime: Date;
    updateTime: Date;
}
export interface CreateIntermediateTableAnalysisRuleOutput {
    analysisRule: IntermediateTableAnalysisRule;
}
export type MembershipQueryLogStatus = "ENABLED" | "DISABLED" | (string & {});
export type MembershipJobLogStatus = "ENABLED" | "DISABLED" | (string & {});
export type ResultFormat = "CSV" | "PARQUET" | (string & {});
export type KeyPrefix = string;
export interface ProtectedQueryS3OutputConfiguration {
    resultFormat: ResultFormat;
    bucket: string;
    keyPrefix?: string | undefined;
    singleFileOutput?: boolean | undefined;
}
export type MembershipProtectedQueryOutputConfiguration = {
    s3: ProtectedQueryS3OutputConfiguration;
};
export interface MembershipProtectedQueryResultConfiguration {
    outputConfiguration: MembershipProtectedQueryOutputConfiguration;
    roleArn?: string | undefined;
}
export interface ProtectedJobS3OutputConfigurationInput {
    resultFormat?: ResultFormat | undefined;
    bucket: string;
    keyPrefix?: string | undefined;
}
export type MembershipProtectedJobOutputConfiguration = {
    s3: ProtectedJobS3OutputConfigurationInput;
};
export interface MembershipProtectedJobResultConfiguration {
    outputConfiguration: MembershipProtectedJobOutputConfiguration;
    roleArn: string;
}
export interface MembershipQueryComputePaymentConfig {
    isResponsible: boolean;
}
export interface MembershipModelTrainingPaymentConfig {
    isResponsible: boolean;
}
export interface MembershipModelInferencePaymentConfig {
    isResponsible: boolean;
}
export interface MembershipSyntheticDataGenerationPaymentConfig {
    isResponsible: boolean;
}
export interface MembershipMLPaymentConfig {
    modelTraining?: MembershipModelTrainingPaymentConfig | undefined;
    modelInference?: MembershipModelInferencePaymentConfig | undefined;
    syntheticDataGeneration?: MembershipSyntheticDataGenerationPaymentConfig | undefined;
}
export interface MembershipJobComputePaymentConfig {
    isResponsible: boolean;
}
export interface MembershipPaymentConfiguration {
    queryCompute: MembershipQueryComputePaymentConfig;
    machineLearning?: MembershipMLPaymentConfig | undefined;
    jobCompute?: MembershipJobComputePaymentConfig | undefined;
}
export interface CreateMembershipInput {
    collaborationIdentifier: string;
    queryLogStatus: MembershipQueryLogStatus;
    jobLogStatus?: MembershipJobLogStatus | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    defaultResultConfiguration?: MembershipProtectedQueryResultConfiguration | undefined;
    defaultJobResultConfiguration?: MembershipProtectedJobResultConfiguration | undefined;
    paymentConfiguration?: MembershipPaymentConfiguration | undefined;
    isMetricsEnabled?: boolean | undefined;
}
export type MembershipStatus = string;
export interface Membership {
    id: string;
    arn: string;
    collaborationArn: string;
    collaborationId: string;
    collaborationCreatorAccountId: string;
    collaborationCreatorDisplayName: string;
    collaborationName: string;
    createTime: Date;
    updateTime: Date;
    status: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities | undefined;
    queryLogStatus: MembershipQueryLogStatus;
    jobLogStatus?: MembershipJobLogStatus | undefined;
    defaultResultConfiguration?: MembershipProtectedQueryResultConfiguration | undefined;
    defaultJobResultConfiguration?: MembershipProtectedJobResultConfiguration | undefined;
    paymentConfiguration: MembershipPaymentConfiguration;
    isMetricsEnabled?: boolean | undefined;
}
export interface CreateMembershipOutput {
    membership: Membership;
}
export type PrivacyBudgetTemplateAutoRefresh = "CALENDAR_MONTH" | "NONE" | (string & {});
export type PrivacyBudgetType = "DIFFERENTIAL_PRIVACY" | "ACCESS_BUDGET" | (string & {});
export type Epsilon = number;
export type UsersNoisePerQuery = number;
export interface DifferentialPrivacyTemplateParametersInput {
    epsilon: number;
    usersNoisePerQuery: number;
}
export type AccessBudgetType = "CALENDAR_DAY" | "CALENDAR_MONTH" | "CALENDAR_WEEK" | "LIFETIME" | (string & {});
export type Budget = number;
export type AutoRefreshMode = "ENABLED" | "DISABLED" | (string & {});
export interface BudgetParameter {
    type: AccessBudgetType;
    budget: number;
    autoRefresh?: AutoRefreshMode | undefined;
}
export type BudgetParameters = BudgetParameter[];
export type BudgetedResourceArn = string;
export interface AccessBudgetsPrivacyTemplateParametersInput {
    budgetParameters: BudgetParameter[];
    resourceArn: string;
}
export type PrivacyBudgetTemplateParametersInput = {
    differentialPrivacy: DifferentialPrivacyTemplateParametersInput;
    accessBudget?: undefined;
} | {
    differentialPrivacy?: undefined;
    accessBudget: AccessBudgetsPrivacyTemplateParametersInput;
};
export interface CreatePrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    autoRefresh?: PrivacyBudgetTemplateAutoRefresh | undefined;
    privacyBudgetType: PrivacyBudgetType;
    parameters: PrivacyBudgetTemplateParametersInput;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PrivacyBudgetTemplateIdentifier = string;
export type PrivacyBudgetTemplateArn = string;
export interface DifferentialPrivacyTemplateParametersOutput {
    epsilon: number;
    usersNoisePerQuery: number;
}
export interface AccessBudgetsPrivacyTemplateParametersOutput {
    budgetParameters: BudgetParameter[];
    resourceArn: string;
}
export type PrivacyBudgetTemplateParametersOutput = {
    differentialPrivacy: DifferentialPrivacyTemplateParametersOutput;
    accessBudget?: undefined;
} | {
    differentialPrivacy?: undefined;
    accessBudget: AccessBudgetsPrivacyTemplateParametersOutput;
};
export interface PrivacyBudgetTemplate {
    id: string;
    arn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    createTime: Date;
    updateTime: Date;
    privacyBudgetType: PrivacyBudgetType;
    autoRefresh: PrivacyBudgetTemplateAutoRefresh;
    parameters: PrivacyBudgetTemplateParametersOutput;
}
export interface CreatePrivacyBudgetTemplateOutput {
    privacyBudgetTemplate: PrivacyBudgetTemplate;
}
export interface DeleteAnalysisTemplateInput {
    membershipIdentifier: string;
    analysisTemplateIdentifier: string;
}
export interface DeleteAnalysisTemplateOutput {
}
export interface DeleteCollaborationInput {
    collaborationIdentifier: string;
}
export interface DeleteCollaborationOutput {
}
export interface DeleteConfiguredAudienceModelAssociationInput {
    configuredAudienceModelAssociationIdentifier: string;
    membershipIdentifier: string;
}
export interface DeleteConfiguredAudienceModelAssociationOutput {
}
export interface DeleteConfiguredTableInput {
    configuredTableIdentifier: string;
}
export interface DeleteConfiguredTableOutput {
}
export interface DeleteConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
}
export interface DeleteConfiguredTableAnalysisRuleOutput {
}
export interface DeleteConfiguredTableAssociationInput {
    configuredTableAssociationIdentifier: string;
    membershipIdentifier: string;
}
export interface DeleteConfiguredTableAssociationOutput {
}
export interface DeleteConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
}
export interface DeleteConfiguredTableAssociationAnalysisRuleOutput {
}
export interface DeleteIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
}
export interface DeleteIdMappingTableOutput {
}
export interface DeleteIdNamespaceAssociationInput {
    idNamespaceAssociationIdentifier: string;
    membershipIdentifier: string;
}
export interface DeleteIdNamespaceAssociationOutput {
}
export interface DeleteIntermediateTableInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
}
export interface DeleteIntermediateTableOutput {
}
export interface DeleteIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
}
export interface DeleteIntermediateTableAnalysisRuleOutput {
}
export interface DeleteMemberInput {
    collaborationIdentifier: string;
    accountId: string;
}
export interface DeleteMemberOutput {
}
export interface DeleteMembershipInput {
    membershipIdentifier: string;
}
export interface DeleteMembershipOutput {
}
export interface DeletePrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
}
export interface DeletePrivacyBudgetTemplateOutput {
}
export interface DisallowIntermediateTableInput {
    membershipIdentifier: string;
    intermediateTableName: string;
    includeDescendants?: boolean | undefined;
}
export interface DisallowIntermediateTableOutput {
}
export type AnalysisLogExportIdentifier = string;
export interface GetAnalysisLogExportInput {
    membershipIdentifier: string;
    analysisLogExportIdentifier: string;
}
export type LogExportAnalysisType = "PROTECTED_QUERY" | (string & {});
export type AnalysisLogExportStatus = "IN_PROGRESS" | "SUCCESS" | "FAILED" | (string & {});
export interface AnalysisLogExportS3OutputConfiguration {
    bucket: string;
    keyPrefix?: string | undefined;
}
export interface AnalysisLogExportOutputConfiguration {
    s3: AnalysisLogExportS3OutputConfiguration;
}
export interface AnalysisLogExportResultConfiguration {
    outputConfiguration: AnalysisLogExportOutputConfiguration;
}
export interface AnalysisLogExportError {
    code: string;
    message: string;
}
export interface AnalysisLogExport {
    analysisLogExportId: string;
    analysisId: string;
    analysisType: LogExportAnalysisType;
    membershipId: string;
    status: AnalysisLogExportStatus;
    resultConfiguration: AnalysisLogExportResultConfiguration;
    createTime: Date;
    updateTime: Date;
    error?: AnalysisLogExportError | undefined;
}
export interface GetAnalysisLogExportOutput {
    analysisLogExport: AnalysisLogExport;
}
export interface GetAnalysisTemplateInput {
    membershipIdentifier: string;
    analysisTemplateIdentifier: string;
}
export interface GetAnalysisTemplateOutput {
    analysisTemplate: AnalysisTemplate;
}
export interface GetCollaborationInput {
    collaborationIdentifier: string;
}
export interface GetCollaborationOutput {
    collaboration: Collaboration;
}
export interface GetCollaborationAnalysisTemplateInput {
    collaborationIdentifier: string;
    analysisTemplateArn: string;
}
export interface GetCollaborationAnalysisTemplateOutput {
    collaborationAnalysisTemplate: CollaborationAnalysisTemplate;
}
export type CollaborationChangeRequestIdentifier = string;
export interface GetCollaborationChangeRequestInput {
    collaborationIdentifier: string;
    changeRequestIdentifier: string;
}
export interface GetCollaborationChangeRequestOutput {
    collaborationChangeRequest: CollaborationChangeRequest;
}
export interface GetCollaborationConfiguredAudienceModelAssociationInput {
    collaborationIdentifier: string;
    configuredAudienceModelAssociationIdentifier: string;
}
export interface CollaborationConfiguredAudienceModelAssociation {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    configuredAudienceModelArn: string;
    name: string;
    description?: string | undefined;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
}
export interface GetCollaborationConfiguredAudienceModelAssociationOutput {
    collaborationConfiguredAudienceModelAssociation: CollaborationConfiguredAudienceModelAssociation;
}
export interface GetCollaborationIdNamespaceAssociationInput {
    collaborationIdentifier: string;
    idNamespaceAssociationIdentifier: string;
}
export interface CollaborationIdNamespaceAssociation {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    name: string;
    description?: string | undefined;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    inputReferenceProperties: IdNamespaceAssociationInputReferenceProperties;
    idMappingConfig?: IdMappingConfig | undefined;
}
export interface GetCollaborationIdNamespaceAssociationOutput {
    collaborationIdNamespaceAssociation: CollaborationIdNamespaceAssociation;
}
export interface GetCollaborationPrivacyBudgetTemplateInput {
    collaborationIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
}
export interface CollaborationPrivacyBudgetTemplate {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
    privacyBudgetType: PrivacyBudgetType;
    autoRefresh: PrivacyBudgetTemplateAutoRefresh;
    parameters: PrivacyBudgetTemplateParametersOutput;
}
export interface GetCollaborationPrivacyBudgetTemplateOutput {
    collaborationPrivacyBudgetTemplate: CollaborationPrivacyBudgetTemplate;
}
export interface GetConfiguredAudienceModelAssociationInput {
    configuredAudienceModelAssociationIdentifier: string;
    membershipIdentifier: string;
}
export interface GetConfiguredAudienceModelAssociationOutput {
    configuredAudienceModelAssociation: ConfiguredAudienceModelAssociation;
}
export interface GetConfiguredTableInput {
    configuredTableIdentifier: string;
}
export interface GetConfiguredTableOutput {
    configuredTable: ConfiguredTable;
}
export interface GetConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
}
export interface GetConfiguredTableAnalysisRuleOutput {
    analysisRule: ConfiguredTableAnalysisRule;
}
export interface GetConfiguredTableAssociationInput {
    configuredTableAssociationIdentifier: string;
    membershipIdentifier: string;
}
export interface GetConfiguredTableAssociationOutput {
    configuredTableAssociation: ConfiguredTableAssociation;
}
export interface GetConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
}
export interface GetConfiguredTableAssociationAnalysisRuleOutput {
    analysisRule: ConfiguredTableAssociationAnalysisRule;
}
export interface GetIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
}
export interface GetIdMappingTableOutput {
    idMappingTable: IdMappingTable;
}
export interface GetIdNamespaceAssociationInput {
    idNamespaceAssociationIdentifier: string;
    membershipIdentifier: string;
}
export interface GetIdNamespaceAssociationOutput {
    idNamespaceAssociation: IdNamespaceAssociation;
}
export interface GetIntermediateTableInput {
    intermediateTableIdentifier: string;
    membershipIdentifier: string;
}
export interface GetIntermediateTableOutput {
    intermediateTable: IntermediateTable;
}
export interface GetIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
}
export interface GetIntermediateTableAnalysisRuleOutput {
    analysisRule: IntermediateTableAnalysisRule;
}
export interface GetMembershipInput {
    membershipIdentifier: string;
}
export interface GetMembershipOutput {
    membership: Membership;
}
export interface GetPrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
}
export interface GetPrivacyBudgetTemplateOutput {
    privacyBudgetTemplate: PrivacyBudgetTemplate;
}
export type ProtectedJobIdentifier = string;
export interface GetProtectedJobInput {
    membershipIdentifier: string;
    protectedJobIdentifier: string;
}
export type JobParameterName = string;
export type JobParameterValue = string;
export type JobParameterMap = {
    [key: string]: string | undefined;
};
export interface ProtectedJobParameters {
    analysisTemplateArn: string;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProtectedJobStatus = "SUBMITTED" | "STARTED" | "CANCELLED" | "CANCELLING" | "FAILED" | "SUCCESS" | (string & {});
export interface ProtectedJobS3OutputConfigurationOutput {
    bucket: string;
    keyPrefix?: string | undefined;
}
export interface ProtectedJobMemberOutputConfigurationOutput {
    accountId: string;
}
export type ProtectedJobOutputConfigurationOutput = {
    s3: ProtectedJobS3OutputConfigurationOutput;
    member?: undefined;
} | {
    s3?: undefined;
    member: ProtectedJobMemberOutputConfigurationOutput;
};
export interface ProtectedJobResultConfigurationOutput {
    outputConfiguration: ProtectedJobOutputConfigurationOutput;
}
export interface BilledJobResourceUtilization {
    units: number;
}
export interface ProtectedJobStatistics {
    totalDurationInMillis?: number | undefined;
    billedResourceUtilization?: BilledJobResourceUtilization | undefined;
}
export interface ProtectedJobS3Output {
    location: string;
}
export interface ProtectedJobSingleMemberOutput {
    accountId: string;
}
export type ProtectedJobMemberOutputList = ProtectedJobSingleMemberOutput[];
export type ProtectedJobOutput = {
    s3: ProtectedJobS3Output;
    memberList?: undefined;
} | {
    s3?: undefined;
    memberList: ProtectedJobSingleMemberOutput[];
};
export interface ProtectedJobResult {
    output: ProtectedJobOutput;
}
export interface RetryInfo {
    retryable?: boolean | undefined;
}
export interface ProtectedJobError {
    message: string;
    code: string;
    retry?: RetryInfo | undefined;
}
export type ProtectedJobWorkerComputeType = "CR.1X" | "CR.4X" | (string & {});
export type SparkPropertyKey = string;
export type SparkPropertyValue = string;
export type SparkProperties = {
    [key: string]: string | undefined;
};
export type WorkerComputeConfigurationProperties = {
    spark: {
        [key: string]: string | undefined;
    };
};
export interface ProtectedJobWorkerComputeConfiguration {
    type: ProtectedJobWorkerComputeType;
    number: number;
    properties?: WorkerComputeConfigurationProperties | undefined;
}
export type ProtectedJobComputeConfiguration = {
    worker: ProtectedJobWorkerComputeConfiguration;
};
export interface ProtectedJob {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    jobParameters?: ProtectedJobParameters | undefined;
    status: ProtectedJobStatus;
    resultConfiguration?: ProtectedJobResultConfigurationOutput | undefined;
    statistics?: ProtectedJobStatistics | undefined;
    result?: ProtectedJobResult | undefined;
    error?: ProtectedJobError | undefined;
    computeConfiguration?: ProtectedJobComputeConfiguration | undefined;
    jobComputePayerAccountId?: string | undefined;
}
export interface GetProtectedJobOutput {
    protectedJob: ProtectedJob;
}
export type ProtectedQueryIdentifier = string;
export interface GetProtectedQueryInput {
    membershipIdentifier: string;
    protectedQueryIdentifier: string;
}
export interface ProtectedQuerySQLParameters {
    queryString?: string | undefined;
    analysisTemplateArn?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProtectedQueryStatus = string;
export interface ProtectedQueryMemberOutputConfiguration {
    accountId: string;
}
export type ProtectedQueryDistributeOutputConfigurationLocation = {
    s3: ProtectedQueryS3OutputConfiguration;
    member?: undefined;
} | {
    s3?: undefined;
    member: ProtectedQueryMemberOutputConfiguration;
};
export type ProtectedQueryDistributeOutputConfigurationLocations = ProtectedQueryDistributeOutputConfigurationLocation[];
export interface ProtectedQueryDistributeOutputConfiguration {
    locations: ProtectedQueryDistributeOutputConfigurationLocation[];
}
export interface IntermediateTableOutputConfiguration {
    id: string;
    arn: string;
    name: string;
}
export type ProtectedQueryOutputConfiguration = {
    s3: ProtectedQueryS3OutputConfiguration;
    member?: undefined;
    distribute?: undefined;
    intermediateTable?: undefined;
} | {
    s3?: undefined;
    member: ProtectedQueryMemberOutputConfiguration;
    distribute?: undefined;
    intermediateTable?: undefined;
} | {
    s3?: undefined;
    member?: undefined;
    distribute: ProtectedQueryDistributeOutputConfiguration;
    intermediateTable?: undefined;
} | {
    s3?: undefined;
    member?: undefined;
    distribute?: undefined;
    intermediateTable: IntermediateTableOutputConfiguration;
};
export interface ProtectedQueryResultConfiguration {
    outputConfiguration: ProtectedQueryOutputConfiguration;
}
export interface BilledResourceUtilization {
    units: number;
}
export interface ProtectedQueryStatistics {
    totalDurationInMillis?: number | undefined;
    billedResourceUtilization?: BilledResourceUtilization | undefined;
}
export interface ProtectedQueryS3Output {
    location: string;
}
export interface ProtectedQuerySingleMemberOutput {
    accountId: string;
}
export type ProtectedQueryMemberOutputList = ProtectedQuerySingleMemberOutput[];
export interface ProtectedQueryDistributeOutput {
    s3?: ProtectedQueryS3Output | undefined;
    memberList?: ProtectedQuerySingleMemberOutput[] | undefined;
}
export type ProtectedQueryOutput = {
    s3: ProtectedQueryS3Output;
    memberList?: undefined;
    distribute?: undefined;
} | {
    s3?: undefined;
    memberList: ProtectedQuerySingleMemberOutput[];
    distribute?: undefined;
} | {
    s3?: undefined;
    memberList?: undefined;
    distribute: ProtectedQueryDistributeOutput;
};
export interface ProtectedQueryResult {
    output: ProtectedQueryOutput;
}
export interface ProtectedQueryError {
    message: string;
    code: string;
    retry?: RetryInfo | undefined;
}
export type DifferentialPrivacyAggregationType = "AVG" | "COUNT" | "COUNT_DISTINCT" | "SUM" | "STDDEV" | (string & {});
export type DifferentialPrivacyAggregationExpression = string;
export interface DifferentialPrivacySensitivityParameters {
    aggregationType: DifferentialPrivacyAggregationType;
    aggregationExpression: string;
    userContributionLimit: number;
    minColumnValue?: number | undefined;
    maxColumnValue?: number | undefined;
}
export type DifferentialPrivacySensitivityParametersList = DifferentialPrivacySensitivityParameters[];
export interface DifferentialPrivacyParameters {
    sensitivityParameters: DifferentialPrivacySensitivityParameters[];
}
export type WorkerComputeType = "CR.1X" | "CR.4X" | "CR.8X" | (string & {});
export interface WorkerComputeConfiguration {
    type?: WorkerComputeType | undefined;
    number?: number | undefined;
    properties?: WorkerComputeConfigurationProperties | undefined;
}
export type ComputeConfiguration = {
    worker: WorkerComputeConfiguration;
};
export interface ProtectedQuery {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    sqlParameters?: ProtectedQuerySQLParameters | undefined;
    status: string;
    resultConfiguration?: ProtectedQueryResultConfiguration | undefined;
    statistics?: ProtectedQueryStatistics | undefined;
    result?: ProtectedQueryResult | undefined;
    error?: ProtectedQueryError | undefined;
    differentialPrivacy?: DifferentialPrivacyParameters | undefined;
    computeConfiguration?: ComputeConfiguration | undefined;
    queryComputePayerAccountId?: string | undefined;
}
export interface GetProtectedQueryOutput {
    protectedQuery: ProtectedQuery;
}
export interface GetSchemaInput {
    collaborationIdentifier: string;
    name: string;
}
export interface GetSchemaOutput {
    schema: Schema;
}
export interface GetSchemaAnalysisRuleInput {
    collaborationIdentifier: string;
    name: string;
    type: AnalysisRuleType;
}
export interface GetSchemaAnalysisRuleOutput {
    analysisRule: AnalysisRule;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListAnalysisLogExportsInput {
    membershipIdentifier: string;
    analysisIdentifier?: string | undefined;
    status?: AnalysisLogExportStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AnalysisLogExportSummary {
    analysisLogExportId: string;
    analysisId: string;
    analysisType: LogExportAnalysisType;
    status: AnalysisLogExportStatus;
    createTime: Date;
}
export type AnalysisLogExportSummaryList = AnalysisLogExportSummary[];
export interface ListAnalysisLogExportsOutput {
    nextToken?: string | undefined;
    analysisLogExports: AnalysisLogExportSummary[];
}
export interface ListAnalysisTemplatesInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AnalysisTemplateSummary {
    arn: string;
    createTime: Date;
    id: string;
    name: string;
    updateTime: Date;
    membershipArn: string;
    membershipId: string;
    collaborationArn: string;
    collaborationId: string;
    description?: string | undefined;
    isSyntheticData?: boolean | undefined;
}
export type AnalysisTemplateSummaryList = AnalysisTemplateSummary[];
export interface ListAnalysisTemplatesOutput {
    nextToken?: string | undefined;
    analysisTemplateSummaries: AnalysisTemplateSummary[];
}
export interface ListCollaborationAnalysisTemplatesInput {
    collaborationIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CollaborationAnalysisTemplateSummary {
    arn: string;
    createTime: Date;
    id: string;
    name: string;
    updateTime: Date;
    collaborationArn: string;
    collaborationId: string;
    creatorAccountId: string;
    description?: string | undefined;
    isSyntheticData?: boolean | undefined;
}
export type CollaborationAnalysisTemplateSummaryList = CollaborationAnalysisTemplateSummary[];
export interface ListCollaborationAnalysisTemplatesOutput {
    nextToken?: string | undefined;
    collaborationAnalysisTemplateSummaries: CollaborationAnalysisTemplateSummary[];
}
export interface ListCollaborationChangeRequestsInput {
    collaborationIdentifier: string;
    status?: ChangeRequestStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CollaborationChangeRequestSummary {
    id: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    status: ChangeRequestStatus;
    isAutoApproved: boolean;
    changes: Change[];
    approvals?: {
        [key: string]: ApprovalStatusDetails | undefined;
    } | undefined;
}
export type CollaborationChangeRequestSummaryList = CollaborationChangeRequestSummary[];
export interface ListCollaborationChangeRequestsOutput {
    collaborationChangeRequestSummaries: CollaborationChangeRequestSummary[];
    nextToken?: string | undefined;
}
export interface ListCollaborationConfiguredAudienceModelAssociationsInput {
    collaborationIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CollaborationConfiguredAudienceModelAssociationSummary {
    arn: string;
    createTime: Date;
    id: string;
    name: string;
    updateTime: Date;
    collaborationArn: string;
    collaborationId: string;
    creatorAccountId: string;
    description?: string | undefined;
}
export type CollaborationConfiguredAudienceModelAssociationSummaryList = CollaborationConfiguredAudienceModelAssociationSummary[];
export interface ListCollaborationConfiguredAudienceModelAssociationsOutput {
    collaborationConfiguredAudienceModelAssociationSummaries: CollaborationConfiguredAudienceModelAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListCollaborationIdNamespaceAssociationsInput {
    collaborationIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IdNamespaceAssociationInputReferencePropertiesSummary {
    idNamespaceType: IdNamespaceType;
}
export interface CollaborationIdNamespaceAssociationSummary {
    arn: string;
    createTime: Date;
    id: string;
    updateTime: Date;
    collaborationArn: string;
    collaborationId: string;
    creatorAccountId: string;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    name: string;
    description?: string | undefined;
    inputReferenceProperties: IdNamespaceAssociationInputReferencePropertiesSummary;
}
export type CollaborationIdNamespaceAssociationSummaryList = CollaborationIdNamespaceAssociationSummary[];
export interface ListCollaborationIdNamespaceAssociationsOutput {
    nextToken?: string | undefined;
    collaborationIdNamespaceAssociationSummaries: CollaborationIdNamespaceAssociationSummary[];
}
export interface ListCollaborationPrivacyBudgetsInput {
    collaborationIdentifier: string;
    privacyBudgetType: PrivacyBudgetType;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accessBudgetResourceArn?: string | undefined;
}
export interface DifferentialPrivacyPrivacyBudgetAggregation {
    type: DifferentialPrivacyAggregationType;
    maxCount: number;
    remainingCount: number;
}
export type DifferentialPrivacyPrivacyBudgetAggregationList = DifferentialPrivacyPrivacyBudgetAggregation[];
export interface DifferentialPrivacyPrivacyBudget {
    aggregations: DifferentialPrivacyPrivacyBudgetAggregation[];
    epsilon: number;
}
export type RemainingBudget = number;
export interface AccessBudgetDetails {
    startTime: Date;
    endTime?: Date | undefined;
    remainingBudget: number;
    budget: number;
    budgetType: AccessBudgetType;
    autoRefresh?: AutoRefreshMode | undefined;
}
export type AccessBudgetDetailsList = AccessBudgetDetails[];
export interface AccessBudget {
    resourceArn: string;
    details: AccessBudgetDetails[];
    aggregateRemainingBudget: number;
}
export type PrivacyBudget = {
    differentialPrivacy: DifferentialPrivacyPrivacyBudget;
    accessBudget?: undefined;
} | {
    differentialPrivacy?: undefined;
    accessBudget: AccessBudget;
};
export interface CollaborationPrivacyBudgetSummary {
    id: string;
    privacyBudgetTemplateId: string;
    privacyBudgetTemplateArn: string;
    collaborationId: string;
    collaborationArn: string;
    creatorAccountId: string;
    type: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
    budget: PrivacyBudget;
}
export type CollaborationPrivacyBudgetSummaryList = CollaborationPrivacyBudgetSummary[];
export interface ListCollaborationPrivacyBudgetsOutput {
    collaborationPrivacyBudgetSummaries: CollaborationPrivacyBudgetSummary[];
    nextToken?: string | undefined;
}
export interface ListCollaborationPrivacyBudgetTemplatesInput {
    collaborationIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CollaborationPrivacyBudgetTemplateSummary {
    id: string;
    arn: string;
    collaborationId: string;
    collaborationArn: string;
    creatorAccountId: string;
    privacyBudgetType: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
}
export type CollaborationPrivacyBudgetTemplateSummaryList = CollaborationPrivacyBudgetTemplateSummary[];
export interface ListCollaborationPrivacyBudgetTemplatesOutput {
    nextToken?: string | undefined;
    collaborationPrivacyBudgetTemplateSummaries: CollaborationPrivacyBudgetTemplateSummary[];
}
export type FilterableMemberStatus = string;
export interface ListCollaborationsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    memberStatus?: string | undefined;
}
export interface CollaborationSummary {
    id: string;
    arn: string;
    name: string;
    creatorAccountId: string;
    creatorDisplayName: string;
    createTime: Date;
    updateTime: Date;
    memberStatus: string;
    membershipId?: string | undefined;
    membershipArn?: string | undefined;
    analyticsEngine?: AnalyticsEngine | undefined;
}
export type CollaborationSummaryList = CollaborationSummary[];
export interface ListCollaborationsOutput {
    nextToken?: string | undefined;
    collaborationList: CollaborationSummary[];
}
export interface ListConfiguredAudienceModelAssociationsInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ConfiguredAudienceModelAssociationSummary {
    membershipId: string;
    membershipArn: string;
    collaborationArn: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    name: string;
    configuredAudienceModelArn: string;
    description?: string | undefined;
}
export type ConfiguredAudienceModelAssociationSummaryList = ConfiguredAudienceModelAssociationSummary[];
export interface ListConfiguredAudienceModelAssociationsOutput {
    configuredAudienceModelAssociationSummaries: ConfiguredAudienceModelAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListConfiguredTableAssociationsInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ConfiguredTableAssociationSummary {
    configuredTableId: string;
    membershipId: string;
    membershipArn: string;
    name: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    analysisRuleTypes?: ConfiguredTableAssociationAnalysisRuleType[] | undefined;
}
export type ConfiguredTableAssociationSummaryList = ConfiguredTableAssociationSummary[];
export interface ListConfiguredTableAssociationsOutput {
    configuredTableAssociationSummaries: ConfiguredTableAssociationSummary[];
    nextToken?: string | undefined;
}
export interface ListConfiguredTablesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ConfiguredTableSummary {
    id: string;
    arn: string;
    name: string;
    tableType?: TableReferenceType | undefined;
    createTime: Date;
    updateTime: Date;
    analysisRuleTypes: ConfiguredTableAnalysisRuleType[];
    analysisMethod: AnalysisMethod;
    selectedAnalysisMethods?: SelectedAnalysisMethod[] | undefined;
}
export type ConfiguredTableSummaryList = ConfiguredTableSummary[];
export interface ListConfiguredTablesOutput {
    configuredTableSummaries: ConfiguredTableSummary[];
    nextToken?: string | undefined;
}
export interface ListIdMappingTablesInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IdMappingTableSummary {
    collaborationArn: string;
    collaborationId: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    description?: string | undefined;
    inputReferenceConfig: IdMappingTableInputReferenceConfig;
    name: string;
}
export type IdMappingTableSummaryList = IdMappingTableSummary[];
export interface ListIdMappingTablesOutput {
    idMappingTableSummaries: IdMappingTableSummary[];
    nextToken?: string | undefined;
}
export interface ListIdNamespaceAssociationsInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IdNamespaceAssociationSummary {
    membershipId: string;
    membershipArn: string;
    collaborationArn: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    id: string;
    arn: string;
    inputReferenceConfig: IdNamespaceAssociationInputReferenceConfig;
    name: string;
    description?: string | undefined;
    inputReferenceProperties: IdNamespaceAssociationInputReferencePropertiesSummary;
}
export type IdNamespaceAssociationSummaryList = IdNamespaceAssociationSummary[];
export interface ListIdNamespaceAssociationsOutput {
    nextToken?: string | undefined;
    idNamespaceAssociationSummaries: IdNamespaceAssociationSummary[];
}
export interface ListIntermediateTablesInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IntermediateTableSummary {
    id: string;
    arn: string;
    name: string;
    description?: string | undefined;
    membershipArn: string;
    membershipId: string;
    collaborationArn: string;
    collaborationId: string;
    createTime: Date;
    updateTime: Date;
    status: IntermediateTableStatus;
    retentionInDays?: number | undefined;
    analysisRuleTypes?: IntermediateTableAnalysisRuleType[] | undefined;
}
export type IntermediateTableSummaryList = IntermediateTableSummary[];
export interface ListIntermediateTablesOutput {
    intermediateTableSummaries: IntermediateTableSummary[];
    nextToken?: string | undefined;
}
export interface ListIntermediateTableVersionsInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type IntermediateTableVersionStatus = "POPULATE_STARTED" | "POPULATE_SUCCESS" | "POPULATE_FAILED" | "RETENTION_PERIOD_EXPIRED" | (string & {});
export interface IntermediateTableVersionSummary {
    versionId: string;
    tableId: string;
    createTime: Date;
    analysisId: string;
    status: IntermediateTableVersionStatus;
    analysisType: PopulateIntermediateTableAnalysisType;
    kmsKeyArn?: string | undefined;
    expirationTime?: Date | undefined;
}
export type IntermediateTableVersionSummaryList = IntermediateTableVersionSummary[];
export interface ListIntermediateTableVersionsOutput {
    intermediateTableVersionSummaries: IntermediateTableVersionSummary[];
    nextToken?: string | undefined;
}
export interface ListMembersInput {
    collaborationIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface MemberSummary {
    accountId: string;
    status: string;
    displayName: string;
    abilities: MemberAbility[];
    mlAbilities?: MLMemberAbilities | undefined;
    createTime: Date;
    updateTime: Date;
    membershipId?: string | undefined;
    membershipArn?: string | undefined;
    paymentConfiguration: PaymentConfiguration;
}
export type MemberSummaryList = MemberSummary[];
export interface ListMembersOutput {
    nextToken?: string | undefined;
    memberSummaries: MemberSummary[];
}
export interface ListMembershipsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    status?: string | undefined;
}
export interface MembershipSummary {
    id: string;
    arn: string;
    collaborationArn: string;
    collaborationId: string;
    collaborationCreatorAccountId: string;
    collaborationCreatorDisplayName: string;
    collaborationName: string;
    createTime: Date;
    updateTime: Date;
    status: string;
    memberAbilities: MemberAbility[];
    mlMemberAbilities?: MLMemberAbilities | undefined;
    paymentConfiguration: MembershipPaymentConfiguration;
}
export type MembershipSummaryList = MembershipSummary[];
export interface ListMembershipsOutput {
    nextToken?: string | undefined;
    membershipSummaries: MembershipSummary[];
}
export interface ListPrivacyBudgetsInput {
    membershipIdentifier: string;
    privacyBudgetType: PrivacyBudgetType;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    accessBudgetResourceArn?: string | undefined;
}
export interface PrivacyBudgetSummary {
    id: string;
    privacyBudgetTemplateId: string;
    privacyBudgetTemplateArn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    type: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
    budget: PrivacyBudget;
}
export type PrivacyBudgetSummaryList = PrivacyBudgetSummary[];
export interface ListPrivacyBudgetsOutput {
    privacyBudgetSummaries: PrivacyBudgetSummary[];
    nextToken?: string | undefined;
}
export interface ListPrivacyBudgetTemplatesInput {
    membershipIdentifier: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PrivacyBudgetTemplateSummary {
    id: string;
    arn: string;
    membershipId: string;
    membershipArn: string;
    collaborationId: string;
    collaborationArn: string;
    privacyBudgetType: PrivacyBudgetType;
    createTime: Date;
    updateTime: Date;
}
export type PrivacyBudgetTemplateSummaryList = PrivacyBudgetTemplateSummary[];
export interface ListPrivacyBudgetTemplatesOutput {
    nextToken?: string | undefined;
    privacyBudgetTemplateSummaries: PrivacyBudgetTemplateSummary[];
}
export interface ListProtectedJobsInput {
    membershipIdentifier: string;
    status?: ProtectedJobStatus | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ProtectedJobAnalysisType = "DIRECT_ANALYSIS" | (string & {});
export type ProtectedJobReceiverAccountIds = string[];
export interface ProtectedJobDirectAnalysisConfigurationDetails {
    receiverAccountIds?: string[] | undefined;
}
export type ProtectedJobConfigurationDetails = {
    directAnalysisConfigurationDetails: ProtectedJobDirectAnalysisConfigurationDetails;
};
export interface ProtectedJobReceiverConfiguration {
    analysisType: ProtectedJobAnalysisType;
    configurationDetails?: ProtectedJobConfigurationDetails | undefined;
}
export type ProtectedJobReceiverConfigurations = ProtectedJobReceiverConfiguration[];
export interface ProtectedJobSummary {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    status: ProtectedJobStatus;
    receiverConfigurations: ProtectedJobReceiverConfiguration[];
    jobComputePayerAccountId?: string | undefined;
}
export type ProtectedJobSummaryList = ProtectedJobSummary[];
export interface ListProtectedJobsOutput {
    nextToken?: string | undefined;
    protectedJobs: ProtectedJobSummary[];
}
export interface ListProtectedQueriesInput {
    membershipIdentifier: string;
    status?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ReceiverAccountIds = string[];
export interface DirectAnalysisConfigurationDetails {
    receiverAccountIds?: string[] | undefined;
}
export type ConfigurationDetails = {
    directAnalysisConfigurationDetails: DirectAnalysisConfigurationDetails;
};
export interface ReceiverConfiguration {
    analysisType: AnalysisType;
    configurationDetails?: ConfigurationDetails | undefined;
}
export type ReceiverConfigurationsList = ReceiverConfiguration[];
export interface ProtectedQuerySummary {
    id: string;
    membershipId: string;
    membershipArn: string;
    createTime: Date;
    status: string;
    receiverConfigurations: ReceiverConfiguration[];
    queryComputePayerAccountId?: string | undefined;
    intermediateTableConfiguration?: IntermediateTableOutputConfiguration | undefined;
}
export type ProtectedQuerySummaryList = ProtectedQuerySummary[];
export interface ListProtectedQueriesOutput {
    nextToken?: string | undefined;
    protectedQueries: ProtectedQuerySummary[];
}
export interface ListSchemasInput {
    collaborationIdentifier: string;
    schemaType?: SchemaType | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SchemaSummary {
    name: string;
    type: SchemaType;
    creatorAccountId: string;
    createTime: Date;
    updateTime: Date;
    collaborationId: string;
    collaborationArn: string;
    analysisRuleTypes: AnalysisRuleType[];
    analysisMethod?: AnalysisMethod | undefined;
    resourceArn?: string | undefined;
    selectedAnalysisMethods?: SelectedAnalysisMethod[] | undefined;
}
export type SchemaSummaryList = SchemaSummary[];
export interface ListSchemasOutput {
    schemaSummaries: SchemaSummary[];
    nextToken?: string | undefined;
}
export type CleanroomsArn = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags: {
        [key: string]: string | undefined;
    };
}
export type JobType = "BATCH" | "INCREMENTAL" | "DELETE_ONLY" | (string & {});
export interface PopulateIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
    jobType?: JobType | undefined;
}
export interface PopulateIdMappingTableOutput {
    idMappingJobId: string;
}
export type IntermediateTableComputeConfiguration = {
    queryComputeConfiguration: WorkerComputeConfiguration;
};
export interface PopulateIntermediateTableInput {
    intermediateTableIdentifier: string;
    membershipIdentifier: string;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    computeConfiguration?: IntermediateTableComputeConfiguration | undefined;
    analysisPayerAccountId?: string | undefined;
}
export interface PopulateIntermediateTableOutput {
    analysisId: string;
    analysisType: PopulateIntermediateTableAnalysisType;
    versionId: string;
}
export interface DifferentialPrivacyPreviewParametersInput {
    epsilon: number;
    usersNoisePerQuery: number;
}
export type PreviewPrivacyImpactParametersInput = {
    differentialPrivacy: DifferentialPrivacyPreviewParametersInput;
};
export interface PreviewPrivacyImpactInput {
    membershipIdentifier: string;
    parameters: PreviewPrivacyImpactParametersInput;
}
export interface DifferentialPrivacyPreviewAggregation {
    type: DifferentialPrivacyAggregationType;
    maxCount: number;
}
export type DifferentialPrivacyPreviewAggregationList = DifferentialPrivacyPreviewAggregation[];
export interface DifferentialPrivacyPrivacyImpact {
    aggregations: DifferentialPrivacyPreviewAggregation[];
}
export type PrivacyImpact = {
    differentialPrivacy: DifferentialPrivacyPrivacyImpact;
};
export interface PreviewPrivacyImpactOutput {
    privacyImpact: PrivacyImpact;
}
export interface StartAnalysisLogExportInput {
    membershipIdentifier: string;
    analysisId: string;
    analysisType: LogExportAnalysisType;
    resultConfiguration: AnalysisLogExportResultConfiguration;
}
export interface StartAnalysisLogExportOutput {
    analysisLogExport: AnalysisLogExport;
}
export type ProtectedJobType = "PYSPARK" | (string & {});
export interface ProtectedJobMemberOutputConfigurationInput {
    accountId: string;
}
export type ProtectedJobOutputConfigurationInput = {
    member: ProtectedJobMemberOutputConfigurationInput;
};
export interface ProtectedJobResultConfigurationInput {
    outputConfiguration: ProtectedJobOutputConfigurationInput;
}
export interface StartProtectedJobInput {
    type: ProtectedJobType;
    membershipIdentifier: string;
    jobParameters: ProtectedJobParameters;
    resultConfiguration?: ProtectedJobResultConfigurationInput | undefined;
    computeConfiguration?: ProtectedJobComputeConfiguration | undefined;
    jobComputePayerAccountId?: string | undefined;
}
export interface StartProtectedJobOutput {
    protectedJob: ProtectedJob;
}
export type ProtectedQueryType = string;
export interface StartProtectedQueryInput {
    type: string;
    membershipIdentifier: string;
    sqlParameters: ProtectedQuerySQLParameters;
    resultConfiguration?: ProtectedQueryResultConfiguration | undefined;
    computeConfiguration?: ComputeConfiguration | undefined;
    queryComputePayerAccountId?: string | undefined;
}
export interface StartProtectedQueryOutput {
    protectedQuery: ProtectedQuery;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateAnalysisTemplateInput {
    membershipIdentifier: string;
    analysisTemplateIdentifier: string;
    description?: string | undefined;
}
export interface UpdateAnalysisTemplateOutput {
    analysisTemplate: AnalysisTemplate;
}
export interface UpdateCollaborationInput {
    collaborationIdentifier: string;
    name?: string | undefined;
    description?: string | undefined;
    analyticsEngine?: AnalyticsEngine | undefined;
}
export interface UpdateCollaborationOutput {
    collaboration: Collaboration;
}
export type ChangeRequestAction = "APPROVE" | "DENY" | "CANCEL" | "COMMIT" | (string & {});
export interface UpdateCollaborationChangeRequestInput {
    collaborationIdentifier: string;
    changeRequestIdentifier: string;
    action: ChangeRequestAction;
}
export interface UpdateCollaborationChangeRequestOutput {
    collaborationChangeRequest: CollaborationChangeRequest;
}
export interface UpdateConfiguredAudienceModelAssociationInput {
    configuredAudienceModelAssociationIdentifier: string;
    membershipIdentifier: string;
    description?: string | undefined;
    name?: string | undefined;
}
export interface UpdateConfiguredAudienceModelAssociationOutput {
    configuredAudienceModelAssociation: ConfiguredAudienceModelAssociation;
}
export interface UpdateConfiguredTableInput {
    configuredTableIdentifier: string;
    name?: string | undefined;
    description?: string | undefined;
    tableReference?: TableReference | undefined;
    allowedColumns?: string[] | undefined;
    analysisMethod?: AnalysisMethod | undefined;
    selectedAnalysisMethods?: SelectedAnalysisMethod[] | undefined;
}
export interface UpdateConfiguredTableOutput {
    configuredTable: ConfiguredTable;
}
export interface UpdateConfiguredTableAnalysisRuleInput {
    configuredTableIdentifier: string;
    analysisRuleType: ConfiguredTableAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAnalysisRulePolicy;
}
export interface UpdateConfiguredTableAnalysisRuleOutput {
    analysisRule: ConfiguredTableAnalysisRule;
}
export interface UpdateConfiguredTableAssociationInput {
    configuredTableAssociationIdentifier: string;
    membershipIdentifier: string;
    description?: string | undefined;
    roleArn?: string | undefined;
}
export interface UpdateConfiguredTableAssociationOutput {
    configuredTableAssociation: ConfiguredTableAssociation;
}
export interface UpdateConfiguredTableAssociationAnalysisRuleInput {
    membershipIdentifier: string;
    configuredTableAssociationIdentifier: string;
    analysisRuleType: ConfiguredTableAssociationAnalysisRuleType;
    analysisRulePolicy: ConfiguredTableAssociationAnalysisRulePolicy;
}
export interface UpdateConfiguredTableAssociationAnalysisRuleOutput {
    analysisRule: ConfiguredTableAssociationAnalysisRule;
}
export interface UpdateIdMappingTableInput {
    idMappingTableIdentifier: string;
    membershipIdentifier: string;
    description?: string | undefined;
    kmsKeyArn?: string | undefined;
}
export interface UpdateIdMappingTableOutput {
    idMappingTable: IdMappingTable;
}
export interface UpdateIdNamespaceAssociationInput {
    idNamespaceAssociationIdentifier: string;
    membershipIdentifier: string;
    name?: string | undefined;
    description?: string | undefined;
    idMappingConfig?: IdMappingConfig | undefined;
}
export interface UpdateIdNamespaceAssociationOutput {
    idNamespaceAssociation: IdNamespaceAssociation;
}
export type IntermediateTableColumnTypeString = string;
export interface IntermediateTableColumn {
    name: string;
    type: string;
}
export type IntermediateTableColumnList = IntermediateTableColumn[];
export interface UpdateIntermediateTableInput {
    intermediateTableIdentifier: string;
    membershipIdentifier: string;
    description?: string | undefined;
    kmsKeyArn?: string | undefined;
    columns?: IntermediateTableColumn[] | undefined;
}
export interface UpdateIntermediateTableOutput {
    intermediateTable: IntermediateTable;
}
export interface UpdateIntermediateTableAnalysisRuleInput {
    membershipIdentifier: string;
    intermediateTableIdentifier: string;
    analysisRuleType: IntermediateTableAnalysisRuleType;
    analysisRulePolicy: IntermediateTableAnalysisRulePolicy;
}
export interface UpdateIntermediateTableAnalysisRuleOutput {
    analysisRule: IntermediateTableAnalysisRule;
}
export interface UpdateMembershipPaymentConfiguration {
    queryCompute?: MembershipQueryComputePaymentConfig | undefined;
    machineLearning?: MembershipMLPaymentConfig | undefined;
    jobCompute?: MembershipJobComputePaymentConfig | undefined;
}
export interface UpdateMembershipInput {
    membershipIdentifier: string;
    queryLogStatus?: MembershipQueryLogStatus | undefined;
    jobLogStatus?: MembershipJobLogStatus | undefined;
    defaultResultConfiguration?: MembershipProtectedQueryResultConfiguration | undefined;
    defaultJobResultConfiguration?: MembershipProtectedJobResultConfiguration | undefined;
    membershipPaymentConfiguration?: UpdateMembershipPaymentConfiguration | undefined;
}
export interface UpdateMembershipOutput {
    membership: Membership;
}
export interface DifferentialPrivacyTemplateUpdateParameters {
    epsilon?: number | undefined;
    usersNoisePerQuery?: number | undefined;
}
export interface AccessBudgetsPrivacyTemplateUpdateParameters {
    budgetParameters: BudgetParameter[];
}
export type PrivacyBudgetTemplateUpdateParameters = {
    differentialPrivacy: DifferentialPrivacyTemplateUpdateParameters;
    accessBudget?: undefined;
} | {
    differentialPrivacy?: undefined;
    accessBudget: AccessBudgetsPrivacyTemplateUpdateParameters;
};
export interface UpdatePrivacyBudgetTemplateInput {
    membershipIdentifier: string;
    privacyBudgetTemplateIdentifier: string;
    privacyBudgetType: PrivacyBudgetType;
    parameters?: PrivacyBudgetTemplateUpdateParameters | undefined;
}
export interface UpdatePrivacyBudgetTemplateOutput {
    privacyBudgetTemplate: PrivacyBudgetTemplate;
}
export type TargetProtectedJobStatus = "CANCELLED" | (string & {});
export interface UpdateProtectedJobInput {
    membershipIdentifier: string;
    protectedJobIdentifier: string;
    targetStatus: TargetProtectedJobStatus;
}
export interface UpdateProtectedJobOutput {
    protectedJob: ProtectedJob;
}
export type TargetProtectedQueryStatus = string;
export interface UpdateProtectedQueryInput {
    membershipIdentifier: string;
    protectedQueryIdentifier: string;
    targetStatus: string;
}
export interface UpdateProtectedQueryOutput {
    protectedQuery: ProtectedQuery;
}
export type AccessDeniedExceptionReason = string;
export type ResourceType = string;
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type ConflictExceptionReason = string;
export type BatchGetCollaborationAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves multiple analysis templates within a collaboration by their Amazon Resource Names (ARNs).
 */
export declare const batchGetCollaborationAnalysisTemplate: API.OperationMethod<BatchGetCollaborationAnalysisTemplateInput & RegionInput, BatchGetCollaborationAnalysisTemplateOutput, BatchGetCollaborationAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type BatchGetSchemaError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves multiple schemas by their identifiers.
 */
export declare const batchGetSchema: API.OperationMethod<BatchGetSchemaInput & RegionInput, BatchGetSchemaOutput, BatchGetSchemaError, Credentials | HttpClient.HttpClient>;
export type BatchGetSchemaAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves multiple analysis rule schemas.
 */
export declare const batchGetSchemaAnalysisRule: API.OperationMethod<BatchGetSchemaAnalysisRuleInput & RegionInput, BatchGetSchemaAnalysisRuleOutput, BatchGetSchemaAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateAnalysisTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new analysis template.
 */
export declare const createAnalysisTemplate: API.OperationMethod<CreateAnalysisTemplateInput & RegionInput, CreateAnalysisTemplateOutput, CreateAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateCollaborationError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new collaboration.
 */
export declare const createCollaboration: API.OperationMethod<CreateCollaborationInput & RegionInput, CreateCollaborationOutput, CreateCollaborationError, Credentials | HttpClient.HttpClient>;
export type CreateCollaborationChangeRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new change request to modify an existing collaboration. This enables post-creation modifications to collaborations through a structured API-driven approach.
 */
export declare const createCollaborationChangeRequest: API.OperationMethod<CreateCollaborationChangeRequestInput & RegionInput, CreateCollaborationChangeRequestOutput, CreateCollaborationChangeRequestError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredAudienceModelAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details necessary to create a configured audience model association.
 */
export declare const createConfiguredAudienceModelAssociation: API.OperationMethod<CreateConfiguredAudienceModelAssociationInput & RegionInput, CreateConfiguredAudienceModelAssociationOutput, CreateConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new configured table resource.
 */
export declare const createConfiguredTable: API.OperationMethod<CreateConfiguredTableInput & RegionInput, CreateConfiguredTableOutput, CreateConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new analysis rule for a configured table. Currently, only one analysis rule can be created for a given configured table.
 */
export declare const createConfiguredTableAnalysisRule: API.OperationMethod<CreateConfiguredTableAnalysisRuleInput & RegionInput, CreateConfiguredTableAnalysisRuleOutput, CreateConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a configured table association. A configured table association links a configured table with a collaboration.
 */
export declare const createConfiguredTableAssociation: API.OperationMethod<CreateConfiguredTableAssociationInput & RegionInput, CreateConfiguredTableAssociationOutput, CreateConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new analysis rule for an associated configured table.
 */
export declare const createConfiguredTableAssociationAnalysisRule: API.OperationMethod<CreateConfiguredTableAssociationAnalysisRuleInput & RegionInput, CreateConfiguredTableAssociationAnalysisRuleOutput, CreateConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateIdMappingTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ID mapping table.
 */
export declare const createIdMappingTable: API.OperationMethod<CreateIdMappingTableInput & RegionInput, CreateIdMappingTableOutput, CreateIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type CreateIdNamespaceAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ID namespace association.
 */
export declare const createIdNamespaceAssociation: API.OperationMethod<CreateIdNamespaceAssociationInput & RegionInput, CreateIdNamespaceAssociationOutput, CreateIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an intermediate table in a membership. The intermediate table is owned by the member with the CAN_QUERY ability. To populate the table with results, use `PopulateIntermediateTable`.
 */
export declare const createIntermediateTable: API.OperationMethod<CreateIntermediateTableInput & RegionInput, CreateIntermediateTableOutput, CreateIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type CreateIntermediateTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an analysis rule for an intermediate table. Only the CUSTOM analysis rule type is supported. Only the intermediate table owner can call this operation.
 */
export declare const createIntermediateTableAnalysisRule: API.OperationMethod<CreateIntermediateTableAnalysisRuleInput & RegionInput, CreateIntermediateTableAnalysisRuleOutput, CreateIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type CreateMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a membership for a specific collaboration identifier and joins the collaboration.
 */
export declare const createMembership: API.OperationMethod<CreateMembershipInput & RegionInput, CreateMembershipOutput, CreateMembershipError, Credentials | HttpClient.HttpClient>;
export type CreatePrivacyBudgetTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a privacy budget template for a specified collaboration. Each collaboration can have only one privacy budget template. If you need to change the privacy budget template, use the UpdatePrivacyBudgetTemplate operation.
 */
export declare const createPrivacyBudgetTemplate: API.OperationMethod<CreatePrivacyBudgetTemplateInput & RegionInput, CreatePrivacyBudgetTemplateOutput, CreatePrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an analysis template.
 */
export declare const deleteAnalysisTemplate: API.OperationMethod<DeleteAnalysisTemplateInput & RegionInput, DeleteAnalysisTemplateOutput, DeleteAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteCollaborationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a collaboration. It can only be called by the collaboration owner.
 */
export declare const deleteCollaboration: API.OperationMethod<DeleteCollaborationInput & RegionInput, DeleteCollaborationOutput, DeleteCollaborationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the information necessary to delete a configured audience model association.
 */
export declare const deleteConfiguredAudienceModelAssociation: API.OperationMethod<DeleteConfiguredAudienceModelAssociationInput & RegionInput, DeleteConfiguredAudienceModelAssociationOutput, DeleteConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured table.
 */
export declare const deleteConfiguredTable: API.OperationMethod<DeleteConfiguredTableInput & RegionInput, DeleteConfiguredTableOutput, DeleteConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured table analysis rule.
 */
export declare const deleteConfiguredTableAnalysisRule: API.OperationMethod<DeleteConfiguredTableAnalysisRuleInput & RegionInput, DeleteConfiguredTableAnalysisRuleOutput, DeleteConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a configured table association.
 */
export declare const deleteConfiguredTableAssociation: API.OperationMethod<DeleteConfiguredTableAssociationInput & RegionInput, DeleteConfiguredTableAssociationOutput, DeleteConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an analysis rule for a configured table association.
 */
export declare const deleteConfiguredTableAssociationAnalysisRule: API.OperationMethod<DeleteConfiguredTableAssociationAnalysisRuleInput & RegionInput, DeleteConfiguredTableAssociationAnalysisRuleOutput, DeleteConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteIdMappingTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ID mapping table.
 */
export declare const deleteIdMappingTable: API.OperationMethod<DeleteIdMappingTableInput & RegionInput, DeleteIdMappingTableOutput, DeleteIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type DeleteIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ID namespace association.
 */
export declare const deleteIdNamespaceAssociation: API.OperationMethod<DeleteIdNamespaceAssociationInput & RegionInput, DeleteIdNamespaceAssociationOutput, DeleteIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an intermediate table. The delete is idempotent. Only the intermediate table owner can call this operation.
 */
export declare const deleteIntermediateTable: API.OperationMethod<DeleteIntermediateTableInput & RegionInput, DeleteIntermediateTableOutput, DeleteIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type DeleteIntermediateTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an analysis rule from an intermediate table. After the analysis rule is deleted, the intermediate table becomes unqueryable until a new analysis rule is attached. Only the intermediate table owner can call this operation.
 */
export declare const deleteIntermediateTableAnalysisRule: API.OperationMethod<DeleteIntermediateTableAnalysisRuleInput & RegionInput, DeleteIntermediateTableAnalysisRuleOutput, DeleteIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified member from a collaboration. The removed member is placed in the Removed status and can't interact with the collaboration. The removed member's data is inaccessible to active members of the collaboration.
 */
export declare const deleteMember: API.OperationMethod<DeleteMemberInput & RegionInput, DeleteMemberOutput, DeleteMemberError, Credentials | HttpClient.HttpClient>;
export type DeleteMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified membership. All resources under a membership must be deleted.
 */
export declare const deleteMembership: API.OperationMethod<DeleteMembershipInput & RegionInput, DeleteMembershipOutput, DeleteMembershipError, Credentials | HttpClient.HttpClient>;
export type DeletePrivacyBudgetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a privacy budget template for a specified collaboration.
 */
export declare const deletePrivacyBudgetTemplate: API.OperationMethod<DeletePrivacyBudgetTemplateInput & RegionInput, DeletePrivacyBudgetTemplateOutput, DeletePrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type DisallowIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Marks an intermediate table as invalid when it references the caller's base table. The data provider (base table owner) calls this operation, not the intermediate table owner. By default, the operation also marks all descendant intermediate tables as invalid.
 */
export declare const disallowIntermediateTable: API.OperationMethod<DisallowIntermediateTableInput & RegionInput, DisallowIntermediateTableOutput, DisallowIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type GetAnalysisLogExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an analysis log export, including its current status and, if the export failed, the reason for the failure.
 *
 * Poll this operation until the `status` is `SUCCESS` or `FAILED`. An export can't be canceled after it starts.
 */
export declare const getAnalysisLogExport: API.OperationMethod<GetAnalysisLogExportInput & RegionInput, GetAnalysisLogExportOutput, GetAnalysisLogExportError, Credentials | HttpClient.HttpClient>;
export type GetAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an analysis template.
 */
export declare const getAnalysisTemplate: API.OperationMethod<GetAnalysisTemplateInput & RegionInput, GetAnalysisTemplateOutput, GetAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns metadata about a collaboration.
 */
export declare const getCollaboration: API.OperationMethod<GetCollaborationInput & RegionInput, GetCollaborationOutput, GetCollaborationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an analysis template within a collaboration.
 */
export declare const getCollaborationAnalysisTemplate: API.OperationMethod<GetCollaborationAnalysisTemplateInput & RegionInput, GetCollaborationAnalysisTemplateOutput, GetCollaborationAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationChangeRequestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific collaboration change request.
 */
export declare const getCollaborationChangeRequest: API.OperationMethod<GetCollaborationChangeRequestInput & RegionInput, GetCollaborationChangeRequestOutput, GetCollaborationChangeRequestError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured audience model association within a collaboration.
 */
export declare const getCollaborationConfiguredAudienceModelAssociation: API.OperationMethod<GetCollaborationConfiguredAudienceModelAssociationInput & RegionInput, GetCollaborationConfiguredAudienceModelAssociationOutput, GetCollaborationConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an ID namespace association from a specific collaboration.
 */
export declare const getCollaborationIdNamespaceAssociation: API.OperationMethod<GetCollaborationIdNamespaceAssociationInput & RegionInput, GetCollaborationIdNamespaceAssociationOutput, GetCollaborationIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type GetCollaborationPrivacyBudgetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specified privacy budget template.
 */
export declare const getCollaborationPrivacyBudgetTemplate: API.OperationMethod<GetCollaborationPrivacyBudgetTemplateInput & RegionInput, GetCollaborationPrivacyBudgetTemplateOutput, GetCollaborationPrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a configured audience model association.
 */
export declare const getConfiguredAudienceModelAssociation: API.OperationMethod<GetConfiguredAudienceModelAssociationInput & RegionInput, GetConfiguredAudienceModelAssociationOutput, GetConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured table.
 */
export declare const getConfiguredTable: API.OperationMethod<GetConfiguredTableInput & RegionInput, GetConfiguredTableOutput, GetConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured table analysis rule.
 */
export declare const getConfiguredTableAnalysisRule: API.OperationMethod<GetConfiguredTableAnalysisRuleInput & RegionInput, GetConfiguredTableAnalysisRuleOutput, GetConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a configured table association.
 */
export declare const getConfiguredTableAssociation: API.OperationMethod<GetConfiguredTableAssociationInput & RegionInput, GetConfiguredTableAssociationOutput, GetConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type GetConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the analysis rule for a configured table association.
 */
export declare const getConfiguredTableAssociationAnalysisRule: API.OperationMethod<GetConfiguredTableAssociationAnalysisRuleInput & RegionInput, GetConfiguredTableAssociationAnalysisRuleOutput, GetConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type GetIdMappingTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an ID mapping table.
 */
export declare const getIdMappingTable: API.OperationMethod<GetIdMappingTableInput & RegionInput, GetIdMappingTableOutput, GetIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type GetIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an ID namespace association.
 */
export declare const getIdNamespaceAssociation: API.OperationMethod<GetIdNamespaceAssociationInput & RegionInput, GetIdNamespaceAssociationOutput, GetIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type GetIntermediateTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves an intermediate table. Returns the full details of the intermediate table, including schema, table dependencies, inherited constraints, child resources, and status. Only the intermediate table owner can call this operation.
 */
export declare const getIntermediateTable: API.OperationMethod<GetIntermediateTableInput & RegionInput, GetIntermediateTableOutput, GetIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type GetIntermediateTableAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the analysis rule for an intermediate table.
 */
export declare const getIntermediateTableAnalysisRule: API.OperationMethod<GetIntermediateTableAnalysisRuleInput & RegionInput, GetIntermediateTableAnalysisRuleOutput, GetIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type GetMembershipError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a specified membership for an identifier.
 */
export declare const getMembership: API.OperationMethod<GetMembershipInput & RegionInput, GetMembershipOutput, GetMembershipError, Credentials | HttpClient.HttpClient>;
export type GetPrivacyBudgetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for a specified privacy budget template.
 */
export declare const getPrivacyBudgetTemplate: API.OperationMethod<GetPrivacyBudgetTemplateInput & RegionInput, GetPrivacyBudgetTemplateOutput, GetPrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetProtectedJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns job processing metadata.
 */
export declare const getProtectedJob: API.OperationMethod<GetProtectedJobInput & RegionInput, GetProtectedJobOutput, GetProtectedJobError, Credentials | HttpClient.HttpClient>;
export type GetProtectedQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns query processing metadata.
 */
export declare const getProtectedQuery: API.OperationMethod<GetProtectedQueryInput & RegionInput, GetProtectedQueryOutput, GetProtectedQueryError, Credentials | HttpClient.HttpClient>;
export type GetSchemaError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the schema for a relation within a collaboration.
 */
export declare const getSchema: API.OperationMethod<GetSchemaInput & RegionInput, GetSchemaOutput, GetSchemaError, Credentials | HttpClient.HttpClient>;
export type GetSchemaAnalysisRuleError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a schema analysis rule.
 */
export declare const getSchemaAnalysisRule: API.OperationMethod<GetSchemaAnalysisRuleInput & RegionInput, GetSchemaAnalysisRuleOutput, GetSchemaAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type ListAnalysisLogExportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists analysis log exports, sorted by the most recent export. Results are paginated. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listAnalysisLogExports: API.PaginatedOperationMethod<ListAnalysisLogExportsInput & RegionInput, ListAnalysisLogExportsOutput, ListAnalysisLogExportsError, Credentials | HttpClient.HttpClient, AnalysisLogExportSummary>;
export type ListAnalysisTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists analysis templates that the caller owns.
 */
export declare const listAnalysisTemplates: API.PaginatedOperationMethod<ListAnalysisTemplatesInput & RegionInput, ListAnalysisTemplatesOutput, ListAnalysisTemplatesError, Credentials | HttpClient.HttpClient, AnalysisTemplateSummary>;
export type ListCollaborationAnalysisTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists analysis templates within a collaboration.
 */
export declare const listCollaborationAnalysisTemplates: API.PaginatedOperationMethod<ListCollaborationAnalysisTemplatesInput & RegionInput, ListCollaborationAnalysisTemplatesOutput, ListCollaborationAnalysisTemplatesError, Credentials | HttpClient.HttpClient, CollaborationAnalysisTemplateSummary>;
export type ListCollaborationChangeRequestsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all change requests for a collaboration with pagination support. Returns change requests sorted by creation time.
 */
export declare const listCollaborationChangeRequests: API.PaginatedOperationMethod<ListCollaborationChangeRequestsInput & RegionInput, ListCollaborationChangeRequestsOutput, ListCollaborationChangeRequestsError, Credentials | HttpClient.HttpClient, CollaborationChangeRequestSummary>;
export type ListCollaborationConfiguredAudienceModelAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured audience model associations within a collaboration.
 */
export declare const listCollaborationConfiguredAudienceModelAssociations: API.PaginatedOperationMethod<ListCollaborationConfiguredAudienceModelAssociationsInput & RegionInput, ListCollaborationConfiguredAudienceModelAssociationsOutput, ListCollaborationConfiguredAudienceModelAssociationsError, Credentials | HttpClient.HttpClient, CollaborationConfiguredAudienceModelAssociationSummary>;
export type ListCollaborationIdNamespaceAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the ID namespace associations in a collaboration.
 */
export declare const listCollaborationIdNamespaceAssociations: API.PaginatedOperationMethod<ListCollaborationIdNamespaceAssociationsInput & RegionInput, ListCollaborationIdNamespaceAssociationsOutput, ListCollaborationIdNamespaceAssociationsError, Credentials | HttpClient.HttpClient, CollaborationIdNamespaceAssociationSummary>;
export type ListCollaborationPrivacyBudgetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array that summarizes each privacy budget in a specified collaboration. The summary includes the collaboration ARN, creation time, creating account, and privacy budget details.
 */
export declare const listCollaborationPrivacyBudgets: API.PaginatedOperationMethod<ListCollaborationPrivacyBudgetsInput & RegionInput, ListCollaborationPrivacyBudgetsOutput, ListCollaborationPrivacyBudgetsError, Credentials | HttpClient.HttpClient, CollaborationPrivacyBudgetSummary>;
export type ListCollaborationPrivacyBudgetTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an array that summarizes each privacy budget template in a specified collaboration.
 */
export declare const listCollaborationPrivacyBudgetTemplates: API.PaginatedOperationMethod<ListCollaborationPrivacyBudgetTemplatesInput & RegionInput, ListCollaborationPrivacyBudgetTemplatesOutput, ListCollaborationPrivacyBudgetTemplatesError, Credentials | HttpClient.HttpClient, CollaborationPrivacyBudgetTemplateSummary>;
export type ListCollaborationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists collaborations the caller owns, is active in, or has been invited to.
 */
export declare const listCollaborations: API.PaginatedOperationMethod<ListCollaborationsInput & RegionInput, ListCollaborationsOutput, ListCollaborationsError, Credentials | HttpClient.HttpClient, CollaborationSummary>;
export type ListConfiguredAudienceModelAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about requested configured audience model associations.
 */
export declare const listConfiguredAudienceModelAssociations: API.PaginatedOperationMethod<ListConfiguredAudienceModelAssociationsInput & RegionInput, ListConfiguredAudienceModelAssociationsOutput, ListConfiguredAudienceModelAssociationsError, Credentials | HttpClient.HttpClient, ConfiguredAudienceModelAssociationSummary>;
export type ListConfiguredTableAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured table associations for a membership.
 */
export declare const listConfiguredTableAssociations: API.PaginatedOperationMethod<ListConfiguredTableAssociationsInput & RegionInput, ListConfiguredTableAssociationsOutput, ListConfiguredTableAssociationsError, Credentials | HttpClient.HttpClient, ConfiguredTableAssociationSummary>;
export type ListConfiguredTablesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured tables.
 */
export declare const listConfiguredTables: API.PaginatedOperationMethod<ListConfiguredTablesInput & RegionInput, ListConfiguredTablesOutput, ListConfiguredTablesError, Credentials | HttpClient.HttpClient, ConfiguredTableSummary>;
export type ListIdMappingTablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of ID mapping tables.
 */
export declare const listIdMappingTables: API.PaginatedOperationMethod<ListIdMappingTablesInput & RegionInput, ListIdMappingTablesOutput, ListIdMappingTablesError, Credentials | HttpClient.HttpClient, IdMappingTableSummary>;
export type ListIdNamespaceAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of ID namespace associations.
 */
export declare const listIdNamespaceAssociations: API.PaginatedOperationMethod<ListIdNamespaceAssociationsInput & RegionInput, ListIdNamespaceAssociationsOutput, ListIdNamespaceAssociationsError, Credentials | HttpClient.HttpClient, IdNamespaceAssociationSummary>;
export type ListIntermediateTablesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists intermediate tables owned by the caller in a membership. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listIntermediateTables: API.PaginatedOperationMethod<ListIntermediateTablesInput & RegionInput, ListIntermediateTablesOutput, ListIntermediateTablesError, Credentials | HttpClient.HttpClient, IntermediateTableSummary>;
export type ListIntermediateTableVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the version history of an intermediate table. Each call to `PopulateIntermediateTable` creates a new version. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listIntermediateTableVersions: API.PaginatedOperationMethod<ListIntermediateTableVersionsInput & RegionInput, ListIntermediateTableVersionsOutput, ListIntermediateTableVersionsError, Credentials | HttpClient.HttpClient, IntermediateTableVersionSummary>;
export type ListMembersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all members within a collaboration.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersInput & RegionInput, ListMembersOutput, ListMembersError, Credentials | HttpClient.HttpClient, MemberSummary>;
export type ListMembershipsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all memberships resources within the caller's account.
 */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsInput & RegionInput, ListMembershipsOutput, ListMembershipsError, Credentials | HttpClient.HttpClient, MembershipSummary>;
export type ListPrivacyBudgetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about the privacy budgets in a specified membership.
 */
export declare const listPrivacyBudgets: API.PaginatedOperationMethod<ListPrivacyBudgetsInput & RegionInput, ListPrivacyBudgetsOutput, ListPrivacyBudgetsError, Credentials | HttpClient.HttpClient, PrivacyBudgetSummary>;
export type ListPrivacyBudgetTemplatesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about the privacy budget templates in a specified membership.
 */
export declare const listPrivacyBudgetTemplates: API.PaginatedOperationMethod<ListPrivacyBudgetTemplatesInput & RegionInput, ListPrivacyBudgetTemplatesOutput, ListPrivacyBudgetTemplatesError, Credentials | HttpClient.HttpClient, PrivacyBudgetTemplateSummary>;
export type ListProtectedJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists protected jobs, sorted by most recent job.
 */
export declare const listProtectedJobs: API.PaginatedOperationMethod<ListProtectedJobsInput & RegionInput, ListProtectedJobsOutput, ListProtectedJobsError, Credentials | HttpClient.HttpClient, ProtectedJobSummary>;
export type ListProtectedQueriesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists protected queries, sorted by the most recent query.
 */
export declare const listProtectedQueries: API.PaginatedOperationMethod<ListProtectedQueriesInput & RegionInput, ListProtectedQueriesOutput, ListProtectedQueriesError, Credentials | HttpClient.HttpClient, ProtectedQuerySummary>;
export type ListSchemasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the schemas for relations within a collaboration.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasInput & RegionInput, ListSchemasOutput, ListSchemasError, Credentials | HttpClient.HttpClient, SchemaSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all of the tags that have been added to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PopulateIdMappingTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Defines the information that's necessary to populate an ID mapping table.
 */
export declare const populateIdMappingTable: API.OperationMethod<PopulateIdMappingTableInput & RegionInput, PopulateIdMappingTableOutput, PopulateIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type PopulateIntermediateTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Runs the stored query of an intermediate table and makes the results available for querying. Each call creates a new version. Use `GetProtectedQuery` with the returned analysis ID to track progress. Only the intermediate table owner can call this operation.
 */
export declare const populateIntermediateTable: API.OperationMethod<PopulateIntermediateTableInput & RegionInput, PopulateIntermediateTableOutput, PopulateIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type PreviewPrivacyImpactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * An estimate of the number of aggregation functions that the member who can query can run given epsilon and noise parameters.
 */
export declare const previewPrivacyImpact: API.OperationMethod<PreviewPrivacyImpactInput & RegionInput, PreviewPrivacyImpactOutput, PreviewPrivacyImpactError, Credentials | HttpClient.HttpClient>;
export type StartAnalysisLogExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an export of the Apache Spark logs for a protected query to an Amazon S3 bucket that you own. Use the exported logs to diagnose a query that failed or that ran more slowly than you expected.
 *
 * Clean Rooms exports a redacted copy of the Spark logs instead of the raw logs. Analyze the exported logs with the tooling of your choice, such as Spark History Server. For details about what the exported logs contain, see https://docs.aws.amazon.com/clean-rooms/latest/userguide/export-analysis-logs-contents.html.
 *
 * The export runs asynchronously and returns with a `status` of `IN_PROGRESS`. Call `GetAnalysisLogExport` to poll for the final status.
 *
 * To use this operation, you must have the `CAN_EXPORT_QUERY_ANALYSIS_LOG` ability for your membership. You must also be the query runner or the query payer. Having the ability alone is not sufficient.
 *
 * The query must have reached a terminal state, and it must have reached the execution stage. A query that failed validation or that was canceled before it started produces no Spark logs.
 *
 * Log export isn't supported for queries that use differential privacy, and isn't supported for PySpark jobs.
 *
 * The destination bucket must be in the same Amazon Web Services Region as the collaboration. Cross-Region export isn't supported.
 *
 * For more information, see https://docs.aws.amazon.com/clean-rooms/latest/userguide/export-analysis-logs.html.
 */
export declare const startAnalysisLogExport: API.OperationMethod<StartAnalysisLogExportInput & RegionInput, StartAnalysisLogExportOutput, StartAnalysisLogExportError, Credentials | HttpClient.HttpClient>;
export type StartProtectedJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a protected job that is started by Clean Rooms.
 */
export declare const startProtectedJob: API.OperationMethod<StartProtectedJobInput & RegionInput, StartProtectedJobOutput, StartProtectedJobError, Credentials | HttpClient.HttpClient>;
export type StartProtectedQueryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a protected query that is started by Clean Rooms.
 */
export declare const startProtectedQuery: API.OperationMethod<StartProtectedQueryInput & RegionInput, StartProtectedQueryOutput, StartProtectedQueryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag or list of tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAnalysisTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the analysis template metadata.
 */
export declare const updateAnalysisTemplate: API.OperationMethod<UpdateAnalysisTemplateInput & RegionInput, UpdateAnalysisTemplateOutput, UpdateAnalysisTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateCollaborationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates collaboration metadata and can only be called by the collaboration owner.
 */
export declare const updateCollaboration: API.OperationMethod<UpdateCollaborationInput & RegionInput, UpdateCollaborationOutput, UpdateCollaborationError, Credentials | HttpClient.HttpClient>;
export type UpdateCollaborationChangeRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing collaboration change request. This operation allows approval actions for pending change requests in collaborations (APPROVE, DENY, CANCEL, COMMIT).
 *
 * For change requests without automatic approval, a member in the collaboration can manually APPROVE or DENY a change request. The collaboration owner can manually CANCEL or COMMIT a change request.
 */
export declare const updateCollaborationChangeRequest: API.OperationMethod<UpdateCollaborationChangeRequestInput & RegionInput, UpdateCollaborationChangeRequestOutput, UpdateCollaborationChangeRequestError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredAudienceModelAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details necessary to update a configured audience model association.
 */
export declare const updateConfiguredAudienceModelAssociation: API.OperationMethod<UpdateConfiguredAudienceModelAssociationInput & RegionInput, UpdateConfiguredAudienceModelAssociationOutput, UpdateConfiguredAudienceModelAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configured table.
 */
export declare const updateConfiguredTable: API.OperationMethod<UpdateConfiguredTableInput & RegionInput, UpdateConfiguredTableOutput, UpdateConfiguredTableError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configured table analysis rule.
 */
export declare const updateConfiguredTableAnalysisRule: API.OperationMethod<UpdateConfiguredTableAnalysisRuleInput & RegionInput, UpdateConfiguredTableAnalysisRuleOutput, UpdateConfiguredTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableAssociationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a configured table association.
 */
export declare const updateConfiguredTableAssociation: API.OperationMethod<UpdateConfiguredTableAssociationInput & RegionInput, UpdateConfiguredTableAssociationOutput, UpdateConfiguredTableAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfiguredTableAssociationAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the analysis rule for a configured table association.
 */
export declare const updateConfiguredTableAssociationAnalysisRule: API.OperationMethod<UpdateConfiguredTableAssociationAnalysisRuleInput & RegionInput, UpdateConfiguredTableAssociationAnalysisRuleOutput, UpdateConfiguredTableAssociationAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateIdMappingTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details that are necessary to update an ID mapping table.
 */
export declare const updateIdMappingTable: API.OperationMethod<UpdateIdMappingTableInput & RegionInput, UpdateIdMappingTableOutput, UpdateIdMappingTableError, Credentials | HttpClient.HttpClient>;
export type UpdateIdNamespaceAssociationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the details that are necessary to update an ID namespace association.
 */
export declare const updateIdNamespaceAssociation: API.OperationMethod<UpdateIdNamespaceAssociationInput & RegionInput, UpdateIdNamespaceAssociationOutput, UpdateIdNamespaceAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntermediateTableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an intermediate table. You can update the description, KMS key ARN, and column types of existing columns. Only the intermediate table owner can call this operation.
 */
export declare const updateIntermediateTable: API.OperationMethod<UpdateIntermediateTableInput & RegionInput, UpdateIntermediateTableOutput, UpdateIntermediateTableError, Credentials | HttpClient.HttpClient>;
export type UpdateIntermediateTableAnalysisRuleError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the analysis rule policy for an intermediate table. Only the intermediate table owner can call this operation.
 */
export declare const updateIntermediateTableAnalysisRule: API.OperationMethod<UpdateIntermediateTableAnalysisRuleInput & RegionInput, UpdateIntermediateTableAnalysisRuleOutput, UpdateIntermediateTableAnalysisRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateMembershipError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a membership.
 */
export declare const updateMembership: API.OperationMethod<UpdateMembershipInput & RegionInput, UpdateMembershipOutput, UpdateMembershipError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivacyBudgetTemplateError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the privacy budget template for the specified collaboration.
 */
export declare const updatePrivacyBudgetTemplate: API.OperationMethod<UpdatePrivacyBudgetTemplateInput & RegionInput, UpdatePrivacyBudgetTemplateOutput, UpdatePrivacyBudgetTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateProtectedJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the processing of a currently running job.
 */
export declare const updateProtectedJob: API.OperationMethod<UpdateProtectedJobInput & RegionInput, UpdateProtectedJobOutput, UpdateProtectedJobError, Credentials | HttpClient.HttpClient>;
export type UpdateProtectedQueryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the processing of a currently running query.
 */
export declare const updateProtectedQuery: API.OperationMethod<UpdateProtectedQueryInput & RegionInput, UpdateProtectedQueryOutput, UpdateProtectedQueryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cleanrooms.d.ts.map