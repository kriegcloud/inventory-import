import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import * as Aggregate from "./Aggregate.ts";
import type * as Api from "./Api.ts";
import * as Explore from "./Explore.ts";
import type * as ModelSearch from "./Explore/internal/ModelSearch.ts";
import type * as Model from "./Model.ts";
import * as Prove from "./Prove.ts";
export interface Options {
    /** The Apis callers reach the model through: their commands are the ones a sequence is made of. */
    readonly apis: ReadonlyArray<Api.Any>;
    /**
     * The file the model is declared in. Left out, it is found from the test
     * file that calls: the file it imports, directly or not, that declares the
     * model.
     */
    readonly source?: URL | string;
    /**
     * A story runner for the model: `Story.make(Bank, { layer, stub })`. Each
     * sequence found is run with it on the real model in memory. The external
     * systems the model calls must be in `stub`, so the run gives them the
     * answers the solver picked.
     */
    readonly story?: (...steps: ReadonlyArray<never>) => Effect.Effect<void, unknown, never>;
    /**
     * The most commands callers send in a sequence.
     * @default 2
     */
    readonly depth?: number;
    /**
     * The most sequences to run before stopping.
     * @default 100000
     */
    readonly budget?: number;
    /**
     * The most instances of one aggregate callers address in a sequence.
     * @default 2
     */
    readonly instances?: number;
    /** The ways delivery goes wrong that every sequence is run with: both, unless turned off. */
    readonly faults?: Explore.ModelOptions["faults"];
    /**
     * Longer sequences to run after every short one, each a walk of commands
     * picked at random: 200 of up to 12 commands, unless said otherwise. The
     * same `seed` picks the same walks. `{ count: 0 }` runs none.
     */
    readonly walks?: Explore.ModelOptions["walks"];
    /** What a pass may leave undone. */
    readonly allow?: Explore.ModelOptions["allow"];
    /**
     * How far a rule has to be known to hold, for the rules named: a rule in
     * `proved` that is only checked fails the verification.
     */
    readonly require?: Require;
    /**
     * A file that keeps each rule as it is written, so that none is taken out
     * or made to say less without it showing: a path from the test file that
     * calls, or a URL. See `AggregateOptions.lock`.
     */
    readonly lock?: URL | string;
}
/** The rules a pass has to do more than check. */
export interface Require {
    /** The rules that have to be proved, each as the report names it: `Account.NeverOverdrawn`. */
    readonly proved?: ReadonlyArray<string>;
}
declare const VerifyError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "VerifyError";
} & Readonly<A>;
/** The verification could not start: a file did not load, or the solver is missing. */
export declare class VerifyError extends VerifyError_base<{
    readonly message: string;
}> {
}
declare const NotVerified_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NotVerified";
} & Readonly<A>;
/** A rule is broken, a sequence does not run on the real model, or part of the check was not done. */
export declare class NotVerified extends NotVerified_base<{
    readonly message: string;
    readonly report: Report;
}> {
}
/** One rule of the model, and how far it is known to hold. */
export interface Rule {
    /** `Account.NeverOverdrawn`, or `Bank.NoTransferLeftPending`. */
    readonly name: string;
    readonly kind: "invariant" | "transition" | "model invariant" | "relation" | "eventually" | "sometimes";
    /**
     * `proved`: no state and no input break it. `checked`: no sequence run
     * breaks it. `broken`: `story` breaks it. `unseen`: no sequence reached it.
     * What the model says can happen is `reached`, with the `story` that gets
     * there, or `unreached`.
     */
    readonly standing: "proved" | "checked" | "broken" | "unseen" | "reached" | "unreached";
    /** How many states, steps or sequences it was looked at in. */
    readonly seen: number;
    readonly story: ModelSearch.Story | undefined;
    /**
     * For a rule that is checked and not proved: what the proof fails on. A
     * proof starts from any states the rules allow, so it can fail on states
     * no sequence of commands reaches.
     */
    readonly unproved?: {
        readonly by: string;
        readonly verdict: Prove.Verdict;
    } | undefined;
    /**
     * For an aggregate's rule whose proof fails from a state the rules allow:
     * an invariant every command keeps, that makes it proved once written down.
     */
    readonly suggested?: Prove.Suggestion | undefined;
}
/** A sequence the explorer found, run on the real model. */
export interface Run {
    /** What the sequence shows: `Account.WithdrawMoney → MoneyWithdrawn`. */
    readonly of: string;
    readonly story: ModelSearch.Story;
    /** `undefined` when the real model did what the explorer read. */
    readonly failure: string | undefined;
}
export interface Report {
    readonly model: string;
    readonly rules: ReadonlyArray<Rule>;
    readonly explored: Explore.ModelReport;
    /** The sequences run on the real model: empty without a `story` runner. */
    readonly runs: ReadonlyArray<Run>;
    /** How many of them are the walks of commands picked at random. */
    readonly walked: number;
    /** The sequences a story cannot run: they need an event delivered twice, a step run twice or a late schedule. */
    readonly unrun: number;
    /** Each part of the check that was not done. */
    readonly undone: ReadonlyArray<string>;
    /**
     * With `UPDATE_VERIFY_LOCK=1`: each rule the lock no longer holds the code
     * to, because it was taken out or changed, and was locked again as written.
     */
    readonly relocked: ReadonlyArray<string>;
    /** What the verification takes for granted. */
    readonly assumptions: ReadonlyArray<string>;
}
type Requirements = FileSystem.FileSystem | Path.Path;
/**
 * Verify a model, and say for each of its rules how far it is known to hold.
 *
 * **Example:** Printing the report
 * ```typescript
 * const report = yield* Verify.report(Bank, { apis: [CustomerApi, SupportApi] });
 * console.log(Verify.render(report));
 * ```
 */
export declare const report: (model: Model.Any, options: Options) => Effect.Effect<Report, VerifyError, Requirements>;
/** Whether a report verifies the model: no rule is broken, every run agrees, and nothing was left undone. */
export declare const verified: (report: Report) => boolean;
/**
 * Verify a model, or fail with the report: a rule is broken, a sequence the
 * explorer found does not run on the real model, or part of the check was
 * not done.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("the bank keeps its promises", () =>
 *   Verify.model(Bank, { apis: [CustomerApi, SupportApi] }).pipe(
 *     Effect.provide(NodeServices.layer),
 *   ),
 * );
 * ```
 *
 * **Example:** Running what it finds on the real model
 * ```typescript
 * const story = Story.make(Bank, { layer: BankHandlers, stub: [FraudCheck, Payments] });
 *
 * it.effect("the bank keeps its promises", () =>
 *   Verify.model(Bank, { apis: [CustomerApi, SupportApi], story }).pipe(
 *     Effect.provide(NodeServices.layer),
 *   ),
 * );
 * ```
 */
export declare const model: (target: Model.Any, options: Options) => Effect.Effect<Report, VerifyError | NotVerified, Requirements>;
export interface AggregateOptions {
    /**
     * The file the aggregate is declared in. Left out, it is found from the
     * test file that calls.
     */
    readonly source?: URL | string;
    /**
     * The most commands in a sequence.
     * @default 3
     */
    readonly depth?: number;
    /**
     * The most sequences to run before stopping.
     * @default 100000
     */
    readonly budget?: number;
    /** What a pass may leave undone. */
    readonly allow?: Explore.Options["allow"];
    /**
     * How far a rule has to be known to hold, for the rules named: a rule in
     * `proved` that is only checked fails the verification.
     */
    readonly require?: Require;
    /**
     * A file that keeps each rule as it is written: a path from the test file
     * that calls, or a URL. The first run writes it, and it is committed with
     * the code. From then on a rule that is in the file and no longer in the
     * code fails the verification, and so does one that changed, unless it is
     * an invariant of an aggregate that still refuses every state it refused.
     * A new rule is added to the file, and one made to say more replaces the
     * one kept. To change a rule on purpose, run the test once with
     * `UPDATE_VERIFY_LOCK=1`: every rule is locked as it is written, and the
     * report's `relocked` says which ones no longer say what they did.
     */
    readonly lock?: URL | string;
}
/** Why a rule no sequence breaks is not proved. */
export interface Unproved {
    readonly command: string;
    readonly verdict: Prove.Verdict;
}
export interface AggregateReport {
    readonly aggregate: string;
    /** Its invariants and transitions, and how far each is known to hold. */
    readonly rules: ReadonlyArray<Omit<Rule, "story" | "unproved"> & {
        /**
         * For a rule that is checked and not proved: the command the proof
         * fails on. A proof starts from any state the rules allow, so it can
         * fail on a state no sequence of commands reaches.
         */
        readonly unproved: Unproved | undefined;
        /**
         * Where the proof fails from a state the rules allow: an invariant
         * every command keeps, that makes the rule proved once written down.
         */
        readonly suggested: Prove.Suggestion | undefined;
    }>;
    readonly proof: Prove.Report;
    readonly explored: Explore.Report;
    /** Each part of the check that was not done. */
    readonly undone: ReadonlyArray<string>;
    /** With `UPDATE_VERIFY_LOCK=1`: each rule that was locked again as written, as for a model. */
    readonly relocked: ReadonlyArray<string>;
}
declare const AggregateNotVerified_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NotVerified";
} & Readonly<A>;
/** An aggregate's rule is broken, or part of the check was not done. */
export declare class AggregateNotVerified extends AggregateNotVerified_base<{
    readonly message: string;
    readonly report: AggregateReport;
}> {
}
/**
 * Verify one aggregate: prove each invariant and transition for every state
 * and every input, and search every sequence of a few commands for one that
 * breaks a rule the solver could not decide. It fails with the report when a
 * rule is broken or part of the check was not done.
 *
 * **Example:** In a test
 * ```typescript
 * it.effect("an account keeps its rules", () =>
 *   Verify.aggregate(Account).pipe(Effect.provide(NodeServices.layer)),
 * );
 * ```
 */
export declare const aggregate: (target: Aggregate.Any, options?: AggregateOptions) => Effect.Effect<AggregateReport, VerifyError | AggregateNotVerified, Requirements>;
/** A report as text: what is proved, what is checked, what is broken and what is assumed. */
export declare const render: (report: Report | AggregateReport) => string;
export {};
//# sourceMappingURL=Verify.d.ts.map