import type { StreamFraming } from "./protocol-rest.ts";
export declare const ndjson: StreamFraming;
//# sourceMappingURL=ndjson.d.ts.map