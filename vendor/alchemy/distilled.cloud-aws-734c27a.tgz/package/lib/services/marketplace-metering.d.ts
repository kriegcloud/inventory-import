import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const CustomerNotEntitledException_base: S.TaggedErrorClass<"CustomerNotEntitledException", {
    readonly message: any;
}>;
export declare class CustomerNotEntitledException extends /*@__PURE__*/ CustomerNotEntitledException_base {
}
declare const DisabledApiException_base: S.TaggedErrorClass<"DisabledApiException", {
    readonly message: any;
}>;
export declare class DisabledApiException extends /*@__PURE__*/ DisabledApiException_base {
}
declare const DuplicateRequestException_base: S.TaggedErrorClass<"DuplicateRequestException", {
    readonly message: any;
}>;
export declare class DuplicateRequestException extends /*@__PURE__*/ DuplicateRequestException_base {
}
declare const ExpiredTokenException_base: S.TaggedErrorClass<"ExpiredTokenException", {
    readonly message: any;
}>;
export declare class ExpiredTokenException extends /*@__PURE__*/ ExpiredTokenException_base {
}
declare const IdempotencyConflictException_base: S.TaggedErrorClass<"IdempotencyConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotencyConflictException extends /*@__PURE__*/ IdempotencyConflictException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}>;
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidCustomerIdentifierException_base: S.TaggedErrorClass<"InvalidCustomerIdentifierException", {
    readonly message: any;
}>;
export declare class InvalidCustomerIdentifierException extends /*@__PURE__*/ InvalidCustomerIdentifierException_base {
}
declare const InvalidEndpointRegionException_base: S.TaggedErrorClass<"InvalidEndpointRegionException", {
    readonly message: any;
}>;
export declare class InvalidEndpointRegionException extends /*@__PURE__*/ InvalidEndpointRegionException_base {
}
declare const InvalidLicenseException_base: S.TaggedErrorClass<"InvalidLicenseException", {
    readonly message: any;
}>;
export declare class InvalidLicenseException extends /*@__PURE__*/ InvalidLicenseException_base {
}
declare const InvalidProductCodeException_base: S.TaggedErrorClass<"InvalidProductCodeException", {
    readonly message: any;
}>;
export declare class InvalidProductCodeException extends /*@__PURE__*/ InvalidProductCodeException_base {
}
declare const InvalidPublicKeyVersionException_base: S.TaggedErrorClass<"InvalidPublicKeyVersionException", {
    readonly message: any;
}>;
export declare class InvalidPublicKeyVersionException extends /*@__PURE__*/ InvalidPublicKeyVersionException_base {
}
declare const InvalidRegionException_base: S.TaggedErrorClass<"InvalidRegionException", {
    readonly message: any;
}>;
export declare class InvalidRegionException extends /*@__PURE__*/ InvalidRegionException_base {
}
declare const InvalidTagException_base: S.TaggedErrorClass<"InvalidTagException", {
    readonly message: any;
}>;
export declare class InvalidTagException extends /*@__PURE__*/ InvalidTagException_base {
}
declare const InvalidTokenException_base: S.TaggedErrorClass<"InvalidTokenException", {
    readonly message: any;
}>;
export declare class InvalidTokenException extends /*@__PURE__*/ InvalidTokenException_base {
}
declare const InvalidUsageAllocationsException_base: S.TaggedErrorClass<"InvalidUsageAllocationsException", {
    readonly message: any;
}>;
export declare class InvalidUsageAllocationsException extends /*@__PURE__*/ InvalidUsageAllocationsException_base {
}
declare const InvalidUsageDimensionException_base: S.TaggedErrorClass<"InvalidUsageDimensionException", {
    readonly message: any;
}>;
export declare class InvalidUsageDimensionException extends /*@__PURE__*/ InvalidUsageDimensionException_base {
}
declare const PlatformNotSupportedException_base: S.TaggedErrorClass<"PlatformNotSupportedException", {
    readonly message: any;
}>;
export declare class PlatformNotSupportedException extends /*@__PURE__*/ PlatformNotSupportedException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TimestampOutOfBoundsException_base: S.TaggedErrorClass<"TimestampOutOfBoundsException", {
    readonly message: any;
}>;
export declare class TimestampOutOfBoundsException extends /*@__PURE__*/ TimestampOutOfBoundsException_base {
}
export type CustomerIdentifier = string;
export type UsageDimension = string;
export type UsageQuantity = number;
export type UsageQuantityAsDecimalString = string;
export type AllocatedUsageQuantity = number;
export type AllocatedUsageQuantityAsDecimalString = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface UsageAllocation {
    AllocatedUsageQuantity?: number | undefined;
    AllocatedUsageQuantityAsDecimal?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type UsageAllocations = UsageAllocation[];
export type CustomerAWSAccountId = string;
export type LicenseArn = string;
export interface UsageRecord {
    Timestamp: Date;
    CustomerIdentifier?: string | undefined;
    Dimension: string;
    Quantity?: number | undefined;
    QuantityAsDecimal?: string | undefined;
    UsageAllocations?: UsageAllocation[] | undefined;
    CustomerAWSAccountId?: string | undefined;
    LicenseArn?: string | undefined;
}
export type UsageRecordList = UsageRecord[];
export type ProductCode = string;
export interface BatchMeterUsageRequest {
    UsageRecords: UsageRecord[];
    ProductCode?: string | undefined;
}
export type UsageRecordResultStatus = "Success" | "CustomerNotSubscribed" | "DuplicateRecord" | (string & {});
export interface UsageRecordResult {
    UsageRecord?: UsageRecord | undefined;
    MeteringRecordId?: string | undefined;
    Status?: UsageRecordResultStatus | undefined;
}
export type UsageRecordResultList = UsageRecordResult[];
export interface BatchMeterUsageResult {
    Results?: UsageRecordResult[] | undefined;
    UnprocessedRecords?: UsageRecord[] | undefined;
}
export type ClientToken = string;
export interface MeterUsageRequest {
    ProductCode: string;
    Timestamp: Date;
    UsageDimension: string;
    UsageQuantity?: number | undefined;
    UsageQuantityAsDecimal?: string | undefined;
    DryRun?: boolean | undefined;
    UsageAllocations?: UsageAllocation[] | undefined;
    ClientToken?: string | undefined;
}
export interface MeterUsageResult {
    MeteringRecordId?: string | undefined;
}
export type VersionInteger = number;
export type Nonce = string;
export interface RegisterUsageRequest {
    ProductCode: string;
    PublicKeyVersion: number;
    Nonce?: string | undefined;
}
export type NonEmptyString = string;
export interface RegisterUsageResult {
    PublicKeyRotationTimestamp?: Date | undefined;
    Signature?: string | undefined;
}
export interface ResolveCustomerRequest {
    RegistrationToken: string;
}
export type AgreementId = string;
export interface Metadata {
    AgreementId?: string | undefined;
}
export interface ResolveCustomerResult {
    CustomerIdentifier?: string | undefined;
    ProductCode?: string | undefined;
    CustomerAWSAccountId?: string | undefined;
    LicenseArn?: string | undefined;
    Metadata?: Metadata | undefined;
}
export type ErrorMessage = string;
export type BatchMeterUsageError = DisabledApiException | InternalServiceErrorException | InvalidCustomerIdentifierException | InvalidLicenseException | InvalidProductCodeException | InvalidTagException | InvalidUsageAllocationsException | InvalidUsageDimensionException | ThrottlingException | TimestampOutOfBoundsException | CommonErrors;
/**
 * The Amazon Web Services Marketplace AI Metering Agent Skill (`aws-marketplace-metering`) helps an AI
 * coding agent integrate your SaaS product's usage reporting with the
 * `BatchMeterUsage` API. The skill is a curated package of instructions and
 * reference material that guides your AI coding agent through building, deploying, and
 * testing the metering integration. To get the skill on demand without checking it out
 * locally, install the Amazon Web Services MCP Server in your coding agent; the agent then discovers and loads
 * the skill at runtime. The skill source is also available on GitHub. For more information, see Get started with the Amazon Web Services Marketplace AI Metering Agent Skill on the Amazon Web Services Marketplace blog.
 *
 * Amazon Web Services Marketplace is introducing Concurrent Agreements, enabling buyers to make multiple purchases per Amazon Web Services account. Starting June 1, 2026, new SaaS products must use `CustomerAWSAccountId` (instead of `CustomerIdentifier`), `LicenseArn` (instead of `ProductCode`) to support this feature. `BatchMeterUsage` does not support `CustomerIdentifier` for new integrations. Existing integrations continue to work. Review the new integration for Concurrent Agreements here. For additional implementation details, see BatchMeterUsage code example with LicenseArn in the *Amazon Web Services Marketplace Seller Guide*.
 *
 * To post metering records for customers, SaaS applications call
 * `BatchMeterUsage`, which is used for metering SaaS flexible
 * consumption pricing (FCP). Identical requests are idempotent and can be
 * retried with the same records or a subset of records. Each
 * `BatchMeterUsage` request is for only one product. If you
 * want to meter usage for multiple products, you must make multiple
 * `BatchMeterUsage` calls.
 *
 * Usage records should be submitted in quick succession following a
 * recorded event. Usage records aren't accepted 24 hours or more after an
 * event. At the end of each billing cycle, a 6-hour grace period applies. We accept
 * usage records for the previous billing month until 06:00 UTC on the first day of the
 * next month. For example, you must submit March usage records before 06:00 UTC on
 * April 1. On April 1 at 05:00 UTC, you can still submit records for March 31 (within the 6-hour grace period). After 06:00 UTC on April 1, March records are rejected regardless of the normal 24-hour submission window. After this grace period, we return a
 * `TimestampOutOfBoundsException` error.
 *
 * `BatchMeterUsage` can process up to 25
 * `UsageRecords` at a time, and each request must be less than
 * 1 MB in size.
 *
 * **Vendor-metered tagging**
 *
 * `BatchMeterUsage` supports vendor-metered tagging. Optionally, you can
 * split the usage in a `UsageRecord` into buckets by including
 * `UsageAllocations`, where each `UsageAllocation` has a set of
 * `Tags` that you define. Vendor-metered tagging doesn't change the price,
 * dimensions, or the total usage that you report. It gives buyers a more granular view of
 * their usage of your product so they can perform cost allocation in the Amazon Web Services Billing and
 * Cost Management console. For more information, see Vendor-metered tagging and BatchMeterUsage with usage allocation tagging code example in the
 * *Amazon Web Services Marketplace Seller Guide*.
 *
 * To report fractional usage, use `QuantityAsDecimal` instead of
 * `Quantity` in each `UsageRecord`.
 *
 * `BatchMeterUsage` returns a list of
 * `UsageRecordResult` objects, which have each
 * `UsageRecord`. It also returns a list of
 * `UnprocessedRecords`, which indicate errors on the service
 * side that should be retried.
 *
 * For Amazon Web Services Regions that support `BatchMeterUsage`, see BatchMeterUsage Region support.
 *
 * For an example of `BatchMeterUsage`, see BatchMeterUsage code example in the Amazon Web Services Marketplace Seller
 * Guide.
 */
export declare const batchMeterUsage: API.OperationMethod<BatchMeterUsageRequest & RegionInput, BatchMeterUsageResult, BatchMeterUsageError, Credentials | HttpClient.HttpClient>;
export type MeterUsageError = CustomerNotEntitledException | DuplicateRequestException | IdempotencyConflictException | InternalServiceErrorException | InvalidEndpointRegionException | InvalidProductCodeException | InvalidTagException | InvalidUsageAllocationsException | InvalidUsageDimensionException | ThrottlingException | TimestampOutOfBoundsException | CommonErrors;
/**
 * As a seller, your software hosted in the buyer's Amazon Web Services account uses this API action to emit metering records directly to Amazon Web Services Marketplace.
 * You must use the following buyer Amazon Web Services account credentials to sign the API request.
 *
 * - For **Amazon EC2** deployments, your software must use the
 * IAM role for Amazon EC2
 * to sign the API call for `MeterUsage` API operation.
 *
 * - For **Amazon EKS** deployments, your software must use
 * IAM roles for service accounts (IRSA)
 * to sign the API call for the `MeterUsage` API operation. Using
 * EKS Pod Identity, the node role, or long-term access keys is not supported.
 *
 * - For **Amazon ECS** deployments, your software must use
 * Amazon ECS task IAM
 * role to sign the API call for the `MeterUsage` API operation. Using the node role or long-term access keys are not supported.
 *
 * - For **Amazon Bedrock AgentCore Runtime** deployments, your software must use the
 * AgentCore Runtime execution role
 * to sign the API call for the `MeterUsage` API operation. Long-term access keys are not supported.
 *
 * The handling of `MeterUsage` requests varies between Amazon Bedrock AgentCore Runtime and non-Amazon Bedrock AgentCore deployments.
 *
 * - For **non-Amazon Bedrock AgentCore Runtime** deployments, you can only report usage once per hour for each dimension.
 * For AMI-based products, this is per dimension and per EC2 instance. For container products, this is per dimension and per ECS task or EKS pod. You can't modify values
 * after they're recorded. If you report usage before a current hour ends, you will be unable to report additional usage until the next hour begins.
 * The `Timestamp` request parameter is rounded down to the hour and used to enforce this once-per-hour rule for idempotency.
 * For requests that are identical after the `Timestamp` is rounded down, the API is idempotent and returns the metering record ID.
 *
 * - For **Amazon Bedrock AgentCore Runtime** deployments, you can report usage multiple times per hour for the same dimension.
 * You do not need to aggregate metering records by the hour. You must include an idempotency token in the `ClientToken` request parameter. If using an Amazon
 * SDK or the Amazon Web Services CLI, you must use the latest version which automatically includes an idempotency token in the `ClientToken` request parameter so that the request is processed successfully.
 * The `Timestamp` request parameter is not rounded down to the hour and is not used for duplicate validation. Requests with duplicate `Timestamps` are aggregated as long as the
 * `ClientToken` is unique.
 *
 * If you submit records more than six hours after events occur, the records won't be accepted. The timestamp in your request determines when an event is recorded.
 *
 * To report fractional usage, use `UsageQuantityAsDecimal` instead of
 * `UsageQuantity`.
 *
 * You can optionally include multiple usage allocations, to provide customers with usage data split into buckets by tags that you define or allow the customer to define.
 *
 * For Amazon Web Services Regions that support `MeterUsage`, see MeterUsage Region support for Amazon EC2 and MeterUsage Region support for Amazon ECS and Amazon EKS.
 */
export declare const meterUsage: API.OperationMethod<MeterUsageRequest & RegionInput, MeterUsageResult, MeterUsageError, Credentials | HttpClient.HttpClient>;
export type RegisterUsageError = CustomerNotEntitledException | DisabledApiException | InternalServiceErrorException | InvalidProductCodeException | InvalidPublicKeyVersionException | InvalidRegionException | PlatformNotSupportedException | ThrottlingException | CommonErrors;
/**
 * Paid container software products sold through Amazon Web Services Marketplace must integrate with the Amazon Web Services Marketplace
 * Metering Service and call the `RegisterUsage` operation for software
 * entitlement and metering. Free and BYOL products for Amazon ECS or Amazon EKS aren't required to call `RegisterUsage`, but you may choose to
 * do so if you would like to receive usage data in your seller reports. The sections below
 * explain the behavior of `RegisterUsage`. `RegisterUsage` performs
 * two primary functions: metering and entitlement.
 *
 * - *Entitlement*: `RegisterUsage` allows you to
 * verify that the customer running your paid software is subscribed to your
 * product on Amazon Web Services Marketplace, enabling you to guard against unauthorized use. Your container
 * image that integrates with `RegisterUsage` is only required to guard
 * against unauthorized use at container startup, as such a
 * `CustomerNotSubscribedException` or
 * `PlatformNotSupportedException` will only be thrown on the
 * initial call to `RegisterUsage`. Subsequent calls from the same
 * Amazon ECS task instance (e.g. task-id) or Amazon EKS pod
 * will not throw a `CustomerNotSubscribedException`, even if the
 * customer unsubscribes while the Amazon ECS task or Amazon EKS
 * pod is still running.
 *
 * - *Metering*: `RegisterUsage` meters software use
 * per ECS task, per hour, or per pod for Amazon EKS with usage prorated to
 * the second. A minimum of 1 minute of usage applies to tasks that are short
 * lived. For example, if a customer has a 10 node Amazon ECS or Amazon EKS cluster and a service configured as a Daemon Set, then Amazon ECS or Amazon EKS will launch a task on all 10 cluster nodes
 * and the customer will be charged for 10 tasks. Software metering
 * is handled by the Amazon Web Services Marketplace metering control plane--your software is
 * not required to perform metering-specific actions other than to call
 * `RegisterUsage` to commence metering.
 * The Amazon Web Services Marketplace metering control plane will also bill customers for
 * running ECS tasks and Amazon EKS pods, regardless of the customer's
 * subscription state, which removes the need for your software to run entitlement
 * checks at runtime. For containers, `RegisterUsage` should be called
 * immediately at launch. If you don't register the container within the first 6 hours
 * of the launch, Amazon Web Services Marketplace Metering Service doesn't provide any metering
 * guarantees for previous months. Metering will continue, however, for the
 * current month forward until the container ends. `RegisterUsage` is
 * for metering paid hourly container products.
 *
 * For Amazon Web Services Regions that support `RegisterUsage`, see RegisterUsage Region support.
 */
export declare const registerUsage: API.OperationMethod<RegisterUsageRequest & RegionInput, RegisterUsageResult, RegisterUsageError, Credentials | HttpClient.HttpClient>;
export type ResolveCustomerError = DisabledApiException | ExpiredTokenException | InternalServiceErrorException | InvalidTokenException | ThrottlingException | CommonErrors;
/**
 * `ResolveCustomer` is called by a SaaS application during the registration
 * process. When a buyer visits your website during the registration process, the buyer
 * submits a registration token through their browser. The registration token is resolved
 * through this API to obtain a `CustomerIdentifier` along with the
 * `CustomerAWSAccountId`, `ProductCode`, and `LicenseArn`.
 *
 * For new SaaS product integrations, the `CustomerIdentifier` field is not populated in the `ResolveCustomer` API response. New integrations must use `CustomerAWSAccountId` and `LicenseArn` to identify customers. Existing integrations continue to work unchanged.
 *
 * To successfully resolve the token, the API must be called from the account that was used to publish the SaaS
 * application. For an example of using `ResolveCustomer`, see ResolveCustomer code example in the Amazon Web Services Marketplace Seller
 * Guide.
 *
 * Permission is required for this operation. Your IAM role or user performing this
 * operation requires a policy to allow the `aws-marketplace:ResolveCustomer`
 * action. For more information, see Actions, resources, and condition keys for Amazon Web Services Marketplace Metering Service in
 * the *Service Authorization Reference*.
 *
 * For Amazon Web Services Regions that support `ResolveCustomer`, see ResolveCustomer Region support.
 */
export declare const resolveCustomer: API.OperationMethod<ResolveCustomerRequest & RegionInput, ResolveCustomerResult, ResolveCustomerError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=marketplace-metering.d.ts.map