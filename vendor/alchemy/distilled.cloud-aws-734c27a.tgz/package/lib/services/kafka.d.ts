import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ClusterConnectivityException_base: S.TaggedErrorClass<"ClusterConnectivityException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ClusterConnectivityException extends /*@__PURE__*/ ClusterConnectivityException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ControllerMovedException_base: S.TaggedErrorClass<"ControllerMovedException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ControllerMovedException extends /*@__PURE__*/ ControllerMovedException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GroupSubscribedToTopicException_base: S.TaggedErrorClass<"GroupSubscribedToTopicException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class GroupSubscribedToTopicException extends /*@__PURE__*/ GroupSubscribedToTopicException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const KafkaRequestException_base: S.TaggedErrorClass<"KafkaRequestException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KafkaRequestException extends /*@__PURE__*/ KafkaRequestException_base {
}
declare const KafkaTimeoutException_base: S.TaggedErrorClass<"KafkaTimeoutException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class KafkaTimeoutException extends /*@__PURE__*/ KafkaTimeoutException_base {
}
declare const NotControllerException_base: S.TaggedErrorClass<"NotControllerException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class NotControllerException extends /*@__PURE__*/ NotControllerException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ReassignmentInProgressException_base: S.TaggedErrorClass<"ReassignmentInProgressException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ReassignmentInProgressException extends /*@__PURE__*/ ReassignmentInProgressException_base {
}
declare const ServerlessUnsupported_base: S.TaggedErrorClass<"ServerlessUnsupported", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServerlessUnsupported extends /*@__PURE__*/ ServerlessUnsupported_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TopicExistsException_base: S.TaggedErrorClass<"TopicExistsException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class TopicExistsException extends /*@__PURE__*/ TopicExistsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
declare const UnknownTopicOrPartitionException_base: S.TaggedErrorClass<"UnknownTopicOrPartitionException", {
    readonly InvalidParameter: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnknownTopicOrPartitionException extends /*@__PURE__*/ UnknownTopicOrPartitionException_base {
}
export type __listOf__string = string[];
export interface BatchAssociateScramSecretRequest {
    ClusterArn: string;
    SecretArnList?: string[] | undefined;
}
export interface UnprocessedScramSecret {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
    SecretArn?: string | undefined;
}
export type __listOfUnprocessedScramSecret = UnprocessedScramSecret[];
export interface BatchAssociateScramSecretResponse {
    ClusterArn?: string | undefined;
    UnprocessedScramSecrets?: UnprocessedScramSecret[] | undefined;
}
export interface BatchDisassociateScramSecretRequest {
    ClusterArn: string;
    SecretArnList?: string[] | undefined;
}
export interface BatchDisassociateScramSecretResponse {
    ClusterArn?: string | undefined;
    UnprocessedScramSecrets?: UnprocessedScramSecret[] | undefined;
}
export interface EncryptionConfiguration {
    KmsKeyArn?: string | undefined;
}
export interface Catalog {
    CatalogArn?: string | undefined;
    WarehouseLocation?: string | undefined;
}
export interface DeadLetterQueueS3 {
    BucketArn?: string | undefined;
    ErrorOutputPrefix?: string | undefined;
    ExpectedBucketOwner?: string | undefined;
}
export type PartitionStrategy = "TIME_HOUR" | (string & {});
export interface PartitionSource {
    SourceName?: string | undefined;
}
export type __listOfPartitionSource = PartitionSource[];
export interface PartitionSpec {
    PartitionStrategy?: PartitionStrategy | undefined;
    SourceList?: PartitionSource[] | undefined;
}
export interface DestinationTable {
    DestinationDatabaseName?: string | undefined;
    DestinationTableName?: string | undefined;
    PartitionSpec?: PartitionSpec | undefined;
}
export type __listOfDestinationTable = DestinationTable[];
export interface SchemaEvolution {
    EnableSchemaEvolution?: boolean | undefined;
}
export interface TableCreation {
    EnableTableCreation?: boolean | undefined;
}
export type IcebergCompressionType = "ZSTD" | "SNAPPY" | (string & {});
export interface IcebergDestinationConfiguration {
    AppendOnly?: boolean | undefined;
    Catalog?: Catalog | undefined;
    DataFreshnessInSeconds?: number | undefined;
    DeadLetterQueueS3?: DeadLetterQueueS3 | undefined;
    DestinationTableList?: DestinationTable[] | undefined;
    SchemaEvolution?: SchemaEvolution | undefined;
    ServiceExecutionRoleArn?: string | undefined;
    TableCreation?: TableCreation | undefined;
    CompressionType?: IcebergCompressionType | undefined;
}
export type S3CompressionType = "NONE" | "GZIP" | "ZSTD" | (string & {});
export type S3StorageClass = "STANDARD" | "INTELLIGENT_TIERING" | "GLACIER_IR" | (string & {});
export interface S3Storage {
    BucketArn?: string | undefined;
    CompressionType?: S3CompressionType | undefined;
    OutputPrefix?: string | undefined;
    OutputKeyTemplate?: string | undefined;
    StorageClass?: S3StorageClass | undefined;
    ExpectedBucketOwner?: string | undefined;
}
export interface S3DestinationConfiguration {
    DataFreshnessInSeconds?: number | undefined;
    DeadLetterQueueS3?: DeadLetterQueueS3 | undefined;
    ServiceExecutionRoleArn?: string | undefined;
    Storage?: S3Storage | undefined;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export type ValueConverter = "BYTE_ARRAY" | "JSON" | "JSON_SCHEMA_GSR" | "STRING" | (string & {});
export interface RecordConverter {
    ValueConverter?: ValueConverter | undefined;
}
export interface RecordSchema {
    GsrArn?: string | undefined;
}
export interface TopicConfiguration {
    RecordConverter?: RecordConverter | undefined;
    RecordSchema?: RecordSchema | undefined;
    TopicArn?: string | undefined;
}
export type __listOfTopicConfiguration = TopicConfiguration[];
export interface CloudWatchLogs {
    Enabled?: boolean | undefined;
    LogGroup?: string | undefined;
}
export interface Firehose {
    DeliveryStream?: string | undefined;
    Enabled?: boolean | undefined;
}
export interface S3 {
    Bucket?: string | undefined;
    Enabled?: boolean | undefined;
    Prefix?: string | undefined;
}
export interface ChannelLoggingInfo {
    CloudWatchLogs?: CloudWatchLogs | undefined;
    Firehose?: Firehose | undefined;
    S3?: S3 | undefined;
}
export interface CreateChannelRequest {
    ChannelName?: string | undefined;
    ClusterArn: string;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    IcebergDestinationConfiguration?: IcebergDestinationConfiguration | undefined;
    S3DestinationConfiguration?: S3DestinationConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TopicConfigurationList?: TopicConfiguration[] | undefined;
    LoggingInfo?: ChannelLoggingInfo | undefined;
}
export interface CreateChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string | undefined;
}
export type BrokerAZDistribution = "DEFAULT" | (string & {});
export type __stringMin5Max32 = string;
export interface ProvisionedThroughput {
    Enabled?: boolean | undefined;
    VolumeThroughput?: number | undefined;
}
export type __integerMin1Max16384 = number;
export interface EBSStorageInfo {
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    VolumeSize?: number | undefined;
}
export interface StorageInfo {
    EbsStorageInfo?: EBSStorageInfo | undefined;
}
export interface PublicAccess {
    Type?: string | undefined;
}
export interface VpcConnectivityScram {
    Enabled?: boolean | undefined;
}
export interface VpcConnectivityIam {
    Enabled?: boolean | undefined;
}
export interface VpcConnectivitySasl {
    Scram?: VpcConnectivityScram | undefined;
    Iam?: VpcConnectivityIam | undefined;
}
export interface VpcConnectivityTls {
    Enabled?: boolean | undefined;
}
export interface VpcConnectivityClientAuthentication {
    Sasl?: VpcConnectivitySasl | undefined;
    Tls?: VpcConnectivityTls | undefined;
}
export interface VpcConnectivity {
    ClientAuthentication?: VpcConnectivityClientAuthentication | undefined;
}
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export interface ConnectivityInfo {
    PublicAccess?: PublicAccess | undefined;
    VpcConnectivity?: VpcConnectivity | undefined;
    NetworkType?: NetworkType | undefined;
}
export interface BrokerNodeGroupInfo {
    BrokerAZDistribution?: BrokerAZDistribution | undefined;
    ClientSubnets?: string[] | undefined;
    InstanceType?: string | undefined;
    SecurityGroups?: string[] | undefined;
    StorageInfo?: StorageInfo | undefined;
    ConnectivityInfo?: ConnectivityInfo | undefined;
    ZoneIds?: string[] | undefined;
}
export type RebalancingStatus = "PAUSED" | "ACTIVE" | (string & {});
export interface Rebalancing {
    Status?: RebalancingStatus | undefined;
}
export interface Scram {
    Enabled?: boolean | undefined;
}
export interface Iam {
    Enabled?: boolean | undefined;
}
export interface Sasl {
    Scram?: Scram | undefined;
    Iam?: Iam | undefined;
}
export interface Tls {
    CertificateAuthorityArnList?: string[] | undefined;
    Enabled?: boolean | undefined;
}
export interface Unauthenticated {
    Enabled?: boolean | undefined;
}
export interface ClientAuthentication {
    Sasl?: Sasl | undefined;
    Tls?: Tls | undefined;
    Unauthenticated?: Unauthenticated | undefined;
}
export type __stringMin1Max64 = string;
export interface ConfigurationInfo {
    Arn?: string | undefined;
    Revision?: number | undefined;
}
export interface EncryptionAtRest {
    DataVolumeKMSKeyId?: string | undefined;
}
export type ClientBroker = "TLS" | "TLS_PLAINTEXT" | "PLAINTEXT" | (string & {});
export interface EncryptionInTransit {
    ClientBroker?: ClientBroker | undefined;
    InCluster?: boolean | undefined;
}
export interface EncryptionInfo {
    EncryptionAtRest?: EncryptionAtRest | undefined;
    EncryptionInTransit?: EncryptionInTransit | undefined;
}
export type EnhancedMonitoring = "DEFAULT" | "PER_BROKER" | "PER_TOPIC_PER_BROKER" | "PER_TOPIC_PER_PARTITION" | (string & {});
export interface JmxExporterInfo {
    EnabledInBroker?: boolean | undefined;
}
export interface NodeExporterInfo {
    EnabledInBroker?: boolean | undefined;
}
export interface PrometheusInfo {
    JmxExporter?: JmxExporterInfo | undefined;
    NodeExporter?: NodeExporterInfo | undefined;
}
export interface OpenMonitoringInfo {
    Prometheus?: PrometheusInfo | undefined;
}
export type __stringMin1Max128 = string;
export interface AuthorizerLogs {
    CloudWatchLogs?: CloudWatchLogs | undefined;
    Firehose?: Firehose | undefined;
    S3?: S3 | undefined;
}
export interface BrokerLogs {
    CloudWatchLogs?: CloudWatchLogs | undefined;
    Firehose?: Firehose | undefined;
    S3?: S3 | undefined;
}
export interface LoggingInfo {
    AuthorizerLogs?: AuthorizerLogs | undefined;
    BrokerLogs?: BrokerLogs | undefined;
}
export type __integerMin1Max15 = number;
export type StorageMode = "LOCAL" | "TIERED" | (string & {});
export interface CreateClusterRequest {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo | undefined;
    Rebalancing?: Rebalancing | undefined;
    ClientAuthentication?: ClientAuthentication | undefined;
    ClusterName?: string | undefined;
    ConfigurationInfo?: ConfigurationInfo | undefined;
    EncryptionInfo?: EncryptionInfo | undefined;
    EnhancedMonitoring?: EnhancedMonitoring | undefined;
    OpenMonitoring?: OpenMonitoringInfo | undefined;
    KafkaVersion?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    NumberOfBrokerNodes?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    StorageMode?: StorageMode | undefined;
}
export type ClusterState = "ACTIVE" | "CREATING" | "DELETING" | "FAILED" | "HEALING" | "MAINTENANCE" | "REBOOTING_BROKER" | "UPDATING" | (string & {});
export interface CreateClusterResponse {
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    State?: ClusterState | undefined;
}
export interface ProvisionedRequest {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo | undefined;
    Rebalancing?: Rebalancing | undefined;
    ClientAuthentication?: ClientAuthentication | undefined;
    ConfigurationInfo?: ConfigurationInfo | undefined;
    EncryptionInfo?: EncryptionInfo | undefined;
    EnhancedMonitoring?: EnhancedMonitoring | undefined;
    OpenMonitoring?: OpenMonitoringInfo | undefined;
    KafkaVersion?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    NumberOfBrokerNodes?: number | undefined;
    StorageMode?: StorageMode | undefined;
}
export interface VpcConfig {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export type __listOfVpcConfig = VpcConfig[];
export interface ServerlessSasl {
    Iam?: Iam | undefined;
}
export interface ServerlessClientAuthentication {
    Sasl?: ServerlessSasl | undefined;
}
export interface ServerlessRequest {
    VpcConfigs?: VpcConfig[] | undefined;
    ClientAuthentication?: ServerlessClientAuthentication | undefined;
}
export interface CreateClusterV2Request {
    ClusterName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Provisioned?: ProvisionedRequest | undefined;
    Serverless?: ServerlessRequest | undefined;
}
export type ClusterType = "PROVISIONED" | "SERVERLESS" | (string & {});
export interface CreateClusterV2Response {
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    State?: ClusterState | undefined;
    ClusterType?: ClusterType | undefined;
}
export type __blob = Uint8Array;
export interface CreateConfigurationRequest {
    Description?: string | undefined;
    KafkaVersions?: string[] | undefined;
    Name?: string | undefined;
    ServerProperties?: Uint8Array | undefined;
}
export type __timestampIso8601 = Date;
export interface ConfigurationRevision {
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    Revision?: number | undefined;
}
export type ConfigurationState = "ACTIVE" | "DELETING" | "DELETE_FAILED" | (string & {});
export interface CreateConfigurationResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    LatestRevision?: (ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    }) | undefined;
    Name?: string | undefined;
    State?: ConfigurationState | undefined;
}
export type __stringMax1024 = string;
export interface AmazonMskCluster {
    MskClusterArn?: string | undefined;
}
export interface ApacheKafkaCluster {
    ApacheKafkaClusterId?: string | undefined;
    BootstrapBrokerString?: string | undefined;
}
export interface KafkaClusterClientVpcConfig {
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
}
export type KafkaClusterSaslScramMechanism = "SHA256" | "SHA512" | (string & {});
export interface KafkaClusterSaslScramAuthentication {
    Mechanism?: KafkaClusterSaslScramMechanism | undefined;
    SecretArn?: string | undefined;
}
export interface KafkaClusterMTLSAuthentication {
    SecretArn?: string | undefined;
}
export interface KafkaClusterOAuthClientCredentials {
    TokenRequestSecretArn?: string | undefined;
}
export type JwtSigningAlgorithm = "RS256" | "ES384" | (string & {});
export interface KafkaClusterOAuthIamJwtBearer {
    Audience?: string | undefined;
    SigningAlgorithm?: JwtSigningAlgorithm | undefined;
    TokenRequestSecretArn?: string | undefined;
}
export interface KafkaClusterOAuthClientCredentialsAssertion {
    Audience?: string | undefined;
    SigningAlgorithm?: JwtSigningAlgorithm | undefined;
    TokenRequestSecretArn?: string | undefined;
}
export type TokenEndpointAuthenticationMethod = "POST" | "BASIC" | "NONE" | (string & {});
export interface KafkaClusterSaslOAuthBearerAuthentication {
    TokenEndpointUrl?: string | undefined;
    ClientCredentials?: KafkaClusterOAuthClientCredentials | undefined;
    IamJwtBearer?: KafkaClusterOAuthIamJwtBearer | undefined;
    ClientCredentialsAssertion?: KafkaClusterOAuthClientCredentialsAssertion | undefined;
    TokenEndpointAuthenticationMethod?: TokenEndpointAuthenticationMethod | undefined;
    Scope?: string | undefined;
    TokenEndpointTlsCertificateArn?: string | undefined;
}
export interface KafkaClusterClientAuthentication {
    SaslScram?: KafkaClusterSaslScramAuthentication | undefined;
    MTLS?: KafkaClusterMTLSAuthentication | undefined;
    SaslOAuthBearer?: KafkaClusterSaslOAuthBearerAuthentication | undefined;
}
export type KafkaClusterEncryptionInTransitType = "TLS" | (string & {});
export interface KafkaClusterEncryptionInTransit {
    EncryptionType?: KafkaClusterEncryptionInTransitType | undefined;
    RootCaCertificate?: string | undefined;
}
export interface KafkaCluster {
    AmazonMskCluster?: AmazonMskCluster | undefined;
    ApacheKafkaCluster?: ApacheKafkaCluster | undefined;
    VpcConfig?: KafkaClusterClientVpcConfig | undefined;
    ClientAuthentication?: KafkaClusterClientAuthentication | undefined;
    EncryptionInTransit?: KafkaClusterEncryptionInTransit | undefined;
}
export type __listOfKafkaCluster = KafkaCluster[];
export type __stringMax256 = string;
export type __listOf__stringMax256 = string[];
export type ConsumerGroupOffsetSyncMode = "LEGACY" | "ENHANCED" | (string & {});
export interface ConsumerGroupReplication {
    ConsumerGroupsToExclude?: string[] | undefined;
    ConsumerGroupsToReplicate?: string[] | undefined;
    DetectAndCopyNewConsumerGroups?: boolean | undefined;
    SynchroniseConsumerGroupOffsets?: boolean | undefined;
    ConsumerGroupOffsetSyncMode?: ConsumerGroupOffsetSyncMode | undefined;
}
export type TargetCompressionType = "NONE" | "GZIP" | "SNAPPY" | "LZ4" | "ZSTD" | (string & {});
export type ReplicationStartingPositionType = "LATEST" | "EARLIEST" | (string & {});
export interface ReplicationStartingPosition {
    Type?: ReplicationStartingPositionType | undefined;
}
export type ReplicationTopicNameConfigurationType = "PREFIXED_WITH_SOURCE_CLUSTER_ALIAS" | "IDENTICAL" | (string & {});
export interface ReplicationTopicNameConfiguration {
    Type?: ReplicationTopicNameConfigurationType | undefined;
}
export type __stringMax249 = string;
export type __listOf__stringMax249 = string[];
export interface TopicReplication {
    CopyAccessControlListsForTopics?: boolean | undefined;
    CopyTopicConfigurations?: boolean | undefined;
    DetectAndCopyNewTopics?: boolean | undefined;
    StartingPosition?: ReplicationStartingPosition | undefined;
    TopicNameConfiguration?: ReplicationTopicNameConfiguration | undefined;
    TopicsToExclude?: string[] | undefined;
    TopicsToReplicate?: string[] | undefined;
}
export interface ReplicationInfo {
    ConsumerGroupReplication?: ConsumerGroupReplication | undefined;
    SourceKafkaClusterArn?: string | undefined;
    SourceKafkaClusterId?: string | undefined;
    TargetCompressionType?: TargetCompressionType | undefined;
    TargetKafkaClusterArn?: string | undefined;
    TargetKafkaClusterId?: string | undefined;
    TopicReplication?: TopicReplication | undefined;
}
export type __listOfReplicationInfo = ReplicationInfo[];
export type __stringMin1Max128Pattern09AZaZ09AZaZ0 = string;
export interface ReplicatorCloudWatchLogs {
    Enabled?: boolean | undefined;
    LogGroup?: string | undefined;
}
export interface ReplicatorFirehose {
    Enabled?: boolean | undefined;
    DeliveryStream?: string | undefined;
}
export interface ReplicatorS3 {
    Enabled?: boolean | undefined;
    Bucket?: string | undefined;
    Prefix?: string | undefined;
}
export interface ReplicatorLogDelivery {
    CloudWatchLogs?: ReplicatorCloudWatchLogs | undefined;
    Firehose?: ReplicatorFirehose | undefined;
    S3?: ReplicatorS3 | undefined;
}
export interface LogDelivery {
    ReplicatorLogDelivery?: ReplicatorLogDelivery | undefined;
}
export interface CreateReplicatorRequest {
    Description?: string | undefined;
    KafkaClusters?: KafkaCluster[] | undefined;
    ReplicationInfoList?: ReplicationInfo[] | undefined;
    ReplicatorName?: string | undefined;
    ServiceExecutionRoleArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    LogDelivery?: LogDelivery | undefined;
}
export type ReplicatorState = "RUNNING" | "CREATING" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export interface CreateReplicatorResponse {
    ReplicatorArn?: string | undefined;
    ReplicatorName?: string | undefined;
    ReplicatorState?: ReplicatorState | undefined;
}
export type __integerMin1 = number;
export interface CreateTopicRequest {
    ClusterArn: string;
    TopicName?: string | undefined;
    PartitionCount?: number | undefined;
    ReplicationFactor?: number | undefined;
    Configs?: string | undefined;
}
export type TopicState = "CREATING" | "UPDATING" | "DELETING" | "ACTIVE" | (string & {});
export interface CreateTopicResponse {
    TopicArn?: string | undefined;
    TopicName?: string | undefined;
    Status?: TopicState | undefined;
}
export interface CreateVpcConnectionRequest {
    TargetClusterArn?: string | undefined;
    Authentication?: string | undefined;
    VpcId?: string | undefined;
    ClientSubnets?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VpcConnectionState = "CREATING" | "AVAILABLE" | "INACTIVE" | "DEACTIVATING" | "DELETING" | "FAILED" | "REJECTED" | "REJECTING" | (string & {});
export interface CreateVpcConnectionResponse {
    VpcConnectionArn?: string | undefined;
    State?: VpcConnectionState | undefined;
    Authentication?: string | undefined;
    VpcId?: string | undefined;
    ClientSubnets?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    CreationTime?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
}
export interface DeleteChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string | undefined;
}
export interface DeleteClusterRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
}
export interface DeleteClusterResponse {
    ClusterArn?: string | undefined;
    State?: ClusterState | undefined;
}
export interface DeleteClusterPolicyRequest {
    ClusterArn: string;
}
export interface DeleteClusterPolicyResponse {
}
export interface DeleteConfigurationRequest {
    Arn: string;
}
export interface DeleteConfigurationResponse {
    Arn?: string | undefined;
    State?: ConfigurationState | undefined;
}
export interface DeleteReplicatorRequest {
    CurrentVersion?: string | undefined;
    ReplicatorArn: string;
}
export interface DeleteReplicatorResponse {
    ReplicatorArn?: string | undefined;
    ReplicatorState?: ReplicatorState | undefined;
}
export interface DeleteTopicRequest {
    ClusterArn: string;
    TopicName: string;
}
export interface DeleteTopicResponse {
    TopicArn?: string | undefined;
    TopicName?: string | undefined;
    Status?: TopicState | undefined;
}
export interface DeleteVpcConnectionRequest {
    Arn: string;
}
export interface DeleteVpcConnectionResponse {
    VpcConnectionArn?: string | undefined;
    State?: VpcConnectionState | undefined;
}
export interface DescribeChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
}
export type ChannelStatus = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "FAILED" | "SUSPENDING" | "SUSPENDED" | (string & {});
export type ChannelDestinationType = "ICEBERG" | "S3" | (string & {});
export interface ChannelStateInfo {
    Code?: string | undefined;
    Message?: string | undefined;
}
export interface DescribeChannelResponse {
    ChannelArn: string;
    ChannelName: string;
    EncryptionConfiguration?: (EncryptionConfiguration & {
        KmsKeyArn: string;
    }) | undefined;
    IcebergDestinationConfiguration?: (IcebergDestinationConfiguration & {
        AppendOnly: boolean;
        DeadLetterQueueS3: DeadLetterQueueS3 & {
            BucketArn: string;
        };
        DestinationTableList: (DestinationTable & {
            PartitionSpec: PartitionSpec & {
                PartitionStrategy: PartitionStrategy;
            };
        })[];
        SchemaEvolution: SchemaEvolution;
        ServiceExecutionRoleArn: string;
        TableCreation: TableCreation;
    }) | undefined;
    S3DestinationConfiguration?: (S3DestinationConfiguration & {
        DeadLetterQueueS3: DeadLetterQueueS3 & {
            BucketArn: string;
        };
        ServiceExecutionRoleArn: string;
        Storage: S3Storage & {
            BucketArn: string;
            CompressionType: S3CompressionType;
            StorageClass: S3StorageClass;
        };
    }) | undefined;
    Status: ChannelStatus;
    DestinationType: ChannelDestinationType;
    CreationTime: Date;
    TopicConfigurationList: (TopicConfiguration & {
        RecordConverter: RecordConverter & {
            ValueConverter: ValueConverter;
        };
        TopicArn: string;
        RecordSchema: RecordSchema & {
            GsrArn: string;
        };
    })[];
    LoggingInfo?: (ChannelLoggingInfo & {
        CloudWatchLogs: CloudWatchLogs & {
            Enabled: boolean;
        };
        Firehose: Firehose & {
            Enabled: boolean;
        };
        S3: S3 & {
            Enabled: boolean;
        };
    }) | undefined;
    StateInfo?: ChannelStateInfo | undefined;
    ClusterOperationArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeClusterRequest {
    ClusterArn: string;
}
export interface BrokerSoftwareInfo {
    ConfigurationArn?: string | undefined;
    ConfigurationRevision?: number | undefined;
    KafkaVersion?: string | undefined;
}
export interface JmxExporter {
    EnabledInBroker?: boolean | undefined;
}
export interface NodeExporter {
    EnabledInBroker?: boolean | undefined;
}
export interface Prometheus {
    JmxExporter?: JmxExporter | undefined;
    NodeExporter?: NodeExporter | undefined;
}
export interface OpenMonitoring {
    Prometheus?: Prometheus | undefined;
}
export interface StateInfo {
    Code?: string | undefined;
    Message?: string | undefined;
}
export type CustomerActionStatus = "CRITICAL_ACTION_REQUIRED" | "ACTION_RECOMMENDED" | "NONE" | (string & {});
export interface ClusterInfo {
    ActiveOperationArn?: string | undefined;
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo | undefined;
    Rebalancing?: Rebalancing | undefined;
    ClientAuthentication?: ClientAuthentication | undefined;
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    CreationTime?: Date | undefined;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo | undefined;
    CurrentVersion?: string | undefined;
    EncryptionInfo?: EncryptionInfo | undefined;
    EnhancedMonitoring?: EnhancedMonitoring | undefined;
    OpenMonitoring?: OpenMonitoring | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    NumberOfBrokerNodes?: number | undefined;
    State?: ClusterState | undefined;
    StateInfo?: StateInfo | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ZookeeperConnectString?: string | undefined;
    ZookeeperConnectStringTls?: string | undefined;
    StorageMode?: StorageMode | undefined;
    CustomerActionStatus?: CustomerActionStatus | undefined;
}
export interface DescribeClusterResponse {
    ClusterInfo?: (ClusterInfo & {
        BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
            ClientSubnets: __listOf__string;
            InstanceType: __stringMin5Max32;
        };
        EncryptionInfo: EncryptionInfo & {
            EncryptionAtRest: EncryptionAtRest & {
                DataVolumeKMSKeyId: string;
            };
        };
        OpenMonitoring: OpenMonitoring & {
            Prometheus: Prometheus & {
                JmxExporter: JmxExporter & {
                    EnabledInBroker: boolean;
                };
                NodeExporter: NodeExporter & {
                    EnabledInBroker: boolean;
                };
            };
        };
        LoggingInfo: LoggingInfo & {
            BrokerLogs: BrokerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
            AuthorizerLogs: AuthorizerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
        };
    }) | undefined;
}
export interface DescribeClusterOperationRequest {
    ClusterOperationArn: string;
}
export interface ErrorInfo {
    ErrorCode?: string | undefined;
    ErrorString?: string | undefined;
}
export interface ClusterOperationStepInfo {
    StepStatus?: string | undefined;
}
export interface ClusterOperationStep {
    StepInfo?: ClusterOperationStepInfo | undefined;
    StepName?: string | undefined;
}
export type __listOfClusterOperationStep = ClusterOperationStep[];
export interface BrokerEBSVolumeInfo {
    KafkaBrokerNodeId?: string | undefined;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    VolumeSizeGB?: number | undefined;
}
export type __listOfBrokerEBSVolumeInfo = BrokerEBSVolumeInfo[];
export interface ZookeeperAccess {
    Enabled?: boolean | undefined;
}
export type __listOf__double = number[];
export interface BrokerCountUpdateInfo {
    CreatedBrokerIds?: number[] | undefined;
    DeletedBrokerIds?: number[] | undefined;
}
export interface MutableClusterInfo {
    BrokerEBSVolumeInfo?: BrokerEBSVolumeInfo[] | undefined;
    ConfigurationInfo?: ConfigurationInfo | undefined;
    NumberOfBrokerNodes?: number | undefined;
    EnhancedMonitoring?: EnhancedMonitoring | undefined;
    OpenMonitoring?: OpenMonitoring | undefined;
    ZookeeperAccess?: ZookeeperAccess | undefined;
    KafkaVersion?: string | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    InstanceType?: string | undefined;
    ClientAuthentication?: ClientAuthentication | undefined;
    EncryptionInfo?: EncryptionInfo | undefined;
    ConnectivityInfo?: ConnectivityInfo | undefined;
    StorageMode?: StorageMode | undefined;
    BrokerCountUpdateInfo?: BrokerCountUpdateInfo | undefined;
    Rebalancing?: Rebalancing | undefined;
}
export type UserIdentityType = "AWSACCOUNT" | "AWSSERVICE" | (string & {});
export interface UserIdentity {
    Type?: UserIdentityType | undefined;
    PrincipalId?: string | undefined;
}
export interface VpcConnectionInfo {
    VpcConnectionArn?: string | undefined;
    Owner?: string | undefined;
    UserIdentity?: UserIdentity | undefined;
    CreationTime?: Date | undefined;
}
export interface ClusterOperationInfo {
    ClientRequestId?: string | undefined;
    ClusterArn?: string | undefined;
    CreationTime?: Date | undefined;
    EndTime?: Date | undefined;
    ErrorInfo?: ErrorInfo | undefined;
    OperationArn?: string | undefined;
    OperationState?: string | undefined;
    OperationSteps?: ClusterOperationStep[] | undefined;
    OperationType?: string | undefined;
    SourceClusterInfo?: MutableClusterInfo | undefined;
    TargetClusterInfo?: MutableClusterInfo | undefined;
    VpcConnectionInfo?: VpcConnectionInfo | undefined;
}
export interface DescribeClusterOperationResponse {
    ClusterOperationInfo?: (ClusterOperationInfo & {
        SourceClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
        TargetClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
    }) | undefined;
}
export interface DescribeClusterOperationV2Request {
    ClusterOperationArn: string;
}
export interface ClusterOperationV2Provisioned {
    OperationSteps?: ClusterOperationStep[] | undefined;
    SourceClusterInfo?: MutableClusterInfo | undefined;
    TargetClusterInfo?: MutableClusterInfo | undefined;
    VpcConnectionInfo?: VpcConnectionInfo | undefined;
}
export interface ServerlessConnectivityInfo {
    NetworkType?: NetworkType | undefined;
}
export interface VpcConnectionInfoServerless {
    CreationTime?: Date | undefined;
    Owner?: string | undefined;
    UserIdentity?: UserIdentity | undefined;
    VpcConnectionArn?: string | undefined;
}
export interface ClusterOperationV2Serverless {
    SourceClusterInfo?: ServerlessConnectivityInfo | undefined;
    TargetClusterInfo?: ServerlessConnectivityInfo | undefined;
    VpcConnectionInfo?: VpcConnectionInfoServerless | undefined;
}
export interface ClusterOperationV2 {
    ClusterArn?: string | undefined;
    ClusterType?: ClusterType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ErrorInfo?: ErrorInfo | undefined;
    OperationArn?: string | undefined;
    OperationState?: string | undefined;
    OperationType?: string | undefined;
    Provisioned?: ClusterOperationV2Provisioned | undefined;
    Serverless?: ClusterOperationV2Serverless | undefined;
}
export interface DescribeClusterOperationV2Response {
    ClusterOperationInfo?: (ClusterOperationV2 & {
        Provisioned: ClusterOperationV2Provisioned & {
            SourceClusterInfo: MutableClusterInfo & {
                BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                    KafkaBrokerNodeId: string;
                })[];
                ConfigurationInfo: ConfigurationInfo & {
                    Arn: string;
                    Revision: number;
                };
                OpenMonitoring: OpenMonitoring & {
                    Prometheus: Prometheus & {
                        JmxExporter: JmxExporter & {
                            EnabledInBroker: boolean;
                        };
                        NodeExporter: NodeExporter & {
                            EnabledInBroker: boolean;
                        };
                    };
                };
                LoggingInfo: LoggingInfo & {
                    BrokerLogs: BrokerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                    AuthorizerLogs: AuthorizerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                };
                EncryptionInfo: EncryptionInfo & {
                    EncryptionAtRest: EncryptionAtRest & {
                        DataVolumeKMSKeyId: string;
                    };
                };
            };
            TargetClusterInfo: MutableClusterInfo & {
                BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                    KafkaBrokerNodeId: string;
                })[];
                ConfigurationInfo: ConfigurationInfo & {
                    Arn: string;
                    Revision: number;
                };
                OpenMonitoring: OpenMonitoring & {
                    Prometheus: Prometheus & {
                        JmxExporter: JmxExporter & {
                            EnabledInBroker: boolean;
                        };
                        NodeExporter: NodeExporter & {
                            EnabledInBroker: boolean;
                        };
                    };
                };
                LoggingInfo: LoggingInfo & {
                    BrokerLogs: BrokerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                    AuthorizerLogs: AuthorizerLogs & {
                        CloudWatchLogs: CloudWatchLogs & {
                            Enabled: boolean;
                        };
                        Firehose: Firehose & {
                            Enabled: boolean;
                        };
                        S3: S3 & {
                            Enabled: boolean;
                        };
                    };
                };
                EncryptionInfo: EncryptionInfo & {
                    EncryptionAtRest: EncryptionAtRest & {
                        DataVolumeKMSKeyId: string;
                    };
                };
            };
        };
    }) | undefined;
}
export interface DescribeClusterV2Request {
    ClusterArn: string;
}
export interface Provisioned {
    BrokerNodeGroupInfo?: BrokerNodeGroupInfo | undefined;
    Rebalancing?: Rebalancing | undefined;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo | undefined;
    ClientAuthentication?: ClientAuthentication | undefined;
    EncryptionInfo?: EncryptionInfo | undefined;
    EnhancedMonitoring?: EnhancedMonitoring | undefined;
    OpenMonitoring?: OpenMonitoringInfo | undefined;
    LoggingInfo?: LoggingInfo | undefined;
    NumberOfBrokerNodes?: number | undefined;
    ZookeeperConnectString?: string | undefined;
    ZookeeperConnectStringTls?: string | undefined;
    StorageMode?: StorageMode | undefined;
    CustomerActionStatus?: CustomerActionStatus | undefined;
}
export interface Serverless {
    VpcConfigs?: VpcConfig[] | undefined;
    ClientAuthentication?: ServerlessClientAuthentication | undefined;
    ConnectivityInfo?: ServerlessConnectivityInfo | undefined;
}
export interface Cluster {
    ActiveOperationArn?: string | undefined;
    ClusterType?: ClusterType | undefined;
    ClusterArn?: string | undefined;
    ClusterName?: string | undefined;
    CreationTime?: Date | undefined;
    CurrentVersion?: string | undefined;
    State?: ClusterState | undefined;
    StateInfo?: StateInfo | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Provisioned?: Provisioned | undefined;
    Serverless?: Serverless | undefined;
}
export interface DescribeClusterV2Response {
    ClusterInfo?: (Cluster & {
        Provisioned: Provisioned & {
            BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
                ClientSubnets: __listOf__string;
                InstanceType: __stringMin5Max32;
            };
            NumberOfBrokerNodes: __integerMin1Max15;
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
            OpenMonitoring: OpenMonitoringInfo & {
                Prometheus: PrometheusInfo & {
                    JmxExporter: JmxExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
        };
        Serverless: Serverless & {
            VpcConfigs: (VpcConfig & {
                SubnetIds: __listOf__string;
            })[];
        };
    }) | undefined;
}
export interface DescribeConfigurationRequest {
    Arn: string;
}
export interface DescribeConfigurationResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    KafkaVersions?: string[] | undefined;
    LatestRevision?: (ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    }) | undefined;
    Name?: string | undefined;
    State?: ConfigurationState | undefined;
}
export interface DescribeConfigurationRevisionRequest {
    Arn: string;
    Revision: number;
}
export interface DescribeConfigurationRevisionResponse {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    Revision?: number | undefined;
    ServerProperties?: Uint8Array | undefined;
}
export interface DescribeReplicatorRequest {
    ReplicatorArn: string;
}
export interface KafkaClusterDescription {
    AmazonMskCluster?: AmazonMskCluster | undefined;
    ApacheKafkaCluster?: ApacheKafkaCluster | undefined;
    KafkaClusterAlias?: string | undefined;
    VpcConfig?: KafkaClusterClientVpcConfig | undefined;
    ClientAuthentication?: KafkaClusterClientAuthentication | undefined;
    EncryptionInTransit?: KafkaClusterEncryptionInTransit | undefined;
}
export type __listOfKafkaClusterDescription = KafkaClusterDescription[];
export interface ReplicationInfoDescription {
    ConsumerGroupReplication?: ConsumerGroupReplication | undefined;
    SourceKafkaClusterAlias?: string | undefined;
    TargetCompressionType?: TargetCompressionType | undefined;
    TargetKafkaClusterAlias?: string | undefined;
    TopicReplication?: TopicReplication | undefined;
}
export type __listOfReplicationInfoDescription = ReplicationInfoDescription[];
export interface ReplicationStateInfo {
    Code?: string | undefined;
    Message?: string | undefined;
}
export interface DescribeReplicatorResponse {
    CreationTime?: Date | undefined;
    CurrentVersion?: string | undefined;
    IsReplicatorReference?: boolean | undefined;
    KafkaClusters?: (KafkaClusterDescription & {
        AmazonMskCluster: AmazonMskCluster & {
            MskClusterArn: string;
        };
        ApacheKafkaCluster: ApacheKafkaCluster & {
            ApacheKafkaClusterId: string;
            BootstrapBrokerString: string;
        };
        VpcConfig: KafkaClusterClientVpcConfig & {
            SubnetIds: __listOf__string;
        };
        ClientAuthentication: KafkaClusterClientAuthentication & {
            SaslScram: KafkaClusterSaslScramAuthentication & {
                Mechanism: KafkaClusterSaslScramMechanism;
                SecretArn: string;
            };
            MTLS: KafkaClusterMTLSAuthentication & {
                SecretArn: string;
            };
            SaslOAuthBearer: KafkaClusterSaslOAuthBearerAuthentication & {
                TokenEndpointUrl: string;
                TokenEndpointAuthenticationMethod: TokenEndpointAuthenticationMethod;
                ClientCredentials: KafkaClusterOAuthClientCredentials & {
                    TokenRequestSecretArn: string;
                };
                IamJwtBearer: KafkaClusterOAuthIamJwtBearer & {
                    Audience: string;
                    SigningAlgorithm: JwtSigningAlgorithm;
                };
                ClientCredentialsAssertion: KafkaClusterOAuthClientCredentialsAssertion & {
                    Audience: string;
                    SigningAlgorithm: JwtSigningAlgorithm;
                };
            };
        };
        EncryptionInTransit: KafkaClusterEncryptionInTransit & {
            EncryptionType: KafkaClusterEncryptionInTransitType;
        };
    })[] | undefined;
    ReplicationInfoList?: (ReplicationInfoDescription & {
        ConsumerGroupReplication: ConsumerGroupReplication & {
            ConsumerGroupsToReplicate: __listOf__stringMax256;
        };
        TopicReplication: TopicReplication & {
            TopicsToReplicate: __listOf__stringMax249;
        };
    })[] | undefined;
    ReplicatorArn?: string | undefined;
    ReplicatorDescription?: string | undefined;
    ReplicatorName?: string | undefined;
    ReplicatorResourceArn?: string | undefined;
    ReplicatorState?: ReplicatorState | undefined;
    ServiceExecutionRoleArn?: string | undefined;
    StateInfo?: ReplicationStateInfo | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    LogDelivery?: (LogDelivery & {
        ReplicatorLogDelivery: ReplicatorLogDelivery & {
            CloudWatchLogs: ReplicatorCloudWatchLogs & {
                Enabled: boolean;
            };
            Firehose: ReplicatorFirehose & {
                Enabled: boolean;
            };
            S3: ReplicatorS3 & {
                Enabled: boolean;
            };
        };
    }) | undefined;
}
export interface DescribeTopicRequest {
    ClusterArn: string;
    TopicName: string;
}
export interface DescribeTopicResponse {
    TopicArn?: string | undefined;
    TopicName?: string | undefined;
    ReplicationFactor?: number | undefined;
    PartitionCount?: number | undefined;
    Configs?: string | undefined;
    Status?: TopicState | undefined;
}
export type MaxResults = number;
export interface DescribeTopicPartitionsRequest {
    ClusterArn: string;
    TopicName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOf__integer = number[];
export interface TopicPartitionInfo {
    Partition?: number | undefined;
    Leader?: number | undefined;
    Replicas?: number[] | undefined;
    Isr?: number[] | undefined;
}
export type __listOfTopicPartitionInfo = TopicPartitionInfo[];
export interface DescribeTopicPartitionsResponse {
    Partitions?: TopicPartitionInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeVpcConnectionRequest {
    Arn: string;
}
export interface DescribeVpcConnectionResponse {
    VpcConnectionArn?: string | undefined;
    TargetClusterArn?: string | undefined;
    State?: VpcConnectionState | undefined;
    Authentication?: string | undefined;
    VpcId?: string | undefined;
    Subnets?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    CreationTime?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetBootstrapBrokersRequest {
    ClusterArn: string;
}
export interface GetBootstrapBrokersResponse {
    BootstrapBrokerString?: string | undefined;
    BootstrapBrokerStringTls?: string | undefined;
    BootstrapBrokerStringSaslScram?: string | undefined;
    BootstrapBrokerStringSaslIam?: string | undefined;
    BootstrapBrokerStringPublicTls?: string | undefined;
    BootstrapBrokerStringPublicSaslScram?: string | undefined;
    BootstrapBrokerStringPublicSaslIam?: string | undefined;
    BootstrapBrokerStringVpcConnectivityTls?: string | undefined;
    BootstrapBrokerStringVpcConnectivitySaslScram?: string | undefined;
    BootstrapBrokerStringVpcConnectivitySaslIam?: string | undefined;
    BootstrapBrokerStringIpv6?: string | undefined;
    BootstrapBrokerStringTlsIpv6?: string | undefined;
    BootstrapBrokerStringSaslScramIpv6?: string | undefined;
    BootstrapBrokerStringSaslIamIpv6?: string | undefined;
}
export interface GetClusterPolicyRequest {
    ClusterArn: string;
}
export interface GetClusterPolicyResponse {
    CurrentVersion?: string | undefined;
    Policy?: string | undefined;
}
export interface GetCompatibleKafkaVersionsRequest {
    ClusterArn?: string | undefined;
}
export interface CompatibleKafkaVersion {
    SourceVersion?: string | undefined;
    TargetVersions?: string[] | undefined;
}
export type __listOfCompatibleKafkaVersion = CompatibleKafkaVersion[];
export interface GetCompatibleKafkaVersionsResponse {
    CompatibleKafkaVersions?: CompatibleKafkaVersion[] | undefined;
}
export interface ListChannelsRequest {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    TopicNameFilter?: string | undefined;
}
export interface ChannelInfo {
    ChannelArn?: string | undefined;
    ChannelName?: string | undefined;
    Status?: ChannelStatus | undefined;
    CreationTime?: Date | undefined;
    DestinationType?: ChannelDestinationType | undefined;
    ClusterOperationArn?: string | undefined;
}
export type __listOfChannelInfo = ChannelInfo[];
export interface ListChannelsResponse {
    Channels?: (ChannelInfo & {
        ChannelArn: string;
        ChannelName: string;
        Status: ChannelStatus;
        CreationTime: __timestampIso8601;
        DestinationType: ChannelDestinationType;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClientVpcConnectionsRequest {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ClientVpcConnection {
    Authentication?: string | undefined;
    CreationTime?: Date | undefined;
    State?: VpcConnectionState | undefined;
    VpcConnectionArn?: string | undefined;
    Owner?: string | undefined;
}
export type __listOfClientVpcConnection = ClientVpcConnection[];
export interface ListClientVpcConnectionsResponse {
    ClientVpcConnections?: (ClientVpcConnection & {
        VpcConnectionArn: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClusterOperationsRequest {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfClusterOperationInfo = ClusterOperationInfo[];
export interface ListClusterOperationsResponse {
    ClusterOperationInfoList?: (ClusterOperationInfo & {
        SourceClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
        TargetClusterInfo: MutableClusterInfo & {
            BrokerEBSVolumeInfo: (BrokerEBSVolumeInfo & {
                KafkaBrokerNodeId: string;
            })[];
            ConfigurationInfo: ConfigurationInfo & {
                Arn: string;
                Revision: number;
            };
            OpenMonitoring: OpenMonitoring & {
                Prometheus: Prometheus & {
                    JmxExporter: JmxExporter & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporter & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClusterOperationsV2Request {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ClusterOperationV2Summary {
    ClusterArn?: string | undefined;
    ClusterType?: ClusterType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    OperationArn?: string | undefined;
    OperationState?: string | undefined;
    OperationType?: string | undefined;
}
export type __listOfClusterOperationV2Summary = ClusterOperationV2Summary[];
export interface ListClusterOperationsV2Response {
    ClusterOperationInfoList?: ClusterOperationV2Summary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClustersRequest {
    ClusterNameFilter?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfClusterInfo = ClusterInfo[];
export interface ListClustersResponse {
    ClusterInfoList?: (ClusterInfo & {
        BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
            ClientSubnets: __listOf__string;
            InstanceType: __stringMin5Max32;
        };
        EncryptionInfo: EncryptionInfo & {
            EncryptionAtRest: EncryptionAtRest & {
                DataVolumeKMSKeyId: string;
            };
        };
        OpenMonitoring: OpenMonitoring & {
            Prometheus: Prometheus & {
                JmxExporter: JmxExporter & {
                    EnabledInBroker: boolean;
                };
                NodeExporter: NodeExporter & {
                    EnabledInBroker: boolean;
                };
            };
        };
        LoggingInfo: LoggingInfo & {
            BrokerLogs: BrokerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
            AuthorizerLogs: AuthorizerLogs & {
                CloudWatchLogs: CloudWatchLogs & {
                    Enabled: boolean;
                };
                Firehose: Firehose & {
                    Enabled: boolean;
                };
                S3: S3 & {
                    Enabled: boolean;
                };
            };
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListClustersV2Request {
    ClusterNameFilter?: string | undefined;
    ClusterTypeFilter?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfCluster = Cluster[];
export interface ListClustersV2Response {
    ClusterInfoList?: (Cluster & {
        Provisioned: Provisioned & {
            BrokerNodeGroupInfo: BrokerNodeGroupInfo & {
                ClientSubnets: __listOf__string;
                InstanceType: __stringMin5Max32;
            };
            NumberOfBrokerNodes: __integerMin1Max15;
            EncryptionInfo: EncryptionInfo & {
                EncryptionAtRest: EncryptionAtRest & {
                    DataVolumeKMSKeyId: string;
                };
            };
            OpenMonitoring: OpenMonitoringInfo & {
                Prometheus: PrometheusInfo & {
                    JmxExporter: JmxExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                    NodeExporter: NodeExporterInfo & {
                        EnabledInBroker: boolean;
                    };
                };
            };
            LoggingInfo: LoggingInfo & {
                BrokerLogs: BrokerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
                AuthorizerLogs: AuthorizerLogs & {
                    CloudWatchLogs: CloudWatchLogs & {
                        Enabled: boolean;
                    };
                    Firehose: Firehose & {
                        Enabled: boolean;
                    };
                    S3: S3 & {
                        Enabled: boolean;
                    };
                };
            };
        };
        Serverless: Serverless & {
            VpcConfigs: (VpcConfig & {
                SubnetIds: __listOf__string;
            })[];
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConfigurationRevisionsRequest {
    Arn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfConfigurationRevision = ConfigurationRevision[];
export interface ListConfigurationRevisionsResponse {
    NextToken?: string | undefined;
    Revisions?: (ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    })[] | undefined;
}
export interface ListConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Configuration {
    Arn?: string | undefined;
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    KafkaVersions?: string[] | undefined;
    LatestRevision?: ConfigurationRevision | undefined;
    Name?: string | undefined;
    State?: ConfigurationState | undefined;
}
export type __listOfConfiguration = Configuration[];
export interface ListConfigurationsResponse {
    Configurations?: (Configuration & {
        Arn: string;
        CreationTime: __timestampIso8601;
        Description: string;
        KafkaVersions: __listOf__string;
        LatestRevision: ConfigurationRevision & {
            CreationTime: __timestampIso8601;
            Revision: number;
        };
        Name: string;
        State: ConfigurationState;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListKafkaVersionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type KafkaVersionStatus = "ACTIVE" | "DEPRECATED" | (string & {});
export interface KafkaVersion {
    Version?: string | undefined;
    Status?: KafkaVersionStatus | undefined;
}
export type __listOfKafkaVersion = KafkaVersion[];
export interface ListKafkaVersionsResponse {
    KafkaVersions?: KafkaVersion[] | undefined;
    NextToken?: string | undefined;
}
export interface ListNodesRequest {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface BrokerNodeInfo {
    AttachedENIId?: string | undefined;
    BrokerId?: number | undefined;
    ClientSubnet?: string | undefined;
    ClientVpcIpAddress?: string | undefined;
    CurrentBrokerSoftwareInfo?: BrokerSoftwareInfo | undefined;
    Endpoints?: string[] | undefined;
}
export interface ControllerNodeInfo {
    Endpoints?: string[] | undefined;
}
export type NodeType = "BROKER" | (string & {});
export interface ZookeeperNodeInfo {
    AttachedENIId?: string | undefined;
    ClientVpcIpAddress?: string | undefined;
    Endpoints?: string[] | undefined;
    ZookeeperId?: number | undefined;
    ZookeeperVersion?: string | undefined;
}
export interface NodeInfo {
    AddedToClusterTime?: string | undefined;
    BrokerNodeInfo?: BrokerNodeInfo | undefined;
    ControllerNodeInfo?: ControllerNodeInfo | undefined;
    InstanceType?: string | undefined;
    NodeARN?: string | undefined;
    NodeType?: NodeType | undefined;
    ZookeeperNodeInfo?: ZookeeperNodeInfo | undefined;
}
export type __listOfNodeInfo = NodeInfo[];
export interface ListNodesResponse {
    NextToken?: string | undefined;
    NodeInfoList?: NodeInfo[] | undefined;
}
export interface ListReplicatorsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ReplicatorNameFilter?: string | undefined;
}
export interface KafkaClusterSummary {
    AmazonMskCluster?: AmazonMskCluster | undefined;
    ApacheKafkaCluster?: ApacheKafkaCluster | undefined;
    KafkaClusterAlias?: string | undefined;
}
export type __listOfKafkaClusterSummary = KafkaClusterSummary[];
export interface ReplicationInfoSummary {
    SourceKafkaClusterAlias?: string | undefined;
    TargetKafkaClusterAlias?: string | undefined;
}
export type __listOfReplicationInfoSummary = ReplicationInfoSummary[];
export interface ReplicatorSummary {
    CreationTime?: Date | undefined;
    CurrentVersion?: string | undefined;
    IsReplicatorReference?: boolean | undefined;
    KafkaClustersSummary?: KafkaClusterSummary[] | undefined;
    ReplicationInfoSummaryList?: ReplicationInfoSummary[] | undefined;
    ReplicatorArn?: string | undefined;
    ReplicatorName?: string | undefined;
    ReplicatorResourceArn?: string | undefined;
    ReplicatorState?: ReplicatorState | undefined;
}
export type __listOfReplicatorSummary = ReplicatorSummary[];
export interface ListReplicatorsResponse {
    NextToken?: string | undefined;
    Replicators?: (ReplicatorSummary & {
        KafkaClustersSummary: (KafkaClusterSummary & {
            AmazonMskCluster: AmazonMskCluster & {
                MskClusterArn: string;
            };
            ApacheKafkaCluster: ApacheKafkaCluster & {
                ApacheKafkaClusterId: string;
                BootstrapBrokerString: string;
            };
        })[];
    })[] | undefined;
}
export interface ListScramSecretsRequest {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListScramSecretsResponse {
    NextToken?: string | undefined;
    SecretArnList?: string[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTopicsRequest {
    ClusterArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    TopicNameFilter?: string | undefined;
}
export interface TopicInfo {
    TopicArn?: string | undefined;
    TopicName?: string | undefined;
    ReplicationFactor?: number | undefined;
    PartitionCount?: number | undefined;
    OutOfSyncReplicaCount?: number | undefined;
}
export type __listOfTopicInfo = TopicInfo[];
export interface ListTopicsResponse {
    Topics?: TopicInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListVpcConnectionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface VpcConnection {
    VpcConnectionArn?: string | undefined;
    TargetClusterArn?: string | undefined;
    CreationTime?: Date | undefined;
    Authentication?: string | undefined;
    VpcId?: string | undefined;
    State?: VpcConnectionState | undefined;
}
export type __listOfVpcConnection = VpcConnection[];
export interface ListVpcConnectionsResponse {
    VpcConnections?: (VpcConnection & {
        VpcConnectionArn: string;
        TargetClusterArn: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface PutClusterPolicyRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    Policy?: string | undefined;
}
export interface PutClusterPolicyResponse {
    CurrentVersion?: string | undefined;
}
export interface RebootBrokerRequest {
    BrokerIds?: string[] | undefined;
    ClusterArn: string;
}
export interface RebootBrokerResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface RejectClientVpcConnectionRequest {
    ClusterArn: string;
    VpcConnectionArn?: string | undefined;
}
export interface RejectClientVpcConnectionResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateBrokerCountRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    TargetNumberOfBrokerNodes?: number | undefined;
}
export interface UpdateBrokerCountResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateBrokerStorageRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    TargetBrokerEBSVolumeInfo?: BrokerEBSVolumeInfo[] | undefined;
}
export interface UpdateBrokerStorageResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateBrokerTypeRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    TargetInstanceType?: string | undefined;
}
export interface UpdateBrokerTypeResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface IcebergDestinationUpdate {
    DataFreshnessInSeconds?: number | undefined;
}
export interface S3DestinationUpdate {
    DataFreshnessInSeconds?: number | undefined;
}
export interface UpdateChannelRequest {
    ChannelArn: string;
    ClusterArn: string;
    IcebergDestinationUpdate?: IcebergDestinationUpdate | undefined;
    S3DestinationUpdate?: S3DestinationUpdate | undefined;
}
export interface UpdateChannelResponse {
    ChannelArn: string;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateClusterConfigurationRequest {
    ClusterArn: string;
    ConfigurationInfo?: ConfigurationInfo | undefined;
    CurrentVersion?: string | undefined;
}
export interface UpdateClusterConfigurationResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateClusterKafkaVersionRequest {
    ClusterArn: string;
    ConfigurationInfo?: ConfigurationInfo | undefined;
    CurrentVersion?: string | undefined;
    TargetKafkaVersion?: string | undefined;
}
export interface UpdateClusterKafkaVersionResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateConfigurationRequest {
    Arn: string;
    Description?: string | undefined;
    ServerProperties?: Uint8Array | undefined;
}
export interface UpdateConfigurationResponse {
    Arn?: string | undefined;
    LatestRevision?: (ConfigurationRevision & {
        CreationTime: __timestampIso8601;
        Revision: number;
    }) | undefined;
}
export interface UpdateConnectivityRequest {
    ClusterArn: string;
    ConnectivityInfo?: ConnectivityInfo | undefined;
    CurrentVersion?: string | undefined;
    ZookeeperAccess?: ZookeeperAccess | undefined;
}
export interface UpdateConnectivityResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateMonitoringRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    EnhancedMonitoring?: EnhancedMonitoring | undefined;
    OpenMonitoring?: OpenMonitoringInfo | undefined;
    LoggingInfo?: LoggingInfo | undefined;
}
export interface UpdateMonitoringResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateRebalancingRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    Rebalancing?: Rebalancing | undefined;
}
export interface UpdateRebalancingResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface ConsumerGroupReplicationUpdate {
    ConsumerGroupsToExclude?: string[] | undefined;
    ConsumerGroupsToReplicate?: string[] | undefined;
    DetectAndCopyNewConsumerGroups?: boolean | undefined;
    SynchroniseConsumerGroupOffsets?: boolean | undefined;
}
export interface TopicReplicationUpdate {
    CopyAccessControlListsForTopics?: boolean | undefined;
    CopyTopicConfigurations?: boolean | undefined;
    DetectAndCopyNewTopics?: boolean | undefined;
    TopicsToExclude?: string[] | undefined;
    TopicsToReplicate?: string[] | undefined;
}
export interface UpdateReplicationInfoRequest {
    ConsumerGroupReplication?: ConsumerGroupReplicationUpdate | undefined;
    CurrentVersion?: string | undefined;
    ReplicatorArn: string;
    SourceKafkaClusterArn?: string | undefined;
    SourceKafkaClusterId?: string | undefined;
    TargetKafkaClusterArn?: string | undefined;
    TargetKafkaClusterId?: string | undefined;
    TopicReplication?: TopicReplicationUpdate | undefined;
    LogDelivery?: LogDelivery | undefined;
}
export interface UpdateReplicationInfoResponse {
    ReplicatorArn?: string | undefined;
    ReplicatorState?: ReplicatorState | undefined;
}
export interface UpdateSecurityRequest {
    ClientAuthentication?: ClientAuthentication | undefined;
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    EncryptionInfo?: EncryptionInfo | undefined;
}
export interface UpdateSecurityResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateStorageRequest {
    ClusterArn: string;
    CurrentVersion?: string | undefined;
    ProvisionedThroughput?: ProvisionedThroughput | undefined;
    StorageMode?: StorageMode | undefined;
    VolumeSizeGB?: number | undefined;
}
export interface UpdateStorageResponse {
    ClusterArn?: string | undefined;
    ClusterOperationArn?: string | undefined;
}
export interface UpdateTopicRequest {
    ClusterArn: string;
    TopicName: string;
    Configs?: string | undefined;
    PartitionCount?: number | undefined;
}
export interface UpdateTopicResponse {
    TopicArn?: string | undefined;
    TopicName?: string | undefined;
    Status?: TopicState | undefined;
}
export type BatchAssociateScramSecretError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Associates one or more Scram Secrets with an Amazon MSK cluster.
 */
export declare const batchAssociateScramSecret: API.OperationMethod<BatchAssociateScramSecretRequest & RegionInput, BatchAssociateScramSecretResponse, BatchAssociateScramSecretError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateScramSecretError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Disassociates one or more Scram Secrets from an Amazon MSK cluster.
 */
export declare const batchDisassociateScramSecret: API.OperationMethod<BatchDisassociateScramSecretRequest & RegionInput, BatchDisassociateScramSecretResponse, BatchDisassociateScramSecretError, Credentials | HttpClient.HttpClient>;
export type CreateChannelError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Channel that streams records from an Amazon MSK Express cluster topic to Amazon S3 or Apache Iceberg.
 */
export declare const createChannel: API.OperationMethod<CreateChannelRequest & RegionInput, CreateChannelResponse, CreateChannelError, Credentials | HttpClient.HttpClient>;
export type CreateClusterError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK cluster.
 */
export declare const createCluster: API.OperationMethod<CreateClusterRequest & RegionInput, CreateClusterResponse, CreateClusterError, Credentials | HttpClient.HttpClient>;
export type CreateClusterV2Error = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK cluster.
 */
export declare const createClusterV2: API.OperationMethod<CreateClusterV2Request & RegionInput, CreateClusterV2Response, CreateClusterV2Error, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK configuration.
 */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest & RegionInput, CreateConfigurationResponse, CreateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateReplicatorError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates the replicator.
 */
export declare const createReplicator: API.OperationMethod<CreateReplicatorRequest & RegionInput, CreateReplicatorResponse, CreateReplicatorError, Credentials | HttpClient.HttpClient>;
export type CreateTopicError = BadRequestException | ClusterConnectivityException | ConflictException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | ReassignmentInProgressException | ServiceUnavailableException | TooManyRequestsException | TopicExistsException | UnauthorizedException | UnknownTopicOrPartitionException | ServerlessUnsupported | CommonErrors;
/**
 * Creates a topic in the specified MSK cluster.
 */
export declare const createTopic: API.OperationMethod<CreateTopicRequest & RegionInput, CreateTopicResponse, CreateTopicError, Credentials | HttpClient.HttpClient>;
export type CreateVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new MSK VPC connection.
 */
export declare const createVpcConnection: API.OperationMethod<CreateVpcConnectionRequest & RegionInput, CreateVpcConnectionResponse, CreateVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the channel specified by channelArn from the cluster specified by clusterArn. The channel transitions through DELETING and is removed when the asynchronous delete completes.
 */
export declare const deleteChannel: API.OperationMethod<DeleteChannelRequest & RegionInput, DeleteChannelResponse, DeleteChannelError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the MSK cluster specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const deleteCluster: API.OperationMethod<DeleteClusterRequest & RegionInput, DeleteClusterResponse, DeleteClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the MSK cluster policy specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const deleteClusterPolicy: API.OperationMethod<DeleteClusterPolicyRequest & RegionInput, DeleteClusterPolicyResponse, DeleteClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes an MSK Configuration.
 */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest & RegionInput, DeleteConfigurationResponse, DeleteConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicatorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a replicator.
 */
export declare const deleteReplicator: API.OperationMethod<DeleteReplicatorRequest & RegionInput, DeleteReplicatorResponse, DeleteReplicatorError, Credentials | HttpClient.HttpClient>;
export type DeleteTopicError = BadRequestException | ClusterConnectivityException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | NotFoundException | ReassignmentInProgressException | UnknownTopicOrPartitionException | ServerlessUnsupported | CommonErrors;
/**
 * Deletes a topic in the specified MSK cluster.
 */
export declare const deleteTopic: API.OperationMethod<DeleteTopicRequest & RegionInput, DeleteTopicResponse, DeleteTopicError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes a MSK VPC connection.
 */
export declare const deleteVpcConnection: API.OperationMethod<DeleteVpcConnectionRequest & RegionInput, DeleteVpcConnectionResponse, DeleteVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the current configuration and state of a channel.
 */
export declare const describeChannel: API.OperationMethod<DescribeChannelRequest & RegionInput, DescribeChannelResponse, DescribeChannelError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the MSK cluster whose Amazon Resource Name (ARN) is specified in the request.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterRequest & RegionInput, DescribeClusterResponse, DescribeClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the cluster operation specified by the ARN.
 */
export declare const describeClusterOperation: API.OperationMethod<DescribeClusterOperationRequest & RegionInput, DescribeClusterOperationResponse, DescribeClusterOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeClusterOperationV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the cluster operation specified by the ARN.
 */
export declare const describeClusterOperationV2: API.OperationMethod<DescribeClusterOperationV2Request & RegionInput, DescribeClusterOperationV2Response, DescribeClusterOperationV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeClusterV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of the MSK cluster whose Amazon Resource Name (ARN) is specified in the request.
 */
export declare const describeClusterV2: API.OperationMethod<DescribeClusterV2Request & RegionInput, DescribeClusterV2Response, DescribeClusterV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this MSK configuration.
 */
export declare const describeConfiguration: API.OperationMethod<DescribeConfigurationRequest & RegionInput, DescribeConfigurationResponse, DescribeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationRevisionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this revision of the configuration.
 */
export declare const describeConfigurationRevision: API.OperationMethod<DescribeConfigurationRevisionRequest & RegionInput, DescribeConfigurationRevisionResponse, DescribeConfigurationRevisionError, Credentials | HttpClient.HttpClient>;
export type DescribeReplicatorError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes a replicator.
 */
export declare const describeReplicator: API.OperationMethod<DescribeReplicatorRequest & RegionInput, DescribeReplicatorResponse, DescribeReplicatorError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | ServerlessUnsupported | CommonErrors;
/**
 * Returns topic details of this topic on a MSK cluster.
 */
export declare const describeTopic: API.OperationMethod<DescribeTopicRequest & RegionInput, DescribeTopicResponse, DescribeTopicError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicPartitionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Returns partition details of this topic on a MSK cluster.
 */
export declare const describeTopicPartitions: API.PaginatedOperationMethod<DescribeTopicPartitionsRequest & RegionInput, DescribeTopicPartitionsResponse, DescribeTopicPartitionsError, Credentials | HttpClient.HttpClient, TopicPartitionInfo>;
export type DescribeVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a description of this MSK VPC connection.
 */
export declare const describeVpcConnection: API.OperationMethod<DescribeVpcConnectionRequest & RegionInput, DescribeVpcConnectionResponse, DescribeVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type GetBootstrapBrokersError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | UnauthorizedException | NotFoundException | CommonErrors;
/**
 * A list of brokers that a client application can use to bootstrap. This list doesn't necessarily include all of the brokers in the cluster. The following Python 3.6 example shows how you can use the Amazon Resource Name (ARN) of a cluster to get its bootstrap brokers. If you don't know the ARN of your cluster, you can use the `ListClusters` operation to get the ARNs of all the clusters in this account and Region.
 */
export declare const getBootstrapBrokers: API.OperationMethod<GetBootstrapBrokersRequest & RegionInput, GetBootstrapBrokersResponse, GetBootstrapBrokersError, Credentials | HttpClient.HttpClient>;
export type GetClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Get the MSK cluster policy specified by the Amazon Resource Name (ARN) in the request.
 */
export declare const getClusterPolicy: API.OperationMethod<GetClusterPolicyRequest & RegionInput, GetClusterPolicyResponse, GetClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleKafkaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the Apache Kafka versions to which you can update the MSK cluster.
 */
export declare const getCompatibleKafkaVersions: API.OperationMethod<GetCompatibleKafkaVersionsRequest & RegionInput, GetCompatibleKafkaVersionsResponse, GetCompatibleKafkaVersionsError, Credentials | HttpClient.HttpClient>;
export type ListChannelsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns the list of channels in a cluster.
 */
export declare const listChannels: API.OperationMethod<ListChannelsRequest & RegionInput, ListChannelsResponse, ListChannelsError, Credentials | HttpClient.HttpClient>;
export type ListClientVpcConnectionsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the VPC connections in this Region.
 */
export declare const listClientVpcConnections: API.PaginatedOperationMethod<ListClientVpcConnectionsRequest & RegionInput, ListClientVpcConnectionsResponse, ListClientVpcConnectionsError, Credentials | HttpClient.HttpClient, ClientVpcConnection>;
export type ListClusterOperationsError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the operations that have been performed on the specified MSK cluster.
 */
export declare const listClusterOperations: API.PaginatedOperationMethod<ListClusterOperationsRequest & RegionInput, ListClusterOperationsResponse, ListClusterOperationsError, Credentials | HttpClient.HttpClient, ClusterOperationInfo>;
export type ListClusterOperationsV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the operations that have been performed on the specified MSK cluster.
 */
export declare const listClusterOperationsV2: API.PaginatedOperationMethod<ListClusterOperationsV2Request & RegionInput, ListClusterOperationsV2Response, ListClusterOperationsV2Error, Credentials | HttpClient.HttpClient, ClusterOperationV2Summary>;
export type ListClustersError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK clusters in the current Region.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersRequest & RegionInput, ListClustersResponse, ListClustersError, Credentials | HttpClient.HttpClient, ClusterInfo>;
export type ListClustersV2Error = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK clusters in the current Region.
 */
export declare const listClustersV2: API.PaginatedOperationMethod<ListClustersV2Request & RegionInput, ListClustersV2Response, ListClustersV2Error, Credentials | HttpClient.HttpClient, Cluster>;
export type ListConfigurationRevisionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK configurations in this Region.
 */
export declare const listConfigurationRevisions: API.PaginatedOperationMethod<ListConfigurationRevisionsRequest & RegionInput, ListConfigurationRevisionsResponse, ListConfigurationRevisionsError, Credentials | HttpClient.HttpClient, ConfigurationRevision>;
export type ListConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the MSK configurations in this Region.
 */
export declare const listConfigurations: API.PaginatedOperationMethod<ListConfigurationsRequest & RegionInput, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient, Configuration>;
export type ListKafkaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of Apache Kafka versions.
 */
export declare const listKafkaVersions: API.PaginatedOperationMethod<ListKafkaVersionsRequest & RegionInput, ListKafkaVersionsResponse, ListKafkaVersionsError, Credentials | HttpClient.HttpClient, KafkaVersion>;
export type ListNodesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of the broker nodes in the cluster.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesRequest & RegionInput, ListNodesResponse, ListNodesError, Credentials | HttpClient.HttpClient, NodeInfo>;
export type ListReplicatorsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the replicators.
 */
export declare const listReplicators: API.PaginatedOperationMethod<ListReplicatorsRequest & RegionInput, ListReplicatorsResponse, ListReplicatorsError, Credentials | HttpClient.HttpClient, ReplicatorSummary>;
export type ListScramSecretsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of the Scram Secrets associated with an Amazon MSK cluster.
 */
export declare const listScramSecrets: API.PaginatedOperationMethod<ListScramSecretsRequest & RegionInput, ListScramSecretsResponse, ListScramSecretsError, Credentials | HttpClient.HttpClient, string>;
export type ListTagsForResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of the tags associated with the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTopicsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | NotFoundException | ServerlessUnsupported | CommonErrors;
/**
 * List topics in a MSK cluster.
 */
export declare const listTopics: API.PaginatedOperationMethod<ListTopicsRequest & RegionInput, ListTopicsResponse, ListTopicsError, Credentials | HttpClient.HttpClient, TopicInfo>;
export type ListVpcConnectionsError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns a list of all the VPC connections in this Region.
 */
export declare const listVpcConnections: API.PaginatedOperationMethod<ListVpcConnectionsRequest & RegionInput, ListVpcConnectionsResponse, ListVpcConnectionsError, Credentials | HttpClient.HttpClient, VpcConnection>;
export type PutClusterPolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Creates or updates the MSK cluster policy specified by the cluster Amazon Resource Name (ARN) in the request.
 */
export declare const putClusterPolicy: API.OperationMethod<PutClusterPolicyRequest & RegionInput, PutClusterPolicyResponse, PutClusterPolicyError, Credentials | HttpClient.HttpClient>;
export type RebootBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Reboots brokers.
 */
export declare const rebootBroker: API.OperationMethod<RebootBrokerRequest & RegionInput, RebootBrokerResponse, RebootBrokerError, Credentials | HttpClient.HttpClient>;
export type RejectClientVpcConnectionError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Returns empty response.
 */
export declare const rejectClientVpcConnection: API.OperationMethod<RejectClientVpcConnectionRequest & RegionInput, RejectClientVpcConnectionResponse, RejectClientVpcConnectionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds tags to the specified MSK resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes the tags associated with the keys that are provided in the query.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerCountError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the number of broker nodes in the cluster.
 */
export declare const updateBrokerCount: API.OperationMethod<UpdateBrokerCountRequest & RegionInput, UpdateBrokerCountResponse, UpdateBrokerCountError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerStorageError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the EBS storage associated with MSK brokers.
 */
export declare const updateBrokerStorage: API.OperationMethod<UpdateBrokerStorageRequest & RegionInput, UpdateBrokerStorageResponse, UpdateBrokerStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerTypeError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates EC2 instance type.
 */
export declare const updateBrokerType: API.OperationMethod<UpdateBrokerTypeRequest & RegionInput, UpdateBrokerTypeResponse, UpdateBrokerTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the destination configuration of an existing channel. Exactly one of icebergDestinationUpdate or s3DestinationUpdate must be supplied.
 */
export declare const updateChannel: API.OperationMethod<UpdateChannelRequest & RegionInput, UpdateChannelResponse, UpdateChannelError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the cluster with the configuration that is specified in the request body.
 */
export declare const updateClusterConfiguration: API.OperationMethod<UpdateClusterConfigurationRequest & RegionInput, UpdateClusterConfigurationResponse, UpdateClusterConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateClusterKafkaVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the Apache Kafka version for the cluster.
 */
export declare const updateClusterKafkaVersion: API.OperationMethod<UpdateClusterKafkaVersionRequest & RegionInput, UpdateClusterKafkaVersionResponse, UpdateClusterKafkaVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates an MSK configuration.
 */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest & RegionInput, UpdateConfigurationResponse, UpdateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the cluster's connectivity configuration.
 */
export declare const updateConnectivity: API.OperationMethod<UpdateConnectivityRequest & RegionInput, UpdateConnectivityResponse, UpdateConnectivityError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitoringError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the monitoring settings for the cluster. You can use this operation to specify which Apache Kafka metrics you want Amazon MSK to send to Amazon CloudWatch. You can also specify settings for open monitoring with Prometheus.
 */
export declare const updateMonitoring: API.OperationMethod<UpdateMonitoringRequest & RegionInput, UpdateMonitoringResponse, UpdateMonitoringError, Credentials | HttpClient.HttpClient>;
export type UpdateRebalancingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Use this resource to update the intelligent rebalancing status of an Amazon MSK Provisioned cluster with Express brokers.
 */
export declare const updateRebalancing: API.OperationMethod<UpdateRebalancingRequest & RegionInput, UpdateRebalancingResponse, UpdateRebalancingError, Credentials | HttpClient.HttpClient>;
export type UpdateReplicationInfoError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates replication info of a replicator.
 */
export declare const updateReplicationInfo: API.OperationMethod<UpdateReplicationInfoRequest & RegionInput, UpdateReplicationInfoResponse, UpdateReplicationInfoError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates the security settings for the cluster. You can use this operation to specify encryption and authentication on existing clusters.
 */
export declare const updateSecurity: API.OperationMethod<UpdateSecurityRequest & RegionInput, UpdateSecurityResponse, UpdateSecurityError, Credentials | HttpClient.HttpClient>;
export type UpdateStorageError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates cluster broker volume size (or) sets cluster storage mode to TIERED.
 */
export declare const updateStorage: API.OperationMethod<UpdateStorageRequest & RegionInput, UpdateStorageResponse, UpdateStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicError = BadRequestException | ClusterConnectivityException | ControllerMovedException | ForbiddenException | GroupSubscribedToTopicException | InternalServerErrorException | KafkaRequestException | KafkaTimeoutException | NotControllerException | NotFoundException | ReassignmentInProgressException | ServiceUnavailableException | UnauthorizedException | UnknownTopicOrPartitionException | ServerlessUnsupported | CommonErrors;
/**
 * Updates the configuration of the specified topic.
 */
export declare const updateTopic: API.OperationMethod<UpdateTopicRequest & RegionInput, UpdateTopicResponse, UpdateTopicError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kafka.d.ts.map