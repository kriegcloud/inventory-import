/**
 * The workerd flavor of the Worker bridge, shared by every engine that runs
 * Workers-compatible bundles (Cloudflare today): the platform services a
 * workerd isolate builds its init against, and the `WorkerEntrypoint` class
 * that turns workerd's handler and JSRPC calls into Effect events over the
 * engine-invariant core in `../WorkerBridge.ts`.
 *
 * @internal
 */
import type * as cf from "@cloudflare/workers-types";
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { handleRpcExit, type SharedBuildOptions, type WorkerBuild, type WorkerRuntimeContextLike } from "../Worker.ts";
/** workerd's `WorkerEntrypoint` (or `DurableObject`) base class. */
export type WorkerdEntrypointClass = abstract new (ctx: any, env: any) => object;
export declare const workerdBuildOptions: SharedBuildOptions;
export interface WorkerdWorkerBridgeOptions<Runtime extends WorkerRuntimeContextLike> {
    readonly entrypoint: any;
    readonly stack: {
        readonly name: string;
        readonly stage: string;
    };
    readonly buildOptions: SharedBuildOptions;
    /** The workerd handler methods the bridge installs (`fetch`, `queue`, …). */
    readonly handlers: readonly string[];
    /** Per-event services built from workerd's execution context and env. */
    readonly services: (context: cf.ExecutionContext, env: Record<string, unknown>, built: WorkerBuild<any, Runtime>) => Layer.Layer<never>;
}
/**
 * Makes the WorkerEntrypoint class and bridges to Effect handler and RPC
 * calls.
 */
export declare const makeWorkerBridge: <Runtime extends WorkerRuntimeContextLike>(Base: WorkerdEntrypointClass, options: WorkerdWorkerBridgeOptions<Runtime>) => {
    new (ctx: any, env: any): {
        readonly ctx: any;
        readonly env: any;
        event<T>(makeEffect: (built: WorkerBuild<any, Runtime>) => readonly [Effect.Effect<any, any, any>, Context.Context<never>], onExit: (exit: Parameters<typeof handleRpcExit>[0], lifetime: Parameters<typeof handleRpcExit>[1] & {}) => Promise<T>): Promise<T>;
    };
};
//# sourceMappingURL=WorkerBridge.d.ts.map