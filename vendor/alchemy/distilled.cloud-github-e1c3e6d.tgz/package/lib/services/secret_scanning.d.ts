import * as API from "@distilled.cloud/core/api";
import type * as Redacted from "effect/Redacted";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** List of regexes that the secret must match. */
export type SecretScanningCustomPatternToCreateMustMatchList = Array<string>;
/** List of regexes that the secret must not match. */
export type SecretScanningCustomPatternToCreateMustNotMatchList = Array<string>;
/** A custom pattern to create in a bulk operation. */
export interface SecretScanningCustomPatternToCreate {
    /** The name of the custom pattern. */
    name: string;
    /** The regular expression of the custom pattern. */
    pattern: string;
    /** The start delimiter regex for the custom pattern. Defaults to `\A|[^0-9A-Za-z]` when not specified. */
    start_delimiter?: string | undefined;
    /** The end delimiter regex for the custom pattern. Defaults to `\z|[^0-9A-Za-z]` when not specified. */
    end_delimiter?: string | undefined;
    /** List of regexes that the secret must match. */
    must_match?: SecretScanningCustomPatternToCreateMustMatchList | undefined;
    /** List of regexes that the secret must not match. */
    must_not_match?: SecretScanningCustomPatternToCreateMustNotMatchList | undefined;
}
/** The list of custom patterns to create (maximum 100). */
export type BulkCreateOrgCustomPatternsRequestPatternsList = Array<SecretScanningCustomPatternToCreate>;
export interface BulkCreateOrgCustomPatternsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The list of custom patterns to create (maximum 100). */
    patterns: BulkCreateOrgCustomPatternsRequestPatternsList;
}
/** The state of the custom pattern. */
export type SecretScanningCustomPatternState = "published" | "unpublished";
/** List of regexes that the secret must match. */
export type SecretScanningCustomPatternMustMatchList = Array<string>;
/** List of regexes that the secret must not match. */
export type SecretScanningCustomPatternMustNotMatchList = Array<string>;
/** A custom pattern for secret scanning. */
export interface SecretScanningCustomPattern {
    /** The ID of the custom pattern. */
    id: number;
    /** The name of the custom pattern. */
    name: string;
    /** The regular expression of the custom pattern. */
    pattern: string;
    /** A URL-friendly identifier for the custom pattern, derived from its name. */
    slug: string;
    /** The state of the custom pattern. */
    state: SecretScanningCustomPatternState;
    /** Whether push protection is enabled for this custom pattern. */
    push_protection_enabled: boolean;
    /** The start delimiter regex for the custom pattern. */
    start_delimiter?: string | null | undefined;
    /** The end delimiter regex for the custom pattern. */
    end_delimiter?: string | null | undefined;
    /** List of regexes that the secret must match. */
    must_match?: SecretScanningCustomPatternMustMatchList | null | undefined;
    /** List of regexes that the secret must not match. */
    must_not_match?: SecretScanningCustomPatternMustNotMatchList | null | undefined;
    custom_pattern_version?: string | null | undefined;
    /** The date and time the custom pattern was created in ISO 8601 format. */
    created_at?: string | undefined;
    /** The date and time the custom pattern was last updated in ISO 8601 format. */
    updated_at?: string | undefined;
}
/** The list of successfully created custom patterns. */
export type BulkCreateOrgCustomPatternsResponseCreatedPatternsList = Array<SecretScanningCustomPattern>;
export interface BulkCreateOrgCustomPatternsResponse {
    /** The list of successfully created custom patterns. */
    created_patterns?: BulkCreateOrgCustomPatternsResponseCreatedPatternsList | undefined;
}
/** The list of custom patterns to create (maximum 100). */
export type BulkCreateRepoCustomPatternsRequestPatternsList = Array<SecretScanningCustomPatternToCreate>;
export interface BulkCreateRepoCustomPatternsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The list of custom patterns to create (maximum 100). */
    patterns: BulkCreateRepoCustomPatternsRequestPatternsList;
}
/** The list of successfully created custom patterns. */
export type BulkCreateRepoCustomPatternsResponseCreatedPatternsList = Array<SecretScanningCustomPattern>;
export interface BulkCreateRepoCustomPatternsResponse {
    /** The list of successfully created custom patterns. */
    created_patterns?: BulkCreateRepoCustomPatternsResponseCreatedPatternsList | undefined;
}
/** A custom pattern to delete in a bulk operation. */
export interface SecretScanningCustomPatternToDelete {
    /** The ID of the custom pattern to delete. */
    pattern_id: number;
    custom_pattern_version?: string | null | undefined;
}
/** The list of custom patterns to delete. */
export type BulkDeleteOrgCustomPatternsRequestPatternsList = Array<SecretScanningCustomPatternToDelete>;
/** What to do with alerts associated with the deleted patterns. `delete_alerts` permanently removes the alerts. `resolve_alerts` resolves the alerts as "pattern deleted". Defaults to `delete_alerts` when not specified. */
export type BulkDeleteOrgCustomPatternsRequestPostDeleteAction = "delete_alerts" | "resolve_alerts";
export interface BulkDeleteOrgCustomPatternsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The list of custom patterns to delete. */
    patterns: BulkDeleteOrgCustomPatternsRequestPatternsList;
    /** What to do with alerts associated with the deleted patterns. `delete_alerts` permanently removes the alerts. `resolve_alerts` resolves the alerts as "pattern deleted". Defaults to `delete_alerts` when not specified. */
    post_delete_action?: BulkDeleteOrgCustomPatternsRequestPostDeleteAction | (string & {}) | undefined;
}
export interface BulkDeleteOrgCustomPatternsResponse {
}
/** The list of custom patterns to delete. */
export type BulkDeleteRepoCustomPatternsRequestPatternsList = Array<SecretScanningCustomPatternToDelete>;
/** What to do with alerts associated with the deleted patterns. `delete_alerts` permanently removes the alerts. `resolve_alerts` resolves the alerts as "pattern deleted". Defaults to `delete_alerts` when not specified. */
export type BulkDeleteRepoCustomPatternsRequestPostDeleteAction = "delete_alerts" | "resolve_alerts";
export interface BulkDeleteRepoCustomPatternsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The list of custom patterns to delete. */
    patterns: BulkDeleteRepoCustomPatternsRequestPatternsList;
    /** What to do with alerts associated with the deleted patterns. `delete_alerts` permanently removes the alerts. `resolve_alerts` resolves the alerts as "pattern deleted". Defaults to `delete_alerts` when not specified. */
    post_delete_action?: BulkDeleteRepoCustomPatternsRequestPostDeleteAction | (string & {}) | undefined;
}
export interface BulkDeleteRepoCustomPatternsResponse {
}
/** The reason for bypassing push protection. */
export type SecretScanningPushProtectionBypassReason = "false_positive" | "used_in_tests" | "will_fix_later";
export interface CreatePushProtectionBypassRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    reason: SecretScanningPushProtectionBypassReason | (string & {});
    placeholder_id: string;
}
export interface SecretScanningPushProtectionBypass {
    reason?: SecretScanningPushProtectionBypassReason | undefined;
    /** The time that the bypass will expire in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    expire_at?: string | null | undefined;
    /** The token type this bypass is for. */
    token_type?: string | undefined;
}
export interface GetAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
    /** A boolean value representing whether or not to hide literal secrets in the results. */
    hide_secret?: boolean | undefined;
}
/** Sets the state of the secret scanning alert. You must provide `resolution` when you set the state to `resolved`. */
export type SecretScanningAlertState = "open" | "resolved";
/** **Required when the `state` is `resolved`.** The reason for resolving the alert. */
export type SecretScanningAlertResolution = "false_positive" | "wont_fix" | "revoked" | "used_in_tests";
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** The token status as of the latest validity check. */
export type SecretScanningAlertWithMetadataValidity = "active" | "inactive" | "unknown";
/** Represents a 'commit' secret scanning location type. This location type shows that a secret was detected inside a commit to a repository. */
export interface SecretScanningLocationCommit {
    /** The file path in the repository */
    path: string;
    /** Line number at which the secret starts in the file */
    start_line: number;
    /** Line number at which the secret ends in the file */
    end_line: number;
    /** The column at which the secret starts within the start line when the file is interpreted as 8BIT ASCII */
    start_column: number;
    /** The column at which the secret ends within the end line when the file is interpreted as 8BIT ASCII */
    end_column: number;
    /** SHA-1 hash ID of the associated blob */
    blob_sha: string;
    /** The API URL to get the associated blob resource */
    blob_url: string;
    /** SHA-1 hash ID of the associated commit */
    commit_sha: string;
    /** The API URL to get the associated commit resource */
    commit_url: string;
    /** The GitHub URL to get the associated commit resource. */
    html_url?: string | undefined;
}
/** Represents a 'wiki_commit' secret scanning location type. This location type shows that a secret was detected inside a commit to a repository wiki. */
export interface SecretScanningLocationWikiCommit {
    /** The file path of the wiki page */
    path: string;
    /** Line number at which the secret starts in the file */
    start_line: number;
    /** Line number at which the secret ends in the file */
    end_line: number;
    /** The column at which the secret starts within the start line when the file is interpreted as 8-bit ASCII. */
    start_column: number;
    /** The column at which the secret ends within the end line when the file is interpreted as 8-bit ASCII. */
    end_column: number;
    /** SHA-1 hash ID of the associated blob */
    blob_sha: string;
    /** The GitHub URL to get the associated wiki page */
    page_url: string;
    /** SHA-1 hash ID of the associated commit */
    commit_sha: string;
    /** The GitHub URL to get the associated wiki commit */
    commit_url: string;
}
/** Represents an 'issue_title' secret scanning location type. This location type shows that a secret was detected in the title of an issue. */
export interface SecretScanningLocationIssueTitle {
    /** The API URL to get the issue where the secret was detected. */
    issue_title_url: string;
    /** The GitHub URL for the issue where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents an 'issue_body' secret scanning location type. This location type shows that a secret was detected in the body of an issue. */
export interface SecretScanningLocationIssueBody {
    /** The API URL to get the issue where the secret was detected. */
    issue_body_url: string;
    /** The GitHub URL for the issue where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents an 'issue_comment' secret scanning location type. This location type shows that a secret was detected in a comment on an issue. */
export interface SecretScanningLocationIssueComment {
    /** The API URL to get the issue comment where the secret was detected. */
    issue_comment_url: string;
    /** The GitHub URL for the issue comment where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents a 'discussion_title' secret scanning location type. This location type shows that a secret was detected in the title of a discussion. */
export interface SecretScanningLocationDiscussionTitle {
    /** The URL to the discussion where the secret was detected. */
    discussion_title_url: string;
}
/** Represents a 'discussion_body' secret scanning location type. This location type shows that a secret was detected in the body of a discussion. */
export interface SecretScanningLocationDiscussionBody {
    /** The URL to the discussion where the secret was detected. */
    discussion_body_url: string;
}
/** Represents a 'discussion_comment' secret scanning location type. This location type shows that a secret was detected in a comment on a discussion. */
export interface SecretScanningLocationDiscussionComment {
    /** The API URL to get the discussion comment where the secret was detected. */
    discussion_comment_url: string;
}
/** Represents a 'pull_request_title' secret scanning location type. This location type shows that a secret was detected in the title of a pull request. */
export interface SecretScanningLocationPullRequestTitle {
    /** The API URL to get the pull request where the secret was detected. */
    pull_request_title_url: string;
    /** The GitHub URL for the pull request where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents a 'pull_request_body' secret scanning location type. This location type shows that a secret was detected in the body of a pull request. */
export interface SecretScanningLocationPullRequestBody {
    /** The API URL to get the pull request where the secret was detected. */
    pull_request_body_url: string;
    /** The GitHub URL for the pull request where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents a 'pull_request_comment' secret scanning location type. This location type shows that a secret was detected in a comment on a pull request. */
export interface SecretScanningLocationPullRequestComment {
    /** The API URL to get the pull request comment where the secret was detected. */
    pull_request_comment_url: string;
    /** The GitHub URL for the pull request comment where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents a 'pull_request_review' secret scanning location type. This location type shows that a secret was detected in a review on a pull request. */
export interface SecretScanningLocationPullRequestReview {
    /** The API URL to get the pull request review where the secret was detected. */
    pull_request_review_url: string;
    /** The GitHub URL for the pull request review where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents a 'pull_request_review_comment' secret scanning location type. This location type shows that a secret was detected in a review comment on a pull request. */
export interface SecretScanningLocationPullRequestReviewComment {
    /** The API URL to get the pull request review comment where the secret was detected. */
    pull_request_review_comment_url: string;
    /** The GitHub URL for the pull request review comment where the secret was detected. */
    html_url?: string | undefined;
}
/** Represents an 'actions_log' secret scanning location type. The path identifies the workflow definition, while line and column positions identify the secret in the raw job log, not in the workflow file. */
export interface SecretScanningLocationActionsLog {
    /** The workflow definition path. Dynamically generated workflows can have a synthetic path. */
    path: string;
    /** Line number at which the secret starts in the raw job log. */
    start_line: number;
    /** Line number at which the secret ends in the raw job log. */
    end_line: number;
    /** The one-based column at which the secret starts within the start line of the raw job log. */
    start_column: number;
    /** The one-based column at which the secret ends within the end line of the raw job log. */
    end_column: number;
}
/** Details on the location where the token was initially detected. This can be a commit, wiki commit, issue, discussion, pull request, or Actions job log. */
export type NullableSecretScanningFirstDetectedLocation = SecretScanningLocationCommit | SecretScanningLocationWikiCommit | SecretScanningLocationIssueTitle | SecretScanningLocationIssueBody | SecretScanningLocationIssueComment | SecretScanningLocationDiscussionTitle | SecretScanningLocationDiscussionBody | SecretScanningLocationDiscussionComment | SecretScanningLocationPullRequestTitle | SecretScanningLocationPullRequestBody | SecretScanningLocationPullRequestComment | SecretScanningLocationPullRequestReview | SecretScanningLocationPullRequestReviewComment | SecretScanningLocationActionsLog;
export interface SecretScanningAlertMetadataItem {
    /** The metadata key. */
    key: string;
    /** The metadata value. */
    value: string;
}
/** A list of metadata key/value pairs associated with the secret scanning alert. */
export type SecretScanningAlertMetadata = Array<SecretScanningAlertMetadataItem>;
export interface SecretScanningAlertWithMetadata {
    number?: number | undefined;
    created_at?: string | undefined;
    updated_at?: string | null | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    /** The REST API URL of the code locations for this alert. */
    locations_url?: string | undefined;
    state?: SecretScanningAlertState | undefined;
    resolution?: SecretScanningAlertResolution | null | undefined;
    /** The time that the alert was resolved in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    resolved_at?: string | null | undefined;
    resolved_by?: NullableSimpleUser | null | undefined;
    /** An optional comment to resolve an alert. */
    resolution_comment?: string | null | undefined;
    /** The type of secret that secret scanning detected. */
    secret_type?: string | undefined;
    /** User-friendly name for the detected secret, matching the `secret_type`. For a list of built-in patterns, see "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)." */
    secret_type_display_name?: string | undefined;
    /** The provider of the secret that was detected. */
    provider?: string | null | undefined;
    /** The slug identifier for the provider of the secret that was detected. Use this value for filtering by provider with the `providers` or `exclude_providers` parameters. */
    provider_slug?: string | null | undefined;
    /** The secret that was detected. */
    secret?: string | Redacted.Redacted<string> | undefined;
    /** Whether push protection was bypassed for the detected secret. */
    push_protection_bypassed?: boolean | null | undefined;
    push_protection_bypassed_by?: NullableSimpleUser | null | undefined;
    /** The time that push protection was bypassed in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    push_protection_bypassed_at?: string | null | undefined;
    push_protection_bypass_request_reviewer?: NullableSimpleUser | null | undefined;
    /** An optional comment when reviewing a push protection bypass. */
    push_protection_bypass_request_reviewer_comment?: string | null | undefined;
    /** An optional comment when requesting a push protection bypass. */
    push_protection_bypass_request_comment?: string | null | undefined;
    /** The URL to a push protection bypass request. */
    push_protection_bypass_request_html_url?: string | null | undefined;
    /** The token status as of the latest validity check. */
    validity?: SecretScanningAlertWithMetadataValidity | undefined;
    /** Whether the detected secret was publicly leaked. */
    publicly_leaked?: boolean | null | undefined;
    /** Whether the detected secret was found in multiple repositories under the same organization or enterprise. */
    multi_repo?: boolean | null | undefined;
    /** A boolean value representing whether or not alert is base64 encoded */
    is_base64_encoded?: boolean | null | undefined;
    first_location_detected?: NullableSecretScanningFirstDetectedLocation | null | undefined;
    /** A boolean value representing whether or not the token in the alert was detected in more than one location. */
    has_more_locations?: boolean | undefined;
    assigned_to?: NullableSimpleUser | null | undefined;
    /** An optional comment from the closure request author. */
    closure_request_comment?: string | null | undefined;
    /** An optional comment from the closure request reviewer. */
    closure_request_reviewer_comment?: string | null | undefined;
    closure_request_reviewer?: NullableSimpleUser | null | undefined;
    metadata?: SecretScanningAlertMetadata | undefined;
}
export interface GetScanHistoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Information on a single scan performed by secret scanning on the repository */
export interface SecretScanningScan {
    /** The type of scan */
    type?: string | undefined;
    /** The state of the scan. Either "completed", "running", "pending", "failed", or "unknown". "failed": this scan type has hit its retry limit and has been marked permanently failed. This usually resolves on its own at the next scheduled scan attempt. If "failed" persists, contact Support. "unknown": the scan is in an unrecognized or currently unhandled state. */
    status?: string | undefined;
    /** The time that the scan was completed. Empty if the scan is running */
    completed_at?: string | null | undefined;
    /** The time that the scan was started. Empty if the scan is pending */
    started_at?: string | null | undefined;
}
export type SecretScanningScanHistoryIncrementalScansList = Array<SecretScanningScan>;
export type SecretScanningScanHistoryPatternUpdateScansList = Array<SecretScanningScan>;
export type SecretScanningScanHistoryBackfillScansList = Array<SecretScanningScan>;
export interface SecretScanningScanHistoryCustomPatternBackfillScansItem {
    /** The type of scan */
    type?: string | undefined;
    /** The state of the scan. Either "completed", "running", "pending", "failed", or "unknown". "failed": this scan type has hit its retry limit and has been marked permanently failed. This usually resolves on its own at the next scheduled scan attempt. If "failed" persists, contact Support. "unknown": the scan is in an unrecognized or currently unhandled state. */
    status?: string | undefined;
    /** The time that the scan was completed. Empty if the scan is running */
    completed_at?: string | null | undefined;
    /** The time that the scan was started. Empty if the scan is pending */
    started_at?: string | null | undefined;
    /** Name of the custom pattern for custom pattern scans */
    pattern_name?: string | undefined;
    /** Level at which the custom pattern is defined, one of "repository", "organization", or "enterprise" */
    pattern_scope?: string | undefined;
}
export type SecretScanningScanHistoryCustomPatternBackfillScansList = Array<SecretScanningScanHistoryCustomPatternBackfillScansItem>;
export type SecretScanningScanHistoryGenericSecretsBackfillScansList = Array<SecretScanningScan>;
export interface SecretScanningScanHistory {
    incremental_scans?: SecretScanningScanHistoryIncrementalScansList | undefined;
    pattern_update_scans?: SecretScanningScanHistoryPatternUpdateScansList | undefined;
    backfill_scans?: SecretScanningScanHistoryBackfillScansList | undefined;
    custom_pattern_backfill_scans?: SecretScanningScanHistoryCustomPatternBackfillScansList | undefined;
    generic_secrets_backfill_scans?: SecretScanningScanHistoryGenericSecretsBackfillScansList | undefined;
}
export type ListAlertsForOrgRequestState = "open" | "resolved";
export type ListAlertsForOrgRequestSort = "created" | "updated";
export type ListAlertsForOrgRequestDirection = "asc" | "desc";
export interface ListAlertsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Set to `open` or `resolved` to only list secret scanning alerts in a specific state. */
    state?: ListAlertsForOrgRequestState | (string & {}) | undefined;
    /** A comma-separated list of secret types to return. All default secret patterns are returned. To return generic patterns, pass the token name(s) in the parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types. */
    secret_type?: string | undefined;
    /** A comma-separated list of secret types to exclude from the results. All default secret patterns are returned except those matching the specified types. Cannot be combined with the `secret_type` parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types. */
    exclude_secret_types?: string | undefined;
    /** A comma-separated list of provider slugs to exclude from the results. Provider slugs use lowercase with underscores (e.g., `github_secret_scanning`, `clojars`). You can find the provider slug in the `provider_slug` field of each alert. Cannot be combined with the `providers` parameter. */
    exclude_providers?: string | undefined;
    /** A comma-separated list of provider slugs to filter by. Provider slugs use lowercase with underscores (e.g., `github_secret_scanning`, `clojars`). You can find the provider slug in the `provider_slug` field of each alert. Cannot be combined with the `exclude_providers` parameter. */
    providers?: string | undefined;
    /** A comma-separated list of resolutions. Only secret scanning alerts with one of these resolutions are listed. Valid resolutions are `false_positive`, `wont_fix`, `revoked`, `pattern_edited`, `pattern_deleted` or `used_in_tests`. */
    resolution?: string | undefined;
    /** Filters alerts by assignee. Use `*` to get all assigned alerts, `none` to get all unassigned alerts, or a GitHub username to get alerts assigned to a specific user. */
    assignee?: string | undefined;
    /** The property to sort the results by. `created` means when the alert was created. `updated` means when the alert was updated or resolved. */
    sort?: ListAlertsForOrgRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForOrgRequestDirection | (string & {}) | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events before this cursor. To receive an initial cursor on your first request, include an empty "before" query string. */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events after this cursor. To receive an initial cursor on your first request, include an empty "after" query string. */
    after?: string | undefined;
    /** A comma-separated list of validities that, when present, will return alerts that match the validities in this list. Valid options are `active`, `inactive`, and `unknown`. */
    validity?: string | undefined;
    /** A boolean value representing whether or not to filter alerts by the publicly-leaked tag being present. */
    is_publicly_leaked?: boolean | undefined;
    /** A boolean value representing whether or not to filter alerts by the multi-repo tag being present. */
    is_multi_repo?: boolean | undefined;
    /** A boolean value representing whether or not to hide literal secrets in the results. */
    hide_secret?: boolean | undefined;
    /** A boolean value (`true` or `false`) indicating whether to filter alerts by their push protection bypass status. When set to `true`, only alerts that were created because a push protection rule was bypassed will be returned. When set to `false`, only alerts that were not caused by a push protection bypass will be returned. */
    is_bypassed?: boolean | undefined;
    /** A comma-separated list of metadata fields to filter alerts by. Only alerts that have all of the specified metadata fields attached will be returned. Possible values are: `owner-email`, `owner-id`, `owner-name`, `secret-id`, `secret-name`, `secret-issued-date`, `secret-expiration-date`, `organization-name`, `organization-id`, `last-used-date`, and `has-organization-access`. */
    included_metadata?: string | undefined;
    /** Filters alerts to only those whose attached `owner_email` metadata field matches the provided value. The value must be the lowercase hex-encoded SHA-256 hash of the email address to match (for example, the SHA-256 of `user@example.com`). Only alerts that have an `owner_email` metadata value whose SHA-256 hash equals this parameter are returned. */
    owner_email_hash?: string | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
/** A GitHub repository. */
export interface SimpleRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The GraphQL identifier of the repository. */
    node_id: string;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    owner: NullableSimpleUser;
    /** Whether the repository is private. */
    private: boolean;
    /** The URL to view the repository on GitHub.com. */
    html_url: string;
    /** The repository description. */
    description: string | null;
    /** Whether the repository is a fork. */
    fork: boolean;
    /** The URL to get more information about the repository from the GitHub API. */
    url: string;
    /** A template for the API URL to download the repository as an archive. */
    archive_url: string;
    /** A template for the API URL to list the available assignees for issues in the repository. */
    assignees_url: string;
    /** A template for the API URL to create or retrieve a raw Git blob in the repository. */
    blobs_url: string;
    /** A template for the API URL to get information about branches in the repository. */
    branches_url: string;
    /** A template for the API URL to get information about collaborators of the repository. */
    collaborators_url: string;
    /** A template for the API URL to get information about comments on the repository. */
    comments_url: string;
    /** A template for the API URL to get information about commits on the repository. */
    commits_url: string;
    /** A template for the API URL to compare two commits or refs. */
    compare_url: string;
    /** A template for the API URL to get the contents of the repository. */
    contents_url: string;
    /** A template for the API URL to list the contributors to the repository. */
    contributors_url: string;
    /** The API URL to list the deployments of the repository. */
    deployments_url: string;
    /** The API URL to list the downloads on the repository. */
    downloads_url: string;
    /** The API URL to list the events of the repository. */
    events_url: string;
    /** The API URL to list the forks of the repository. */
    forks_url: string;
    /** A template for the API URL to get information about Git commits of the repository. */
    git_commits_url: string;
    /** A template for the API URL to get information about Git refs of the repository. */
    git_refs_url: string;
    /** A template for the API URL to get information about Git tags of the repository. */
    git_tags_url: string;
    /** A template for the API URL to get information about issue comments on the repository. */
    issue_comment_url: string;
    /** A template for the API URL to get information about issue events on the repository. */
    issue_events_url: string;
    /** A template for the API URL to get information about issues on the repository. */
    issues_url: string;
    /** A template for the API URL to get information about deploy keys on the repository. */
    keys_url: string;
    /** A template for the API URL to get information about labels of the repository. */
    labels_url: string;
    /** The API URL to get information about the languages of the repository. */
    languages_url: string;
    /** The API URL to merge branches in the repository. */
    merges_url: string;
    /** A template for the API URL to get information about milestones of the repository. */
    milestones_url: string;
    /** A template for the API URL to get information about notifications on the repository. */
    notifications_url: string;
    /** A template for the API URL to get information about pull requests on the repository. */
    pulls_url: string;
    /** A template for the API URL to get information about releases on the repository. */
    releases_url: string;
    /** The API URL to list the stargazers on the repository. */
    stargazers_url: string;
    /** A template for the API URL to get information about statuses of a commit. */
    statuses_url: string;
    /** The API URL to list the subscribers on the repository. */
    subscribers_url: string;
    /** The API URL to subscribe to notifications for this repository. */
    subscription_url: string;
    /** The API URL to get information about tags on the repository. */
    tags_url: string;
    /** The API URL to list the teams on the repository. */
    teams_url: string;
    /** A template for the API URL to create or retrieve a raw Git tree of the repository. */
    trees_url: string;
    /** The API URL to list the hooks on the repository. */
    hooks_url: string;
}
/** The token status as of the latest validity check. */
export type OrganizationSecretScanningAlertValidity = "active" | "inactive" | "unknown";
export interface OrganizationSecretScanningAlert {
    number?: number | undefined;
    created_at?: string | undefined;
    updated_at?: string | null | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    /** The REST API URL of the code locations for this alert. */
    locations_url?: string | undefined;
    state?: SecretScanningAlertState | undefined;
    resolution?: SecretScanningAlertResolution | null | undefined;
    /** The time that the alert was resolved in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    resolved_at?: string | null | undefined;
    resolved_by?: NullableSimpleUser | null | undefined;
    /** The type of secret that secret scanning detected. */
    secret_type?: string | undefined;
    /** User-friendly name for the detected secret, matching the `secret_type`. For a list of built-in patterns, see "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)." */
    secret_type_display_name?: string | undefined;
    /** The provider of the secret that was detected. */
    provider?: string | null | undefined;
    /** The slug identifier for the provider of the secret that was detected. Use this value for filtering by provider with the `providers` or `exclude_providers` parameters. */
    provider_slug?: string | null | undefined;
    /** The secret that was detected. */
    secret?: string | Redacted.Redacted<string> | undefined;
    repository?: SimpleRepository | undefined;
    /** Whether push protection was bypassed for the detected secret. */
    push_protection_bypassed?: boolean | null | undefined;
    push_protection_bypassed_by?: NullableSimpleUser | null | undefined;
    /** The time that push protection was bypassed in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    push_protection_bypassed_at?: string | null | undefined;
    push_protection_bypass_request_reviewer?: NullableSimpleUser | null | undefined;
    /** An optional comment when reviewing a push protection bypass. */
    push_protection_bypass_request_reviewer_comment?: string | null | undefined;
    /** An optional comment when requesting a push protection bypass. */
    push_protection_bypass_request_comment?: string | null | undefined;
    /** The URL to a push protection bypass request. */
    push_protection_bypass_request_html_url?: string | null | undefined;
    /** The comment that was optionally added when this alert was closed */
    resolution_comment?: string | null | undefined;
    /** The token status as of the latest validity check. */
    validity?: OrganizationSecretScanningAlertValidity | undefined;
    /** Whether the secret was publicly leaked. */
    publicly_leaked?: boolean | null | undefined;
    /** Whether the detected secret was found in multiple repositories in the same organization or enterprise. */
    multi_repo?: boolean | null | undefined;
    /** A boolean value representing whether or not alert is base64 encoded */
    is_base64_encoded?: boolean | null | undefined;
    first_location_detected?: NullableSecretScanningFirstDetectedLocation | null | undefined;
    /** A boolean value representing whether or not the token in the alert was detected in more than one location. */
    has_more_locations?: boolean | undefined;
    assigned_to?: NullableSimpleUser | null | undefined;
    /** An optional comment from the closure request author. */
    closure_request_comment?: string | null | undefined;
    /** An optional comment from the closure request reviewer. */
    closure_request_reviewer_comment?: string | null | undefined;
    closure_request_reviewer?: NullableSimpleUser | null | undefined;
}
export type ListAlertsForOrgResponseBodyList = Array<OrganizationSecretScanningAlert>;
export type ListAlertsForOrgResponse = ListAlertsForOrgResponseBodyList;
export type ListAlertsForRepoRequestState = "open" | "resolved";
export type ListAlertsForRepoRequestSort = "created" | "updated";
export type ListAlertsForRepoRequestDirection = "asc" | "desc";
export interface ListAlertsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Set to `open` or `resolved` to only list secret scanning alerts in a specific state. */
    state?: ListAlertsForRepoRequestState | (string & {}) | undefined;
    /** A comma-separated list of secret types to return. All default secret patterns are returned. To return generic patterns, pass the token name(s) in the parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types. */
    secret_type?: string | undefined;
    /** A comma-separated list of secret types to exclude from the results. All default secret patterns are returned except those matching the specified types. Cannot be combined with the `secret_type` parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types. */
    exclude_secret_types?: string | undefined;
    /** A comma-separated list of provider slugs to exclude from the results. Provider slugs use lowercase with underscores (e.g., `github_secret_scanning`, `clojars`). You can find the provider slug in the `provider_slug` field of each alert. Cannot be combined with the `providers` parameter. */
    exclude_providers?: string | undefined;
    /** A comma-separated list of provider slugs to filter by. Provider slugs use lowercase with underscores (e.g., `github_secret_scanning`, `clojars`). You can find the provider slug in the `provider_slug` field of each alert. Cannot be combined with the `exclude_providers` parameter. */
    providers?: string | undefined;
    /** A comma-separated list of resolutions. Only secret scanning alerts with one of these resolutions are listed. Valid resolutions are `false_positive`, `wont_fix`, `revoked`, `pattern_edited`, `pattern_deleted` or `used_in_tests`. */
    resolution?: string | undefined;
    /** Filters alerts by assignee. Use `*` to get all assigned alerts, `none` to get all unassigned alerts, or a GitHub username to get alerts assigned to a specific user. */
    assignee?: string | undefined;
    /** The property to sort the results by. `created` means when the alert was created. `updated` means when the alert was updated or resolved. */
    sort?: ListAlertsForRepoRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForRepoRequestDirection | (string & {}) | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events before this cursor. To receive an initial cursor on your first request, include an empty "before" query string. */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events after this cursor. To receive an initial cursor on your first request, include an empty "after" query string. */
    after?: string | undefined;
    /** A comma-separated list of validities that, when present, will return alerts that match the validities in this list. Valid options are `active`, `inactive`, and `unknown`. */
    validity?: string | undefined;
    /** A boolean value representing whether or not to filter alerts by the publicly-leaked tag being present. */
    is_publicly_leaked?: boolean | undefined;
    /** A boolean value representing whether or not to filter alerts by the multi-repo tag being present. */
    is_multi_repo?: boolean | undefined;
    /** A boolean value representing whether or not to hide literal secrets in the results. */
    hide_secret?: boolean | undefined;
    /** A boolean value (`true` or `false`) indicating whether to filter alerts by their push protection bypass status. When set to `true`, only alerts that were created because a push protection rule was bypassed will be returned. When set to `false`, only alerts that were not caused by a push protection bypass will be returned. */
    is_bypassed?: boolean | undefined;
    /** A comma-separated list of metadata fields to filter alerts by. Only alerts that have all of the specified metadata fields attached will be returned. Possible values are: `owner-email`, `owner-id`, `owner-name`, `secret-id`, `secret-name`, `secret-issued-date`, `secret-expiration-date`, `organization-name`, `organization-id`, `last-used-date`, and `has-organization-access`. */
    included_metadata?: string | undefined;
    /** Filters alerts to only those whose attached `owner_email` metadata field matches the provided value. The value must be the lowercase hex-encoded SHA-256 hash of the email address to match (for example, the SHA-256 of `user@example.com`). Only alerts that have an `owner_email` metadata value whose SHA-256 hash equals this parameter are returned. */
    owner_email_hash?: string | undefined;
}
/** The token status as of the latest validity check. */
export type SecretScanningAlertValidity = "active" | "inactive" | "unknown";
export interface SecretScanningAlert {
    number?: number | undefined;
    created_at?: string | undefined;
    updated_at?: string | null | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    /** The REST API URL of the code locations for this alert. */
    locations_url?: string | undefined;
    state?: SecretScanningAlertState | undefined;
    resolution?: SecretScanningAlertResolution | null | undefined;
    /** The time that the alert was resolved in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    resolved_at?: string | null | undefined;
    resolved_by?: NullableSimpleUser | null | undefined;
    /** An optional comment to resolve an alert. */
    resolution_comment?: string | null | undefined;
    /** The type of secret that secret scanning detected. */
    secret_type?: string | undefined;
    /** User-friendly name for the detected secret, matching the `secret_type`. For a list of built-in patterns, see "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)." */
    secret_type_display_name?: string | undefined;
    /** The provider of the secret that was detected. */
    provider?: string | null | undefined;
    /** The slug identifier for the provider of the secret that was detected. Use this value for filtering by provider with the `providers` or `exclude_providers` parameters. */
    provider_slug?: string | null | undefined;
    /** The secret that was detected. */
    secret?: string | Redacted.Redacted<string> | undefined;
    /** Whether push protection was bypassed for the detected secret. */
    push_protection_bypassed?: boolean | null | undefined;
    push_protection_bypassed_by?: NullableSimpleUser | null | undefined;
    /** The time that push protection was bypassed in ISO 8601 format: `YYYY-MM-DDTHH:MM:SSZ`. */
    push_protection_bypassed_at?: string | null | undefined;
    push_protection_bypass_request_reviewer?: NullableSimpleUser | null | undefined;
    /** An optional comment when reviewing a push protection bypass. */
    push_protection_bypass_request_reviewer_comment?: string | null | undefined;
    /** An optional comment when requesting a push protection bypass. */
    push_protection_bypass_request_comment?: string | null | undefined;
    /** The URL to a push protection bypass request. */
    push_protection_bypass_request_html_url?: string | null | undefined;
    /** The token status as of the latest validity check. */
    validity?: SecretScanningAlertValidity | undefined;
    /** Whether the detected secret was publicly leaked. */
    publicly_leaked?: boolean | null | undefined;
    /** Whether the detected secret was found in multiple repositories under the same organization or enterprise. */
    multi_repo?: boolean | null | undefined;
    /** A boolean value representing whether or not alert is base64 encoded */
    is_base64_encoded?: boolean | null | undefined;
    first_location_detected?: NullableSecretScanningFirstDetectedLocation | null | undefined;
    /** A boolean value representing whether or not the token in the alert was detected in more than one location. */
    has_more_locations?: boolean | undefined;
    assigned_to?: NullableSimpleUser | null | undefined;
    /** An optional comment from the closure request author. */
    closure_request_comment?: string | null | undefined;
    /** An optional comment from the closure request reviewer. */
    closure_request_reviewer_comment?: string | null | undefined;
    closure_request_reviewer?: NullableSimpleUser | null | undefined;
}
export type ListAlertsForRepoResponseBodyList = Array<SecretScanningAlert>;
export type ListAlertsForRepoResponse = ListAlertsForRepoResponseBodyList;
export interface ListLocationsForAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
/** The location type. Because secrets may be found in different types of resources (ie. code, comments, issues, pull requests, discussions), this field identifies the type of resource where the secret was found. */
export type SecretScanningLocationType = "commit" | "wiki_commit" | "issue_title" | "issue_body" | "issue_comment" | "discussion_title" | "discussion_body" | "discussion_comment" | "pull_request_title" | "pull_request_body" | "pull_request_comment" | "pull_request_review" | "pull_request_review_comment" | "actions_log";
export type SecretScanningLocationDetails = SecretScanningLocationCommit | SecretScanningLocationWikiCommit | SecretScanningLocationIssueTitle | SecretScanningLocationIssueBody | SecretScanningLocationIssueComment | SecretScanningLocationDiscussionTitle | SecretScanningLocationDiscussionBody | SecretScanningLocationDiscussionComment | SecretScanningLocationPullRequestTitle | SecretScanningLocationPullRequestBody | SecretScanningLocationPullRequestComment | SecretScanningLocationPullRequestReview | SecretScanningLocationPullRequestReviewComment | SecretScanningLocationActionsLog;
export interface SecretScanningLocation {
    /** The location type. Because secrets may be found in different types of resources (ie. code, comments, issues, pull requests, discussions), this field identifies the type of resource where the secret was found. */
    type?: SecretScanningLocationType | undefined;
    details?: SecretScanningLocationDetails | undefined;
}
/** List of locations where the secret was detected */
export type ListLocationsForAlertResponseBodyList = Array<SecretScanningLocation>;
export type ListLocationsForAlertResponse = ListLocationsForAlertResponseBodyList;
export type ListOrgCustomPatternsRequestState = "published" | "unpublished";
export type ListOrgCustomPatternsRequestPushProtection = "enabled" | "disabled";
export type ListOrgCustomPatternsRequestSort = "created" | "updated" | "name";
export type ListOrgCustomPatternsRequestDirection = "asc" | "desc";
export interface ListOrgCustomPatternsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Filter custom patterns by state. When absent, returns patterns in all states. */
    state?: ListOrgCustomPatternsRequestState | (string & {}) | undefined;
    /** Filter custom patterns by whether push protection is enabled. When absent, returns patterns regardless of push protection status. */
    push_protection?: ListOrgCustomPatternsRequestPushProtection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListOrgCustomPatternsRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListOrgCustomPatternsRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type ListOrgCustomPatternsResponseBodyList = Array<SecretScanningCustomPattern>;
export type ListOrgCustomPatternsResponse = ListOrgCustomPatternsResponseBodyList;
export interface ListOrgPatternConfigsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The default push protection setting for this pattern. */
export type SecretScanningPatternOverrideDefaultSetting = "disabled" | "enabled";
/** The push protection setting for this pattern set at the enterprise level. Only present for partner patterns when the organization has a parent enterprise. */
export type SecretScanningPatternOverrideEnterpriseSetting = "not-set" | "disabled" | "enabled";
/** The current push protection setting for this pattern. If this is `not-set`, then it inherits either the enterprise setting if it exists or the default setting. */
export type SecretScanningPatternOverrideSetting = "not-set" | "disabled" | "enabled";
export interface SecretScanningPatternOverride {
    /** The ID of the pattern. */
    token_type?: string | undefined;
    /** The version of this pattern if it's a custom pattern. */
    custom_pattern_version?: string | null | undefined;
    /** The slug of the pattern. */
    slug?: string | undefined;
    /** The user-friendly name for the pattern. */
    display_name?: string | undefined;
    /** The total number of alerts generated by this pattern. */
    alert_total?: number | undefined;
    /** The percentage of all alerts that this pattern represents, rounded to the nearest integer. */
    alert_total_percentage?: number | undefined;
    /** The number of false positive alerts generated by this pattern. */
    false_positives?: number | undefined;
    /** The percentage of alerts from this pattern that are false positives, rounded to the nearest integer. */
    false_positive_rate?: number | undefined;
    /** The percentage of blocks for this pattern that were bypassed, rounded to the nearest integer. */
    bypass_rate?: number | undefined;
    /** The default push protection setting for this pattern. */
    default_setting?: SecretScanningPatternOverrideDefaultSetting | undefined;
    /** The push protection setting for this pattern set at the enterprise level. Only present for partner patterns when the organization has a parent enterprise. */
    enterprise_setting?: SecretScanningPatternOverrideEnterpriseSetting | null | undefined;
    /** The current push protection setting for this pattern. If this is `not-set`, then it inherits either the enterprise setting if it exists or the default setting. */
    setting?: SecretScanningPatternOverrideSetting | undefined;
}
/** Overrides for partner patterns. */
export type SecretScanningPatternConfigurationProviderPatternOverridesList = Array<SecretScanningPatternOverride>;
/** Overrides for custom patterns defined by the organization. */
export type SecretScanningPatternConfigurationCustomPatternOverridesList = Array<SecretScanningPatternOverride>;
/** A collection of secret scanning patterns and their settings related to push protection. */
export interface SecretScanningPatternConfiguration {
    pattern_config_version?: string | null | undefined;
    /** Overrides for partner patterns. */
    provider_pattern_overrides?: SecretScanningPatternConfigurationProviderPatternOverridesList | undefined;
    /** Overrides for custom patterns defined by the organization. */
    custom_pattern_overrides?: SecretScanningPatternConfigurationCustomPatternOverridesList | undefined;
}
export type ListRepoCustomPatternsRequestState = "published" | "unpublished";
export type ListRepoCustomPatternsRequestPushProtection = "enabled" | "disabled";
export type ListRepoCustomPatternsRequestSort = "created" | "updated" | "name";
export type ListRepoCustomPatternsRequestDirection = "asc" | "desc";
export interface ListRepoCustomPatternsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Filter custom patterns by state. When absent, returns patterns in all states. */
    state?: ListRepoCustomPatternsRequestState | (string & {}) | undefined;
    /** Filter custom patterns by whether push protection is enabled. When absent, returns patterns regardless of push protection status. */
    push_protection?: ListRepoCustomPatternsRequestPushProtection | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListRepoCustomPatternsRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListRepoCustomPatternsRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type ListRepoCustomPatternsResponseBodyList = Array<SecretScanningCustomPattern>;
export type ListRepoCustomPatternsResponse = ListRepoCustomPatternsResponseBodyList;
/** Sets the validity of the secret scanning alert. Can be `active`, `inactive`, or `null` to clear the override. */
export type UpdateAlertRequestValidity = "active" | "inactive";
export interface UpdateAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
    state?: SecretScanningAlertState | (string & {}) | undefined;
    resolution?: SecretScanningAlertResolution | (string & {}) | null | undefined;
    resolution_comment?: string | null | undefined;
    assignee?: string | null | undefined;
    /** Sets the validity of the secret scanning alert. Can be `active`, `inactive`, or `null` to clear the override. */
    validity?: UpdateAlertRequestValidity | (string & {}) | null | undefined;
}
/** Updated list of regexes that the secret must match. */
export type UpdateOrgCustomPatternRequestMustMatchList = Array<string>;
/** Updated list of regexes that the secret must not match. */
export type UpdateOrgCustomPatternRequestMustNotMatchList = Array<string>;
export interface UpdateOrgCustomPatternRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the custom pattern. */
    pattern_id: number;
    /** The updated regular expression of the custom pattern. */
    pattern?: string | undefined;
    /** The updated start delimiter regex for the custom pattern. */
    start_delimiter?: string | undefined;
    /** The updated end delimiter regex for the custom pattern. */
    end_delimiter?: string | undefined;
    /** Updated list of regexes that the secret must match. */
    must_match?: UpdateOrgCustomPatternRequestMustMatchList | undefined;
    /** Updated list of regexes that the secret must not match. */
    must_not_match?: UpdateOrgCustomPatternRequestMustNotMatchList | undefined;
    custom_pattern_version: string | null;
}
/** Push protection setting to set for the pattern. */
export type UpdateOrgPatternConfigsRequestProviderPatternSettingsItemPushProtectionSetting = "not-set" | "disabled" | "enabled";
export interface UpdateOrgPatternConfigsRequestProviderPatternSettingsItem {
    /** The ID of the pattern to configure. */
    token_type?: string | undefined;
    /** Push protection setting to set for the pattern. */
    push_protection_setting?: UpdateOrgPatternConfigsRequestProviderPatternSettingsItemPushProtectionSetting | (string & {}) | undefined;
}
/** Pattern settings for provider patterns. */
export type UpdateOrgPatternConfigsRequestProviderPatternSettingsList = Array<UpdateOrgPatternConfigsRequestProviderPatternSettingsItem>;
/** Push protection setting to set for the pattern. */
export type UpdateOrgPatternConfigsRequestCustomPatternSettingsItemPushProtectionSetting = "disabled" | "enabled";
export interface UpdateOrgPatternConfigsRequestCustomPatternSettingsItem {
    /** The ID of the pattern to configure. */
    token_type?: string | undefined;
    custom_pattern_version?: string | null | undefined;
    /** Push protection setting to set for the pattern. */
    push_protection_setting?: UpdateOrgPatternConfigsRequestCustomPatternSettingsItemPushProtectionSetting | (string & {}) | undefined;
}
/** Pattern settings for custom patterns. */
export type UpdateOrgPatternConfigsRequestCustomPatternSettingsList = Array<UpdateOrgPatternConfigsRequestCustomPatternSettingsItem>;
export interface UpdateOrgPatternConfigsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    pattern_config_version?: string | null | undefined;
    /** Pattern settings for provider patterns. */
    provider_pattern_settings?: UpdateOrgPatternConfigsRequestProviderPatternSettingsList | undefined;
    /** Pattern settings for custom patterns. */
    custom_pattern_settings?: UpdateOrgPatternConfigsRequestCustomPatternSettingsList | undefined;
}
export interface UpdateOrgPatternConfigsResponse {
    /** The updated pattern configuration version. */
    pattern_config_version?: string | undefined;
}
/** Updated list of regexes that the secret must match. */
export type UpdateRepoCustomPatternRequestMustMatchList = Array<string>;
/** Updated list of regexes that the secret must not match. */
export type UpdateRepoCustomPatternRequestMustNotMatchList = Array<string>;
export interface UpdateRepoCustomPatternRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the custom pattern. */
    pattern_id: number;
    /** The updated regular expression of the custom pattern. */
    pattern?: string | undefined;
    /** The updated start delimiter regex for the custom pattern. */
    start_delimiter?: string | undefined;
    /** The updated end delimiter regex for the custom pattern. */
    end_delimiter?: string | undefined;
    /** Updated list of regexes that the secret must match. */
    must_match?: UpdateRepoCustomPatternRequestMustMatchList | undefined;
    /** Updated list of regexes that the secret must not match. */
    must_not_match?: UpdateRepoCustomPatternRequestMustNotMatchList | undefined;
    custom_pattern_version: string | null;
}
export type BulkCreateOrgCustomPatternsError = GithubOpError;
/** Bulk create organization custom patterns Bulk creates secret scanning custom patterns for an organization. Personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const bulkCreateOrgCustomPatterns: API.OperationMethod<BulkCreateOrgCustomPatternsRequest, BulkCreateOrgCustomPatternsResponse, BulkCreateOrgCustomPatternsError, GithubOpContext>;
export type BulkCreateRepoCustomPatternsError = GithubOpError;
/** Bulk create repository custom patterns Bulk creates secret scanning custom patterns for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. Fine-grained access tokens require the `administration:write` repository permission. */
export declare const bulkCreateRepoCustomPatterns: API.OperationMethod<BulkCreateRepoCustomPatternsRequest, BulkCreateRepoCustomPatternsResponse, BulkCreateRepoCustomPatternsError, GithubOpContext>;
export type BulkDeleteOrgCustomPatternsError = GithubOpError;
/** Bulk delete organization custom patterns Bulk deletes secret scanning custom patterns for an organization. Personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const bulkDeleteOrgCustomPatterns: API.OperationMethod<BulkDeleteOrgCustomPatternsRequest, BulkDeleteOrgCustomPatternsResponse, BulkDeleteOrgCustomPatternsError, GithubOpContext>;
export type BulkDeleteRepoCustomPatternsError = GithubOpError;
/** Bulk delete repository custom patterns Bulk deletes secret scanning custom patterns for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. Fine-grained access tokens require the `administration:write` repository permission. */
export declare const bulkDeleteRepoCustomPatterns: API.OperationMethod<BulkDeleteRepoCustomPatternsRequest, BulkDeleteRepoCustomPatternsResponse, BulkDeleteRepoCustomPatternsError, GithubOpContext>;
export type CreatePushProtectionBypassError = GithubOpError;
/** Create a push protection bypass Creates a bypass for a previously push protected secret. The authenticated user must be the original author of the committed secret. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createPushProtectionBypass: API.OperationMethod<CreatePushProtectionBypassRequest, SecretScanningPushProtectionBypass, CreatePushProtectionBypassError, GithubOpContext>;
export type GetAlertError = GithubOpError;
/** Get a secret scanning alert Gets a single secret scanning alert detected in an eligible repository. The authenticated user must be an administrator for the repository or for the organization that owns the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const getAlert: API.OperationMethod<GetAlertRequest, SecretScanningAlertWithMetadata, GetAlertError, GithubOpContext>;
export type GetScanHistoryError = GithubOpError;
/** Get secret scanning scan history for a repository Lists the latest default incremental and backfill scans by type for a repository. > [!NOTE] > This endpoint requires [GitHub Advanced Security](https://docs.github.com/get-started/learning-about-github/about-github-advanced-security). OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const getScanHistory: API.OperationMethod<GetScanHistoryRequest, SecretScanningScanHistory, GetScanHistoryError, GithubOpContext>;
export type ListAlertsForOrgError = GithubOpError;
/** List secret scanning alerts for an organization Lists secret scanning alerts for eligible repositories in an organization, from newest to oldest. The authenticated user must be an administrator or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const listAlertsForOrg: API.PaginatedOperationMethod<ListAlertsForOrgRequest, ListAlertsForOrgResponse, ListAlertsForOrgError, GithubOpContext, OrganizationSecretScanningAlert>;
export type ListAlertsForRepoError = GithubOpError;
/** List secret scanning alerts for a repository Lists secret scanning alerts for an eligible repository, from newest to oldest. The authenticated user must be an administrator for the repository or for the organization that owns the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const listAlertsForRepo: API.PaginatedOperationMethod<ListAlertsForRepoRequest, ListAlertsForRepoResponse, ListAlertsForRepoError, GithubOpContext, SecretScanningAlert>;
export type ListLocationsForAlertError = GithubOpError;
/** List locations for a secret scanning alert Lists all locations for a given secret scanning alert for an eligible repository. The authenticated user must be an administrator for the repository or for the organization that owns the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. */
export declare const listLocationsForAlert: API.PaginatedOperationMethod<ListLocationsForAlertRequest, ListLocationsForAlertResponse, ListLocationsForAlertError, GithubOpContext, SecretScanningLocation>;
export type ListOrgCustomPatternsError = GithubOpError;
/** List organization custom patterns Lists secret scanning custom patterns for an organization. Personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const listOrgCustomPatterns: API.OperationMethod<ListOrgCustomPatternsRequest, ListOrgCustomPatternsResponse, ListOrgCustomPatternsError, GithubOpContext>;
export type ListOrgPatternConfigsError = GithubOpError;
/** List organization pattern configurations Lists the secret scanning pattern configurations for an organization. Personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const listOrgPatternConfigs: API.OperationMethod<ListOrgPatternConfigsRequest, SecretScanningPatternConfiguration, ListOrgPatternConfigsError, GithubOpContext>;
export type ListRepoCustomPatternsError = GithubOpError;
/** List repository custom patterns Lists secret scanning custom patterns for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. Fine-grained access tokens require the `administration:write` repository permission. */
export declare const listRepoCustomPatterns: API.OperationMethod<ListRepoCustomPatternsRequest, ListRepoCustomPatternsResponse, ListRepoCustomPatternsError, GithubOpContext>;
export type UpdateAlertError = GithubOpError;
/** Update a secret scanning alert Updates the status of a secret scanning alert in an eligible repository. You can also use this endpoint to assign or unassign an alert to a user who has write access to the repository. The authenticated user must be an administrator for the repository or for the organization that owns the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` or `security_events` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. > [!NOTE] > If [delegated alert dismissal](https://docs.github.com/code-security/how-tos/manage-security-alerts/manage-secret-scanning-alerts/enable-delegated-dismissal) is enabled, resolving or reopening an alert also requires write access to the "Secret scanning alert dismissal requests" permission. Granting the permission to the app alone is not sufficient if the token's permissions exclude it. */
export declare const updateAlert: API.OperationMethod<UpdateAlertRequest, SecretScanningAlertWithMetadata, UpdateAlertError, GithubOpContext>;
export type UpdateOrgCustomPatternError = GithubOpError;
/** Update an organization custom pattern Updates a secret scanning custom pattern for an organization. Personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const updateOrgCustomPattern: API.OperationMethod<UpdateOrgCustomPatternRequest, SecretScanningCustomPattern, UpdateOrgCustomPatternError, GithubOpContext>;
export type UpdateOrgPatternConfigsError = GithubOpError;
/** Update organization pattern configurations Updates the secret scanning pattern configurations for an organization. Personal access tokens (classic) need the `write:org` scope to use this endpoint. */
export declare const updateOrgPatternConfigs: API.OperationMethod<UpdateOrgPatternConfigsRequest, UpdateOrgPatternConfigsResponse, UpdateOrgPatternConfigsError, GithubOpContext>;
export type UpdateRepoCustomPatternError = GithubOpError;
/** Update a repository custom pattern Updates a secret scanning custom pattern for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. If this endpoint is only used with public repositories, the token can use the `public_repo` scope instead. Fine-grained access tokens require the `administration:write` repository permission. */
export declare const updateRepoCustomPattern: API.OperationMethod<UpdateRepoCustomPatternRequest, SecretScanningCustomPattern, UpdateRepoCustomPatternError, GithubOpContext>;
//# sourceMappingURL=secret_scanning.d.ts.map