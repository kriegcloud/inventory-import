import * as HttpClient from "effect/http/HttpClient";
import type * as Layer from "effect/Layer";
/** An `HttpClient` that sends each request as an HTTP/2 stream. */
export declare const client: HttpClient.HttpClient;
/**
 * An `HttpClient` that sends each request as an HTTP/2 stream over the Unix
 * domain socket at `path`, whatever the request's host. Requests share one
 * session per socket.
 *
 * ```ts
 * program.pipe(Effect.provide(NodeHttp2.unixLayer("/run/modal.sock")));
 * ```
 */
export declare const unixSocket: (path: string) => HttpClient.HttpClient;
/** Send gRPC calls over HTTP/2 in this scope. */
export declare const layer: Layer.Layer<never>;
/** Send gRPC calls over HTTP/2 on the Unix domain socket at `path` in this scope. */
export declare const unixLayer: (path: string) => Layer.Layer<never>;
//# sourceMappingURL=grpc-transport-node-http2.d.ts.map