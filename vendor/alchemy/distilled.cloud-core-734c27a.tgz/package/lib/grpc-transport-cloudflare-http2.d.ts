import * as HttpClient from "effect/http/HttpClient";
import type * as Layer from "effect/Layer";
/** An `HttpClient` that sends each request as an HTTP/2 stream on its own `cloudflare:sockets` socket. */
export declare const client: HttpClient.HttpClient;
/** Send gRPC calls over HTTP/2 on `cloudflare:sockets` in this scope. */
export declare const layer: Layer.Layer<never>;
//# sourceMappingURL=grpc-transport-cloudflare-http2.d.ts.map