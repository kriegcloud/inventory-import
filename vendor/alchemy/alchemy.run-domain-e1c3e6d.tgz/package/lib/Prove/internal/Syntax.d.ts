/** A node of a parsed source, as far as a form looks at it. */
interface Node {
    readonly type: string;
    readonly [key: string]: any;
}
/**
 * One way a piece of the language is written. The prover reads it, or stops
 * at it and says so: either way the tests hold a case for it.
 */
export interface Form {
    /** How a reader names it: the kind of node, and the way it is written. */
    readonly name: string;
    /** Whether the prover reads it. A form it does not read is reported. */
    readonly read: boolean;
    readonly is: (node: Node, parent: Node | undefined, key: string) => boolean;
}
/**
 * The language, one form at a time: every kind of node the prover's
 * interpreter and loader meet, in each way it is written. A form with
 * `read: false` is one the prover stops at.
 */
export declare const FORMS: ReadonlyArray<Form>;
/**
 * The forms a parsed source is written with, by name. A node that is none of
 * the forms above is `undeclared <its type>`: something the list has yet to
 * say whether the prover reads.
 */
export declare const formsOf: (program: unknown) => ReadonlySet<string>;
export {};
//# sourceMappingURL=Syntax.d.ts.map