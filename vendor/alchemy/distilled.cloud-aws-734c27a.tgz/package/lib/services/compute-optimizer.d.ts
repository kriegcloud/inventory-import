import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MissingAuthenticationToken_base: S.TaggedErrorClass<"MissingAuthenticationToken", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class MissingAuthenticationToken extends /*@__PURE__*/ MissingAuthenticationToken_base {
}
declare const OptInRequiredException_base: S.TaggedErrorClass<"OptInRequiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OptInRequiredException extends /*@__PURE__*/ OptInRequiredException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type ResourceType = "Ec2Instance" | "AutoScalingGroup" | "EbsVolume" | "LambdaFunction" | "NotApplicable" | "EcsService" | "License" | "RdsDBInstance" | "AuroraDBClusterStorage" | "Idle" | (string & {});
export type ScopeName = "Organization" | "AccountId" | "ResourceArn" | (string & {});
export type ScopeValue = string;
export interface Scope {
    name?: ScopeName | undefined;
    value?: string | undefined;
}
export type RecommendationPreferenceName = "EnhancedInfrastructureMetrics" | "InferredWorkloadTypes" | "ExternalMetricsPreference" | "LookBackPeriodPreference" | "PreferredResources" | "UtilizationPreferences" | (string & {});
export type RecommendationPreferenceNames = RecommendationPreferenceName[];
export interface DeleteRecommendationPreferencesRequest {
    resourceType: ResourceType;
    scope?: Scope | undefined;
    recommendationPreferenceNames: RecommendationPreferenceName[];
}
export interface DeleteRecommendationPreferencesResponse {
}
export type JobId = string;
export type JobIds = string[];
export type JobFilterName = "ResourceType" | "JobStatus" | (string & {});
export type FilterValue = string;
export type FilterValues = string[];
export interface JobFilter {
    name?: JobFilterName | undefined;
    values?: string[] | undefined;
}
export type JobFilters = JobFilter[];
export type NextToken = string;
export type MaxResults = number;
export interface DescribeRecommendationExportJobsRequest {
    jobIds?: string[] | undefined;
    filters?: JobFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type DestinationBucket = string;
export type DestinationKey = string;
export type MetadataKey = string;
export interface S3Destination {
    bucket?: string | undefined;
    key?: string | undefined;
    metadataKey?: string | undefined;
}
export interface ExportDestination {
    s3?: S3Destination | undefined;
}
export type JobStatus = "Queued" | "InProgress" | "Complete" | "Failed" | (string & {});
export type CreationTimestamp = Date;
export type LastUpdatedTimestamp = Date;
export type FailureReason = string;
export interface RecommendationExportJob {
    jobId?: string | undefined;
    destination?: ExportDestination | undefined;
    resourceType?: ResourceType | undefined;
    status?: JobStatus | undefined;
    creationTimestamp?: Date | undefined;
    lastUpdatedTimestamp?: Date | undefined;
    failureReason?: string | undefined;
}
export type RecommendationExportJobs = RecommendationExportJob[];
export interface DescribeRecommendationExportJobsResponse {
    recommendationExportJobs?: RecommendationExportJob[] | undefined;
    nextToken?: string | undefined;
}
export type AccountId = string;
export type AccountIds = string[];
export type FilterName = "Finding" | "FindingReasonCodes" | "RecommendationSourceType" | "InferredWorkloadTypes" | (string & {});
export interface Filter {
    name?: FilterName | undefined;
    values?: string[] | undefined;
}
export type Filters = Filter[];
export type ExportableAutoScalingGroupField = "AccountId" | "AutoScalingGroupArn" | "AutoScalingGroupName" | "Finding" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsEbsReadOpsPerSecondMaximum" | "UtilizationMetricsEbsWriteOpsPerSecondMaximum" | "UtilizationMetricsEbsReadBytesPerSecondMaximum" | "UtilizationMetricsEbsWriteBytesPerSecondMaximum" | "UtilizationMetricsDiskReadOpsPerSecondMaximum" | "UtilizationMetricsDiskWriteOpsPerSecondMaximum" | "UtilizationMetricsDiskReadBytesPerSecondMaximum" | "UtilizationMetricsDiskWriteBytesPerSecondMaximum" | "UtilizationMetricsNetworkInBytesPerSecondMaximum" | "UtilizationMetricsNetworkOutBytesPerSecondMaximum" | "UtilizationMetricsNetworkPacketsInPerSecondMaximum" | "UtilizationMetricsNetworkPacketsOutPerSecondMaximum" | "LookbackPeriodInDays" | "CurrentConfigurationInstanceType" | "CurrentConfigurationDesiredCapacity" | "CurrentConfigurationMinSize" | "CurrentConfigurationMaxSize" | "CurrentConfigurationAllocationStrategy" | "CurrentConfigurationMixedInstanceTypes" | "CurrentConfigurationType" | "CurrentOnDemandPrice" | "CurrentStandardOneYearNoUpfrontReservedPrice" | "CurrentStandardThreeYearNoUpfrontReservedPrice" | "CurrentVCpus" | "CurrentMemory" | "CurrentStorage" | "CurrentNetwork" | "RecommendationOptionsConfigurationInstanceType" | "RecommendationOptionsConfigurationDesiredCapacity" | "RecommendationOptionsConfigurationMinSize" | "RecommendationOptionsConfigurationMaxSize" | "RecommendationOptionsConfigurationEstimatedInstanceHourReductionPercentage" | "RecommendationOptionsConfigurationAllocationStrategy" | "RecommendationOptionsConfigurationMixedInstanceTypes" | "RecommendationOptionsConfigurationType" | "RecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "RecommendationOptionsProjectedUtilizationMetricsMemoryMaximum" | "RecommendationOptionsPerformanceRisk" | "RecommendationOptionsOnDemandPrice" | "RecommendationOptionsStandardOneYearNoUpfrontReservedPrice" | "RecommendationOptionsStandardThreeYearNoUpfrontReservedPrice" | "RecommendationOptionsVcpus" | "RecommendationOptionsMemory" | "RecommendationOptionsStorage" | "RecommendationOptionsNetwork" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "EffectiveRecommendationPreferencesCpuVendorArchitectures" | "EffectiveRecommendationPreferencesEnhancedInfrastructureMetrics" | "EffectiveRecommendationPreferencesInferredWorkloadTypes" | "EffectiveRecommendationPreferencesPreferredResources" | "EffectiveRecommendationPreferencesLookBackPeriod" | "InferredWorkloadTypes" | "RecommendationOptionsMigrationEffort" | "CurrentInstanceGpuInfo" | "RecommendationOptionsInstanceGpuInfo" | "UtilizationMetricsGpuPercentageMaximum" | "UtilizationMetricsGpuMemoryPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuMemoryPercentageMaximum" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | (string & {});
export type ExportableAutoScalingGroupFields = ExportableAutoScalingGroupField[];
export type DestinationKeyPrefix = string;
export interface S3DestinationConfig {
    bucket?: string | undefined;
    keyPrefix?: string | undefined;
}
export type FileFormat = "Csv" | (string & {});
export type IncludeMemberAccounts = boolean;
export type CpuVendorArchitecture = "AWS_ARM64" | "CURRENT" | (string & {});
export type CpuVendorArchitectures = CpuVendorArchitecture[];
export interface RecommendationPreferences {
    cpuVendorArchitectures?: CpuVendorArchitecture[] | undefined;
}
export interface ExportAutoScalingGroupRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: Filter[] | undefined;
    fieldsToExport?: ExportableAutoScalingGroupField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export interface ExportAutoScalingGroupRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type EBSFilterName = "Finding" | (string & {});
export interface EBSFilter {
    name?: EBSFilterName | undefined;
    values?: string[] | undefined;
}
export type EBSFilters = EBSFilter[];
export type ExportableVolumeField = "AccountId" | "VolumeArn" | "Finding" | "UtilizationMetricsVolumeReadOpsPerSecondMaximum" | "UtilizationMetricsVolumeWriteOpsPerSecondMaximum" | "UtilizationMetricsVolumeReadBytesPerSecondMaximum" | "UtilizationMetricsVolumeWriteBytesPerSecondMaximum" | "UtilizationMetricsVolumeIOPSExceededMaximum" | "UtilizationMetricsVolumeThroughputExceededMaximum" | "LookbackPeriodInDays" | "CurrentConfigurationVolumeType" | "CurrentConfigurationVolumeBaselineIOPS" | "CurrentConfigurationVolumeBaselineThroughput" | "CurrentConfigurationVolumeBurstIOPS" | "CurrentConfigurationVolumeBurstThroughput" | "CurrentConfigurationVolumeSize" | "CurrentMonthlyPrice" | "RecommendationOptionsConfigurationVolumeType" | "RecommendationOptionsConfigurationVolumeBaselineIOPS" | "RecommendationOptionsConfigurationVolumeBaselineThroughput" | "RecommendationOptionsConfigurationVolumeBurstIOPS" | "RecommendationOptionsConfigurationVolumeBurstThroughput" | "RecommendationOptionsConfigurationVolumeSize" | "RecommendationOptionsMonthlyPrice" | "RecommendationOptionsPerformanceRisk" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "Tags" | "RootVolume" | "CurrentConfigurationRootVolume" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "EffectiveRecommendationPreferencesLookBackPeriod" | (string & {});
export type ExportableVolumeFields = ExportableVolumeField[];
export interface ExportEBSVolumeRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: EBSFilter[] | undefined;
    fieldsToExport?: ExportableVolumeField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
}
export interface ExportEBSVolumeRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type ExportableInstanceField = "AccountId" | "InstanceArn" | "InstanceName" | "Finding" | "FindingReasonCodes" | "LookbackPeriodInDays" | "CurrentInstanceType" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsEbsReadOpsPerSecondMaximum" | "UtilizationMetricsEbsWriteOpsPerSecondMaximum" | "UtilizationMetricsEbsReadBytesPerSecondMaximum" | "UtilizationMetricsEbsWriteBytesPerSecondMaximum" | "UtilizationMetricsDiskReadOpsPerSecondMaximum" | "UtilizationMetricsDiskWriteOpsPerSecondMaximum" | "UtilizationMetricsDiskReadBytesPerSecondMaximum" | "UtilizationMetricsDiskWriteBytesPerSecondMaximum" | "UtilizationMetricsNetworkInBytesPerSecondMaximum" | "UtilizationMetricsNetworkOutBytesPerSecondMaximum" | "UtilizationMetricsNetworkPacketsInPerSecondMaximum" | "UtilizationMetricsNetworkPacketsOutPerSecondMaximum" | "CurrentOnDemandPrice" | "CurrentStandardOneYearNoUpfrontReservedPrice" | "CurrentStandardThreeYearNoUpfrontReservedPrice" | "CurrentVCpus" | "CurrentMemory" | "CurrentStorage" | "CurrentNetwork" | "RecommendationOptionsInstanceType" | "RecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "RecommendationOptionsProjectedUtilizationMetricsMemoryMaximum" | "RecommendationOptionsPlatformDifferences" | "RecommendationOptionsPerformanceRisk" | "RecommendationOptionsVcpus" | "RecommendationOptionsMemory" | "RecommendationOptionsStorage" | "RecommendationOptionsNetwork" | "RecommendationOptionsOnDemandPrice" | "RecommendationOptionsStandardOneYearNoUpfrontReservedPrice" | "RecommendationOptionsStandardThreeYearNoUpfrontReservedPrice" | "RecommendationsSourcesRecommendationSourceArn" | "RecommendationsSourcesRecommendationSourceType" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "EffectiveRecommendationPreferencesCpuVendorArchitectures" | "EffectiveRecommendationPreferencesEnhancedInfrastructureMetrics" | "EffectiveRecommendationPreferencesInferredWorkloadTypes" | "InferredWorkloadTypes" | "RecommendationOptionsMigrationEffort" | "EffectiveRecommendationPreferencesExternalMetricsSource" | "Tags" | "InstanceState" | "ExternalMetricStatusCode" | "ExternalMetricStatusReason" | "CurrentInstanceGpuInfo" | "RecommendationOptionsInstanceGpuInfo" | "UtilizationMetricsGpuPercentageMaximum" | "UtilizationMetricsGpuMemoryPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuPercentageMaximum" | "RecommendationOptionsProjectedUtilizationMetricsGpuMemoryPercentageMaximum" | "Idle" | "EffectiveRecommendationPreferencesPreferredResources" | "EffectiveRecommendationPreferencesLookBackPeriod" | "EffectiveRecommendationPreferencesUtilizationPreferences" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | (string & {});
export type ExportableInstanceFields = ExportableInstanceField[];
export interface ExportEC2InstanceRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: Filter[] | undefined;
    fieldsToExport?: ExportableInstanceField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export interface ExportEC2InstanceRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type ECSServiceRecommendationFilterName = "Finding" | "FindingReasonCode" | (string & {});
export interface ECSServiceRecommendationFilter {
    name?: ECSServiceRecommendationFilterName | undefined;
    values?: string[] | undefined;
}
export type ECSServiceRecommendationFilters = ECSServiceRecommendationFilter[];
export type ExportableECSServiceField = "AccountId" | "ServiceArn" | "LookbackPeriodInDays" | "LastRefreshTimestamp" | "LaunchType" | "CurrentPerformanceRisk" | "CurrentServiceConfigurationMemory" | "CurrentServiceConfigurationCpu" | "CurrentServiceConfigurationTaskDefinitionArn" | "CurrentServiceConfigurationAutoScalingConfiguration" | "CurrentServiceContainerConfigurations" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "Finding" | "FindingReasonCodes" | "RecommendationOptionsMemory" | "RecommendationOptionsCpu" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "RecommendationOptionsContainerRecommendations" | "RecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "RecommendationOptionsProjectedUtilizationMetricsMemoryMaximum" | "Tags" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "EffectiveRecommendationPreferencesLookBackPeriod" | (string & {});
export type ExportableECSServiceFields = ExportableECSServiceField[];
export interface ExportECSServiceRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: ECSServiceRecommendationFilter[] | undefined;
    fieldsToExport?: ExportableECSServiceField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
}
export interface ExportECSServiceRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type IdleRecommendationFilterName = "Finding" | "ResourceType" | (string & {});
export interface IdleRecommendationFilter {
    name?: IdleRecommendationFilterName | undefined;
    values?: string[] | undefined;
}
export type IdleRecommendationFilters = IdleRecommendationFilter[];
export type ExportableIdleField = "AccountId" | "ResourceArn" | "ResourceId" | "ResourceType" | "LastRefreshTimestamp" | "LookbackPeriodInDays" | "SavingsOpportunity" | "SavingsOpportunityAfterDiscount" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsNetworkOutBytesPerSecondMaximum" | "UtilizationMetricsNetworkInBytesPerSecondMaximum" | "UtilizationMetricsDatabaseConnectionsMaximum" | "UtilizationMetricsEBSVolumeReadIOPSMaximum" | "UtilizationMetricsEBSVolumeWriteIOPSMaximum" | "UtilizationMetricsVolumeReadOpsPerSecondMaximum" | "UtilizationMetricsVolumeWriteOpsPerSecondMaximum" | "UtilizationMetricsActiveConnectionCountMaximum" | "UtilizationMetricsPacketsInFromSourceMaximum" | "UtilizationMetricsPacketsInFromDestinationMaximum" | "UtilizationMetricsConsumedReadCapacityUnitsSum" | "UtilizationMetricsConsumedWriteCapacityUnitsSum" | "UtilizationMetricsNewConnectionsSum" | "UtilizationMetricsEngineCPUUtilizationMaximum" | "UtilizationMetricsCacheHitsSum" | "UtilizationMetricsCacheMissesSum" | "UtilizationMetricsKeyspaceHitsSum" | "UtilizationMetricsKeyspaceMissesSum" | "UtilizationMetricsIsIdleMinimum" | "UtilizationMetricsUserConnectedSum" | "UtilizationMetricsInvocationsSum" | "UtilizationMetricsGetTypeCmdsSum" | "UtilizationMetricsSetTypeCmdsSum" | "UtilizationMetricsElastiCacheProcessingUnitsSum" | "UtilizationMetricsCurrConnectionsSum" | "UtilizationMetricsDatabaseConnectionsSum" | "Finding" | "FindingDescription" | "Tags" | (string & {});
export type ExportableIdleFields = ExportableIdleField[];
export interface ExportIdleRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: IdleRecommendationFilter[] | undefined;
    fieldsToExport?: ExportableIdleField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
}
export interface ExportIdleRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type LambdaFunctionRecommendationFilterName = "Finding" | "FindingReasonCode" | (string & {});
export interface LambdaFunctionRecommendationFilter {
    name?: LambdaFunctionRecommendationFilterName | undefined;
    values?: string[] | undefined;
}
export type LambdaFunctionRecommendationFilters = LambdaFunctionRecommendationFilter[];
export type ExportableLambdaFunctionField = "AccountId" | "FunctionArn" | "FunctionVersion" | "Finding" | "FindingReasonCodes" | "NumberOfInvocations" | "UtilizationMetricsDurationMaximum" | "UtilizationMetricsDurationAverage" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsMemoryAverage" | "LookbackPeriodInDays" | "CurrentConfigurationMemorySize" | "CurrentConfigurationTimeout" | "CurrentCostTotal" | "CurrentCostAverage" | "RecommendationOptionsConfigurationMemorySize" | "RecommendationOptionsCostLow" | "RecommendationOptionsCostHigh" | "RecommendationOptionsProjectedUtilizationMetricsDurationLowerBound" | "RecommendationOptionsProjectedUtilizationMetricsDurationUpperBound" | "RecommendationOptionsProjectedUtilizationMetricsDurationExpected" | "LastRefreshTimestamp" | "CurrentPerformanceRisk" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "Tags" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "RecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "RecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | (string & {});
export type ExportableLambdaFunctionFields = ExportableLambdaFunctionField[];
export interface ExportLambdaFunctionRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: LambdaFunctionRecommendationFilter[] | undefined;
    fieldsToExport?: ExportableLambdaFunctionField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
}
export interface ExportLambdaFunctionRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type LicenseRecommendationFilterName = "Finding" | "FindingReasonCode" | "LicenseName" | (string & {});
export interface LicenseRecommendationFilter {
    name?: LicenseRecommendationFilterName | undefined;
    values?: string[] | undefined;
}
export type LicenseRecommendationFilters = LicenseRecommendationFilter[];
export type ExportableLicenseField = "AccountId" | "ResourceArn" | "LookbackPeriodInDays" | "LastRefreshTimestamp" | "Finding" | "FindingReasonCodes" | "CurrentLicenseConfigurationNumberOfCores" | "CurrentLicenseConfigurationInstanceType" | "CurrentLicenseConfigurationOperatingSystem" | "CurrentLicenseConfigurationLicenseName" | "CurrentLicenseConfigurationLicenseEdition" | "CurrentLicenseConfigurationLicenseModel" | "CurrentLicenseConfigurationLicenseVersion" | "CurrentLicenseConfigurationMetricsSource" | "RecommendationOptionsOperatingSystem" | "RecommendationOptionsLicenseEdition" | "RecommendationOptionsLicenseModel" | "RecommendationOptionsSavingsOpportunityPercentage" | "RecommendationOptionsEstimatedMonthlySavingsCurrency" | "RecommendationOptionsEstimatedMonthlySavingsValue" | "Tags" | (string & {});
export type ExportableLicenseFields = ExportableLicenseField[];
export interface ExportLicenseRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: LicenseRecommendationFilter[] | undefined;
    fieldsToExport?: ExportableLicenseField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
}
export interface ExportLicenseRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type RDSDBRecommendationFilterName = "InstanceFinding" | "InstanceFindingReasonCode" | "StorageFinding" | "StorageFindingReasonCode" | "Idle" | (string & {});
export interface RDSDBRecommendationFilter {
    name?: RDSDBRecommendationFilterName | undefined;
    values?: string[] | undefined;
}
export type RDSDBRecommendationFilters = RDSDBRecommendationFilter[];
export type ExportableRDSDBField = "ResourceArn" | "AccountId" | "Engine" | "EngineVersion" | "Idle" | "MultiAZDBInstance" | "ClusterWriter" | "CurrentDBInstanceClass" | "CurrentStorageConfigurationStorageType" | "CurrentStorageConfigurationAllocatedStorage" | "CurrentStorageConfigurationMaxAllocatedStorage" | "CurrentStorageConfigurationIOPS" | "CurrentStorageConfigurationStorageThroughput" | "CurrentStorageEstimatedMonthlyVolumeIOPsCostVariation" | "CurrentInstanceOnDemandHourlyPrice" | "CurrentStorageOnDemandMonthlyPrice" | "LookbackPeriodInDays" | "CurrentStorageEstimatedClusterInstanceOnDemandMonthlyCost" | "CurrentStorageEstimatedClusterStorageOnDemandMonthlyCost" | "CurrentStorageEstimatedClusterStorageIOOnDemandMonthlyCost" | "CurrentInstancePerformanceRisk" | "UtilizationMetricsCpuMaximum" | "UtilizationMetricsMemoryMaximum" | "UtilizationMetricsEBSVolumeStorageSpaceUtilizationMaximum" | "UtilizationMetricsNetworkReceiveThroughputMaximum" | "UtilizationMetricsNetworkTransmitThroughputMaximum" | "UtilizationMetricsEBSVolumeReadIOPSMaximum" | "UtilizationMetricsEBSVolumeWriteIOPSMaximum" | "UtilizationMetricsEBSVolumeReadThroughputMaximum" | "UtilizationMetricsEBSVolumeWriteThroughputMaximum" | "UtilizationMetricsDatabaseConnectionsMaximum" | "UtilizationMetricsStorageNetworkReceiveThroughputMaximum" | "UtilizationMetricsStorageNetworkTransmitThroughputMaximum" | "UtilizationMetricsAuroraMemoryHealthStateMaximum" | "UtilizationMetricsAuroraMemoryNumDeclinedSqlTotalMaximum" | "UtilizationMetricsAuroraMemoryNumKillConnTotalMaximum" | "UtilizationMetricsAuroraMemoryNumKillQueryTotalMaximum" | "UtilizationMetricsReadIOPSEphemeralStorageMaximum" | "UtilizationMetricsWriteIOPSEphemeralStorageMaximum" | "UtilizationMetricsVolumeBytesUsedAverage" | "UtilizationMetricsVolumeReadIOPsAverage" | "UtilizationMetricsVolumeWriteIOPsAverage" | "InstanceFinding" | "InstanceFindingReasonCodes" | "StorageFinding" | "StorageFindingReasonCodes" | "InstanceRecommendationOptionsDBInstanceClass" | "InstanceRecommendationOptionsRank" | "InstanceRecommendationOptionsPerformanceRisk" | "InstanceRecommendationOptionsProjectedUtilizationMetricsCpuMaximum" | "StorageRecommendationOptionsStorageType" | "StorageRecommendationOptionsAllocatedStorage" | "StorageRecommendationOptionsMaxAllocatedStorage" | "StorageRecommendationOptionsIOPS" | "StorageRecommendationOptionsStorageThroughput" | "StorageRecommendationOptionsRank" | "StorageRecommendationOptionsEstimatedMonthlyVolumeIOPsCostVariation" | "InstanceRecommendationOptionsInstanceOnDemandHourlyPrice" | "InstanceRecommendationOptionsSavingsOpportunityPercentage" | "InstanceRecommendationOptionsEstimatedMonthlySavingsCurrency" | "InstanceRecommendationOptionsEstimatedMonthlySavingsValue" | "InstanceRecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "InstanceRecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "InstanceRecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "StorageRecommendationOptionsOnDemandMonthlyPrice" | "StorageRecommendationOptionsEstimatedClusterInstanceOnDemandMonthlyCost" | "StorageRecommendationOptionsEstimatedClusterStorageOnDemandMonthlyCost" | "StorageRecommendationOptionsEstimatedClusterStorageIOOnDemandMonthlyCost" | "StorageRecommendationOptionsSavingsOpportunityPercentage" | "StorageRecommendationOptionsEstimatedMonthlySavingsCurrency" | "StorageRecommendationOptionsEstimatedMonthlySavingsValue" | "StorageRecommendationOptionsSavingsOpportunityAfterDiscountsPercentage" | "StorageRecommendationOptionsEstimatedMonthlySavingsCurrencyAfterDiscounts" | "StorageRecommendationOptionsEstimatedMonthlySavingsValueAfterDiscounts" | "EffectiveRecommendationPreferencesCpuVendorArchitectures" | "EffectiveRecommendationPreferencesEnhancedInfrastructureMetrics" | "EffectiveRecommendationPreferencesLookBackPeriod" | "EffectiveRecommendationPreferencesSavingsEstimationMode" | "LastRefreshTimestamp" | "Tags" | "DBClusterIdentifier" | "PromotionTier" | (string & {});
export type ExportableRDSDBFields = ExportableRDSDBField[];
export interface ExportRDSDatabaseRecommendationsRequest {
    accountIds?: string[] | undefined;
    filters?: RDSDBRecommendationFilter[] | undefined;
    fieldsToExport?: ExportableRDSDBField[] | undefined;
    s3DestinationConfig: S3DestinationConfig;
    fileFormat?: FileFormat | undefined;
    includeMemberAccounts?: boolean | undefined;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export interface ExportRDSDatabaseRecommendationsResponse {
    jobId?: string | undefined;
    s3Destination?: S3Destination | undefined;
}
export type AutoScalingGroupArn = string;
export type AutoScalingGroupArns = string[];
export interface GetAutoScalingGroupRecommendationsRequest {
    accountIds?: string[] | undefined;
    autoScalingGroupArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: Filter[] | undefined;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export type AutoScalingGroupName = string;
export type Finding = "Underprovisioned" | "Overprovisioned" | "Optimized" | "NotOptimized" | (string & {});
export type MetricName = "Cpu" | "Memory" | "EBS_READ_OPS_PER_SECOND" | "EBS_WRITE_OPS_PER_SECOND" | "EBS_READ_BYTES_PER_SECOND" | "EBS_WRITE_BYTES_PER_SECOND" | "DISK_READ_OPS_PER_SECOND" | "DISK_WRITE_OPS_PER_SECOND" | "DISK_READ_BYTES_PER_SECOND" | "DISK_WRITE_BYTES_PER_SECOND" | "NETWORK_IN_BYTES_PER_SECOND" | "NETWORK_OUT_BYTES_PER_SECOND" | "NETWORK_PACKETS_IN_PER_SECOND" | "NETWORK_PACKETS_OUT_PER_SECOND" | "GPU_PERCENTAGE" | "GPU_MEMORY_PERCENTAGE" | (string & {});
export type MetricStatistic = "Maximum" | "Average" | (string & {});
export type MetricValue = number;
export interface UtilizationMetric {
    name?: MetricName | undefined;
    statistic?: MetricStatistic | undefined;
    value?: number | undefined;
}
export type UtilizationMetrics = UtilizationMetric[];
export type LookBackPeriodInDays = number;
export type DesiredCapacity = number;
export type MinSize = number;
export type MaxSize = number;
export type NullableInstanceType = string;
export type AllocationStrategy = "Prioritized" | "LowestPrice" | (string & {});
export type NullableEstimatedInstanceHourReductionPercentage = number;
export type AsgType = "SingleInstanceType" | "MixedInstanceTypes" | (string & {});
export type MixedInstanceType = string;
export type MixedInstanceTypes = string[];
export interface AutoScalingGroupConfiguration {
    desiredCapacity?: number | undefined;
    minSize?: number | undefined;
    maxSize?: number | undefined;
    instanceType?: string | undefined;
    allocationStrategy?: AllocationStrategy | undefined;
    estimatedInstanceHourReductionPercentage?: number | undefined;
    type?: AsgType | undefined;
    mixedInstanceTypes?: string[] | undefined;
}
export type GpuCount = number;
export type GpuMemorySizeInMiB = number;
export interface Gpu {
    gpuCount?: number | undefined;
    gpuMemorySizeInMiB?: number | undefined;
}
export type Gpus = Gpu[];
export interface GpuInfo {
    gpus?: Gpu[] | undefined;
}
export type ProjectedUtilizationMetrics = UtilizationMetric[];
export type PerformanceRisk = number;
export type Rank = number;
export type SavingsOpportunityPercentage = number;
export type Currency = "USD" | "CNY" | (string & {});
export type Value = number;
export interface EstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface SavingsOpportunity {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
}
export interface AutoScalingGroupEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface AutoScalingGroupSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: AutoScalingGroupEstimatedMonthlySavings | undefined;
}
export type MigrationEffort = "VeryLow" | "Low" | "Medium" | "High" | (string & {});
export interface AutoScalingGroupRecommendationOption {
    configuration?: AutoScalingGroupConfiguration | undefined;
    instanceGpuInfo?: GpuInfo | undefined;
    projectedUtilizationMetrics?: UtilizationMetric[] | undefined;
    performanceRisk?: number | undefined;
    rank?: number | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: AutoScalingGroupSavingsOpportunityAfterDiscounts | undefined;
    migrationEffort?: MigrationEffort | undefined;
}
export type AutoScalingGroupRecommendationOptions = AutoScalingGroupRecommendationOption[];
export type LastRefreshTimestamp = Date;
export type CurrentPerformanceRisk = "VeryLow" | "Low" | "Medium" | "High" | (string & {});
export type EnhancedInfrastructureMetrics = "Active" | "Inactive" | (string & {});
export type InferredWorkloadTypesPreference = "Active" | "Inactive" | (string & {});
export type ExternalMetricsSource = "Datadog" | "Dynatrace" | "NewRelic" | "Instana" | (string & {});
export interface ExternalMetricsPreference {
    source?: ExternalMetricsSource | undefined;
}
export type LookBackPeriodPreference = "DAYS_14" | "DAYS_32" | "DAYS_93" | (string & {});
export type CustomizableMetricName = "CpuUtilization" | "MemoryUtilization" | (string & {});
export type CustomizableMetricThreshold = "P90" | "P95" | "P99_5" | (string & {});
export type CustomizableMetricHeadroom = "PERCENT_30" | "PERCENT_20" | "PERCENT_10" | "PERCENT_0" | (string & {});
export interface CustomizableMetricParameters {
    threshold?: CustomizableMetricThreshold | undefined;
    headroom?: CustomizableMetricHeadroom | undefined;
}
export interface UtilizationPreference {
    metricName?: CustomizableMetricName | undefined;
    metricParameters?: CustomizableMetricParameters | undefined;
}
export type UtilizationPreferences = UtilizationPreference[];
export type PreferredResourceName = "Ec2InstanceTypes" | (string & {});
export type PreferredResourceValue = string;
export type PreferredResourceValues = string[];
export interface EffectivePreferredResource {
    name?: PreferredResourceName | undefined;
    includeList?: string[] | undefined;
    effectiveIncludeList?: string[] | undefined;
    excludeList?: string[] | undefined;
}
export type EffectivePreferredResources = EffectivePreferredResource[];
export type InstanceSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export interface InstanceSavingsEstimationMode {
    source?: InstanceSavingsEstimationModeSource | undefined;
}
export interface EffectiveRecommendationPreferences {
    cpuVendorArchitectures?: CpuVendorArchitecture[] | undefined;
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics | undefined;
    inferredWorkloadTypes?: InferredWorkloadTypesPreference | undefined;
    externalMetricsPreference?: ExternalMetricsPreference | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
    utilizationPreferences?: UtilizationPreference[] | undefined;
    preferredResources?: EffectivePreferredResource[] | undefined;
    savingsEstimationMode?: InstanceSavingsEstimationMode | undefined;
}
export type InferredWorkloadType = "AmazonEmr" | "ApacheCassandra" | "ApacheHadoop" | "Memcached" | "Nginx" | "PostgreSql" | "Redis" | "Kafka" | "SQLServer" | (string & {});
export type InferredWorkloadTypes = InferredWorkloadType[];
export interface AutoScalingGroupRecommendation {
    accountId?: string | undefined;
    autoScalingGroupArn?: string | undefined;
    autoScalingGroupName?: string | undefined;
    finding?: Finding | undefined;
    utilizationMetrics?: UtilizationMetric[] | undefined;
    lookBackPeriodInDays?: number | undefined;
    currentConfiguration?: AutoScalingGroupConfiguration | undefined;
    currentInstanceGpuInfo?: GpuInfo | undefined;
    recommendationOptions?: AutoScalingGroupRecommendationOption[] | undefined;
    lastRefreshTimestamp?: Date | undefined;
    currentPerformanceRisk?: CurrentPerformanceRisk | undefined;
    effectiveRecommendationPreferences?: EffectiveRecommendationPreferences | undefined;
    inferredWorkloadTypes?: InferredWorkloadType[] | undefined;
}
export type AutoScalingGroupRecommendations = AutoScalingGroupRecommendation[];
export type Identifier = string;
export type Code = string;
export type Message = string;
export interface GetRecommendationError {
    identifier?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type GetRecommendationErrors = GetRecommendationError[];
export interface GetAutoScalingGroupRecommendationsResponse {
    nextToken?: string | undefined;
    autoScalingGroupRecommendations?: AutoScalingGroupRecommendation[] | undefined;
    errors?: GetRecommendationError[] | undefined;
}
export type VolumeArn = string;
export type VolumeArns = string[];
export interface GetEBSVolumeRecommendationsRequest {
    volumeArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: EBSFilter[] | undefined;
    accountIds?: string[] | undefined;
}
export type VolumeType = string;
export type VolumeSize = number;
export type VolumeBaselineIOPS = number;
export type VolumeBurstIOPS = number;
export type VolumeBaselineThroughput = number;
export type VolumeBurstThroughput = number;
export type RootVolume = boolean;
export interface VolumeConfiguration {
    volumeType?: string | undefined;
    volumeSize?: number | undefined;
    volumeBaselineIOPS?: number | undefined;
    volumeBurstIOPS?: number | undefined;
    volumeBaselineThroughput?: number | undefined;
    volumeBurstThroughput?: number | undefined;
    rootVolume?: boolean | undefined;
}
export type EBSFinding = "Optimized" | "NotOptimized" | (string & {});
export type EBSMetricName = "VolumeReadOpsPerSecond" | "VolumeWriteOpsPerSecond" | "VolumeReadBytesPerSecond" | "VolumeWriteBytesPerSecond" | "VolumeIOPSExceeded" | "VolumeThroughputExceeded" | (string & {});
export interface EBSUtilizationMetric {
    name?: EBSMetricName | undefined;
    statistic?: MetricStatistic | undefined;
    value?: number | undefined;
}
export type EBSUtilizationMetrics = EBSUtilizationMetric[];
export interface EBSEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface EBSSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: EBSEstimatedMonthlySavings | undefined;
}
export interface VolumeRecommendationOption {
    configuration?: VolumeConfiguration | undefined;
    performanceRisk?: number | undefined;
    rank?: number | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: EBSSavingsOpportunityAfterDiscounts | undefined;
}
export type VolumeRecommendationOptions = VolumeRecommendationOption[];
export type EBSSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export interface EBSSavingsEstimationMode {
    source?: EBSSavingsEstimationModeSource | undefined;
}
export interface EBSEffectiveRecommendationPreferences {
    savingsEstimationMode?: EBSSavingsEstimationMode | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key?: string | undefined;
    value?: string | undefined;
}
export type Tags = Tag[];
export interface VolumeRecommendation {
    volumeArn?: string | undefined;
    accountId?: string | undefined;
    currentConfiguration?: VolumeConfiguration | undefined;
    finding?: EBSFinding | undefined;
    utilizationMetrics?: EBSUtilizationMetric[] | undefined;
    lookBackPeriodInDays?: number | undefined;
    volumeRecommendationOptions?: VolumeRecommendationOption[] | undefined;
    lastRefreshTimestamp?: Date | undefined;
    currentPerformanceRisk?: CurrentPerformanceRisk | undefined;
    effectiveRecommendationPreferences?: EBSEffectiveRecommendationPreferences | undefined;
    tags?: Tag[] | undefined;
}
export type VolumeRecommendations = VolumeRecommendation[];
export interface GetEBSVolumeRecommendationsResponse {
    nextToken?: string | undefined;
    volumeRecommendations?: VolumeRecommendation[] | undefined;
    errors?: GetRecommendationError[] | undefined;
}
export type InstanceArn = string;
export type InstanceArns = string[];
export interface GetEC2InstanceRecommendationsRequest {
    instanceArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: Filter[] | undefined;
    accountIds?: string[] | undefined;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export type InstanceName = string;
export type CurrentInstanceType = string;
export type InstanceRecommendationFindingReasonCode = "CPUOverprovisioned" | "CPUUnderprovisioned" | "MemoryOverprovisioned" | "MemoryUnderprovisioned" | "EBSThroughputOverprovisioned" | "EBSThroughputUnderprovisioned" | "EBSIOPSOverprovisioned" | "EBSIOPSUnderprovisioned" | "NetworkBandwidthOverprovisioned" | "NetworkBandwidthUnderprovisioned" | "NetworkPPSOverprovisioned" | "NetworkPPSUnderprovisioned" | "DiskIOPSOverprovisioned" | "DiskIOPSUnderprovisioned" | "DiskThroughputOverprovisioned" | "DiskThroughputUnderprovisioned" | "GPUUnderprovisioned" | "GPUOverprovisioned" | "GPUMemoryUnderprovisioned" | "GPUMemoryOverprovisioned" | (string & {});
export type InstanceRecommendationFindingReasonCodes = InstanceRecommendationFindingReasonCode[];
export type InstanceType = string;
export type PlatformDifference = "Hypervisor" | "NetworkInterface" | "StorageInterface" | "InstanceStoreAvailability" | "VirtualizationType" | "Architecture" | (string & {});
export type PlatformDifferences = PlatformDifference[];
export interface InstanceEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface InstanceSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: InstanceEstimatedMonthlySavings | undefined;
}
export interface InstanceRecommendationOption {
    instanceType?: string | undefined;
    instanceGpuInfo?: GpuInfo | undefined;
    projectedUtilizationMetrics?: UtilizationMetric[] | undefined;
    platformDifferences?: PlatformDifference[] | undefined;
    performanceRisk?: number | undefined;
    rank?: number | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: InstanceSavingsOpportunityAfterDiscounts | undefined;
    migrationEffort?: MigrationEffort | undefined;
}
export type RecommendationOptions = InstanceRecommendationOption[];
export type RecommendationSourceArn = string;
export type RecommendationSourceType = "Ec2Instance" | "AutoScalingGroup" | "EbsVolume" | "LambdaFunction" | "EcsService" | "License" | "RdsDBInstance" | "RdsDBInstanceStorage" | "AuroraDBClusterStorage" | "NatGateway" | "DynamoDBTable" | "ElastiCacheCluster" | "MemoryDBCluster" | "DocumentDBCluster" | "WorkSpaces" | "SageMakerEndpoint" | (string & {});
export interface RecommendationSource {
    recommendationSourceArn?: string | undefined;
    recommendationSourceType?: RecommendationSourceType | undefined;
}
export type RecommendationSources = RecommendationSource[];
export type InstanceState = "pending" | "running" | "shutting-down" | "terminated" | "stopping" | "stopped" | (string & {});
export type ExternalMetricStatusCode = "NO_EXTERNAL_METRIC_SET" | "INTEGRATION_SUCCESS" | "DATADOG_INTEGRATION_ERROR" | "DYNATRACE_INTEGRATION_ERROR" | "NEWRELIC_INTEGRATION_ERROR" | "INSTANA_INTEGRATION_ERROR" | "INSUFFICIENT_DATADOG_METRICS" | "INSUFFICIENT_DYNATRACE_METRICS" | "INSUFFICIENT_NEWRELIC_METRICS" | "INSUFFICIENT_INSTANA_METRICS" | (string & {});
export type ExternalMetricStatusReason = string;
export interface ExternalMetricStatus {
    statusCode?: ExternalMetricStatusCode | undefined;
    statusReason?: string | undefined;
}
export type InstanceIdle = "True" | "False" | (string & {});
export interface InstanceRecommendation {
    instanceArn?: string | undefined;
    accountId?: string | undefined;
    instanceName?: string | undefined;
    currentInstanceType?: string | undefined;
    finding?: Finding | undefined;
    findingReasonCodes?: InstanceRecommendationFindingReasonCode[] | undefined;
    utilizationMetrics?: UtilizationMetric[] | undefined;
    lookBackPeriodInDays?: number | undefined;
    recommendationOptions?: InstanceRecommendationOption[] | undefined;
    recommendationSources?: RecommendationSource[] | undefined;
    lastRefreshTimestamp?: Date | undefined;
    currentPerformanceRisk?: CurrentPerformanceRisk | undefined;
    effectiveRecommendationPreferences?: EffectiveRecommendationPreferences | undefined;
    inferredWorkloadTypes?: InferredWorkloadType[] | undefined;
    instanceState?: InstanceState | undefined;
    tags?: Tag[] | undefined;
    externalMetricStatus?: ExternalMetricStatus | undefined;
    currentInstanceGpuInfo?: GpuInfo | undefined;
    idle?: InstanceIdle | undefined;
}
export type InstanceRecommendations = InstanceRecommendation[];
export interface GetEC2InstanceRecommendationsResponse {
    nextToken?: string | undefined;
    instanceRecommendations?: InstanceRecommendation[] | undefined;
    errors?: GetRecommendationError[] | undefined;
}
export type Period = number;
export interface GetEC2RecommendationProjectedMetricsRequest {
    instanceArn: string;
    stat: MetricStatistic;
    period: number;
    startTime: Date;
    endTime: Date;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export type RecommendedInstanceType = string;
export type Timestamps = Date[];
export type MetricValues = number[];
export interface ProjectedMetric {
    name?: MetricName | undefined;
    timestamps?: Date[] | undefined;
    values?: number[] | undefined;
}
export type ProjectedMetrics = ProjectedMetric[];
export interface RecommendedOptionProjectedMetric {
    recommendedInstanceType?: string | undefined;
    rank?: number | undefined;
    projectedMetrics?: ProjectedMetric[] | undefined;
}
export type RecommendedOptionProjectedMetrics = RecommendedOptionProjectedMetric[];
export interface GetEC2RecommendationProjectedMetricsResponse {
    recommendedOptionProjectedMetrics?: RecommendedOptionProjectedMetric[] | undefined;
}
export type ServiceArn = string;
export interface GetECSServiceRecommendationProjectedMetricsRequest {
    serviceArn: string;
    stat: MetricStatistic;
    period: number;
    startTime: Date;
    endTime: Date;
}
export type CpuSize = number;
export type MemorySize = number;
export type ECSServiceMetricName = "Cpu" | "Memory" | (string & {});
export interface ECSServiceProjectedMetric {
    name?: ECSServiceMetricName | undefined;
    timestamps?: Date[] | undefined;
    upperBoundValues?: number[] | undefined;
    lowerBoundValues?: number[] | undefined;
}
export type ECSServiceProjectedMetrics = ECSServiceProjectedMetric[];
export interface ECSServiceRecommendedOptionProjectedMetric {
    recommendedCpuUnits?: number | undefined;
    recommendedMemorySize?: number | undefined;
    projectedMetrics?: ECSServiceProjectedMetric[] | undefined;
}
export type ECSServiceRecommendedOptionProjectedMetrics = ECSServiceRecommendedOptionProjectedMetric[];
export interface GetECSServiceRecommendationProjectedMetricsResponse {
    recommendedOptionProjectedMetrics?: ECSServiceRecommendedOptionProjectedMetric[] | undefined;
}
export type ServiceArns = string[];
export interface GetECSServiceRecommendationsRequest {
    serviceArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: ECSServiceRecommendationFilter[] | undefined;
    accountIds?: string[] | undefined;
}
export type NullableMemory = number;
export type NullableCpu = number;
export type ContainerName = string;
export type NullableMemoryReservation = number;
export interface MemorySizeConfiguration {
    memory?: number | undefined;
    memoryReservation?: number | undefined;
}
export interface ContainerConfiguration {
    containerName?: string | undefined;
    memorySizeConfiguration?: MemorySizeConfiguration | undefined;
    cpu?: number | undefined;
}
export type ContainerConfigurations = ContainerConfiguration[];
export type AutoScalingConfiguration = "TargetTrackingScalingCpu" | "TargetTrackingScalingMemory" | (string & {});
export type TaskDefinitionArn = string;
export interface ServiceConfiguration {
    memory?: number | undefined;
    cpu?: number | undefined;
    containerConfigurations?: ContainerConfiguration[] | undefined;
    autoScalingConfiguration?: AutoScalingConfiguration | undefined;
    taskDefinitionArn?: string | undefined;
}
export type ECSServiceMetricStatistic = "Maximum" | "Average" | (string & {});
export interface ECSServiceUtilizationMetric {
    name?: ECSServiceMetricName | undefined;
    statistic?: ECSServiceMetricStatistic | undefined;
    value?: number | undefined;
}
export type ECSServiceUtilizationMetrics = ECSServiceUtilizationMetric[];
export type ECSServiceLaunchType = "EC2" | "Fargate" | (string & {});
export type ECSServiceRecommendationFinding = "Optimized" | "Underprovisioned" | "Overprovisioned" | (string & {});
export type ECSServiceRecommendationFindingReasonCode = "MemoryOverprovisioned" | "MemoryUnderprovisioned" | "CPUOverprovisioned" | "CPUUnderprovisioned" | (string & {});
export type ECSServiceRecommendationFindingReasonCodes = ECSServiceRecommendationFindingReasonCode[];
export interface ECSEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface ECSSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: ECSEstimatedMonthlySavings | undefined;
}
export type LowerBoundValue = number;
export type UpperBoundValue = number;
export interface ECSServiceProjectedUtilizationMetric {
    name?: ECSServiceMetricName | undefined;
    statistic?: ECSServiceMetricStatistic | undefined;
    lowerBoundValue?: number | undefined;
    upperBoundValue?: number | undefined;
}
export type ECSServiceProjectedUtilizationMetrics = ECSServiceProjectedUtilizationMetric[];
export interface ContainerRecommendation {
    containerName?: string | undefined;
    memorySizeConfiguration?: MemorySizeConfiguration | undefined;
    cpu?: number | undefined;
}
export type ContainerRecommendations = ContainerRecommendation[];
export interface ECSServiceRecommendationOption {
    memory?: number | undefined;
    cpu?: number | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: ECSSavingsOpportunityAfterDiscounts | undefined;
    projectedUtilizationMetrics?: ECSServiceProjectedUtilizationMetric[] | undefined;
    containerRecommendations?: ContainerRecommendation[] | undefined;
}
export type ECSServiceRecommendationOptions = ECSServiceRecommendationOption[];
export type ECSSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export interface ECSSavingsEstimationMode {
    source?: ECSSavingsEstimationModeSource | undefined;
}
export interface ECSEffectiveRecommendationPreferences {
    savingsEstimationMode?: ECSSavingsEstimationMode | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
}
export interface ECSServiceRecommendation {
    serviceArn?: string | undefined;
    accountId?: string | undefined;
    currentServiceConfiguration?: ServiceConfiguration | undefined;
    utilizationMetrics?: ECSServiceUtilizationMetric[] | undefined;
    lookbackPeriodInDays?: number | undefined;
    launchType?: ECSServiceLaunchType | undefined;
    lastRefreshTimestamp?: Date | undefined;
    finding?: ECSServiceRecommendationFinding | undefined;
    findingReasonCodes?: ECSServiceRecommendationFindingReasonCode[] | undefined;
    serviceRecommendationOptions?: ECSServiceRecommendationOption[] | undefined;
    currentPerformanceRisk?: CurrentPerformanceRisk | undefined;
    effectiveRecommendationPreferences?: ECSEffectiveRecommendationPreferences | undefined;
    tags?: Tag[] | undefined;
}
export type ECSServiceRecommendations = ECSServiceRecommendation[];
export interface GetECSServiceRecommendationsResponse {
    nextToken?: string | undefined;
    ecsServiceRecommendations?: ECSServiceRecommendation[] | undefined;
    errors?: GetRecommendationError[] | undefined;
}
export type ResourceArn = string;
export interface GetEffectiveRecommendationPreferencesRequest {
    resourceArn: string;
}
export interface GetEffectiveRecommendationPreferencesResponse {
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics | undefined;
    externalMetricsPreference?: ExternalMetricsPreference | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
    utilizationPreferences?: UtilizationPreference[] | undefined;
    preferredResources?: EffectivePreferredResource[] | undefined;
}
export interface GetEnrollmentStatusRequest {
}
export type Status = "Active" | "Inactive" | "Pending" | "Failed" | (string & {});
export type StatusReason = string;
export type MemberAccountsEnrolled = boolean;
export type NumberOfMemberAccountsOptedIn = number;
export interface GetEnrollmentStatusResponse {
    status?: Status | undefined;
    statusReason?: string | undefined;
    memberAccountsEnrolled?: boolean | undefined;
    lastUpdatedTimestamp?: Date | undefined;
    numberOfMemberAccountsOptedIn?: number | undefined;
}
export type EnrollmentFilterName = "Status" | (string & {});
export interface EnrollmentFilter {
    name?: EnrollmentFilterName | undefined;
    values?: string[] | undefined;
}
export type EnrollmentFilters = EnrollmentFilter[];
export interface GetEnrollmentStatusesForOrganizationRequest {
    filters?: EnrollmentFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AccountEnrollmentStatus {
    accountId?: string | undefined;
    status?: Status | undefined;
    statusReason?: string | undefined;
    lastUpdatedTimestamp?: Date | undefined;
}
export type AccountEnrollmentStatuses = AccountEnrollmentStatus[];
export interface GetEnrollmentStatusesForOrganizationResponse {
    accountEnrollmentStatuses?: AccountEnrollmentStatus[] | undefined;
    nextToken?: string | undefined;
}
export type ResourceArns = string[];
export type IdleMaxResults = number;
export type Dimension = "SavingsValue" | "SavingsValueAfterDiscount" | (string & {});
export type Order = "Asc" | "Desc" | (string & {});
export interface OrderBy {
    dimension?: Dimension | undefined;
    order?: Order | undefined;
}
export interface GetIdleRecommendationsRequest {
    resourceArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: IdleRecommendationFilter[] | undefined;
    accountIds?: string[] | undefined;
    orderBy?: OrderBy | undefined;
}
export type ResourceId = string;
export type IdleRecommendationResourceType = "EC2Instance" | "AutoScalingGroup" | "EBSVolume" | "ECSService" | "RDSDBInstance" | "NatGateway" | "DynamoDBTable" | "ElastiCacheCluster" | "MemoryDBCluster" | "DocumentDBCluster" | "WorkSpaces" | "SageMakerEndpoint" | (string & {});
export type IdleFinding = "Idle" | "Unattached" | "Unused" | (string & {});
export type IdleFindingDescription = string;
export interface IdleEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface IdleSavingsOpportunity {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: IdleEstimatedMonthlySavings | undefined;
}
export interface IdleSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: IdleEstimatedMonthlySavings | undefined;
}
export type IdleMetricName = "CPU" | "Memory" | "NetworkOutBytesPerSecond" | "NetworkInBytesPerSecond" | "DatabaseConnections" | "EBSVolumeReadIOPS" | "EBSVolumeWriteIOPS" | "VolumeReadOpsPerSecond" | "VolumeWriteOpsPerSecond" | "ActiveConnectionCount" | "PacketsInFromSource" | "PacketsInFromDestination" | "ConsumedReadCapacityUnits" | "ConsumedWriteCapacityUnits" | "ConsumedChangeDataCaptureUnits" | "NewConnections" | "EngineCPUUtilization" | "CacheHits" | "CacheMisses" | "KeyspaceHits" | "KeyspaceMisses" | "IsIdle" | "UserConnected" | "Invocations" | "GetTypeCmds" | "SetTypeCmds" | "ElastiCacheProcessingUnits" | "CurrConnections" | (string & {});
export type IdleDimensionKey = string;
export type IdleDimensionValue = string;
export type IdleDimensionValues = string[];
export interface IdleDimension {
    key?: string | undefined;
    values?: string[] | undefined;
}
export type IdleDimensions = IdleDimension[];
export interface IdleUtilizationMetric {
    name?: IdleMetricName | undefined;
    statistic?: MetricStatistic | undefined;
    value?: number | undefined;
    dimensions?: IdleDimension[] | undefined;
}
export type IdleUtilizationMetrics = IdleUtilizationMetric[];
export interface IdleRecommendation {
    resourceArn?: string | undefined;
    resourceId?: string | undefined;
    resourceType?: IdleRecommendationResourceType | undefined;
    accountId?: string | undefined;
    finding?: IdleFinding | undefined;
    findingDescription?: string | undefined;
    savingsOpportunity?: IdleSavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: IdleSavingsOpportunityAfterDiscounts | undefined;
    utilizationMetrics?: IdleUtilizationMetric[] | undefined;
    lookBackPeriodInDays?: number | undefined;
    lastRefreshTimestamp?: Date | undefined;
    tags?: Tag[] | undefined;
}
export type IdleRecommendations = IdleRecommendation[];
export interface IdleRecommendationError {
    identifier?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
    resourceType?: IdleRecommendationResourceType | undefined;
}
export type IdleRecommendationErrors = IdleRecommendationError[];
export interface GetIdleRecommendationsResponse {
    nextToken?: string | undefined;
    idleRecommendations?: IdleRecommendation[] | undefined;
    errors?: IdleRecommendationError[] | undefined;
}
export type FunctionArn = string;
export type FunctionArns = string[];
export interface GetLambdaFunctionRecommendationsRequest {
    functionArns?: string[] | undefined;
    accountIds?: string[] | undefined;
    filters?: LambdaFunctionRecommendationFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type FunctionVersion = string;
export type NumberOfInvocations = number;
export type LambdaFunctionMetricName = "Duration" | "Memory" | (string & {});
export type LambdaFunctionMetricStatistic = "Maximum" | "Average" | (string & {});
export interface LambdaFunctionUtilizationMetric {
    name?: LambdaFunctionMetricName | undefined;
    statistic?: LambdaFunctionMetricStatistic | undefined;
    value?: number | undefined;
}
export type LambdaFunctionUtilizationMetrics = LambdaFunctionUtilizationMetric[];
export type LambdaFunctionRecommendationFinding = "Optimized" | "NotOptimized" | "Unavailable" | (string & {});
export type LambdaFunctionRecommendationFindingReasonCode = "MemoryOverprovisioned" | "MemoryUnderprovisioned" | "InsufficientData" | "Inconclusive" | (string & {});
export type LambdaFunctionRecommendationFindingReasonCodes = LambdaFunctionRecommendationFindingReasonCode[];
export type LambdaFunctionMemoryMetricName = "Duration" | (string & {});
export type LambdaFunctionMemoryMetricStatistic = "LowerBound" | "UpperBound" | "Expected" | (string & {});
export interface LambdaFunctionMemoryProjectedMetric {
    name?: LambdaFunctionMemoryMetricName | undefined;
    statistic?: LambdaFunctionMemoryMetricStatistic | undefined;
    value?: number | undefined;
}
export type LambdaFunctionMemoryProjectedMetrics = LambdaFunctionMemoryProjectedMetric[];
export interface LambdaEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface LambdaSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: LambdaEstimatedMonthlySavings | undefined;
}
export interface LambdaFunctionMemoryRecommendationOption {
    rank?: number | undefined;
    memorySize?: number | undefined;
    projectedUtilizationMetrics?: LambdaFunctionMemoryProjectedMetric[] | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: LambdaSavingsOpportunityAfterDiscounts | undefined;
}
export type LambdaFunctionMemoryRecommendationOptions = LambdaFunctionMemoryRecommendationOption[];
export type LambdaSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export interface LambdaSavingsEstimationMode {
    source?: LambdaSavingsEstimationModeSource | undefined;
}
export interface LambdaEffectiveRecommendationPreferences {
    savingsEstimationMode?: LambdaSavingsEstimationMode | undefined;
}
export interface LambdaFunctionRecommendation {
    functionArn?: string | undefined;
    functionVersion?: string | undefined;
    accountId?: string | undefined;
    currentMemorySize?: number | undefined;
    numberOfInvocations?: number | undefined;
    utilizationMetrics?: LambdaFunctionUtilizationMetric[] | undefined;
    lookbackPeriodInDays?: number | undefined;
    lastRefreshTimestamp?: Date | undefined;
    finding?: LambdaFunctionRecommendationFinding | undefined;
    findingReasonCodes?: LambdaFunctionRecommendationFindingReasonCode[] | undefined;
    memorySizeRecommendationOptions?: LambdaFunctionMemoryRecommendationOption[] | undefined;
    currentPerformanceRisk?: CurrentPerformanceRisk | undefined;
    effectiveRecommendationPreferences?: LambdaEffectiveRecommendationPreferences | undefined;
    tags?: Tag[] | undefined;
}
export type LambdaFunctionRecommendations = LambdaFunctionRecommendation[];
export interface GetLambdaFunctionRecommendationsResponse {
    nextToken?: string | undefined;
    lambdaFunctionRecommendations?: LambdaFunctionRecommendation[] | undefined;
}
export interface GetLicenseRecommendationsRequest {
    resourceArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: LicenseRecommendationFilter[] | undefined;
    accountIds?: string[] | undefined;
}
export type NumberOfCores = number;
export type OperatingSystem = string;
export type LicenseEdition = "Enterprise" | "Standard" | "Free" | "NoLicenseEditionFound" | (string & {});
export type LicenseName = "SQLServer" | (string & {});
export type LicenseModel = "LicenseIncluded" | "BringYourOwnLicense" | (string & {});
export type LicenseVersion = string;
export type MetricSourceProvider = "CloudWatchApplicationInsights" | (string & {});
export type MetricProviderArn = string;
export interface MetricSource {
    provider?: MetricSourceProvider | undefined;
    providerArn?: string | undefined;
}
export type MetricsSource = MetricSource[];
export interface LicenseConfiguration {
    numberOfCores?: number | undefined;
    instanceType?: string | undefined;
    operatingSystem?: string | undefined;
    licenseEdition?: LicenseEdition | undefined;
    licenseName?: LicenseName | undefined;
    licenseModel?: LicenseModel | undefined;
    licenseVersion?: string | undefined;
    metricsSource?: MetricSource[] | undefined;
}
export type LicenseFinding = "InsufficientMetrics" | "Optimized" | "NotOptimized" | (string & {});
export type LicenseFindingReasonCode = "InvalidCloudWatchApplicationInsightsSetup" | "CloudWatchApplicationInsightsError" | "LicenseOverprovisioned" | "Optimized" | (string & {});
export type LicenseFindingReasonCodes = LicenseFindingReasonCode[];
export interface LicenseRecommendationOption {
    rank?: number | undefined;
    operatingSystem?: string | undefined;
    licenseEdition?: LicenseEdition | undefined;
    licenseModel?: LicenseModel | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
}
export type LicenseRecommendationOptions = LicenseRecommendationOption[];
export interface LicenseRecommendation {
    resourceArn?: string | undefined;
    accountId?: string | undefined;
    currentLicenseConfiguration?: LicenseConfiguration | undefined;
    lookbackPeriodInDays?: number | undefined;
    lastRefreshTimestamp?: Date | undefined;
    finding?: LicenseFinding | undefined;
    findingReasonCodes?: LicenseFindingReasonCode[] | undefined;
    licenseRecommendationOptions?: LicenseRecommendationOption[] | undefined;
    tags?: Tag[] | undefined;
}
export type LicenseRecommendations = LicenseRecommendation[];
export interface GetLicenseRecommendationsResponse {
    nextToken?: string | undefined;
    licenseRecommendations?: LicenseRecommendation[] | undefined;
    errors?: GetRecommendationError[] | undefined;
}
export interface GetRDSDatabaseRecommendationProjectedMetricsRequest {
    resourceArn: string;
    stat: MetricStatistic;
    period: number;
    startTime: Date;
    endTime: Date;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export type RecommendedDBInstanceClass = string;
export type RDSDBMetricName = "CPU" | "Memory" | "EBSVolumeStorageSpaceUtilization" | "NetworkReceiveThroughput" | "NetworkTransmitThroughput" | "EBSVolumeReadIOPS" | "EBSVolumeWriteIOPS" | "EBSVolumeReadThroughput" | "EBSVolumeWriteThroughput" | "DatabaseConnections" | "StorageNetworkReceiveThroughput" | "StorageNetworkTransmitThroughput" | "AuroraMemoryHealthState" | "AuroraMemoryNumDeclinedSql" | "AuroraMemoryNumKillConnTotal" | "AuroraMemoryNumKillQueryTotal" | "ReadIOPSEphemeralStorage" | "WriteIOPSEphemeralStorage" | "VolumeReadIOPs" | "VolumeBytesUsed" | "VolumeWriteIOPs" | (string & {});
export interface RDSDatabaseProjectedMetric {
    name?: RDSDBMetricName | undefined;
    timestamps?: Date[] | undefined;
    values?: number[] | undefined;
}
export type RDSDatabaseProjectedMetrics = RDSDatabaseProjectedMetric[];
export interface RDSDatabaseRecommendedOptionProjectedMetric {
    recommendedDBInstanceClass?: string | undefined;
    rank?: number | undefined;
    projectedMetrics?: RDSDatabaseProjectedMetric[] | undefined;
}
export type RDSDatabaseRecommendedOptionProjectedMetrics = RDSDatabaseRecommendedOptionProjectedMetric[];
export interface GetRDSDatabaseRecommendationProjectedMetricsResponse {
    recommendedOptionProjectedMetrics?: RDSDatabaseRecommendedOptionProjectedMetric[] | undefined;
}
export interface GetRDSDatabaseRecommendationsRequest {
    resourceArns?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: RDSDBRecommendationFilter[] | undefined;
    accountIds?: string[] | undefined;
    recommendationPreferences?: RecommendationPreferences | undefined;
}
export type Engine = string;
export type EngineVersion = string;
export type PromotionTier = number;
export type CurrentDBInstanceClass = string;
export type StorageType = string;
export type AllocatedStorage = number;
export type NullableIOPS = number;
export type NullableMaxAllocatedStorage = number;
export type NullableStorageThroughput = number;
export interface DBStorageConfiguration {
    storageType?: string | undefined;
    allocatedStorage?: number | undefined;
    iops?: number | undefined;
    maxAllocatedStorage?: number | undefined;
    storageThroughput?: number | undefined;
}
export type DBClusterIdentifier = string;
export type Idle = "True" | "False" | (string & {});
export type RDSInstanceFinding = "Optimized" | "Underprovisioned" | "Overprovisioned" | (string & {});
export type RDSStorageFinding = "Optimized" | "Underprovisioned" | "Overprovisioned" | "NotOptimized" | (string & {});
export type RDSInstanceFindingReasonCode = "CPUOverprovisioned" | "NetworkBandwidthOverprovisioned" | "EBSIOPSOverprovisioned" | "EBSIOPSUnderprovisioned" | "EBSThroughputOverprovisioned" | "CPUUnderprovisioned" | "NetworkBandwidthUnderprovisioned" | "EBSThroughputUnderprovisioned" | "NewGenerationDBInstanceClassAvailable" | "NewEngineVersionAvailable" | "DBClusterWriterUnderprovisioned" | "MemoryUnderprovisioned" | "InstanceStorageReadIOPSUnderprovisioned" | "InstanceStorageWriteIOPSUnderprovisioned" | (string & {});
export type RDSInstanceFindingReasonCodes = RDSInstanceFindingReasonCode[];
export type RDSCurrentInstancePerformanceRisk = "VeryLow" | "Low" | "Medium" | "High" | (string & {});
export type RDSEstimatedMonthlyVolumeIOPsCostVariation = "None" | "Low" | "Medium" | "High" | (string & {});
export type RDSStorageFindingReasonCode = "EBSVolumeAllocatedStorageUnderprovisioned" | "EBSVolumeThroughputUnderprovisioned" | "EBSVolumeIOPSOverprovisioned" | "EBSVolumeThroughputOverprovisioned" | "NewGenerationStorageTypeAvailable" | "DBClusterStorageOptionAvailable" | "DBClusterStorageSavingsAvailable" | (string & {});
export type RDSStorageFindingReasonCodes = RDSStorageFindingReasonCode[];
export type DBInstanceClass = string;
export type RDSDBMetricStatistic = "Maximum" | "Minimum" | "Average" | (string & {});
export interface RDSDBUtilizationMetric {
    name?: RDSDBMetricName | undefined;
    statistic?: RDSDBMetricStatistic | undefined;
    value?: number | undefined;
}
export type RDSDBProjectedUtilizationMetrics = RDSDBUtilizationMetric[];
export interface RDSInstanceEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface RDSInstanceSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: RDSInstanceEstimatedMonthlySavings | undefined;
}
export interface RDSDBInstanceRecommendationOption {
    dbInstanceClass?: string | undefined;
    projectedUtilizationMetrics?: RDSDBUtilizationMetric[] | undefined;
    performanceRisk?: number | undefined;
    rank?: number | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: RDSInstanceSavingsOpportunityAfterDiscounts | undefined;
}
export type RDSDBInstanceRecommendationOptions = RDSDBInstanceRecommendationOption[];
export interface RDSStorageEstimatedMonthlySavings {
    currency?: Currency | undefined;
    value?: number | undefined;
}
export interface RDSStorageSavingsOpportunityAfterDiscounts {
    savingsOpportunityPercentage?: number | undefined;
    estimatedMonthlySavings?: RDSStorageEstimatedMonthlySavings | undefined;
}
export interface RDSDBStorageRecommendationOption {
    storageConfiguration?: DBStorageConfiguration | undefined;
    rank?: number | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    savingsOpportunityAfterDiscounts?: RDSStorageSavingsOpportunityAfterDiscounts | undefined;
    estimatedMonthlyVolumeIOPsCostVariation?: RDSEstimatedMonthlyVolumeIOPsCostVariation | undefined;
}
export type RDSDBStorageRecommendationOptions = RDSDBStorageRecommendationOption[];
export type RDSDBUtilizationMetrics = RDSDBUtilizationMetric[];
export type RDSSavingsEstimationModeSource = "PublicPricing" | "CostExplorerRightsizing" | "CostOptimizationHub" | (string & {});
export interface RDSSavingsEstimationMode {
    source?: RDSSavingsEstimationModeSource | undefined;
}
export interface RDSEffectiveRecommendationPreferences {
    cpuVendorArchitectures?: CpuVendorArchitecture[] | undefined;
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
    savingsEstimationMode?: RDSSavingsEstimationMode | undefined;
}
export interface RDSDBRecommendation {
    resourceArn?: string | undefined;
    accountId?: string | undefined;
    engine?: string | undefined;
    engineVersion?: string | undefined;
    promotionTier?: number | undefined;
    currentDBInstanceClass?: string | undefined;
    currentStorageConfiguration?: DBStorageConfiguration | undefined;
    dbClusterIdentifier?: string | undefined;
    idle?: Idle | undefined;
    instanceFinding?: RDSInstanceFinding | undefined;
    storageFinding?: RDSStorageFinding | undefined;
    instanceFindingReasonCodes?: RDSInstanceFindingReasonCode[] | undefined;
    currentInstancePerformanceRisk?: RDSCurrentInstancePerformanceRisk | undefined;
    currentStorageEstimatedMonthlyVolumeIOPsCostVariation?: RDSEstimatedMonthlyVolumeIOPsCostVariation | undefined;
    storageFindingReasonCodes?: RDSStorageFindingReasonCode[] | undefined;
    instanceRecommendationOptions?: RDSDBInstanceRecommendationOption[] | undefined;
    storageRecommendationOptions?: RDSDBStorageRecommendationOption[] | undefined;
    utilizationMetrics?: RDSDBUtilizationMetric[] | undefined;
    effectiveRecommendationPreferences?: RDSEffectiveRecommendationPreferences | undefined;
    lookbackPeriodInDays?: number | undefined;
    lastRefreshTimestamp?: Date | undefined;
    tags?: Tag[] | undefined;
}
export type RDSDBRecommendations = RDSDBRecommendation[];
export interface GetRDSDatabaseRecommendationsResponse {
    nextToken?: string | undefined;
    rdsDBRecommendations?: RDSDBRecommendation[] | undefined;
    errors?: GetRecommendationError[] | undefined;
}
export interface GetRecommendationPreferencesRequest {
    resourceType: ResourceType;
    scope?: Scope | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SavingsEstimationMode = "AfterDiscounts" | "BeforeDiscounts" | (string & {});
export interface RecommendationPreferencesDetail {
    scope?: Scope | undefined;
    resourceType?: ResourceType | undefined;
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics | undefined;
    inferredWorkloadTypes?: InferredWorkloadTypesPreference | undefined;
    externalMetricsPreference?: ExternalMetricsPreference | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
    utilizationPreferences?: UtilizationPreference[] | undefined;
    preferredResources?: EffectivePreferredResource[] | undefined;
    savingsEstimationMode?: SavingsEstimationMode | undefined;
}
export type RecommendationPreferencesDetails = RecommendationPreferencesDetail[];
export interface GetRecommendationPreferencesResponse {
    nextToken?: string | undefined;
    recommendationPreferencesDetails?: RecommendationPreferencesDetail[] | undefined;
}
export interface GetRecommendationSummariesRequest {
    accountIds?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SummaryValue = number;
export type FindingReasonCode = "MemoryOverprovisioned" | "MemoryUnderprovisioned" | (string & {});
export interface ReasonCodeSummary {
    name?: FindingReasonCode | undefined;
    value?: number | undefined;
}
export type ReasonCodeSummaries = ReasonCodeSummary[];
export interface Summary {
    name?: Finding | undefined;
    value?: number | undefined;
    reasonCodeSummaries?: ReasonCodeSummary[] | undefined;
}
export type Summaries = Summary[];
export interface IdleSummary {
    name?: IdleFinding | undefined;
    value?: number | undefined;
}
export type IdleSummaries = IdleSummary[];
export type High = number;
export type Medium = number;
export type Low = number;
export type VeryLow = number;
export interface CurrentPerformanceRiskRatings {
    high?: number | undefined;
    medium?: number | undefined;
    low?: number | undefined;
    veryLow?: number | undefined;
}
export interface InferredWorkloadSaving {
    inferredWorkloadTypes?: InferredWorkloadType[] | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
}
export type InferredWorkloadSavings = InferredWorkloadSaving[];
export interface RecommendationSummary {
    summaries?: Summary[] | undefined;
    idleSummaries?: IdleSummary[] | undefined;
    recommendationResourceType?: RecommendationSourceType | undefined;
    accountId?: string | undefined;
    savingsOpportunity?: SavingsOpportunity | undefined;
    idleSavingsOpportunity?: SavingsOpportunity | undefined;
    aggregatedSavingsOpportunity?: SavingsOpportunity | undefined;
    currentPerformanceRiskRatings?: CurrentPerformanceRiskRatings | undefined;
    inferredWorkloadSavings?: InferredWorkloadSaving[] | undefined;
}
export type RecommendationSummaries = RecommendationSummary[];
export interface GetRecommendationSummariesResponse {
    nextToken?: string | undefined;
    recommendationSummaries?: RecommendationSummary[] | undefined;
}
export interface PreferredResource {
    name?: PreferredResourceName | undefined;
    includeList?: string[] | undefined;
    excludeList?: string[] | undefined;
}
export type PreferredResources = PreferredResource[];
export interface PutRecommendationPreferencesRequest {
    resourceType: ResourceType;
    scope?: Scope | undefined;
    enhancedInfrastructureMetrics?: EnhancedInfrastructureMetrics | undefined;
    inferredWorkloadTypes?: InferredWorkloadTypesPreference | undefined;
    externalMetricsPreference?: ExternalMetricsPreference | undefined;
    lookBackPeriod?: LookBackPeriodPreference | undefined;
    utilizationPreferences?: UtilizationPreference[] | undefined;
    preferredResources?: PreferredResource[] | undefined;
    savingsEstimationMode?: SavingsEstimationMode | undefined;
}
export interface PutRecommendationPreferencesResponse {
}
export interface UpdateEnrollmentStatusRequest {
    status: Status;
    includeMemberAccounts?: boolean | undefined;
}
export interface UpdateEnrollmentStatusResponse {
    status?: Status | undefined;
    statusReason?: string | undefined;
}
export type ErrorMessage = string;
export type DeleteRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a recommendation preference, such as enhanced infrastructure metrics.
 *
 * For more information, see Activating
 * enhanced infrastructure metrics in the Compute Optimizer User
 * Guide.
 */
export declare const deleteRecommendationPreferences: API.OperationMethod<DeleteRecommendationPreferencesRequest & RegionInput, DeleteRecommendationPreferencesResponse, DeleteRecommendationPreferencesError, Credentials | HttpClient.HttpClient>;
export type DescribeRecommendationExportJobsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes recommendation export jobs created in the last seven days.
 *
 * Use the ExportAutoScalingGroupRecommendations or ExportEC2InstanceRecommendations actions to request an export of your
 * recommendations. Then use the DescribeRecommendationExportJobs action
 * to view your export jobs.
 */
export declare const describeRecommendationExportJobs: API.PaginatedOperationMethod<DescribeRecommendationExportJobsRequest & RegionInput, DescribeRecommendationExportJobsResponse, DescribeRecommendationExportJobsError, Credentials | HttpClient.HttpClient, RecommendationExportJob>;
export type ExportAutoScalingGroupRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Auto Scaling groups.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Auto Scaling group export job in progress per Amazon Web Services Region.
 */
export declare const exportAutoScalingGroupRecommendations: API.OperationMethod<ExportAutoScalingGroupRecommendationsRequest & RegionInput, ExportAutoScalingGroupRecommendationsResponse, ExportAutoScalingGroupRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportEBSVolumeRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Amazon EBS volumes.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Amazon EBS volume export job in progress per Amazon Web Services Region.
 */
export declare const exportEBSVolumeRecommendations: API.OperationMethod<ExportEBSVolumeRecommendationsRequest & RegionInput, ExportEBSVolumeRecommendationsResponse, ExportEBSVolumeRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportEC2InstanceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Amazon EC2 instances.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Amazon EC2 instance export job in progress per Amazon Web Services Region.
 */
export declare const exportEC2InstanceRecommendations: API.OperationMethod<ExportEC2InstanceRecommendationsRequest & RegionInput, ExportEC2InstanceRecommendationsResponse, ExportEC2InstanceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportECSServiceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Amazon ECS services on Fargate.
 *
 * Recommendations are exported in a CSV file, and its metadata
 * in a JSON file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can only have one Amazon ECS service export job in progress per Amazon Web Services Region.
 */
export declare const exportECSServiceRecommendations: API.OperationMethod<ExportECSServiceRecommendationsRequest & RegionInput, ExportECSServiceRecommendationsResponse, ExportECSServiceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportIdleRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Export optimization recommendations for your idle resources.
 *
 * Recommendations are exported in a comma-separated values (CSV) file, and its metadata
 * in a JavaScript Object Notation (JSON) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one idle resource export job in progress per Amazon Web Services Region.
 */
export declare const exportIdleRecommendations: API.OperationMethod<ExportIdleRecommendationsRequest & RegionInput, ExportIdleRecommendationsResponse, ExportIdleRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportLambdaFunctionRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Exports optimization recommendations for Lambda functions.
 *
 * Recommendations are exported in a comma-separated values (.csv) file, and its metadata
 * in a JavaScript Object Notation (JSON) (.json) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Lambda function export job in progress per Amazon Web Services Region.
 */
export declare const exportLambdaFunctionRecommendations: API.OperationMethod<ExportLambdaFunctionRecommendationsRequest & RegionInput, ExportLambdaFunctionRecommendationsResponse, ExportLambdaFunctionRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportLicenseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Export optimization recommendations for your licenses.
 *
 * Recommendations are exported in a comma-separated values (CSV) file, and its metadata
 * in a JavaScript Object Notation (JSON) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one license export job in progress per Amazon Web Services Region.
 */
export declare const exportLicenseRecommendations: API.OperationMethod<ExportLicenseRecommendationsRequest & RegionInput, ExportLicenseRecommendationsResponse, ExportLicenseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type ExportRDSDatabaseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Export optimization recommendations for your Amazon Aurora and Amazon Relational Database Service (Amazon RDS) databases.
 *
 * Recommendations are exported in a comma-separated values (CSV) file, and its metadata
 * in a JavaScript Object Notation (JSON) file, to an existing Amazon Simple Storage Service (Amazon S3) bucket that you specify. For more information, see Exporting
 * Recommendations in the Compute Optimizer User
 * Guide.
 *
 * You can have only one Amazon Aurora or RDS export job in progress per Amazon Web Services Region.
 */
export declare const exportRDSDatabaseRecommendations: API.OperationMethod<ExportRDSDatabaseRecommendationsRequest & RegionInput, ExportRDSDatabaseRecommendationsResponse, ExportRDSDatabaseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetAutoScalingGroupRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Auto Scaling group recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon EC2 Auto Scaling groups that
 * meet a specific set of requirements. For more information, see the Supported
 * resources and requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getAutoScalingGroupRecommendations: API.OperationMethod<GetAutoScalingGroupRecommendationsRequest & RegionInput, GetAutoScalingGroupRecommendationsResponse, GetAutoScalingGroupRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEBSVolumeRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon Elastic Block Store (Amazon EBS) volume recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon EBS volumes that
 * meet a specific set of requirements. For more information, see the Supported
 * resources and requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getEBSVolumeRecommendations: API.OperationMethod<GetEBSVolumeRecommendationsRequest & RegionInput, GetEBSVolumeRecommendationsResponse, GetEBSVolumeRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEC2InstanceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon EC2 instance recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon Elastic Compute Cloud (Amazon EC2) instances that meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getEC2InstanceRecommendations: API.OperationMethod<GetEC2InstanceRecommendationsRequest & RegionInput, GetEC2InstanceRecommendationsResponse, GetEC2InstanceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEC2RecommendationProjectedMetricsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the projected utilization metrics of Amazon EC2 instance
 * recommendations.
 *
 * The `Cpu` and `Memory` metrics are the only projected
 * utilization metrics returned when you run this action. Additionally, the
 * `Memory` metric is returned only for resources that have the unified
 * CloudWatch agent installed on them. For more information, see Enabling Memory Utilization with the CloudWatch Agent.
 */
export declare const getEC2RecommendationProjectedMetrics: API.OperationMethod<GetEC2RecommendationProjectedMetricsRequest & RegionInput, GetEC2RecommendationProjectedMetricsResponse, GetEC2RecommendationProjectedMetricsError, Credentials | HttpClient.HttpClient>;
export type GetECSServiceRecommendationProjectedMetricsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the projected metrics of Amazon ECS service recommendations.
 */
export declare const getECSServiceRecommendationProjectedMetrics: API.OperationMethod<GetECSServiceRecommendationProjectedMetricsRequest & RegionInput, GetECSServiceRecommendationProjectedMetricsResponse, GetECSServiceRecommendationProjectedMetricsError, Credentials | HttpClient.HttpClient>;
export type GetECSServiceRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon ECS service recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon ECS services on
 * Fargate that meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getECSServiceRecommendations: API.OperationMethod<GetECSServiceRecommendationsRequest & RegionInput, GetECSServiceRecommendationsResponse, GetECSServiceRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetEffectiveRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the recommendation preferences that are in effect for a given resource, such
 * as enhanced infrastructure metrics. Considers all applicable preferences that you might
 * have set at the resource, account, and organization level.
 *
 * When you create a recommendation preference, you can set its status to
 * `Active` or `Inactive`. Use this action to view the
 * recommendation preferences that are in effect, or `Active`.
 */
export declare const getEffectiveRecommendationPreferences: API.OperationMethod<GetEffectiveRecommendationPreferencesRequest & RegionInput, GetEffectiveRecommendationPreferencesResponse, GetEffectiveRecommendationPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetEnrollmentStatusError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the enrollment (opt in) status of an account to the Compute Optimizer
 * service.
 *
 * If the account is the management account of an organization, this action also confirms
 * the enrollment status of member accounts of the organization. Use the GetEnrollmentStatusesForOrganization action to get detailed information
 * about the enrollment status of member accounts of an organization.
 */
export declare const getEnrollmentStatus: API.OperationMethod<GetEnrollmentStatusRequest & RegionInput, GetEnrollmentStatusResponse, GetEnrollmentStatusError, Credentials | HttpClient.HttpClient>;
export type GetEnrollmentStatusesForOrganizationError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the Compute Optimizer enrollment (opt-in) status of organization member
 * accounts, if your account is an organization management account.
 *
 * To get the enrollment status of standalone accounts, use the GetEnrollmentStatus action.
 */
export declare const getEnrollmentStatusesForOrganization: API.PaginatedOperationMethod<GetEnrollmentStatusesForOrganizationRequest & RegionInput, GetEnrollmentStatusesForOrganizationResponse, GetEnrollmentStatusesForOrganizationError, Credentials | HttpClient.HttpClient, AccountEnrollmentStatus>;
export type GetIdleRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns idle resource recommendations. Compute Optimizer generates recommendations for
 * idle resources that meet a specific set of requirements. For more information, see
 * Resource requirements in the
 * *Compute Optimizer User Guide*
 */
export declare const getIdleRecommendations: API.OperationMethod<GetIdleRecommendationsRequest & RegionInput, GetIdleRecommendationsResponse, GetIdleRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetLambdaFunctionRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | LimitExceededException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Lambda function recommendations.
 *
 * Compute Optimizer generates recommendations for functions that meet a specific set
 * of requirements. For more information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getLambdaFunctionRecommendations: API.PaginatedOperationMethod<GetLambdaFunctionRecommendationsRequest & RegionInput, GetLambdaFunctionRecommendationsResponse, GetLambdaFunctionRecommendationsError, Credentials | HttpClient.HttpClient, LambdaFunctionRecommendation>;
export type GetLicenseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns license recommendations for Amazon EC2 instances that run on a specific license.
 *
 * Compute Optimizer generates recommendations for licenses that meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getLicenseRecommendations: API.OperationMethod<GetLicenseRecommendationsRequest & RegionInput, GetLicenseRecommendationsResponse, GetLicenseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetRDSDatabaseRecommendationProjectedMetricsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the projected metrics of Aurora and RDS database recommendations.
 */
export declare const getRDSDatabaseRecommendationProjectedMetrics: API.OperationMethod<GetRDSDatabaseRecommendationProjectedMetricsRequest & RegionInput, GetRDSDatabaseRecommendationProjectedMetricsResponse, GetRDSDatabaseRecommendationProjectedMetricsError, Credentials | HttpClient.HttpClient>;
export type GetRDSDatabaseRecommendationsError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns Amazon Aurora and RDS database recommendations.
 *
 * Compute Optimizer generates recommendations for Amazon Aurora and RDS databases that
 * meet a specific set of requirements. For more
 * information, see the Supported resources and
 * requirements in the Compute Optimizer User
 * Guide.
 */
export declare const getRDSDatabaseRecommendations: API.OperationMethod<GetRDSDatabaseRecommendationsRequest & RegionInput, GetRDSDatabaseRecommendationsResponse, GetRDSDatabaseRecommendationsError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns existing recommendation preferences, such as enhanced infrastructure
 * metrics.
 *
 * Use the `scope` parameter to specify which preferences to return. You can
 * specify to return preferences for an organization, a specific account ID, or a specific
 * EC2 instance or Auto Scaling group Amazon Resource Name (ARN).
 *
 * For more information, see Activating
 * enhanced infrastructure metrics in the Compute Optimizer User
 * Guide.
 */
export declare const getRecommendationPreferences: API.PaginatedOperationMethod<GetRecommendationPreferencesRequest & RegionInput, GetRecommendationPreferencesResponse, GetRecommendationPreferencesError, Credentials | HttpClient.HttpClient, RecommendationPreferencesDetail>;
export type GetRecommendationSummariesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns the optimization findings for an account.
 *
 * It returns the number of:
 *
 * - Amazon EC2 instances in an account that are
 * `Underprovisioned`, `Overprovisioned`, or
 * `Optimized`.
 *
 * - EC2Auto Scaling groups in an account that are `NotOptimized`, or
 * `Optimized`.
 *
 * - Amazon EBS volumes in an account that are `NotOptimized`,
 * or `Optimized`.
 *
 * - Lambda functions in an account that are `NotOptimized`,
 * or `Optimized`.
 *
 * - Amazon ECS services in an account that are `Underprovisioned`,
 * `Overprovisioned`, or `Optimized`.
 *
 * - Commercial software licenses in an account that are `InsufficientMetrics`,
 * `NotOptimized` or `Optimized`.
 *
 * - Amazon Aurora and Amazon RDS databases in an account that are `Underprovisioned`,
 * `Overprovisioned`, `Optimized`, or `NotOptimized`.
 */
export declare const getRecommendationSummaries: API.PaginatedOperationMethod<GetRecommendationSummariesRequest & RegionInput, GetRecommendationSummariesResponse, GetRecommendationSummariesError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type PutRecommendationPreferencesError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a new recommendation preference or updates an existing recommendation
 * preference, such as enhanced infrastructure metrics.
 *
 * For more information, see Activating
 * enhanced infrastructure metrics in the Compute Optimizer User
 * Guide.
 */
export declare const putRecommendationPreferences: API.OperationMethod<PutRecommendationPreferencesRequest & RegionInput, PutRecommendationPreferencesResponse, PutRecommendationPreferencesError, Credentials | HttpClient.HttpClient>;
export type UpdateEnrollmentStatusError = AccessDeniedException | InternalServerException | InvalidParameterValueException | MissingAuthenticationToken | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the enrollment (opt in and opt out) status of an account to the Compute Optimizer service.
 *
 * If the account is a management account of an organization, this action can also be
 * used to enroll member accounts of the organization.
 *
 * You must have the appropriate permissions to opt in to Compute Optimizer, to view its
 * recommendations, and to opt out. For more information, see Controlling access with Amazon Web Services Identity and Access Management in the *Compute Optimizer User Guide*.
 *
 * When you opt in, Compute Optimizer automatically creates a service-linked role in your
 * account to access its data. For more information, see Using
 * Service-Linked Roles for Compute Optimizer in the *Compute Optimizer User Guide*.
 */
export declare const updateEnrollmentStatus: API.OperationMethod<UpdateEnrollmentStatusRequest & RegionInput, UpdateEnrollmentStatusResponse, UpdateEnrollmentStatusError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=compute-optimizer.d.ts.map