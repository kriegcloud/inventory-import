import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface ListRequestAction {
    /** Filters by the action type. */
    type?: string | undefined;
}
export interface ListRequestActor {
    /** Filters by the email address of the actor that made the change. */
    email?: string | undefined;
    /** Filters by the IP address of the request that made the change by specific IP address or valid CIDR Range. */
    ip?: string | undefined;
}
export type ListRequestDirection = "desc" | "asc";
export interface ListRequestZone {
    /** Filters by the name of the zone associated to the change. */
    name?: string | undefined;
}
export interface ListAuditLogsRequest {
    /** Identifier */
    accountId: string;
    /** Finds a specific log by its ID. */
    id?: string | undefined;
    action?: ListRequestAction | undefined;
    actor?: ListRequestActor | undefined;
    /** Limits the returned results to logs older than the specified date. A `full-date` that conforms to RFC3339. */
    before?: string | undefined;
    /** Changes the direction of the chronological sorting. */
    direction?: ListRequestDirection | (string & {}) | undefined;
    /** Indicates that this request is an export of logs in CSV format. */
    export?: boolean | undefined;
    /** Indicates whether or not to hide user level audit logs. */
    hideUserLogs?: boolean | undefined;
    /** Defines which page of results to return. */
    page?: number | undefined;
    /** Sets the number of results to return per page. */
    perPage?: number | undefined;
    /** Limits the returned results to logs newer than the specified date. A `full-date` that conforms to RFC3339. */
    since?: string | undefined;
    zone?: ListRequestZone | undefined;
}
export interface ListResultItemAction {
    /** A boolean that indicates if the action attempted was successful. */
    result?: boolean | null | undefined;
    /** A short string that describes the action that was performed. */
    type?: string | null | undefined;
}
export type ListResultItemActorType = "user" | "admin" | "Cloudflare";
export interface ListResultItemActor {
    /** The ID of the actor that performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null | undefined;
    /** The email of the user that performed the action. */
    email?: string | null | undefined;
    /** The IP address of the request that performed the action. */
    ip?: string | null | undefined;
    /** The type of actor, whether a User, Cloudflare Admin, or an Automated System. */
    type?: ListResultItemActorType | null | undefined;
}
export interface ListResultItemOwner {
    /** Identifier */
    id?: string | null | undefined;
}
export interface ListResultItemResource {
    /** An identifier for the resource that was affected by the action. */
    id?: string | null | undefined;
    /** A short string that describes the resource that was affected by the action. */
    type?: string | null | undefined;
}
export interface ListResultItem {
    /** A string that uniquely identifies the audit log. */
    id?: string | null | undefined;
    action?: ListResultItemAction | null | undefined;
    actor?: ListResultItemActor | null | undefined;
    /** The source of the event. */
    interface?: string | null | undefined;
    /** An object which can lend more context to the action being logged. This is a flexible value and varies between different actions. */
    metadata?: unknown | null | undefined;
    /** The new value of the resource that was modified. */
    newValue?: string | null | undefined;
    /** The value of the resource before it was modified. */
    oldValue?: string | null | undefined;
    owner?: ListResultItemOwner | null | undefined;
    resource?: ListResultItemResource | null | undefined;
    /** A UTC RFC3339 timestamp that specifies when the action being logged occured. */
    when?: string | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListAuditLogsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type ListAuditLogsError = CloudflareOpError;
/** Gets a list of audit logs for an account. Can be filtered by who made the change, on which zone, and the timeframe of the change. */
export declare const listAuditLogs: API.PaginatedOperationMethod<ListAuditLogsRequest, ListAuditLogsResponse, ListAuditLogsError, CloudflareOpContext, ListResultItem>;
//# sourceMappingURL=audit_logs.d.ts.map