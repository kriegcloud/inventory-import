import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AddSelectedRepoToOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface AddSelectedRepoToOrgSecretResponse {
}
export interface AddSelectedRepoToOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    repository_id: number;
}
export interface AddSelectedRepoToOrgVariableResponse {
}
/** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
export type CreateOrgVariableRequestVisibility = "all" | "private" | "selected";
/** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
export type CreateOrgVariableRequestSelectedRepositoryIdsList = Array<number>;
export interface CreateOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
    /** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
    visibility: CreateOrgVariableRequestVisibility | (string & {});
    /** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
    selected_repository_ids?: CreateOrgVariableRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrgVariableResponse = unknown;
/** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
export type CreateOrUpdateOrgSecretRequestVisibility = "all" | "private" | "selected";
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/agents/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/agents/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/agents/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface CreateOrUpdateOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/agents/secrets#get-an-organization-public-key) endpoint. */
    encrypted_value: string;
    /** ID of the key you used to encrypt the secret. */
    key_id: string;
    /** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
    visibility: CreateOrUpdateOrgSecretRequestVisibility | (string & {});
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/agents/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/agents/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/agents/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids?: CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrUpdateOrgSecretResponse = unknown;
export interface CreateOrUpdateRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/agents/secrets#get-a-repository-public-key) endpoint. */
    encrypted_value: string;
    /** ID of the key you used to encrypt the secret. */
    key_id: string;
}
export type CreateOrUpdateRepoSecretResponse = unknown;
export interface CreateRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
}
export type CreateRepoVariableResponse = unknown;
export interface DeleteOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteOrgSecretResponse {
}
export interface DeleteOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
}
export interface DeleteOrgVariableResponse {
}
export interface DeleteRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteRepoSecretResponse {
}
export interface DeleteRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
}
export interface DeleteRepoVariableResponse {
}
export interface GetOrgPublicKeyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The public key used for setting Actions Secrets. */
export interface ActionsPublicKey {
    /** The identifier for the key. */
    key_id: string;
    /** The Base64 encoded public key. */
    key: string;
    id?: number | undefined;
    url?: string | undefined;
    title?: string | undefined;
    created_at?: string | undefined;
}
export interface GetOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Visibility of a secret */
export type OrganizationActionsSecretVisibility = "all" | "private" | "selected";
/** Secrets for GitHub Actions for an organization. */
export interface OrganizationActionsSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
    /** Visibility of a secret */
    visibility: OrganizationActionsSecretVisibility;
    selected_repositories_url?: string | undefined;
}
export interface GetOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
}
/** Visibility of a variable */
export type OrganizationActionsVariableVisibility = "all" | "private" | "selected";
/** Organization variable for GitHub Actions. */
export interface OrganizationActionsVariable {
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
    /** The date and time at which the variable was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the variable was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
    /** Visibility of a variable */
    visibility: OrganizationActionsVariableVisibility;
    selected_repositories_url?: string | undefined;
}
export interface GetRepoPublicKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Set secrets for GitHub Actions. */
export interface ActionsSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
}
export interface GetRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
}
export interface ActionsVariable {
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
    /** The date and time at which the variable was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the variable was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
}
export interface ListOrgSecretsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgSecretsResponseSecretsList = Array<OrganizationActionsSecret>;
export interface ListOrgSecretsResponse {
    total_count: number;
    secrets: ListOrgSecretsResponseSecretsList;
}
export interface ListOrgVariablesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgVariablesResponseVariablesList = Array<OrganizationActionsVariable>;
export interface ListOrgVariablesResponse {
    total_count: number;
    variables: ListOrgVariablesResponseVariablesList;
}
export interface ListRepoOrganizationSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoOrganizationSecretsResponseSecretsList = Array<ActionsSecret>;
export interface ListRepoOrganizationSecretsResponse {
    total_count: number;
    secrets: ListRepoOrganizationSecretsResponseSecretsList;
}
export interface ListRepoOrganizationVariablesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoOrganizationVariablesResponseVariablesList = Array<ActionsVariable>;
export interface ListRepoOrganizationVariablesResponse {
    total_count: number;
    variables: ListRepoOrganizationVariablesResponseVariablesList;
}
export interface ListRepoSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoSecretsResponseSecretsList = Array<ActionsSecret>;
export interface ListRepoSecretsResponse {
    total_count: number;
    secrets: ListRepoSecretsResponseSecretsList;
}
export interface ListRepoVariablesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoVariablesResponseVariablesList = Array<ActionsVariable>;
export interface ListRepoVariablesResponse {
    total_count: number;
    variables: ListRepoVariablesResponseVariablesList;
}
export interface ListSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type ListSelectedReposForOrgSecretResponseRepositoriesList = Array<MinimalRepository>;
export interface ListSelectedReposForOrgSecretResponse {
    total_count: number;
    repositories: ListSelectedReposForOrgSecretResponseRepositoriesList;
}
export interface ListSelectedReposForOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListSelectedReposForOrgVariableResponseRepositoriesList = Array<MinimalRepository>;
export interface ListSelectedReposForOrgVariableResponse {
    total_count: number;
    repositories: ListSelectedReposForOrgVariableResponseRepositoriesList;
}
export interface RemoveSelectedRepoFromOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface RemoveSelectedRepoFromOrgSecretResponse {
}
export interface RemoveSelectedRepoFromOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    repository_id: number;
}
export interface RemoveSelectedRepoFromOrgVariableResponse {
}
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Add selected repository to an organization secret](https://docs.github.com/rest/agents/secrets#add-selected-repository-to-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/agents/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Add selected repository to an organization secret](https://docs.github.com/rest/agents/secrets#add-selected-repository-to-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/agents/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids: SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList;
}
export interface SetSelectedReposForOrgSecretResponse {
}
/** The IDs of the repositories that can access the organization variable. */
export type SetSelectedReposForOrgVariableRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedReposForOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The IDs of the repositories that can access the organization variable. */
    selected_repository_ids: SetSelectedReposForOrgVariableRequestSelectedRepositoryIdsList;
}
export interface SetSelectedReposForOrgVariableResponse {
}
/** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
export type UpdateOrgVariableRequestVisibility = "all" | "private" | "selected";
/** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
export type UpdateOrgVariableRequestSelectedRepositoryIdsList = Array<number>;
export interface UpdateOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value?: string | undefined;
    /** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
    visibility?: UpdateOrgVariableRequestVisibility | (string & {}) | undefined;
    /** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
    selected_repository_ids?: UpdateOrgVariableRequestSelectedRepositoryIdsList | undefined;
}
export interface UpdateOrgVariableResponse {
}
export interface UpdateRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value?: string | undefined;
}
export interface UpdateRepoVariableResponse {
}
export type AddSelectedRepoToOrgSecretError = GithubOpError;
/** Add selected repository to an organization secret Adds a repository to an organization secret when the `visibility` for repository access is set to `selected`. For more information about setting the visibility, see [Create or update an organization secret](https://docs.github.com/rest/agents/secrets#create-or-update-an-organization-secret). Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const addSelectedRepoToOrgSecret: API.OperationMethod<AddSelectedRepoToOrgSecretRequest, AddSelectedRepoToOrgSecretResponse, AddSelectedRepoToOrgSecretError, GithubOpContext>;
export type AddSelectedRepoToOrgVariableError = GithubOpError;
/** Add selected repository to an organization variable Adds a repository to an organization agent variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const addSelectedRepoToOrgVariable: API.OperationMethod<AddSelectedRepoToOrgVariableRequest, AddSelectedRepoToOrgVariableResponse, AddSelectedRepoToOrgVariableError, GithubOpContext>;
export type CreateOrgVariableError = GithubOpError;
/** Create an organization variable Creates an organization agent variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrgVariable: API.OperationMethod<CreateOrgVariableRequest, CreateOrgVariableResponse, CreateOrgVariableError, GithubOpContext>;
export type CreateOrUpdateOrgSecretError = GithubOpError;
/** Create or update an organization secret Creates or updates an organization secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateOrgSecret: API.OperationMethod<CreateOrUpdateOrgSecretRequest, CreateOrUpdateOrgSecretResponse, CreateOrUpdateOrgSecretError, GithubOpContext>;
export type CreateOrUpdateRepoSecretError = GithubOpError;
/** Create or update a repository secret Creates or updates a repository secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateRepoSecret: API.OperationMethod<CreateOrUpdateRepoSecretRequest, CreateOrUpdateRepoSecretResponse, CreateOrUpdateRepoSecretError, GithubOpContext>;
export type CreateRepoVariableError = GithubOpError;
/** Create a repository variable Creates a repository variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRepoVariable: API.OperationMethod<CreateRepoVariableRequest, CreateRepoVariableResponse, CreateRepoVariableError, GithubOpContext>;
export type DeleteOrgSecretError = GithubOpError;
/** Delete an organization secret Deletes a secret in an organization using the secret name. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteOrgSecret: API.OperationMethod<DeleteOrgSecretRequest, DeleteOrgSecretResponse, DeleteOrgSecretError, GithubOpContext>;
export type DeleteOrgVariableError = GithubOpError;
/** Delete an organization variable Deletes an organization agent variable using the variable name. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteOrgVariable: API.OperationMethod<DeleteOrgVariableRequest, DeleteOrgVariableResponse, DeleteOrgVariableError, GithubOpContext>;
export type DeleteRepoSecretError = GithubOpError;
/** Delete a repository secret Deletes a secret in a repository using the secret name. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteRepoSecret: API.OperationMethod<DeleteRepoSecretRequest, DeleteRepoSecretResponse, DeleteRepoSecretError, GithubOpContext>;
export type DeleteRepoVariableError = GithubOpError;
/** Delete a repository variable Deletes a repository variable using the variable name. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteRepoVariable: API.OperationMethod<DeleteRepoVariableRequest, DeleteRepoVariableResponse, DeleteRepoVariableError, GithubOpContext>;
export type GetOrgPublicKeyError = GithubOpError;
/** Get an organization public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const getOrgPublicKey: API.OperationMethod<GetOrgPublicKeyRequest, ActionsPublicKey, GetOrgPublicKeyError, GithubOpContext>;
export type GetOrgSecretError = GithubOpError;
/** Get an organization secret Gets a single organization secret without revealing its encrypted value. The authenticated user must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getOrgSecret: API.OperationMethod<GetOrgSecretRequest, OrganizationActionsSecret, GetOrgSecretError, GithubOpContext>;
export type GetOrgVariableError = GithubOpError;
/** Get an organization variable Gets a specific agent variable in an organization. The authenticated user must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getOrgVariable: API.OperationMethod<GetOrgVariableRequest, OrganizationActionsVariable, GetOrgVariableError, GithubOpContext>;
export type GetRepoPublicKeyError = GithubOpError;
/** Get a repository public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoPublicKey: API.OperationMethod<GetRepoPublicKeyRequest, ActionsPublicKey, GetRepoPublicKeyError, GithubOpContext>;
export type GetRepoSecretError = GithubOpError;
/** Get a repository secret Gets a single repository secret without revealing its encrypted value. The authenticated user must have collaborator access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoSecret: API.OperationMethod<GetRepoSecretRequest, ActionsSecret, GetRepoSecretError, GithubOpContext>;
export type GetRepoVariableError = GithubOpError;
/** Get a repository variable Gets a specific variable in a repository. The authenticated user must have collaborator access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoVariable: API.OperationMethod<GetRepoVariableRequest, ActionsVariable, GetRepoVariableError, GithubOpContext>;
export type ListOrgSecretsError = GithubOpError;
/** List organization secrets Lists all secrets available in an organization without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listOrgSecrets: API.PaginatedOperationMethod<ListOrgSecretsRequest, ListOrgSecretsResponse, ListOrgSecretsError, GithubOpContext, OrganizationActionsSecret>;
export type ListOrgVariablesError = GithubOpError;
/** List organization variables Lists all agent variables available in an organization. Returned variables include their values. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listOrgVariables: API.PaginatedOperationMethod<ListOrgVariablesRequest, ListOrgVariablesResponse, ListOrgVariablesError, GithubOpContext, OrganizationActionsVariable>;
export type ListRepoOrganizationSecretsError = GithubOpError;
/** List repository organization secrets Lists all organization secrets shared with a repository without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoOrganizationSecrets: API.PaginatedOperationMethod<ListRepoOrganizationSecretsRequest, ListRepoOrganizationSecretsResponse, ListRepoOrganizationSecretsError, GithubOpContext, ActionsSecret>;
export type ListRepoOrganizationVariablesError = GithubOpError;
/** List repository organization variables Lists all organization variables shared with a repository. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoOrganizationVariables: API.PaginatedOperationMethod<ListRepoOrganizationVariablesRequest, ListRepoOrganizationVariablesResponse, ListRepoOrganizationVariablesError, GithubOpContext, ActionsVariable>;
export type ListRepoSecretsError = GithubOpError;
/** List repository secrets Lists all secrets available in a repository without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoSecrets: API.PaginatedOperationMethod<ListRepoSecretsRequest, ListRepoSecretsResponse, ListRepoSecretsError, GithubOpContext, ActionsSecret>;
export type ListRepoVariablesError = GithubOpError;
/** List repository variables Lists all repository variables. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoVariables: API.PaginatedOperationMethod<ListRepoVariablesRequest, ListRepoVariablesResponse, ListRepoVariablesError, GithubOpContext, ActionsVariable>;
export type ListSelectedReposForOrgSecretError = GithubOpError;
/** List selected repositories for an organization secret Lists all repositories that have been selected when the `visibility` for repository access to a secret is set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listSelectedReposForOrgSecret: API.PaginatedOperationMethod<ListSelectedReposForOrgSecretRequest, ListSelectedReposForOrgSecretResponse, ListSelectedReposForOrgSecretError, GithubOpContext, MinimalRepository>;
export type ListSelectedReposForOrgVariableError = GithubOpError;
/** List selected repositories for an organization variable Lists all repositories that can access an organization agent variable that is available to selected repositories. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listSelectedReposForOrgVariable: API.PaginatedOperationMethod<ListSelectedReposForOrgVariableRequest, ListSelectedReposForOrgVariableResponse, ListSelectedReposForOrgVariableError, GithubOpContext, MinimalRepository>;
export type RemoveSelectedRepoFromOrgSecretError = GithubOpError;
/** Remove selected repository from an organization secret Removes a repository from an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/agents/secrets#create-or-update-an-organization-secret). Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const removeSelectedRepoFromOrgSecret: API.OperationMethod<RemoveSelectedRepoFromOrgSecretRequest, RemoveSelectedRepoFromOrgSecretResponse, RemoveSelectedRepoFromOrgSecretError, GithubOpContext>;
export type RemoveSelectedRepoFromOrgVariableError = GithubOpError;
/** Remove selected repository from an organization variable Removes a repository from an organization agent variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const removeSelectedRepoFromOrgVariable: API.OperationMethod<RemoveSelectedRepoFromOrgVariableRequest, RemoveSelectedRepoFromOrgVariableResponse, RemoveSelectedRepoFromOrgVariableError, GithubOpContext>;
export type SetSelectedReposForOrgSecretError = GithubOpError;
/** Set selected repositories for an organization secret Replaces all repositories for an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/agents/secrets#create-or-update-an-organization-secret). Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const setSelectedReposForOrgSecret: API.OperationMethod<SetSelectedReposForOrgSecretRequest, SetSelectedReposForOrgSecretResponse, SetSelectedReposForOrgSecretError, GithubOpContext>;
export type SetSelectedReposForOrgVariableError = GithubOpError;
/** Set selected repositories for an organization variable Replaces all repositories for an organization agent variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const setSelectedReposForOrgVariable: API.OperationMethod<SetSelectedReposForOrgVariableRequest, SetSelectedReposForOrgVariableResponse, SetSelectedReposForOrgVariableError, GithubOpContext>;
export type UpdateOrgVariableError = GithubOpError;
/** Update an organization variable Updates an organization agent variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const updateOrgVariable: API.OperationMethod<UpdateOrgVariableRequest, UpdateOrgVariableResponse, UpdateOrgVariableError, GithubOpContext>;
export type UpdateRepoVariableError = GithubOpError;
/** Update a repository variable Updates a repository variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const updateRepoVariable: API.OperationMethod<UpdateRepoVariableRequest, UpdateRepoVariableResponse, UpdateRepoVariableError, GithubOpContext>;
//# sourceMappingURL=agents.d.ts.map