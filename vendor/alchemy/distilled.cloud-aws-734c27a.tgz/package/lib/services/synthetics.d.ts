import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const RequestEntityTooLargeException_base: S.TaggedErrorClass<"RequestEntityTooLargeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestEntityTooLargeException extends /*@__PURE__*/ RequestEntityTooLargeException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GroupIdentifier = string;
export type CanaryArn = string;
export interface AssociateResourceRequest {
    GroupIdentifier: string;
    ResourceArn: string;
}
export interface AssociateResourceResponse {
}
export type CanaryName = string;
export type CodeHandler = string;
export type BlueprintType = string;
export type BlueprintTypes = string[];
export type DependencyType = "LambdaLayer" | (string & {});
export interface Dependency {
    Type?: DependencyType | undefined;
    Reference: string;
}
export type Dependencies = Dependency[];
export interface CanaryCodeInput {
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3Version?: string | undefined;
    ZipFile?: Uint8Array | undefined;
    Handler?: string | undefined;
    BlueprintTypes?: string[] | undefined;
    Dependencies?: Dependency[] | undefined;
}
export type RoleArn = string;
export type MaxOneYearInSeconds = number;
export type MaxRetries = number;
export interface RetryConfigInput {
    MaxRetries: number;
}
export interface CanaryScheduleInput {
    Expression: string;
    DurationInSeconds?: number | undefined;
    RetryConfig?: RetryConfigInput | undefined;
}
export type MaxFifteenMinutesInSeconds = number;
export type MaxSize3008 = number;
export type EnvironmentVariableName = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type EphemeralStorageSize = number;
export interface CanaryRunConfigInput {
    TimeoutInSeconds?: number | undefined;
    MemoryInMB?: number | undefined;
    ActiveTracing?: boolean | undefined;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    EphemeralStorage?: number | undefined;
}
export type MaxSize1024 = number;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface VpcConfigInput {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Ipv6AllowedForDualStack?: boolean | undefined;
}
export type ResourceToTag = "lambda-function" | (string & {});
export type ResourceList = ResourceToTag[];
export type ProvisionedResourceCleanupSetting = "AUTOMATIC" | "OFF" | (string & {});
export type BrowserType = "CHROME" | "FIREFOX" | (string & {});
export interface BrowserConfig {
    BrowserType?: BrowserType | undefined;
}
export type BrowserConfigs = BrowserConfig[];
export type Location = string;
export type KmsKeyArn = string;
export interface AddReplicaLocationInput {
    Location: string;
    VpcConfig?: VpcConfigInput | undefined;
    KmsKeyArn?: string | undefined;
}
export type AddReplicaLocations = AddReplicaLocationInput[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type EncryptionMode = "SSE_S3" | "SSE_KMS" | (string & {});
export interface S3EncryptionConfig {
    EncryptionMode?: EncryptionMode | undefined;
    KmsKeyArn?: string | undefined;
}
export interface ArtifactConfigInput {
    S3Encryption?: S3EncryptionConfig | undefined;
}
export interface CreateCanaryRequest {
    Name: string;
    Code: CanaryCodeInput;
    ArtifactS3Location: string;
    ExecutionRoleArn: string;
    Schedule: CanaryScheduleInput;
    RunConfig?: CanaryRunConfigInput | undefined;
    SuccessRetentionPeriodInDays?: number | undefined;
    FailureRetentionPeriodInDays?: number | undefined;
    RuntimeVersion: string;
    VpcConfig?: VpcConfigInput | undefined;
    ResourcesToReplicateTags?: ResourceToTag[] | undefined;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting | undefined;
    BrowserConfigs?: BrowserConfig[] | undefined;
    AddReplicaLocations?: AddReplicaLocationInput[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ArtifactConfig?: ArtifactConfigInput | undefined;
    KmsKeyArn?: string | undefined;
}
export type UUID = string;
export interface CanaryCodeOutput {
    SourceLocationArn?: string | undefined;
    Handler?: string | undefined;
    BlueprintTypes?: string[] | undefined;
    Dependencies?: Dependency[] | undefined;
}
export interface RetryConfigOutput {
    MaxRetries?: number | undefined;
}
export interface CanaryScheduleOutput {
    Expression?: string | undefined;
    DurationInSeconds?: number | undefined;
    RetryConfig?: RetryConfigOutput | undefined;
}
export interface CanaryRunConfigOutput {
    TimeoutInSeconds?: number | undefined;
    MemoryInMB?: number | undefined;
    ActiveTracing?: boolean | undefined;
    EphemeralStorage?: number | undefined;
}
export type CanaryState = "CREATING" | "READY" | "STARTING" | "RUNNING" | "UPDATING" | "STOPPING" | "STOPPED" | "ERROR" | "DELETING" | (string & {});
export type CanaryStateReasonCode = "INVALID_PERMISSIONS" | "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "UPDATE_PENDING" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE" | "ROLLBACK_COMPLETE" | "ROLLBACK_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "SYNC_DELETE_IN_PROGRESS" | (string & {});
export interface CanaryStatus {
    State?: CanaryState | undefined;
    StateReason?: string | undefined;
    StateReasonCode?: CanaryStateReasonCode | undefined;
}
export interface CanaryTimeline {
    Created?: Date | undefined;
    LastModified?: Date | undefined;
    LastStarted?: Date | undefined;
    LastStopped?: Date | undefined;
}
export type FunctionArn = string;
export type VpcId = string;
export interface VpcConfigOutput {
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Ipv6AllowedForDualStack?: boolean | undefined;
}
export type BaseScreenshotConfigIgnoreCoordinate = string;
export type BaseScreenshotIgnoreCoordinates = string[];
export interface BaseScreenshot {
    ScreenshotName: string;
    IgnoreCoordinates?: string[] | undefined;
}
export type BaseScreenshots = BaseScreenshot[];
export interface VisualReferenceOutput {
    BaseScreenshots?: BaseScreenshot[] | undefined;
    BaseCanaryRunId?: string | undefined;
    BrowserType?: BrowserType | undefined;
}
export interface EngineConfig {
    EngineArn?: string | undefined;
    BrowserType?: BrowserType | undefined;
}
export type EngineConfigs = EngineConfig[];
export type VisualReferencesOutput = VisualReferenceOutput[];
export type LocationType = "Primary" | "Replica" | (string & {});
export type ReplicationState = "InProgress" | "InSync" | "Inconsistent" | (string & {});
export interface ReplicationStatus {
    State?: ReplicationState | undefined;
    StateReason?: string | undefined;
    StateReasonCode?: string | undefined;
}
export interface Replica {
    Location?: string | undefined;
    ReplicationStatus?: ReplicationStatus | undefined;
    CanaryState?: CanaryState | undefined;
    LastModified?: Date | undefined;
    VpcConfig?: VpcConfigOutput | undefined;
}
export type Replicas = Replica[];
export interface MultiLocationConfig {
    LocationType?: LocationType | undefined;
    PrimaryLocation?: string | undefined;
    Replicas?: Replica[] | undefined;
    ReplicationState?: ReplicationState | undefined;
}
export interface ArtifactConfigOutput {
    S3Encryption?: S3EncryptionConfig | undefined;
}
export interface DryRunConfigOutput {
    DryRunId?: string | undefined;
    LastDryRunExecutionStatus?: string | undefined;
}
export interface Canary {
    Id?: string | undefined;
    Name?: string | undefined;
    Code?: CanaryCodeOutput | undefined;
    ExecutionRoleArn?: string | undefined;
    Schedule?: CanaryScheduleOutput | undefined;
    RunConfig?: CanaryRunConfigOutput | undefined;
    SuccessRetentionPeriodInDays?: number | undefined;
    FailureRetentionPeriodInDays?: number | undefined;
    Status?: CanaryStatus | undefined;
    Timeline?: CanaryTimeline | undefined;
    ArtifactS3Location?: string | undefined;
    EngineArn?: string | undefined;
    RuntimeVersion?: string | undefined;
    VpcConfig?: VpcConfigOutput | undefined;
    VisualReference?: VisualReferenceOutput | undefined;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting | undefined;
    BrowserConfigs?: BrowserConfig[] | undefined;
    EngineConfigs?: EngineConfig[] | undefined;
    VisualReferences?: VisualReferenceOutput[] | undefined;
    MultiLocationConfig?: MultiLocationConfig | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ArtifactConfig?: ArtifactConfigOutput | undefined;
    KmsKeyArn?: string | undefined;
    DryRunConfig?: DryRunConfigOutput | undefined;
}
export interface CreateCanaryResponse {
    Canary?: Canary | undefined;
}
export type GroupName = string;
export interface CreateGroupRequest {
    Name: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type GroupArn = string;
export interface Group {
    Id?: string | undefined;
    Name?: string | undefined;
    Arn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface CreateGroupResponse {
    Group?: Group | undefined;
}
export interface DeleteCanaryRequest {
    Name: string;
    DeleteLambda?: boolean | undefined;
}
export interface DeleteCanaryResponse {
}
export interface DeleteGroupRequest {
    GroupIdentifier: string;
}
export interface DeleteGroupResponse {
}
export type Token = string;
export type MaxCanaryResults = number;
export type DescribeCanariesNameFilter = string[];
export interface DescribeCanariesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Names?: string[] | undefined;
}
export type Canaries = Canary[];
export interface DescribeCanariesResponse {
    Canaries?: Canary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxSize100 = number;
export type DescribeCanariesLastRunNameFilter = string[];
export interface DescribeCanariesLastRunRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Names?: string[] | undefined;
    BrowserType?: BrowserType | undefined;
}
export type RetryAttempt = number;
export type CanaryRunState = "RUNNING" | "PASSED" | "FAILED" | (string & {});
export type CanaryRunStateReasonCode = "CANARY_FAILURE" | "EXECUTION_FAILURE" | (string & {});
export type CanaryRunTestResult = "PASSED" | "FAILED" | "UNKNOWN" | (string & {});
export interface CanaryRunStatus {
    State?: CanaryRunState | undefined;
    StateReason?: string | undefined;
    StateReasonCode?: CanaryRunStateReasonCode | undefined;
    TestResult?: CanaryRunTestResult | undefined;
}
export interface CanaryRunTimeline {
    Started?: Date | undefined;
    Completed?: Date | undefined;
    MetricTimestampForRunAndRetries?: Date | undefined;
}
export interface CanaryDryRunConfigOutput {
    DryRunId?: string | undefined;
}
export interface CanaryRun {
    Id?: string | undefined;
    ScheduledRunId?: string | undefined;
    RetryAttempt?: number | undefined;
    Name?: string | undefined;
    Status?: CanaryRunStatus | undefined;
    Timeline?: CanaryRunTimeline | undefined;
    ArtifactS3Location?: string | undefined;
    DryRunConfig?: CanaryDryRunConfigOutput | undefined;
    BrowserType?: BrowserType | undefined;
    Location?: string | undefined;
}
export interface CanaryLastRun {
    CanaryName?: string | undefined;
    LastRun?: CanaryRun | undefined;
}
export type CanariesLastRun = CanaryLastRun[];
export interface DescribeCanariesLastRunResponse {
    CanariesLastRun?: CanaryLastRun[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeRuntimeVersionsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface RuntimeVersion {
    VersionName?: string | undefined;
    Description?: string | undefined;
    ReleaseDate?: Date | undefined;
    DeprecationDate?: Date | undefined;
}
export type RuntimeVersionList = RuntimeVersion[];
export interface DescribeRuntimeVersionsResponse {
    RuntimeVersions?: RuntimeVersion[] | undefined;
    NextToken?: string | undefined;
}
export interface DisassociateResourceRequest {
    GroupIdentifier: string;
    ResourceArn: string;
}
export interface DisassociateResourceResponse {
}
export interface GetCanaryRequest {
    Name: string;
    DryRunId?: string | undefined;
}
export interface GetCanaryResponse {
    Canary?: Canary | undefined;
}
export type RunType = "CANARY_RUN" | "DRY_RUN" | (string & {});
export interface GetCanaryRunsRequest {
    Name: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    DryRunId?: string | undefined;
    RunType?: RunType | undefined;
}
export type CanaryRuns = CanaryRun[];
export interface GetCanaryRunsResponse {
    CanaryRuns?: CanaryRun[] | undefined;
    NextToken?: string | undefined;
}
export interface GetGroupRequest {
    GroupIdentifier: string;
}
export interface GetGroupResponse {
    Group?: Group | undefined;
}
export type PaginationToken = string;
export type MaxGroupResults = number;
export interface ListAssociatedGroupsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ResourceArn: string;
}
export interface GroupSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Arn?: string | undefined;
}
export type GroupSummaryList = GroupSummary[];
export interface ListAssociatedGroupsResponse {
    Groups?: GroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupResourcesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    GroupIdentifier: string;
}
export type StringList = string[];
export interface ListGroupResourcesResponse {
    Resources?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListGroupsResponse {
    Groups?: GroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartCanaryRequest {
    Name: string;
}
export interface StartCanaryResponse {
}
export interface VisualReferenceInput {
    BaseScreenshots?: BaseScreenshot[] | undefined;
    BaseCanaryRunId: string;
    BrowserType?: BrowserType | undefined;
}
export type VisualReferences = VisualReferenceInput[];
export interface StartCanaryDryRunRequest {
    Name: string;
    Code?: CanaryCodeInput | undefined;
    RuntimeVersion?: string | undefined;
    RunConfig?: CanaryRunConfigInput | undefined;
    VpcConfig?: VpcConfigInput | undefined;
    ExecutionRoleArn?: string | undefined;
    SuccessRetentionPeriodInDays?: number | undefined;
    FailureRetentionPeriodInDays?: number | undefined;
    VisualReference?: VisualReferenceInput | undefined;
    ArtifactS3Location?: string | undefined;
    ArtifactConfig?: ArtifactConfigInput | undefined;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting | undefined;
    BrowserConfigs?: BrowserConfig[] | undefined;
    VisualReferences?: VisualReferenceInput[] | undefined;
}
export interface StartCanaryDryRunResponse {
    DryRunConfig?: DryRunConfigOutput | undefined;
}
export interface StopCanaryRequest {
    Name: string;
}
export interface StopCanaryResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type RemoveReplicaLocations = string[];
export interface UpdateCanaryRequest {
    Name: string;
    Code?: CanaryCodeInput | undefined;
    ExecutionRoleArn?: string | undefined;
    RuntimeVersion?: string | undefined;
    Schedule?: CanaryScheduleInput | undefined;
    RunConfig?: CanaryRunConfigInput | undefined;
    SuccessRetentionPeriodInDays?: number | undefined;
    FailureRetentionPeriodInDays?: number | undefined;
    VpcConfig?: VpcConfigInput | undefined;
    VisualReference?: VisualReferenceInput | undefined;
    ArtifactS3Location?: string | undefined;
    ArtifactConfig?: ArtifactConfigInput | undefined;
    ProvisionedResourceCleanup?: ProvisionedResourceCleanupSetting | undefined;
    DryRunId?: string | undefined;
    VisualReferences?: VisualReferenceInput[] | undefined;
    BrowserConfigs?: BrowserConfig[] | undefined;
    AddReplicaLocations?: AddReplicaLocationInput[] | undefined;
    RemoveReplicaLocations?: string[] | undefined;
    KmsKeyArn?: string | undefined;
}
export interface UpdateCanaryResponse {
}
export type ErrorMessage = string;
export type AssociateResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Associates a canary with a group. Using groups can help you with
 * managing and automating your canaries, and you can also view aggregated run results and statistics
 * for all canaries in a group.
 *
 * You must run this operation in the Region where the canary exists.
 */
export declare const associateResource: API.OperationMethod<AssociateResourceRequest & RegionInput, AssociateResourceResponse, AssociateResourceError, Credentials | HttpClient.HttpClient>;
export type CreateCanaryError = InternalServerException | RequestEntityTooLargeException | ValidationException | CommonErrors;
/**
 * Creates a canary. Canaries are scripts that monitor your endpoints and APIs from the
 * outside-in. Canaries help you check the availability and latency of your web services and
 * troubleshoot anomalies by investigating load time data, screenshots of the UI, logs, and
 * metrics. You can set up a canary to run continuously or just once.
 *
 * Do not use `CreateCanary` to modify an existing canary. Use UpdateCanary instead.
 *
 * To create canaries, you must have the `CloudWatchSyntheticsFullAccess` policy.
 * If you are creating a new IAM role for the canary, you also need the
 * `iam:CreateRole`, `iam:CreatePolicy` and
 * `iam:AttachRolePolicy` permissions. For more information, see Necessary
 * Roles and Permissions.
 *
 * Do not include secrets or proprietary information in your canary names. The canary name
 * makes up part of the Amazon Resource Name (ARN) for the canary, and the ARN is included in
 * outbound calls over the internet. For more information, see Security
 * Considerations for Synthetics Canaries.
 */
export declare const createCanary: API.OperationMethod<CreateCanaryRequest & RegionInput, CreateCanaryResponse, CreateCanaryError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a group which you can use to associate canaries with each other, including cross-Region
 * canaries. Using groups can help you with
 * managing and automating your canaries, and you can also view aggregated run results and statistics
 * for all canaries in a group.
 *
 * Groups are global resources. When you create a group, it is replicated across Amazon Web Services Regions, and
 * you can view it and add canaries to it from any Region.
 * Although the group ARN format reflects the Region name where it was created, a group is not constrained to any Region.
 * This means that you can put canaries from multiple Regions into the same group, and then use
 * that group to view and manage all of those canaries in a single view.
 *
 * Groups are supported in all Regions except the Regions that are disabled by default. For more information
 * about these Regions, see Enabling a Region.
 *
 * Each group can contain as many as 10 canaries. You can have as many as 20 groups in your account. Any single canary
 * can be a member of up to 10 groups.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteCanaryError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Permanently deletes the specified canary.
 *
 * If the canary's `ProvisionedResourceCleanup` field is set to `AUTOMATIC`
 * or you specify `DeleteLambda` in this operation as `true`, CloudWatch Synthetics also deletes
 * the Lambda functions and layers that are used by the canary.
 *
 * Other resources used and created by the canary are not automatically deleted.
 * After you delete a canary, you
 * should also delete the following:
 *
 * - The CloudWatch alarms created for this canary. These alarms have a name of
 * Synthetics-Alarm-*first-198-characters-of-canary-name*-*canaryId*-*alarm number*
 *
 * - Amazon S3 objects and buckets, such as the canary's artifact location.
 *
 * - IAM roles created for the canary. If they were created in the console, these roles
 * have the name
 * role/service-role/CloudWatchSyntheticsRole-*First-21-Characters-of-CanaryName*
 *
 * - CloudWatch Logs log groups created for the canary. These logs groups have the name
 * /aws/lambda/cwsyn-*First-21-Characters-of-CanaryName*
 *
 * Before you delete a canary, you might want to use `GetCanary` to display
 * the information about this canary. Make
 * note of the information returned by this operation so that you can delete these resources
 * after you delete the canary.
 */
export declare const deleteCanary: API.OperationMethod<DeleteCanaryRequest & RegionInput, DeleteCanaryResponse, DeleteCanaryError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a group. The group doesn't need to be empty to be deleted. If there are canaries in the group,
 * they are not deleted when you delete the group.
 *
 * Groups are a global resource that appear in all Regions, but the request to delete a group
 * must be made from its home Region. You can find the home Region of a group within its ARN.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeCanariesError = InternalServerException | ValidationException | CommonErrors;
/**
 * This operation returns a list of the canaries in your account, along with full details
 * about each canary.
 *
 * This operation supports resource-level authorization using an IAM policy and
 * the `Names` parameter. If you specify the `Names` parameter, the operation is successful only if you have authorization to view
 * all the canaries that you specify in your request. If you do not have permission to view any of
 * the canaries, the request fails with a 403 response.
 *
 * You are required to use the `Names` parameter if you are logged on to a user or role that has an
 * IAM policy that restricts which canaries that you are allowed to view. For more information,
 * see
 * Limiting a user to viewing specific canaries.
 */
export declare const describeCanaries: API.PaginatedOperationMethod<DescribeCanariesRequest & RegionInput, DescribeCanariesResponse, DescribeCanariesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeCanariesLastRunError = InternalServerException | ValidationException | CommonErrors;
/**
 * Use this operation to see information from the most recent run of each canary that you have created.
 *
 * This operation supports resource-level authorization using an IAM policy and
 * the `Names` parameter. If you specify the `Names` parameter, the operation is successful only if you have authorization to view
 * all the canaries that you specify in your request. If you do not have permission to view any of
 * the canaries, the request fails with a 403 response.
 *
 * You are required to use the `Names` parameter if you are logged on to a user or role that has an
 * IAM policy that restricts which canaries that you are allowed to view. For more information,
 * see
 * Limiting a user to viewing specific canaries.
 */
export declare const describeCanariesLastRun: API.PaginatedOperationMethod<DescribeCanariesLastRunRequest & RegionInput, DescribeCanariesLastRunResponse, DescribeCanariesLastRunError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRuntimeVersionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of Synthetics canary runtime versions. For more information,
 * see
 * Canary Runtime Versions.
 */
export declare const describeRuntimeVersions: API.PaginatedOperationMethod<DescribeRuntimeVersionsRequest & RegionInput, DescribeRuntimeVersionsResponse, DescribeRuntimeVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DisassociateResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a canary from a group. You must run this operation in the Region where the canary exists.
 */
export declare const disassociateResource: API.OperationMethod<DisassociateResourceRequest & RegionInput, DisassociateResourceResponse, DisassociateResourceError, Credentials | HttpClient.HttpClient>;
export type GetCanaryError = InternalServerException | ValidationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves complete information about one canary. You must specify
 * the name of the canary that you want. To get a list of canaries
 * and their names, use DescribeCanaries.
 */
export declare const getCanary: API.OperationMethod<GetCanaryRequest & RegionInput, GetCanaryResponse, GetCanaryError, Credentials | HttpClient.HttpClient>;
export type GetCanaryRunsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a list of runs for a specified canary.
 */
export declare const getCanaryRuns: API.PaginatedOperationMethod<GetCanaryRunsRequest & RegionInput, GetCanaryRunsResponse, GetCanaryRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about one group. Groups are a global resource, so you can use this operation from
 * any Region.
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest & RegionInput, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedGroupsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of the groups that the specified canary is associated with. The canary
 * that you specify must be in the current Region.
 */
export declare const listAssociatedGroups: API.PaginatedOperationMethod<ListAssociatedGroupsRequest & RegionInput, ListAssociatedGroupsResponse, ListAssociatedGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupResourcesError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * This operation returns a list of the ARNs of the canaries that are associated with the specified group.
 */
export declare const listGroupResources: API.PaginatedOperationMethod<ListGroupResourcesRequest & RegionInput, ListGroupResourcesResponse, ListGroupResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of all groups in the account, displaying their names, unique IDs, and ARNs. The groups
 * from all Regions are returned.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | ConflictException | InternalFailureException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Displays the tags associated with a canary or group.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartCanaryError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Use this operation to run a canary that has already been created.
 * The frequency of the canary runs is determined by the value of the canary's `Schedule`. To see a canary's schedule,
 * use GetCanary.
 */
export declare const startCanary: API.OperationMethod<StartCanaryRequest & RegionInput, StartCanaryResponse, StartCanaryError, Credentials | HttpClient.HttpClient>;
export type StartCanaryDryRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Use this operation to start a dry run for a canary that has already been created
 */
export declare const startCanaryDryRun: API.OperationMethod<StartCanaryDryRunRequest & RegionInput, StartCanaryDryRunResponse, StartCanaryDryRunError, Credentials | HttpClient.HttpClient>;
export type StopCanaryError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops the canary to prevent all future runs. If the canary is currently running,the
 * run that is in progress completes on its own, publishes metrics, and uploads artifacts, but
 * it is not recorded in Synthetics as a completed run.
 *
 * You can use `StartCanary` to start it running again
 * with the canary's current schedule at any point in the future.
 */
export declare const stopCanary: API.OperationMethod<StopCanaryRequest & RegionInput, StopCanaryResponse, StopCanaryError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | InternalFailureException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified canary or group.
 *
 * Tags can help you organize and categorize your
 * resources. You can also use them to scope user permissions, by granting a user permission to access or change only resources with
 * certain tag values.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters.
 *
 * You can use the `TagResource` action with a resource that already has tags. If you specify a new
 * tag key for the resource,
 * this tag is appended to the list of tags associated
 * with the resource. If you specify a tag key that is already associated with the resource, the new tag
 * value that you specify replaces
 * the previous value for that tag.
 *
 * You can associate as many as 50 tags with a canary or group.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | InternalFailureException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCanaryError = AccessDeniedException | ConflictException | InternalServerException | RequestEntityTooLargeException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a canary that has already been created.
 *
 * For multibrowser canaries, you can add or remove browsers by updating the browserConfig list in the update call. For example:
 *
 * - To add Firefox to a canary that currently uses Chrome, specify browserConfigs as [CHROME, FIREFOX]
 *
 * - To remove Firefox and keep only Chrome, specify browserConfigs as [CHROME]
 *
 * You can't use this operation to update the tags of an existing canary. To change the tags of an existing canary, use
 * TagResource.
 *
 * When you use the `dryRunId` field when updating a canary, the only other field you can provide is the `Schedule`. Adding any other field will thrown an exception.
 */
export declare const updateCanary: API.OperationMethod<UpdateCanaryRequest & RegionInput, UpdateCanaryResponse, UpdateCanaryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=synthetics.d.ts.map