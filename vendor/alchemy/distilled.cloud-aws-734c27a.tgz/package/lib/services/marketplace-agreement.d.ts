import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly requestId: any;
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly requestId: any;
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly requestId: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly requestId: any;
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly requestId: any;
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
    readonly resourceType: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly requestId: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly requestId: any;
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AgreementId = string;
export type AgreementCancellationRequestId = string;
export interface AcceptAgreementCancellationRequestInput {
    agreementId: string;
    agreementCancellationRequestId: string;
}
export type AgreementCancellationRequestStatus = "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "CANCELLED" | "VALIDATION_FAILED" | (string & {});
export type AgreementCancellationRequestReasonCode = "INCORRECT_TERMS_ACCEPTED" | "REPLACING_AGREEMENT" | "TEST_AGREEMENT" | "ALTERNATIVE_PROCUREMENT_CHANNEL" | "PRODUCT_DISCONTINUED" | "UNINTENDED_RENEWAL" | "BUYER_DISSATISFACTION" | "OTHER" | (string & {});
export type AgreementCancellationRequestDescription = string | redacted.Redacted<string>;
export interface AcceptAgreementCancellationRequestOutput {
    agreementId?: string | undefined;
    agreementCancellationRequestId?: string | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    reasonCode?: AgreementCancellationRequestReasonCode | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PaymentRequestId = string;
export type PurchaseOrderReference = string;
export interface AcceptAgreementPaymentRequestInput {
    paymentRequestId: string;
    agreementId: string;
    purchaseOrderReference?: string | undefined;
}
export type PaymentRequestStatus = "VALIDATING" | "VALIDATION_FAILED" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "CANCELLED" | (string & {});
export type PaymentRequestName = string;
export type PaymentRequestDescription = string | redacted.Redacted<string>;
export type PositiveAmountUpto8Decimals = string;
export type CurrencyCode = string;
export interface AcceptAgreementPaymentRequestOutput {
    paymentRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    chargeAmount?: string | undefined;
    currencyCode?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type AgreementRequestId = string;
export type ResourceId = string;
export type ChargeRevision = number;
export interface PurchaseOrder {
    chargeId: string;
    chargeRevision?: number | undefined;
    agreementId?: string | undefined;
    purchaseOrderReference?: string | undefined;
}
export type PurchaseOrders = PurchaseOrder[];
export interface AcceptAgreementRequestInput {
    agreementRequestId: string;
    purchaseOrders?: PurchaseOrder[] | undefined;
}
export interface AcceptAgreementRequestOutput {
    agreementId?: string | undefined;
}
export type InvoiceId = string;
export type BillingAdjustmentReasonCode = "INCORRECT_TERMS_ACCEPTED" | "INCORRECT_METERING" | "TEST_ENVIRONMENT_CHARGES" | "ALTERNATIVE_PROCUREMENT_CHANNEL" | "UNINTENDED_RENEWAL" | "BUYER_DISSATISFACTION" | "OTHER" | (string & {});
export type BillingAdjustmentDescription = string | redacted.Redacted<string>;
export type ClientToken = string;
export interface BatchCreateBillingAdjustmentRequestEntry {
    agreementId: string;
    originalInvoiceId: string;
    adjustmentAmount: string;
    currencyCode: string;
    adjustmentReasonCode: BillingAdjustmentReasonCode;
    description?: string | redacted.Redacted<string> | undefined;
    clientToken: string;
}
export type BatchCreateBillingAdjustmentRequestEntryList = BatchCreateBillingAdjustmentRequestEntry[];
export interface BatchCreateBillingAdjustmentRequestInput {
    billingAdjustmentRequestEntries: BatchCreateBillingAdjustmentRequestEntry[];
}
export type BillingAdjustmentRequestId = string;
export interface BatchCreateBillingAdjustmentItem {
    billingAdjustmentRequestId: string;
    clientToken: string;
}
export type BatchCreateBillingAdjustmentItemList = BatchCreateBillingAdjustmentItem[];
export type BillingAdjustmentErrorCode = "CONFLICT_EXCEPTION" | "VALIDATION_EXCEPTION" | "RESOURCE_NOT_FOUND_EXCEPTION" | "INTERNAL_FAILURE" | (string & {});
export interface BatchCreateBillingAdjustmentError {
    code: BillingAdjustmentErrorCode;
    message: string;
    clientToken: string;
}
export type BatchCreateBillingAdjustmentErrorList = BatchCreateBillingAdjustmentError[];
export interface BatchCreateBillingAdjustmentRequestOutput {
    items: BatchCreateBillingAdjustmentItem[];
    errors: BatchCreateBillingAdjustmentError[];
}
export interface CancelAgreementInput {
    agreementId: string;
}
export interface CancelAgreementOutput {
}
export type AgreementCancellationRequestCancellationReason = string | redacted.Redacted<string>;
export interface CancelAgreementCancellationRequestInput {
    agreementId: string;
    agreementCancellationRequestId: string;
    cancellationReason: string | redacted.Redacted<string>;
}
export type AgreementCancellationRequestStatusMessage = string;
export interface CancelAgreementCancellationRequestOutput {
    agreementCancellationRequestId?: string | undefined;
    agreementId?: string | undefined;
    reasonCode?: AgreementCancellationRequestReasonCode | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    statusMessage?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CancelAgreementPaymentRequestInput {
    paymentRequestId: string;
    agreementId: string;
}
export interface CancelAgreementPaymentRequestOutput {
    paymentRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    chargeAmount?: string | undefined;
    currencyCode?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type Intent = "NEW" | "AMEND" | "REPLACE" | (string & {});
export type TermId = string;
export type BoundedString = string;
export type ZeroValueInteger = number;
export interface Dimension {
    dimensionKey: string;
    dimensionValue: number;
}
export type DimensionList = Dimension[];
export interface ConfigurableUpfrontPricingTermConfiguration {
    selectorValue: string;
    dimensions: Dimension[];
}
export interface RenewalTermConfiguration {
    enableAutoRenew: boolean;
}
export type PaymentRequestApprovalStrategy = "AUTO_APPROVE_ON_EXPIRATION" | "WAIT_FOR_APPROVAL" | (string & {});
export type ISO8601Duration = string;
export interface VariablePaymentTermConfiguration {
    paymentRequestApprovalStrategy: PaymentRequestApprovalStrategy;
    expirationDuration?: string | undefined;
}
export type RequestedTermConfiguration = {
    configurableUpfrontPricingTermConfiguration: ConfigurableUpfrontPricingTermConfiguration;
    renewalTermConfiguration?: undefined;
    variablePaymentTermConfiguration?: undefined;
} | {
    configurableUpfrontPricingTermConfiguration?: undefined;
    renewalTermConfiguration: RenewalTermConfiguration;
    variablePaymentTermConfiguration?: undefined;
} | {
    configurableUpfrontPricingTermConfiguration?: undefined;
    renewalTermConfiguration?: undefined;
    variablePaymentTermConfiguration: VariablePaymentTermConfiguration;
};
export interface RequestedTerm {
    id: string;
    configuration?: RequestedTermConfiguration | undefined;
}
export type RequestedTermList = RequestedTerm[];
export type AgreementProposalId = string;
export type TaxEstimation = "DISABLED" | "ENABLED" | (string & {});
export interface TaxConfiguration {
    taxEstimation?: TaxEstimation | undefined;
}
export interface CreateAgreementRequestInput {
    clientToken?: string | undefined;
    intent: Intent;
    requestedTerms: RequestedTerm[];
    sourceAgreementIdentifier?: string | undefined;
    agreementProposalIdentifier?: string | undefined;
    taxConfiguration?: TaxConfiguration | undefined;
}
export type Timing = "ON_ACCEPTANCE" | "SCHEDULED" | "BILLING_PERIOD" | (string & {});
export interface TaxBreakdownItem {
    amount?: string | undefined;
    rate?: string | undefined;
    type?: string | undefined;
}
export type TaxBreakdown = TaxBreakdownItem[];
export interface EstimatedTaxes {
    breakdown?: TaxBreakdownItem[] | undefined;
    totalAmount?: string | undefined;
}
export interface ExpectedCharge {
    id?: string | undefined;
    time?: Date | undefined;
    amount?: string | undefined;
    amountAfterTax?: string | undefined;
    timing?: Timing | undefined;
    estimatedTaxes?: EstimatedTaxes | undefined;
}
export type ExpectedChargeList = ExpectedCharge[];
export interface ItemizedCharge {
    dimensionKey?: string | undefined;
    newQuantity?: number | undefined;
    oldQuantity?: number | undefined;
    chargeReference?: string | undefined;
    incrementalChargeAmount?: string | undefined;
}
export type ItemizedChargeList = ItemizedCharge[];
export interface InvoicingEntity {
    legalName?: string | undefined;
    branchName?: string | undefined;
}
export interface ChargeSummary {
    currencyCode?: string | undefined;
    newAgreementValue?: string | undefined;
    newAgreementValueAfterTax?: string | undefined;
    expectedCharges?: ExpectedCharge[] | undefined;
    estimatedTaxes?: EstimatedTaxes | undefined;
    itemizedCharges?: ItemizedCharge[] | undefined;
    invoicingEntity?: InvoicingEntity | undefined;
}
export interface CreateAgreementRequestOutput {
    agreementRequestId?: string | undefined;
    chargeSummary?: ChargeSummary | undefined;
}
export interface DescribeAgreementInput {
    agreementId: string;
}
export type AWSAccountId = string;
export interface Acceptor {
    accountId?: string | undefined;
}
export interface Proposer {
    accountId?: string | undefined;
}
export type AgreementType = string;
export interface EstimatedCharges {
    currencyCode?: string | undefined;
    agreementValue?: string | undefined;
}
export type AgreementResourceType = string;
export interface Resource {
    id?: string | undefined;
    type?: string | undefined;
}
export type Resources = Resource[];
export type OfferId = string;
export type OfferSetId = string;
export interface ProposalSummary {
    resources?: Resource[] | undefined;
    offerId?: string | undefined;
    offerSetId?: string | undefined;
}
export type AgreementStatus = "ACTIVE" | "ARCHIVED" | "CANCELLED" | "EXPIRED" | "RENEWED" | "REPLACED" | "ROLLED_BACK" | "SUPERSEDED" | "TERMINATED" | (string & {});
export type EndTimeBehaviorType = "RENEW" | "REPLACE" | "EXPIRE" | (string & {});
export type EndTimeBehaviorReasonCode = "PROPOSER_RENEW_OPTED_OUT" | "ACCEPTOR_RENEW_OPTED_OUT" | "NO_RENEWAL_TERM" | "RENEWAL_LIMIT_EXHAUSTED" | (string & {});
export interface RenewalSummary {
    offerId?: string | undefined;
}
export interface EndTimeBehavior {
    type: EndTimeBehaviorType;
    reasonCode?: EndTimeBehaviorReasonCode | undefined;
    renewalSummary?: RenewalSummary | undefined;
}
export interface FreeTrialSummary {
    trialEndTime?: Date | undefined;
}
export interface DescribeAgreementOutput {
    agreementId?: string | undefined;
    acceptor?: Acceptor | undefined;
    proposer?: Proposer | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    acceptanceTime?: Date | undefined;
    agreementType?: string | undefined;
    estimatedCharges?: EstimatedCharges | undefined;
    proposalSummary?: ProposalSummary | undefined;
    status?: AgreementStatus | undefined;
    initialAgreementId?: string | undefined;
    endTimeBehavior?: EndTimeBehavior | undefined;
    freeTrialSummary?: FreeTrialSummary | undefined;
}
export interface GetAgreementCancellationRequestInput {
    agreementCancellationRequestId: string;
    agreementId: string;
}
export interface GetAgreementCancellationRequestOutput {
    agreementCancellationRequestId?: string | undefined;
    agreementId?: string | undefined;
    reasonCode?: AgreementCancellationRequestReasonCode | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    statusMessage?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface GetAgreementEntitlementsInput {
    agreementId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type EntitlementType = string;
export type RegistrationToken = string;
export type AgreementEntitlementStatus = "PROVISIONED" | "SCHEDULED" | "PENDING" | "FAILED" | "DEPROVISIONED" | (string & {});
export type AgreementEntitlementStatusReasonCode = "PROVISIONING_IN_PROGRESS" | "FUTURE_START_DATE" | "INVALID_PAYMENT_INSTRUMENT" | "INCOMPATIBLE_CURRENCY" | "ACCOUNT_SUSPENDED" | "UNSUPPORTED_OPERATION" | "AGREEMENT_INACTIVE" | "AGREEMENT_ACTIVE" | "PRODUCT_RESTRICTED" | (string & {});
export type AwsArn = string;
export interface AgreementEntitlement {
    resource?: Resource | undefined;
    type?: string | undefined;
    registrationToken?: string | undefined;
    status?: AgreementEntitlementStatus | undefined;
    statusReasonCode?: AgreementEntitlementStatusReasonCode | undefined;
    licenseArn?: string | undefined;
}
export type AgreementEntitlementList = AgreementEntitlement[];
export interface GetAgreementEntitlementsOutput {
    agreementEntitlements?: AgreementEntitlement[] | undefined;
    nextToken?: string | undefined;
}
export interface GetAgreementPaymentRequestInput {
    paymentRequestId: string;
    agreementId: string;
}
export type PaymentRequestStatusMessage = string;
export type ChargeId = string;
export interface GetAgreementPaymentRequestOutput {
    paymentRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    statusMessage?: string | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    chargeId?: string | undefined;
    chargeAmount?: string | undefined;
    currencyCode?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetAgreementTermsInput {
    agreementId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type UnversionedTermType = string;
export interface DocumentItem {
    type?: string | undefined;
    url?: string | undefined;
    version?: string | undefined;
}
export type DocumentList = DocumentItem[];
export interface LegalTerm {
    type?: string | undefined;
    id?: string | undefined;
    documents?: DocumentItem[] | undefined;
}
export interface SupportTerm {
    type?: string | undefined;
    id?: string | undefined;
    refundPolicy?: string | undefined;
}
export type DayDuration = string;
export type PriceIncreasePercentage = string;
export interface FixedPercentage {
    value?: string | undefined;
}
export interface PercentageRange {
    minValue?: string | undefined;
    maxValue?: string | undefined;
    defaultValue?: string | undefined;
}
export type PriceIncrease = {
    fixedPercentage: FixedPercentage;
    percentageRange?: undefined;
} | {
    fixedPercentage?: undefined;
    percentageRange: PercentageRange;
};
export type OffsetDuration = string;
export type ChargePercentage = string;
export interface PaymentScheduleEntry {
    chargeDateOffset?: string | undefined;
    chargePercentage?: string | undefined;
    dayOfMonth?: number | undefined;
}
export type PaymentScheduleEntryList = PaymentScheduleEntry[];
export interface PaymentScheduleTermTemplate {
    schedule?: PaymentScheduleEntry[] | undefined;
}
export type TermTemplate = {
    paymentScheduleTermTemplate: PaymentScheduleTermTemplate;
};
export type TermTemplateList = TermTemplate[];
export interface RenewalTerm {
    type?: string | undefined;
    id?: string | undefined;
    configuration?: RenewalTermConfiguration | undefined;
    lockoutPeriod?: string | undefined;
    maxRenewals?: number | undefined;
    adjustmentDeadline?: string | undefined;
    priceIncrease?: PriceIncrease | undefined;
    termTemplates?: TermTemplate[] | undefined;
}
export interface RateCardItem {
    dimensionKey?: string | undefined;
    price?: string | undefined;
}
export type RateCardList = RateCardItem[];
export interface UsageBasedRateCardItem {
    rateCard?: RateCardItem[] | undefined;
}
export type UsageBasedRateCardList = UsageBasedRateCardItem[];
export interface UsageBasedPricingTerm {
    type?: string | undefined;
    id?: string | undefined;
    currencyCode?: string | undefined;
    rateCards?: UsageBasedRateCardItem[] | undefined;
}
export interface Selector {
    type?: string | undefined;
    value?: string | undefined;
}
export interface Constraints {
    multipleDimensionSelection?: string | undefined;
    quantityConfiguration?: string | undefined;
}
export interface ConfigurableUpfrontRateCardItem {
    selector?: Selector | undefined;
    constraints?: Constraints | undefined;
    rateCard?: RateCardItem[] | undefined;
}
export type ConfigurableUpfrontRateCardList = ConfigurableUpfrontRateCardItem[];
export interface ConfigurableUpfrontPricingTerm {
    type?: string | undefined;
    id?: string | undefined;
    currencyCode?: string | undefined;
    rateCards?: ConfigurableUpfrontRateCardItem[] | undefined;
    configuration?: ConfigurableUpfrontPricingTermConfiguration | undefined;
}
export interface ByolPricingTerm {
    type?: string | undefined;
    id?: string | undefined;
}
export interface RecurringPaymentTerm {
    type?: string | undefined;
    id?: string | undefined;
    currencyCode?: string | undefined;
    billingPeriod?: string | undefined;
    price?: string | undefined;
}
export interface ValidityTerm {
    type?: string | undefined;
    id?: string | undefined;
    agreementDuration?: string | undefined;
    agreementStartDate?: Date | undefined;
    agreementEndDate?: Date | undefined;
}
export interface ScheduleItem {
    chargeDate?: Date | undefined;
    chargeAmount?: string | undefined;
}
export type ScheduleList = ScheduleItem[];
export interface PaymentScheduleTerm {
    type?: string | undefined;
    id?: string | undefined;
    currencyCode?: string | undefined;
    schedule?: ScheduleItem[] | undefined;
}
export type PositiveIntegerWithDefaultValueOne = number;
export interface GrantItem {
    dimensionKey?: string | undefined;
    maxQuantity?: number | undefined;
}
export type GrantList = GrantItem[];
export interface FreeTrialPricingTerm {
    type?: string | undefined;
    id?: string | undefined;
    duration?: string | undefined;
    grants?: GrantItem[] | undefined;
}
export interface FixedUpfrontPricingTerm {
    type?: string | undefined;
    id?: string | undefined;
    currencyCode?: string | undefined;
    duration?: string | undefined;
    price?: string | undefined;
    grants?: GrantItem[] | undefined;
}
export interface VariablePaymentTerm {
    type?: string | undefined;
    id?: string | undefined;
    currencyCode?: string | undefined;
    maxTotalChargeAmount?: string | undefined;
    configuration?: VariablePaymentTermConfiguration | undefined;
}
export interface NetPaymentTerm {
    type?: string | undefined;
    id?: string | undefined;
    paymentDuePeriod?: string | undefined;
}
export type AcceptedTerm = {
    legalTerm: LegalTerm;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm: SupportTerm;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm: RenewalTerm;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm: UsageBasedPricingTerm;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm: ConfigurableUpfrontPricingTerm;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm: ByolPricingTerm;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm: RecurringPaymentTerm;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm: ValidityTerm;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm: PaymentScheduleTerm;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm: FreeTrialPricingTerm;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm: FixedUpfrontPricingTerm;
    variablePaymentTerm?: undefined;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm: VariablePaymentTerm;
    netPaymentTerm?: undefined;
} | {
    legalTerm?: undefined;
    supportTerm?: undefined;
    renewalTerm?: undefined;
    usageBasedPricingTerm?: undefined;
    configurableUpfrontPricingTerm?: undefined;
    byolPricingTerm?: undefined;
    recurringPaymentTerm?: undefined;
    validityTerm?: undefined;
    paymentScheduleTerm?: undefined;
    freeTrialPricingTerm?: undefined;
    fixedUpfrontPricingTerm?: undefined;
    variablePaymentTerm?: undefined;
    netPaymentTerm: NetPaymentTerm;
};
export type AcceptedTermList = AcceptedTerm[];
export interface GetAgreementTermsOutput {
    acceptedTerms?: AcceptedTerm[] | undefined;
    nextToken?: string | undefined;
}
export interface GetBillingAdjustmentRequestInput {
    agreementId: string;
    billingAdjustmentRequestId: string;
}
export type BillingAdjustmentStatus = "PENDING" | "VALIDATION_FAILED" | "COMPLETED" | (string & {});
export type BillingAdjustmentStatusMessage = string;
export interface GetBillingAdjustmentRequestOutput {
    billingAdjustmentRequestId: string;
    agreementId: string;
    adjustmentReasonCode: BillingAdjustmentReasonCode;
    description?: string | undefined;
    originalInvoiceId: string;
    adjustmentAmount: string;
    currencyCode: string;
    status: BillingAdjustmentStatus;
    statusMessage?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type PartyType = string;
export type Catalog = string;
export interface ListAgreementCancellationRequestsInput {
    partyType: string;
    agreementId?: string | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    agreementType?: string | undefined;
    catalog?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgreementCancellationRequestSummary {
    agreementCancellationRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    reasonCode?: AgreementCancellationRequestReasonCode | undefined;
    agreementType?: string | undefined;
    catalog?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type AgreementCancellationRequestSummaryList = AgreementCancellationRequestSummary[];
export interface ListAgreementCancellationRequestsOutput {
    nextToken?: string | undefined;
    items?: AgreementCancellationRequestSummary[] | undefined;
}
export interface ListAgreementChargesInput {
    catalog?: string | undefined;
    agreementId?: string | undefined;
    agreementType?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface Charge {
    id?: string | undefined;
    revision?: number | undefined;
    agreementId?: string | undefined;
    agreementType?: string | undefined;
    purchaseOrderReference?: string | undefined;
    currencyCode?: string | undefined;
    amount?: string | undefined;
    time?: Date | undefined;
}
export type Charges = Charge[];
export interface ListAgreementChargesOutput {
    items?: Charge[] | undefined;
    nextToken?: string | undefined;
}
export type LineItemGroupBy = "INVOICE_ID" | (string & {});
export type InvoiceType = "INVOICE" | "CREDIT_MEMO" | (string & {});
export interface InvoiceBillingPeriod {
    month: number;
    year: number;
}
export interface ListAgreementInvoiceLineItemsInput {
    agreementId: string;
    groupBy: LineItemGroupBy;
    invoiceId?: string | undefined;
    invoiceType?: InvoiceType | undefined;
    invoiceBillingPeriod?: InvoiceBillingPeriod | undefined;
    beforeIssuedTime?: Date | undefined;
    afterIssuedTime?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PricingCurrencyAmount {
    amount?: string | undefined;
    maxAdjustmentAmount?: string | undefined;
    currencyCode?: string | undefined;
}
export interface AgreementInvoiceLineItemGroupSummary {
    agreementId?: string | undefined;
    invoiceId?: string | undefined;
    pricingCurrencyAmount?: PricingCurrencyAmount | undefined;
    invoiceBillingPeriod?: InvoiceBillingPeriod | undefined;
    issuedTime?: Date | undefined;
    invoiceType?: InvoiceType | undefined;
    invoicingEntity?: InvoicingEntity | undefined;
}
export type AgreementInvoiceLineItemGroupSummaries = AgreementInvoiceLineItemGroupSummary[];
export interface ListAgreementInvoiceLineItemsOutput {
    agreementInvoiceLineItemGroupSummaries?: AgreementInvoiceLineItemGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAgreementPaymentRequestsInput {
    partyType: string;
    agreementType?: string | undefined;
    catalog?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PaymentRequestSummary {
    paymentRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    name?: string | undefined;
    chargeId?: string | undefined;
    chargeAmount?: string | undefined;
    currencyCode?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PaymentRequestSummaryList = PaymentRequestSummary[];
export interface ListAgreementPaymentRequestsOutput {
    nextToken?: string | undefined;
    items: PaymentRequestSummary[];
}
export interface ListBillingAdjustmentRequestsInput {
    agreementId?: string | undefined;
    status?: BillingAdjustmentStatus | undefined;
    createdAfter?: Date | undefined;
    createdBefore?: Date | undefined;
    maxResults?: number | undefined;
    catalog?: string | undefined;
    agreementType?: string | undefined;
    nextToken?: string | undefined;
}
export interface BillingAdjustmentSummary {
    billingAdjustmentRequestId: string;
    originalInvoiceId: string;
    adjustmentAmount: string;
    currencyCode: string;
    status: BillingAdjustmentStatus;
    agreementId: string;
    createdAt: Date;
    updatedAt: Date;
    agreementType: string;
    catalog: string;
}
export type BillingAdjustmentSummaryList = BillingAdjustmentSummary[];
export interface ListBillingAdjustmentRequestsOutput {
    nextToken?: string | undefined;
    items: BillingAdjustmentSummary[];
}
export type AgreementCancellationRequestRejectionReason = string | redacted.Redacted<string>;
export interface RejectAgreementCancellationRequestInput {
    agreementId: string;
    agreementCancellationRequestId: string;
    rejectionReason: string | redacted.Redacted<string>;
}
export interface RejectAgreementCancellationRequestOutput {
    agreementId?: string | undefined;
    agreementCancellationRequestId?: string | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    statusMessage?: string | undefined;
    reasonCode?: AgreementCancellationRequestReasonCode | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PaymentRequestRejectionReason = string;
export interface RejectAgreementPaymentRequestInput {
    paymentRequestId: string;
    agreementId: string;
    rejectionReason?: string | undefined;
}
export interface RejectAgreementPaymentRequestOutput {
    paymentRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    statusMessage?: string | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    chargeAmount?: string | undefined;
    currencyCode?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValueList = string[];
export interface Filter {
    name?: string | undefined;
    values?: string[] | undefined;
}
export type FilterList = Filter[];
export type SortBy = string;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface Sort {
    sortBy?: string | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface SearchAgreementsInput {
    catalog?: string | undefined;
    filters?: Filter[] | undefined;
    sort?: Sort | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface Entitlement {
    licenseArn?: string | undefined;
}
export type EntitlementList = Entitlement[];
export interface AgreementViewSummary {
    agreementId?: string | undefined;
    acceptanceTime?: Date | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    lastUpdateTime?: Date | undefined;
    agreementType?: string | undefined;
    acceptor?: Acceptor | undefined;
    proposer?: Proposer | undefined;
    proposalSummary?: ProposalSummary | undefined;
    status?: AgreementStatus | undefined;
    entitlements?: Entitlement[] | undefined;
    initialAgreementId?: string | undefined;
    endTimeBehaviorType?: EndTimeBehaviorType | undefined;
    endTimeBehaviorReasonCode?: EndTimeBehaviorReasonCode | undefined;
    freeTrialEndTime?: Date | undefined;
}
export type AgreementViewSummaryList = AgreementViewSummary[];
export interface SearchAgreementsOutput {
    agreementViewSummaries?: AgreementViewSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface SendAgreementCancellationRequestInput {
    agreementId: string;
    reasonCode: AgreementCancellationRequestReasonCode;
    clientToken?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface SendAgreementCancellationRequestOutput {
    agreementId?: string | undefined;
    agreementCancellationRequestId?: string | undefined;
    status?: AgreementCancellationRequestStatus | undefined;
    reasonCode?: AgreementCancellationRequestReasonCode | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface SendAgreementPaymentRequestInput {
    clientToken?: string | undefined;
    agreementId: string;
    termId: string;
    name: string;
    chargeAmount: string;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface SendAgreementPaymentRequestOutput {
    paymentRequestId?: string | undefined;
    agreementId?: string | undefined;
    status?: PaymentRequestStatus | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    chargeAmount?: string | undefined;
    currencyCode?: string | undefined;
    createdAt?: Date | undefined;
}
export interface UpdatePurchaseOrdersInput {
    purchaseOrders: PurchaseOrder[];
}
export interface UpdatePurchaseOrdersOutput {
}
export type RequestId = string;
export type ExceptionMessage = string;
export type AccessDeniedExceptionReason = "INVALID_ACCOUNT_STATE" | "DENIED_BY_PRIVATE_MARKETPLACE_POLICY" | "FAILED_KYC_COMPLIANCE" | "MISSING_MFA" | "INVALID_ACCESS" | (string & {});
export type ResourceType = "Agreement" | "AgreementRequest" | "AgreementProposal" | "Charge" | "PaymentRequest" | "Invoice" | "AgreementCancellationRequest" | "BillingAdjustmentRequest" | (string & {});
export type ValidationExceptionReason = "MISSING_BILLING_ADJUSTMENTS" | "BILLING_ADJUSTMENTS_LIMIT_EXCEEDED" | "MISSING_INVOICE_ID" | "INVALID_ADJUSTMENT_AMOUNT" | "MISSING_ADJUSTMENT_AMOUNT" | "INVALID_REASON_CODE" | "MISSING_REASON_CODE" | "MISSING_DESCRIPTION" | "INVALID_INVOICE_ADJUSTMENT_PERIOD" | "INVALID_CURRENCY_CODE" | "MISSING_CURRENCY_CODE" | "EXCEEDED_MAXIMUM_ADJUSTMENT_AMOUNT" | "MISSING_BILLING_ADJUSTMENT_REQUEST_ENTRY" | "MULTIPLE_AGREEMENT_IDS" | "INVALID_AGREEMENT_CANCELLATION_REQUEST_ID" | "MISSING_AGREEMENT_CANCELLATION_REQUEST_ID" | "MISSING_REASON" | "INVALID_REASON" | "INVALID_STATUS" | "INVALID_AGREEMENT_ID" | "MISSING_AGREEMENT_ID" | "INVALID_CATALOG" | "INVALID_FILTERS" | "INVALID_FILTER_NAME" | "MISSING_FILTER_NAME" | "INVALID_FILTER_VALUES" | "MISSING_FILTER_VALUES" | "INVALID_SORT_BY" | "INVALID_SORT_ORDER" | "INVALID_NEXT_TOKEN" | "INVALID_MAX_RESULTS" | "INVALID_TERM_ID" | "MISSING_TERM_ID" | "MISSING_NAME" | "INVALID_NAME" | "INVALID_DESCRIPTION" | "MISSING_CHARGE_AMOUNT" | "INVALID_CHARGE_AMOUNT" | "MISSING_PAYMENT_REQUEST_ID" | "INVALID_PAYMENT_REQUEST_ID" | "MISSING_PARTY_TYPE" | "INVALID_PARTY_TYPE" | "UNSUPPORTED_FILTERS" | "INVALID_CLIENT_TOKEN" | "INVALID_INTENT" | "MISSING_INTENT" | "INVALID_SOURCE_AGREEMENT_IDENTIFIER" | "MISSING_SOURCE_AGREEMENT_IDENTIFIER" | "INVALID_AGREEMENT_PROPOSAL_IDENTIFIER" | "MISSING_AGREEMENT_PROPOSAL_IDENTIFIER" | "INVALID_REQUESTED_TERMS" | "MISSING_REQUESTED_TERMS" | "INVALID_REQUESTED_TERM_ID" | "MISSING_REQUESTED_TERM_ID" | "INVALID_REQUESTED_TERM_CONFIGURATION" | "MISSING_REQUESTED_TERM_CONFIGURATION" | "INVALID_AGREEMENT_REQUEST_ID" | "MISSING_AGREEMENT_REQUEST_ID" | "INVALID_PURCHASE_ORDERS" | "MISSING_PURCHASE_ORDERS" | "INVALID_CHARGE_ID" | "MISSING_CHARGE_ID" | "INVALID_CHARGE_REVISION" | "MISSING_CHARGE_REVISION" | "INVALID_AGREEMENT_TYPE" | "INVALID_PURCHASE_ORDER_REFERENCE" | "INACTIVE_AGREEMENT" | "SUPERSEDED_AGREEMENT_PROPOSAL" | "EXPIRED_AGREEMENT_PROPOSAL" | "MISSING_MANDATORY_TERMS" | "INCOMPATIBLE_TERMS" | "MISSING_USAGE_AGREEMENT" | "INVALID_INCREMENTAL_CHARGE" | "MISSING_ACCOUNT_ADDRESS" | "UNSUPPORTED_ACTION" | "INVALID_REJECTION_REASON" | "INVALID_PAYMENT_REQUEST_STATUS" | "OTHER" | "DUPLICATE_CHARGES" | "UNSUPPORTED_ACCOUNT_PLAN" | "DUPLICATE_AGREEMENT_IN_ORGANIZATION" | "MISSING_PURCHASE_ORDER_REFERENCE" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AcceptAgreementCancellationRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows buyers (acceptors) to accept a cancellation request that is in `PENDING_APPROVAL` status. Once accepted, the cancellation request transitions to `APPROVED` status and the agreement cancellation will be processed.
 *
 * Only cancellation requests in `PENDING_APPROVAL` status can be accepted. A `ConflictException` is thrown if the cancellation request is in any other status.
 */
export declare const acceptAgreementCancellationRequest: API.OperationMethod<AcceptAgreementCancellationRequestInput & RegionInput, AcceptAgreementCancellationRequestOutput, AcceptAgreementCancellationRequestError, Credentials | HttpClient.HttpClient>;
export type AcceptAgreementPaymentRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows buyers (acceptors) to accept a payment request that is in `PENDING_APPROVAL` status. Once accepted, the payment request transitions to `APPROVED` status and the charge will be processed. Buyers can optionally provide a purchase order reference for their internal tracking.
 *
 * Only payment requests in `PENDING_APPROVAL` status can be accepted. A `ConflictException` is thrown if the payment request is in any other status.
 */
export declare const acceptAgreementPaymentRequest: API.OperationMethod<AcceptAgreementPaymentRequestInput & RegionInput, AcceptAgreementPaymentRequestOutput, AcceptAgreementPaymentRequestError, Credentials | HttpClient.HttpClient>;
export type AcceptAgreementRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts an agreement request to finalize the agreement. The acceptor can optionally provide purchase orders to associate with the agreement charges.
 */
export declare const acceptAgreementRequest: API.OperationMethod<AcceptAgreementRequestInput & RegionInput, AcceptAgreementRequestOutput, AcceptAgreementRequestError, Credentials | HttpClient.HttpClient>;
export type BatchCreateBillingAdjustmentRequestError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows sellers (proposers) to submit billing adjustment requests for one or more invoices within an agreement. Each entry in the batch specifies an invoice and the adjustment amount. The operation returns successfully created adjustment request IDs and any errors for entries that failed to process.
 *
 * Each entry requires a unique `clientToken` for idempotency.
 */
export declare const batchCreateBillingAdjustmentRequest: API.OperationMethod<BatchCreateBillingAdjustmentRequestInput & RegionInput, BatchCreateBillingAdjustmentRequestOutput, BatchCreateBillingAdjustmentRequestError, Credentials | HttpClient.HttpClient>;
export type CancelAgreementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows an acceptor to cancel an active agreement. Not all agreements are eligible for cancellation. Use the error response to determine why a cancellation request was rejected.
 */
export declare const cancelAgreement: API.OperationMethod<CancelAgreementInput & RegionInput, CancelAgreementOutput, CancelAgreementError, Credentials | HttpClient.HttpClient>;
export type CancelAgreementCancellationRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows sellers (proposers) to withdraw an existing agreement cancellation request that is in a pending state. Once cancelled, the cancellation request transitions to `CANCELLED` status and can no longer be approved or rejected by the buyer.
 *
 * Only cancellation requests in `PENDING_APPROVAL` status can be cancelled. A `ConflictException` is thrown if the cancellation request is in any other status.
 */
export declare const cancelAgreementCancellationRequest: API.OperationMethod<CancelAgreementCancellationRequestInput & RegionInput, CancelAgreementCancellationRequestOutput, CancelAgreementCancellationRequestError, Credentials | HttpClient.HttpClient>;
export type CancelAgreementPaymentRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows sellers (proposers) to cancel a payment request that is in `PENDING_APPROVAL` status. Once cancelled, the payment request transitions to `CANCELLED` status and can no longer be accepted or rejected by the buyer.
 *
 * Only payment requests in `PENDING_APPROVAL` status can be cancelled. A `ConflictException` is thrown if the payment request is in any other status.
 */
export declare const cancelAgreementPaymentRequest: API.OperationMethod<CancelAgreementPaymentRequestInput & RegionInput, CancelAgreementPaymentRequestOutput, CancelAgreementPaymentRequestError, Credentials | HttpClient.HttpClient>;
export type CreateAgreementRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an agreement request that acts as a quote for the terms you want to accept. The agreement request captures the requested terms, calculates charges, and returns a summary. Use `AcceptAgreementRequest` with the returned `agreementRequestId` to finalize the agreement.
 */
export declare const createAgreementRequest: API.OperationMethod<CreateAgreementRequestInput & RegionInput, CreateAgreementRequestOutput, CreateAgreementRequestError, Credentials | HttpClient.HttpClient>;
export type DescribeAgreementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides details about an agreement, such as the proposer, acceptor, start date, and end date.
 */
export declare const describeAgreement: API.OperationMethod<DescribeAgreementInput & RegionInput, DescribeAgreementOutput, DescribeAgreementError, Credentials | HttpClient.HttpClient>;
export type GetAgreementCancellationRequestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific agreement cancellation request. Both sellers (proposers) and buyers (acceptors) can use this operation to view cancellation requests associated with their agreements.
 */
export declare const getAgreementCancellationRequest: API.OperationMethod<GetAgreementCancellationRequestInput & RegionInput, GetAgreementCancellationRequestOutput, GetAgreementCancellationRequestError, Credentials | HttpClient.HttpClient>;
export type GetAgreementEntitlementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Obtains details about the entitlements of an agreement.
 */
export declare const getAgreementEntitlements: API.PaginatedOperationMethod<GetAgreementEntitlementsInput & RegionInput, GetAgreementEntitlementsOutput, GetAgreementEntitlementsError, Credentials | HttpClient.HttpClient, AgreementEntitlement>;
export type GetAgreementPaymentRequestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific payment request. Both sellers (proposers) and buyers (acceptors) can use this operation to view payment requests associated with their agreements. The response includes the current status, charge details, timestamps, and the charge ID if the request has been approved.
 *
 * The calling identity must be either the acceptor or proposer of the payment request. A `ResourceNotFoundException` is returned if the payment request does not exist.
 */
export declare const getAgreementPaymentRequest: API.OperationMethod<GetAgreementPaymentRequestInput & RegionInput, GetAgreementPaymentRequestOutput, GetAgreementPaymentRequestError, Credentials | HttpClient.HttpClient>;
export type GetAgreementTermsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Obtains details about the terms in an agreement that you participated in as proposer or acceptor.
 *
 * The details include:
 *
 * - `TermType` - The type of term, such as `LegalTerm`, `RenewalTerm`, or `ConfigurableUpfrontPricingTerm`.
 *
 * - `TermID` - The ID of the particular term, which is common between offer and agreement.
 *
 * - `TermPayload` - The key information contained in the term, such as the EULA for `LegalTerm` or pricing and dimensions for various pricing terms, such as `ConfigurableUpfrontPricingTerm` or `UsageBasedPricingTerm`.
 *
 * - `Configuration` - The buyer/acceptor's selection at the time of agreement creation, such as the number of units purchased for a dimension or setting the `EnableAutoRenew` flag.
 */
export declare const getAgreementTerms: API.PaginatedOperationMethod<GetAgreementTermsInput & RegionInput, GetAgreementTermsOutput, GetAgreementTermsError, Credentials | HttpClient.HttpClient, AcceptedTerm>;
export type GetBillingAdjustmentRequestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific billing adjustment request. Sellers (proposers) can use this operation to view the status and details of a billing adjustment request they submitted.
 */
export declare const getBillingAdjustmentRequest: API.OperationMethod<GetBillingAdjustmentRequestInput & RegionInput, GetBillingAdjustmentRequestOutput, GetBillingAdjustmentRequestError, Credentials | HttpClient.HttpClient>;
export type ListAgreementCancellationRequestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists agreement cancellation requests available to you as a seller or buyer. Both sellers (proposers) and buyers (acceptors) can use this operation to find cancellation requests by specifying their party type and applying optional filters.
 *
 * `PartyType` is a required parameter. A `ValidationException` is returned if `PartyType` is not provided.
 */
export declare const listAgreementCancellationRequests: API.PaginatedOperationMethod<ListAgreementCancellationRequestsInput & RegionInput, ListAgreementCancellationRequestsOutput, ListAgreementCancellationRequestsError, Credentials | HttpClient.HttpClient, AgreementCancellationRequestSummary>;
export type ListAgreementChargesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows acceptors to view charges and purchase orders that are associated with an agreement. The response includes details about all charges regardless of whether a purchase order is linked to each charge.
 */
export declare const listAgreementCharges: API.PaginatedOperationMethod<ListAgreementChargesInput & RegionInput, ListAgreementChargesOutput, ListAgreementChargesError, Credentials | HttpClient.HttpClient, Charge>;
export type ListAgreementInvoiceLineItemsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows sellers (proposers) to retrieve aggregated billing data from AWS Marketplace agreements using flexible grouping. Supports invoice-level aggregation with filtering by billing period, invoice type, and issued date.
 *
 * The `groupBy` parameter is required and supports only `INVOICE_ID` as a value. The `agreementId` parameter is required.
 */
export declare const listAgreementInvoiceLineItems: API.PaginatedOperationMethod<ListAgreementInvoiceLineItemsInput & RegionInput, ListAgreementInvoiceLineItemsOutput, ListAgreementInvoiceLineItemsError, Credentials | HttpClient.HttpClient, AgreementInvoiceLineItemGroupSummary>;
export type ListAgreementPaymentRequestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists payment requests available to you as a seller or buyer. Both sellers (proposers) and buyers (acceptors) can use this operation to find payment requests by specifying their party type and applying optional parameters.
 *
 * `PartyType` is a required parameter. A `ValidationException` is returned if `PartyType` is not provided. Pagination is supported through `maxResults` (1-50, default 50) and `nextToken` parameters.
 */
export declare const listAgreementPaymentRequests: API.PaginatedOperationMethod<ListAgreementPaymentRequestsInput & RegionInput, ListAgreementPaymentRequestsOutput, ListAgreementPaymentRequestsError, Credentials | HttpClient.HttpClient, PaymentRequestSummary>;
export type ListBillingAdjustmentRequestsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists billing adjustment requests for a specific agreement. Sellers (proposers) can use this operation to view all billing adjustment requests associated with an agreement.
 */
export declare const listBillingAdjustmentRequests: API.PaginatedOperationMethod<ListBillingAdjustmentRequestsInput & RegionInput, ListBillingAdjustmentRequestsOutput, ListBillingAdjustmentRequestsError, Credentials | HttpClient.HttpClient, BillingAdjustmentSummary>;
export type RejectAgreementCancellationRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows buyers (acceptors) to reject a cancellation request that is in `PENDING_APPROVAL` status. Once rejected, the cancellation request transitions to `REJECTED` status and the agreement remains active. Buyers must provide a reason for the rejection.
 *
 * Only cancellation requests in `PENDING_APPROVAL` status can be rejected. A `ConflictException` is thrown if the cancellation request is in any other status.
 */
export declare const rejectAgreementCancellationRequest: API.OperationMethod<RejectAgreementCancellationRequestInput & RegionInput, RejectAgreementCancellationRequestOutput, RejectAgreementCancellationRequestError, Credentials | HttpClient.HttpClient>;
export type RejectAgreementPaymentRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows buyers (acceptors) to reject a payment request that is in `PENDING_APPROVAL` status. Once rejected, the payment request transitions to `REJECTED` status and cannot be accepted. Buyers can optionally provide a reason for the rejection.
 *
 * Only payment requests in `PENDING_APPROVAL` status can be rejected. A `ConflictException` is thrown if the payment request is in any other status.
 */
export declare const rejectAgreementPaymentRequest: API.OperationMethod<RejectAgreementPaymentRequestInput & RegionInput, RejectAgreementPaymentRequestOutput, RejectAgreementPaymentRequestError, Credentials | HttpClient.HttpClient>;
export type SearchAgreementsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches across all agreements that a proposer or an acceptor has in AWS Marketplace. The search returns a list of agreements with basic agreement information.
 */
export declare const searchAgreements: API.PaginatedOperationMethod<SearchAgreementsInput & RegionInput, SearchAgreementsOutput, SearchAgreementsError, Credentials | HttpClient.HttpClient, AgreementViewSummary>;
export type SendAgreementCancellationRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows sellers (proposers) to submit a cancellation request for an active agreement. The cancellation request is created in `PENDING_APPROVAL` status, at which point the buyer can review it.
 */
export declare const sendAgreementCancellationRequest: API.OperationMethod<SendAgreementCancellationRequestInput & RegionInput, SendAgreementCancellationRequestOutput, SendAgreementCancellationRequestError, Credentials | HttpClient.HttpClient>;
export type SendAgreementPaymentRequestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows sellers (proposers) to submit a payment request to buyers (acceptors) for a specific charge amount for an agreement that includes a `VariablePaymentTerm`. The payment request is created in `PENDING_APPROVAL` status, at which point the buyer can accept or reject it.
 *
 * The agreement must be active and have a `VariablePaymentTerm` to support payment requests. The `chargeAmount` must not exceed the remaining available balance under the `VariablePaymentTerm` `maxTotalChargeAmount`.
 */
export declare const sendAgreementPaymentRequest: API.OperationMethod<SendAgreementPaymentRequestInput & RegionInput, SendAgreementPaymentRequestOutput, SendAgreementPaymentRequestError, Credentials | HttpClient.HttpClient>;
export type UpdatePurchaseOrdersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows acceptors to associate purchase orders with agreement charges after an agreement is created.
 */
export declare const updatePurchaseOrders: API.OperationMethod<UpdatePurchaseOrdersInput & RegionInput, UpdatePurchaseOrdersOutput, UpdatePurchaseOrdersError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=marketplace-agreement.d.ts.map