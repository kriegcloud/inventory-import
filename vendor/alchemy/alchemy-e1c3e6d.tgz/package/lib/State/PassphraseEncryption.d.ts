import * as Config from "effect/Config";
import * as Layer from "effect/Layer";
import * as Redacted from "effect/Redacted";
import { StateStoreError } from "./State.ts";
import { StateEncryption } from "./StateEncryption.ts";
export interface PassphraseEncryptionOptions {
    /**
     * The passphrase data keys are wrapped with.
     *
     * @default `Config.Redacted("ALCHEMY_STATE_PASSPHRASE")`
     */
    readonly passphrase?: Redacted.Redacted<string> | Config.Config<Redacted.Redacted<string>>;
    /**
     * Turn encryption off: write secrets in plaintext again, and decrypt each
     * stage's secrets as it loads. Deploy every stage with this set, then
     * remove the layer.
     *
     * @default false
     */
    readonly disable?: boolean;
}
/**
 * Encrypt the secrets in any state store with a passphrase.
 *
 * Each secret (a `Redacted` value: a minted token, a `Random` value) is
 * encrypted with AES-256-GCM under a data key before the store writes it, so
 * the store only ever holds ciphertext. The data key is wrapped with a key
 * derived from the passphrase by scrypt, and bound to its stack and stage. A
 * deploy derives one key per stage it writes, so the cost doesn't grow with
 * the number of secrets.
 *
 * Whoever has the passphrase can read every secret, and losing it loses
 * them, so keep it in a secret manager and hand it to deploys as a secret.
 * A key service such as AWS KMS (`AWS.stateEncryption()`) avoids sharing a
 * passphrase at all: access is an IAM grant, can be scoped to one stage,
 * and is logged.
 *
 * ### Encrypting with a Passphrase
 * **Example:** Cloudflare state, passphrase from `ALCHEMY_STATE_PASSPHRASE`
 * ```typescript
 * import { passphraseEncryption } from "alchemy/State/PassphraseEncryption";
 *
 * state: Cloudflare.state().pipe(Layer.provide(passphraseEncryption())),
 * ```
 *
 * **Example:** Passphrase from another config key
 * ```typescript
 * state: localState().pipe(
 *   Layer.provide(passphraseEncryption({ passphrase: Config.Redacted("STATE_KEY") })),
 * ),
 * ```
 *
 * @layer
 * @provides StateEncryption
 */
export declare const passphraseEncryption: (options?: PassphraseEncryptionOptions) => Layer.Layer<StateEncryption, StateStoreError, never>;
//# sourceMappingURL=PassphraseEncryption.d.ts.map