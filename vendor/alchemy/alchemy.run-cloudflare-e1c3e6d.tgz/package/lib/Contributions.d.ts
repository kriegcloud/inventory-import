import * as Contributions from "alchemy/Contributions";
import * as Flag from "effect/cli/Flag";
declare const _default: {
    readonly name: "cloudflare";
    readonly auth: Contributions.Lazy<import("effect/Layer").Layer<never, never, import("alchemy").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("alchemy/Auth/Credentials").CredentialsStore | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("effect/crypto/SecureRandom").SecureRandom>>;
    readonly stateStores: {
        readonly cloudflare: {
            readonly description: "State-store Worker in the profile's Cloudflare account";
            readonly flags: {
                name: Flag.Flag<string>;
                domain: Flag.Flag<string>;
            };
            readonly load: Contributions.Lazy<Contributions.StateStoreImpl<import("./Alchemist/StateStore.ts").CloudflareStateStoreOptions>>;
        };
    };
    readonly cli: {
        readonly provider: {
            readonly description: "Manage Cloudflare provider prerequisites";
            readonly load: Contributions.Lazy<import("effect/cli/Command").Command<"cloudflare", {} | {}, {}, import("alchemy/Alchemist/Errors").AlchemistInvalidInput | import("@distilled.cloud/iceberg").BadGateway | import("@distilled.cloud/cloudflare/Errors").CloudflareError | import("@distilled.cloud/cloudflare/Errors").CloudflareHttpError | import("@distilled.cloud/cloudflare/Errors").CloudflareParseError | import("@distilled.cloud/cloudflare/Errors").CloudflareRateLimited | import("./Alchemist/Token.ts").CloudflareTokenError | import("effect/Config").ConfigError | import("@distilled.cloud/iceberg").ConfigError | import("alchemy/Cli/commands/confirm").ConfirmationDeclined | import("@distilled.cloud/iceberg").Forbidden | import("@distilled.cloud/iceberg").GatewayTimeout | import("effect/http/HttpClientError").HttpClientError | import("@distilled.cloud/iceberg").InternalServerError | import("@distilled.cloud/core/protocol-http").InvalidInput | import("@distilled.cloud/cloudflare/Errors").InvalidRoute | import("@distilled.cloud/cloudflare/user").InvalidRoute | import("@distilled.cloud/cloudflare/user").InvalidTokenName | import("alchemy/Interaction").NonInteractiveTerminal | import("@distilled.cloud/cloudflare/Credentials").OAuthRefreshError | import("@distilled.cloud/cloudflare/user").PermissionGroupNotFound | import("effect/PlatformError").PlatformError | import("@distilled.cloud/core/sdk-error").SdkError | import("@distilled.cloud/iceberg").ServiceUnavailable | import("alchemy/Interaction").TerminalCancelled | import("@distilled.cloud/iceberg").TooManyRequests | import("@distilled.cloud/iceberg").Unauthorized | import("@distilled.cloud/cloudflare/Errors").UnknownCloudflareError, import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("alchemy/Interaction").Interaction>>;
        };
    };
};
export default _default;
//# sourceMappingURL=Contributions.d.ts.map