import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The names of the custom labels to add to the runner. */
export type AddCustomLabelsToSelfHostedRunnerForOrgRequestLabelsList = Array<string>;
export interface AddCustomLabelsToSelfHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
    /** The names of the custom labels to add to the runner. */
    labels: AddCustomLabelsToSelfHostedRunnerForOrgRequestLabelsList;
}
/** The type of label. Read-only labels are applied automatically when the runner is configured. */
export type RunnerLabelType = "read-only" | "custom";
/** A label for a self hosted runner */
export interface RunnerLabel {
    /** Unique identifier of the label. */
    id?: number | undefined;
    /** Name of the label. */
    name: string;
    /** The type of label. Read-only labels are applied automatically when the runner is configured. */
    type?: RunnerLabelType | undefined;
}
export type AddCustomLabelsToSelfHostedRunnerForOrgResponseLabelsList = Array<RunnerLabel>;
export interface AddCustomLabelsToSelfHostedRunnerForOrgResponse {
    total_count: number;
    labels: AddCustomLabelsToSelfHostedRunnerForOrgResponseLabelsList;
}
/** The names of the custom labels to add to the runner. */
export type AddCustomLabelsToSelfHostedRunnerForRepoRequestLabelsList = Array<string>;
export interface AddCustomLabelsToSelfHostedRunnerForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
    /** The names of the custom labels to add to the runner. */
    labels: AddCustomLabelsToSelfHostedRunnerForRepoRequestLabelsList;
}
export type AddCustomLabelsToSelfHostedRunnerForRepoResponseLabelsList = Array<RunnerLabel>;
export interface AddCustomLabelsToSelfHostedRunnerForRepoResponse {
    total_count: number;
    labels: AddCustomLabelsToSelfHostedRunnerForRepoResponseLabelsList;
}
export interface AddRepoAccessToSelfHostedRunnerGroupInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface AddRepoAccessToSelfHostedRunnerGroupInOrgResponse {
}
export interface AddSelectedRepoToOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface AddSelectedRepoToOrgSecretResponse {
}
export interface AddSelectedRepoToOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    repository_id: number;
}
export interface AddSelectedRepoToOrgVariableResponse {
}
export interface AddSelfHostedRunnerToGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export interface AddSelfHostedRunnerToGroupForOrgResponse {
}
export interface ApproveWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export type ApproveWorkflowRunResponse = unknown;
export interface CancelWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface CancelWorkflowRunResponse {
}
export interface CreateEnvironmentVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
}
export type CreateEnvironmentVariableResponse = unknown;
/** The source of the runner image. */
export type CreateHostedRunnerForOrgRequestImageSource = "github" | "partner" | "custom";
/** The image of runner. To list all available images, use `GET /actions/hosted-runners/images/github-owned` or `GET /actions/hosted-runners/images/partner`. */
export interface CreateHostedRunnerForOrgRequestImage {
    /** The unique identifier of the runner image. */
    id?: string | undefined;
    /** The source of the runner image. */
    source?: CreateHostedRunnerForOrgRequestImageSource | (string & {}) | undefined;
    /** The version of the runner image to deploy. This is relevant only for runners using custom images. */
    version?: string | null | undefined;
}
export interface CreateHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Name of the runner. Must be between 1 and 64 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'. */
    name: string;
    /** The image of runner. To list all available images, use `GET /actions/hosted-runners/images/github-owned` or `GET /actions/hosted-runners/images/partner`. */
    image: CreateHostedRunnerForOrgRequestImage;
    /** The machine size of the runner. To list available sizes, use `GET actions/hosted-runners/machine-sizes` */
    size: string;
    /** The existing runner group to add this runner to. */
    runner_group_id: number;
    /** The maximum amount of runners to scale up to. Runners will not auto-scale above this number. Use this setting to limit your cost. */
    maximum_runners?: number | undefined;
    /** Whether this runner should be created with a static public IP. Note limit on account. To list limits on account, use `GET actions/hosted-runners/limits` */
    enable_static_ip?: boolean | undefined;
    /** Whether this runner should be used to generate custom images. */
    image_gen?: boolean | undefined;
}
/** The image provider. */
export type NullableActionsHostedRunnerPoolImageSource = "github" | "partner" | "custom";
/** Provides details of a hosted runner image */
export interface NullableActionsHostedRunnerPoolImage {
    /** The ID of the image. Use this ID for the `image` parameter when creating a new larger runner. */
    id: string;
    /** Image size in GB. */
    size_gb: number;
    /** Display name for this image. */
    display_name: string;
    /** The image provider. */
    source: NullableActionsHostedRunnerPoolImageSource;
    /** The image version of the hosted runner pool. */
    version?: string | undefined;
}
/** Provides details of a particular machine spec. */
export interface ActionsHostedRunnerMachineSpec {
    /** The ID used for the `size` parameter when creating a new runner. */
    id: string;
    /** The number of cores. */
    cpu_cores: number;
    /** The available RAM for the machine spec. */
    memory_gb: number;
    /** The available SSD storage for the machine spec. */
    storage_gb: number;
}
/** The status of the runner. */
export type ActionsHostedRunnerStatus = "Ready" | "Provisioning" | "Shutdown" | "Deleting" | "Stuck";
/** Provides details of Public IP for a GitHub-hosted larger runners */
export interface PublicIp {
    /** Whether public IP is enabled. */
    enabled?: boolean | undefined;
    /** The prefix for the public IP. */
    prefix?: string | undefined;
    /** The length of the IP prefix. */
    length?: number | undefined;
}
/** The public IP ranges when public IP is enabled for the hosted runners. */
export type ActionsHostedRunnerPublicIpsList = Array<PublicIp>;
/** A Github-hosted hosted runner. */
export interface ActionsHostedRunner {
    /** The unique identifier of the hosted runner. */
    id: number;
    /** The name of the hosted runner. */
    name: string;
    /** The unique identifier of the group that the hosted runner belongs to. */
    runner_group_id?: number | undefined;
    image_details: NullableActionsHostedRunnerPoolImage | null;
    machine_size_details: ActionsHostedRunnerMachineSpec;
    /** The status of the runner. */
    status: ActionsHostedRunnerStatus;
    /** The operating system of the image. */
    platform: string;
    /** The maximum amount of hosted runners. Runners will not scale automatically above this number. Use this setting to limit your cost. */
    maximum_runners?: number | undefined;
    /** Whether public IP is enabled for the hosted runners. */
    public_ip_enabled: boolean;
    /** The public IP ranges when public IP is enabled for the hosted runners. */
    public_ips?: ActionsHostedRunnerPublicIpsList | undefined;
    /** The time at which the runner was last used, in ISO 8601 format. */
    last_active_on?: string | null | undefined;
    /** Whether custom image generation is enabled for the hosted runners. */
    image_gen?: boolean | undefined;
}
/** The enforcement level of the ruleset. `evaluate` allows admins to test rules before enforcing them. Admins can view insights on the Rule Insights page (`evaluate` is only available with GitHub Enterprise). */
export type RepositoryRuleEnforcement = "disabled" | "active" | "evaluate";
/** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
export type ActionsPolicyOrgConditionsCase0RepositoryNameIncludeList = Array<string>;
/** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type ActionsPolicyOrgConditionsCase0RepositoryNameExcludeList = Array<string>;
export interface ActionsPolicyOrgConditionsCase0RepositoryName {
    /** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
    include?: ActionsPolicyOrgConditionsCase0RepositoryNameIncludeList | undefined;
    /** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: ActionsPolicyOrgConditionsCase0RepositoryNameExcludeList | undefined;
    /** Whether renaming of target repositories is prevented. */
    protected?: boolean | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyOrgConditionsCase0WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyOrgConditionsCase0WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyOrgConditionsCase0WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyOrgConditionsCase0WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyOrgConditionsCase0WorkflowPathExcludeList;
}
export interface ActionsPolicyOrgConditionsCase0 {
    repository_name: ActionsPolicyOrgConditionsCase0RepositoryName;
    workflow_path?: ActionsPolicyOrgConditionsCase0WorkflowPath | undefined;
}
/** The repository IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
export type ActionsPolicyOrgConditionsCase1RepositoryIdRepositoryIdsList = Array<number>;
export interface ActionsPolicyOrgConditionsCase1RepositoryId {
    /** The repository IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
    repository_ids?: ActionsPolicyOrgConditionsCase1RepositoryIdRepositoryIdsList | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyOrgConditionsCase1WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyOrgConditionsCase1WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyOrgConditionsCase1WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyOrgConditionsCase1WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyOrgConditionsCase1WorkflowPathExcludeList;
}
export interface ActionsPolicyOrgConditionsCase1 {
    repository_id: ActionsPolicyOrgConditionsCase1RepositoryId;
    workflow_path?: ActionsPolicyOrgConditionsCase1WorkflowPath | undefined;
}
/** The values to match for the repository property */
export type RepositoryRulesetConditionsRepositoryPropertySpecPropertyValuesList = Array<string>;
/** The source of the repository property. Defaults to 'custom' if not specified. */
export type RepositoryRulesetConditionsRepositoryPropertySpecSource = "custom" | "system";
/** Parameters for a targeting a repository property */
export interface RepositoryRulesetConditionsRepositoryPropertySpec {
    /** The name of the repository property to target */
    name: string;
    /** The values to match for the repository property */
    property_values: RepositoryRulesetConditionsRepositoryPropertySpecPropertyValuesList;
    /** The source of the repository property. Defaults to 'custom' if not specified. */
    source?: RepositoryRulesetConditionsRepositoryPropertySpecSource | (string & {}) | undefined;
}
/** The repository properties and values to include. All of these properties must match for the condition to pass. */
export type ActionsPolicyOrgConditionsCase2RepositoryPropertyIncludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
/** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
export type ActionsPolicyOrgConditionsCase2RepositoryPropertyExcludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
export interface ActionsPolicyOrgConditionsCase2RepositoryProperty {
    /** The repository properties and values to include. All of these properties must match for the condition to pass. */
    include?: ActionsPolicyOrgConditionsCase2RepositoryPropertyIncludeList | undefined;
    /** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: ActionsPolicyOrgConditionsCase2RepositoryPropertyExcludeList | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyOrgConditionsCase2WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyOrgConditionsCase2WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyOrgConditionsCase2WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyOrgConditionsCase2WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyOrgConditionsCase2WorkflowPathExcludeList;
}
export interface ActionsPolicyOrgConditionsCase2 {
    repository_property: ActionsPolicyOrgConditionsCase2RepositoryProperty;
    workflow_path?: ActionsPolicyOrgConditionsCase2WorkflowPath | undefined;
}
/** Conditions for an organization Actions policy. The conditions object should contain one of `repository_name`, `repository_id`, or `repository_property`, and may also contain `workflow_path`. */
export type ActionsPolicyOrgConditions = ActionsPolicyOrgConditionsCase0 | ActionsPolicyOrgConditionsCase1 | ActionsPolicyOrgConditionsCase2;
export type ActionsRuleRestrictActionsActorsType = "restrict_actions_actors";
/** The type of the actor */
export type ActionsRuleParamsActorType = "User" | "Bot" | "Team" | "BusinessTeam" | "EnterpriseTeam" | "IntegrationInstallation" | "App" | "RepositoryRole";
/** An actor authorized to trigger Actions workflows */
export interface ActionsRuleParamsActor {
    /** ID of the actor authorized to trigger Actions workflows. */
    id: number;
    /** The type of the actor */
    type: ActionsRuleParamsActorType | (string & {});
}
/** Select the actors who can run Actions workflows. */
export type ActionsRuleRestrictActionsActorsParametersAllowedActorsList = Array<ActionsRuleParamsActor>;
export interface ActionsRuleRestrictActionsActorsParameters {
    /** Select the actors who can run Actions workflows. */
    allowed_actors: ActionsRuleRestrictActionsActorsParametersAllowedActorsList;
}
/** Choose specific actors that are authorized to trigger Actions workflows. */
export interface ActionsRuleRestrictActionsActors {
    type: ActionsRuleRestrictActionsActorsType;
    parameters?: ActionsRuleRestrictActionsActorsParameters | undefined;
}
export type ActionsRuleRestrictActionEventsType = "restrict_action_events";
export type ActionsRuleRestrictActionEventsParametersAllowedEventsItem = "branch_protection_rule" | "check_run" | "check_suite" | "create" | "delete" | "deployment" | "deployment_status" | "discussion" | "discussion_comment" | "fork" | "gollum" | "image_version" | "issue_comment" | "issues" | "label" | "merge_group" | "milestone" | "page_build" | "project" | "project_card" | "project_column" | "public" | "pull_request" | "pull_request_review" | "pull_request_review_comment" | "pull_request_target" | "push" | "registry_package" | "release" | "repository_dispatch" | "schedule" | "status" | "watch" | "workflow_call" | "workflow_dispatch" | "workflow_run";
/** Select the events that can trigger Actions workflows. */
export type ActionsRuleRestrictActionEventsParametersAllowedEventsList = Array<ActionsRuleRestrictActionEventsParametersAllowedEventsItem | (string & {})>;
export interface ActionsRuleRestrictActionEventsParameters {
    /** Select the events that can trigger Actions workflows. */
    allowed_events: ActionsRuleRestrictActionEventsParametersAllowedEventsList;
}
/** Choose specific GitHub events that will trigger Actions workflows. */
export interface ActionsRuleRestrictActionEvents {
    type: ActionsRuleRestrictActionEventsType;
    parameters?: ActionsRuleRestrictActionEventsParameters | undefined;
}
/** An actions rule. */
export type ActionsRule = ActionsRuleRestrictActionsActors | ActionsRuleRestrictActionEvents;
/** An array of rules within the policy. */
export type CreateOrgActionsPolicyRequestRulesList = Array<ActionsRule>;
export interface CreateOrgActionsPolicyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the policy. */
    name: string;
    enforcement: RepositoryRuleEnforcement | (string & {});
    conditions?: ActionsPolicyOrgConditions | undefined;
    /** An array of rules within the policy. */
    rules?: CreateOrgActionsPolicyRequestRulesList | undefined;
}
/** The target of the policy */
export type ActionsPolicyTarget = "actions";
/** The type of the source of the policy */
export type ActionsPolicySourceType = "Repository" | "Organization" | "Enterprise";
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyWorkflowPathConditionWorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyWorkflowPathConditionWorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyWorkflowPathConditionWorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyWorkflowPathConditionWorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyWorkflowPathConditionWorkflowPathExcludeList;
}
/** Parameters for an Actions policy workflow path condition. Omitting `workflow_path` when creating a policy targets all workflows without storing an explicit condition. Omitting it when updating a policy preserves the existing workflow targeting. For new or changed workflow conditions, the API requires at least one included or excluded pattern. This is validated server-side rather than by this schema, which can also describe existing stored conditions. */
export interface ActionsPolicyWorkflowPathCondition {
    workflow_path?: ActionsPolicyWorkflowPathConditionWorkflowPath | undefined;
}
/** Conditions for a repository Actions policy. The object may be empty to preserve or use the default workflow targeting, or contain only `workflow_path`. */
export type ActionsPolicyRepoConditions = unknown | ActionsPolicyWorkflowPathCondition;
/** Array of organization names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all organizations and ~EMUS to target all enterprise managed user accounts. */
export type ActionsPolicyEnterpriseConditionsCase0OrganizationNameIncludeList = Array<string>;
/** Array of organization names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type ActionsPolicyEnterpriseConditionsCase0OrganizationNameExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase0OrganizationName {
    /** Array of organization names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all organizations and ~EMUS to target all enterprise managed user accounts. */
    include?: ActionsPolicyEnterpriseConditionsCase0OrganizationNameIncludeList | undefined;
    /** Array of organization names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase0OrganizationNameExcludeList | undefined;
}
/** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
export type ActionsPolicyEnterpriseConditionsCase0RepositoryNameIncludeList = Array<string>;
/** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type ActionsPolicyEnterpriseConditionsCase0RepositoryNameExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase0RepositoryName {
    /** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
    include?: ActionsPolicyEnterpriseConditionsCase0RepositoryNameIncludeList | undefined;
    /** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase0RepositoryNameExcludeList | undefined;
    /** Whether renaming of target repositories is prevented. */
    protected?: boolean | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyEnterpriseConditionsCase0WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyEnterpriseConditionsCase0WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase0WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyEnterpriseConditionsCase0WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyEnterpriseConditionsCase0WorkflowPathExcludeList;
}
/** Conditions to target organizations by name and repositories by name */
export interface ActionsPolicyEnterpriseConditionsCase0 {
    organization_name: ActionsPolicyEnterpriseConditionsCase0OrganizationName;
    repository_name: ActionsPolicyEnterpriseConditionsCase0RepositoryName;
    workflow_path?: ActionsPolicyEnterpriseConditionsCase0WorkflowPath | undefined;
}
/** Array of organization names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all organizations and ~EMUS to target all enterprise managed user accounts. */
export type ActionsPolicyEnterpriseConditionsCase1OrganizationNameIncludeList = Array<string>;
/** Array of organization names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type ActionsPolicyEnterpriseConditionsCase1OrganizationNameExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase1OrganizationName {
    /** Array of organization names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all organizations and ~EMUS to target all enterprise managed user accounts. */
    include?: ActionsPolicyEnterpriseConditionsCase1OrganizationNameIncludeList | undefined;
    /** Array of organization names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase1OrganizationNameExcludeList | undefined;
}
/** The repository properties and values to include. All of these properties must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase1RepositoryPropertyIncludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
/** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
export type ActionsPolicyEnterpriseConditionsCase1RepositoryPropertyExcludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
export interface ActionsPolicyEnterpriseConditionsCase1RepositoryProperty {
    /** The repository properties and values to include. All of these properties must match for the condition to pass. */
    include?: ActionsPolicyEnterpriseConditionsCase1RepositoryPropertyIncludeList | undefined;
    /** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase1RepositoryPropertyExcludeList | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyEnterpriseConditionsCase1WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyEnterpriseConditionsCase1WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase1WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyEnterpriseConditionsCase1WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyEnterpriseConditionsCase1WorkflowPathExcludeList;
}
/** Conditions to target organizations by name and repositories by property */
export interface ActionsPolicyEnterpriseConditionsCase1 {
    organization_name: ActionsPolicyEnterpriseConditionsCase1OrganizationName;
    repository_property: ActionsPolicyEnterpriseConditionsCase1RepositoryProperty;
    workflow_path?: ActionsPolicyEnterpriseConditionsCase1WorkflowPath | undefined;
}
/** The organization IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase2OrganizationIdOrganizationIdsList = Array<number>;
export interface ActionsPolicyEnterpriseConditionsCase2OrganizationId {
    /** The organization IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
    organization_ids?: ActionsPolicyEnterpriseConditionsCase2OrganizationIdOrganizationIdsList | undefined;
}
/** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
export type ActionsPolicyEnterpriseConditionsCase2RepositoryNameIncludeList = Array<string>;
/** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type ActionsPolicyEnterpriseConditionsCase2RepositoryNameExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase2RepositoryName {
    /** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
    include?: ActionsPolicyEnterpriseConditionsCase2RepositoryNameIncludeList | undefined;
    /** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase2RepositoryNameExcludeList | undefined;
    /** Whether renaming of target repositories is prevented. */
    protected?: boolean | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyEnterpriseConditionsCase2WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyEnterpriseConditionsCase2WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase2WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyEnterpriseConditionsCase2WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyEnterpriseConditionsCase2WorkflowPathExcludeList;
}
/** Conditions to target organizations by id and repositories by name */
export interface ActionsPolicyEnterpriseConditionsCase2 {
    organization_id: ActionsPolicyEnterpriseConditionsCase2OrganizationId;
    repository_name: ActionsPolicyEnterpriseConditionsCase2RepositoryName;
    workflow_path?: ActionsPolicyEnterpriseConditionsCase2WorkflowPath | undefined;
}
/** The organization IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase3OrganizationIdOrganizationIdsList = Array<number>;
export interface ActionsPolicyEnterpriseConditionsCase3OrganizationId {
    /** The organization IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
    organization_ids?: ActionsPolicyEnterpriseConditionsCase3OrganizationIdOrganizationIdsList | undefined;
}
/** The repository properties and values to include. All of these properties must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase3RepositoryPropertyIncludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
/** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
export type ActionsPolicyEnterpriseConditionsCase3RepositoryPropertyExcludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
export interface ActionsPolicyEnterpriseConditionsCase3RepositoryProperty {
    /** The repository properties and values to include. All of these properties must match for the condition to pass. */
    include?: ActionsPolicyEnterpriseConditionsCase3RepositoryPropertyIncludeList | undefined;
    /** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase3RepositoryPropertyExcludeList | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyEnterpriseConditionsCase3WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyEnterpriseConditionsCase3WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase3WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyEnterpriseConditionsCase3WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyEnterpriseConditionsCase3WorkflowPathExcludeList;
}
/** Conditions to target organizations by id and repositories by property */
export interface ActionsPolicyEnterpriseConditionsCase3 {
    organization_id: ActionsPolicyEnterpriseConditionsCase3OrganizationId;
    repository_property: ActionsPolicyEnterpriseConditionsCase3RepositoryProperty;
    workflow_path?: ActionsPolicyEnterpriseConditionsCase3WorkflowPath | undefined;
}
/** The values to match for the organization property */
export type EnterpriseRulesetConditionsOrganizationPropertySpecPropertyValuesList = Array<string>;
/** Parameters for a targeting a organization property */
export interface EnterpriseRulesetConditionsOrganizationPropertySpec {
    /** The name of the organization property to target */
    name: string;
    /** The values to match for the organization property */
    property_values: EnterpriseRulesetConditionsOrganizationPropertySpecPropertyValuesList;
}
/** The organization properties and values to include. All of these properties must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase4OrganizationPropertyIncludeList = Array<EnterpriseRulesetConditionsOrganizationPropertySpec>;
/** The organization properties and values to exclude. The condition will not pass if any of these properties match. */
export type ActionsPolicyEnterpriseConditionsCase4OrganizationPropertyExcludeList = Array<EnterpriseRulesetConditionsOrganizationPropertySpec>;
export interface ActionsPolicyEnterpriseConditionsCase4OrganizationProperty {
    /** The organization properties and values to include. All of these properties must match for the condition to pass. */
    include?: ActionsPolicyEnterpriseConditionsCase4OrganizationPropertyIncludeList | undefined;
    /** The organization properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase4OrganizationPropertyExcludeList | undefined;
}
/** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
export type ActionsPolicyEnterpriseConditionsCase4RepositoryNameIncludeList = Array<string>;
/** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type ActionsPolicyEnterpriseConditionsCase4RepositoryNameExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase4RepositoryName {
    /** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
    include?: ActionsPolicyEnterpriseConditionsCase4RepositoryNameIncludeList | undefined;
    /** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase4RepositoryNameExcludeList | undefined;
    /** Whether renaming of target repositories is prevented. */
    protected?: boolean | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyEnterpriseConditionsCase4WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyEnterpriseConditionsCase4WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase4WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyEnterpriseConditionsCase4WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyEnterpriseConditionsCase4WorkflowPathExcludeList;
}
/** Conditions to target organizations by property and repositories by name */
export interface ActionsPolicyEnterpriseConditionsCase4 {
    organization_property: ActionsPolicyEnterpriseConditionsCase4OrganizationProperty;
    repository_name: ActionsPolicyEnterpriseConditionsCase4RepositoryName;
    workflow_path?: ActionsPolicyEnterpriseConditionsCase4WorkflowPath | undefined;
}
/** The organization properties and values to include. All of these properties must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase5OrganizationPropertyIncludeList = Array<EnterpriseRulesetConditionsOrganizationPropertySpec>;
/** The organization properties and values to exclude. The condition will not pass if any of these properties match. */
export type ActionsPolicyEnterpriseConditionsCase5OrganizationPropertyExcludeList = Array<EnterpriseRulesetConditionsOrganizationPropertySpec>;
export interface ActionsPolicyEnterpriseConditionsCase5OrganizationProperty {
    /** The organization properties and values to include. All of these properties must match for the condition to pass. */
    include?: ActionsPolicyEnterpriseConditionsCase5OrganizationPropertyIncludeList | undefined;
    /** The organization properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase5OrganizationPropertyExcludeList | undefined;
}
/** The repository properties and values to include. All of these properties must match for the condition to pass. */
export type ActionsPolicyEnterpriseConditionsCase5RepositoryPropertyIncludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
/** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
export type ActionsPolicyEnterpriseConditionsCase5RepositoryPropertyExcludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
export interface ActionsPolicyEnterpriseConditionsCase5RepositoryProperty {
    /** The repository properties and values to include. All of these properties must match for the condition to pass. */
    include?: ActionsPolicyEnterpriseConditionsCase5RepositoryPropertyIncludeList | undefined;
    /** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: ActionsPolicyEnterpriseConditionsCase5RepositoryPropertyExcludeList | undefined;
}
/** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
export type ActionsPolicyEnterpriseConditionsCase5WorkflowPathIncludeList = Array<string>;
/** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
export type ActionsPolicyEnterpriseConditionsCase5WorkflowPathExcludeList = Array<string>;
export interface ActionsPolicyEnterpriseConditionsCase5WorkflowPath {
    /** Array of workflow file paths or glob patterns to include. An empty array includes all workflows not matched by an excluded pattern. Use `~ALL` by itself to include all workflows. `~ALL` cannot be combined with other included patterns. */
    include: ActionsPolicyEnterpriseConditionsCase5WorkflowPathIncludeList;
    /** Array of workflow file paths or glob patterns to exclude. The condition will not pass if any of these patterns match. `~ALL` is not allowed in this array. */
    exclude: ActionsPolicyEnterpriseConditionsCase5WorkflowPathExcludeList;
}
/** Conditions to target organizations by property and repositories by property */
export interface ActionsPolicyEnterpriseConditionsCase5 {
    organization_property: ActionsPolicyEnterpriseConditionsCase5OrganizationProperty;
    repository_property: ActionsPolicyEnterpriseConditionsCase5RepositoryProperty;
    workflow_path?: ActionsPolicyEnterpriseConditionsCase5WorkflowPath | undefined;
}
/** Conditions for an enterprise Actions policy. The conditions object supports one organization target (`organization_name`, `organization_id`, or `organization_property`) combined with one repository target (`repository_name` or `repository_property`), and may also contain `workflow_path`. */
export type ActionsPolicyEnterpriseConditions = ActionsPolicyEnterpriseConditionsCase0 | ActionsPolicyEnterpriseConditionsCase1 | ActionsPolicyEnterpriseConditionsCase2 | ActionsPolicyEnterpriseConditionsCase3 | ActionsPolicyEnterpriseConditionsCase4 | ActionsPolicyEnterpriseConditionsCase5;
/** When workflow path targeting is available, detailed responses represent an omitted stored workflow condition as `workflow_path` with `include` set to `["~ALL"]` and `exclude` set to `[]`. When workflow path targeting is unavailable, an omitted stored condition remains omitted. */
export type ActionsPolicyConditions = ActionsPolicyRepoConditions | ActionsPolicyOrgConditions | ActionsPolicyEnterpriseConditions;
/** An array of rules within the policy */
export type ActionsPolicyRulesList = Array<ActionsRule>;
export interface ActionsPolicyLinksSelf {
    /** The URL of the policy */
    href?: string | undefined;
}
export interface ActionsPolicyLinksHtml {
    /** The html URL of the policy */
    href?: string | undefined;
}
export interface ActionsPolicyLinks {
    self?: ActionsPolicyLinksSelf | undefined;
    html?: ActionsPolicyLinksHtml | undefined;
}
/** An Actions policy defines rules for workflow execution protection. */
export interface ActionsPolicy {
    /** The ID of the policy */
    id: number;
    /** The name of the policy */
    name: string;
    /** The target of the policy */
    target: ActionsPolicyTarget;
    /** The type of the source of the policy */
    source_type: ActionsPolicySourceType;
    /** The name of the source */
    source: string;
    enforcement: RepositoryRuleEnforcement;
    /** When workflow path targeting is available, detailed responses represent an omitted stored workflow condition as `workflow_path` with `include` set to `["~ALL"]` and `exclude` set to `[]`. When workflow path targeting is unavailable, an omitted stored condition remains omitted. */
    conditions?: ActionsPolicyConditions | null | undefined;
    /** An array of rules within the policy */
    rules?: ActionsPolicyRulesList | undefined;
    node_id?: string | undefined;
    _links?: ActionsPolicyLinks | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
}
/** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
export type CreateOrgVariableRequestVisibility = "all" | "private" | "selected";
/** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
export type CreateOrgVariableRequestSelectedRepositoryIdsList = Array<number>;
export interface CreateOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
    /** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
    visibility: CreateOrgVariableRequestVisibility | (string & {});
    /** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
    selected_repository_ids?: CreateOrgVariableRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrgVariableResponse = unknown;
export interface CreateOrUpdateEnvironmentSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an environment public key](https://docs.github.com/rest/actions/secrets#get-an-environment-public-key) endpoint. */
    encrypted_value: string;
    /** ID of the key you used to encrypt the secret. */
    key_id: string;
}
export type CreateOrUpdateEnvironmentSecretResponse = unknown;
/** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
export type CreateOrUpdateOrgSecretRequestVisibility = "all" | "private" | "selected";
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/actions/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/actions/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface CreateOrUpdateOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/actions/secrets#get-an-organization-public-key) endpoint. */
    encrypted_value: string;
    /** ID of the key you used to encrypt the secret. */
    key_id: string;
    /** Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret. */
    visibility: CreateOrUpdateOrgSecretRequestVisibility | (string & {});
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/actions/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/actions/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids?: CreateOrUpdateOrgSecretRequestSelectedRepositoryIdsList | undefined;
}
export type CreateOrUpdateOrgSecretResponse = unknown;
export interface CreateOrUpdateRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
    /** Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/actions/secrets#get-a-repository-public-key) endpoint. */
    encrypted_value: string;
    /** ID of the key you used to encrypt the secret. */
    key_id: string;
}
export type CreateOrUpdateRepoSecretResponse = unknown;
export interface CreateRegistrationTokenForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
/** The repositories this token has access to */
export type AuthenticationTokenRepositoriesList = Array<Repository>;
/** Describe whether all repositories have been selected or there's a selection involved */
export type AuthenticationTokenRepositorySelection = "all" | "selected";
/** Authentication Token */
export interface AuthenticationToken {
    /** The token used for authentication */
    token: string;
    /** The time this token expires */
    expires_at: string;
    permissions?: unknown | undefined;
    /** The repositories this token has access to */
    repositories?: AuthenticationTokenRepositoriesList | undefined;
    single_file?: string | null | undefined;
    /** Describe whether all repositories have been selected or there's a selection involved */
    repository_selection?: AuthenticationTokenRepositorySelection | undefined;
}
export interface CreateRegistrationTokenForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface CreateRemoveTokenForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface CreateRemoveTokenForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** An array of rules within the policy. */
export type CreateRepoActionsPolicyRequestRulesList = Array<ActionsRule>;
export interface CreateRepoActionsPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the policy. */
    name: string;
    enforcement: RepositoryRuleEnforcement | (string & {});
    conditions?: ActionsPolicyRepoConditions | undefined;
    /** An array of rules within the policy. */
    rules?: CreateRepoActionsPolicyRequestRulesList | undefined;
}
export interface CreateRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
}
export type CreateRepoVariableResponse = unknown;
/** Visibility of a runner group. You can select all repositories, select individual repositories, or limit access to private repositories. */
export type CreateSelfHostedRunnerGroupForOrgRequestVisibility = "selected" | "all" | "private";
/** List of repository IDs that can access the runner group. */
export type CreateSelfHostedRunnerGroupForOrgRequestSelectedRepositoryIdsList = Array<number>;
/** List of runner IDs to add to the runner group. */
export type CreateSelfHostedRunnerGroupForOrgRequestRunnersList = Array<number>;
/** List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`. */
export type CreateSelfHostedRunnerGroupForOrgRequestSelectedWorkflowsList = Array<string>;
export interface CreateSelfHostedRunnerGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Name of the runner group. */
    name: string;
    /** Visibility of a runner group. You can select all repositories, select individual repositories, or limit access to private repositories. */
    visibility?: CreateSelfHostedRunnerGroupForOrgRequestVisibility | (string & {}) | undefined;
    /** List of repository IDs that can access the runner group. */
    selected_repository_ids?: CreateSelfHostedRunnerGroupForOrgRequestSelectedRepositoryIdsList | undefined;
    /** List of runner IDs to add to the runner group. */
    runners?: CreateSelfHostedRunnerGroupForOrgRequestRunnersList | undefined;
    /** Whether the runner group can be used by `public` repositories. */
    allows_public_repositories?: boolean | undefined;
    /** If `true`, the runner group will be restricted to running only the workflows specified in the `selected_workflows` array. */
    restricted_to_workflows?: boolean | undefined;
    /** List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`. */
    selected_workflows?: CreateSelfHostedRunnerGroupForOrgRequestSelectedWorkflowsList | undefined;
    /** The identifier of a hosted compute network configuration. */
    network_configuration_id?: string | undefined;
}
/** List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`. */
export type RunnerGroupsOrgSelectedWorkflowsList = Array<string>;
export interface RunnerGroupsOrg {
    id: number;
    name: string;
    visibility: string;
    default: boolean;
    /** Link to the selected repositories resource for this runner group. Not present unless visibility was set to `selected` */
    selected_repositories_url?: string | undefined;
    runners_url: string;
    hosted_runners_url?: string | undefined;
    /** The identifier of a hosted compute network configuration. */
    network_configuration_id?: string | undefined;
    inherited: boolean;
    inherited_allows_public_repositories?: boolean | undefined;
    allows_public_repositories: boolean;
    /** If `true`, the `restricted_to_workflows` and `selected_workflows` fields cannot be modified. */
    workflow_restrictions_read_only?: boolean | undefined;
    /** If `true`, the runner group will be restricted to running only the workflows specified in the `selected_workflows` array. */
    restricted_to_workflows?: boolean | undefined;
    /** List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`. */
    selected_workflows?: RunnerGroupsOrgSelectedWorkflowsList | undefined;
}
/** Input keys and values configured in the workflow file. The maximum number of properties is 25. Any default properties configured in the workflow file will be used when `inputs` are omitted. */
export type CreateWorkflowDispatchRequestInputsMap = {
    [key: string]: unknown | undefined;
};
export interface CreateWorkflowDispatchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the workflow. You can also pass the workflow file name as a string. */
    workflow_id: string;
    /** The git reference for the workflow. The reference can be a branch or tag name. */
    ref: string;
    /** Input keys and values configured in the workflow file. The maximum number of properties is 25. Any default properties configured in the workflow file will be used when `inputs` are omitted. */
    inputs?: CreateWorkflowDispatchRequestInputsMap | undefined;
    /** Whether the response should include the workflow run ID and URLs. */
    return_run_details?: boolean | undefined;
}
/** Response containing the workflow run ID and URLs. */
export interface WorkflowDispatchResponse {
    workflow_run_id: number;
    /** The URL to the workflow run. */
    run_url: string;
    html_url: string;
}
export interface DeleteActionsCacheByIdRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the GitHub Actions cache. */
    cache_id: number;
}
export interface DeleteActionsCacheByIdResponse {
}
export interface DeleteActionsCacheByKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A key for identifying the cache. */
    key: string;
    /** The full Git reference for narrowing down the cache. The `ref` for a branch should be formatted as `refs/heads/<branch name>`. To reference a pull request use `refs/pull/<number>/merge`. */
    ref?: string | undefined;
}
export interface ActionsCacheListActionsCachesItem {
    id?: number | undefined;
    ref?: string | undefined;
    key?: string | undefined;
    version?: string | undefined;
    last_accessed_at?: string | undefined;
    created_at?: string | undefined;
    size_in_bytes?: number | undefined;
}
/** Array of caches */
export type ActionsCacheListActionsCachesList = Array<ActionsCacheListActionsCachesItem>;
/** Repository actions caches */
export interface ActionsCacheList {
    /** Total number of caches */
    total_count: number;
    /** Array of caches */
    actions_caches: ActionsCacheListActionsCachesList;
}
export interface DeleteArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the artifact. */
    artifact_id: number;
}
export interface DeleteArtifactResponse {
}
export interface DeleteCustomImageFromOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Image definition ID of custom image */
    image_definition_id: number;
}
export interface DeleteCustomImageFromOrgResponse {
}
export interface DeleteCustomImageVersionFromOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Image definition ID of custom image */
    image_definition_id: number;
    /** Version of a custom image */
    version: string;
}
export interface DeleteCustomImageVersionFromOrgResponse {
}
export interface DeleteEnvironmentSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteEnvironmentSecretResponse {
}
export interface DeleteEnvironmentVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the variable. */
    name: string;
}
export interface DeleteEnvironmentVariableResponse {
}
export interface DeleteHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the GitHub-hosted runner. */
    hosted_runner_id: number;
}
export interface DeleteHostedRunnerForOrgResponse {
}
export interface DeleteOrgActionsPolicyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the policy. */
    policy_id: number;
}
export interface DeleteOrgActionsPolicyResponse {
}
export interface DeleteOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteOrgSecretResponse {
}
export interface DeleteOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
}
export interface DeleteOrgVariableResponse {
}
export interface DeleteRepoActionsPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the policy. */
    policy_id: number;
}
export interface DeleteRepoActionsPolicyResponse {
}
export interface DeleteRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface DeleteRepoSecretResponse {
}
export interface DeleteRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
}
export interface DeleteRepoVariableResponse {
}
export interface DeleteSelfHostedRunnerFromOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export interface DeleteSelfHostedRunnerFromOrgResponse {
}
export interface DeleteSelfHostedRunnerFromRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export interface DeleteSelfHostedRunnerFromRepoResponse {
}
export interface DeleteSelfHostedRunnerGroupFromOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
}
export interface DeleteSelfHostedRunnerGroupFromOrgResponse {
}
export interface DeleteWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface DeleteWorkflowRunResponse {
}
export interface DeleteWorkflowRunLogsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface DeleteWorkflowRunLogsResponse {
}
export interface DisableSelectedRepositoryGithubActionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface DisableSelectedRepositoryGithubActionsOrganizationResponse {
}
export interface DisableSelectedRepositorySelfHostedRunnersOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface DisableSelectedRepositorySelfHostedRunnersOrganizationResponse {
}
export interface DisableWorkflowRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the workflow. You can also pass the workflow file name as a string. */
    workflow_id: string;
}
export interface DisableWorkflowResponse {
}
export interface DownloadArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the artifact. */
    artifact_id: number;
    archive_format: string;
}
export interface DownloadArtifactResponse {
}
export interface DownloadJobLogsForWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the job. */
    job_id: number;
}
export interface DownloadJobLogsForWorkflowRunResponse {
}
export interface DownloadStepLogsForWorkflowRunJobRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the job. */
    job_id: number;
    /** The number assigned to the step, as shown in the `number` field of the workflow job's `steps` array. */
    step_number: number;
}
export interface DownloadStepLogsForWorkflowRunJobResponse {
}
export interface DownloadWorkflowRunAttemptLogsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** The attempt number of the workflow run. */
    attempt_number: number;
}
export interface DownloadWorkflowRunAttemptLogsResponse {
}
export interface DownloadWorkflowRunLogsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface DownloadWorkflowRunLogsResponse {
}
export interface EnableSelectedRepositoryGithubActionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface EnableSelectedRepositoryGithubActionsOrganizationResponse {
}
export interface EnableSelectedRepositorySelfHostedRunnersOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface EnableSelectedRepositorySelfHostedRunnersOrganizationResponse {
}
export interface EnableWorkflowRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the workflow. You can also pass the workflow file name as a string. */
    workflow_id: string;
}
export interface EnableWorkflowResponse {
}
export interface ForceCancelWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface ForceCancelWorkflowRunResponse {
}
/** The names of the custom labels to add to the runner. **Minimum items**: 1. **Maximum items**: 100. */
export type GenerateRunnerJitconfigForOrgRequestLabelsList = Array<string>;
export interface GenerateRunnerJitconfigForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the new runner. */
    name: string;
    /** The ID of the runner group to register the runner to. */
    runner_group_id: number;
    /** The names of the custom labels to add to the runner. **Minimum items**: 1. **Maximum items**: 100. */
    labels: GenerateRunnerJitconfigForOrgRequestLabelsList;
    /** The working directory to be used for job execution, relative to the runner install directory. */
    work_folder?: string | undefined;
}
export type RunnerLabelsList = Array<RunnerLabel>;
/** A self hosted runner */
export interface Runner {
    /** The ID of the runner. */
    id: number;
    /** The ID of the runner group. */
    runner_group_id?: number | undefined;
    /** The name of the runner. */
    name: string;
    /** The Operating System of the runner. */
    os: string;
    /** The status of the runner. */
    status: string;
    busy: boolean;
    labels: RunnerLabelsList;
    ephemeral?: boolean | undefined;
    /** The version of the GitHub Actions Runner software. This is only set if the runner has connected to the service at least once. */
    version?: string | null | undefined;
}
export interface GenerateRunnerJitconfigForOrgResponse {
    runner: Runner;
    /** The base64 encoded runner configuration. */
    encoded_jit_config: string;
}
/** The names of the custom labels to add to the runner. **Minimum items**: 1. **Maximum items**: 100. */
export type GenerateRunnerJitconfigForRepoRequestLabelsList = Array<string>;
export interface GenerateRunnerJitconfigForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the new runner. */
    name: string;
    /** The ID of the runner group to register the runner to. */
    runner_group_id: number;
    /** The names of the custom labels to add to the runner. **Minimum items**: 1. **Maximum items**: 100. */
    labels: GenerateRunnerJitconfigForRepoRequestLabelsList;
    /** The working directory to be used for job execution, relative to the runner install directory. */
    work_folder?: string | undefined;
}
export interface GenerateRunnerJitconfigForRepoResponse {
    runner: Runner;
    /** The base64 encoded runner configuration. */
    encoded_jit_config: string;
}
export type GetActionsCacheListRequestSort = "created_at" | "last_accessed_at" | "size_in_bytes";
export type GetActionsCacheListRequestDirection = "asc" | "desc";
export interface GetActionsCacheListRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The full Git reference for narrowing down the cache. The `ref` for a branch should be formatted as `refs/heads/<branch name>`. To reference a pull request use `refs/pull/<number>/merge`. */
    ref?: string | undefined;
    /** An explicit key or prefix for identifying the cache */
    key?: string | undefined;
    /** The property to sort the results by. `created_at` means when the cache was created. `last_accessed_at` means when the cache was last accessed. `size_in_bytes` is the size of the cache in bytes. */
    sort?: GetActionsCacheListRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: GetActionsCacheListRequestDirection | (string & {}) | undefined;
}
export interface GetActionsCacheRetentionLimitForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
/** GitHub Actions cache retention policy for an enterprise. */
export interface ActionsCacheRetentionLimitForEnterprise {
    /** For repositories & organizations in an enterprise, the maximum duration, in days, for which caches in a repository may be retained. */
    max_cache_retention_days?: number | undefined;
}
export interface GetActionsCacheRetentionLimitForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** GitHub Actions cache retention policy for an organization. */
export interface ActionsCacheRetentionLimitForOrganization {
    /** For repositories in this organization, the maximum duration, in days, for which caches in a repository may be retained. */
    max_cache_retention_days?: number | undefined;
}
export interface GetActionsCacheRetentionLimitForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** GitHub Actions cache retention policy for a repository. */
export interface ActionsCacheRetentionLimitForRepository {
    /** The maximum number of days to keep caches in this repository. */
    max_cache_retention_days?: number | undefined;
}
export interface GetActionsCacheStorageLimitForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
}
/** GitHub Actions cache storage policy for an enterprise. */
export interface ActionsCacheStorageLimitForEnterprise {
    /** For repositories & organizations in an enterprise, the maximum size limit for the sum of all caches in a repository, in gigabytes. */
    max_cache_size_gb?: number | undefined;
}
export interface GetActionsCacheStorageLimitForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** GitHub Actions cache storage policy for an organization. */
export interface ActionsCacheStorageLimitForOrganization {
    /** For repositories in the organization, the maximum size limit for the sum of all caches in a repository, in gigabytes. */
    max_cache_size_gb?: number | undefined;
}
export interface GetActionsCacheStorageLimitForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** GitHub Actions cache storage policy for a repository. */
export interface ActionsCacheStorageLimitForRepository {
    /** The maximum total cache size for this repository, in gigabytes. */
    max_cache_size_gb?: number | undefined;
}
export interface GetActionsCacheUsageRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** GitHub Actions Cache Usage by repository. */
export interface ActionsCacheUsageByRepository {
    /** The repository owner and name for the cache usage being shown. */
    full_name: string;
    /** The sum of the size in bytes of all the active cache items in the repository. */
    active_caches_size_in_bytes: number;
    /** The number of active caches in the repository. */
    active_caches_count: number;
}
export interface GetActionsCacheUsageByRepoForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type GetActionsCacheUsageByRepoForOrgResponseRepositoryCacheUsagesList = Array<ActionsCacheUsageByRepository>;
export interface GetActionsCacheUsageByRepoForOrgResponse {
    total_count: number;
    repository_cache_usages: GetActionsCacheUsageByRepoForOrgResponseRepositoryCacheUsagesList;
}
export interface GetActionsCacheUsageForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface ActionsCacheUsageOrgEnterprise {
    /** The count of active caches across all repositories of an enterprise or an organization. */
    total_active_caches_count: number;
    /** The total size in bytes of all active cache items across all repositories of an enterprise or an organization. */
    total_active_caches_size_in_bytes: number;
}
export interface GetAllowedActionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`. > [!NOTE] > The `patterns_allowed` setting only applies to public repositories. */
export type SelectedActionsPatternsAllowedList = Array<string>;
export interface SelectedActions {
    /** Whether GitHub-owned actions are allowed. For example, this includes the actions in the `actions` organization. */
    github_owned_allowed?: boolean | undefined;
    /** Whether actions from GitHub Marketplace verified creators are allowed. Set to `true` to allow all actions by GitHub Marketplace verified creators. */
    verified_allowed?: boolean | undefined;
    /** Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`. > [!NOTE] > The `patterns_allowed` setting only applies to public repositories. */
    patterns_allowed?: SelectedActionsPatternsAllowedList | undefined;
}
export interface GetAllowedActionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetArtifactRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the artifact. */
    artifact_id: number;
}
export interface ArtifactWorkflowRun {
    id?: number | undefined;
    repository_id?: number | undefined;
    head_repository_id?: number | undefined;
    head_branch?: string | undefined;
    head_sha?: string | undefined;
}
/** An artifact */
export interface Artifact {
    id: number;
    node_id: string;
    /** The name of the artifact. */
    name: string;
    /** The size in bytes of the artifact. */
    size_in_bytes: number;
    url: string;
    archive_download_url: string;
    /** Whether or not the artifact has expired. */
    expired: boolean;
    created_at: string | null;
    expires_at: string | null;
    updated_at: string | null;
    /** The SHA256 digest of the artifact. This field will only be populated on artifacts uploaded with upload-artifact v4 or newer. For older versions, this field will be null. */
    digest?: string | null | undefined;
    workflow_run?: ArtifactWorkflowRun | null | undefined;
}
export interface GetArtifactAndLogRetentionSettingsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface ActionsArtifactAndLogRetentionResponse {
    /** The number of days checks, workflow runs, commit statuses, artifacts, and logs are retained */
    days: number;
    /** The maximum number of days that can be configured */
    maximum_allowed_days: number;
}
export interface GetArtifactAndLogRetentionSettingsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetConcurrencyGroupForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the concurrency group. */
    concurrency_group_name: string;
    /** Filter to items ahead of this workflow run ID in the queue, plus the run itself. Matches workflow-level concurrency and reusable-workflow leases held on behalf of the run. Mutually exclusive with `ahead_of_job`. */
    ahead_of_run?: number | undefined;
    /** Filter to items ahead of this job ID in the queue, plus the job itself. Matches job-level concurrency and reusable-workflow leases on the job's ancestor paths. Mutually exclusive with `ahead_of_run`. */
    ahead_of_job?: number | undefined;
}
export type ConcurrencyGroupGroupMembersItemStatus = "in_progress" | "pending";
export interface ConcurrencyGroupGroupMembersItem {
    /** The ID of the workflow run. */
    run_id: number;
    /** The name of the workflow run. */
    run_name: string;
    /** API URL for the workflow run. */
    run_url: string | null;
    /** Web URL for the workflow run. */
    run_html_url: string | null;
    /** The ID of the job, when the item represents a job-level or reusable-workflow-level lease. */
    job_id?: number | undefined;
    /** The display name of the job, when the item represents a job-level or reusable-workflow-level lease. */
    job_name?: string | undefined;
    /** API URL for the job. */
    job_url?: string | null | undefined;
    /** Web URL for the job. */
    job_html_url?: string | null | undefined;
    status: ConcurrencyGroupGroupMembersItemStatus;
}
export type ConcurrencyGroupGroupMembersList = Array<ConcurrencyGroupGroupMembersItem>;
/** A concurrency group with the workflow runs and jobs that are either currently holding or waiting for the concurrency group lease. */
export interface ConcurrencyGroup {
    /** The name of the concurrency group. */
    group_name: string;
    /** API URL for this concurrency group. */
    group_url: string;
    total_count: number;
    group_members: ConcurrencyGroupGroupMembersList;
}
export interface GetCustomImageForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Image definition ID of custom image */
    image_definition_id: number;
}
/** Provides details of a custom runner image */
export interface ActionsHostedRunnerCustomImage {
    /** The ID of the image. Use this ID for the `image` parameter when creating a new larger runner. */
    id: number;
    /** The operating system of the image. */
    platform: string;
    /** Total size of all the image versions in GB. */
    total_versions_size: number;
    /** Display name for this image. */
    name: string;
    /** The image provider. */
    source: string;
    /** The number of image versions associated with the image. */
    versions_count: number;
    /** The latest image version associated with the image. */
    latest_version: string;
    /** The number of image versions associated with the image. */
    state: string;
}
export interface GetCustomImageVersionForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Image definition ID of custom image */
    image_definition_id: number;
    /** Version of a custom image */
    version: string;
}
/** Provides details of a hosted runner custom image version */
export interface ActionsHostedRunnerCustomImageVersion {
    /** The version of image. */
    version: string;
    /** The state of image version. */
    state: string;
    /** Image version size in GB. */
    size_gb: number;
    /** The creation date time of the image version. */
    created_on: string;
    /** The image version status details. */
    state_details: string;
}
export interface GetCustomOidcSubClaimForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
export type OidcCustomSubRepoIncludeClaimKeysList = Array<string>;
/** Actions OIDC subject customization for a repository */
export interface OidcCustomSubRepo {
    /** Whether to use the default template or not. If `true`, the `include_claim_keys` field is ignored. */
    use_default: boolean;
    /** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
    include_claim_keys?: OidcCustomSubRepoIncludeClaimKeysList | undefined;
    /** Whether the repository has opted in to the immutable OIDC subject claim format. When `true`, OIDC tokens will use a stable, repository-ID-based `sub` claim. If not set at the repository level, falls back to the organization-level setting. */
    use_immutable_subject?: boolean | undefined;
    /** The current `sub` claim prefix for this repository. */
    sub_claim_prefix?: string | undefined;
}
export interface GetEnvironmentPublicKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
}
/** The public key used for setting Actions Secrets. */
export interface ActionsPublicKey {
    /** The identifier for the key. */
    key_id: string;
    /** The Base64 encoded public key. */
    key: string;
    id?: number | undefined;
    url?: string | undefined;
    title?: string | undefined;
    created_at?: string | undefined;
}
export interface GetEnvironmentSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Set secrets for GitHub Actions. */
export interface ActionsSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
}
export interface GetEnvironmentVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the variable. */
    name: string;
}
export interface ActionsVariable {
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
    /** The date and time at which the variable was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the variable was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
}
export interface GetForkPrContributorApprovalPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The policy that controls when fork PR workflows require approval from a maintainer. */
export type ActionsForkPrContributorApprovalApprovalPolicy = "first_time_contributors_new_to_github" | "first_time_contributors" | "all_external_contributors";
export interface ActionsForkPrContributorApproval {
    /** The policy that controls when fork PR workflows require approval from a maintainer. */
    approval_policy: ActionsForkPrContributorApprovalApprovalPolicy;
}
export interface GetForkPrContributorApprovalPermissionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetGithubActionsDefaultWorkflowPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The default workflow permissions granted to the GITHUB_TOKEN when running workflows. */
export type ActionsDefaultWorkflowPermissions = "read" | "write";
export interface ActionsGetDefaultWorkflowPermissions {
    default_workflow_permissions: ActionsDefaultWorkflowPermissions;
    can_approve_pull_request_reviews: boolean;
}
export interface GetGithubActionsDefaultWorkflowPermissionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetGithubActionsPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The policy that controls the repositories in the organization that are allowed to run GitHub Actions. */
export type EnabledRepositories = "all" | "none" | "selected";
/** The permissions policy that controls the actions and reusable workflows that are allowed to run. */
export type AllowedActions = "all" | "local_only" | "selected";
export interface ActionsOrganizationPermissions {
    enabled_repositories: EnabledRepositories;
    /** The API URL to use to get or set the selected repositories that are allowed to run GitHub Actions, when `enabled_repositories` is set to `selected`. */
    selected_repositories_url?: string | undefined;
    allowed_actions?: AllowedActions | undefined;
    selected_actions_url?: string | undefined;
    sha_pinning_required?: boolean | undefined;
}
export interface GetGithubActionsPermissionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface ActionsRepositoryPermissions {
    enabled: boolean;
    allowed_actions?: AllowedActions | undefined;
    selected_actions_url?: string | undefined;
    sha_pinning_required?: boolean | undefined;
}
export interface GetHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the GitHub-hosted runner. */
    hosted_runner_id: number;
}
export interface GetHostedRunnersGithubOwnedImagesForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The image provider. */
export type ActionsHostedRunnerCuratedImageSource = "github" | "partner" | "custom";
/** Provides details of a hosted runner image */
export interface ActionsHostedRunnerCuratedImage {
    /** The ID of the image. Use this ID for the `image` parameter when creating a new larger runner. */
    id: string;
    /** The operating system of the image. */
    platform: string;
    /** Image size in GB. */
    size_gb: number;
    /** Display name for this image. */
    display_name: string;
    /** The image provider. */
    source: ActionsHostedRunnerCuratedImageSource;
}
export type GetHostedRunnersGithubOwnedImagesForOrgResponseImagesList = Array<ActionsHostedRunnerCuratedImage>;
export interface GetHostedRunnersGithubOwnedImagesForOrgResponse {
    total_count: number;
    images: GetHostedRunnersGithubOwnedImagesForOrgResponseImagesList;
}
export interface GetHostedRunnersLimitsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** Provides details of static public IP limits for GitHub-hosted Hosted Runners */
export interface ActionsHostedRunnerLimitsPublicIps {
    /** The maximum number of static public IP addresses that can be used for Hosted Runners. */
    maximum: number;
    /** The current number of static public IP addresses in use by Hosted Runners. */
    current_usage: number;
}
export interface ActionsHostedRunnerLimits {
    /** Provides details of static public IP limits for GitHub-hosted Hosted Runners */
    public_ips: ActionsHostedRunnerLimitsPublicIps;
}
export interface GetHostedRunnersMachineSpecsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type GetHostedRunnersMachineSpecsForOrgResponseMachineSpecsList = Array<ActionsHostedRunnerMachineSpec>;
export interface GetHostedRunnersMachineSpecsForOrgResponse {
    total_count: number;
    machine_specs: GetHostedRunnersMachineSpecsForOrgResponseMachineSpecsList;
}
export interface GetHostedRunnersPartnerImagesForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type GetHostedRunnersPartnerImagesForOrgResponseImagesList = Array<ActionsHostedRunnerCuratedImage>;
export interface GetHostedRunnersPartnerImagesForOrgResponse {
    total_count: number;
    images: GetHostedRunnersPartnerImagesForOrgResponseImagesList;
}
export interface GetHostedRunnersPlatformsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type GetHostedRunnersPlatformsForOrgResponsePlatformsList = Array<string>;
export interface GetHostedRunnersPlatformsForOrgResponse {
    total_count: number;
    platforms: GetHostedRunnersPlatformsForOrgResponsePlatformsList;
}
export interface GetJobForWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the job. */
    job_id: number;
}
/** The phase of the lifecycle that the job is currently in. */
export type JobStatus = "queued" | "in_progress" | "completed" | "waiting" | "requested" | "pending";
/** The outcome of the job. */
export type JobConclusion = "success" | "failure" | "neutral" | "cancelled" | "skipped" | "timed_out" | "action_required";
/** The phase of the lifecycle that the job is currently in. */
export type JobStepsItemStatus = "queued" | "in_progress" | "completed";
export interface JobStepsItem {
    /** The phase of the lifecycle that the job is currently in. */
    status: JobStepsItemStatus;
    /** The outcome of the job. */
    conclusion: string | null;
    /** The name of the job. */
    name: string;
    number: number;
    /** The time that the step started, in ISO 8601 format. */
    started_at?: string | null | undefined;
    /** The time that the job finished, in ISO 8601 format. */
    completed_at?: string | null | undefined;
}
/** Steps in this job. */
export type JobStepsList = Array<JobStepsItem>;
/** Labels for the workflow job. Specified by the "runs_on" attribute in the action's workflow file. */
export type JobLabelsList = Array<string>;
/** Information of a job execution in a workflow run */
export interface Job {
    /** The id of the job. */
    id: number;
    /** The id of the associated workflow run. */
    run_id: number;
    run_url: string;
    /** Attempt number of the associated workflow run, 1 for first attempt and higher if the workflow was re-run. */
    run_attempt?: number | undefined;
    node_id: string;
    /** The SHA of the commit that is being run. */
    head_sha: string;
    url: string;
    html_url: string | null;
    /** The phase of the lifecycle that the job is currently in. */
    status: JobStatus;
    /** The outcome of the job. */
    conclusion: JobConclusion | null;
    /** The time that the job created, in ISO 8601 format. */
    created_at: string;
    /** The time that the job started, in ISO 8601 format. */
    started_at: string;
    /** The time that the job finished, in ISO 8601 format. */
    completed_at: string | null;
    /** The name of the job. */
    name: string;
    /** Steps in this job. */
    steps?: JobStepsList | undefined;
    check_run_url: string;
    /** Labels for the workflow job. Specified by the "runs_on" attribute in the action's workflow file. */
    labels: JobLabelsList;
    /** The ID of the runner to which this job has been assigned. (If a runner hasn't yet been assigned, this will be null.) */
    runner_id: number | null;
    /** The name of the runner to which this job has been assigned. (If a runner hasn't yet been assigned, this will be null.) */
    runner_name: string | null;
    /** The ID of the runner group to which this job has been assigned. (If a runner hasn't yet been assigned, this will be null.) */
    runner_group_id: number | null;
    /** The name of the runner group to which this job has been assigned. (If a runner hasn't yet been assigned, this will be null.) */
    runner_group_name: string | null;
    /** The name of the workflow. */
    workflow_name: string | null;
    /** The name of the current branch. */
    head_branch: string | null;
}
export interface GetOrgActionsPoliciesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Include policies configured at higher levels that apply to this organization */
    has_parents?: boolean | undefined;
}
/** An array of Actions policies. */
export type GetOrgActionsPoliciesResponsePoliciesList = Array<ActionsPolicy>;
export interface GetOrgActionsPoliciesResponse {
    /** The total number of Actions policies. */
    total_count: number;
    /** An array of Actions policies. */
    policies: GetOrgActionsPoliciesResponsePoliciesList;
}
export interface GetOrgActionsPolicyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the policy. */
    policy_id: number;
}
export interface GetOrgPublicKeyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface GetOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
}
/** Visibility of a secret */
export type OrganizationActionsSecretVisibility = "all" | "private" | "selected";
/** Secrets for GitHub Actions for an organization. */
export interface OrganizationActionsSecret {
    /** The name of the secret. */
    name: string;
    created_at: string;
    updated_at: string;
    /** Visibility of a secret */
    visibility: OrganizationActionsSecretVisibility;
    selected_repositories_url?: string | undefined;
}
export interface GetOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
}
/** Visibility of a variable */
export type OrganizationActionsVariableVisibility = "all" | "private" | "selected";
/** Organization variable for GitHub Actions. */
export interface OrganizationActionsVariable {
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value: string;
    /** The date and time at which the variable was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the variable was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
    /** Visibility of a variable */
    visibility: OrganizationActionsVariableVisibility;
    selected_repositories_url?: string | undefined;
}
export interface GetPendingDeploymentsForRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface PendingDeploymentEnvironment {
    /** The id of the environment. */
    id?: number | undefined;
    node_id?: string | undefined;
    /** The name of the environment. */
    name?: string | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
}
/** The type of reviewer. */
export type DeploymentReviewerType = "User" | "Team";
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type PendingDeploymentReviewersItemReviewer = SimpleUser | Team;
export interface PendingDeploymentReviewersItem {
    type?: DeploymentReviewerType | undefined;
    reviewer?: PendingDeploymentReviewersItemReviewer | undefined;
}
/** The people or teams that may approve jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed. */
export type PendingDeploymentReviewersList = Array<PendingDeploymentReviewersItem>;
/** Details of a deployment that is waiting for protection rules to pass */
export interface PendingDeployment {
    environment: PendingDeploymentEnvironment;
    /** The set duration of the wait timer */
    wait_timer: number;
    /** The time that the wait timer began. */
    wait_timer_started_at: string | null;
    /** Whether the currently authenticated user can approve the deployment */
    current_user_can_approve: boolean;
    /** The people or teams that may approve jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed. */
    reviewers: PendingDeploymentReviewersList;
}
export type GetPendingDeploymentsForRunResponseBodyList = Array<PendingDeployment>;
export type GetPendingDeploymentsForRunResponse = GetPendingDeploymentsForRunResponseBodyList;
export interface GetPrivateRepoForkPrWorkflowsSettingsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface ActionsForkPrWorkflowsPrivateRepos {
    /** Whether workflows triggered by pull requests from forks are allowed to run on private repositories. */
    run_workflows_from_fork_pull_requests: boolean;
    /** Whether GitHub Actions can create pull requests or submit approving pull request reviews from a workflow triggered by a fork pull request. */
    send_write_tokens_to_workflows: boolean;
    /** Whether to make secrets and variables available to workflows triggered by pull requests from forks. */
    send_secrets_and_variables: boolean;
    /** Whether workflows triggered by pull requests from forks require approval from a repository administrator to run. */
    require_approval_for_fork_pr_workflows: boolean;
}
export interface GetPrivateRepoForkPrWorkflowsSettingsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetRepoActionsPoliciesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Include policies configured at higher levels that apply to this repository */
    has_parents?: boolean | undefined;
}
/** An array of Actions policies. */
export type GetRepoActionsPoliciesResponsePoliciesList = Array<ActionsPolicy>;
export interface GetRepoActionsPoliciesResponse {
    /** The total number of Actions policies. */
    total_count: number;
    /** An array of Actions policies. */
    policies: GetRepoActionsPoliciesResponsePoliciesList;
}
export interface GetRepoActionsPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the policy. */
    policy_id: number;
}
export interface GetRepoPublicKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetRepoSecretRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the secret. */
    secret_name: string;
}
export interface GetRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
}
export interface GetReviewsForRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface EnvironmentApprovalsEnvironmentsItem {
    /** The id of the environment. */
    id?: number | undefined;
    node_id?: string | undefined;
    /** The name of the environment. */
    name?: string | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    /** The time that the environment was created, in ISO 8601 format. */
    created_at?: string | undefined;
    /** The time that the environment was last updated, in ISO 8601 format. */
    updated_at?: string | undefined;
}
/** The list of environments that were approved or rejected */
export type EnvironmentApprovalsEnvironmentsList = Array<EnvironmentApprovalsEnvironmentsItem>;
/** Whether deployment to the environment(s) was approved or rejected or pending (with comments) */
export type EnvironmentApprovalsState = "approved" | "rejected" | "pending";
/** An entry in the reviews log for environment deployments */
export interface EnvironmentApprovals {
    /** The list of environments that were approved or rejected */
    environments: EnvironmentApprovalsEnvironmentsList;
    /** Whether deployment to the environment(s) was approved or rejected or pending (with comments) */
    state: EnvironmentApprovalsState;
    user: SimpleUser;
    /** The comment submitted with the deployment review */
    comment: string;
}
export type GetReviewsForRunResponseBodyList = Array<EnvironmentApprovals>;
export type GetReviewsForRunResponse = GetReviewsForRunResponseBodyList;
export interface GetRunnerVersionDeprecationForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The runner version to look up. */
    version: string;
}
export interface GetRunnerVersionDeprecationForOrgResponse {
    /** The runner version string. */
    runner_version: string;
    /** The date after which this runner version can no longer register. Only set for runner versions below the minimum version required to register (currently 2.329.0); `null` for versions with no registration end date. */
    registration_deprecates_at?: string | null | undefined;
    /** The date after which jobs will no longer be dispatched to runners on this version. `null` when no newer runner release exists yet. */
    runtime_deprecates_at?: string | null | undefined;
}
export interface GetRunnerVersionDeprecationForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The runner version to look up. */
    version: string;
}
export interface GetRunnerVersionDeprecationForRepoResponse {
    /** The runner version string. */
    runner_version: string;
    /** The date after which this runner version can no longer register. Only set for runner versions below the minimum version required to register (currently 2.329.0); `null` for versions with no registration end date. */
    registration_deprecates_at?: string | null | undefined;
    /** The date after which jobs will no longer be dispatched to runners on this version. `null` when no newer runner release exists yet. */
    runtime_deprecates_at?: string | null | undefined;
}
export interface GetSelfHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export interface GetSelfHostedRunnerForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export interface GetSelfHostedRunnerGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
}
export interface GetSelfHostedRunnersPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** The policy that controls whether self-hosted runners can be used by repositories in the organization */
export type SelfHostedRunnersSettingsEnabledRepositories = "all" | "selected" | "none";
export interface SelfHostedRunnersSettings {
    /** The policy that controls whether self-hosted runners can be used by repositories in the organization */
    enabled_repositories: SelfHostedRunnersSettingsEnabledRepositories;
    /** The URL to the endpoint for managing selected repositories for self-hosted runners in the organization */
    selected_repositories_url?: string | undefined;
}
export interface GetWorkflowRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the workflow. You can also pass the workflow file name as a string. */
    workflow_id: string;
}
export type WorkflowState = "active" | "deleted" | "disabled_fork" | "disabled_inactivity" | "disabled_manually";
/** A GitHub Actions workflow */
export interface Workflow {
    id: number;
    node_id: string;
    name: string;
    path: string;
    state: WorkflowState;
    created_at: string;
    updated_at: string;
    url: string;
    html_url: string;
    badge_url: string;
    deleted_at?: string | undefined;
}
export interface GetWorkflowAccessToRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Defines the level of access that workflows outside of the repository have to actions and reusable workflows within the repository. `none` means the access is only possible from workflows in this repository. `user` level access allows sharing across user owned private repositories only. `organization` level access allows sharing across the organization. */
export type ActionsWorkflowAccessToRepositoryAccessLevel = "none" | "user" | "organization";
export interface ActionsWorkflowAccessToRepository {
    /** Defines the level of access that workflows outside of the repository have to actions and reusable workflows within the repository. `none` means the access is only possible from workflows in this repository. `user` level access allows sharing across user owned private repositories only. `organization` level access allows sharing across the organization. */
    access_level: ActionsWorkflowAccessToRepositoryAccessLevel;
}
export interface GetWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** If `true` pull requests are omitted from the response (empty array). */
    exclude_pull_requests?: boolean | undefined;
}
/** A workflow referenced/reused by the initial caller workflow */
export interface ReferencedWorkflow {
    path: string;
    sha: string;
    ref?: string | undefined;
}
export type WorkflowRunReferencedWorkflowsList = Array<ReferencedWorkflow>;
export interface PullRequestMinimalHeadRepo {
    id: number;
    url: string;
    name: string;
}
export interface PullRequestMinimalHead {
    ref: string;
    sha: string;
    repo: PullRequestMinimalHeadRepo;
}
export type PullRequestMinimalBaseRepo = PullRequestMinimalHeadRepo;
export type PullRequestMinimalBase = PullRequestMinimalHead;
export interface PullRequestMinimal {
    id: number;
    number: number;
    url: string;
    head: PullRequestMinimalHead;
    base: PullRequestMinimalHead;
}
/** Pull requests that are open with a `head_sha` or `head_branch` that matches the workflow run. The returned pull requests do not necessarily indicate pull requests that triggered the run. */
export type WorkflowRunPullRequestsList = Array<PullRequestMinimal>;
/** Information about the Git author */
export interface NullableSimpleCommitAuthor {
    /** Name of the commit's author */
    name: string;
    /** Git email address of the commit's author */
    email: string;
}
/** Information about the Git committer */
export interface NullableSimpleCommitCommitter {
    /** Name of the commit's committer */
    name: string;
    /** Git email address of the commit's committer */
    email: string;
}
/** A commit. */
export interface NullableSimpleCommit {
    /** SHA for the commit */
    id: string;
    /** SHA for the commit's tree */
    tree_id: string;
    /** Message describing the purpose of the commit */
    message: string;
    /** Timestamp of the commit */
    timestamp: string;
    /** Information about the Git author */
    author: NullableSimpleCommitAuthor | null;
    /** Information about the Git committer */
    committer: NullableSimpleCommitCommitter | null;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
/** An invocation of a workflow */
export interface WorkflowRun {
    /** The ID of the workflow run. */
    id: number;
    /** The name of the workflow run. */
    name?: string | null | undefined;
    node_id: string;
    /** The ID of the associated check suite. */
    check_suite_id?: number | undefined;
    /** The node ID of the associated check suite. */
    check_suite_node_id?: string | undefined;
    head_branch: string | null;
    /** The SHA of the head commit that points to the version of the workflow being run. */
    head_sha: string;
    /** The full path of the workflow */
    path: string;
    /** The auto incrementing run number for the workflow run. */
    run_number: number;
    /** Attempt number of the run, 1 for first attempt and higher if the workflow was re-run. */
    run_attempt?: number | undefined;
    referenced_workflows?: WorkflowRunReferencedWorkflowsList | null | undefined;
    event: string;
    status: string | null;
    conclusion: string | null;
    /** The ID of the parent workflow. */
    workflow_id: number;
    /** The URL to the workflow run. */
    url: string;
    html_url: string;
    /** Pull requests that are open with a `head_sha` or `head_branch` that matches the workflow run. The returned pull requests do not necessarily indicate pull requests that triggered the run. */
    pull_requests: WorkflowRunPullRequestsList | null;
    created_at: string;
    updated_at: string;
    actor?: SimpleUser | undefined;
    triggering_actor?: SimpleUser | undefined;
    /** The start time of the latest run. Resets on re-run. */
    run_started_at?: string | undefined;
    /** The URL to the jobs for the workflow run. */
    jobs_url: string;
    /** The URL to download the logs for the workflow run. */
    logs_url: string;
    /** The URL to the associated check suite. */
    check_suite_url: string;
    /** The URL to the artifacts for the workflow run. */
    artifacts_url: string;
    /** The URL to cancel the workflow run. */
    cancel_url: string;
    /** The URL to rerun the workflow run. */
    rerun_url: string;
    /** The URL to the previous attempted run of this workflow, if one exists. */
    previous_attempt_url?: string | null | undefined;
    /** The URL to the workflow. */
    workflow_url: string;
    head_commit: NullableSimpleCommit | null;
    repository: MinimalRepository;
    head_repository: MinimalRepository;
    head_repository_id?: number | undefined;
    /** The event-specific title associated with the run or the run-name if set, or the value of `run-name` if it is set in the workflow. */
    display_title: string;
}
export interface GetWorkflowRunAttemptRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** The attempt number of the workflow run. */
    attempt_number: number;
    /** If `true` pull requests are omitted from the response (empty array). */
    exclude_pull_requests?: boolean | undefined;
}
export interface GetWorkflowRunUsageRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
}
export interface WorkflowRunUsageBillableUBUNTUJobRunsItem {
    job_id: number;
    duration_ms: number;
}
export type WorkflowRunUsageBillableUBUNTUJobRunsList = Array<WorkflowRunUsageBillableUBUNTUJobRunsItem>;
export interface WorkflowRunUsageBillableUBUNTU {
    total_ms: number;
    jobs: number;
    job_runs?: WorkflowRunUsageBillableUBUNTUJobRunsList | undefined;
}
export type WorkflowRunUsageBillableMACOSJobRunsItem = WorkflowRunUsageBillableUBUNTUJobRunsItem;
export type WorkflowRunUsageBillableMACOSJobRunsList = Array<WorkflowRunUsageBillableUBUNTUJobRunsItem>;
export interface WorkflowRunUsageBillableMACOS {
    total_ms: number;
    jobs: number;
    job_runs?: WorkflowRunUsageBillableMACOSJobRunsList | undefined;
}
export type WorkflowRunUsageBillableWINDOWSJobRunsItem = WorkflowRunUsageBillableUBUNTUJobRunsItem;
export type WorkflowRunUsageBillableWINDOWSJobRunsList = Array<WorkflowRunUsageBillableUBUNTUJobRunsItem>;
export interface WorkflowRunUsageBillableWINDOWS {
    total_ms: number;
    jobs: number;
    job_runs?: WorkflowRunUsageBillableWINDOWSJobRunsList | undefined;
}
export interface WorkflowRunUsageBillable {
    UBUNTU?: WorkflowRunUsageBillableUBUNTU | undefined;
    MACOS?: WorkflowRunUsageBillableMACOS | undefined;
    WINDOWS?: WorkflowRunUsageBillableWINDOWS | undefined;
}
/** Workflow Run Usage */
export interface WorkflowRunUsage {
    billable: WorkflowRunUsageBillable;
    run_duration_ms?: number | undefined;
}
export interface GetWorkflowUsageRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the workflow. You can also pass the workflow file name as a string. */
    workflow_id: string;
}
export interface WorkflowUsageBillableUBUNTU {
    total_ms?: number | undefined;
}
export type WorkflowUsageBillableMACOS = WorkflowUsageBillableUBUNTU;
export type WorkflowUsageBillableWINDOWS = WorkflowUsageBillableUBUNTU;
export interface WorkflowUsageBillable {
    UBUNTU?: WorkflowUsageBillableUBUNTU | undefined;
    MACOS?: WorkflowUsageBillableUBUNTU | undefined;
    WINDOWS?: WorkflowUsageBillableUBUNTU | undefined;
}
/** Workflow Usage */
export interface WorkflowUsage {
    billable: WorkflowUsageBillable;
}
export interface ListArtifactsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The name field of an artifact. When specified, only artifacts with this name will be returned. */
    name?: string | undefined;
}
export type ListArtifactsForRepoResponseArtifactsList = Array<Artifact>;
export interface ListArtifactsForRepoResponse {
    total_count: number;
    artifacts: ListArtifactsForRepoResponseArtifactsList;
}
export interface ListConcurrencyGroupsForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export interface ConcurrencyGroupListConcurrencyGroupsItem {
    /** The name of the concurrency group. */
    group_name: string;
    /** API URL for this concurrency group. */
    group_url: string;
    last_acquired_at: string | null;
}
export type ConcurrencyGroupListConcurrencyGroupsList = Array<ConcurrencyGroupListConcurrencyGroupsItem>;
/** A list of active concurrency groups for a repository. */
export interface ConcurrencyGroupList {
    total_count: number;
    concurrency_groups: ConcurrencyGroupListConcurrencyGroupsList;
}
export interface ListConcurrencyGroupsForWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
}
export type ConcurrencyGroupRunListConcurrencyGroupsItemGroupMembersItemStatus = "in_progress" | "pending";
export interface ConcurrencyGroupRunListConcurrencyGroupsItemGroupMembersItem {
    /** The ID of the workflow run. */
    run_id: number;
    /** The name of the workflow run. */
    run_name: string;
    /** API URL for the workflow run. */
    run_url: string | null;
    /** Web URL for the workflow run. */
    run_html_url: string | null;
    /** Queue position. 0 means the item holds the concurrency lease (in_progress), 1 or higher means queued (pending). */
    position: number;
    /** API URL to get items ahead of this item in the concurrency group. */
    position_url: string;
    /** The ID of the job, when the item represents a job-level or reusable-workflow-level lease. */
    job_id?: number | null | undefined;
    /** The display name of the job, when the item represents a job-level or reusable-workflow-level lease. */
    job_name?: string | null | undefined;
    /** API URL for the job. */
    job_url?: string | null | undefined;
    /** Web URL for the job. */
    job_html_url?: string | null | undefined;
    status: ConcurrencyGroupRunListConcurrencyGroupsItemGroupMembersItemStatus;
}
/** Items belonging to this workflow run that are either currently holding or waiting for the concurrency group lease. May be empty if the run no longer has any active or queued items in this group. */
export type ConcurrencyGroupRunListConcurrencyGroupsItemGroupMembersList = Array<ConcurrencyGroupRunListConcurrencyGroupsItemGroupMembersItem>;
export interface ConcurrencyGroupRunListConcurrencyGroupsItem {
    /** The name of the concurrency group. */
    group_name: string;
    /** API URL for this concurrency group. May return 404 if the group has no active items at the time it is requested, since the get-by-name endpoint reports the live repo-wide state of a group while this endpoint lists groups associated with a run by configuration. */
    group_url: string;
    /** Items belonging to this workflow run that are either currently holding or waiting for the concurrency group lease. May be empty if the run no longer has any active or queued items in this group. */
    group_members: ConcurrencyGroupRunListConcurrencyGroupsItemGroupMembersList;
}
export type ConcurrencyGroupRunListConcurrencyGroupsList = Array<ConcurrencyGroupRunListConcurrencyGroupsItem>;
/** A list of concurrency groups associated with a workflow run. */
export interface ConcurrencyGroupRunList {
    /** The total number of concurrency groups this workflow run participates in, derived from the run's configuration. This count is not filtered by whether the run currently holds or is waiting in each group, so it can include groups whose `group_members` array is empty (for example, when the run has already released its lease in that group). */
    total_count: number;
    concurrency_groups: ConcurrencyGroupRunListConcurrencyGroupsList;
}
export interface ListCustomImagesForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export type ListCustomImagesForOrgResponseImagesList = Array<ActionsHostedRunnerCustomImage>;
export interface ListCustomImagesForOrgResponse {
    total_count: number;
    images: ListCustomImagesForOrgResponseImagesList;
}
export interface ListCustomImageVersionsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Image definition ID of custom image */
    image_definition_id: number;
}
export type ListCustomImageVersionsForOrgResponseImageVersionsList = Array<ActionsHostedRunnerCustomImageVersion>;
export interface ListCustomImageVersionsForOrgResponse {
    total_count: number;
    image_versions: ListCustomImageVersionsForOrgResponseImageVersionsList;
}
export interface ListEnvironmentSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListEnvironmentSecretsResponseSecretsList = Array<ActionsSecret>;
export interface ListEnvironmentSecretsResponse {
    total_count: number;
    secrets: ListEnvironmentSecretsResponseSecretsList;
}
export interface ListEnvironmentVariablesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListEnvironmentVariablesResponseVariablesList = Array<ActionsVariable>;
export interface ListEnvironmentVariablesResponse {
    total_count: number;
    variables: ListEnvironmentVariablesResponseVariablesList;
}
export interface ListGithubHostedRunnersInGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListGithubHostedRunnersInGroupForOrgResponseRunnersList = Array<ActionsHostedRunner>;
export interface ListGithubHostedRunnersInGroupForOrgResponse {
    total_count: number;
    runners: ListGithubHostedRunnersInGroupForOrgResponseRunnersList;
}
export interface ListHostedRunnersForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListHostedRunnersForOrgResponseRunnersList = Array<ActionsHostedRunner>;
export interface ListHostedRunnersForOrgResponse {
    total_count: number;
    runners: ListHostedRunnersForOrgResponseRunnersList;
}
export type ListJobsForWorkflowRunRequestFilter = "latest" | "all";
export interface ListJobsForWorkflowRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** Filters jobs by their `completed_at` timestamp. `latest` returns jobs from the most recent execution of the workflow run. `all` returns all jobs for a workflow run, including from old executions of the workflow run. */
    filter?: ListJobsForWorkflowRunRequestFilter | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListJobsForWorkflowRunResponseJobsList = Array<Job>;
export interface ListJobsForWorkflowRunResponse {
    total_count: number;
    jobs: ListJobsForWorkflowRunResponseJobsList;
}
export interface ListJobsForWorkflowRunAttemptRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** The attempt number of the workflow run. */
    attempt_number: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListJobsForWorkflowRunAttemptResponseJobsList = Array<Job>;
export interface ListJobsForWorkflowRunAttemptResponse {
    total_count: number;
    jobs: ListJobsForWorkflowRunAttemptResponseJobsList;
}
export interface ListLabelsForSelfHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export type ListLabelsForSelfHostedRunnerForOrgResponseLabelsList = Array<RunnerLabel>;
export interface ListLabelsForSelfHostedRunnerForOrgResponse {
    total_count: number;
    labels: ListLabelsForSelfHostedRunnerForOrgResponseLabelsList;
}
export interface ListLabelsForSelfHostedRunnerForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export type ListLabelsForSelfHostedRunnerForRepoResponseLabelsList = Array<RunnerLabel>;
export interface ListLabelsForSelfHostedRunnerForRepoResponse {
    total_count: number;
    labels: ListLabelsForSelfHostedRunnerForRepoResponseLabelsList;
}
export interface ListOrgSecretsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgSecretsResponseSecretsList = Array<OrganizationActionsSecret>;
export interface ListOrgSecretsResponse {
    total_count: number;
    secrets: ListOrgSecretsResponseSecretsList;
}
export interface ListOrgVariablesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgVariablesResponseVariablesList = Array<OrganizationActionsVariable>;
export interface ListOrgVariablesResponse {
    total_count: number;
    variables: ListOrgVariablesResponseVariablesList;
}
export interface ListRepoAccessToSelfHostedRunnerGroupInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListRepoAccessToSelfHostedRunnerGroupInOrgResponseRepositoriesList = Array<MinimalRepository>;
export interface ListRepoAccessToSelfHostedRunnerGroupInOrgResponse {
    total_count: number;
    repositories: ListRepoAccessToSelfHostedRunnerGroupInOrgResponseRepositoriesList;
}
export interface ListRepoOrganizationSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoOrganizationSecretsResponseSecretsList = Array<ActionsSecret>;
export interface ListRepoOrganizationSecretsResponse {
    total_count: number;
    secrets: ListRepoOrganizationSecretsResponseSecretsList;
}
export interface ListRepoOrganizationVariablesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoOrganizationVariablesResponseVariablesList = Array<ActionsVariable>;
export interface ListRepoOrganizationVariablesResponse {
    total_count: number;
    variables: ListRepoOrganizationVariablesResponseVariablesList;
}
export interface ListRepoSecretsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoSecretsResponseSecretsList = Array<ActionsSecret>;
export interface ListRepoSecretsResponse {
    total_count: number;
    secrets: ListRepoSecretsResponseSecretsList;
}
export interface ListRepoVariablesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoVariablesResponseVariablesList = Array<ActionsVariable>;
export interface ListRepoVariablesResponse {
    total_count: number;
    variables: ListRepoVariablesResponseVariablesList;
}
export interface ListRepoWorkflowsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoWorkflowsResponseWorkflowsList = Array<Workflow>;
export interface ListRepoWorkflowsResponse {
    total_count: number;
    workflows: ListRepoWorkflowsResponseWorkflowsList;
}
export interface ListRunnerApplicationsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** Runner Application */
export interface RunnerApplication {
    os: string;
    architecture: string;
    download_url: string;
    filename: string;
    /** A short lived bearer token used to download the runner, if needed. */
    temp_download_token?: string | undefined;
    sha256_checksum?: string | undefined;
}
export type ListRunnerApplicationsForOrgResponseBodyList = Array<RunnerApplication>;
export type ListRunnerApplicationsForOrgResponse = ListRunnerApplicationsForOrgResponseBodyList;
export interface ListRunnerApplicationsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type ListRunnerApplicationsForRepoResponseBodyList = Array<RunnerApplication>;
export type ListRunnerApplicationsForRepoResponse = ListRunnerApplicationsForRepoResponseBodyList;
export interface ListSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListSelectedReposForOrgSecretResponseRepositoriesList = Array<MinimalRepository>;
export interface ListSelectedReposForOrgSecretResponse {
    total_count: number;
    repositories: ListSelectedReposForOrgSecretResponseRepositoriesList;
}
export interface ListSelectedReposForOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListSelectedReposForOrgVariableResponseRepositoriesList = Array<MinimalRepository>;
export interface ListSelectedReposForOrgVariableResponse {
    total_count: number;
    repositories: ListSelectedReposForOrgVariableResponseRepositoriesList;
}
export interface ListSelectedRepositoriesEnabledGithubActionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSelectedRepositoriesEnabledGithubActionsOrganizationResponseRepositoriesList = Array<Repository>;
export interface ListSelectedRepositoriesEnabledGithubActionsOrganizationResponse {
    total_count: number;
    repositories: ListSelectedRepositoriesEnabledGithubActionsOrganizationResponseRepositoriesList;
}
export interface ListSelectedRepositoriesSelfHostedRunnersOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSelectedRepositoriesSelfHostedRunnersOrganizationResponseRepositoriesList = Array<Repository>;
export interface ListSelectedRepositoriesSelfHostedRunnersOrganizationResponse {
    total_count?: number | undefined;
    repositories: ListSelectedRepositoriesSelfHostedRunnersOrganizationResponseRepositoriesList;
}
export interface ListSelfHostedRunnerGroupsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Only return runner groups that are allowed to be used by this repository. */
    visible_to_repository?: string | undefined;
}
export type ListSelfHostedRunnerGroupsForOrgResponseRunnerGroupsList = Array<RunnerGroupsOrg>;
export interface ListSelfHostedRunnerGroupsForOrgResponse {
    total_count: number;
    runner_groups: ListSelfHostedRunnerGroupsForOrgResponseRunnerGroupsList;
}
export interface ListSelfHostedRunnersForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of a self-hosted runner. */
    name?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSelfHostedRunnersForOrgResponseRunnersList = Array<Runner>;
export interface ListSelfHostedRunnersForOrgResponse {
    total_count: number;
    runners: ListSelfHostedRunnersForOrgResponseRunnersList;
}
export interface ListSelfHostedRunnersForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of a self-hosted runner. */
    name?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSelfHostedRunnersForRepoResponseRunnersList = Array<Runner>;
export interface ListSelfHostedRunnersForRepoResponse {
    total_count: number;
    runners: ListSelfHostedRunnersForRepoResponseRunnersList;
}
export interface ListSelfHostedRunnersInGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSelfHostedRunnersInGroupForOrgResponseRunnersList = Array<Runner>;
export interface ListSelfHostedRunnersInGroupForOrgResponse {
    total_count: number;
    runners: ListSelfHostedRunnersInGroupForOrgResponseRunnersList;
}
export type ListWorkflowRunArtifactsRequestDirection = "asc" | "desc";
export interface ListWorkflowRunArtifactsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The name field of an artifact. When specified, only artifacts with this name will be returned. */
    name?: string | undefined;
    /** The direction to sort the results by. */
    direction?: ListWorkflowRunArtifactsRequestDirection | (string & {}) | undefined;
}
export type ListWorkflowRunArtifactsResponseArtifactsList = Array<Artifact>;
export interface ListWorkflowRunArtifactsResponse {
    total_count: number;
    artifacts: ListWorkflowRunArtifactsResponseArtifactsList;
}
export type ListWorkflowRunsRequestStatus = "completed" | "action_required" | "cancelled" | "failure" | "neutral" | "skipped" | "stale" | "success" | "timed_out" | "in_progress" | "queued" | "requested" | "waiting" | "pending";
export interface ListWorkflowRunsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the workflow. You can also pass the workflow file name as a string. */
    workflow_id: string;
    /** Returns someone's workflow runs. Use the login for the user who created the `push` associated with the check suite or workflow run. */
    actor?: string | undefined;
    /** Returns workflow runs associated with a branch. Use the name of the branch of the `push`. */
    branch?: string | undefined;
    /** Returns workflow run triggered by the event you specify. For example, `push`, `pull_request` or `issue`. For more information, see "[Events that trigger workflows](https://docs.github.com/actions/automating-your-workflow-with-github-actions/events-that-trigger-workflows)." */
    event?: string | undefined;
    /** Returns workflow runs with the check run `status` or `conclusion` that you specify. For example, a conclusion can be `success` or a status can be `in_progress`. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. */
    status?: ListWorkflowRunsRequestStatus | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Returns workflow runs created within the given date-time range. For more information on the syntax, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)." */
    created?: string | undefined;
    /** If `true` pull requests are omitted from the response (empty array). */
    exclude_pull_requests?: boolean | undefined;
    /** Returns workflow runs with the `check_suite_id` that you specify. */
    check_suite_id?: number | undefined;
    /** Only returns workflow runs that are associated with the specified `head_sha`. */
    head_sha?: string | undefined;
}
export type ListWorkflowRunsResponseWorkflowRunsList = Array<WorkflowRun>;
export interface ListWorkflowRunsResponse {
    total_count: number;
    workflow_runs: ListWorkflowRunsResponseWorkflowRunsList;
}
export type ListWorkflowRunsForRepoRequestStatus = "completed" | "action_required" | "cancelled" | "failure" | "neutral" | "skipped" | "stale" | "success" | "timed_out" | "in_progress" | "queued" | "requested" | "waiting" | "pending";
export interface ListWorkflowRunsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Returns someone's workflow runs. Use the login for the user who created the `push` associated with the check suite or workflow run. */
    actor?: string | undefined;
    /** Returns workflow runs associated with a branch. Use the name of the branch of the `push`. */
    branch?: string | undefined;
    /** Returns workflow run triggered by the event you specify. For example, `push`, `pull_request` or `issue`. For more information, see "[Events that trigger workflows](https://docs.github.com/actions/automating-your-workflow-with-github-actions/events-that-trigger-workflows)." */
    event?: string | undefined;
    /** Returns workflow runs with the check run `status` or `conclusion` that you specify. For example, a conclusion can be `success` or a status can be `in_progress`. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. */
    status?: ListWorkflowRunsForRepoRequestStatus | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Returns workflow runs created within the given date-time range. For more information on the syntax, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)." */
    created?: string | undefined;
    /** If `true` pull requests are omitted from the response (empty array). */
    exclude_pull_requests?: boolean | undefined;
    /** Returns workflow runs with the `check_suite_id` that you specify. */
    check_suite_id?: number | undefined;
    /** Only returns workflow runs that are associated with the specified `head_sha`. */
    head_sha?: string | undefined;
}
export type ListWorkflowRunsForRepoResponseWorkflowRunsList = Array<WorkflowRun>;
export interface ListWorkflowRunsForRepoResponse {
    total_count: number;
    workflow_runs: ListWorkflowRunsForRepoResponseWorkflowRunsList;
}
export interface RemoveAllCustomLabelsFromSelfHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export type RemoveAllCustomLabelsFromSelfHostedRunnerForOrgResponseLabelsList = Array<RunnerLabel>;
export interface RemoveAllCustomLabelsFromSelfHostedRunnerForOrgResponse {
    total_count: number;
    labels: RemoveAllCustomLabelsFromSelfHostedRunnerForOrgResponseLabelsList;
}
export interface RemoveAllCustomLabelsFromSelfHostedRunnerForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export type RemoveAllCustomLabelsFromSelfHostedRunnerForRepoResponseLabelsList = Array<RunnerLabel>;
export interface RemoveAllCustomLabelsFromSelfHostedRunnerForRepoResponse {
    total_count: number;
    labels: RemoveAllCustomLabelsFromSelfHostedRunnerForRepoResponseLabelsList;
}
export interface RemoveCustomLabelFromSelfHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
    /** The name of a self-hosted runner's custom label. */
    name: string;
}
export type RemoveCustomLabelFromSelfHostedRunnerForOrgResponseLabelsList = Array<RunnerLabel>;
export interface RemoveCustomLabelFromSelfHostedRunnerForOrgResponse {
    total_count: number;
    labels: RemoveCustomLabelFromSelfHostedRunnerForOrgResponseLabelsList;
}
export interface RemoveCustomLabelFromSelfHostedRunnerForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
    /** The name of a self-hosted runner's custom label. */
    name: string;
}
export type RemoveCustomLabelFromSelfHostedRunnerForRepoResponseLabelsList = Array<RunnerLabel>;
export interface RemoveCustomLabelFromSelfHostedRunnerForRepoResponse {
    total_count: number;
    labels: RemoveCustomLabelFromSelfHostedRunnerForRepoResponseLabelsList;
}
export interface RemoveRepoAccessToSelfHostedRunnerGroupInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface RemoveRepoAccessToSelfHostedRunnerGroupInOrgResponse {
}
export interface RemoveSelectedRepoFromOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    repository_id: number;
}
export interface RemoveSelectedRepoFromOrgSecretResponse {
}
export interface RemoveSelectedRepoFromOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    repository_id: number;
}
export interface RemoveSelectedRepoFromOrgVariableResponse {
}
export interface RemoveSelfHostedRunnerFromGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
}
export interface RemoveSelfHostedRunnerFromGroupForOrgResponse {
}
export interface ReRunWorkflowRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** Whether to enable debug logging for the re-run. */
    enable_debug_logging?: boolean | undefined;
}
export type ReRunWorkflowResponse = unknown;
export interface ReRunWorkflowFailedJobsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** Whether to enable debug logging for the re-run. */
    enable_debug_logging?: boolean | undefined;
}
export type ReRunWorkflowFailedJobsResponse = unknown;
export interface ReviewCustomGatesCommentRequired {
    /** The name of the environment to approve or reject. */
    environment_name: string;
    /** Comment associated with the pending deployment protection rule. **Required when state is not provided.** */
    comment: string;
}
/** Whether to approve or reject deployment to the specified environments. */
export type ReviewCustomGatesStateRequiredState = "approved" | "rejected";
export interface ReviewCustomGatesStateRequired {
    /** The name of the environment to approve or reject. */
    environment_name: string;
    /** Whether to approve or reject deployment to the specified environments. */
    state: ReviewCustomGatesStateRequiredState | (string & {});
    /** Optional comment to include with the review. */
    comment?: string | undefined;
}
export type ReviewCustomGatesForRunRequestBody = ReviewCustomGatesCommentRequired | ReviewCustomGatesStateRequired;
export interface ReviewCustomGatesForRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    body: ReviewCustomGatesForRunRequestBody;
}
export interface ReviewCustomGatesForRunResponse {
}
/** The list of environment ids to approve or reject */
export type ReviewPendingDeploymentsForRunRequestEnvironmentIdsList = Array<number>;
/** Whether to approve or reject deployment to the specified environments. */
export type ReviewPendingDeploymentsForRunRequestState = "approved" | "rejected";
export interface ReviewPendingDeploymentsForRunRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the workflow run. */
    run_id: number;
    /** The list of environment ids to approve or reject */
    environment_ids: ReviewPendingDeploymentsForRunRequestEnvironmentIdsList;
    /** Whether to approve or reject deployment to the specified environments. */
    state: ReviewPendingDeploymentsForRunRequestState | (string & {});
    /** A comment to accompany the deployment review */
    comment: string;
}
export type DeploymentPayloadCase0Map = {
    [key: string]: unknown | undefined;
};
export type DeploymentPayload = DeploymentPayloadCase0Map | string;
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type NullableIntegrationOwner = SimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface NullableIntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
/** A request for a specific ref(branch,sha,tag) to be deployed */
export interface Deployment {
    url: string;
    /** Unique identifier of the deployment */
    id: number;
    node_id: string;
    sha: string;
    /** The ref to deploy. This can be a branch, tag, or sha. */
    ref: string;
    /** Parameter to specify a task to execute */
    task: string;
    payload: DeploymentPayload;
    original_environment?: string | undefined;
    /** Name for the target deployment environment. */
    environment: string;
    description: string | null;
    creator: SimpleUser | null;
    created_at: string;
    updated_at: string;
    statuses_url: string;
    repository_url: string;
    /** Specifies if the given environment is will no longer exist at some point in the future. Default: false. */
    transient_environment?: boolean | undefined;
    /** Specifies if the given environment is one that end-users directly interact with. Default: false. */
    production_environment?: boolean | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
}
export type ReviewPendingDeploymentsForRunResponseBodyList = Array<Deployment>;
export type ReviewPendingDeploymentsForRunResponse = ReviewPendingDeploymentsForRunResponseBodyList;
export interface RunReRunJobForWorkflowRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the job. */
    job_id: number;
    /** Whether to enable debug logging for the re-run. */
    enable_debug_logging?: boolean | undefined;
    /** Whether to enable the debugger for the re-run of this job. */
    enable_debugger?: boolean | undefined;
}
export type RunReRunJobForWorkflowResponse = unknown;
export interface SetActionsCacheRetentionLimitForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** For repositories & organizations in an enterprise, the maximum duration, in days, for which caches in a repository may be retained. */
    max_cache_retention_days?: number | undefined;
}
export interface SetActionsCacheRetentionLimitForEnterpriseResponse {
}
export interface SetActionsCacheRetentionLimitForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** For repositories in this organization, the maximum duration, in days, for which caches in a repository may be retained. */
    max_cache_retention_days?: number | undefined;
}
export interface SetActionsCacheRetentionLimitForOrganizationResponse {
}
export interface SetActionsCacheRetentionLimitForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The maximum number of days to keep caches in this repository. */
    max_cache_retention_days?: number | undefined;
}
export interface SetActionsCacheRetentionLimitForRepositoryResponse {
}
export interface SetActionsCacheStorageLimitForEnterpriseRequest {
    /** The slug version of the enterprise name. */
    enterprise: string;
    /** For repositories & organizations in an enterprise, the maximum size limit for the sum of all caches in a repository, in gigabytes. */
    max_cache_size_gb?: number | undefined;
}
export interface SetActionsCacheStorageLimitForEnterpriseResponse {
}
export interface SetActionsCacheStorageLimitForOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** For repositories in the organization, the maximum size limit for the sum of all caches in a repository, in gigabytes. */
    max_cache_size_gb?: number | undefined;
}
export interface SetActionsCacheStorageLimitForOrganizationResponse {
}
export interface SetActionsCacheStorageLimitForRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The maximum total cache size for this repository, in gigabytes. */
    max_cache_size_gb?: number | undefined;
}
export interface SetActionsCacheStorageLimitForRepositoryResponse {
}
/** Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`. > [!NOTE] > The `patterns_allowed` setting only applies to public repositories. */
export type SetAllowedActionsOrganizationRequestPatternsAllowedList = Array<string>;
export interface SetAllowedActionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Whether GitHub-owned actions are allowed. For example, this includes the actions in the `actions` organization. */
    github_owned_allowed?: boolean | undefined;
    /** Whether actions from GitHub Marketplace verified creators are allowed. Set to `true` to allow all actions by GitHub Marketplace verified creators. */
    verified_allowed?: boolean | undefined;
    /** Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`. > [!NOTE] > The `patterns_allowed` setting only applies to public repositories. */
    patterns_allowed?: SetAllowedActionsOrganizationRequestPatternsAllowedList | undefined;
}
export interface SetAllowedActionsOrganizationResponse {
}
/** Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`. > [!NOTE] > The `patterns_allowed` setting only applies to public repositories. */
export type SetAllowedActionsRepositoryRequestPatternsAllowedList = Array<string>;
export interface SetAllowedActionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Whether GitHub-owned actions are allowed. For example, this includes the actions in the `actions` organization. */
    github_owned_allowed?: boolean | undefined;
    /** Whether actions from GitHub Marketplace verified creators are allowed. Set to `true` to allow all actions by GitHub Marketplace verified creators. */
    verified_allowed?: boolean | undefined;
    /** Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`. > [!NOTE] > The `patterns_allowed` setting only applies to public repositories. */
    patterns_allowed?: SetAllowedActionsRepositoryRequestPatternsAllowedList | undefined;
}
export interface SetAllowedActionsRepositoryResponse {
}
export interface SetArtifactAndLogRetentionSettingsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of days to retain checks, workflow runs, commit statuses, artifacts, and logs */
    days: number;
}
export interface SetArtifactAndLogRetentionSettingsOrganizationResponse {
}
export interface SetArtifactAndLogRetentionSettingsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of days to retain checks, workflow runs, commit statuses, artifacts, and logs */
    days: number;
}
export interface SetArtifactAndLogRetentionSettingsRepositoryResponse {
}
/** The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels. */
export type SetCustomLabelsForSelfHostedRunnerForOrgRequestLabelsList = Array<string>;
export interface SetCustomLabelsForSelfHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
    /** The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels. */
    labels: SetCustomLabelsForSelfHostedRunnerForOrgRequestLabelsList;
}
export type SetCustomLabelsForSelfHostedRunnerForOrgResponseLabelsList = Array<RunnerLabel>;
export interface SetCustomLabelsForSelfHostedRunnerForOrgResponse {
    total_count: number;
    labels: SetCustomLabelsForSelfHostedRunnerForOrgResponseLabelsList;
}
/** The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels. */
export type SetCustomLabelsForSelfHostedRunnerForRepoRequestLabelsList = Array<string>;
export interface SetCustomLabelsForSelfHostedRunnerForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Unique identifier of the self-hosted runner. */
    runner_id: number;
    /** The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels. */
    labels: SetCustomLabelsForSelfHostedRunnerForRepoRequestLabelsList;
}
export type SetCustomLabelsForSelfHostedRunnerForRepoResponseLabelsList = Array<RunnerLabel>;
export interface SetCustomLabelsForSelfHostedRunnerForRepoResponse {
    total_count: number;
    labels: SetCustomLabelsForSelfHostedRunnerForRepoResponseLabelsList;
}
/** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
export type SetCustomOidcSubClaimForRepoRequestIncludeClaimKeysList = Array<string>;
export interface SetCustomOidcSubClaimForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Whether to use the default template or not. If `true`, the `include_claim_keys` field is ignored. */
    use_default: boolean;
    /** Array of unique strings. Each claim key can only contain alphanumeric characters and underscores. */
    include_claim_keys?: SetCustomOidcSubClaimForRepoRequestIncludeClaimKeysList | undefined;
    /** Whether to opt in to the immutable OIDC subject claim format for this repository. When `true`, OIDC tokens will use a stable, repository-ID-based `sub` claim. */
    use_immutable_subject?: boolean | undefined;
}
export type SetCustomOidcSubClaimForRepoResponse = unknown;
/** The policy that controls when fork PR workflows require approval from a maintainer. */
export type SetForkPrContributorApprovalPermissionsOrganizationRequestApprovalPolicy = "first_time_contributors_new_to_github" | "first_time_contributors" | "all_external_contributors";
export interface SetForkPrContributorApprovalPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The policy that controls when fork PR workflows require approval from a maintainer. */
    approval_policy: SetForkPrContributorApprovalPermissionsOrganizationRequestApprovalPolicy | (string & {});
}
export interface SetForkPrContributorApprovalPermissionsOrganizationResponse {
}
/** The policy that controls when fork PR workflows require approval from a maintainer. */
export type SetForkPrContributorApprovalPermissionsRepositoryRequestApprovalPolicy = "first_time_contributors_new_to_github" | "first_time_contributors" | "all_external_contributors";
export interface SetForkPrContributorApprovalPermissionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The policy that controls when fork PR workflows require approval from a maintainer. */
    approval_policy: SetForkPrContributorApprovalPermissionsRepositoryRequestApprovalPolicy | (string & {});
}
export interface SetForkPrContributorApprovalPermissionsRepositoryResponse {
}
export interface SetGithubActionsDefaultWorkflowPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    default_workflow_permissions?: ActionsDefaultWorkflowPermissions | (string & {}) | undefined;
    can_approve_pull_request_reviews?: boolean | undefined;
}
export interface SetGithubActionsDefaultWorkflowPermissionsOrganizationResponse {
}
export interface SetGithubActionsDefaultWorkflowPermissionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    default_workflow_permissions?: ActionsDefaultWorkflowPermissions | (string & {}) | undefined;
    can_approve_pull_request_reviews?: boolean | undefined;
}
export interface SetGithubActionsDefaultWorkflowPermissionsRepositoryResponse {
}
export interface SetGithubActionsPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    enabled_repositories: EnabledRepositories | (string & {});
    allowed_actions?: AllowedActions | (string & {}) | undefined;
    sha_pinning_required?: boolean | undefined;
}
export interface SetGithubActionsPermissionsOrganizationResponse {
}
export interface SetGithubActionsPermissionsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    enabled: boolean;
    allowed_actions?: AllowedActions | (string & {}) | undefined;
    sha_pinning_required?: boolean | undefined;
}
export interface SetGithubActionsPermissionsRepositoryResponse {
}
export interface SetPrivateRepoForkPrWorkflowsSettingsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Whether workflows triggered by pull requests from forks are allowed to run on private repositories. */
    run_workflows_from_fork_pull_requests: boolean;
    /** Whether GitHub Actions can create pull requests or submit approving pull request reviews from a workflow triggered by a fork pull request. */
    send_write_tokens_to_workflows?: boolean | undefined;
    /** Whether to make secrets and variables available to workflows triggered by pull requests from forks. */
    send_secrets_and_variables?: boolean | undefined;
    /** Whether workflows triggered by pull requests from forks require approval from a repository administrator to run. */
    require_approval_for_fork_pr_workflows?: boolean | undefined;
}
export interface SetPrivateRepoForkPrWorkflowsSettingsOrganizationResponse {
}
export interface SetPrivateRepoForkPrWorkflowsSettingsRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Whether workflows triggered by pull requests from forks are allowed to run on private repositories. */
    run_workflows_from_fork_pull_requests: boolean;
    /** Whether GitHub Actions can create pull requests or submit approving pull request reviews from a workflow triggered by a fork pull request. */
    send_write_tokens_to_workflows?: boolean | undefined;
    /** Whether to make secrets and variables available to workflows triggered by pull requests from forks. */
    send_secrets_and_variables?: boolean | undefined;
    /** Whether workflows triggered by pull requests from forks require approval from a repository administrator to run. */
    require_approval_for_fork_pr_workflows?: boolean | undefined;
}
export interface SetPrivateRepoForkPrWorkflowsSettingsRepositoryResponse {
}
/** List of repository IDs that can access the runner group. */
export type SetRepoAccessToSelfHostedRunnerGroupInOrgRequestSelectedRepositoryIdsList = Array<number>;
export interface SetRepoAccessToSelfHostedRunnerGroupInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** List of repository IDs that can access the runner group. */
    selected_repository_ids: SetRepoAccessToSelfHostedRunnerGroupInOrgRequestSelectedRepositoryIdsList;
}
export interface SetRepoAccessToSelfHostedRunnerGroupInOrgResponse {
}
/** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Add selected repository to an organization secret](https://docs.github.com/rest/actions/secrets#add-selected-repository-to-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
export type SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedReposForOrgSecretRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the secret. */
    secret_name: string;
    /** An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Add selected repository to an organization secret](https://docs.github.com/rest/actions/secrets#add-selected-repository-to-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) endpoints. */
    selected_repository_ids: SetSelectedReposForOrgSecretRequestSelectedRepositoryIdsList;
}
export interface SetSelectedReposForOrgSecretResponse {
}
/** The IDs of the repositories that can access the organization variable. */
export type SetSelectedReposForOrgVariableRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedReposForOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The IDs of the repositories that can access the organization variable. */
    selected_repository_ids: SetSelectedReposForOrgVariableRequestSelectedRepositoryIdsList;
}
export interface SetSelectedReposForOrgVariableResponse {
}
/** List of repository IDs to enable for GitHub Actions. */
export type SetSelectedRepositoriesEnabledGithubActionsOrganizationRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedRepositoriesEnabledGithubActionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** List of repository IDs to enable for GitHub Actions. */
    selected_repository_ids: SetSelectedRepositoriesEnabledGithubActionsOrganizationRequestSelectedRepositoryIdsList;
}
export interface SetSelectedRepositoriesEnabledGithubActionsOrganizationResponse {
}
/** IDs of repositories that can use repository-level self-hosted runners */
export type SetSelectedRepositoriesSelfHostedRunnersOrganizationRequestSelectedRepositoryIdsList = Array<number>;
export interface SetSelectedRepositoriesSelfHostedRunnersOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** IDs of repositories that can use repository-level self-hosted runners */
    selected_repository_ids: SetSelectedRepositoriesSelfHostedRunnersOrganizationRequestSelectedRepositoryIdsList;
}
export interface SetSelectedRepositoriesSelfHostedRunnersOrganizationResponse {
}
/** List of runner IDs to add to the runner group. */
export type SetSelfHostedRunnersInGroupForOrgRequestRunnersList = Array<number>;
export interface SetSelfHostedRunnersInGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** List of runner IDs to add to the runner group. */
    runners: SetSelfHostedRunnersInGroupForOrgRequestRunnersList;
}
export interface SetSelfHostedRunnersInGroupForOrgResponse {
}
/** The policy that controls whether self-hosted runners can be used in the organization */
export type SetSelfHostedRunnersPermissionsOrganizationRequestEnabledRepositories = "all" | "selected" | "none";
export interface SetSelfHostedRunnersPermissionsOrganizationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The policy that controls whether self-hosted runners can be used in the organization */
    enabled_repositories: SetSelfHostedRunnersPermissionsOrganizationRequestEnabledRepositories | (string & {});
}
export interface SetSelfHostedRunnersPermissionsOrganizationResponse {
}
/** Defines the level of access that workflows outside of the repository have to actions and reusable workflows within the repository. `none` means the access is only possible from workflows in this repository. `user` level access allows sharing across user owned private repositories only. `organization` level access allows sharing across the organization. */
export type SetWorkflowAccessToRepositoryRequestAccessLevel = "none" | "user" | "organization";
export interface SetWorkflowAccessToRepositoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Defines the level of access that workflows outside of the repository have to actions and reusable workflows within the repository. `none` means the access is only possible from workflows in this repository. `user` level access allows sharing across user owned private repositories only. `organization` level access allows sharing across the organization. */
    access_level: SetWorkflowAccessToRepositoryRequestAccessLevel | (string & {});
}
export interface SetWorkflowAccessToRepositoryResponse {
}
export interface UpdateEnvironmentVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value?: string | undefined;
}
export interface UpdateEnvironmentVariableResponse {
}
/** The source type of the runner image to use. Must match the source of the image specified by `image_id`. Can be one of `github`, `partner`, or `custom`. */
export type UpdateHostedRunnerForOrgRequestImageSource = "github" | "partner" | "custom";
export interface UpdateHostedRunnerForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the GitHub-hosted runner. */
    hosted_runner_id: number;
    /** Name of the runner. Must be between 1 and 64 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'. */
    name?: string | undefined;
    /** The existing runner group to add this runner to. */
    runner_group_id?: number | undefined;
    /** The maximum amount of runners to scale up to. Runners will not auto-scale above this number. Use this setting to limit your cost. */
    maximum_runners?: number | undefined;
    /** Whether this runner should be updated with a static public IP. Note limit on account. To list limits on account, use `GET actions/hosted-runners/limits` */
    enable_static_ip?: boolean | undefined;
    /** The machine size of the runner. To list available sizes, use `GET actions/hosted-runners/machine-sizes` */
    size?: string | undefined;
    /** The source type of the runner image to use. Must match the source of the image specified by `image_id`. Can be one of `github`, `partner`, or `custom`. */
    image_source?: UpdateHostedRunnerForOrgRequestImageSource | (string & {}) | undefined;
    /** The unique identifier of the runner image. To list available images, use `GET /actions/hosted-runners/images/github-owned`, `GET /actions/hosted-runners/images/partner`, or `GET /actions/hosted-runners/images/custom`. */
    image_id?: string | undefined;
    /** The version of the runner image to deploy. This is relevant only for runners using custom images. */
    image_version?: string | null | undefined;
    /** Whether to enable image generation for this runner pool. When enabled, the runner pool is used to build and publish custom runner images. */
    image_gen?: boolean | undefined;
}
/** An array of rules within the policy. */
export type UpdateOrgActionsPolicyRequestRulesList = Array<ActionsRule>;
export interface UpdateOrgActionsPolicyRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the policy. */
    policy_id: number;
    /** The name of the policy. */
    name?: string | undefined;
    enforcement?: RepositoryRuleEnforcement | (string & {}) | undefined;
    conditions?: ActionsPolicyOrgConditions | undefined;
    /** An array of rules within the policy. */
    rules?: UpdateOrgActionsPolicyRequestRulesList | undefined;
}
/** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
export type UpdateOrgVariableRequestVisibility = "all" | "private" | "selected";
/** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
export type UpdateOrgVariableRequestSelectedRepositoryIdsList = Array<number>;
export interface UpdateOrgVariableRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value?: string | undefined;
    /** The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable. */
    visibility?: UpdateOrgVariableRequestVisibility | (string & {}) | undefined;
    /** An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`. */
    selected_repository_ids?: UpdateOrgVariableRequestSelectedRepositoryIdsList | undefined;
}
export interface UpdateOrgVariableResponse {
}
/** An array of rules within the policy. */
export type UpdateRepoActionsPolicyRequestRulesList = Array<ActionsRule>;
export interface UpdateRepoActionsPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the policy. */
    policy_id: number;
    /** The name of the policy. */
    name?: string | undefined;
    enforcement?: RepositoryRuleEnforcement | (string & {}) | undefined;
    conditions?: ActionsPolicyRepoConditions | undefined;
    /** An array of rules within the policy. */
    rules?: UpdateRepoActionsPolicyRequestRulesList | undefined;
}
export interface UpdateRepoVariableRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the variable. */
    name: string;
    /** The value of the variable. */
    value?: string | undefined;
}
export interface UpdateRepoVariableResponse {
}
/** Visibility of a runner group. You can select all repositories, select individual repositories, or all private repositories. */
export type UpdateSelfHostedRunnerGroupForOrgRequestVisibility = "selected" | "all" | "private";
/** List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`. */
export type UpdateSelfHostedRunnerGroupForOrgRequestSelectedWorkflowsList = Array<string>;
export interface UpdateSelfHostedRunnerGroupForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Unique identifier of the self-hosted runner group. */
    runner_group_id: number;
    /** Name of the runner group. */
    name: string;
    /** Visibility of a runner group. You can select all repositories, select individual repositories, or all private repositories. */
    visibility?: UpdateSelfHostedRunnerGroupForOrgRequestVisibility | (string & {}) | undefined;
    /** Whether the runner group can be used by `public` repositories. */
    allows_public_repositories?: boolean | undefined;
    /** If `true`, the runner group will be restricted to running only the workflows specified in the `selected_workflows` array. */
    restricted_to_workflows?: boolean | undefined;
    /** List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`. */
    selected_workflows?: UpdateSelfHostedRunnerGroupForOrgRequestSelectedWorkflowsList | undefined;
    /** The identifier of a hosted compute network configuration. */
    network_configuration_id?: string | null | undefined;
}
export type AddCustomLabelsToSelfHostedRunnerForOrgError = GithubOpError;
/** Add custom labels to a self-hosted runner for an organization Adds custom labels to a self-hosted runner configured in an organization. Authenticated users must have admin access to the organization to use this endpoint. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const addCustomLabelsToSelfHostedRunnerForOrg: API.OperationMethod<AddCustomLabelsToSelfHostedRunnerForOrgRequest, AddCustomLabelsToSelfHostedRunnerForOrgResponse, AddCustomLabelsToSelfHostedRunnerForOrgError, GithubOpContext>;
export type AddCustomLabelsToSelfHostedRunnerForRepoError = GithubOpError;
/** Add custom labels to a self-hosted runner for a repository Adds custom labels to a self-hosted runner configured in a repository. Authenticated users must have admin access to the organization to use this endpoint. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const addCustomLabelsToSelfHostedRunnerForRepo: API.OperationMethod<AddCustomLabelsToSelfHostedRunnerForRepoRequest, AddCustomLabelsToSelfHostedRunnerForRepoResponse, AddCustomLabelsToSelfHostedRunnerForRepoError, GithubOpContext>;
export type AddRepoAccessToSelfHostedRunnerGroupInOrgError = GithubOpError;
/** Add repository access to a self-hosted runner group in an organization Adds a repository to the list of repositories that can access a self-hosted runner group. The runner group must have `visibility` set to `selected`. For more information, see "[Create a self-hosted runner group for an organization](#create-a-self-hosted-runner-group-for-an-organization)." OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const addRepoAccessToSelfHostedRunnerGroupInOrg: API.OperationMethod<AddRepoAccessToSelfHostedRunnerGroupInOrgRequest, AddRepoAccessToSelfHostedRunnerGroupInOrgResponse, AddRepoAccessToSelfHostedRunnerGroupInOrgError, GithubOpContext>;
export type AddSelectedRepoToOrgSecretError = GithubOpError;
/** Add selected repository to an organization secret Adds a repository to an organization secret when the `visibility` for repository access is set to `selected`. For more information about setting the visibility, see [Create or update an organization secret](https://docs.github.com/rest/actions/secrets#create-or-update-an-organization-secret). Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const addSelectedRepoToOrgSecret: API.OperationMethod<AddSelectedRepoToOrgSecretRequest, AddSelectedRepoToOrgSecretResponse, AddSelectedRepoToOrgSecretError, GithubOpContext>;
export type AddSelectedRepoToOrgVariableError = GithubOpError;
/** Add selected repository to an organization variable Adds a repository to an organization variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const addSelectedRepoToOrgVariable: API.OperationMethod<AddSelectedRepoToOrgVariableRequest, AddSelectedRepoToOrgVariableResponse, AddSelectedRepoToOrgVariableError, GithubOpContext>;
export type AddSelfHostedRunnerToGroupForOrgError = GithubOpError;
/** Add a self-hosted runner to a group for an organization Adds a self-hosted runner to a runner group configured in an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const addSelfHostedRunnerToGroupForOrg: API.OperationMethod<AddSelfHostedRunnerToGroupForOrgRequest, AddSelfHostedRunnerToGroupForOrgResponse, AddSelfHostedRunnerToGroupForOrgError, GithubOpContext>;
export type ApproveWorkflowRunError = GithubOpError;
/** Approve a workflow run for a fork pull request Approves a workflow run for a pull request from a public fork of a first time contributor. For more information, see ["Approving workflow runs from public forks](https://docs.github.com/actions/managing-workflow-runs/approving-workflow-runs-from-public-forks)." OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const approveWorkflowRun: API.OperationMethod<ApproveWorkflowRunRequest, ApproveWorkflowRunResponse, ApproveWorkflowRunError, GithubOpContext>;
export type CancelWorkflowRunError = GithubOpError;
/** Cancel a workflow run Cancels a workflow run using its `id`. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const cancelWorkflowRun: API.OperationMethod<CancelWorkflowRunRequest, CancelWorkflowRunResponse, CancelWorkflowRunError, GithubOpContext>;
export type CreateEnvironmentVariableError = GithubOpError;
/** Create an environment variable Create an environment variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createEnvironmentVariable: API.OperationMethod<CreateEnvironmentVariableRequest, CreateEnvironmentVariableResponse, CreateEnvironmentVariableError, GithubOpContext>;
export type CreateHostedRunnerForOrgError = GithubOpError;
/** Create a GitHub-hosted runner for an organization Creates a GitHub-hosted runner for an organization. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const createHostedRunnerForOrg: API.OperationMethod<CreateHostedRunnerForOrgRequest, ActionsHostedRunner, CreateHostedRunnerForOrgError, GithubOpContext>;
export type CreateOrgActionsPolicyError = GithubOpError;
/** Create an organization Actions policy Create an Actions policy for an organization. Omitting `workflow_path` targets all workflows without storing an explicit condition. */
export declare const createOrgActionsPolicy: API.OperationMethod<CreateOrgActionsPolicyRequest, ActionsPolicy, CreateOrgActionsPolicyError, GithubOpContext>;
export type CreateOrgVariableError = GithubOpError;
/** Create an organization variable Creates an organization variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrgVariable: API.OperationMethod<CreateOrgVariableRequest, CreateOrgVariableResponse, CreateOrgVariableError, GithubOpContext>;
export type CreateOrUpdateEnvironmentSecretError = GithubOpError;
/** Create or update an environment secret Creates or updates an environment secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateEnvironmentSecret: API.OperationMethod<CreateOrUpdateEnvironmentSecretRequest, CreateOrUpdateEnvironmentSecretResponse, CreateOrUpdateEnvironmentSecretError, GithubOpContext>;
export type CreateOrUpdateOrgSecretError = GithubOpError;
/** Create or update an organization secret Creates or updates an organization secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateOrgSecret: API.OperationMethod<CreateOrUpdateOrgSecretRequest, CreateOrUpdateOrgSecretResponse, CreateOrUpdateOrgSecretError, GithubOpContext>;
export type CreateOrUpdateRepoSecretError = GithubOpError;
/** Create or update a repository secret Creates or updates a repository secret with an encrypted value. Encrypt your secret using [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages). For more information, see "[Encrypting secrets for the REST API](https://docs.github.com/rest/guides/encrypting-secrets-for-the-rest-api)." Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateRepoSecret: API.OperationMethod<CreateOrUpdateRepoSecretRequest, CreateOrUpdateRepoSecretResponse, CreateOrUpdateRepoSecretError, GithubOpContext>;
export type CreateRegistrationTokenForOrgError = GithubOpError;
/** Create a registration token for an organization Returns a token that you can pass to the `config` script. The token expires after one hour. For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to configure your self-hosted runner: ``` ./config.sh --url https://github.com/octo-org --token TOKEN ``` Authenticated users must have admin access to the organization to use this endpoint. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRegistrationTokenForOrg: API.OperationMethod<CreateRegistrationTokenForOrgRequest, AuthenticationToken, CreateRegistrationTokenForOrgError, GithubOpContext>;
export type CreateRegistrationTokenForRepoError = GithubOpError;
/** Create a registration token for a repository Returns a token that you can pass to the `config` script. The token expires after one hour. For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to configure your self-hosted runner: ``` ./config.sh --url https://github.com/octo-org --token TOKEN ``` Authenticated users must have admin access to the repository to use this endpoint. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRegistrationTokenForRepo: API.OperationMethod<CreateRegistrationTokenForRepoRequest, AuthenticationToken, CreateRegistrationTokenForRepoError, GithubOpContext>;
export type CreateRemoveTokenForOrgError = GithubOpError;
/** Create a remove token for an organization Returns a token that you can pass to the `config` script to remove a self-hosted runner from an organization. The token expires after one hour. For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to remove your self-hosted runner from an organization: ``` ./config.sh remove --token TOKEN ``` Authenticated users must have admin access to the organization to use this endpoint. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRemoveTokenForOrg: API.OperationMethod<CreateRemoveTokenForOrgRequest, AuthenticationToken, CreateRemoveTokenForOrgError, GithubOpContext>;
export type CreateRemoveTokenForRepoError = GithubOpError;
/** Create a remove token for a repository Returns a token that you can pass to the `config` script to remove a self-hosted runner from an repository. The token expires after one hour. For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to remove your self-hosted runner from an organization: ``` ./config.sh remove --token TOKEN ``` Authenticated users must have admin access to the repository to use this endpoint. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRemoveTokenForRepo: API.OperationMethod<CreateRemoveTokenForRepoRequest, AuthenticationToken, CreateRemoveTokenForRepoError, GithubOpContext>;
export type CreateRepoActionsPolicyError = GithubOpError;
/** Create a repository Actions policy Create an Actions policy for a repository. Omitting `workflow_path` targets all workflows without storing an explicit condition. */
export declare const createRepoActionsPolicy: API.OperationMethod<CreateRepoActionsPolicyRequest, ActionsPolicy, CreateRepoActionsPolicyError, GithubOpContext>;
export type CreateRepoVariableError = GithubOpError;
/** Create a repository variable Creates a repository variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createRepoVariable: API.OperationMethod<CreateRepoVariableRequest, CreateRepoVariableResponse, CreateRepoVariableError, GithubOpContext>;
export type CreateSelfHostedRunnerGroupForOrgError = GithubOpError;
/** Create a self-hosted runner group for an organization Creates a new self-hosted runner group for an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const createSelfHostedRunnerGroupForOrg: API.OperationMethod<CreateSelfHostedRunnerGroupForOrgRequest, RunnerGroupsOrg, CreateSelfHostedRunnerGroupForOrgError, GithubOpContext>;
export type CreateWorkflowDispatchError = GithubOpError;
/** Create a workflow dispatch event You can use this endpoint to manually trigger a GitHub Actions workflow run. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. You must configure your GitHub Actions workflow to run when the [`workflow_dispatch` webhook](/developers/webhooks-and-events/webhook-events-and-payloads#workflow_dispatch) event occurs. The `inputs` are configured in the workflow file. For more information about how to configure the `workflow_dispatch` event in the workflow file, see "[Events that trigger workflows](/actions/reference/events-that-trigger-workflows#workflow_dispatch)." OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createWorkflowDispatch: API.OperationMethod<CreateWorkflowDispatchRequest, WorkflowDispatchResponse, CreateWorkflowDispatchError, GithubOpContext>;
export type DeleteActionsCacheByIdError = GithubOpError;
/** Delete a GitHub Actions cache for a repository (using a cache ID) Deletes a GitHub Actions cache for a repository, using a cache ID. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteActionsCacheById: API.OperationMethod<DeleteActionsCacheByIdRequest, DeleteActionsCacheByIdResponse, DeleteActionsCacheByIdError, GithubOpContext>;
export type DeleteActionsCacheByKeyError = GithubOpError;
/** Delete GitHub Actions caches for a repository (using a cache key) Deletes one or more GitHub Actions caches for a repository, using a complete cache key. By default, all caches that match the provided key are deleted, but you can optionally provide a Git ref to restrict deletions to caches that match both the provided key and the Git ref. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteActionsCacheByKey: API.OperationMethod<DeleteActionsCacheByKeyRequest, ActionsCacheList, DeleteActionsCacheByKeyError, GithubOpContext>;
export type DeleteArtifactError = GithubOpError;
/** Delete an artifact Deletes an artifact for a workflow run. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteArtifact: API.OperationMethod<DeleteArtifactRequest, DeleteArtifactResponse, DeleteArtifactError, GithubOpContext>;
export type DeleteCustomImageFromOrgError = GithubOpError;
/** Delete a custom image from the organization Delete a custom image from the organization. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const deleteCustomImageFromOrg: API.OperationMethod<DeleteCustomImageFromOrgRequest, DeleteCustomImageFromOrgResponse, DeleteCustomImageFromOrgError, GithubOpContext>;
export type DeleteCustomImageVersionFromOrgError = GithubOpError;
/** Delete an image version of custom image from the organization Delete an image version of custom image from the organization. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const deleteCustomImageVersionFromOrg: API.OperationMethod<DeleteCustomImageVersionFromOrgRequest, DeleteCustomImageVersionFromOrgResponse, DeleteCustomImageVersionFromOrgError, GithubOpContext>;
export type DeleteEnvironmentSecretError = GithubOpError;
/** Delete an environment secret Deletes a secret in an environment using the secret name. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteEnvironmentSecret: API.OperationMethod<DeleteEnvironmentSecretRequest, DeleteEnvironmentSecretResponse, DeleteEnvironmentSecretError, GithubOpContext>;
export type DeleteEnvironmentVariableError = GithubOpError;
/** Delete an environment variable Deletes an environment variable using the variable name. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteEnvironmentVariable: API.OperationMethod<DeleteEnvironmentVariableRequest, DeleteEnvironmentVariableResponse, DeleteEnvironmentVariableError, GithubOpContext>;
export type DeleteHostedRunnerForOrgError = GithubOpError;
/** Delete a GitHub-hosted runner for an organization Deletes a GitHub-hosted runner for an organization. */
export declare const deleteHostedRunnerForOrg: API.OperationMethod<DeleteHostedRunnerForOrgRequest, DeleteHostedRunnerForOrgResponse, DeleteHostedRunnerForOrgError, GithubOpContext>;
export type DeleteOrgActionsPolicyError = GithubOpError;
/** Delete an organization Actions policy Delete an Actions policy for an organization. */
export declare const deleteOrgActionsPolicy: API.OperationMethod<DeleteOrgActionsPolicyRequest, DeleteOrgActionsPolicyResponse, DeleteOrgActionsPolicyError, GithubOpContext>;
export type DeleteOrgSecretError = GithubOpError;
/** Delete an organization secret Deletes a secret in an organization using the secret name. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteOrgSecret: API.OperationMethod<DeleteOrgSecretRequest, DeleteOrgSecretResponse, DeleteOrgSecretError, GithubOpContext>;
export type DeleteOrgVariableError = GithubOpError;
/** Delete an organization variable Deletes an organization variable using the variable name. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteOrgVariable: API.OperationMethod<DeleteOrgVariableRequest, DeleteOrgVariableResponse, DeleteOrgVariableError, GithubOpContext>;
export type DeleteRepoActionsPolicyError = GithubOpError;
/** Delete a repository Actions policy Delete an Actions policy for a repository. */
export declare const deleteRepoActionsPolicy: API.OperationMethod<DeleteRepoActionsPolicyRequest, DeleteRepoActionsPolicyResponse, DeleteRepoActionsPolicyError, GithubOpContext>;
export type DeleteRepoSecretError = GithubOpError;
/** Delete a repository secret Deletes a secret in a repository using the secret name. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteRepoSecret: API.OperationMethod<DeleteRepoSecretRequest, DeleteRepoSecretResponse, DeleteRepoSecretError, GithubOpContext>;
export type DeleteRepoVariableError = GithubOpError;
/** Delete a repository variable Deletes a repository variable using the variable name. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteRepoVariable: API.OperationMethod<DeleteRepoVariableRequest, DeleteRepoVariableResponse, DeleteRepoVariableError, GithubOpContext>;
export type DeleteSelfHostedRunnerFromOrgError = GithubOpError;
/** Delete a self-hosted runner from an organization Forces the removal of a self-hosted runner from an organization. You can use this endpoint to completely remove the runner when the machine you were using no longer exists. Authenticated users must have admin access to the organization to use this endpoint. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteSelfHostedRunnerFromOrg: API.OperationMethod<DeleteSelfHostedRunnerFromOrgRequest, DeleteSelfHostedRunnerFromOrgResponse, DeleteSelfHostedRunnerFromOrgError, GithubOpContext>;
export type DeleteSelfHostedRunnerFromRepoError = GithubOpError;
/** Delete a self-hosted runner from a repository Forces the removal of a self-hosted runner from a repository. You can use this endpoint to completely remove the runner when the machine you were using no longer exists. Authenticated users must have admin access to the repository to use this endpoint. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteSelfHostedRunnerFromRepo: API.OperationMethod<DeleteSelfHostedRunnerFromRepoRequest, DeleteSelfHostedRunnerFromRepoResponse, DeleteSelfHostedRunnerFromRepoError, GithubOpContext>;
export type DeleteSelfHostedRunnerGroupFromOrgError = GithubOpError;
/** Delete a self-hosted runner group from an organization Deletes a self-hosted runner group for an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const deleteSelfHostedRunnerGroupFromOrg: API.OperationMethod<DeleteSelfHostedRunnerGroupFromOrgRequest, DeleteSelfHostedRunnerGroupFromOrgResponse, DeleteSelfHostedRunnerGroupFromOrgError, GithubOpContext>;
export type DeleteWorkflowRunError = GithubOpError;
/** Delete a workflow run Deletes a specific workflow run. Anyone with write access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteWorkflowRun: API.OperationMethod<DeleteWorkflowRunRequest, DeleteWorkflowRunResponse, DeleteWorkflowRunError, GithubOpContext>;
export type DeleteWorkflowRunLogsError = GithubOpError;
/** Delete workflow run logs Deletes all logs for a workflow run. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteWorkflowRunLogs: API.OperationMethod<DeleteWorkflowRunLogsRequest, DeleteWorkflowRunLogsResponse, DeleteWorkflowRunLogsError, GithubOpContext>;
export type DisableSelectedRepositoryGithubActionsOrganizationError = GithubOpError;
/** Disable a selected repository for GitHub Actions in an organization Removes a repository from the list of selected repositories that are enabled for GitHub Actions in an organization. To use this endpoint, the organization permission policy for `enabled_repositories` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for an organization](#set-github-actions-permissions-for-an-organization)." OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const disableSelectedRepositoryGithubActionsOrganization: API.OperationMethod<DisableSelectedRepositoryGithubActionsOrganizationRequest, DisableSelectedRepositoryGithubActionsOrganizationResponse, DisableSelectedRepositoryGithubActionsOrganizationError, GithubOpContext>;
export type DisableSelectedRepositorySelfHostedRunnersOrganizationError = GithubOpError;
/** Remove a repository from the list of repositories allowed to use self-hosted runners in an organization Removes a repository from the list of repositories that are allowed to use self-hosted runners in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const disableSelectedRepositorySelfHostedRunnersOrganization: API.OperationMethod<DisableSelectedRepositorySelfHostedRunnersOrganizationRequest, DisableSelectedRepositorySelfHostedRunnersOrganizationResponse, DisableSelectedRepositorySelfHostedRunnersOrganizationError, GithubOpContext>;
export type DisableWorkflowError = GithubOpError;
/** Disable a workflow Disables a workflow and sets the `state` of the workflow to `disabled_manually`. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const disableWorkflow: API.OperationMethod<DisableWorkflowRequest, DisableWorkflowResponse, DisableWorkflowError, GithubOpContext>;
export type DownloadArtifactError = GithubOpError;
/** Download an artifact Gets a redirect URL to download an archive for a repository. This URL expires after 1 minute. Look for `Location:` in the response header to find the URL for the download. The `:archive_format` must be `zip`. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const downloadArtifact: API.OperationMethod<DownloadArtifactRequest, DownloadArtifactResponse, DownloadArtifactError, GithubOpContext>;
export type DownloadJobLogsForWorkflowRunError = GithubOpError;
/** Download job logs for a workflow run Gets a redirect URL to download a plain text file of logs for a workflow job. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const downloadJobLogsForWorkflowRun: API.OperationMethod<DownloadJobLogsForWorkflowRunRequest, DownloadJobLogsForWorkflowRunResponse, DownloadJobLogsForWorkflowRunError, GithubOpContext>;
export type DownloadStepLogsForWorkflowRunJobError = GithubOpError;
/** Download step logs for a workflow run job Gets a redirect URL to download a plain text file of logs for a specific step of a workflow job. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download. This endpoint is intended for selective retrieval of one step. To download complete job logs, use the [job logs endpoint](https://docs.github.com/rest/actions/workflow-jobs#download-job-logs-for-a-workflow-run). Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const downloadStepLogsForWorkflowRunJob: API.OperationMethod<DownloadStepLogsForWorkflowRunJobRequest, DownloadStepLogsForWorkflowRunJobResponse, DownloadStepLogsForWorkflowRunJobError, GithubOpContext>;
export type DownloadWorkflowRunAttemptLogsError = GithubOpError;
/** Download workflow run attempt logs Gets a redirect URL to download an archive of log files for a specific workflow run attempt. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const downloadWorkflowRunAttemptLogs: API.OperationMethod<DownloadWorkflowRunAttemptLogsRequest, DownloadWorkflowRunAttemptLogsResponse, DownloadWorkflowRunAttemptLogsError, GithubOpContext>;
export type DownloadWorkflowRunLogsError = GithubOpError;
/** Download workflow run logs Gets a redirect URL to download an archive of log files for a workflow run. This link expires after 1 minute. Look for `Location:` in the response header to find the URL for the download. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const downloadWorkflowRunLogs: API.OperationMethod<DownloadWorkflowRunLogsRequest, DownloadWorkflowRunLogsResponse, DownloadWorkflowRunLogsError, GithubOpContext>;
export type EnableSelectedRepositoryGithubActionsOrganizationError = GithubOpError;
/** Enable a selected repository for GitHub Actions in an organization Adds a repository to the list of selected repositories that are enabled for GitHub Actions in an organization. To use this endpoint, the organization permission policy for `enabled_repositories` must be must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for an organization](#set-github-actions-permissions-for-an-organization)." OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const enableSelectedRepositoryGithubActionsOrganization: API.OperationMethod<EnableSelectedRepositoryGithubActionsOrganizationRequest, EnableSelectedRepositoryGithubActionsOrganizationResponse, EnableSelectedRepositoryGithubActionsOrganizationError, GithubOpContext>;
export type EnableSelectedRepositorySelfHostedRunnersOrganizationError = GithubOpError;
/** Add a repository to the list of repositories allowed to use self-hosted runners in an organization Adds a repository to the list of repositories that are allowed to use self-hosted runners in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const enableSelectedRepositorySelfHostedRunnersOrganization: API.OperationMethod<EnableSelectedRepositorySelfHostedRunnersOrganizationRequest, EnableSelectedRepositorySelfHostedRunnersOrganizationResponse, EnableSelectedRepositorySelfHostedRunnersOrganizationError, GithubOpContext>;
export type EnableWorkflowError = GithubOpError;
/** Enable a workflow Enables a workflow and sets the `state` of the workflow to `active`. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const enableWorkflow: API.OperationMethod<EnableWorkflowRequest, EnableWorkflowResponse, EnableWorkflowError, GithubOpContext>;
export type ForceCancelWorkflowRunError = GithubOpError;
/** Force cancel a workflow run Cancels a workflow run and bypasses conditions that would otherwise cause a workflow execution to continue, such as an `always()` condition on a job. You should only use this endpoint to cancel a workflow run when the workflow run is not responding to [`POST /repos/{owner}/{repo}/actions/runs/{run_id}/cancel`](/rest/actions/workflow-runs#cancel-a-workflow-run). OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const forceCancelWorkflowRun: API.OperationMethod<ForceCancelWorkflowRunRequest, ForceCancelWorkflowRunResponse, ForceCancelWorkflowRunError, GithubOpContext>;
export type GenerateRunnerJitconfigForOrgError = GithubOpError;
/** Create configuration for a just-in-time runner for an organization Generates a configuration that can be passed to the runner application at startup. The authenticated user must have admin access to the organization. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const generateRunnerJitconfigForOrg: API.OperationMethod<GenerateRunnerJitconfigForOrgRequest, GenerateRunnerJitconfigForOrgResponse, GenerateRunnerJitconfigForOrgError, GithubOpContext>;
export type GenerateRunnerJitconfigForRepoError = GithubOpError;
/** Create configuration for a just-in-time runner for a repository Generates a configuration that can be passed to the runner application at startup. The authenticated user must have admin access to the repository. OAuth tokens and personal access tokens (classic) need the`repo` scope to use this endpoint. */
export declare const generateRunnerJitconfigForRepo: API.OperationMethod<GenerateRunnerJitconfigForRepoRequest, GenerateRunnerJitconfigForRepoResponse, GenerateRunnerJitconfigForRepoError, GithubOpContext>;
export type GetActionsCacheListError = GithubOpError;
/** List GitHub Actions caches for a repository Lists the GitHub Actions caches for a repository. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getActionsCacheList: API.PaginatedOperationMethod<GetActionsCacheListRequest, ActionsCacheList, GetActionsCacheListError, GithubOpContext, ActionsCacheListActionsCachesItem>;
export type GetActionsCacheRetentionLimitForEnterpriseError = GithubOpError;
/** Get GitHub Actions cache retention limit for an enterprise Gets GitHub Actions cache retention limit for an enterprise. All organizations and repositories under this enterprise may not set a higher cache retention limit. OAuth tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const getActionsCacheRetentionLimitForEnterprise: API.OperationMethod<GetActionsCacheRetentionLimitForEnterpriseRequest, ActionsCacheRetentionLimitForEnterprise, GetActionsCacheRetentionLimitForEnterpriseError, GithubOpContext>;
export type GetActionsCacheRetentionLimitForOrganizationError = GithubOpError;
/** Get GitHub Actions cache retention limit for an organization Gets GitHub Actions cache retention limit for an organization. All repositories under this organization may not set a higher cache retention limit. OAuth tokens and personal access tokens (classic) need the `admin:organization` scope to use this endpoint. */
export declare const getActionsCacheRetentionLimitForOrganization: API.OperationMethod<GetActionsCacheRetentionLimitForOrganizationRequest, ActionsCacheRetentionLimitForOrganization, GetActionsCacheRetentionLimitForOrganizationError, GithubOpContext>;
export type GetActionsCacheRetentionLimitForRepositoryError = GithubOpError;
/** Get GitHub Actions cache retention limit for a repository Gets GitHub Actions cache retention limit for a repository. This determines how long caches will be retained for, if not manually removed or evicted due to size constraints. OAuth tokens and personal access tokens (classic) need the `admin:repository` scope to use this endpoint. */
export declare const getActionsCacheRetentionLimitForRepository: API.OperationMethod<GetActionsCacheRetentionLimitForRepositoryRequest, ActionsCacheRetentionLimitForRepository, GetActionsCacheRetentionLimitForRepositoryError, GithubOpContext>;
export type GetActionsCacheStorageLimitForEnterpriseError = GithubOpError;
/** Get GitHub Actions cache storage limit for an enterprise Gets GitHub Actions cache storage limit for an enterprise. All organizations and repositories under this enterprise may not set a higher cache storage limit. OAuth tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const getActionsCacheStorageLimitForEnterprise: API.OperationMethod<GetActionsCacheStorageLimitForEnterpriseRequest, ActionsCacheStorageLimitForEnterprise, GetActionsCacheStorageLimitForEnterpriseError, GithubOpContext>;
export type GetActionsCacheStorageLimitForOrganizationError = GithubOpError;
/** Get GitHub Actions cache storage limit for an organization Gets GitHub Actions cache storage limit for an organization. All repositories under this organization may not set a higher cache storage limit. OAuth tokens and personal access tokens (classic) need the `admin:organization` scope to use this endpoint. */
export declare const getActionsCacheStorageLimitForOrganization: API.OperationMethod<GetActionsCacheStorageLimitForOrganizationRequest, ActionsCacheStorageLimitForOrganization, GetActionsCacheStorageLimitForOrganizationError, GithubOpContext>;
export type GetActionsCacheStorageLimitForRepositoryError = GithubOpError;
/** Get GitHub Actions cache storage limit for a repository Gets GitHub Actions cache storage limit for a repository. This determines the maximum size of caches that can be stored before eviction occurs. OAuth tokens and personal access tokens (classic) need the `admin:repository` scope to use this endpoint. */
export declare const getActionsCacheStorageLimitForRepository: API.OperationMethod<GetActionsCacheStorageLimitForRepositoryRequest, ActionsCacheStorageLimitForRepository, GetActionsCacheStorageLimitForRepositoryError, GithubOpContext>;
export type GetActionsCacheUsageError = GithubOpError;
/** Get GitHub Actions cache usage for a repository Gets GitHub Actions cache usage for a repository. The data fetched using this API is refreshed approximately every 5 minutes, so values returned from this endpoint may take at least 5 minutes to get updated. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getActionsCacheUsage: API.OperationMethod<GetActionsCacheUsageRequest, ActionsCacheUsageByRepository, GetActionsCacheUsageError, GithubOpContext>;
export type GetActionsCacheUsageByRepoForOrgError = GithubOpError;
/** List repositories with GitHub Actions cache usage for an organization Lists repositories and their GitHub Actions cache usage for an organization. The data fetched using this API is refreshed approximately every 5 minutes, so values returned from this endpoint may take at least 5 minutes to get updated. OAuth tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getActionsCacheUsageByRepoForOrg: API.PaginatedOperationMethod<GetActionsCacheUsageByRepoForOrgRequest, GetActionsCacheUsageByRepoForOrgResponse, GetActionsCacheUsageByRepoForOrgError, GithubOpContext, ActionsCacheUsageByRepository>;
export type GetActionsCacheUsageForOrgError = GithubOpError;
/** Get GitHub Actions cache usage for an organization Gets the total GitHub Actions cache usage for an organization. The data fetched using this API is refreshed approximately every 5 minutes, so values returned from this endpoint may take at least 5 minutes to get updated. OAuth tokens and personal access tokens (classic) need the `read:org` scope to use this endpoint. */
export declare const getActionsCacheUsageForOrg: API.OperationMethod<GetActionsCacheUsageForOrgRequest, ActionsCacheUsageOrgEnterprise, GetActionsCacheUsageForOrgError, GithubOpContext>;
export type GetAllowedActionsOrganizationError = GithubOpError;
/** Get allowed actions and reusable workflows for an organization Gets the selected actions and reusable workflows that are allowed in an organization. To use this endpoint, the organization permission policy for `allowed_actions` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for an organization](#set-github-actions-permissions-for-an-organization)." OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getAllowedActionsOrganization: API.OperationMethod<GetAllowedActionsOrganizationRequest, SelectedActions, GetAllowedActionsOrganizationError, GithubOpContext>;
export type GetAllowedActionsRepositoryError = GithubOpError;
/** Get allowed actions and reusable workflows for a repository Gets the settings for selected actions and reusable workflows that are allowed in a repository. To use this endpoint, the repository policy for `allowed_actions` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for a repository](#set-github-actions-permissions-for-a-repository)." OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getAllowedActionsRepository: API.OperationMethod<GetAllowedActionsRepositoryRequest, SelectedActions, GetAllowedActionsRepositoryError, GithubOpContext>;
export type GetArtifactError = GithubOpError;
/** Get an artifact Gets a specific artifact for a workflow run. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getArtifact: API.OperationMethod<GetArtifactRequest, Artifact, GetArtifactError, GithubOpContext>;
export type GetArtifactAndLogRetentionSettingsOrganizationError = GithubOpError;
/** Get artifact and log retention settings for an organization Gets retention settings for checks, workflow runs, commit statuses, artifacts, and logs for an organization. Checks include check suites, check runs, and check annotations. These settings also apply to checks and commit statuses created by third-party integrations, and are not limited to data created by GitHub Actions. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const getArtifactAndLogRetentionSettingsOrganization: API.OperationMethod<GetArtifactAndLogRetentionSettingsOrganizationRequest, ActionsArtifactAndLogRetentionResponse, GetArtifactAndLogRetentionSettingsOrganizationError, GithubOpContext>;
export type GetArtifactAndLogRetentionSettingsRepositoryError = GithubOpError;
/** Get artifact and log retention settings for a repository Gets retention settings for checks, workflow runs, commit statuses, artifacts, and logs for a repository. Checks include check suites, check runs, and check annotations. These settings also apply to checks and commit statuses created by third-party integrations, and are not limited to data created by GitHub Actions. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getArtifactAndLogRetentionSettingsRepository: API.OperationMethod<GetArtifactAndLogRetentionSettingsRepositoryRequest, ActionsArtifactAndLogRetentionResponse, GetArtifactAndLogRetentionSettingsRepositoryError, GithubOpContext>;
export type GetConcurrencyGroupForRepositoryError = GithubOpError;
/** Get a concurrency group for a repository Gets a specific concurrency group for a repository, including all instances in the group's queue. Returns 404 if the group is inactive or does not exist. Optionally, pass `ahead_of_run` or `ahead_of_job` to filter the results to only the items ahead of the specified workflow run or job in the queue, plus the specified item itself (returned as the last element). This is useful for determining what is blocking a particular run or job. Returns 422 if the specified run or job is not in this concurrency group. When using `ahead_of_run`, this matches workflow-level concurrency and any reusable-workflow leases held on behalf of that run. Job-level leases within the run are not considered to block the run as a whole. Use `ahead_of_job` to match job-level concurrency and reusable-workflow leases on the job's ancestor paths. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getConcurrencyGroupForRepository: API.OperationMethod<GetConcurrencyGroupForRepositoryRequest, ConcurrencyGroup, GetConcurrencyGroupForRepositoryError, GithubOpContext>;
export type GetCustomImageForOrgError = GithubOpError;
/** Get a custom image definition for GitHub Actions Hosted Runners Get a custom image definition for GitHub Actions Hosted Runners. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const getCustomImageForOrg: API.OperationMethod<GetCustomImageForOrgRequest, ActionsHostedRunnerCustomImage, GetCustomImageForOrgError, GithubOpContext>;
export type GetCustomImageVersionForOrgError = GithubOpError;
/** Get an image version of a custom image for GitHub Actions Hosted Runners Get an image version of a custom image for GitHub Actions Hosted Runners. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const getCustomImageVersionForOrg: API.OperationMethod<GetCustomImageVersionForOrgRequest, ActionsHostedRunnerCustomImageVersion, GetCustomImageVersionForOrgError, GithubOpContext>;
export type GetCustomOidcSubClaimForRepoError = GithubOpError;
/** Get the customization template for an OIDC subject claim for a repository Gets the customization template for an OpenID Connect (OIDC) subject claim. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getCustomOidcSubClaimForRepo: API.OperationMethod<GetCustomOidcSubClaimForRepoRequest, OidcCustomSubRepo, GetCustomOidcSubClaimForRepoError, GithubOpContext>;
export type GetEnvironmentPublicKeyError = GithubOpError;
/** Get an environment public key Get the public key for an environment, which you need to encrypt environment secrets. You need to encrypt a secret before you can create or update secrets. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getEnvironmentPublicKey: API.OperationMethod<GetEnvironmentPublicKeyRequest, ActionsPublicKey, GetEnvironmentPublicKeyError, GithubOpContext>;
export type GetEnvironmentSecretError = GithubOpError;
/** Get an environment secret Gets a single environment secret without revealing its encrypted value. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getEnvironmentSecret: API.OperationMethod<GetEnvironmentSecretRequest, ActionsSecret, GetEnvironmentSecretError, GithubOpContext>;
export type GetEnvironmentVariableError = GithubOpError;
/** Get an environment variable Gets a specific variable in an environment. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getEnvironmentVariable: API.OperationMethod<GetEnvironmentVariableRequest, ActionsVariable, GetEnvironmentVariableError, GithubOpContext>;
export type GetForkPrContributorApprovalPermissionsOrganizationError = GithubOpError;
/** Get fork PR contributor approval permissions for an organization Gets the fork PR contributor approval policy for an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const getForkPrContributorApprovalPermissionsOrganization: API.OperationMethod<GetForkPrContributorApprovalPermissionsOrganizationRequest, ActionsForkPrContributorApproval, GetForkPrContributorApprovalPermissionsOrganizationError, GithubOpContext>;
export type GetForkPrContributorApprovalPermissionsRepositoryError = GithubOpError;
/** Get fork PR contributor approval permissions for a repository Gets the fork PR contributor approval policy for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getForkPrContributorApprovalPermissionsRepository: API.OperationMethod<GetForkPrContributorApprovalPermissionsRepositoryRequest, ActionsForkPrContributorApproval, GetForkPrContributorApprovalPermissionsRepositoryError, GithubOpContext>;
export type GetGithubActionsDefaultWorkflowPermissionsOrganizationError = GithubOpError;
/** Get default workflow permissions for an organization Gets the default workflow permissions granted to the `GITHUB_TOKEN` when running workflows in an organization, as well as whether GitHub Actions can submit approving pull request reviews. For more information, see "[Setting the permissions of the GITHUB_TOKEN for your organization](https://docs.github.com/organizations/managing-organization-settings/disabling-or-limiting-github-actions-for-your-organization#setting-the-permissions-of-the-github_token-for-your-organization)." OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getGithubActionsDefaultWorkflowPermissionsOrganization: API.OperationMethod<GetGithubActionsDefaultWorkflowPermissionsOrganizationRequest, ActionsGetDefaultWorkflowPermissions, GetGithubActionsDefaultWorkflowPermissionsOrganizationError, GithubOpContext>;
export type GetGithubActionsDefaultWorkflowPermissionsRepositoryError = GithubOpError;
/** Get default workflow permissions for a repository Gets the default workflow permissions granted to the `GITHUB_TOKEN` when running workflows in a repository, as well as if GitHub Actions can submit approving pull request reviews. For more information, see "[Setting the permissions of the GITHUB_TOKEN for your repository](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#setting-the-permissions-of-the-github_token-for-your-repository)." OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getGithubActionsDefaultWorkflowPermissionsRepository: API.OperationMethod<GetGithubActionsDefaultWorkflowPermissionsRepositoryRequest, ActionsGetDefaultWorkflowPermissions, GetGithubActionsDefaultWorkflowPermissionsRepositoryError, GithubOpContext>;
export type GetGithubActionsPermissionsOrganizationError = GithubOpError;
/** Get GitHub Actions permissions for an organization Gets the GitHub Actions permissions policy for repositories and allowed actions and reusable workflows in an organization. OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getGithubActionsPermissionsOrganization: API.OperationMethod<GetGithubActionsPermissionsOrganizationRequest, ActionsOrganizationPermissions, GetGithubActionsPermissionsOrganizationError, GithubOpContext>;
export type GetGithubActionsPermissionsRepositoryError = GithubOpError;
/** Get GitHub Actions permissions for a repository Gets the GitHub Actions permissions policy for a repository, including whether GitHub Actions is enabled and the actions and reusable workflows allowed to run in the repository. OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getGithubActionsPermissionsRepository: API.OperationMethod<GetGithubActionsPermissionsRepositoryRequest, ActionsRepositoryPermissions, GetGithubActionsPermissionsRepositoryError, GithubOpContext>;
export type GetHostedRunnerForOrgError = GithubOpError;
/** Get a GitHub-hosted runner for an organization Gets a GitHub-hosted runner configured in an organization. OAuth app tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const getHostedRunnerForOrg: API.OperationMethod<GetHostedRunnerForOrgRequest, ActionsHostedRunner, GetHostedRunnerForOrgError, GithubOpContext>;
export type GetHostedRunnersGithubOwnedImagesForOrgError = GithubOpError;
/** Get GitHub-owned images for GitHub-hosted runners in an organization Get the list of GitHub-owned images available for GitHub-hosted runners for an organization. */
export declare const getHostedRunnersGithubOwnedImagesForOrg: API.OperationMethod<GetHostedRunnersGithubOwnedImagesForOrgRequest, GetHostedRunnersGithubOwnedImagesForOrgResponse, GetHostedRunnersGithubOwnedImagesForOrgError, GithubOpContext>;
export type GetHostedRunnersLimitsForOrgError = GithubOpError;
/** Get limits on GitHub-hosted runners for an organization Get the GitHub-hosted runners limits for an organization. */
export declare const getHostedRunnersLimitsForOrg: API.OperationMethod<GetHostedRunnersLimitsForOrgRequest, ActionsHostedRunnerLimits, GetHostedRunnersLimitsForOrgError, GithubOpContext>;
export type GetHostedRunnersMachineSpecsForOrgError = GithubOpError;
/** Get GitHub-hosted runners machine specs for an organization Get the list of machine specs available for GitHub-hosted runners for an organization. */
export declare const getHostedRunnersMachineSpecsForOrg: API.OperationMethod<GetHostedRunnersMachineSpecsForOrgRequest, GetHostedRunnersMachineSpecsForOrgResponse, GetHostedRunnersMachineSpecsForOrgError, GithubOpContext>;
export type GetHostedRunnersPartnerImagesForOrgError = GithubOpError;
/** Get partner images for GitHub-hosted runners in an organization Get the list of partner images available for GitHub-hosted runners for an organization. */
export declare const getHostedRunnersPartnerImagesForOrg: API.OperationMethod<GetHostedRunnersPartnerImagesForOrgRequest, GetHostedRunnersPartnerImagesForOrgResponse, GetHostedRunnersPartnerImagesForOrgError, GithubOpContext>;
export type GetHostedRunnersPlatformsForOrgError = GithubOpError;
/** Get platforms for GitHub-hosted runners in an organization Get the list of platforms available for GitHub-hosted runners for an organization. */
export declare const getHostedRunnersPlatformsForOrg: API.OperationMethod<GetHostedRunnersPlatformsForOrgRequest, GetHostedRunnersPlatformsForOrgResponse, GetHostedRunnersPlatformsForOrgError, GithubOpContext>;
export type GetJobForWorkflowRunError = GithubOpError;
/** Get a job for a workflow run Gets a specific job in a workflow run. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getJobForWorkflowRun: API.OperationMethod<GetJobForWorkflowRunRequest, Job, GetJobForWorkflowRunError, GithubOpContext>;
export type GetOrgActionsPoliciesError = GithubOpError;
/** List organization Actions policies List all Actions policies for an organization. */
export declare const getOrgActionsPolicies: API.PaginatedOperationMethod<GetOrgActionsPoliciesRequest, GetOrgActionsPoliciesResponse, GetOrgActionsPoliciesError, GithubOpContext, ActionsPolicy>;
export type GetOrgActionsPolicyError = GithubOpError;
/** Get an organization Actions policy Get a specific Actions policy for an organization. */
export declare const getOrgActionsPolicy: API.OperationMethod<GetOrgActionsPolicyRequest, ActionsPolicy, GetOrgActionsPolicyError, GithubOpContext>;
export type GetOrgPublicKeyError = GithubOpError;
/** Get an organization public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. The authenticated user must have collaborator access to a repository to create, update, or read secrets. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getOrgPublicKey: API.OperationMethod<GetOrgPublicKeyRequest, ActionsPublicKey, GetOrgPublicKeyError, GithubOpContext>;
export type GetOrgSecretError = GithubOpError;
/** Get an organization secret Gets a single organization secret without revealing its encrypted value. The authenticated user must have collaborator access to a repository to create, update, or read secrets OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getOrgSecret: API.OperationMethod<GetOrgSecretRequest, OrganizationActionsSecret, GetOrgSecretError, GithubOpContext>;
export type GetOrgVariableError = GithubOpError;
/** Get an organization variable Gets a specific variable in an organization. The authenticated user must have collaborator access to a repository to create, update, or read variables. OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getOrgVariable: API.OperationMethod<GetOrgVariableRequest, OrganizationActionsVariable, GetOrgVariableError, GithubOpContext>;
export type GetPendingDeploymentsForRunError = GithubOpError;
/** Get pending deployments for a workflow run Get all deployment environments for a workflow run that are waiting for protection rules to pass. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getPendingDeploymentsForRun: API.OperationMethod<GetPendingDeploymentsForRunRequest, GetPendingDeploymentsForRunResponse, GetPendingDeploymentsForRunError, GithubOpContext>;
export type GetPrivateRepoForkPrWorkflowsSettingsOrganizationError = GithubOpError;
/** Get private repo fork PR workflow settings for an organization Gets the settings for whether workflows from fork pull requests can run on private repositories in an organization. */
export declare const getPrivateRepoForkPrWorkflowsSettingsOrganization: API.OperationMethod<GetPrivateRepoForkPrWorkflowsSettingsOrganizationRequest, ActionsForkPrWorkflowsPrivateRepos, GetPrivateRepoForkPrWorkflowsSettingsOrganizationError, GithubOpContext>;
export type GetPrivateRepoForkPrWorkflowsSettingsRepositoryError = GithubOpError;
/** Get private repo fork PR workflow settings for a repository Gets the settings for whether workflows from fork pull requests can run on a private repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getPrivateRepoForkPrWorkflowsSettingsRepository: API.OperationMethod<GetPrivateRepoForkPrWorkflowsSettingsRepositoryRequest, ActionsForkPrWorkflowsPrivateRepos, GetPrivateRepoForkPrWorkflowsSettingsRepositoryError, GithubOpContext>;
export type GetRepoActionsPoliciesError = GithubOpError;
/** List repository Actions policies List all Actions policies for a repository. */
export declare const getRepoActionsPolicies: API.PaginatedOperationMethod<GetRepoActionsPoliciesRequest, GetRepoActionsPoliciesResponse, GetRepoActionsPoliciesError, GithubOpContext, ActionsPolicy>;
export type GetRepoActionsPolicyError = GithubOpError;
/** Get a repository Actions policy Get a specific Actions policy for a repository. */
export declare const getRepoActionsPolicy: API.OperationMethod<GetRepoActionsPolicyRequest, ActionsPolicy, GetRepoActionsPolicyError, GithubOpContext>;
export type GetRepoPublicKeyError = GithubOpError;
/** Get a repository public key Gets your public key, which you need to encrypt secrets. You need to encrypt a secret before you can create or update secrets. Anyone with read access to the repository can use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoPublicKey: API.OperationMethod<GetRepoPublicKeyRequest, ActionsPublicKey, GetRepoPublicKeyError, GithubOpContext>;
export type GetRepoSecretError = GithubOpError;
/** Get a repository secret Gets a single repository secret without revealing its encrypted value. The authenticated user must have collaborator access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoSecret: API.OperationMethod<GetRepoSecretRequest, ActionsSecret, GetRepoSecretError, GithubOpContext>;
export type GetRepoVariableError = GithubOpError;
/** Get a repository variable Gets a specific variable in a repository. The authenticated user must have collaborator access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRepoVariable: API.OperationMethod<GetRepoVariableRequest, ActionsVariable, GetRepoVariableError, GithubOpContext>;
export type GetReviewsForRunError = GithubOpError;
/** Get the review history for a workflow run Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getReviewsForRun: API.OperationMethod<GetReviewsForRunRequest, GetReviewsForRunResponse, GetReviewsForRunError, GithubOpContext>;
export type GetRunnerVersionDeprecationForOrgError = GithubOpError;
/** Get runner version end-of-life schedule for an organization Gets the end-of-life schedule for a specific runner version in an organization. Returns the runner version and the dates when registration and runtime support will end. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getRunnerVersionDeprecationForOrg: API.OperationMethod<GetRunnerVersionDeprecationForOrgRequest, GetRunnerVersionDeprecationForOrgResponse, GetRunnerVersionDeprecationForOrgError, GithubOpContext>;
export type GetRunnerVersionDeprecationForRepoError = GithubOpError;
/** Get runner version end-of-life schedule for a repository Gets the end-of-life schedule for a specific runner version in a repository. Returns the runner version and the dates when registration and runtime support will end. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getRunnerVersionDeprecationForRepo: API.OperationMethod<GetRunnerVersionDeprecationForRepoRequest, GetRunnerVersionDeprecationForRepoResponse, GetRunnerVersionDeprecationForRepoError, GithubOpContext>;
export type GetSelfHostedRunnerForOrgError = GithubOpError;
/** Get a self-hosted runner for an organization Gets a specific self-hosted runner configured in an organization. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const getSelfHostedRunnerForOrg: API.OperationMethod<GetSelfHostedRunnerForOrgRequest, Runner, GetSelfHostedRunnerForOrgError, GithubOpContext>;
export type GetSelfHostedRunnerForRepoError = GithubOpError;
/** Get a self-hosted runner for a repository Gets a specific self-hosted runner configured in a repository. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getSelfHostedRunnerForRepo: API.OperationMethod<GetSelfHostedRunnerForRepoRequest, Runner, GetSelfHostedRunnerForRepoError, GithubOpContext>;
export type GetSelfHostedRunnerGroupForOrgError = GithubOpError;
/** Get a self-hosted runner group for an organization Gets a specific self-hosted runner group for an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const getSelfHostedRunnerGroupForOrg: API.OperationMethod<GetSelfHostedRunnerGroupForOrgRequest, RunnerGroupsOrg, GetSelfHostedRunnerGroupForOrgError, GithubOpContext>;
export type GetSelfHostedRunnersPermissionsOrganizationError = GithubOpError;
/** Get self-hosted runners settings for an organization Gets the settings for self-hosted runners for an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const getSelfHostedRunnersPermissionsOrganization: API.OperationMethod<GetSelfHostedRunnersPermissionsOrganizationRequest, SelfHostedRunnersSettings, GetSelfHostedRunnersPermissionsOrganizationError, GithubOpContext>;
export type GetWorkflowError = GithubOpError;
/** Get a workflow Gets a specific workflow. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest, Workflow, GetWorkflowError, GithubOpContext>;
export type GetWorkflowAccessToRepositoryError = GithubOpError;
/** Get the level of access for workflows outside of the repository Gets the level of access that workflows outside of the repository have to actions and reusable workflows in the repository. This endpoint only applies to private repositories. For more information, see "[Allowing access to components in a private repository](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#allowing-access-to-components-in-a-private-repository)." OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getWorkflowAccessToRepository: API.OperationMethod<GetWorkflowAccessToRepositoryRequest, ActionsWorkflowAccessToRepository, GetWorkflowAccessToRepositoryError, GithubOpContext>;
export type GetWorkflowRunError = GithubOpError;
/** Get a workflow run Gets a specific workflow run. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getWorkflowRun: API.OperationMethod<GetWorkflowRunRequest, WorkflowRun, GetWorkflowRunError, GithubOpContext>;
export type GetWorkflowRunAttemptError = GithubOpError;
/** Get a workflow run attempt Gets a specific workflow run attempt. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getWorkflowRunAttempt: API.OperationMethod<GetWorkflowRunAttemptRequest, WorkflowRun, GetWorkflowRunAttemptError, GithubOpContext>;
export type GetWorkflowRunUsageError = GithubOpError;
/** Get workflow run usage > [!WARNING] > This endpoint is in the process of closing down. Refer to "[Actions Get workflow usage and Get workflow run usage endpoints closing down](https://github.blog/changelog/2025-02-02-actions-get-workflow-usage-and-get-workflow-run-usage-endpoints-closing-down/)" for more information. Gets the number of billable minutes and total run time for a specific workflow run. Billable minutes only apply to workflows in private repositories that use GitHub-hosted runners. Usage is listed for each GitHub-hosted runner operating system in milliseconds. Any job re-runs are also included in the usage. The usage does not include the multiplier for macOS and Windows runners and is not rounded up to the nearest whole minute. For more information, see "[Managing billing for GitHub Actions](https://docs.github.com/github/setting-up-and-managing-billing-and-payments-on-github/managing-billing-for-github-actions)". Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getWorkflowRunUsage: API.OperationMethod<GetWorkflowRunUsageRequest, WorkflowRunUsage, GetWorkflowRunUsageError, GithubOpContext>;
export type GetWorkflowUsageError = GithubOpError;
/** Get workflow usage > [!WARNING] > This endpoint is in the process of closing down. Refer to "[Actions Get workflow usage and Get workflow run usage endpoints closing down](https://github.blog/changelog/2025-02-02-actions-get-workflow-usage-and-get-workflow-run-usage-endpoints-closing-down/)" for more information. Gets the number of billable minutes used by a specific workflow during the current billing cycle. Billable minutes only apply to workflows in private repositories that use GitHub-hosted runners. Usage is listed for each GitHub-hosted runner operating system in milliseconds. Any job re-runs are also included in the usage. The usage does not include the multiplier for macOS and Windows runners and is not rounded up to the nearest whole minute. For more information, see "[Managing billing for GitHub Actions](https://docs.github.com/github/setting-up-and-managing-billing-and-payments-on-github/managing-billing-for-github-actions)". You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getWorkflowUsage: API.OperationMethod<GetWorkflowUsageRequest, WorkflowUsage, GetWorkflowUsageError, GithubOpContext>;
export type ListArtifactsForRepoError = GithubOpError;
/** List artifacts for a repository Lists all artifacts for a repository. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listArtifactsForRepo: API.PaginatedOperationMethod<ListArtifactsForRepoRequest, ListArtifactsForRepoResponse, ListArtifactsForRepoError, GithubOpContext, Artifact>;
export type ListConcurrencyGroupsForRepositoryError = GithubOpError;
/** List concurrency groups for a repository Lists the active concurrency groups for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listConcurrencyGroupsForRepository: API.OperationMethod<ListConcurrencyGroupsForRepositoryRequest, ConcurrencyGroupList, ListConcurrencyGroupsForRepositoryError, GithubOpContext>;
export type ListConcurrencyGroupsForWorkflowRunError = GithubOpError;
/** List concurrency groups for a workflow run Lists all concurrency groups associated with a workflow run or its jobs. The set of groups is derived from the run's configuration, so a group is included even when the run no longer has any items currently holding or waiting in it. In that case the `group_members` array will be empty. `total_count` reflects the number of groups the run participates in by configuration, not the number with active items. This differs from `GET /repos/{owner}/{repo}/actions/concurrency_groups/{group_name}`, which returns 404 when a group has no active items. That endpoint reports the live state of a group repo-wide, while this endpoint reports the groups associated with a specific run by configuration. Results are sorted by group name and support cursor-based pagination via `before` and `after`. The `after` cursor paginates forward only and does not emit a `rel="prev"` Link; use `before` to page backward from a forward page's `next` cursor. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listConcurrencyGroupsForWorkflowRun: API.OperationMethod<ListConcurrencyGroupsForWorkflowRunRequest, ConcurrencyGroupRunList, ListConcurrencyGroupsForWorkflowRunError, GithubOpContext>;
export type ListCustomImagesForOrgError = GithubOpError;
/** List custom images for an organization List custom images for an organization. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const listCustomImagesForOrg: API.OperationMethod<ListCustomImagesForOrgRequest, ListCustomImagesForOrgResponse, ListCustomImagesForOrgError, GithubOpContext>;
export type ListCustomImageVersionsForOrgError = GithubOpError;
/** List image versions of a custom image for an organization List image versions of a custom image for an organization. OAuth tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const listCustomImageVersionsForOrg: API.OperationMethod<ListCustomImageVersionsForOrgRequest, ListCustomImageVersionsForOrgResponse, ListCustomImageVersionsForOrgError, GithubOpContext>;
export type ListEnvironmentSecretsError = GithubOpError;
/** List environment secrets Lists all secrets available in an environment without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listEnvironmentSecrets: API.PaginatedOperationMethod<ListEnvironmentSecretsRequest, ListEnvironmentSecretsResponse, ListEnvironmentSecretsError, GithubOpContext, ActionsSecret>;
export type ListEnvironmentVariablesError = GithubOpError;
/** List environment variables Lists all environment variables. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listEnvironmentVariables: API.PaginatedOperationMethod<ListEnvironmentVariablesRequest, ListEnvironmentVariablesResponse, ListEnvironmentVariablesError, GithubOpContext, ActionsVariable>;
export type ListGithubHostedRunnersInGroupForOrgError = GithubOpError;
/** List GitHub-hosted runners in a group for an organization Lists the GitHub-hosted runners in an organization group. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listGithubHostedRunnersInGroupForOrg: API.PaginatedOperationMethod<ListGithubHostedRunnersInGroupForOrgRequest, ListGithubHostedRunnersInGroupForOrgResponse, ListGithubHostedRunnersInGroupForOrgError, GithubOpContext, ActionsHostedRunner>;
export type ListHostedRunnersForOrgError = GithubOpError;
/** List GitHub-hosted runners for an organization Lists all GitHub-hosted runners configured in an organization. OAuth app tokens and personal access tokens (classic) need the `manage_runner:org` scope to use this endpoint. */
export declare const listHostedRunnersForOrg: API.PaginatedOperationMethod<ListHostedRunnersForOrgRequest, ListHostedRunnersForOrgResponse, ListHostedRunnersForOrgError, GithubOpContext, ActionsHostedRunner>;
export type ListJobsForWorkflowRunError = GithubOpError;
/** List jobs for a workflow run Lists jobs for a workflow run. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters). Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listJobsForWorkflowRun: API.PaginatedOperationMethod<ListJobsForWorkflowRunRequest, ListJobsForWorkflowRunResponse, ListJobsForWorkflowRunError, GithubOpContext, Job>;
export type ListJobsForWorkflowRunAttemptError = GithubOpError;
/** List jobs for a workflow run attempt Lists jobs for a specific workflow run attempt. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters). Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listJobsForWorkflowRunAttempt: API.PaginatedOperationMethod<ListJobsForWorkflowRunAttemptRequest, ListJobsForWorkflowRunAttemptResponse, ListJobsForWorkflowRunAttemptError, GithubOpContext, Job>;
export type ListLabelsForSelfHostedRunnerForOrgError = GithubOpError;
/** List labels for a self-hosted runner for an organization Lists all labels for a self-hosted runner configured in an organization. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listLabelsForSelfHostedRunnerForOrg: API.OperationMethod<ListLabelsForSelfHostedRunnerForOrgRequest, ListLabelsForSelfHostedRunnerForOrgResponse, ListLabelsForSelfHostedRunnerForOrgError, GithubOpContext>;
export type ListLabelsForSelfHostedRunnerForRepoError = GithubOpError;
/** List labels for a self-hosted runner for a repository Lists all labels for a self-hosted runner configured in a repository. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listLabelsForSelfHostedRunnerForRepo: API.OperationMethod<ListLabelsForSelfHostedRunnerForRepoRequest, ListLabelsForSelfHostedRunnerForRepoResponse, ListLabelsForSelfHostedRunnerForRepoError, GithubOpContext>;
export type ListOrgSecretsError = GithubOpError;
/** List organization secrets Lists all secrets available in an organization without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listOrgSecrets: API.PaginatedOperationMethod<ListOrgSecretsRequest, ListOrgSecretsResponse, ListOrgSecretsError, GithubOpContext, OrganizationActionsSecret>;
export type ListOrgVariablesError = GithubOpError;
/** List organization variables Lists all organization variables. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listOrgVariables: API.PaginatedOperationMethod<ListOrgVariablesRequest, ListOrgVariablesResponse, ListOrgVariablesError, GithubOpContext, OrganizationActionsVariable>;
export type ListRepoAccessToSelfHostedRunnerGroupInOrgError = GithubOpError;
/** List repository access to a self-hosted runner group in an organization Lists the repositories with access to a self-hosted runner group configured in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listRepoAccessToSelfHostedRunnerGroupInOrg: API.PaginatedOperationMethod<ListRepoAccessToSelfHostedRunnerGroupInOrgRequest, ListRepoAccessToSelfHostedRunnerGroupInOrgResponse, ListRepoAccessToSelfHostedRunnerGroupInOrgError, GithubOpContext, MinimalRepository>;
export type ListRepoOrganizationSecretsError = GithubOpError;
/** List repository organization secrets Lists all organization secrets shared with a repository without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoOrganizationSecrets: API.PaginatedOperationMethod<ListRepoOrganizationSecretsRequest, ListRepoOrganizationSecretsResponse, ListRepoOrganizationSecretsError, GithubOpContext, ActionsSecret>;
export type ListRepoOrganizationVariablesError = GithubOpError;
/** List repository organization variables Lists all organization variables shared with a repository. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoOrganizationVariables: API.PaginatedOperationMethod<ListRepoOrganizationVariablesRequest, ListRepoOrganizationVariablesResponse, ListRepoOrganizationVariablesError, GithubOpContext, ActionsVariable>;
export type ListRepoSecretsError = GithubOpError;
/** List repository secrets Lists all secrets available in a repository without revealing their encrypted values. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoSecrets: API.PaginatedOperationMethod<ListRepoSecretsRequest, ListRepoSecretsResponse, ListRepoSecretsError, GithubOpContext, ActionsSecret>;
export type ListRepoVariablesError = GithubOpError;
/** List repository variables Lists all repository variables. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRepoVariables: API.PaginatedOperationMethod<ListRepoVariablesRequest, ListRepoVariablesResponse, ListRepoVariablesError, GithubOpContext, ActionsVariable>;
export type ListRepoWorkflowsError = GithubOpError;
/** List repository workflows Lists the workflows in a repository. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listRepoWorkflows: API.PaginatedOperationMethod<ListRepoWorkflowsRequest, ListRepoWorkflowsResponse, ListRepoWorkflowsError, GithubOpContext, Workflow>;
export type ListRunnerApplicationsForOrgError = GithubOpError;
/** List runner applications for an organization Lists binaries for the runner application that you can download and run. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listRunnerApplicationsForOrg: API.OperationMethod<ListRunnerApplicationsForOrgRequest, ListRunnerApplicationsForOrgResponse, ListRunnerApplicationsForOrgError, GithubOpContext>;
export type ListRunnerApplicationsForRepoError = GithubOpError;
/** List runner applications for a repository Lists binaries for the runner application that you can download and run. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listRunnerApplicationsForRepo: API.OperationMethod<ListRunnerApplicationsForRepoRequest, ListRunnerApplicationsForRepoResponse, ListRunnerApplicationsForRepoError, GithubOpContext>;
export type ListSelectedReposForOrgSecretError = GithubOpError;
/** List selected repositories for an organization secret Lists all repositories that have been selected when the `visibility` for repository access to a secret is set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listSelectedReposForOrgSecret: API.PaginatedOperationMethod<ListSelectedReposForOrgSecretRequest, ListSelectedReposForOrgSecretResponse, ListSelectedReposForOrgSecretError, GithubOpContext, MinimalRepository>;
export type ListSelectedReposForOrgVariableError = GithubOpError;
/** List selected repositories for an organization variable Lists all repositories that can access an organization variable that is available to selected repositories. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listSelectedReposForOrgVariable: API.PaginatedOperationMethod<ListSelectedReposForOrgVariableRequest, ListSelectedReposForOrgVariableResponse, ListSelectedReposForOrgVariableError, GithubOpContext, MinimalRepository>;
export type ListSelectedRepositoriesEnabledGithubActionsOrganizationError = GithubOpError;
/** List selected repositories enabled for GitHub Actions in an organization Lists the selected repositories that are enabled for GitHub Actions in an organization. To use this endpoint, the organization permission policy for `enabled_repositories` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for an organization](#set-github-actions-permissions-for-an-organization)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listSelectedRepositoriesEnabledGithubActionsOrganization: API.PaginatedOperationMethod<ListSelectedRepositoriesEnabledGithubActionsOrganizationRequest, ListSelectedRepositoriesEnabledGithubActionsOrganizationResponse, ListSelectedRepositoriesEnabledGithubActionsOrganizationError, GithubOpContext, Repository>;
export type ListSelectedRepositoriesSelfHostedRunnersOrganizationError = GithubOpError;
/** List repositories allowed to use self-hosted runners in an organization Lists repositories that are allowed to use self-hosted runners in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const listSelectedRepositoriesSelfHostedRunnersOrganization: API.PaginatedOperationMethod<ListSelectedRepositoriesSelfHostedRunnersOrganizationRequest, ListSelectedRepositoriesSelfHostedRunnersOrganizationResponse, ListSelectedRepositoriesSelfHostedRunnersOrganizationError, GithubOpContext, Repository>;
export type ListSelfHostedRunnerGroupsForOrgError = GithubOpError;
/** List self-hosted runner groups for an organization Lists all self-hosted runner groups configured in an organization and inherited from an enterprise. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listSelfHostedRunnerGroupsForOrg: API.PaginatedOperationMethod<ListSelfHostedRunnerGroupsForOrgRequest, ListSelfHostedRunnerGroupsForOrgResponse, ListSelfHostedRunnerGroupsForOrgError, GithubOpContext, RunnerGroupsOrg>;
export type ListSelfHostedRunnersForOrgError = GithubOpError;
/** List self-hosted runners for an organization Lists all self-hosted runners configured in an organization. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const listSelfHostedRunnersForOrg: API.PaginatedOperationMethod<ListSelfHostedRunnersForOrgRequest, ListSelfHostedRunnersForOrgResponse, ListSelfHostedRunnersForOrgError, GithubOpContext, Runner>;
export type ListSelfHostedRunnersForRepoError = GithubOpError;
/** List self-hosted runners for a repository Lists all self-hosted runners configured in a repository. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listSelfHostedRunnersForRepo: API.PaginatedOperationMethod<ListSelfHostedRunnersForRepoRequest, ListSelfHostedRunnersForRepoResponse, ListSelfHostedRunnersForRepoError, GithubOpContext, Runner>;
export type ListSelfHostedRunnersInGroupForOrgError = GithubOpError;
/** List self-hosted runners in a group for an organization Lists self-hosted runners that are in a specific organization group. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const listSelfHostedRunnersInGroupForOrg: API.PaginatedOperationMethod<ListSelfHostedRunnersInGroupForOrgRequest, ListSelfHostedRunnersInGroupForOrgResponse, ListSelfHostedRunnersInGroupForOrgError, GithubOpContext, Runner>;
export type ListWorkflowRunArtifactsError = GithubOpError;
/** List workflow run artifacts Lists artifacts for a workflow run. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listWorkflowRunArtifacts: API.PaginatedOperationMethod<ListWorkflowRunArtifactsRequest, ListWorkflowRunArtifactsResponse, ListWorkflowRunArtifactsError, GithubOpContext, Artifact>;
export type ListWorkflowRunsError = GithubOpError;
/** List workflow runs for a workflow List all workflow runs for a workflow. You can replace `workflow_id` with the workflow file name. For example, you could use `main.yaml`. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters). Anyone with read access to the repository can use this endpoint OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. This endpoint will return up to 1,000 results for each search when using the following parameters: `actor`, `branch`, `check_suite_id`, `created`, `event`, `head_sha`, `status`. */
export declare const listWorkflowRuns: API.PaginatedOperationMethod<ListWorkflowRunsRequest, ListWorkflowRunsResponse, ListWorkflowRunsError, GithubOpContext, WorkflowRun>;
export type ListWorkflowRunsForRepoError = GithubOpError;
/** List workflow runs for a repository Lists all workflow runs for a repository. You can use parameters to narrow the list of results. For more information about using parameters, see [Parameters](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#parameters). Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. This endpoint will return up to 1,000 results for each search when using the following parameters: `actor`, `branch`, `check_suite_id`, `created`, `event`, `head_sha`, `status`. */
export declare const listWorkflowRunsForRepo: API.PaginatedOperationMethod<ListWorkflowRunsForRepoRequest, ListWorkflowRunsForRepoResponse, ListWorkflowRunsForRepoError, GithubOpContext, WorkflowRun>;
export type RemoveAllCustomLabelsFromSelfHostedRunnerForOrgError = GithubOpError;
/** Remove all custom labels from a self-hosted runner for an organization Remove all custom labels from a self-hosted runner configured in an organization. Returns the remaining read-only labels from the runner. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const removeAllCustomLabelsFromSelfHostedRunnerForOrg: API.OperationMethod<RemoveAllCustomLabelsFromSelfHostedRunnerForOrgRequest, RemoveAllCustomLabelsFromSelfHostedRunnerForOrgResponse, RemoveAllCustomLabelsFromSelfHostedRunnerForOrgError, GithubOpContext>;
export type RemoveAllCustomLabelsFromSelfHostedRunnerForRepoError = GithubOpError;
/** Remove all custom labels from a self-hosted runner for a repository Remove all custom labels from a self-hosted runner configured in a repository. Returns the remaining read-only labels from the runner. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const removeAllCustomLabelsFromSelfHostedRunnerForRepo: API.OperationMethod<RemoveAllCustomLabelsFromSelfHostedRunnerForRepoRequest, RemoveAllCustomLabelsFromSelfHostedRunnerForRepoResponse, RemoveAllCustomLabelsFromSelfHostedRunnerForRepoError, GithubOpContext>;
export type RemoveCustomLabelFromSelfHostedRunnerForOrgError = GithubOpError;
/** Remove a custom label from a self-hosted runner for an organization Remove a custom label from a self-hosted runner configured in an organization. Returns the remaining labels from the runner. This endpoint returns a `404 Not Found` status if the custom label is not present on the runner. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const removeCustomLabelFromSelfHostedRunnerForOrg: API.OperationMethod<RemoveCustomLabelFromSelfHostedRunnerForOrgRequest, RemoveCustomLabelFromSelfHostedRunnerForOrgResponse, RemoveCustomLabelFromSelfHostedRunnerForOrgError, GithubOpContext>;
export type RemoveCustomLabelFromSelfHostedRunnerForRepoError = GithubOpError;
/** Remove a custom label from a self-hosted runner for a repository Remove a custom label from a self-hosted runner configured in a repository. Returns the remaining labels from the runner. This endpoint returns a `404 Not Found` status if the custom label is not present on the runner. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const removeCustomLabelFromSelfHostedRunnerForRepo: API.OperationMethod<RemoveCustomLabelFromSelfHostedRunnerForRepoRequest, RemoveCustomLabelFromSelfHostedRunnerForRepoResponse, RemoveCustomLabelFromSelfHostedRunnerForRepoError, GithubOpContext>;
export type RemoveRepoAccessToSelfHostedRunnerGroupInOrgError = GithubOpError;
/** Remove repository access to a self-hosted runner group in an organization Removes a repository from the list of selected repositories that can access a self-hosted runner group. The runner group must have `visibility` set to `selected`. For more information, see "[Create a self-hosted runner group for an organization](#create-a-self-hosted-runner-group-for-an-organization)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const removeRepoAccessToSelfHostedRunnerGroupInOrg: API.OperationMethod<RemoveRepoAccessToSelfHostedRunnerGroupInOrgRequest, RemoveRepoAccessToSelfHostedRunnerGroupInOrgResponse, RemoveRepoAccessToSelfHostedRunnerGroupInOrgError, GithubOpContext>;
export type RemoveSelectedRepoFromOrgSecretError = GithubOpError;
/** Remove selected repository from an organization secret Removes a repository from an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/actions/secrets#create-or-update-an-organization-secret). Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const removeSelectedRepoFromOrgSecret: API.OperationMethod<RemoveSelectedRepoFromOrgSecretRequest, RemoveSelectedRepoFromOrgSecretResponse, RemoveSelectedRepoFromOrgSecretError, GithubOpContext>;
export type RemoveSelectedRepoFromOrgVariableError = GithubOpError;
/** Remove selected repository from an organization variable Removes a repository from an organization variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const removeSelectedRepoFromOrgVariable: API.OperationMethod<RemoveSelectedRepoFromOrgVariableRequest, RemoveSelectedRepoFromOrgVariableResponse, RemoveSelectedRepoFromOrgVariableError, GithubOpContext>;
export type RemoveSelfHostedRunnerFromGroupForOrgError = GithubOpError;
/** Remove a self-hosted runner from a group for an organization Removes a self-hosted runner from a group configured in an organization. The runner is then returned to the default group. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const removeSelfHostedRunnerFromGroupForOrg: API.OperationMethod<RemoveSelfHostedRunnerFromGroupForOrgRequest, RemoveSelfHostedRunnerFromGroupForOrgResponse, RemoveSelfHostedRunnerFromGroupForOrgError, GithubOpContext>;
export type ReRunWorkflowError = GithubOpError;
/** Re-run a workflow Re-runs your workflow run using its `id`. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const reRunWorkflow: API.OperationMethod<ReRunWorkflowRequest, ReRunWorkflowResponse, ReRunWorkflowError, GithubOpContext>;
export type ReRunWorkflowFailedJobsError = GithubOpError;
/** Re-run failed jobs from a workflow run Re-run all of the failed jobs and their dependent jobs in a workflow run using the `id` of the workflow run. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const reRunWorkflowFailedJobs: API.OperationMethod<ReRunWorkflowFailedJobsRequest, ReRunWorkflowFailedJobsResponse, ReRunWorkflowFailedJobsError, GithubOpContext>;
export type ReviewCustomGatesForRunError = GithubOpError;
/** Review custom deployment protection rules for a workflow run Approve or reject custom deployment protection rules provided by a GitHub App for a workflow run. For more information, see "[Using environments for deployment](https://docs.github.com/actions/deployment/targeting-different-environments/using-environments-for-deployment)." > [!NOTE] > GitHub Apps can only review their own custom deployment protection rules. To approve or reject pending deployments that are waiting for review from a specific person or team, see [`POST /repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments`](/rest/actions/workflow-runs#review-pending-deployments-for-a-workflow-run). OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const reviewCustomGatesForRun: API.OperationMethod<ReviewCustomGatesForRunRequest, ReviewCustomGatesForRunResponse, ReviewCustomGatesForRunError, GithubOpContext>;
export type ReviewPendingDeploymentsForRunError = GithubOpError;
/** Review pending deployments for a workflow run Approve or reject pending deployments that are waiting on approval by a required reviewer. Required reviewers with read access to the repository contents and deployments can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const reviewPendingDeploymentsForRun: API.OperationMethod<ReviewPendingDeploymentsForRunRequest, ReviewPendingDeploymentsForRunResponse, ReviewPendingDeploymentsForRunError, GithubOpContext>;
export type RunReRunJobForWorkflowError = GithubOpError;
/** Re-run a job from a workflow run Re-run a job and its dependent jobs in a workflow run. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const runReRunJobForWorkflow: API.OperationMethod<RunReRunJobForWorkflowRequest, RunReRunJobForWorkflowResponse, RunReRunJobForWorkflowError, GithubOpContext>;
export type SetActionsCacheRetentionLimitForEnterpriseError = GithubOpError;
/** Set GitHub Actions cache retention limit for an enterprise Sets GitHub Actions cache retention limit for an enterprise. All organizations and repositories under this enterprise may not set a higher cache retention limit. OAuth tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const setActionsCacheRetentionLimitForEnterprise: API.OperationMethod<SetActionsCacheRetentionLimitForEnterpriseRequest, SetActionsCacheRetentionLimitForEnterpriseResponse, SetActionsCacheRetentionLimitForEnterpriseError, GithubOpContext>;
export type SetActionsCacheRetentionLimitForOrganizationError = GithubOpError;
/** Set GitHub Actions cache retention limit for an organization Sets GitHub Actions cache retention limit for an organization. All repositories under this organization may not set a higher cache retention limit. OAuth tokens and personal access tokens (classic) need the `admin:organization` scope to use this endpoint. */
export declare const setActionsCacheRetentionLimitForOrganization: API.OperationMethod<SetActionsCacheRetentionLimitForOrganizationRequest, SetActionsCacheRetentionLimitForOrganizationResponse, SetActionsCacheRetentionLimitForOrganizationError, GithubOpContext>;
export type SetActionsCacheRetentionLimitForRepositoryError = GithubOpError;
/** Set GitHub Actions cache retention limit for a repository Sets GitHub Actions cache retention limit for a repository. This determines how long caches will be retained for, if not manually removed or evicted due to size constraints. OAuth tokens and personal access tokens (classic) need the `admin:repository` scope to use this endpoint. */
export declare const setActionsCacheRetentionLimitForRepository: API.OperationMethod<SetActionsCacheRetentionLimitForRepositoryRequest, SetActionsCacheRetentionLimitForRepositoryResponse, SetActionsCacheRetentionLimitForRepositoryError, GithubOpContext>;
export type SetActionsCacheStorageLimitForEnterpriseError = GithubOpError;
/** Set GitHub Actions cache storage limit for an enterprise Sets GitHub Actions cache storage limit for an enterprise. All organizations and repositories under this enterprise may not set a higher cache storage limit. OAuth tokens and personal access tokens (classic) need the `admin:enterprise` scope to use this endpoint. > [!NOTE] > The "Enterprise administration" fine-grained permission is not available to callers. To use this API, you must use an OAuth app token or a personal access token (classic). */
export declare const setActionsCacheStorageLimitForEnterprise: API.OperationMethod<SetActionsCacheStorageLimitForEnterpriseRequest, SetActionsCacheStorageLimitForEnterpriseResponse, SetActionsCacheStorageLimitForEnterpriseError, GithubOpContext>;
export type SetActionsCacheStorageLimitForOrganizationError = GithubOpError;
/** Set GitHub Actions cache storage limit for an organization Sets GitHub Actions cache storage limit for an organization. All organizations and repositories under this organization may not set a higher cache storage limit. OAuth tokens and personal access tokens (classic) need the `admin:organization` scope to use this endpoint. */
export declare const setActionsCacheStorageLimitForOrganization: API.OperationMethod<SetActionsCacheStorageLimitForOrganizationRequest, SetActionsCacheStorageLimitForOrganizationResponse, SetActionsCacheStorageLimitForOrganizationError, GithubOpContext>;
export type SetActionsCacheStorageLimitForRepositoryError = GithubOpError;
/** Set GitHub Actions cache storage limit for a repository Sets GitHub Actions cache storage limit for a repository. This determines the maximum size of caches that can be stored before eviction occurs. OAuth tokens and personal access tokens (classic) need the `admin:repository` scope to use this endpoint. */
export declare const setActionsCacheStorageLimitForRepository: API.OperationMethod<SetActionsCacheStorageLimitForRepositoryRequest, SetActionsCacheStorageLimitForRepositoryResponse, SetActionsCacheStorageLimitForRepositoryError, GithubOpContext>;
export type SetAllowedActionsOrganizationError = GithubOpError;
/** Set allowed actions and reusable workflows for an organization Sets the actions and reusable workflows that are allowed in an organization. To use this endpoint, the organization permission policy for `allowed_actions` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for an organization](#set-github-actions-permissions-for-an-organization)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setAllowedActionsOrganization: API.OperationMethod<SetAllowedActionsOrganizationRequest, SetAllowedActionsOrganizationResponse, SetAllowedActionsOrganizationError, GithubOpContext>;
export type SetAllowedActionsRepositoryError = GithubOpError;
/** Set allowed actions and reusable workflows for a repository Sets the actions and reusable workflows that are allowed in a repository. To use this endpoint, the repository permission policy for `allowed_actions` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for a repository](#set-github-actions-permissions-for-a-repository)." OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setAllowedActionsRepository: API.OperationMethod<SetAllowedActionsRepositoryRequest, SetAllowedActionsRepositoryResponse, SetAllowedActionsRepositoryError, GithubOpContext>;
export type SetArtifactAndLogRetentionSettingsOrganizationError = GithubOpError;
/** Set artifact and log retention settings for an organization Sets retention settings for checks, workflow runs, commit statuses, artifacts, and logs for an organization. Checks include check suites, check runs, and check annotations. These settings also apply to checks and commit statuses created by third-party integrations, and are not limited to data created by GitHub Actions. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const setArtifactAndLogRetentionSettingsOrganization: API.OperationMethod<SetArtifactAndLogRetentionSettingsOrganizationRequest, SetArtifactAndLogRetentionSettingsOrganizationResponse, SetArtifactAndLogRetentionSettingsOrganizationError, GithubOpContext>;
export type SetArtifactAndLogRetentionSettingsRepositoryError = GithubOpError;
/** Set artifact and log retention settings for a repository Sets retention settings for checks, workflow runs, commit statuses, artifacts, and logs for a repository. Checks include check suites, check runs, and check annotations. These settings also apply to checks and commit statuses created by third-party integrations, and are not limited to data created by GitHub Actions. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setArtifactAndLogRetentionSettingsRepository: API.OperationMethod<SetArtifactAndLogRetentionSettingsRepositoryRequest, SetArtifactAndLogRetentionSettingsRepositoryResponse, SetArtifactAndLogRetentionSettingsRepositoryError, GithubOpContext>;
export type SetCustomLabelsForSelfHostedRunnerForOrgError = GithubOpError;
/** Set custom labels for a self-hosted runner for an organization Remove all previous custom labels and set the new custom labels for a specific self-hosted runner configured in an organization. Authenticated users must have admin access to the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const setCustomLabelsForSelfHostedRunnerForOrg: API.OperationMethod<SetCustomLabelsForSelfHostedRunnerForOrgRequest, SetCustomLabelsForSelfHostedRunnerForOrgResponse, SetCustomLabelsForSelfHostedRunnerForOrgError, GithubOpContext>;
export type SetCustomLabelsForSelfHostedRunnerForRepoError = GithubOpError;
/** Set custom labels for a self-hosted runner for a repository Remove all previous custom labels and set the new custom labels for a specific self-hosted runner configured in a repository. Authenticated users must have admin access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setCustomLabelsForSelfHostedRunnerForRepo: API.OperationMethod<SetCustomLabelsForSelfHostedRunnerForRepoRequest, SetCustomLabelsForSelfHostedRunnerForRepoResponse, SetCustomLabelsForSelfHostedRunnerForRepoError, GithubOpContext>;
export type SetCustomOidcSubClaimForRepoError = GithubOpError;
/** Set the customization template for an OIDC subject claim for a repository Sets the customization template and `opt-in` or `opt-out` flag for an OpenID Connect (OIDC) subject claim for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setCustomOidcSubClaimForRepo: API.OperationMethod<SetCustomOidcSubClaimForRepoRequest, SetCustomOidcSubClaimForRepoResponse, SetCustomOidcSubClaimForRepoError, GithubOpContext>;
export type SetForkPrContributorApprovalPermissionsOrganizationError = GithubOpError;
/** Set fork PR contributor approval permissions for an organization Sets the fork PR contributor approval policy for an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setForkPrContributorApprovalPermissionsOrganization: API.OperationMethod<SetForkPrContributorApprovalPermissionsOrganizationRequest, SetForkPrContributorApprovalPermissionsOrganizationResponse, SetForkPrContributorApprovalPermissionsOrganizationError, GithubOpContext>;
export type SetForkPrContributorApprovalPermissionsRepositoryError = GithubOpError;
/** Set fork PR contributor approval permissions for a repository Sets the fork PR contributor approval policy for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setForkPrContributorApprovalPermissionsRepository: API.OperationMethod<SetForkPrContributorApprovalPermissionsRepositoryRequest, SetForkPrContributorApprovalPermissionsRepositoryResponse, SetForkPrContributorApprovalPermissionsRepositoryError, GithubOpContext>;
export type SetGithubActionsDefaultWorkflowPermissionsOrganizationError = GithubOpError;
/** Set default workflow permissions for an organization Sets the default workflow permissions granted to the `GITHUB_TOKEN` when running workflows in an organization, and sets if GitHub Actions can submit approving pull request reviews. For more information, see "[Setting the permissions of the GITHUB_TOKEN for your organization](https://docs.github.com/organizations/managing-organization-settings/disabling-or-limiting-github-actions-for-your-organization#setting-the-permissions-of-the-github_token-for-your-organization)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setGithubActionsDefaultWorkflowPermissionsOrganization: API.OperationMethod<SetGithubActionsDefaultWorkflowPermissionsOrganizationRequest, SetGithubActionsDefaultWorkflowPermissionsOrganizationResponse, SetGithubActionsDefaultWorkflowPermissionsOrganizationError, GithubOpContext>;
export type SetGithubActionsDefaultWorkflowPermissionsRepositoryError = GithubOpError;
/** Set default workflow permissions for a repository Sets the default workflow permissions granted to the `GITHUB_TOKEN` when running workflows in a repository, and sets if GitHub Actions can submit approving pull request reviews. For more information, see "[Setting the permissions of the GITHUB_TOKEN for your repository](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#setting-the-permissions-of-the-github_token-for-your-repository)." OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setGithubActionsDefaultWorkflowPermissionsRepository: API.OperationMethod<SetGithubActionsDefaultWorkflowPermissionsRepositoryRequest, SetGithubActionsDefaultWorkflowPermissionsRepositoryResponse, SetGithubActionsDefaultWorkflowPermissionsRepositoryError, GithubOpContext>;
export type SetGithubActionsPermissionsOrganizationError = GithubOpError;
/** Set GitHub Actions permissions for an organization Sets the GitHub Actions permissions policy for repositories and allowed actions and reusable workflows in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setGithubActionsPermissionsOrganization: API.OperationMethod<SetGithubActionsPermissionsOrganizationRequest, SetGithubActionsPermissionsOrganizationResponse, SetGithubActionsPermissionsOrganizationError, GithubOpContext>;
export type SetGithubActionsPermissionsRepositoryError = GithubOpError;
/** Set GitHub Actions permissions for a repository Sets the GitHub Actions permissions policy for enabling GitHub Actions and allowed actions and reusable workflows in the repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setGithubActionsPermissionsRepository: API.OperationMethod<SetGithubActionsPermissionsRepositoryRequest, SetGithubActionsPermissionsRepositoryResponse, SetGithubActionsPermissionsRepositoryError, GithubOpContext>;
export type SetPrivateRepoForkPrWorkflowsSettingsOrganizationError = GithubOpError;
/** Set private repo fork PR workflow settings for an organization Sets the settings for whether workflows from fork pull requests can run on private repositories in an organization. */
export declare const setPrivateRepoForkPrWorkflowsSettingsOrganization: API.OperationMethod<SetPrivateRepoForkPrWorkflowsSettingsOrganizationRequest, SetPrivateRepoForkPrWorkflowsSettingsOrganizationResponse, SetPrivateRepoForkPrWorkflowsSettingsOrganizationError, GithubOpContext>;
export type SetPrivateRepoForkPrWorkflowsSettingsRepositoryError = GithubOpError;
/** Set private repo fork PR workflow settings for a repository Sets the settings for whether workflows from fork pull requests can run on a private repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setPrivateRepoForkPrWorkflowsSettingsRepository: API.OperationMethod<SetPrivateRepoForkPrWorkflowsSettingsRepositoryRequest, SetPrivateRepoForkPrWorkflowsSettingsRepositoryResponse, SetPrivateRepoForkPrWorkflowsSettingsRepositoryError, GithubOpContext>;
export type SetRepoAccessToSelfHostedRunnerGroupInOrgError = GithubOpError;
/** Set repository access for a self-hosted runner group in an organization Replaces the list of repositories that have access to a self-hosted runner group configured in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setRepoAccessToSelfHostedRunnerGroupInOrg: API.OperationMethod<SetRepoAccessToSelfHostedRunnerGroupInOrgRequest, SetRepoAccessToSelfHostedRunnerGroupInOrgResponse, SetRepoAccessToSelfHostedRunnerGroupInOrgError, GithubOpContext>;
export type SetSelectedReposForOrgSecretError = GithubOpError;
/** Set selected repositories for an organization secret Replaces all repositories for an organization secret when the `visibility` for repository access is set to `selected`. The visibility is set when you [Create or update an organization secret](https://docs.github.com/rest/actions/secrets#create-or-update-an-organization-secret). Authenticated users must have collaborator access to a repository to create, update, or read secrets. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const setSelectedReposForOrgSecret: API.OperationMethod<SetSelectedReposForOrgSecretRequest, SetSelectedReposForOrgSecretResponse, SetSelectedReposForOrgSecretError, GithubOpContext>;
export type SetSelectedReposForOrgVariableError = GithubOpError;
/** Set selected repositories for an organization variable Replaces all repositories for an organization variable that is available to selected repositories. Organization variables that are available to selected repositories have their `visibility` field set to `selected`. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const setSelectedReposForOrgVariable: API.OperationMethod<SetSelectedReposForOrgVariableRequest, SetSelectedReposForOrgVariableResponse, SetSelectedReposForOrgVariableError, GithubOpContext>;
export type SetSelectedRepositoriesEnabledGithubActionsOrganizationError = GithubOpError;
/** Set selected repositories enabled for GitHub Actions in an organization Replaces the list of selected repositories that are enabled for GitHub Actions in an organization. To use this endpoint, the organization permission policy for `enabled_repositories` must be configured to `selected`. For more information, see "[Set GitHub Actions permissions for an organization](#set-github-actions-permissions-for-an-organization)." OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setSelectedRepositoriesEnabledGithubActionsOrganization: API.OperationMethod<SetSelectedRepositoriesEnabledGithubActionsOrganizationRequest, SetSelectedRepositoriesEnabledGithubActionsOrganizationResponse, SetSelectedRepositoriesEnabledGithubActionsOrganizationError, GithubOpContext>;
export type SetSelectedRepositoriesSelfHostedRunnersOrganizationError = GithubOpError;
/** Set repositories allowed to use self-hosted runners in an organization Sets repositories that are allowed to use self-hosted runners in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const setSelectedRepositoriesSelfHostedRunnersOrganization: API.OperationMethod<SetSelectedRepositoriesSelfHostedRunnersOrganizationRequest, SetSelectedRepositoriesSelfHostedRunnersOrganizationResponse, SetSelectedRepositoriesSelfHostedRunnersOrganizationError, GithubOpContext>;
export type SetSelfHostedRunnersInGroupForOrgError = GithubOpError;
/** Set self-hosted runners in a group for an organization Replaces the list of self-hosted runners that are part of an organization runner group. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const setSelfHostedRunnersInGroupForOrg: API.OperationMethod<SetSelfHostedRunnersInGroupForOrgRequest, SetSelfHostedRunnersInGroupForOrgResponse, SetSelfHostedRunnersInGroupForOrgError, GithubOpContext>;
export type SetSelfHostedRunnersPermissionsOrganizationError = GithubOpError;
/** Set self-hosted runners settings for an organization Sets the settings for self-hosted runners for an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope or the "Actions policies" fine-grained permission to use this endpoint. */
export declare const setSelfHostedRunnersPermissionsOrganization: API.OperationMethod<SetSelfHostedRunnersPermissionsOrganizationRequest, SetSelfHostedRunnersPermissionsOrganizationResponse, SetSelfHostedRunnersPermissionsOrganizationError, GithubOpContext>;
export type SetWorkflowAccessToRepositoryError = GithubOpError;
/** Set the level of access for workflows outside of the repository Sets the level of access that workflows outside of the repository have to actions and reusable workflows in the repository. This endpoint only applies to private repositories. For more information, see "[Allowing access to components in a private repository](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#allowing-access-to-components-in-a-private-repository)". OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const setWorkflowAccessToRepository: API.OperationMethod<SetWorkflowAccessToRepositoryRequest, SetWorkflowAccessToRepositoryResponse, SetWorkflowAccessToRepositoryError, GithubOpContext>;
export type UpdateEnvironmentVariableError = GithubOpError;
/** Update an environment variable Updates an environment variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const updateEnvironmentVariable: API.OperationMethod<UpdateEnvironmentVariableRequest, UpdateEnvironmentVariableResponse, UpdateEnvironmentVariableError, GithubOpContext>;
export type UpdateHostedRunnerForOrgError = GithubOpError;
/** Update a GitHub-hosted runner for an organization Updates a GitHub-hosted runner for an organization. OAuth app tokens and personal access tokens (classic) need the `manage_runners:org` scope to use this endpoint. */
export declare const updateHostedRunnerForOrg: API.OperationMethod<UpdateHostedRunnerForOrgRequest, ActionsHostedRunner, UpdateHostedRunnerForOrgError, GithubOpContext>;
export type UpdateOrgActionsPolicyError = GithubOpError;
/** Update an organization Actions policy Update an Actions policy for an organization. Omitting `workflow_path` preserves the policy's existing workflow targeting. */
export declare const updateOrgActionsPolicy: API.OperationMethod<UpdateOrgActionsPolicyRequest, ActionsPolicy, UpdateOrgActionsPolicyError, GithubOpContext>;
export type UpdateOrgVariableError = GithubOpError;
/** Update an organization variable Updates an organization variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required. */
export declare const updateOrgVariable: API.OperationMethod<UpdateOrgVariableRequest, UpdateOrgVariableResponse, UpdateOrgVariableError, GithubOpContext>;
export type UpdateRepoActionsPolicyError = GithubOpError;
/** Update a repository Actions policy Update an Actions policy for a repository. Omitting `workflow_path` preserves the policy's existing workflow targeting. */
export declare const updateRepoActionsPolicy: API.OperationMethod<UpdateRepoActionsPolicyRequest, ActionsPolicy, UpdateRepoActionsPolicyError, GithubOpContext>;
export type UpdateRepoVariableError = GithubOpError;
/** Update a repository variable Updates a repository variable that you can reference in a GitHub Actions workflow. Authenticated users must have collaborator access to a repository to create, update, or read variables. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const updateRepoVariable: API.OperationMethod<UpdateRepoVariableRequest, UpdateRepoVariableResponse, UpdateRepoVariableError, GithubOpContext>;
export type UpdateSelfHostedRunnerGroupForOrgError = GithubOpError;
/** Update a self-hosted runner group for an organization Updates the `name` and `visibility` of a self-hosted runner group in an organization. OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. */
export declare const updateSelfHostedRunnerGroupForOrg: API.OperationMethod<UpdateSelfHostedRunnerGroupForOrgRequest, RunnerGroupsOrg, UpdateSelfHostedRunnerGroupForOrgError, GithubOpContext>;
//# sourceMappingURL=actions.d.ts.map