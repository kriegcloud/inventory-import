import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AdvancedPromptOptimizationJobIdentifier = string;
export type AdvancedPromptOptimizationJobIdentifiers = string[];
export interface BatchDeleteAdvancedPromptOptimizationJobRequest {
    jobIdentifiers: string[];
}
export interface BatchDeleteAdvancedPromptOptimizationJobError_ {
    jobIdentifier: string;
    code: string;
    message?: string | undefined;
}
export type BatchDeleteAdvancedPromptOptimizationJobErrors = BatchDeleteAdvancedPromptOptimizationJobError_[];
export type AdvancedPromptOptimizationJobStatus = "InProgress" | "Completed" | "Failed" | "PartiallyCompleted" | "Stopping" | "Stopped" | "Deleting" | (string & {});
export interface BatchDeleteAdvancedPromptOptimizationJobItem {
    jobIdentifier: string;
    jobStatus: AdvancedPromptOptimizationJobStatus;
}
export type BatchDeleteAdvancedPromptOptimizationJobItems = BatchDeleteAdvancedPromptOptimizationJobItem[];
export interface BatchDeleteAdvancedPromptOptimizationJobResponse {
    errors: BatchDeleteAdvancedPromptOptimizationJobError_[];
    advancedPromptOptimizationJobs: BatchDeleteAdvancedPromptOptimizationJobItem[];
}
export type EvaluationJobIdentifier = string | redacted.Redacted<string>;
export type EvaluationJobIdentifiers = (string | redacted.Redacted<string>)[];
export interface BatchDeleteEvaluationJobRequest {
    jobIdentifiers: (string | redacted.Redacted<string>)[];
}
export interface BatchDeleteEvaluationJobError_ {
    jobIdentifier: string | redacted.Redacted<string>;
    code: string;
    message?: string | undefined;
}
export type BatchDeleteEvaluationJobErrors = BatchDeleteEvaluationJobError_[];
export type EvaluationJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "Deleting" | (string & {});
export interface BatchDeleteEvaluationJobItem {
    jobIdentifier: string | redacted.Redacted<string>;
    jobStatus: EvaluationJobStatus;
}
export type BatchDeleteEvaluationJobItems = BatchDeleteEvaluationJobItem[];
export interface BatchDeleteEvaluationJobResponse {
    errors: BatchDeleteEvaluationJobError_[];
    evaluationJobs: BatchDeleteEvaluationJobItem[];
}
export type AutomatedReasoningPolicyArn = string;
export type AutomatedReasoningPolicyBuildWorkflowId = string;
export interface CancelAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export interface CancelAutomatedReasoningPolicyBuildWorkflowResponse {
}
export type AdvancedPromptOptimizationJobName = string;
export type AdvancedPromptOptimizationJobDescription = string;
export type IdempotencyToken = string;
export type S3Uri = string;
export interface AdvancedPromptOptimizationInputConfig {
    s3Uri: string;
}
export type S3UriFolder = string;
export interface AdvancedPromptOptimizationOutputConfig {
    s3Uri: string;
}
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export type AdvancedPromptOptimizationModelIdentifier = string;
export type NonEmptyStringList = string[];
export interface InferenceConfiguration {
    maxTokens?: number | undefined;
    temperature?: number | undefined;
    topP?: number | undefined;
    stopSequences?: string[] | undefined;
}
export type AdditionalModelRequestFieldsKey = string;
export type AdditionalModelRequestFieldsValue = unknown;
export type AdditionalModelRequestFields = {
    [key: string]: any | undefined;
};
export interface ModelConfiguration {
    modelId: string;
    inferenceConfig?: InferenceConfiguration | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type ModelConfigurations = ModelConfiguration[];
export interface CreateAdvancedPromptOptimizationJobRequest {
    jobName: string;
    jobDescription?: string | undefined;
    clientToken?: string | undefined;
    inputConfig: AdvancedPromptOptimizationInputConfig;
    outputConfig: AdvancedPromptOptimizationOutputConfig;
    encryptionKeyArn?: string | undefined;
    tags?: Tag[] | undefined;
    modelConfigurations: ModelConfiguration[];
}
export type AdvancedPromptOptimizationJobArn = string;
export interface CreateAdvancedPromptOptimizationJobResponse {
    jobArn: string;
}
export type AutomatedReasoningPolicyName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDescription = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyFormatVersion = string;
export type AutomatedReasoningPolicyDefinitionTypeName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionTypeDescription = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionTypeValueName = string;
export type AutomatedReasoningPolicyDefinitionTypeValueDescription = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyDefinitionTypeValue {
    value: string;
    description?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyDefinitionTypeValueList = AutomatedReasoningPolicyDefinitionTypeValue[];
export interface AutomatedReasoningPolicyDefinitionType {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    values: AutomatedReasoningPolicyDefinitionTypeValue[];
}
export type AutomatedReasoningPolicyDefinitionTypeList = AutomatedReasoningPolicyDefinitionType[];
export type AutomatedReasoningPolicyDefinitionRuleId = string;
export type AutomatedReasoningPolicyDefinitionRuleExpression = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionRuleAlternateExpression = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyDefinitionRule {
    id: string;
    expression: string | redacted.Redacted<string>;
    alternateExpression?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyDefinitionRuleList = AutomatedReasoningPolicyDefinitionRule[];
export type AutomatedReasoningPolicyDefinitionVariableName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyDefinitionVariableDescription = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyDefinitionVariable {
    name: string | redacted.Redacted<string>;
    type: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
}
export type AutomatedReasoningPolicyDefinitionVariableList = AutomatedReasoningPolicyDefinitionVariable[];
export interface AutomatedReasoningPolicyDefinition {
    version?: string | undefined;
    types?: AutomatedReasoningPolicyDefinitionType[] | undefined;
    rules?: AutomatedReasoningPolicyDefinitionRule[] | undefined;
    variables?: AutomatedReasoningPolicyDefinitionVariable[] | undefined;
}
export type KmsKeyId = string;
export interface CreateAutomatedReasoningPolicyRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    clientRequestToken?: string | undefined;
    policyDefinition?: AutomatedReasoningPolicyDefinition | undefined;
    kmsKeyId?: string | undefined;
    tags?: Tag[] | undefined;
}
export type AutomatedReasoningPolicyVersion = string;
export type AutomatedReasoningPolicyHash = string;
export interface CreateAutomatedReasoningPolicyResponse {
    policyArn: string;
    version: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    definitionHash?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type AutomatedReasoningPolicyTestGuardContent = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyTestQueryContent = string | redacted.Redacted<string>;
export type AutomatedReasoningCheckResult = "VALID" | "INVALID" | "SATISFIABLE" | "IMPOSSIBLE" | "TRANSLATION_AMBIGUOUS" | "TOO_COMPLEX" | "NO_TRANSLATION" | (string & {});
export type AutomatedReasoningCheckTranslationConfidence = number;
export interface CreateAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    guardContent: string | redacted.Redacted<string>;
    queryContent?: string | redacted.Redacted<string> | undefined;
    expectedAggregatedFindingsResult: AutomatedReasoningCheckResult;
    clientRequestToken?: string | undefined;
    confidenceThreshold?: number | undefined;
}
export type AutomatedReasoningPolicyTestCaseId = string;
export interface CreateAutomatedReasoningPolicyTestCaseResponse {
    policyArn: string;
    testCaseId: string;
}
export interface CreateAutomatedReasoningPolicyVersionRequest {
    policyArn: string;
    clientRequestToken?: string | undefined;
    lastUpdatedDefinitionHash: string;
    tags?: Tag[] | undefined;
}
export interface CreateAutomatedReasoningPolicyVersionResponse {
    policyArn: string;
    version: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    definitionHash: string;
    createdAt: Date;
}
export type CustomModelName = string;
export interface S3DataSource {
    s3Uri: string;
}
export type ModelDataSource = {
    s3DataSource: S3DataSource;
};
export type ModelPackageArn = string;
export interface ModelPackageArnDataSource {
    modelPackageArn: string;
}
export type CustomModelDataSource = {
    modelPackageArnDataSource: ModelPackageArnDataSource;
};
export type RoleArn = string;
export interface CreateCustomModelRequest {
    modelName: string;
    modelSourceConfig?: ModelDataSource | undefined;
    customModelDataSource?: CustomModelDataSource | undefined;
    modelKmsKeyArn?: string | undefined;
    roleArn?: string | undefined;
    modelTags?: Tag[] | undefined;
    clientRequestToken?: string | undefined;
}
export type ModelArn = string;
export interface CreateCustomModelResponse {
    modelArn: string;
}
export type ModelDeploymentName = string;
export type CustomModelArn = string;
export type CustomModelDeploymentDescription = string;
export interface CreateCustomModelDeploymentRequest {
    modelDeploymentName: string;
    modelArn: string;
    description?: string | undefined;
    tags?: Tag[] | undefined;
    clientRequestToken?: string | undefined;
}
export type CustomModelDeploymentArn = string;
export interface CreateCustomModelDeploymentResponse {
    customModelDeploymentArn: string;
}
export type EvaluationJobName = string;
export type EvaluationJobDescription = string | redacted.Redacted<string>;
export type ApplicationType = "ModelEvaluation" | "RagEvaluation" | (string & {});
export type EvaluationTaskType = "Summarization" | "Classification" | "QuestionAndAnswer" | "Generation" | "Custom" | (string & {});
export type EvaluationDatasetName = string | redacted.Redacted<string>;
export type EvaluationDatasetLocation = {
    s3Uri: string;
};
export interface EvaluationDataset {
    name: string | redacted.Redacted<string>;
    datasetLocation?: EvaluationDatasetLocation | undefined;
}
export type EvaluationMetricName = string | redacted.Redacted<string>;
export type EvaluationMetricNames = (string | redacted.Redacted<string>)[];
export interface EvaluationDatasetMetricConfig {
    taskType: EvaluationTaskType;
    dataset: EvaluationDataset;
    metricNames: (string | redacted.Redacted<string>)[];
}
export type EvaluationDatasetMetricConfigs = EvaluationDatasetMetricConfig[];
export type EvaluatorModelIdentifier = string;
export interface BedrockEvaluatorModel {
    modelIdentifier: string;
}
export type BedrockEvaluatorModels = BedrockEvaluatorModel[];
export type EvaluatorModelConfig = {
    bedrockEvaluatorModels: BedrockEvaluatorModel[];
};
export type MetricName = string | redacted.Redacted<string>;
export type CustomMetricInstructions = string;
export type RatingScaleItemDefinition = string;
export type RatingScaleItemValue = {
    stringValue: string;
    floatValue?: undefined;
} | {
    stringValue?: undefined;
    floatValue: number;
};
export interface RatingScaleItem {
    definition: string;
    value: RatingScaleItemValue;
}
export type RatingScale = RatingScaleItem[];
export interface CustomMetricDefinition {
    name: string | redacted.Redacted<string>;
    instructions: string;
    ratingScale?: RatingScaleItem[] | undefined;
}
export type AutomatedEvaluationCustomMetricSource = {
    customMetricDefinition: CustomMetricDefinition;
};
export type AutomatedEvaluationCustomMetrics = AutomatedEvaluationCustomMetricSource[];
export interface CustomMetricBedrockEvaluatorModel {
    modelIdentifier: string;
}
export type CustomMetricBedrockEvaluatorModels = CustomMetricBedrockEvaluatorModel[];
export interface CustomMetricEvaluatorModelConfig {
    bedrockEvaluatorModels: CustomMetricBedrockEvaluatorModel[];
}
export interface AutomatedEvaluationCustomMetricConfig {
    customMetrics: AutomatedEvaluationCustomMetricSource[];
    evaluatorModelConfig: CustomMetricEvaluatorModelConfig;
}
export interface AutomatedEvaluationConfig {
    datasetMetricConfigs: EvaluationDatasetMetricConfig[];
    evaluatorModelConfig?: EvaluatorModelConfig | undefined;
    customMetricConfig?: AutomatedEvaluationCustomMetricConfig | undefined;
}
export type SageMakerFlowDefinitionArn = string;
export type HumanTaskInstructions = string | redacted.Redacted<string>;
export interface HumanWorkflowConfig {
    flowDefinitionArn: string;
    instructions?: string | redacted.Redacted<string> | undefined;
}
export type EvaluationMetricDescription = string | redacted.Redacted<string>;
export type EvaluationRatingMethod = string;
export interface HumanEvaluationCustomMetric {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    ratingMethod: string;
}
export type HumanEvaluationCustomMetrics = HumanEvaluationCustomMetric[];
export interface HumanEvaluationConfig {
    humanWorkflowConfig?: HumanWorkflowConfig | undefined;
    customMetrics?: HumanEvaluationCustomMetric[] | undefined;
    datasetMetricConfigs: EvaluationDatasetMetricConfig[];
}
export type EvaluationConfig = {
    automated: AutomatedEvaluationConfig;
    human?: undefined;
} | {
    automated?: undefined;
    human: HumanEvaluationConfig;
};
export type EvaluationBedrockModelIdentifier = string;
export type EvaluationModelInferenceParams = string | redacted.Redacted<string>;
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency | undefined;
}
export interface EvaluationBedrockModel {
    modelIdentifier: string;
    inferenceParams?: string | redacted.Redacted<string> | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
}
export type EvaluationPrecomputedInferenceSourceIdentifier = string;
export interface EvaluationPrecomputedInferenceSource {
    inferenceSourceIdentifier: string;
}
export type EvaluationModelConfig = {
    bedrockModel: EvaluationBedrockModel;
    precomputedInferenceSource?: undefined;
} | {
    bedrockModel?: undefined;
    precomputedInferenceSource: EvaluationPrecomputedInferenceSource;
};
export type EvaluationModelConfigs = EvaluationModelConfig[];
export type KnowledgeBaseId = string;
export type SearchType = "HYBRID" | "SEMANTIC" | (string & {});
export type FilterKey = string;
export type FilterValue = unknown;
export interface FilterAttribute {
    key: string;
    value: any;
}
export type RetrievalFilterList = RetrievalFilter[];
export type RetrievalFilter = {
    equals: FilterAttribute;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals: FilterAttribute;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan: FilterAttribute;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals: FilterAttribute;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan: FilterAttribute;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals: FilterAttribute;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in: FilterAttribute;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn: FilterAttribute;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith: FilterAttribute;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains: FilterAttribute;
    stringContains?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains: FilterAttribute;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll: RetrievalFilter[];
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    greaterThan?: undefined;
    greaterThanOrEquals?: undefined;
    lessThan?: undefined;
    lessThanOrEquals?: undefined;
    in?: undefined;
    notIn?: undefined;
    startsWith?: undefined;
    listContains?: undefined;
    stringContains?: undefined;
    andAll?: undefined;
    orAll: RetrievalFilter[];
};
export type AttributeType = "STRING" | "NUMBER" | "BOOLEAN" | "STRING_LIST" | (string & {});
export interface MetadataAttributeSchema {
    key: string;
    type: AttributeType;
    description: string;
}
export type MetadataAttributeSchemaList = MetadataAttributeSchema[];
export type BedrockModelArn = string;
export interface ImplicitFilterConfiguration {
    metadataAttributes: MetadataAttributeSchema[];
    modelArn: string;
}
export type VectorSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export type BedrockRerankingModelArn = string;
export interface VectorSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type RerankingMetadataSelectionMode = "SELECTIVE" | "ALL" | (string & {});
export interface FieldForReranking {
    fieldName: string;
}
export type FieldsForReranking = FieldForReranking[];
export type RerankingMetadataSelectiveModeConfiguration = {
    fieldsToInclude: FieldForReranking[];
    fieldsToExclude?: undefined;
} | {
    fieldsToInclude?: undefined;
    fieldsToExclude: FieldForReranking[];
};
export interface MetadataConfigurationForReranking {
    selectionMode: RerankingMetadataSelectionMode;
    selectiveModeConfiguration?: RerankingMetadataSelectiveModeConfiguration | undefined;
}
export interface VectorSearchBedrockRerankingConfiguration {
    modelConfiguration: VectorSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number | undefined;
    metadataConfiguration?: MetadataConfigurationForReranking | undefined;
}
export interface VectorSearchRerankingConfiguration {
    type: VectorSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: VectorSearchBedrockRerankingConfiguration | undefined;
}
export interface KnowledgeBaseVectorSearchConfiguration {
    numberOfResults?: number | undefined;
    overrideSearchType?: SearchType | undefined;
    filter?: RetrievalFilter | undefined;
    implicitFilterConfiguration?: ImplicitFilterConfiguration | undefined;
    rerankingConfiguration?: VectorSearchRerankingConfiguration | undefined;
}
export interface KnowledgeBaseRetrievalConfiguration {
    vectorSearchConfiguration: KnowledgeBaseVectorSearchConfiguration;
}
export interface RetrieveConfig {
    knowledgeBaseId: string;
    knowledgeBaseRetrievalConfiguration: KnowledgeBaseRetrievalConfiguration;
}
export type RetrieveAndGenerateType = "KNOWLEDGE_BASE" | "EXTERNAL_SOURCES" | (string & {});
export type TextPromptTemplate = string | redacted.Redacted<string>;
export interface PromptTemplate {
    textPromptTemplate?: string | redacted.Redacted<string> | undefined;
}
export interface GuardrailConfiguration {
    guardrailId: string;
    guardrailVersion: string;
}
export type Temperature = number;
export type TopP = number;
export type MaxTokens = number;
export type RAGStopSequences = string[];
export interface TextInferenceConfig {
    temperature?: number | undefined;
    topP?: number | undefined;
    maxTokens?: number | undefined;
    stopSequences?: string[] | undefined;
}
export interface KbInferenceConfig {
    textInferenceConfig?: TextInferenceConfig | undefined;
}
export interface GenerationConfiguration {
    promptTemplate?: PromptTemplate | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    kbInferenceConfig?: KbInferenceConfig | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type QueryTransformationType = "QUERY_DECOMPOSITION" | (string & {});
export interface QueryTransformationConfiguration {
    type: QueryTransformationType;
}
export interface OrchestrationConfiguration {
    queryTransformationConfiguration: QueryTransformationConfiguration;
}
export interface KnowledgeBaseRetrieveAndGenerateConfiguration {
    knowledgeBaseId: string;
    modelArn: string;
    retrievalConfiguration?: KnowledgeBaseRetrievalConfiguration | undefined;
    generationConfiguration?: GenerationConfiguration | undefined;
    orchestrationConfiguration?: OrchestrationConfiguration | undefined;
}
export type ExternalSourceType = "S3" | "BYTE_CONTENT" | (string & {});
export type KBS3Uri = string;
export interface S3ObjectDoc {
    uri: string;
}
export type Identifier = string | redacted.Redacted<string>;
export type ContentType = string;
export type ByteContentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ByteContentDoc {
    identifier: string | redacted.Redacted<string>;
    contentType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export interface ExternalSource {
    sourceType: ExternalSourceType;
    s3Location?: S3ObjectDoc | undefined;
    byteContent?: ByteContentDoc | undefined;
}
export type ExternalSources = ExternalSource[];
export interface ExternalSourcesGenerationConfiguration {
    promptTemplate?: PromptTemplate | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    kbInferenceConfig?: KbInferenceConfig | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export interface ExternalSourcesRetrieveAndGenerateConfiguration {
    modelArn: string;
    sources: ExternalSource[];
    generationConfiguration?: ExternalSourcesGenerationConfiguration | undefined;
}
export interface RetrieveAndGenerateConfiguration {
    type: RetrieveAndGenerateType;
    knowledgeBaseConfiguration?: KnowledgeBaseRetrieveAndGenerateConfiguration | undefined;
    externalSourcesConfiguration?: ExternalSourcesRetrieveAndGenerateConfiguration | undefined;
}
export type KnowledgeBaseConfig = {
    retrieveConfig: RetrieveConfig;
    retrieveAndGenerateConfig?: undefined;
} | {
    retrieveConfig?: undefined;
    retrieveAndGenerateConfig: RetrieveAndGenerateConfiguration;
};
export type EvaluationPrecomputedRagSourceIdentifier = string;
export interface EvaluationPrecomputedRetrieveSourceConfig {
    ragSourceIdentifier: string;
}
export interface EvaluationPrecomputedRetrieveAndGenerateSourceConfig {
    ragSourceIdentifier: string;
}
export type EvaluationPrecomputedRagSourceConfig = {
    retrieveSourceConfig: EvaluationPrecomputedRetrieveSourceConfig;
    retrieveAndGenerateSourceConfig?: undefined;
} | {
    retrieveSourceConfig?: undefined;
    retrieveAndGenerateSourceConfig: EvaluationPrecomputedRetrieveAndGenerateSourceConfig;
};
export type RAGConfig = {
    knowledgeBaseConfig: KnowledgeBaseConfig;
    precomputedRagSourceConfig?: undefined;
} | {
    knowledgeBaseConfig?: undefined;
    precomputedRagSourceConfig: EvaluationPrecomputedRagSourceConfig;
};
export type RagConfigs = RAGConfig[];
export type EvaluationInferenceConfig = {
    models: EvaluationModelConfig[];
    ragConfigs?: undefined;
} | {
    models?: undefined;
    ragConfigs: RAGConfig[];
};
export interface EvaluationOutputDataConfig {
    s3Uri: string;
}
export interface CreateEvaluationJobRequest {
    jobName: string;
    jobDescription?: string | redacted.Redacted<string> | undefined;
    clientRequestToken?: string | undefined;
    roleArn: string;
    customerEncryptionKeyId?: string | undefined;
    jobTags?: Tag[] | undefined;
    applicationType?: ApplicationType | undefined;
    evaluationConfig: EvaluationConfig;
    inferenceConfig: EvaluationInferenceConfig;
    outputDataConfig: EvaluationOutputDataConfig;
}
export type EvaluationJobArn = string;
export interface CreateEvaluationJobResponse {
    jobArn: string;
}
export type OfferToken = string;
export type BedrockModelId = string;
export interface CreateFoundationModelAgreementRequest {
    offerToken: string;
    modelId: string;
}
export interface CreateFoundationModelAgreementResponse {
    modelId: string;
}
export type GuardrailName = string | redacted.Redacted<string>;
export type GuardrailDescription = string | redacted.Redacted<string>;
export type GuardrailTopicName = string | redacted.Redacted<string>;
export type GuardrailTopicDefinition = string | redacted.Redacted<string>;
export type GuardrailTopicExample = string | redacted.Redacted<string>;
export type GuardrailTopicExamples = (string | redacted.Redacted<string>)[];
export type GuardrailTopicType = "DENY" | (string & {});
export type GuardrailTopicAction = "BLOCK" | "NONE" | (string & {});
export interface GuardrailTopicConfig {
    name: string | redacted.Redacted<string>;
    definition: string | redacted.Redacted<string>;
    examples?: (string | redacted.Redacted<string>)[] | undefined;
    type: GuardrailTopicType;
    inputAction?: GuardrailTopicAction | undefined;
    outputAction?: GuardrailTopicAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailTopicsConfig = GuardrailTopicConfig[];
export type GuardrailTopicsTierName = "CLASSIC" | "STANDARD" | (string & {});
export interface GuardrailTopicsTierConfig {
    tierName: GuardrailTopicsTierName;
}
export interface GuardrailTopicPolicyConfig {
    topicsConfig: GuardrailTopicConfig[];
    tierConfig?: GuardrailTopicsTierConfig | undefined;
}
export type GuardrailContentFilterType = "SEXUAL" | "VIOLENCE" | "HATE" | "INSULTS" | "MISCONDUCT" | "PROMPT_ATTACK" | (string & {});
export type GuardrailFilterStrength = "NONE" | "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type GuardrailModality = "TEXT" | "IMAGE" | (string & {});
export type GuardrailModalities = GuardrailModality[];
export type GuardrailContentFilterAction = "BLOCK" | "NONE" | (string & {});
export interface GuardrailContentFilterConfig {
    type: GuardrailContentFilterType;
    inputStrength: GuardrailFilterStrength;
    outputStrength: GuardrailFilterStrength;
    inputModalities?: GuardrailModality[] | undefined;
    outputModalities?: GuardrailModality[] | undefined;
    inputAction?: GuardrailContentFilterAction | undefined;
    outputAction?: GuardrailContentFilterAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailContentFiltersConfig = GuardrailContentFilterConfig[];
export type GuardrailContentFiltersTierName = "CLASSIC" | "STANDARD" | (string & {});
export interface GuardrailContentFiltersTierConfig {
    tierName: GuardrailContentFiltersTierName;
}
export interface GuardrailContentPolicyConfig {
    filtersConfig: GuardrailContentFilterConfig[];
    tierConfig?: GuardrailContentFiltersTierConfig | undefined;
}
export type GuardrailWordAction = "BLOCK" | "NONE" | (string & {});
export interface GuardrailWordConfig {
    text: string;
    inputAction?: GuardrailWordAction | undefined;
    outputAction?: GuardrailWordAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailWordsConfig = GuardrailWordConfig[];
export type GuardrailManagedWordsType = "PROFANITY" | (string & {});
export interface GuardrailManagedWordsConfig {
    type: GuardrailManagedWordsType;
    inputAction?: GuardrailWordAction | undefined;
    outputAction?: GuardrailWordAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailManagedWordListsConfig = GuardrailManagedWordsConfig[];
export interface GuardrailWordPolicyConfig {
    wordsConfig?: GuardrailWordConfig[] | undefined;
    managedWordListsConfig?: GuardrailManagedWordsConfig[] | undefined;
}
export type GuardrailPiiEntityType = "ADDRESS" | "AGE" | "AWS_ACCESS_KEY" | "AWS_SECRET_KEY" | "CA_HEALTH_NUMBER" | "CA_SOCIAL_INSURANCE_NUMBER" | "CREDIT_DEBIT_CARD_CVV" | "CREDIT_DEBIT_CARD_EXPIRY" | "CREDIT_DEBIT_CARD_NUMBER" | "DRIVER_ID" | "EMAIL" | "INTERNATIONAL_BANK_ACCOUNT_NUMBER" | "IP_ADDRESS" | "LICENSE_PLATE" | "MAC_ADDRESS" | "NAME" | "PASSWORD" | "PHONE" | "PIN" | "SWIFT_CODE" | "UK_NATIONAL_HEALTH_SERVICE_NUMBER" | "UK_NATIONAL_INSURANCE_NUMBER" | "UK_UNIQUE_TAXPAYER_REFERENCE_NUMBER" | "URL" | "USERNAME" | "US_BANK_ACCOUNT_NUMBER" | "US_BANK_ROUTING_NUMBER" | "US_INDIVIDUAL_TAX_IDENTIFICATION_NUMBER" | "US_PASSPORT_NUMBER" | "US_SOCIAL_SECURITY_NUMBER" | "VEHICLE_IDENTIFICATION_NUMBER" | (string & {});
export type GuardrailSensitiveInformationAction = "BLOCK" | "ANONYMIZE" | "NONE" | (string & {});
export interface GuardrailPiiEntityConfig {
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction | undefined;
    outputAction?: GuardrailSensitiveInformationAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailPiiEntitiesConfig = GuardrailPiiEntityConfig[];
export interface GuardrailRegexConfig {
    name: string;
    description?: string | undefined;
    pattern: string;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction | undefined;
    outputAction?: GuardrailSensitiveInformationAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailRegexesConfig = GuardrailRegexConfig[];
export interface GuardrailSensitiveInformationPolicyConfig {
    piiEntitiesConfig?: GuardrailPiiEntityConfig[] | undefined;
    regexesConfig?: GuardrailRegexConfig[] | undefined;
}
export type GuardrailContextualGroundingFilterType = "GROUNDING" | "RELEVANCE" | (string & {});
export type GuardrailContextualGroundingAction = "BLOCK" | "NONE" | (string & {});
export interface GuardrailContextualGroundingFilterConfig {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    action?: GuardrailContextualGroundingAction | undefined;
    enabled?: boolean | undefined;
}
export type GuardrailContextualGroundingFiltersConfig = GuardrailContextualGroundingFilterConfig[];
export type GuardrailContextualGroundingTierName = "CLASSIC" | "STANDARD" | (string & {});
export interface GuardrailContextualGroundingTierConfig {
    tierName: GuardrailContextualGroundingTierName;
}
export interface GuardrailContextualGroundingPolicyConfig {
    filtersConfig: GuardrailContextualGroundingFilterConfig[];
    tierConfig?: GuardrailContextualGroundingTierConfig | undefined;
}
export type AutomatedReasoningPolicyArnList = string[];
export type AutomatedReasoningConfidenceFilterThreshold = number;
export interface GuardrailAutomatedReasoningPolicyConfig {
    policies: string[];
    confidenceThreshold?: number | undefined;
}
export type GuardrailCrossRegionGuardrailProfileIdentifier = string;
export interface GuardrailCrossRegionConfig {
    guardrailProfileIdentifier: string;
}
export type GuardrailBlockedMessaging = string | redacted.Redacted<string>;
export interface CreateGuardrailRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    topicPolicyConfig?: GuardrailTopicPolicyConfig | undefined;
    contentPolicyConfig?: GuardrailContentPolicyConfig | undefined;
    wordPolicyConfig?: GuardrailWordPolicyConfig | undefined;
    sensitiveInformationPolicyConfig?: GuardrailSensitiveInformationPolicyConfig | undefined;
    contextualGroundingPolicyConfig?: GuardrailContextualGroundingPolicyConfig | undefined;
    automatedReasoningPolicyConfig?: GuardrailAutomatedReasoningPolicyConfig | undefined;
    crossRegionConfig?: GuardrailCrossRegionConfig | undefined;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    kmsKeyId?: string | undefined;
    tags?: Tag[] | undefined;
    clientRequestToken?: string | undefined;
}
export type GuardrailId = string;
export type GuardrailArn = string;
export type GuardrailDraftVersion = string;
export interface CreateGuardrailResponse {
    guardrailId: string;
    guardrailArn: string;
    version: string;
    createdAt: Date;
}
export type GuardrailIdentifier = string;
export interface CreateGuardrailVersionRequest {
    guardrailIdentifier: string;
    description?: string | redacted.Redacted<string> | undefined;
    clientRequestToken?: string | undefined;
}
export type GuardrailNumericalVersion = string;
export interface CreateGuardrailVersionResponse {
    guardrailId: string;
    version: string;
}
export type InferenceProfileName = string;
export type InferenceProfileDescription = string | redacted.Redacted<string>;
export type InferenceProfileModelSourceArn = string;
export type InferenceProfileModelSource = {
    copyFrom: string;
};
export interface CreateInferenceProfileRequest {
    inferenceProfileName: string;
    description?: string | redacted.Redacted<string> | undefined;
    clientRequestToken?: string | undefined;
    modelSource: InferenceProfileModelSource;
    tags?: Tag[] | undefined;
}
export type InferenceProfileArn = string;
export type InferenceProfileStatus = "ACTIVE" | (string & {});
export interface CreateInferenceProfileResponse {
    inferenceProfileArn: string;
    status?: InferenceProfileStatus | undefined;
}
export type ModelSourceIdentifier = string;
export type InstanceCount = number;
export type InstanceType = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface VpcConfig {
    subnetIds: string[];
    securityGroupIds: string[];
}
export interface SageMakerEndpoint {
    initialInstanceCount: number;
    instanceType: string;
    executionRole: string;
    kmsEncryptionKey?: string | undefined;
    vpc?: VpcConfig | undefined;
}
export type EndpointConfig = {
    sageMaker: SageMakerEndpoint;
};
export type AcceptEula = boolean;
export type EndpointName = string;
export interface CreateMarketplaceModelEndpointRequest {
    modelSourceIdentifier: string;
    endpointConfig: EndpointConfig;
    acceptEula?: boolean | undefined;
    endpointName: string;
    clientRequestToken?: string | undefined;
    tags?: Tag[] | undefined;
}
export type Arn = string;
export type Status = "REGISTERED" | "INCOMPATIBLE_ENDPOINT" | (string & {});
export interface MarketplaceModelEndpoint {
    endpointArn: string;
    modelSourceIdentifier: string;
    status?: Status | undefined;
    statusMessage?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    endpointConfig: EndpointConfig;
    endpointStatus: string;
    endpointStatusMessage?: string | undefined;
}
export interface CreateMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint: MarketplaceModelEndpoint;
}
export interface CreateModelCopyJobRequest {
    sourceModelArn: string;
    targetModelName: string;
    modelKmsKeyId?: string | undefined;
    targetModelTags?: Tag[] | undefined;
    clientRequestToken?: string | undefined;
}
export type ModelCopyJobArn = string;
export interface CreateModelCopyJobResponse {
    jobArn: string;
}
export type JobName = string;
export type BaseModelIdentifier = string;
export type CustomizationType = "FINE_TUNING" | "CONTINUED_PRE_TRAINING" | "DISTILLATION" | "REINFORCEMENT_FINE_TUNING" | "IMPORTED" | (string & {});
export type UsePromptResponse = boolean;
export type InvocationLogSource = {
    s3Uri: string;
};
export type RequestMetadataMap = {
    [key: string]: string | undefined;
};
export interface RequestMetadataBaseFilters {
    equals?: {
        [key: string]: string | undefined;
    } | undefined;
    notEquals?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RequestMetadataFiltersList = RequestMetadataBaseFilters[];
export type RequestMetadataFilters = {
    equals: {
        [key: string]: string | undefined;
    };
    notEquals?: undefined;
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals: {
        [key: string]: string | undefined;
    };
    andAll?: undefined;
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    andAll: RequestMetadataBaseFilters[];
    orAll?: undefined;
} | {
    equals?: undefined;
    notEquals?: undefined;
    andAll?: undefined;
    orAll: RequestMetadataBaseFilters[];
};
export interface InvocationLogsConfig {
    usePromptResponse?: boolean | undefined;
    invocationLogSource: InvocationLogSource;
    requestMetadataFilters?: RequestMetadataFilters | undefined;
}
export interface TrainingDataConfig {
    s3Uri?: string | undefined;
    invocationLogsConfig?: InvocationLogsConfig | undefined;
}
export interface Validator {
    s3Uri: string;
}
export type Validators = Validator[];
export interface ValidationDataConfig {
    validators: Validator[];
}
export interface OutputDataConfig {
    s3Uri: string;
}
export type ModelCustomizationHyperParameters = {
    [key: string]: string | undefined;
};
export type TeacherModelIdentifier = string;
export interface TeacherModelConfig {
    teacherModelIdentifier: string;
    maxResponseLengthForInference?: number | undefined;
}
export interface DistillationConfig {
    teacherModelConfig: TeacherModelConfig;
}
export type LambdaArn = string;
export interface LambdaGraderConfig {
    lambdaArn: string;
}
export type GraderConfig = {
    lambdaGrader: LambdaGraderConfig;
};
export type EpochCount = number;
export type RFTBatchSize = number;
export type RFTLearningRate = number;
export type RFTMaxPromptLength = number;
export type RFTTrainingSamplePerPrompt = number;
export type RFTInferenceMaxTokens = number;
export type ReasoningEffort = "low" | "medium" | "high" | (string & {});
export type RFTEvalInterval = number;
export interface RFTHyperParameters {
    epochCount?: number | undefined;
    batchSize?: number | undefined;
    learningRate?: number | undefined;
    maxPromptLength?: number | undefined;
    trainingSamplePerPrompt?: number | undefined;
    inferenceMaxTokens?: number | undefined;
    reasoningEffort?: ReasoningEffort | undefined;
    evalInterval?: number | undefined;
}
export interface RFTConfig {
    graderConfig?: GraderConfig | undefined;
    hyperParameters?: RFTHyperParameters | undefined;
}
export type CustomizationConfig = {
    distillationConfig: DistillationConfig;
    rftConfig?: undefined;
} | {
    distillationConfig?: undefined;
    rftConfig: RFTConfig;
};
export interface CreateModelCustomizationJobRequest {
    jobName: string;
    customModelName: string;
    roleArn: string;
    clientRequestToken?: string | undefined;
    baseModelIdentifier: string;
    customizationType?: CustomizationType | undefined;
    customModelKmsKeyId?: string | undefined;
    jobTags?: Tag[] | undefined;
    customModelTags?: Tag[] | undefined;
    trainingDataConfig: TrainingDataConfig;
    validationDataConfig?: ValidationDataConfig | undefined;
    outputDataConfig: OutputDataConfig;
    hyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    vpcConfig?: VpcConfig | undefined;
    customizationConfig?: CustomizationConfig | undefined;
}
export type ModelCustomizationJobArn = string;
export interface CreateModelCustomizationJobResponse {
    jobArn: string;
}
export type ImportedModelName = string;
export interface CreateModelImportJobRequest {
    jobName: string;
    importedModelName: string;
    roleArn: string;
    modelDataSource: ModelDataSource;
    jobTags?: Tag[] | undefined;
    importedModelTags?: Tag[] | undefined;
    clientRequestToken?: string | undefined;
    vpcConfig?: VpcConfig | undefined;
    importedModelKmsKeyId?: string | undefined;
}
export type ModelImportJobArn = string;
export interface CreateModelImportJobResponse {
    jobArn: string;
}
export type ModelInvocationJobName = string;
export type ModelInvocationIdempotencyToken = string;
export type ModelId = string;
export type S3InputFormat = "JSONL" | (string & {});
export type AccountId = string;
export interface ModelInvocationJobS3InputDataConfig {
    s3InputFormat?: S3InputFormat | undefined;
    s3Uri: string;
    s3BucketOwner?: string | undefined;
}
export type ModelInvocationJobInputDataConfig = {
    s3InputDataConfig: ModelInvocationJobS3InputDataConfig;
};
export interface ModelInvocationJobS3OutputDataConfig {
    s3Uri: string;
    s3EncryptionKeyId?: string | undefined;
    s3BucketOwner?: string | undefined;
}
export type ModelInvocationJobOutputDataConfig = {
    s3OutputDataConfig: ModelInvocationJobS3OutputDataConfig;
};
export type ModelInvocationJobTimeoutDurationInHours = number;
export type ModelInvocationType = "InvokeModel" | "Converse" | (string & {});
export interface CreateModelInvocationJobRequest {
    jobName: string;
    roleArn: string;
    clientRequestToken?: string | undefined;
    modelId: string;
    inputDataConfig: ModelInvocationJobInputDataConfig;
    outputDataConfig: ModelInvocationJobOutputDataConfig;
    vpcConfig?: VpcConfig | undefined;
    timeoutDurationInHours?: number | undefined;
    tags?: Tag[] | undefined;
    modelInvocationType?: ModelInvocationType | undefined;
}
export type ModelInvocationJobArn = string;
export interface CreateModelInvocationJobResponse {
    jobArn: string;
}
export type PromptRouterName = string;
export type PromptRouterTargetModelArn = string;
export interface PromptRouterTargetModel {
    modelArn?: string | undefined;
}
export type PromptRouterTargetModels = PromptRouterTargetModel[];
export type PromptRouterDescription = string | redacted.Redacted<string>;
export interface RoutingCriteria {
    responseQualityDifference: number;
}
export interface CreatePromptRouterRequest {
    clientRequestToken?: string | undefined;
    promptRouterName: string;
    models: PromptRouterTargetModel[];
    description?: string | redacted.Redacted<string> | undefined;
    routingCriteria: RoutingCriteria;
    fallbackModel: PromptRouterTargetModel;
    tags?: Tag[] | undefined;
}
export type PromptRouterArn = string;
export interface CreatePromptRouterResponse {
    promptRouterArn?: string | undefined;
}
export type PositiveInteger = number;
export type ProvisionedModelName = string;
export type ModelIdentifier = string;
export type CommitmentDuration = "OneMonth" | "SixMonths" | (string & {});
export interface CreateProvisionedModelThroughputRequest {
    clientRequestToken?: string | undefined;
    modelUnits: number;
    provisionedModelName: string;
    modelId: string;
    commitmentDuration?: CommitmentDuration | undefined;
    tags?: Tag[] | undefined;
}
export type ProvisionedModelArn = string;
export interface CreateProvisionedModelThroughputResponse {
    provisionedModelArn: string;
}
export interface DeleteAutomatedReasoningPolicyRequest {
    policyArn: string;
    force?: boolean | undefined;
}
export interface DeleteAutomatedReasoningPolicyResponse {
}
export interface DeleteAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
    lastUpdatedAt: Date;
}
export interface DeleteAutomatedReasoningPolicyBuildWorkflowResponse {
}
export interface DeleteAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    testCaseId: string;
    lastUpdatedAt: Date;
}
export interface DeleteAutomatedReasoningPolicyTestCaseResponse {
}
export interface DeleteCustomModelRequest {
    modelIdentifier: string;
}
export interface DeleteCustomModelResponse {
}
export type CustomModelDeploymentIdentifier = string;
export interface DeleteCustomModelDeploymentRequest {
    customModelDeploymentIdentifier: string;
}
export interface DeleteCustomModelDeploymentResponse {
}
export type AccountEnforcedGuardrailConfigurationId = string;
export interface DeleteEnforcedGuardrailConfigurationRequest {
    configId: string;
}
export interface DeleteEnforcedGuardrailConfigurationResponse {
}
export interface DeleteFoundationModelAgreementRequest {
    modelId: string;
}
export interface DeleteFoundationModelAgreementResponse {
}
export interface DeleteGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion?: string | undefined;
}
export interface DeleteGuardrailResponse {
}
export type ImportedModelIdentifier = string;
export interface DeleteImportedModelRequest {
    modelIdentifier: string;
}
export interface DeleteImportedModelResponse {
}
export type InferenceProfileIdentifier = string;
export interface DeleteInferenceProfileRequest {
    inferenceProfileIdentifier: string;
}
export interface DeleteInferenceProfileResponse {
}
export interface DeleteMarketplaceModelEndpointRequest {
    endpointArn: string;
}
export interface DeleteMarketplaceModelEndpointResponse {
}
export interface DeleteModelInvocationLoggingConfigurationRequest {
}
export interface DeleteModelInvocationLoggingConfigurationResponse {
}
export interface DeletePromptRouterRequest {
    promptRouterArn: string;
}
export interface DeletePromptRouterResponse {
}
export type ProvisionedModelId = string;
export interface DeleteProvisionedModelThroughputRequest {
    provisionedModelId: string;
}
export interface DeleteProvisionedModelThroughputResponse {
}
export type ResourcePolicyResourceArn = string;
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeregisterMarketplaceModelEndpointRequest {
    endpointArn: string;
}
export interface DeregisterMarketplaceModelEndpointResponse {
}
export interface ExportAutomatedReasoningPolicyVersionRequest {
    policyArn: string;
}
export interface ExportAutomatedReasoningPolicyVersionResponse {
    policyDefinition: AutomatedReasoningPolicyDefinition;
}
export interface GetAccountDataRetentionRequest {
}
export type DataRetentionMode = "default" | "none" | "aws_review" | "provider_data_share" | "inherit" | (string & {});
export interface GetAccountDataRetentionResponse {
    mode: DataRetentionMode;
    updatedAt?: Date | undefined;
}
export interface GetAdvancedPromptOptimizationJobRequest {
    jobIdentifier: string;
}
export type ErrorMessage = string;
export interface GetAdvancedPromptOptimizationJobResponse {
    jobArn: string;
    jobName: string;
    jobDescription?: string | undefined;
    jobStatus: AdvancedPromptOptimizationJobStatus;
    inputConfig: AdvancedPromptOptimizationInputConfig;
    outputConfig: AdvancedPromptOptimizationOutputConfig;
    encryptionKeyArn?: string | undefined;
    creationTime: Date;
    lastModifiedTime?: Date | undefined;
    failureMessage?: string | undefined;
    modelConfigurations: ModelConfiguration[];
}
export interface GetAutomatedReasoningPolicyRequest {
    policyArn: string;
}
export type AutomatedReasoningPolicyId = string;
export interface GetAutomatedReasoningPolicyResponse {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    version: string;
    policyId: string;
    description?: string | redacted.Redacted<string> | undefined;
    definitionHash: string;
    kmsKeyArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt: Date;
}
export interface GetAutomatedReasoningPolicyAnnotationsRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export interface AutomatedReasoningPolicyAddTypeAnnotation {
    name: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
    values: AutomatedReasoningPolicyDefinitionTypeValue[];
}
export interface AutomatedReasoningPolicyAddTypeValue {
    value: string;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface AutomatedReasoningPolicyUpdateTypeValue {
    value: string;
    newValue?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface AutomatedReasoningPolicyDeleteTypeValue {
    value: string;
}
export type AutomatedReasoningPolicyTypeValueAnnotation = {
    addTypeValue: AutomatedReasoningPolicyAddTypeValue;
    updateTypeValue?: undefined;
    deleteTypeValue?: undefined;
} | {
    addTypeValue?: undefined;
    updateTypeValue: AutomatedReasoningPolicyUpdateTypeValue;
    deleteTypeValue?: undefined;
} | {
    addTypeValue?: undefined;
    updateTypeValue?: undefined;
    deleteTypeValue: AutomatedReasoningPolicyDeleteTypeValue;
};
export type AutomatedReasoningPolicyTypeValueAnnotationList = AutomatedReasoningPolicyTypeValueAnnotation[];
export interface AutomatedReasoningPolicyUpdateTypeAnnotation {
    name: string | redacted.Redacted<string>;
    newName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    values: AutomatedReasoningPolicyTypeValueAnnotation[];
}
export interface AutomatedReasoningPolicyDeleteTypeAnnotation {
    name: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyAddVariableAnnotation {
    name: string | redacted.Redacted<string>;
    type: string | redacted.Redacted<string>;
    description: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyUpdateVariableAnnotation {
    name: string | redacted.Redacted<string>;
    newName?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface AutomatedReasoningPolicyDeleteVariableAnnotation {
    name: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyAddRuleAnnotation {
    expression: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyUpdateRuleAnnotation {
    ruleId: string;
    expression: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyDeleteRuleAnnotation {
    ruleId: string;
}
export type AutomatedReasoningPolicyAnnotationRuleNaturalLanguage = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyAddRuleFromNaturalLanguageAnnotation {
    naturalLanguage: string | redacted.Redacted<string>;
}
export type AutomatedReasoningPolicyDefinitionRuleIdList = string[];
export type AutomatedReasoningPolicyAnnotationFeedbackNaturalLanguage = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyUpdateFromRuleFeedbackAnnotation {
    ruleIds?: string[] | undefined;
    feedback: string | redacted.Redacted<string>;
}
export type AutomatedReasoningPolicyScenarioExpression = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyUpdateFromScenarioFeedbackAnnotation {
    ruleIds?: string[] | undefined;
    scenarioExpression: string | redacted.Redacted<string>;
    feedback?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyAnnotationIngestContent = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyIngestContentAnnotation {
    content: string | redacted.Redacted<string>;
}
export type AutomatedReasoningPolicyAnnotation = {
    addType: AutomatedReasoningPolicyAddTypeAnnotation;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType: AutomatedReasoningPolicyUpdateTypeAnnotation;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType: AutomatedReasoningPolicyDeleteTypeAnnotation;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable: AutomatedReasoningPolicyAddVariableAnnotation;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable: AutomatedReasoningPolicyUpdateVariableAnnotation;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable: AutomatedReasoningPolicyDeleteVariableAnnotation;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule: AutomatedReasoningPolicyAddRuleAnnotation;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule: AutomatedReasoningPolicyUpdateRuleAnnotation;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule: AutomatedReasoningPolicyDeleteRuleAnnotation;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage: AutomatedReasoningPolicyAddRuleFromNaturalLanguageAnnotation;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback: AutomatedReasoningPolicyUpdateFromRuleFeedbackAnnotation;
    updateFromScenarioFeedback?: undefined;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback: AutomatedReasoningPolicyUpdateFromScenarioFeedbackAnnotation;
    ingestContent?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
    addRuleFromNaturalLanguage?: undefined;
    updateFromRulesFeedback?: undefined;
    updateFromScenarioFeedback?: undefined;
    ingestContent: AutomatedReasoningPolicyIngestContentAnnotation;
};
export type AutomatedReasoningPolicyAnnotationList = AutomatedReasoningPolicyAnnotation[];
export interface GetAutomatedReasoningPolicyAnnotationsResponse {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    buildWorkflowId: string;
    annotations: AutomatedReasoningPolicyAnnotation[];
    annotationSetHash: string;
    updatedAt: Date;
}
export interface GetAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export type AutomatedReasoningPolicyBuildWorkflowStatus = "SCHEDULED" | "CANCEL_REQUESTED" | "PREPROCESSING" | "BUILDING" | "TESTING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export type AutomatedReasoningPolicyBuildWorkflowType = "INGEST_CONTENT" | "REFINE_POLICY" | "IMPORT_POLICY" | "GENERATE_FIDELITY_REPORT" | "GENERATE_POLICY_SCENARIOS" | "RESOLVE_POLICY_AMBIGUITIES" | "ITERATIVELY_REFINE_POLICY" | (string & {});
export type AutomatedReasoningPolicyBuildDocumentName = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyBuildDocumentContentType = "pdf" | "txt" | (string & {});
export type AutomatedReasoningPolicyBuildDocumentDescription = string | redacted.Redacted<string>;
export interface GetAutomatedReasoningPolicyBuildWorkflowResponse {
    policyArn: string;
    buildWorkflowId: string;
    status: AutomatedReasoningPolicyBuildWorkflowStatus;
    buildWorkflowType: AutomatedReasoningPolicyBuildWorkflowType;
    documentName?: string | redacted.Redacted<string> | undefined;
    documentContentType?: AutomatedReasoningPolicyBuildDocumentContentType | undefined;
    documentDescription?: string | redacted.Redacted<string> | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type AutomatedReasoningPolicyBuildResultAssetType = "BUILD_LOG" | "QUALITY_REPORT" | "POLICY_DEFINITION" | "GENERATED_TEST_CASES" | "POLICY_SCENARIOS" | "FIDELITY_REPORT" | "ASSET_MANIFEST" | "SOURCE_DOCUMENT" | (string & {});
export type AutomatedReasoningPolicyBuildResultAssetId = string;
export interface GetAutomatedReasoningPolicyBuildWorkflowResultAssetsRequest {
    policyArn: string;
    buildWorkflowId: string;
    assetType: AutomatedReasoningPolicyBuildResultAssetType;
    assetId?: string | undefined;
}
export type AutomatedReasoningPolicyDefinitionTypeNameList = (string | redacted.Redacted<string>)[];
export interface AutomatedReasoningPolicyDefinitionTypeValuePair {
    typeName: string | redacted.Redacted<string>;
    valueName: string;
}
export type AutomatedReasoningPolicyDefinitionTypeValuePairList = AutomatedReasoningPolicyDefinitionTypeValuePair[];
export type AutomatedReasoningPolicyDefinitionVariableNameList = (string | redacted.Redacted<string>)[];
export type AutomatedReasoningPolicyConflictedRuleIdList = string[];
export type AutomatedReasoningPolicyDisjointedRuleIdList = string[];
export interface AutomatedReasoningPolicyDisjointRuleSet {
    variables: (string | redacted.Redacted<string>)[];
    rules: string[];
}
export type AutomatedReasoningPolicyDisjointRuleSetList = AutomatedReasoningPolicyDisjointRuleSet[];
export interface AutomatedReasoningPolicyDefinitionQualityReport {
    typeCount: number;
    variableCount: number;
    ruleCount: number;
    unusedTypes: (string | redacted.Redacted<string>)[];
    unusedTypeValues: AutomatedReasoningPolicyDefinitionTypeValuePair[];
    unusedVariables: (string | redacted.Redacted<string>)[];
    conflictingRules: string[];
    disjointRuleSets: AutomatedReasoningPolicyDisjointRuleSet[];
}
export type AutomatedReasoningPolicyAnnotationStatus = "APPLIED" | "FAILED" | (string & {});
export interface AutomatedReasoningPolicyPlanning {
}
export interface AutomatedReasoningPolicyAddTypeMutation {
    type: AutomatedReasoningPolicyDefinitionType;
}
export interface AutomatedReasoningPolicyUpdateTypeMutation {
    type: AutomatedReasoningPolicyDefinitionType;
}
export interface AutomatedReasoningPolicyDeleteTypeMutation {
    name: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyAddVariableMutation {
    variable: AutomatedReasoningPolicyDefinitionVariable;
}
export interface AutomatedReasoningPolicyUpdateVariableMutation {
    variable: AutomatedReasoningPolicyDefinitionVariable;
}
export interface AutomatedReasoningPolicyDeleteVariableMutation {
    name: string | redacted.Redacted<string>;
}
export interface AutomatedReasoningPolicyAddRuleMutation {
    rule: AutomatedReasoningPolicyDefinitionRule;
}
export interface AutomatedReasoningPolicyUpdateRuleMutation {
    rule: AutomatedReasoningPolicyDefinitionRule;
}
export interface AutomatedReasoningPolicyDeleteRuleMutation {
    id: string;
}
export type AutomatedReasoningPolicyMutation = {
    addType: AutomatedReasoningPolicyAddTypeMutation;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType: AutomatedReasoningPolicyUpdateTypeMutation;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType: AutomatedReasoningPolicyDeleteTypeMutation;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable: AutomatedReasoningPolicyAddVariableMutation;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable: AutomatedReasoningPolicyUpdateVariableMutation;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable: AutomatedReasoningPolicyDeleteVariableMutation;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule: AutomatedReasoningPolicyAddRuleMutation;
    updateRule?: undefined;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule: AutomatedReasoningPolicyUpdateRuleMutation;
    deleteRule?: undefined;
} | {
    addType?: undefined;
    updateType?: undefined;
    deleteType?: undefined;
    addVariable?: undefined;
    updateVariable?: undefined;
    deleteVariable?: undefined;
    addRule?: undefined;
    updateRule?: undefined;
    deleteRule: AutomatedReasoningPolicyDeleteRuleMutation;
};
export type AutomatedReasoningPolicyBuildStepContext = {
    planning: AutomatedReasoningPolicyPlanning;
    mutation?: undefined;
} | {
    planning?: undefined;
    mutation: AutomatedReasoningPolicyMutation;
};
export type AutomatedReasoningPolicyDefinitionElement = {
    policyDefinitionVariable: AutomatedReasoningPolicyDefinitionVariable;
    policyDefinitionType?: undefined;
    policyDefinitionRule?: undefined;
} | {
    policyDefinitionVariable?: undefined;
    policyDefinitionType: AutomatedReasoningPolicyDefinitionType;
    policyDefinitionRule?: undefined;
} | {
    policyDefinitionVariable?: undefined;
    policyDefinitionType?: undefined;
    policyDefinitionRule: AutomatedReasoningPolicyDefinitionRule;
};
export type AutomatedReasoningPolicyBuildMessageType = "INFO" | "WARNING" | "ERROR" | (string & {});
export interface AutomatedReasoningPolicyBuildStepMessage {
    message: string;
    messageType: AutomatedReasoningPolicyBuildMessageType;
}
export type AutomatedReasoningPolicyBuildStepMessageList = AutomatedReasoningPolicyBuildStepMessage[];
export interface AutomatedReasoningPolicyBuildStep {
    context: AutomatedReasoningPolicyBuildStepContext;
    priorElement?: AutomatedReasoningPolicyDefinitionElement | undefined;
    messages: AutomatedReasoningPolicyBuildStepMessage[];
}
export type AutomatedReasoningPolicyBuildStepList = AutomatedReasoningPolicyBuildStep[];
export interface AutomatedReasoningPolicyBuildLogEntry {
    annotation: AutomatedReasoningPolicyAnnotation;
    status: AutomatedReasoningPolicyAnnotationStatus;
    buildSteps: AutomatedReasoningPolicyBuildStep[];
}
export type AutomatedReasoningPolicyBuildLogEntryList = AutomatedReasoningPolicyBuildLogEntry[];
export interface AutomatedReasoningPolicyBuildLog {
    entries: AutomatedReasoningPolicyBuildLogEntry[];
}
export interface AutomatedReasoningPolicyGeneratedTestCase {
    queryContent: string | redacted.Redacted<string>;
    guardContent: string | redacted.Redacted<string>;
    expectedAggregatedFindingsResult: AutomatedReasoningCheckResult;
}
export type AutomatedReasoningPolicyGeneratedTestCaseList = AutomatedReasoningPolicyGeneratedTestCase[];
export interface AutomatedReasoningPolicyGeneratedTestCases {
    generatedTestCases: AutomatedReasoningPolicyGeneratedTestCase[];
}
export type AutomatedReasoningPolicyScenarioAlternateExpression = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyScenario {
    expression: string | redacted.Redacted<string>;
    alternateExpression: string | redacted.Redacted<string>;
    expectedResult: AutomatedReasoningCheckResult;
    ruleIds: string[];
}
export type AutomatedReasoningPolicyScenarioList = AutomatedReasoningPolicyScenario[];
export interface AutomatedReasoningPolicyScenarios {
    policyScenarios: AutomatedReasoningPolicyScenario[];
}
export type AutomatedReasoningPolicyBuildResultAssetName = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyBuildResultAssetManifestEntry {
    assetType: AutomatedReasoningPolicyBuildResultAssetType;
    assetName?: string | redacted.Redacted<string> | undefined;
    assetId?: string | undefined;
}
export type AutomatedReasoningPolicyBuildResultAssetManifestList = AutomatedReasoningPolicyBuildResultAssetManifestEntry[];
export interface AutomatedReasoningPolicyBuildResultAssetManifest {
    entries: AutomatedReasoningPolicyBuildResultAssetManifestEntry[];
}
export type AutomatedReasoningPolicyBuildDocumentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export type AutomatedReasoningPolicyDocumentSha256 = string;
export interface AutomatedReasoningPolicySourceDocument {
    document: Uint8Array | redacted.Redacted<Uint8Array>;
    documentContentType: AutomatedReasoningPolicyBuildDocumentContentType;
    documentName: string | redacted.Redacted<string>;
    documentDescription?: string | redacted.Redacted<string> | undefined;
    documentHash: string;
}
export type AutomatedReasoningPolicyCoverageScore = number;
export type AutomatedReasoningPolicyAccuracyScore = number;
export type AutomatedReasoningPolicyDocumentId = string;
export type AutomatedReasoningPolicyStatementId = string;
export interface AutomatedReasoningPolicyStatementReference {
    documentId: string;
    statementId: string;
}
export type AutomatedReasoningPolicyStatementReferenceList = AutomatedReasoningPolicyStatementReference[];
export type AutomatedReasoningPolicyJustificationText = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyJustificationList = (string | redacted.Redacted<string>)[];
export interface AutomatedReasoningPolicyRuleReport {
    rule: string;
    groundingStatements?: AutomatedReasoningPolicyStatementReference[] | undefined;
    groundingJustifications?: (string | redacted.Redacted<string>)[] | undefined;
    accuracyScore?: number | undefined;
    accuracyJustification?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyRuleReportMap = {
    [key: string]: AutomatedReasoningPolicyRuleReport | undefined;
};
export interface AutomatedReasoningPolicyVariableReport {
    policyVariable: string | redacted.Redacted<string>;
    groundingStatements?: AutomatedReasoningPolicyStatementReference[] | undefined;
    groundingJustifications?: (string | redacted.Redacted<string>)[] | undefined;
    accuracyScore?: number | undefined;
    accuracyJustification?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyVariableReportMap = {
    [key: string]: AutomatedReasoningPolicyVariableReport | undefined;
};
export type AutomatedReasoningPolicyStatementText = string | redacted.Redacted<string>;
export type AutomatedReasoningPolicyLineNumberList = number[];
export interface AutomatedReasoningPolicyStatementLocation {
    lines: number[];
}
export interface AutomatedReasoningPolicyAtomicStatement {
    id: string;
    text: string | redacted.Redacted<string>;
    location: AutomatedReasoningPolicyStatementLocation;
}
export type AutomatedReasoningPolicyAtomicStatementList = AutomatedReasoningPolicyAtomicStatement[];
export type AutomatedReasoningPolicyLineText = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyAnnotatedLine {
    lineNumber?: number | undefined;
    lineText?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyAnnotatedContent = {
    line: AutomatedReasoningPolicyAnnotatedLine;
};
export type AutomatedReasoningPolicyAnnotatedContentList = AutomatedReasoningPolicyAnnotatedContent[];
export interface AutomatedReasoningPolicyAnnotatedChunk {
    pageNumber?: number | undefined;
    content: AutomatedReasoningPolicyAnnotatedContent[];
}
export type AutomatedReasoningPolicyAnnotatedChunkList = AutomatedReasoningPolicyAnnotatedChunk[];
export interface AutomatedReasoningPolicyReportSourceDocument {
    documentName: string | redacted.Redacted<string>;
    documentHash: string;
    documentId: string;
    atomicStatements: AutomatedReasoningPolicyAtomicStatement[];
    documentContent: AutomatedReasoningPolicyAnnotatedChunk[];
}
export type AutomatedReasoningPolicyReportSourceDocumentList = AutomatedReasoningPolicyReportSourceDocument[];
export interface AutomatedReasoningPolicyFidelityReport {
    coverageScore: number;
    accuracyScore: number;
    ruleReports: {
        [key: string]: AutomatedReasoningPolicyRuleReport | undefined;
    };
    variableReports: {
        [key: string]: AutomatedReasoningPolicyVariableReport | undefined;
    };
    documentSources: AutomatedReasoningPolicyReportSourceDocument[];
}
export type AutomatedReasoningPolicyBuildResultAssets = {
    policyDefinition: AutomatedReasoningPolicyDefinition;
    qualityReport?: undefined;
    buildLog?: undefined;
    generatedTestCases?: undefined;
    policyScenarios?: undefined;
    assetManifest?: undefined;
    document?: undefined;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport: AutomatedReasoningPolicyDefinitionQualityReport;
    buildLog?: undefined;
    generatedTestCases?: undefined;
    policyScenarios?: undefined;
    assetManifest?: undefined;
    document?: undefined;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport?: undefined;
    buildLog: AutomatedReasoningPolicyBuildLog;
    generatedTestCases?: undefined;
    policyScenarios?: undefined;
    assetManifest?: undefined;
    document?: undefined;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport?: undefined;
    buildLog?: undefined;
    generatedTestCases: AutomatedReasoningPolicyGeneratedTestCases;
    policyScenarios?: undefined;
    assetManifest?: undefined;
    document?: undefined;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport?: undefined;
    buildLog?: undefined;
    generatedTestCases?: undefined;
    policyScenarios: AutomatedReasoningPolicyScenarios;
    assetManifest?: undefined;
    document?: undefined;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport?: undefined;
    buildLog?: undefined;
    generatedTestCases?: undefined;
    policyScenarios?: undefined;
    assetManifest: AutomatedReasoningPolicyBuildResultAssetManifest;
    document?: undefined;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport?: undefined;
    buildLog?: undefined;
    generatedTestCases?: undefined;
    policyScenarios?: undefined;
    assetManifest?: undefined;
    document: AutomatedReasoningPolicySourceDocument;
    fidelityReport?: undefined;
} | {
    policyDefinition?: undefined;
    qualityReport?: undefined;
    buildLog?: undefined;
    generatedTestCases?: undefined;
    policyScenarios?: undefined;
    assetManifest?: undefined;
    document?: undefined;
    fidelityReport: AutomatedReasoningPolicyFidelityReport;
};
export interface GetAutomatedReasoningPolicyBuildWorkflowResultAssetsResponse {
    policyArn: string;
    buildWorkflowId: string;
    buildWorkflowAssets?: AutomatedReasoningPolicyBuildResultAssets | undefined;
}
export interface GetAutomatedReasoningPolicyNextScenarioRequest {
    policyArn: string;
    buildWorkflowId: string;
}
export interface GetAutomatedReasoningPolicyNextScenarioResponse {
    policyArn: string;
    scenario?: AutomatedReasoningPolicyScenario | undefined;
}
export interface GetAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    testCaseId: string;
}
export interface AutomatedReasoningPolicyTestCase {
    testCaseId: string;
    guardContent: string | redacted.Redacted<string>;
    queryContent?: string | redacted.Redacted<string> | undefined;
    expectedAggregatedFindingsResult?: AutomatedReasoningCheckResult | undefined;
    createdAt: Date;
    updatedAt: Date;
    confidenceThreshold?: number | undefined;
}
export interface GetAutomatedReasoningPolicyTestCaseResponse {
    policyArn: string;
    testCase: AutomatedReasoningPolicyTestCase;
}
export interface GetAutomatedReasoningPolicyTestResultRequest {
    policyArn: string;
    buildWorkflowId: string;
    testCaseId: string;
}
export type AutomatedReasoningPolicyTestRunStatus = "NOT_STARTED" | "SCHEDULED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type AutomatedReasoningLogicStatementContent = string | redacted.Redacted<string>;
export type AutomatedReasoningNaturalLanguageStatementContent = string | redacted.Redacted<string>;
export interface AutomatedReasoningLogicStatement {
    logic: string | redacted.Redacted<string>;
    naturalLanguage?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningLogicStatementList = AutomatedReasoningLogicStatement[];
export interface AutomatedReasoningCheckInputTextReference {
    text?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningCheckInputTextReferenceList = AutomatedReasoningCheckInputTextReference[];
export interface AutomatedReasoningCheckTranslation {
    premises?: AutomatedReasoningLogicStatement[] | undefined;
    claims: AutomatedReasoningLogicStatement[];
    untranslatedPremises?: AutomatedReasoningCheckInputTextReference[] | undefined;
    untranslatedClaims?: AutomatedReasoningCheckInputTextReference[] | undefined;
    confidence: number;
}
export interface AutomatedReasoningCheckScenario {
    statements?: AutomatedReasoningLogicStatement[] | undefined;
}
export interface AutomatedReasoningCheckRule {
    id?: string | undefined;
    policyVersionArn?: string | undefined;
}
export type AutomatedReasoningCheckRuleList = AutomatedReasoningCheckRule[];
export type AutomatedReasoningCheckLogicWarningType = "ALWAYS_TRUE" | "ALWAYS_FALSE" | (string & {});
export interface AutomatedReasoningCheckLogicWarning {
    type?: AutomatedReasoningCheckLogicWarningType | undefined;
    premises?: AutomatedReasoningLogicStatement[] | undefined;
    claims?: AutomatedReasoningLogicStatement[] | undefined;
}
export interface AutomatedReasoningCheckValidFinding {
    translation?: AutomatedReasoningCheckTranslation | undefined;
    claimsTrueScenario?: AutomatedReasoningCheckScenario | undefined;
    supportingRules?: AutomatedReasoningCheckRule[] | undefined;
    logicWarning?: AutomatedReasoningCheckLogicWarning | undefined;
}
export interface AutomatedReasoningCheckInvalidFinding {
    translation?: AutomatedReasoningCheckTranslation | undefined;
    contradictingRules?: AutomatedReasoningCheckRule[] | undefined;
    logicWarning?: AutomatedReasoningCheckLogicWarning | undefined;
}
export interface AutomatedReasoningCheckSatisfiableFinding {
    translation?: AutomatedReasoningCheckTranslation | undefined;
    claimsTrueScenario?: AutomatedReasoningCheckScenario | undefined;
    claimsFalseScenario?: AutomatedReasoningCheckScenario | undefined;
    logicWarning?: AutomatedReasoningCheckLogicWarning | undefined;
}
export interface AutomatedReasoningCheckImpossibleFinding {
    translation?: AutomatedReasoningCheckTranslation | undefined;
    contradictingRules?: AutomatedReasoningCheckRule[] | undefined;
    logicWarning?: AutomatedReasoningCheckLogicWarning | undefined;
}
export type AutomatedReasoningCheckTranslationList = AutomatedReasoningCheckTranslation[];
export interface AutomatedReasoningCheckTranslationOption {
    translations?: AutomatedReasoningCheckTranslation[] | undefined;
}
export type AutomatedReasoningCheckTranslationOptionList = AutomatedReasoningCheckTranslationOption[];
export type AutomatedReasoningCheckDifferenceScenarioList = AutomatedReasoningCheckScenario[];
export interface AutomatedReasoningCheckTranslationAmbiguousFinding {
    options?: AutomatedReasoningCheckTranslationOption[] | undefined;
    differenceScenarios?: AutomatedReasoningCheckScenario[] | undefined;
}
export interface AutomatedReasoningCheckTooComplexFinding {
}
export interface AutomatedReasoningCheckNoTranslationsFinding {
}
export type AutomatedReasoningCheckFinding = {
    valid: AutomatedReasoningCheckValidFinding;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid: AutomatedReasoningCheckInvalidFinding;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable: AutomatedReasoningCheckSatisfiableFinding;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible: AutomatedReasoningCheckImpossibleFinding;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous: AutomatedReasoningCheckTranslationAmbiguousFinding;
    tooComplex?: undefined;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex: AutomatedReasoningCheckTooComplexFinding;
    noTranslations?: undefined;
} | {
    valid?: undefined;
    invalid?: undefined;
    satisfiable?: undefined;
    impossible?: undefined;
    translationAmbiguous?: undefined;
    tooComplex?: undefined;
    noTranslations: AutomatedReasoningCheckNoTranslationsFinding;
};
export type AutomatedReasoningCheckFindingList = AutomatedReasoningCheckFinding[];
export type AutomatedReasoningPolicyTestRunResult = "PASSED" | "FAILED" | (string & {});
export interface AutomatedReasoningPolicyTestResult {
    testCase: AutomatedReasoningPolicyTestCase;
    policyArn: string;
    testRunStatus: AutomatedReasoningPolicyTestRunStatus;
    testFindings?: AutomatedReasoningCheckFinding[] | undefined;
    testRunResult?: AutomatedReasoningPolicyTestRunResult | undefined;
    aggregatedTestFindingsResult?: AutomatedReasoningCheckResult | undefined;
    updatedAt: Date;
}
export interface GetAutomatedReasoningPolicyTestResultResponse {
    testResult: AutomatedReasoningPolicyTestResult;
}
export interface GetCustomModelRequest {
    modelIdentifier: string;
}
export type MetricFloat = number;
export interface TrainingMetrics {
    trainingLoss?: number | undefined;
}
export interface ValidatorMetric {
    validationLoss?: number | undefined;
}
export type ValidationMetrics = ValidatorMetric[];
export type ModelStatus = "Active" | "Creating" | "Failed" | (string & {});
export interface GetCustomModelResponse {
    modelArn: string;
    modelName: string;
    jobName?: string | undefined;
    jobArn?: string | undefined;
    baseModelArn?: string | undefined;
    customizationType?: CustomizationType | undefined;
    modelKmsKeyArn?: string | undefined;
    hyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    trainingDataConfig?: TrainingDataConfig | undefined;
    validationDataConfig?: ValidationDataConfig | undefined;
    outputDataConfig?: OutputDataConfig | undefined;
    trainingMetrics?: TrainingMetrics | undefined;
    validationMetrics?: ValidatorMetric[] | undefined;
    creationTime: Date;
    customizationConfig?: CustomizationConfig | undefined;
    modelStatus?: ModelStatus | undefined;
    failureMessage?: string | undefined;
}
export interface GetCustomModelDeploymentRequest {
    customModelDeploymentIdentifier: string;
}
export type CustomModelDeploymentStatus = "Creating" | "Active" | "Failed" | (string & {});
export type CustomModelDeploymentUpdateStatus = "Updating" | "UpdateCompleted" | "UpdateFailed" | (string & {});
export interface CustomModelDeploymentUpdateDetails {
    modelArn: string;
    updateStatus: CustomModelDeploymentUpdateStatus;
}
export interface GetCustomModelDeploymentResponse {
    customModelDeploymentArn: string;
    modelDeploymentName: string;
    modelArn: string;
    createdAt: Date;
    status: CustomModelDeploymentStatus;
    description?: string | undefined;
    updateDetails?: CustomModelDeploymentUpdateDetails | undefined;
    failureMessage?: string | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface GetEvaluationJobRequest {
    jobIdentifier: string | redacted.Redacted<string>;
}
export type EvaluationJobType = "Human" | "Automated" | (string & {});
export type ErrorMessages = string[];
export interface GetEvaluationJobResponse {
    jobName: string;
    status: EvaluationJobStatus;
    jobArn: string;
    jobDescription?: string | redacted.Redacted<string> | undefined;
    roleArn: string;
    customerEncryptionKeyId?: string | undefined;
    jobType: EvaluationJobType;
    applicationType?: ApplicationType | undefined;
    evaluationConfig: EvaluationConfig;
    inferenceConfig: EvaluationInferenceConfig;
    outputDataConfig: EvaluationOutputDataConfig;
    creationTime: Date;
    lastModifiedTime?: Date | undefined;
    failureMessages?: string[] | undefined;
}
export type GetFoundationModelIdentifier = string;
export interface GetFoundationModelRequest {
    modelIdentifier: string;
}
export type FoundationModelArn = string;
export type BrandedName = string;
export type ModelModality = "TEXT" | "IMAGE" | "EMBEDDING" | (string & {});
export type ModelModalityList = ModelModality[];
export type ModelCustomization = "FINE_TUNING" | "CONTINUED_PRE_TRAINING" | "DISTILLATION" | (string & {});
export type ModelCustomizationList = ModelCustomization[];
export type InferenceType = "ON_DEMAND" | "PROVISIONED" | (string & {});
export type InferenceTypeList = InferenceType[];
export type FoundationModelLifecycleStatus = "ACTIVE" | "LEGACY" | (string & {});
export interface FoundationModelLifecycle {
    status: FoundationModelLifecycleStatus;
    startOfLifeTime?: Date | undefined;
    endOfLifeTime?: Date | undefined;
    legacyTime?: Date | undefined;
    publicExtendedAccessTime?: Date | undefined;
}
export interface FoundationModelDetails {
    modelArn: string;
    modelId: string;
    modelName?: string | undefined;
    providerName?: string | undefined;
    inputModalities?: ModelModality[] | undefined;
    outputModalities?: ModelModality[] | undefined;
    responseStreamingSupported?: boolean | undefined;
    customizationsSupported?: ModelCustomization[] | undefined;
    inferenceTypesSupported?: InferenceType[] | undefined;
    modelLifecycle?: FoundationModelLifecycle | undefined;
}
export interface GetFoundationModelResponse {
    modelDetails?: FoundationModelDetails | undefined;
}
export interface GetFoundationModelAvailabilityRequest {
    modelId: string;
}
export type AgreementStatus = "AVAILABLE" | "PENDING" | "NOT_AVAILABLE" | "ERROR" | (string & {});
export interface AgreementAvailability {
    status: AgreementStatus;
    errorMessage?: string | undefined;
}
export type AuthorizationStatus = "AUTHORIZED" | "NOT_AUTHORIZED" | (string & {});
export type EntitlementAvailability = "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export type RegionAvailability = "AVAILABLE" | "NOT_AVAILABLE" | (string & {});
export interface GetFoundationModelAvailabilityResponse {
    modelId: string;
    agreementAvailability: AgreementAvailability;
    authorizationStatus: AuthorizationStatus;
    entitlementAvailability: EntitlementAvailability;
    regionAvailability: RegionAvailability;
}
export type GuardrailVersion = string;
export interface GetGuardrailRequest {
    guardrailIdentifier: string;
    guardrailVersion?: string | undefined;
}
export type GuardrailStatus = "CREATING" | "UPDATING" | "VERSIONING" | "READY" | "FAILED" | "DELETING" | (string & {});
export interface GuardrailTopic {
    name: string | redacted.Redacted<string>;
    definition: string | redacted.Redacted<string>;
    examples?: (string | redacted.Redacted<string>)[] | undefined;
    type?: GuardrailTopicType | undefined;
    inputAction?: GuardrailTopicAction | undefined;
    outputAction?: GuardrailTopicAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailTopics = GuardrailTopic[];
export interface GuardrailTopicsTier {
    tierName: GuardrailTopicsTierName;
}
export interface GuardrailTopicPolicy {
    topics: GuardrailTopic[];
    tier?: GuardrailTopicsTier | undefined;
}
export interface GuardrailContentFilter {
    type: GuardrailContentFilterType;
    inputStrength: GuardrailFilterStrength;
    outputStrength: GuardrailFilterStrength;
    inputModalities?: GuardrailModality[] | undefined;
    outputModalities?: GuardrailModality[] | undefined;
    inputAction?: GuardrailContentFilterAction | undefined;
    outputAction?: GuardrailContentFilterAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailContentFilters = GuardrailContentFilter[];
export interface GuardrailContentFiltersTier {
    tierName: GuardrailContentFiltersTierName;
}
export interface GuardrailContentPolicy {
    filters?: GuardrailContentFilter[] | undefined;
    tier?: GuardrailContentFiltersTier | undefined;
}
export interface GuardrailWord {
    text: string;
    inputAction?: GuardrailWordAction | undefined;
    outputAction?: GuardrailWordAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailWords = GuardrailWord[];
export interface GuardrailManagedWords {
    type: GuardrailManagedWordsType;
    inputAction?: GuardrailWordAction | undefined;
    outputAction?: GuardrailWordAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailManagedWordLists = GuardrailManagedWords[];
export interface GuardrailWordPolicy {
    words?: GuardrailWord[] | undefined;
    managedWordLists?: GuardrailManagedWords[] | undefined;
}
export interface GuardrailPiiEntity {
    type: GuardrailPiiEntityType;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction | undefined;
    outputAction?: GuardrailSensitiveInformationAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailPiiEntities = GuardrailPiiEntity[];
export interface GuardrailRegex {
    name: string;
    description?: string | undefined;
    pattern: string;
    action: GuardrailSensitiveInformationAction;
    inputAction?: GuardrailSensitiveInformationAction | undefined;
    outputAction?: GuardrailSensitiveInformationAction | undefined;
    inputEnabled?: boolean | undefined;
    outputEnabled?: boolean | undefined;
}
export type GuardrailRegexes = GuardrailRegex[];
export interface GuardrailSensitiveInformationPolicy {
    piiEntities?: GuardrailPiiEntity[] | undefined;
    regexes?: GuardrailRegex[] | undefined;
}
export interface GuardrailContextualGroundingFilter {
    type: GuardrailContextualGroundingFilterType;
    threshold: number;
    action?: GuardrailContextualGroundingAction | undefined;
    enabled?: boolean | undefined;
}
export type GuardrailContextualGroundingFilters = GuardrailContextualGroundingFilter[];
export interface GuardrailContextualGroundingTier {
    tierName: GuardrailContextualGroundingTierName;
}
export interface GuardrailContextualGroundingPolicy {
    filters: GuardrailContextualGroundingFilter[];
    tier?: GuardrailContextualGroundingTier | undefined;
}
export interface GuardrailAutomatedReasoningPolicy {
    policies: string[];
    confidenceThreshold?: number | undefined;
}
export type GuardrailCrossRegionGuardrailProfileId = string;
export type GuardrailCrossRegionGuardrailProfileArn = string;
export interface GuardrailCrossRegionDetails {
    guardrailProfileId?: string | undefined;
    guardrailProfileArn?: string | undefined;
}
export type GuardrailStatusReason = string | redacted.Redacted<string>;
export type GuardrailStatusReasons = (string | redacted.Redacted<string>)[];
export type GuardrailFailureRecommendation = string | redacted.Redacted<string>;
export type GuardrailFailureRecommendations = (string | redacted.Redacted<string>)[];
export interface GetGuardrailResponse {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    guardrailId: string;
    guardrailArn: string;
    version: string;
    status: GuardrailStatus;
    topicPolicy?: GuardrailTopicPolicy | undefined;
    contentPolicy?: GuardrailContentPolicy | undefined;
    wordPolicy?: GuardrailWordPolicy | undefined;
    sensitiveInformationPolicy?: GuardrailSensitiveInformationPolicy | undefined;
    contextualGroundingPolicy?: GuardrailContextualGroundingPolicy | undefined;
    automatedReasoningPolicy?: GuardrailAutomatedReasoningPolicy | undefined;
    crossRegionDetails?: GuardrailCrossRegionDetails | undefined;
    createdAt: Date;
    updatedAt: Date;
    statusReasons?: (string | redacted.Redacted<string>)[] | undefined;
    failureRecommendations?: (string | redacted.Redacted<string>)[] | undefined;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    kmsKeyArn?: string | undefined;
}
export interface GetImportedModelRequest {
    modelIdentifier: string;
}
export type ImportedModelArn = string;
export type InstructSupported = boolean;
export type CustomModelUnitsVersion = string;
export interface CustomModelUnits {
    customModelUnitsPerModelCopy?: number | undefined;
    customModelUnitsVersion?: string | undefined;
}
export interface GetImportedModelResponse {
    modelArn?: string | undefined;
    modelName?: string | undefined;
    jobName?: string | undefined;
    jobArn?: string | undefined;
    modelDataSource?: ModelDataSource | undefined;
    creationTime?: Date | undefined;
    modelArchitecture?: string | undefined;
    modelKmsKeyArn?: string | undefined;
    instructSupported?: boolean | undefined;
    customModelUnits?: CustomModelUnits | undefined;
}
export interface GetInferenceProfileRequest {
    inferenceProfileIdentifier: string;
}
export interface InferenceProfileModel {
    modelArn?: string | undefined;
}
export type InferenceProfileModels = InferenceProfileModel[];
export type InferenceProfileId = string;
export type InferenceProfileType = "SYSTEM_DEFINED" | "APPLICATION" | (string & {});
export interface GetInferenceProfileResponse {
    inferenceProfileName: string;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    inferenceProfileArn: string;
    models: InferenceProfileModel[];
    inferenceProfileId: string;
    status: InferenceProfileStatus;
    type: InferenceProfileType;
}
export interface GetMarketplaceModelEndpointRequest {
    endpointArn: string;
}
export interface GetMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint?: MarketplaceModelEndpoint | undefined;
}
export interface GetModelCopyJobRequest {
    jobArn: string;
}
export type ModelCopyJobStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface GetModelCopyJobResponse {
    jobArn: string;
    status: ModelCopyJobStatus;
    creationTime: Date;
    targetModelArn: string;
    targetModelName?: string | undefined;
    sourceAccountId: string;
    sourceModelArn: string;
    targetModelKmsKeyArn?: string | undefined;
    targetModelTags?: Tag[] | undefined;
    failureMessage?: string | undefined;
    sourceModelName?: string | undefined;
}
export type ModelCustomizationJobIdentifier = string;
export interface GetModelCustomizationJobRequest {
    jobIdentifier: string;
}
export type ModelCustomizationJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export type JobStatusDetails = "InProgress" | "Completed" | "Stopping" | "Stopped" | "Failed" | "NotStarted" | (string & {});
export interface ValidationDetails {
    status?: JobStatusDetails | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
}
export interface DataProcessingDetails {
    status?: JobStatusDetails | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
}
export interface TrainingDetails {
    status?: JobStatusDetails | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
}
export interface StatusDetails {
    validationDetails?: ValidationDetails | undefined;
    dataProcessingDetails?: DataProcessingDetails | undefined;
    trainingDetails?: TrainingDetails | undefined;
}
export interface GetModelCustomizationJobResponse {
    jobArn: string;
    jobName: string;
    outputModelName: string;
    outputModelArn?: string | undefined;
    clientRequestToken?: string | undefined;
    roleArn: string;
    status?: ModelCustomizationJobStatus | undefined;
    statusDetails?: StatusDetails | undefined;
    failureMessage?: string | undefined;
    creationTime: Date;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    baseModelArn: string;
    hyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    trainingDataConfig: TrainingDataConfig;
    validationDataConfig: ValidationDataConfig;
    outputDataConfig: OutputDataConfig;
    customizationType?: CustomizationType | undefined;
    outputModelKmsKeyArn?: string | undefined;
    trainingMetrics?: TrainingMetrics | undefined;
    validationMetrics?: ValidatorMetric[] | undefined;
    vpcConfig?: VpcConfig | undefined;
    customizationConfig?: CustomizationConfig | undefined;
}
export type ModelImportJobIdentifier = string;
export interface GetModelImportJobRequest {
    jobIdentifier: string;
}
export type ModelImportJobStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface GetModelImportJobResponse {
    jobArn?: string | undefined;
    jobName?: string | undefined;
    importedModelName?: string | undefined;
    importedModelArn?: string | undefined;
    roleArn?: string | undefined;
    modelDataSource?: ModelDataSource | undefined;
    status?: ModelImportJobStatus | undefined;
    failureMessage?: string | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    vpcConfig?: VpcConfig | undefined;
    importedModelKmsKeyArn?: string | undefined;
}
export type ModelInvocationJobIdentifier = string;
export interface GetModelInvocationJobRequest {
    jobIdentifier: string;
}
export type ModelInvocationJobStatus = "Submitted" | "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | "PartiallyCompleted" | "Expired" | "Validating" | "Scheduled" | (string & {});
export type Message = string | redacted.Redacted<string>;
export type NonNegativeLong = number;
export interface GetModelInvocationJobResponse {
    jobArn: string;
    jobName?: string | undefined;
    modelId: string;
    clientRequestToken?: string | undefined;
    roleArn: string;
    status?: ModelInvocationJobStatus | undefined;
    message?: string | redacted.Redacted<string> | undefined;
    submitTime: Date;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    inputDataConfig: ModelInvocationJobInputDataConfig;
    outputDataConfig: ModelInvocationJobOutputDataConfig;
    vpcConfig?: VpcConfig | undefined;
    timeoutDurationInHours?: number | undefined;
    jobExpirationTime?: Date | undefined;
    modelInvocationType?: ModelInvocationType | undefined;
    totalRecordCount?: number | undefined;
    processedRecordCount?: number | undefined;
    successRecordCount?: number | undefined;
    errorRecordCount?: number | undefined;
}
export interface GetModelInvocationLoggingConfigurationRequest {
}
export type LogGroupName = string;
export type BucketName = string;
export type KeyPrefix = string;
export interface S3Config {
    bucketName: string;
    keyPrefix?: string | undefined;
}
export interface CloudWatchConfig {
    logGroupName: string;
    roleArn: string;
    largeDataDeliveryS3Config?: S3Config | undefined;
}
export interface LoggingConfig {
    cloudWatchConfig?: CloudWatchConfig | undefined;
    s3Config?: S3Config | undefined;
    textDataDeliveryEnabled?: boolean | undefined;
    imageDataDeliveryEnabled?: boolean | undefined;
    embeddingDataDeliveryEnabled?: boolean | undefined;
    videoDataDeliveryEnabled?: boolean | undefined;
    audioDataDeliveryEnabled?: boolean | undefined;
}
export interface GetModelInvocationLoggingConfigurationResponse {
    loggingConfig?: LoggingConfig | undefined;
}
export interface GetPromptRouterRequest {
    promptRouterArn: string;
}
export type PromptRouterStatus = "AVAILABLE" | (string & {});
export type PromptRouterType = "custom" | "default" | (string & {});
export interface GetPromptRouterResponse {
    promptRouterName: string;
    routingCriteria: RoutingCriteria;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    promptRouterArn: string;
    models: (PromptRouterTargetModel & {
        modelArn: PromptRouterTargetModelArn;
    })[];
    fallbackModel: PromptRouterTargetModel & {
        modelArn: PromptRouterTargetModelArn;
    };
    status: PromptRouterStatus;
    type: PromptRouterType;
}
export interface GetProvisionedModelThroughputRequest {
    provisionedModelId: string;
}
export type ProvisionedModelStatus = "Creating" | "InService" | "Updating" | "Failed" | (string & {});
export interface GetProvisionedModelThroughputResponse {
    modelUnits: number;
    desiredModelUnits: number;
    provisionedModelName: string;
    provisionedModelArn: string;
    modelArn: string;
    desiredModelArn: string;
    foundationModelArn: string;
    status: ProvisionedModelStatus;
    creationTime: Date;
    lastModifiedTime: Date;
    failureMessage?: string | undefined;
    commitmentDuration?: CommitmentDuration | undefined;
    commitmentExpirationTime?: Date | undefined;
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export type ResourcePolicyDocument = string;
export interface GetResourcePolicyResponse {
    resourcePolicy?: string | undefined;
}
export interface GetUseCaseForModelAccessRequest {
}
export type AcknowledgementFormDataBody = Uint8Array;
export interface GetUseCaseForModelAccessResponse {
    formData: Uint8Array;
}
export type MaxResults = number;
export type PaginationToken = string;
export type SortJobsBy = "CreationTime" | (string & {});
export type SortOrder = "Ascending" | "Descending" | (string & {});
export interface ListAdvancedPromptOptimizationJobsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortJobsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface AdvancedPromptOptimizationJobSummary {
    jobArn: string;
    jobName: string;
    jobStatus: AdvancedPromptOptimizationJobStatus;
    creationTime: Date;
    lastModifiedTime?: Date | undefined;
}
export type AdvancedPromptOptimizationJobSummaries = AdvancedPromptOptimizationJobSummary[];
export interface ListAdvancedPromptOptimizationJobsResponse {
    jobSummaries?: AdvancedPromptOptimizationJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAutomatedReasoningPoliciesRequest {
    policyArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AutomatedReasoningPolicySummary {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    version: string;
    policyId: string;
    createdAt: Date;
    updatedAt: Date;
}
export type AutomatedReasoningPolicySummaries = AutomatedReasoningPolicySummary[];
export interface ListAutomatedReasoningPoliciesResponse {
    automatedReasoningPolicySummaries: AutomatedReasoningPolicySummary[];
    nextToken?: string | undefined;
}
export interface ListAutomatedReasoningPolicyBuildWorkflowsRequest {
    policyArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AutomatedReasoningPolicyBuildWorkflowSummary {
    policyArn: string;
    buildWorkflowId: string;
    status: AutomatedReasoningPolicyBuildWorkflowStatus;
    buildWorkflowType: AutomatedReasoningPolicyBuildWorkflowType;
    createdAt: Date;
    updatedAt: Date;
}
export type AutomatedReasoningPolicyBuildWorkflowSummaries = AutomatedReasoningPolicyBuildWorkflowSummary[];
export interface ListAutomatedReasoningPolicyBuildWorkflowsResponse {
    automatedReasoningPolicyBuildWorkflowSummaries: AutomatedReasoningPolicyBuildWorkflowSummary[];
    nextToken?: string | undefined;
}
export interface ListAutomatedReasoningPolicyTestCasesRequest {
    policyArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type AutomatedReasoningPolicyTestCaseList = AutomatedReasoningPolicyTestCase[];
export interface ListAutomatedReasoningPolicyTestCasesResponse {
    testCases: AutomatedReasoningPolicyTestCase[];
    nextToken?: string | undefined;
}
export interface ListAutomatedReasoningPolicyTestResultsRequest {
    policyArn: string;
    buildWorkflowId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type AutomatedReasoningPolicyTestList = AutomatedReasoningPolicyTestResult[];
export interface ListAutomatedReasoningPolicyTestResultsResponse {
    testResults: AutomatedReasoningPolicyTestResult[];
    nextToken?: string | undefined;
}
export type SortModelsBy = "CreationTime" | (string & {});
export interface ListCustomModelDeploymentsRequest {
    createdBefore?: Date | undefined;
    createdAfter?: Date | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortModelsBy | undefined;
    sortOrder?: SortOrder | undefined;
    statusEquals?: CustomModelDeploymentStatus | undefined;
    modelArnEquals?: string | undefined;
}
export interface CustomModelDeploymentSummary {
    customModelDeploymentArn: string;
    customModelDeploymentName: string;
    modelArn: string;
    createdAt: Date;
    status: CustomModelDeploymentStatus;
    lastUpdatedAt?: Date | undefined;
    failureMessage?: string | undefined;
}
export type CustomModelDeploymentSummaryList = CustomModelDeploymentSummary[];
export interface ListCustomModelDeploymentsResponse {
    nextToken?: string | undefined;
    modelDeploymentSummaries?: CustomModelDeploymentSummary[] | undefined;
}
export interface ListCustomModelsRequest {
    creationTimeBefore?: Date | undefined;
    creationTimeAfter?: Date | undefined;
    nameContains?: string | undefined;
    baseModelArnEquals?: string | undefined;
    foundationModelArnEquals?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortModelsBy | undefined;
    sortOrder?: SortOrder | undefined;
    isOwned?: boolean | undefined;
    modelStatus?: ModelStatus | undefined;
}
export type ModelName = string;
export interface CustomModelSummary {
    modelArn: string;
    modelName: string;
    creationTime: Date;
    baseModelArn: string;
    baseModelName: string;
    customizationType?: CustomizationType | undefined;
    ownerAccountId?: string | undefined;
    modelStatus?: ModelStatus | undefined;
}
export type CustomModelSummaryList = CustomModelSummary[];
export interface ListCustomModelsResponse {
    nextToken?: string | undefined;
    modelSummaries?: CustomModelSummary[] | undefined;
}
export interface ListEnforcedGuardrailsConfigurationRequest {
    nextToken?: string | undefined;
}
export type InputTags = "HONOR" | "IGNORE" | (string & {});
export type SelectiveGuardingMode = "SELECTIVE" | "COMPREHENSIVE" | (string & {});
export interface SelectiveContentGuarding {
    system?: SelectiveGuardingMode | undefined;
    messages?: SelectiveGuardingMode | undefined;
}
export type ConfigurationOwner = string;
export type IncludedModelId = string;
export type IncludedModelsList = string[];
export type ExcludedModelId = string;
export type ExcludedModelsList = string[];
export interface ModelEnforcement {
    includedModels: string[];
    excludedModels: string[];
}
export interface AccountEnforcedGuardrailOutputConfiguration {
    configId?: string | undefined;
    guardrailArn?: string | undefined;
    guardrailId?: string | undefined;
    inputTags?: InputTags | undefined;
    selectiveContentGuarding?: SelectiveContentGuarding | undefined;
    guardrailVersion?: string | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
    owner?: string | undefined;
    modelEnforcement?: ModelEnforcement | undefined;
}
export type AccountEnforcedGuardrailsOutputConfiguration = AccountEnforcedGuardrailOutputConfiguration[];
export interface ListEnforcedGuardrailsConfigurationResponse {
    guardrailsConfig: AccountEnforcedGuardrailOutputConfiguration[];
    nextToken?: string | undefined;
}
export interface ListEvaluationJobsRequest {
    creationTimeAfter?: Date | undefined;
    creationTimeBefore?: Date | undefined;
    statusEquals?: EvaluationJobStatus | undefined;
    applicationTypeEquals?: ApplicationType | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortJobsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export type EvaluationTaskTypes = EvaluationTaskType[];
export type EvaluationBedrockModelIdentifiers = string[];
export type EvaluationBedrockKnowledgeBaseIdentifiers = string[];
export type EvaluatorModelIdentifiers = string[];
export type EvaluationPrecomputedInferenceSourceIdentifiers = string[];
export interface EvaluationModelConfigSummary {
    bedrockModelIdentifiers?: string[] | undefined;
    precomputedInferenceSourceIdentifiers?: string[] | undefined;
}
export type EvaluationPrecomputedRagSourceIdentifiers = string[];
export interface EvaluationRagConfigSummary {
    bedrockKnowledgeBaseIdentifiers?: string[] | undefined;
    precomputedRagSourceIdentifiers?: string[] | undefined;
}
export interface EvaluationInferenceConfigSummary {
    modelConfigSummary?: EvaluationModelConfigSummary | undefined;
    ragConfigSummary?: EvaluationRagConfigSummary | undefined;
}
export interface EvaluationSummary {
    jobArn: string;
    jobName: string;
    status: EvaluationJobStatus;
    creationTime: Date;
    jobType: EvaluationJobType;
    evaluationTaskTypes: EvaluationTaskType[];
    modelIdentifiers?: string[] | undefined;
    ragIdentifiers?: string[] | undefined;
    evaluatorModelIdentifiers?: string[] | undefined;
    customMetricsEvaluatorModelIdentifiers?: string[] | undefined;
    inferenceConfigSummary?: EvaluationInferenceConfigSummary | undefined;
    applicationType?: ApplicationType | undefined;
}
export type EvaluationSummaries = EvaluationSummary[];
export interface ListEvaluationJobsResponse {
    nextToken?: string | undefined;
    jobSummaries?: EvaluationSummary[] | undefined;
}
export type OfferType = "ALL" | "PUBLIC" | (string & {});
export interface ListFoundationModelAgreementOffersRequest {
    modelId: string;
    offerType?: OfferType | undefined;
}
export type OfferId = string;
export interface DimensionalPriceRate {
    dimension?: string | undefined;
    price?: string | undefined;
    description?: string | undefined;
    unit?: string | undefined;
}
export type RateCard = DimensionalPriceRate[];
export interface PricingTerm {
    rateCard: DimensionalPriceRate[];
}
export interface LegalTerm {
    url?: string | undefined;
}
export interface SupportTerm {
    refundPolicyDescription?: string | undefined;
}
export interface ValidityTerm {
    agreementDuration?: string | undefined;
}
export interface TermDetails {
    usageBasedPricingTerm: PricingTerm;
    legalTerm: LegalTerm;
    supportTerm: SupportTerm;
    validityTerm?: ValidityTerm | undefined;
}
export interface Offer {
    offerId?: string | undefined;
    offerToken: string;
    termDetails: TermDetails;
}
export type Offers = Offer[];
export interface ListFoundationModelAgreementOffersResponse {
    modelId: string;
    offers: Offer[];
}
export type Provider = string;
export interface ListFoundationModelsRequest {
    byProvider?: string | undefined;
    byCustomizationType?: ModelCustomization | undefined;
    byOutputModality?: ModelModality | undefined;
    byInferenceType?: InferenceType | undefined;
}
export interface FoundationModelSummary {
    modelArn: string;
    modelId: string;
    modelName?: string | undefined;
    providerName?: string | undefined;
    inputModalities?: ModelModality[] | undefined;
    outputModalities?: ModelModality[] | undefined;
    responseStreamingSupported?: boolean | undefined;
    customizationsSupported?: ModelCustomization[] | undefined;
    inferenceTypesSupported?: InferenceType[] | undefined;
    modelLifecycle?: FoundationModelLifecycle | undefined;
}
export type FoundationModelSummaryList = FoundationModelSummary[];
export interface ListFoundationModelsResponse {
    modelSummaries?: FoundationModelSummary[] | undefined;
}
export interface ListGuardrailsRequest {
    guardrailIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface GuardrailSummary {
    id: string;
    arn: string;
    status: GuardrailStatus;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    version: string;
    createdAt: Date;
    updatedAt: Date;
    crossRegionDetails?: GuardrailCrossRegionDetails | undefined;
}
export type GuardrailSummaries = GuardrailSummary[];
export interface ListGuardrailsResponse {
    guardrails: GuardrailSummary[];
    nextToken?: string | undefined;
}
export interface ListImportedModelsRequest {
    creationTimeBefore?: Date | undefined;
    creationTimeAfter?: Date | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortModelsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export type ModelArchitecture = string;
export interface ImportedModelSummary {
    modelArn: string;
    modelName: string;
    creationTime: Date;
    instructSupported?: boolean | undefined;
    modelArchitecture?: string | undefined;
}
export type ImportedModelSummaryList = ImportedModelSummary[];
export interface ListImportedModelsResponse {
    nextToken?: string | undefined;
    modelSummaries?: ImportedModelSummary[] | undefined;
}
export interface ListInferenceProfilesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    typeEquals?: InferenceProfileType | undefined;
}
export interface InferenceProfileSummary {
    inferenceProfileName: string;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    inferenceProfileArn: string;
    models: InferenceProfileModel[];
    inferenceProfileId: string;
    status: InferenceProfileStatus;
    type: InferenceProfileType;
}
export type InferenceProfileSummaries = InferenceProfileSummary[];
export interface ListInferenceProfilesResponse {
    inferenceProfileSummaries?: InferenceProfileSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMarketplaceModelEndpointsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    modelSourceEquals?: string | undefined;
}
export interface MarketplaceModelEndpointSummary {
    endpointArn: string;
    modelSourceIdentifier: string;
    status?: Status | undefined;
    statusMessage?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type MarketplaceModelEndpointSummaries = MarketplaceModelEndpointSummary[];
export interface ListMarketplaceModelEndpointsResponse {
    marketplaceModelEndpoints?: MarketplaceModelEndpointSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListModelCopyJobsRequest {
    creationTimeAfter?: Date | undefined;
    creationTimeBefore?: Date | undefined;
    statusEquals?: ModelCopyJobStatus | undefined;
    sourceAccountEquals?: string | undefined;
    sourceModelArnEquals?: string | undefined;
    targetModelNameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortJobsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface ModelCopyJobSummary {
    jobArn: string;
    status: ModelCopyJobStatus;
    creationTime: Date;
    targetModelArn: string;
    targetModelName?: string | undefined;
    sourceAccountId: string;
    sourceModelArn: string;
    targetModelKmsKeyArn?: string | undefined;
    targetModelTags?: Tag[] | undefined;
    failureMessage?: string | undefined;
    sourceModelName?: string | undefined;
}
export type ModelCopyJobSummaries = ModelCopyJobSummary[];
export interface ListModelCopyJobsResponse {
    nextToken?: string | undefined;
    modelCopyJobSummaries?: ModelCopyJobSummary[] | undefined;
}
export type FineTuningJobStatus = "InProgress" | "Completed" | "Failed" | "Stopping" | "Stopped" | (string & {});
export interface ListModelCustomizationJobsRequest {
    creationTimeAfter?: Date | undefined;
    creationTimeBefore?: Date | undefined;
    statusEquals?: FineTuningJobStatus | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortJobsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface ModelCustomizationJobSummary {
    jobArn: string;
    baseModelArn: string;
    jobName: string;
    status: ModelCustomizationJobStatus;
    statusDetails?: StatusDetails | undefined;
    lastModifiedTime?: Date | undefined;
    creationTime: Date;
    endTime?: Date | undefined;
    customModelArn?: string | undefined;
    customModelName?: string | undefined;
    customizationType?: CustomizationType | undefined;
}
export type ModelCustomizationJobSummaries = ModelCustomizationJobSummary[];
export interface ListModelCustomizationJobsResponse {
    nextToken?: string | undefined;
    modelCustomizationJobSummaries?: ModelCustomizationJobSummary[] | undefined;
}
export interface ListModelImportJobsRequest {
    creationTimeAfter?: Date | undefined;
    creationTimeBefore?: Date | undefined;
    statusEquals?: ModelImportJobStatus | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortJobsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface ModelImportJobSummary {
    jobArn: string;
    jobName: string;
    status: ModelImportJobStatus;
    lastModifiedTime?: Date | undefined;
    creationTime: Date;
    endTime?: Date | undefined;
    importedModelArn?: string | undefined;
    importedModelName?: string | undefined;
}
export type ModelImportJobSummaries = ModelImportJobSummary[];
export interface ListModelImportJobsResponse {
    nextToken?: string | undefined;
    modelImportJobSummaries?: ModelImportJobSummary[] | undefined;
}
export interface ListModelInvocationJobsRequest {
    submitTimeAfter?: Date | undefined;
    submitTimeBefore?: Date | undefined;
    statusEquals?: ModelInvocationJobStatus | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortJobsBy | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface ModelInvocationJobSummary {
    jobArn: string;
    jobName: string;
    modelId: string;
    clientRequestToken?: string | undefined;
    roleArn: string;
    status?: ModelInvocationJobStatus | undefined;
    message?: string | redacted.Redacted<string> | undefined;
    submitTime: Date;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    inputDataConfig: ModelInvocationJobInputDataConfig;
    outputDataConfig: ModelInvocationJobOutputDataConfig;
    vpcConfig?: VpcConfig | undefined;
    timeoutDurationInHours?: number | undefined;
    jobExpirationTime?: Date | undefined;
    modelInvocationType?: ModelInvocationType | undefined;
    totalRecordCount?: number | undefined;
    processedRecordCount?: number | undefined;
    successRecordCount?: number | undefined;
    errorRecordCount?: number | undefined;
}
export type ModelInvocationJobSummaries = ModelInvocationJobSummary[];
export interface ListModelInvocationJobsResponse {
    nextToken?: string | undefined;
    invocationJobSummaries?: ModelInvocationJobSummary[] | undefined;
}
export interface ListPromptRoutersRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    type?: PromptRouterType | undefined;
}
export interface PromptRouterSummary {
    promptRouterName: string;
    routingCriteria: RoutingCriteria;
    description?: string | redacted.Redacted<string> | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    promptRouterArn: string;
    models: PromptRouterTargetModel[];
    fallbackModel: PromptRouterTargetModel;
    status: PromptRouterStatus;
    type: PromptRouterType;
}
export type PromptRouterSummaries = PromptRouterSummary[];
export interface ListPromptRoutersResponse {
    promptRouterSummaries?: (PromptRouterSummary & {
        models: (PromptRouterTargetModel & {
            modelArn: PromptRouterTargetModelArn;
        })[];
        fallbackModel: PromptRouterTargetModel & {
            modelArn: PromptRouterTargetModelArn;
        };
    })[] | undefined;
    nextToken?: string | undefined;
}
export type SortByProvisionedModels = "CreationTime" | (string & {});
export interface ListProvisionedModelThroughputsRequest {
    creationTimeAfter?: Date | undefined;
    creationTimeBefore?: Date | undefined;
    statusEquals?: ProvisionedModelStatus | undefined;
    modelArnEquals?: string | undefined;
    nameContains?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: SortByProvisionedModels | undefined;
    sortOrder?: SortOrder | undefined;
}
export interface ProvisionedModelSummary {
    provisionedModelName: string;
    provisionedModelArn: string;
    modelArn: string;
    desiredModelArn: string;
    foundationModelArn: string;
    modelUnits: number;
    desiredModelUnits: number;
    status: ProvisionedModelStatus;
    commitmentDuration?: CommitmentDuration | undefined;
    commitmentExpirationTime?: Date | undefined;
    creationTime: Date;
    lastModifiedTime: Date;
}
export type ProvisionedModelSummaries = ProvisionedModelSummary[];
export interface ListProvisionedModelThroughputsResponse {
    nextToken?: string | undefined;
    provisionedModelSummaries?: ProvisionedModelSummary[] | undefined;
}
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface PutAccountDataRetentionRequest {
    mode: DataRetentionMode;
}
export interface PutAccountDataRetentionResponse {
    mode: DataRetentionMode;
    updatedAt?: Date | undefined;
}
export interface AccountEnforcedGuardrailInferenceInputConfiguration {
    guardrailIdentifier: string;
    guardrailVersion: string;
    selectiveContentGuarding?: SelectiveContentGuarding | undefined;
    modelEnforcement?: ModelEnforcement | undefined;
}
export interface PutEnforcedGuardrailConfigurationRequest {
    configId?: string | undefined;
    guardrailInferenceConfig: AccountEnforcedGuardrailInferenceInputConfiguration;
}
export interface PutEnforcedGuardrailConfigurationResponse {
    configId?: string | undefined;
    updatedAt?: Date | undefined;
    updatedBy?: string | undefined;
}
export interface PutModelInvocationLoggingConfigurationRequest {
    loggingConfig: LoggingConfig;
}
export interface PutModelInvocationLoggingConfigurationResponse {
}
export interface PutResourcePolicyRequest {
    resourceArn: string;
    resourcePolicy: string;
}
export interface PutResourcePolicyResponse {
    resourceArn?: string | undefined;
}
export interface PutUseCaseForModelAccessRequest {
    formData: Uint8Array;
}
export interface PutUseCaseForModelAccessResponse {
}
export interface RegisterMarketplaceModelEndpointRequest {
    endpointIdentifier: string;
    modelSourceIdentifier: string;
}
export interface RegisterMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint: MarketplaceModelEndpoint;
}
export interface AutomatedReasoningPolicyBuildWorkflowDocument {
    document: Uint8Array | redacted.Redacted<Uint8Array>;
    documentContentType: AutomatedReasoningPolicyBuildDocumentContentType;
    documentName: string | redacted.Redacted<string>;
    documentDescription?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyBuildWorkflowDocumentList = AutomatedReasoningPolicyBuildWorkflowDocument[];
export interface AutomatedReasoningPolicyBuildWorkflowRepairContent {
    annotations: AutomatedReasoningPolicyAnnotation[];
}
export type AutomatedReasoningPolicyGenerateFidelityReportDocumentList = AutomatedReasoningPolicyBuildWorkflowDocument[];
export type AutomatedReasoningPolicyGenerateFidelityReportContent = {
    documents: AutomatedReasoningPolicyBuildWorkflowDocument[];
};
export type AutomatedReasoningPolicyIterativeRefinementDocumentList = AutomatedReasoningPolicyBuildWorkflowDocument[];
export type AutomatedReasoningPolicyBuildFeedback = string | redacted.Redacted<string>;
export interface AutomatedReasoningPolicyIterativeRefinementContent {
    documents: AutomatedReasoningPolicyBuildWorkflowDocument[];
    feedback?: string | redacted.Redacted<string> | undefined;
}
export type AutomatedReasoningPolicyWorkflowTypeContent = {
    documents: AutomatedReasoningPolicyBuildWorkflowDocument[];
    policyRepairAssets?: undefined;
    generateFidelityReportContent?: undefined;
    iterativeRefinementContent?: undefined;
} | {
    documents?: undefined;
    policyRepairAssets: AutomatedReasoningPolicyBuildWorkflowRepairContent;
    generateFidelityReportContent?: undefined;
    iterativeRefinementContent?: undefined;
} | {
    documents?: undefined;
    policyRepairAssets?: undefined;
    generateFidelityReportContent: AutomatedReasoningPolicyGenerateFidelityReportContent;
    iterativeRefinementContent?: undefined;
} | {
    documents?: undefined;
    policyRepairAssets?: undefined;
    generateFidelityReportContent?: undefined;
    iterativeRefinementContent: AutomatedReasoningPolicyIterativeRefinementContent;
};
export interface AutomatedReasoningPolicyBuildWorkflowSource {
    policyDefinition?: AutomatedReasoningPolicyDefinition | undefined;
    workflowContent?: AutomatedReasoningPolicyWorkflowTypeContent | undefined;
}
export interface StartAutomatedReasoningPolicyBuildWorkflowRequest {
    policyArn: string;
    buildWorkflowType: AutomatedReasoningPolicyBuildWorkflowType;
    clientRequestToken?: string | undefined;
    sourceContent: AutomatedReasoningPolicyBuildWorkflowSource;
}
export interface StartAutomatedReasoningPolicyBuildWorkflowResponse {
    policyArn: string;
    buildWorkflowId: string;
}
export type AutomatedReasoningPolicyTestCaseIdList = string[];
export interface StartAutomatedReasoningPolicyTestWorkflowRequest {
    policyArn: string;
    buildWorkflowId: string;
    testCaseIds?: string[] | undefined;
    clientRequestToken?: string | undefined;
}
export interface StartAutomatedReasoningPolicyTestWorkflowResponse {
    policyArn: string;
}
export interface StopAdvancedPromptOptimizationJobRequest {
    jobIdentifier: string;
}
export interface StopAdvancedPromptOptimizationJobResponse {
}
export interface StopEvaluationJobRequest {
    jobIdentifier: string | redacted.Redacted<string>;
}
export interface StopEvaluationJobResponse {
}
export interface StopModelCustomizationJobRequest {
    jobIdentifier: string;
}
export interface StopModelCustomizationJobResponse {
}
export interface StopModelInvocationJobRequest {
    jobIdentifier: string;
}
export interface StopModelInvocationJobResponse {
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAutomatedReasoningPolicyRequest {
    policyArn: string;
    policyDefinition: AutomatedReasoningPolicyDefinition;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateAutomatedReasoningPolicyResponse {
    policyArn: string;
    name: string | redacted.Redacted<string>;
    definitionHash: string;
    updatedAt: Date;
}
export interface UpdateAutomatedReasoningPolicyAnnotationsRequest {
    policyArn: string;
    buildWorkflowId: string;
    annotations: AutomatedReasoningPolicyAnnotation[];
    lastUpdatedAnnotationSetHash: string;
}
export interface UpdateAutomatedReasoningPolicyAnnotationsResponse {
    policyArn: string;
    buildWorkflowId: string;
    annotationSetHash: string;
    updatedAt: Date;
}
export interface UpdateAutomatedReasoningPolicyTestCaseRequest {
    policyArn: string;
    testCaseId: string;
    guardContent: string | redacted.Redacted<string>;
    queryContent?: string | redacted.Redacted<string> | undefined;
    lastUpdatedAt: Date;
    expectedAggregatedFindingsResult: AutomatedReasoningCheckResult;
    confidenceThreshold?: number | undefined;
    clientRequestToken?: string | undefined;
}
export interface UpdateAutomatedReasoningPolicyTestCaseResponse {
    policyArn: string;
    testCaseId: string;
}
export interface UpdateCustomModelDeploymentRequest {
    modelArn: string;
    customModelDeploymentIdentifier: string;
}
export interface UpdateCustomModelDeploymentResponse {
    customModelDeploymentArn: string;
}
export interface UpdateGuardrailRequest {
    guardrailIdentifier: string;
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    topicPolicyConfig?: GuardrailTopicPolicyConfig | undefined;
    contentPolicyConfig?: GuardrailContentPolicyConfig | undefined;
    wordPolicyConfig?: GuardrailWordPolicyConfig | undefined;
    sensitiveInformationPolicyConfig?: GuardrailSensitiveInformationPolicyConfig | undefined;
    contextualGroundingPolicyConfig?: GuardrailContextualGroundingPolicyConfig | undefined;
    automatedReasoningPolicyConfig?: GuardrailAutomatedReasoningPolicyConfig | undefined;
    crossRegionConfig?: GuardrailCrossRegionConfig | undefined;
    blockedInputMessaging: string | redacted.Redacted<string>;
    blockedOutputsMessaging: string | redacted.Redacted<string>;
    kmsKeyId?: string | undefined;
}
export interface UpdateGuardrailResponse {
    guardrailId: string;
    guardrailArn: string;
    version: string;
    updatedAt: Date;
}
export interface UpdateMarketplaceModelEndpointRequest {
    endpointArn: string;
    endpointConfig: EndpointConfig;
    clientRequestToken?: string | undefined;
}
export interface UpdateMarketplaceModelEndpointResponse {
    marketplaceModelEndpoint: MarketplaceModelEndpoint;
}
export interface UpdateProvisionedModelThroughputRequest {
    provisionedModelId: string;
    desiredProvisionedModelName?: string | undefined;
    desiredModelId?: string | undefined;
}
export interface UpdateProvisionedModelThroughputResponse {
}
export type NonBlankString = string;
export type BatchDeleteAdvancedPromptOptimizationJobError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one or more advanced prompt optimization jobs.
 */
export declare const batchDeleteAdvancedPromptOptimizationJob: API.OperationMethod<BatchDeleteAdvancedPromptOptimizationJobRequest & RegionInput, BatchDeleteAdvancedPromptOptimizationJobResponse, BatchDeleteAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteEvaluationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a batch of evaluation jobs. An evaluation job can only be deleted if it has following status `FAILED`, `COMPLETED`, and `STOPPED`. You can request up to 25 model evaluation jobs be deleted in a single request.
 */
export declare const batchDeleteEvaluationJob: API.OperationMethod<BatchDeleteEvaluationJobRequest & RegionInput, BatchDeleteEvaluationJobResponse, BatchDeleteEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type CancelAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a running Automated Reasoning policy build workflow. This stops the policy generation process and prevents further processing of the source documents.
 */
export declare const cancelAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<CancelAutomatedReasoningPolicyBuildWorkflowRequest & RegionInput, CancelAutomatedReasoningPolicyBuildWorkflowResponse, CancelAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateAdvancedPromptOptimizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an advanced prompt optimization job. The job optimizes your prompt templates for specific models using your evaluation dataset and criteria.
 */
export declare const createAdvancedPromptOptimizationJob: API.OperationMethod<CreateAdvancedPromptOptimizationJobRequest & RegionInput, CreateAdvancedPromptOptimizationJobResponse, CreateAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type CreateAutomatedReasoningPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an Automated Reasoning policy for Amazon Bedrock Guardrails. Automated Reasoning policies use mathematical techniques to detect hallucinations, suggest corrections, and highlight unstated assumptions in the responses of your GenAI application.
 *
 * To create a policy, you upload a source document that describes the rules that you're encoding. Automated Reasoning extracts important concepts from the source document that will become variables in the policy and infers policy rules.
 */
export declare const createAutomatedReasoningPolicy: API.OperationMethod<CreateAutomatedReasoningPolicyRequest & RegionInput, CreateAutomatedReasoningPolicyResponse, CreateAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateAutomatedReasoningPolicyTestCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a test for an Automated Reasoning policy. Tests validate that your policy works as expected by providing sample inputs and expected outcomes. Use tests to verify policy behavior before deploying to production.
 */
export declare const createAutomatedReasoningPolicyTestCase: API.OperationMethod<CreateAutomatedReasoningPolicyTestCaseRequest & RegionInput, CreateAutomatedReasoningPolicyTestCaseResponse, CreateAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type CreateAutomatedReasoningPolicyVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a new version of an existing Automated Reasoning policy. This allows you to iterate on your policy rules while maintaining previous versions for rollback or comparison purposes.
 */
export declare const createAutomatedReasoningPolicyVersion: API.OperationMethod<CreateAutomatedReasoningPolicyVersionRequest & RegionInput, CreateAutomatedReasoningPolicyVersionResponse, CreateAutomatedReasoningPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type CreateCustomModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a new custom model in Amazon Bedrock. After the model is active, you can use it for inference.
 *
 * You can provide the model data source in one of the following ways:
 *
 * - `customModelDataSource` -- Specify a SageMaker AI model package ARN. Amazon Bedrock resolves the model package to retrieve the model artifacts. This is the preferred method for new SageMaker AI training outputs.
 *
 * - `modelSourceConfig` -- Specify an Amazon S3 URI pointing to the Amazon-managed Amazon S3 bucket containing your model artifacts.
 *
 * To use the model for inference, you must purchase Provisioned Throughput for it. You can't use On-demand inference with these custom models. For more information about Provisioned Throughput, see Provisioned Throughput.
 *
 * The model appears in `ListCustomModels` with a `customizationType` of `imported`. To track the status of the new model, you use the `GetCustomModel` API operation. The model can be in the following states:
 *
 * - `Creating` - Initial state during validation and registration
 *
 * - `Active` - Model is ready for use in inference
 *
 * - `Failed` - Creation process encountered an error
 *
 * **Related APIs**
 *
 * - GetCustomModel
 *
 * - ListCustomModels
 *
 * - DeleteCustomModel
 */
export declare const createCustomModel: API.OperationMethod<CreateCustomModelRequest & RegionInput, CreateCustomModelResponse, CreateCustomModelError, Credentials | HttpClient.HttpClient>;
export type CreateCustomModelDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Deploys a custom model for on-demand inference in Amazon Bedrock. After you deploy your custom model, you use the deployment's Amazon Resource Name (ARN) as the `modelId` parameter when you submit prompts and generate responses with model inference.
 *
 * For more information about setting up on-demand inference for custom models, see Set up inference for a custom model.
 *
 * The following actions are related to the `CreateCustomModelDeployment` operation:
 *
 * - GetCustomModelDeployment
 *
 * - ListCustomModelDeployments
 *
 * - DeleteCustomModelDeployment
 */
export declare const createCustomModelDeployment: API.OperationMethod<CreateCustomModelDeploymentRequest & RegionInput, CreateCustomModelDeploymentResponse, CreateCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateEvaluationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an evaluation job.
 */
export declare const createEvaluationJob: API.OperationMethod<CreateEvaluationJobRequest & RegionInput, CreateEvaluationJobResponse, CreateEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type CreateFoundationModelAgreementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Request a model access agreement for the specified model.
 */
export declare const createFoundationModelAgreement: API.OperationMethod<CreateFoundationModelAgreementRequest & RegionInput, CreateFoundationModelAgreementResponse, CreateFoundationModelAgreementError, Credentials | HttpClient.HttpClient>;
export type CreateGuardrailError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a guardrail to block topics and to implement safeguards for your generative AI applications.
 *
 * You can configure the following policies in a guardrail to avoid undesirable and harmful content, filter out denied topics and words, and remove sensitive information for privacy protection.
 *
 * - **Content filters** - Adjust filter strengths to block input prompts or model responses containing harmful content.
 *
 * - **Denied topics** - Define a set of topics that are undesirable in the context of your application. These topics will be blocked if detected in user queries or model responses.
 *
 * - **Word filters** - Configure filters to block undesirable words, phrases, and profanity. Such words can include offensive terms, competitor names etc.
 *
 * - **Sensitive information filters** - Block or mask sensitive information such as personally identifiable information (PII) or custom regex in user inputs and model responses.
 *
 * In addition to the above policies, you can also configure the messages to be returned to the user if a user input or model response is in violation of the policies defined in the guardrail.
 *
 * For more information, see Amazon Bedrock Guardrails in the *Amazon Bedrock User Guide*.
 */
export declare const createGuardrail: API.OperationMethod<CreateGuardrailRequest & RegionInput, CreateGuardrailResponse, CreateGuardrailError, Credentials | HttpClient.HttpClient>;
export type CreateGuardrailVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a version of the guardrail. Use this API to create a snapshot of the guardrail when you are satisfied with a configuration, or to compare the configuration with another version.
 */
export declare const createGuardrailVersion: API.OperationMethod<CreateGuardrailVersionRequest & RegionInput, CreateGuardrailVersionResponse, CreateGuardrailVersionError, Credentials | HttpClient.HttpClient>;
export type CreateInferenceProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates an application inference profile to track metrics and costs when invoking a model. To create an application inference profile for a foundation model in one region, specify the ARN of the model in that region. To create an application inference profile for a foundation model across multiple regions, specify the ARN of the system-defined inference profile that contains the regions that you want to route requests to. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const createInferenceProfile: API.OperationMethod<CreateInferenceProfileRequest & RegionInput, CreateInferenceProfileResponse, CreateInferenceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateMarketplaceModelEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an endpoint for a model from Amazon Bedrock Marketplace. The endpoint is hosted by Amazon SageMaker.
 */
export declare const createMarketplaceModelEndpoint: API.OperationMethod<CreateMarketplaceModelEndpointRequest & RegionInput, CreateMarketplaceModelEndpointResponse, CreateMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateModelCopyJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Copies a model to another region so that it can be used there. For more information, see Copy models to be used in other regions in the Amazon Bedrock User Guide.
 */
export declare const createModelCopyJob: API.OperationMethod<CreateModelCopyJobRequest & RegionInput, CreateModelCopyJobResponse, CreateModelCopyJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelCustomizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a fine-tuning job to customize a base model.
 *
 * You specify the base foundation model and the location of the training data. After the model-customization job completes successfully, your custom model resource will be ready to use. Amazon Bedrock returns validation loss metrics and output generations after the job completes.
 *
 * For information on the format of training and validation data, see Prepare the datasets.
 *
 * Model-customization jobs are asynchronous and the completion time depends on the base model and the training/validation data size. To monitor a job, use the `GetModelCustomizationJob` operation to retrieve the job status.
 *
 * For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const createModelCustomizationJob: API.OperationMethod<CreateModelCustomizationJobRequest & RegionInput, CreateModelCustomizationJobResponse, CreateModelCustomizationJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelImportJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a model import job to import model that you have customized in other environments, such as Amazon SageMaker. For more information, see Import a customized model
 */
export declare const createModelImportJob: API.OperationMethod<CreateModelImportJobRequest & RegionInput, CreateModelImportJobResponse, CreateModelImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateModelInvocationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a batch inference job to invoke a model on multiple prompts. Format your data according to Format your inference data and upload it to an Amazon S3 bucket. For more information, see Process multiple prompts with batch inference.
 *
 * The response returns a `jobArn` that you can use to stop or get details about the job.
 */
export declare const createModelInvocationJob: API.OperationMethod<CreateModelInvocationJobRequest & RegionInput, CreateModelInvocationJobResponse, CreateModelInvocationJobError, Credentials | HttpClient.HttpClient>;
export type CreatePromptRouterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates a prompt router that manages the routing of requests between multiple foundation models based on the routing criteria.
 */
export declare const createPromptRouter: API.OperationMethod<CreatePromptRouterRequest & RegionInput, CreatePromptRouterResponse, CreatePromptRouterError, Credentials | HttpClient.HttpClient>;
export type CreateProvisionedModelThroughputError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Creates dedicated throughput for a base or custom model with the model units and for the duration that you specify. For pricing details, see Amazon Bedrock Pricing. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const createProvisionedModelThroughput: API.OperationMethod<CreateProvisionedModelThroughputRequest & RegionInput, CreateProvisionedModelThroughputResponse, CreateProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomatedReasoningPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Automated Reasoning policy or policy version. This operation is idempotent. If you delete a policy more than once, each call succeeds. Deleting a policy removes it permanently and cannot be undone.
 */
export declare const deleteAutomatedReasoningPolicy: API.OperationMethod<DeleteAutomatedReasoningPolicyRequest & RegionInput, DeleteAutomatedReasoningPolicyResponse, DeleteAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Automated Reasoning policy build workflow and its associated artifacts. This permanently removes the workflow history and any generated assets.
 */
export declare const deleteAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<DeleteAutomatedReasoningPolicyBuildWorkflowRequest & RegionInput, DeleteAutomatedReasoningPolicyBuildWorkflowResponse, DeleteAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomatedReasoningPolicyTestCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Automated Reasoning policy test. This operation is idempotent; if you delete a test more than once, each call succeeds.
 */
export declare const deleteAutomatedReasoningPolicyTestCase: API.OperationMethod<DeleteAutomatedReasoningPolicyTestCaseRequest & RegionInput, DeleteAutomatedReasoningPolicyTestCaseResponse, DeleteAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom model that you created earlier. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const deleteCustomModel: API.OperationMethod<DeleteCustomModelRequest & RegionInput, DeleteCustomModelResponse, DeleteCustomModelError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomModelDeploymentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom model deployment. This operation stops the deployment and removes it from your account. After deletion, the deployment ARN can no longer be used for inference requests.
 *
 * The following actions are related to the `DeleteCustomModelDeployment` operation:
 *
 * - CreateCustomModelDeployment
 *
 * - GetCustomModelDeployment
 *
 * - ListCustomModelDeployments
 */
export declare const deleteCustomModelDeployment: API.OperationMethod<DeleteCustomModelDeploymentRequest & RegionInput, DeleteCustomModelDeploymentResponse, DeleteCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteEnforcedGuardrailConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the account-level enforced guardrail configuration.
 */
export declare const deleteEnforcedGuardrailConfiguration: API.OperationMethod<DeleteEnforcedGuardrailConfigurationRequest & RegionInput, DeleteEnforcedGuardrailConfigurationResponse, DeleteEnforcedGuardrailConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteFoundationModelAgreementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the model access agreement for the specified model.
 */
export declare const deleteFoundationModelAgreement: API.OperationMethod<DeleteFoundationModelAgreementRequest & RegionInput, DeleteFoundationModelAgreementResponse, DeleteFoundationModelAgreementError, Credentials | HttpClient.HttpClient>;
export type DeleteGuardrailError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a guardrail.
 *
 * - To delete a guardrail, only specify the ARN of the guardrail in the `guardrailIdentifier` field. If you delete a guardrail, all of its versions will be deleted.
 *
 * - To delete a version of a guardrail, specify the ARN of the guardrail in the `guardrailIdentifier` field and the version in the `guardrailVersion` field.
 */
export declare const deleteGuardrail: API.OperationMethod<DeleteGuardrailRequest & RegionInput, DeleteGuardrailResponse, DeleteGuardrailError, Credentials | HttpClient.HttpClient>;
export type DeleteImportedModelError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a custom model that you imported earlier. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const deleteImportedModel: API.OperationMethod<DeleteImportedModelRequest & RegionInput, DeleteImportedModelResponse, DeleteImportedModelError, Credentials | HttpClient.HttpClient>;
export type DeleteInferenceProfileError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an application inference profile. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const deleteInferenceProfile: API.OperationMethod<DeleteInferenceProfileRequest & RegionInput, DeleteInferenceProfileResponse, DeleteInferenceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an endpoint for a model from Amazon Bedrock Marketplace.
 */
export declare const deleteMarketplaceModelEndpoint: API.OperationMethod<DeleteMarketplaceModelEndpointRequest & RegionInput, DeleteMarketplaceModelEndpointResponse, DeleteMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteModelInvocationLoggingConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Delete the invocation logging.
 */
export declare const deleteModelInvocationLoggingConfiguration: API.OperationMethod<DeleteModelInvocationLoggingConfigurationRequest & RegionInput, DeleteModelInvocationLoggingConfigurationResponse, DeleteModelInvocationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeletePromptRouterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified prompt router. This action cannot be undone.
 */
export declare const deletePromptRouter: API.OperationMethod<DeletePromptRouterRequest & RegionInput, DeletePromptRouterResponse, DeletePromptRouterError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisionedModelThroughputError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Provisioned Throughput. You can't delete a Provisioned Throughput before the commitment term is over. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const deleteProvisionedModelThroughput: API.OperationMethod<DeleteProvisionedModelThroughputRequest & RegionInput, DeleteProvisionedModelThroughputResponse, DeleteProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a previously created Bedrock resource policy.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeregisterMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters an endpoint for a model from Amazon Bedrock Marketplace. This operation removes the endpoint's association with Amazon Bedrock but does not delete the underlying Amazon SageMaker endpoint.
 */
export declare const deregisterMarketplaceModelEndpoint: API.OperationMethod<DeregisterMarketplaceModelEndpointRequest & RegionInput, DeregisterMarketplaceModelEndpointResponse, DeregisterMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type ExportAutomatedReasoningPolicyVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Exports the policy definition for an Automated Reasoning policy version. Returns the complete policy definition including rules, variables, and custom variable types in a structured format.
 */
export declare const exportAutomatedReasoningPolicyVersion: API.OperationMethod<ExportAutomatedReasoningPolicyVersionRequest & RegionInput, ExportAutomatedReasoningPolicyVersionResponse, ExportAutomatedReasoningPolicyVersionError, Credentials | HttpClient.HttpClient>;
export type GetAccountDataRetentionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the account-wide data retention mode for Amazon Bedrock.
 */
export declare const getAccountDataRetention: API.OperationMethod<GetAccountDataRetentionRequest & RegionInput, GetAccountDataRetentionResponse, GetAccountDataRetentionError, Credentials | HttpClient.HttpClient>;
export type GetAdvancedPromptOptimizationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an advanced prompt optimization job.
 */
export declare const getAdvancedPromptOptimizationJob: API.OperationMethod<GetAdvancedPromptOptimizationJobRequest & RegionInput, GetAdvancedPromptOptimizationJobResponse, GetAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about an Automated Reasoning policy or policy version. Returns information including the policy definition, metadata, and timestamps.
 */
export declare const getAutomatedReasoningPolicy: API.OperationMethod<GetAutomatedReasoningPolicyRequest & RegionInput, GetAutomatedReasoningPolicyResponse, GetAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyAnnotationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current annotations for an Automated Reasoning policy build workflow. Annotations contain corrections to the rules, variables and types to be applied to the policy.
 */
export declare const getAutomatedReasoningPolicyAnnotations: API.OperationMethod<GetAutomatedReasoningPolicyAnnotationsRequest & RegionInput, GetAutomatedReasoningPolicyAnnotationsResponse, GetAutomatedReasoningPolicyAnnotationsError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about an Automated Reasoning policy build workflow, including its status, configuration, and metadata.
 */
export declare const getAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<GetAutomatedReasoningPolicyBuildWorkflowRequest & RegionInput, GetAutomatedReasoningPolicyBuildWorkflowResponse, GetAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyBuildWorkflowResultAssetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resulting assets from a completed Automated Reasoning policy build workflow, including build logs, quality reports, and generated policy artifacts.
 */
export declare const getAutomatedReasoningPolicyBuildWorkflowResultAssets: API.OperationMethod<GetAutomatedReasoningPolicyBuildWorkflowResultAssetsRequest & RegionInput, GetAutomatedReasoningPolicyBuildWorkflowResultAssetsResponse, GetAutomatedReasoningPolicyBuildWorkflowResultAssetsError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyNextScenarioError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the next test scenario for validating an Automated Reasoning policy. This is used during the interactive policy refinement process to test policy behavior.
 */
export declare const getAutomatedReasoningPolicyNextScenario: API.OperationMethod<GetAutomatedReasoningPolicyNextScenarioRequest & RegionInput, GetAutomatedReasoningPolicyNextScenarioResponse, GetAutomatedReasoningPolicyNextScenarioError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyTestCaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific Automated Reasoning policy test.
 */
export declare const getAutomatedReasoningPolicyTestCase: API.OperationMethod<GetAutomatedReasoningPolicyTestCaseRequest & RegionInput, GetAutomatedReasoningPolicyTestCaseResponse, GetAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedReasoningPolicyTestResultError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the test result for a specific Automated Reasoning policy test. Returns detailed validation findings and execution status.
 */
export declare const getAutomatedReasoningPolicyTestResult: API.OperationMethod<GetAutomatedReasoningPolicyTestResultRequest & RegionInput, GetAutomatedReasoningPolicyTestResultResponse, GetAutomatedReasoningPolicyTestResultError, Credentials | HttpClient.HttpClient>;
export type GetCustomModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the properties associated with a Amazon Bedrock custom model that you have created. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const getCustomModel: API.OperationMethod<GetCustomModelRequest & RegionInput, GetCustomModelResponse, GetCustomModelError, Credentials | HttpClient.HttpClient>;
export type GetCustomModelDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a custom model deployment, including its status, configuration, and metadata. Use this operation to monitor the deployment status and retrieve details needed for inference requests.
 *
 * The following actions are related to the `GetCustomModelDeployment` operation:
 *
 * - CreateCustomModelDeployment
 *
 * - ListCustomModelDeployments
 *
 * - DeleteCustomModelDeployment
 */
export declare const getCustomModelDeployment: API.OperationMethod<GetCustomModelDeploymentRequest & RegionInput, GetCustomModelDeploymentResponse, GetCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetEvaluationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an evaluation job, such as the status of the job.
 */
export declare const getEvaluationJob: API.OperationMethod<GetEvaluationJobRequest & RegionInput, GetEvaluationJobResponse, GetEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type GetFoundationModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get details about a Amazon Bedrock foundation model.
 */
export declare const getFoundationModel: API.OperationMethod<GetFoundationModelRequest & RegionInput, GetFoundationModelResponse, GetFoundationModelError, Credentials | HttpClient.HttpClient>;
export type GetFoundationModelAvailabilityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about the Foundation model availability.
 */
export declare const getFoundationModelAvailability: API.OperationMethod<GetFoundationModelAvailabilityRequest & RegionInput, GetFoundationModelAvailabilityResponse, GetFoundationModelAvailabilityError, Credentials | HttpClient.HttpClient>;
export type GetGuardrailError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a guardrail. If you don't specify a version, the response returns details for the `DRAFT` version.
 */
export declare const getGuardrail: API.OperationMethod<GetGuardrailRequest & RegionInput, GetGuardrailResponse, GetGuardrailError, Credentials | HttpClient.HttpClient>;
export type GetImportedModelError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets properties associated with a customized model you imported.
 */
export declare const getImportedModel: API.OperationMethod<GetImportedModelRequest & RegionInput, GetImportedModelResponse, GetImportedModelError, Credentials | HttpClient.HttpClient>;
export type GetInferenceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an inference profile. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const getInferenceProfile: API.OperationMethod<GetInferenceProfileRequest & RegionInput, GetInferenceProfileResponse, GetInferenceProfileError, Credentials | HttpClient.HttpClient>;
export type GetMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a specific endpoint for a model from Amazon Bedrock Marketplace.
 */
export declare const getMarketplaceModelEndpoint: API.OperationMethod<GetMarketplaceModelEndpointRequest & RegionInput, GetMarketplaceModelEndpointResponse, GetMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type GetModelCopyJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a model copy job. For more information, see Copy models to be used in other regions in the Amazon Bedrock User Guide.
 */
export declare const getModelCopyJob: API.OperationMethod<GetModelCopyJobRequest & RegionInput, GetModelCopyJobResponse, GetModelCopyJobError, Credentials | HttpClient.HttpClient>;
export type GetModelCustomizationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the properties associated with a model-customization job, including the status of the job. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const getModelCustomizationJob: API.OperationMethod<GetModelCustomizationJobRequest & RegionInput, GetModelCustomizationJobResponse, GetModelCustomizationJobError, Credentials | HttpClient.HttpClient>;
export type GetModelImportJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the properties associated with import model job, including the status of the job. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const getModelImportJob: API.OperationMethod<GetModelImportJobRequest & RegionInput, GetModelImportJobResponse, GetModelImportJobError, Credentials | HttpClient.HttpClient>;
export type GetModelInvocationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a batch inference job. For more information, see Monitor batch inference jobs
 */
export declare const getModelInvocationJob: API.OperationMethod<GetModelInvocationJobRequest & RegionInput, GetModelInvocationJobResponse, GetModelInvocationJobError, Credentials | HttpClient.HttpClient>;
export type GetModelInvocationLoggingConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Get the current configuration values for model invocation logging.
 */
export declare const getModelInvocationLoggingConfiguration: API.OperationMethod<GetModelInvocationLoggingConfigurationRequest & RegionInput, GetModelInvocationLoggingConfigurationResponse, GetModelInvocationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetPromptRouterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a prompt router.
 */
export declare const getPromptRouter: API.OperationMethod<GetPromptRouterRequest & RegionInput, GetPromptRouterResponse, GetPromptRouterError, Credentials | HttpClient.HttpClient>;
export type GetProvisionedModelThroughputError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details for a Provisioned Throughput. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const getProvisionedModelThroughput: API.OperationMethod<GetProvisionedModelThroughputRequest & RegionInput, GetProvisionedModelThroughputResponse, GetProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the resource policy document for a Bedrock resource
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetUseCaseForModelAccessError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get usecase for model access.
 */
export declare const getUseCaseForModelAccess: API.OperationMethod<GetUseCaseForModelAccessRequest & RegionInput, GetUseCaseForModelAccessResponse, GetUseCaseForModelAccessError, Credentials | HttpClient.HttpClient>;
export type ListAdvancedPromptOptimizationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the advanced prompt optimization jobs in your account.
 */
export declare const listAdvancedPromptOptimizationJobs: API.PaginatedOperationMethod<ListAdvancedPromptOptimizationJobsRequest & RegionInput, ListAdvancedPromptOptimizationJobsResponse, ListAdvancedPromptOptimizationJobsError, Credentials | HttpClient.HttpClient, AdvancedPromptOptimizationJobSummary>;
export type ListAutomatedReasoningPoliciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Automated Reasoning policies in your account, with optional filtering by policy ARN. This helps you manage and discover existing policies.
 */
export declare const listAutomatedReasoningPolicies: API.PaginatedOperationMethod<ListAutomatedReasoningPoliciesRequest & RegionInput, ListAutomatedReasoningPoliciesResponse, ListAutomatedReasoningPoliciesError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicySummary>;
export type ListAutomatedReasoningPolicyBuildWorkflowsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all build workflows for an Automated Reasoning policy, showing the history of policy creation and modification attempts.
 */
export declare const listAutomatedReasoningPolicyBuildWorkflows: API.PaginatedOperationMethod<ListAutomatedReasoningPolicyBuildWorkflowsRequest & RegionInput, ListAutomatedReasoningPolicyBuildWorkflowsResponse, ListAutomatedReasoningPolicyBuildWorkflowsError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicyBuildWorkflowSummary>;
export type ListAutomatedReasoningPolicyTestCasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists tests for an Automated Reasoning policy. We recommend using pagination to ensure that the operation returns quickly and successfully.
 */
export declare const listAutomatedReasoningPolicyTestCases: API.PaginatedOperationMethod<ListAutomatedReasoningPolicyTestCasesRequest & RegionInput, ListAutomatedReasoningPolicyTestCasesResponse, ListAutomatedReasoningPolicyTestCasesError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicyTestCase>;
export type ListAutomatedReasoningPolicyTestResultsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists test results for an Automated Reasoning policy, showing how the policy performed against various test scenarios and validation checks.
 */
export declare const listAutomatedReasoningPolicyTestResults: API.PaginatedOperationMethod<ListAutomatedReasoningPolicyTestResultsRequest & RegionInput, ListAutomatedReasoningPolicyTestResultsResponse, ListAutomatedReasoningPolicyTestResultsError, Credentials | HttpClient.HttpClient, AutomatedReasoningPolicyTestResult>;
export type ListCustomModelDeploymentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists custom model deployments in your account. You can filter the results by creation time, name, status, and associated model. Use this operation to manage and monitor your custom model deployments.
 *
 * We recommend using pagination to ensure that the operation returns quickly and successfully.
 *
 * The following actions are related to the `ListCustomModelDeployments` operation:
 *
 * - CreateCustomModelDeployment
 *
 * - GetCustomModelDeployment
 *
 * - DeleteCustomModelDeployment
 */
export declare const listCustomModelDeployments: API.PaginatedOperationMethod<ListCustomModelDeploymentsRequest & RegionInput, ListCustomModelDeploymentsResponse, ListCustomModelDeploymentsError, Credentials | HttpClient.HttpClient, CustomModelDeploymentSummary>;
export type ListCustomModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the custom models that you have created with the `CreateModelCustomizationJob` operation.
 *
 * For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const listCustomModels: API.PaginatedOperationMethod<ListCustomModelsRequest & RegionInput, ListCustomModelsResponse, ListCustomModelsError, Credentials | HttpClient.HttpClient, CustomModelSummary>;
export type ListEnforcedGuardrailsConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the account-level enforced guardrail configurations.
 */
export declare const listEnforcedGuardrailsConfiguration: API.PaginatedOperationMethod<ListEnforcedGuardrailsConfigurationRequest & RegionInput, ListEnforcedGuardrailsConfigurationResponse, ListEnforcedGuardrailsConfigurationError, Credentials | HttpClient.HttpClient, AccountEnforcedGuardrailOutputConfiguration>;
export type ListEvaluationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all existing evaluation jobs.
 */
export declare const listEvaluationJobs: API.PaginatedOperationMethod<ListEvaluationJobsRequest & RegionInput, ListEvaluationJobsResponse, ListEvaluationJobsError, Credentials | HttpClient.HttpClient, EvaluationSummary>;
export type ListFoundationModelAgreementOffersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the offers associated with the specified model.
 */
export declare const listFoundationModelAgreementOffers: API.OperationMethod<ListFoundationModelAgreementOffersRequest & RegionInput, ListFoundationModelAgreementOffersResponse, ListFoundationModelAgreementOffersError, Credentials | HttpClient.HttpClient>;
export type ListFoundationModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Bedrock foundation models that you can use. You can filter the results with the request parameters. For more information, see Foundation models in the Amazon Bedrock User Guide.
 */
export declare const listFoundationModels: API.OperationMethod<ListFoundationModelsRequest & RegionInput, ListFoundationModelsResponse, ListFoundationModelsError, Credentials | HttpClient.HttpClient>;
export type ListGuardrailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists details about all the guardrails in an account. To list the `DRAFT` version of all your guardrails, don't specify the `guardrailIdentifier` field. To list all versions of a guardrail, specify the ARN of the guardrail in the `guardrailIdentifier` field.
 *
 * You can set the maximum number of results to return in a response in the `maxResults` field. If there are more results than the number you set, the response returns a `nextToken` that you can send in another `ListGuardrails` request to see the next batch of results.
 */
export declare const listGuardrails: API.PaginatedOperationMethod<ListGuardrailsRequest & RegionInput, ListGuardrailsResponse, ListGuardrailsError, Credentials | HttpClient.HttpClient, GuardrailSummary>;
export type ListImportedModelsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of models you've imported. You can filter the results to return based on one or more criteria. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const listImportedModels: API.PaginatedOperationMethod<ListImportedModelsRequest & RegionInput, ListImportedModelsResponse, ListImportedModelsError, Credentials | HttpClient.HttpClient, ImportedModelSummary>;
export type ListInferenceProfilesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of inference profiles that you can use. For more information, see Increase throughput and resilience with cross-region inference in Amazon Bedrock. in the Amazon Bedrock User Guide.
 */
export declare const listInferenceProfiles: API.PaginatedOperationMethod<ListInferenceProfilesRequest & RegionInput, ListInferenceProfilesResponse, ListInferenceProfilesError, Credentials | HttpClient.HttpClient, InferenceProfileSummary>;
export type ListMarketplaceModelEndpointsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the endpoints for models from Amazon Bedrock Marketplace in your Amazon Web Services account.
 */
export declare const listMarketplaceModelEndpoints: API.PaginatedOperationMethod<ListMarketplaceModelEndpointsRequest & RegionInput, ListMarketplaceModelEndpointsResponse, ListMarketplaceModelEndpointsError, Credentials | HttpClient.HttpClient, MarketplaceModelEndpointSummary>;
export type ListModelCopyJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of model copy jobs that you have submitted. You can filter the jobs to return based on one or more criteria. For more information, see Copy models to be used in other regions in the Amazon Bedrock User Guide.
 */
export declare const listModelCopyJobs: API.PaginatedOperationMethod<ListModelCopyJobsRequest & RegionInput, ListModelCopyJobsResponse, ListModelCopyJobsError, Credentials | HttpClient.HttpClient, ModelCopyJobSummary>;
export type ListModelCustomizationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of model customization jobs that you have submitted. You can filter the jobs to return based on one or more criteria.
 *
 * For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const listModelCustomizationJobs: API.PaginatedOperationMethod<ListModelCustomizationJobsRequest & RegionInput, ListModelCustomizationJobsResponse, ListModelCustomizationJobsError, Credentials | HttpClient.HttpClient, ModelCustomizationJobSummary>;
export type ListModelImportJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of import jobs you've submitted. You can filter the results to return based on one or more criteria. For more information, see Import a customized model in the Amazon Bedrock User Guide.
 */
export declare const listModelImportJobs: API.PaginatedOperationMethod<ListModelImportJobsRequest & RegionInput, ListModelImportJobsResponse, ListModelImportJobsError, Credentials | HttpClient.HttpClient, ModelImportJobSummary>;
export type ListModelInvocationJobsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all batch inference jobs in the account. For more information, see View details about a batch inference job.
 */
export declare const listModelInvocationJobs: API.PaginatedOperationMethod<ListModelInvocationJobsRequest & RegionInput, ListModelInvocationJobsResponse, ListModelInvocationJobsError, Credentials | HttpClient.HttpClient, ModelInvocationJobSummary>;
export type ListPromptRoutersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of prompt routers.
 */
export declare const listPromptRouters: API.PaginatedOperationMethod<ListPromptRoutersRequest & RegionInput, ListPromptRoutersResponse, ListPromptRoutersError, Credentials | HttpClient.HttpClient, PromptRouterSummary>;
export type ListProvisionedModelThroughputsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Provisioned Throughputs in the account. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const listProvisionedModelThroughputs: API.PaginatedOperationMethod<ListProvisionedModelThroughputsRequest & RegionInput, ListProvisionedModelThroughputsResponse, ListProvisionedModelThroughputsError, Credentials | HttpClient.HttpClient, ProvisionedModelSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the tags associated with the specified resource.
 *
 * For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountDataRetentionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the account-wide data retention mode for Amazon Bedrock.
 */
export declare const putAccountDataRetention: API.OperationMethod<PutAccountDataRetentionRequest & RegionInput, PutAccountDataRetentionResponse, PutAccountDataRetentionError, Credentials | HttpClient.HttpClient>;
export type PutEnforcedGuardrailConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the account-level enforced guardrail configuration.
 */
export declare const putEnforcedGuardrailConfiguration: API.OperationMethod<PutEnforcedGuardrailConfigurationRequest & RegionInput, PutEnforcedGuardrailConfigurationResponse, PutEnforcedGuardrailConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutModelInvocationLoggingConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the configuration values for model invocation logging.
 */
export declare const putModelInvocationLoggingConfiguration: API.OperationMethod<PutModelInvocationLoggingConfigurationRequest & RegionInput, PutModelInvocationLoggingConfigurationResponse, PutModelInvocationLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a resource policy for a Bedrock resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutUseCaseForModelAccessError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put usecase for model access.
 */
export declare const putUseCaseForModelAccess: API.OperationMethod<PutUseCaseForModelAccessRequest & RegionInput, PutUseCaseForModelAccessResponse, PutUseCaseForModelAccessError, Credentials | HttpClient.HttpClient>;
export type RegisterMarketplaceModelEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers an existing Amazon SageMaker endpoint with Amazon Bedrock Marketplace, allowing it to be used with Amazon Bedrock APIs.
 */
export declare const registerMarketplaceModelEndpoint: API.OperationMethod<RegisterMarketplaceModelEndpointRequest & RegionInput, RegisterMarketplaceModelEndpointResponse, RegisterMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type StartAutomatedReasoningPolicyBuildWorkflowError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new build workflow for an Automated Reasoning policy. This initiates the process of analyzing source documents and generating policy rules, variables, and types.
 */
export declare const startAutomatedReasoningPolicyBuildWorkflow: API.OperationMethod<StartAutomatedReasoningPolicyBuildWorkflowRequest & RegionInput, StartAutomatedReasoningPolicyBuildWorkflowResponse, StartAutomatedReasoningPolicyBuildWorkflowError, Credentials | HttpClient.HttpClient>;
export type StartAutomatedReasoningPolicyTestWorkflowError = AccessDeniedException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a test workflow to validate Automated Reasoning policy tests. The workflow executes the specified tests against the policy and generates validation results.
 */
export declare const startAutomatedReasoningPolicyTestWorkflow: API.OperationMethod<StartAutomatedReasoningPolicyTestWorkflowRequest & RegionInput, StartAutomatedReasoningPolicyTestWorkflowResponse, StartAutomatedReasoningPolicyTestWorkflowError, Credentials | HttpClient.HttpClient>;
export type StopAdvancedPromptOptimizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an advanced prompt optimization job that is in progress.
 */
export declare const stopAdvancedPromptOptimizationJob: API.OperationMethod<StopAdvancedPromptOptimizationJobRequest & RegionInput, StopAdvancedPromptOptimizationJobResponse, StopAdvancedPromptOptimizationJobError, Credentials | HttpClient.HttpClient>;
export type StopEvaluationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an evaluation job that is current being created or running.
 */
export declare const stopEvaluationJob: API.OperationMethod<StopEvaluationJobRequest & RegionInput, StopEvaluationJobResponse, StopEvaluationJobError, Credentials | HttpClient.HttpClient>;
export type StopModelCustomizationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an active model customization job. For more information, see Custom models in the Amazon Bedrock User Guide.
 */
export declare const stopModelCustomizationJob: API.OperationMethod<StopModelCustomizationJobRequest & RegionInput, StopModelCustomizationJobResponse, StopModelCustomizationJobError, Credentials | HttpClient.HttpClient>;
export type StopModelInvocationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a batch inference job. You're only charged for tokens that were already processed. For more information, see Stop a batch inference job.
 */
export declare const stopModelInvocationJob: API.OperationMethod<StopModelInvocationJobRequest & RegionInput, StopModelInvocationJobResponse, StopModelInvocationJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Associate tags with a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove one or more tags from a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedReasoningPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Updates an existing Automated Reasoning policy with new rules, variables, or configuration. This creates a new version of the policy while preserving the previous version.
 */
export declare const updateAutomatedReasoningPolicy: API.OperationMethod<UpdateAutomatedReasoningPolicyRequest & RegionInput, UpdateAutomatedReasoningPolicyResponse, UpdateAutomatedReasoningPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedReasoningPolicyAnnotationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the annotations for an Automated Reasoning policy build workflow. This allows you to modify extracted rules, variables, and types before finalizing the policy.
 */
export declare const updateAutomatedReasoningPolicyAnnotations: API.OperationMethod<UpdateAutomatedReasoningPolicyAnnotationsRequest & RegionInput, UpdateAutomatedReasoningPolicyAnnotationsResponse, UpdateAutomatedReasoningPolicyAnnotationsError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedReasoningPolicyTestCaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Automated Reasoning policy test. You can modify the content, query, expected result, and confidence threshold.
 */
export declare const updateAutomatedReasoningPolicyTestCase: API.OperationMethod<UpdateAutomatedReasoningPolicyTestCaseRequest & RegionInput, UpdateAutomatedReasoningPolicyTestCaseResponse, UpdateAutomatedReasoningPolicyTestCaseError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomModelDeploymentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a custom model deployment with a new custom model. This allows you to deploy updated models without creating new deployment endpoints.
 */
export declare const updateCustomModelDeployment: API.OperationMethod<UpdateCustomModelDeploymentRequest & RegionInput, UpdateCustomModelDeploymentResponse, UpdateCustomModelDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateGuardrailError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a guardrail with the values you specify.
 *
 * - Specify a `name` and optional `description`.
 *
 * - Specify messages for when the guardrail successfully blocks a prompt or a model response in the `blockedInputMessaging` and `blockedOutputsMessaging` fields.
 *
 * - Specify topics for the guardrail to deny in the `topicPolicyConfig` object. Each GuardrailTopicConfig object in the `topicsConfig` list pertains to one topic.
 *
 * - Give a `name` and `description` so that the guardrail can properly identify the topic.
 *
 * - Specify `DENY` in the `type` field.
 *
 * - (Optional) Provide up to five prompts that you would categorize as belonging to the topic in the `examples` list.
 *
 * - Specify filter strengths for the harmful categories defined in Amazon Bedrock in the `contentPolicyConfig` object. Each GuardrailContentFilterConfig object in the `filtersConfig` list pertains to a harmful category. For more information, see Content filters. For more information about the fields in a content filter, see GuardrailContentFilterConfig.
 *
 * - Specify the category in the `type` field.
 *
 * - Specify the strength of the filter for prompts in the `inputStrength` field and for model responses in the `strength` field of the GuardrailContentFilterConfig.
 *
 * - (Optional) For security, include the ARN of a KMS key in the `kmsKeyId` field.
 */
export declare const updateGuardrail: API.OperationMethod<UpdateGuardrailRequest & RegionInput, UpdateGuardrailResponse, UpdateGuardrailError, Credentials | HttpClient.HttpClient>;
export type UpdateMarketplaceModelEndpointError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing endpoint for a model from Amazon Bedrock Marketplace.
 */
export declare const updateMarketplaceModelEndpoint: API.OperationMethod<UpdateMarketplaceModelEndpointRequest & RegionInput, UpdateMarketplaceModelEndpointResponse, UpdateMarketplaceModelEndpointError, Credentials | HttpClient.HttpClient>;
export type UpdateProvisionedModelThroughputError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the name or associated model for a Provisioned Throughput. For more information, see Provisioned Throughput in the Amazon Bedrock User Guide.
 */
export declare const updateProvisionedModelThroughput: API.OperationMethod<UpdateProvisionedModelThroughputRequest & RegionInput, UpdateProvisionedModelThroughputResponse, UpdateProvisionedModelThroughputError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock.d.ts.map