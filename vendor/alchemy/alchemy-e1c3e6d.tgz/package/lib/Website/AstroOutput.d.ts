import * as Effect from "effect/Effect";
export interface AstroOutputProps {
    /** Project root, relative to the initial working directory. */
    readonly rootDir?: string | undefined;
    /** Alternate astro config file, relative to {@link rootDir}. */
    readonly config?: string | undefined;
    /** The composite's `astro.output` prop. */
    readonly output?: "server" | "static" | undefined;
}
/**
 * Resolves the Astro `output` a website composite deploys: the
 * `astro.output` prop, else the `output` declared in the project's
 * `astro.config.*`, else `"server"`. Composites decide at plan time whether
 * a site is assets-only, so the config file is read here rather than left
 * to the build.
 *
 * `@alchemy.run/frontend-frameworks` is an optional peer dependency, so it
 * is imported lazily. When it is missing or the config cannot be loaded the
 * site falls back to `"server"` (the build reports the real error).
 */
export declare const resolveAstroOutput: (props: AstroOutputProps) => Effect.Effect<import("@alchemy.run/frontend-frameworks/astro/config").AstroOutput, never, never>;
export interface AstroSettings {
    /** The resolved `output` (see {@link resolveAstroOutput}). */
    readonly output: "server" | "static";
    /**
     * Whether the Astro config routes caching through the Cloudflare cache
     * provider (`cacheCloudflare()`), so the Worker needs Workers Cache on.
     */
    readonly workerCache: boolean;
}
/**
 * Resolves the Astro settings a Cloudflare composite deploys from one read
 * of the project's `astro.config.*`: the `output` (as
 * {@link resolveAstroOutput}) and whether the config uses the Cloudflare
 * cache provider. When the config cannot be loaded the site falls back to
 * `"server"` without Workers Cache (the build reports the real error).
 */
export declare const resolveAstroSettings: (props: AstroOutputProps) => Effect.Effect<{
    output: import("@alchemy.run/frontend-frameworks/astro/config").AstroOutput;
    workerCache: boolean;
}, never, never>;
//# sourceMappingURL=AstroOutput.d.ts.map