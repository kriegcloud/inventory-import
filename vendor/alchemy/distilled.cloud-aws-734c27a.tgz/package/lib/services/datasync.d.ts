import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
    readonly errorCode: any;
}>;
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LocationAccessTestFailed_base: S.TaggedErrorClass<"LocationAccessTestFailed", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LocationAccessTestFailed extends /*@__PURE__*/ LocationAccessTestFailed_base {
}
declare const LocationNotFound_base: S.TaggedErrorClass<"LocationNotFound", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class LocationNotFound extends /*@__PURE__*/ LocationNotFound_base {
}
declare const LocationRoleNotAssumable_base: S.TaggedErrorClass<"LocationRoleNotAssumable", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LocationRoleNotAssumable extends /*@__PURE__*/ LocationRoleNotAssumable_base {
}
declare const TaskNotFound_base: S.TaggedErrorClass<"TaskNotFound", {
    readonly message: any;
    readonly errorCode: any;
    readonly datasyncErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class TaskNotFound extends /*@__PURE__*/ TaskNotFound_base {
}
export type TaskExecutionArn = string;
export interface CancelTaskExecutionRequest {
    TaskExecutionArn: string;
}
export interface CancelTaskExecutionResponse {
}
export type ActivationKey = string;
export type TagValue = string;
export type TagKey = string;
export interface TagListEntry {
    Key: string;
    Value?: string | undefined;
}
export type InputTagList = TagListEntry[];
export type VpcEndpointId = string;
export type Ec2SubnetArn = string;
export type PLSubnetArnList = string[];
export type Ec2SecurityGroupArn = string;
export type PLSecurityGroupArnList = string[];
export interface CreateAgentRequest {
    ActivationKey: string;
    AgentName?: string | undefined;
    Tags?: TagListEntry[] | undefined;
    VpcEndpointId?: string | undefined;
    SubnetArns?: string[] | undefined;
    SecurityGroupArns?: string[] | undefined;
}
export type AgentArn = string;
export interface CreateAgentResponse {
    AgentArn?: string | undefined;
}
export type AzureBlobContainerUrl = string;
export type AzureBlobAuthenticationType = "SAS" | "NONE" | "OIDC" | (string & {});
export type AzureBlobSasToken = string | redacted.Redacted<string>;
export interface AzureBlobSasConfiguration {
    Token: string | redacted.Redacted<string>;
}
export type IamRoleArn = string;
export type AzureGuidString = string;
export interface AzureOidcConfig {
    TenantId: string;
    ClientId: string;
}
export interface AzureFederatedIdentityConfig {
    AwsIamRole?: string | undefined;
    AzureOidc?: AzureOidcConfig | undefined;
}
export type AzureBlobType = "BLOCK" | (string & {});
export type AzureAccessTier = "HOT" | "COOL" | "ARCHIVE" | (string & {});
export type AzureBlobSubdirectory = string;
export type AgentArnList = string[];
export type SecretArn = string;
export type KmsKeyArn = string;
export interface CmkSecretConfig {
    SecretArn?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export type IamRoleArnOrEmptyString = string;
export interface CustomSecretConfig {
    SecretArn?: string | undefined;
    SecretAccessRoleArn?: string | undefined;
}
export interface CreateLocationAzureBlobRequest {
    ContainerUrl: string;
    AuthenticationType: AzureBlobAuthenticationType;
    SasConfiguration?: AzureBlobSasConfiguration | undefined;
    FederatedIdentity?: AzureFederatedIdentityConfig | undefined;
    BlobType?: AzureBlobType | undefined;
    AccessTier?: AzureAccessTier | undefined;
    Subdirectory?: string | undefined;
    AgentArns?: string[] | undefined;
    Tags?: TagListEntry[] | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export type LocationArn = string;
export interface CreateLocationAzureBlobResponse {
    LocationArn?: string | undefined;
}
export type EfsSubdirectory = string;
export type EfsFilesystemArn = string;
export type Ec2SecurityGroupArnList = string[];
export interface Ec2Config {
    SubnetArn: string;
    SecurityGroupArns: string[];
}
export type EfsAccessPointArn = string;
export type EfsInTransitEncryption = "NONE" | "TLS1_2" | (string & {});
export interface CreateLocationEfsRequest {
    Subdirectory?: string | undefined;
    EfsFilesystemArn: string;
    Ec2Config: Ec2Config;
    Tags?: TagListEntry[] | undefined;
    AccessPointArn?: string | undefined;
    FileSystemAccessRoleArn?: string | undefined;
    InTransitEncryption?: EfsInTransitEncryption | undefined;
}
export interface CreateLocationEfsResponse {
    LocationArn?: string | undefined;
}
export type FsxFilesystemArn = string;
export type FsxLustreSubdirectory = string;
export interface CreateLocationFsxLustreRequest {
    FsxFilesystemArn: string;
    SecurityGroupArns: string[];
    Subdirectory?: string | undefined;
    Tags?: TagListEntry[] | undefined;
}
export interface CreateLocationFsxLustreResponse {
    LocationArn?: string | undefined;
}
export type NfsVersion = "AUTOMATIC" | "NFS3" | "NFS4_0" | "NFS4_1" | "NFS4_2" | (string & {});
export interface NfsMountOptions {
    Version?: NfsVersion | undefined;
}
export interface FsxProtocolNfs {
    MountOptions?: NfsMountOptions | undefined;
}
export type SmbDomain = string;
export type SmbVersion = "AUTOMATIC" | "SMB2" | "SMB3" | "SMB1" | "SMB2_0" | (string & {});
export interface SmbMountOptions {
    Version?: SmbVersion | undefined;
}
export type SmbPassword = string | redacted.Redacted<string>;
export type SmbUser = string;
export interface ManagedSecretConfig {
    SecretArn?: string | undefined;
}
export interface FsxProtocolSmb {
    Domain?: string | undefined;
    MountOptions?: SmbMountOptions | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    User: string;
    ManagedSecretConfig?: ManagedSecretConfig | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface FsxProtocol {
    NFS?: FsxProtocolNfs | undefined;
    SMB?: FsxProtocolSmb | undefined;
}
export type StorageVirtualMachineArn = string;
export type FsxOntapSubdirectory = string;
export interface CreateLocationFsxOntapRequest {
    Protocol: FsxProtocol;
    SecurityGroupArns: string[];
    StorageVirtualMachineArn: string;
    Subdirectory?: string | undefined;
    Tags?: TagListEntry[] | undefined;
}
export interface CreateLocationFsxOntapResponse {
    LocationArn?: string | undefined;
}
export type FsxOpenZfsSubdirectory = string;
export interface CreateLocationFsxOpenZfsRequest {
    FsxFilesystemArn: string;
    Protocol: FsxProtocol;
    SecurityGroupArns: string[];
    Subdirectory?: string | undefined;
    Tags?: TagListEntry[] | undefined;
}
export interface CreateLocationFsxOpenZfsResponse {
    LocationArn?: string | undefined;
}
export type FsxWindowsSubdirectory = string;
export interface CreateLocationFsxWindowsRequest {
    Subdirectory?: string | undefined;
    FsxFilesystemArn: string;
    SecurityGroupArns: string[];
    Tags?: TagListEntry[] | undefined;
    User: string;
    Domain?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface CreateLocationFsxWindowsResponse {
    LocationArn?: string | undefined;
}
export type HdfsSubdirectory = string;
export type HdfsServerHostname = string;
export type HdfsServerPort = number;
export interface HdfsNameNode {
    Hostname: string;
    Port: number;
}
export type HdfsNameNodeList = HdfsNameNode[];
export type HdfsBlockSize = number;
export type HdfsReplicationFactor = number;
export type KmsKeyProviderUri = string;
export type HdfsRpcProtection = "DISABLED" | "AUTHENTICATION" | "INTEGRITY" | "PRIVACY" | (string & {});
export type HdfsDataTransferProtection = "DISABLED" | "AUTHENTICATION" | "INTEGRITY" | "PRIVACY" | (string & {});
export interface QopConfiguration {
    RpcProtection?: HdfsRpcProtection | undefined;
    DataTransferProtection?: HdfsDataTransferProtection | undefined;
}
export type HdfsAuthenticationType = "SIMPLE" | "KERBEROS" | (string & {});
export type HdfsUser = string;
export type KerberosPrincipal = string;
export type KerberosKeytabFile = Uint8Array;
export type KerberosKrb5ConfFile = Uint8Array;
export interface CreateLocationHdfsRequest {
    Subdirectory?: string | undefined;
    NameNodes: HdfsNameNode[];
    BlockSize?: number | undefined;
    ReplicationFactor?: number | undefined;
    KmsKeyProviderUri?: string | undefined;
    QopConfiguration?: QopConfiguration | undefined;
    AuthenticationType: HdfsAuthenticationType;
    SimpleUser?: string | undefined;
    KerberosPrincipal?: string | undefined;
    KerberosKeytab?: Uint8Array | undefined;
    KerberosKrb5Conf?: Uint8Array | undefined;
    AgentArns: string[];
    Tags?: TagListEntry[] | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface CreateLocationHdfsResponse {
    LocationArn?: string | undefined;
}
export type NfsSubdirectory = string;
export type ServerHostname = string;
export interface OnPremConfig {
    AgentArns: string[];
}
export interface CreateLocationNfsRequest {
    Subdirectory: string;
    ServerHostname: string;
    OnPremConfig: OnPremConfig;
    MountOptions?: NfsMountOptions | undefined;
    Tags?: TagListEntry[] | undefined;
}
export interface CreateLocationNfsResponse {
    LocationArn?: string | undefined;
}
export type ObjectStorageServerPort = number;
export type ObjectStorageServerProtocol = "HTTPS" | "HTTP" | (string & {});
export type S3Subdirectory = string;
export type ObjectStorageBucketName = string;
export type ObjectStorageAccessKey = string;
export type ObjectStorageSecretKey = string | redacted.Redacted<string>;
export type ProjectNameString = string;
export type ProjectNumberString = string;
export type GoogleIdentityFederationResourceString = string;
export interface GoogleOidcConfig {
    ProjectName: string;
    ProjectNumber: string;
    IdentityPoolName: string;
    IdentityProviderName: string;
}
export interface ObjectStorageExternalIdentityConfig {
    GoogleOidc?: GoogleOidcConfig | undefined;
}
export interface ObjectStorageFederatedIdentityConfig {
    AwsIamRole?: string | undefined;
    ExternalIdentity?: ObjectStorageExternalIdentityConfig | undefined;
}
export type ObjectStorageCertificate = Uint8Array;
export interface CreateLocationObjectStorageRequest {
    ServerHostname: string;
    ServerPort?: number | undefined;
    ServerProtocol?: ObjectStorageServerProtocol | undefined;
    Subdirectory?: string | undefined;
    BucketName: string;
    AccessKey?: string | undefined;
    SecretKey?: string | redacted.Redacted<string> | undefined;
    FederatedIdentity?: ObjectStorageFederatedIdentityConfig | undefined;
    AgentArns?: string[] | undefined;
    Tags?: TagListEntry[] | undefined;
    ServerCertificate?: Uint8Array | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface CreateLocationObjectStorageResponse {
    LocationArn?: string | undefined;
}
export type S3BucketArn = string;
export type S3StorageClass = "STANDARD" | "STANDARD_IA" | "ONEZONE_IA" | "INTELLIGENT_TIERING" | "GLACIER" | "DEEP_ARCHIVE" | "OUTPOSTS" | "GLACIER_INSTANT_RETRIEVAL" | (string & {});
export interface S3Config {
    BucketAccessRoleArn: string;
}
export interface CreateLocationS3Request {
    Subdirectory?: string | undefined;
    S3BucketArn: string;
    S3StorageClass?: S3StorageClass | undefined;
    S3Config: S3Config;
    AgentArns?: string[] | undefined;
    Tags?: TagListEntry[] | undefined;
}
export interface CreateLocationS3Response {
    LocationArn?: string | undefined;
}
export type SmbSubdirectory = string;
export type SmbAuthenticationType = "NTLM" | "KERBEROS" | (string & {});
export type ServerIpAddress = string;
export type DnsIpList = string[];
export interface CreateLocationSmbRequest {
    Subdirectory: string;
    ServerHostname: string;
    User?: string | undefined;
    Domain?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
    AgentArns: string[];
    MountOptions?: SmbMountOptions | undefined;
    Tags?: TagListEntry[] | undefined;
    AuthenticationType?: SmbAuthenticationType | undefined;
    DnsIpAddresses?: string[] | undefined;
    KerberosPrincipal?: string | undefined;
    KerberosKeytab?: Uint8Array | undefined;
    KerberosKrb5Conf?: Uint8Array | undefined;
}
export interface CreateLocationSmbResponse {
    LocationArn?: string | undefined;
}
export type LogGroupArn = string;
export type VerifyMode = "POINT_IN_TIME_CONSISTENT" | "ONLY_FILES_TRANSFERRED" | "NONE" | (string & {});
export type OverwriteMode = "ALWAYS" | "NEVER" | (string & {});
export type Atime = "NONE" | "BEST_EFFORT" | (string & {});
export type Mtime = "NONE" | "PRESERVE" | (string & {});
export type Uid = "NONE" | "INT_VALUE" | "NAME" | "BOTH" | (string & {});
export type Gid = "NONE" | "INT_VALUE" | "NAME" | "BOTH" | (string & {});
export type PreserveDeletedFiles = "PRESERVE" | "REMOVE" | (string & {});
export type PreserveDevices = "NONE" | "PRESERVE" | (string & {});
export type PosixPermissions = "NONE" | "PRESERVE" | (string & {});
export type BytesPerSecond = number;
export type TaskQueueing = "ENABLED" | "DISABLED" | (string & {});
export type LogLevel = "OFF" | "BASIC" | "TRANSFER" | (string & {});
export type TransferMode = "CHANGED" | "ALL" | (string & {});
export type SmbSecurityDescriptorCopyFlags = "NONE" | "OWNER_DACL" | "OWNER_DACL_SACL" | (string & {});
export type ObjectTags = "PRESERVE" | "NONE" | (string & {});
export type ObjectMetadata = "PRESERVE" | "NONE" | (string & {});
export interface Options {
    VerifyMode?: VerifyMode | undefined;
    OverwriteMode?: OverwriteMode | undefined;
    Atime?: Atime | undefined;
    Mtime?: Mtime | undefined;
    Uid?: Uid | undefined;
    Gid?: Gid | undefined;
    PreserveDeletedFiles?: PreserveDeletedFiles | undefined;
    PreserveDevices?: PreserveDevices | undefined;
    PosixPermissions?: PosixPermissions | undefined;
    BytesPerSecond?: number | undefined;
    TaskQueueing?: TaskQueueing | undefined;
    LogLevel?: LogLevel | undefined;
    TransferMode?: TransferMode | undefined;
    SecurityDescriptorCopyFlags?: SmbSecurityDescriptorCopyFlags | undefined;
    ObjectTags?: ObjectTags | undefined;
    ObjectMetadata?: ObjectMetadata | undefined;
}
export type FilterType = "SIMPLE_PATTERN" | (string & {});
export type FilterValue = string;
export interface FilterRule {
    FilterType?: FilterType | undefined;
    Value?: string | undefined;
}
export type FilterList = FilterRule[];
export type ScheduleExpressionCron = string;
export type ScheduleStatus = "ENABLED" | "DISABLED" | (string & {});
export interface TaskSchedule {
    ScheduleExpression: string;
    Status?: ScheduleStatus | undefined;
}
export type ManifestAction = "TRANSFER" | (string & {});
export type ManifestFormat = "CSV" | (string & {});
export type S3ObjectVersionId = string;
export interface S3ManifestConfig {
    ManifestObjectPath: string;
    BucketAccessRoleArn: string;
    S3BucketArn: string;
    ManifestObjectVersionId?: string | undefined;
}
export interface SourceManifestConfig {
    S3: S3ManifestConfig;
}
export interface ManifestConfig {
    Action?: ManifestAction | undefined;
    Format?: ManifestFormat | undefined;
    Source?: SourceManifestConfig | undefined;
}
export interface ReportDestinationS3 {
    Subdirectory?: string | undefined;
    S3BucketArn: string;
    BucketAccessRoleArn: string;
}
export interface ReportDestination {
    S3?: ReportDestinationS3 | undefined;
}
export type ReportOutputType = "SUMMARY_ONLY" | "STANDARD" | (string & {});
export type ReportLevel = "ERRORS_ONLY" | "SUCCESSES_AND_ERRORS" | (string & {});
export type ObjectVersionIds = "INCLUDE" | "NONE" | (string & {});
export interface ReportOverride {
    ReportLevel?: ReportLevel | undefined;
}
export interface ReportOverrides {
    Transferred?: ReportOverride | undefined;
    Verified?: ReportOverride | undefined;
    Deleted?: ReportOverride | undefined;
    Skipped?: ReportOverride | undefined;
}
export interface TaskReportConfig {
    Destination?: ReportDestination | undefined;
    OutputType?: ReportOutputType | undefined;
    ReportLevel?: ReportLevel | undefined;
    ObjectVersionIds?: ObjectVersionIds | undefined;
    Overrides?: ReportOverrides | undefined;
}
export type TaskMode = "BASIC" | "ENHANCED" | (string & {});
export interface CreateTaskRequest {
    SourceLocationArn: string;
    DestinationLocationArn: string;
    CloudWatchLogGroupArn?: string | undefined;
    Name?: string | undefined;
    Options?: Options | undefined;
    Excludes?: FilterRule[] | undefined;
    Schedule?: TaskSchedule | undefined;
    Tags?: TagListEntry[] | undefined;
    Includes?: FilterRule[] | undefined;
    ManifestConfig?: ManifestConfig | undefined;
    TaskReportConfig?: TaskReportConfig | undefined;
    TaskMode?: TaskMode | undefined;
}
export type TaskArn = string;
export interface CreateTaskResponse {
    TaskArn?: string | undefined;
}
export interface DeleteAgentRequest {
    AgentArn: string;
}
export interface DeleteAgentResponse {
}
export interface DeleteLocationRequest {
    LocationArn: string;
}
export interface DeleteLocationResponse {
}
export interface DeleteTaskRequest {
    TaskArn: string;
}
export interface DeleteTaskResponse {
}
export interface DescribeAgentRequest {
    AgentArn: string;
}
export type AgentStatus = "ONLINE" | "OFFLINE" | (string & {});
export type EndpointType = "PUBLIC" | "PRIVATE_LINK" | "FIPS" | "FIPS_PRIVATE_LINK" | (string & {});
export type Endpoint = string;
export interface PrivateLinkConfig {
    VpcEndpointId?: string | undefined;
    PrivateLinkEndpoint?: string | undefined;
    SubnetArns?: string[] | undefined;
    SecurityGroupArns?: string[] | undefined;
}
export type AgentVersion = string;
export interface Platform {
    Version?: string | undefined;
}
export interface DescribeAgentResponse {
    AgentArn?: string | undefined;
    Name?: string | undefined;
    Status?: AgentStatus | undefined;
    LastConnectionTime?: Date | undefined;
    CreationTime?: Date | undefined;
    EndpointType?: EndpointType | undefined;
    PrivateLinkConfig?: PrivateLinkConfig | undefined;
    Platform?: Platform | undefined;
}
export interface DescribeLocationAzureBlobRequest {
    LocationArn: string;
}
export type LocationUri = string;
export interface DescribeLocationAzureBlobResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    AuthenticationType?: AzureBlobAuthenticationType | undefined;
    FederatedIdentity?: AzureFederatedIdentityConfig | undefined;
    BlobType?: AzureBlobType | undefined;
    AccessTier?: AzureAccessTier | undefined;
    AgentArns?: string[] | undefined;
    CreationTime?: Date | undefined;
    ManagedSecretConfig?: ManagedSecretConfig | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface DescribeLocationEfsRequest {
    LocationArn: string;
}
export interface DescribeLocationEfsResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    Ec2Config?: Ec2Config | undefined;
    CreationTime?: Date | undefined;
    AccessPointArn?: string | undefined;
    FileSystemAccessRoleArn?: string | undefined;
    InTransitEncryption?: EfsInTransitEncryption | undefined;
}
export interface DescribeLocationFsxLustreRequest {
    LocationArn: string;
}
export interface DescribeLocationFsxLustreResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    SecurityGroupArns?: string[] | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribeLocationFsxOntapRequest {
    LocationArn: string;
}
export interface DescribeLocationFsxOntapResponse {
    CreationTime?: Date | undefined;
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    Protocol?: FsxProtocol | undefined;
    SecurityGroupArns?: string[] | undefined;
    StorageVirtualMachineArn?: string | undefined;
    FsxFilesystemArn?: string | undefined;
}
export interface DescribeLocationFsxOpenZfsRequest {
    LocationArn: string;
}
export interface DescribeLocationFsxOpenZfsResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    SecurityGroupArns?: string[] | undefined;
    Protocol?: FsxProtocol | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribeLocationFsxWindowsRequest {
    LocationArn: string;
}
export interface DescribeLocationFsxWindowsResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    SecurityGroupArns?: string[] | undefined;
    CreationTime?: Date | undefined;
    User?: string | undefined;
    Domain?: string | undefined;
    ManagedSecretConfig?: ManagedSecretConfig | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface DescribeLocationHdfsRequest {
    LocationArn: string;
}
export interface DescribeLocationHdfsResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    NameNodes?: HdfsNameNode[] | undefined;
    BlockSize?: number | undefined;
    ReplicationFactor?: number | undefined;
    KmsKeyProviderUri?: string | undefined;
    QopConfiguration?: QopConfiguration | undefined;
    AuthenticationType?: HdfsAuthenticationType | undefined;
    SimpleUser?: string | undefined;
    KerberosPrincipal?: string | undefined;
    AgentArns?: string[] | undefined;
    CreationTime?: Date | undefined;
    ManagedSecretConfig?: ManagedSecretConfig | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface DescribeLocationNfsRequest {
    LocationArn: string;
}
export interface DescribeLocationNfsResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    OnPremConfig?: OnPremConfig | undefined;
    MountOptions?: NfsMountOptions | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribeLocationObjectStorageRequest {
    LocationArn: string;
}
export interface DescribeLocationObjectStorageResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    AccessKey?: string | undefined;
    FederatedIdentity?: ObjectStorageFederatedIdentityConfig | undefined;
    ServerPort?: number | undefined;
    ServerProtocol?: ObjectStorageServerProtocol | undefined;
    AgentArns?: string[] | undefined;
    CreationTime?: Date | undefined;
    ServerCertificate?: Uint8Array | undefined;
    ManagedSecretConfig?: ManagedSecretConfig | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface DescribeLocationS3Request {
    LocationArn: string;
}
export interface DescribeLocationS3Response {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    S3StorageClass?: S3StorageClass | undefined;
    S3Config?: S3Config | undefined;
    AgentArns?: string[] | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribeLocationSmbRequest {
    LocationArn: string;
}
export interface DescribeLocationSmbResponse {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
    AgentArns?: string[] | undefined;
    User?: string | undefined;
    Domain?: string | undefined;
    MountOptions?: SmbMountOptions | undefined;
    CreationTime?: Date | undefined;
    DnsIpAddresses?: string[] | undefined;
    KerberosPrincipal?: string | undefined;
    AuthenticationType?: SmbAuthenticationType | undefined;
    ManagedSecretConfig?: ManagedSecretConfig | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface DescribeTaskRequest {
    TaskArn: string;
}
export type TaskStatus = "AVAILABLE" | "CREATING" | "QUEUED" | "RUNNING" | "UNAVAILABLE" | (string & {});
export type NetworkInterfaceArn = string;
export type SourceNetworkInterfaceArns = string[];
export type DestinationNetworkInterfaceArns = string[];
export type ScheduleDisabledReason = string;
export type ScheduleDisabledBy = "USER" | "SERVICE" | (string & {});
export interface TaskScheduleDetails {
    StatusUpdateTime?: Date | undefined;
    DisabledReason?: string | undefined;
    DisabledBy?: ScheduleDisabledBy | undefined;
}
export interface DescribeTaskResponse {
    TaskArn?: string | undefined;
    Status?: TaskStatus | undefined;
    Name?: string | undefined;
    CurrentTaskExecutionArn?: string | undefined;
    SourceLocationArn?: string | undefined;
    DestinationLocationArn?: string | undefined;
    CloudWatchLogGroupArn?: string | undefined;
    SourceNetworkInterfaceArns?: string[] | undefined;
    DestinationNetworkInterfaceArns?: string[] | undefined;
    Options?: Options | undefined;
    Excludes?: FilterRule[] | undefined;
    Schedule?: TaskSchedule | undefined;
    ErrorCode?: string | undefined;
    ErrorDetail?: string | undefined;
    CreationTime?: Date | undefined;
    Includes?: FilterRule[] | undefined;
    ManifestConfig?: ManifestConfig | undefined;
    TaskReportConfig?: TaskReportConfig | undefined;
    ScheduleDetails?: TaskScheduleDetails | undefined;
    TaskMode?: TaskMode | undefined;
}
export interface DescribeTaskExecutionRequest {
    TaskExecutionArn: string;
}
export type TaskExecutionStatus = "QUEUED" | "CANCELLING" | "LAUNCHING" | "PREPARING" | "TRANSFERRING" | "VERIFYING" | "SUCCESS" | "ERROR" | (string & {});
export type Duration = number;
export type PhaseStatus = "PENDING" | "SUCCESS" | "ERROR" | (string & {});
export interface TaskExecutionResultDetail {
    PrepareDuration?: number | undefined;
    PrepareStatus?: PhaseStatus | undefined;
    TotalDuration?: number | undefined;
    TransferDuration?: number | undefined;
    TransferStatus?: PhaseStatus | undefined;
    VerifyDuration?: number | undefined;
    VerifyStatus?: PhaseStatus | undefined;
    ErrorCode?: string | undefined;
    ErrorDetail?: string | undefined;
}
export interface ReportResult {
    Status?: PhaseStatus | undefined;
    ErrorCode?: string | undefined;
    ErrorDetail?: string | undefined;
}
export interface TaskExecutionFilesListedDetail {
    AtSource?: number | undefined;
    AtDestinationForDelete?: number | undefined;
}
export interface TaskExecutionFilesFailedDetail {
    Prepare?: number | undefined;
    Transfer?: number | undefined;
    Verify?: number | undefined;
    Delete?: number | undefined;
}
export type ItemCount = number;
export interface TaskExecutionFoldersListedDetail {
    AtSource?: number | undefined;
    AtDestinationForDelete?: number | undefined;
}
export interface TaskExecutionFoldersFailedDetail {
    List?: number | undefined;
    Prepare?: number | undefined;
    Transfer?: number | undefined;
    Verify?: number | undefined;
    Delete?: number | undefined;
}
export interface DescribeTaskExecutionResponse {
    TaskExecutionArn?: string | undefined;
    Status?: TaskExecutionStatus | undefined;
    Options?: Options | undefined;
    Excludes?: FilterRule[] | undefined;
    Includes?: FilterRule[] | undefined;
    ManifestConfig?: ManifestConfig | undefined;
    StartTime?: Date | undefined;
    EstimatedFilesToTransfer?: number | undefined;
    EstimatedBytesToTransfer?: number | undefined;
    FilesTransferred?: number | undefined;
    BytesWritten?: number | undefined;
    BytesTransferred?: number | undefined;
    BytesCompressed?: number | undefined;
    Result?: TaskExecutionResultDetail | undefined;
    TaskReportConfig?: TaskReportConfig | undefined;
    FilesDeleted?: number | undefined;
    FilesSkipped?: number | undefined;
    FilesVerified?: number | undefined;
    ReportResult?: ReportResult | undefined;
    EstimatedFilesToDelete?: number | undefined;
    TaskMode?: TaskMode | undefined;
    FilesPrepared?: number | undefined;
    FilesListed?: TaskExecutionFilesListedDetail | undefined;
    FilesFailed?: TaskExecutionFilesFailedDetail | undefined;
    EstimatedFoldersToDelete?: number | undefined;
    EstimatedFoldersToTransfer?: number | undefined;
    FoldersSkipped?: number | undefined;
    FoldersPrepared?: number | undefined;
    FoldersTransferred?: number | undefined;
    FoldersVerified?: number | undefined;
    FoldersDeleted?: number | undefined;
    FoldersListed?: TaskExecutionFoldersListedDetail | undefined;
    FoldersFailed?: TaskExecutionFoldersFailedDetail | undefined;
    LaunchTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAgentsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AgentListEntry {
    AgentArn?: string | undefined;
    Name?: string | undefined;
    Status?: AgentStatus | undefined;
    Platform?: Platform | undefined;
}
export type AgentList = AgentListEntry[];
export interface ListAgentsResponse {
    Agents?: AgentListEntry[] | undefined;
    NextToken?: string | undefined;
}
export type LocationFilterName = "LocationUri" | "LocationType" | "CreationTime" | (string & {});
export type FilterAttributeValue = string;
export type FilterValues = string[];
export type Operator = "Equals" | "NotEquals" | "In" | "LessThanOrEqual" | "LessThan" | "GreaterThanOrEqual" | "GreaterThan" | "Contains" | "NotContains" | "BeginsWith" | (string & {});
export interface LocationFilter {
    Name: LocationFilterName;
    Values: string[];
    Operator: Operator;
}
export type LocationFilters = LocationFilter[];
export interface ListLocationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: LocationFilter[] | undefined;
}
export interface LocationListEntry {
    LocationArn?: string | undefined;
    LocationUri?: string | undefined;
}
export type LocationList = LocationListEntry[];
export interface ListLocationsResponse {
    Locations?: LocationListEntry[] | undefined;
    NextToken?: string | undefined;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type OutputTagList = TagListEntry[];
export interface ListTagsForResourceResponse {
    Tags?: TagListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTaskExecutionsRequest {
    TaskArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface TaskExecutionListEntry {
    TaskExecutionArn?: string | undefined;
    Status?: TaskExecutionStatus | undefined;
    TaskMode?: TaskMode | undefined;
}
export type TaskExecutionList = TaskExecutionListEntry[];
export interface ListTaskExecutionsResponse {
    TaskExecutions?: TaskExecutionListEntry[] | undefined;
    NextToken?: string | undefined;
}
export type TaskFilterName = "LocationId" | "CreationTime" | (string & {});
export interface TaskFilter {
    Name: TaskFilterName;
    Values: string[];
    Operator: Operator;
}
export type TaskFilters = TaskFilter[];
export interface ListTasksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: TaskFilter[] | undefined;
}
export interface TaskListEntry {
    TaskArn?: string | undefined;
    Status?: TaskStatus | undefined;
    Name?: string | undefined;
    TaskMode?: TaskMode | undefined;
}
export type TaskList = TaskListEntry[];
export interface ListTasksResponse {
    Tasks?: TaskListEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface StartTaskExecutionRequest {
    TaskArn: string;
    OverrideOptions?: Options | undefined;
    Includes?: FilterRule[] | undefined;
    Excludes?: FilterRule[] | undefined;
    ManifestConfig?: ManifestConfig | undefined;
    TaskReportConfig?: TaskReportConfig | undefined;
    Tags?: TagListEntry[] | undefined;
}
export interface StartTaskExecutionResponse {
    TaskExecutionArn?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: TagListEntry[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    Keys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAgentRequest {
    AgentArn: string;
    Name?: string | undefined;
}
export interface UpdateAgentResponse {
}
export interface UpdateLocationAzureBlobRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
    AuthenticationType?: AzureBlobAuthenticationType | undefined;
    SasConfiguration?: AzureBlobSasConfiguration | undefined;
    FederatedIdentity?: AzureFederatedIdentityConfig | undefined;
    BlobType?: AzureBlobType | undefined;
    AccessTier?: AzureAccessTier | undefined;
    AgentArns?: string[] | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface UpdateLocationAzureBlobResponse {
}
export type UpdatedEfsAccessPointArn = string;
export type UpdatedEfsIamRoleArn = string;
export interface UpdateLocationEfsRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
    AccessPointArn?: string | undefined;
    FileSystemAccessRoleArn?: string | undefined;
    InTransitEncryption?: EfsInTransitEncryption | undefined;
}
export interface UpdateLocationEfsResponse {
}
export interface UpdateLocationFsxLustreRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
}
export interface UpdateLocationFsxLustreResponse {
}
export type UpdateSmbDomain = string;
export interface FsxUpdateProtocolSmb {
    Domain?: string | undefined;
    MountOptions?: SmbMountOptions | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    User?: string | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface FsxUpdateProtocol {
    NFS?: FsxProtocolNfs | undefined;
    SMB?: FsxUpdateProtocolSmb | undefined;
}
export interface UpdateLocationFsxOntapRequest {
    LocationArn: string;
    Protocol?: FsxUpdateProtocol | undefined;
    Subdirectory?: string | undefined;
}
export interface UpdateLocationFsxOntapResponse {
}
export interface UpdateLocationFsxOpenZfsRequest {
    LocationArn: string;
    Protocol?: FsxProtocol | undefined;
    Subdirectory?: string | undefined;
}
export interface UpdateLocationFsxOpenZfsResponse {
}
export interface UpdateLocationFsxWindowsRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
    Domain?: string | undefined;
    User?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface UpdateLocationFsxWindowsResponse {
}
export interface UpdateLocationHdfsRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
    NameNodes?: HdfsNameNode[] | undefined;
    BlockSize?: number | undefined;
    ReplicationFactor?: number | undefined;
    KmsKeyProviderUri?: string | undefined;
    QopConfiguration?: QopConfiguration | undefined;
    AuthenticationType?: HdfsAuthenticationType | undefined;
    SimpleUser?: string | undefined;
    KerberosPrincipal?: string | undefined;
    KerberosKeytab?: Uint8Array | undefined;
    KerberosKrb5Conf?: Uint8Array | undefined;
    AgentArns?: string[] | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface UpdateLocationHdfsResponse {
}
export interface UpdateLocationNfsRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
    ServerHostname?: string | undefined;
    OnPremConfig?: OnPremConfig | undefined;
    MountOptions?: NfsMountOptions | undefined;
}
export interface UpdateLocationNfsResponse {
}
export interface UpdateLocationObjectStorageRequest {
    LocationArn: string;
    ServerPort?: number | undefined;
    ServerProtocol?: ObjectStorageServerProtocol | undefined;
    Subdirectory?: string | undefined;
    ServerHostname?: string | undefined;
    AccessKey?: string | undefined;
    SecretKey?: string | redacted.Redacted<string> | undefined;
    FederatedIdentity?: ObjectStorageFederatedIdentityConfig | undefined;
    AgentArns?: string[] | undefined;
    ServerCertificate?: Uint8Array | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
}
export interface UpdateLocationObjectStorageResponse {
}
export interface UpdateLocationS3Request {
    LocationArn: string;
    Subdirectory?: string | undefined;
    S3StorageClass?: S3StorageClass | undefined;
    S3Config?: S3Config | undefined;
}
export interface UpdateLocationS3Response {
}
export interface UpdateLocationSmbRequest {
    LocationArn: string;
    Subdirectory?: string | undefined;
    ServerHostname?: string | undefined;
    User?: string | undefined;
    Domain?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    CmkSecretConfig?: CmkSecretConfig | undefined;
    CustomSecretConfig?: CustomSecretConfig | undefined;
    AgentArns?: string[] | undefined;
    MountOptions?: SmbMountOptions | undefined;
    AuthenticationType?: SmbAuthenticationType | undefined;
    DnsIpAddresses?: string[] | undefined;
    KerberosPrincipal?: string | undefined;
    KerberosKeytab?: Uint8Array | undefined;
    KerberosKrb5Conf?: Uint8Array | undefined;
}
export interface UpdateLocationSmbResponse {
}
export interface UpdateTaskRequest {
    TaskArn: string;
    Options?: Options | undefined;
    Excludes?: FilterRule[] | undefined;
    Schedule?: TaskSchedule | undefined;
    Name?: string | undefined;
    CloudWatchLogGroupArn?: string | undefined;
    Includes?: FilterRule[] | undefined;
    ManifestConfig?: ManifestConfig | undefined;
    TaskReportConfig?: TaskReportConfig | undefined;
}
export interface UpdateTaskResponse {
}
export interface UpdateTaskExecutionRequest {
    TaskExecutionArn: string;
    Options: Options;
}
export interface UpdateTaskExecutionResponse {
}
export type CancelTaskExecutionError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Stops an DataSync task execution that's in progress. The transfer of some
 * files are abruptly interrupted. File contents that're transferred to the destination might be
 * incomplete or inconsistent with the source files.
 *
 * However, if you start a new task execution using the same task and allow it to finish,
 * file content on the destination will be complete and consistent. This applies to other
 * unexpected failures that interrupt a task execution. In all of these cases, DataSync
 * successfully completes the transfer when you start the next task execution.
 */
export declare const cancelTaskExecution: API.OperationMethod<CancelTaskExecutionRequest & RegionInput, CancelTaskExecutionResponse, CancelTaskExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Activates an DataSync agent that you deploy in your storage environment.
 * The activation process associates the agent with your Amazon Web Services account.
 *
 * If you haven't deployed an agent yet, see Do I need a DataSync
 * agent?
 */
export declare const createAgent: API.OperationMethod<CreateAgentRequest & RegionInput, CreateAgentResponse, CreateAgentError, Credentials | HttpClient.HttpClient>;
export type CreateLocationAzureBlobError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Microsoft Azure Blob Storage
 * container. DataSync can use this location as a transfer source or destination.
 * You can make transfers with or without a DataSync agent that connects to your
 * container.
 *
 * Before you begin, make sure you know how DataSync accesses Azure Blob Storage and works with access tiers and blob types.
 */
export declare const createLocationAzureBlob: API.OperationMethod<CreateLocationAzureBlobRequest & RegionInput, CreateLocationAzureBlobResponse, CreateLocationAzureBlobError, Credentials | HttpClient.HttpClient>;
export type CreateLocationEfsError = InternalException | InvalidRequestException | LocationRoleNotAssumable | LocationAccessTestFailed | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon EFS file system.
 * DataSync can use this location as a source or destination for transferring
 * data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses
 * Amazon EFS file systems.
 */
export declare const createLocationEfs: API.OperationMethod<CreateLocationEfsRequest & RegionInput, CreateLocationEfsResponse, CreateLocationEfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxLustreError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for Lustre file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses FSx for Lustre file systems.
 */
export declare const createLocationFsxLustre: API.OperationMethod<CreateLocationFsxLustreRequest & RegionInput, CreateLocationFsxLustreResponse, CreateLocationFsxLustreError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxOntapError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for NetApp ONTAP file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses FSx for ONTAP file systems.
 */
export declare const createLocationFsxOntap: API.OperationMethod<CreateLocationFsxOntapRequest & RegionInput, CreateLocationFsxOntapResponse, CreateLocationFsxOntapError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxOpenZfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for OpenZFS file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses
 * FSx for OpenZFS file systems.
 *
 * Request parameters related to `SMB` aren't supported with the
 * `CreateLocationFsxOpenZfs` operation.
 */
export declare const createLocationFsxOpenZfs: API.OperationMethod<CreateLocationFsxOpenZfsRequest & RegionInput, CreateLocationFsxOpenZfsResponse, CreateLocationFsxOpenZfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationFsxWindowsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon FSx for Windows File Server file
 * system. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses
 * FSx for Windows File Server file systems.
 */
export declare const createLocationFsxWindows: API.OperationMethod<CreateLocationFsxWindowsRequest & RegionInput, CreateLocationFsxWindowsResponse, CreateLocationFsxWindowsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationHdfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Hadoop Distributed File System
 * (HDFS). DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses HDFS
 * clusters.
 */
export declare const createLocationHdfs: API.OperationMethod<CreateLocationHdfsRequest & RegionInput, CreateLocationHdfsResponse, CreateLocationHdfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationNfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Network File System (NFS) file
 * server. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync
 * accesses NFS file
 * servers.
 */
export declare const createLocationNfs: API.OperationMethod<CreateLocationNfsRequest & RegionInput, CreateLocationNfsResponse, CreateLocationNfsError, Credentials | HttpClient.HttpClient>;
export type CreateLocationObjectStorageError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for an object storage system. DataSync can use this location as a source or destination for transferring data. You
 * can make transfers with or without a DataSync
 * agent.
 *
 * Before you begin, make sure that you understand the prerequisites for DataSync to work with object storage systems.
 */
export declare const createLocationObjectStorage: API.OperationMethod<CreateLocationObjectStorageRequest & RegionInput, CreateLocationObjectStorageResponse, CreateLocationObjectStorageError, Credentials | HttpClient.HttpClient>;
export type CreateLocationS3Error = InternalException | InvalidRequestException | LocationRoleNotAssumable | LocationAccessTestFailed | CommonErrors;
/**
 * Creates a transfer *location* for an Amazon S3 bucket.
 * DataSync can use this location as a source or destination for transferring
 * data.
 *
 * Before you begin, make sure that you read the following topics:
 *
 * - Storage
 * class considerations with Amazon S3 locations
 *
 * - Evaluating S3 request costs when using DataSync
 *
 * For more information, see Configuring
 * transfers with Amazon S3.
 */
export declare const createLocationS3: API.OperationMethod<CreateLocationS3Request & RegionInput, CreateLocationS3Response, CreateLocationS3Error, Credentials | HttpClient.HttpClient>;
export type CreateLocationSmbError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Creates a transfer *location* for a Server Message Block (SMB) file
 * server. DataSync can use this location as a source or destination for
 * transferring data.
 *
 * Before you begin, make sure that you understand how DataSync accesses SMB
 * file servers. For more information, see Providing DataSync access to SMB file servers.
 */
export declare const createLocationSmb: API.OperationMethod<CreateLocationSmbRequest & RegionInput, CreateLocationSmbResponse, CreateLocationSmbError, Credentials | HttpClient.HttpClient>;
export type CreateTaskError = InternalException | InvalidRequestException | LocationAccessTestFailed | CommonErrors;
/**
 * Configures a *task*, which defines where and how DataSync
 * transfers your data.
 *
 * A task includes a source location, destination location, and transfer options (such as
 * bandwidth limits, scheduling, and more).
 *
 * If you're planning to transfer data to or from an Amazon S3 location, review
 * how
 * DataSync can affect your S3 request charges and the DataSync pricing page before
 * you begin.
 */
export declare const createTask: API.OperationMethod<CreateTaskRequest & RegionInput, CreateTaskResponse, CreateTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Removes an DataSync agent resource from your Amazon Web Services account.
 *
 * Keep in mind that this operation (which can't be undone) doesn't remove the agent's
 * virtual machine (VM) or Amazon EC2 instance from your storage environment. For next
 * steps, you can delete the VM or instance from your storage environment or reuse it to activate a new
 * agent.
 */
export declare const deleteAgent: API.OperationMethod<DeleteAgentRequest & RegionInput, DeleteAgentResponse, DeleteAgentError, Credentials | HttpClient.HttpClient>;
export type DeleteLocationError = InternalException | InvalidRequestException | LocationNotFound | CommonErrors;
/**
 * Deletes a transfer location resource from DataSync.
 */
export declare const deleteLocation: API.OperationMethod<DeleteLocationRequest & RegionInput, DeleteLocationResponse, DeleteLocationError, Credentials | HttpClient.HttpClient>;
export type DeleteTaskError = InternalException | InvalidRequestException | TaskNotFound | CommonErrors;
/**
 * Deletes a transfer task resource from DataSync.
 */
export declare const deleteTask: API.OperationMethod<DeleteTaskRequest & RegionInput, DeleteTaskResponse, DeleteTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns information about an DataSync agent, such as its name, service
 * endpoint type, and status.
 */
export declare const describeAgent: API.OperationMethod<DescribeAgentRequest & RegionInput, DescribeAgentResponse, DescribeAgentError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationAzureBlobError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for Microsoft Azure
 * Blob Storage is configured.
 */
export declare const describeLocationAzureBlob: API.OperationMethod<DescribeLocationAzureBlobRequest & RegionInput, DescribeLocationAzureBlobResponse, DescribeLocationAzureBlobError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationEfsError = InternalException | InvalidRequestException | LocationNotFound | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon EFS file system is configured.
 */
export declare const describeLocationEfs: API.OperationMethod<DescribeLocationEfsRequest & RegionInput, DescribeLocationEfsResponse, DescribeLocationEfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxLustreError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for Lustre file system is configured.
 */
export declare const describeLocationFsxLustre: API.OperationMethod<DescribeLocationFsxLustreRequest & RegionInput, DescribeLocationFsxLustreResponse, DescribeLocationFsxLustreError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxOntapError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for NetApp ONTAP file system is configured.
 *
 * If your location uses SMB, the `DescribeLocationFsxOntap` operation doesn't
 * actually return a `Password`.
 */
export declare const describeLocationFsxOntap: API.OperationMethod<DescribeLocationFsxOntapRequest & RegionInput, DescribeLocationFsxOntapResponse, DescribeLocationFsxOntapError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxOpenZfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for OpenZFS file system is configured.
 *
 * Response elements related to `SMB` aren't supported with the
 * `DescribeLocationFsxOpenZfs` operation.
 */
export declare const describeLocationFsxOpenZfs: API.OperationMethod<DescribeLocationFsxOpenZfsRequest & RegionInput, DescribeLocationFsxOpenZfsResponse, DescribeLocationFsxOpenZfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationFsxWindowsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an Amazon FSx for Windows File Server file system is configured.
 */
export declare const describeLocationFsxWindows: API.OperationMethod<DescribeLocationFsxWindowsRequest & RegionInput, DescribeLocationFsxWindowsResponse, DescribeLocationFsxWindowsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationHdfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for a Hadoop
 * Distributed File System (HDFS) is configured.
 */
export declare const describeLocationHdfs: API.OperationMethod<DescribeLocationHdfsRequest & RegionInput, DescribeLocationHdfsResponse, DescribeLocationHdfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationNfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for a Network
 * File System (NFS) file server is configured.
 */
export declare const describeLocationNfs: API.OperationMethod<DescribeLocationNfsRequest & RegionInput, DescribeLocationNfsResponse, DescribeLocationNfsError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationObjectStorageError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an object
 * storage system is configured.
 */
export declare const describeLocationObjectStorage: API.OperationMethod<DescribeLocationObjectStorageRequest & RegionInput, DescribeLocationObjectStorageResponse, DescribeLocationObjectStorageError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationS3Error = InternalException | InvalidRequestException | LocationNotFound | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for an S3 bucket
 * is configured.
 */
export declare const describeLocationS3: API.OperationMethod<DescribeLocationS3Request & RegionInput, DescribeLocationS3Response, DescribeLocationS3Error, Credentials | HttpClient.HttpClient>;
export type DescribeLocationSmbError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides details about how an DataSync transfer location for a Server
 * Message Block (SMB) file server is configured.
 */
export declare const describeLocationSmb: API.OperationMethod<DescribeLocationSmbRequest & RegionInput, DescribeLocationSmbResponse, DescribeLocationSmbError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskError = InternalException | InvalidRequestException | TaskNotFound | CommonErrors;
/**
 * Provides information about a *task*, which defines where and how
 * DataSync transfers your data.
 */
export declare const describeTask: API.OperationMethod<DescribeTaskRequest & RegionInput, DescribeTaskResponse, DescribeTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskExecutionError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Provides information about an execution of your DataSync task. You can
 * use this operation to help monitor the progress of an ongoing data transfer or check the
 * results of the transfer.
 *
 * Some `DescribeTaskExecution` response elements are only relevant to a
 * specific task mode. For information, see Understanding task mode differences and Understanding data
 * transfer performance counters.
 */
export declare const describeTaskExecution: API.OperationMethod<DescribeTaskExecutionRequest & RegionInput, DescribeTaskExecutionResponse, DescribeTaskExecutionError, Credentials | HttpClient.HttpClient>;
export type ListAgentsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of DataSync agents that belong to an Amazon Web Services account in the Amazon Web Services Region specified in the request.
 *
 * With pagination, you can reduce the number of agents returned in a response. If you get
 * a truncated list of agents in a response, the response contains a marker that you can specify
 * in your next request to fetch the next page of agents.
 */
export declare const listAgents: API.PaginatedOperationMethod<ListAgentsRequest & RegionInput, ListAgentsResponse, ListAgentsError, Credentials | HttpClient.HttpClient, AgentListEntry>;
export type ListLocationsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of source and destination locations.
 *
 * If you have more locations than are returned in a response (that is, the response
 * returns only a truncated list of your agents), the response contains a token that you can
 * specify in your next request to fetch the next page of locations.
 */
export declare const listLocations: API.PaginatedOperationMethod<ListLocationsRequest & RegionInput, ListLocationsResponse, ListLocationsError, Credentials | HttpClient.HttpClient, LocationListEntry>;
export type ListTagsForResourceError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns all the tags associated with an Amazon Web Services resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, TagListEntry>;
export type ListTaskExecutionsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of executions for an DataSync transfer task.
 */
export declare const listTaskExecutions: API.PaginatedOperationMethod<ListTaskExecutionsRequest & RegionInput, ListTaskExecutionsResponse, ListTaskExecutionsError, Credentials | HttpClient.HttpClient, TaskExecutionListEntry>;
export type ListTasksError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of the DataSync tasks you created.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksRequest & RegionInput, ListTasksResponse, ListTasksError, Credentials | HttpClient.HttpClient, TaskListEntry>;
export type StartTaskExecutionError = InternalException | InvalidRequestException | LocationAccessTestFailed | CommonErrors;
/**
 * Starts an DataSync transfer task. For each task, you can only run one task
 * execution at a time.
 *
 * There are several steps to a task execution. For more information, see Task execution statuses.
 *
 * If you're planning to transfer data to or from an Amazon S3 location, review
 * how
 * DataSync can affect your S3 request charges and the DataSync pricing page before
 * you begin.
 */
export declare const startTaskExecution: API.OperationMethod<StartTaskExecutionRequest & RegionInput, StartTaskExecutionResponse, StartTaskExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Applies a *tag* to an Amazon Web Services resource. Tags are
 * key-value pairs that can help you manage, filter, and search for your resources.
 *
 * These include DataSync resources, such as locations, tasks, and task
 * executions.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Removes tags from an Amazon Web Services resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Updates the name of an DataSync agent.
 */
export declare const updateAgent: API.OperationMethod<UpdateAgentRequest & RegionInput, UpdateAgentResponse, UpdateAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationAzureBlobError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configurations of the Microsoft Azure Blob Storage transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync transfers with Azure Blob Storage.
 */
export declare const updateLocationAzureBlob: API.OperationMethod<UpdateLocationAzureBlobRequest & RegionInput, UpdateLocationAzureBlobResponse, UpdateLocationAzureBlobError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationEfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon EFS transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with Amazon EFS.
 */
export declare const updateLocationEfs: API.OperationMethod<UpdateLocationEfsRequest & RegionInput, UpdateLocationEfsResponse, UpdateLocationEfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxLustreError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for Lustre
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for Lustre.
 */
export declare const updateLocationFsxLustre: API.OperationMethod<UpdateLocationFsxLustreRequest & RegionInput, UpdateLocationFsxLustreResponse, UpdateLocationFsxLustreError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxOntapError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for NetApp ONTAP
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for ONTAP.
 */
export declare const updateLocationFsxOntap: API.OperationMethod<UpdateLocationFsxOntapRequest & RegionInput, UpdateLocationFsxOntapResponse, UpdateLocationFsxOntapError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxOpenZfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for OpenZFS
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for OpenZFS.
 *
 * Request parameters related to `SMB` aren't supported with the
 * `UpdateLocationFsxOpenZfs` operation.
 */
export declare const updateLocationFsxOpenZfs: API.OperationMethod<UpdateLocationFsxOpenZfsRequest & RegionInput, UpdateLocationFsxOpenZfsResponse, UpdateLocationFsxOpenZfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationFsxWindowsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon FSx for Windows File Server
 * transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with FSx for Windows File Server.
 */
export declare const updateLocationFsxWindows: API.OperationMethod<UpdateLocationFsxWindowsRequest & RegionInput, UpdateLocationFsxWindowsResponse, UpdateLocationFsxWindowsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationHdfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Hadoop Distributed File System
 * (HDFS) transfer location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with an HDFS cluster.
 */
export declare const updateLocationHdfs: API.OperationMethod<UpdateLocationHdfsRequest & RegionInput, UpdateLocationHdfsResponse, UpdateLocationHdfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationNfsError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Network File System (NFS) transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring transfers with an NFS
 * file server.
 */
export declare const updateLocationNfs: API.OperationMethod<UpdateLocationNfsRequest & RegionInput, UpdateLocationNfsResponse, UpdateLocationNfsError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationObjectStorageError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the object storage transfer location
 * that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with an object storage system.
 */
export declare const updateLocationObjectStorage: API.OperationMethod<UpdateLocationObjectStorageRequest & RegionInput, UpdateLocationObjectStorageResponse, UpdateLocationObjectStorageError, Credentials | HttpClient.HttpClient>;
export type UpdateLocationS3Error = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Amazon S3 transfer location
 * that you're using with DataSync.
 *
 * Before you begin, make sure that you read the following topics:
 *
 * - Storage
 * class considerations with Amazon S3 locations
 *
 * - Evaluating S3 request costs when using DataSync
 */
export declare const updateLocationS3: API.OperationMethod<UpdateLocationS3Request & RegionInput, UpdateLocationS3Response, UpdateLocationS3Error, Credentials | HttpClient.HttpClient>;
export type UpdateLocationSmbError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Modifies the following configuration parameters of the Server Message Block (SMB) transfer
 * location that you're using with DataSync.
 *
 * For more information, see Configuring DataSync
 * transfers with an SMB file server.
 */
export declare const updateLocationSmb: API.OperationMethod<UpdateLocationSmbRequest & RegionInput, UpdateLocationSmbResponse, UpdateLocationSmbError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskError = InternalException | InvalidRequestException | TaskNotFound | CommonErrors;
/**
 * Updates the configuration of a *task*, which defines where and how
 * DataSync transfers your data.
 */
export declare const updateTask: API.OperationMethod<UpdateTaskRequest & RegionInput, UpdateTaskResponse, UpdateTaskError, Credentials | HttpClient.HttpClient>;
export type UpdateTaskExecutionError = InternalException | InvalidRequestException | CommonErrors;
/**
 * Updates the configuration of a running DataSync task execution.
 *
 * Currently, the only `Option` that you can modify with
 * `UpdateTaskExecution` is
 * BytesPerSecond
 * , which throttles bandwidth for a running or queued task
 * execution.
 */
export declare const updateTaskExecution: API.OperationMethod<UpdateTaskExecutionRequest & RegionInput, UpdateTaskExecutionResponse, UpdateTaskExecutionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=datasync.d.ts.map