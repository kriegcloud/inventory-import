/** `450ms`, `1.2s`, `12m 34s` or `1h 3s`, by size — shared by every renderer. */
export declare const formatElapsed: (ms: number) => string;
/** Per-resource colors for `alchemy logs`, assigned in order of appearance. */
export declare const TAIL_COLORS: ("#60764b" | "#8f887c" | "#9acb69" | "#b6c77a" | "#c5df8c" | "#d96f52" | "#efb85a")[];
export declare const formatLocalTimestamp: (date: Date) => string;
//# sourceMappingURL=Format.d.ts.map