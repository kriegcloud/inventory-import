import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Scope from "effect/Scope";
import type { RuntimeContext } from "../RuntimeContext.ts";
declare const EventLifetime_base: Context.ServiceClass<EventLifetime, "Cloudflare.Workers.EventLifetime", {
    /** Keep the event's scope open until `promise` settles. */
    readonly extend: (promise: Promise<unknown>) => void;
}>;
/**
 * The current event's lifetime. The Worker and Durable Object bridges close
 * an event's scope once its handler has returned and every piece of work it
 * was told about has settled: work handed to `waitUntil`, and a streamed
 * response body or RPC result. Provided per event, and read from the calling
 * fiber, so a context captured at init still reaches the live event.
 *
 * @internal
 */
export declare class EventLifetime extends EventLifetime_base {
}
/**
 * Run `effect` with the caller's context, hand its promise to `register`
 * (workerd's `waitUntil`) un-awaited, and extend the event's
 * {@link EventLifetime} until it settles.
 *
 * The event is found through {@link EventLifetime} rather than the ambient
 * `Scope`: work handed off inside an `Effect.scoped` region (an RPC request's
 * scope, say) must not hold that region open. The work gets a scope of its
 * own, so what it acquires lives as long as it does, not as long as the
 * region it was handed off from.
 *
 * @internal
 */
export declare const runInBackground: <A, E, R>(effect: Effect.Effect<A, E, R>, register: (promise: Promise<unknown>) => void) => Effect.Effect<void, never, R | RuntimeContext>;
/**
 * Make the {@link EventLifetime} of an event whose scope is `scope`. Provide
 * `lifetime`, and call `holdScope` once the handler has returned: closing the
 * scope then waits for the work the event was told about, including work
 * started while waiting, before running the rest of its finalizers. So that
 * work can still use the event's resources, and its spans and logs reach the
 * event's exporters.
 *
 * Run `holdExporters` once the event's exporters are on the scope and before
 * the handler: work a handler's finalizer hands off is waited for again
 * before the exporters flush.
 *
 * @internal
 */
export declare const makeEventLifetime: (scope: Scope.Scope) => {
    lifetime: {
        /** Keep the event's scope open until `promise` settles. */
        readonly extend: (promise: Promise<unknown>) => void;
    };
    holdExporters: Effect.Effect<void, never, never>;
    holdScope: () => void;
};
export {};
//# sourceMappingURL=EventLifetime.d.ts.map