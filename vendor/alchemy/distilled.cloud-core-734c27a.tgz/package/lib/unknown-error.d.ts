export declare const UnknownErrorFields: {
    /** HTTP status of the response that carried the failure. */
    status: import("effect/Schema").Number;
    /** The provider's machine-readable error code, when the response has one. */
    code: import("effect/Schema").optional<import("effect/Schema").String>;
    /** The provider's error message, when the response has one. */
    message: import("effect/Schema").optional<import("effect/Schema").String>;
    /** Parsed JSON body, or the raw text when the body wasn't JSON. */
    body: import("effect/Schema").Unknown;
};
/** The values of {@link UnknownErrorFields}. */
export interface UnknownErrorProps {
    readonly status: number;
    readonly code?: string | undefined;
    readonly message?: string | undefined;
    readonly body: unknown;
}
//# sourceMappingURL=unknown-error.d.ts.map