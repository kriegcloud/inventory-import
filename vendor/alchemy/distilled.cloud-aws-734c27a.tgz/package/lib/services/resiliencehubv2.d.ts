import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type AssertionText = string;
export type ClientToken = string;
export interface CreateAssertionRequest {
    serviceArn: string;
    text: string;
    clientToken?: string | undefined;
}
export type Uuid = string;
export type AssertionSource = "AI_GENERATED" | "USER" | (string & {});
export interface Assertion {
    serviceArn: string;
    assertionId: string;
    text: string;
    source: AssertionSource;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateAssertionResponse {
    assertion: Assertion;
}
export type TagKey = string;
export type TagValue = string;
export type TagValueList = string[];
export interface ResourceTag {
    key: string;
    values: string[];
}
export type ResourceTagList = ResourceTag[];
export type S3Url = string;
export type EksNamespace = string;
export type EksNamespaceList = string[];
export type EksLabelKey = string;
export type EksLabelValue = string;
export type EksLabelMap = {
    [key: string]: string | undefined;
};
export type EksLabelSelectorOperator = "IN" | "NOT_IN" | "EXISTS" | "DOES_NOT_EXIST" | (string & {});
export type EksLabelValueList = string[];
export interface EksLabelSelectorRequirement {
    key: string;
    operator: EksLabelSelectorOperator;
    values?: string[] | undefined;
}
export type EksLabelSelectorRequirementList = EksLabelSelectorRequirement[];
export interface EksLabelSelector {
    matchLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    matchExpressions?: EksLabelSelectorRequirement[] | undefined;
}
export interface EksSource {
    clusterArn: string;
    namespaces: string[];
    labelSelector?: EksLabelSelector | undefined;
}
export type ResourceConfiguration = {
    resourceTags: ResourceTag[];
    cfnStackArn?: undefined;
    tfStateFileUrl?: undefined;
    eks?: undefined;
    designFileS3Url?: undefined;
} | {
    resourceTags?: undefined;
    cfnStackArn: string;
    tfStateFileUrl?: undefined;
    eks?: undefined;
    designFileS3Url?: undefined;
} | {
    resourceTags?: undefined;
    cfnStackArn?: undefined;
    tfStateFileUrl: string;
    eks?: undefined;
    designFileS3Url?: undefined;
} | {
    resourceTags?: undefined;
    cfnStackArn?: undefined;
    tfStateFileUrl?: undefined;
    eks: EksSource;
    designFileS3Url?: undefined;
} | {
    resourceTags?: undefined;
    cfnStackArn?: undefined;
    tfStateFileUrl?: undefined;
    eks?: undefined;
    designFileS3Url: string;
};
export interface CreateInputSourceRequest {
    serviceArn: string;
    resourceConfiguration: ResourceConfiguration;
    clientToken?: string | undefined;
}
export type InputSourceId = string;
export interface CreateInputSourceResponse {
    serviceArn: string;
    inputSourceId: string;
}
export type EntityName = string;
export type LongDescription = string;
export interface AvailabilitySlo {
    target?: number | undefined;
}
export type MultiAzDisasterRecoveryApproach = "ACTIVE_ACTIVE" | "HOT_STANDBY" | "WARM_STANDBY" | "PILOT_LIGHT" | "BACKUP_AND_RESTORE" | (string & {});
export interface MultiAzTargets {
    rtoInMinutes?: number | undefined;
    rpoInMinutes?: number | undefined;
    disasterRecoveryApproach?: MultiAzDisasterRecoveryApproach | undefined;
}
export type MultiRegionDisasterRecoveryApproach = "ACTIVE_ACTIVE" | "HOT_STANDBY" | "WARM_STANDBY" | "PILOT_LIGHT" | "BACKUP_AND_RESTORE" | (string & {});
export interface MultiRegionTargets {
    rtoInMinutes?: number | undefined;
    rpoInMinutes?: number | undefined;
    disasterRecoveryApproach?: MultiRegionDisasterRecoveryApproach | undefined;
}
export interface DataRecoveryTargets {
    timeBetweenBackupsInMinutes?: number | undefined;
}
export type KmsKeyId = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreatePolicyRequest {
    name: string;
    description?: string | undefined;
    availabilitySlo?: AvailabilitySlo | undefined;
    multiAz?: MultiAzTargets | undefined;
    multiRegion?: MultiRegionTargets | undefined;
    dataRecovery?: DataRecoveryTargets | undefined;
    sharingEnabled?: boolean | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type OrganizationId = string;
export interface Policy {
    policyArn: string;
    name: string;
    description?: string | undefined;
    availabilitySlo?: AvailabilitySlo | undefined;
    multiAz?: MultiAzTargets | undefined;
    multiRegion?: MultiRegionTargets | undefined;
    dataRecovery?: DataRecoveryTargets | undefined;
    sharingEnabled?: boolean | undefined;
    organizationId?: string | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    associatedServiceCount?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreatePolicyResponse {
    policy: Policy;
}
export type ReportType = "FAILURE_MODE" | "TESTING" | (string & {});
export interface CreateReportRequest {
    serviceArn: string;
    reportType: ReportType;
    clientToken?: string | undefined;
}
export type ReportGenerationStatus = "PENDING" | "SUCCEEDED" | "FAILED" | (string & {});
export type TestRunId = string;
export type ServiceOwnedArn = string;
export interface S3ReportOutput {
    s3ObjectKey: string;
}
export type ReportGenerationErrorCode = "INSUFFICIENT_PERMISSIONS" | "CONFIGURATION_ERROR" | "INTERNAL_ERROR" | (string & {});
export interface FailedReportOutput {
    errorCode: ReportGenerationErrorCode;
    errorMessage?: string | undefined;
}
export type ReportOutput = {
    s3ReportOutput: S3ReportOutput;
    failedReportOutput?: undefined;
} | {
    s3ReportOutput?: undefined;
    failedReportOutput: FailedReportOutput;
};
export interface ReportGenerationResult {
    reportType: ReportType;
    status: ReportGenerationStatus;
    serviceArn?: string | undefined;
    assessmentId?: string | undefined;
    testRunId?: string | undefined;
    testTemplateArn?: string | undefined;
    createdAt?: Date | undefined;
    reportOutput?: ReportOutput | undefined;
}
export interface CreateReportResponse {
    reportGenerationResult: ReportGenerationResult;
}
export type UserJourneyId = string;
export type UserJourneyIdList = string[];
export interface AssociatedSystem {
    systemArn: string;
    systemName?: string | undefined;
    userJourneyIds?: string[] | undefined;
}
export type AssociatedSystemList = AssociatedSystem[];
export type AwsRegion = string;
export type RegionList = string[];
export type IamRoleName = string;
export type IamRoleArn = string;
export interface CrossAccountRole {
    crossAccountRoleArn: string;
    externalId?: string | undefined;
}
export type CrossAccountRoleList = CrossAccountRole[];
export interface PermissionModel {
    invokerRoleName: string;
    crossAccountRoles?: CrossAccountRole[] | undefined;
}
export type DependencyDiscoveryInput = "ENABLED" | "DISABLED" | (string & {});
export type S3BucketPath = string;
export type AwsAccountId = string;
export interface S3ReportOutputConfiguration {
    bucketPath: string;
    bucketOwner: string;
}
export type ReportOutputConfiguration = {
    s3: S3ReportOutputConfiguration;
};
export type ReportOutputConfigurationList = ReportOutputConfiguration[];
export interface ServiceReportConfiguration {
    reportOutputs: ReportOutputConfiguration[];
}
export type DevOpsAgentSpaceArn = string;
export interface DevOpsAgentConfiguration {
    agentSpaceArn?: string | undefined;
}
export interface CreateServiceRequest {
    name: string;
    description?: string | undefined;
    associatedSystems?: AssociatedSystem[] | undefined;
    policyArn?: string | undefined;
    regions: string[];
    permissionModel: PermissionModel;
    dependencyDiscovery?: DependencyDiscoveryInput | undefined;
    reportConfiguration?: ServiceReportConfiguration | undefined;
    kmsKeyId?: string | undefined;
    devOpsAgentConfiguration?: DevOpsAgentConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type DependencyDiscoveryStatus = "ENABLED" | "INITIALIZING" | "DISABLED" | (string & {});
export interface DependencyDiscoveryConfig {
    status: DependencyDiscoveryStatus;
    updatedAt?: Date | undefined;
    eligibleResourceCount?: number | undefined;
    message?: string | undefined;
}
export type PolicyValueSource = "SELF" | "CROSS_ACCOUNT" | (string & {});
export interface SloSource {
    value?: number | undefined;
    policyName?: string | undefined;
    source?: PolicyValueSource | undefined;
}
export interface TargetSource {
    value?: number | undefined;
    policyName?: string | undefined;
    source?: PolicyValueSource | undefined;
}
export interface DisasterRecoverySource {
    value?: string | undefined;
    policyName?: string | undefined;
    source?: PolicyValueSource | undefined;
}
export interface EffectivePolicyValues {
    availabilitySlo?: SloSource | undefined;
    multiAzRto?: TargetSource | undefined;
    multiAzRpo?: TargetSource | undefined;
    multiAzDrApproach?: DisasterRecoverySource | undefined;
    multiRegionRto?: TargetSource | undefined;
    multiRegionRpo?: TargetSource | undefined;
    multiRegionDrApproach?: DisasterRecoverySource | undefined;
    dataRecoveryTimeBetweenBackups?: TargetSource | undefined;
}
export type AchievabilityStatus = "ACHIEVABLE" | "NOT_ACHIEVABLE" | (string & {});
export interface Achievability {
    availabilitySlo?: AchievabilityStatus | undefined;
    multiAzRtoRpo?: AchievabilityStatus | undefined;
    multiRegionRtoRpo?: AchievabilityStatus | undefined;
    dataRecoveryTimeBetweenBackups?: AchievabilityStatus | undefined;
}
export type CostCurrency = "USD" | (string & {});
export interface AssessmentCost {
    amount?: number | undefined;
    currency?: CostCurrency | undefined;
}
export type ResourceDiscoveryRunStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "COMPLETED_WITH_FAILURES" | "NOT_STARTED" | (string & {});
export type ResourceDiscoveryErrorCode = "INVALID_PERMISSIONS" | "STACK_NOT_FOUND" | "CLUSTER_NOT_FOUND" | "STATE_FILE_NOT_FOUND" | "ACCESS_DENIED" | "UNSUPPORTED_CLUSTER" | "INTERNAL_ERROR" | (string & {});
export interface ResourceDiscoveryStatus {
    status?: ResourceDiscoveryRunStatus | undefined;
    lastRunAt?: Date | undefined;
    errorCode?: ResourceDiscoveryErrorCode | undefined;
    errorMessage?: string | undefined;
}
export type AssessmentStatus = "NOT_STARTED" | "PENDING" | "IN_PROGRESS" | "FAILED" | "SUCCESS" | (string & {});
export type OuId = string;
export type AccountId = string;
export type DevOpsAgentSpaceId = string;
export type DevOpsAgentRegion = string;
export type DevOpsAgentConnectionStatus = "CONNECTING" | "CONNECTED" | "DISCONNECTED" | "FAILED" | (string & {});
export interface DevOpsAgentConfigurationView {
    agentSpaceArn?: string | undefined;
    agentSpaceId?: string | undefined;
    region?: string | undefined;
    status?: DevOpsAgentConnectionStatus | undefined;
    operatorAppUrl?: string | undefined;
    connectedAt?: Date | undefined;
    statusReason?: string | undefined;
}
export interface Service {
    serviceArn: string;
    name: string;
    description?: string | undefined;
    associatedSystems?: AssociatedSystem[] | undefined;
    policyArn?: string | undefined;
    regions?: string[] | undefined;
    permissionModel?: PermissionModel | undefined;
    dependencyDiscovery?: DependencyDiscoveryConfig | undefined;
    effectivePolicyValues?: EffectivePolicyValues | undefined;
    achievability?: Achievability | undefined;
    reportConfiguration?: ServiceReportConfiguration | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    estimatedAssessmentCost?: AssessmentCost | undefined;
    resourceDiscovery?: ResourceDiscoveryStatus | undefined;
    assessmentStatus?: AssessmentStatus | undefined;
    rerunAssessment?: boolean | undefined;
    openFindingsCount?: number | undefined;
    resolvedFindingsCount?: number | undefined;
    organizationId?: string | undefined;
    ouId?: string | undefined;
    accountId?: string | undefined;
    devOpsAgentConfiguration?: DevOpsAgentConfigurationView | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateServiceResponse {
    service: Service;
}
export type EntityLabel = string;
export type EntityDescription = string;
export type ServiceFunctionCriticality = "PRIMARY" | "SUPPLEMENTAL" | (string & {});
export interface CreateServiceFunctionRequest {
    name: string;
    serviceArn: string;
    description?: string | undefined;
    criticality: ServiceFunctionCriticality;
    clientToken?: string | undefined;
}
export type EntityId = string;
export type ServiceFunctionSource = "AI_GENERATED" | "USER" | (string & {});
export interface ServiceFunction {
    serviceArn: string;
    serviceFunctionId: string;
    name: string;
    description?: string | undefined;
    criticality: ServiceFunctionCriticality;
    resourceCount?: number | undefined;
    source?: ServiceFunctionSource | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateServiceFunctionResponse {
    serviceFunction: ServiceFunction;
}
export type ResourceList = string[];
export interface CreateServiceFunctionResourcesRequest {
    serviceArn: string;
    serviceFunctionId: string;
    resources: string[];
}
export interface CreateServiceFunctionResourcesResponse {
    serviceArn?: string | undefined;
    serviceFunctionId?: string | undefined;
    resources?: string[] | undefined;
}
export interface CreateSystemRequest {
    name: string;
    description?: string | undefined;
    sharingEnabled?: boolean | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type SystemId = string;
export interface System {
    systemArn: string;
    systemId: string;
    name: string;
    description?: string | undefined;
    sharingEnabled?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyId?: string | undefined;
    organizationId?: string | undefined;
    ouId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateSystemResponse {
    system: System;
}
export interface LoggingConfiguration {
    s3BucketName?: string | undefined;
    cloudWatchLogGroupArn?: string | undefined;
    logSchemaVersion?: string | undefined;
}
export type StopConditionSource = "aws:cloudwatch:alarm" | "none" | (string & {});
export interface StopCondition {
    source: StopConditionSource;
    value: string;
}
export type StopConditionList = StopCondition[];
export type ParameterKey = string;
export type ParameterValue = string;
export type StringList = string[];
export type TestParameters = {
    [key: string]: string[] | undefined;
};
export interface CreateTestRequest {
    serviceArn: string;
    testTemplateArn: string;
    loggingConfiguration?: LoggingConfiguration | undefined;
    stopConditions?: StopCondition[] | undefined;
    roleName?: string | undefined;
    parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type TestId = string;
export interface TestAction {
    actionId: string;
    description?: string | undefined;
    resourceType: string;
}
export type TestActionList = TestAction[];
export interface Test {
    testId: string;
    testTemplateArn: string;
    serviceArn: string;
    name: string;
    actions?: TestAction[] | undefined;
    loggingConfiguration?: LoggingConfiguration | undefined;
    stopConditions?: StopCondition[] | undefined;
    roleName?: string | undefined;
    parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    totalTestRuns: number;
    successfulTestRuns: number;
    creationTime: Date;
}
export interface CreateTestResponse {
    test: Test;
}
export interface CreateUserJourneyRequest {
    systemArn: string;
    name: string;
    description?: string | undefined;
    policyArn?: string | undefined;
    clientToken?: string | undefined;
}
export interface UserJourney {
    userJourneyId: string;
    name: string;
    description?: string | undefined;
    policyArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface CreateUserJourneyResponse {
    userJourney: UserJourney;
}
export interface DeleteAssertionRequest {
    serviceArn: string;
    assertionId: string;
}
export interface DeleteAssertionResponse {
    assertionId?: string | undefined;
}
export interface DeleteInputSourceRequest {
    serviceArn: string;
    inputSourceId: string;
}
export interface DeleteInputSourceResponse {
    serviceArn: string;
    inputSourceId: string;
}
export interface DeletePolicyRequest {
    policyArn: string;
}
export interface DeletePolicyResponse {
    policyArn: string;
}
export interface DeleteServiceRequest {
    serviceArn: string;
}
export interface DeleteServiceResponse {
    serviceArn: string;
}
export interface DeleteServiceFunctionRequest {
    serviceArn: string;
    serviceFunctionId: string;
}
export interface DeleteServiceFunctionResponse {
    serviceFunctionId?: string | undefined;
}
export interface DeleteServiceFunctionResourcesRequest {
    serviceArn: string;
    serviceFunctionId: string;
    resources: string[];
}
export interface DeleteServiceFunctionResourcesResponse {
    serviceArn?: string | undefined;
    serviceFunctionId?: string | undefined;
    resources?: string[] | undefined;
}
export interface DeleteSystemRequest {
    systemArn: string;
}
export interface DeleteSystemResponse {
    systemArn: string;
}
export interface DeleteTestRequest {
    testId: string;
    serviceArn: string;
}
export interface DeleteTestResponse {
    testId: string;
}
export type CloudWatchAlarmArn = string;
export interface SuccessCriteriaAlarmInput {
    alarmArn: string;
}
export interface ObservabilityAlarmInput {
    alarmArn: string;
}
export type TestSourceInput = {
    successCriteriaAlarm: SuccessCriteriaAlarmInput;
    observabilityAlarm?: undefined;
} | {
    successCriteriaAlarm?: undefined;
    observabilityAlarm: ObservabilityAlarmInput;
};
export type TestSourceInputList = TestSourceInput[];
export interface DeleteTestSourcesRequest {
    testId: string;
    serviceArn: string;
    testSources: TestSourceInput[];
}
export interface DeleteTestSourcesResponse {
}
export interface DeleteUserJourneyRequest {
    systemArn: string;
    userJourneyId: string;
}
export interface DeleteUserJourneyResponse {
    userJourneyId: string;
}
export interface GetDependencyInsightsRequest {
    serviceArn: string;
}
export type InsightsCategory = "CROSS_REGION" | "NEW_DEPENDENCY" | "THIRD_PARTY" | "UNEVEN_USAGE" | "AWS_SERVICE" | (string & {});
export interface DependencyInsight {
    category: InsightsCategory;
    description: string;
}
export type DependencyInsightsList = DependencyInsight[];
export type DependencyInsightsStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type DependencyInsightsErrorCode = "INSUFFICIENT_DATA" | "LLM_GENERATION_FAILED" | "INTERNAL_ERROR" | (string & {});
export interface GetDependencyInsightsResponse {
    overview?: string | undefined;
    insights?: DependencyInsight[] | undefined;
    status: DependencyInsightsStatus;
    createdAt?: Date | undefined;
    errorCode?: DependencyInsightsErrorCode | undefined;
    errorMessage?: string | undefined;
}
export interface GetFailureModeFindingRequest {
    findingId: string;
    serviceArn: string;
}
export type FailureCategory = "SHARED_FATE" | "EXCESSIVE_LOAD" | "EXCESSIVE_LATENCY" | "MISCONFIGURATION_AND_BUGS" | "SINGLE_POINT_OF_FAILURE" | (string & {});
export type FindingStatus = "OPEN" | "RESOLVED" | "IRRELEVANT" | (string & {});
export type FindingSeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export type FunctionsList = string[];
export type PolicyComponent = "AVAILABILITY_SLO" | "MULTI_AZ_DISASTER_RECOVERY" | "MULTI_REGION_DISASTER_RECOVERY" | "DATA_RECOVERY" | (string & {});
export type SuggestedChangesList = string[];
export interface InfrastructureAndCodeRecommendation {
    suggestedChanges?: string[] | undefined;
}
export type InfrastructureAndCodeRecommendationsList = InfrastructureAndCodeRecommendation[];
export interface ObservabilityRecommendation {
    suggestedChanges?: string[] | undefined;
}
export type ObservabilityRecommendationsList = ObservabilityRecommendation[];
export interface TestingRecommendation {
    suggestedChanges?: string[] | undefined;
}
export type TestingRecommendationsList = TestingRecommendation[];
export interface Finding {
    findingId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    failureCategory?: FailureCategory | undefined;
    status?: FindingStatus | undefined;
    reasoning?: string | undefined;
    comment?: string | undefined;
    severity?: FindingSeverity | undefined;
    serviceFunctions?: string[] | undefined;
    policyComponent?: PolicyComponent | undefined;
    infrastructureAndCodeRecommendations?: InfrastructureAndCodeRecommendation[] | undefined;
    observabilityRecommendations?: ObservabilityRecommendation[] | undefined;
    testingRecommendations?: TestingRecommendation[] | undefined;
    updatedAt?: Date | undefined;
    investigationDeepLink?: string | undefined;
}
export interface GetFailureModeFindingResponse {
    finding?: Finding | undefined;
}
export interface GetPolicyRequest {
    policyArn: string;
}
export interface GetPolicyResponse {
    policy: Policy;
}
export interface GetServiceRequest {
    serviceArn: string;
}
export interface GetServiceResponse {
    service: Service;
}
export interface GetSystemRequest {
    systemArn: string;
}
export interface GetSystemResponse {
    system: System;
}
export interface GetTestRequest {
    testId: string;
    serviceArn: string;
}
export interface GetTestResponse {
    test: Test;
}
export interface GetTestRunRequest {
    testRunId: string;
    serviceArn: string;
}
export type TestRunStatus = "INITIALIZING" | "RUNNING" | "STOPPING" | "PASSED" | "FAILED" | "STOPPED" | "ERROR" | (string & {});
export interface ExperimentDetails {
    experimentArn: string;
    details?: string | undefined;
}
export type ExperimentDetailsList = ExperimentDetails[];
export interface TestRunReportConfiguration {
    reportOutput: ReportOutputConfiguration[];
}
export interface TestRunPolicySnapshot {
    policyArn?: string | undefined;
    name?: string | undefined;
    availabilitySlo?: AvailabilitySlo | undefined;
    multiAz?: MultiAzTargets | undefined;
    multiRegion?: MultiRegionTargets | undefined;
    dataRecovery?: DataRecoveryTargets | undefined;
}
export type RegionSwitchExecutionId = string;
export type AccountTargeting = "SINGLE_ACCOUNT" | "MULTI_ACCOUNT" | (string & {});
export type DevOpsAgentVerdict = "PASS" | "FAIL" | (string & {});
export type DevOpsAgentConfidence = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export type DevOpsAgentInvestigationStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | "TIMED_OUT" | "CANCELED" | (string & {});
export interface DevOpsAgentInvestigation {
    verdict?: DevOpsAgentVerdict | undefined;
    confidence?: DevOpsAgentConfidence | undefined;
    deepLink?: string | undefined;
    status?: DevOpsAgentInvestigationStatus | undefined;
    summary?: string | undefined;
}
export interface TestRun {
    testRunId: string;
    testId: string;
    status: TestRunStatus;
    serviceArn?: string | undefined;
    startedAt: Date;
    endedAt?: Date | undefined;
    experiments?: ExperimentDetails[] | undefined;
    eventCount?: number | undefined;
    parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    errorMessage?: string | undefined;
    stopConditions?: StopCondition[] | undefined;
    loggingConfiguration?: LoggingConfiguration | undefined;
    roleName?: string | undefined;
    testTemplateArn: string;
    reportConfiguration?: TestRunReportConfiguration | undefined;
    policy?: TestRunPolicySnapshot | undefined;
    reportOutput?: ReportGenerationResult | undefined;
    regionSwitchPlanArn?: string | undefined;
    regionSwitchExecutionId?: string | undefined;
    permissionModel?: PermissionModel | undefined;
    regions?: string[] | undefined;
    accountTargeting?: AccountTargeting | undefined;
    devOpsAgentInvestigation?: DevOpsAgentInvestigation | undefined;
}
export interface GetTestRunResponse {
    testRun: TestRun;
}
export interface GetTestTemplateRequest {
    testTemplateArn: string;
}
export type ParameterType = "STRING" | "STRING_LIST" | "INTEGER" | (string & {});
export interface TestTemplateParameter {
    name: string;
    description?: string | undefined;
    type: ParameterType;
    required: boolean;
    defaultValue?: string | undefined;
    maxValues?: number | undefined;
}
export type TestTemplateParameterList = TestTemplateParameter[];
export interface TestTemplate {
    testTemplateArn: string;
    name: string;
    description?: string | undefined;
    parameters?: TestTemplateParameter[] | undefined;
    actions?: TestAction[] | undefined;
}
export interface GetTestTemplateResponse {
    testTemplate: TestTemplate;
}
export interface GetUserJourneyRequest {
    systemArn: string;
    userJourneyId: string;
}
export interface GetUserJourneyResponse {
    userJourney: UserJourney;
}
export interface ImportAppRequest {
    v1AppArn: string;
    policyArn?: string | undefined;
    kmsKeyId?: string | undefined;
    skipManuallyAddedResources?: boolean | undefined;
    associatedSystems?: AssociatedSystem[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface ImportAppResponse {
    service: Service;
}
export interface ImportPolicyRequest {
    v1PolicyArn: string;
    kmsKeyId?: string | undefined;
    availabilitySlo?: AvailabilitySlo | undefined;
    multiAzDisasterRecoveryApproach?: MultiAzDisasterRecoveryApproach | undefined;
    multiRegionDisasterRecoveryApproach?: MultiRegionDisasterRecoveryApproach | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface ImportPolicyResponse {
    policy: Policy;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAssertionsRequest {
    serviceArn: string;
    source?: AssertionSource | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AssertionList = Assertion[];
export interface ListAssertionsResponse {
    assertions: Assertion[];
    nextToken?: string | undefined;
}
export type QueryGranularity = "HOURLY" | "DAILY" | (string & {});
export interface ListDependenciesRequest {
    serviceArn?: string | undefined;
    queryRangeStartTime?: Date | undefined;
    queryRangeEndTime?: Date | undefined;
    queryRangeGranularity?: QueryGranularity | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface QueryDataPoint {
    timestamp: Date;
    queryCount: number;
}
export type QueryDataPointList = QueryDataPoint[];
export interface QueryRange {
    startTime: Date;
    endTime: Date;
    granularity: QueryGranularity;
    dataPoints: QueryDataPoint[];
}
export type DependencyCriticality = "HARD" | "SOFT" | "UNKNOWN" | (string & {});
export interface DependencySummary {
    dependencyId: string;
    serviceArn: string;
    dependencyName: string;
    dnsName: string;
    location: string;
    lastDetectedTime: Date;
    sourceRegions: string[];
    provider?: string | undefined;
    queryRange: QueryRange;
    criticality: DependencyCriticality;
    comment?: string | undefined;
}
export type DependencySummaryList = DependencySummary[];
export interface ListDependenciesResponse {
    dependencySummaries: DependencySummary[];
    nextToken?: string | undefined;
}
export type AssessmentStatusList = AssessmentStatus[];
export type AssessmentSortField = "STARTED_AT" | (string & {});
export type SortOrder = "ASC" | "DESC" | (string & {});
export interface ListFailureModeAssessmentsRequest {
    serviceArn: string;
    assessmentStatuses?: AssessmentStatus[] | undefined;
    startedAfter?: Date | undefined;
    endedBefore?: Date | undefined;
    sortBy?: AssessmentSortField | undefined;
    sortOrder?: SortOrder | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AssessmentStep = "TOPOLOGY_GENERATION" | "INPUT_VALIDATION" | "DESIGN_ANALYSIS" | "TOPOLOGY_ENHANCEMENT" | "SERVICE_FUNCTION_GENERATION" | "POLICY_VALIDATION" | "RESILIENCE_ASSESSMENT" | "FAILURE_MODE_FINDINGS_CONSOLIDATION" | "FAILURE_MODE_FINDINGS_ENRICHMENT" | (string & {});
export type AssessmentErrorCode = "INVALID_PERMISSIONS" | "CMK_ACCESS_DENIED" | "AGENT_ERROR" | "INTERNAL_ERROR" | "DESIGN_FILE_ACCESS_DENIED" | (string & {});
export interface AssessmentSummary {
    assessmentId: string;
    serviceArn: string;
    assessmentStatus?: AssessmentStatus | undefined;
    assessmentStep?: AssessmentStep | undefined;
    totalFindings?: number | undefined;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    errorMessage?: string | undefined;
    errorCode?: AssessmentErrorCode | undefined;
    assessmentCost?: AssessmentCost | undefined;
    billableAssessmentUnitCount?: number | undefined;
    achievability?: Achievability | undefined;
}
export type AssessmentSummaryList = AssessmentSummary[];
export interface ListFailureModeAssessmentsResponse {
    assessmentSummaries: AssessmentSummary[];
    nextToken?: string | undefined;
}
export interface ListFailureModeFindingsRequest {
    serviceArn: string;
    severity?: FindingSeverity | undefined;
    failureCategory?: FailureCategory | undefined;
    status?: FindingStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FindingSummary {
    serviceArn?: string | undefined;
    findingId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    failureCategory?: FailureCategory | undefined;
    severity?: FindingSeverity | undefined;
    status?: FindingStatus | undefined;
    policyComponent?: PolicyComponent | undefined;
    updatedAt?: Date | undefined;
    investigationDeepLink?: string | undefined;
}
export type FindingsList = FindingSummary[];
export interface ListFailureModeFindingsResponse {
    findingsSummary: FindingSummary[];
    nextToken?: string | undefined;
}
export type InputSourceType = "CFN_STACK" | "TAGS" | "EKS" | "TERRAFORM" | "DESIGN_FILE" | "MONITORING" | (string & {});
export interface ListInputSourcesRequest {
    serviceArn: string;
    type?: InputSourceType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface InputSourceSummary {
    inputSourceId: string;
    type?: InputSourceType | undefined;
    resourceTags?: ResourceTag[] | undefined;
    cfnStackArn?: string | undefined;
    tfStateFileUrl?: string | undefined;
    eks?: EksSource | undefined;
    designFileS3Url?: string | undefined;
    createdAt?: Date | undefined;
}
export type InputSourceSummaryList = InputSourceSummary[];
export interface ListInputSourcesResponse {
    inputSourceSummaries: InputSourceSummary[];
    nextToken?: string | undefined;
}
export interface ListPoliciesRequest {
    accountId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PolicySummary {
    policyArn: string;
    name: string;
    availabilitySlo?: AvailabilitySlo | undefined;
    multiAz?: MultiAzTargets | undefined;
    multiRegion?: MultiRegionTargets | undefined;
    dataRecovery?: DataRecoveryTargets | undefined;
    sharingEnabled?: boolean | undefined;
    organizationId?: string | undefined;
    associatedServiceCount?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type PolicySummaryList = PolicySummary[];
export interface ListPoliciesResponse {
    policySummaries: PolicySummary[];
    nextToken?: string | undefined;
}
export type PolicyEventType = "POLICY_ATTACHED_TO_SERVICE" | "POLICY_DETACHED_FROM_SERVICE" | "POLICY_SHARING_REVOKED" | "POLICY_DELETED" | (string & {});
export type PolicyEventTypeList = PolicyEventType[];
export interface ListPolicyEventsRequest {
    policyArn: string;
    eventTypes?: PolicyEventType[] | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ActorType = "USER" | "SYSTEM" | (string & {});
export interface EventActor {
    type: ActorType;
    principalId: string;
    accountId?: string | undefined;
    userName?: string | undefined;
}
export interface PolicyAttachedToServiceMetadata {
    serviceArn?: string | undefined;
    accountId?: string | undefined;
}
export interface PolicyDetachedFromServiceMetadata {
    serviceArn?: string | undefined;
    accountId?: string | undefined;
}
export interface PolicySharingRevokedMetadata {
    affectedServiceCount?: number | undefined;
}
export interface PolicyDeletedMetadata {
    affectedServiceCount?: number | undefined;
}
export type PolicyEventMetadata = {
    policyAttachedToService: PolicyAttachedToServiceMetadata;
    policyDetachedFromService?: undefined;
    policySharingRevoked?: undefined;
    policyDeleted?: undefined;
} | {
    policyAttachedToService?: undefined;
    policyDetachedFromService: PolicyDetachedFromServiceMetadata;
    policySharingRevoked?: undefined;
    policyDeleted?: undefined;
} | {
    policyAttachedToService?: undefined;
    policyDetachedFromService?: undefined;
    policySharingRevoked: PolicySharingRevokedMetadata;
    policyDeleted?: undefined;
} | {
    policyAttachedToService?: undefined;
    policyDetachedFromService?: undefined;
    policySharingRevoked?: undefined;
    policyDeleted: PolicyDeletedMetadata;
};
export interface PolicyEventDetails {
    title: string;
    description: string;
    eventMetadata?: PolicyEventMetadata | undefined;
}
export interface PolicyEvent {
    eventId: string;
    timestamp: Date;
    eventType: PolicyEventType;
    policyArn: string;
    actor: EventActor;
    eventDetails: PolicyEventDetails;
}
export type PolicyEventList = PolicyEvent[];
export interface ListPolicyEventsResponse {
    events: PolicyEvent[];
    nextToken?: string | undefined;
}
export interface ListReportsRequest {
    serviceArn?: string | undefined;
    reportType?: ReportType | undefined;
    testRunId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ReportGenerationResultList = ReportGenerationResult[];
export interface ListReportsResponse {
    reportGenerationResults: ReportGenerationResult[];
    nextToken?: string | undefined;
}
export interface ListResolvedTestRunTargetResourcesRequest {
    testRunId: string;
    serviceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ResolvedTargetInformationKey = string;
export type ResolvedTargetInformationValue = string;
export type ResolvedTargetInformation = {
    [key: string]: string | undefined;
};
export interface ResolvedTargetResource {
    resourceType: string;
    targetName: string;
    targetInformation: {
        [key: string]: string | undefined;
    };
}
export type ResolvedTargetResourceList = ResolvedTargetResource[];
export interface ListResolvedTestRunTargetResourcesResponse {
    resolvedTargetResources: ResolvedTargetResource[];
    nextToken?: string | undefined;
}
export type ResourceTypeFilter = string;
export type ResourceTypeFilterList = string[];
export interface ListResourcesRequest {
    serviceArn: string;
    serviceFunctionId?: string | undefined;
    awsRegion?: string | undefined;
    resourceTypes?: string[] | undefined;
    billable?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface InputSource {
    identifier: string;
    type: InputSourceType;
}
export interface Resource {
    identifier: string;
    awsRegion?: string | undefined;
    awsAccountId?: string | undefined;
    resourceType?: string | undefined;
    availabilityZoneId?: string | undefined;
    availabilityZoneName?: string | undefined;
    containmentParentId?: string | undefined;
    logicalResourceGroupId?: string | undefined;
}
export interface ServiceResource {
    resourceIdentifier: string;
    inputSource?: InputSource | undefined;
    resource: Resource;
}
export type ServiceResourceList = ServiceResource[];
export interface ListResourcesResponse {
    serviceFunctionId?: string | undefined;
    serviceResources?: ServiceResource[] | undefined;
    nextToken?: string | undefined;
}
export type ServiceEventType = "SERVICE_CREATED" | "SERVICE_DELETED" | "SERVICE_SYSTEM_ASSOCIATED" | "SERVICE_SYSTEM_DISASSOCIATED" | "SERVICE_RESOURCES_ASSOCIATED" | "SERVICE_RESOURCES_DISASSOCIATED" | "SERVICE_WORKFLOW_UPDATED" | "SERVICE_INPUT_SOURCES_UPDATED" | "SERVICE_POLICY_ASSOCIATED" | "SERVICE_POLICY_DISASSOCIATED" | "SERVICE_FUNCTION_CREATED" | "SERVICE_FUNCTION_UPDATED" | "SERVICE_FUNCTION_DELETED" | "SERVICE_FUNCTION_RESOURCES_ADDED" | "SERVICE_FUNCTION_RESOURCES_REMOVED" | "SERVICE_ACHIEVABILITY_UPDATED" | "ASSERTION_CREATED" | "ASSERTION_UPDATED" | "ASSERTION_DELETED" | (string & {});
export type ServiceEventTypeList = ServiceEventType[];
export interface ListServiceEventsRequest {
    serviceArn: string;
    eventTypes?: ServiceEventType[] | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceCreatedMetadata {
}
export interface ServiceDeletedMetadata {
}
export interface ServiceSystemAssociatedMetadata {
    systemName?: string | undefined;
    systemArn?: string | undefined;
}
export interface ServiceSystemDisassociatedMetadata {
    systemId?: string | undefined;
    systemName?: string | undefined;
    systemArn?: string | undefined;
}
export type ResourceTypeList = string[];
export interface ServiceResourcesAssociatedMetadata {
    resourceCount?: number | undefined;
    resourceTypes?: string[] | undefined;
}
export interface ServiceResourcesDisassociatedMetadata {
    resourceCount?: number | undefined;
    resourceTypes?: string[] | undefined;
}
export interface ServiceWorkflowUpdatedMetadata {
    serviceFunctionId?: string | undefined;
    serviceFunctionName?: string | undefined;
}
export interface ServiceInputSourcesUpdatedMetadata {
}
export interface ServicePolicyAssociatedMetadata {
    policyName?: string | undefined;
    policyArn?: string | undefined;
    policyOwnerAccountId?: string | undefined;
    policySource?: PolicyValueSource | undefined;
}
export type PolicyDisassociationReason = "REPLACED_BY_UPDATE" | "SHARING_REVOKED" | "POLICY_DELETED" | (string & {});
export interface ServicePolicyDisassociatedMetadata {
    policyName?: string | undefined;
    policyArn?: string | undefined;
    policyOwnerAccountId?: string | undefined;
    policySource?: PolicyValueSource | undefined;
    reason?: PolicyDisassociationReason | undefined;
}
export interface ServiceFunctionCreatedMetadata {
    serviceFunctionId?: string | undefined;
    serviceFunctionName?: string | undefined;
}
export type ArnList = string[];
export interface ServiceFunctionUpdatedMetadata {
    serviceFunctionId?: string | undefined;
    serviceFunctionName?: string | undefined;
    resourcesAdded?: string[] | undefined;
    resourcesRemoved?: string[] | undefined;
}
export interface ServiceFunctionDeletedMetadata {
    serviceFunctionId?: string | undefined;
    serviceFunctionName?: string | undefined;
}
export interface ServiceFunctionResourcesAddedMetadata {
    serviceFunctionId?: string | undefined;
    serviceFunctionName?: string | undefined;
    resourcesAdded?: string[] | undefined;
}
export interface ServiceFunctionResourcesRemovedMetadata {
    serviceFunctionId?: string | undefined;
    serviceFunctionName?: string | undefined;
    resourcesRemoved?: string[] | undefined;
}
export interface ServiceAchievabilityUpdatedMetadata {
    assessmentId?: string | undefined;
    availabilitySlo?: string | undefined;
    multiAzRtoRpo?: string | undefined;
    multiRegionRtoRpo?: string | undefined;
}
export interface AssertionCreatedMetadata {
    assertionId?: string | undefined;
    assertionName?: string | undefined;
}
export interface AssertionUpdatedMetadata {
    assertionId?: string | undefined;
    assertionName?: string | undefined;
}
export interface AssertionDeletedMetadata {
    assertionId?: string | undefined;
    assertionName?: string | undefined;
}
export type ServiceEventMetadata = {
    serviceCreated: ServiceCreatedMetadata;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted: ServiceDeletedMetadata;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated: ServiceSystemAssociatedMetadata;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated: ServiceSystemDisassociatedMetadata;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated: ServiceResourcesAssociatedMetadata;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated: ServiceResourcesDisassociatedMetadata;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated: ServiceWorkflowUpdatedMetadata;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated: ServiceInputSourcesUpdatedMetadata;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated: ServicePolicyAssociatedMetadata;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated: ServicePolicyDisassociatedMetadata;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated: ServiceFunctionCreatedMetadata;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated: ServiceFunctionUpdatedMetadata;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted: ServiceFunctionDeletedMetadata;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded: ServiceFunctionResourcesAddedMetadata;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved: ServiceFunctionResourcesRemovedMetadata;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated: ServiceAchievabilityUpdatedMetadata;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated: AssertionCreatedMetadata;
    assertionUpdated?: undefined;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated: AssertionUpdatedMetadata;
    assertionDeleted?: undefined;
} | {
    serviceCreated?: undefined;
    serviceDeleted?: undefined;
    serviceSystemAssociated?: undefined;
    serviceSystemDisassociated?: undefined;
    serviceResourcesAssociated?: undefined;
    serviceResourcesDisassociated?: undefined;
    serviceWorkflowUpdated?: undefined;
    serviceInputSourcesUpdated?: undefined;
    servicePolicyAssociated?: undefined;
    servicePolicyDisassociated?: undefined;
    serviceFunctionCreated?: undefined;
    serviceFunctionUpdated?: undefined;
    serviceFunctionDeleted?: undefined;
    serviceFunctionResourcesAdded?: undefined;
    serviceFunctionResourcesRemoved?: undefined;
    serviceAchievabilityUpdated?: undefined;
    assertionCreated?: undefined;
    assertionUpdated?: undefined;
    assertionDeleted: AssertionDeletedMetadata;
};
export interface ServiceEventDetails {
    title: string;
    description: string;
    eventMetadata?: ServiceEventMetadata | undefined;
}
export interface ServiceEvent {
    eventId: string;
    timestamp: Date;
    eventType: ServiceEventType;
    serviceArn: string;
    actor: EventActor;
    eventDetails: ServiceEventDetails;
}
export type ServiceEventList = ServiceEvent[];
export interface ListServiceEventsResponse {
    events: ServiceEvent[];
    nextToken?: string | undefined;
}
export interface ListServiceFunctionsRequest {
    serviceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ServiceFunctionList = ServiceFunction[];
export interface ListServiceFunctionsResponse {
    serviceFunctions: ServiceFunction[];
    nextToken?: string | undefined;
}
export interface ListServicesRequest {
    systemArn?: string | undefined;
    userJourneyId?: string | undefined;
    ouId?: string | undefined;
    accountId?: string | undefined;
    assessmentStatus?: AssessmentStatus | undefined;
    policyArn?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ServiceSummary {
    serviceArn: string;
    name: string;
    associatedSystems?: AssociatedSystem[] | undefined;
    regions?: string[] | undefined;
    policyArn?: string | undefined;
    assessmentStatus?: AssessmentStatus | undefined;
    devOpsAgentStatus?: DevOpsAgentConnectionStatus | undefined;
    devOpsAgentSpaceArn?: string | undefined;
    openFindingsCount?: number | undefined;
    resolvedFindingsCount?: number | undefined;
    dependencyDiscovery?: DependencyDiscoveryConfig | undefined;
    achievability?: Achievability | undefined;
    organizationId?: string | undefined;
    ouId?: string | undefined;
    accountId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ServiceSummaryList = ServiceSummary[];
export interface ListServicesResponse {
    serviceSummaries: ServiceSummary[];
    nextToken?: string | undefined;
}
export interface ListServiceTopologyEdgesRequest {
    serviceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TopologyType = "CONTAINMENT" | "DATA_FLOW" | "OBSERVABILITY" | "PERMISSIONS" | (string & {});
export interface EdgePropertySummary {
    topologyType?: TopologyType | undefined;
    label?: string | undefined;
}
export type EdgePropertyList = EdgePropertySummary[];
export interface ServiceTopologyEdgeSummary {
    sourceResourceIdentifier: string;
    destinationResourceIdentifier: string;
    sourceRegion?: string | undefined;
    destinationRegion?: string | undefined;
    sourceAccount?: string | undefined;
    destinationAccount?: string | undefined;
    properties?: EdgePropertySummary[] | undefined;
}
export type ServiceTopologyEdgeSummaryList = ServiceTopologyEdgeSummary[];
export interface ListServiceTopologyEdgesResponse {
    serviceTopologyEdgeSummaries?: ServiceTopologyEdgeSummary[] | undefined;
    nextToken?: string | undefined;
}
export type SystemEventType = "SYSTEM_CREATED" | "SYSTEM_DELETED" | "SYSTEM_USER_JOURNEY_CREATED" | "SYSTEM_USER_JOURNEY_UPDATED" | "SYSTEM_USER_JOURNEY_DELETED" | "SYSTEM_SERVICE_ASSOCIATED" | "SYSTEM_SERVICE_DISASSOCIATED" | "SYSTEM_POLICY_ASSOCIATED" | "SYSTEM_POLICY_DISASSOCIATED" | (string & {});
export type SystemEventTypeList = SystemEventType[];
export interface ListSystemEventsRequest {
    systemArn: string;
    eventTypes?: SystemEventType[] | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SystemCreatedMetadata {
}
export interface SystemDeletedMetadata {
}
export interface ServiceReference {
    serviceId?: string | undefined;
    serviceName?: string | undefined;
}
export type ServiceReferenceList = ServiceReference[];
export interface SystemUserJourneyCreatedMetadata {
    userJourneyName?: string | undefined;
    associatedServices?: ServiceReference[] | undefined;
}
export interface StringChange {
    oldValue?: string | undefined;
    newValue?: string | undefined;
}
export interface ServiceReferenceChanges {
    added?: ServiceReference[] | undefined;
    removed?: ServiceReference[] | undefined;
}
export interface UserJourneyChanges {
    journeyDescription?: StringChange | undefined;
    associatedServices?: ServiceReferenceChanges | undefined;
}
export interface SystemUserJourneyUpdatedMetadata {
    userJourneyName?: string | undefined;
    changes?: UserJourneyChanges | undefined;
}
export interface SystemUserJourneyDeletedMetadata {
    userJourneyName?: string | undefined;
    associatedServicesAtDeletion?: ServiceReference[] | undefined;
}
export type UserJourneyNameList = string[];
export interface SystemServiceAssociatedMetadata {
    serviceName?: string | undefined;
    serviceArn?: string | undefined;
    userJourneys?: string[] | undefined;
}
export interface SystemServiceDisassociatedMetadata {
    serviceName?: string | undefined;
    serviceArn?: string | undefined;
    userJourneysAffected?: string[] | undefined;
    comment?: string | undefined;
}
export interface SystemPolicyAssociatedMetadata {
    policyName?: string | undefined;
    policyArn?: string | undefined;
}
export interface SystemPolicyDisassociatedMetadata {
    policyName?: string | undefined;
    policyArn?: string | undefined;
}
export type SystemEventMetadata = {
    systemCreated: SystemCreatedMetadata;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted: SystemDeletedMetadata;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated: SystemUserJourneyCreatedMetadata;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated: SystemUserJourneyUpdatedMetadata;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted: SystemUserJourneyDeletedMetadata;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated: SystemServiceAssociatedMetadata;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated: SystemServiceDisassociatedMetadata;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated: SystemPolicyAssociatedMetadata;
    systemPolicyDisassociated?: undefined;
} | {
    systemCreated?: undefined;
    systemDeleted?: undefined;
    systemUserJourneyCreated?: undefined;
    systemUserJourneyUpdated?: undefined;
    systemUserJourneyDeleted?: undefined;
    systemServiceAssociated?: undefined;
    systemServiceDisassociated?: undefined;
    systemPolicyAssociated?: undefined;
    systemPolicyDisassociated: SystemPolicyDisassociatedMetadata;
};
export interface SystemEventDetails {
    title: string;
    description: string;
    eventMetadata?: SystemEventMetadata | undefined;
}
export interface SystemEvent {
    eventId: string;
    timestamp: Date;
    eventType: SystemEventType;
    systemArn: string;
    actor: EventActor;
    eventDetails: SystemEventDetails;
}
export type SystemEventList = SystemEvent[];
export interface ListSystemEventsResponse {
    events: SystemEvent[];
    nextToken?: string | undefined;
}
export interface ListSystemsRequest {
    ouId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SystemSummary {
    systemId: string;
    name: string;
    systemArn?: string | undefined;
    userJourneysCount?: number | undefined;
    servicesCount?: number | undefined;
    organizationId?: string | undefined;
    ouId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type SystemSummaryList = SystemSummary[];
export interface ListSystemsResponse {
    systemSummaries: SystemSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTestRunDependenciesRequest {
    testRunId: string;
    serviceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TestRunDependencySource = "DISCOVERED" | "MANUAL" | (string & {});
export interface TestRunDependencySummary {
    dependencyId?: string | undefined;
    dependencyName: string;
    dnsName: string;
    criticality: DependencyCriticality;
    source: TestRunDependencySource;
    location?: string | undefined;
    sourceRegions?: string[] | undefined;
    provider?: string | undefined;
}
export type TestRunDependencySummaryList = TestRunDependencySummary[];
export interface ListTestRunDependenciesResponse {
    dependencies: TestRunDependencySummary[];
    nextToken?: string | undefined;
}
export interface ListTestRunEventsRequest {
    testRunId: string;
    serviceArn: string;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TestRunEventAttributeKey = string;
export type TestRunEventAttributeValue = string;
export type TestRunEventAttributes = {
    [key: string]: string | undefined;
};
export interface TestRunEvent {
    eventId: string;
    eventType: string;
    message: string;
    timestamp: Date;
    attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TestRunEventList = TestRunEvent[];
export interface ListTestRunEventsResponse {
    events: TestRunEvent[];
    nextToken?: string | undefined;
}
export interface ListTestRunsRequest {
    serviceArn: string;
    testId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TestRunSummary {
    testRunId: string;
    status: TestRunStatus;
    startedAt: Date;
    endedAt?: Date | undefined;
    testTemplateArn: string;
    serviceArn?: string | undefined;
    errorMessage?: string | undefined;
    accountTargeting?: AccountTargeting | undefined;
}
export type TestRunSummaryList = TestRunSummary[];
export interface ListTestRunsResponse {
    testRuns: TestRunSummary[];
    nextToken?: string | undefined;
}
export type TestRunSourceArn = string;
export interface ListTestRunSourceEventsRequest {
    testRunId: string;
    serviceArn: string;
    sourceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TestRunSourceEventType = "ALARM" | (string & {});
export type AlarmState = "OK" | "ALARM" | "INSUFFICIENT_DATA" | (string & {});
export interface AlarmStateChangeDetail {
    state: AlarmState;
    previousState?: AlarmState | undefined;
    reason?: string | undefined;
}
export type TestRunSourceEventErrorCode = "ACCESS_DENIED" | "INTERNAL_ERROR" | (string & {});
export interface TestRunSourceEventError {
    errorCode: TestRunSourceEventErrorCode;
    errorMessage: string;
}
export type TestRunSourceEventDetail = {
    alarmStateChange: AlarmStateChangeDetail;
    error?: undefined;
} | {
    alarmStateChange?: undefined;
    error: TestRunSourceEventError;
};
export interface TestRunSourceEvent {
    timestamp: Date;
    sourceArn: string;
    eventType: TestRunSourceEventType;
    detail: TestRunSourceEventDetail;
}
export type TestRunSourceEventList = TestRunSourceEvent[];
export interface ListTestRunSourceEventsResponse {
    testRunSourceEvents: TestRunSourceEvent[];
    nextToken?: string | undefined;
}
export type TestRunSourceType = "SUCCESS_CRITERIA" | "OBSERVABILITY" | (string & {});
export interface ListTestRunSourcesRequest {
    testRunId: string;
    serviceArn: string;
    type?: TestRunSourceType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TestSourceOutcome = "PASSED" | "FAILED" | "ERROR" | (string & {});
export interface TestRunSuccessCriteriaAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
    outcome?: TestSourceOutcome | undefined;
    outcomeReason?: string | undefined;
}
export interface TestRunObservabilityAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
}
export type TestRunSourceSummary = {
    successCriteriaAlarm: TestRunSuccessCriteriaAlarmSummary;
    observabilityAlarm?: undefined;
} | {
    successCriteriaAlarm?: undefined;
    observabilityAlarm: TestRunObservabilityAlarmSummary;
};
export type TestRunSourceSummaryList = TestRunSourceSummary[];
export interface ListTestRunSourcesResponse {
    testRunSources: TestRunSourceSummary[];
    nextToken?: string | undefined;
}
export interface ListTestsRequest {
    serviceArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TestSummary {
    testId: string;
    testTemplateArn: string;
    serviceArn: string;
    totalTestRuns: number;
    successfulTestRuns: number;
    creationTime: Date;
}
export type TestSummaryList = TestSummary[];
export interface ListTestsResponse {
    tests: TestSummary[];
    nextToken?: string | undefined;
}
export type TestSourceType = "SUCCESS_CRITERIA" | "OBSERVABILITY" | (string & {});
export interface ListTestSourcesRequest {
    testId: string;
    serviceArn: string;
    type?: TestSourceType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SuccessCriteriaAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
    createdAt?: Date | undefined;
}
export interface ObservabilityAlarmSummary {
    alarmArn: string;
    alarmName: string;
    region: string;
    accountId: string;
    createdAt?: Date | undefined;
}
export type TestSourceSummary = {
    successCriteriaAlarm: SuccessCriteriaAlarmSummary;
    observabilityAlarm?: undefined;
} | {
    successCriteriaAlarm?: undefined;
    observabilityAlarm: ObservabilityAlarmSummary;
};
export type TestSourceSummaryList = TestSourceSummary[];
export interface ListTestSourcesResponse {
    testSources: TestSourceSummary[];
    nextToken?: string | undefined;
}
export interface ListTestTemplatesRequest {
}
export interface TestTemplateSummary {
    testTemplateArn: string;
    name: string;
    description: string;
}
export type TestTemplateSummaryList = TestTemplateSummary[];
export interface ListTestTemplatesResponse {
    testTemplates: TestTemplateSummary[];
}
export interface ListUserJourneysRequest {
    systemArn: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface UserJourneySummary {
    userJourneyId: string;
    name: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type UserJourneySummaryList = UserJourneySummary[];
export interface ListUserJourneysResponse {
    userJourneySummaries: UserJourneySummary[];
    nextToken?: string | undefined;
}
export interface PutTestSourcesRequest {
    testId: string;
    serviceArn: string;
    testSources: TestSourceInput[];
}
export interface PutTestSourcesResponse {
}
export interface StartDependencyInsightsRequest {
    serviceArn: string;
    clientToken?: string | undefined;
}
export interface StartDependencyInsightsResponse {
    status: DependencyInsightsStatus;
}
export interface StartFailureModeAssessmentRequest {
    serviceArn: string;
    clientToken?: string | undefined;
}
export interface StartFailureModeAssessmentResponse {
    assessmentId?: string | undefined;
    serviceArn?: string | undefined;
    assessmentStatus?: AssessmentStatus | undefined;
    startedAt?: Date | undefined;
}
export interface StartTestRunRequest {
    testId: string;
    serviceArn: string;
}
export type ExperimentArnList = string[];
export interface StartTestRunResponse {
    testRunId: string;
    status: TestRunStatus;
    experimentArns: string[];
}
export interface StopTestRunRequest {
    testRunId: string;
    serviceArn: string;
}
export interface StopTestRunResponse {
    testRunId: string;
    status: TestRunStatus;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAssertionRequest {
    serviceArn: string;
    assertionId: string;
    text?: string | undefined;
}
export interface UpdateAssertionResponse {
    assertion: Assertion;
}
export interface UpdateDependencyRequest {
    serviceArn: string;
    dependencyId: string;
    criticality?: DependencyCriticality | undefined;
    comment?: string | undefined;
}
export interface UpdateDependencyResponse {
    dependencyId: string;
    dependencyName: string;
    location: string;
    criticality: DependencyCriticality;
    comment?: string | undefined;
    provider?: string | undefined;
    updatedAt: Date;
}
export interface UpdateFailureModeFindingRequest {
    findingId: string;
    status: FindingStatus;
    serviceArn: string;
    comment?: string | undefined;
}
export interface UpdateFailureModeFindingResponse {
    finding?: Finding | undefined;
}
export interface UpdatePolicyRequest {
    policyArn: string;
    description?: string | undefined;
    availabilitySlo?: AvailabilitySlo | undefined;
    multiAz?: MultiAzTargets | undefined;
    multiRegion?: MultiRegionTargets | undefined;
    dataRecovery?: DataRecoveryTargets | undefined;
    sharingEnabled?: boolean | undefined;
}
export interface UpdatePolicyResponse {
    policy: Policy;
}
export interface UpdateServiceRequest {
    serviceArn: string;
    description?: string | undefined;
    associatedSystems?: AssociatedSystem[] | undefined;
    policyArn?: string | undefined;
    regions?: string[] | undefined;
    permissionModel?: PermissionModel | undefined;
    dependencyDiscovery?: DependencyDiscoveryInput | undefined;
    reportConfiguration?: ServiceReportConfiguration | undefined;
    devOpsAgentConfiguration?: DevOpsAgentConfiguration | undefined;
}
export interface UpdateServiceResponse {
    service: Service;
}
export interface UpdateServiceFunctionRequest {
    serviceArn: string;
    serviceFunctionId: string;
    name?: string | undefined;
    description?: string | undefined;
    criticality?: ServiceFunctionCriticality | undefined;
}
export interface UpdateServiceFunctionResponse {
    serviceFunction: ServiceFunction;
}
export interface UpdateSystemRequest {
    systemArn: string;
    description?: string | undefined;
    sharingEnabled?: boolean | undefined;
}
export interface UpdateSystemResponse {
    system: System;
}
export interface UpdateTestRequest {
    testId: string;
    serviceArn: string;
    loggingConfiguration?: LoggingConfiguration | undefined;
    stopConditions?: StopCondition[] | undefined;
    roleName?: string | undefined;
    parameters?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface UpdateTestResponse {
    test: Test;
}
export interface UpdateUserJourneyRequest {
    systemArn: string;
    userJourneyId: string;
    name?: string | undefined;
    description?: string | undefined;
    policyArn?: string | undefined;
}
export interface UpdateUserJourneyResponse {
    userJourney: UserJourney;
}
export type ValidationExceptionReason = "INVALID_FIELD_VALUE" | "DUPLICATE_VALUE" | "MISSING_REQUIRED_FIELD" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateAssertionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a resilience assertion for a service.
 */
export declare const createAssertion: API.OperationMethod<CreateAssertionRequest & RegionInput, CreateAssertionResponse, CreateAssertionError, Credentials | HttpClient.HttpClient>;
export type CreateInputSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an input source for a service.
 */
export declare const createInputSource: API.OperationMethod<CreateInputSourceRequest & RegionInput, CreateInputSourceResponse, CreateInputSourceError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a resilience policy that defines availability and disaster recovery requirements.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyRequest & RegionInput, CreatePolicyResponse, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateReportError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * On-demand report creation. Idempotent -- duplicate requests with same clientToken return existing result.
 */
export declare const createReport: API.OperationMethod<CreateReportRequest & RegionInput, CreateReportResponse, CreateReportError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a service.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest & RegionInput, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type CreateServiceFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a service function within a service.
 */
export declare const createServiceFunction: API.OperationMethod<CreateServiceFunctionRequest & RegionInput, CreateServiceFunctionResponse, CreateServiceFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateServiceFunctionResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates resources with a service function.
 */
export declare const createServiceFunctionResources: API.OperationMethod<CreateServiceFunctionResourcesRequest & RegionInput, CreateServiceFunctionResourcesResponse, CreateServiceFunctionResourcesError, Credentials | HttpClient.HttpClient>;
export type CreateSystemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a system that represents a logical grouping of services.
 */
export declare const createSystem: API.OperationMethod<CreateSystemRequest & RegionInput, CreateSystemResponse, CreateSystemError, Credentials | HttpClient.HttpClient>;
export type CreateTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a test for a service by configuring a test template. Each service has one test per template.
 */
export declare const createTest: API.OperationMethod<CreateTestRequest & RegionInput, CreateTestResponse, CreateTestError, Credentials | HttpClient.HttpClient>;
export type CreateUserJourneyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a user journey within a system.
 */
export declare const createUserJourney: API.OperationMethod<CreateUserJourneyRequest & RegionInput, CreateUserJourneyResponse, CreateUserJourneyError, Credentials | HttpClient.HttpClient>;
export type DeleteAssertionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a resilience assertion from a service.
 */
export declare const deleteAssertion: API.OperationMethod<DeleteAssertionRequest & RegionInput, DeleteAssertionResponse, DeleteAssertionError, Credentials | HttpClient.HttpClient>;
export type DeleteInputSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an input source.
 */
export declare const deleteInputSource: API.OperationMethod<DeleteInputSourceRequest & RegionInput, DeleteInputSourceResponse, DeleteInputSourceError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a resilience policy.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyRequest & RegionInput, DeletePolicyResponse, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a service.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest & RegionInput, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a service function.
 */
export declare const deleteServiceFunction: API.OperationMethod<DeleteServiceFunctionRequest & RegionInput, DeleteServiceFunctionResponse, DeleteServiceFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceFunctionResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes resources from a service function.
 */
export declare const deleteServiceFunctionResources: API.OperationMethod<DeleteServiceFunctionResourcesRequest & RegionInput, DeleteServiceFunctionResourcesResponse, DeleteServiceFunctionResourcesError, Credentials | HttpClient.HttpClient>;
export type DeleteSystemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a system.
 */
export declare const deleteSystem: API.OperationMethod<DeleteSystemRequest & RegionInput, DeleteSystemResponse, DeleteSystemError, Credentials | HttpClient.HttpClient>;
export type DeleteTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a test.
 */
export declare const deleteTest: API.OperationMethod<DeleteTestRequest & RegionInput, DeleteTestResponse, DeleteTestError, Credentials | HttpClient.HttpClient>;
export type DeleteTestSourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes monitoring sources from a test. The operation is transactional and idempotent -- removing a source that is not attached is a no-op.
 */
export declare const deleteTestSources: API.OperationMethod<DeleteTestSourcesRequest & RegionInput, DeleteTestSourcesResponse, DeleteTestSourcesError, Credentials | HttpClient.HttpClient>;
export type DeleteUserJourneyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a user journey.
 */
export declare const deleteUserJourney: API.OperationMethod<DeleteUserJourneyRequest & RegionInput, DeleteUserJourneyResponse, DeleteUserJourneyError, Credentials | HttpClient.HttpClient>;
export type GetDependencyInsightsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the dependency insights generated for a service. The response reports the current generation status; insights are populated once generation has completed. If generation failed, the response includes an error code, whose possible values are listed under the response's errorCode field, and a message describing the cause. To use this operation, you must have the `resiliencehub:GetDependencyInsights` permission on the service.
 */
export declare const getDependencyInsights: API.OperationMethod<GetDependencyInsightsRequest & RegionInput, GetDependencyInsightsResponse, GetDependencyInsightsError, Credentials | HttpClient.HttpClient>;
export type GetFailureModeFindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a finding by findingId.
 */
export declare const getFailureModeFinding: API.OperationMethod<GetFailureModeFindingRequest & RegionInput, GetFailureModeFindingResponse, GetFailureModeFindingError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a resilience policy by ARN.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest & RegionInput, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a service by ARN.
 */
export declare const getService: API.OperationMethod<GetServiceRequest & RegionInput, GetServiceResponse, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetSystemError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a system by ARN.
 */
export declare const getSystem: API.OperationMethod<GetSystemRequest & RegionInput, GetSystemResponse, GetSystemError, Credentials | HttpClient.HttpClient>;
export type GetTestError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a test by ID.
 */
export declare const getTest: API.OperationMethod<GetTestRequest & RegionInput, GetTestResponse, GetTestError, Credentials | HttpClient.HttpClient>;
export type GetTestRunError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a test run by ID, including its status, results, and the configuration snapshotted when the run started.
 */
export declare const getTestRun: API.OperationMethod<GetTestRunRequest & RegionInput, GetTestRunResponse, GetTestRunError, Credentials | HttpClient.HttpClient>;
export type GetTestTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a resilience test template by ARN, including the parameters it accepts and the fault actions it runs.
 */
export declare const getTestTemplate: API.OperationMethod<GetTestTemplateRequest & RegionInput, GetTestTemplateResponse, GetTestTemplateError, Credentials | HttpClient.HttpClient>;
export type GetUserJourneyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves a user journey.
 */
export declare const getUserJourney: API.OperationMethod<GetUserJourneyRequest & RegionInput, GetUserJourneyResponse, GetUserJourneyError, Credentials | HttpClient.HttpClient>;
export type ImportAppError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Imports a V1 app into the V2 resource model, creating a service with the same name.
 */
export declare const importApp: API.OperationMethod<ImportAppRequest & RegionInput, ImportAppResponse, ImportAppError, Credentials | HttpClient.HttpClient>;
export type ImportPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Imports a V1 policy into V2, mapping RTO/RPO values from V1 scenarios.
 */
export declare const importPolicy: API.OperationMethod<ImportPolicyRequest & RegionInput, ImportPolicyResponse, ImportPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAssertionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists resilience assertions for a service.
 */
export declare const listAssertions: API.PaginatedOperationMethod<ListAssertionsRequest & RegionInput, ListAssertionsResponse, ListAssertionsError, Credentials | HttpClient.HttpClient, Assertion>;
export type ListDependenciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists dependencies discovered for services.
 */
export declare const listDependencies: API.PaginatedOperationMethod<ListDependenciesRequest & RegionInput, ListDependenciesResponse, ListDependenciesError, Credentials | HttpClient.HttpClient, DependencySummary>;
export type ListFailureModeAssessmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists failure mode assessments.
 */
export declare const listFailureModeAssessments: API.PaginatedOperationMethod<ListFailureModeAssessmentsRequest & RegionInput, ListFailureModeAssessmentsResponse, ListFailureModeAssessmentsError, Credentials | HttpClient.HttpClient, AssessmentSummary>;
export type ListFailureModeFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List findings.
 */
export declare const listFailureModeFindings: API.PaginatedOperationMethod<ListFailureModeFindingsRequest & RegionInput, ListFailureModeFindingsResponse, ListFailureModeFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListInputSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists input sources for a service.
 */
export declare const listInputSources: API.PaginatedOperationMethod<ListInputSourcesRequest & RegionInput, ListInputSourcesResponse, ListInputSourcesError, Credentials | HttpClient.HttpClient, InputSourceSummary>;
export type ListPoliciesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists resilience policies.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesRequest & RegionInput, ListPoliciesResponse, ListPoliciesError, Credentials | HttpClient.HttpClient, PolicySummary>;
export type ListPolicyEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists events for a resilience policy, including services that started or stopped using it, changes to cross-account sharing, and deletion of the policy.
 */
export declare const listPolicyEvents: API.PaginatedOperationMethod<ListPolicyEventsRequest & RegionInput, ListPolicyEventsResponse, ListPolicyEventsError, Credentials | HttpClient.HttpClient, PolicyEvent>;
export type ListReportsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List reports for a service, or all reports owned by the account if serviceArn is not provided.
 */
export declare const listReports: API.PaginatedOperationMethod<ListReportsRequest & RegionInput, ListReportsResponse, ListReportsError, Credentials | HttpClient.HttpClient, ReportGenerationResult>;
export type ListResolvedTestRunTargetResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the AWS resources that AWS Fault Injection Service (AWS FIS) resolved as targets for a test run.
 */
export declare const listResolvedTestRunTargetResources: API.PaginatedOperationMethod<ListResolvedTestRunTargetResourcesRequest & RegionInput, ListResolvedTestRunTargetResourcesResponse, ListResolvedTestRunTargetResourcesError, Credentials | HttpClient.HttpClient, ResolvedTargetResource>;
export type ListResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List resources.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest & RegionInput, ListResourcesResponse, ListResourcesError, Credentials | HttpClient.HttpClient, ServiceResource>;
export type ListServiceEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists events for a service.
 */
export declare const listServiceEvents: API.PaginatedOperationMethod<ListServiceEventsRequest & RegionInput, ListServiceEventsResponse, ListServiceEventsError, Credentials | HttpClient.HttpClient, ServiceEvent>;
export type ListServiceFunctionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists service functions for a service.
 */
export declare const listServiceFunctions: API.PaginatedOperationMethod<ListServiceFunctionsRequest & RegionInput, ListServiceFunctionsResponse, ListServiceFunctionsError, Credentials | HttpClient.HttpClient, ServiceFunction>;
export type ListServicesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists services.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest & RegionInput, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, ServiceSummary>;
export type ListServiceTopologyEdgesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists topology edges for a service.
 */
export declare const listServiceTopologyEdges: API.PaginatedOperationMethod<ListServiceTopologyEdgesRequest & RegionInput, ListServiceTopologyEdgesResponse, ListServiceTopologyEdgesError, Credentials | HttpClient.HttpClient, ServiceTopologyEdgeSummary>;
export type ListSystemEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists events for a system.
 */
export declare const listSystemEvents: API.PaginatedOperationMethod<ListSystemEventsRequest & RegionInput, ListSystemEventsResponse, ListSystemEventsError, Credentials | HttpClient.HttpClient, SystemEvent>;
export type ListSystemsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists systems.
 */
export declare const listSystems: API.PaginatedOperationMethod<ListSystemsRequest & RegionInput, ListSystemsResponse, ListSystemsError, Credentials | HttpClient.HttpClient, SystemSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTestRunDependenciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the dependencies that a test run blocked. Each dependency reflects the discovered classification captured when the run started, so results do not change if a dependency is reclassified after the run.
 */
export declare const listTestRunDependencies: API.PaginatedOperationMethod<ListTestRunDependenciesRequest & RegionInput, ListTestRunDependenciesResponse, ListTestRunDependenciesError, Credentials | HttpClient.HttpClient, TestRunDependencySummary>;
export type ListTestRunEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the events in a test run's timeline.
 */
export declare const listTestRunEvents: API.PaginatedOperationMethod<ListTestRunEventsRequest & RegionInput, ListTestRunEventsResponse, ListTestRunEventsError, Credentials | HttpClient.HttpClient, TestRunEvent>;
export type ListTestRunsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the runs of a test, or all test runs for a service.
 */
export declare const listTestRuns: API.PaginatedOperationMethod<ListTestRunsRequest & RegionInput, ListTestRunsResponse, ListTestRunsError, Credentials | HttpClient.HttpClient, TestRunSummary>;
export type ListTestRunSourceEventsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the state-change events observed for a test run monitoring source. Events are returned for one source per call, in chronological order.
 */
export declare const listTestRunSourceEvents: API.PaginatedOperationMethod<ListTestRunSourceEventsRequest & RegionInput, ListTestRunSourceEventsResponse, ListTestRunSourceEventsError, Credentials | HttpClient.HttpClient, TestRunSourceEvent>;
export type ListTestRunSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the monitoring source snapshots captured for a test run, optionally filtered by type.
 */
export declare const listTestRunSources: API.PaginatedOperationMethod<ListTestRunSourcesRequest & RegionInput, ListTestRunSourcesResponse, ListTestRunSourcesError, Credentials | HttpClient.HttpClient, TestRunSourceSummary>;
export type ListTestsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tests configured for a service.
 */
export declare const listTests: API.PaginatedOperationMethod<ListTestsRequest & RegionInput, ListTestsResponse, ListTestsError, Credentials | HttpClient.HttpClient, TestSummary>;
export type ListTestSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the monitoring sources attached to a test, optionally filtered by type.
 */
export declare const listTestSources: API.PaginatedOperationMethod<ListTestSourcesRequest & RegionInput, ListTestSourcesResponse, ListTestSourcesError, Credentials | HttpClient.HttpClient, TestSourceSummary>;
export type ListTestTemplatesError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the available resilience test templates. A test template is a pre-configured, AWS recommended test that defines which resilience capability to validate.
 */
export declare const listTestTemplates: API.OperationMethod<ListTestTemplatesRequest & RegionInput, ListTestTemplatesResponse, ListTestTemplatesError, Credentials | HttpClient.HttpClient>;
export type ListUserJourneysError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists user journeys for a system.
 */
export declare const listUserJourneys: API.PaginatedOperationMethod<ListUserJourneysRequest & RegionInput, ListUserJourneysResponse, ListUserJourneysError, Credentials | HttpClient.HttpClient, UserJourneySummary>;
export type PutTestSourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds or updates the monitoring sources on a test. The operation is transactional -- either every source is written or the call fails and nothing is written.
 */
export declare const putTestSources: API.OperationMethod<PutTestSourcesRequest & RegionInput, PutTestSourcesResponse, PutTestSourcesError, Credentials | HttpClient.HttpClient>;
export type StartDependencyInsightsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts generating dependency insights for a service. Generation runs asynchronously; the response returns the initial status, and you retrieve the results with GetDependencyInsights. To use this operation, you must have the `resiliencehub:StartDependencyInsights` permission on the service.
 */
export declare const startDependencyInsights: API.OperationMethod<StartDependencyInsightsRequest & RegionInput, StartDependencyInsightsResponse, StartDependencyInsightsError, Credentials | HttpClient.HttpClient>;
export type StartFailureModeAssessmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a failure mode assessment.
 */
export declare const startFailureModeAssessment: API.OperationMethod<StartFailureModeAssessmentRequest & RegionInput, StartFailureModeAssessmentResponse, StartFailureModeAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartTestRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Starts a run of a test. Each run scopes to the current resources in the service and produces a pass or fail outcome.
 */
export declare const startTestRun: API.OperationMethod<StartTestRunRequest & RegionInput, StartTestRunResponse, StartTestRunError, Credentials | HttpClient.HttpClient>;
export type StopTestRunError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Stops an in-progress test run.
 */
export declare const stopTestRun: API.OperationMethod<StopTestRunRequest & RegionInput, StopTestRunResponse, StopTestRunError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssertionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a resilience assertion.
 */
export declare const updateAssertion: API.OperationMethod<UpdateAssertionRequest & RegionInput, UpdateAssertionResponse, UpdateAssertionError, Credentials | HttpClient.HttpClient>;
export type UpdateDependencyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a dependency classification.
 */
export declare const updateDependency: API.OperationMethod<UpdateDependencyRequest & RegionInput, UpdateDependencyResponse, UpdateDependencyError, Credentials | HttpClient.HttpClient>;
export type UpdateFailureModeFindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing finding.
 */
export declare const updateFailureModeFinding: API.OperationMethod<UpdateFailureModeFindingRequest & RegionInput, UpdateFailureModeFindingResponse, UpdateFailureModeFindingError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing resilience policy.
 */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyRequest & RegionInput, UpdatePolicyResponse, UpdatePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an existing service.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest & RegionInput, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceFunctionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a service function.
 */
export declare const updateServiceFunction: API.OperationMethod<UpdateServiceFunctionRequest & RegionInput, UpdateServiceFunctionResponse, UpdateServiceFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateSystemError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing system.
 */
export declare const updateSystem: API.OperationMethod<UpdateSystemRequest & RegionInput, UpdateSystemResponse, UpdateSystemError, Credentials | HttpClient.HttpClient>;
export type UpdateTestError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an existing test.
 */
export declare const updateTest: API.OperationMethod<UpdateTestRequest & RegionInput, UpdateTestResponse, UpdateTestError, Credentials | HttpClient.HttpClient>;
export type UpdateUserJourneyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing user journey.
 */
export declare const updateUserJourney: API.OperationMethod<UpdateUserJourneyRequest & RegionInput, UpdateUserJourneyResponse, UpdateUserJourneyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=resiliencehubv2.d.ts.map