import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type Name = string;
export type ForecastType = string;
export type ForecastTypes = string[];
export type ForecastDimensions = string[];
export type Frequency = string;
export type Arn = string;
export type Value = string;
export type Transformations = {
    [key: string]: string | undefined;
};
export interface AttributeConfig {
    AttributeName: string;
    Transformations: {
        [key: string]: string | undefined;
    };
}
export type AttributeConfigs = AttributeConfig[];
export type Values = string[];
export type Configuration = {
    [key: string]: string[] | undefined;
};
export interface AdditionalDataset {
    Name: string;
    Configuration?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type AdditionalDatasets = AdditionalDataset[];
export interface DataConfig {
    DatasetGroupArn: string;
    AttributeConfigs?: AttributeConfig[] | undefined;
    AdditionalDatasets?: AdditionalDataset[] | undefined;
}
export type KMSKeyArn = string;
export interface EncryptionConfig {
    RoleArn: string;
    KMSKeyArn: string;
}
export type OptimizationMetric = "WAPE" | "RMSE" | "AverageWeightedQuantileLoss" | "MASE" | "MAPE" | (string & {});
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type Tags = Tag[];
export interface MonitorConfig {
    MonitorName: string;
}
export type Month = "JANUARY" | "FEBRUARY" | "MARCH" | "APRIL" | "MAY" | "JUNE" | "JULY" | "AUGUST" | "SEPTEMBER" | "OCTOBER" | "NOVEMBER" | "DECEMBER" | (string & {});
export type DayOfMonth = number;
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export type Hour = number;
export interface TimeAlignmentBoundary {
    Month?: Month | undefined;
    DayOfMonth?: number | undefined;
    DayOfWeek?: DayOfWeek | undefined;
    Hour?: number | undefined;
}
export interface CreateAutoPredictorRequest {
    PredictorName: string;
    ForecastHorizon?: number | undefined;
    ForecastTypes?: string[] | undefined;
    ForecastDimensions?: string[] | undefined;
    ForecastFrequency?: string | undefined;
    DataConfig?: DataConfig | undefined;
    EncryptionConfig?: EncryptionConfig | undefined;
    ReferencePredictorArn?: string | undefined;
    OptimizationMetric?: OptimizationMetric | undefined;
    ExplainPredictor?: boolean | undefined;
    Tags?: Tag[] | undefined;
    MonitorConfig?: MonitorConfig | undefined;
    TimeAlignmentBoundary?: TimeAlignmentBoundary | undefined;
}
export interface CreateAutoPredictorResponse {
    PredictorArn?: string | undefined;
}
export type Domain = "RETAIL" | "CUSTOM" | "INVENTORY_PLANNING" | "EC2_CAPACITY" | "WORK_FORCE" | "WEB_TRAFFIC" | "METRICS" | (string & {});
export type DatasetType = "TARGET_TIME_SERIES" | "RELATED_TIME_SERIES" | "ITEM_METADATA" | (string & {});
export type AttributeType = "string" | "integer" | "float" | "timestamp" | "geolocation" | (string & {});
export interface SchemaAttribute {
    AttributeName?: string | undefined;
    AttributeType?: AttributeType | undefined;
}
export type SchemaAttributes = SchemaAttribute[];
export interface Schema {
    Attributes?: SchemaAttribute[] | undefined;
}
export interface CreateDatasetRequest {
    DatasetName: string;
    Domain: Domain;
    DatasetType: DatasetType;
    DataFrequency?: string | undefined;
    Schema: Schema;
    EncryptionConfig?: EncryptionConfig | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDatasetResponse {
    DatasetArn?: string | undefined;
}
export type ArnList = string[];
export interface CreateDatasetGroupRequest {
    DatasetGroupName: string;
    Domain: Domain;
    DatasetArns?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDatasetGroupResponse {
    DatasetGroupArn?: string | undefined;
}
export type S3Path = string;
export interface S3Config {
    Path: string;
    RoleArn: string;
    KMSKeyArn?: string | undefined;
}
export interface DataSource {
    S3Config: S3Config;
}
export type TimestampFormat = string;
export type TimeZone = string;
export type UseGeolocationForTimeZone = boolean;
export type GeolocationFormat = string;
export type Format = string;
export type ImportMode = "FULL" | "INCREMENTAL" | (string & {});
export interface CreateDatasetImportJobRequest {
    DatasetImportJobName: string;
    DatasetArn: string;
    DataSource: DataSource;
    TimestampFormat?: string | undefined;
    TimeZone?: string | undefined;
    UseGeolocationForTimeZone?: boolean | undefined;
    GeolocationFormat?: string | undefined;
    Tags?: Tag[] | undefined;
    Format?: string | undefined;
    ImportMode?: ImportMode | undefined;
}
export interface CreateDatasetImportJobResponse {
    DatasetImportJobArn?: string | undefined;
}
export type TimeSeriesGranularity = "ALL" | "SPECIFIC" | (string & {});
export type TimePointGranularity = "ALL" | "SPECIFIC" | (string & {});
export interface ExplainabilityConfig {
    TimeSeriesGranularity: TimeSeriesGranularity;
    TimePointGranularity: TimePointGranularity;
}
export type LocalDateTime = string;
export interface CreateExplainabilityRequest {
    ExplainabilityName: string;
    ResourceArn: string;
    ExplainabilityConfig: ExplainabilityConfig;
    DataSource?: DataSource | undefined;
    Schema?: Schema | undefined;
    EnableVisualization?: boolean | undefined;
    StartDateTime?: string | undefined;
    EndDateTime?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateExplainabilityResponse {
    ExplainabilityArn?: string | undefined;
}
export interface DataDestination {
    S3Config: S3Config;
}
export interface CreateExplainabilityExportRequest {
    ExplainabilityExportName: string;
    ExplainabilityArn: string;
    Destination: DataDestination;
    Tags?: Tag[] | undefined;
    Format?: string | undefined;
}
export interface CreateExplainabilityExportResponse {
    ExplainabilityExportArn?: string | undefined;
}
export interface TimeSeriesIdentifiers {
    DataSource?: DataSource | undefined;
    Schema?: Schema | undefined;
    Format?: string | undefined;
}
export interface TimeSeriesSelector {
    TimeSeriesIdentifiers?: TimeSeriesIdentifiers | undefined;
}
export interface CreateForecastRequest {
    ForecastName: string;
    PredictorArn: string;
    ForecastTypes?: string[] | undefined;
    Tags?: Tag[] | undefined;
    TimeSeriesSelector?: TimeSeriesSelector | undefined;
}
export interface CreateForecastResponse {
    ForecastArn?: string | undefined;
}
export interface CreateForecastExportJobRequest {
    ForecastExportJobName: string;
    ForecastArn: string;
    Destination: DataDestination;
    Tags?: Tag[] | undefined;
    Format?: string | undefined;
}
export interface CreateForecastExportJobResponse {
    ForecastExportJobArn?: string | undefined;
}
export interface CreateMonitorRequest {
    MonitorName: string;
    ResourceArn: string;
    Tags?: Tag[] | undefined;
}
export interface CreateMonitorResponse {
    MonitorArn?: string | undefined;
}
export type AutoMLOverrideStrategy = "LatencyOptimized" | "AccuracyOptimized" | (string & {});
export type ParameterKey = string;
export type ParameterValue = string;
export type TrainingParameters = {
    [key: string]: string | undefined;
};
export interface EvaluationParameters {
    NumberOfBacktestWindows?: number | undefined;
    BackTestWindowOffset?: number | undefined;
}
export interface CategoricalParameterRange {
    Name: string;
    Values: string[];
}
export type CategoricalParameterRanges = CategoricalParameterRange[];
export type ScalingType = "Auto" | "Linear" | "Logarithmic" | "ReverseLogarithmic" | (string & {});
export interface ContinuousParameterRange {
    Name: string;
    MaxValue: number;
    MinValue: number;
    ScalingType?: ScalingType | undefined;
}
export type ContinuousParameterRanges = ContinuousParameterRange[];
export interface IntegerParameterRange {
    Name: string;
    MaxValue: number;
    MinValue: number;
    ScalingType?: ScalingType | undefined;
}
export type IntegerParameterRanges = IntegerParameterRange[];
export interface ParameterRanges {
    CategoricalParameterRanges?: CategoricalParameterRange[] | undefined;
    ContinuousParameterRanges?: ContinuousParameterRange[] | undefined;
    IntegerParameterRanges?: IntegerParameterRange[] | undefined;
}
export interface HyperParameterTuningJobConfig {
    ParameterRanges?: ParameterRanges | undefined;
}
export interface SupplementaryFeature {
    Name: string;
    Value: string;
}
export type SupplementaryFeatures = SupplementaryFeature[];
export interface InputDataConfig {
    DatasetGroupArn: string;
    SupplementaryFeatures?: SupplementaryFeature[] | undefined;
}
export type FeaturizationMethodName = "filling" | (string & {});
export type FeaturizationMethodParameters = {
    [key: string]: string | undefined;
};
export interface FeaturizationMethod {
    FeaturizationMethodName: FeaturizationMethodName;
    FeaturizationMethodParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FeaturizationPipeline = FeaturizationMethod[];
export interface Featurization {
    AttributeName: string;
    FeaturizationPipeline?: FeaturizationMethod[] | undefined;
}
export type Featurizations = Featurization[];
export interface FeaturizationConfig {
    ForecastFrequency: string;
    ForecastDimensions?: string[] | undefined;
    Featurizations?: Featurization[] | undefined;
}
export interface CreatePredictorRequest {
    PredictorName: string;
    AlgorithmArn?: string | undefined;
    ForecastHorizon: number;
    ForecastTypes?: string[] | undefined;
    PerformAutoML?: boolean | undefined;
    AutoMLOverrideStrategy?: AutoMLOverrideStrategy | undefined;
    PerformHPO?: boolean | undefined;
    TrainingParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    EvaluationParameters?: EvaluationParameters | undefined;
    HPOConfig?: HyperParameterTuningJobConfig | undefined;
    InputDataConfig: InputDataConfig;
    FeaturizationConfig: FeaturizationConfig;
    EncryptionConfig?: EncryptionConfig | undefined;
    Tags?: Tag[] | undefined;
    OptimizationMetric?: OptimizationMetric | undefined;
}
export interface CreatePredictorResponse {
    PredictorArn?: string | undefined;
}
export interface CreatePredictorBacktestExportJobRequest {
    PredictorBacktestExportJobName: string;
    PredictorArn: string;
    Destination: DataDestination;
    Tags?: Tag[] | undefined;
    Format?: string | undefined;
}
export interface CreatePredictorBacktestExportJobResponse {
    PredictorBacktestExportJobArn?: string | undefined;
}
export interface CreateWhatIfAnalysisRequest {
    WhatIfAnalysisName: string;
    ForecastArn: string;
    TimeSeriesSelector?: TimeSeriesSelector | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateWhatIfAnalysisResponse {
    WhatIfAnalysisArn?: string | undefined;
}
export type Operation = "ADD" | "SUBTRACT" | "MULTIPLY" | "DIVIDE" | (string & {});
export interface Action {
    AttributeName: string;
    Operation: Operation;
    Value: number;
}
export type AttributeValue = string;
export type Condition = "EQUALS" | "NOT_EQUALS" | "LESS_THAN" | "GREATER_THAN" | (string & {});
export interface TimeSeriesCondition {
    AttributeName: string;
    AttributeValue: string;
    Condition: Condition;
}
export type TimeSeriesConditions = TimeSeriesCondition[];
export interface TimeSeriesTransformation {
    Action?: Action | undefined;
    TimeSeriesConditions?: TimeSeriesCondition[] | undefined;
}
export type TimeSeriesTransformations = TimeSeriesTransformation[];
export interface TimeSeriesReplacementsDataSource {
    S3Config: S3Config;
    Schema: Schema;
    Format?: string | undefined;
    TimestampFormat?: string | undefined;
}
export interface CreateWhatIfForecastRequest {
    WhatIfForecastName: string;
    WhatIfAnalysisArn: string;
    TimeSeriesTransformations?: TimeSeriesTransformation[] | undefined;
    TimeSeriesReplacementsDataSource?: TimeSeriesReplacementsDataSource | undefined;
    Tags?: Tag[] | undefined;
}
export type LongArn = string;
export interface CreateWhatIfForecastResponse {
    WhatIfForecastArn?: string | undefined;
}
export type WhatIfForecastArnListForExport = string[];
export interface CreateWhatIfForecastExportRequest {
    WhatIfForecastExportName: string;
    WhatIfForecastArns: string[];
    Destination: DataDestination;
    Tags?: Tag[] | undefined;
    Format?: string | undefined;
}
export interface CreateWhatIfForecastExportResponse {
    WhatIfForecastExportArn?: string | undefined;
}
export interface DeleteDatasetRequest {
    DatasetArn: string;
}
export interface DeleteDatasetResponse {
}
export interface DeleteDatasetGroupRequest {
    DatasetGroupArn: string;
}
export interface DeleteDatasetGroupResponse {
}
export interface DeleteDatasetImportJobRequest {
    DatasetImportJobArn: string;
}
export interface DeleteDatasetImportJobResponse {
}
export interface DeleteExplainabilityRequest {
    ExplainabilityArn: string;
}
export interface DeleteExplainabilityResponse {
}
export interface DeleteExplainabilityExportRequest {
    ExplainabilityExportArn: string;
}
export interface DeleteExplainabilityExportResponse {
}
export interface DeleteForecastRequest {
    ForecastArn: string;
}
export interface DeleteForecastResponse {
}
export interface DeleteForecastExportJobRequest {
    ForecastExportJobArn: string;
}
export interface DeleteForecastExportJobResponse {
}
export interface DeleteMonitorRequest {
    MonitorArn: string;
}
export interface DeleteMonitorResponse {
}
export interface DeletePredictorRequest {
    PredictorArn: string;
}
export interface DeletePredictorResponse {
}
export interface DeletePredictorBacktestExportJobRequest {
    PredictorBacktestExportJobArn: string;
}
export interface DeletePredictorBacktestExportJobResponse {
}
export interface DeleteResourceTreeRequest {
    ResourceArn: string;
}
export interface DeleteResourceTreeResponse {
}
export interface DeleteWhatIfAnalysisRequest {
    WhatIfAnalysisArn: string;
}
export interface DeleteWhatIfAnalysisResponse {
}
export interface DeleteWhatIfForecastRequest {
    WhatIfForecastArn: string;
}
export interface DeleteWhatIfForecastResponse {
}
export interface DeleteWhatIfForecastExportRequest {
    WhatIfForecastExportArn: string;
}
export interface DeleteWhatIfForecastExportResponse {
}
export interface DescribeAutoPredictorRequest {
    PredictorArn: string;
}
export type State = "Active" | "Deleted" | (string & {});
export interface ReferencePredictorSummary {
    Arn?: string | undefined;
    State?: State | undefined;
}
export type Status = string;
export type Message = string;
export interface ExplainabilityInfo {
    ExplainabilityArn?: string | undefined;
    Status?: string | undefined;
}
export interface MonitorInfo {
    MonitorArn?: string | undefined;
    Status?: string | undefined;
}
export interface DescribeAutoPredictorResponse {
    PredictorArn?: string | undefined;
    PredictorName?: string | undefined;
    ForecastHorizon?: number | undefined;
    ForecastTypes?: string[] | undefined;
    ForecastFrequency?: string | undefined;
    ForecastDimensions?: string[] | undefined;
    DatasetImportJobArns?: string[] | undefined;
    DataConfig?: DataConfig | undefined;
    EncryptionConfig?: EncryptionConfig | undefined;
    ReferencePredictorSummary?: ReferencePredictorSummary | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    OptimizationMetric?: OptimizationMetric | undefined;
    ExplainabilityInfo?: ExplainabilityInfo | undefined;
    MonitorInfo?: MonitorInfo | undefined;
    TimeAlignmentBoundary?: TimeAlignmentBoundary | undefined;
}
export interface DescribeDatasetRequest {
    DatasetArn: string;
}
export interface DescribeDatasetResponse {
    DatasetArn?: string | undefined;
    DatasetName?: string | undefined;
    Domain?: Domain | undefined;
    DatasetType?: DatasetType | undefined;
    DataFrequency?: string | undefined;
    Schema?: Schema | undefined;
    EncryptionConfig?: EncryptionConfig | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export interface DescribeDatasetGroupRequest {
    DatasetGroupArn: string;
}
export interface DescribeDatasetGroupResponse {
    DatasetGroupName?: string | undefined;
    DatasetGroupArn?: string | undefined;
    DatasetArns?: string[] | undefined;
    Domain?: Domain | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export interface DescribeDatasetImportJobRequest {
    DatasetImportJobArn: string;
}
export interface Statistics {
    Count?: number | undefined;
    CountDistinct?: number | undefined;
    CountNull?: number | undefined;
    CountNan?: number | undefined;
    Min?: string | undefined;
    Max?: string | undefined;
    Avg?: number | undefined;
    Stddev?: number | undefined;
    CountLong?: number | undefined;
    CountDistinctLong?: number | undefined;
    CountNullLong?: number | undefined;
    CountNanLong?: number | undefined;
}
export type FieldStatistics = {
    [key: string]: Statistics | undefined;
};
export interface DescribeDatasetImportJobResponse {
    DatasetImportJobName?: string | undefined;
    DatasetImportJobArn?: string | undefined;
    DatasetArn?: string | undefined;
    TimestampFormat?: string | undefined;
    TimeZone?: string | undefined;
    UseGeolocationForTimeZone?: boolean | undefined;
    GeolocationFormat?: string | undefined;
    DataSource?: DataSource | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    FieldStatistics?: {
        [key: string]: Statistics | undefined;
    } | undefined;
    DataSize?: number | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    Format?: string | undefined;
    ImportMode?: ImportMode | undefined;
}
export interface DescribeExplainabilityRequest {
    ExplainabilityArn: string;
}
export interface DescribeExplainabilityResponse {
    ExplainabilityArn?: string | undefined;
    ExplainabilityName?: string | undefined;
    ResourceArn?: string | undefined;
    ExplainabilityConfig?: ExplainabilityConfig | undefined;
    EnableVisualization?: boolean | undefined;
    DataSource?: DataSource | undefined;
    Schema?: Schema | undefined;
    StartDateTime?: string | undefined;
    EndDateTime?: string | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    Message?: string | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export interface DescribeExplainabilityExportRequest {
    ExplainabilityExportArn: string;
}
export interface DescribeExplainabilityExportResponse {
    ExplainabilityExportArn?: string | undefined;
    ExplainabilityExportName?: string | undefined;
    ExplainabilityArn?: string | undefined;
    Destination?: DataDestination | undefined;
    Message?: string | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    Format?: string | undefined;
}
export interface DescribeForecastRequest {
    ForecastArn: string;
}
export type ErrorMessage = string;
export interface DescribeForecastResponse {
    ForecastArn?: string | undefined;
    ForecastName?: string | undefined;
    ForecastTypes?: string[] | undefined;
    PredictorArn?: string | undefined;
    DatasetGroupArn?: string | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    TimeSeriesSelector?: TimeSeriesSelector | undefined;
}
export interface DescribeForecastExportJobRequest {
    ForecastExportJobArn: string;
}
export interface DescribeForecastExportJobResponse {
    ForecastExportJobArn?: string | undefined;
    ForecastExportJobName?: string | undefined;
    ForecastArn?: string | undefined;
    Destination?: DataDestination | undefined;
    Message?: string | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    Format?: string | undefined;
}
export interface DescribeMonitorRequest {
    MonitorArn: string;
}
export type EvaluationState = string;
export interface BaselineMetric {
    Name?: string | undefined;
    Value?: number | undefined;
}
export type BaselineMetrics = BaselineMetric[];
export interface PredictorBaseline {
    BaselineMetrics?: BaselineMetric[] | undefined;
}
export interface Baseline {
    PredictorBaseline?: PredictorBaseline | undefined;
}
export interface DescribeMonitorResponse {
    MonitorName?: string | undefined;
    MonitorArn?: string | undefined;
    ResourceArn?: string | undefined;
    Status?: string | undefined;
    LastEvaluationTime?: Date | undefined;
    LastEvaluationState?: string | undefined;
    Baseline?: Baseline | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    EstimatedEvaluationTimeRemainingInMinutes?: number | undefined;
}
export interface DescribePredictorRequest {
    PredictorArn: string;
}
export interface TestWindowSummary {
    TestWindowStart?: Date | undefined;
    TestWindowEnd?: Date | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
}
export type TestWindowDetails = TestWindowSummary[];
export interface PredictorExecution {
    AlgorithmArn?: string | undefined;
    TestWindows?: TestWindowSummary[] | undefined;
}
export type PredictorExecutions = PredictorExecution[];
export interface PredictorExecutionDetails {
    PredictorExecutions?: PredictorExecution[] | undefined;
}
export interface DescribePredictorResponse {
    PredictorArn?: string | undefined;
    PredictorName?: string | undefined;
    AlgorithmArn?: string | undefined;
    AutoMLAlgorithmArns?: string[] | undefined;
    ForecastHorizon?: number | undefined;
    ForecastTypes?: string[] | undefined;
    PerformAutoML?: boolean | undefined;
    AutoMLOverrideStrategy?: AutoMLOverrideStrategy | undefined;
    PerformHPO?: boolean | undefined;
    TrainingParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    EvaluationParameters?: EvaluationParameters | undefined;
    HPOConfig?: HyperParameterTuningJobConfig | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    FeaturizationConfig?: FeaturizationConfig | undefined;
    EncryptionConfig?: EncryptionConfig | undefined;
    PredictorExecutionDetails?: PredictorExecutionDetails | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    IsAutoPredictor?: boolean | undefined;
    DatasetImportJobArns?: string[] | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    OptimizationMetric?: OptimizationMetric | undefined;
}
export interface DescribePredictorBacktestExportJobRequest {
    PredictorBacktestExportJobArn: string;
}
export interface DescribePredictorBacktestExportJobResponse {
    PredictorBacktestExportJobArn?: string | undefined;
    PredictorBacktestExportJobName?: string | undefined;
    PredictorArn?: string | undefined;
    Destination?: DataDestination | undefined;
    Message?: string | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    Format?: string | undefined;
}
export interface DescribeWhatIfAnalysisRequest {
    WhatIfAnalysisArn: string;
}
export interface DescribeWhatIfAnalysisResponse {
    WhatIfAnalysisName?: string | undefined;
    WhatIfAnalysisArn?: string | undefined;
    ForecastArn?: string | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    TimeSeriesSelector?: TimeSeriesSelector | undefined;
}
export interface DescribeWhatIfForecastRequest {
    WhatIfForecastArn: string;
}
export interface DescribeWhatIfForecastResponse {
    WhatIfForecastName?: string | undefined;
    WhatIfForecastArn?: string | undefined;
    WhatIfAnalysisArn?: string | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    TimeSeriesTransformations?: TimeSeriesTransformation[] | undefined;
    TimeSeriesReplacementsDataSource?: TimeSeriesReplacementsDataSource | undefined;
    ForecastTypes?: string[] | undefined;
}
export interface DescribeWhatIfForecastExportRequest {
    WhatIfForecastExportArn: string;
}
export type LongArnList = string[];
export interface DescribeWhatIfForecastExportResponse {
    WhatIfForecastExportArn?: string | undefined;
    WhatIfForecastExportName?: string | undefined;
    WhatIfForecastArns?: string[] | undefined;
    Destination?: DataDestination | undefined;
    Message?: string | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    EstimatedTimeRemainingInMinutes?: number | undefined;
    LastModificationTime?: Date | undefined;
    Format?: string | undefined;
}
export interface GetAccuracyMetricsRequest {
    PredictorArn: string;
}
export type EvaluationType = "SUMMARY" | "COMPUTED" | (string & {});
export interface WeightedQuantileLoss {
    Quantile?: number | undefined;
    LossValue?: number | undefined;
}
export type WeightedQuantileLosses = WeightedQuantileLoss[];
export interface ErrorMetric {
    ForecastType?: string | undefined;
    WAPE?: number | undefined;
    RMSE?: number | undefined;
    MASE?: number | undefined;
    MAPE?: number | undefined;
}
export type ErrorMetrics = ErrorMetric[];
export interface Metrics {
    RMSE?: number | undefined;
    WeightedQuantileLosses?: WeightedQuantileLoss[] | undefined;
    ErrorMetrics?: ErrorMetric[] | undefined;
    AverageWeightedQuantileLoss?: number | undefined;
}
export interface WindowSummary {
    TestWindowStart?: Date | undefined;
    TestWindowEnd?: Date | undefined;
    ItemCount?: number | undefined;
    EvaluationType?: EvaluationType | undefined;
    Metrics?: Metrics | undefined;
}
export type TestWindows = WindowSummary[];
export interface EvaluationResult {
    AlgorithmArn?: string | undefined;
    TestWindows?: WindowSummary[] | undefined;
}
export type PredictorEvaluationResults = EvaluationResult[];
export interface GetAccuracyMetricsResponse {
    PredictorEvaluationResults?: EvaluationResult[] | undefined;
    IsAutoPredictor?: boolean | undefined;
    AutoMLOverrideStrategy?: AutoMLOverrideStrategy | undefined;
    OptimizationMetric?: OptimizationMetric | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListDatasetGroupsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DatasetGroupSummary {
    DatasetGroupArn?: string | undefined;
    DatasetGroupName?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type DatasetGroups = DatasetGroupSummary[];
export interface ListDatasetGroupsResponse {
    DatasetGroups?: DatasetGroupSummary[] | undefined;
    NextToken?: string | undefined;
}
export type FilterConditionString = "IS" | "IS_NOT" | (string & {});
export interface Filter {
    Key: string;
    Value: string;
    Condition: FilterConditionString;
}
export type Filters = Filter[];
export interface ListDatasetImportJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface DatasetImportJobSummary {
    DatasetImportJobArn?: string | undefined;
    DatasetImportJobName?: string | undefined;
    DataSource?: DataSource | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
    ImportMode?: ImportMode | undefined;
}
export type DatasetImportJobs = DatasetImportJobSummary[];
export interface ListDatasetImportJobsResponse {
    DatasetImportJobs?: DatasetImportJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDatasetsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DatasetSummary {
    DatasetArn?: string | undefined;
    DatasetName?: string | undefined;
    DatasetType?: DatasetType | undefined;
    Domain?: Domain | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type Datasets = DatasetSummary[];
export interface ListDatasetsResponse {
    Datasets?: DatasetSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExplainabilitiesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface ExplainabilitySummary {
    ExplainabilityArn?: string | undefined;
    ExplainabilityName?: string | undefined;
    ResourceArn?: string | undefined;
    ExplainabilityConfig?: ExplainabilityConfig | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type Explainabilities = ExplainabilitySummary[];
export interface ListExplainabilitiesResponse {
    Explainabilities?: ExplainabilitySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExplainabilityExportsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface ExplainabilityExportSummary {
    ExplainabilityExportArn?: string | undefined;
    ExplainabilityExportName?: string | undefined;
    Destination?: DataDestination | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type ExplainabilityExports = ExplainabilityExportSummary[];
export interface ListExplainabilityExportsResponse {
    ExplainabilityExports?: ExplainabilityExportSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListForecastExportJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface ForecastExportJobSummary {
    ForecastExportJobArn?: string | undefined;
    ForecastExportJobName?: string | undefined;
    Destination?: DataDestination | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type ForecastExportJobs = ForecastExportJobSummary[];
export interface ListForecastExportJobsResponse {
    ForecastExportJobs?: ForecastExportJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListForecastsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface ForecastSummary {
    ForecastArn?: string | undefined;
    ForecastName?: string | undefined;
    PredictorArn?: string | undefined;
    CreatedUsingAutoPredictor?: boolean | undefined;
    DatasetGroupArn?: string | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type Forecasts = ForecastSummary[];
export interface ListForecastsResponse {
    Forecasts?: ForecastSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMonitorEvaluationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    MonitorArn: string;
    Filters?: Filter[] | undefined;
}
export type Detail = string;
export interface PredictorEvent {
    Detail?: string | undefined;
    Datetime?: Date | undefined;
}
export interface MonitorDataSource {
    DatasetImportJobArn?: string | undefined;
    ForecastArn?: string | undefined;
    PredictorArn?: string | undefined;
}
export type MetricName = string;
export interface MetricResult {
    MetricName?: string | undefined;
    MetricValue?: number | undefined;
}
export type MetricResults = MetricResult[];
export interface PredictorMonitorEvaluation {
    ResourceArn?: string | undefined;
    MonitorArn?: string | undefined;
    EvaluationTime?: Date | undefined;
    EvaluationState?: string | undefined;
    WindowStartDatetime?: Date | undefined;
    WindowEndDatetime?: Date | undefined;
    PredictorEvent?: PredictorEvent | undefined;
    MonitorDataSource?: MonitorDataSource | undefined;
    MetricResults?: MetricResult[] | undefined;
    NumItemsEvaluated?: number | undefined;
    Message?: string | undefined;
}
export type PredictorMonitorEvaluations = PredictorMonitorEvaluation[];
export interface ListMonitorEvaluationsResponse {
    NextToken?: string | undefined;
    PredictorMonitorEvaluations?: PredictorMonitorEvaluation[] | undefined;
}
export interface ListMonitorsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface MonitorSummary {
    MonitorArn?: string | undefined;
    MonitorName?: string | undefined;
    ResourceArn?: string | undefined;
    Status?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type Monitors = MonitorSummary[];
export interface ListMonitorsResponse {
    Monitors?: MonitorSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPredictorBacktestExportJobsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface PredictorBacktestExportJobSummary {
    PredictorBacktestExportJobArn?: string | undefined;
    PredictorBacktestExportJobName?: string | undefined;
    Destination?: DataDestination | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type PredictorBacktestExportJobs = PredictorBacktestExportJobSummary[];
export interface ListPredictorBacktestExportJobsResponse {
    PredictorBacktestExportJobs?: PredictorBacktestExportJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPredictorsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface PredictorSummary {
    PredictorArn?: string | undefined;
    PredictorName?: string | undefined;
    DatasetGroupArn?: string | undefined;
    IsAutoPredictor?: boolean | undefined;
    ReferencePredictorSummary?: ReferencePredictorSummary | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type Predictors = PredictorSummary[];
export interface ListPredictorsResponse {
    Predictors?: PredictorSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListWhatIfAnalysesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface WhatIfAnalysisSummary {
    WhatIfAnalysisArn?: string | undefined;
    WhatIfAnalysisName?: string | undefined;
    ForecastArn?: string | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type WhatIfAnalyses = WhatIfAnalysisSummary[];
export interface ListWhatIfAnalysesResponse {
    WhatIfAnalyses?: WhatIfAnalysisSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListWhatIfForecastExportsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface WhatIfForecastExportSummary {
    WhatIfForecastExportArn?: string | undefined;
    WhatIfForecastArns?: string[] | undefined;
    WhatIfForecastExportName?: string | undefined;
    Destination?: DataDestination | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type WhatIfForecastExports = WhatIfForecastExportSummary[];
export interface ListWhatIfForecastExportsResponse {
    WhatIfForecastExports?: WhatIfForecastExportSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListWhatIfForecastsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: Filter[] | undefined;
}
export interface WhatIfForecastSummary {
    WhatIfForecastArn?: string | undefined;
    WhatIfForecastName?: string | undefined;
    WhatIfAnalysisArn?: string | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
    CreationTime?: Date | undefined;
    LastModificationTime?: Date | undefined;
}
export type WhatIfForecasts = WhatIfForecastSummary[];
export interface ListWhatIfForecastsResponse {
    WhatIfForecasts?: WhatIfForecastSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ResumeResourceRequest {
    ResourceArn: string;
}
export interface ResumeResourceResponse {
}
export interface StopResourceRequest {
    ResourceArn: string;
}
export interface StopResourceResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateDatasetGroupRequest {
    DatasetGroupArn: string;
    DatasetArns: string[];
}
export interface UpdateDatasetGroupResponse {
}
export type CreateAutoPredictorError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an Amazon Forecast predictor.
 *
 * Amazon Forecast creates predictors with AutoPredictor, which involves applying the
 * optimal combination of algorithms to each time series in your datasets. You can use
 * CreateAutoPredictor to create new predictors or upgrade/retrain
 * existing predictors.
 *
 * **Creating new predictors**
 *
 * The following parameters are required when creating a new predictor:
 *
 * - `PredictorName` - A unique name for the predictor.
 *
 * - `DatasetGroupArn` - The ARN of the dataset group used to train the
 * predictor.
 *
 * - `ForecastFrequency` - The granularity of your forecasts (hourly,
 * daily, weekly, etc).
 *
 * - `ForecastHorizon` - The number of time-steps that the model
 * predicts. The forecast horizon is also called the prediction length.
 *
 * When creating a new predictor, do not specify a value for
 * `ReferencePredictorArn`.
 *
 * **Upgrading and retraining predictors**
 *
 * The following parameters are required when retraining or upgrading a predictor:
 *
 * - `PredictorName` - A unique name for the predictor.
 *
 * - `ReferencePredictorArn` - The ARN of the predictor to retrain or
 * upgrade.
 *
 * When upgrading or retraining a predictor, only specify values for the
 * `ReferencePredictorArn` and `PredictorName`.
 */
export declare const createAutoPredictor: API.OperationMethod<CreateAutoPredictorRequest & RegionInput, CreateAutoPredictorResponse, CreateAutoPredictorError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates an Amazon Forecast dataset. The information about the dataset that you provide helps
 * Forecast understand how to consume the data for model training. This includes the
 * following:
 *
 * -
 * `DataFrequency`
 * - How frequently your historical
 * time-series data is collected.
 *
 * -
 * `Domain`
 * and
 *
 * `DatasetType`
 * - Each dataset has an associated dataset
 * domain and a type within the domain. Amazon Forecast provides a list of predefined domains and
 * types within each domain. For each unique dataset domain and type within the domain,
 * Amazon Forecast requires your data to include a minimum set of predefined fields.
 *
 * -
 * `Schema`
 * - A schema specifies the fields in the dataset,
 * including the field name and data type.
 *
 * After creating a dataset, you import your training data into it and add the dataset to a
 * dataset group. You use the dataset group to create a predictor. For more information, see
 * Importing datasets.
 *
 * To get a list of all your datasets, use the ListDatasets operation.
 *
 * For example Forecast datasets, see the Amazon Forecast Sample GitHub
 * repository.
 *
 * The `Status` of a dataset must be `ACTIVE` before you can import
 * training data. Use the DescribeDataset operation to get
 * the status.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest & RegionInput, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetGroupError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a dataset group, which holds a collection of related datasets. You can add
 * datasets to the dataset group when you create the dataset group, or later by using the UpdateDatasetGroup operation.
 *
 * After creating a dataset group and adding datasets, you use the dataset group when you
 * create a predictor. For more information, see Dataset groups.
 *
 * To get a list of all your datasets groups, use the ListDatasetGroups
 * operation.
 *
 * The `Status` of a dataset group must be `ACTIVE` before you can
 * use the dataset group to create a predictor. To get the status, use the DescribeDatasetGroup operation.
 */
export declare const createDatasetGroup: API.OperationMethod<CreateDatasetGroupRequest & RegionInput, CreateDatasetGroupResponse, CreateDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetImportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Imports your training data to an Amazon Forecast dataset. You provide the location of your
 * training data in an Amazon Simple Storage Service (Amazon S3) bucket and the Amazon Resource Name (ARN) of the dataset
 * that you want to import the data to.
 *
 * You must specify a DataSource object that includes an
 * Identity and Access Management (IAM) role that Amazon Forecast can assume to access the data, as Amazon Forecast makes a copy
 * of your data and processes it in an internal Amazon Web Services system. For more information, see Set up
 * permissions.
 *
 * The training data must be in CSV or Parquet format. The delimiter must be a comma (,).
 *
 * You can specify the path to a specific file, the S3 bucket, or to a folder in the S3
 * bucket. For the latter two cases, Amazon Forecast imports all files up to the limit of 10,000
 * files.
 *
 * Because dataset imports are not aggregated, your most recent dataset import is the one
 * that is used when training a predictor or generating a forecast. Make sure that your most
 * recent dataset import contains all of the data you want to model off of, and not just the new
 * data collected since the previous import.
 *
 * To get a list of all your dataset import jobs, filtered by specified criteria, use the
 * ListDatasetImportJobs operation.
 */
export declare const createDatasetImportJob: API.OperationMethod<CreateDatasetImportJobRequest & RegionInput, CreateDatasetImportJobResponse, CreateDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateExplainabilityError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Explainability is only available for Forecasts and Predictors generated from an
 * AutoPredictor (CreateAutoPredictor)
 *
 * Creates an Amazon Forecast Explainability.
 *
 * Explainability helps you better understand how the attributes in your datasets impact
 * forecast. Amazon Forecast uses a metric called Impact scores to quantify the relative
 * impact of each attribute and determine whether they increase or decrease forecast
 * values.
 *
 * To enable Forecast Explainability, your predictor must include at least one of the
 * following: related time series, item metadata, or additional datasets like Holidays and
 * the Weather Index.
 *
 * CreateExplainability accepts either a Predictor ARN or Forecast ARN. To receive
 * aggregated Impact scores for all time series and time points in your datasets, provide a
 * Predictor ARN. To receive Impact scores for specific time series and time points,
 * provide a Forecast ARN.
 *
 * **CreateExplainability with a Predictor ARN**
 *
 * You can only have one Explainability resource per predictor. If you already
 * enabled `ExplainPredictor` in CreateAutoPredictor, that
 * predictor already has an Explainability resource.
 *
 * The following parameters are required when providing a Predictor ARN:
 *
 * - `ExplainabilityName` - A unique name for the Explainability.
 *
 * - `ResourceArn` - The Arn of the predictor.
 *
 * - `TimePointGranularity` - Must be set to "ALL".
 *
 * - `TimeSeriesGranularity` - Must be set to "ALL".
 *
 * Do not specify a value for the following parameters:
 *
 * - `DataSource` - Only valid when TimeSeriesGranularity is
 * "SPECIFIC".
 *
 * - `Schema` - Only valid when TimeSeriesGranularity is
 * "SPECIFIC".
 *
 * - `StartDateTime` - Only valid when TimePointGranularity is
 * "SPECIFIC".
 *
 * - `EndDateTime` - Only valid when TimePointGranularity is
 * "SPECIFIC".
 *
 * **CreateExplainability with a Forecast ARN**
 *
 * You can specify a maximum of 50 time series and 500 time points.
 *
 * The following parameters are required when providing a Predictor ARN:
 *
 * - `ExplainabilityName` - A unique name for the Explainability.
 *
 * - `ResourceArn` - The Arn of the forecast.
 *
 * - `TimePointGranularity` - Either "ALL" or "SPECIFIC".
 *
 * - `TimeSeriesGranularity` - Either "ALL" or "SPECIFIC".
 *
 * If you set TimeSeriesGranularity to "SPECIFIC", you must also provide the
 * following:
 *
 * - `DataSource` - The S3 location of the CSV file specifying your time
 * series.
 *
 * - `Schema` - The Schema defines the attributes and attribute types
 * listed in the Data Source.
 *
 * If you set TimePointGranularity to "SPECIFIC", you must also provide the
 * following:
 *
 * - `StartDateTime` - The first timestamp in the range of time
 * points.
 *
 * - `EndDateTime` - The last timestamp in the range of time
 * points.
 */
export declare const createExplainability: API.OperationMethod<CreateExplainabilityRequest & RegionInput, CreateExplainabilityResponse, CreateExplainabilityError, Credentials | HttpClient.HttpClient>;
export type CreateExplainabilityExportError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports an Explainability resource created by the CreateExplainability operation. Exported files are exported to an Amazon Simple Storage Service (Amazon
 * S3) bucket.
 *
 * You must specify a DataDestination object that includes an Amazon S3
 * bucket and an Identity and Access Management (IAM) role that Amazon Forecast can assume to access the Amazon S3
 * bucket. For more information, see aws-forecast-iam-roles.
 *
 * The `Status` of the export job must be `ACTIVE` before you
 * can access the export in your Amazon S3 bucket. To get the status, use the DescribeExplainabilityExport operation.
 */
export declare const createExplainabilityExport: API.OperationMethod<CreateExplainabilityExportRequest & RegionInput, CreateExplainabilityExportResponse, CreateExplainabilityExportError, Credentials | HttpClient.HttpClient>;
export type CreateForecastError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a forecast for each item in the `TARGET_TIME_SERIES` dataset that was
 * used to train the predictor. This is known as inference. To retrieve the forecast for a single
 * item at low latency, use the operation. To
 * export the complete forecast into your Amazon Simple Storage Service (Amazon S3) bucket, use the CreateForecastExportJob operation.
 *
 * The range of the forecast is determined by the `ForecastHorizon` value, which
 * you specify in the CreatePredictor request. When you query a forecast, you
 * can request a specific date range within the forecast.
 *
 * To get a list of all your forecasts, use the ListForecasts
 * operation.
 *
 * The forecasts generated by Amazon Forecast are in the same time zone as the dataset that was
 * used to create the predictor.
 *
 * For more information, see howitworks-forecast.
 *
 * The `Status` of the forecast must be `ACTIVE` before you can query
 * or export the forecast. Use the DescribeForecast operation to get the
 * status.
 *
 * By default, a forecast includes predictions for every item (`item_id`) in the dataset group that was used to train the predictor.
 * However, you can use the `TimeSeriesSelector` object to generate a forecast on a subset of time series. Forecast creation is skipped for any time series that you specify that are not in the input dataset. The forecast export file will not contain these time series or their forecasted values.
 */
export declare const createForecast: API.OperationMethod<CreateForecastRequest & RegionInput, CreateForecastResponse, CreateForecastError, Credentials | HttpClient.HttpClient>;
export type CreateForecastExportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports a forecast created by the CreateForecast operation to your
 * Amazon Simple Storage Service (Amazon S3) bucket. The forecast file name will match the following conventions:
 *
 * __
 *
 * where the component is in Java SimpleDateFormat
 * (yyyy-MM-ddTHH-mm-ssZ).
 *
 * You must specify a DataDestination object that includes an Identity and Access Management
 * (IAM) role that Amazon Forecast can assume to access the Amazon S3 bucket. For more information, see
 * aws-forecast-iam-roles.
 *
 * For more information, see howitworks-forecast.
 *
 * To get a list of all your forecast export jobs, use the ListForecastExportJobs operation.
 *
 * The `Status` of the forecast export job must be `ACTIVE` before
 * you can access the forecast in your Amazon S3 bucket. To get the status, use the DescribeForecastExportJob operation.
 */
export declare const createForecastExportJob: API.OperationMethod<CreateForecastExportJobRequest & RegionInput, CreateForecastExportJobResponse, CreateForecastExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateMonitorError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a predictor monitor resource for an existing auto predictor. Predictor monitoring allows you to see how your predictor's performance changes over time.
 * For more information, see Predictor Monitoring.
 */
export declare const createMonitor: API.OperationMethod<CreateMonitorRequest & RegionInput, CreateMonitorResponse, CreateMonitorError, Credentials | HttpClient.HttpClient>;
export type CreatePredictorError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * This operation creates a legacy predictor that does not include all the predictor
 * functionalities provided by Amazon Forecast. To create a predictor that is compatible with all
 * aspects of Forecast, use CreateAutoPredictor.
 *
 * Creates an Amazon Forecast predictor.
 *
 * In the request, provide a dataset group and either specify an algorithm or let Amazon Forecast
 * choose an algorithm for you using AutoML. If you specify an algorithm, you also can override
 * algorithm-specific hyperparameters.
 *
 * Amazon Forecast uses the algorithm to train a predictor using the latest version of the datasets
 * in the specified dataset group. You can then generate a forecast using the CreateForecast operation.
 *
 * To see the evaluation metrics, use the GetAccuracyMetrics operation.
 *
 * You can specify a featurization configuration to fill and aggregate the data fields in the
 * `TARGET_TIME_SERIES` dataset to improve model training. For more information, see
 * FeaturizationConfig.
 *
 * For RELATED_TIME_SERIES datasets, `CreatePredictor` verifies that the
 * `DataFrequency` specified when the dataset was created matches the
 * `ForecastFrequency`. TARGET_TIME_SERIES datasets don't have this restriction.
 * Amazon Forecast also verifies the delimiter and timestamp format. For more information, see howitworks-datasets-groups.
 *
 * By default, predictors are trained and evaluated at the 0.1 (P10), 0.5 (P50), and 0.9
 * (P90) quantiles. You can choose custom forecast types to train and evaluate your predictor by
 * setting the `ForecastTypes`.
 *
 * **AutoML**
 *
 * If you want Amazon Forecast to evaluate each algorithm and choose the one that minimizes the
 * `objective function`, set `PerformAutoML` to `true`. The
 * `objective function` is defined as the mean of the weighted losses over the
 * forecast types. By default, these are the p10, p50, and p90 quantile losses. For more
 * information, see EvaluationResult.
 *
 * When AutoML is enabled, the following properties are disallowed:
 *
 * - `AlgorithmArn`
 *
 * - `HPOConfig`
 *
 * - `PerformHPO`
 *
 * - `TrainingParameters`
 *
 * To get a list of all of your predictors, use the ListPredictors
 * operation.
 *
 * Before you can use the predictor to create a forecast, the `Status` of the
 * predictor must be `ACTIVE`, signifying that training has completed. To get the
 * status, use the DescribePredictor operation.
 */
export declare const createPredictor: API.OperationMethod<CreatePredictorRequest & RegionInput, CreatePredictorResponse, CreatePredictorError, Credentials | HttpClient.HttpClient>;
export type CreatePredictorBacktestExportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports backtest forecasts and accuracy metrics generated by the CreateAutoPredictor or CreatePredictor operations. Two
 * folders containing CSV or Parquet files are exported to your specified S3 bucket.
 *
 * The export file names will match the following conventions:
 *
 * `__.csv`
 *
 * The component is in Java SimpleDate format
 * (yyyy-MM-ddTHH-mm-ssZ).
 *
 * You must specify a DataDestination object that includes an Amazon S3
 * bucket and an Identity and Access Management (IAM) role that Amazon Forecast can assume to access the Amazon S3
 * bucket. For more information, see aws-forecast-iam-roles.
 *
 * The `Status` of the export job must be `ACTIVE` before you
 * can access the export in your Amazon S3 bucket. To get the status, use the DescribePredictorBacktestExportJob operation.
 */
export declare const createPredictorBacktestExportJob: API.OperationMethod<CreatePredictorBacktestExportJobRequest & RegionInput, CreatePredictorBacktestExportJobResponse, CreatePredictorBacktestExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateWhatIfAnalysisError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * What-if analysis is a scenario modeling technique where you make a hypothetical change to a time series and
 * compare the forecasts generated by these changes against the baseline, unchanged time series. It is important to
 * remember that the purpose of a what-if analysis is to understand how a forecast can change given different
 * modifications to the baseline time series.
 *
 * For example, imagine you are a clothing retailer who is considering an end of season sale
 * to clear space for new styles. After creating a baseline forecast, you can use a what-if
 * analysis to investigate how different sales tactics might affect your goals.
 *
 * You could create a scenario where everything is given a 25% markdown, and another where
 * everything is given a fixed dollar markdown. You could create a scenario where the sale lasts for one week and
 * another where the sale lasts for one month.
 * With a what-if analysis, you can compare many different scenarios against each other.
 *
 * Note that a what-if analysis is meant to display what the forecasting model has learned and how it will behave in the scenarios that you are evaluating. Do not blindly use the results of the what-if analysis to make business decisions. For instance, forecasts might not be accurate for novel scenarios where there is no reference available to determine whether a forecast is good.
 *
 * The TimeSeriesSelector object defines the items that you want in the what-if analysis.
 */
export declare const createWhatIfAnalysis: API.OperationMethod<CreateWhatIfAnalysisRequest & RegionInput, CreateWhatIfAnalysisResponse, CreateWhatIfAnalysisError, Credentials | HttpClient.HttpClient>;
export type CreateWhatIfForecastError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * A what-if forecast is a forecast that is created from a modified version of the baseline forecast. Each
 * what-if forecast incorporates either a replacement dataset or a set of transformations to the original dataset.
 */
export declare const createWhatIfForecast: API.OperationMethod<CreateWhatIfForecastRequest & RegionInput, CreateWhatIfForecastResponse, CreateWhatIfForecastError, Credentials | HttpClient.HttpClient>;
export type CreateWhatIfForecastExportError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Exports a forecast created by the CreateWhatIfForecast operation to your
 * Amazon Simple Storage Service (Amazon S3) bucket. The forecast file name will match the following conventions:
 *
 * `~__`
 *
 * The component is in Java SimpleDateFormat
 * (yyyy-MM-ddTHH-mm-ssZ).
 *
 * You must specify a DataDestination object that includes an Identity and Access Management
 * (IAM) role that Amazon Forecast can assume to access the Amazon S3 bucket. For more information, see
 * aws-forecast-iam-roles.
 *
 * For more information, see howitworks-forecast.
 *
 * To get a list of all your what-if forecast export jobs, use the ListWhatIfForecastExports
 * operation.
 *
 * The `Status` of the forecast export job must be `ACTIVE` before
 * you can access the forecast in your Amazon S3 bucket. To get the status, use the DescribeWhatIfForecastExport operation.
 */
export declare const createWhatIfForecastExport: API.OperationMethod<CreateWhatIfForecastExportRequest & RegionInput, CreateWhatIfForecastExportResponse, CreateWhatIfForecastExportError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon Forecast dataset that was created using the CreateDataset operation. You can
 * only delete datasets that have a status of `ACTIVE` or `CREATE_FAILED`.
 * To get the status use the DescribeDataset operation.
 *
 * Forecast does not automatically update any dataset groups that contain the deleted dataset.
 * In order to update the dataset group, use the UpdateDatasetGroup operation,
 * omitting the deleted dataset's ARN.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest & RegionInput, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetGroupError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataset group created using the CreateDatasetGroup operation.
 * You can only delete dataset groups that have a status of `ACTIVE`,
 * `CREATE_FAILED`, or `UPDATE_FAILED`. To get the status, use the DescribeDatasetGroup operation.
 *
 * This operation deletes only the dataset group, not the datasets in the group.
 */
export declare const deleteDatasetGroup: API.OperationMethod<DeleteDatasetGroupRequest & RegionInput, DeleteDatasetGroupResponse, DeleteDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetImportJobError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataset import job created using the CreateDatasetImportJob
 * operation. You can delete only dataset import jobs that have a status of `ACTIVE`
 * or `CREATE_FAILED`. To get the status, use the DescribeDatasetImportJob
 * operation.
 */
export declare const deleteDatasetImportJob: API.OperationMethod<DeleteDatasetImportJobRequest & RegionInput, DeleteDatasetImportJobResponse, DeleteDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteExplainabilityError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Explainability resource.
 *
 * You can delete only predictor that have a status of `ACTIVE` or
 * `CREATE_FAILED`. To get the status, use the DescribeExplainability operation.
 */
export declare const deleteExplainability: API.OperationMethod<DeleteExplainabilityRequest & RegionInput, DeleteExplainabilityResponse, DeleteExplainabilityError, Credentials | HttpClient.HttpClient>;
export type DeleteExplainabilityExportError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Explainability export.
 */
export declare const deleteExplainabilityExport: API.OperationMethod<DeleteExplainabilityExportRequest & RegionInput, DeleteExplainabilityExportResponse, DeleteExplainabilityExportError, Credentials | HttpClient.HttpClient>;
export type DeleteForecastError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a forecast created using the CreateForecast operation. You can
 * delete only forecasts that have a status of `ACTIVE` or `CREATE_FAILED`.
 * To get the status, use the DescribeForecast operation.
 *
 * You can't delete a forecast while it is being exported. After a forecast is deleted, you
 * can no longer query the forecast.
 */
export declare const deleteForecast: API.OperationMethod<DeleteForecastRequest & RegionInput, DeleteForecastResponse, DeleteForecastError, Credentials | HttpClient.HttpClient>;
export type DeleteForecastExportJobError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a forecast export job created using the CreateForecastExportJob
 * operation. You can delete only export jobs that have a status of `ACTIVE` or
 * `CREATE_FAILED`. To get the status, use the DescribeForecastExportJob operation.
 */
export declare const deleteForecastExportJob: API.OperationMethod<DeleteForecastExportJobRequest & RegionInput, DeleteForecastExportJobResponse, DeleteForecastExportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitorError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a monitor resource. You can only delete a monitor resource with a status of `ACTIVE`, `ACTIVE_STOPPED`, `CREATE_FAILED`, or `CREATE_STOPPED`.
 */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorRequest & RegionInput, DeleteMonitorResponse, DeleteMonitorError, Credentials | HttpClient.HttpClient>;
export type DeletePredictorError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a predictor created using the DescribePredictor or CreatePredictor operations. You can delete only predictor that have a status of
 * `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribePredictor operation.
 */
export declare const deletePredictor: API.OperationMethod<DeletePredictorRequest & RegionInput, DeletePredictorResponse, DeletePredictorError, Credentials | HttpClient.HttpClient>;
export type DeletePredictorBacktestExportJobError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a predictor backtest export job.
 */
export declare const deletePredictorBacktestExportJob: API.OperationMethod<DeletePredictorBacktestExportJobRequest & RegionInput, DeletePredictorBacktestExportJobResponse, DeletePredictorBacktestExportJobError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceTreeError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an entire resource tree. This operation will delete the parent resource and
 * its child resources.
 *
 * Child resources are resources that were created from another resource. For example,
 * when a forecast is generated from a predictor, the forecast is the child resource and
 * the predictor is the parent resource.
 *
 * Amazon Forecast resources possess the following parent-child resource hierarchies:
 *
 * - **Dataset**: dataset import jobs
 *
 * - **Dataset Group**: predictors, predictor backtest
 * export jobs, forecasts, forecast export jobs
 *
 * - **Predictor**: predictor backtest export jobs,
 * forecasts, forecast export jobs
 *
 * - **Forecast**: forecast export jobs
 *
 * `DeleteResourceTree` will only delete Amazon Forecast resources, and will not
 * delete datasets or exported files stored in Amazon S3.
 */
export declare const deleteResourceTree: API.OperationMethod<DeleteResourceTreeRequest & RegionInput, DeleteResourceTreeResponse, DeleteResourceTreeError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatIfAnalysisError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a what-if analysis created using the CreateWhatIfAnalysis
 * operation. You can delete only what-if analyses that have a status of `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribeWhatIfAnalysis operation.
 *
 * You can't delete a what-if analysis while any of its forecasts are being exported.
 */
export declare const deleteWhatIfAnalysis: API.OperationMethod<DeleteWhatIfAnalysisRequest & RegionInput, DeleteWhatIfAnalysisResponse, DeleteWhatIfAnalysisError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatIfForecastError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a what-if forecast created using the CreateWhatIfForecast
 * operation. You can delete only what-if forecasts that have a status of `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribeWhatIfForecast operation.
 *
 * You can't delete a what-if forecast while it is being exported. After a what-if forecast is deleted, you can no longer query the what-if analysis.
 */
export declare const deleteWhatIfForecast: API.OperationMethod<DeleteWhatIfForecastRequest & RegionInput, DeleteWhatIfForecastResponse, DeleteWhatIfForecastError, Credentials | HttpClient.HttpClient>;
export type DeleteWhatIfForecastExportError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a what-if forecast export created using the CreateWhatIfForecastExport
 * operation. You can delete only what-if forecast exports that have a status of `ACTIVE` or `CREATE_FAILED`. To get the status, use the DescribeWhatIfForecastExport operation.
 */
export declare const deleteWhatIfForecastExport: API.OperationMethod<DeleteWhatIfForecastExportRequest & RegionInput, DeleteWhatIfForecastExportResponse, DeleteWhatIfForecastExportError, Credentials | HttpClient.HttpClient>;
export type DescribeAutoPredictorError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a predictor created using the CreateAutoPredictor operation.
 */
export declare const describeAutoPredictor: API.OperationMethod<DescribeAutoPredictorRequest & RegionInput, DescribeAutoPredictorResponse, DescribeAutoPredictorError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an Amazon Forecast dataset created using the CreateDataset operation.
 *
 * In addition to listing the parameters specified in the `CreateDataset` request,
 * this operation includes the following dataset properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest & RegionInput, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetGroupError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a dataset group created using the CreateDatasetGroup
 * operation.
 *
 * In addition to listing the parameters provided in the `CreateDatasetGroup`
 * request, this operation includes the following properties:
 *
 * - `DatasetArns` - The datasets belonging to the group.
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 */
export declare const describeDatasetGroup: API.OperationMethod<DescribeDatasetGroupRequest & RegionInput, DescribeDatasetGroupResponse, DescribeDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetImportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a dataset import job created using the CreateDatasetImportJob
 * operation.
 *
 * In addition to listing the parameters provided in the `CreateDatasetImportJob`
 * request, this operation includes the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `DataSize`
 *
 * - `FieldStatistics`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describeDatasetImportJob: API.OperationMethod<DescribeDatasetImportJobRequest & RegionInput, DescribeDatasetImportJobResponse, DescribeDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeExplainabilityError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an Explainability resource created using the CreateExplainability operation.
 */
export declare const describeExplainability: API.OperationMethod<DescribeExplainabilityRequest & RegionInput, DescribeExplainabilityResponse, DescribeExplainabilityError, Credentials | HttpClient.HttpClient>;
export type DescribeExplainabilityExportError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an Explainability export created using the CreateExplainabilityExport operation.
 */
export declare const describeExplainabilityExport: API.OperationMethod<DescribeExplainabilityExportRequest & RegionInput, DescribeExplainabilityExportResponse, DescribeExplainabilityExportError, Credentials | HttpClient.HttpClient>;
export type DescribeForecastError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a forecast created using the CreateForecast operation.
 *
 * In addition to listing the properties provided in the `CreateForecast` request,
 * this operation lists the following properties:
 *
 * - `DatasetGroupArn` - The dataset group that provided the training
 * data.
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describeForecast: API.OperationMethod<DescribeForecastRequest & RegionInput, DescribeForecastResponse, DescribeForecastError, Credentials | HttpClient.HttpClient>;
export type DescribeForecastExportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a forecast export job created using the CreateForecastExportJob operation.
 *
 * In addition to listing the properties provided by the user in the
 * `CreateForecastExportJob` request, this operation lists the following
 * properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describeForecastExportJob: API.OperationMethod<DescribeForecastExportJobRequest & RegionInput, DescribeForecastExportJobResponse, DescribeForecastExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeMonitorError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a monitor resource. In addition to listing the properties provided in the CreateMonitor request, this operation lists the following properties:
 *
 * - `Baseline`
 *
 * - `CreationTime`
 *
 * - `LastEvaluationTime`
 *
 * - `LastEvaluationState`
 *
 * - `LastModificationTime`
 *
 * - `Message`
 *
 * - `Status`
 */
export declare const describeMonitor: API.OperationMethod<DescribeMonitorRequest & RegionInput, DescribeMonitorResponse, DescribeMonitorError, Credentials | HttpClient.HttpClient>;
export type DescribePredictorError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * This operation is only valid for legacy predictors created with CreatePredictor. If you
 * are not using a legacy predictor, use DescribeAutoPredictor.
 *
 * Describes a predictor created using the CreatePredictor
 * operation.
 *
 * In addition to listing the properties provided in the `CreatePredictor`
 * request, this operation lists the following properties:
 *
 * - `DatasetImportJobArns` - The dataset import jobs used to import training
 * data.
 *
 * - `AutoMLAlgorithmArns` - If AutoML is performed, the algorithms that were
 * evaluated.
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` - If an error occurred, information about the error.
 */
export declare const describePredictor: API.OperationMethod<DescribePredictorRequest & RegionInput, DescribePredictorResponse, DescribePredictorError, Credentials | HttpClient.HttpClient>;
export type DescribePredictorBacktestExportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a predictor backtest export job created using the CreatePredictorBacktestExportJob operation.
 *
 * In addition to listing the properties provided by the user in the
 * `CreatePredictorBacktestExportJob` request, this operation lists the
 * following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Status`
 *
 * - `Message` (if an error occurred)
 */
export declare const describePredictorBacktestExportJob: API.OperationMethod<DescribePredictorBacktestExportJobRequest & RegionInput, DescribePredictorBacktestExportJobResponse, DescribePredictorBacktestExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeWhatIfAnalysisError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the what-if analysis created using the CreateWhatIfAnalysis operation.
 *
 * In addition to listing the properties provided in the `CreateWhatIfAnalysis` request, this operation lists the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Message` - If an error occurred, information about the error.
 *
 * - `Status`
 */
export declare const describeWhatIfAnalysis: API.OperationMethod<DescribeWhatIfAnalysisRequest & RegionInput, DescribeWhatIfAnalysisResponse, DescribeWhatIfAnalysisError, Credentials | HttpClient.HttpClient>;
export type DescribeWhatIfForecastError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the what-if forecast created using the CreateWhatIfForecast operation.
 *
 * In addition to listing the properties provided in the `CreateWhatIfForecast` request, this operation lists the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Message` - If an error occurred, information about the error.
 *
 * - `Status`
 */
export declare const describeWhatIfForecast: API.OperationMethod<DescribeWhatIfForecastRequest & RegionInput, DescribeWhatIfForecastResponse, DescribeWhatIfForecastError, Credentials | HttpClient.HttpClient>;
export type DescribeWhatIfForecastExportError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the what-if forecast export created using the CreateWhatIfForecastExport operation.
 *
 * In addition to listing the properties provided in the `CreateWhatIfForecastExport` request, this operation lists the following properties:
 *
 * - `CreationTime`
 *
 * - `LastModificationTime`
 *
 * - `Message` - If an error occurred, information about the error.
 *
 * - `Status`
 */
export declare const describeWhatIfForecastExport: API.OperationMethod<DescribeWhatIfForecastExportRequest & RegionInput, DescribeWhatIfForecastExportResponse, DescribeWhatIfForecastExportError, Credentials | HttpClient.HttpClient>;
export type GetAccuracyMetricsError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Provides metrics on the accuracy of the models that were trained by the CreatePredictor operation. Use metrics to see how well the model performed and
 * to decide whether to use the predictor to generate a forecast. For more information, see
 * Predictor
 * Metrics.
 *
 * This operation generates metrics for each backtest window that was evaluated. The number
 * of backtest windows (`NumberOfBacktestWindows`) is specified using the EvaluationParameters object, which is optionally included in the
 * `CreatePredictor` request. If `NumberOfBacktestWindows` isn't
 * specified, the number defaults to one.
 *
 * The parameters of the `filling` method determine which items contribute to the
 * metrics. If you want all items to contribute, specify `zero`. If you want only
 * those items that have complete data in the range being evaluated to contribute, specify
 * `nan`. For more information, see FeaturizationMethod.
 *
 * Before you can get accuracy metrics, the `Status` of the predictor must be
 * `ACTIVE`, signifying that training has completed. To get the status, use the
 * DescribePredictor operation.
 */
export declare const getAccuracyMetrics: API.OperationMethod<GetAccuracyMetricsRequest & RegionInput, GetAccuracyMetricsResponse, GetAccuracyMetricsError, Credentials | HttpClient.HttpClient>;
export type ListDatasetGroupsError = InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset groups created using the CreateDatasetGroup operation.
 * For each dataset group, this operation returns a summary of its properties, including its
 * Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the
 * dataset group ARN with the DescribeDatasetGroup
 * operation.
 */
export declare const listDatasetGroups: API.PaginatedOperationMethod<ListDatasetGroupsRequest & RegionInput, ListDatasetGroupsResponse, ListDatasetGroupsError, Credentials | HttpClient.HttpClient, DatasetGroupSummary>;
export type ListDatasetImportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset import jobs created using the CreateDatasetImportJob
 * operation. For each import job, this operation returns a summary of its properties, including
 * its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the
 * ARN with the DescribeDatasetImportJob
 * operation. You can filter the list by providing an array of Filter objects.
 */
export declare const listDatasetImportJobs: API.PaginatedOperationMethod<ListDatasetImportJobsRequest & RegionInput, ListDatasetImportJobsResponse, ListDatasetImportJobsError, Credentials | HttpClient.HttpClient, DatasetImportJobSummary>;
export type ListDatasetsError = InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of datasets created using the CreateDataset operation. For each
 * dataset, a summary of its properties, including its Amazon Resource Name (ARN), is returned.
 * To retrieve the complete set of properties, use the ARN with the DescribeDataset operation.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest & RegionInput, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, DatasetSummary>;
export type ListExplainabilitiesError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of Explainability resources created using the CreateExplainability operation. This operation returns a summary for
 * each Explainability. You can filter the list using an array of Filter
 * objects.
 *
 * To retrieve the complete set of properties for a particular Explainability resource,
 * use the ARN with the DescribeExplainability operation.
 */
export declare const listExplainabilities: API.PaginatedOperationMethod<ListExplainabilitiesRequest & RegionInput, ListExplainabilitiesResponse, ListExplainabilitiesError, Credentials | HttpClient.HttpClient, ExplainabilitySummary>;
export type ListExplainabilityExportsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of Explainability exports created using the CreateExplainabilityExport operation. This operation returns a summary
 * for each Explainability export. You can filter the list using an array of Filter objects.
 *
 * To retrieve the complete set of properties for a particular Explainability export, use
 * the ARN with the DescribeExplainability operation.
 */
export declare const listExplainabilityExports: API.PaginatedOperationMethod<ListExplainabilityExportsRequest & RegionInput, ListExplainabilityExportsResponse, ListExplainabilityExportsError, Credentials | HttpClient.HttpClient, ExplainabilityExportSummary>;
export type ListForecastExportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of forecast export jobs created using the CreateForecastExportJob operation. For each forecast export job, this operation
 * returns a summary of its properties, including its Amazon Resource Name (ARN). To retrieve the
 * complete set of properties, use the ARN with the DescribeForecastExportJob
 * operation. You can filter the list using an array of Filter objects.
 */
export declare const listForecastExportJobs: API.PaginatedOperationMethod<ListForecastExportJobsRequest & RegionInput, ListForecastExportJobsResponse, ListForecastExportJobsError, Credentials | HttpClient.HttpClient, ForecastExportJobSummary>;
export type ListForecastsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of forecasts created using the CreateForecast operation.
 * For each forecast, this operation returns a summary of its properties, including its Amazon
 * Resource Name (ARN). To retrieve the complete set of properties, specify the ARN with the
 * DescribeForecast operation. You can filter the list using an array of
 * Filter objects.
 */
export declare const listForecasts: API.PaginatedOperationMethod<ListForecastsRequest & RegionInput, ListForecastsResponse, ListForecastsError, Credentials | HttpClient.HttpClient, ForecastSummary>;
export type ListMonitorEvaluationsError = InvalidInputException | InvalidNextTokenException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of the monitoring evaluation results and predictor events collected by
 * the monitor resource during different windows of time.
 *
 * For information about monitoring see predictor-monitoring. For
 * more information about retrieving monitoring results see Viewing Monitoring Results.
 */
export declare const listMonitorEvaluations: API.PaginatedOperationMethod<ListMonitorEvaluationsRequest & RegionInput, ListMonitorEvaluationsResponse, ListMonitorEvaluationsError, Credentials | HttpClient.HttpClient, PredictorMonitorEvaluation>;
export type ListMonitorsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of monitors created with the CreateMonitor operation and CreateAutoPredictor operation. For each monitor resource, this operation returns of a summary of its properties, including its Amazon Resource Name (ARN). You
 * can retrieve a complete set of properties of a monitor resource by specify the monitor's ARN in the DescribeMonitor operation.
 */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsRequest & RegionInput, ListMonitorsResponse, ListMonitorsError, Credentials | HttpClient.HttpClient, MonitorSummary>;
export type ListPredictorBacktestExportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of predictor backtest export jobs created using the CreatePredictorBacktestExportJob operation. This operation returns a
 * summary for each backtest export job. You can filter the list using an array of Filter objects.
 *
 * To retrieve the complete set of properties for a particular backtest export job, use
 * the ARN with the DescribePredictorBacktestExportJob operation.
 */
export declare const listPredictorBacktestExportJobs: API.PaginatedOperationMethod<ListPredictorBacktestExportJobsRequest & RegionInput, ListPredictorBacktestExportJobsResponse, ListPredictorBacktestExportJobsError, Credentials | HttpClient.HttpClient, PredictorBacktestExportJobSummary>;
export type ListPredictorsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of predictors created using the CreateAutoPredictor or
 * CreatePredictor operations. For each predictor, this operation returns a
 * summary of its properties, including its Amazon Resource Name (ARN).
 *
 * You can retrieve the complete set of properties by using the ARN with the DescribeAutoPredictor and DescribePredictor operations. You
 * can filter the list using an array of Filter objects.
 */
export declare const listPredictors: API.PaginatedOperationMethod<ListPredictorsRequest & RegionInput, ListPredictorsResponse, ListPredictorsError, Credentials | HttpClient.HttpClient, PredictorSummary>;
export type ListTagsForResourceError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for an Amazon Forecast resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWhatIfAnalysesError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of what-if analyses created using the CreateWhatIfAnalysis operation. For each what-if analysis, this operation returns a summary of its properties, including its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the what-if analysis ARN with the DescribeWhatIfAnalysis operation.
 */
export declare const listWhatIfAnalyses: API.PaginatedOperationMethod<ListWhatIfAnalysesRequest & RegionInput, ListWhatIfAnalysesResponse, ListWhatIfAnalysesError, Credentials | HttpClient.HttpClient, WhatIfAnalysisSummary>;
export type ListWhatIfForecastExportsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of what-if forecast exports created using the CreateWhatIfForecastExport operation. For each what-if forecast export, this operation returns a summary of its properties, including its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the what-if forecast export ARN with the DescribeWhatIfForecastExport operation.
 */
export declare const listWhatIfForecastExports: API.PaginatedOperationMethod<ListWhatIfForecastExportsRequest & RegionInput, ListWhatIfForecastExportsResponse, ListWhatIfForecastExportsError, Credentials | HttpClient.HttpClient, WhatIfForecastExportSummary>;
export type ListWhatIfForecastsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of what-if forecasts created using the CreateWhatIfForecast operation. For each what-if forecast, this operation returns a summary of its properties, including its Amazon Resource Name (ARN). You can retrieve the complete set of properties by using the what-if forecast ARN with the DescribeWhatIfForecast operation.
 */
export declare const listWhatIfForecasts: API.PaginatedOperationMethod<ListWhatIfForecastsRequest & RegionInput, ListWhatIfForecastsResponse, ListWhatIfForecastsError, Credentials | HttpClient.HttpClient, WhatIfForecastSummary>;
export type ResumeResourceError = InvalidInputException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Resumes a stopped monitor resource.
 */
export declare const resumeResource: API.OperationMethod<ResumeResourceRequest & RegionInput, ResumeResourceResponse, ResumeResourceError, Credentials | HttpClient.HttpClient>;
export type StopResourceError = InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a resource.
 *
 * The resource undergoes the following states: `CREATE_STOPPING` and
 * `CREATE_STOPPED`. You cannot resume a resource once it has been
 * stopped.
 *
 * This operation can be applied to the following resources (and their corresponding child
 * resources):
 *
 * - Dataset Import Job
 *
 * - Predictor Job
 *
 * - Forecast Job
 *
 * - Forecast Export Job
 *
 * - Predictor Backtest Export Job
 *
 * - Explainability Job
 *
 * - Explainability Export Job
 */
export declare const stopResource: API.OperationMethod<StopResourceRequest & RegionInput, StopResourceResponse, StopResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource are not specified in the request parameters, they are not
 * changed. When a resource is deleted, the tags associated with that resource are also
 * deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetGroupError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Replaces the datasets in a dataset group with the specified datasets.
 *
 * The `Status` of the dataset group must be `ACTIVE` before you can
 * use the dataset group to create a predictor. Use the DescribeDatasetGroup
 * operation to get the status.
 */
export declare const updateDatasetGroup: API.OperationMethod<UpdateDatasetGroupRequest & RegionInput, UpdateDatasetGroupResponse, UpdateDatasetGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=forecast.d.ts.map