/**
 * Protobuf binary wire codec over generated descriptors.
 *
 * Proto-sourced SDKs keep their schemas in proto3 JSON shape (camelCase wire
 * names, 64-bit integers as strings, bytes as base64, enums by name,
 * `google.protobuf.Timestamp` as RFC 3339). Servers that only speak binary
 * gRPC need the same values as protobuf bytes, so this module transcodes
 * between the two using a descriptor table the converter emits next to the
 * services (`src/descriptors.ts`): field numbers, scalar kinds, message and
 * enum references.
 *
 * Decoding follows proto3: a field without presence (a plain scalar, enum,
 * `repeated` or `map` field) reads as its default when the wire omits it
 * (`""`, `0`, `"0"` for 64-bit integers, `false`, the enum's zero value,
 * `[]`, `{}`), so the JSON always carries it. Fields with presence (marked
 * `optional`, message fields and `oneof` members) are omitted when absent.
 * Enum numbers map back to names, and unknown fields are skipped.
 */
/** A scalar or composite field kind. */
export type FieldKind = "double" | "float" | "int32" | "int64" | "uint32" | "uint64" | "sint32" | "sint64" | "fixed32" | "fixed64" | "sfixed32" | "sfixed64" | "bool" | "string" | "bytes" | "enum" | "message" | "map";
/** `[keyKind, valueKind, valueRef?]` for a `map<K, V>` field. */
export type MapRef = readonly [key: FieldKind, value: FieldKind, ref?: string];
/**
 * One field: `[number, jsonName, kind, ref?, repeated?, presence?]`. `ref`
 * names the message or enum for `message`/`enum` kinds and is a
 * {@link MapRef} for `map`; `repeated` is `1` for repeated fields. `presence`
 * is set for a field whose absence is observable: `1` for a proto3
 * `optional` field, and `n >= 2` for the members of the message's oneof `n`
 * (setting one member clears the others). Message fields always have
 * presence.
 */
export type FieldDescriptor = readonly [
    number: number,
    jsonName: string,
    kind: FieldKind,
    ref?: string | MapRef | 0,
    repeated?: 0 | 1,
    presence?: number
];
export interface ProtoDescriptors {
    /** Message full name -> fields. */
    readonly messages: Readonly<Record<string, ReadonlyArray<FieldDescriptor>>>;
    /** Enum full name -> value name -> number. */
    readonly enums: Readonly<Record<string, Readonly<Record<string, number>>>>;
    /**
     * gRPC method path (`/<package>.<Service>/<Method>`) ->
     * `[requestMessage, responseMessage, serverStream?]`. A server-streaming
     * method's JSON output is `{ items: [response, ...] }`.
     */
    readonly methods: Readonly<Record<string, readonly [request: string, response: string, serverStream?: 0 | 1]>>;
}
/** A value the descriptors can't encode (a wrong type for its field). */
export declare class ProtobufEncodeError extends Error {
    readonly _tag = "ProtobufEncodeError";
}
/** Bytes that aren't valid protobuf for the expected message. */
export declare class ProtobufDecodeError extends Error {
    readonly _tag: string;
}
/**
 * Valid protobuf whose value proto3 JSON can't represent: a Timestamp
 * outside years 0001 to 9999, or a Duration beyond 10,000 years.
 */
export declare class ProtobufJsonRangeError extends ProtobufDecodeError {
    readonly _tag = "ProtobufJsonRangeError";
}
/** Encode a proto3 JSON value of message `name` to protobuf bytes. */
export declare const encodeMessage: (d: ProtoDescriptors, name: string, value: unknown) => Uint8Array;
/**
 * Decode protobuf bytes of message `name` to a proto3 JSON value. As in any
 * proto3 parser, the last value of a singular field wins, a message field
 * seen more than once is merged, setting a oneof member clears the others,
 * a field whose wire type doesn't match its kind is skipped as unknown, and
 * unknown fields are dropped.
 */
export declare const decodeMessage: (d: ProtoDescriptors, name: string, bytes: Uint8Array) => unknown;
/** One gRPC message frame: `[flag=0][u32 length BE][payload]`. */
export declare const frame: (payload: Uint8Array) => Uint8Array;
/**
 * Reads gRPC message frames from a body that arrives in chunks: `push` each
 * chunk and get back the messages it completed. `rest` is the number of
 * bytes held for an incomplete frame (`0` once a body ends cleanly).
 * Compressed frames are rejected. A gRPC-Web trailer frame (flag `0x80`) is
 * not a message: its `name: value` lines are collected in `trailers`.
 */
export declare class FrameReader {
    private buf;
    /** The trailers of the gRPC-Web trailer frames read so far, names lowercase. */
    readonly trailers: Record<string, string>;
    get rest(): number;
    push(chunk: Uint8Array): Uint8Array[];
    private readTrailers;
}
/** Split a whole gRPC body into message payloads. */
export declare const unframe: (body: Uint8Array) => Uint8Array[];
//# sourceMappingURL=protobuf.d.ts.map