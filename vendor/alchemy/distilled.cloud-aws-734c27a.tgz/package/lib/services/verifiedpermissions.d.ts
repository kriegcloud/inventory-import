import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resources: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly resourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PolicyStoreId = string;
export type PolicyId = string;
export interface BatchGetPolicyInputItem {
    policyStoreId: string;
    policyId: string;
}
export type BatchGetPolicyInputList = BatchGetPolicyInputItem[];
export interface BatchGetPolicyInput {
    requests: BatchGetPolicyInputItem[];
}
export type PolicyType = "STATIC" | "TEMPLATE_LINKED" | (string & {});
export type StaticPolicyDescription = string | redacted.Redacted<string>;
export type PolicyStatement = string | redacted.Redacted<string>;
export interface StaticPolicyDefinitionDetail {
    description?: string | redacted.Redacted<string> | undefined;
    statement: string | redacted.Redacted<string>;
}
export type PolicyTemplateId = string;
export type EntityType = string | redacted.Redacted<string>;
export type EntityId = string | redacted.Redacted<string>;
export interface EntityIdentifier {
    entityType: string | redacted.Redacted<string>;
    entityId: string | redacted.Redacted<string>;
}
export interface TemplateLinkedPolicyDefinitionDetail {
    policyTemplateId: string;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
}
export type PolicyDefinitionDetail = {
    static: StaticPolicyDefinitionDetail;
    templateLinked?: undefined;
} | {
    static?: undefined;
    templateLinked: TemplateLinkedPolicyDefinitionDetail;
};
export type TimestampFormat = Date;
export type PolicyName = string;
export interface BatchGetPolicyOutputItem {
    policyStoreId: string;
    policyId: string;
    policyType: PolicyType;
    definition: PolicyDefinitionDetail;
    createdDate: Date;
    lastUpdatedDate: Date;
    name?: string | undefined;
}
export type BatchGetPolicyOutputList = BatchGetPolicyOutputItem[];
export type BatchGetPolicyErrorCode = "POLICY_STORE_NOT_FOUND" | "POLICY_NOT_FOUND" | "POLICY_STORE_ALIAS_NOT_FOUND" | (string & {});
export interface BatchGetPolicyErrorItem {
    code: BatchGetPolicyErrorCode;
    policyStoreId: string;
    policyId: string;
    message: string;
}
export type BatchGetPolicyErrorList = BatchGetPolicyErrorItem[];
export interface BatchGetPolicyOutput {
    results: BatchGetPolicyOutputItem[];
    errors: BatchGetPolicyErrorItem[];
}
export type BooleanAttribute = boolean;
export type LongAttribute = number;
export type StringAttribute = string | redacted.Redacted<string>;
export type SetAttribute = AttributeValue[];
export type RecordAttribute = {
    [key: string]: AttributeValue | undefined;
};
export type IpAddr = string | redacted.Redacted<string>;
export type Decimal = string | redacted.Redacted<string>;
export type DatetimeAttribute = string | redacted.Redacted<string>;
export type Duration = string | redacted.Redacted<string>;
export type AttributeValue = {
    boolean: boolean;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier: EntityIdentifier;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long: number;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string: string | redacted.Redacted<string>;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set: AttributeValue[];
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record: {
        [key: string]: AttributeValue | undefined;
    };
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr: string | redacted.Redacted<string>;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal: string | redacted.Redacted<string>;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime: string | redacted.Redacted<string>;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration: string | redacted.Redacted<string>;
};
export type EntityAttributes = {
    [key: string]: AttributeValue | undefined;
};
export type ParentList = EntityIdentifier[];
export type CedarTagSetAttribute = CedarTagValue[];
export type CedarTagRecordAttribute = {
    [key: string]: CedarTagValue | undefined;
};
export type CedarTagValue = {
    boolean: boolean;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier: EntityIdentifier;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long: number;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string: string | redacted.Redacted<string>;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set: CedarTagValue[];
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record: {
        [key: string]: CedarTagValue | undefined;
    };
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr: string | redacted.Redacted<string>;
    decimal?: undefined;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal: string | redacted.Redacted<string>;
    datetime?: undefined;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime: string | redacted.Redacted<string>;
    duration?: undefined;
} | {
    boolean?: undefined;
    entityIdentifier?: undefined;
    long?: undefined;
    string?: undefined;
    set?: undefined;
    record?: undefined;
    ipaddr?: undefined;
    decimal?: undefined;
    datetime?: undefined;
    duration: string | redacted.Redacted<string>;
};
export type EntityCedarTags = {
    [key: string]: CedarTagValue | undefined;
};
export interface EntityItem {
    identifier: EntityIdentifier;
    attributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    parents?: EntityIdentifier[] | undefined;
    tags?: {
        [key: string]: CedarTagValue | undefined;
    } | undefined;
}
export type EntityList = EntityItem[];
export type CedarJson = string | redacted.Redacted<string>;
export type EntitiesDefinition = {
    entityList: EntityItem[];
    cedarJson?: undefined;
} | {
    entityList?: undefined;
    cedarJson: string | redacted.Redacted<string>;
};
export type ActionType = string | redacted.Redacted<string>;
export type ActionId = string | redacted.Redacted<string>;
export interface ActionIdentifier {
    actionType: string | redacted.Redacted<string>;
    actionId: string | redacted.Redacted<string>;
}
export type ContextMap = {
    [key: string]: AttributeValue | undefined;
};
export type ContextDefinition = {
    contextMap: {
        [key: string]: AttributeValue | undefined;
    };
    cedarJson?: undefined;
} | {
    contextMap?: undefined;
    cedarJson: string | redacted.Redacted<string>;
};
export interface BatchIsAuthorizedInputItem {
    principal?: EntityIdentifier | undefined;
    action?: ActionIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    context?: ContextDefinition | undefined;
}
export type BatchIsAuthorizedInputList = BatchIsAuthorizedInputItem[];
export interface BatchIsAuthorizedInput {
    policyStoreId: string;
    entities?: EntitiesDefinition | undefined;
    requests: BatchIsAuthorizedInputItem[];
}
export type Decision = "ALLOW" | "DENY" | (string & {});
export interface DeterminingPolicyItem {
    policyId: string;
}
export type DeterminingPolicyList = DeterminingPolicyItem[];
export interface EvaluationErrorItem {
    errorDescription: string;
}
export type EvaluationErrorList = EvaluationErrorItem[];
export interface BatchIsAuthorizedOutputItem {
    request: BatchIsAuthorizedInputItem;
    decision: Decision;
    determiningPolicies: DeterminingPolicyItem[];
    errors: EvaluationErrorItem[];
}
export type BatchIsAuthorizedOutputList = BatchIsAuthorizedOutputItem[];
export interface BatchIsAuthorizedOutput {
    results: BatchIsAuthorizedOutputItem[];
}
export type Token = string | redacted.Redacted<string>;
export interface BatchIsAuthorizedWithTokenInputItem {
    action?: ActionIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    context?: ContextDefinition | undefined;
}
export type BatchIsAuthorizedWithTokenInputList = BatchIsAuthorizedWithTokenInputItem[];
export interface BatchIsAuthorizedWithTokenInput {
    policyStoreId: string;
    identityToken?: string | redacted.Redacted<string> | undefined;
    accessToken?: string | redacted.Redacted<string> | undefined;
    entities?: EntitiesDefinition | undefined;
    requests: BatchIsAuthorizedWithTokenInputItem[];
}
export interface BatchIsAuthorizedWithTokenOutputItem {
    request: BatchIsAuthorizedWithTokenInputItem;
    decision: Decision;
    determiningPolicies: DeterminingPolicyItem[];
    errors: EvaluationErrorItem[];
}
export type BatchIsAuthorizedWithTokenOutputList = BatchIsAuthorizedWithTokenOutputItem[];
export interface BatchIsAuthorizedWithTokenOutput {
    principal?: EntityIdentifier | undefined;
    results: BatchIsAuthorizedWithTokenOutputItem[];
}
export type IdempotencyToken = string;
export type UserPoolArn = string;
export type ClientId = string | redacted.Redacted<string>;
export type ClientIds = (string | redacted.Redacted<string>)[];
export type GroupEntityType = string | redacted.Redacted<string>;
export interface CognitoGroupConfiguration {
    groupEntityType: string | redacted.Redacted<string>;
}
export interface CognitoUserPoolConfiguration {
    userPoolArn: string;
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
    groupConfiguration?: CognitoGroupConfiguration | undefined;
}
export type Issuer = string;
export type EntityIdPrefix = string | redacted.Redacted<string>;
export type Claim = string | redacted.Redacted<string>;
export interface OpenIdConnectGroupConfiguration {
    groupClaim: string | redacted.Redacted<string>;
    groupEntityType: string | redacted.Redacted<string>;
}
export type Audience = string;
export type Audiences = string[];
export interface OpenIdConnectAccessTokenConfiguration {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    audiences?: string[] | undefined;
}
export interface OpenIdConnectIdentityTokenConfiguration {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
}
export type OpenIdConnectTokenSelection = {
    accessTokenOnly: OpenIdConnectAccessTokenConfiguration;
    identityTokenOnly?: undefined;
} | {
    accessTokenOnly?: undefined;
    identityTokenOnly: OpenIdConnectIdentityTokenConfiguration;
};
export interface OpenIdConnectConfiguration {
    issuer: string;
    entityIdPrefix?: string | redacted.Redacted<string> | undefined;
    groupConfiguration?: OpenIdConnectGroupConfiguration | undefined;
    tokenSelection: OpenIdConnectTokenSelection;
}
export type Configuration = {
    cognitoUserPoolConfiguration: CognitoUserPoolConfiguration;
    openIdConnectConfiguration?: undefined;
} | {
    cognitoUserPoolConfiguration?: undefined;
    openIdConnectConfiguration: OpenIdConnectConfiguration;
};
export type PrincipalEntityType = string | redacted.Redacted<string>;
export interface CreateIdentitySourceInput {
    clientToken?: string | undefined;
    policyStoreId: string;
    configuration: Configuration;
    principalEntityType?: string | redacted.Redacted<string> | undefined;
}
export type IdentitySourceId = string;
export interface CreateIdentitySourceOutput {
    createdDate: Date;
    identitySourceId: string;
    lastUpdatedDate: Date;
    policyStoreId: string;
}
export interface StaticPolicyDefinition {
    description?: string | redacted.Redacted<string> | undefined;
    statement: string | redacted.Redacted<string>;
}
export interface TemplateLinkedPolicyDefinition {
    policyTemplateId: string;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
}
export type PolicyDefinition = {
    static: StaticPolicyDefinition;
    templateLinked?: undefined;
} | {
    static?: undefined;
    templateLinked: TemplateLinkedPolicyDefinition;
};
export interface CreatePolicyInput {
    clientToken?: string | undefined;
    policyStoreId: string;
    definition: PolicyDefinition;
    name?: string | undefined;
}
export type ActionIdentifierList = ActionIdentifier[];
export type PolicyEffect = "Permit" | "Forbid" | (string & {});
export interface CreatePolicyOutput {
    policyStoreId: string;
    policyId: string;
    policyType: PolicyType;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    actions?: ActionIdentifier[] | undefined;
    createdDate: Date;
    lastUpdatedDate: Date;
    effect?: PolicyEffect | undefined;
}
export type ValidationMode = "OFF" | "STRICT" | (string & {});
export interface ValidationSettings {
    mode: ValidationMode;
}
export type PolicyStoreDescription = string | redacted.Redacted<string>;
export type DeletionProtection = "ENABLED" | "DISABLED" | (string & {});
export type KmsKey = string;
export type EncryptionContextKey = string;
export type EncryptionContextValue = string;
export type EncryptionContext = {
    [key: string]: string | undefined;
};
export interface KmsEncryptionSettings {
    key: string;
    encryptionContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EncryptionSettings = {
    kmsEncryptionSettings: KmsEncryptionSettings;
    default?: undefined;
} | {
    kmsEncryptionSettings?: undefined;
    default: Record<string, never>;
};
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreatePolicyStoreInput {
    clientToken?: string | undefined;
    validationSettings: ValidationSettings;
    description?: string | redacted.Redacted<string> | undefined;
    deletionProtection?: DeletionProtection | undefined;
    encryptionSettings?: EncryptionSettings | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ResourceArn = string;
export interface CreatePolicyStoreOutput {
    policyStoreId: string;
    arn: string;
    createdDate: Date;
    lastUpdatedDate: Date;
}
export type Alias = string;
export interface CreatePolicyStoreAliasInput {
    aliasName: string;
    policyStoreId: string;
}
export interface CreatePolicyStoreAliasOutput {
    aliasName: string;
    policyStoreId: string;
    aliasArn: string;
    createdAt: Date;
}
export type PolicyTemplateDescription = string | redacted.Redacted<string>;
export type PolicyTemplateName = string;
export interface CreatePolicyTemplateInput {
    clientToken?: string | undefined;
    policyStoreId: string;
    description?: string | redacted.Redacted<string> | undefined;
    statement: string | redacted.Redacted<string>;
    name?: string | undefined;
}
export interface CreatePolicyTemplateOutput {
    policyStoreId: string;
    policyTemplateId: string;
    createdDate: Date;
    lastUpdatedDate: Date;
}
export interface DeleteIdentitySourceInput {
    policyStoreId: string;
    identitySourceId: string;
}
export interface DeleteIdentitySourceOutput {
}
export interface DeletePolicyInput {
    policyStoreId: string;
    policyId: string;
}
export interface DeletePolicyOutput {
}
export interface DeletePolicyStoreInput {
    policyStoreId: string;
}
export interface DeletePolicyStoreOutput {
}
export type DeletionMode = "SoftDelete" | "HardDelete" | (string & {});
export interface DeletePolicyStoreAliasInput {
    aliasName: string;
    deletionMode?: DeletionMode | undefined;
}
export interface DeletePolicyStoreAliasOutput {
}
export interface DeletePolicyTemplateInput {
    policyStoreId: string;
    policyTemplateId: string;
}
export interface DeletePolicyTemplateOutput {
}
export interface GetIdentitySourceInput {
    policyStoreId: string;
    identitySourceId: string;
}
export type DiscoveryUrl = string;
export type OpenIdIssuer = "COGNITO" | (string & {});
export interface IdentitySourceDetails {
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
    userPoolArn?: string | undefined;
    discoveryUrl?: string | undefined;
    openIdIssuer?: OpenIdIssuer | undefined;
}
export interface CognitoGroupConfigurationDetail {
    groupEntityType?: string | redacted.Redacted<string> | undefined;
}
export interface CognitoUserPoolConfigurationDetail {
    userPoolArn: string;
    clientIds: (string | redacted.Redacted<string>)[];
    issuer: string;
    groupConfiguration?: CognitoGroupConfigurationDetail | undefined;
}
export interface OpenIdConnectGroupConfigurationDetail {
    groupClaim: string | redacted.Redacted<string>;
    groupEntityType: string | redacted.Redacted<string>;
}
export interface OpenIdConnectAccessTokenConfigurationDetail {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    audiences?: string[] | undefined;
}
export interface OpenIdConnectIdentityTokenConfigurationDetail {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
}
export type OpenIdConnectTokenSelectionDetail = {
    accessTokenOnly: OpenIdConnectAccessTokenConfigurationDetail;
    identityTokenOnly?: undefined;
} | {
    accessTokenOnly?: undefined;
    identityTokenOnly: OpenIdConnectIdentityTokenConfigurationDetail;
};
export interface OpenIdConnectConfigurationDetail {
    issuer: string;
    entityIdPrefix?: string | redacted.Redacted<string> | undefined;
    groupConfiguration?: OpenIdConnectGroupConfigurationDetail | undefined;
    tokenSelection: OpenIdConnectTokenSelectionDetail;
}
export type ConfigurationDetail = {
    cognitoUserPoolConfiguration: CognitoUserPoolConfigurationDetail;
    openIdConnectConfiguration?: undefined;
} | {
    cognitoUserPoolConfiguration?: undefined;
    openIdConnectConfiguration: OpenIdConnectConfigurationDetail;
};
export interface GetIdentitySourceOutput {
    createdDate: Date;
    details?: IdentitySourceDetails | undefined;
    identitySourceId: string;
    lastUpdatedDate: Date;
    policyStoreId: string;
    principalEntityType: string | redacted.Redacted<string>;
    configuration?: ConfigurationDetail | undefined;
}
export interface GetPolicyInput {
    policyStoreId: string;
    policyId: string;
}
export interface GetPolicyOutput {
    policyStoreId: string;
    policyId: string;
    policyType: PolicyType;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    actions?: ActionIdentifier[] | undefined;
    definition: PolicyDefinitionDetail;
    createdDate: Date;
    lastUpdatedDate: Date;
    effect?: PolicyEffect | undefined;
    name?: string | undefined;
}
export interface GetPolicyStoreInput {
    policyStoreId: string;
    tags?: boolean | undefined;
}
export interface KmsEncryptionState {
    key: string;
    encryptionContext: {
        [key: string]: string | undefined;
    };
}
export type EncryptionState = {
    kmsEncryptionState: KmsEncryptionState;
    default?: undefined;
} | {
    kmsEncryptionState?: undefined;
    default: Record<string, never>;
};
export type CedarVersion = "CEDAR_2" | "CEDAR_4" | (string & {});
export interface GetPolicyStoreOutput {
    policyStoreId: string;
    arn: string;
    validationSettings: ValidationSettings;
    createdDate: Date;
    lastUpdatedDate: Date;
    description?: string | redacted.Redacted<string> | undefined;
    deletionProtection?: DeletionProtection | undefined;
    encryptionState?: EncryptionState | undefined;
    cedarVersion?: CedarVersion | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetPolicyStoreAliasInput {
    aliasName: string;
}
export type AliasState = "Active" | "PendingDeletion" | (string & {});
export interface GetPolicyStoreAliasOutput {
    aliasName: string;
    policyStoreId: string;
    aliasArn: string;
    createdAt: Date;
    state: AliasState;
}
export interface GetPolicyTemplateInput {
    policyStoreId: string;
    policyTemplateId: string;
}
export interface GetPolicyTemplateOutput {
    policyStoreId: string;
    policyTemplateId: string;
    description?: string | redacted.Redacted<string> | undefined;
    statement: string | redacted.Redacted<string>;
    createdDate: Date;
    lastUpdatedDate: Date;
    name?: string | undefined;
}
export interface GetSchemaInput {
    policyStoreId: string;
}
export type SchemaJson = string | redacted.Redacted<string>;
export type Namespace = string | redacted.Redacted<string>;
export type NamespaceList = (string | redacted.Redacted<string>)[];
export interface GetSchemaOutput {
    policyStoreId: string;
    schema: string | redacted.Redacted<string>;
    createdDate: Date;
    lastUpdatedDate: Date;
    namespaces?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface IsAuthorizedInput {
    policyStoreId: string;
    principal?: EntityIdentifier | undefined;
    action?: ActionIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    context?: ContextDefinition | undefined;
    entities?: EntitiesDefinition | undefined;
}
export interface IsAuthorizedOutput {
    decision: Decision;
    determiningPolicies: DeterminingPolicyItem[];
    errors: EvaluationErrorItem[];
}
export interface IsAuthorizedWithTokenInput {
    policyStoreId: string;
    identityToken?: string | redacted.Redacted<string> | undefined;
    accessToken?: string | redacted.Redacted<string> | undefined;
    action?: ActionIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    context?: ContextDefinition | undefined;
    entities?: EntitiesDefinition | undefined;
}
export interface IsAuthorizedWithTokenOutput {
    decision: Decision;
    determiningPolicies: DeterminingPolicyItem[];
    errors: EvaluationErrorItem[];
    principal?: EntityIdentifier | undefined;
}
export type NextToken = string;
export type ListIdentitySourcesMaxResults = number;
export interface IdentitySourceFilter {
    principalEntityType?: string | redacted.Redacted<string> | undefined;
}
export type IdentitySourceFilters = IdentitySourceFilter[];
export interface ListIdentitySourcesInput {
    policyStoreId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: IdentitySourceFilter[] | undefined;
}
export interface IdentitySourceItemDetails {
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
    userPoolArn?: string | undefined;
    discoveryUrl?: string | undefined;
    openIdIssuer?: OpenIdIssuer | undefined;
}
export interface CognitoGroupConfigurationItem {
    groupEntityType?: string | redacted.Redacted<string> | undefined;
}
export interface CognitoUserPoolConfigurationItem {
    userPoolArn: string;
    clientIds: (string | redacted.Redacted<string>)[];
    issuer: string;
    groupConfiguration?: CognitoGroupConfigurationItem | undefined;
}
export interface OpenIdConnectGroupConfigurationItem {
    groupClaim: string | redacted.Redacted<string>;
    groupEntityType: string | redacted.Redacted<string>;
}
export interface OpenIdConnectAccessTokenConfigurationItem {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    audiences?: string[] | undefined;
}
export interface OpenIdConnectIdentityTokenConfigurationItem {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
}
export type OpenIdConnectTokenSelectionItem = {
    accessTokenOnly: OpenIdConnectAccessTokenConfigurationItem;
    identityTokenOnly?: undefined;
} | {
    accessTokenOnly?: undefined;
    identityTokenOnly: OpenIdConnectIdentityTokenConfigurationItem;
};
export interface OpenIdConnectConfigurationItem {
    issuer: string;
    entityIdPrefix?: string | redacted.Redacted<string> | undefined;
    groupConfiguration?: OpenIdConnectGroupConfigurationItem | undefined;
    tokenSelection: OpenIdConnectTokenSelectionItem;
}
export type ConfigurationItem = {
    cognitoUserPoolConfiguration: CognitoUserPoolConfigurationItem;
    openIdConnectConfiguration?: undefined;
} | {
    cognitoUserPoolConfiguration?: undefined;
    openIdConnectConfiguration: OpenIdConnectConfigurationItem;
};
export interface IdentitySourceItem {
    createdDate: Date;
    details?: IdentitySourceItemDetails | undefined;
    identitySourceId: string;
    lastUpdatedDate: Date;
    policyStoreId: string;
    principalEntityType: string | redacted.Redacted<string>;
    configuration?: ConfigurationItem | undefined;
}
export type IdentitySources = IdentitySourceItem[];
export interface ListIdentitySourcesOutput {
    nextToken?: string | undefined;
    identitySources: IdentitySourceItem[];
}
export type MaxResults = number;
export type EntityReference = {
    unspecified: boolean;
    identifier?: undefined;
} | {
    unspecified?: undefined;
    identifier: EntityIdentifier;
};
export interface PolicyFilter {
    principal?: EntityReference | undefined;
    resource?: EntityReference | undefined;
    policyType?: PolicyType | undefined;
    policyTemplateId?: string | undefined;
}
export interface ListPoliciesInput {
    policyStoreId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: PolicyFilter | undefined;
}
export interface StaticPolicyDefinitionItem {
    description?: string | redacted.Redacted<string> | undefined;
}
export interface TemplateLinkedPolicyDefinitionItem {
    policyTemplateId: string;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
}
export type PolicyDefinitionItem = {
    static: StaticPolicyDefinitionItem;
    templateLinked?: undefined;
} | {
    static?: undefined;
    templateLinked: TemplateLinkedPolicyDefinitionItem;
};
export interface PolicyItem {
    policyStoreId: string;
    policyId: string;
    policyType: PolicyType;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    actions?: ActionIdentifier[] | undefined;
    definition: PolicyDefinitionItem;
    createdDate: Date;
    lastUpdatedDate: Date;
    effect?: PolicyEffect | undefined;
    name?: string | undefined;
}
export type PolicyList = PolicyItem[];
export interface ListPoliciesOutput {
    nextToken?: string | undefined;
    policies: PolicyItem[];
}
export interface PolicyStoreAliasFilter {
    policyStoreId?: string | undefined;
}
export interface ListPolicyStoreAliasesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filter?: PolicyStoreAliasFilter | undefined;
}
export interface PolicyStoreAliasItem {
    aliasName: string;
    policyStoreId: string;
    aliasArn: string;
    createdAt: Date;
    state: AliasState;
}
export type PolicyStoreAliasList = PolicyStoreAliasItem[];
export interface ListPolicyStoreAliasesOutput {
    nextToken?: string | undefined;
    policyStoreAliases: PolicyStoreAliasItem[];
}
export interface ListPolicyStoresInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PolicyStoreItem {
    policyStoreId: string;
    arn: string;
    createdDate: Date;
    lastUpdatedDate?: Date | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export type PolicyStoreList = PolicyStoreItem[];
export interface ListPolicyStoresOutput {
    nextToken?: string | undefined;
    policyStores: PolicyStoreItem[];
}
export interface ListPolicyTemplatesInput {
    policyStoreId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface PolicyTemplateItem {
    policyStoreId: string;
    policyTemplateId: string;
    description?: string | redacted.Redacted<string> | undefined;
    createdDate: Date;
    lastUpdatedDate: Date;
    name?: string | undefined;
}
export type PolicyTemplatesList = PolicyTemplateItem[];
export interface ListPolicyTemplatesOutput {
    nextToken?: string | undefined;
    policyTemplates: PolicyTemplateItem[];
}
export type AmazonResourceName = string;
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SchemaDefinition = {
    cedarJson: string | redacted.Redacted<string>;
};
export interface PutSchemaInput {
    policyStoreId: string;
    definition: SchemaDefinition;
}
export interface PutSchemaOutput {
    policyStoreId: string;
    namespaces: (string | redacted.Redacted<string>)[];
    createdDate: Date;
    lastUpdatedDate: Date;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateCognitoGroupConfiguration {
    groupEntityType: string | redacted.Redacted<string>;
}
export interface UpdateCognitoUserPoolConfiguration {
    userPoolArn: string;
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
    groupConfiguration?: UpdateCognitoGroupConfiguration | undefined;
}
export interface UpdateOpenIdConnectGroupConfiguration {
    groupClaim: string | redacted.Redacted<string>;
    groupEntityType: string | redacted.Redacted<string>;
}
export interface UpdateOpenIdConnectAccessTokenConfiguration {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    audiences?: string[] | undefined;
}
export interface UpdateOpenIdConnectIdentityTokenConfiguration {
    principalIdClaim?: string | redacted.Redacted<string> | undefined;
    clientIds?: (string | redacted.Redacted<string>)[] | undefined;
}
export type UpdateOpenIdConnectTokenSelection = {
    accessTokenOnly: UpdateOpenIdConnectAccessTokenConfiguration;
    identityTokenOnly?: undefined;
} | {
    accessTokenOnly?: undefined;
    identityTokenOnly: UpdateOpenIdConnectIdentityTokenConfiguration;
};
export interface UpdateOpenIdConnectConfiguration {
    issuer: string;
    entityIdPrefix?: string | redacted.Redacted<string> | undefined;
    groupConfiguration?: UpdateOpenIdConnectGroupConfiguration | undefined;
    tokenSelection: UpdateOpenIdConnectTokenSelection;
}
export type UpdateConfiguration = {
    cognitoUserPoolConfiguration: UpdateCognitoUserPoolConfiguration;
    openIdConnectConfiguration?: undefined;
} | {
    cognitoUserPoolConfiguration?: undefined;
    openIdConnectConfiguration: UpdateOpenIdConnectConfiguration;
};
export interface UpdateIdentitySourceInput {
    policyStoreId: string;
    identitySourceId: string;
    updateConfiguration: UpdateConfiguration;
    principalEntityType?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateIdentitySourceOutput {
    createdDate: Date;
    identitySourceId: string;
    lastUpdatedDate: Date;
    policyStoreId: string;
}
export interface UpdateStaticPolicyDefinition {
    description?: string | redacted.Redacted<string> | undefined;
    statement: string | redacted.Redacted<string>;
}
export type UpdatePolicyDefinition = {
    static: UpdateStaticPolicyDefinition;
};
export interface UpdatePolicyInput {
    policyStoreId: string;
    policyId: string;
    definition?: UpdatePolicyDefinition | undefined;
    name?: string | undefined;
}
export interface UpdatePolicyOutput {
    policyStoreId: string;
    policyId: string;
    policyType: PolicyType;
    principal?: EntityIdentifier | undefined;
    resource?: EntityIdentifier | undefined;
    actions?: ActionIdentifier[] | undefined;
    createdDate: Date;
    lastUpdatedDate: Date;
    effect?: PolicyEffect | undefined;
}
export interface UpdatePolicyStoreInput {
    policyStoreId: string;
    validationSettings: ValidationSettings;
    deletionProtection?: DeletionProtection | undefined;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdatePolicyStoreOutput {
    policyStoreId: string;
    arn: string;
    createdDate: Date;
    lastUpdatedDate: Date;
}
export interface UpdatePolicyTemplateInput {
    policyStoreId: string;
    policyTemplateId: string;
    description?: string | redacted.Redacted<string> | undefined;
    statement: string | redacted.Redacted<string>;
    name?: string | undefined;
}
export interface UpdatePolicyTemplateOutput {
    policyStoreId: string;
    policyTemplateId: string;
    createdDate: Date;
    lastUpdatedDate: Date;
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type ResourceType = "IDENTITY_SOURCE" | "POLICY_STORE" | "POLICY" | "POLICY_TEMPLATE" | "SCHEMA" | "POLICY_STORE_ALIAS" | (string & {});
export interface ResourceConflict {
    resourceId: string;
    resourceType: ResourceType;
}
export type ResourceConflictList = ResourceConflict[];
export type BatchGetPolicyError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a group (batch) of policies.
 *
 * The `BatchGetPolicy` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `verifiedpermissions:GetPolicy` in their IAM policies.
 */
export declare const batchGetPolicy: API.OperationMethod<BatchGetPolicyInput & RegionInput, BatchGetPolicyOutput, BatchGetPolicyError, Credentials | HttpClient.HttpClient>;
export type BatchIsAuthorizedError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Makes a series of decisions about multiple authorization requests for one principal or resource. Each request contains the equivalent content of an `IsAuthorized` request: principal, action, resource, and context. Either the `principal` or the `resource` parameter must be identical across all requests. For example, Verified Permissions won't evaluate a pair of requests where `bob` views `photo1` and `alice` views `photo2`. Authorization of `bob` to view `photo1` and `photo2`, or `bob` and `alice` to view `photo1`, are valid batches.
 *
 * The request is evaluated against all policies in the specified policy store that match the entities that you declare. The result of the decisions is a series of `Allow` or `Deny` responses, along with the IDs of the policies that produced each decision.
 *
 * The `entities` of a `BatchIsAuthorized` API request can contain up to 100 principals and up to 100 resources. The `requests` of a `BatchIsAuthorized` API request can contain up to 30 requests.
 *
 * The `BatchIsAuthorized` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `verifiedpermissions:IsAuthorized` in their IAM policies.
 */
export declare const batchIsAuthorized: API.OperationMethod<BatchIsAuthorizedInput & RegionInput, BatchIsAuthorizedOutput, BatchIsAuthorizedError, Credentials | HttpClient.HttpClient>;
export type BatchIsAuthorizedWithTokenError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Makes a series of decisions about multiple authorization requests for one token. The principal in this request comes from an external identity source in the form of an identity or access token, formatted as a JSON web token (JWT). The information in the parameters can also define additional context that Verified Permissions can include in the evaluations.
 *
 * The request is evaluated against all policies in the specified policy store that match the entities that you provide in the entities declaration and in the token. The result of the decisions is a series of `Allow` or `Deny` responses, along with the IDs of the policies that produced each decision.
 *
 * The `entities` of a `BatchIsAuthorizedWithToken` API request can contain up to 100 resources and up to 99 user groups. The `requests` of a `BatchIsAuthorizedWithToken` API request can contain up to 30 requests.
 *
 * The `BatchIsAuthorizedWithToken` operation doesn't have its own IAM permission. To authorize this operation for Amazon Web Services principals, include the permission `verifiedpermissions:IsAuthorizedWithToken` in their IAM policies.
 */
export declare const batchIsAuthorizedWithToken: API.OperationMethod<BatchIsAuthorizedWithTokenInput & RegionInput, BatchIsAuthorizedWithTokenOutput, BatchIsAuthorizedWithTokenError, Credentials | HttpClient.HttpClient>;
export type CreateIdentitySourceError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds an identity source to a policy store-an Amazon Cognito user pool or OpenID Connect (OIDC) identity provider (IdP).
 *
 * After you create an identity source, you can use the identities provided by the IdP as proxies for the principal in authorization queries that use the IsAuthorizedWithToken or BatchIsAuthorizedWithToken API operations. These identities take the form of tokens that contain claims about the user, such as IDs, attributes and group memberships. Identity sources provide identity (ID) tokens and access tokens. Verified Permissions derives information about your user and session from token claims. Access tokens provide action `context` to your policies, and ID tokens provide principal `Attributes`.
 *
 * Tokens from an identity source user continue to be usable until they expire. Token revocation and resource deletion have no effect on the validity of a token in your policy store
 *
 * To reference a user from this identity source in your Cedar policies, refer to the following syntax examples.
 *
 * - Amazon Cognito user pool: `Namespace::[Entity type]::[User pool ID]|[user principal attribute]`, for example `MyCorp::User::us-east-1_EXAMPLE|a1b2c3d4-5678-90ab-cdef-EXAMPLE11111`.
 *
 * - OpenID Connect (OIDC) provider: `Namespace::[Entity type]::[entityIdPrefix]|[user principal attribute]`, for example `MyCorp::User::MyOIDCProvider|a1b2c3d4-5678-90ab-cdef-EXAMPLE22222`.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const createIdentitySource: API.OperationMethod<CreateIdentitySourceInput & RegionInput, CreateIdentitySourceOutput, CreateIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Cedar policy and saves it in the specified policy store. You can create either a static policy or a policy linked to a policy template.
 *
 * - To create a static policy, provide the Cedar policy text in the `StaticPolicy` section of the `PolicyDefinition`.
 *
 * - To create a policy that is dynamically linked to a policy template, specify the policy template ID and the principal and resource to associate with this policy in the `templateLinked` section of the `PolicyDefinition`. If the policy template is ever updated, any policies linked to the policy template automatically use the updated template.
 *
 * Creating a policy causes it to be validated against the schema in the policy store. If the policy doesn't pass validation, the operation fails and the policy isn't stored.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const createPolicy: API.OperationMethod<CreatePolicyInput & RegionInput, CreatePolicyOutput, CreatePolicyError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyStoreError = ConflictException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a policy store. A policy store is a container for policy resources.
 *
 * As of May 2026, Verified Permissions has aligned with Cedar and now supports multiple namespaces.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const createPolicyStore: API.OperationMethod<CreatePolicyStoreInput & RegionInput, CreatePolicyStoreOutput, CreatePolicyStoreError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyStoreAliasError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a policy store alias for the specified policy store. A policy store alias is an alternative identifier that you can use to reference a policy store in API operations.
 *
 * This operation is idempotent. If multiple CreatePolicyStoreAlias requests are made where the `aliasName` and `policyStoreId` fields are the same between the requests, subsequent requests will be ignored. For each duplicate CreatePolicyStoreAlias request, a Success response will be returned and a new policy store alias will not be created.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const createPolicyStoreAlias: API.OperationMethod<CreatePolicyStoreAliasInput & RegionInput, CreatePolicyStoreAliasOutput, CreatePolicyStoreAliasError, Credentials | HttpClient.HttpClient>;
export type CreatePolicyTemplateError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a policy template. A template can use placeholders for the principal and resource. A template must be instantiated into a policy by associating it with specific principals and resources to use for the placeholders. That instantiated policy can then be considered in authorization decisions. The instantiated policy works identically to any other policy, except that it is dynamically linked to the template. If the template changes, then any policies that are linked to that template are immediately updated as well.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const createPolicyTemplate: API.OperationMethod<CreatePolicyTemplateInput & RegionInput, CreatePolicyTemplateOutput, CreatePolicyTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentitySourceError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an identity source that references an identity provider (IdP) such as Amazon Cognito. After you delete the identity source, you can no longer use tokens for identities from that identity source to represent principals in authorization queries made using IsAuthorizedWithToken. operations.
 */
export declare const deleteIdentitySource: API.OperationMethod<DeleteIdentitySourceInput & RegionInput, DeleteIdentitySourceOutput, DeleteIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified policy from the policy store.
 *
 * This operation is idempotent; if you specify a policy that doesn't exist, the request response returns a successful `HTTP 200` status code.
 */
export declare const deletePolicy: API.OperationMethod<DeletePolicyInput & RegionInput, DeletePolicyOutput, DeletePolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyStoreError = InvalidStateException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified policy store.
 *
 * This operation is idempotent. If you specify a policy store that does not exist, the request response will still return a successful HTTP 200 status code.
 */
export declare const deletePolicyStore: API.OperationMethod<DeletePolicyStoreInput & RegionInput, DeletePolicyStoreOutput, DeletePolicyStoreError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyStoreAliasError = InvalidStateException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified policy store alias.
 *
 * This operation is idempotent. If you specify a policy store alias that does not exist, the request response will still return a successful HTTP 200 status code.
 *
 * By default, when a policy store alias is deleted, it enters the `PendingDeletion` state. When a policy store alias is in the `PendingDeletion` state, new policy store aliases cannot be created with the same name. If the policy store alias is used in an API that has a `policyStoreId` field, the operation will fail with a `ResourceNotFound` exception.
 *
 * To immediately delete a policy store alias and bypass the `PendingDeletion` state, set the `deletionMode` parameter to `HardDelete`.
 *
 * Verified Permissions is eventually consistent. If you hard delete a policy store alias and then immediately recreate it to be associated with a different policy store, requests that reference this alias may continue to be evaluated against the previously associated policy store for a short period of time.
 */
export declare const deletePolicyStoreAlias: API.OperationMethod<DeletePolicyStoreAliasInput & RegionInput, DeletePolicyStoreAliasOutput, DeletePolicyStoreAliasError, Credentials | HttpClient.HttpClient>;
export type DeletePolicyTemplateError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified policy template from the policy store.
 *
 * This operation also deletes any policies that were created from the specified policy template. Those policies are immediately removed from all future API responses, and are asynchronously deleted from the policy store.
 */
export declare const deletePolicyTemplate: API.OperationMethod<DeletePolicyTemplateInput & RegionInput, DeletePolicyTemplateOutput, DeletePolicyTemplateError, Credentials | HttpClient.HttpClient>;
export type GetIdentitySourceError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details about the specified identity source.
 */
export declare const getIdentitySource: API.OperationMethod<GetIdentitySourceInput & RegionInput, GetIdentitySourceOutput, GetIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified policy.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyInput & RegionInput, GetPolicyOutput, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPolicyStoreError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about a policy store.
 */
export declare const getPolicyStore: API.OperationMethod<GetPolicyStoreInput & RegionInput, GetPolicyStoreOutput, GetPolicyStoreError, Credentials | HttpClient.HttpClient>;
export type GetPolicyStoreAliasError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details about the specified policy store alias.
 */
export declare const getPolicyStoreAlias: API.OperationMethod<GetPolicyStoreAliasInput & RegionInput, GetPolicyStoreAliasOutput, GetPolicyStoreAliasError, Credentials | HttpClient.HttpClient>;
export type GetPolicyTemplateError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve the details for the specified policy template in the specified policy store.
 */
export declare const getPolicyTemplate: API.OperationMethod<GetPolicyTemplateInput & RegionInput, GetPolicyTemplateOutput, GetPolicyTemplateError, Credentials | HttpClient.HttpClient>;
export type GetSchemaError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve the details for the specified schema in the specified policy store.
 */
export declare const getSchema: API.OperationMethod<GetSchemaInput & RegionInput, GetSchemaOutput, GetSchemaError, Credentials | HttpClient.HttpClient>;
export type IsAuthorizedError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Makes an authorization decision about a service request described in the parameters. The information in the parameters can also define additional context that Verified Permissions can include in the evaluation. The request is evaluated against all matching policies in the specified policy store. The result of the decision is either `Allow` or `Deny`, along with a list of the policies that resulted in the decision.
 */
export declare const isAuthorized: API.OperationMethod<IsAuthorizedInput & RegionInput, IsAuthorizedOutput, IsAuthorizedError, Credentials | HttpClient.HttpClient>;
export type IsAuthorizedWithTokenError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Makes an authorization decision about a service request described in the parameters. The principal in this request comes from an external identity source in the form of an identity token formatted as a JSON web token (JWT). The information in the parameters can also define additional context that Verified Permissions can include in the evaluation. The request is evaluated against all matching policies in the specified policy store. The result of the decision is either `Allow` or `Deny`, along with a list of the policies that resulted in the decision.
 *
 * Verified Permissions validates each token that is specified in a request by checking its expiration date and its signature.
 *
 * Tokens from an identity source user continue to be usable until they expire. Token revocation and resource deletion have no effect on the validity of a token in your policy store
 */
export declare const isAuthorizedWithToken: API.OperationMethod<IsAuthorizedWithTokenInput & RegionInput, IsAuthorizedWithTokenOutput, IsAuthorizedWithTokenError, Credentials | HttpClient.HttpClient>;
export type ListIdentitySourcesError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all of the identity sources defined in the specified policy store.
 */
export declare const listIdentitySources: API.PaginatedOperationMethod<ListIdentitySourcesInput & RegionInput, ListIdentitySourcesOutput, ListIdentitySourcesError, Credentials | HttpClient.HttpClient, IdentitySourceItem>;
export type ListPoliciesError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all policies stored in the specified policy store.
 */
export declare const listPolicies: API.PaginatedOperationMethod<ListPoliciesInput & RegionInput, ListPoliciesOutput, ListPoliciesError, Credentials | HttpClient.HttpClient, PolicyItem>;
export type ListPolicyStoreAliasesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all policy store aliases in the calling Amazon Web Services account.
 */
export declare const listPolicyStoreAliases: API.PaginatedOperationMethod<ListPolicyStoreAliasesInput & RegionInput, ListPolicyStoreAliasesOutput, ListPolicyStoreAliasesError, Credentials | HttpClient.HttpClient, PolicyStoreAliasItem>;
export type ListPolicyStoresError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all policy stores in the calling Amazon Web Services account.
 */
export declare const listPolicyStores: API.PaginatedOperationMethod<ListPolicyStoresInput & RegionInput, ListPolicyStoresOutput, ListPolicyStoresError, Credentials | HttpClient.HttpClient, PolicyStoreItem>;
export type ListPolicyTemplatesError = ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all policy templates in the specified policy store.
 */
export declare const listPolicyTemplates: API.PaginatedOperationMethod<ListPolicyTemplatesInput & RegionInput, ListPolicyTemplatesOutput, ListPolicyTemplatesError, Credentials | HttpClient.HttpClient, PolicyTemplateItem>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the tags associated with the specified Amazon Verified Permissions resource. In Verified Permissions, policy stores can be tagged.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutSchemaError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates the policy schema in the specified policy store. The schema is used to validate any Cedar policies and policy templates submitted to the policy store. Any changes to the schema validate only policies and templates submitted after the schema change. Existing policies and templates are not re-evaluated against the changed schema. If you later update a policy, then it is evaluated against the new schema at that time.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const putSchema: API.OperationMethod<PutSchemaInput & RegionInput, PutSchemaOutput, PutSchemaError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified Amazon Verified Permissions resource. Tags can help you organize and categorize your resources. You can also use them to scope user permissions by granting a user permission to access or change only resources with certain tag values. In Verified Permissions, policy stores can be tagged.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of characters.
 *
 * You can use the TagResource action with a resource that already has tags. If you specify a new tag key, this tag is appended to the list of tags associated with the resource. If you specify a tag key that is already associated with the resource, the new tag value that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified Amazon Verified Permissions resource. In Verified Permissions, policy stores can be tagged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentitySourceError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified identity source to use a new identity provider (IdP), or to change the mapping of identities from the IdP to a different principal entity type.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const updateIdentitySource: API.OperationMethod<UpdateIdentitySourceInput & RegionInput, UpdateIdentitySourceOutput, UpdateIdentitySourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies a Cedar static policy in the specified policy store. You can change only certain elements of the UpdatePolicyDefinition parameter. You can directly update only static policies. To change a template-linked policy, you must update the template instead, using UpdatePolicyTemplate.
 *
 * - If policy validation is enabled in the policy store, then updating a static policy causes Verified Permissions to validate the policy against the schema in the policy store. If the updated static policy doesn't pass validation, the operation fails and the update isn't stored.
 *
 * - When you edit a static policy, you can change only certain elements of a static policy:
 *
 * - The action referenced by the policy.
 *
 * - A condition clause, such as when and unless.
 *
 * You can't change these elements of a static policy:
 *
 * - Changing a policy from a static policy to a template-linked policy.
 *
 * - Changing the effect of a static policy from permit or forbid.
 *
 * - The principal referenced by a static policy.
 *
 * - The resource referenced by a static policy.
 *
 * - To update a template-linked policy, you must update the template instead.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const updatePolicy: API.OperationMethod<UpdatePolicyInput & RegionInput, UpdatePolicyOutput, UpdatePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyStoreError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the validation setting for a policy store.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const updatePolicyStore: API.OperationMethod<UpdatePolicyStoreInput & RegionInput, UpdatePolicyStoreOutput, UpdatePolicyStoreError, Credentials | HttpClient.HttpClient>;
export type UpdatePolicyTemplateError = ConflictException | ResourceNotFoundException | AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified policy template. You can update only the description and the some elements of the policyBody.
 *
 * Changes you make to the policy template content are immediately (within the constraints of eventual consistency) reflected in authorization decisions that involve all template-linked policies instantiated from this template.
 *
 * Verified Permissions is * eventually consistent *. It can take a few seconds for a new or changed element to propagate through the service and be visible in the results of other Verified Permissions operations.
 */
export declare const updatePolicyTemplate: API.OperationMethod<UpdatePolicyTemplateInput & RegionInput, UpdatePolicyTemplateOutput, UpdatePolicyTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=verifiedpermissions.d.ts.map