import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export interface StageKey {
    restApiId?: string | undefined;
    stageName?: string | undefined;
}
export type ListOfStageKeys = StageKey[];
export type MapOfStringToString = {
    [key: string]: string | undefined;
};
export interface CreateApiKeyRequest {
    name?: string | undefined;
    description?: string | undefined;
    enabled?: boolean | undefined;
    generateDistinctId?: boolean | undefined;
    value?: string | redacted.Redacted<string> | undefined;
    stageKeys?: StageKey[] | undefined;
    customerId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListOfString = string[];
export interface ApiKey {
    id?: string | undefined;
    value?: string | redacted.Redacted<string> | undefined;
    name?: string | undefined;
    customerId?: string | undefined;
    description?: string | undefined;
    enabled?: boolean | undefined;
    createdDate?: Date | undefined;
    lastUpdatedDate?: Date | undefined;
    stageKeys?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AuthorizerType = "TOKEN" | "REQUEST" | "COGNITO_USER_POOLS" | (string & {});
export type ProviderARN = string;
export type ListOfARNs = string[];
export interface CreateAuthorizerRequest {
    restApiId: string;
    name: string;
    type: AuthorizerType;
    providerARNs?: string[] | undefined;
    authType?: string | undefined;
    authorizerUri?: string | undefined;
    authorizerCredentials?: string | undefined;
    identitySource?: string | undefined;
    identityValidationExpression?: string | undefined;
    authorizerResultTtlInSeconds?: number | undefined;
}
export interface Authorizer {
    id?: string | undefined;
    name?: string | undefined;
    type?: AuthorizerType | undefined;
    providerARNs?: string[] | undefined;
    authType?: string | undefined;
    authorizerUri?: string | undefined;
    authorizerCredentials?: string | undefined;
    identitySource?: string | undefined;
    identityValidationExpression?: string | undefined;
    authorizerResultTtlInSeconds?: number | undefined;
}
export interface CreateBasePathMappingRequest {
    domainName: string;
    domainNameId?: string | undefined;
    basePath?: string | undefined;
    restApiId: string;
    stage?: string | undefined;
}
export interface BasePathMapping {
    basePath?: string | undefined;
    restApiId?: string | undefined;
    stage?: string | undefined;
}
export type CacheClusterSize = "0.5" | "1.6" | "6.1" | "13.5" | "28.4" | "58.2" | "118" | "237" | (string & {});
export interface DeploymentCanarySettings {
    percentTraffic?: number | undefined;
    stageVariableOverrides?: {
        [key: string]: string | undefined;
    } | undefined;
    useStageCache?: boolean | undefined;
}
export interface CreateDeploymentRequest {
    restApiId: string;
    stageName?: string | undefined;
    stageDescription?: string | undefined;
    description?: string | undefined;
    cacheClusterEnabled?: boolean | undefined;
    cacheClusterSize?: CacheClusterSize | undefined;
    variables?: {
        [key: string]: string | undefined;
    } | undefined;
    canarySettings?: DeploymentCanarySettings | undefined;
    tracingEnabled?: boolean | undefined;
}
export interface MethodSnapshot {
    authorizationType?: string | undefined;
    apiKeyRequired?: boolean | undefined;
}
export type MapOfMethodSnapshot = {
    [key: string]: MethodSnapshot | undefined;
};
export type PathToMapOfMethodSnapshot = {
    [key: string]: {
        [key: string]: MethodSnapshot | undefined;
    } | undefined;
};
export interface Deployment {
    id?: string | undefined;
    description?: string | undefined;
    createdDate?: Date | undefined;
    apiSummary?: {
        [key: string]: {
            [key: string]: MethodSnapshot | undefined;
        } | undefined;
    } | undefined;
}
export type DocumentationPartType = "API" | "AUTHORIZER" | "MODEL" | "RESOURCE" | "METHOD" | "PATH_PARAMETER" | "QUERY_PARAMETER" | "REQUEST_HEADER" | "REQUEST_BODY" | "RESPONSE" | "RESPONSE_HEADER" | "RESPONSE_BODY" | (string & {});
export type DocumentationPartLocationStatusCode = string;
export interface DocumentationPartLocation {
    type: DocumentationPartType;
    path?: string | undefined;
    method?: string | undefined;
    statusCode?: string | undefined;
    name?: string | undefined;
}
export interface CreateDocumentationPartRequest {
    restApiId: string;
    location: DocumentationPartLocation;
    properties: string;
}
export interface DocumentationPart {
    id?: string | undefined;
    location?: DocumentationPartLocation | undefined;
    properties?: string | undefined;
}
export interface CreateDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
    stageName?: string | undefined;
    description?: string | undefined;
}
export interface DocumentationVersion {
    version?: string | undefined;
    createdDate?: Date | undefined;
    description?: string | undefined;
}
export type EndpointType = "REGIONAL" | "EDGE" | "PRIVATE" | (string & {});
export type ListOfEndpointType = EndpointType[];
export type IpAddressType = "ipv4" | "dualstack" | (string & {});
export interface EndpointConfiguration {
    types?: EndpointType[] | undefined;
    ipAddressType?: IpAddressType | undefined;
    vpcEndpointIds?: string[] | undefined;
}
export type SecurityPolicy = "TLS_1_0" | "TLS_1_2" | "SecurityPolicy_TLS13_1_3_2025_09" | "SecurityPolicy_TLS13_1_3_FIPS_2025_09" | "SecurityPolicy_TLS13_1_2_PFS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_FIPS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_FIPS_PFS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_Ext2_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_Ext2_FIPS_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_PQ_2025_09" | "SecurityPolicy_TLS13_1_2_2021_06" | "SecurityPolicy_TLS13_2025_EDGE" | "SecurityPolicy_TLS12_PFS_2025_EDGE" | "SecurityPolicy_TLS12_2018_EDGE" | (string & {});
export type EndpointAccessMode = "BASIC" | "STRICT" | (string & {});
export interface MutualTlsAuthenticationInput {
    truststoreUri?: string | undefined;
    truststoreVersion?: string | undefined;
}
export type RoutingMode = "BASE_PATH_MAPPING_ONLY" | "ROUTING_RULE_ONLY" | "ROUTING_RULE_THEN_BASE_PATH_MAPPING" | (string & {});
export interface CreateDomainNameRequest {
    domainName: string;
    certificateName?: string | undefined;
    certificateBody?: string | undefined;
    certificatePrivateKey?: string | undefined;
    certificateChain?: string | undefined;
    certificateArn?: string | undefined;
    regionalCertificateName?: string | undefined;
    regionalCertificateArn?: string | undefined;
    endpointConfiguration?: EndpointConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    securityPolicy?: SecurityPolicy | undefined;
    endpointAccessMode?: EndpointAccessMode | undefined;
    mutualTlsAuthentication?: MutualTlsAuthenticationInput | undefined;
    ownershipVerificationCertificateArn?: string | undefined;
    policy?: string | undefined;
    routingMode?: RoutingMode | undefined;
}
export type DomainNameStatus = "AVAILABLE" | "UPDATING" | "PENDING" | "PENDING_CERTIFICATE_REIMPORT" | "PENDING_OWNERSHIP_VERIFICATION" | "FAILED" | (string & {});
export interface MutualTlsAuthentication {
    truststoreUri?: string | undefined;
    truststoreVersion?: string | undefined;
    truststoreWarnings?: string[] | undefined;
}
export interface DomainName {
    domainName?: string | undefined;
    domainNameId?: string | undefined;
    domainNameArn?: string | undefined;
    certificateName?: string | undefined;
    certificateArn?: string | undefined;
    certificateUploadDate?: Date | undefined;
    regionalDomainName?: string | undefined;
    regionalHostedZoneId?: string | undefined;
    regionalCertificateName?: string | undefined;
    regionalCertificateArn?: string | undefined;
    distributionDomainName?: string | undefined;
    distributionHostedZoneId?: string | undefined;
    endpointConfiguration?: EndpointConfiguration | undefined;
    domainNameStatus?: DomainNameStatus | undefined;
    domainNameStatusMessage?: string | undefined;
    securityPolicy?: SecurityPolicy | undefined;
    endpointAccessMode?: EndpointAccessMode | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    mutualTlsAuthentication?: MutualTlsAuthentication | undefined;
    ownershipVerificationCertificateArn?: string | undefined;
    managementPolicy?: string | undefined;
    policy?: string | undefined;
    routingMode?: RoutingMode | undefined;
}
export type AccessAssociationSourceType = "VPCE" | (string & {});
export interface CreateDomainNameAccessAssociationRequest {
    domainNameArn: string;
    accessAssociationSourceType: AccessAssociationSourceType;
    accessAssociationSource: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DomainNameAccessAssociation {
    domainNameAccessAssociationArn?: string | undefined;
    domainNameArn?: string | undefined;
    accessAssociationSourceType?: AccessAssociationSourceType | undefined;
    accessAssociationSource?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateModelRequest {
    restApiId: string;
    name: string;
    description?: string | undefined;
    schema?: string | undefined;
    contentType: string;
}
export interface Model {
    id?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    schema?: string | undefined;
    contentType?: string | undefined;
}
export interface CreateRequestValidatorRequest {
    restApiId: string;
    name?: string | undefined;
    validateRequestBody?: boolean | undefined;
    validateRequestParameters?: boolean | undefined;
}
export interface RequestValidator {
    id?: string | undefined;
    name?: string | undefined;
    validateRequestBody?: boolean | undefined;
    validateRequestParameters?: boolean | undefined;
}
export interface CreateResourceRequest {
    restApiId: string;
    parentId: string;
    pathPart: string;
}
export type MapOfStringToBoolean = {
    [key: string]: boolean | undefined;
};
export type StatusCode = string;
export interface MethodResponse {
    statusCode?: string | undefined;
    responseParameters?: {
        [key: string]: boolean | undefined;
    } | undefined;
    responseModels?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MapOfMethodResponse = {
    [key: string]: MethodResponse | undefined;
};
export type IntegrationType = "HTTP" | "AWS" | "MOCK" | "HTTP_PROXY" | "AWS_PROXY" | (string & {});
export type ConnectionType = "INTERNET" | "VPC_LINK" | (string & {});
export type ContentHandlingStrategy = "CONVERT_TO_BINARY" | "CONVERT_TO_TEXT" | (string & {});
export interface IntegrationResponse {
    statusCode?: string | undefined;
    selectionPattern?: string | undefined;
    responseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    responseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    contentHandling?: ContentHandlingStrategy | undefined;
}
export type MapOfIntegrationResponse = {
    [key: string]: IntegrationResponse | undefined;
};
export interface TlsConfig {
    insecureSkipVerification?: boolean | undefined;
}
export type ResponseTransferMode = "BUFFERED" | "STREAM" | (string & {});
export interface Integration {
    type?: IntegrationType | undefined;
    httpMethod?: string | undefined;
    uri?: string | undefined;
    connectionType?: ConnectionType | undefined;
    connectionId?: string | undefined;
    credentials?: string | undefined;
    requestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    requestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    passthroughBehavior?: string | undefined;
    contentHandling?: ContentHandlingStrategy | undefined;
    timeoutInMillis?: number | undefined;
    cacheNamespace?: string | undefined;
    cacheKeyParameters?: string[] | undefined;
    integrationResponses?: {
        [key: string]: IntegrationResponse | undefined;
    } | undefined;
    tlsConfig?: TlsConfig | undefined;
    responseTransferMode?: ResponseTransferMode | undefined;
    integrationTarget?: string | undefined;
}
export interface Method {
    httpMethod?: string | undefined;
    authorizationType?: string | undefined;
    authorizerId?: string | undefined;
    apiKeyRequired?: boolean | undefined;
    requestValidatorId?: string | undefined;
    operationName?: string | undefined;
    requestParameters?: {
        [key: string]: boolean | undefined;
    } | undefined;
    requestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    methodResponses?: {
        [key: string]: MethodResponse | undefined;
    } | undefined;
    methodIntegration?: Integration | undefined;
    authorizationScopes?: string[] | undefined;
}
export type MapOfMethod = {
    [key: string]: Method | undefined;
};
export interface Resource {
    id?: string | undefined;
    parentId?: string | undefined;
    pathPart?: string | undefined;
    path?: string | undefined;
    resourceMethods?: {
        [key: string]: Method | undefined;
    } | undefined;
}
export type ApiKeySourceType = "HEADER" | "AUTHORIZER" | (string & {});
export interface CreateRestApiRequest {
    name: string;
    description?: string | undefined;
    version?: string | undefined;
    cloneFrom?: string | undefined;
    binaryMediaTypes?: string[] | undefined;
    minimumCompressionSize?: number | undefined;
    apiKeySource?: ApiKeySourceType | undefined;
    endpointConfiguration?: EndpointConfiguration | undefined;
    policy?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    disableExecuteApiEndpoint?: boolean | undefined;
    securityPolicy?: SecurityPolicy | undefined;
    endpointAccessMode?: EndpointAccessMode | undefined;
}
export type ApiStatus = "UPDATING" | "AVAILABLE" | "PENDING" | "FAILED" | (string & {});
export interface RestApi {
    id?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    warnings?: string[] | undefined;
    binaryMediaTypes?: string[] | undefined;
    minimumCompressionSize?: number | undefined;
    apiKeySource?: ApiKeySourceType | undefined;
    endpointConfiguration?: EndpointConfiguration | undefined;
    policy?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    disableExecuteApiEndpoint?: boolean | undefined;
    rootResourceId?: string | undefined;
    securityPolicy?: SecurityPolicy | undefined;
    endpointAccessMode?: EndpointAccessMode | undefined;
    apiStatus?: ApiStatus | undefined;
    apiStatusMessage?: string | undefined;
}
export interface CanarySettings {
    percentTraffic?: number | undefined;
    deploymentId?: string | undefined;
    stageVariableOverrides?: {
        [key: string]: string | undefined;
    } | undefined;
    useStageCache?: boolean | undefined;
}
export interface CreateStageRequest {
    restApiId: string;
    stageName: string;
    deploymentId: string;
    description?: string | undefined;
    cacheClusterEnabled?: boolean | undefined;
    cacheClusterSize?: CacheClusterSize | undefined;
    variables?: {
        [key: string]: string | undefined;
    } | undefined;
    documentationVersion?: string | undefined;
    canarySettings?: CanarySettings | undefined;
    tracingEnabled?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CacheClusterStatus = "CREATE_IN_PROGRESS" | "AVAILABLE" | "DELETE_IN_PROGRESS" | "NOT_AVAILABLE" | "FLUSH_IN_PROGRESS" | (string & {});
export type UnauthorizedCacheControlHeaderStrategy = "FAIL_WITH_403" | "SUCCEED_WITH_RESPONSE_HEADER" | "SUCCEED_WITHOUT_RESPONSE_HEADER" | (string & {});
export interface MethodSetting {
    metricsEnabled?: boolean | undefined;
    loggingLevel?: string | undefined;
    dataTraceEnabled?: boolean | undefined;
    throttlingBurstLimit?: number | undefined;
    throttlingRateLimit?: number | undefined;
    cachingEnabled?: boolean | undefined;
    cacheTtlInSeconds?: number | undefined;
    cacheDataEncrypted?: boolean | undefined;
    requireAuthorizationForCacheControl?: boolean | undefined;
    unauthorizedCacheControlHeaderStrategy?: UnauthorizedCacheControlHeaderStrategy | undefined;
}
export type MapOfMethodSettings = {
    [key: string]: MethodSetting | undefined;
};
export interface AccessLogSettings {
    format?: string | undefined;
    destinationArn?: string | undefined;
}
export interface Stage {
    deploymentId?: string | undefined;
    clientCertificateId?: string | undefined;
    stageName?: string | undefined;
    description?: string | undefined;
    cacheClusterEnabled?: boolean | undefined;
    cacheClusterSize?: CacheClusterSize | undefined;
    cacheClusterStatus?: CacheClusterStatus | undefined;
    methodSettings?: {
        [key: string]: MethodSetting | undefined;
    } | undefined;
    variables?: {
        [key: string]: string | undefined;
    } | undefined;
    documentationVersion?: string | undefined;
    accessLogSettings?: AccessLogSettings | undefined;
    canarySettings?: CanarySettings | undefined;
    tracingEnabled?: boolean | undefined;
    webAclArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    createdDate?: Date | undefined;
    lastUpdatedDate?: Date | undefined;
}
export interface ThrottleSettings {
    burstLimit?: number | undefined;
    rateLimit?: number | undefined;
}
export type MapOfApiStageThrottleSettings = {
    [key: string]: ThrottleSettings | undefined;
};
export interface ApiStage {
    apiId?: string | undefined;
    stage?: string | undefined;
    throttle?: {
        [key: string]: ThrottleSettings | undefined;
    } | undefined;
}
export type ListOfApiStage = ApiStage[];
export type QuotaPeriodType = "DAY" | "WEEK" | "MONTH" | (string & {});
export interface QuotaSettings {
    limit?: number | undefined;
    offset?: number | undefined;
    period?: QuotaPeriodType | undefined;
}
export interface CreateUsagePlanRequest {
    name: string;
    description?: string | undefined;
    apiStages?: ApiStage[] | undefined;
    throttle?: ThrottleSettings | undefined;
    quota?: QuotaSettings | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UsagePlan {
    id?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    apiStages?: ApiStage[] | undefined;
    throttle?: ThrottleSettings | undefined;
    quota?: QuotaSettings | undefined;
    productCode?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateUsagePlanKeyRequest {
    usagePlanId: string;
    keyId: string;
    keyType: string;
}
export interface UsagePlanKey {
    id?: string | undefined;
    type?: string | undefined;
    value?: string | undefined;
    name?: string | undefined;
}
export interface CreateVpcLinkRequest {
    name: string;
    description?: string | undefined;
    targetArns: string[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type VpcLinkStatus = "AVAILABLE" | "PENDING" | "DELETING" | "FAILED" | (string & {});
export interface VpcLink {
    id?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    targetArns?: string[] | undefined;
    status?: VpcLinkStatus | undefined;
    statusMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteApiKeyRequest {
    apiKey: string;
}
export interface DeleteApiKeyResponse {
}
export interface DeleteAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
}
export interface DeleteAuthorizerResponse {
}
export interface DeleteBasePathMappingRequest {
    domainName: string;
    domainNameId?: string | undefined;
    basePath: string;
}
export interface DeleteBasePathMappingResponse {
}
export interface DeleteClientCertificateRequest {
    clientCertificateId: string;
}
export interface DeleteClientCertificateResponse {
}
export interface DeleteDeploymentRequest {
    restApiId: string;
    deploymentId: string;
}
export interface DeleteDeploymentResponse {
}
export interface DeleteDocumentationPartRequest {
    restApiId: string;
    documentationPartId: string;
}
export interface DeleteDocumentationPartResponse {
}
export interface DeleteDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
}
export interface DeleteDocumentationVersionResponse {
}
export interface DeleteDomainNameRequest {
    domainName: string;
    domainNameId?: string | undefined;
}
export interface DeleteDomainNameResponse {
}
export interface DeleteDomainNameAccessAssociationRequest {
    domainNameAccessAssociationArn: string;
}
export interface DeleteDomainNameAccessAssociationResponse {
}
export type GatewayResponseType = "DEFAULT_4XX" | "DEFAULT_5XX" | "RESOURCE_NOT_FOUND" | "UNAUTHORIZED" | "INVALID_API_KEY" | "ACCESS_DENIED" | "AUTHORIZER_FAILURE" | "AUTHORIZER_CONFIGURATION_ERROR" | "INVALID_SIGNATURE" | "EXPIRED_TOKEN" | "MISSING_AUTHENTICATION_TOKEN" | "INTEGRATION_FAILURE" | "INTEGRATION_TIMEOUT" | "API_CONFIGURATION_ERROR" | "UNSUPPORTED_MEDIA_TYPE" | "BAD_REQUEST_PARAMETERS" | "BAD_REQUEST_BODY" | "REQUEST_TOO_LARGE" | "THROTTLED" | "QUOTA_EXCEEDED" | "WAF_FILTERED" | (string & {});
export interface DeleteGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
}
export interface DeleteGatewayResponseResponse {
}
export interface DeleteIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface DeleteIntegrationResponse {
}
export interface DeleteIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface DeleteIntegrationResponseResponse {
}
export interface DeleteMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface DeleteMethodResponse {
}
export interface DeleteMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface DeleteMethodResponseResponse {
}
export interface DeleteModelRequest {
    restApiId: string;
    modelName: string;
}
export interface DeleteModelResponse {
}
export interface DeleteRequestValidatorRequest {
    restApiId: string;
    requestValidatorId: string;
}
export interface DeleteRequestValidatorResponse {
}
export interface DeleteResourceRequest {
    restApiId: string;
    resourceId: string;
}
export interface DeleteResourceResponse {
}
export interface DeleteRestApiRequest {
    restApiId: string;
}
export interface DeleteRestApiResponse {
}
export interface DeleteStageRequest {
    restApiId: string;
    stageName: string;
}
export interface DeleteStageResponse {
}
export interface DeleteUsagePlanRequest {
    usagePlanId: string;
}
export interface DeleteUsagePlanResponse {
}
export interface DeleteUsagePlanKeyRequest {
    usagePlanId: string;
    keyId: string;
}
export interface DeleteUsagePlanKeyResponse {
}
export interface DeleteVpcLinkRequest {
    vpcLinkId: string;
}
export interface DeleteVpcLinkResponse {
}
export interface FlushStageAuthorizersCacheRequest {
    restApiId: string;
    stageName: string;
}
export interface FlushStageAuthorizersCacheResponse {
}
export interface FlushStageCacheRequest {
    restApiId: string;
    stageName: string;
}
export interface FlushStageCacheResponse {
}
export interface GenerateClientCertificateRequest {
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ClientCertificate {
    clientCertificateId?: string | undefined;
    description?: string | undefined;
    pemEncodedCertificate?: string | undefined;
    createdDate?: Date | undefined;
    expirationDate?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetAccountRequest {
}
export interface Account {
    cloudwatchRoleArn?: string | undefined;
    throttleSettings?: ThrottleSettings | undefined;
    features?: string[] | undefined;
    apiKeyVersion?: string | undefined;
}
export interface GetApiKeyRequest {
    apiKey: string;
    includeValue?: boolean | undefined;
}
export interface GetApiKeysRequest {
    position?: string | undefined;
    limit?: number | undefined;
    nameQuery?: string | undefined;
    customerId?: string | undefined;
    includeValues?: boolean | undefined;
}
export type ListOfApiKey = ApiKey[];
export interface ApiKeys {
    warnings?: string[] | undefined;
    items?: ApiKey[] | undefined;
    position?: string | undefined;
}
export interface GetAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
}
export interface GetAuthorizersRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfAuthorizer = Authorizer[];
export interface Authorizers {
    items?: Authorizer[] | undefined;
    position?: string | undefined;
}
export interface GetBasePathMappingRequest {
    domainName: string;
    domainNameId?: string | undefined;
    basePath: string;
}
export interface GetBasePathMappingsRequest {
    domainName: string;
    domainNameId?: string | undefined;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfBasePathMapping = BasePathMapping[];
export interface BasePathMappings {
    items?: BasePathMapping[] | undefined;
    position?: string | undefined;
}
export interface GetClientCertificateRequest {
    clientCertificateId: string;
}
export interface GetClientCertificatesRequest {
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfClientCertificate = ClientCertificate[];
export interface ClientCertificates {
    items?: ClientCertificate[] | undefined;
    position?: string | undefined;
}
export interface GetDeploymentRequest {
    restApiId: string;
    deploymentId: string;
    embed?: string[] | undefined;
}
export interface GetDeploymentsRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfDeployment = Deployment[];
export interface Deployments {
    items?: Deployment[] | undefined;
    position?: string | undefined;
}
export interface GetDocumentationPartRequest {
    restApiId: string;
    documentationPartId: string;
}
export type LocationStatusType = "DOCUMENTED" | "UNDOCUMENTED" | (string & {});
export interface GetDocumentationPartsRequest {
    restApiId: string;
    type?: DocumentationPartType | undefined;
    nameQuery?: string | undefined;
    path?: string | undefined;
    position?: string | undefined;
    limit?: number | undefined;
    locationStatus?: LocationStatusType | undefined;
}
export type ListOfDocumentationPart = DocumentationPart[];
export interface DocumentationParts {
    items?: DocumentationPart[] | undefined;
    position?: string | undefined;
}
export interface GetDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
}
export interface GetDocumentationVersionsRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfDocumentationVersion = DocumentationVersion[];
export interface DocumentationVersions {
    items?: DocumentationVersion[] | undefined;
    position?: string | undefined;
}
export interface GetDomainNameRequest {
    domainName: string;
    domainNameId?: string | undefined;
}
export type ResourceOwner = "SELF" | "OTHER_ACCOUNTS" | (string & {});
export interface GetDomainNameAccessAssociationsRequest {
    position?: string | undefined;
    limit?: number | undefined;
    resourceOwner?: ResourceOwner | undefined;
}
export type ListOfDomainNameAccessAssociation = DomainNameAccessAssociation[];
export interface DomainNameAccessAssociations {
    items?: DomainNameAccessAssociation[] | undefined;
    position?: string | undefined;
}
export interface GetDomainNamesRequest {
    position?: string | undefined;
    limit?: number | undefined;
    resourceOwner?: ResourceOwner | undefined;
}
export type ListOfDomainName = DomainName[];
export interface DomainNames {
    items?: DomainName[] | undefined;
    position?: string | undefined;
}
export interface GetExportRequest {
    restApiId: string;
    stageName: string;
    exportType: string;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    accepts?: string | undefined;
}
export interface ExportResponse {
    contentType?: string | undefined;
    contentDisposition?: string | undefined;
    body?: T.StreamingOutputBody | undefined;
}
export interface GetGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
}
export interface GatewayResponse {
    responseType?: GatewayResponseType | undefined;
    statusCode?: string | undefined;
    responseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    responseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    defaultResponse?: boolean | undefined;
}
export interface GetGatewayResponsesRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfGatewayResponse = GatewayResponse[];
export interface GatewayResponses {
    items?: GatewayResponse[] | undefined;
    position?: string | undefined;
}
export interface GetIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface GetIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface GetMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
}
export interface GetMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
}
export interface GetModelRequest {
    restApiId: string;
    modelName: string;
    flatten?: boolean | undefined;
}
export interface GetModelsRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfModel = Model[];
export interface Models {
    items?: Model[] | undefined;
    position?: string | undefined;
}
export interface GetModelTemplateRequest {
    restApiId: string;
    modelName: string;
}
export interface Template {
    value?: string | undefined;
}
export interface GetRequestValidatorRequest {
    restApiId: string;
    requestValidatorId: string;
}
export interface GetRequestValidatorsRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfRequestValidator = RequestValidator[];
export interface RequestValidators {
    items?: RequestValidator[] | undefined;
    position?: string | undefined;
}
export interface GetResourceRequest {
    restApiId: string;
    resourceId: string;
    embed?: string[] | undefined;
}
export interface GetResourcesRequest {
    restApiId: string;
    position?: string | undefined;
    limit?: number | undefined;
    embed?: string[] | undefined;
}
export type ListOfResource = Resource[];
export interface Resources {
    items?: Resource[] | undefined;
    position?: string | undefined;
}
export interface GetRestApiRequest {
    restApiId: string;
}
export interface GetRestApisRequest {
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfRestApi = RestApi[];
export interface RestApis {
    items?: RestApi[] | undefined;
    position?: string | undefined;
}
export interface GetSdkRequest {
    restApiId: string;
    stageName: string;
    sdkType: string;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SdkResponse {
    contentType?: string | undefined;
    contentDisposition?: string | undefined;
    body?: T.StreamingOutputBody | undefined;
}
export interface GetSdkTypeRequest {
    id: string;
}
export interface SdkConfigurationProperty {
    name?: string | undefined;
    friendlyName?: string | undefined;
    description?: string | undefined;
    required?: boolean | undefined;
    defaultValue?: string | undefined;
}
export type ListOfSdkConfigurationProperty = SdkConfigurationProperty[];
export interface SdkType {
    id?: string | undefined;
    friendlyName?: string | undefined;
    description?: string | undefined;
    configurationProperties?: SdkConfigurationProperty[] | undefined;
}
export interface GetSdkTypesRequest {
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfSdkType = SdkType[];
export interface SdkTypes {
    items?: SdkType[] | undefined;
}
export interface GetStageRequest {
    restApiId: string;
    stageName: string;
}
export interface GetStagesRequest {
    restApiId: string;
    deploymentId?: string | undefined;
}
export type ListOfStage = Stage[];
export interface Stages {
    item?: Stage[] | undefined;
}
export interface GetTagsRequest {
    resourceArn: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export interface Tags {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetUsageRequest {
    usagePlanId: string;
    keyId?: string | undefined;
    startDate: string;
    endDate: string;
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfLong = number[];
export type ListOfUsage = number[][];
export type MapOfKeyUsages = {
    [key: string]: number[][] | undefined;
};
export interface Usage {
    usagePlanId?: string | undefined;
    startDate?: string | undefined;
    endDate?: string | undefined;
    items?: {
        [key: string]: number[][] | undefined;
    } | undefined;
    position?: string | undefined;
}
export interface GetUsagePlanRequest {
    usagePlanId: string;
}
export interface GetUsagePlanKeyRequest {
    usagePlanId: string;
    keyId: string;
}
export interface GetUsagePlanKeysRequest {
    usagePlanId: string;
    position?: string | undefined;
    limit?: number | undefined;
    nameQuery?: string | undefined;
}
export type ListOfUsagePlanKey = UsagePlanKey[];
export interface UsagePlanKeys {
    items?: UsagePlanKey[] | undefined;
    position?: string | undefined;
}
export interface GetUsagePlansRequest {
    position?: string | undefined;
    keyId?: string | undefined;
    limit?: number | undefined;
}
export type ListOfUsagePlan = UsagePlan[];
export interface UsagePlans {
    items?: UsagePlan[] | undefined;
    position?: string | undefined;
}
export interface GetVpcLinkRequest {
    vpcLinkId: string;
}
export interface GetVpcLinksRequest {
    position?: string | undefined;
    limit?: number | undefined;
}
export type ListOfVpcLink = VpcLink[];
export interface VpcLinks {
    items?: VpcLink[] | undefined;
    position?: string | undefined;
}
export type ApiKeysFormat = "csv" | (string & {});
export interface ImportApiKeysRequest {
    body: T.StreamingInputBody;
    format: ApiKeysFormat;
    failOnWarnings?: boolean | undefined;
}
export interface ApiKeyIds {
    ids?: string[] | undefined;
    warnings?: string[] | undefined;
}
export type PutMode = "merge" | "overwrite" | (string & {});
export interface ImportDocumentationPartsRequest {
    restApiId: string;
    mode?: PutMode | undefined;
    failOnWarnings?: boolean | undefined;
    body: T.StreamingInputBody;
}
export interface DocumentationPartIds {
    ids?: string[] | undefined;
    warnings?: string[] | undefined;
}
export interface ImportRestApiRequest {
    failOnWarnings?: boolean | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    body: T.StreamingInputBody;
}
export interface PutGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
    statusCode?: string | undefined;
    responseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    responseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    type: IntegrationType;
    integrationHttpMethod?: string | undefined;
    uri?: string | undefined;
    connectionType?: ConnectionType | undefined;
    connectionId?: string | undefined;
    credentials?: string | undefined;
    requestParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    requestTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    passthroughBehavior?: string | undefined;
    cacheNamespace?: string | undefined;
    cacheKeyParameters?: string[] | undefined;
    contentHandling?: ContentHandlingStrategy | undefined;
    timeoutInMillis?: number | undefined;
    tlsConfig?: TlsConfig | undefined;
    responseTransferMode?: ResponseTransferMode | undefined;
    integrationTarget?: string | undefined;
}
export interface PutIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    selectionPattern?: string | undefined;
    responseParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    responseTemplates?: {
        [key: string]: string | undefined;
    } | undefined;
    contentHandling?: ContentHandlingStrategy | undefined;
}
export interface PutMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    authorizationType: string;
    authorizerId?: string | undefined;
    apiKeyRequired?: boolean | undefined;
    operationName?: string | undefined;
    requestParameters?: {
        [key: string]: boolean | undefined;
    } | undefined;
    requestModels?: {
        [key: string]: string | undefined;
    } | undefined;
    requestValidatorId?: string | undefined;
    authorizationScopes?: string[] | undefined;
}
export interface PutMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    responseParameters?: {
        [key: string]: boolean | undefined;
    } | undefined;
    responseModels?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutRestApiRequest {
    restApiId: string;
    mode?: PutMode | undefined;
    failOnWarnings?: boolean | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    body: T.StreamingInputBody;
}
export interface RejectDomainNameAccessAssociationRequest {
    domainNameAccessAssociationArn: string;
    domainNameArn: string;
}
export interface RejectDomainNameAccessAssociationResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type MapOfStringToList = {
    [key: string]: string[] | undefined;
};
export interface TestInvokeAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
    headers?: {
        [key: string]: string | undefined;
    } | undefined;
    multiValueHeaders?: {
        [key: string]: string[] | undefined;
    } | undefined;
    pathWithQueryString?: string | undefined;
    body?: string | undefined;
    stageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    additionalContext?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TestInvokeAuthorizerResponse {
    clientStatus?: number | undefined;
    log?: string | undefined;
    latency?: number | undefined;
    principalId?: string | undefined;
    policy?: string | undefined;
    authorization?: {
        [key: string]: string[] | undefined;
    } | undefined;
    claims?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TestInvokeMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    pathWithQueryString?: string | undefined;
    body?: string | undefined;
    headers?: {
        [key: string]: string | undefined;
    } | undefined;
    multiValueHeaders?: {
        [key: string]: string[] | undefined;
    } | undefined;
    clientCertificateId?: string | undefined;
    stageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TestInvokeMethodResponse {
    status?: number | undefined;
    body?: string | undefined;
    headers?: {
        [key: string]: string | undefined;
    } | undefined;
    multiValueHeaders?: {
        [key: string]: string[] | undefined;
    } | undefined;
    log?: string | undefined;
    latency?: number | undefined;
}
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type Op = "add" | "remove" | "replace" | "move" | "copy" | "test" | (string & {});
export interface PatchOperation {
    op?: Op | undefined;
    path?: string | undefined;
    value?: string | undefined;
    from?: string | undefined;
}
export type ListOfPatchOperation = PatchOperation[];
export interface UpdateAccountRequest {
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateApiKeyRequest {
    apiKey: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateAuthorizerRequest {
    restApiId: string;
    authorizerId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateBasePathMappingRequest {
    domainName: string;
    domainNameId?: string | undefined;
    basePath: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateClientCertificateRequest {
    clientCertificateId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateDeploymentRequest {
    restApiId: string;
    deploymentId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateDocumentationPartRequest {
    restApiId: string;
    documentationPartId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateDocumentationVersionRequest {
    restApiId: string;
    documentationVersion: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateDomainNameRequest {
    domainName: string;
    domainNameId?: string | undefined;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateGatewayResponseRequest {
    restApiId: string;
    responseType: GatewayResponseType;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateIntegrationRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateIntegrationResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateMethodRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateMethodResponseRequest {
    restApiId: string;
    resourceId: string;
    httpMethod: string;
    statusCode: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateModelRequest {
    restApiId: string;
    modelName: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateRequestValidatorRequest {
    restApiId: string;
    requestValidatorId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateResourceRequest {
    restApiId: string;
    resourceId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateRestApiRequest {
    restApiId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateStageRequest {
    restApiId: string;
    stageName: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateUsageRequest {
    usagePlanId: string;
    keyId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateUsagePlanRequest {
    usagePlanId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export interface UpdateVpcLinkRequest {
    vpcLinkId: string;
    patchOperations?: PatchOperation[] | undefined;
}
export type CreateApiKeyError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Create an ApiKey resource.
 */
export declare const createApiKey: API.OperationMethod<CreateApiKeyRequest & RegionInput, ApiKey, CreateApiKeyError, Credentials | HttpClient.HttpClient>;
export type CreateAuthorizerError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds a new Authorizer resource to an existing RestApi resource.
 */
export declare const createAuthorizer: API.OperationMethod<CreateAuthorizerRequest & RegionInput, Authorizer, CreateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type CreateBasePathMappingError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new BasePathMapping resource.
 */
export declare const createBasePathMapping: API.OperationMethod<CreateBasePathMappingRequest & RegionInput, BasePathMapping, CreateBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Deployment resource, which makes a specified RestApi callable over the internet.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest & RegionInput, Deployment, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDocumentationPartError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a documentation part.
 */
export declare const createDocumentationPart: API.OperationMethod<CreateDocumentationPartRequest & RegionInput, DocumentationPart, CreateDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type CreateDocumentationVersionError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a documentation version
 */
export declare const createDocumentationVersion: API.OperationMethod<CreateDocumentationVersionRequest & RegionInput, DocumentationVersion, CreateDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new domain name.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest & RegionInput, DomainName, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameAccessAssociationError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a domain name access association resource between an access association source and a private custom
 * domain name.
 */
export declare const createDomainNameAccessAssociation: API.OperationMethod<CreateDomainNameAccessAssociationRequest & RegionInput, DomainNameAccessAssociation, CreateDomainNameAccessAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateModelError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds a new Model resource to an existing RestApi resource.
 */
export declare const createModel: API.OperationMethod<CreateModelRequest & RegionInput, Model, CreateModelError, Credentials | HttpClient.HttpClient>;
export type CreateRequestValidatorError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a RequestValidator of a given RestApi.
 */
export declare const createRequestValidator: API.OperationMethod<CreateRequestValidatorRequest & RegionInput, RequestValidator, CreateRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type CreateResourceError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a Resource resource.
 */
export declare const createResource: API.OperationMethod<CreateResourceRequest & RegionInput, Resource, CreateResourceError, Credentials | HttpClient.HttpClient>;
export type CreateRestApiError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new RestApi resource.
 */
export declare const createRestApi: API.OperationMethod<CreateRestApiRequest & RegionInput, RestApi, CreateRestApiError, Credentials | HttpClient.HttpClient>;
export type CreateStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a new Stage resource that references a pre-existing Deployment for the API.
 */
export declare const createStage: API.OperationMethod<CreateStageRequest & RegionInput, Stage, CreateStageError, Credentials | HttpClient.HttpClient>;
export type CreateUsagePlanError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a usage plan with the throttle and quota limits, as well as the associated API stages, specified in the payload.
 */
export declare const createUsagePlan: API.OperationMethod<CreateUsagePlanRequest & RegionInput, UsagePlan, CreateUsagePlanError, Credentials | HttpClient.HttpClient>;
export type CreateUsagePlanKeyError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a usage plan key for adding an existing API key to a usage plan.
 */
export declare const createUsagePlanKey: API.OperationMethod<CreateUsagePlanKeyRequest & RegionInput, UsagePlanKey, CreateUsagePlanKeyError, Credentials | HttpClient.HttpClient>;
export type CreateVpcLinkError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a VPC link, under the caller's account in a selected region, in an asynchronous operation that typically takes 2-4 minutes to complete and become operational. The caller must have permissions to create and update VPC Endpoint services.
 */
export declare const createVpcLink: API.OperationMethod<CreateVpcLinkRequest & RegionInput, VpcLink, CreateVpcLinkError, Credentials | HttpClient.HttpClient>;
export type DeleteApiKeyError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the ApiKey resource.
 */
export declare const deleteApiKey: API.OperationMethod<DeleteApiKeyRequest & RegionInput, DeleteApiKeyResponse, DeleteApiKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteAuthorizerError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing Authorizer resource.
 */
export declare const deleteAuthorizer: API.OperationMethod<DeleteAuthorizerRequest & RegionInput, DeleteAuthorizerResponse, DeleteAuthorizerError, Credentials | HttpClient.HttpClient>;
export type DeleteBasePathMappingError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the BasePathMapping resource.
 */
export declare const deleteBasePathMapping: API.OperationMethod<DeleteBasePathMappingRequest & RegionInput, DeleteBasePathMappingResponse, DeleteBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteClientCertificateError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the ClientCertificate resource.
 */
export declare const deleteClientCertificate: API.OperationMethod<DeleteClientCertificateRequest & RegionInput, DeleteClientCertificateResponse, DeleteClientCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteDeploymentError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Deployment resource. Deleting a deployment will only succeed if there are no Stage resources associated with it.
 */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest & RegionInput, DeleteDeploymentResponse, DeleteDeploymentError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentationPartError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a documentation part
 */
export declare const deleteDocumentationPart: API.OperationMethod<DeleteDocumentationPartRequest & RegionInput, DeleteDocumentationPartResponse, DeleteDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type DeleteDocumentationVersionError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a documentation version.
 */
export declare const deleteDocumentationVersion: API.OperationMethod<DeleteDocumentationVersionRequest & RegionInput, DeleteDocumentationVersionResponse, DeleteDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the DomainName resource.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest & RegionInput, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameAccessAssociationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the DomainNameAccessAssociation resource.
 *
 * Only the AWS account that created the DomainNameAccessAssociation resource can delete it. To stop an access association source in another AWS account from accessing your private custom domain name, use the RejectDomainNameAccessAssociation operation.
 */
export declare const deleteDomainNameAccessAssociation: API.OperationMethod<DeleteDomainNameAccessAssociationRequest & RegionInput, DeleteDomainNameAccessAssociationResponse, DeleteDomainNameAccessAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Clears any customization of a GatewayResponse of a specified response type on the given RestApi and resets it with the default settings.
 */
export declare const deleteGatewayResponse: API.OperationMethod<DeleteGatewayResponseRequest & RegionInput, DeleteGatewayResponseResponse, DeleteGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a delete integration.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationRequest & RegionInput, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a delete integration response.
 */
export declare const deleteIntegrationResponse: API.OperationMethod<DeleteIntegrationResponseRequest & RegionInput, DeleteIntegrationResponseResponse, DeleteIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteMethodError = ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing Method resource.
 */
export declare const deleteMethod: API.OperationMethod<DeleteMethodRequest & RegionInput, DeleteMethodResponse, DeleteMethodError, Credentials | HttpClient.HttpClient>;
export type DeleteMethodResponseError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing MethodResponse resource.
 */
export declare const deleteMethodResponse: API.OperationMethod<DeleteMethodResponseRequest & RegionInput, DeleteMethodResponseResponse, DeleteMethodResponseError, Credentials | HttpClient.HttpClient>;
export type DeleteModelError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a model.
 */
export declare const deleteModel: API.OperationMethod<DeleteModelRequest & RegionInput, DeleteModelResponse, DeleteModelError, Credentials | HttpClient.HttpClient>;
export type DeleteRequestValidatorError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a RequestValidator of a given RestApi.
 */
export declare const deleteRequestValidator: API.OperationMethod<DeleteRequestValidatorRequest & RegionInput, DeleteRequestValidatorResponse, DeleteRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Resource resource.
 */
export declare const deleteResource: API.OperationMethod<DeleteResourceRequest & RegionInput, DeleteResourceResponse, DeleteResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteRestApiError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes the specified API.
 */
export declare const deleteRestApi: API.OperationMethod<DeleteRestApiRequest & RegionInput, DeleteRestApiResponse, DeleteRestApiError, Credentials | HttpClient.HttpClient>;
export type DeleteStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Stage resource.
 */
export declare const deleteStage: API.OperationMethod<DeleteStageRequest & RegionInput, DeleteStageResponse, DeleteStageError, Credentials | HttpClient.HttpClient>;
export type DeleteUsagePlanError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a usage plan of a given plan Id.
 */
export declare const deleteUsagePlan: API.OperationMethod<DeleteUsagePlanRequest & RegionInput, DeleteUsagePlanResponse, DeleteUsagePlanError, Credentials | HttpClient.HttpClient>;
export type DeleteUsagePlanKeyError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes a usage plan key and remove the underlying API key from the associated usage plan.
 */
export declare const deleteUsagePlanKey: API.OperationMethod<DeleteUsagePlanKeyRequest & RegionInput, DeleteUsagePlanKeyResponse, DeleteUsagePlanKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcLinkError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Deletes an existing VpcLink of a specified identifier.
 */
export declare const deleteVpcLink: API.OperationMethod<DeleteVpcLinkRequest & RegionInput, DeleteVpcLinkResponse, DeleteVpcLinkError, Credentials | HttpClient.HttpClient>;
export type FlushStageAuthorizersCacheError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Flushes all authorizer cache entries on a stage.
 */
export declare const flushStageAuthorizersCache: API.OperationMethod<FlushStageAuthorizersCacheRequest & RegionInput, FlushStageAuthorizersCacheResponse, FlushStageAuthorizersCacheError, Credentials | HttpClient.HttpClient>;
export type FlushStageCacheError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Flushes a stage's cache.
 */
export declare const flushStageCache: API.OperationMethod<FlushStageCacheRequest & RegionInput, FlushStageCacheResponse, FlushStageCacheError, Credentials | HttpClient.HttpClient>;
export type GenerateClientCertificateError = BadRequestException | ConflictException | LimitExceededException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Generates a ClientCertificate resource.
 */
export declare const generateClientCertificate: API.OperationMethod<GenerateClientCertificateRequest & RegionInput, ClientCertificate, GenerateClientCertificateError, Credentials | HttpClient.HttpClient>;
export type GetAccountError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current Account resource.
 */
export declare const getAccount: API.OperationMethod<GetAccountRequest & RegionInput, Account, GetAccountError, Credentials | HttpClient.HttpClient>;
export type GetApiKeyError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current ApiKey resource.
 */
export declare const getApiKey: API.OperationMethod<GetApiKeyRequest & RegionInput, ApiKey, GetApiKeyError, Credentials | HttpClient.HttpClient>;
export type GetApiKeysError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current ApiKeys resource.
 */
export declare const getApiKeys: API.PaginatedOperationMethod<GetApiKeysRequest & RegionInput, ApiKeys, GetApiKeysError, Credentials | HttpClient.HttpClient, ApiKey>;
export type GetAuthorizerError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe an existing Authorizer resource.
 */
export declare const getAuthorizer: API.OperationMethod<GetAuthorizerRequest & RegionInput, Authorizer, GetAuthorizerError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizersError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe an existing Authorizers resource.
 */
export declare const getAuthorizers: API.OperationMethod<GetAuthorizersRequest & RegionInput, Authorizers, GetAuthorizersError, Credentials | HttpClient.HttpClient>;
export type GetBasePathMappingError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe a BasePathMapping resource.
 */
export declare const getBasePathMapping: API.OperationMethod<GetBasePathMappingRequest & RegionInput, BasePathMapping, GetBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type GetBasePathMappingsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a collection of BasePathMapping resources.
 */
export declare const getBasePathMappings: API.PaginatedOperationMethod<GetBasePathMappingsRequest & RegionInput, BasePathMappings, GetBasePathMappingsError, Credentials | HttpClient.HttpClient, BasePathMapping>;
export type GetClientCertificateError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about the current ClientCertificate resource.
 */
export declare const getClientCertificate: API.OperationMethod<GetClientCertificateRequest & RegionInput, ClientCertificate, GetClientCertificateError, Credentials | HttpClient.HttpClient>;
export type GetClientCertificatesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a collection of ClientCertificate resources.
 */
export declare const getClientCertificates: API.PaginatedOperationMethod<GetClientCertificatesRequest & RegionInput, ClientCertificates, GetClientCertificatesError, Credentials | HttpClient.HttpClient, ClientCertificate>;
export type GetDeploymentError = BadRequestException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about a Deployment resource.
 */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest & RegionInput, Deployment, GetDeploymentError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentsError = BadRequestException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about a Deployments collection.
 */
export declare const getDeployments: API.PaginatedOperationMethod<GetDeploymentsRequest & RegionInput, Deployments, GetDeploymentsError, Credentials | HttpClient.HttpClient, Deployment>;
export type GetDocumentationPartError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a documentation part.
 */
export declare const getDocumentationPart: API.OperationMethod<GetDocumentationPartRequest & RegionInput, DocumentationPart, GetDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type GetDocumentationPartsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets documentation parts.
 */
export declare const getDocumentationParts: API.OperationMethod<GetDocumentationPartsRequest & RegionInput, DocumentationParts, GetDocumentationPartsError, Credentials | HttpClient.HttpClient>;
export type GetDocumentationVersionError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a documentation version.
 */
export declare const getDocumentationVersion: API.OperationMethod<GetDocumentationVersionRequest & RegionInput, DocumentationVersion, GetDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type GetDocumentationVersionsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets documentation versions.
 */
export declare const getDocumentationVersions: API.OperationMethod<GetDocumentationVersionsRequest & RegionInput, DocumentationVersions, GetDocumentationVersionsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a domain name that is contained in a simpler, more intuitive URL that can be called.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest & RegionInput, DomainName, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameAccessAssociationsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a collection on DomainNameAccessAssociations resources.
 */
export declare const getDomainNameAccessAssociations: API.OperationMethod<GetDomainNameAccessAssociationsRequest & RegionInput, DomainNameAccessAssociations, GetDomainNameAccessAssociationsError, Credentials | HttpClient.HttpClient>;
export type GetDomainNamesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a collection of DomainName resources.
 */
export declare const getDomainNames: API.PaginatedOperationMethod<GetDomainNamesRequest & RegionInput, DomainNames, GetDomainNamesError, Credentials | HttpClient.HttpClient, DomainName>;
export type GetExportError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Exports a deployed version of a RestApi in a specified format.
 */
export declare const getExport: API.OperationMethod<GetExportRequest & RegionInput, ExportResponse, GetExportError, Credentials | HttpClient.HttpClient>;
export type GetGatewayResponseError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a GatewayResponse of a specified response type on the given RestApi.
 */
export declare const getGatewayResponse: API.OperationMethod<GetGatewayResponseRequest & RegionInput, GatewayResponse, GetGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type GetGatewayResponsesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the GatewayResponses collection on the given RestApi. If an API developer has not added any definitions for gateway responses, the result will be the API Gateway-generated default GatewayResponses collection for the supported response types.
 */
export declare const getGatewayResponses: API.OperationMethod<GetGatewayResponsesRequest & RegionInput, GatewayResponses, GetGatewayResponsesError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Get the integration settings.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationRequest & RegionInput, Integration, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationResponseError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a get integration response.
 */
export declare const getIntegrationResponse: API.OperationMethod<GetIntegrationResponseRequest & RegionInput, IntegrationResponse, GetIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type GetMethodError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe an existing Method resource.
 */
export declare const getMethod: API.OperationMethod<GetMethodRequest & RegionInput, Method, GetMethodError, Credentials | HttpClient.HttpClient>;
export type GetMethodResponseError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes a MethodResponse resource.
 */
export declare const getMethodResponse: API.OperationMethod<GetMethodResponseRequest & RegionInput, MethodResponse, GetMethodResponseError, Credentials | HttpClient.HttpClient>;
export type GetModelError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes an existing model defined for a RestApi resource.
 */
export declare const getModel: API.OperationMethod<GetModelRequest & RegionInput, Model, GetModelError, Credentials | HttpClient.HttpClient>;
export type GetModelsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describes existing Models defined for a RestApi resource.
 */
export declare const getModels: API.PaginatedOperationMethod<GetModelsRequest & RegionInput, Models, GetModelsError, Credentials | HttpClient.HttpClient, Model>;
export type GetModelTemplateError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Generates a sample mapping template that can be used to transform a payload into the structure of a model.
 */
export declare const getModelTemplate: API.OperationMethod<GetModelTemplateRequest & RegionInput, Template, GetModelTemplateError, Credentials | HttpClient.HttpClient>;
export type GetRequestValidatorError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a RequestValidator of a given RestApi.
 */
export declare const getRequestValidator: API.OperationMethod<GetRequestValidatorRequest & RegionInput, RequestValidator, GetRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type GetRequestValidatorsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the RequestValidators collection of a given RestApi.
 */
export declare const getRequestValidators: API.OperationMethod<GetRequestValidatorsRequest & RegionInput, RequestValidators, GetRequestValidatorsError, Credentials | HttpClient.HttpClient>;
export type GetResourceError = NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a resource.
 */
export declare const getResource: API.OperationMethod<GetResourceRequest & RegionInput, Resource, GetResourceError, Credentials | HttpClient.HttpClient>;
export type GetResourcesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists information about a collection of Resource resources.
 */
export declare const getResources: API.PaginatedOperationMethod<GetResourcesRequest & RegionInput, Resources, GetResourcesError, Credentials | HttpClient.HttpClient, Resource>;
export type GetRestApiError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the RestApi resource in the collection.
 */
export declare const getRestApi: API.OperationMethod<GetRestApiRequest & RegionInput, RestApi, GetRestApiError, Credentials | HttpClient.HttpClient>;
export type GetRestApisError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Lists the RestApis resources for your collection.
 */
export declare const getRestApis: API.PaginatedOperationMethod<GetRestApisRequest & RegionInput, RestApis, GetRestApisError, Credentials | HttpClient.HttpClient, RestApi>;
export type GetSdkError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Generates a client SDK for a RestApi and Stage.
 */
export declare const getSdk: API.OperationMethod<GetSdkRequest & RegionInput, SdkResponse, GetSdkError, Credentials | HttpClient.HttpClient>;
export type GetSdkTypeError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets an SDK type.
 */
export declare const getSdkType: API.OperationMethod<GetSdkTypeRequest & RegionInput, SdkType, GetSdkTypeError, Credentials | HttpClient.HttpClient>;
export type GetSdkTypesError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets SDK types
 */
export declare const getSdkTypes: API.OperationMethod<GetSdkTypesRequest & RegionInput, SdkTypes, GetSdkTypesError, Credentials | HttpClient.HttpClient>;
export type GetStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about a Stage resource.
 */
export declare const getStage: API.OperationMethod<GetStageRequest & RegionInput, Stage, GetStageError, Credentials | HttpClient.HttpClient>;
export type GetStagesError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets information about one or more Stage resources.
 */
export declare const getStages: API.OperationMethod<GetStagesRequest & RegionInput, Stages, GetStagesError, Credentials | HttpClient.HttpClient>;
export type GetTagsError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the Tags collection for a given resource.
 */
export declare const getTags: API.OperationMethod<GetTagsRequest & RegionInput, Tags, GetTagsError, Credentials | HttpClient.HttpClient>;
export type GetUsageError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the usage data of a usage plan in a specified time interval.
 */
export declare const getUsage: API.PaginatedOperationMethod<GetUsageRequest & RegionInput, Usage, GetUsageError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUsagePlanError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a usage plan of a given plan identifier.
 */
export declare const getUsagePlan: API.OperationMethod<GetUsagePlanRequest & RegionInput, UsagePlan, GetUsagePlanError, Credentials | HttpClient.HttpClient>;
export type GetUsagePlanKeyError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a usage plan key of a given key identifier.
 */
export declare const getUsagePlanKey: API.OperationMethod<GetUsagePlanKeyRequest & RegionInput, UsagePlanKey, GetUsagePlanKeyError, Credentials | HttpClient.HttpClient>;
export type GetUsagePlanKeysError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets all the usage plan keys representing the API keys added to a specified usage plan.
 */
export declare const getUsagePlanKeys: API.PaginatedOperationMethod<GetUsagePlanKeysRequest & RegionInput, UsagePlanKeys, GetUsagePlanKeysError, Credentials | HttpClient.HttpClient, UsagePlanKey>;
export type GetUsagePlansError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets all the usage plans of the caller's account.
 */
export declare const getUsagePlans: API.PaginatedOperationMethod<GetUsagePlansRequest & RegionInput, UsagePlans, GetUsagePlansError, Credentials | HttpClient.HttpClient, UsagePlan>;
export type GetVpcLinkError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets a specified VPC link under the caller's account in a region.
 */
export declare const getVpcLink: API.OperationMethod<GetVpcLinkRequest & RegionInput, VpcLink, GetVpcLinkError, Credentials | HttpClient.HttpClient>;
export type GetVpcLinksError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Gets the VpcLinks collection under the caller's account in a selected region.
 */
export declare const getVpcLinks: API.PaginatedOperationMethod<GetVpcLinksRequest & RegionInput, VpcLinks, GetVpcLinksError, Credentials | HttpClient.HttpClient, VpcLink>;
export type ImportApiKeysError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Import API keys from an external source, such as a CSV-formatted file.
 */
export declare const importApiKeys: API.OperationMethod<ImportApiKeysRequest & RegionInput, ApiKeyIds, ImportApiKeysError, Credentials | HttpClient.HttpClient>;
export type ImportDocumentationPartsError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Imports documentation parts
 */
export declare const importDocumentationParts: API.OperationMethod<ImportDocumentationPartsRequest & RegionInput, DocumentationPartIds, ImportDocumentationPartsError, Credentials | HttpClient.HttpClient>;
export type ImportRestApiError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A feature of the API Gateway control service for creating a new API from an external API definition file.
 */
export declare const importRestApi: API.OperationMethod<ImportRestApiRequest & RegionInput, RestApi, ImportRestApiError, Credentials | HttpClient.HttpClient>;
export type PutGatewayResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Creates a customization of a GatewayResponse of a specified response type and status code on the given RestApi.
 */
export declare const putGatewayResponse: API.OperationMethod<PutGatewayResponseRequest & RegionInput, GatewayResponse, PutGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type PutIntegrationError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Sets up a method's integration.
 */
export declare const putIntegration: API.OperationMethod<PutIntegrationRequest & RegionInput, Integration, PutIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutIntegrationResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents a put integration.
 */
export declare const putIntegrationResponse: API.OperationMethod<PutIntegrationResponseRequest & RegionInput, IntegrationResponse, PutIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type PutMethodError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Add a method to an existing Resource resource.
 */
export declare const putMethod: API.OperationMethod<PutMethodRequest & RegionInput, Method, PutMethodError, Credentials | HttpClient.HttpClient>;
export type PutMethodResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds a MethodResponse to an existing Method resource.
 */
export declare const putMethodResponse: API.OperationMethod<PutMethodResponseRequest & RegionInput, MethodResponse, PutMethodResponseError, Credentials | HttpClient.HttpClient>;
export type PutRestApiError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * A feature of the API Gateway control service for updating an existing API with an input of external API definitions.
 * The update can take the form of merging the supplied definition into the existing API or overwriting the existing API.
 */
export declare const putRestApi: API.OperationMethod<PutRestApiRequest & RegionInput, RestApi, PutRestApiError, Credentials | HttpClient.HttpClient>;
export type RejectDomainNameAccessAssociationError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Rejects a domain name access association with a private custom domain name.
 *
 * To reject a domain name access association with an access association source in another AWS account, use this operation. To remove a domain name access association with an access association source in your own account, use the DeleteDomainNameAccessAssociation operation.
 */
export declare const rejectDomainNameAccessAssociation: API.OperationMethod<RejectDomainNameAccessAssociationRequest & RegionInput, RejectDomainNameAccessAssociationResponse, RejectDomainNameAccessAssociationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Adds or updates a tag on a given resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestInvokeAuthorizerError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Simulate the execution of an Authorizer in your RestApi with headers, parameters, and an incoming request body.
 */
export declare const testInvokeAuthorizer: API.OperationMethod<TestInvokeAuthorizerRequest & RegionInput, TestInvokeAuthorizerResponse, TestInvokeAuthorizerError, Credentials | HttpClient.HttpClient>;
export type TestInvokeMethodError = BadRequestException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Simulate the invocation of a Method in your RestApi with headers, parameters, and an incoming request body.
 */
export declare const testInvokeMethod: API.OperationMethod<TestInvokeMethodRequest & RegionInput, TestInvokeMethodResponse, TestInvokeMethodError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Removes a tag from a given resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the current Account resource.
 */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest & RegionInput, Account, UpdateAccountError, Credentials | HttpClient.HttpClient>;
export type UpdateApiKeyError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about an ApiKey resource.
 */
export declare const updateApiKey: API.OperationMethod<UpdateApiKeyRequest & RegionInput, ApiKey, UpdateApiKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateAuthorizerError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing Authorizer resource.
 */
export declare const updateAuthorizer: API.OperationMethod<UpdateAuthorizerRequest & RegionInput, Authorizer, UpdateAuthorizerError, Credentials | HttpClient.HttpClient>;
export type UpdateBasePathMappingError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the BasePathMapping resource.
 */
export declare const updateBasePathMapping: API.OperationMethod<UpdateBasePathMappingRequest & RegionInput, BasePathMapping, UpdateBasePathMappingError, Credentials | HttpClient.HttpClient>;
export type UpdateClientCertificateError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about an ClientCertificate resource.
 */
export declare const updateClientCertificate: API.OperationMethod<UpdateClientCertificateRequest & RegionInput, ClientCertificate, UpdateClientCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateDeploymentError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a Deployment resource.
 */
export declare const updateDeployment: API.OperationMethod<UpdateDeploymentRequest & RegionInput, Deployment, UpdateDeploymentError, Credentials | HttpClient.HttpClient>;
export type UpdateDocumentationPartError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a documentation part.
 */
export declare const updateDocumentationPart: API.OperationMethod<UpdateDocumentationPartRequest & RegionInput, DocumentationPart, UpdateDocumentationPartError, Credentials | HttpClient.HttpClient>;
export type UpdateDocumentationVersionError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a documentation version.
 */
export declare const updateDocumentationVersion: API.OperationMethod<UpdateDocumentationVersionRequest & RegionInput, DocumentationVersion, UpdateDocumentationVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the DomainName resource.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest & RegionInput, DomainName, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a GatewayResponse of a specified response type on the given RestApi.
 */
export declare const updateGatewayResponse: API.OperationMethod<UpdateGatewayResponseRequest & RegionInput, GatewayResponse, UpdateGatewayResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents an update integration.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationRequest & RegionInput, Integration, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Represents an update integration response.
 */
export declare const updateIntegrationResponse: API.OperationMethod<UpdateIntegrationResponseRequest & RegionInput, IntegrationResponse, UpdateIntegrationResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateMethodError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing Method resource.
 */
export declare const updateMethod: API.OperationMethod<UpdateMethodRequest & RegionInput, Method, UpdateMethodError, Credentials | HttpClient.HttpClient>;
export type UpdateMethodResponseError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing MethodResponse resource.
 */
export declare const updateMethodResponse: API.OperationMethod<UpdateMethodResponseRequest & RegionInput, MethodResponse, UpdateMethodResponseError, Credentials | HttpClient.HttpClient>;
export type UpdateModelError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a model. The maximum size of the model is 400 KB.
 */
export declare const updateModel: API.OperationMethod<UpdateModelRequest & RegionInput, Model, UpdateModelError, Credentials | HttpClient.HttpClient>;
export type UpdateRequestValidatorError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a RequestValidator of a given RestApi.
 */
export declare const updateRequestValidator: API.OperationMethod<UpdateRequestValidatorRequest & RegionInput, RequestValidator, UpdateRequestValidatorError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceError = BadRequestException | ConflictException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a Resource resource.
 */
export declare const updateResource: API.OperationMethod<UpdateResourceRequest & RegionInput, Resource, UpdateResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateRestApiError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about the specified API.
 */
export declare const updateRestApi: API.OperationMethod<UpdateRestApiRequest & RegionInput, RestApi, UpdateRestApiError, Credentials | HttpClient.HttpClient>;
export type UpdateStageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Changes information about a Stage resource.
 */
export declare const updateStage: API.OperationMethod<UpdateStageRequest & RegionInput, Stage, UpdateStageError, Credentials | HttpClient.HttpClient>;
export type UpdateUsageError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Grants a temporary extension to the remaining quota of a usage plan associated with a specified API key.
 */
export declare const updateUsage: API.OperationMethod<UpdateUsageRequest & RegionInput, Usage, UpdateUsageError, Credentials | HttpClient.HttpClient>;
export type UpdateUsagePlanError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates a usage plan of a given plan Id.
 */
export declare const updateUsagePlan: API.OperationMethod<UpdateUsagePlanRequest & RegionInput, UsagePlan, UpdateUsagePlanError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcLinkError = BadRequestException | ConflictException | LimitExceededException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Updates an existing VpcLink of a specified identifier.
 */
export declare const updateVpcLink: API.OperationMethod<UpdateVpcLinkRequest & RegionInput, VpcLink, UpdateVpcLinkError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=api-gateway.d.ts.map