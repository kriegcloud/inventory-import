import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const DependentServiceFailureException_base: S.TaggedErrorClass<"DependentServiceFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DependentServiceFailureException extends /*@__PURE__*/ DependentServiceFailureException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TimeoutException_base: S.TaggedErrorClass<"TimeoutException", {
    readonly message: any;
}>;
export declare class TimeoutException extends /*@__PURE__*/ TimeoutException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type Name = string;
export type Description = string;
export type Repository = string;
export type Platform = "WEB" | "WEB_DYNAMIC" | "WEB_COMPUTE" | (string & {});
export type ComputeRoleArn = string;
export type ServiceRoleArn = string;
export type OauthToken = string | redacted.Redacted<string>;
export type AccessToken = string | redacted.Redacted<string>;
export type EnvKey = string;
export type EnvValue = string;
export type EnvironmentVariables = {
    [key: string]: string | undefined;
};
export type EnableBranchAutoBuild = boolean;
export type EnableBranchAutoDeletion = boolean;
export type EnableBasicAuth = boolean;
export type BasicAuthCredentials = string | redacted.Redacted<string>;
export type Source = string;
export type Target = string;
export type Status = string;
export type Condition = string;
export interface CustomRule {
    source: string;
    target: string;
    status?: string | undefined;
    condition?: string | undefined;
}
export type CustomRules = CustomRule[];
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type BuildSpec = string | redacted.Redacted<string>;
export type CustomHeaders = string;
export type EnableAutoBranchCreation = boolean;
export type AutoBranchCreationPattern = string;
export type AutoBranchCreationPatterns = string[];
export type Stage = "PRODUCTION" | "BETA" | "DEVELOPMENT" | "EXPERIMENTAL" | "PULL_REQUEST" | (string & {});
export type Framework = string;
export type EnableAutoBuild = boolean;
export type EnablePerformanceMode = boolean;
export type EnablePullRequestPreview = boolean;
export type PullRequestEnvironmentName = string;
export interface AutoBranchCreationConfig {
    stage?: Stage | undefined;
    framework?: string | undefined;
    enableAutoBuild?: boolean | undefined;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    enableBasicAuth?: boolean | undefined;
    enablePerformanceMode?: boolean | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    enablePullRequestPreview?: boolean | undefined;
    pullRequestEnvironmentName?: string | undefined;
}
export type BuildComputeType = "STANDARD_8GB" | "LARGE_16GB" | "XLARGE_72GB" | (string & {});
export interface JobConfig {
    buildComputeType: BuildComputeType;
}
export type CacheConfigType = "AMPLIFY_MANAGED" | "AMPLIFY_MANAGED_NO_COOKIES" | (string & {});
export interface CacheConfig {
    type: CacheConfigType;
}
export interface CreateAppRequest {
    name: string;
    description?: string | undefined;
    repository?: string | undefined;
    platform?: Platform | undefined;
    computeRoleArn?: string | undefined;
    iamServiceRoleArn?: string | undefined;
    oauthToken?: string | redacted.Redacted<string> | undefined;
    accessToken?: string | redacted.Redacted<string> | undefined;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    enableBranchAutoBuild?: boolean | undefined;
    enableBranchAutoDeletion?: boolean | undefined;
    enableBasicAuth?: boolean | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    customRules?: CustomRule[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    customHeaders?: string | undefined;
    enableAutoBranchCreation?: boolean | undefined;
    autoBranchCreationPatterns?: string[] | undefined;
    autoBranchCreationConfig?: AutoBranchCreationConfig | undefined;
    jobConfig?: JobConfig | undefined;
    cacheConfig?: CacheConfig | undefined;
}
export type AppId = string;
export type AppArn = string;
export type CreateTime = Date;
export type UpdateTime = Date;
export type DefaultDomain = string;
export type LastDeployTime = Date;
export type ThumbnailUrl = string;
export type BranchName = string;
export interface ProductionBranch {
    lastDeployTime?: Date | undefined;
    status?: string | undefined;
    thumbnailUrl?: string | undefined;
    branchName?: string | undefined;
}
export type RepositoryCloneMethod = "SSH" | "TOKEN" | "SIGV4" | (string & {});
export type WebhookCreateTime = Date;
export type WebAclArn = string;
export type WafStatus = "ASSOCIATING" | "ASSOCIATION_FAILED" | "ASSOCIATION_SUCCESS" | "DISASSOCIATING" | "DISASSOCIATION_FAILED" | (string & {});
export type StatusReason = string;
export interface WafConfiguration {
    webAclArn?: string | undefined;
    wafStatus?: WafStatus | undefined;
    statusReason?: string | undefined;
}
export interface App {
    appId: string;
    appArn: string;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    description?: string | undefined;
    repository?: string | undefined;
    platform?: Platform | undefined;
    createTime: Date;
    updateTime: Date;
    computeRoleArn?: string | undefined;
    iamServiceRoleArn?: string | undefined;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    defaultDomain?: string | undefined;
    enableBranchAutoBuild?: boolean | undefined;
    enableBranchAutoDeletion?: boolean | undefined;
    enableBasicAuth?: boolean | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    customRules?: CustomRule[] | undefined;
    productionBranch?: ProductionBranch | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    customHeaders?: string | undefined;
    enableAutoBranchCreation?: boolean | undefined;
    autoBranchCreationPatterns?: string[] | undefined;
    autoBranchCreationConfig?: AutoBranchCreationConfig | undefined;
    repositoryCloneMethod?: RepositoryCloneMethod | undefined;
    cacheConfig?: CacheConfig | undefined;
    webhookCreateTime?: Date | undefined;
    wafConfiguration?: WafConfiguration | undefined;
    jobConfig?: JobConfig | undefined;
}
export interface CreateAppResult {
    app: App;
}
export type EnvironmentName = string;
export type StackName = string;
export type DeploymentArtifacts = string;
export interface CreateBackendEnvironmentRequest {
    appId: string;
    environmentName: string;
    stackName?: string | undefined;
    deploymentArtifacts?: string | undefined;
}
export type BackendEnvironmentArn = string;
export interface BackendEnvironment {
    backendEnvironmentArn: string;
    environmentName: string;
    stackName?: string | undefined;
    deploymentArtifacts?: string | undefined;
    createTime: Date;
    updateTime: Date;
}
export interface CreateBackendEnvironmentResult {
    backendEnvironment: BackendEnvironment;
}
export type EnableNotification = boolean;
export type EnableSkewProtection = boolean;
export type TTL = string;
export type DisplayName = string;
export type StackArn = string;
export interface Backend {
    stackArn?: string | undefined;
}
export interface CreateBranchRequest {
    appId: string;
    branchName: string;
    description?: string | undefined;
    stage?: Stage | undefined;
    framework?: string | undefined;
    enableNotification?: boolean | undefined;
    enableAutoBuild?: boolean | undefined;
    enableSkewProtection?: boolean | undefined;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    enableBasicAuth?: boolean | undefined;
    enablePerformanceMode?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    ttl?: string | undefined;
    displayName?: string | undefined;
    enablePullRequestPreview?: boolean | undefined;
    pullRequestEnvironmentName?: string | undefined;
    backendEnvironmentArn?: string | undefined;
    backend?: Backend | undefined;
    computeRoleArn?: string | undefined;
}
export type BranchArn = string;
export type CustomDomain = string;
export type CustomDomains = string[];
export type ActiveJobId = string;
export type TotalNumberOfJobs = string;
export type AssociatedResource = string;
export type AssociatedResources = string[];
export interface Branch {
    branchArn: string;
    branchName: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    stage?: Stage | undefined;
    displayName?: string | undefined;
    enableNotification?: boolean | undefined;
    createTime: Date;
    updateTime: Date;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    enableAutoBuild?: boolean | undefined;
    enableSkewProtection?: boolean | undefined;
    customDomains?: string[] | undefined;
    framework?: string | undefined;
    activeJobId?: string | undefined;
    totalNumberOfJobs?: string | undefined;
    enableBasicAuth?: boolean | undefined;
    enablePerformanceMode?: boolean | undefined;
    thumbnailUrl?: string | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    ttl?: string | undefined;
    associatedResources?: string[] | undefined;
    enablePullRequestPreview?: boolean | undefined;
    pullRequestEnvironmentName?: string | undefined;
    destinationBranch?: string | undefined;
    sourceBranch?: string | undefined;
    backendEnvironmentArn?: string | undefined;
    backend?: Backend | undefined;
    computeRoleArn?: string | undefined;
}
export interface CreateBranchResult {
    branch: Branch;
}
export type FileName = string;
export type MD5Hash = string;
export type FileMap = {
    [key: string]: string | undefined;
};
export interface CreateDeploymentRequest {
    appId: string;
    branchName: string;
    fileMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type JobId = string;
export type UploadUrl = string;
export type FileUploadUrls = {
    [key: string]: string | undefined;
};
export interface CreateDeploymentResult {
    jobId?: string | undefined;
    fileUploadUrls?: {
        [key: string]: string | undefined;
    } | undefined;
    zipUploadUrl: string;
}
export type DomainName = string;
export type EnableAutoSubDomain = boolean;
export type DomainPrefix = string;
export interface SubDomainSetting {
    prefix: string;
    branchName: string;
}
export type SubDomainSettings = SubDomainSetting[];
export type AutoSubDomainCreationPattern = string;
export type AutoSubDomainCreationPatterns = string[];
export type AutoSubDomainIAMRole = string;
export type CertificateType = "AMPLIFY_MANAGED" | "CUSTOM" | (string & {});
export type CertificateArn = string;
export interface CertificateSettings {
    type: CertificateType;
    customCertificateArn?: string | undefined;
}
export interface CreateDomainAssociationRequest {
    appId: string;
    domainName: string;
    enableAutoSubDomain?: boolean | undefined;
    subDomainSettings: SubDomainSetting[];
    autoSubDomainCreationPatterns?: string[] | undefined;
    autoSubDomainIAMRole?: string | undefined;
    certificateSettings?: CertificateSettings | undefined;
}
export type DomainAssociationArn = string;
export type DomainStatus = "PENDING_VERIFICATION" | "IN_PROGRESS" | "AVAILABLE" | "IMPORTING_CUSTOM_CERTIFICATE" | "PENDING_DEPLOYMENT" | "AWAITING_APP_CNAME" | "FAILED" | "CREATING" | "REQUESTING_CERTIFICATE" | "UPDATING" | (string & {});
export type UpdateStatus = "REQUESTING_CERTIFICATE" | "PENDING_VERIFICATION" | "IMPORTING_CUSTOM_CERTIFICATE" | "PENDING_DEPLOYMENT" | "AWAITING_APP_CNAME" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | (string & {});
export type CertificateVerificationDNSRecord = string;
export type Verified = boolean;
export type DNSRecord = string;
export interface SubDomain {
    subDomainSetting: SubDomainSetting;
    verified: boolean;
    dnsRecord: string;
}
export type SubDomains = SubDomain[];
export interface Certificate {
    type: CertificateType;
    customCertificateArn?: string | undefined;
    certificateVerificationDNSRecord?: string | undefined;
}
export interface DomainAssociation {
    domainAssociationArn: string;
    domainName: string;
    enableAutoSubDomain: boolean;
    autoSubDomainCreationPatterns?: string[] | undefined;
    autoSubDomainIAMRole?: string | undefined;
    domainStatus: DomainStatus;
    updateStatus?: UpdateStatus | undefined;
    statusReason: string;
    certificateVerificationDNSRecord?: string | undefined;
    subDomains: SubDomain[];
    certificate?: Certificate | undefined;
}
export interface CreateDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export interface CreateWebhookRequest {
    appId: string;
    branchName: string;
    description?: string | undefined;
}
export type WebhookArn = string;
export type WebhookId = string;
export type WebhookUrl = string;
export interface Webhook {
    webhookArn: string;
    webhookId: string;
    webhookUrl: string;
    appId?: string | undefined;
    branchName: string;
    description: string;
    createTime: Date;
    updateTime: Date;
}
export interface CreateWebhookResult {
    webhook: Webhook;
}
export interface DeleteAppRequest {
    appId: string;
}
export interface DeleteAppResult {
    app: App;
}
export interface DeleteBackendEnvironmentRequest {
    appId: string;
    environmentName: string;
}
export interface DeleteBackendEnvironmentResult {
    backendEnvironment: BackendEnvironment;
}
export interface DeleteBranchRequest {
    appId: string;
    branchName: string;
}
export interface DeleteBranchResult {
    branch: Branch;
}
export interface DeleteDomainAssociationRequest {
    appId: string;
    domainName: string;
}
export interface DeleteDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export interface DeleteJobRequest {
    appId: string;
    branchName: string;
    jobId: string;
}
export type JobArn = string;
export type CommitId = string;
export type CommitMessage = string;
export type CommitTime = Date;
export type StartTime = Date;
export type JobStatus = "CREATED" | "PENDING" | "PROVISIONING" | "RUNNING" | "FAILED" | "SUCCEED" | "CANCELLING" | "CANCELLED" | (string & {});
export type EndTime = Date;
export type JobType = "RELEASE" | "RETRY" | "MANUAL" | "WEB_HOOK" | (string & {});
export type SourceUrl = string;
export type SourceUrlType = "ZIP" | "BUCKET_PREFIX" | (string & {});
export interface JobSummary {
    jobArn: string;
    jobId: string;
    commitId?: string | undefined;
    commitMessage?: string | undefined;
    commitTime?: Date | undefined;
    startTime: Date;
    status: JobStatus;
    endTime?: Date | undefined;
    jobType?: JobType | undefined;
    sourceUrl?: string | undefined;
    sourceUrlType?: SourceUrlType | undefined;
}
export interface DeleteJobResult {
    jobSummary: JobSummary;
}
export interface DeleteWebhookRequest {
    webhookId: string;
}
export interface DeleteWebhookResult {
    webhook: Webhook;
}
export interface GenerateAccessLogsRequest {
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    domainName: string;
    appId: string;
}
export type LogUrl = string;
export interface GenerateAccessLogsResult {
    logUrl?: string | undefined;
}
export interface GetAppRequest {
    appId: string;
}
export interface GetAppResult {
    app: App;
}
export type ArtifactId = string;
export interface GetArtifactUrlRequest {
    artifactId: string;
}
export type ArtifactUrl = string;
export interface GetArtifactUrlResult {
    artifactId: string;
    artifactUrl: string;
}
export interface GetBackendEnvironmentRequest {
    appId: string;
    environmentName: string;
}
export interface GetBackendEnvironmentResult {
    backendEnvironment: BackendEnvironment;
}
export interface GetBranchRequest {
    appId: string;
    branchName: string;
}
export interface GetBranchResult {
    branch: Branch;
}
export interface GetDomainAssociationRequest {
    appId: string;
    domainName: string;
}
export interface GetDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export interface GetJobRequest {
    appId: string;
    branchName: string;
    jobId: string;
}
export type StepName = string;
export type ArtifactsUrl = string;
export type TestArtifactsUrl = string;
export type TestConfigUrl = string;
export type ThumbnailName = string;
export type Screenshots = {
    [key: string]: string | undefined;
};
export type Context = string;
export interface Step {
    stepName: string;
    startTime: Date;
    status: JobStatus;
    endTime?: Date | undefined;
    logUrl?: string | undefined;
    artifactsUrl?: string | undefined;
    testArtifactsUrl?: string | undefined;
    testConfigUrl?: string | undefined;
    screenshots?: {
        [key: string]: string | undefined;
    } | undefined;
    statusReason?: string | undefined;
    context?: string | undefined;
}
export type Steps = Step[];
export interface Job {
    summary: JobSummary;
    steps: Step[];
}
export interface GetJobResult {
    job: Job;
}
export interface GetWebhookRequest {
    webhookId: string;
}
export interface GetWebhookResult {
    webhook: Webhook;
}
export type NextToken = string;
export type MaxResultsForListApps = number;
export interface ListAppsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Apps = App[];
export interface ListAppsResult {
    apps: App[];
    nextToken?: string | undefined;
}
export type MaxResults = number;
export interface ListArtifactsRequest {
    appId: string;
    branchName: string;
    jobId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ArtifactFileName = string;
export interface Artifact {
    artifactFileName: string;
    artifactId: string;
}
export type Artifacts = Artifact[];
export interface ListArtifactsResult {
    artifacts: Artifact[];
    nextToken?: string | undefined;
}
export interface ListBackendEnvironmentsRequest {
    appId: string;
    environmentName?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type BackendEnvironments = BackendEnvironment[];
export interface ListBackendEnvironmentsResult {
    backendEnvironments: BackendEnvironment[];
    nextToken?: string | undefined;
}
export interface ListBranchesRequest {
    appId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Branches = Branch[];
export interface ListBranchesResult {
    branches: Branch[];
    nextToken?: string | undefined;
}
export interface ListDomainAssociationsRequest {
    appId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type DomainAssociations = DomainAssociation[];
export interface ListDomainAssociationsResult {
    domainAssociations: DomainAssociation[];
    nextToken?: string | undefined;
}
export interface ListJobsRequest {
    appId: string;
    branchName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type JobSummaries = JobSummary[];
export interface ListJobsResult {
    jobSummaries: JobSummary[];
    nextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListWebhooksRequest {
    appId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Webhooks = Webhook[];
export interface ListWebhooksResult {
    webhooks: Webhook[];
    nextToken?: string | undefined;
}
export interface StartDeploymentRequest {
    appId: string;
    branchName: string;
    jobId?: string | undefined;
    sourceUrl?: string | undefined;
    sourceUrlType?: SourceUrlType | undefined;
}
export interface StartDeploymentResult {
    jobSummary: JobSummary;
}
export type JobReason = string;
export interface StartJobRequest {
    appId: string;
    branchName: string;
    jobId?: string | undefined;
    jobType: JobType;
    jobReason?: string | undefined;
    commitId?: string | undefined;
    commitMessage?: string | undefined;
    commitTime?: Date | undefined;
}
export interface StartJobResult {
    jobSummary: JobSummary;
}
export interface StopJobRequest {
    appId: string;
    branchName: string;
    jobId: string;
}
export interface StopJobResult {
    jobSummary: JobSummary;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAppRequest {
    appId: string;
    name?: string | undefined;
    description?: string | undefined;
    platform?: Platform | undefined;
    computeRoleArn?: string | undefined;
    iamServiceRoleArn?: string | undefined;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    enableBranchAutoBuild?: boolean | undefined;
    enableBranchAutoDeletion?: boolean | undefined;
    enableBasicAuth?: boolean | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    customRules?: CustomRule[] | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    customHeaders?: string | undefined;
    enableAutoBranchCreation?: boolean | undefined;
    autoBranchCreationPatterns?: string[] | undefined;
    autoBranchCreationConfig?: AutoBranchCreationConfig | undefined;
    repository?: string | undefined;
    oauthToken?: string | redacted.Redacted<string> | undefined;
    accessToken?: string | redacted.Redacted<string> | undefined;
    jobConfig?: JobConfig | undefined;
    cacheConfig?: CacheConfig | undefined;
}
export interface UpdateAppResult {
    app: App;
}
export interface UpdateBranchRequest {
    appId: string;
    branchName: string;
    description?: string | undefined;
    framework?: string | undefined;
    stage?: Stage | undefined;
    enableNotification?: boolean | undefined;
    enableAutoBuild?: boolean | undefined;
    enableSkewProtection?: boolean | undefined;
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    basicAuthCredentials?: string | redacted.Redacted<string> | undefined;
    enableBasicAuth?: boolean | undefined;
    enablePerformanceMode?: boolean | undefined;
    buildSpec?: string | redacted.Redacted<string> | undefined;
    ttl?: string | undefined;
    displayName?: string | undefined;
    enablePullRequestPreview?: boolean | undefined;
    pullRequestEnvironmentName?: string | undefined;
    backendEnvironmentArn?: string | undefined;
    backend?: Backend | undefined;
    computeRoleArn?: string | undefined;
}
export interface UpdateBranchResult {
    branch: Branch;
}
export interface UpdateDomainAssociationRequest {
    appId: string;
    domainName: string;
    enableAutoSubDomain?: boolean | undefined;
    subDomainSettings?: SubDomainSetting[] | undefined;
    autoSubDomainCreationPatterns?: string[] | undefined;
    autoSubDomainIAMRole?: string | undefined;
    certificateSettings?: CertificateSettings | undefined;
}
export interface UpdateDomainAssociationResult {
    domainAssociation: DomainAssociation;
}
export interface UpdateWebhookRequest {
    webhookId: string;
    branchName?: string | undefined;
    description?: string | undefined;
}
export interface UpdateWebhookResult {
    webhook: Webhook;
}
export type ErrorMessage = string;
export type Code = string;
export type CreateAppError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new Amplify app.
 */
export declare const createApp: API.OperationMethod<CreateAppRequest & RegionInput, CreateAppResult, CreateAppError, Credentials | HttpClient.HttpClient>;
export type CreateBackendEnvironmentError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new backend environment for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn't available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const createBackendEnvironment: API.OperationMethod<CreateBackendEnvironmentRequest & RegionInput, CreateBackendEnvironmentResult, CreateBackendEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateBranchError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new branch for an Amplify app.
 */
export declare const createBranch: API.OperationMethod<CreateBranchRequest & RegionInput, CreateBranchResult, CreateBranchError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a deployment for a manually deployed Amplify app. Manually deployed apps are
 * not connected to a Git repository.
 *
 * The maximum duration between the `CreateDeployment` call and the
 * `StartDeployment` call cannot exceed 8 hours. If the duration exceeds 8
 * hours, the `StartDeployment` call and the associated `Job` will
 * fail.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest & RegionInput, CreateDeploymentResult, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDomainAssociationError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new domain association for an Amplify app. This action associates a custom
 * domain with the Amplify app
 */
export declare const createDomainAssociation: API.OperationMethod<CreateDomainAssociationRequest & RegionInput, CreateDomainAssociationResult, CreateDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateWebhookError = BadRequestException | DependentServiceFailureException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new webhook on an Amplify app.
 */
export declare const createWebhook: API.OperationMethod<CreateWebhookRequest & RegionInput, CreateWebhookResult, CreateWebhookError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes an existing Amplify app specified by an app ID.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest & RegionInput, DeleteAppResult, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteBackendEnvironmentError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a backend environment for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn't available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const deleteBackendEnvironment: API.OperationMethod<DeleteBackendEnvironmentRequest & RegionInput, DeleteBackendEnvironmentResult, DeleteBackendEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteBranchError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a branch for an Amplify app.
 */
export declare const deleteBranch: API.OperationMethod<DeleteBranchRequest & RegionInput, DeleteBranchResult, DeleteBranchError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainAssociationError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a domain association for an Amplify app.
 */
export declare const deleteDomainAssociation: API.OperationMethod<DeleteDomainAssociationRequest & RegionInput, DeleteDomainAssociationResult, DeleteDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a job for a branch of an Amplify app.
 */
export declare const deleteJob: API.OperationMethod<DeleteJobRequest & RegionInput, DeleteJobResult, DeleteJobError, Credentials | HttpClient.HttpClient>;
export type DeleteWebhookError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Deletes a webhook.
 */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest & RegionInput, DeleteWebhookResult, DeleteWebhookError, Credentials | HttpClient.HttpClient>;
export type GenerateAccessLogsError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the website access logs for a specific time range using a presigned URL.
 */
export declare const generateAccessLogs: API.OperationMethod<GenerateAccessLogsRequest & RegionInput, GenerateAccessLogsResult, GenerateAccessLogsError, Credentials | HttpClient.HttpClient>;
export type GetAppError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns an existing Amplify app specified by an app ID.
 */
export declare const getApp: API.OperationMethod<GetAppRequest & RegionInput, GetAppResult, GetAppError, Credentials | HttpClient.HttpClient>;
export type GetArtifactUrlError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the artifact info that corresponds to an artifact id.
 */
export declare const getArtifactUrl: API.OperationMethod<GetArtifactUrlRequest & RegionInput, GetArtifactUrlResult, GetArtifactUrlError, Credentials | HttpClient.HttpClient>;
export type GetBackendEnvironmentError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a backend environment for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn't available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const getBackendEnvironment: API.OperationMethod<GetBackendEnvironmentRequest & RegionInput, GetBackendEnvironmentResult, GetBackendEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetBranchError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a branch for an Amplify app.
 */
export declare const getBranch: API.OperationMethod<GetBranchRequest & RegionInput, GetBranchResult, GetBranchError, Credentials | HttpClient.HttpClient>;
export type GetDomainAssociationError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the domain information for an Amplify app.
 */
export declare const getDomainAssociation: API.OperationMethod<GetDomainAssociationRequest & RegionInput, GetDomainAssociationResult, GetDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type GetJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a job for a branch of an Amplify app.
 */
export declare const getJob: API.OperationMethod<GetJobRequest & RegionInput, GetJobResult, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetWebhookError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the webhook information that corresponds to a specified webhook ID.
 */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest & RegionInput, GetWebhookResult, GetWebhookError, Credentials | HttpClient.HttpClient>;
export type ListAppsError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a list of the existing Amplify apps.
 */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest & RegionInput, ListAppsResult, ListAppsError, Credentials | HttpClient.HttpClient, App>;
export type ListArtifactsError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a list of end-to-end testing artifacts for a specified app, branch, and
 * job.
 *
 * To return the build artifacts, use the GetJob API.
 *
 * For more information about Amplify testing support, see Setting up
 * end-to-end Cypress tests for your Amplify application in the
 *
 * Amplify Hosting User Guide.
 */
export declare const listArtifacts: API.OperationMethod<ListArtifactsRequest & RegionInput, ListArtifactsResult, ListArtifactsError, Credentials | HttpClient.HttpClient>;
export type ListBackendEnvironmentsError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Lists the backend environments for an Amplify app.
 *
 * This API is available only to Amplify Gen 1 applications where the
 * backend is created using Amplify Studio or the Amplify
 * command line interface (CLI). This API isn't available to Amplify Gen 2
 * applications. When you deploy an application with Amplify Gen 2, you provision the app's
 * backend infrastructure using Typescript code.
 */
export declare const listBackendEnvironments: API.OperationMethod<ListBackendEnvironmentsRequest & RegionInput, ListBackendEnvironmentsResult, ListBackendEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type ListBranchesError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Lists the branches of an Amplify app.
 */
export declare const listBranches: API.PaginatedOperationMethod<ListBranchesRequest & RegionInput, ListBranchesResult, ListBranchesError, Credentials | HttpClient.HttpClient, Branch>;
export type ListDomainAssociationsError = BadRequestException | InternalFailureException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns the domain associations for an Amplify app.
 */
export declare const listDomainAssociations: API.PaginatedOperationMethod<ListDomainAssociationsRequest & RegionInput, ListDomainAssociationsResult, ListDomainAssociationsError, Credentials | HttpClient.HttpClient, DomainAssociation>;
export type ListJobsError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Lists the jobs for a branch of an Amplify app.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResult, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListTagsForResourceError = BadRequestException | InternalFailureException | ResourceNotFoundException | TimeoutException | CommonErrors;
/**
 * Returns a list of tags for a specified Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWebhooksError = BadRequestException | InternalFailureException | LimitExceededException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Returns a list of webhooks for an Amplify app.
 */
export declare const listWebhooks: API.OperationMethod<ListWebhooksRequest & RegionInput, ListWebhooksResult, ListWebhooksError, Credentials | HttpClient.HttpClient>;
export type StartDeploymentError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Starts a deployment for a manually deployed app. Manually deployed apps are not
 * connected to a Git repository.
 *
 * The maximum duration between the `CreateDeployment` call and the
 * `StartDeployment` call cannot exceed 8 hours. If the duration exceeds 8
 * hours, the `StartDeployment` call and the associated `Job` will
 * fail.
 */
export declare const startDeployment: API.OperationMethod<StartDeploymentRequest & RegionInput, StartDeploymentResult, StartDeploymentError, Credentials | HttpClient.HttpClient>;
export type StartJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Starts a new job for a branch of an Amplify app.
 */
export declare const startJob: API.OperationMethod<StartJobRequest & RegionInput, StartJobResult, StartJobError, Credentials | HttpClient.HttpClient>;
export type StopJobError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Stops a job that is in progress for a branch of an Amplify app.
 */
export declare const stopJob: API.OperationMethod<StopJobRequest & RegionInput, StopJobResult, StopJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalFailureException | ResourceNotFoundException | TimeoutException | CommonErrors;
/**
 * Tags the resource with a tag key and value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | InternalFailureException | ResourceNotFoundException | TimeoutException | CommonErrors;
/**
 * Untags a resource with a specified Amazon Resource Name (ARN).
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Updates an existing Amplify app.
 */
export declare const updateApp: API.OperationMethod<UpdateAppRequest & RegionInput, UpdateAppResult, UpdateAppError, Credentials | HttpClient.HttpClient>;
export type UpdateBranchError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Updates a branch for an Amplify app.
 */
export declare const updateBranch: API.OperationMethod<UpdateBranchRequest & RegionInput, UpdateBranchResult, UpdateBranchError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainAssociationError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Creates a new domain association for an Amplify app.
 */
export declare const updateDomainAssociation: API.OperationMethod<UpdateDomainAssociationRequest & RegionInput, UpdateDomainAssociationResult, UpdateDomainAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateWebhookError = BadRequestException | DependentServiceFailureException | InternalFailureException | NotFoundException | UnauthorizedException | TimeoutException | CommonErrors;
/**
 * Updates a webhook.
 */
export declare const updateWebhook: API.OperationMethod<UpdateWebhookRequest & RegionInput, UpdateWebhookResult, UpdateWebhookError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amplify.d.ts.map