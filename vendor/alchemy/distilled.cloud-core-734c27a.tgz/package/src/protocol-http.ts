import * as Effect from "effect/Effect";
import * as Headers from "effect/http/Headers";
import * as HttpBody from "effect/http/HttpBody";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
/**
 * Generic REST protocol machinery, shared by SDK protocol layers.
 *
 * Everything here is driven purely by the trait annotations in
 * `core/trait.ts` -- nothing is provider-specific. An SDK protocol (e.g.
 * cloudflare's) supplies credentials/base-URL, calls {@link buildRequest} to
 * encode, and layers its own response-envelope handling on top of the
 * decode-side helpers ({@link getProps}/{@link mapKeys}/
 * {@link matchTypedError}).
 */
import type * as AST from "effect/SchemaAST";
import { getAnn, getProps, resolveNode } from "./annotations.ts";
import * as Category from "./category.ts";
import { isOpaqueValue } from "./plain-values.ts";
import { parseServerRetryHint } from "./retry-after.ts";
import * as Schema from "./schema-lite-typed.ts";
import { SdkError } from "./sdk-error.ts";
import { restoreStack, suppressStack } from "./telemetry.ts";
import {
  bodySymbol,
  commaDelimitedSymbol,
  deepQuerySymbol,
  formDataFileSymbol,
  getErrorMatchers,
  headerSymbol,
  httpBodySymbol,
  httpSymbol,
  keyDictionarySymbol,
  labelSymbol,
  labelEncodingSymbol,
  querySymbol,
  stringEncodedSymbol,
  unionCasesSymbol,
  type ErrorMatcher,
  type ErrorTextMatcher,
  type HttpTrait,
  type KeyDictionaryEntries,
  type UnionDiscriminator,
} from "./trait.ts";

//#region AST helpers (survive S.optional / Suspend / transforms)

export { getAnn, getProps, resolveNode } from "./annotations.ts";

export const getPropAnn = (prop: AST.PropertySignature, symbol: symbol): unknown =>
  getAnn(prop.type, symbol);
export const hasPropAnn = (prop: AST.PropertySignature, symbol: symbol): boolean =>
  getPropAnn(prop, symbol) !== undefined;
export const nameOf = (prop: AST.PropertySignature, symbol: symbol): string => {
  const v = getPropAnn(prop, symbol);
  return typeof v === "string" ? v : String(prop.name);
};

//#endregion

//#region Response headers on outputs

/** An output member read from a response header (`T.Header`). */
export interface ResponseHeaderMember {
  readonly key: string;
  /** Lowercase header name. */
  readonly wire: string;
  /** The member is a number; the header's text is parsed. */
  readonly number: boolean;
}

const noHeaderMembers: ReadonlyArray<ResponseHeaderMember> = [];
const headerMemberCache = /*@__PURE__*/ new WeakMap<AST.AST, ReadonlyArray<ResponseHeaderMember>>();

/** The output's header-bound members, read from the schema once. */
export const responseHeaderMembers = (outputAst: AST.AST): ReadonlyArray<ResponseHeaderMember> => {
  let members = headerMemberCache.get(outputAst);
  if (members !== undefined) return members;
  const found: ResponseHeaderMember[] = [];
  for (const prop of getProps(outputAst)) {
    if (!hasPropAnn(prop, headerSymbol)) continue;
    found.push({
      key: String(prop.name),
      wire: nameOf(prop, headerSymbol).toLowerCase(),
      number: resolveNode(prop.type)._tag === "Number",
    });
  }
  members = found.length === 0 ? noHeaderMembers : found;
  headerMemberCache.set(outputAst, members);
  return members;
};

/**
 * Copy the response headers an output declares onto its decoded body. A
 * number member gets the header parsed; text that is not a number is kept
 * as sent, so strict validation reports it. A body that is not an object
 * (a raw root) is returned as is -- generators bind no headers there.
 */
export const withResponseHeaders = (
  members: ReadonlyArray<ResponseHeaderMember>,
  body: unknown,
  headers: Record<string, string | undefined>,
): unknown => {
  if (members.length === 0 || body === null || typeof body !== "object" || Array.isArray(body)) {
    return body;
  }
  let result: Record<string, unknown> | undefined;
  for (const m of members) {
    const raw = headers[m.wire];
    if (raw === undefined) continue;
    result ??= { ...(body as Record<string, unknown>) };
    const parsed = m.number && raw.trim() !== "" ? Number(raw) : Number.NaN;
    result[m.key] = Number.isNaN(parsed) ? raw : parsed;
  }
  return result ?? body;
};
//#endregion

//#region Recursive wire-name mapping

export { isOpaqueValue };

/** TS name -> wire name (encode) or every wire spelling -> TS name (decode). */
const renameTable = (
  dict: KeyDictionaryEntries,
  direction: "encode" | "decode",
): Record<string, string> =>
  direction === "decode"
    ? Object.fromEntries(
        Object.entries(dict).flatMap(([ts, wire]) =>
          typeof wire === "string" ? [[wire, ts] as const] : wire.map((w) => [w, ts] as const),
        ),
      )
    : Object.fromEntries(
        Object.entries(dict).map(([ts, wire]) => [ts, typeof wire === "string" ? wire : wire[0]!]),
      );

/**
 * Deep-rename keys via a plain dictionary (see `T.KeyDictionary`). An entry
 * may list several wire spellings; encode uses the first (canonical) one and
 * decode maps every listed spelling back to the TS name.
 */
export const mapKeysByDictionary = (
  dict: KeyDictionaryEntries,
  value: unknown,
  direction: "encode" | "decode",
): unknown => {
  if (value === null || typeof value !== "object" || isOpaqueValue(value)) {
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((v) => mapKeysByDictionary(dict, v, direction));
  }
  const rename = renameTable(dict, direction);
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if (v === undefined) continue;
    out[rename[k] ?? k] = mapKeysByDictionary(dict, v, direction);
  }
  return out;
};

/**
 * Recursively rename keys between TS names and wire names, per the schema.
 *
 * `fallback` is the nearest ancestor `T.KeyDictionary` -- schema-known members
 * always map via their own annotations, but opaque values (Document members,
 * keys the schema doesn't know) deep-rename via the dictionary so nested
 * TS-cased content still reaches the wire in wire case. Content with no
 * dictionary in scope passes through verbatim.
 */
/**
 * Value form for a `StringEncoded()` member: the string spelling of the
 * value, element-wise for lists. `null` stays `null` -- an API that models a
 * flag as `"true" | "false"` still means "unset" by null, not `"null"`.
 */
const stringEncode = (value: unknown): unknown =>
  value === null ? null : Array.isArray(value) ? value.map(stringEncode) : String(value);

/**
 * Whether {@link mapKeys} returns every value of `root` unchanged (as a deep
 * copy) in `direction` with no fallback dictionary: no member is renamed,
 * string-encoded (encode) or picked by `T.UnionCases` (decode, or encode for
 * a union whose cases carry member dictionaries), and no
 * `T.KeyDictionary` is in scope anywhere below `root`. Protocols use it to
 * skip the walk. Computed once per schema node and direction.
 */
export const mapsVerbatim = (root: AST.AST, direction: "encode" | "decode"): boolean => {
  const cache = direction === "encode" ? verbatimEncode : verbatimDecode;
  let result = cache.get(root);
  if (result !== undefined) return result;
  result = true;
  const seen = new Set<AST.AST>();
  const stack: AST.AST[] = [root];
  walk: while (stack.length > 0) {
    const ast = stack.pop()!;
    if (seen.has(ast)) continue;
    seen.add(ast);
    if (getAnn(ast, keyDictionarySymbol) !== undefined) {
      result = false;
      break;
    }
    const unionCases = getAnn(ast, unionCasesSymbol) as UnionCasesValue | undefined;
    if (
      unionCases !== undefined &&
      (direction === "decode" || unionCases.dictionaries !== undefined)
    ) {
      result = false;
      break;
    }
    const node = resolveNode(ast);
    if (node._tag === "Union") {
      for (const t of (node as AST.Union).types) stack.push(resolveNode(t));
    } else if (node._tag === "Arrays") {
      const elem = (node as any).rest?.[0] as AST.AST | undefined;
      if (elem) stack.push(elem);
    } else if (node._tag === "Objects") {
      for (const p of (node as any).propertySignatures as readonly AST.PropertySignature[]) {
        if (
          nameOf(p, bodySymbol) !== String(p.name) ||
          (direction === "encode" && hasPropAnn(p, stringEncodedSymbol))
        ) {
          result = false;
          break walk;
        }
        stack.push(p.type);
      }
      for (const s of ((node as any).indexSignatures ?? []) as readonly { type: AST.AST }[]) {
        stack.push(s.type);
      }
    }
  }
  cache.set(root, result);
  return result;
};

/** The value `T.UnionCases` annotates. */
interface UnionCasesValue {
  readonly cases: ReadonlyArray<ReadonlyArray<string>>;
  readonly discriminator?: UnionDiscriminator;
  readonly dictionaries?: ReadonlyArray<Readonly<Record<string, KeyDictionaryEntries>>>;
}
const verbatimEncode = /*@__PURE__*/ new WeakMap<AST.AST, boolean>();
const verbatimDecode = /*@__PURE__*/ new WeakMap<AST.AST, boolean>();

export const mapKeys = (
  ast: AST.AST,
  value: unknown,
  direction: "encode" | "decode",
  fallback?: KeyDictionaryEntries,
): unknown => {
  if (value === null || value === undefined || typeof value !== "object" || isOpaqueValue(value)) {
    return value;
  }
  const dict = (getAnn(ast, keyDictionarySymbol) as KeyDictionaryEntries | undefined) ?? fallback;

  // Discriminated union whose cases the API returns merged (every case's
  // keys present, `null` for the inactive ones). Map wire names, then keep
  // only the active case's keys. The case is read off the union's
  // discriminator when it has one -- cases that share a key set (every
  // resource kind of `resource_tagging`, every page-rule action) are
  // indistinguishable by keys alone. Without one, a case does NOT need every
  // key present -- arms carry optional members the wire may omit -- so the
  // active case is the one that best EXPLAINS the value: most present,
  // non-null keys covered, minus present keys the case cannot explain (ties
  // break by coverage, then declaration order).
  //
  // A case member with its own dictionary (`{}` for caller content such as
  // a Worker binding's `json`) maps its value by that one. Encode takes this
  // path only for a union that has such members: it picks the case the same
  // way, then renames the top-level keys.
  const unionCases = getAnn(ast, unionCasesSymbol) as UnionCasesValue | undefined;
  if (
    unionCases &&
    (direction === "decode" || unionCases.dictionaries !== undefined) &&
    !Array.isArray(value)
  ) {
    // Top-level keys in TS names; values still as given.
    const rename = dict ? renameTable(dict, direction) : undefined;
    const obj: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== undefined) obj[direction === "decode" ? (rename?.[k] ?? k) : k] = v;
    }
    const present = Object.keys(obj).filter((k) => obj[k] !== undefined && obj[k] !== null);
    const disc = unionCases.discriminator;
    const tag = disc ? obj[disc.key] : undefined;
    const tagged = typeof tag === "string" ? disc!.values.indexOf(tag) : -1;
    let best: { index: number; score: number; matched: number } | undefined;
    if (tagged >= 0) {
      best = { index: tagged, score: 0, matched: 0 };
    } else {
      for (let index = 0; index < unionCases.cases.length; index++) {
        const set = new Set(unionCases.cases[index]);
        let matched = 0;
        let excess = 0;
        for (const k of present) {
          if (set.has(k)) matched++;
          else excess++;
        }
        const score = matched - excess;
        if (
          matched > 0 &&
          (!best || score > best.score || (score === best.score && matched > best.matched))
        ) {
          best = { index, score, matched };
        }
      }
    }
    const own = best ? unionCases.dictionaries?.[best.index] : undefined;
    const mapValue = (k: string, v: unknown): unknown => {
      const d = own?.[k] ?? dict;
      return d ? mapKeysByDictionary(d, v, direction) : v;
    };
    const out: Record<string, unknown> = {};
    if (direction === "encode") {
      // Every given key goes out, like the plain dictionary walk.
      for (const [k, v] of Object.entries(obj)) out[rename?.[k] ?? k] = mapValue(k, v);
    } else {
      for (const k of best ? unionCases.cases[best.index]! : Object.keys(obj)) {
        out[k] = mapValue(k, obj[k]);
      }
    }
    return out;
  }

  const node = resolveNode(ast);

  // Schema-level union member (a merged response struct whose arms disagree
  // on a member's type -- see the codegen's response-union merge): pick the
  // arm that explains the value best and map with it. Object values score
  // arms by how many of their declared keys are present; array values take
  // the first array arm. Anything unmatched deep-renames via the dictionary
  // fallback, like other opaque content. (Single-real-member unions --
  // optional/null wrappers -- were already collapsed by resolveNode; the
  // opaque `T.UnionCases` mechanism never produces a Union node and is
  // handled above.)
  if (node._tag === "Union") {
    const arms = (node as AST.Union).types.map(resolveNode);
    if (Array.isArray(value)) {
      const arr = arms.find((t) => t._tag === "Arrays");
      if (arr) return mapKeys(arr, value, direction, dict);
    } else {
      let best: AST.AST | undefined;
      let bestScore = 0;
      for (const t of arms) {
        if (t._tag !== "Objects") continue;
        let score = 0;
        for (const p of (t as any).propertySignatures as readonly AST.PropertySignature[]) {
          const from = direction === "encode" ? String(p.name) : nameOf(p, bodySymbol);
          if ((value as Record<string, unknown>)[from] !== undefined) score++;
        }
        if (score > bestScore) {
          best = t;
          bestScore = score;
        }
      }
      if (best) return mapKeys(best, value, direction, dict);
    }
    return dict ? mapKeysByDictionary(dict, value, direction) : value;
  }

  if (node._tag === "Arrays") {
    if (!Array.isArray(value)) return value;
    const elem = (node as any).rest?.[0] as AST.AST | undefined;
    return elem
      ? value.map((v) => mapKeys(elem, v, direction, dict))
      : dict
        ? mapKeysByDictionary(dict, value, direction)
        : value;
  }

  if (node._tag === "Objects" && !Array.isArray(value)) {
    const props = (node as any).propertySignatures as readonly AST.PropertySignature[];
    const isigs = (node as any).indexSignatures as readonly { type: AST.AST }[] | undefined;
    if (props.length === 0 && !(isigs && isigs.length)) {
      // opaque object -- dictionary fallback or verbatim
      return dict ? mapKeysByDictionary(dict, value, direction) : value;
    }
    const out: Record<string, unknown> = {};
    const consumed = new Set<string>();
    for (const p of props) {
      const tsName = String(p.name);
      const wire = nameOf(p, bodySymbol);
      const from = direction === "encode" ? tsName : wire;
      const to = direction === "encode" ? wire : tsName;
      consumed.add(from);
      const v = (value as Record<string, unknown>)[from];
      if (v === undefined) continue;
      // A `StringEncoded()` member nested in a body struct (e.g. Azure's
      // `hardwareProfile.dynamicMemoryEnabled`) stringifies here -- the
      // top-level pass in `buildRequest` only sees the outermost member.
      out[to] =
        direction === "encode" && hasPropAnn(p, stringEncodedSymbol)
          ? stringEncode(v)
          : mapKeys(p.type, v, direction, dict);
    }
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (consumed.has(k) || v === undefined) continue;
      const renamed = dict
        ? direction === "encode"
          ? (dict[k] ?? k)
          : (Object.entries(dict).find(([, w]) => w === k)?.[0] ?? k)
        : k;

      out[typeof renamed === "string" ? renamed : renamed[0]] =
        isigs && isigs.length
          ? mapKeys(isigs[0]!.type, v, direction, dict)
          : dict
            ? mapKeysByDictionary(dict, v, direction)
            : v;
    }
    return out;
  }

  // Scalar-typed schema node holding object content (spec drift) --
  // dictionary fallback or verbatim.
  return dict ? mapKeysByDictionary(dict, value, direction) : value;
};
//#endregion

//#region Request building

const BODYLESS = /*@__PURE__*/ new Set(["GET", "HEAD"]);

/**
 * Serialize one query member. Scalars go as `k=v`, arrays as repeated `k=v`
 * pairs, and nested plain objects recurse as DOTTED params -- several list
 * endpoints model their filters as structs (e.g. Cloudflare DNS listRecords
 * takes `name: { exact, contains, ... }`) that must go over the wire as
 * `name.exact=value`. Without this they fell through to `String(value)` and
 * were sent as `name=[object Object]`, which servers happily treat as a
 * filter matching nothing -- the call "succeeds" with zero results and the
 * bug is invisible to the caller.
 */
const appendQuery = (query: URLSearchParams, name: string, value: unknown): void => {
  if (Array.isArray(value)) {
    for (const v of value) appendQuery(query, name, v);
  } else if (value !== null && typeof value === "object" && !(value instanceof Date)) {
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== undefined) appendQuery(query, `${name}.${k}`, v);
    }
  } else {
    query.append(name, String(value));
  }
};

export interface BuildRequestOptions {
  readonly input: unknown;
  readonly inputAst: AST.AST;
  /** Base URL the operation's URI template is appended to. */
  readonly baseUrl: string;
  /** Headers applied before member-bound headers (credentials etc.). */
  readonly headers?: Record<string, string>;
  /**
   * Transform a member-bound header value before it is set (e.g.
   * Bearer-prefixing a raw token supplied as an Authorization member).
   */
  readonly mapMemberHeader?: (name: string, value: string) => string;
  /**
   * Wire name for input keys the schema doesn't declare (spec drift --
   * unknown keys pass through as body fields rather than being dropped).
   * Defaults to the key verbatim.
   */
  readonly unknownKeyToWire?: (key: string) => string;
  /**
   * Send `{}` on a method that takes a body even when the input declares no
   * body members. Connect unary RPCs (E2B's envd) POST JSON for every call,
   * and refuse a bodyless one with 415.
   */
  readonly emptyJsonBody?: boolean;
  /**
   * How a query member spells a nested object or an array.
   *
   * - `"dotted"` (default): `created.gte=1`; an array repeats the key
   *   (`expand=a&expand=b`).
   * - `"brackets"`: `created[gte]=1`; an array indexes the key
   *   (`expand[0]=a&expand[1]=b`), the same rule as form-urlencoded bodies.
   *   Stripe needs this: its v2 API refuses `key[]` and repeated keys.
   *
   * `T.CommaDelimited` and `T.DeepQuery` members keep their own spelling.
   */
  readonly queryStyle?: "dotted" | "brackets";
}

/**
 * Encode a greedy `{name+}` label: the value may span several path
 * segments (e.g. an Azure scope `/subscriptions/{id}/resourceGroups/{rg}`),
 * so each segment is encoded on its own and the `/` separators are kept.
 * Leading slashes are dropped because the URI template already supplies one.
 */
export const encodeGreedyLabel = (value: string): string =>
  value.replace(/^\/+/, "").split("/").map(encodeURIComponent).join("/");

/**
 * Flatten a nested object into Stripe-style bracket notation pairs for
 * form-urlencoded bodies: nested objects become `a[b][c]`, arrays index as
 * `a[0]`; null/undefined dropped, booleans as "true"/"false".
 */
const flattenToFormPairs = (obj: Record<string, unknown>, prefix = ""): Array<[string, string]> => {
  const pairs: Array<[string, string]> = [];
  for (const [key, value] of Object.entries(obj)) {
    if (value === undefined || value === null) continue;
    const fullKey = prefix ? `${prefix}[${key}]` : key;
    if (Array.isArray(value)) {
      for (let i = 0; i < value.length; i++) {
        const item = value[i];
        if (item === undefined || item === null) continue;
        if (typeof item === "object" && !Array.isArray(item)) {
          pairs.push(...flattenToFormPairs(item as Record<string, unknown>, `${fullKey}[${i}]`));
        } else {
          pairs.push([`${fullKey}[${i}]`, String(item)]);
        }
      }
    } else if (typeof value === "object") {
      pairs.push(...flattenToFormPairs(value as Record<string, unknown>, fullKey));
    } else {
      pairs.push([fullKey, String(value)]);
    }
  }
  return pairs;
};

/** How an input member binds to the request. */
type Bind = "label" | "header" | "query" | "deepQuery" | "file" | "httpBody" | "body";

/** One input member, with its binding read from the schema once. */
interface MemberPlan {
  readonly key: string;
  readonly bind: Bind;
  /** Label token, lower-cased header name, query name or body wire name. */
  readonly name: string;
  readonly type: AST.AST;
  /** `LabelEncoding` characters kept unescaped. */
  readonly preserve: string | undefined;
  /** `{name+}` placeholder. */
  readonly greedy: boolean;
  readonly stringEncoded: boolean;
  /** A list query member sent as one comma-separated parameter. */
  readonly commaDelimited: boolean;
  /** `mapKeys(type, value, "encode", rootDict)` returns the value unchanged. */
  readonly verbatim: boolean;
}

/** What `buildRequest` reads from an input schema, computed once per schema. */
interface RequestPlan {
  readonly http: HttpTrait;
  readonly rootDict: KeyDictionaryEntries | undefined;
  readonly members: ReadonlyArray<MemberPlan>;
  readonly known: ReadonlySet<string>;
  /** The schema declares a member that is sent in the body. */
  readonly hasBodyMembers: boolean;
}

const plans = /*@__PURE__*/ new WeakMap<AST.AST, RequestPlan>();

const planFor = (inputAst: AST.AST): RequestPlan | SdkError => {
  let plan = plans.get(inputAst);
  if (plan !== undefined) return plan;
  const http = getAnn(inputAst, httpSymbol) as HttpTrait | undefined;
  if (!http) {
    return new SdkError({ message: "operation input is missing the Http() trait" });
  }
  const rootDict = getAnn(inputAst, keyDictionarySymbol) as KeyDictionaryEntries | undefined;
  const members: MemberPlan[] = [];
  const known = new Set<string>();
  let hasBodyMembers = false;
  for (const prop of getProps(inputAst)) {
    const key = String(prop.name);
    known.add(key);
    let bind: Bind;
    let name: string;
    let greedy = false;
    if (hasPropAnn(prop, labelSymbol)) {
      bind = "label";
      name = nameOf(prop, labelSymbol);
      greedy = http.uri.includes(`{${name}+}`);
    } else if (hasPropAnn(prop, headerSymbol)) {
      bind = "header";
      name = nameOf(prop, headerSymbol).toLowerCase();
    } else if (hasPropAnn(prop, querySymbol)) {
      bind = "query";
      name = nameOf(prop, querySymbol);
    } else if (hasPropAnn(prop, deepQuerySymbol)) {
      bind = "deepQuery";
      name = nameOf(prop, deepQuerySymbol);
    } else {
      hasBodyMembers = true;
      bind = hasPropAnn(prop, formDataFileSymbol)
        ? "file"
        : hasPropAnn(prop, httpBodySymbol)
          ? "httpBody"
          : "body";
      name = nameOf(prop, bodySymbol);
    }
    const preserve = getPropAnn(prop, labelEncodingSymbol);
    members.push({
      key,
      bind,
      name,
      type: prop.type,
      preserve: typeof preserve === "string" ? preserve : undefined,
      greedy,
      stringEncoded: hasPropAnn(prop, stringEncodedSymbol),
      commaDelimited: hasPropAnn(prop, commaDelimitedSymbol),
      verbatim: rootDict === undefined && mapsVerbatim(prop.type, "encode"),
    });
  }
  plan = { http, rootDict, members, known, hasBodyMembers };
  plans.set(inputAst, plan);
  return plan;
};

const emptyRequest = /*@__PURE__*/ HttpClientRequest.get("");

/**
 * `HttpClientRequest.make(method)(url)` with `headers` set, in one object:
 * the same request as `make(...).pipe(setHeaders(headers))` without the
 * intermediate copies. `url` may carry a query string.
 */
export const makeRequest = (
  method: HttpTrait["method"],
  url: string,
  headers: Record<string, string>,
): HttpClientRequest.HttpClientRequest =>
  HttpClientRequest.makeWith(
    method,
    url,
    emptyRequest.urlParams,
    emptyRequest.hash,
    Headers.fromInput(headers),
    HttpBody.empty,
  );

/**
 * The input cannot be sent: a path label whose value would address another
 * resource (`.` or `..`, which the URL parser resolves to the parent path).
 * Raised before anything is sent.
 */
export class InvalidInput
  extends /*@__PURE__*/ Schema.TaggedError<InvalidInput>()("InvalidInput", {
    member: Schema.String,
    message: Schema.String,
  }).pipe(Category.withBadRequestError) {}

/**
 * The refusal for a path label value that would address another resource,
 * or `undefined`. The URL parser resolves a `.` or `..` segment,
 * percent-encoded or not, so no encoding can carry one
 * (`/projects/p1/branches/..` -> `/projects/p1/`). A greedy label keeps its
 * `/`, so each of its segments counts.
 */
export const invalidLabel = (
  member: string,
  value: unknown,
  greedy?: boolean,
): InvalidInput | undefined => {
  const text = String(value);
  return (greedy ? text.split("/") : [text]).some((s) => s === "." || s === "..")
    ? new InvalidInput({
        member,
        message: `Input member ${member} cannot be ${JSON.stringify(text)}: as a path label it would address another resource`,
      })
    : undefined;
};

/**
 * Build an HTTP request from an operation input and its schema, driven by
 * the trait annotations: `Http()` supplies method + URI template, `Label()`
 * members fill URI placeholders, `Header()`/`Query()` members bind to
 * headers/query params, `DeepQuery()` struct members expand into dotted
 * query params, `HttpBody()` sends the member as the whole body,
 * `FormDataFile()` members become multipart file parts, and everything else
 * is a JSON body field (wire-named via `Body()` / `KeyDictionary`).
 *
 * The schema is read once per input schema (see `planFor`); later calls only
 * walk the input value.
 *
 * Fails with {@link InvalidInput}, before anything is sent, when a label is
 * `.` or `..` (for a greedy `{name+}` label, when any of its segments is).
 * Fails with {@link SdkError} when the input schema is missing the `Http()`
 * trait (a codegen bug the generator refuses).
 */
export const buildRequest = (
  options: BuildRequestOptions,
): Effect.Effect<HttpClientRequest.HttpClientRequest, InvalidInput | SdkError> => {
  const request = requestOrInvalid(options);
  return request instanceof InvalidInput || request instanceof SdkError
    ? Effect.fail(request)
    : Effect.succeed(request);
};

const requestOrInvalid = ({
  input,
  inputAst,
  baseUrl,
  headers: baseHeaders,
  mapMemberHeader,
  unknownKeyToWire,
  emptyJsonBody,
  queryStyle,
}: BuildRequestOptions): HttpClientRequest.HttpClientRequest | InvalidInput | SdkError => {
  const inputObj = (input ?? {}) as Record<string, unknown>;
  const plan = planFor(inputAst);
  if (plan instanceof SdkError) return plan;
  const { http, rootDict, members, known } = plan;
  let hasBodyMembers = plan.hasBodyMembers;

  const headers: Record<string, string> = { ...baseHeaders };
  const body: Record<string, unknown> = {};
  let bodyKeys = 0;
  let rawBody: unknown; // whole-body member (T.HttpBody) -- sent as-is
  let files: Array<Blob | File> | undefined;
  let query: URLSearchParams | undefined;
  let uri = http.uri;
  // Value of a modeled `Content-Type` header member, e.g. R2 putObject's
  // `contentType`. A raw body is sent under it (see below).
  let memberContentType: string | undefined;

  for (let i = 0; i < members.length; i++) {
    const m = members[i]!;
    const value = inputObj[m.key];
    if (value === undefined) continue;
    switch (m.bind) {
      case "label": {
        const invalid = invalidLabel(m.key, value, m.greedy);
        if (invalid) return invalid;
        const encoded = encodeURIComponent(String(value));
        const preserve = m.preserve;
        const label =
          preserve !== undefined
            ? encoded.replace(/%[0-9A-F]{2}/g, (escape) => {
                const character = String.fromCharCode(Number.parseInt(escape.slice(1), 16));
                return preserve.includes(character) ? character : escape;
              })
            : encoded;
        uri = m.greedy
          ? uri.replace(`{${m.name}+}`, () => encodeGreedyLabel(String(value)))
          : uri.replace(`{${m.name}}`, () => label);
        break;
      }
      case "header": {
        const hVal = String(value);
        headers[m.name] = mapMemberHeader ? mapMemberHeader(m.name, hVal) : hVal;
        if (m.name === "content-type") memberContentType = headers[m.name];
        break;
      }
      case "query":
        if (m.commaDelimited && Array.isArray(value)) {
          (query ??= new URLSearchParams()).append(m.name, value.map(String).join(","));
        } else if (queryStyle === "brackets") {
          query ??= new URLSearchParams();
          for (const [k, v] of flattenToFormPairs({ [m.name]: value })) query.append(k, v);
        } else {
          appendQuery((query ??= new URLSearchParams()), m.name, value);
        }
        break;
      case "deepQuery": {
        // Deep-object query member (T.DeepQuery): a nested struct expands into
        // dotted query keys (`account.id=...`) under the member's wire name.
        // Wire-name the nested content via the schema first, skip null/
        // undefined entries; deeper nesting recurses through appendQuery.
        const mapped = m.verbatim ? value : mapKeys(m.type, value, "encode", rootDict);
        if (mapped !== null && typeof mapped === "object") {
          for (const [k, v] of Object.entries(mapped as Record<string, unknown>)) {
            if (v !== undefined && v !== null) {
              appendQuery((query ??= new URLSearchParams()), `${m.name}.${k}`, v);
            }
          }
        }
        break;
      }
      case "file":
        files ??= [];
        for (const f of Array.isArray(value) ? value : [value]) {
          files.push(f as Blob | File);
        }
        break;
      case "httpBody":
        rawBody = m.verbatim ? value : mapKeys(m.type, value, "encode", rootDict);
        break;
      default:
        // T.StringEncoded(): the API takes this member's value only as its
        // string spelling (`true` -> `"true"`), while the TS surface keeps the
        // natural type. Explicit here so a JSON body carries the string too,
        // rather than relying on the multipart encoder's own `String()`.
        body[m.name] = m.stringEncoded
          ? stringEncode(value)
          : m.verbatim
            ? value
            : mapKeys(m.type, value, "encode", rootDict);
        bodyKeys++;
    }
  }

  // Input keys the schema doesn't know pass through as body fields -- the
  // generated schemas can lag the real API, and silently dropping them
  // would break working callers. The key dictionary maps them when it knows
  // the key, otherwise `unknownKeyToWire` decides the wire name.
  for (const key in inputObj) {
    if (known.has(key) || !Object.hasOwn(inputObj, key)) continue;
    const value = inputObj[key];
    if (value === undefined) continue;
    const wire = rootDict?.[key] ?? (unknownKeyToWire ? unknownKeyToWire(key) : key);
    body[typeof wire === "string" ? wire : wire[0]] = rootDict
      ? mapKeysByDictionary(rootDict, value, "encode")
      : value;
    bodyKeys++;
    hasBodyMembers = true;
  }

  const qs = query === undefined ? "" : query.toString();
  const url = qs ? `${baseUrl}${uri}?${qs}` : `${baseUrl}${uri}`;

  const request = makeRequest(http.method, url, headers);
  const bodied = !BODYLESS.has(http.method);
  if (http.contentType === "multipart") {
    // Multipart upload: each body member is a form part (objects
    // JSON-encoded under their wire name). Files and byte buffers become
    // binary parts under the member's wire name, with a File's own filename
    // (the wire name for a nameless Blob or a byte buffer); a list of them is
    // one such part per element, the repeated-field form multipart APIs read
    // (`-F documents=@a.pdf -F documents=@b.txt`). `FormDataFile()` members
    // append under each file's own filename instead (below). A whole-body
    // member (T.HttpBody) that is a record of files becomes one part per
    // entry (e.g. asset upload: { <hash>: File }).
    const form = new FormData();
    const parts =
      rawBody !== undefined && typeof rawBody === "object"
        ? (rawBody as Record<string, unknown>)
        : body;
    const isBinary = (v: unknown): v is Blob | Uint8Array | ArrayBuffer =>
      v instanceof Blob || v instanceof Uint8Array || v instanceof ArrayBuffer;
    const appendBinary = (key: string, value: Blob | Uint8Array | ArrayBuffer) => {
      if (value instanceof Blob) {
        form.append(key, value, value instanceof File ? value.name : key);
      } else {
        // Copy a Uint8Array view's own bytes (a subarray shares a larger buffer).
        const bytes = value instanceof Uint8Array ? new Uint8Array(value).buffer : value;
        form.append(key, new Blob([bytes]), key);
      }
    };
    for (const [key, value] of Object.entries(parts)) {
      if (value === undefined || value === null) continue;
      if (isBinary(value)) {
        appendBinary(key, value);
      } else if (Array.isArray(value) && value.length > 0 && value.every(isBinary)) {
        for (const element of value) appendBinary(key, element);
      } else if (typeof value === "object") {
        form.append(key, JSON.stringify(value));
      } else {
        form.append(key, String(value));
      }
    }
    for (const f of files ?? []) {
      const filename = (f as File).name ?? "file";
      form.append(filename, f, filename);
    }
    return HttpClientRequest.setBody(request, HttpBody.formData(form));
  }
  if (http.contentType === "form-urlencoded" && bodied) {
    // application/x-www-form-urlencoded with Stripe-style deepObject bracket
    // notation: { shipping: { address: { city } } } -> shipping[address][city],
    // arrays indexed ({ expand: ["a"] } -> expand[0]=a).
    const source =
      rawBody !== undefined && typeof rawBody === "object"
        ? (rawBody as Record<string, unknown>)
        : body;
    const params = new URLSearchParams();
    for (const [k, v] of flattenToFormPairs(source)) params.append(k, v);
    return HttpClientRequest.setBody(
      request,
      HttpBody.text(params.toString(), "application/x-www-form-urlencoded"),
    );
  }
  if (rawBody !== undefined && bodied) {
    // Whole-body member (raw arrays/scalars) -- sent as the body itself.
    // Binary payloads (Blob / ArrayBuffer / Uint8Array) send verbatim
    // (raw object uploads). With a bodyMediaType, the member is a
    // preserialized payload (string / bytes) sent verbatim; otherwise it's
    // JSON, under the Content-Type member when set (e.g. Kubernetes'
    // application/merge-patch+json).
    //
    // `setBody` overwrites the Content-Type header with the body's media
    // type (and removes it when that is undefined), so the body carries the
    // modeled Content-Type member when the caller set one, else the declared
    // bodyMediaType (e.g. application/x-ndjson for Vectorize insert/upsert).
    const mediaType = memberContentType ?? http.bodyMediaType;
    if (rawBody instanceof Blob || rawBody instanceof ArrayBuffer) {
      // With no media type at all, fetch falls back to the Blob's own type.
      return HttpClientRequest.setBody(request, HttpBody.raw(rawBody, { contentType: mediaType }));
    }
    if (rawBody instanceof Uint8Array) {
      return HttpClientRequest.setBody(request, HttpBody.uint8Array(rawBody, mediaType));
    }
    if (http.bodyMediaType) {
      return HttpClientRequest.setBody(
        request,
        typeof rawBody === "string"
          ? HttpBody.text(rawBody, mediaType)
          : HttpBody.uint8Array(rawBody as Uint8Array, mediaType),
      );
    }
    return HttpClientRequest.setBody(request, HttpBody.jsonUnsafe(rawBody, memberContentType));
  }
  if (
    // A GET/HEAD sends a body only when body members actually carry values.
    // Some APIs really do document GET-with-body: MongoDB Atlas's
    // `.../lineItems:search` declares a `requestBody` on `get`, and AWS EFS's
    // DescribeAccountPreferences takes `{ MaxResults, NextToken }` on a GET.
    // Suppressing it outright dropped those members silently -- the request
    // succeeded, unfiltered, with nothing on the wire to show why.
    //
    // The `{}`-when-empty rule below stays limited to methods that expect a
    // body, so a bodyless method with nothing set still sends nothing.
    bodyKeys > 0 ||
    ((hasBodyMembers || emptyJsonBody === true) && bodied && http.method !== "DELETE")
  ) {
    // Send `{}` rather than no body when the schema declares body members --
    // some endpoints reject a missing JSON body outright. A Content-Type
    // member names the JSON media type, as for a whole body above (a
    // Kubernetes merge patch is `application/merge-patch+json`).
    return HttpClientRequest.setBody(request, HttpBody.jsonUnsafe(body, memberContentType));
  }
  return request;
};
//#endregion

//#region Typed error matching

/** Parsed response metadata supplied by a protocol after it detects a failure. */
export interface ErrorResponse {
  readonly body?: unknown;
  readonly headers?: Readonly<Record<string, string | undefined>>;
  /**
   * JSON pointer to the object that holds the error's fields when the
   * provider nests them, e.g. `"/error"` for `{ error: { status, details } }`.
   */
  readonly fieldsAt?: string;
}

const matchesText = (matcher: ErrorTextMatcher, value: unknown): boolean => {
  if (typeof value !== "string") return false;
  if (typeof matcher === "string") return matcher === value;
  const { includes, matches } = matcher;
  return (
    (includes !== undefined || matches !== undefined) &&
    (includes === undefined || value.includes(includes)) &&
    (matches === undefined || new RegExp(matches).test(value))
  );
};

// Own properties only: inherited properties are not JSON response members.
const atPointer = (body: unknown, pointer: string): unknown => {
  if (pointer === "") return body;
  if (!pointer.startsWith("/") || /~(?![01])/u.test(pointer)) return undefined;
  let value = body;
  for (const segment of pointer.slice(1).split("/")) {
    const key = segment.replace(/~1/g, "/").replace(/~0/g, "~");
    if (
      value === null ||
      typeof value !== "object" ||
      !Object.hasOwn(value, key) ||
      (Array.isArray(value) && !/^(0|[1-9][0-9]*)$/.test(key))
    )
      return undefined;
    value = (value as Record<string, unknown>)[key];
  }
  return value;
};

const matcherSpecificity = (m: ErrorMatcher): number =>
  (m.code !== undefined ? 1 : 0) +
  (m.status !== undefined ? 1 : 0) +
  (m.message !== undefined ? 1 : 0) +
  (m.body === undefined ? 0 : Object.keys(m.body).length) +
  (m.headers === undefined ? 0 : Object.keys(m.headers).length);

/** Every supplied constraint must match; an unconstrained matcher matches nothing. */
export const matchesExpression = (
  m: ErrorMatcher,
  code: number | undefined,
  status: number,
  message: string,
  response: ErrorResponse = {},
): boolean => {
  if (
    m.code === undefined &&
    m.status === undefined &&
    m.message === undefined &&
    matcherSpecificity(m) === 0
  )
    return false;
  if (m.code !== undefined && m.code !== code) return false;
  if (m.status !== undefined && m.status !== status) return false;
  if (m.message !== undefined && !matchesText(m.message, message)) return false;
  if (m.body !== undefined) {
    for (const [pointer, expected] of Object.entries(m.body)) {
      const actual = atPointer(response.body, pointer);
      if (typeof expected === "string" || (expected !== null && typeof expected === "object")) {
        if (!matchesText(expected, actual)) return false;
      } else if (actual !== expected) return false;
    }
  }
  if (m.headers !== undefined) {
    for (const [name, expected] of Object.entries(m.headers)) {
      if (response.headers === undefined) return false;
      const actual = Object.entries(response.headers).find(
        ([key]) => key.toLowerCase() === name.toLowerCase(),
      )?.[1];
      if (!matchesText(expected, actual)) return false;
    }
  }
  return true;
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

/**
 * The body values whose keys the error class declares as fields: from the
 * object at `fieldsAt` first, then from the top level.
 */
const declaredBodyFields = (
  fields: Record<string, unknown> | undefined,
  body: unknown,
  fieldsAt: string | undefined,
): Record<string, unknown> => {
  if (fields === undefined) return {};
  const nested = fieldsAt === undefined ? undefined : atPointer(body, fieldsAt);
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(fields)) {
    if (isRecord(nested) && Object.hasOwn(nested, key)) out[key] = nested[key];
    else if (isRecord(body) && Object.hasOwn(body, key)) out[key] = body[key];
  }
  return out;
};

/**
 * The fields every error built from a response gets, when its class declares
 * them: the body (keys mapped to TS names when the class types it), the
 * headers, and the server's retry hint from `Retry-After` or `RateLimit`.
 */
export const responseErrorFields = (
  fields: Record<string, unknown> | undefined,
  response: ErrorResponse,
): Record<string, unknown> => {
  // A typed body (the provider's documented error schema) gets the TS names
  // a success body gets; an untyped one stays as the wire sent it.
  const bodyAst = (fields?.body as { readonly ast?: AST.AST } | undefined)?.ast;
  const out: Record<string, unknown> = {
    body:
      bodyAst !== undefined &&
      typeof response.body === "object" &&
      response.body !== null &&
      !mapsVerbatim(bodyAst, "decode")
        ? mapKeys(bodyAst, response.body, "decode")
        : response.body,
    headers: response.headers,
  };
  if (fields !== undefined && Object.hasOwn(fields, "retryAfter") && response.headers) {
    out.retryAfter = parseServerRetryHint(response.headers);
  }
  return out;
};

/**
 * Pick the operation's typed error class for a failed response: among all
 * declared classes whose matchers (see `applyErrorMatchers`) match the wire
 * failure, the most specific matcher wins (ties break by declaration order).
 * Empty error lists use an HTTP-status message so body/header-only failures can
 * still match. The constructor receives the raw body and headers as well as
 * code/message; error schemas can declare these fields to expose them to callers.
 * Any other field the class declares is read from the JSON body's key of the
 * same name -- at `response.fieldsAt` first, then at the top level -- so a
 * patch that adds `requestId` to an error gets the body's `requestId`. A
 * declared `retryAfter` gets the `Retry-After` / `RateLimit` header hint. The
 * matched `code` and `message` always win over the body's.
 */
export const matchTypedError = (
  errorClasses: ReadonlyArray<unknown>,
  status: number,
  errors: ReadonlyArray<{ code?: number; message: string }>,
  response: ErrorResponse = {},
): unknown | undefined => {
  let best: { cls: unknown; specificity: number; code?: number; message: string } | undefined;
  const wireErrors = errors.length > 0 ? errors : [{ message: `HTTP ${status}` }];
  for (const cls of errorClasses) {
    const matchers = getErrorMatchers(cls);
    if (!matchers) continue;
    for (const m of matchers) {
      for (const e of wireErrors) {
        if (!matchesExpression(m, e.code, status, e.message, response)) continue;
        const specificity = matcherSpecificity(m);
        if (!best || specificity > best.specificity) {
          best = { cls, specificity, code: e.code, message: e.message };
        }
      }
    }
  }
  if (!best) return undefined;
  const fields = (best.cls as { fields?: Record<string, unknown> }).fields;
  const saved = suppressStack();
  try {
    return new (best.cls as new (args: any) => unknown)({
      ...declaredBodyFields(fields, response.body, response.fieldsAt),
      code: best.code ?? 0,
      message: best.message,
      ...responseErrorFields(fields, response),
    });
  } finally {
    restoreStack(saved);
  }
};
//#endregion
