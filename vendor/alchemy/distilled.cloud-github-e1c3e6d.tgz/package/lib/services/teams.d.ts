import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The role that this user should have in the team. */
export type AddOrUpdateMembershipForUserInOrgRequestRole = "member" | "maintainer";
export interface AddOrUpdateMembershipForUserInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The role that this user should have in the team. */
    role?: AddOrUpdateMembershipForUserInOrgRequestRole | (string & {}) | undefined;
}
/** The role of the user in the team. */
export type TeamMembershipRole = "member" | "maintainer";
/** The state of the user's membership in the team. */
export type TeamMembershipState = "active" | "pending";
/** Team Membership */
export interface TeamMembership {
    url: string;
    /** The role of the user in the team. */
    role: TeamMembershipRole;
    /** The state of the user's membership in the team. */
    state: TeamMembershipState;
}
export interface AddOrUpdateRepoPermissionsInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The permission to grant the team on this repository. We accept the following permissions to be set: `pull`, `triage`, `moderate`, `push`, `maintain`, `admin` and you can also specify a custom repository role name, if the owning organization has defined any. If no permission is specified, the team's `permission` attribute will be used to determine what permission to grant the team on this repository. */
    permission?: string | undefined;
}
export interface AddOrUpdateRepoPermissionsInOrgResponse {
}
export interface CheckPermissionsForRepoInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface TeamRepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type TeamRepositoryTopicsList = Array<string>;
/** A team's access to a repository. */
export interface TeamRepository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: TeamRepositoryPermissions | undefined;
    role_name?: string | undefined;
    owner: NullableSimpleUser | null;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: TeamRepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
}
/** List GitHub usernames for organization members who will become team maintainers. */
export type CreateRequestMaintainersList = Array<string>;
/** The full name (e.g., "organization-name/repository-name") of repositories to add the team to. */
export type CreateRequestRepoNamesList = Array<string>;
/** The level of privacy this team should have. The options are: **For a non-nested team:** * `secret` - only visible to organization owners and members of this team. * `closed` - visible to all members of this organization. Default: `secret` **For a parent or child team:** * `closed` - visible to all members of this organization. Default for child team: `closed` */
export type CreateRequestPrivacy = "secret" | "closed";
/** The notification setting the team has chosen. The options are: * `notifications_enabled` - team members receive notifications when the team is @mentioned. * `notifications_disabled` - no one receives notifications. Default: `notifications_enabled` */
export type CreateRequestNotificationSetting = "notifications_enabled" | "notifications_disabled";
/** **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. */
export type CreateRequestPermission = "pull" | "push";
export interface CreateRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the team. */
    name: string;
    /** The description of the team. */
    description?: string | undefined;
    /** List GitHub usernames for organization members who will become team maintainers. */
    maintainers?: CreateRequestMaintainersList | undefined;
    /** The full name (e.g., "organization-name/repository-name") of repositories to add the team to. */
    repo_names?: CreateRequestRepoNamesList | undefined;
    /** The level of privacy this team should have. The options are: **For a non-nested team:** * `secret` - only visible to organization owners and members of this team. * `closed` - visible to all members of this organization. Default: `secret` **For a parent or child team:** * `closed` - visible to all members of this organization. Default for child team: `closed` */
    privacy?: CreateRequestPrivacy | (string & {}) | undefined;
    /** The notification setting the team has chosen. The options are: * `notifications_enabled` - team members receive notifications when the team is @mentioned. * `notifications_disabled` - no one receives notifications. Default: `notifications_enabled` */
    notification_setting?: CreateRequestNotificationSetting | (string & {}) | undefined;
    /** **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. */
    permission?: CreateRequestPermission | (string & {}) | undefined;
    /** The ID of a team to set as the parent team. */
    parent_team_id?: number | undefined;
    /** The slug of a team to set as the parent team. Ignored when `parent_team_id` is also provided. */
    parent_team_slug?: string | undefined;
}
/** The level of privacy this team should have */
export type TeamFullPrivacy = "closed" | "secret";
/** The notification setting the team has set */
export type TeamFullNotificationSetting = "notifications_enabled" | "notifications_disabled";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
export interface TeamOrganizationPlan {
    name: string;
    space: number;
    private_repos: number;
    filled_seats?: number | undefined;
    seats?: number | undefined;
}
/** Team Organization */
export interface TeamOrganization {
    login: string;
    id: number;
    node_id: string;
    url: string;
    repos_url: string;
    events_url: string;
    hooks_url: string;
    issues_url: string;
    members_url: string;
    public_members_url: string;
    avatar_url: string;
    description: string | null;
    name?: string | undefined;
    company?: string | null | undefined;
    blog?: string | null | undefined;
    location?: string | null | undefined;
    email?: string | null | undefined;
    twitter_username?: string | null | undefined;
    is_verified?: boolean | undefined;
    has_organization_projects: boolean;
    has_repository_projects: boolean;
    public_repos: number;
    public_gists: number;
    followers: number;
    following: number;
    html_url: string;
    created_at: string;
    type: string;
    total_private_repos?: number | undefined;
    owned_private_repos?: number | undefined;
    private_gists?: number | null | undefined;
    disk_usage?: number | null | undefined;
    collaborators?: number | null | undefined;
    billing_email?: string | null | undefined;
    plan?: TeamOrganizationPlan | undefined;
    default_repository_permission?: string | null | undefined;
    members_can_create_repositories?: boolean | null | undefined;
    two_factor_requirement_enabled?: boolean | null | undefined;
    members_allowed_repository_creation_type?: string | undefined;
    members_can_create_public_repositories?: boolean | undefined;
    members_can_create_private_repositories?: boolean | undefined;
    members_can_create_internal_repositories?: boolean | undefined;
    members_can_create_pages?: boolean | undefined;
    members_can_create_public_pages?: boolean | undefined;
    members_can_create_private_pages?: boolean | undefined;
    members_can_fork_private_repositories?: boolean | null | undefined;
    web_commit_signoff_required?: boolean | undefined;
    updated_at: string;
    archived_at: string | null;
}
/** The ownership type of the team */
export type TeamFullType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface TeamFull {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    html_url: string;
    /** Name of the team */
    name: string;
    slug: string;
    description: string | null;
    /** The level of privacy this team should have */
    privacy?: TeamFullPrivacy | undefined;
    /** The notification setting the team has set */
    notification_setting?: TeamFullNotificationSetting | undefined;
    /** Permission that the team will have for its repositories */
    permission: string;
    members_url: string;
    repositories_url: string;
    parent?: NullableTeamSimple | null | undefined;
    members_count: number;
    repos_count: number;
    created_at: string;
    updated_at: string;
    organization: TeamOrganization;
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: TeamFullType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
export interface DeleteInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
}
export interface DeleteInOrgResponse {
}
export interface GetByNameRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
}
export interface GetMembershipForUserInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export type ListRequestTeamType = "all" | "enterprise" | "organization";
export interface ListRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Filter team results by their type. For more information, see "[What kind of team should I use?](https://docs.github.com/admin/concepts/enterprise-fundamentals/teams-in-an-enterprise#what-kind-of-team-should-i-use)" */
    team_type?: ListRequestTeamType | (string & {}) | undefined;
}
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type ListResponseBodyList = Array<Team>;
export type ListResponse = ListResponseBodyList;
export interface ListChildInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListChildInOrgResponseBodyList = Array<Team>;
export type ListChildInOrgResponse = ListChildInOrgResponseBodyList;
export interface ListForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForAuthenticatedUserResponseBodyList = Array<TeamFull>;
export type ListForAuthenticatedUserResponse = ListForAuthenticatedUserResponseBodyList;
export type ListMembersInOrgRequestRole = "member" | "maintainer" | "all";
export interface ListMembersInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** Filters members returned by their role in the team. */
    role?: ListMembersInOrgRequestRole | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The member's role on the team. Only present on the `List team members` endpoint, and only when the feature is enabled for the organization. */
export type TeamMemberRole = "member" | "maintainer";
/** A user that is a member of a team, including their role on the team and whether the membership is inherited from a child team. */
export interface TeamMember {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
    /** The member's role on the team. Only present on the `List team members` endpoint, and only when the feature is enabled for the organization. */
    role?: TeamMemberRole | undefined;
    /** Whether the user is a member of the team only through a child team. `true` means the membership is inherited from a child team; `false` means the user is a direct (immediate) member of the team. Only present on the `List team members` endpoint, and only when the feature is enabled for the organization. */
    inherited?: boolean | undefined;
}
export type ListMembersInOrgResponseBodyList = Array<TeamMember>;
export type ListMembersInOrgResponse = ListMembersInOrgResponseBodyList;
export interface ListPendingInvitationsInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
/** Organization Invitation */
export interface OrganizationInvitation {
    id: number;
    login: string | null;
    email: string | null;
    role: string;
    created_at: string;
    failed_at?: string | null | undefined;
    failed_reason?: string | null | undefined;
    inviter: NullableSimpleUser;
    team_count: number;
    node_id: string;
    invitation_teams_url: string;
    invitation_source?: string | undefined;
}
export type ListPendingInvitationsInOrgResponseBodyList = Array<OrganizationInvitation>;
export type ListPendingInvitationsInOrgResponse = ListPendingInvitationsInOrgResponseBodyList;
export interface ListReposInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: NullableSimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type ListReposInOrgResponseBodyList = Array<MinimalRepository>;
export type ListReposInOrgResponse = ListReposInOrgResponseBodyList;
export interface RemoveMembershipForUserInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RemoveMembershipForUserInOrgResponse {
}
export interface RemoveRepoInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface RemoveRepoInOrgResponse {
}
/** The level of privacy this team should have. Editing teams without specifying this parameter leaves `privacy` intact. When a team is nested, the `privacy` for parent teams cannot be `secret`. The options are: **For a non-nested team:** * `secret` - only visible to organization owners and members of this team. * `closed` - visible to all members of this organization. **For a parent or child team:** * `closed` - visible to all members of this organization. */
export type UpdateInOrgRequestPrivacy = "secret" | "closed";
/** The notification setting the team has chosen. Editing teams without specifying this parameter leaves `notification_setting` intact. The options are: * `notifications_enabled` - team members receive notifications when the team is @mentioned. * `notifications_disabled` - no one receives notifications. */
export type UpdateInOrgRequestNotificationSetting = "notifications_enabled" | "notifications_disabled";
/** **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. */
export type UpdateInOrgRequestPermission = "pull" | "push" | "admin";
export interface UpdateInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The slug of the team name. */
    team_slug: string;
    /** The name of the team. */
    name?: string | undefined;
    /** The description of the team. */
    description?: string | undefined;
    /** The level of privacy this team should have. Editing teams without specifying this parameter leaves `privacy` intact. When a team is nested, the `privacy` for parent teams cannot be `secret`. The options are: **For a non-nested team:** * `secret` - only visible to organization owners and members of this team. * `closed` - visible to all members of this organization. **For a parent or child team:** * `closed` - visible to all members of this organization. */
    privacy?: UpdateInOrgRequestPrivacy | (string & {}) | undefined;
    /** The notification setting the team has chosen. Editing teams without specifying this parameter leaves `notification_setting` intact. The options are: * `notifications_enabled` - team members receive notifications when the team is @mentioned. * `notifications_disabled` - no one receives notifications. */
    notification_setting?: UpdateInOrgRequestNotificationSetting | (string & {}) | undefined;
    /** **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. */
    permission?: UpdateInOrgRequestPermission | (string & {}) | undefined;
    /** The ID of a team to set as the parent team. */
    parent_team_id?: number | null | undefined;
    /** The slug of a team to set as the parent team. Ignored when `parent_team_id` is also provided. */
    parent_team_slug?: string | null | undefined;
}
export type AddOrUpdateMembershipForUserInOrgError = GithubOpError;
/** Add or update team membership for a user Adds an organization member to a team. An authenticated organization owner or team maintainer can add organization members to a team. Team synchronization is available for organizations using GitHub Enterprise Cloud. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. > [!NOTE] > When you have team synchronization set up for a team with your organization's identity provider (IdP), you will see an error if you attempt to use the API for making changes to the team's membership. If you have access to manage group membership in your IdP, you can manage GitHub team membership through your identity provider, which automatically adds and removes team members in an organization. For more information, see "[Synchronizing teams between your identity provider and GitHub](https://docs.github.com/articles/synchronizing-teams-between-your-identity-provider-and-github/)." An organization owner can add someone who is not part of the team's organization to a team. When an organization owner adds someone to a team who is not an organization member, this endpoint will send an invitation to the person via email. This newly-created membership will be in the "pending" state until the person accepts the invitation, at which point the membership will transition to the "active" state and the user will be added as a member of the team. If the user is already a member of the team, this endpoint will update the role of the team member's role. To update the membership of a team member, the authenticated user must be an organization owner or a team maintainer. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `PUT /organizations/{org_id}/team/{team_id}/memberships/{username}`. */
export declare const addOrUpdateMembershipForUserInOrg: API.OperationMethod<AddOrUpdateMembershipForUserInOrgRequest, TeamMembership, AddOrUpdateMembershipForUserInOrgError, GithubOpContext>;
export type AddOrUpdateRepoPermissionsInOrgError = GithubOpError;
/** Add or update team repository permissions To add a repository to a team or update the team's permission on a repository, the authenticated user must have admin access to the repository, and must be able to see the team. The repository must be owned by the organization, or a direct fork of a repository owned by the organization. You will get a `422 Unprocessable Entity` status if you attempt to add a repository to a team that is not owned by the organization. Note that, if you choose not to pass any parameters, you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `PUT /organizations/{org_id}/team/{team_id}/repos/{owner}/{repo}`. For more information about the permission levels, see "[Repository permission levels for an organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/repository-permission-levels-for-an-organization#permission-levels-for-repositories-owned-by-an-organization)". */
export declare const addOrUpdateRepoPermissionsInOrg: API.OperationMethod<AddOrUpdateRepoPermissionsInOrgRequest, AddOrUpdateRepoPermissionsInOrgResponse, AddOrUpdateRepoPermissionsInOrgError, GithubOpContext>;
export type CheckPermissionsForRepoInOrgError = GithubOpError;
/** Check team permissions for a repository Checks whether a team has `admin`, `push`, `maintain`, `triage`, or `pull` permission for a repository. Repositories inherited through a parent team will also be checked. You can also get information about the specified repository, including what permissions the team grants on it, by passing the following custom [media type](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types/) via the `application/vnd.github.v3.repository+json` accept header. If a team doesn't have permission for the repository, you will receive a `404 Not Found` response status. If the repository is private, you must have at least `read` permission for that repository, and your token must have the `repo` or `admin:org` scope. Otherwise, you will receive a `404 Not Found` response status. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/repos/{owner}/{repo}`. */
export declare const checkPermissionsForRepoInOrg: API.OperationMethod<CheckPermissionsForRepoInOrgRequest, TeamRepository, CheckPermissionsForRepoInOrgError, GithubOpContext>;
export type CreateError = GithubOpError;
/** Create a team To create a team, the authenticated user must be a member or owner of `{org}`. By default, organization members can create teams. Organization owners can limit team creation to organization owners. For more information, see "[Setting team creation permissions](https://docs.github.com/articles/setting-team-creation-permissions-in-your-organization)." When you create a new team, you automatically become a team maintainer without explicitly adding yourself to the optional array of `maintainers`. For more information, see "[About teams](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/about-teams)". */
export declare const create: API.OperationMethod<CreateRequest, TeamFull, CreateError, GithubOpContext>;
export type DeleteInOrgError = GithubOpError;
/** Delete a team To delete a team, the authenticated user must be an organization owner or team maintainer. If you are an organization owner, deleting a parent team will delete all of its child teams as well. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `DELETE /organizations/{org_id}/team/{team_id}`. */
export declare const deleteInOrg: API.OperationMethod<DeleteInOrgRequest, DeleteInOrgResponse, DeleteInOrgError, GithubOpContext>;
export type GetByNameError = GithubOpError;
/** Get a team by name Gets a team using the team's `slug`. To create the `slug`, GitHub replaces special characters in the `name` string, changes all words to lowercase, and replaces spaces with a `-` separator. For example, `"My TEam Näme"` would become `my-team-name`. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}`. */
export declare const getByName: API.OperationMethod<GetByNameRequest, TeamFull, GetByNameError, GithubOpContext>;
export type GetMembershipForUserInOrgError = GithubOpError;
/** Get team membership for a user Team members will include the members of child teams. To get a user's membership with a team, the team must be visible to the authenticated user. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/memberships/{username}`. > [!NOTE] > The response contains the `state` of the membership and the member's `role`. The `role` for organization owners is set to `maintainer`. For more information about `maintainer` roles, see [Create a team](https://docs.github.com/rest/teams/teams#create-a-team). */
export declare const getMembershipForUserInOrg: API.OperationMethod<GetMembershipForUserInOrgRequest, TeamMembership, GetMembershipForUserInOrgError, GithubOpContext>;
export type ListError = GithubOpError;
/** List teams Lists all teams in an organization that are visible to the authenticated user. */
export declare const list: API.PaginatedOperationMethod<ListRequest, ListResponse, ListError, GithubOpContext, Team>;
export type ListChildInOrgError = GithubOpError;
/** List child teams Lists the child teams of the team specified by `{team_slug}`. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/teams`. */
export declare const listChildInOrg: API.PaginatedOperationMethod<ListChildInOrgRequest, ListChildInOrgResponse, ListChildInOrgError, GithubOpContext, Team>;
export type ListForAuthenticatedUserError = GithubOpError;
/** List teams for the authenticated user List all of the teams across all of the organizations to which the authenticated user belongs. OAuth app tokens and personal access tokens (classic) need the `user`, `repo`, or `read:org` scope to use this endpoint. When using a fine-grained personal access token, the resource owner of the token must be a single organization, and the response will only include the teams from that organization. */
export declare const listForAuthenticatedUser: API.PaginatedOperationMethod<ListForAuthenticatedUserRequest, ListForAuthenticatedUserResponse, ListForAuthenticatedUserError, GithubOpContext, TeamFull>;
export type ListMembersInOrgError = GithubOpError;
/** List team members Team members will include the members of child teams. Each member includes their `role` on the team (`member` or `maintainer`) and an `inherited` flag indicating whether the membership is inherited from a child team (`true`) or is a direct membership (`false`). These fields let you read a member's role and direct/inherited status without additional requests. To list members in a team, the team must be visible to the authenticated user. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/members`. */
export declare const listMembersInOrg: API.PaginatedOperationMethod<ListMembersInOrgRequest, ListMembersInOrgResponse, ListMembersInOrgError, GithubOpContext, TeamMember>;
export type ListPendingInvitationsInOrgError = GithubOpError;
/** List pending team invitations The return hash contains a `role` field which refers to the Organization Invitation role and will be one of the following values: `direct_member`, `admin`, `billing_manager`, `hiring_manager`, or `reinstate`. If the invitee is not a GitHub member, the `login` field in the return hash will be `null`. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/invitations`. */
export declare const listPendingInvitationsInOrg: API.PaginatedOperationMethod<ListPendingInvitationsInOrgRequest, ListPendingInvitationsInOrgResponse, ListPendingInvitationsInOrgError, GithubOpContext, OrganizationInvitation>;
export type ListReposInOrgError = GithubOpError;
/** List team repositories Lists a team's repositories visible to the authenticated user. OAuth app tokens and personal access tokens (classic) need the `read:org` or `repo` scope to use this endpoint. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `GET /organizations/{org_id}/team/{team_id}/repos`. */
export declare const listReposInOrg: API.PaginatedOperationMethod<ListReposInOrgRequest, ListReposInOrgResponse, ListReposInOrgError, GithubOpContext, MinimalRepository>;
export type RemoveMembershipForUserInOrgError = GithubOpError;
/** Remove team membership for a user To remove a membership between a user and a team, the authenticated user must have 'admin' permissions to the team or be an owner of the organization that the team is associated with. Removing team membership does not delete the user, it just removes their membership from the team. Team synchronization is available for organizations using GitHub Enterprise Cloud. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. > [!NOTE] > When you have team synchronization set up for a team with your organization's identity provider (IdP), you will see an error if you attempt to use the API for making changes to the team's membership. If you have access to manage group membership in your IdP, you can manage GitHub team membership through your identity provider, which automatically adds and removes team members in an organization. For more information, see "[Synchronizing teams between your identity provider and GitHub](https://docs.github.com/articles/synchronizing-teams-between-your-identity-provider-and-github/)." > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `DELETE /organizations/{org_id}/team/{team_id}/memberships/{username}`. */
export declare const removeMembershipForUserInOrg: API.OperationMethod<RemoveMembershipForUserInOrgRequest, RemoveMembershipForUserInOrgResponse, RemoveMembershipForUserInOrgError, GithubOpContext>;
export type RemoveRepoInOrgError = GithubOpError;
/** Remove a repository from a team If the authenticated user is an organization owner or a team maintainer, they can remove any repositories from the team. To remove a repository from a team as an organization member, the authenticated user must have admin access to the repository and must be able to see the team. This does not delete the repository, it just removes it from the team. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `DELETE /organizations/{org_id}/team/{team_id}/repos/{owner}/{repo}`. */
export declare const removeRepoInOrg: API.OperationMethod<RemoveRepoInOrgRequest, RemoveRepoInOrgResponse, RemoveRepoInOrgError, GithubOpContext>;
export type UpdateInOrgError = GithubOpError;
/** Update a team To edit a team, the authenticated user must either be an organization owner or a team maintainer. > [!NOTE] > You can also specify a team by `org_id` and `team_id` using the route `PATCH /organizations/{org_id}/team/{team_id}`. */
export declare const updateInOrg: API.OperationMethod<UpdateInOrgRequest, TeamFull, UpdateInOrgError, GithubOpContext>;
//# sourceMappingURL=teams.d.ts.map