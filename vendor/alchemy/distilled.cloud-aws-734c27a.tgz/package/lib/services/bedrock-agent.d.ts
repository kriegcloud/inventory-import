import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Id = string;
export type DraftVersion = string;
export type AgentAliasArn = string;
export interface AgentDescriptor {
    aliasArn?: string | undefined;
}
export type Name = string;
export type CollaborationInstruction = string | redacted.Redacted<string>;
export type RelayConversationHistory = "TO_COLLABORATOR" | "DISABLED" | (string & {});
export type ClientToken = string;
export interface AssociateAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    agentDescriptor: AgentDescriptor;
    collaboratorName: string;
    collaborationInstruction: string | redacted.Redacted<string>;
    relayConversationHistory?: RelayConversationHistory | undefined;
    clientToken?: string | undefined;
}
export type Version = string;
export interface AgentCollaborator {
    agentId: string;
    agentVersion: string;
    agentDescriptor: AgentDescriptor;
    collaboratorId: string;
    collaborationInstruction: string | redacted.Redacted<string>;
    collaboratorName: string;
    createdAt: Date;
    lastUpdatedAt: Date;
    relayConversationHistory?: RelayConversationHistory | undefined;
    clientToken?: string | undefined;
}
export interface AssociateAgentCollaboratorResponse {
    agentCollaborator: AgentCollaborator;
}
export type Description = string;
export type KnowledgeBaseState = "ENABLED" | "DISABLED" | (string & {});
export interface AssociateAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
    description: string;
    knowledgeBaseState?: KnowledgeBaseState | undefined;
}
export interface AgentKnowledgeBase {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
    description: string;
    createdAt: Date;
    updatedAt: Date;
    knowledgeBaseState: KnowledgeBaseState;
}
export interface AssociateAgentKnowledgeBaseResponse {
    agentKnowledgeBase: AgentKnowledgeBase;
}
export type Instruction = string | redacted.Redacted<string>;
export type ModelIdentifier = string;
export type OrchestrationType = "DEFAULT" | "CUSTOM_ORCHESTRATION" | (string & {});
export type LambdaArn = string;
export type OrchestrationExecutor = {
    lambda: string;
};
export interface CustomOrchestration {
    executor?: OrchestrationExecutor | undefined;
}
export type SessionTTL = number;
export type AgentRoleArn = string;
export type KmsKeyArn = string;
export type TagKey = string;
export type TagValue = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type PromptType = "PRE_PROCESSING" | "ORCHESTRATION" | "POST_PROCESSING" | "KNOWLEDGE_BASE_RESPONSE_GENERATION" | "MEMORY_SUMMARIZATION" | (string & {});
export type CreationMode = "DEFAULT" | "OVERRIDDEN" | (string & {});
export type PromptState = "ENABLED" | "DISABLED" | (string & {});
export type BasePromptTemplate = string | redacted.Redacted<string>;
export type Temperature = number;
export type TopP = number;
export type TopK = number;
export type MaximumLength = number;
export type StopSequences = string[];
export interface InferenceConfiguration {
    temperature?: number | undefined;
    topP?: number | undefined;
    topK?: number | undefined;
    maximumLength?: number | undefined;
    stopSequences?: string[] | undefined;
}
export interface PromptConfiguration {
    promptType?: PromptType | undefined;
    promptCreationMode?: CreationMode | undefined;
    promptState?: PromptState | undefined;
    basePromptTemplate?: string | redacted.Redacted<string> | undefined;
    inferenceConfiguration?: InferenceConfiguration | undefined;
    parserMode?: CreationMode | undefined;
    foundationModel?: string | undefined;
    additionalModelRequestFields?: any | undefined;
}
export type PromptConfigurations = PromptConfiguration[];
export interface PromptOverrideConfiguration {
    promptConfigurations: PromptConfiguration[];
    overrideLambda?: string | undefined;
}
export type GuardrailIdentifier = string;
export type GuardrailVersion = string;
export interface GuardrailConfiguration {
    guardrailIdentifier?: string | undefined;
    guardrailVersion?: string | undefined;
}
export type MemoryType = "SESSION_SUMMARY" | (string & {});
export type EnabledMemoryTypes = MemoryType[];
export type StorageDays = number;
export type MaxRecentSessions = number;
export interface SessionSummaryConfiguration {
    maxRecentSessions?: number | undefined;
}
export interface MemoryConfiguration {
    enabledMemoryTypes: MemoryType[];
    storageDays?: number | undefined;
    sessionSummaryConfiguration?: SessionSummaryConfiguration | undefined;
}
export type AgentCollaboration = "SUPERVISOR" | "SUPERVISOR_ROUTER" | "DISABLED" | (string & {});
export interface CreateAgentRequest {
    agentName: string;
    clientToken?: string | undefined;
    instruction?: string | redacted.Redacted<string> | undefined;
    foundationModel?: string | undefined;
    description?: string | undefined;
    orchestrationType?: OrchestrationType | undefined;
    customOrchestration?: CustomOrchestration | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    agentResourceRoleArn?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    promptOverrideConfiguration?: PromptOverrideConfiguration | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    memoryConfiguration?: MemoryConfiguration | undefined;
    agentCollaboration?: AgentCollaboration | undefined;
}
export type AgentArn = string;
export type AgentStatus = "CREATING" | "PREPARING" | "PREPARED" | "NOT_PREPARED" | "DELETING" | "FAILED" | "VERSIONING" | "UPDATING" | (string & {});
export type FailureReason = string;
export type FailureReasons = string[];
export type RecommendedAction = string;
export type RecommendedActions = string[];
export interface Agent {
    agentId: string;
    agentName: string;
    agentArn: string;
    agentVersion?: string | undefined;
    clientToken?: string | undefined;
    instruction?: string | redacted.Redacted<string> | undefined;
    agentStatus: AgentStatus;
    foundationModel?: string | undefined;
    description?: string | undefined;
    orchestrationType?: OrchestrationType | undefined;
    customOrchestration?: CustomOrchestration | undefined;
    idleSessionTTLInSeconds: number;
    agentResourceRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    preparedAt?: Date | undefined;
    failureReasons?: string[] | undefined;
    recommendedActions?: string[] | undefined;
    promptOverrideConfiguration?: PromptOverrideConfiguration | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    memoryConfiguration?: MemoryConfiguration | undefined;
    agentCollaboration?: AgentCollaboration | undefined;
}
export interface CreateAgentResponse {
    agent: Agent;
}
export type ActionGroupSignature = "AMAZON.UserInput" | "AMAZON.CodeInterpreter" | "ANTHROPIC.Computer" | "ANTHROPIC.Bash" | "ANTHROPIC.TextEditor" | (string & {});
export type ActionGroupSignatureParams = {
    [key: string]: string | undefined;
};
export type CustomControlMethod = "RETURN_CONTROL" | (string & {});
export type ActionGroupExecutor = {
    lambda: string;
    customControl?: undefined;
} | {
    lambda?: undefined;
    customControl: CustomControlMethod;
};
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3Identifier {
    s3BucketName?: string | undefined;
    s3ObjectKey?: string | undefined;
}
export type Payload = string | redacted.Redacted<string>;
export type APISchema = {
    s3: S3Identifier;
    payload?: undefined;
} | {
    s3?: undefined;
    payload: string | redacted.Redacted<string>;
};
export type ActionGroupState = "ENABLED" | "DISABLED" | (string & {});
export type FunctionDescription = string;
export type ParameterDescription = string;
export type Type = "string" | "number" | "integer" | "boolean" | "array" | (string & {});
export interface ParameterDetail {
    description?: string | undefined;
    type: Type;
    required?: boolean | undefined;
}
export type ParameterMap = {
    [key: string]: ParameterDetail | undefined;
};
export type RequireConfirmation = "ENABLED" | "DISABLED" | (string & {});
export interface Function {
    name: string;
    description?: string | undefined;
    parameters?: {
        [key: string]: ParameterDetail | undefined;
    } | undefined;
    requireConfirmation?: RequireConfirmation | undefined;
}
export type Functions = Function[];
export type FunctionSchema = {
    functions: Function[];
};
export interface CreateAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupName: string;
    clientToken?: string | undefined;
    description?: string | undefined;
    parentActionGroupSignature?: ActionGroupSignature | undefined;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    } | undefined;
    actionGroupExecutor?: ActionGroupExecutor | undefined;
    apiSchema?: APISchema | undefined;
    actionGroupState?: ActionGroupState | undefined;
    functionSchema?: FunctionSchema | undefined;
}
export interface AgentActionGroup {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
    actionGroupName: string;
    clientToken?: string | undefined;
    description?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    parentActionSignature?: ActionGroupSignature | undefined;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    } | undefined;
    actionGroupExecutor?: ActionGroupExecutor | undefined;
    apiSchema?: APISchema | undefined;
    functionSchema?: FunctionSchema | undefined;
    actionGroupState: ActionGroupState;
}
export interface CreateAgentActionGroupResponse {
    agentActionGroup: AgentActionGroup;
}
export type ProvisionedModelIdentifier = string;
export interface AgentAliasRoutingConfigurationListItem {
    agentVersion?: string | undefined;
    provisionedThroughput?: string | undefined;
}
export type AgentAliasRoutingConfiguration = AgentAliasRoutingConfigurationListItem[];
export interface CreateAgentAliasRequest {
    agentId: string;
    agentAliasName: string;
    clientToken?: string | undefined;
    description?: string | undefined;
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AgentAliasId = string;
export interface AgentAliasHistoryEvent {
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[] | undefined;
    endDate?: Date | undefined;
    startDate?: Date | undefined;
}
export type AgentAliasHistoryEvents = AgentAliasHistoryEvent[];
export type AgentAliasStatus = "CREATING" | "PREPARED" | "FAILED" | "UPDATING" | "DELETING" | "DISSOCIATED" | (string & {});
export type AliasInvocationState = "ACCEPT_INVOCATIONS" | "REJECT_INVOCATIONS" | (string & {});
export interface AgentAlias {
    agentId: string;
    agentAliasId: string;
    agentAliasName: string;
    agentAliasArn: string;
    clientToken?: string | undefined;
    description?: string | undefined;
    routingConfiguration: AgentAliasRoutingConfigurationListItem[];
    createdAt: Date;
    updatedAt: Date;
    agentAliasHistoryEvents?: AgentAliasHistoryEvent[] | undefined;
    agentAliasStatus: AgentAliasStatus;
    failureReasons?: string[] | undefined;
    aliasInvocationState?: AliasInvocationState | undefined;
}
export interface CreateAgentAliasResponse {
    agentAlias: AgentAlias;
}
export type DataSourceType = "S3" | "WEB" | "CONFLUENCE" | "SALESFORCE" | "SHAREPOINT" | "CUSTOM" | "REDSHIFT_METADATA" | "MANAGED_KNOWLEDGE_BASE_CONNECTOR" | (string & {});
export type EnabledOrDisabledState = "ENABLED" | "DISABLED" | (string & {});
export interface DeletionProtectionConfiguration {
    deletionProtectionStatus: EnabledOrDisabledState;
    deletionProtectionThreshold?: number | undefined;
}
export interface ImageExtractionConfiguration {
    imageExtractionStatus: EnabledOrDisabledState;
}
export interface AudioExtractionConfiguration {
    audioExtractionStatus: EnabledOrDisabledState;
}
export interface VideoExtractionConfiguration {
    videoExtractionStatus: EnabledOrDisabledState;
}
export interface MediaExtractionConfiguration {
    imageExtractionConfiguration?: ImageExtractionConfiguration | undefined;
    audioExtractionConfiguration?: AudioExtractionConfiguration | undefined;
    videoExtractionConfiguration?: VideoExtractionConfiguration | undefined;
}
export interface DailySchedule {
}
export type DayOfWeek = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export interface WeeklySchedule {
    dayOfWeek: DayOfWeek;
}
export type DayOfMonthNumber = number;
export interface LastDayOfMonth {
}
export type DayOfMonth = {
    dayNumber: number;
    lastDayOfMonth?: undefined;
} | {
    dayNumber?: undefined;
    lastDayOfMonth: LastDayOfMonth;
};
export interface MonthlySchedule {
    dayOfMonth: DayOfMonth;
}
export type SyncSchedule = {
    daily: DailySchedule;
    weekly?: undefined;
    monthly?: undefined;
} | {
    daily?: undefined;
    weekly: WeeklySchedule;
    monthly?: undefined;
} | {
    daily?: undefined;
    weekly?: undefined;
    monthly: MonthlySchedule;
};
export interface ManagedKnowledgeBaseConnectorConfiguration {
    deletionProtectionConfiguration?: DeletionProtectionConfiguration | undefined;
    mediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
    connectorParameters?: any | undefined;
    syncSchedule?: SyncSchedule | undefined;
}
export type S3BucketArn = string;
export type S3Prefix = string | redacted.Redacted<string>;
export type S3Prefixes = (string | redacted.Redacted<string>)[];
export type BucketOwnerAccountId = string;
export interface S3DataSourceConfiguration {
    bucketArn: string;
    inclusionPrefixes?: (string | redacted.Redacted<string>)[] | undefined;
    bucketOwnerAccountId?: string | undefined;
}
export type Url = string;
export interface SeedUrl {
    url?: string | undefined;
}
export type SeedUrls = SeedUrl[];
export interface UrlConfiguration {
    seedUrls?: SeedUrl[] | undefined;
}
export interface WebSourceConfiguration {
    urlConfiguration: UrlConfiguration;
}
export interface WebCrawlerLimits {
    rateLimit?: number | undefined;
    maxPages?: number | undefined;
}
export type FilterPattern = string | redacted.Redacted<string>;
export type FilterList = (string | redacted.Redacted<string>)[];
export type WebScopeType = "HOST_ONLY" | "SUBDOMAINS" | (string & {});
export type UserAgent = string | redacted.Redacted<string>;
export type UserAgentHeader = string | redacted.Redacted<string>;
export interface WebCrawlerConfiguration {
    crawlerLimits?: WebCrawlerLimits | undefined;
    inclusionFilters?: (string | redacted.Redacted<string>)[] | undefined;
    exclusionFilters?: (string | redacted.Redacted<string>)[] | undefined;
    scope?: WebScopeType | undefined;
    userAgent?: string | redacted.Redacted<string> | undefined;
    userAgentHeader?: string | redacted.Redacted<string> | undefined;
}
export interface WebDataSourceConfiguration {
    sourceConfiguration: WebSourceConfiguration;
    crawlerConfiguration?: WebCrawlerConfiguration | undefined;
}
export type HttpsUrl = string;
export type ConfluenceHostType = "SAAS" | (string & {});
export type ConfluenceAuthType = "BASIC" | "OAUTH2_CLIENT_CREDENTIALS" | (string & {});
export type SecretArn = string;
export interface ConfluenceSourceConfiguration {
    hostUrl: string;
    hostType: ConfluenceHostType;
    authType: ConfluenceAuthType;
    credentialsSecretArn: string;
}
export type CrawlFilterConfigurationType = "PATTERN" | (string & {});
export type FilteredObjectType = string | redacted.Redacted<string>;
export interface PatternObjectFilter {
    objectType: string | redacted.Redacted<string>;
    inclusionFilters?: (string | redacted.Redacted<string>)[] | undefined;
    exclusionFilters?: (string | redacted.Redacted<string>)[] | undefined;
}
export type PatternObjectFilterList = PatternObjectFilter[];
export interface PatternObjectFilterConfiguration {
    filters: PatternObjectFilter[];
}
export interface CrawlFilterConfiguration {
    type: CrawlFilterConfigurationType;
    patternObjectFilter?: PatternObjectFilterConfiguration | undefined;
}
export interface ConfluenceCrawlerConfiguration {
    filterConfiguration?: CrawlFilterConfiguration | undefined;
}
export interface ConfluenceDataSourceConfiguration {
    sourceConfiguration: ConfluenceSourceConfiguration;
    crawlerConfiguration?: ConfluenceCrawlerConfiguration | undefined;
}
export type SalesforceAuthType = "OAUTH2_CLIENT_CREDENTIALS" | (string & {});
export interface SalesforceSourceConfiguration {
    hostUrl: string;
    authType: SalesforceAuthType;
    credentialsSecretArn: string;
}
export interface SalesforceCrawlerConfiguration {
    filterConfiguration?: CrawlFilterConfiguration | undefined;
}
export interface SalesforceDataSourceConfiguration {
    sourceConfiguration: SalesforceSourceConfiguration;
    crawlerConfiguration?: SalesforceCrawlerConfiguration | undefined;
}
export type Microsoft365TenantId = string;
export type SharePointDomain = string;
export type SharePointSiteUrls = string[];
export type SharePointHostType = "ONLINE" | (string & {});
export type SharePointAuthType = "OAUTH2_CLIENT_CREDENTIALS" | "OAUTH2_SHAREPOINT_APP_ONLY_CLIENT_CREDENTIALS" | (string & {});
export interface SharePointSourceConfiguration {
    tenantId?: string | undefined;
    domain: string;
    siteUrls: string[];
    hostType: SharePointHostType;
    authType: SharePointAuthType;
    credentialsSecretArn: string;
}
export interface SharePointCrawlerConfiguration {
    filterConfiguration?: CrawlFilterConfiguration | undefined;
}
export interface SharePointDataSourceConfiguration {
    sourceConfiguration: SharePointSourceConfiguration;
    crawlerConfiguration?: SharePointCrawlerConfiguration | undefined;
}
export interface DataSourceConfiguration {
    type: DataSourceType;
    managedKnowledgeBaseConnectorConfiguration?: ManagedKnowledgeBaseConnectorConfiguration | undefined;
    s3Configuration?: S3DataSourceConfiguration | undefined;
    webConfiguration?: WebDataSourceConfiguration | undefined;
    confluenceConfiguration?: ConfluenceDataSourceConfiguration | undefined;
    salesforceConfiguration?: SalesforceDataSourceConfiguration | undefined;
    sharePointConfiguration?: SharePointDataSourceConfiguration | undefined;
}
export type DataDeletionPolicy = "RETAIN" | "DELETE" | (string & {});
export interface ServerSideEncryptionConfiguration {
    kmsKeyArn?: string | undefined;
}
export type ChunkingStrategy = "FIXED_SIZE" | "NONE" | "HIERARCHICAL" | "SEMANTIC" | (string & {});
export interface FixedSizeChunkingConfiguration {
    maxTokens: number;
    overlapPercentage: number;
}
export interface HierarchicalChunkingLevelConfiguration {
    maxTokens: number;
}
export type HierarchicalChunkingLevelConfigurations = HierarchicalChunkingLevelConfiguration[];
export interface HierarchicalChunkingConfiguration {
    levelConfigurations: HierarchicalChunkingLevelConfiguration[];
    overlapTokens: number;
}
export interface SemanticChunkingConfiguration {
    maxTokens: number;
    bufferSize: number;
    breakpointPercentileThreshold: number;
}
export interface ChunkingConfiguration {
    chunkingStrategy: ChunkingStrategy;
    fixedSizeChunkingConfiguration?: FixedSizeChunkingConfiguration | undefined;
    hierarchicalChunkingConfiguration?: HierarchicalChunkingConfiguration | undefined;
    semanticChunkingConfiguration?: SemanticChunkingConfiguration | undefined;
}
export type S3BucketUri = string;
export interface S3Location {
    uri: string;
}
export interface IntermediateStorage {
    s3Location: S3Location;
}
export interface TransformationLambdaConfiguration {
    lambdaArn: string;
}
export interface TransformationFunction {
    transformationLambdaConfiguration: TransformationLambdaConfiguration;
}
export type StepType = "POST_CHUNKING" | (string & {});
export interface Transformation {
    transformationFunction: TransformationFunction;
    stepToApply: StepType;
}
export type Transformations = Transformation[];
export interface CustomTransformationConfiguration {
    intermediateStorage: IntermediateStorage;
    transformations: Transformation[];
}
export type ParsingStrategy = "BEDROCK_FOUNDATION_MODEL" | "BEDROCK_DATA_AUTOMATION" | "SMART_PARSING" | "MULTI_MODAL_EMBEDDINGS" | (string & {});
export type BedrockModelArn = string;
export type ParsingPromptText = string;
export interface ParsingPrompt {
    parsingPromptText: string;
}
export type ParsingModality = "MULTIMODAL" | (string & {});
export interface BedrockFoundationModelConfiguration {
    modelArn: string;
    parsingPrompt?: ParsingPrompt | undefined;
    parsingModality?: ParsingModality | undefined;
}
export interface BedrockDataAutomationConfiguration {
    parsingModality?: ParsingModality | undefined;
}
export interface ParsingConfiguration {
    parsingStrategy: ParsingStrategy;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelConfiguration | undefined;
    bedrockDataAutomationConfiguration?: BedrockDataAutomationConfiguration | undefined;
}
export type ContextEnrichmentType = "BEDROCK_FOUNDATION_MODEL" | (string & {});
export type EnrichmentStrategyMethod = "CHUNK_ENTITY_EXTRACTION" | (string & {});
export interface EnrichmentStrategyConfiguration {
    method: EnrichmentStrategyMethod;
}
export interface BedrockFoundationModelContextEnrichmentConfiguration {
    enrichmentStrategyConfiguration: EnrichmentStrategyConfiguration;
    modelArn: string;
}
export interface ContextEnrichmentConfiguration {
    type: ContextEnrichmentType;
    bedrockFoundationModelConfiguration?: BedrockFoundationModelContextEnrichmentConfiguration | undefined;
}
export interface VectorIngestionConfiguration {
    chunkingConfiguration?: ChunkingConfiguration | undefined;
    customTransformationConfiguration?: CustomTransformationConfiguration | undefined;
    parsingConfiguration?: ParsingConfiguration | undefined;
    contextEnrichmentConfiguration?: ContextEnrichmentConfiguration | undefined;
}
export interface CreateDataSourceRequest {
    knowledgeBaseId: string;
    clientToken?: string | undefined;
    name: string;
    description?: string | undefined;
    dataSourceConfiguration: DataSourceConfiguration;
    dataDeletionPolicy?: DataDeletionPolicy | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    vectorIngestionConfiguration?: VectorIngestionConfiguration | undefined;
}
export type DataSourceStatus = "AVAILABLE" | "DELETING" | "DELETE_UNSUCCESSFUL" | "CREATING" | "UPDATING" | "FAILED" | (string & {});
export interface DataSource {
    knowledgeBaseId: string;
    dataSourceId: string;
    name: string;
    status: DataSourceStatus;
    description?: string | undefined;
    dataSourceConfiguration: DataSourceConfiguration;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    vectorIngestionConfiguration?: VectorIngestionConfiguration | undefined;
    dataDeletionPolicy?: DataDeletionPolicy | undefined;
    createdAt: Date;
    updatedAt: Date;
    failureReasons?: string[] | undefined;
}
export interface CreateDataSourceResponse {
    dataSource: DataSource;
}
export type FlowName = string;
export type FlowDescription = string;
export type FlowExecutionRoleArn = string;
export type FlowNodeName = string;
export type FlowNodeType = "Input" | "Output" | "KnowledgeBase" | "Condition" | "Lex" | "Prompt" | "LambdaFunction" | "Storage" | "Agent" | "Retrieval" | "Iterator" | "Collector" | "InlineCode" | "Loop" | "LoopInput" | "LoopController" | (string & {});
export interface InputFlowNodeConfiguration {
}
export interface OutputFlowNodeConfiguration {
}
export type FlowKnowledgeBaseId = string;
export type KnowledgeBaseModelIdentifier = string;
export type KnowledgeBaseTextPrompt = string | redacted.Redacted<string>;
export interface KnowledgeBasePromptTemplate {
    textPromptTemplate?: string | redacted.Redacted<string> | undefined;
}
export interface PromptModelInferenceConfiguration {
    temperature?: number | undefined;
    topP?: number | undefined;
    maxTokens?: number | undefined;
    stopSequences?: string[] | undefined;
}
export type PromptInferenceConfiguration = {
    text: PromptModelInferenceConfiguration;
};
export type VectorSearchRerankingConfigurationType = "BEDROCK_RERANKING_MODEL" | (string & {});
export type BedrockRerankingModelArn = string;
export type AdditionalModelRequestFieldsKey = string;
export type AdditionalModelRequestFieldsValue = unknown;
export type AdditionalModelRequestFields = {
    [key: string]: any | undefined;
};
export interface VectorSearchBedrockRerankingModelConfiguration {
    modelArn: string;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type RerankingMetadataSelectionMode = "SELECTIVE" | "ALL" | (string & {});
export interface FieldForReranking {
    fieldName: string;
}
export type FieldsForReranking = FieldForReranking[];
export type RerankingMetadataSelectiveModeConfiguration = {
    fieldsToInclude: FieldForReranking[];
    fieldsToExclude?: undefined;
} | {
    fieldsToInclude?: undefined;
    fieldsToExclude: FieldForReranking[];
};
export interface MetadataConfigurationForReranking {
    selectionMode: RerankingMetadataSelectionMode;
    selectiveModeConfiguration?: RerankingMetadataSelectiveModeConfiguration | undefined;
}
export interface VectorSearchBedrockRerankingConfiguration {
    modelConfiguration: VectorSearchBedrockRerankingModelConfiguration;
    numberOfRerankedResults?: number | undefined;
    metadataConfiguration?: MetadataConfigurationForReranking | undefined;
}
export interface VectorSearchRerankingConfiguration {
    type: VectorSearchRerankingConfigurationType;
    bedrockRerankingConfiguration?: VectorSearchBedrockRerankingConfiguration | undefined;
}
export type PerformanceConfigLatency = "standard" | "optimized" | (string & {});
export interface PerformanceConfiguration {
    latency?: PerformanceConfigLatency | undefined;
}
export interface KnowledgeBaseOrchestrationConfiguration {
    promptTemplate?: KnowledgeBasePromptTemplate | undefined;
    inferenceConfig?: PromptInferenceConfiguration | undefined;
    additionalModelRequestFields?: {
        [key: string]: any | undefined;
    } | undefined;
    performanceConfig?: PerformanceConfiguration | undefined;
}
export interface KnowledgeBaseFlowNodeConfiguration {
    knowledgeBaseId: string;
    modelId?: string | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    numberOfResults?: number | undefined;
    promptTemplate?: KnowledgeBasePromptTemplate | undefined;
    inferenceConfiguration?: PromptInferenceConfiguration | undefined;
    rerankingConfiguration?: VectorSearchRerankingConfiguration | undefined;
    orchestrationConfiguration?: KnowledgeBaseOrchestrationConfiguration | undefined;
}
export type FlowConditionName = string;
export type FlowConditionExpression = string | redacted.Redacted<string>;
export interface FlowCondition {
    name: string;
    expression?: string | redacted.Redacted<string> | undefined;
}
export type FlowConditions = FlowCondition[];
export interface ConditionFlowNodeConfiguration {
    conditions: FlowCondition[];
}
export type FlowLexBotAliasArn = string;
export type FlowLexBotLocaleId = string;
export interface LexFlowNodeConfiguration {
    botAliasArn: string;
    localeId: string;
}
export type FlowPromptArn = string;
export interface PromptFlowNodeResourceConfiguration {
    promptArn: string;
}
export type PromptTemplateType = "TEXT" | "CHAT" | (string & {});
export type TextPrompt = string | redacted.Redacted<string>;
export type CachePointType = "default" | (string & {});
export interface CachePointBlock {
    type: CachePointType;
}
export type PromptInputVariableName = string;
export interface PromptInputVariable {
    name?: string | undefined;
}
export type PromptInputVariablesList = PromptInputVariable[];
export interface TextPromptTemplateConfiguration {
    text: string | redacted.Redacted<string>;
    cachePoint?: CachePointBlock | undefined;
    inputVariables?: PromptInputVariable[] | undefined;
}
export type ConversationRole = "user" | "assistant" | (string & {});
export type ContentBlock = {
    text: string;
    cachePoint?: undefined;
} | {
    text?: undefined;
    cachePoint: CachePointBlock;
};
export type ContentBlocks = ContentBlock[];
export interface Message {
    role: ConversationRole;
    content: ContentBlock[];
}
export type Messages = Message[];
export type NonEmptyString = string;
export type SystemContentBlock = {
    text: string;
    cachePoint?: undefined;
} | {
    text?: undefined;
    cachePoint: CachePointBlock;
};
export type SystemContentBlocks = SystemContentBlock[];
export type ToolName = string;
export type ToolInputSchema = {
    json: any;
};
export interface ToolSpecification {
    name: string;
    description?: string | undefined;
    inputSchema: ToolInputSchema;
    strict?: boolean | undefined;
}
export type Tool = {
    toolSpec: ToolSpecification;
    cachePoint?: undefined;
} | {
    toolSpec?: undefined;
    cachePoint: CachePointBlock;
};
export type Tools = Tool[];
export interface AutoToolChoice {
}
export interface AnyToolChoice {
}
export interface SpecificToolChoice {
    name: string;
}
export type ToolChoice = {
    auto: AutoToolChoice;
    any?: undefined;
    tool?: undefined;
} | {
    auto?: undefined;
    any: AnyToolChoice;
    tool?: undefined;
} | {
    auto?: undefined;
    any?: undefined;
    tool: SpecificToolChoice;
};
export interface ToolConfiguration {
    tools: Tool[];
    toolChoice?: ToolChoice | undefined;
}
export interface ChatPromptTemplateConfiguration {
    messages: Message[];
    system?: SystemContentBlock[] | undefined;
    inputVariables?: PromptInputVariable[] | undefined;
    toolConfiguration?: ToolConfiguration | undefined;
}
export type PromptTemplateConfiguration = {
    text: TextPromptTemplateConfiguration;
    chat?: undefined;
} | {
    text?: undefined;
    chat: ChatPromptTemplateConfiguration;
};
export type FlowPromptModelIdentifier = string;
export interface PromptFlowNodeInlineConfiguration {
    templateType: PromptTemplateType;
    templateConfiguration: PromptTemplateConfiguration;
    modelId: string;
    inferenceConfiguration?: PromptInferenceConfiguration | undefined;
    additionalModelRequestFields?: any | undefined;
}
export type PromptFlowNodeSourceConfiguration = {
    resource: PromptFlowNodeResourceConfiguration;
    inline?: undefined;
} | {
    resource?: undefined;
    inline: PromptFlowNodeInlineConfiguration;
};
export interface PromptFlowNodeConfiguration {
    sourceConfiguration: PromptFlowNodeSourceConfiguration;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
}
export type FlowLambdaArn = string;
export interface LambdaFunctionFlowNodeConfiguration {
    lambdaArn: string;
}
export type FlowS3BucketName = string;
export interface StorageFlowNodeS3Configuration {
    bucketName: string;
}
export type StorageFlowNodeServiceConfiguration = {
    s3: StorageFlowNodeS3Configuration;
};
export interface StorageFlowNodeConfiguration {
    serviceConfiguration: StorageFlowNodeServiceConfiguration;
}
export type FlowAgentAliasArn = string;
export interface AgentFlowNodeConfiguration {
    agentAliasArn: string;
}
export interface RetrievalFlowNodeS3Configuration {
    bucketName: string;
}
export type RetrievalFlowNodeServiceConfiguration = {
    s3: RetrievalFlowNodeS3Configuration;
};
export interface RetrievalFlowNodeConfiguration {
    serviceConfiguration: RetrievalFlowNodeServiceConfiguration;
}
export interface IteratorFlowNodeConfiguration {
}
export interface CollectorFlowNodeConfiguration {
}
export type InlineCode = string | redacted.Redacted<string>;
export type SupportedLanguages = "Python_3" | (string & {});
export interface InlineCodeFlowNodeConfiguration {
    code: string | redacted.Redacted<string>;
    language: SupportedLanguages;
}
export interface LoopFlowNodeConfiguration {
    definition: FlowDefinition;
}
export interface LoopInputFlowNodeConfiguration {
}
export interface LoopControllerFlowNodeConfiguration {
    continueCondition: FlowCondition;
    maxIterations?: number | undefined;
}
export type FlowNodeConfiguration = {
    input: InputFlowNodeConfiguration;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output: OutputFlowNodeConfiguration;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase: KnowledgeBaseFlowNodeConfiguration;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition: ConditionFlowNodeConfiguration;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex: LexFlowNodeConfiguration;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt: PromptFlowNodeConfiguration;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction: LambdaFunctionFlowNodeConfiguration;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage: StorageFlowNodeConfiguration;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent: AgentFlowNodeConfiguration;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval: RetrievalFlowNodeConfiguration;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator: IteratorFlowNodeConfiguration;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector: CollectorFlowNodeConfiguration;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode: InlineCodeFlowNodeConfiguration;
    loop?: undefined;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop: LoopFlowNodeConfiguration;
    loopInput?: undefined;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput: LoopInputFlowNodeConfiguration;
    loopController?: undefined;
} | {
    input?: undefined;
    output?: undefined;
    knowledgeBase?: undefined;
    condition?: undefined;
    lex?: undefined;
    prompt?: undefined;
    lambdaFunction?: undefined;
    storage?: undefined;
    agent?: undefined;
    retrieval?: undefined;
    iterator?: undefined;
    collector?: undefined;
    inlineCode?: undefined;
    loop?: undefined;
    loopInput?: undefined;
    loopController: LoopControllerFlowNodeConfiguration;
};
export type FlowNodeInputName = string;
export type FlowNodeIODataType = "String" | "Number" | "Boolean" | "Object" | "Array" | (string & {});
export type FlowNodeInputExpression = string | redacted.Redacted<string>;
export type FlowNodeInputCategory = "LoopCondition" | "ReturnValueToLoopStart" | "ExitLoop" | (string & {});
export interface FlowNodeInput {
    name: string;
    type: FlowNodeIODataType;
    expression: string | redacted.Redacted<string>;
    category?: FlowNodeInputCategory | undefined;
}
export type FlowNodeInputs = FlowNodeInput[];
export type FlowNodeOutputName = string;
export interface FlowNodeOutput {
    name: string;
    type: FlowNodeIODataType;
}
export type FlowNodeOutputs = FlowNodeOutput[];
export interface FlowNode {
    name: string;
    type: FlowNodeType;
    configuration?: FlowNodeConfiguration | undefined;
    inputs?: FlowNodeInput[] | undefined;
    outputs?: FlowNodeOutput[] | undefined;
}
export type FlowNodes = FlowNode[];
export type FlowConnectionType = "Data" | "Conditional" | (string & {});
export type FlowConnectionName = string;
export interface FlowDataConnectionConfiguration {
    sourceOutput: string;
    targetInput: string;
}
export interface FlowConditionalConnectionConfiguration {
    condition: string;
}
export type FlowConnectionConfiguration = {
    data: FlowDataConnectionConfiguration;
    conditional?: undefined;
} | {
    data?: undefined;
    conditional: FlowConditionalConnectionConfiguration;
};
export interface FlowConnection {
    type: FlowConnectionType;
    name: string;
    source: string;
    target: string;
    configuration?: FlowConnectionConfiguration | undefined;
}
export type FlowConnections = FlowConnection[];
export interface FlowDefinition {
    nodes?: FlowNode[] | undefined;
    connections?: FlowConnection[] | undefined;
}
export interface CreateFlowRequest {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    definition?: FlowDefinition | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FlowId = string;
export type FlowArn = string;
export type FlowStatus = "Failed" | "Prepared" | "Preparing" | "NotPrepared" | (string & {});
export interface CreateFlowResponse {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
    definition?: FlowDefinition | undefined;
}
export interface FlowAliasRoutingConfigurationListItem {
    flowVersion?: string | undefined;
}
export type FlowAliasRoutingConfiguration = FlowAliasRoutingConfigurationListItem[];
export type ConcurrencyType = "Automatic" | "Manual" | (string & {});
export interface FlowAliasConcurrencyConfiguration {
    type: ConcurrencyType;
    maxConcurrency?: number | undefined;
}
export type FlowIdentifier = string;
export interface CreateFlowAliasRequest {
    name: string;
    description?: string | undefined;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration | undefined;
    flowIdentifier: string;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FlowAliasId = string;
export type FlowAliasArn = string;
export interface CreateFlowAliasResponse {
    name: string;
    description?: string | undefined;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration | undefined;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateFlowVersionRequest {
    flowIdentifier: string;
    description?: string | undefined;
    clientToken?: string | undefined;
}
export type NumericalVersion = string;
export interface CreateFlowVersionResponse {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    version: string;
    definition?: FlowDefinition | undefined;
}
export type KnowledgeBaseRoleArn = string;
export type KnowledgeBaseType = "VECTOR" | "KENDRA" | "SQL" | "MANAGED" | (string & {});
export type BedrockEmbeddingModelArn = string;
export type Dimensions = number;
export type EmbeddingDataType = "FLOAT32" | "BINARY" | (string & {});
export interface AudioSegmentationConfiguration {
    fixedLengthDuration: number;
}
export interface AudioConfiguration {
    segmentationConfiguration: AudioSegmentationConfiguration;
}
export type AudioConfigurations = AudioConfiguration[];
export interface VideoSegmentationConfiguration {
    fixedLengthDuration: number;
}
export interface VideoConfiguration {
    segmentationConfiguration: VideoSegmentationConfiguration;
}
export type VideoConfigurations = VideoConfiguration[];
export interface BedrockEmbeddingModelConfiguration {
    dimensions?: number | undefined;
    embeddingDataType?: EmbeddingDataType | undefined;
    audio?: AudioConfiguration[] | undefined;
    video?: VideoConfiguration[] | undefined;
    modelConfiguration?: any | undefined;
}
export interface EmbeddingModelConfiguration {
    bedrockEmbeddingModelConfiguration?: BedrockEmbeddingModelConfiguration | undefined;
}
export type SupplementalDataStorageLocationType = "S3" | (string & {});
export interface SupplementalDataStorageLocation {
    type: SupplementalDataStorageLocationType;
    s3Location?: S3Location | undefined;
}
export type SupplementalDataStorageLocations = SupplementalDataStorageLocation[];
export interface SupplementalDataStorageConfiguration {
    storageLocations: SupplementalDataStorageLocation[];
}
export interface VectorKnowledgeBaseConfiguration {
    embeddingModelArn: string;
    embeddingModelConfiguration?: EmbeddingModelConfiguration | undefined;
    supplementalDataStorageConfiguration?: SupplementalDataStorageConfiguration | undefined;
}
export type EmbeddingModelType = "CUSTOM" | "MANAGED" | (string & {});
export interface ManagedKnowledgeBaseConfiguration {
    embeddingModelType?: EmbeddingModelType | undefined;
    embeddingModelArn?: string | undefined;
    embeddingModelConfiguration?: EmbeddingModelConfiguration | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    supplementalDataStorageConfiguration?: SupplementalDataStorageConfiguration | undefined;
}
export type KendraIndexArn = string;
export interface KendraKnowledgeBaseConfiguration {
    kendraIndexArn: string;
}
export type QueryEngineType = "REDSHIFT" | (string & {});
export type RedshiftQueryEngineStorageType = "REDSHIFT" | "AWS_DATA_CATALOG" | (string & {});
export type AwsDataCatalogTableName = string;
export type AwsDataCatalogTableNames = string[];
export interface RedshiftQueryEngineAwsDataCatalogStorageConfiguration {
    tableNames: string[];
}
export type RedshiftDatabase = string;
export interface RedshiftQueryEngineRedshiftStorageConfiguration {
    databaseName: string;
}
export interface RedshiftQueryEngineStorageConfiguration {
    type: RedshiftQueryEngineStorageType;
    awsDataCatalogConfiguration?: RedshiftQueryEngineAwsDataCatalogStorageConfiguration | undefined;
    redshiftConfiguration?: RedshiftQueryEngineRedshiftStorageConfiguration | undefined;
}
export type RedshiftQueryEngineStorageConfigurations = RedshiftQueryEngineStorageConfiguration[];
export type RedshiftQueryEngineType = "SERVERLESS" | "PROVISIONED" | (string & {});
export type WorkgroupArn = string;
export type RedshiftServerlessAuthType = "IAM" | "USERNAME_PASSWORD" | (string & {});
export interface RedshiftServerlessAuthConfiguration {
    type: RedshiftServerlessAuthType;
    usernamePasswordSecretArn?: string | undefined;
}
export interface RedshiftServerlessConfiguration {
    workgroupArn: string;
    authConfiguration: RedshiftServerlessAuthConfiguration;
}
export type RedshiftClusterIdentifier = string;
export type RedshiftProvisionedAuthType = "IAM" | "USERNAME_PASSWORD" | "USERNAME" | (string & {});
export interface RedshiftProvisionedAuthConfiguration {
    type: RedshiftProvisionedAuthType;
    databaseUser?: string | undefined;
    usernamePasswordSecretArn?: string | undefined;
}
export interface RedshiftProvisionedConfiguration {
    clusterIdentifier: string;
    authConfiguration: RedshiftProvisionedAuthConfiguration;
}
export interface RedshiftQueryEngineConfiguration {
    type: RedshiftQueryEngineType;
    serverlessConfiguration?: RedshiftServerlessConfiguration | undefined;
    provisionedConfiguration?: RedshiftProvisionedConfiguration | undefined;
}
export type QueryExecutionTimeoutSeconds = number;
export type QueryGenerationTableName = string;
export type DescriptionString = string;
export type IncludeExclude = "INCLUDE" | "EXCLUDE" | (string & {});
export type QueryGenerationColumnName = string;
export interface QueryGenerationColumn {
    name?: string | undefined;
    description?: string | undefined;
    inclusion?: IncludeExclude | undefined;
}
export type QueryGenerationColumns = QueryGenerationColumn[];
export interface QueryGenerationTable {
    name: string;
    description?: string | undefined;
    inclusion?: IncludeExclude | undefined;
    columns?: QueryGenerationColumn[] | undefined;
}
export type QueryGenerationTables = QueryGenerationTable[];
export type NaturalLanguageString = string;
export type SqlString = string;
export interface CuratedQuery {
    naturalLanguage: string;
    sql: string;
}
export type CuratedQueries = CuratedQuery[];
export interface QueryGenerationContext {
    tables?: QueryGenerationTable[] | undefined;
    curatedQueries?: CuratedQuery[] | undefined;
}
export interface QueryGenerationConfiguration {
    executionTimeoutSeconds?: number | undefined;
    generationContext?: QueryGenerationContext | undefined;
}
export interface RedshiftConfiguration {
    storageConfigurations: RedshiftQueryEngineStorageConfiguration[];
    queryEngineConfiguration: RedshiftQueryEngineConfiguration;
    queryGenerationConfiguration?: QueryGenerationConfiguration | undefined;
}
export interface SqlKnowledgeBaseConfiguration {
    type: QueryEngineType;
    redshiftConfiguration?: RedshiftConfiguration | undefined;
}
export interface KnowledgeBaseConfiguration {
    type: KnowledgeBaseType;
    vectorKnowledgeBaseConfiguration?: VectorKnowledgeBaseConfiguration | undefined;
    managedKnowledgeBaseConfiguration?: ManagedKnowledgeBaseConfiguration | undefined;
    kendraKnowledgeBaseConfiguration?: KendraKnowledgeBaseConfiguration | undefined;
    sqlKnowledgeBaseConfiguration?: SqlKnowledgeBaseConfiguration | undefined;
}
export type KnowledgeBaseStorageType = "OPENSEARCH_SERVERLESS" | "PINECONE" | "REDIS_ENTERPRISE_CLOUD" | "RDS" | "MONGO_DB_ATLAS" | "NEPTUNE_ANALYTICS" | "OPENSEARCH_MANAGED_CLUSTER" | "S3_VECTORS" | (string & {});
export type OpenSearchServerlessCollectionArn = string;
export type OpenSearchServerlessIndexName = string;
export type FieldName = string;
export interface OpenSearchServerlessFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export interface OpenSearchServerlessConfiguration {
    collectionArn: string;
    vectorIndexName: string;
    fieldMapping: OpenSearchServerlessFieldMapping;
}
export type OpenSearchManagedClusterDomainEndpoint = string;
export type OpenSearchManagedClusterDomainArn = string;
export type OpenSearchManagedClusterIndexName = string | redacted.Redacted<string>;
export interface OpenSearchManagedClusterFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export interface OpenSearchManagedClusterConfiguration {
    domainEndpoint: string;
    domainArn: string;
    vectorIndexName: string | redacted.Redacted<string>;
    fieldMapping: OpenSearchManagedClusterFieldMapping;
}
export type PineconeConnectionString = string;
export type PineconeNamespace = string;
export interface PineconeFieldMapping {
    textField: string;
    metadataField: string;
}
export interface PineconeConfiguration {
    connectionString: string;
    credentialsSecretArn: string;
    namespace?: string | undefined;
    fieldMapping: PineconeFieldMapping;
}
export type RedisEnterpriseCloudEndpoint = string;
export type RedisEnterpriseCloudIndexName = string;
export interface RedisEnterpriseCloudFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export interface RedisEnterpriseCloudConfiguration {
    endpoint: string;
    vectorIndexName: string;
    credentialsSecretArn: string;
    fieldMapping: RedisEnterpriseCloudFieldMapping;
}
export type RdsArn = string;
export type RdsDatabaseName = string;
export type RdsTableName = string;
export type ColumnName = string;
export interface RdsFieldMapping {
    primaryKeyField: string;
    vectorField: string;
    textField: string;
    metadataField: string;
    customMetadataField?: string | undefined;
}
export interface RdsConfiguration {
    resourceArn: string;
    credentialsSecretArn: string;
    databaseName: string;
    tableName: string;
    fieldMapping: RdsFieldMapping;
}
export type MongoDbAtlasEndpoint = string;
export type MongoDbAtlasDatabaseName = string;
export type MongoDbAtlasCollectionName = string;
export type MongoDbAtlasIndexName = string;
export interface MongoDbAtlasFieldMapping {
    vectorField: string;
    textField: string;
    metadataField: string;
}
export type MongoDbAtlasEndpointServiceName = string;
export interface MongoDbAtlasConfiguration {
    endpoint: string;
    databaseName: string;
    collectionName: string;
    vectorIndexName: string;
    credentialsSecretArn: string;
    fieldMapping: MongoDbAtlasFieldMapping;
    endpointServiceName?: string | undefined;
    textIndexName?: string | undefined;
}
export type GraphArn = string | redacted.Redacted<string>;
export interface NeptuneAnalyticsFieldMapping {
    textField: string;
    metadataField: string;
}
export interface NeptuneAnalyticsConfiguration {
    graphArn: string | redacted.Redacted<string>;
    fieldMapping: NeptuneAnalyticsFieldMapping;
}
export type VectorBucketArn = string | redacted.Redacted<string>;
export type IndexArn = string | redacted.Redacted<string>;
export type IndexName = string | redacted.Redacted<string>;
export interface S3VectorsConfiguration {
    vectorBucketArn?: string | redacted.Redacted<string> | undefined;
    indexArn?: string | redacted.Redacted<string> | undefined;
    indexName?: string | redacted.Redacted<string> | undefined;
}
export interface StorageConfiguration {
    type: KnowledgeBaseStorageType;
    opensearchServerlessConfiguration?: OpenSearchServerlessConfiguration | undefined;
    opensearchManagedClusterConfiguration?: OpenSearchManagedClusterConfiguration | undefined;
    pineconeConfiguration?: PineconeConfiguration | undefined;
    redisEnterpriseCloudConfiguration?: RedisEnterpriseCloudConfiguration | undefined;
    rdsConfiguration?: RdsConfiguration | undefined;
    mongoDbAtlasConfiguration?: MongoDbAtlasConfiguration | undefined;
    neptuneAnalyticsConfiguration?: NeptuneAnalyticsConfiguration | undefined;
    s3VectorsConfiguration?: S3VectorsConfiguration | undefined;
}
export interface CreateKnowledgeBaseRequest {
    clientToken?: string | undefined;
    name: string;
    description?: string | undefined;
    roleArn: string;
    knowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    storageConfiguration?: StorageConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type KnowledgeBaseArn = string;
export type KnowledgeBaseStatus = "CREATING" | "ACTIVE" | "DELETING" | "UPDATING" | "FAILED" | "DELETE_UNSUCCESSFUL" | "UPDATE_UNSUCCESSFUL" | (string & {});
export type MetadataKeyName = string | redacted.Redacted<string>;
export type FieldType = "STRING" | "STRING_LIST" | (string & {});
export type SearchableStatus = "ENABLED" | "DISABLED" | (string & {});
export interface MetadataConfiguration {
    name: string | redacted.Redacted<string>;
    type: FieldType;
    searchability: SearchableStatus;
}
export type MetadataConfigurations = MetadataConfiguration[];
export interface KnowledgeBase {
    knowledgeBaseId: string;
    name: string;
    knowledgeBaseArn: string;
    description?: string | undefined;
    roleArn: string;
    knowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    storageConfiguration?: StorageConfiguration | undefined;
    status: KnowledgeBaseStatus;
    createdAt: Date;
    updatedAt: Date;
    failureReasons?: string[] | undefined;
    metadataConfigurations?: MetadataConfiguration[] | undefined;
}
export interface CreateKnowledgeBaseResponse {
    knowledgeBase: KnowledgeBase;
}
export type PromptName = string;
export type PromptDescription = string;
export type PromptVariantName = string;
export type PromptModelIdentifier = string;
export type PromptMetadataKey = string | redacted.Redacted<string>;
export type PromptMetadataValue = string | redacted.Redacted<string>;
export interface PromptMetadataEntry {
    key: string | redacted.Redacted<string>;
    value: string | redacted.Redacted<string>;
}
export type PromptMetadataList = PromptMetadataEntry[];
export interface PromptAgentResource {
    agentIdentifier: string;
}
export type PromptGenAiResource = {
    agent: PromptAgentResource;
};
export interface PromptVariant {
    name: string;
    templateType: PromptTemplateType;
    templateConfiguration: PromptTemplateConfiguration;
    modelId?: string | undefined;
    inferenceConfiguration?: PromptInferenceConfiguration | undefined;
    metadata?: PromptMetadataEntry[] | undefined;
    additionalModelRequestFields?: any | undefined;
    genAiResource?: PromptGenAiResource | undefined;
}
export type PromptVariantList = PromptVariant[];
export interface CreatePromptRequest {
    name: string;
    description?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    defaultVariant?: string | undefined;
    variants?: PromptVariant[] | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PromptId = string;
export type PromptArn = string;
export interface CreatePromptResponse {
    name: string;
    description?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    defaultVariant?: string | undefined;
    variants?: PromptVariant[] | undefined;
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export type PromptIdentifier = string;
export interface CreatePromptVersionRequest {
    promptIdentifier: string;
    description?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreatePromptVersionResponse {
    name: string;
    description?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    defaultVariant?: string | undefined;
    variants?: PromptVariant[] | undefined;
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export type RetrievalInstructionName = string | redacted.Redacted<string>;
export type RetrievalInstructionFieldText = string | redacted.Redacted<string>;
export interface RetrievalInstructionContent {
    retrievalGuidance?: string | redacted.Redacted<string> | undefined;
    persona?: string | redacted.Redacted<string> | undefined;
    answerFormat?: string | redacted.Redacted<string> | undefined;
    answerPolicy?: string | redacted.Redacted<string> | undefined;
}
export type RetrievalInstructionDescription = string | redacted.Redacted<string>;
export interface CreateRetrievalInstructionRequest {
    clientToken?: string | undefined;
    name: string | redacted.Redacted<string>;
    instruction: RetrievalInstructionContent;
    description?: string | redacted.Redacted<string> | undefined;
    customerEncryptionKeyArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RetrievalInstructionId = string;
export type RetrievalInstructionArn = string;
export type RetrievalInstructionStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type RetrievalInstructionLastTransitionStatus = "CREATING" | "UPDATING" | "CREATE_SUCCESSFUL" | "CREATE_FAILED" | "UPDATE_SUCCESSFUL" | "UPDATE_FAILED" | (string & {});
export interface CreateRetrievalInstructionResponse {
    retrievalInstructionId: string;
    retrievalInstructionArn: string;
    name: string | redacted.Redacted<string>;
    status: RetrievalInstructionStatus;
    lastTransitionStatus: RetrievalInstructionLastTransitionStatus;
    createdAt: Date;
    updatedAt: Date;
}
export interface CreateRetrievalInstructionVersionRequest {
    retrievalInstructionId: string;
    description?: string | redacted.Redacted<string> | undefined;
    clientToken?: string | undefined;
}
export type RetrievalInstructionNumericalVersion = string;
export interface CreateRetrievalInstructionVersionResponse {
    retrievalInstructionId: string;
    retrievalInstructionArn: string;
    version: string;
    createdAt: Date;
    description?: string | redacted.Redacted<string> | undefined;
}
export type VpcId = string;
export type SubnetId = string;
export type SubnetIdList = string[];
export type ResourceTarget = string;
export type Port = number;
export type VpcProtocol = "HTTP" | "HTTPS" | (string & {});
export type VpcResolutionMode = "PUBLIC" | "IN_VPC" | (string & {});
export type HostHeader = string;
export type TlsServerName = string;
export type VpcConfigurationName = string;
export type VpcConfigurationDescription = string;
export interface CreateVpcConfigurationRequest {
    knowledgeBaseId: string;
    clientToken?: string | undefined;
    vpcId: string;
    subnetIds: string[];
    resourceTarget: string;
    port: number;
    protocol: VpcProtocol;
    resolutionMode: VpcResolutionMode;
    hostHeader?: string | undefined;
    tlsServerName?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
}
export type VpcConfigurationId = string;
export type VpcConfigurationStatus = "CREATING" | "CREATED" | "DELETING" | "CREATE_FAILED" | "DELETE_FAILED" | (string & {});
export interface CreateVpcConfigurationResponse {
    vpcConfigurationId: string;
    status: VpcConfigurationStatus;
}
export interface DeleteAgentRequest {
    agentId: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteAgentResponse {
    agentId: string;
    agentStatus: AgentStatus;
}
export interface DeleteAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteAgentActionGroupResponse {
}
export interface DeleteAgentAliasRequest {
    agentId: string;
    agentAliasId: string;
}
export interface DeleteAgentAliasResponse {
    agentId: string;
    agentAliasId: string;
    agentAliasStatus: AgentAliasStatus;
}
export interface DeleteAgentVersionRequest {
    agentId: string;
    agentVersion: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteAgentVersionResponse {
    agentId: string;
    agentVersion: string;
    agentStatus: AgentStatus;
}
export interface DeleteDataSourceRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
}
export interface DeleteDataSourceResponse {
    knowledgeBaseId: string;
    dataSourceId: string;
    status: DataSourceStatus;
}
export interface DeleteFlowRequest {
    flowIdentifier: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteFlowResponse {
    id: string;
}
export type FlowAliasIdentifier = string;
export interface DeleteFlowAliasRequest {
    flowIdentifier: string;
    aliasIdentifier: string;
}
export interface DeleteFlowAliasResponse {
    flowId: string;
    id: string;
}
export interface DeleteFlowVersionRequest {
    flowIdentifier: string;
    flowVersion: string;
    skipResourceInUseCheck?: boolean | undefined;
}
export interface DeleteFlowVersionResponse {
    id: string;
    version: string;
}
export interface DeleteKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export interface DeleteKnowledgeBaseResponse {
    knowledgeBaseId: string;
    status: KnowledgeBaseStatus;
}
export type ContentDataSourceType = "CUSTOM" | "S3" | (string & {});
export interface CustomDocumentIdentifier {
    id: string;
}
export interface DocumentIdentifier {
    dataSourceType: ContentDataSourceType;
    s3?: S3Location | undefined;
    custom?: CustomDocumentIdentifier | undefined;
}
export type DocumentIdentifiers = DocumentIdentifier[];
export interface DeleteKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    clientToken?: string | undefined;
    documentIdentifiers: DocumentIdentifier[];
}
export type DocumentStatus = "INDEXED" | "PARTIALLY_INDEXED" | "PENDING" | "FAILED" | "METADATA_PARTIALLY_INDEXED" | "METADATA_UPDATE_FAILED" | "IGNORED" | "NOT_FOUND" | "STARTING" | "IN_PROGRESS" | "DELETING" | "DELETE_IN_PROGRESS" | (string & {});
export interface KnowledgeBaseDocumentDetail {
    knowledgeBaseId: string;
    dataSourceId: string;
    status: DocumentStatus;
    identifier: DocumentIdentifier;
    statusReason?: string | undefined;
    updatedAt?: Date | undefined;
}
export type KnowledgeBaseDocumentDetails = KnowledgeBaseDocumentDetail[];
export interface DeleteKnowledgeBaseDocumentsResponse {
    documentDetails?: KnowledgeBaseDocumentDetail[] | undefined;
}
export interface DeletePromptRequest {
    promptIdentifier: string;
    promptVersion?: string | undefined;
}
export interface DeletePromptResponse {
    id: string;
    version?: string | undefined;
}
export type ResourceArn = string;
export type RevisionId = string;
export interface DeleteResourcePolicyRequest {
    resourceArn: string;
    expectedRevisionId?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
    resourceArn: string;
    revisionId?: string | undefined;
}
export interface DeleteRetrievalInstructionRequest {
    retrievalInstructionId: string;
    retrievalInstructionVersion?: string | undefined;
}
export interface DeleteRetrievalInstructionResponse {
    retrievalInstructionId: string;
    retrievalInstructionArn: string;
    version?: string | undefined;
}
export interface DeleteVpcConfigurationRequest {
    knowledgeBaseId: string;
    vpcConfigurationId: string;
}
export interface DeleteVpcConfigurationResponse {
    vpcConfigurationId: string;
    status: VpcConfigurationStatus;
}
export interface DisassociateAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
}
export interface DisassociateAgentCollaboratorResponse {
}
export interface DisassociateAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
}
export interface DisassociateAgentKnowledgeBaseResponse {
}
export interface GetAgentRequest {
    agentId: string;
}
export interface GetAgentResponse {
    agent: Agent;
}
export interface GetAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
}
export interface GetAgentActionGroupResponse {
    agentActionGroup: AgentActionGroup;
}
export interface GetAgentAliasRequest {
    agentId: string;
    agentAliasId: string;
}
export interface GetAgentAliasResponse {
    agentAlias: AgentAlias;
}
export interface GetAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
}
export interface GetAgentCollaboratorResponse {
    agentCollaborator: AgentCollaborator;
}
export interface GetAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
}
export interface GetAgentKnowledgeBaseResponse {
    agentKnowledgeBase: AgentKnowledgeBase;
}
export interface GetAgentVersionRequest {
    agentId: string;
    agentVersion: string;
}
export interface AgentVersion {
    agentId: string;
    agentName: string;
    agentArn: string;
    version: string;
    instruction?: string | redacted.Redacted<string> | undefined;
    agentStatus: AgentStatus;
    foundationModel?: string | undefined;
    description?: string | undefined;
    idleSessionTTLInSeconds: number;
    agentResourceRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
    failureReasons?: string[] | undefined;
    recommendedActions?: string[] | undefined;
    promptOverrideConfiguration?: PromptOverrideConfiguration | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    memoryConfiguration?: MemoryConfiguration | undefined;
    agentCollaboration?: AgentCollaboration | undefined;
}
export interface GetAgentVersionResponse {
    agentVersion: AgentVersion;
}
export interface GetDataSourceRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
}
export interface GetDataSourceResponse {
    dataSource: DataSource;
}
export type IncludedData = "ALL_DATA" | "METADATA_ONLY" | (string & {});
export interface GetFlowRequest {
    flowIdentifier: string;
    includedData?: IncludedData | undefined;
}
export type NonBlankString = string;
export type FlowValidationSeverity = "Warning" | "Error" | (string & {});
export interface CyclicConnectionFlowValidationDetails {
    connection: string;
}
export interface DuplicateConnectionsFlowValidationDetails {
    source: string;
    target: string;
}
export interface DuplicateConditionExpressionFlowValidationDetails {
    node: string;
    expression: string | redacted.Redacted<string>;
}
export interface UnreachableNodeFlowValidationDetails {
    node: string;
}
export interface UnknownConnectionSourceFlowValidationDetails {
    connection: string;
}
export interface UnknownConnectionSourceOutputFlowValidationDetails {
    connection: string;
}
export interface UnknownConnectionTargetFlowValidationDetails {
    connection: string;
}
export interface UnknownConnectionTargetInputFlowValidationDetails {
    connection: string;
}
export interface UnknownConnectionConditionFlowValidationDetails {
    connection: string;
}
export type ErrorMessage = string;
export interface MalformedConditionExpressionFlowValidationDetails {
    node: string;
    condition: string;
    cause: string;
}
export interface MalformedNodeInputExpressionFlowValidationDetails {
    node: string;
    input: string;
    cause: string;
}
export interface MismatchedNodeInputTypeFlowValidationDetails {
    node: string;
    input: string;
    expectedType: FlowNodeIODataType;
}
export interface MismatchedNodeOutputTypeFlowValidationDetails {
    node: string;
    output: string;
    expectedType: FlowNodeIODataType;
}
export interface IncompatibleConnectionDataTypeFlowValidationDetails {
    connection: string;
}
export interface MissingConnectionConfigurationFlowValidationDetails {
    connection: string;
}
export interface MissingDefaultConditionFlowValidationDetails {
    node: string;
}
export interface MissingEndingNodesFlowValidationDetails {
}
export interface MissingNodeConfigurationFlowValidationDetails {
    node: string;
}
export interface MissingNodeInputFlowValidationDetails {
    node: string;
    input: string;
}
export interface MissingNodeOutputFlowValidationDetails {
    node: string;
    output: string;
}
export interface MissingStartingNodesFlowValidationDetails {
}
export interface MultipleNodeInputConnectionsFlowValidationDetails {
    node: string;
    input: string;
}
export interface UnfulfilledNodeInputFlowValidationDetails {
    node: string;
    input: string;
}
export interface UnsatisfiedConnectionConditionsFlowValidationDetails {
    connection: string;
}
export interface UnspecifiedFlowValidationDetails {
}
export interface UnknownNodeInputFlowValidationDetails {
    node: string;
    input: string;
}
export interface UnknownNodeOutputFlowValidationDetails {
    node: string;
    output: string;
}
export interface MissingLoopInputNodeFlowValidationDetails {
    loopNode: string;
}
export interface MissingLoopControllerNodeFlowValidationDetails {
    loopNode: string;
}
export interface MultipleLoopInputNodesFlowValidationDetails {
    loopNode: string;
}
export interface MultipleLoopControllerNodesFlowValidationDetails {
    loopNode: string;
}
export type IncompatibleLoopNodeType = "Input" | "Condition" | "Iterator" | "Collector" | (string & {});
export interface LoopIncompatibleNodeTypeFlowValidationDetails {
    node: string;
    incompatibleNodeType: IncompatibleLoopNodeType;
    incompatibleNodeName: string;
}
export interface InvalidLoopBoundaryFlowValidationDetails {
    connection: string;
    source: string;
    target: string;
}
export type FlowValidationDetails = {
    cyclicConnection: CyclicConnectionFlowValidationDetails;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections: DuplicateConnectionsFlowValidationDetails;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression: DuplicateConditionExpressionFlowValidationDetails;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode: UnreachableNodeFlowValidationDetails;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource: UnknownConnectionSourceFlowValidationDetails;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput: UnknownConnectionSourceOutputFlowValidationDetails;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget: UnknownConnectionTargetFlowValidationDetails;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput: UnknownConnectionTargetInputFlowValidationDetails;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition: UnknownConnectionConditionFlowValidationDetails;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression: MalformedConditionExpressionFlowValidationDetails;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression: MalformedNodeInputExpressionFlowValidationDetails;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType: MismatchedNodeInputTypeFlowValidationDetails;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType: MismatchedNodeOutputTypeFlowValidationDetails;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType: IncompatibleConnectionDataTypeFlowValidationDetails;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration: MissingConnectionConfigurationFlowValidationDetails;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition: MissingDefaultConditionFlowValidationDetails;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes: MissingEndingNodesFlowValidationDetails;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration: MissingNodeConfigurationFlowValidationDetails;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput: MissingNodeInputFlowValidationDetails;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput: MissingNodeOutputFlowValidationDetails;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes: MissingStartingNodesFlowValidationDetails;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections: MultipleNodeInputConnectionsFlowValidationDetails;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput: UnfulfilledNodeInputFlowValidationDetails;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions: UnsatisfiedConnectionConditionsFlowValidationDetails;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified: UnspecifiedFlowValidationDetails;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput: UnknownNodeInputFlowValidationDetails;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput: UnknownNodeOutputFlowValidationDetails;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode: MissingLoopInputNodeFlowValidationDetails;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode: MissingLoopControllerNodeFlowValidationDetails;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes: MultipleLoopInputNodesFlowValidationDetails;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes: MultipleLoopControllerNodesFlowValidationDetails;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType: LoopIncompatibleNodeTypeFlowValidationDetails;
    invalidLoopBoundary?: undefined;
} | {
    cyclicConnection?: undefined;
    duplicateConnections?: undefined;
    duplicateConditionExpression?: undefined;
    unreachableNode?: undefined;
    unknownConnectionSource?: undefined;
    unknownConnectionSourceOutput?: undefined;
    unknownConnectionTarget?: undefined;
    unknownConnectionTargetInput?: undefined;
    unknownConnectionCondition?: undefined;
    malformedConditionExpression?: undefined;
    malformedNodeInputExpression?: undefined;
    mismatchedNodeInputType?: undefined;
    mismatchedNodeOutputType?: undefined;
    incompatibleConnectionDataType?: undefined;
    missingConnectionConfiguration?: undefined;
    missingDefaultCondition?: undefined;
    missingEndingNodes?: undefined;
    missingNodeConfiguration?: undefined;
    missingNodeInput?: undefined;
    missingNodeOutput?: undefined;
    missingStartingNodes?: undefined;
    multipleNodeInputConnections?: undefined;
    unfulfilledNodeInput?: undefined;
    unsatisfiedConnectionConditions?: undefined;
    unspecified?: undefined;
    unknownNodeInput?: undefined;
    unknownNodeOutput?: undefined;
    missingLoopInputNode?: undefined;
    missingLoopControllerNode?: undefined;
    multipleLoopInputNodes?: undefined;
    multipleLoopControllerNodes?: undefined;
    loopIncompatibleNodeType?: undefined;
    invalidLoopBoundary: InvalidLoopBoundaryFlowValidationDetails;
};
export type FlowValidationType = "CyclicConnection" | "DuplicateConnections" | "DuplicateConditionExpression" | "UnreachableNode" | "UnknownConnectionSource" | "UnknownConnectionSourceOutput" | "UnknownConnectionTarget" | "UnknownConnectionTargetInput" | "UnknownConnectionCondition" | "MalformedConditionExpression" | "MalformedNodeInputExpression" | "MismatchedNodeInputType" | "MismatchedNodeOutputType" | "IncompatibleConnectionDataType" | "MissingConnectionConfiguration" | "MissingDefaultCondition" | "MissingEndingNodes" | "MissingNodeConfiguration" | "MissingNodeInput" | "MissingNodeOutput" | "MissingStartingNodes" | "MultipleNodeInputConnections" | "UnfulfilledNodeInput" | "UnsatisfiedConnectionConditions" | "Unspecified" | "UnknownNodeInput" | "UnknownNodeOutput" | "MissingLoopInputNode" | "MissingLoopControllerNode" | "MultipleLoopInputNodes" | "MultipleLoopControllerNodes" | "LoopIncompatibleNodeType" | "InvalidLoopBoundary" | (string & {});
export interface FlowValidation {
    message: string;
    severity: FlowValidationSeverity;
    details?: FlowValidationDetails | undefined;
    type?: FlowValidationType | undefined;
}
export type FlowValidations = FlowValidation[];
export interface GetFlowResponse {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
    definition?: FlowDefinition | undefined;
    validations?: FlowValidation[] | undefined;
}
export interface GetFlowAliasRequest {
    flowIdentifier: string;
    aliasIdentifier: string;
}
export interface GetFlowAliasResponse {
    name: string;
    description?: string | undefined;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration | undefined;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetFlowVersionRequest {
    flowIdentifier: string;
    flowVersion: string;
    includedData?: IncludedData | undefined;
}
export interface GetFlowVersionResponse {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    version: string;
    definition?: FlowDefinition | undefined;
}
export interface GetIngestionJobRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
}
export type IngestionJobStatus = "STARTING" | "IN_PROGRESS" | "COMPLETE" | "FAILED" | "STOPPING" | "STOPPED" | (string & {});
export interface IngestionJobStatistics {
    numberOfDocumentsScanned?: number | undefined;
    numberOfMetadataDocumentsScanned?: number | undefined;
    numberOfNewDocumentsIndexed?: number | undefined;
    numberOfModifiedDocumentsIndexed?: number | undefined;
    numberOfMetadataDocumentsModified?: number | undefined;
    numberOfDocumentsDeleted?: number | undefined;
    numberOfDocumentsFailed?: number | undefined;
    numberOfDocumentsSkipped?: number | undefined;
}
export interface IngestionJob {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
    description?: string | undefined;
    status: IngestionJobStatus;
    statistics?: IngestionJobStatistics | undefined;
    failureReasons?: string[] | undefined;
    startedAt: Date;
    updatedAt: Date;
    textReadyAt?: Date | undefined;
}
export interface GetIngestionJobResponse {
    ingestionJob: IngestionJob;
}
export interface GetKnowledgeBaseRequest {
    knowledgeBaseId: string;
}
export interface GetKnowledgeBaseResponse {
    knowledgeBase: KnowledgeBase;
}
export interface GetKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    documentIdentifiers: DocumentIdentifier[];
}
export interface GetKnowledgeBaseDocumentsResponse {
    documentDetails?: KnowledgeBaseDocumentDetail[] | undefined;
}
export interface GetPromptRequest {
    promptIdentifier: string;
    promptVersion?: string | undefined;
    includedData?: IncludedData | undefined;
}
export interface GetPromptResponse {
    name: string;
    description?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    defaultVariant?: string | undefined;
    variants?: PromptVariant[] | undefined;
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetResourcePolicyRequest {
    resourceArn: string;
}
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    resourceArn: string;
    policy: string;
    revisionId: string;
}
export type RetrievalInstructionVersionSelector = string;
export interface GetRetrievalInstructionRequest {
    retrievalInstructionId: string;
    retrievalInstructionVersion?: string | undefined;
}
export type RetrievalInstructionFieldName = "RETRIEVAL_GUIDANCE" | "PERSONA" | "ANSWER_FORMAT" | "ANSWER_POLICY" | (string & {});
export type RetrievalInstructionFailureReasonCode = "CONTENT_REJECTED" | "CLIENT_ERROR" | "INTERNAL_ERROR" | (string & {});
export interface RetrievalInstructionFailureReason {
    fieldName?: RetrievalInstructionFieldName | undefined;
    code: RetrievalInstructionFailureReasonCode;
    message: string;
}
export type RetrievalInstructionFailureReasons = RetrievalInstructionFailureReason[];
export interface GetRetrievalInstructionResponse {
    retrievalInstructionId: string;
    retrievalInstructionArn: string;
    name: string | redacted.Redacted<string>;
    status: RetrievalInstructionStatus;
    lastTransitionStatus: RetrievalInstructionLastTransitionStatus;
    instruction?: RetrievalInstructionContent | undefined;
    createdAt: Date;
    updatedAt: Date;
    description?: string | redacted.Redacted<string> | undefined;
    customerEncryptionKeyArn?: string | undefined;
    lastTransitionStatusReasons?: RetrievalInstructionFailureReason[] | undefined;
    version?: string | undefined;
    latestVersion?: string | undefined;
}
export interface GetVpcConfigurationRequest {
    knowledgeBaseId: string;
    vpcConfigurationId: string;
}
export type VpcConfigurationStatusMessage = string;
export interface VpcConfiguration {
    vpcConfigurationId: string;
    status: VpcConfigurationStatus;
    statusMessage?: string | undefined;
    vpcId: string;
    subnetIds: string[];
    resourceTarget: string;
    port: number;
    protocol: VpcProtocol;
    resolutionMode: VpcResolutionMode;
    hostHeader?: string | undefined;
    tlsServerName?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export interface GetVpcConfigurationResponse {
    vpcConfiguration: VpcConfiguration;
}
export type MetadataSourceType = "IN_LINE_ATTRIBUTE" | "S3_LOCATION" | (string & {});
export type Key = string | redacted.Redacted<string>;
export type MetadataValueType = "BOOLEAN" | "NUMBER" | "STRING" | "STRING_LIST" | (string & {});
export type NumberValue = number;
export type StringValue = string | redacted.Redacted<string>;
export type StringListValue = (string | redacted.Redacted<string>)[];
export interface MetadataAttributeValue {
    type: MetadataValueType;
    numberValue?: number | undefined;
    booleanValue?: boolean | undefined;
    stringValue?: string | redacted.Redacted<string> | undefined;
    stringListValue?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface MetadataAttribute {
    key: string | redacted.Redacted<string>;
    value: MetadataAttributeValue;
}
export type MetadataAttributes = MetadataAttribute[];
export type S3ObjectUri = string;
export interface CustomS3Location {
    uri: string;
    bucketOwnerAccountId?: string | undefined;
}
export type AccessControlPrincipalType = "USER" | (string & {});
export type AccessControlAccess = "ALLOW" | "DENY" | (string & {});
export interface DocumentAccessControlEntry {
    name: string;
    type: AccessControlPrincipalType;
    access: AccessControlAccess;
}
export type DocumentAccessControlList = DocumentAccessControlEntry[];
export interface DocumentMetadata {
    type: MetadataSourceType;
    inlineAttributes?: MetadataAttribute[] | undefined;
    s3Location?: CustomS3Location | undefined;
    accessControlList?: DocumentAccessControlEntry[] | undefined;
}
export type CustomSourceType = "IN_LINE" | "S3_LOCATION" | (string & {});
export type InlineContentType = "BYTE" | "TEXT" | (string & {});
export type ByteContentBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface ByteContentDoc {
    mimeType: string;
    data: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type Data = string | redacted.Redacted<string>;
export interface TextContentDoc {
    data: string | redacted.Redacted<string>;
}
export interface InlineContent {
    type: InlineContentType;
    byteContent?: ByteContentDoc | undefined;
    textContent?: TextContentDoc | undefined;
}
export interface CustomContent {
    customDocumentIdentifier: CustomDocumentIdentifier;
    sourceType: CustomSourceType;
    s3Location?: CustomS3Location | undefined;
    inlineContent?: InlineContent | undefined;
}
export interface S3Content {
    s3Location: S3Location;
}
export interface DocumentContent {
    dataSourceType: ContentDataSourceType;
    custom?: CustomContent | undefined;
    s3?: S3Content | undefined;
}
export interface KnowledgeBaseDocument {
    metadata?: DocumentMetadata | undefined;
    content: DocumentContent;
}
export type KnowledgeBaseDocuments = KnowledgeBaseDocument[];
export interface IngestKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    clientToken?: string | undefined;
    documents: KnowledgeBaseDocument[];
}
export interface IngestKnowledgeBaseDocumentsResponse {
    documentDetails?: KnowledgeBaseDocumentDetail[] | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAgentActionGroupsRequest {
    agentId: string;
    agentVersion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ActionGroupSummary {
    actionGroupId: string;
    actionGroupName: string;
    actionGroupState: ActionGroupState;
    description?: string | undefined;
    updatedAt: Date;
}
export type ActionGroupSummaries = ActionGroupSummary[];
export interface ListAgentActionGroupsResponse {
    actionGroupSummaries: ActionGroupSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentAliasesRequest {
    agentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentAliasSummary {
    agentAliasId: string;
    agentAliasName: string;
    description?: string | undefined;
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[] | undefined;
    agentAliasStatus: AgentAliasStatus;
    createdAt: Date;
    updatedAt: Date;
    aliasInvocationState?: AliasInvocationState | undefined;
}
export type AgentAliasSummaries = AgentAliasSummary[];
export interface ListAgentAliasesResponse {
    agentAliasSummaries: AgentAliasSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentCollaboratorsRequest {
    agentId: string;
    agentVersion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentCollaboratorSummary {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
    agentDescriptor: AgentDescriptor;
    collaborationInstruction: string | redacted.Redacted<string>;
    relayConversationHistory: RelayConversationHistory;
    collaboratorName: string;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type AgentCollaboratorSummaries = AgentCollaboratorSummary[];
export interface ListAgentCollaboratorsResponse {
    agentCollaboratorSummaries: AgentCollaboratorSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentKnowledgeBasesRequest {
    agentId: string;
    agentVersion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentKnowledgeBaseSummary {
    knowledgeBaseId: string;
    description?: string | undefined;
    knowledgeBaseState: KnowledgeBaseState;
    updatedAt: Date;
}
export type AgentKnowledgeBaseSummaries = AgentKnowledgeBaseSummary[];
export interface ListAgentKnowledgeBasesResponse {
    agentKnowledgeBaseSummaries: AgentKnowledgeBaseSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentSummary {
    agentId: string;
    agentName: string;
    agentStatus: AgentStatus;
    description?: string | undefined;
    updatedAt: Date;
    latestAgentVersion?: string | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
}
export type AgentSummaries = AgentSummary[];
export interface ListAgentsResponse {
    agentSummaries: AgentSummary[];
    nextToken?: string | undefined;
}
export interface ListAgentVersionsRequest {
    agentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AgentVersionSummary {
    agentName: string;
    agentStatus: AgentStatus;
    agentVersion: string;
    createdAt: Date;
    updatedAt: Date;
    description?: string | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
}
export type AgentVersionSummaries = AgentVersionSummary[];
export interface ListAgentVersionsResponse {
    agentVersionSummaries: AgentVersionSummary[];
    nextToken?: string | undefined;
}
export interface ListDataSourcesRequest {
    knowledgeBaseId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DataSourceSummary {
    knowledgeBaseId: string;
    dataSourceId: string;
    name: string;
    status: DataSourceStatus;
    description?: string | undefined;
    updatedAt: Date;
}
export type DataSourceSummaries = DataSourceSummary[];
export interface ListDataSourcesResponse {
    dataSourceSummaries: DataSourceSummary[];
    nextToken?: string | undefined;
}
export interface ListFlowAliasesRequest {
    flowIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FlowAliasSummary {
    name: string;
    description?: string | undefined;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration | undefined;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export type FlowAliasSummaries = FlowAliasSummary[];
export interface ListFlowAliasesResponse {
    flowAliasSummaries: FlowAliasSummary[];
    nextToken?: string | undefined;
}
export interface ListFlowsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FlowSummary {
    name: string;
    description?: string | undefined;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
}
export type FlowSummaries = FlowSummary[];
export interface ListFlowsResponse {
    flowSummaries: FlowSummary[];
    nextToken?: string | undefined;
}
export interface ListFlowVersionsRequest {
    flowIdentifier: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FlowVersionSummary {
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    version: string;
}
export type FlowVersionSummaries = FlowVersionSummary[];
export interface ListFlowVersionsResponse {
    flowVersionSummaries: FlowVersionSummary[];
    nextToken?: string | undefined;
}
export type IngestionJobFilterAttribute = "STATUS" | (string & {});
export type IngestionJobFilterOperator = "EQ" | (string & {});
export type IngestionJobFilterValue = string;
export type IngestionJobFilterValues = string[];
export interface IngestionJobFilter {
    attribute: IngestionJobFilterAttribute;
    operator: IngestionJobFilterOperator;
    values: string[];
}
export type IngestionJobFilters = IngestionJobFilter[];
export type IngestionJobSortByAttribute = "STATUS" | "STARTED_AT" | (string & {});
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface IngestionJobSortBy {
    attribute: IngestionJobSortByAttribute;
    order: SortOrder;
}
export interface ListIngestionJobsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    filters?: IngestionJobFilter[] | undefined;
    sortBy?: IngestionJobSortBy | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface IngestionJobSummary {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
    description?: string | undefined;
    status: IngestionJobStatus;
    startedAt: Date;
    updatedAt: Date;
    textReadyAt?: Date | undefined;
    statistics?: IngestionJobStatistics | undefined;
}
export type IngestionJobSummaries = IngestionJobSummary[];
export interface ListIngestionJobsResponse {
    ingestionJobSummaries: IngestionJobSummary[];
    nextToken?: string | undefined;
}
export interface ListKnowledgeBaseDocumentsRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListKnowledgeBaseDocumentsResponse {
    documentDetails: KnowledgeBaseDocumentDetail[];
    nextToken?: string | undefined;
}
export interface ListKnowledgeBasesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface KnowledgeBaseSummary {
    knowledgeBaseId: string;
    name: string;
    description?: string | undefined;
    status: KnowledgeBaseStatus;
    updatedAt: Date;
}
export type KnowledgeBaseSummaries = KnowledgeBaseSummary[];
export interface ListKnowledgeBasesResponse {
    knowledgeBaseSummaries: KnowledgeBaseSummary[];
    nextToken?: string | undefined;
}
export interface ListPromptsRequest {
    promptIdentifier?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PromptSummary {
    name: string;
    description?: string | undefined;
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export type PromptSummaries = PromptSummary[];
export interface ListPromptsResponse {
    promptSummaries: PromptSummary[];
    nextToken?: string | undefined;
}
export type RetrievalInstructionMaxResults = number;
export interface ListRetrievalInstructionsRequest {
    status?: RetrievalInstructionStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RetrievalInstructionSummary {
    retrievalInstructionId: string;
    retrievalInstructionArn: string;
    name: string | redacted.Redacted<string>;
    status: RetrievalInstructionStatus;
    lastTransitionStatus: RetrievalInstructionLastTransitionStatus;
    createdAt: Date;
    updatedAt: Date;
    description?: string | redacted.Redacted<string> | undefined;
}
export type RetrievalInstructionSummaries = RetrievalInstructionSummary[];
export interface ListRetrievalInstructionsResponse {
    retrievalInstructionSummaries: RetrievalInstructionSummary[];
    nextToken?: string | undefined;
}
export interface ListRetrievalInstructionVersionsRequest {
    retrievalInstructionId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RetrievalInstructionVersionSummary {
    version: string;
    createdAt: Date;
}
export type RetrievalInstructionVersionSummaries = RetrievalInstructionVersionSummary[];
export interface ListRetrievalInstructionVersionsResponse {
    retrievalInstructionVersionSummaries: RetrievalInstructionVersionSummary[];
    nextToken?: string | undefined;
}
export type TaggableResourcesArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListVpcConfigurationsRequest {
    knowledgeBaseId: string;
    statusFilter?: VpcConfigurationStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface VpcConfigurationSummary {
    vpcConfigurationId: string;
    status: VpcConfigurationStatus;
    statusMessage?: string | undefined;
    vpcId: string;
    resourceTarget: string;
    port: number;
    protocol: VpcProtocol;
    resolutionMode: VpcResolutionMode;
    hostHeader?: string | undefined;
    tlsServerName?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    createdAt: Date;
}
export type VpcConfigurationSummaryList = VpcConfigurationSummary[];
export interface ListVpcConfigurationsResponse {
    items: VpcConfigurationSummary[];
    nextToken?: string | undefined;
}
export interface PrepareAgentRequest {
    agentId: string;
}
export interface PrepareAgentResponse {
    agentId: string;
    agentStatus: AgentStatus;
    agentVersion: string;
    preparedAt: Date;
}
export interface PrepareFlowRequest {
    flowIdentifier: string;
}
export interface PrepareFlowResponse {
    id: string;
    status: FlowStatus;
}
export interface PutResourcePolicyRequest {
    resourceArn: string;
    policy: string;
    expectedRevisionId?: string | undefined;
}
export interface PutResourcePolicyResponse {
    resourceArn: string;
    revisionId: string;
}
export interface StartIngestionJobRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    clientToken?: string | undefined;
    description?: string | undefined;
}
export interface StartIngestionJobResponse {
    ingestionJob: IngestionJob;
}
export interface StopIngestionJobRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    ingestionJobId: string;
}
export interface StopIngestionJobResponse {
    ingestionJob: IngestionJob;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAgentRequest {
    agentId: string;
    agentName: string;
    instruction?: string | redacted.Redacted<string> | undefined;
    foundationModel?: string | undefined;
    description?: string | undefined;
    orchestrationType?: OrchestrationType | undefined;
    customOrchestration?: CustomOrchestration | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    agentResourceRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    promptOverrideConfiguration?: PromptOverrideConfiguration | undefined;
    guardrailConfiguration?: GuardrailConfiguration | undefined;
    memoryConfiguration?: MemoryConfiguration | undefined;
    agentCollaboration?: AgentCollaboration | undefined;
}
export interface UpdateAgentResponse {
    agent: Agent;
}
export interface UpdateAgentActionGroupRequest {
    agentId: string;
    agentVersion: string;
    actionGroupId: string;
    actionGroupName: string;
    description?: string | undefined;
    parentActionGroupSignature?: ActionGroupSignature | undefined;
    parentActionGroupSignatureParams?: {
        [key: string]: string | undefined;
    } | undefined;
    actionGroupExecutor?: ActionGroupExecutor | undefined;
    actionGroupState?: ActionGroupState | undefined;
    apiSchema?: APISchema | undefined;
    functionSchema?: FunctionSchema | undefined;
}
export interface UpdateAgentActionGroupResponse {
    agentActionGroup: AgentActionGroup;
}
export interface UpdateAgentAliasRequest {
    agentId: string;
    agentAliasId: string;
    agentAliasName: string;
    description?: string | undefined;
    routingConfiguration?: AgentAliasRoutingConfigurationListItem[] | undefined;
    aliasInvocationState?: AliasInvocationState | undefined;
}
export interface UpdateAgentAliasResponse {
    agentAlias: AgentAlias;
}
export interface UpdateAgentCollaboratorRequest {
    agentId: string;
    agentVersion: string;
    collaboratorId: string;
    agentDescriptor: AgentDescriptor;
    collaboratorName: string;
    collaborationInstruction: string | redacted.Redacted<string>;
    relayConversationHistory?: RelayConversationHistory | undefined;
}
export interface UpdateAgentCollaboratorResponse {
    agentCollaborator: AgentCollaborator;
}
export interface UpdateAgentKnowledgeBaseRequest {
    agentId: string;
    agentVersion: string;
    knowledgeBaseId: string;
    description?: string | undefined;
    knowledgeBaseState?: KnowledgeBaseState | undefined;
}
export interface UpdateAgentKnowledgeBaseResponse {
    agentKnowledgeBase: AgentKnowledgeBase;
}
export interface UpdateDataSourceRequest {
    knowledgeBaseId: string;
    dataSourceId: string;
    name: string;
    description?: string | undefined;
    dataSourceConfiguration: DataSourceConfiguration;
    dataDeletionPolicy?: DataDeletionPolicy | undefined;
    serverSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    vectorIngestionConfiguration?: VectorIngestionConfiguration | undefined;
}
export interface UpdateDataSourceResponse {
    dataSource: DataSource;
}
export interface UpdateFlowRequest {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    definition?: FlowDefinition | undefined;
    flowIdentifier: string;
}
export interface UpdateFlowResponse {
    name: string;
    description?: string | undefined;
    executionRoleArn: string;
    customerEncryptionKeyArn?: string | undefined;
    id: string;
    arn: string;
    status: FlowStatus;
    createdAt: Date;
    updatedAt: Date;
    version: string;
    definition?: FlowDefinition | undefined;
}
export interface UpdateFlowAliasRequest {
    name: string;
    description?: string | undefined;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration | undefined;
    flowIdentifier: string;
    aliasIdentifier: string;
}
export interface UpdateFlowAliasResponse {
    name: string;
    description?: string | undefined;
    routingConfiguration: FlowAliasRoutingConfigurationListItem[];
    concurrencyConfiguration?: FlowAliasConcurrencyConfiguration | undefined;
    flowId: string;
    id: string;
    arn: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface UpdateKnowledgeBaseRequest {
    knowledgeBaseId: string;
    name: string;
    description?: string | undefined;
    roleArn: string;
    knowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    storageConfiguration?: StorageConfiguration | undefined;
    metadataConfigurations?: MetadataConfiguration[] | undefined;
}
export interface UpdateKnowledgeBaseResponse {
    knowledgeBase: KnowledgeBase;
}
export interface UpdatePromptRequest {
    name: string;
    description?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    defaultVariant?: string | undefined;
    variants?: PromptVariant[] | undefined;
    promptIdentifier: string;
}
export interface UpdatePromptResponse {
    name: string;
    description?: string | undefined;
    customerEncryptionKeyArn?: string | undefined;
    defaultVariant?: string | undefined;
    variants?: PromptVariant[] | undefined;
    id: string;
    arn: string;
    version: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface UpdateRetrievalInstructionRequest {
    retrievalInstructionId: string;
    instruction: RetrievalInstructionContent;
    description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateRetrievalInstructionResponse {
    retrievalInstructionId: string;
    retrievalInstructionArn: string;
    name: string | redacted.Redacted<string>;
    status: RetrievalInstructionStatus;
    lastTransitionStatus: RetrievalInstructionLastTransitionStatus;
    createdAt: Date;
    updatedAt: Date;
}
export interface ValidateFlowDefinitionRequest {
    definition: FlowDefinition;
}
export interface ValidateFlowDefinitionResponse {
    validations: FlowValidation[];
}
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateAgentCollaboratorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Makes an agent a collaborator for another agent.
 */
export declare const associateAgentCollaborator: API.OperationMethod<AssociateAgentCollaboratorRequest & RegionInput, AssociateAgentCollaboratorResponse, AssociateAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type AssociateAgentKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a knowledge base with an agent. If a knowledge base is associated and its `indexState` is set to `Enabled`, the agent queries the knowledge base for information to augment its response to the user.
 */
export declare const associateAgentKnowledgeBase: API.OperationMethod<AssociateAgentKnowledgeBaseRequest & RegionInput, AssociateAgentKnowledgeBaseResponse, AssociateAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreateAgentError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Amazon Bedrock Agents (now Amazon Bedrock Agents Classic) is no longer open to new customers. For capabilities similar to Bedrock Agents Classic, explore Amazon Bedrock AgentCore. Existing customers can continue to use the service as normal. For more information, see Amazon Bedrock Agents Classic availability change.
 *
 * Creates an agent that orchestrates interactions between foundation models, data sources, software applications, user conversations, and APIs to carry out tasks to help customers.
 *
 * - Specify the following fields for security purposes.
 *
 * - `agentResourceRoleArn` - The Amazon Resource Name (ARN) of the role with permissions to invoke API operations on an agent.
 *
 * - (Optional) `customerEncryptionKeyArn` - The Amazon Resource Name (ARN) of a KMS key to encrypt the creation of the agent.
 *
 * - (Optional) `idleSessionTTLinSeconds` - Specify the number of seconds for which the agent should maintain session information. After this time expires, the subsequent `InvokeAgent` request begins a new session.
 *
 * - To enable your agent to retain conversational context across multiple sessions, include a `memoryConfiguration` object. For more information, see Configure memory.
 *
 * - To override the default prompt behavior for agent orchestration and to use advanced prompts, include a `promptOverrideConfiguration` object. For more information, see Advanced prompts.
 *
 * - If your agent fails to be created, the response returns a list of `failureReasons` alongside a list of `recommendedActions` for you to troubleshoot.
 *
 * - The agent instructions will not be honored if your agent has only one knowledge base, uses default prompts, has no action group, and user input is disabled.
 */
export declare const createAgent: API.OperationMethod<CreateAgentRequest & RegionInput, CreateAgentResponse, CreateAgentError, Credentials | HttpClient.HttpClient>;
export type CreateAgentActionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an action group for an agent. An action group represents the actions that an agent can carry out for the customer by defining the APIs that an agent can call and the logic for calling them.
 *
 * To allow your agent to request the user for additional information when trying to complete a task, add an action group with the `parentActionGroupSignature` field set to `AMAZON.UserInput`.
 *
 * To allow your agent to generate, run, and troubleshoot code when trying to complete a task, add an action group with the `parentActionGroupSignature` field set to `AMAZON.CodeInterpreter`.
 *
 * You must leave the `description`, `apiSchema`, and `actionGroupExecutor` fields blank for this action group. During orchestration, if your agent determines that it needs to invoke an API in an action group, but doesn't have enough information to complete the API request, it will invoke this action group instead and return an Observation reprompting the user for more information.
 */
export declare const createAgentActionGroup: API.OperationMethod<CreateAgentActionGroupRequest & RegionInput, CreateAgentActionGroupResponse, CreateAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateAgentAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an alias of an agent that can be used to deploy the agent.
 */
export declare const createAgentAlias: API.OperationMethod<CreateAgentAliasRequest & RegionInput, CreateAgentAliasResponse, CreateAgentAliasError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Connects a knowledge base to a data source. You specify the configuration for the specific data source service in the `dataSourceConfiguration` field.
 *
 * You can't change the `chunkingConfiguration` after you create the data source connector.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest & RegionInput, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a prompt flow that you can use to send an input through various steps to yield an output. Configure nodes, each of which corresponds to a step of the flow, and create connections between the nodes to create paths to different outputs. For more information, see How it works and Create a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest & RegionInput, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type CreateFlowAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an alias of a flow for deployment. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createFlowAlias: API.OperationMethod<CreateFlowAliasRequest & RegionInput, CreateFlowAliasResponse, CreateFlowAliasError, Credentials | HttpClient.HttpClient>;
export type CreateFlowVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a version of the flow that you can deploy. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createFlowVersion: API.OperationMethod<CreateFlowVersionRequest & RegionInput, CreateFlowVersionResponse, CreateFlowVersionError, Credentials | HttpClient.HttpClient>;
export type CreateKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a knowledge base. A knowledge base contains your data sources so that Large Language Models (LLMs) can use your data. To create a knowledge base, you must first set up your data sources and configure a supported vector store. For more information, see Set up a knowledge base.
 *
 * To create a managed knowledge base, provide a `managedKnowledgeBaseConfiguration` during creation. For more information, see Build a managed knowledge base.
 *
 * - Provide the `name` and an optional `description`.
 *
 * - Provide the Amazon Resource Name (ARN) with permissions to create a knowledge base in the `roleArn` field.
 *
 * - For managed knowledge bases, set `embeddingModelType` to `MANAGED` to use the service-managed embedding model, or `CUSTOM` with an `embeddingModelArn` to use your own. To use your own KMS key for encryption, provide the ARN in `serverSideEncryptionConfiguration`. No vector store configuration is required for managed knowledge bases.
 *
 * - For self-managed knowledge bases, provide the embedding model to use in the `embeddingModelArn` field in the `knowledgeBaseConfiguration` object.
 *
 * - For self-managed knowledge bases, provide the configuration for your vector store in the `storageConfiguration` object.
 *
 * - For an Amazon OpenSearch Service database, use the `opensearchServerlessConfiguration` object. For more information, see Create a vector store in Amazon OpenSearch Service.
 *
 * - For an Amazon Aurora database, use the `RdsConfiguration` object. For more information, see Create a vector store in Amazon Aurora.
 *
 * - For a Pinecone database, use the `pineconeConfiguration` object. For more information, see Create a vector store in Pinecone.
 *
 * - For a Redis Enterprise Cloud database, use the `redisEnterpriseCloudConfiguration` object. For more information, see Create a vector store in Redis Enterprise Cloud.
 */
export declare const createKnowledgeBase: API.OperationMethod<CreateKnowledgeBaseRequest & RegionInput, CreateKnowledgeBaseResponse, CreateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreatePromptError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a prompt in your prompt library that you can add to a flow. For more information, see Prompt management in Amazon Bedrock, Create a prompt using Prompt management and Prompt flows in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const createPrompt: API.OperationMethod<CreatePromptRequest & RegionInput, CreatePromptResponse, CreatePromptError, Credentials | HttpClient.HttpClient>;
export type CreatePromptVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a static snapshot of your prompt that can be deployed to production. For more information, see Deploy prompts using Prompt management by creating versions in the Amazon Bedrock User Guide.
 */
export declare const createPromptVersion: API.OperationMethod<CreatePromptVersionRequest & RegionInput, CreatePromptVersionResponse, CreatePromptVersionError, Credentials | HttpClient.HttpClient>;
export type CreateRetrievalInstructionError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new retrieval instruction. The retrieval instruction is usable once its status becomes ACTIVE. Use GetRetrievalInstruction to check whether it is ready.
 */
export declare const createRetrievalInstruction: API.OperationMethod<CreateRetrievalInstructionRequest & RegionInput, CreateRetrievalInstructionResponse, CreateRetrievalInstructionError, Credentials | HttpClient.HttpClient>;
export type CreateRetrievalInstructionVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an immutable numbered version from the retrieval instruction's current reviewed content. The service creates the version synchronously.
 *
 * The service numbers versions from 1 and assigns them in order, never reusing a number.
 */
export declare const createRetrievalInstructionVersion: API.OperationMethod<CreateRetrievalInstructionVersionRequest & RegionInput, CreateRetrievalInstructionVersionResponse, CreateRetrievalInstructionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateVpcConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a VPC configuration that lets a knowledge base connect to a resource in your private VPC. This operation is asynchronous: it returns a `vpcConfigurationId` with status `CREATING`. Poll `GetVpcConfiguration` until the status becomes `CREATED` or `CREATE_FAILED`.
 */
export declare const createVpcConfiguration: API.OperationMethod<CreateVpcConfigurationRequest & RegionInput, CreateVpcConfigurationResponse, CreateVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an agent.
 */
export declare const deleteAgent: API.OperationMethod<DeleteAgentRequest & RegionInput, DeleteAgentResponse, DeleteAgentError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentActionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an action group in an agent.
 */
export declare const deleteAgentActionGroup: API.OperationMethod<DeleteAgentActionGroupRequest & RegionInput, DeleteAgentActionGroupResponse, DeleteAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an alias of an agent.
 */
export declare const deleteAgentAlias: API.OperationMethod<DeleteAgentAliasRequest & RegionInput, DeleteAgentAliasResponse, DeleteAgentAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a version of an agent.
 */
export declare const deleteAgentVersion: API.OperationMethod<DeleteAgentVersionRequest & RegionInput, DeleteAgentVersionResponse, DeleteAgentVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a data source from a knowledge base.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest & RegionInput, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a flow.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest & RegionInput, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an alias of a flow.
 */
export declare const deleteFlowAlias: API.OperationMethod<DeleteFlowAliasRequest & RegionInput, DeleteFlowAliasResponse, DeleteFlowAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a version of a flow.
 */
export declare const deleteFlowVersion: API.OperationMethod<DeleteFlowVersionRequest & RegionInput, DeleteFlowVersionResponse, DeleteFlowVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a knowledge base. Before deleting a knowledge base, you should disassociate the knowledge base from any agents that it is associated with by making a DisassociateAgentKnowledgeBase request.
 */
export declare const deleteKnowledgeBase: API.OperationMethod<DeleteKnowledgeBaseRequest & RegionInput, DeleteKnowledgeBaseResponse, DeleteKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes documents from a data source and syncs the changes to the knowledge base that is connected to it. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const deleteKnowledgeBaseDocuments: API.OperationMethod<DeleteKnowledgeBaseDocumentsRequest & RegionInput, DeleteKnowledgeBaseDocumentsResponse, DeleteKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient>;
export type DeletePromptError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a prompt or a version of it, depending on whether you include the `promptVersion` field or not. For more information, see Delete prompts from the Prompt management tool and Delete a version of a prompt from the Prompt management tool in the Amazon Bedrock User Guide.
 */
export declare const deletePrompt: API.OperationMethod<DeletePromptRequest & RegionInput, DeletePromptResponse, DeletePromptError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the resource policy associated with a knowledge base. After deletion, other AWS accounts can no longer access the knowledge base using cross-account permissions.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRetrievalInstructionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a retrieval instruction or a single version of it. Omit retrievalInstructionVersion to delete the retrieval instruction itself; the service rejects that request with ConflictException while the retrieval instruction has versions or while lastTransitionStatus is CREATING or UPDATING. Specify retrievalInstructionVersion to delete only that version; the retrieval instruction and its other versions are unaffected.
 */
export declare const deleteRetrievalInstruction: API.OperationMethod<DeleteRetrievalInstructionRequest & RegionInput, DeleteRetrievalInstructionResponse, DeleteRetrievalInstructionError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a VPC configuration. This operation is asynchronous: it returns status `DELETING`. Poll `GetVpcConfiguration` until it returns a `ResourceNotFoundException`, indicating the configuration is deleted. Delete requests are idempotent and safe to retry.
 */
export declare const deleteVpcConfiguration: API.OperationMethod<DeleteVpcConfigurationRequest & RegionInput, DeleteVpcConfigurationResponse, DeleteVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type DisassociateAgentCollaboratorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an agent collaborator.
 */
export declare const disassociateAgentCollaborator: API.OperationMethod<DisassociateAgentCollaboratorRequest & RegionInput, DisassociateAgentCollaboratorResponse, DisassociateAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type DisassociateAgentKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a knowledge base from an agent.
 */
export declare const disassociateAgentKnowledgeBase: API.OperationMethod<DisassociateAgentKnowledgeBaseRequest & RegionInput, DisassociateAgentKnowledgeBaseResponse, DisassociateAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetAgentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an agent.
 */
export declare const getAgent: API.OperationMethod<GetAgentRequest & RegionInput, GetAgentResponse, GetAgentError, Credentials | HttpClient.HttpClient>;
export type GetAgentActionGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an action group for an agent.
 */
export declare const getAgentActionGroup: API.OperationMethod<GetAgentActionGroupRequest & RegionInput, GetAgentActionGroupResponse, GetAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type GetAgentAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an alias of an agent.
 */
export declare const getAgentAlias: API.OperationMethod<GetAgentAliasRequest & RegionInput, GetAgentAliasResponse, GetAgentAliasError, Credentials | HttpClient.HttpClient>;
export type GetAgentCollaboratorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an agent's collaborator.
 */
export declare const getAgentCollaborator: API.OperationMethod<GetAgentCollaboratorRequest & RegionInput, GetAgentCollaboratorResponse, GetAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type GetAgentKnowledgeBaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a knowledge base associated with an agent.
 */
export declare const getAgentKnowledgeBase: API.OperationMethod<GetAgentKnowledgeBaseRequest & RegionInput, GetAgentKnowledgeBaseResponse, GetAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetAgentVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details about a version of an agent.
 */
export declare const getAgentVersion: API.OperationMethod<GetAgentVersionRequest & RegionInput, GetAgentVersionResponse, GetAgentVersionError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a data source.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest & RegionInput, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetFlowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a flow. For more information, see Manage a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const getFlow: API.OperationMethod<GetFlowRequest & RegionInput, GetFlowResponse, GetFlowError, Credentials | HttpClient.HttpClient>;
export type GetFlowAliasError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a flow. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const getFlowAlias: API.OperationMethod<GetFlowAliasRequest & RegionInput, GetFlowAliasResponse, GetFlowAliasError, Credentials | HttpClient.HttpClient>;
export type GetFlowVersionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a version of a flow. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const getFlowVersion: API.OperationMethod<GetFlowVersionRequest & RegionInput, GetFlowVersionResponse, GetFlowVersionError, Credentials | HttpClient.HttpClient>;
export type GetIngestionJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a data ingestion job. Data sources are ingested into your knowledge base so that Large Language Models (LLMs) can use your data.
 */
export declare const getIngestionJob: API.OperationMethod<GetIngestionJobRequest & RegionInput, GetIngestionJobResponse, GetIngestionJobError, Credentials | HttpClient.HttpClient>;
export type GetKnowledgeBaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a knowledge base.
 */
export declare const getKnowledgeBase: API.OperationMethod<GetKnowledgeBaseRequest & RegionInput, GetKnowledgeBaseResponse, GetKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type GetKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves specific documents from a data source that is connected to a knowledge base. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const getKnowledgeBaseDocuments: API.OperationMethod<GetKnowledgeBaseDocumentsRequest & RegionInput, GetKnowledgeBaseDocumentsResponse, GetKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient>;
export type GetPromptError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the working draft (`DRAFT` version) of a prompt or a version of it, depending on whether you include the `promptVersion` field or not. For more information, see View information about prompts using Prompt management and View information about a version of your prompt in the Amazon Bedrock User Guide.
 */
export declare const getPrompt: API.OperationMethod<GetPromptRequest & RegionInput, GetPromptResponse, GetPromptError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource policy associated with a knowledge base.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetRetrievalInstructionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a retrieval instruction. Also used to poll the terminal reporting of an asynchronous create or update.
 */
export declare const getRetrievalInstruction: API.OperationMethod<GetRetrievalInstructionRequest & RegionInput, GetRetrievalInstructionResponse, GetRetrievalInstructionError, Credentials | HttpClient.HttpClient>;
export type GetVpcConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details and current status of a single VPC configuration. Use this operation to poll for the outcome of an asynchronous create or delete.
 */
export declare const getVpcConfiguration: API.OperationMethod<GetVpcConfigurationRequest & RegionInput, GetVpcConfigurationResponse, GetVpcConfigurationError, Credentials | HttpClient.HttpClient>;
export type IngestKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ingests documents directly into the knowledge base that is connected to the data source. The `dataSourceType` specified in the content for each document must match the type of the data source that you specify in the header. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const ingestKnowledgeBaseDocuments: API.OperationMethod<IngestKnowledgeBaseDocumentsRequest & RegionInput, IngestKnowledgeBaseDocumentsResponse, IngestKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient>;
export type ListAgentActionGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the action groups for an agent and information about each one.
 */
export declare const listAgentActionGroups: API.PaginatedOperationMethod<ListAgentActionGroupsRequest & RegionInput, ListAgentActionGroupsResponse, ListAgentActionGroupsError, Credentials | HttpClient.HttpClient, ActionGroupSummary>;
export type ListAgentAliasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the aliases of an agent and information about each one.
 */
export declare const listAgentAliases: API.PaginatedOperationMethod<ListAgentAliasesRequest & RegionInput, ListAgentAliasesResponse, ListAgentAliasesError, Credentials | HttpClient.HttpClient, AgentAliasSummary>;
export type ListAgentCollaboratorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieve a list of an agent's collaborators.
 */
export declare const listAgentCollaborators: API.PaginatedOperationMethod<ListAgentCollaboratorsRequest & RegionInput, ListAgentCollaboratorsResponse, ListAgentCollaboratorsError, Credentials | HttpClient.HttpClient, AgentCollaboratorSummary>;
export type ListAgentKnowledgeBasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists knowledge bases associated with an agent and information about each one.
 */
export declare const listAgentKnowledgeBases: API.PaginatedOperationMethod<ListAgentKnowledgeBasesRequest & RegionInput, ListAgentKnowledgeBasesResponse, ListAgentKnowledgeBasesError, Credentials | HttpClient.HttpClient, AgentKnowledgeBaseSummary>;
export type ListAgentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the agents belonging to an account and information about each agent.
 */
export declare const listAgents: API.PaginatedOperationMethod<ListAgentsRequest & RegionInput, ListAgentsResponse, ListAgentsError, Credentials | HttpClient.HttpClient, AgentSummary>;
export type ListAgentVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the versions of an agent and information about each version.
 */
export declare const listAgentVersions: API.PaginatedOperationMethod<ListAgentVersionsRequest & RegionInput, ListAgentVersionsResponse, ListAgentVersionsError, Credentials | HttpClient.HttpClient, AgentVersionSummary>;
export type ListDataSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data sources in a knowledge base and information about each one.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest & RegionInput, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSourceSummary>;
export type ListFlowAliasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of aliases for a flow.
 */
export declare const listFlowAliases: API.PaginatedOperationMethod<ListFlowAliasesRequest & RegionInput, ListFlowAliasesResponse, ListFlowAliasesError, Credentials | HttpClient.HttpClient, FlowAliasSummary>;
export type ListFlowsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of flows and information about each flow. For more information, see Manage a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsRequest & RegionInput, ListFlowsResponse, ListFlowsError, Credentials | HttpClient.HttpClient, FlowSummary>;
export type ListFlowVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of information about each flow. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const listFlowVersions: API.PaginatedOperationMethod<ListFlowVersionsRequest & RegionInput, ListFlowVersionsResponse, ListFlowVersionsError, Credentials | HttpClient.HttpClient, FlowVersionSummary>;
export type ListIngestionJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data ingestion jobs for a data source. The list also includes information about each job.
 */
export declare const listIngestionJobs: API.PaginatedOperationMethod<ListIngestionJobsRequest & RegionInput, ListIngestionJobsResponse, ListIngestionJobsError, Credentials | HttpClient.HttpClient, IngestionJobSummary>;
export type ListKnowledgeBaseDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves all the documents contained in a data source that is connected to a knowledge base. For more information, see Ingest changes directly into a knowledge base in the Amazon Bedrock User Guide.
 */
export declare const listKnowledgeBaseDocuments: API.PaginatedOperationMethod<ListKnowledgeBaseDocumentsRequest & RegionInput, ListKnowledgeBaseDocumentsResponse, ListKnowledgeBaseDocumentsError, Credentials | HttpClient.HttpClient, KnowledgeBaseDocumentDetail>;
export type ListKnowledgeBasesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the knowledge bases in an account. The list also includesinformation about each knowledge base.
 */
export declare const listKnowledgeBases: API.PaginatedOperationMethod<ListKnowledgeBasesRequest & RegionInput, ListKnowledgeBasesResponse, ListKnowledgeBasesError, Credentials | HttpClient.HttpClient, KnowledgeBaseSummary>;
export type ListPromptsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns either information about the working draft (`DRAFT` version) of each prompt in an account, or information about of all versions of a prompt, depending on whether you include the `promptIdentifier` field or not. For more information, see View information about prompts using Prompt management in the Amazon Bedrock User Guide.
 */
export declare const listPrompts: API.PaginatedOperationMethod<ListPromptsRequest & RegionInput, ListPromptsResponse, ListPromptsError, Credentials | HttpClient.HttpClient, PromptSummary>;
export type ListRetrievalInstructionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the retrieval instructions in the caller's account. Results are paginated. Use the nextToken parameter to retrieve additional results.
 */
export declare const listRetrievalInstructions: API.PaginatedOperationMethod<ListRetrievalInstructionsRequest & RegionInput, ListRetrievalInstructionsResponse, ListRetrievalInstructionsError, Credentials | HttpClient.HttpClient, RetrievalInstructionSummary>;
export type ListRetrievalInstructionVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the numbered versions of a retrieval instruction, newest first. DRAFT is not listed; read it with GetRetrievalInstruction without retrievalInstructionVersion. Results are paginated. Use the nextToken parameter to retrieve additional results.
 */
export declare const listRetrievalInstructionVersions: API.PaginatedOperationMethod<ListRetrievalInstructionVersionsRequest & RegionInput, ListRetrievalInstructionVersionsResponse, ListRetrievalInstructionVersionsError, Credentials | HttpClient.HttpClient, RetrievalInstructionVersionSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List all the tags for the resource you specify.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVpcConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of the VPC configurations for a knowledge base. You can optionally filter by status. Use the `nextToken` parameter to retrieve additional results.
 */
export declare const listVpcConfigurations: API.PaginatedOperationMethod<ListVpcConfigurationsRequest & RegionInput, ListVpcConfigurationsResponse, ListVpcConfigurationsError, Credentials | HttpClient.HttpClient, VpcConfigurationSummary>;
export type PrepareAgentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a `DRAFT` version of the agent that can be used for internal testing.
 */
export declare const prepareAgent: API.OperationMethod<PrepareAgentRequest & RegionInput, PrepareAgentResponse, PrepareAgentError, Credentials | HttpClient.HttpClient>;
export type PrepareFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Prepares the `DRAFT` version of a flow so that it can be invoked. For more information, see Test a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const prepareFlow: API.OperationMethod<PrepareFlowRequest & RegionInput, PrepareFlowResponse, PrepareFlowError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a resource policy with a knowledge base. A resource policy allows other AWS accounts to access the knowledge base. For more information, see Cross-account access for knowledge bases.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Begins a data ingestion job. Data sources are ingested into your knowledge base so that Large Language Models (LLMs) can use your data.
 */
export declare const startIngestionJob: API.OperationMethod<StartIngestionJobRequest & RegionInput, StartIngestionJobResponse, StartIngestionJobError, Credentials | HttpClient.HttpClient>;
export type StopIngestionJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a currently running data ingestion job. You can send a `StartIngestionJob` request again to ingest the rest of your data when you are ready.
 */
export declare const stopIngestionJob: API.OperationMethod<StopIngestionJobRequest & RegionInput, StopIngestionJobResponse, StopIngestionJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associate tags with a resource. For more information, see Tagging resources in the Amazon Bedrock User Guide.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Remove tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of an agent.
 */
export declare const updateAgent: API.OperationMethod<UpdateAgentRequest & RegionInput, UpdateAgentResponse, UpdateAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentActionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration for an action group for an agent.
 */
export declare const updateAgentActionGroup: API.OperationMethod<UpdateAgentActionGroupRequest & RegionInput, UpdateAgentActionGroupResponse, UpdateAgentActionGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates configurations for an alias of an agent.
 */
export declare const updateAgentAlias: API.OperationMethod<UpdateAgentAliasRequest & RegionInput, UpdateAgentAliasResponse, UpdateAgentAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentCollaboratorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an agent's collaborator.
 */
export declare const updateAgentCollaborator: API.OperationMethod<UpdateAgentCollaboratorRequest & RegionInput, UpdateAgentCollaboratorResponse, UpdateAgentCollaboratorError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration for a knowledge base that has been associated with an agent.
 */
export declare const updateAgentKnowledgeBase: API.OperationMethod<UpdateAgentKnowledgeBaseRequest & RegionInput, UpdateAgentKnowledgeBaseResponse, UpdateAgentKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configurations for a data source connector.
 *
 * You can't change the `chunkingConfiguration` after you create the data source connector. Specify the existing `chunkingConfiguration`.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest & RegionInput, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies a flow. Include both fields that you want to keep and fields that you want to change. For more information, see How it works and Create a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest & RegionInput, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the alias of a flow. Include both fields that you want to keep and ones that you want to change. For more information, see Deploy a flow in Amazon Bedrock in the Amazon Bedrock User Guide.
 */
export declare const updateFlowAlias: API.OperationMethod<UpdateFlowAliasRequest & RegionInput, UpdateFlowAliasResponse, UpdateFlowAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateKnowledgeBaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration of a knowledge base with the fields that you specify. Because all fields will be overwritten, you must include the same values for fields that you want to keep the same.
 *
 * You can change the following fields:
 *
 * - `name`
 *
 * - `description`
 *
 * - `roleArn`
 *
 * You can't change the `knowledgeBaseConfiguration` or `storageConfiguration` fields, so you must specify the same configurations as when you created the knowledge base. You can send a GetKnowledgeBase request and copy the same configurations.
 */
export declare const updateKnowledgeBase: API.OperationMethod<UpdateKnowledgeBaseRequest & RegionInput, UpdateKnowledgeBaseResponse, UpdateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type UpdatePromptError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies a prompt in your prompt library. Include both fields that you want to keep and fields that you want to replace. For more information, see Prompt management in Amazon Bedrock and Edit prompts in your prompt library in the Amazon Bedrock User Guide.
 */
export declare const updatePrompt: API.OperationMethod<UpdatePromptRequest & RegionInput, UpdatePromptResponse, UpdatePromptError, Credentials | HttpClient.HttpClient>;
export type UpdateRetrievalInstructionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the content of a retrieval instruction. The update is processed asynchronously; the stored content is a candidate until content review passes, and the served content does not change while the update is in flight. The service rejects the request with ConflictException while lastTransitionStatus is CREATING or UPDATING.
 */
export declare const updateRetrievalInstruction: API.OperationMethod<UpdateRetrievalInstructionRequest & RegionInput, UpdateRetrievalInstructionResponse, UpdateRetrievalInstructionError, Credentials | HttpClient.HttpClient>;
export type ValidateFlowDefinitionError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Validates the definition of a flow.
 */
export declare const validateFlowDefinition: API.OperationMethod<ValidateFlowDefinitionRequest & RegionInput, ValidateFlowDefinitionResponse, ValidateFlowDefinitionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=bedrock-agent.d.ts.map