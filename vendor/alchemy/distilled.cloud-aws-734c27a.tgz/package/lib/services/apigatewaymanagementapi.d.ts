import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.TaggedErrorClass<"GoneException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PayloadTooLargeException_base: S.TaggedErrorClass<"PayloadTooLargeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PayloadTooLargeException extends /*@__PURE__*/ PayloadTooLargeException_base {
}
export interface DeleteConnectionRequest {
    ConnectionId: string;
}
export interface DeleteConnectionResponse {
}
export interface GetConnectionRequest {
    ConnectionId: string;
}
export type __timestampIso8601 = Date;
export interface Identity {
    SourceIp?: string | undefined;
    UserAgent?: string | undefined;
}
export interface GetConnectionResponse {
    ConnectedAt?: Date | undefined;
    Identity?: (Identity & {
        SourceIp: string;
        UserAgent: string;
    }) | undefined;
    LastActiveAt?: Date | undefined;
}
export interface PostToConnectionRequest {
    Data?: T.StreamingInputBody | undefined;
    ConnectionId: string;
}
export interface PostToConnectionResponse {
}
export type DeleteConnectionError = ForbiddenException | GoneException | LimitExceededException | CommonErrors;
/**
 * Delete the connection with the provided id.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest & RegionInput, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type GetConnectionError = ForbiddenException | GoneException | LimitExceededException | CommonErrors;
/**
 * Get information about the connection with the provided id.
 */
export declare const getConnection: API.OperationMethod<GetConnectionRequest & RegionInput, GetConnectionResponse, GetConnectionError, Credentials | HttpClient.HttpClient>;
export type PostToConnectionError = ForbiddenException | GoneException | LimitExceededException | PayloadTooLargeException | CommonErrors;
/**
 * Sends the provided data to the specified connection.
 */
export declare const postToConnection: API.OperationMethod<PostToConnectionRequest & RegionInput, PostToConnectionResponse, PostToConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=apigatewaymanagementapi.d.ts.map