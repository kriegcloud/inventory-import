import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type TaskId = string;
export interface CancelTaskInput {
    taskId: string;
}
export interface CancelTaskOutput {
    taskId?: string | undefined;
}
export type TargetList = string[];
export interface Unlock {
}
export interface Reboot {
}
export type Command = {
    unlock: Unlock;
    reboot?: undefined;
} | {
    unlock?: undefined;
    reboot: Reboot;
};
export type TaskDescriptionString = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type IdempotencyToken = string;
export interface CreateTaskInput {
    targets: string[];
    command: Command;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface CreateTaskOutput {
    taskId?: string | undefined;
    taskArn?: string | undefined;
}
export type ManagedDeviceId = string;
export interface DescribeDeviceInput {
    managedDeviceId: string;
}
export type UnlockState = string;
export type PhysicalConnectorType = string;
export type IpAddressAssignment = string;
export interface PhysicalNetworkInterface {
    physicalNetworkInterfaceId?: string | undefined;
    physicalConnectorType?: string | undefined;
    ipAddressAssignment?: string | undefined;
    ipAddress?: string | undefined;
    netmask?: string | undefined;
    defaultGateway?: string | undefined;
    macAddress?: string | undefined;
}
export type PhysicalNetworkInterfaceList = PhysicalNetworkInterface[];
export interface Capacity {
    name?: string | undefined;
    unit?: string | undefined;
    total?: number | undefined;
    used?: number | undefined;
    available?: number | undefined;
}
export type CapacityList = Capacity[];
export interface SoftwareInformation {
    installedVersion?: string | undefined;
    installingVersion?: string | undefined;
    installState?: string | undefined;
}
export interface DescribeDeviceOutput {
    lastReachedOutAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    managedDeviceId?: string | undefined;
    managedDeviceArn?: string | undefined;
    deviceType?: string | undefined;
    associatedWithJob?: string | undefined;
    deviceState?: string | undefined;
    physicalNetworkInterfaces?: PhysicalNetworkInterface[] | undefined;
    deviceCapacities?: Capacity[] | undefined;
    software?: SoftwareInformation | undefined;
}
export type InstanceIdsList = string[];
export interface DescribeDeviceEc2Input {
    managedDeviceId: string;
    instanceIds: string[];
}
export type InstanceStateName = string;
export interface InstanceState {
    code?: number | undefined;
    name?: string | undefined;
}
export type AttachmentStatus = string;
export interface EbsInstanceBlockDevice {
    attachTime?: Date | undefined;
    deleteOnTermination?: boolean | undefined;
    status?: string | undefined;
    volumeId?: string | undefined;
}
export interface InstanceBlockDeviceMapping {
    deviceName?: string | undefined;
    ebs?: EbsInstanceBlockDevice | undefined;
}
export type InstanceBlockDeviceMappingList = InstanceBlockDeviceMapping[];
export interface SecurityGroupIdentifier {
    groupId?: string | undefined;
    groupName?: string | undefined;
}
export type SecurityGroupIdentifierList = SecurityGroupIdentifier[];
export interface CpuOptions {
    coreCount?: number | undefined;
    threadsPerCore?: number | undefined;
}
export interface Instance {
    imageId?: string | undefined;
    amiLaunchIndex?: number | undefined;
    instanceId?: string | undefined;
    state?: InstanceState | undefined;
    instanceType?: string | undefined;
    privateIpAddress?: string | undefined;
    publicIpAddress?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    blockDeviceMappings?: InstanceBlockDeviceMapping[] | undefined;
    securityGroups?: SecurityGroupIdentifier[] | undefined;
    cpuOptions?: CpuOptions | undefined;
    rootDeviceName?: string | undefined;
}
export interface InstanceSummary {
    instance?: Instance | undefined;
    lastUpdatedAt?: Date | undefined;
}
export type InstanceSummaryList = InstanceSummary[];
export interface DescribeDeviceEc2Output {
    instances?: InstanceSummary[] | undefined;
}
export interface DescribeExecutionInput {
    taskId: string;
    managedDeviceId: string;
}
export type ExecutionId = string;
export type ExecutionState = string;
export interface DescribeExecutionOutput {
    taskId?: string | undefined;
    executionId?: string | undefined;
    managedDeviceId?: string | undefined;
    state?: string | undefined;
    startedAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
}
export interface DescribeTaskInput {
    taskId: string;
}
export type TaskState = string;
export interface DescribeTaskOutput {
    taskId?: string | undefined;
    taskArn?: string | undefined;
    targets?: string[] | undefined;
    state?: string | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    completedAt?: Date | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListDeviceResourcesInput {
    managedDeviceId: string;
    type?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ResourceSummary {
    resourceType: string;
    arn?: string | undefined;
    id?: string | undefined;
}
export type ResourceSummaryList = ResourceSummary[];
export interface ListDeviceResourcesOutput {
    resources?: ResourceSummary[] | undefined;
    nextToken?: string | undefined;
}
export type JobId = string;
export interface ListDevicesInput {
    jobId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DeviceSummary {
    managedDeviceId?: string | undefined;
    managedDeviceArn?: string | undefined;
    associatedWithJob?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DeviceSummaryList = DeviceSummary[];
export interface ListDevicesOutput {
    devices?: DeviceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListExecutionsInput {
    taskId: string;
    state?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ExecutionSummary {
    taskId?: string | undefined;
    executionId?: string | undefined;
    managedDeviceId?: string | undefined;
    state?: string | undefined;
}
export type ExecutionSummaryList = ExecutionSummary[];
export interface ListExecutionsOutput {
    executions?: ExecutionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTasksInput {
    state?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface TaskSummary {
    taskId: string;
    taskArn?: string | undefined;
    state?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TaskSummaryList = TaskSummary[];
export interface ListTasksOutput {
    tasks?: TaskSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type CancelTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a cancel request for a specified task. You can cancel a task only if it's still in a
 * `QUEUED` state. Tasks that are already running can't be cancelled.
 *
 * A task might still run if it's processed from the queue before the
 * `CancelTask` operation changes the task's state.
 */
export declare const cancelTask: API.OperationMethod<CancelTaskInput & RegionInput, CancelTaskOutput, CancelTaskError, Credentials | HttpClient.HttpClient>;
export type CreateTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Instructs one or more devices to start a task, such as unlocking or rebooting.
 */
export declare const createTask: API.OperationMethod<CreateTaskInput & RegionInput, CreateTaskOutput, CreateTaskError, Credentials | HttpClient.HttpClient>;
export type DescribeDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Checks device-specific information, such as the device type, software version, IP
 * addresses, and lock status.
 */
export declare const describeDevice: API.OperationMethod<DescribeDeviceInput & RegionInput, DescribeDeviceOutput, DescribeDeviceError, Credentials | HttpClient.HttpClient>;
export type DescribeDeviceEc2InstancesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Checks the current state of the Amazon EC2 instances. The output is similar to
 * `describeDevice`, but the results are sourced from the device cache in the
 * Amazon Web Services Cloud and include a subset of the available fields.
 */
export declare const describeDeviceEc2Instances: API.OperationMethod<DescribeDeviceEc2Input & RegionInput, DescribeDeviceEc2Output, DescribeDeviceEc2InstancesError, Credentials | HttpClient.HttpClient>;
export type DescribeExecutionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Checks the status of a remote task running on one or more target devices.
 */
export declare const describeExecution: API.OperationMethod<DescribeExecutionInput & RegionInput, DescribeExecutionOutput, DescribeExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Checks the metadata for a given task on a device.
 */
export declare const describeTask: API.OperationMethod<DescribeTaskInput & RegionInput, DescribeTaskOutput, DescribeTaskError, Credentials | HttpClient.HttpClient>;
export type ListDeviceResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the Amazon Web Services resources available for a device. Currently, Amazon EC2 instances are the only supported resource type.
 */
export declare const listDeviceResources: API.PaginatedOperationMethod<ListDeviceResourcesInput & RegionInput, ListDeviceResourcesOutput, ListDeviceResourcesError, Credentials | HttpClient.HttpClient, ResourceSummary>;
export type ListDevicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all devices on your Amazon Web Services account that have Amazon Web Services Snow Device Management
 * enabled in the Amazon Web Services Region where the command is run.
 */
export declare const listDevices: API.PaginatedOperationMethod<ListDevicesInput & RegionInput, ListDevicesOutput, ListDevicesError, Credentials | HttpClient.HttpClient, DeviceSummary>;
export type ListExecutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the status of tasks for one or more target devices.
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsInput & RegionInput, ListExecutionsOutput, ListExecutionsError, Credentials | HttpClient.HttpClient, ExecutionSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a managed device or task.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTasksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tasks that can be filtered by state.
 */
export declare const listTasks: API.PaginatedOperationMethod<ListTasksInput & RegionInput, ListTasksOutput, ListTasksError, Credentials | HttpClient.HttpClient, TaskSummary>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds or replaces tags on a device or task.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag from a device or task.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=snow-device-management.d.ts.map