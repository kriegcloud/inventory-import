import * as API from "@distilled.cloud/core/api";
import * as HttpClient from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import * as Credentials from "./credentials.ts";
/**
 * Context (requirements) shared by every generated AWS operation.
 *
 * `Region` is deliberately absent: it is an optional override (see
 * `region.ts`), falling back to the region the credentials carry, so callers
 * who already configured a region for their credentials don't have to state
 * it again.
 */
export type AwsOpContext = Credentials.Credentials | HttpClient.HttpClient;
/**
 * The Protocol layer every generated AWS operation references. Failure and
 * requirement channels are erased at this boundary (see the note on
 * `encode`); the generated operation types reintroduce them.
 */
export declare const AwsProtocol: Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol.d.ts.map