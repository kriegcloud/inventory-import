import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidCampaignStateException_base: S.TaggedErrorClass<"InvalidCampaignStateException", {
    readonly state: any;
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidCampaignStateException extends /*@__PURE__*/ InvalidCampaignStateException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CampaignName = string;
export type InstanceId = string;
export type BandwidthAllocation = number;
export type DialingCapacity = number;
export interface ProgressiveDialerConfig {
    bandwidthAllocation: number;
    dialingCapacity?: number | undefined;
}
export interface PredictiveDialerConfig {
    bandwidthAllocation: number;
    dialingCapacity?: number | undefined;
}
export interface AgentlessDialerConfig {
    dialingCapacity?: number | undefined;
}
export type DialerConfig = {
    progressiveDialerConfig: ProgressiveDialerConfig;
    predictiveDialerConfig?: undefined;
    agentlessDialerConfig?: undefined;
} | {
    progressiveDialerConfig?: undefined;
    predictiveDialerConfig: PredictiveDialerConfig;
    agentlessDialerConfig?: undefined;
} | {
    progressiveDialerConfig?: undefined;
    predictiveDialerConfig?: undefined;
    agentlessDialerConfig: AgentlessDialerConfig;
};
export type ContactFlowId = string;
export type SourcePhoneNumber = string;
export type QueueId = string;
export interface AnswerMachineDetectionConfig {
    enableAnswerMachineDetection: boolean;
    awaitAnswerMachinePrompt?: boolean | undefined;
}
export interface OutboundCallConfig {
    connectContactFlowId: string;
    connectSourcePhoneNumber?: string | undefined;
    connectQueueId?: string | undefined;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCampaignRequest {
    name: string;
    connectInstanceId: string;
    dialerConfig: DialerConfig;
    outboundCallConfig: OutboundCallConfig;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CampaignId = string;
export type CampaignArn = string;
export interface CreateCampaignResponse {
    id?: string | undefined;
    arn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteCampaignRequest {
    id: string;
}
export interface DeleteCampaignResponse {
}
export interface DeleteConnectInstanceConfigRequest {
    connectInstanceId: string;
}
export interface DeleteConnectInstanceConfigResponse {
}
export interface DeleteInstanceOnboardingJobRequest {
    connectInstanceId: string;
}
export interface DeleteInstanceOnboardingJobResponse {
}
export interface DescribeCampaignRequest {
    id: string;
}
export interface Campaign {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
    dialerConfig: DialerConfig;
    outboundCallConfig: OutboundCallConfig;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeCampaignResponse {
    campaign?: Campaign | undefined;
}
export interface GetCampaignStateRequest {
    id: string;
}
export type CampaignState = string;
export interface GetCampaignStateResponse {
    state?: string | undefined;
}
export type CampaignIdList = string[];
export interface GetCampaignStateBatchRequest {
    campaignIds: string[];
}
export interface SuccessfulCampaignStateResponse {
    campaignId?: string | undefined;
    state?: string | undefined;
}
export type SuccessfulCampaignStateResponseList = SuccessfulCampaignStateResponse[];
export type GetCampaignStateBatchFailureCode = string;
export interface FailedCampaignStateResponse {
    campaignId?: string | undefined;
    failureCode?: string | undefined;
}
export type FailedCampaignStateResponseList = FailedCampaignStateResponse[];
export interface GetCampaignStateBatchResponse {
    successfulRequests?: SuccessfulCampaignStateResponse[] | undefined;
    failedRequests?: FailedCampaignStateResponse[] | undefined;
}
export interface GetConnectInstanceConfigRequest {
    connectInstanceId: string;
}
export type ServiceLinkedRoleArn = string;
export type Enabled = boolean;
export type EncryptionType = string;
export type EncryptionKey = string;
export interface EncryptionConfig {
    enabled: boolean;
    encryptionType?: string | undefined;
    keyArn?: string | undefined;
}
export interface InstanceConfig {
    connectInstanceId: string;
    serviceLinkedRoleArn: string;
    encryptionConfig: EncryptionConfig;
}
export interface GetConnectInstanceConfigResponse {
    connectInstanceConfig?: InstanceConfig | undefined;
}
export interface GetInstanceOnboardingJobStatusRequest {
    connectInstanceId: string;
}
export type InstanceOnboardingJobStatusCode = string;
export type InstanceOnboardingJobFailureCode = string;
export interface InstanceOnboardingJobStatus {
    connectInstanceId: string;
    status: string;
    failureCode?: string | undefined;
}
export interface GetInstanceOnboardingJobStatusResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export type InstanceIdFilterOperator = string;
export interface InstanceIdFilter {
    value: string;
    operator: string;
}
export interface CampaignFilters {
    instanceIdFilter?: InstanceIdFilter | undefined;
}
export interface ListCampaignsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: CampaignFilters | undefined;
}
export interface CampaignSummary {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
}
export type CampaignSummaryList = CampaignSummary[];
export interface ListCampaignsResponse {
    nextToken?: string | undefined;
    campaignSummaryList?: CampaignSummary[] | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PauseCampaignRequest {
    id: string;
}
export interface PauseCampaignResponse {
}
export type ClientToken = string;
export type DestinationPhoneNumber = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export interface DialRequest {
    clientToken: string;
    phoneNumber: string | redacted.Redacted<string>;
    expirationTime: Date;
    attributes: {
        [key: string]: string | undefined;
    };
}
export type DialRequestList = DialRequest[];
export interface PutDialRequestBatchRequest {
    id: string;
    dialRequests: DialRequest[];
}
export type DialRequestId = string;
export interface SuccessfulRequest {
    clientToken?: string | undefined;
    id?: string | undefined;
}
export type SuccessfulRequestList = SuccessfulRequest[];
export type FailureCode = string;
export interface FailedRequest {
    clientToken?: string | undefined;
    id?: string | undefined;
    failureCode?: string | undefined;
}
export type FailedRequestList = FailedRequest[];
export interface PutDialRequestBatchResponse {
    successfulRequests?: SuccessfulRequest[] | undefined;
    failedRequests?: FailedRequest[] | undefined;
}
export interface ResumeCampaignRequest {
    id: string;
}
export interface ResumeCampaignResponse {
}
export interface StartCampaignRequest {
    id: string;
}
export interface StartCampaignResponse {
}
export interface StartInstanceOnboardingJobRequest {
    connectInstanceId: string;
    encryptionConfig: EncryptionConfig;
}
export interface StartInstanceOnboardingJobResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus | undefined;
}
export interface StopCampaignRequest {
    id: string;
}
export interface StopCampaignResponse {
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCampaignDialerConfigRequest {
    id: string;
    dialerConfig: DialerConfig;
}
export interface UpdateCampaignDialerConfigResponse {
}
export interface UpdateCampaignNameRequest {
    id: string;
    name: string;
}
export interface UpdateCampaignNameResponse {
}
export interface UpdateCampaignOutboundCallConfigRequest {
    id: string;
    connectContactFlowId?: string | undefined;
    connectSourcePhoneNumber?: string | undefined;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig | undefined;
}
export interface UpdateCampaignOutboundCallConfigResponse {
}
export type XAmazonErrorType = string;
export type CreateCampaignError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a campaign for the specified Amazon Connect account. This API is idempotent.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest & RegionInput, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a campaign from the specified Amazon Connect account.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest & RegionInput, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectInstanceConfigError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connect instance config from the specified AWS account.
 */
export declare const deleteConnectInstanceConfig: API.OperationMethod<DeleteConnectInstanceConfigRequest & RegionInput, DeleteConnectInstanceConfigResponse, DeleteConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceOnboardingJobError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the Connect Campaigns onboarding job for the specified Amazon Connect instance.
 */
export declare const deleteInstanceOnboardingJob: API.OperationMethod<DeleteInstanceOnboardingJobRequest & RegionInput, DeleteInstanceOnboardingJobResponse, DeleteInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the specific campaign.
 */
export declare const describeCampaign: API.OperationMethod<DescribeCampaignRequest & RegionInput, DescribeCampaignResponse, DescribeCampaignError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of a campaign for the specified Amazon Connect account.
 */
export declare const getCampaignState: API.OperationMethod<GetCampaignStateRequest & RegionInput, GetCampaignStateResponse, GetCampaignStateError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateBatchError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of campaigns for the specified Amazon Connect account.
 */
export declare const getCampaignStateBatch: API.OperationMethod<GetCampaignStateBatchRequest & RegionInput, GetCampaignStateBatchResponse, GetCampaignStateBatchError, Credentials | HttpClient.HttpClient>;
export type GetConnectInstanceConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific Connect instance config.
 */
export declare const getConnectInstanceConfig: API.OperationMethod<GetConnectInstanceConfigRequest & RegionInput, GetConnectInstanceConfigResponse, GetConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type GetInstanceOnboardingJobStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific instance onboarding job status.
 */
export declare const getInstanceOnboardingJobStatus: API.OperationMethod<GetInstanceOnboardingJobStatusRequest & RegionInput, GetInstanceOnboardingJobStatusResponse, GetInstanceOnboardingJobStatusError, Credentials | HttpClient.HttpClient>;
export type ListCampaignsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Provides summary information about the campaigns under the specified Amazon Connect account.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest & RegionInput, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PauseCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Pauses a campaign for the specified Amazon Connect account.
 */
export declare const pauseCampaign: API.OperationMethod<PauseCampaignRequest & RegionInput, PauseCampaignResponse, PauseCampaignError, Credentials | HttpClient.HttpClient>;
export type PutDialRequestBatchError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates dials requests for the specified campaign Amazon Connect account. This API is idempotent.
 */
export declare const putDialRequestBatch: API.OperationMethod<PutDialRequestBatchRequest & RegionInput, PutDialRequestBatchResponse, PutDialRequestBatchError, Credentials | HttpClient.HttpClient>;
export type ResumeCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const resumeCampaign: API.OperationMethod<ResumeCampaignRequest & RegionInput, ResumeCampaignResponse, ResumeCampaignError, Credentials | HttpClient.HttpClient>;
export type StartCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a campaign for the specified Amazon Connect account.
 */
export declare const startCampaign: API.OperationMethod<StartCampaignRequest & RegionInput, StartCampaignResponse, StartCampaignError, Credentials | HttpClient.HttpClient>;
export type StartInstanceOnboardingJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Onboard the specific Amazon Connect instance to Connect Campaigns.
 */
export declare const startInstanceOnboardingJob: API.OperationMethod<StartInstanceOnboardingJobRequest & RegionInput, StartInstanceOnboardingJobResponse, StartInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type StopCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const stopCampaign: API.OperationMethod<StopCampaignRequest & RegionInput, StopCampaignResponse, StopCampaignError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignDialerConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the dialer config of a campaign. This API is idempotent.
 */
export declare const updateCampaignDialerConfig: API.OperationMethod<UpdateCampaignDialerConfigRequest & RegionInput, UpdateCampaignDialerConfigResponse, UpdateCampaignDialerConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignNameError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the name of a campaign. This API is idempotent.
 */
export declare const updateCampaignName: API.OperationMethod<UpdateCampaignNameRequest & RegionInput, UpdateCampaignNameResponse, UpdateCampaignNameError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignOutboundCallConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the outbound call config of a campaign. This API is idempotent.
 */
export declare const updateCampaignOutboundCallConfig: API.OperationMethod<UpdateCampaignOutboundCallConfigRequest & RegionInput, UpdateCampaignOutboundCallConfigResponse, UpdateCampaignOutboundCallConfigError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectcampaigns.d.ts.map