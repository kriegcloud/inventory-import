import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidEncodingException_base: S.TaggedErrorClass<"InvalidEncodingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEncodingException extends /*@__PURE__*/ InvalidEncodingException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TextSizeLimitExceededException_base: S.TaggedErrorClass<"TextSizeLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TextSizeLimitExceededException extends /*@__PURE__*/ TextSizeLimitExceededException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type JobId = string;
export interface DescribeEntitiesDetectionV2JobRequest {
    JobId: string;
}
export type JobName = string;
export type JobStatus = "SUBMITTED" | "IN_PROGRESS" | "COMPLETED" | "PARTIAL_SUCCESS" | "FAILED" | "STOP_REQUESTED" | "STOPPED" | (string & {});
export type AnyLengthString = string;
export type S3Bucket = string;
export type S3Key = string;
export interface InputDataConfig {
    S3Bucket: string;
    S3Key?: string | undefined;
}
export interface OutputDataConfig {
    S3Bucket: string;
    S3Key?: string | undefined;
}
export type LanguageCode = "en" | (string & {});
export type IamRoleArn = string;
export type ManifestFilePath = string;
export type KMSKey = string;
export type ModelVersion = string;
export interface ComprehendMedicalAsyncJobProperties {
    JobId?: string | undefined;
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    Message?: string | undefined;
    SubmitTime?: Date | undefined;
    EndTime?: Date | undefined;
    ExpirationTime?: Date | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    LanguageCode?: LanguageCode | undefined;
    DataAccessRoleArn?: string | undefined;
    ManifestFilePath?: string | undefined;
    KMSKey?: string | undefined;
    ModelVersion?: string | undefined;
}
export interface DescribeEntitiesDetectionV2JobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties | undefined;
}
export interface DescribeICD10CMInferenceJobRequest {
    JobId: string;
}
export interface DescribeICD10CMInferenceJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties | undefined;
}
export interface DescribePHIDetectionJobRequest {
    JobId: string;
}
export interface DescribePHIDetectionJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties | undefined;
}
export interface DescribeRxNormInferenceJobRequest {
    JobId: string;
}
export interface DescribeRxNormInferenceJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties | undefined;
}
export interface DescribeSNOMEDCTInferenceJobRequest {
    JobId: string;
}
export interface DescribeSNOMEDCTInferenceJobResponse {
    ComprehendMedicalAsyncJobProperties?: ComprehendMedicalAsyncJobProperties | undefined;
}
export type BoundedLengthString = string;
export interface DetectEntitiesRequest {
    Text: string;
}
export type EntityType = "MEDICATION" | "MEDICAL_CONDITION" | "PROTECTED_HEALTH_INFORMATION" | "TEST_TREATMENT_PROCEDURE" | "ANATOMY" | "TIME_EXPRESSION" | "BEHAVIORAL_ENVIRONMENTAL_SOCIAL" | (string & {});
export type EntitySubType = "NAME" | "DX_NAME" | "DOSAGE" | "ROUTE_OR_MODE" | "FORM" | "FREQUENCY" | "DURATION" | "GENERIC_NAME" | "BRAND_NAME" | "STRENGTH" | "RATE" | "ACUITY" | "TEST_NAME" | "TEST_VALUE" | "TEST_UNITS" | "TEST_UNIT" | "PROCEDURE_NAME" | "TREATMENT_NAME" | "DATE" | "AGE" | "CONTACT_POINT" | "PHONE_OR_FAX" | "EMAIL" | "IDENTIFIER" | "ID" | "URL" | "ADDRESS" | "PROFESSION" | "SYSTEM_ORGAN_SITE" | "DIRECTION" | "QUALITY" | "QUANTITY" | "TIME_EXPRESSION" | "TIME_TO_MEDICATION_NAME" | "TIME_TO_DX_NAME" | "TIME_TO_TEST_NAME" | "TIME_TO_PROCEDURE_NAME" | "TIME_TO_TREATMENT_NAME" | "AMOUNT" | "GENDER" | "RACE_ETHNICITY" | "ALLERGIES" | "TOBACCO_USE" | "ALCOHOL_CONSUMPTION" | "REC_DRUG_USE" | (string & {});
export type AttributeName = "SIGN" | "SYMPTOM" | "DIAGNOSIS" | "NEGATION" | "PERTAINS_TO_FAMILY" | "HYPOTHETICAL" | "LOW_CONFIDENCE" | "PAST_HISTORY" | "FUTURE" | (string & {});
export interface Trait {
    Name?: AttributeName | undefined;
    Score?: number | undefined;
}
export type TraitList = Trait[];
export type RelationshipType = "EVERY" | "WITH_DOSAGE" | "ADMINISTERED_VIA" | "FOR" | "NEGATIVE" | "OVERLAP" | "DOSAGE" | "ROUTE_OR_MODE" | "FORM" | "FREQUENCY" | "DURATION" | "STRENGTH" | "RATE" | "ACUITY" | "TEST_VALUE" | "TEST_UNITS" | "TEST_UNIT" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "AMOUNT" | "USAGE" | "QUALITY" | (string & {});
export interface Attribute {
    Type?: EntitySubType | undefined;
    Score?: number | undefined;
    RelationshipScore?: number | undefined;
    RelationshipType?: RelationshipType | undefined;
    Id?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Text?: string | undefined;
    Category?: EntityType | undefined;
    Traits?: Trait[] | undefined;
}
export type AttributeList = Attribute[];
export interface Entity {
    Id?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Score?: number | undefined;
    Text?: string | undefined;
    Category?: EntityType | undefined;
    Type?: EntitySubType | undefined;
    Traits?: Trait[] | undefined;
    Attributes?: Attribute[] | undefined;
}
export type EntityList = Entity[];
export interface UnmappedAttribute {
    Type?: EntityType | undefined;
    Attribute?: Attribute | undefined;
}
export type UnmappedAttributeList = UnmappedAttribute[];
export interface DetectEntitiesResponse {
    Entities: Entity[];
    UnmappedAttributes?: UnmappedAttribute[] | undefined;
    PaginationToken?: string | undefined;
    ModelVersion: string;
}
export interface DetectEntitiesV2Request {
    Text: string;
}
export interface DetectEntitiesV2Response {
    Entities: Entity[];
    UnmappedAttributes?: UnmappedAttribute[] | undefined;
    PaginationToken?: string | undefined;
    ModelVersion: string;
}
export interface DetectPHIRequest {
    Text: string;
}
export interface DetectPHIResponse {
    Entities: Entity[];
    PaginationToken?: string | undefined;
    ModelVersion: string;
}
export type OntologyLinkingBoundedLengthString = string;
export interface InferICD10CMRequest {
    Text: string;
}
export type ICD10CMEntityCategory = "MEDICAL_CONDITION" | (string & {});
export type ICD10CMEntityType = "DX_NAME" | "TIME_EXPRESSION" | (string & {});
export type ICD10CMAttributeType = "ACUITY" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "QUALITY" | "QUANTITY" | "TIME_TO_DX_NAME" | "TIME_EXPRESSION" | (string & {});
export type ICD10CMTraitName = "NEGATION" | "DIAGNOSIS" | "SIGN" | "SYMPTOM" | "PERTAINS_TO_FAMILY" | "HYPOTHETICAL" | "LOW_CONFIDENCE" | (string & {});
export interface ICD10CMTrait {
    Name?: ICD10CMTraitName | undefined;
    Score?: number | undefined;
}
export type ICD10CMTraitList = ICD10CMTrait[];
export type ICD10CMRelationshipType = "OVERLAP" | "SYSTEM_ORGAN_SITE" | "QUALITY" | (string & {});
export interface ICD10CMAttribute {
    Type?: ICD10CMAttributeType | undefined;
    Score?: number | undefined;
    RelationshipScore?: number | undefined;
    Id?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Text?: string | undefined;
    Traits?: ICD10CMTrait[] | undefined;
    Category?: ICD10CMEntityType | undefined;
    RelationshipType?: ICD10CMRelationshipType | undefined;
}
export type ICD10CMAttributeList = ICD10CMAttribute[];
export interface ICD10CMConcept {
    Description?: string | undefined;
    Code?: string | undefined;
    Score?: number | undefined;
}
export type ICD10CMConceptList = ICD10CMConcept[];
export interface ICD10CMEntity {
    Id?: number | undefined;
    Text?: string | undefined;
    Category?: ICD10CMEntityCategory | undefined;
    Type?: ICD10CMEntityType | undefined;
    Score?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Attributes?: ICD10CMAttribute[] | undefined;
    Traits?: ICD10CMTrait[] | undefined;
    ICD10CMConcepts?: ICD10CMConcept[] | undefined;
}
export type ICD10CMEntityList = ICD10CMEntity[];
export interface InferICD10CMResponse {
    Entities: ICD10CMEntity[];
    PaginationToken?: string | undefined;
    ModelVersion?: string | undefined;
}
export interface InferRxNormRequest {
    Text: string;
}
export type RxNormEntityCategory = "MEDICATION" | (string & {});
export type RxNormEntityType = "BRAND_NAME" | "GENERIC_NAME" | (string & {});
export type RxNormAttributeType = "DOSAGE" | "DURATION" | "FORM" | "FREQUENCY" | "RATE" | "ROUTE_OR_MODE" | "STRENGTH" | (string & {});
export type RxNormTraitName = "NEGATION" | "PAST_HISTORY" | (string & {});
export interface RxNormTrait {
    Name?: RxNormTraitName | undefined;
    Score?: number | undefined;
}
export type RxNormTraitList = RxNormTrait[];
export interface RxNormAttribute {
    Type?: RxNormAttributeType | undefined;
    Score?: number | undefined;
    RelationshipScore?: number | undefined;
    Id?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Text?: string | undefined;
    Traits?: RxNormTrait[] | undefined;
}
export type RxNormAttributeList = RxNormAttribute[];
export interface RxNormConcept {
    Description?: string | undefined;
    Code?: string | undefined;
    Score?: number | undefined;
}
export type RxNormConceptList = RxNormConcept[];
export interface RxNormEntity {
    Id?: number | undefined;
    Text?: string | undefined;
    Category?: RxNormEntityCategory | undefined;
    Type?: RxNormEntityType | undefined;
    Score?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Attributes?: RxNormAttribute[] | undefined;
    Traits?: RxNormTrait[] | undefined;
    RxNormConcepts?: RxNormConcept[] | undefined;
}
export type RxNormEntityList = RxNormEntity[];
export interface InferRxNormResponse {
    Entities: RxNormEntity[];
    PaginationToken?: string | undefined;
    ModelVersion?: string | undefined;
}
export interface InferSNOMEDCTRequest {
    Text: string;
}
export type SNOMEDCTEntityCategory = "MEDICAL_CONDITION" | "ANATOMY" | "TEST_TREATMENT_PROCEDURE" | (string & {});
export type SNOMEDCTEntityType = "DX_NAME" | "TEST_NAME" | "PROCEDURE_NAME" | "TREATMENT_NAME" | (string & {});
export type SNOMEDCTAttributeType = "ACUITY" | "QUALITY" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "TEST_VALUE" | "TEST_UNIT" | (string & {});
export type SNOMEDCTRelationshipType = "ACUITY" | "QUALITY" | "TEST_VALUE" | "TEST_UNITS" | "DIRECTION" | "SYSTEM_ORGAN_SITE" | "TEST_UNIT" | (string & {});
export type SNOMEDCTTraitName = "NEGATION" | "DIAGNOSIS" | "SIGN" | "SYMPTOM" | "PERTAINS_TO_FAMILY" | "HYPOTHETICAL" | "LOW_CONFIDENCE" | "PAST_HISTORY" | "FUTURE" | (string & {});
export interface SNOMEDCTTrait {
    Name?: SNOMEDCTTraitName | undefined;
    Score?: number | undefined;
}
export type SNOMEDCTTraitList = SNOMEDCTTrait[];
export interface SNOMEDCTConcept {
    Description?: string | undefined;
    Code?: string | undefined;
    Score?: number | undefined;
}
export type SNOMEDCTConceptList = SNOMEDCTConcept[];
export interface SNOMEDCTAttribute {
    Category?: SNOMEDCTEntityCategory | undefined;
    Type?: SNOMEDCTAttributeType | undefined;
    Score?: number | undefined;
    RelationshipScore?: number | undefined;
    RelationshipType?: SNOMEDCTRelationshipType | undefined;
    Id?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Text?: string | undefined;
    Traits?: SNOMEDCTTrait[] | undefined;
    SNOMEDCTConcepts?: SNOMEDCTConcept[] | undefined;
}
export type SNOMEDCTAttributeList = SNOMEDCTAttribute[];
export interface SNOMEDCTEntity {
    Id?: number | undefined;
    Text?: string | undefined;
    Category?: SNOMEDCTEntityCategory | undefined;
    Type?: SNOMEDCTEntityType | undefined;
    Score?: number | undefined;
    BeginOffset?: number | undefined;
    EndOffset?: number | undefined;
    Attributes?: SNOMEDCTAttribute[] | undefined;
    Traits?: SNOMEDCTTrait[] | undefined;
    SNOMEDCTConcepts?: SNOMEDCTConcept[] | undefined;
}
export type SNOMEDCTEntityList = SNOMEDCTEntity[];
export interface SNOMEDCTDetails {
    Edition?: string | undefined;
    Language?: string | undefined;
    VersionDate?: string | undefined;
}
export interface Characters {
    OriginalTextCharacters?: number | undefined;
}
export interface InferSNOMEDCTResponse {
    Entities: SNOMEDCTEntity[];
    PaginationToken?: string | undefined;
    ModelVersion?: string | undefined;
    SNOMEDCTDetails?: SNOMEDCTDetails | undefined;
    Characters?: Characters | undefined;
}
export interface ComprehendMedicalAsyncJobFilter {
    JobName?: string | undefined;
    JobStatus?: JobStatus | undefined;
    SubmitTimeBefore?: Date | undefined;
    SubmitTimeAfter?: Date | undefined;
}
export type MaxResultsInteger = number;
export interface ListEntitiesDetectionV2JobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ComprehendMedicalAsyncJobPropertiesList = ComprehendMedicalAsyncJobProperties[];
export interface ListEntitiesDetectionV2JobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListICD10CMInferenceJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListICD10CMInferenceJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPHIDetectionJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListPHIDetectionJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRxNormInferenceJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListRxNormInferenceJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSNOMEDCTInferenceJobsRequest {
    Filter?: ComprehendMedicalAsyncJobFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListSNOMEDCTInferenceJobsResponse {
    ComprehendMedicalAsyncJobPropertiesList?: ComprehendMedicalAsyncJobProperties[] | undefined;
    NextToken?: string | undefined;
}
export type ClientRequestTokenString = string;
export interface StartEntitiesDetectionV2JobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    ClientRequestToken?: string | undefined;
    KMSKey?: string | undefined;
    LanguageCode: LanguageCode;
}
export interface StartEntitiesDetectionV2JobResponse {
    JobId?: string | undefined;
}
export interface StartICD10CMInferenceJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    ClientRequestToken?: string | undefined;
    KMSKey?: string | undefined;
    LanguageCode: LanguageCode;
}
export interface StartICD10CMInferenceJobResponse {
    JobId?: string | undefined;
}
export interface StartPHIDetectionJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    ClientRequestToken?: string | undefined;
    KMSKey?: string | undefined;
    LanguageCode: LanguageCode;
}
export interface StartPHIDetectionJobResponse {
    JobId?: string | undefined;
}
export interface StartRxNormInferenceJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    ClientRequestToken?: string | undefined;
    KMSKey?: string | undefined;
    LanguageCode: LanguageCode;
}
export interface StartRxNormInferenceJobResponse {
    JobId?: string | undefined;
}
export interface StartSNOMEDCTInferenceJobRequest {
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
    DataAccessRoleArn: string;
    JobName?: string | undefined;
    ClientRequestToken?: string | undefined;
    KMSKey?: string | undefined;
    LanguageCode: LanguageCode;
}
export interface StartSNOMEDCTInferenceJobResponse {
    JobId?: string | undefined;
}
export interface StopEntitiesDetectionV2JobRequest {
    JobId: string;
}
export interface StopEntitiesDetectionV2JobResponse {
    JobId?: string | undefined;
}
export interface StopICD10CMInferenceJobRequest {
    JobId: string;
}
export interface StopICD10CMInferenceJobResponse {
    JobId?: string | undefined;
}
export interface StopPHIDetectionJobRequest {
    JobId: string;
}
export interface StopPHIDetectionJobResponse {
    JobId?: string | undefined;
}
export interface StopRxNormInferenceJobRequest {
    JobId: string;
}
export interface StopRxNormInferenceJobResponse {
    JobId?: string | undefined;
}
export interface StopSNOMEDCTInferenceJobRequest {
    JobId: string;
}
export interface StopSNOMEDCTInferenceJobResponse {
    JobId?: string | undefined;
}
export type DescribeEntitiesDetectionV2JobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a medical entities detection job. Use this operation
 * to get the status of a detection job.
 */
export declare const describeEntitiesDetectionV2Job: API.OperationMethod<DescribeEntitiesDetectionV2JobRequest & RegionInput, DescribeEntitiesDetectionV2JobResponse, DescribeEntitiesDetectionV2JobError, Credentials | HttpClient.HttpClient>;
export type DescribeICD10CMInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an InferICD10CM job. Use this operation to get the
 * status of an inference job.
 */
export declare const describeICD10CMInferenceJob: API.OperationMethod<DescribeICD10CMInferenceJobRequest & RegionInput, DescribeICD10CMInferenceJobResponse, DescribeICD10CMInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DescribePHIDetectionJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with a protected health information (PHI) detection job.
 * Use this operation to get the status of a detection job.
 */
export declare const describePHIDetectionJob: API.OperationMethod<DescribePHIDetectionJobRequest & RegionInput, DescribePHIDetectionJobResponse, DescribePHIDetectionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeRxNormInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an InferRxNorm job. Use this operation to get the
 * status of an inference job.
 */
export declare const describeRxNormInferenceJob: API.OperationMethod<DescribeRxNormInferenceJobRequest & RegionInput, DescribeRxNormInferenceJobResponse, DescribeRxNormInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DescribeSNOMEDCTInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Gets the properties associated with an InferSNOMEDCT job. Use this operation to get the status of an inference job.
 */
export declare const describeSNOMEDCTInferenceJob: API.OperationMethod<DescribeSNOMEDCTInferenceJobRequest & RegionInput, DescribeSNOMEDCTInferenceJobResponse, DescribeSNOMEDCTInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DetectEntitiesError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * The `DetectEntities` operation is deprecated. You should use the DetectEntitiesV2 operation instead.
 *
 * Inspects the clinical text for a variety of medical entities and returns specific
 * information about them such as entity category, location, and confidence score on that
 * information.
 */
export declare const detectEntities: API.OperationMethod<DetectEntitiesRequest & RegionInput, DetectEntitiesResponse, DetectEntitiesError, Credentials | HttpClient.HttpClient>;
export type DetectEntitiesV2Error = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Inspects the clinical text for a variety of medical entities and returns specific
 * information about them such as entity category, location, and confidence score on that
 * information. Amazon Comprehend Medical only detects medical entities in English language
 * texts.
 *
 * The `DetectEntitiesV2` operation replaces the DetectEntities
 * operation. This new action uses a different model for determining the entities in your medical
 * text and changes the way that some entities are returned in the output. You should use the
 * `DetectEntitiesV2` operation in all new applications.
 *
 * The `DetectEntitiesV2` operation returns the `Acuity` and
 * `Direction` entities as attributes instead of types.
 */
export declare const detectEntitiesV2: API.OperationMethod<DetectEntitiesV2Request & RegionInput, DetectEntitiesV2Response, DetectEntitiesV2Error, Credentials | HttpClient.HttpClient>;
export type DetectPHIError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Inspects the clinical text for protected health information (PHI) entities and returns
 * the entity category, location, and confidence score for each entity. Amazon Comprehend Medical
 * only detects entities in English language texts.
 */
export declare const detectPHI: API.OperationMethod<DetectPHIRequest & RegionInput, DetectPHIResponse, DetectPHIError, Credentials | HttpClient.HttpClient>;
export type InferICD10CMError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * InferICD10CM detects medical conditions as entities listed in a patient record and links
 * those entities to normalized concept identifiers in the ICD-10-CM knowledge base from the
 * Centers for Disease Control. Amazon Comprehend Medical only detects medical entities in
 * English language texts.
 */
export declare const inferICD10CM: API.OperationMethod<InferICD10CMRequest & RegionInput, InferICD10CMResponse, InferICD10CMError, Credentials | HttpClient.HttpClient>;
export type InferRxNormError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * InferRxNorm detects medications as entities listed in a patient record and links to the
 * normalized concept identifiers in the RxNorm database from the National Library of Medicine.
 * Amazon Comprehend Medical only detects medical entities in English language texts.
 */
export declare const inferRxNorm: API.OperationMethod<InferRxNormRequest & RegionInput, InferRxNormResponse, InferRxNormError, Credentials | HttpClient.HttpClient>;
export type InferSNOMEDCTError = InternalServerException | InvalidEncodingException | InvalidRequestException | ServiceUnavailableException | TextSizeLimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * InferSNOMEDCT detects possible medical concepts as entities and links them to codes from the Systematized Nomenclature of Medicine, Clinical Terms (SNOMED-CT) ontology
 */
export declare const inferSNOMEDCT: API.OperationMethod<InferSNOMEDCTRequest & RegionInput, InferSNOMEDCTResponse, InferSNOMEDCTError, Credentials | HttpClient.HttpClient>;
export type ListEntitiesDetectionV2JobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of medical entity detection jobs that you have submitted.
 */
export declare const listEntitiesDetectionV2Jobs: API.OperationMethod<ListEntitiesDetectionV2JobsRequest & RegionInput, ListEntitiesDetectionV2JobsResponse, ListEntitiesDetectionV2JobsError, Credentials | HttpClient.HttpClient>;
export type ListICD10CMInferenceJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of InferICD10CM jobs that you have submitted.
 */
export declare const listICD10CMInferenceJobs: API.OperationMethod<ListICD10CMInferenceJobsRequest & RegionInput, ListICD10CMInferenceJobsResponse, ListICD10CMInferenceJobsError, Credentials | HttpClient.HttpClient>;
export type ListPHIDetectionJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of protected health information (PHI) detection jobs you have
 * submitted.
 */
export declare const listPHIDetectionJobs: API.OperationMethod<ListPHIDetectionJobsRequest & RegionInput, ListPHIDetectionJobsResponse, ListPHIDetectionJobsError, Credentials | HttpClient.HttpClient>;
export type ListRxNormInferenceJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of InferRxNorm jobs that you have submitted.
 */
export declare const listRxNormInferenceJobs: API.OperationMethod<ListRxNormInferenceJobsRequest & RegionInput, ListRxNormInferenceJobsResponse, ListRxNormInferenceJobsError, Credentials | HttpClient.HttpClient>;
export type ListSNOMEDCTInferenceJobsError = InternalServerException | InvalidRequestException | TooManyRequestsException | ValidationException | CommonErrors;
/**
 * Gets a list of InferSNOMEDCT jobs a user has submitted.
 */
export declare const listSNOMEDCTInferenceJobs: API.OperationMethod<ListSNOMEDCTInferenceJobsRequest & RegionInput, ListSNOMEDCTInferenceJobsResponse, ListSNOMEDCTInferenceJobsError, Credentials | HttpClient.HttpClient>;
export type StartEntitiesDetectionV2JobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous medical entity detection job for a collection of documents. Use the
 * `DescribeEntitiesDetectionV2Job` operation to track the status of a job.
 */
export declare const startEntitiesDetectionV2Job: API.OperationMethod<StartEntitiesDetectionV2JobRequest & RegionInput, StartEntitiesDetectionV2JobResponse, StartEntitiesDetectionV2JobError, Credentials | HttpClient.HttpClient>;
export type StartICD10CMInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect medical conditions and link them to the ICD-10-CM
 * ontology. Use the `DescribeICD10CMInferenceJob` operation to track the status of a
 * job.
 */
export declare const startICD10CMInferenceJob: API.OperationMethod<StartICD10CMInferenceJobRequest & RegionInput, StartICD10CMInferenceJobResponse, StartICD10CMInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StartPHIDetectionJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect protected health information (PHI). Use the
 * `DescribePHIDetectionJob` operation to track the status of a job.
 */
export declare const startPHIDetectionJob: API.OperationMethod<StartPHIDetectionJobRequest & RegionInput, StartPHIDetectionJobResponse, StartPHIDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StartRxNormInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect medication entities and link them to the RxNorm
 * ontology. Use the `DescribeRxNormInferenceJob` operation to track the status of a
 * job.
 */
export declare const startRxNormInferenceJob: API.OperationMethod<StartRxNormInferenceJobRequest & RegionInput, StartRxNormInferenceJobResponse, StartRxNormInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StartSNOMEDCTInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Starts an asynchronous job to detect medical concepts and link them to the SNOMED-CT ontology. Use the DescribeSNOMEDCTInferenceJob operation to track the status of a job.
 */
export declare const startSNOMEDCTInferenceJob: API.OperationMethod<StartSNOMEDCTInferenceJobRequest & RegionInput, StartSNOMEDCTInferenceJobResponse, StartSNOMEDCTInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StopEntitiesDetectionV2JobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a medical entities detection job in progress.
 */
export declare const stopEntitiesDetectionV2Job: API.OperationMethod<StopEntitiesDetectionV2JobRequest & RegionInput, StopEntitiesDetectionV2JobResponse, StopEntitiesDetectionV2JobError, Credentials | HttpClient.HttpClient>;
export type StopICD10CMInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops an InferICD10CM inference job in progress.
 */
export declare const stopICD10CMInferenceJob: API.OperationMethod<StopICD10CMInferenceJobRequest & RegionInput, StopICD10CMInferenceJobResponse, StopICD10CMInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StopPHIDetectionJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a protected health information (PHI) detection job in progress.
 */
export declare const stopPHIDetectionJob: API.OperationMethod<StopPHIDetectionJobRequest & RegionInput, StopPHIDetectionJobResponse, StopPHIDetectionJobError, Credentials | HttpClient.HttpClient>;
export type StopRxNormInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Stops an InferRxNorm inference job in progress.
 */
export declare const stopRxNormInferenceJob: API.OperationMethod<StopRxNormInferenceJobRequest & RegionInput, StopRxNormInferenceJobResponse, StopRxNormInferenceJobError, Credentials | HttpClient.HttpClient>;
export type StopSNOMEDCTInferenceJobError = InternalServerException | InvalidRequestException | ResourceNotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Stops an InferSNOMEDCT inference job in progress.
 */
export declare const stopSNOMEDCTInferenceJob: API.OperationMethod<StopSNOMEDCTInferenceJobRequest & RegionInput, StopSNOMEDCTInferenceJobResponse, StopSNOMEDCTInferenceJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=comprehendmedical.d.ts.map