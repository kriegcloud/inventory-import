/**
 * Construction-time capture of embedded SQL migrations. Kept apart from
 * `Embedded.ts` so a runtime bundle that only applies migrations never
 * reaches the deploy-time file readers.
 *
 * @internal
 */
import * as Effect from "effect/Effect";
import { type SqlMigrationSnapshot, type SqlMigrationsExport } from "./Embedded.ts";
/** A migrations directory, optionally with a custom bookkeeping table. */
export type SqlMigrationsInput = string | {
    /** Directory relative to the directory where Alchemy runs. */
    readonly dir: string;
    /** Applied-migrations table. Defaults to `__alchemy_migrations`. */
    readonly table?: string;
};
/** The hosting Worker a snapshot is exported onto during construction. */
export interface SqlMigrationsHost {
    readonly export: (name: string, value: SqlMigrationsExport) => Effect.Effect<void>;
}
/**
 * Capture files during construction and export them onto the hosting
 * Worker; at runtime, resolve only the records embedded in the bundle.
 */
export declare const captureSqlMigrations: <R>(input: SqlMigrationsInput, host: Effect.Effect<SqlMigrationsHost, never, R>) => Effect.Effect<SqlMigrationSnapshot, never, R | import("effect/FileSystem").FileSystem | import("effect/Path").Path>;
//# sourceMappingURL=EmbeddedCapture.d.ts.map