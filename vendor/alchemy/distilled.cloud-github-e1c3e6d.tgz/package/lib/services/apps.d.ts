import * as API from "@distilled.cloud/core/api";
import type * as Redacted from "effect/Redacted";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AddRepoToInstallationForAuthenticatedUserRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface AddRepoToInstallationForAuthenticatedUserResponse {
}
export interface CheckTokenRequest {
    /** The client ID of the GitHub app. */
    client_id: string;
    /** The access_token of the OAuth or GitHub application. */
    access_token: string | Redacted.Redacted<string>;
}
/** A list of scopes that this authorization is in. */
export type AuthorizationScopesList = Array<string>;
export interface AuthorizationApp {
    client_id: string;
    name: string;
    url: string;
}
/** A GitHub user. */
export interface NullableSimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** The level of permission to grant the access token for GitHub Actions workflows, workflow runs, and artifacts. */
export type AppPermissionsActions = "read" | "write";
/** The level of permission to grant the access token for repository creation, deletion, settings, teams, and collaborators creation. */
export type AppPermissionsAdministration = "read" | "write";
/** The level of permission to grant the access token to create and retrieve build artifact metadata records. */
export type AppPermissionsArtifactMetadata = "read" | "write";
/** The level of permission to create and retrieve the access token for repository attestations. */
export type AppPermissionsAttestations = "read" | "write";
/** The level of permission to grant the access token for checks on code. */
export type AppPermissionsChecks = "read" | "write";
/** The level of permission to grant the access token to view and manage code quality data. */
export type AppPermissionsCodeQuality = "read" | "write";
/** The level of permission to grant the access token to create, edit, delete, and list Codespaces. */
export type AppPermissionsCodespaces = "read" | "write";
/** The level of permission to grant the access token for repository contents, commits, branches, downloads, releases, and merges. */
export type AppPermissionsContents = "read" | "write";
/** The level of permission to grant the access token to manage Dependabot secrets. */
export type AppPermissionsDependabotSecrets = "read" | "write";
/** The level of permission to grant the access token for deployments and deployment statuses. */
export type AppPermissionsDeployments = "read" | "write";
/** The level of permission to grant the access token for discussions and related comments and labels. */
export type AppPermissionsDiscussions = "read" | "write";
/** The level of permission to grant the access token for managing repository environments. */
export type AppPermissionsEnvironments = "read" | "write";
/** The level of permission to grant the access token for issues and related comments, assignees, labels, and milestones. */
export type AppPermissionsIssues = "read" | "write";
/** The level of permission to grant the access token to manage the merge queues for a repository. */
export type AppPermissionsMergeQueues = "read" | "write";
/** The level of permission to grant the access token to search repositories, list collaborators, and access repository metadata. */
export type AppPermissionsMetadata = "read" | "write";
/** The level of permission to grant the access token for packages published to GitHub Packages. */
export type AppPermissionsPackages = "read" | "write";
/** The level of permission to grant the access token to retrieve Pages statuses, configuration, and builds, as well as create new builds. */
export type AppPermissionsPages = "read" | "write";
/** The level of permission to grant the access token for pull requests and related comments, assignees, labels, milestones, and merges. */
export type AppPermissionsPullRequests = "read" | "write";
/** The level of permission to grant the access token to view and edit custom properties for a repository, when allowed by the property. */
export type AppPermissionsRepositoryCustomProperties = "read" | "write";
/** The level of permission to grant the access token to manage the post-receive hooks for a repository. */
export type AppPermissionsRepositoryHooks = "read" | "write";
/** The level of permission to grant the access token to manage repository projects, columns, and cards. */
export type AppPermissionsRepositoryProjects = "read" | "write" | "admin";
/** The level of permission to grant the access token to view and manage secret scanning alerts. */
export type AppPermissionsSecretScanningAlerts = "read" | "write";
/** The level of permission to grant the access token to manage repository secrets. */
export type AppPermissionsSecrets = "read" | "write";
/** The level of permission to grant the access token to view and manage security events like code scanning alerts. */
export type AppPermissionsSecurityEvents = "read" | "write";
/** The level of permission to grant the access token to manage just a single file. */
export type AppPermissionsSingleFile = "read" | "write";
/** The level of permission to grant the access token for commit statuses. */
export type AppPermissionsStatuses = "read" | "write";
/** The level of permission to grant the access token to manage Dependabot alerts. */
export type AppPermissionsVulnerabilityAlerts = "read" | "write";
/** The level of permission to grant the access token to update GitHub Actions workflow files. */
export type AppPermissionsWorkflows = "write";
/** The level of permission to grant the access token to view and edit custom properties for an organization, when allowed by the property. */
export type AppPermissionsCustomPropertiesForOrganizations = "read" | "write";
/** The level of permission to grant the access token for organization teams and members. */
export type AppPermissionsMembers = "read" | "write";
/** The level of permission to grant the access token to manage access to an organization. */
export type AppPermissionsOrganizationAdministration = "read" | "write";
/** The level of permission to grant the access token for custom repository roles management. */
export type AppPermissionsOrganizationCustomRoles = "read" | "write";
/** The level of permission to grant the access token for custom organization roles management. */
export type AppPermissionsOrganizationCustomOrgRoles = "read" | "write";
/** The level of permission to grant the access token for repository custom properties management at the organization level. */
export type AppPermissionsOrganizationCustomProperties = "read" | "write" | "admin";
/** The level of permission to grant the access token for managing access to GitHub Copilot for members of an organization with a Copilot Business subscription. This property is in public preview and is subject to change. */
export type AppPermissionsOrganizationCopilotSeatManagement = "read" | "write";
/** The level of permission to grant the access token to view and manage Copilot cloud agent settings for an organization. */
export type AppPermissionsOrganizationCopilotAgentSettings = "read" | "write";
/** The level of permission to grant the access token to make Copilot requests billed to the organization where the app is installed. This property is in public preview and is subject to change. */
export type AppPermissionsOrganizationCopilotRequests = "read";
/** The level of permission to grant the access token for managing external custom properties for repositories in an organization. */
export type AppPermissionsOrganizationExternalPropertiesForRepos = "read" | "write" | "admin";
/** The level of permission to grant the access token to view and manage announcement banners for an organization. */
export type AppPermissionsOrganizationAnnouncementBanners = "read" | "write";
/** The level of permission to grant the access token to view events triggered by an activity in an organization. */
export type AppPermissionsOrganizationEvents = "read";
/** The level of permission to grant the access token to manage the post-receive hooks for an organization. */
export type AppPermissionsOrganizationHooks = "read" | "write";
/** The level of permission to grant the access token for viewing and managing fine-grained personal access token requests to an organization. */
export type AppPermissionsOrganizationPersonalAccessTokens = "read" | "write";
/** The level of permission to grant the access token for viewing and managing fine-grained personal access tokens that have been approved by an organization. */
export type AppPermissionsOrganizationPersonalAccessTokenRequests = "read" | "write";
/** The level of permission to grant the access token for viewing an organization's plan. */
export type AppPermissionsOrganizationPlan = "read";
/** The level of permission to grant the access token to manage organization projects and projects public preview (where available). */
export type AppPermissionsOrganizationProjects = "read" | "write" | "admin";
/** The level of permission to grant the access token for organization packages published to GitHub Packages. */
export type AppPermissionsOrganizationPackages = "read" | "write";
/** The level of permission to grant the access token to manage organization secrets. */
export type AppPermissionsOrganizationSecrets = "read" | "write";
/** The level of permission to grant the access token to view and manage GitHub Actions self-hosted runners available to an organization. */
export type AppPermissionsOrganizationSelfHostedRunners = "read" | "write";
/** The level of permission to grant the access token to view and manage users blocked by the organization. */
export type AppPermissionsOrganizationUserBlocking = "read" | "write";
/** The level of permission to grant the access token to manage the email addresses belonging to a user. */
export type AppPermissionsEmailAddresses = "read" | "write";
/** The level of permission to grant the access token to manage the followers belonging to a user. */
export type AppPermissionsFollowers = "read" | "write";
/** The level of permission to grant the access token to manage git SSH keys. */
export type AppPermissionsGitSshKeys = "read" | "write";
/** The level of permission to grant the access token to view and manage GPG keys belonging to a user. */
export type AppPermissionsGpgKeys = "read" | "write";
/** The level of permission to grant the access token to view and manage interaction limits on a repository. */
export type AppPermissionsInteractionLimits = "read" | "write";
/** The level of permission to grant the access token to manage the profile settings belonging to a user. */
export type AppPermissionsProfile = "write";
/** The level of permission to grant the access token to list and manage repositories a user is starring. */
export type AppPermissionsStarring = "read" | "write";
/** The level of permission to grant the access token for organization custom properties management at the enterprise level. */
export type AppPermissionsEnterpriseCustomPropertiesForOrganizations = "read" | "write" | "admin";
/** The permissions granted to the fine-grained access token. */
export interface AppPermissions {
    /** The level of permission to grant the access token for GitHub Actions workflows, workflow runs, and artifacts. */
    actions?: AppPermissionsActions | (string & {}) | undefined;
    /** The level of permission to grant the access token for repository creation, deletion, settings, teams, and collaborators creation. */
    administration?: AppPermissionsAdministration | (string & {}) | undefined;
    /** The level of permission to grant the access token to create and retrieve build artifact metadata records. */
    artifact_metadata?: AppPermissionsArtifactMetadata | (string & {}) | undefined;
    /** The level of permission to create and retrieve the access token for repository attestations. */
    attestations?: AppPermissionsAttestations | (string & {}) | undefined;
    /** The level of permission to grant the access token for checks on code. */
    checks?: AppPermissionsChecks | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage code quality data. */
    code_quality?: AppPermissionsCodeQuality | (string & {}) | undefined;
    /** The level of permission to grant the access token to create, edit, delete, and list Codespaces. */
    codespaces?: AppPermissionsCodespaces | (string & {}) | undefined;
    /** The level of permission to grant the access token for repository contents, commits, branches, downloads, releases, and merges. */
    contents?: AppPermissionsContents | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage Dependabot secrets. */
    dependabot_secrets?: AppPermissionsDependabotSecrets | (string & {}) | undefined;
    /** The level of permission to grant the access token for deployments and deployment statuses. */
    deployments?: AppPermissionsDeployments | (string & {}) | undefined;
    /** The level of permission to grant the access token for discussions and related comments and labels. */
    discussions?: AppPermissionsDiscussions | (string & {}) | undefined;
    /** The level of permission to grant the access token for managing repository environments. */
    environments?: AppPermissionsEnvironments | (string & {}) | undefined;
    /** The level of permission to grant the access token for issues and related comments, assignees, labels, and milestones. */
    issues?: AppPermissionsIssues | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage the merge queues for a repository. */
    merge_queues?: AppPermissionsMergeQueues | (string & {}) | undefined;
    /** The level of permission to grant the access token to search repositories, list collaborators, and access repository metadata. */
    metadata?: AppPermissionsMetadata | (string & {}) | undefined;
    /** The level of permission to grant the access token for packages published to GitHub Packages. */
    packages?: AppPermissionsPackages | (string & {}) | undefined;
    /** The level of permission to grant the access token to retrieve Pages statuses, configuration, and builds, as well as create new builds. */
    pages?: AppPermissionsPages | (string & {}) | undefined;
    /** The level of permission to grant the access token for pull requests and related comments, assignees, labels, milestones, and merges. */
    pull_requests?: AppPermissionsPullRequests | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and edit custom properties for a repository, when allowed by the property. */
    repository_custom_properties?: AppPermissionsRepositoryCustomProperties | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage the post-receive hooks for a repository. */
    repository_hooks?: AppPermissionsRepositoryHooks | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage repository projects, columns, and cards. */
    repository_projects?: AppPermissionsRepositoryProjects | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage secret scanning alerts. */
    secret_scanning_alerts?: AppPermissionsSecretScanningAlerts | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage repository secrets. */
    secrets?: AppPermissionsSecrets | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage security events like code scanning alerts. */
    security_events?: AppPermissionsSecurityEvents | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage just a single file. */
    single_file?: AppPermissionsSingleFile | (string & {}) | undefined;
    /** The level of permission to grant the access token for commit statuses. */
    statuses?: AppPermissionsStatuses | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage Dependabot alerts. */
    vulnerability_alerts?: AppPermissionsVulnerabilityAlerts | (string & {}) | undefined;
    /** The level of permission to grant the access token to update GitHub Actions workflow files. */
    workflows?: AppPermissionsWorkflows | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and edit custom properties for an organization, when allowed by the property. */
    custom_properties_for_organizations?: AppPermissionsCustomPropertiesForOrganizations | (string & {}) | undefined;
    /** The level of permission to grant the access token for organization teams and members. */
    members?: AppPermissionsMembers | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage access to an organization. */
    organization_administration?: AppPermissionsOrganizationAdministration | (string & {}) | undefined;
    /** The level of permission to grant the access token for custom repository roles management. */
    organization_custom_roles?: AppPermissionsOrganizationCustomRoles | (string & {}) | undefined;
    /** The level of permission to grant the access token for custom organization roles management. */
    organization_custom_org_roles?: AppPermissionsOrganizationCustomOrgRoles | (string & {}) | undefined;
    /** The level of permission to grant the access token for repository custom properties management at the organization level. */
    organization_custom_properties?: AppPermissionsOrganizationCustomProperties | (string & {}) | undefined;
    /** The level of permission to grant the access token for managing access to GitHub Copilot for members of an organization with a Copilot Business subscription. This property is in public preview and is subject to change. */
    organization_copilot_seat_management?: AppPermissionsOrganizationCopilotSeatManagement | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage Copilot cloud agent settings for an organization. */
    organization_copilot_agent_settings?: AppPermissionsOrganizationCopilotAgentSettings | (string & {}) | undefined;
    /** The level of permission to grant the access token to make Copilot requests billed to the organization where the app is installed. This property is in public preview and is subject to change. */
    organization_copilot_requests?: AppPermissionsOrganizationCopilotRequests | (string & {}) | undefined;
    /** The level of permission to grant the access token for managing external custom properties for repositories in an organization. */
    organization_external_properties_for_repos?: AppPermissionsOrganizationExternalPropertiesForRepos | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage announcement banners for an organization. */
    organization_announcement_banners?: AppPermissionsOrganizationAnnouncementBanners | (string & {}) | undefined;
    /** The level of permission to grant the access token to view events triggered by an activity in an organization. */
    organization_events?: AppPermissionsOrganizationEvents | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage the post-receive hooks for an organization. */
    organization_hooks?: AppPermissionsOrganizationHooks | (string & {}) | undefined;
    /** The level of permission to grant the access token for viewing and managing fine-grained personal access token requests to an organization. */
    organization_personal_access_tokens?: AppPermissionsOrganizationPersonalAccessTokens | (string & {}) | undefined;
    /** The level of permission to grant the access token for viewing and managing fine-grained personal access tokens that have been approved by an organization. */
    organization_personal_access_token_requests?: AppPermissionsOrganizationPersonalAccessTokenRequests | (string & {}) | undefined;
    /** The level of permission to grant the access token for viewing an organization's plan. */
    organization_plan?: AppPermissionsOrganizationPlan | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage organization projects and projects public preview (where available). */
    organization_projects?: AppPermissionsOrganizationProjects | (string & {}) | undefined;
    /** The level of permission to grant the access token for organization packages published to GitHub Packages. */
    organization_packages?: AppPermissionsOrganizationPackages | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage organization secrets. */
    organization_secrets?: AppPermissionsOrganizationSecrets | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage GitHub Actions self-hosted runners available to an organization. */
    organization_self_hosted_runners?: AppPermissionsOrganizationSelfHostedRunners | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage users blocked by the organization. */
    organization_user_blocking?: AppPermissionsOrganizationUserBlocking | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage the email addresses belonging to a user. */
    email_addresses?: AppPermissionsEmailAddresses | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage the followers belonging to a user. */
    followers?: AppPermissionsFollowers | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage git SSH keys. */
    git_ssh_keys?: AppPermissionsGitSshKeys | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage GPG keys belonging to a user. */
    gpg_keys?: AppPermissionsGpgKeys | (string & {}) | undefined;
    /** The level of permission to grant the access token to view and manage interaction limits on a repository. */
    interaction_limits?: AppPermissionsInteractionLimits | (string & {}) | undefined;
    /** The level of permission to grant the access token to manage the profile settings belonging to a user. */
    profile?: AppPermissionsProfile | (string & {}) | undefined;
    /** The level of permission to grant the access token to list and manage repositories a user is starring. */
    starring?: AppPermissionsStarring | (string & {}) | undefined;
    /** The level of permission to grant the access token for organization custom properties management at the enterprise level. */
    enterprise_custom_properties_for_organizations?: AppPermissionsEnterpriseCustomPropertiesForOrganizations | (string & {}) | undefined;
}
/** Describe whether all repositories have been selected or there's a selection involved */
export type NullableScopedInstallationRepositorySelection = "all" | "selected";
export type NullableScopedInstallationSingleFilePathsList = Array<string>;
/** A GitHub user. */
export type SimpleUser = NullableSimpleUser;
export interface NullableScopedInstallation {
    permissions: AppPermissions;
    /** Describe whether all repositories have been selected or there's a selection involved */
    repository_selection: NullableScopedInstallationRepositorySelection;
    single_file_name: string | null;
    has_multiple_single_files?: boolean | undefined;
    single_file_paths?: NullableScopedInstallationSingleFilePathsList | undefined;
    repositories_url: string;
    account: NullableSimpleUser;
}
/** The authorization for an OAuth app, GitHub App, or a Personal Access Token. */
export interface Authorization {
    id: number;
    url: string;
    /** A list of scopes that this authorization is in. */
    scopes: AuthorizationScopesList | null;
    token: string;
    token_last_eight: string | null;
    hashed_token: string | null;
    app: AuthorizationApp;
    note: string | null;
    note_url: string | null;
    updated_at: string;
    created_at: string;
    fingerprint: string | null;
    user?: NullableSimpleUser | null | undefined;
    installation?: NullableScopedInstallation | null | undefined;
    expires_at: string | null;
}
export interface CreateFromManifestRequest {
    code: string;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type CreateFromManifestResponseOwner = NullableSimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface CreateFromManifestResponsePermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type CreateFromManifestResponseEventsList = Array<string>;
export interface CreateFromManifestResponse {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id: string;
    owner: CreateFromManifestResponseOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: CreateFromManifestResponsePermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: CreateFromManifestResponseEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
    client_secret: string | Redacted.Redacted<string>;
    webhook_secret: string | Redacted.Redacted<string> | null;
    pem: string;
}
/** List of repository names that the token should have access to */
export type CreateInstallationAccessTokenRequestRepositoriesList = Array<string>;
/** List of repository IDs that the token should have access to */
export type CreateInstallationAccessTokenRequestRepositoryIdsList = Array<number>;
export interface CreateInstallationAccessTokenRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
    /** List of repository names that the token should have access to */
    repositories?: CreateInstallationAccessTokenRequestRepositoriesList | undefined;
    /** List of repository IDs that the token should have access to */
    repository_ids?: CreateInstallationAccessTokenRequestRepositoryIdsList | undefined;
    permissions?: AppPermissions | undefined;
}
export type InstallationTokenRepositorySelection = "all" | "selected";
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
export type InstallationTokenRepositoriesList = Array<Repository>;
export type InstallationTokenSingleFilePathsList = Array<string>;
/** Authentication token for a GitHub App installed on a user or org. */
export interface InstallationToken {
    token: string;
    expires_at: string;
    permissions?: AppPermissions | undefined;
    repository_selection?: InstallationTokenRepositorySelection | undefined;
    repositories?: InstallationTokenRepositoriesList | undefined;
    single_file?: string | undefined;
    has_multiple_single_files?: boolean | undefined;
    single_file_paths?: InstallationTokenSingleFilePathsList | undefined;
}
export interface DeleteAuthorizationRequest {
    /** The client ID of the GitHub app. */
    client_id: string;
    /** The OAuth access token used to authenticate to the GitHub API. */
    access_token: string | Redacted.Redacted<string>;
}
export interface DeleteAuthorizationResponse {
}
export interface DeleteInstallationRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
}
export interface DeleteInstallationResponse {
}
export interface DeleteTokenRequest {
    /** The client ID of the GitHub app. */
    client_id: string;
    /** The OAuth access token used to authenticate to the GitHub API. */
    access_token: string | Redacted.Redacted<string>;
}
export interface DeleteTokenResponse {
}
export interface GetAuthenticatedRequest {
}
export type IntegrationOwner = NullableSimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export type IntegrationPermissions = CreateFromManifestResponsePermissions;
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type IntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface Integration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: IntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: CreateFromManifestResponsePermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: IntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
export interface GetBySlugRequest {
    app_slug: string;
}
export interface GetInstallationRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
}
export type InstallationAccount = NullableSimpleUser | Enterprise;
/** Describe whether all repositories have been selected or there's a selection involved */
export type InstallationRepositorySelection = "all" | "selected";
export type InstallationEventsList = Array<string>;
export type InstallationSingleFilePathsList = Array<string>;
/** Installation */
export interface Installation {
    /** The ID of the installation. */
    id: number;
    account: InstallationAccount | null;
    /** Describe whether all repositories have been selected or there's a selection involved */
    repository_selection: InstallationRepositorySelection;
    access_tokens_url: string;
    repositories_url: string;
    html_url: string;
    app_id: number;
    client_id?: string | undefined;
    /** The ID of the user or organization this token is being scoped to. */
    target_id: number;
    target_type: string;
    permissions: AppPermissions;
    events: InstallationEventsList;
    created_at: string;
    updated_at: string;
    single_file_name: string | null;
    has_multiple_single_files?: boolean | undefined;
    single_file_paths?: InstallationSingleFilePathsList | undefined;
    app_slug: string;
    suspended_by: NullableSimpleUser | null;
    suspended_at: string | null;
    contact_email?: string | null | undefined;
}
export interface GetOrgInstallationRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
export interface GetRepoInstallationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetSubscriptionPlanForAccountRequest {
    /** account_id parameter */
    account_id: number;
}
export type MarketplaceListingPlanPriceModel = "FREE" | "FLAT_RATE" | "PER_UNIT";
export type MarketplaceListingPlanBulletsList = Array<string>;
/** Marketplace Listing Plan */
export interface MarketplaceListingPlan {
    url: string;
    accounts_url: string;
    id: number;
    number: number;
    name: string;
    description: string;
    monthly_price_in_cents: number;
    yearly_price_in_cents: number;
    price_model: MarketplaceListingPlanPriceModel;
    has_free_trial: boolean;
    unit_name: string | null;
    state: string;
    bullets: MarketplaceListingPlanBulletsList;
}
export interface MarketplacePurchaseMarketplacePendingChange {
    is_installed?: boolean | undefined;
    effective_date?: string | undefined;
    unit_count?: number | null | undefined;
    id?: number | undefined;
    plan?: MarketplaceListingPlan | undefined;
}
export interface MarketplacePurchaseMarketplacePurchase {
    billing_cycle?: string | undefined;
    next_billing_date?: string | null | undefined;
    is_installed?: boolean | undefined;
    unit_count?: number | null | undefined;
    on_free_trial?: boolean | undefined;
    free_trial_ends_on?: string | null | undefined;
    updated_at?: string | undefined;
    plan?: MarketplaceListingPlan | undefined;
}
/** Marketplace Purchase */
export interface MarketplacePurchase {
    url: string;
    type: string;
    id: number;
    login: string;
    organization_billing_email?: string | undefined;
    email?: string | null | undefined;
    marketplace_pending_change?: MarketplacePurchaseMarketplacePendingChange | null | undefined;
    marketplace_purchase: MarketplacePurchaseMarketplacePurchase;
}
export interface GetSubscriptionPlanForAccountStubbedRequest {
    /** account_id parameter */
    account_id: number;
}
export interface GetUserInstallationRequest {
    /** The handle for the GitHub user account. */
    username: string;
}
export interface GetWebhookConfigForAppRequest {
}
export type WebhookConfigInsecureSsl = string | number;
/** Configuration object of the webhook */
export interface WebhookConfig {
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
export interface GetWebhookDeliveryRequest {
    delivery_id: number;
}
/** The request headers sent with the webhook delivery. */
export type HookDeliveryRequestHeadersMap = {
    [key: string]: unknown | undefined;
};
/** The webhook payload. */
export type HookDeliveryRequestPayloadMap = {
    [key: string]: unknown | undefined;
};
export interface HookDeliveryRequest {
    /** The request headers sent with the webhook delivery. */
    headers: HookDeliveryRequestHeadersMap | null;
    /** The webhook payload. */
    payload: HookDeliveryRequestPayloadMap | null;
}
/** The response headers received when the delivery was made. */
export type HookDeliveryResponseHeadersMap = {
    [key: string]: unknown | undefined;
};
/** The response payload received. */
export type HookDeliveryResponsePayloadMap = {
    [key: string]: unknown | undefined;
};
export interface HookDeliveryResponse {
    /** The response headers received when the delivery was made. */
    headers: HookDeliveryResponseHeadersMap | null;
    /** The response payload received. */
    payload: HookDeliveryResponsePayloadMap | null;
}
/** Delivery made by a webhook. */
export interface HookDelivery {
    /** Unique identifier of the delivery. */
    id: number;
    /** Unique identifier for the event (shared with all deliveries for all webhooks that subscribe to this event). */
    guid: string;
    /** Time when the delivery was delivered. */
    delivered_at: string;
    /** Whether the delivery is a redelivery. */
    redelivery: boolean;
    /** Time spent delivering. */
    duration: number;
    /** Description of the status of the attempted delivery */
    status: string;
    /** Status code received when delivery was made. */
    status_code: number;
    /** The event that triggered the delivery. */
    event: string;
    /** The type of activity for the event that triggered the delivery. */
    action: string | null;
    /** The id of the GitHub App installation associated with this event. */
    installation_id: number | null;
    /** The id of the repository associated with this event. */
    repository_id: number | null;
    /** Time when the webhook delivery was throttled. */
    throttled_at?: string | null | undefined;
    /** The URL target of the delivery. */
    url?: string | undefined;
    request: HookDeliveryRequest;
    response: HookDeliveryResponse;
}
export type ListAccountsForPlanRequestSort = "created" | "updated";
export type ListAccountsForPlanRequestDirection = "asc" | "desc";
export interface ListAccountsForPlanRequest {
    /** The unique identifier of the plan. */
    plan_id: number;
    /** The property to sort the results by. */
    sort?: ListAccountsForPlanRequestSort | (string & {}) | undefined;
    /** To return the oldest accounts first, set to `asc`. Ignored without the `sort` parameter. */
    direction?: ListAccountsForPlanRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListAccountsForPlanResponseBodyList = Array<MarketplacePurchase>;
export type ListAccountsForPlanResponse = ListAccountsForPlanResponseBodyList;
export type ListAccountsForPlanStubbedRequestSort = "created" | "updated";
export type ListAccountsForPlanStubbedRequestDirection = "asc" | "desc";
export interface ListAccountsForPlanStubbedRequest {
    /** The unique identifier of the plan. */
    plan_id: number;
    /** The property to sort the results by. */
    sort?: ListAccountsForPlanStubbedRequestSort | (string & {}) | undefined;
    /** To return the oldest accounts first, set to `asc`. Ignored without the `sort` parameter. */
    direction?: ListAccountsForPlanStubbedRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListAccountsForPlanStubbedResponseBodyList = Array<MarketplacePurchase>;
export type ListAccountsForPlanStubbedResponse = ListAccountsForPlanStubbedResponseBodyList;
export interface ListInstallationReposForAuthenticatedUserRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemPermissions = RepositoryPermissions;
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemSquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemSquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemCodeSearchIndexStatus = RepositoryCodeSearchIndexStatus;
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. Present for org repos only. */
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesItemCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface ListInstallationReposForAuthenticatedUserResponseRepositoriesItem {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemSquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemSquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. Present for org repos only. */
    custom_properties?: ListInstallationReposForAuthenticatedUserResponseRepositoriesItemCustomPropertiesMap | undefined;
}
export type ListInstallationReposForAuthenticatedUserResponseRepositoriesList = Array<ListInstallationReposForAuthenticatedUserResponseRepositoriesItem>;
export interface ListInstallationReposForAuthenticatedUserResponse {
    total_count: number;
    repository_selection?: string | undefined;
    repositories: ListInstallationReposForAuthenticatedUserResponseRepositoriesList;
}
export interface ListInstallationRequestsForAuthenticatedAppRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type IntegrationInstallationRequestAccount = NullableSimpleUser | Enterprise;
/** Request to install an integration on a target */
export interface IntegrationInstallationRequest {
    /** Unique identifier of the request installation. */
    id: number;
    node_id?: string | undefined;
    account: IntegrationInstallationRequestAccount;
    requester: NullableSimpleUser;
    created_at: string;
}
export type ListInstallationRequestsForAuthenticatedAppResponseBodyList = Array<IntegrationInstallationRequest>;
export type ListInstallationRequestsForAuthenticatedAppResponse = ListInstallationRequestsForAuthenticatedAppResponseBodyList;
export interface ListInstallationsRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    outdated?: string | undefined;
}
export type ListInstallationsResponseBodyList = Array<Installation>;
export type ListInstallationsResponse = ListInstallationsResponseBodyList;
export interface ListInstallationsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListInstallationsForAuthenticatedUserResponseInstallationsList = Array<Installation>;
export interface ListInstallationsForAuthenticatedUserResponse {
    total_count: number;
    installations: ListInstallationsForAuthenticatedUserResponseInstallationsList;
}
export interface ListPlansRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPlansResponseBodyList = Array<MarketplaceListingPlan>;
export type ListPlansResponse = ListPlansResponseBodyList;
export interface ListPlansStubbedRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPlansStubbedResponseBodyList = Array<MarketplaceListingPlan>;
export type ListPlansStubbedResponse = ListPlansStubbedResponseBodyList;
export interface ListReposAccessibleToInstallationRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReposAccessibleToInstallationResponseRepositoriesItemPermissions = RepositoryPermissions;
export type ListReposAccessibleToInstallationResponseRepositoriesItemTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type ListReposAccessibleToInstallationResponseRepositoriesItemPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type ListReposAccessibleToInstallationResponseRepositoriesItemSquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type ListReposAccessibleToInstallationResponseRepositoriesItemSquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type ListReposAccessibleToInstallationResponseRepositoriesItemMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type ListReposAccessibleToInstallationResponseRepositoriesItemMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export type ListReposAccessibleToInstallationResponseRepositoriesItemCodeSearchIndexStatus = RepositoryCodeSearchIndexStatus;
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. Present for org repos only. */
export type ListReposAccessibleToInstallationResponseRepositoriesItemCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface ListReposAccessibleToInstallationResponseRepositoriesItem {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: NullableSimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: ListReposAccessibleToInstallationResponseRepositoriesItemTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: ListReposAccessibleToInstallationResponseRepositoriesItemPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: ListReposAccessibleToInstallationResponseRepositoriesItemSquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: ListReposAccessibleToInstallationResponseRepositoriesItemSquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: ListReposAccessibleToInstallationResponseRepositoriesItemMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: ListReposAccessibleToInstallationResponseRepositoriesItemMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. Present for org repos only. */
    custom_properties?: ListReposAccessibleToInstallationResponseRepositoriesItemCustomPropertiesMap | undefined;
}
export type ListReposAccessibleToInstallationResponseRepositoriesList = Array<ListReposAccessibleToInstallationResponseRepositoriesItem>;
export interface ListReposAccessibleToInstallationResponse {
    total_count: number;
    repositories: ListReposAccessibleToInstallationResponseRepositoriesList;
    repository_selection?: string | undefined;
}
export interface ListSubscriptionsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface MarketplaceAccount {
    url: string;
    id: number;
    type: string;
    node_id?: string | undefined;
    login: string;
    email?: string | null | undefined;
    organization_billing_email?: string | null | undefined;
}
/** User Marketplace Purchase */
export interface UserMarketplacePurchase {
    billing_cycle: string;
    next_billing_date: string | null;
    unit_count: number | null;
    on_free_trial: boolean;
    free_trial_ends_on: string | null;
    updated_at: string | null;
    account: MarketplaceAccount;
    plan: MarketplaceListingPlan;
}
export type ListSubscriptionsForAuthenticatedUserResponseBodyList = Array<UserMarketplacePurchase>;
export type ListSubscriptionsForAuthenticatedUserResponse = ListSubscriptionsForAuthenticatedUserResponseBodyList;
export interface ListSubscriptionsForAuthenticatedUserStubbedRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSubscriptionsForAuthenticatedUserStubbedResponseBodyList = Array<UserMarketplacePurchase>;
export type ListSubscriptionsForAuthenticatedUserStubbedResponse = ListSubscriptionsForAuthenticatedUserStubbedResponseBodyList;
export type ListWebhookDeliveriesRequestStatus = "success" | "failure";
export interface ListWebhookDeliveriesRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors. */
    cursor?: string | undefined;
    /** Returns webhook deliveries filtered by delivery outcome classification based on `status_code` range. A `status` of `success` returns deliveries with a `status_code` in the 200-399 range (inclusive). A `status` of `failure` returns deliveries with a `status_code` in the 400-599 range (inclusive). */
    status?: ListWebhookDeliveriesRequestStatus | (string & {}) | undefined;
}
/** Delivery made by a webhook, without request and response information. */
export interface HookDeliveryItem {
    /** Unique identifier of the webhook delivery. */
    id: number;
    /** Unique identifier for the event (shared with all deliveries for all webhooks that subscribe to this event). */
    guid: string;
    /** Time when the webhook delivery occurred. */
    delivered_at: string;
    /** Whether the webhook delivery is a redelivery. */
    redelivery: boolean;
    /** Time spent delivering. */
    duration: number;
    /** Describes the response returned after attempting the delivery. */
    status: string;
    /** Status code received when delivery was made. */
    status_code: number;
    /** The event that triggered the delivery. */
    event: string;
    /** The type of activity for the event that triggered the delivery. */
    action: string | null;
    /** The id of the GitHub App installation associated with this event. */
    installation_id: number | null;
    /** The id of the repository associated with this event. */
    repository_id: number | null;
    /** Time when the webhook delivery was throttled. */
    throttled_at?: string | null | undefined;
}
export type ListWebhookDeliveriesResponseBodyList = Array<HookDeliveryItem>;
export type ListWebhookDeliveriesResponse = ListWebhookDeliveriesResponseBodyList;
export interface RedeliverWebhookDeliveryRequest {
    delivery_id: number;
}
export interface RedeliverWebhookDeliveryResponse {
}
export interface RemoveRepoFromInstallationForAuthenticatedUserRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
    /** The unique identifier of the repository. */
    repository_id: number;
}
export interface RemoveRepoFromInstallationForAuthenticatedUserResponse {
}
export interface ResetTokenRequest {
    /** The client ID of the GitHub app. */
    client_id: string;
    /** The access_token of the OAuth or GitHub application. */
    access_token: string | Redacted.Redacted<string>;
}
export interface RevokeInstallationAccessTokenRequest {
}
export interface RevokeInstallationAccessTokenResponse {
}
/** The list of repository names to scope the user access token to. `repositories` may not be specified if `repository_ids` is specified. */
export type ScopeTokenRequestRepositoriesList = Array<string>;
/** The list of repository IDs to scope the user access token to. `repository_ids` may not be specified if `repositories` is specified. */
export type ScopeTokenRequestRepositoryIdsList = Array<number>;
export interface ScopeTokenRequest {
    /** The client ID of the GitHub app. */
    client_id: string;
    /** The access token used to authenticate to the GitHub API. */
    access_token: string | Redacted.Redacted<string>;
    /** The name of the user or organization to scope the user access token to. **Required** unless `target_id` is specified. */
    target?: string | undefined;
    /** The ID of the user or organization to scope the user access token to. **Required** unless `target` is specified. */
    target_id?: number | undefined;
    /** The list of repository names to scope the user access token to. `repositories` may not be specified if `repository_ids` is specified. */
    repositories?: ScopeTokenRequestRepositoriesList | undefined;
    /** The list of repository IDs to scope the user access token to. `repository_ids` may not be specified if `repositories` is specified. */
    repository_ids?: ScopeTokenRequestRepositoryIdsList | undefined;
    permissions?: AppPermissions | undefined;
}
export interface SuspendInstallationRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
}
export interface SuspendInstallationResponse {
}
export interface UnsuspendInstallationRequest {
    /** The unique identifier of the installation. */
    installation_id: number;
}
export interface UnsuspendInstallationResponse {
}
export interface UpdateWebhookConfigForAppRequest {
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
export type AddRepoToInstallationForAuthenticatedUserError = GithubOpError;
/** Add a repository to an app installation Add a single repository to an installation. The authenticated user must have admin access to the repository. */
export declare const addRepoToInstallationForAuthenticatedUser: API.OperationMethod<AddRepoToInstallationForAuthenticatedUserRequest, AddRepoToInstallationForAuthenticatedUserResponse, AddRepoToInstallationForAuthenticatedUserError, GithubOpContext>;
export type CheckTokenError = GithubOpError;
/** Check a token OAuth applications and GitHub applications with OAuth authorizations can use this API method for checking OAuth token validity without exceeding the normal rate limits for failed login attempts. Authentication works differently with this particular endpoint. Invalid tokens will return `404 NOT FOUND`. */
export declare const checkToken: API.OperationMethod<CheckTokenRequest, Authorization, CheckTokenError, GithubOpContext>;
export type CreateFromManifestError = GithubOpError;
/** Create a GitHub App from a manifest Use this endpoint to complete the handshake necessary when implementing the [GitHub App Manifest flow](https://docs.github.com/apps/building-github-apps/creating-github-apps-from-a-manifest/). When you create a GitHub App with the manifest flow, you receive a temporary `code` used to retrieve the GitHub App's `id`, `pem` (private key), and `webhook_secret`. */
export declare const createFromManifest: API.OperationMethod<CreateFromManifestRequest, CreateFromManifestResponse, CreateFromManifestError, GithubOpContext>;
export type CreateInstallationAccessTokenError = GithubOpError;
/** Create an installation access token for an app Creates an installation access token that enables a GitHub App to make authenticated API requests for the app's installation on an organization or individual account. Installation tokens expire one hour from the time you create them. Using an expired token produces a status code of `401 - Unauthorized`, and requires creating a new installation token. By default the installation token has access to all repositories that the installation can access. > [!NOTE] > Starting April 27, 2026, GitHub began a staged rollout of a stateless format (`ghs_APPID_JWT`) to all newly minted GitHub App installation tokens, making them more performant and improving the reliability of our API surface. If your application expects or relies on installation tokens being exactly 40 characters long, it may not handle this new token format correctly. You can now validate your apps and workflows using a temporary request header that lets you enable the token format on demand. For more information about the temporary header, see [the GitHub blog](https://github.blog/changelog/2026-05-15-github-app-installation-tokens-per-request-override-header). Optionally, you can use the `repositories` or `repository_ids` body parameters to specify individual repositories that the installation access token can access. If you don't use `repositories` or `repository_ids` to grant access to specific repositories, the installation access token will have access to all repositories that the installation was granted access to. The installation access token cannot be granted access to repositories that the installation was not granted access to. Up to 500 repositories can be listed in this manner. Optionally, use the `permissions` body parameter to specify the permissions that the installation access token should have. If `permissions` is not specified, the installation access token will have all of the permissions that were granted to the app. The installation access token cannot be granted permissions that the app was not granted. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const createInstallationAccessToken: API.OperationMethod<CreateInstallationAccessTokenRequest, InstallationToken, CreateInstallationAccessTokenError, GithubOpContext>;
export type DeleteAuthorizationError = GithubOpError;
/** Delete an app authorization OAuth and GitHub application owners can revoke a grant for their application and a specific user. You must provide a valid OAuth `access_token` as an input parameter and the grant for the token's owner will be deleted. Deleting an application's grant will also delete all OAuth tokens associated with the application for the user. Once deleted, the application will have no access to the user's account and will no longer be listed on [the application authorizations settings screen within GitHub](https://github.com/settings/applications#authorized). */
export declare const deleteAuthorization: API.OperationMethod<DeleteAuthorizationRequest, DeleteAuthorizationResponse, DeleteAuthorizationError, GithubOpContext>;
export type DeleteInstallationError = GithubOpError;
/** Delete an installation for the authenticated app Uninstalls a GitHub App on a user, organization, or enterprise account. If you prefer to temporarily suspend an app's access to your account's resources, then we recommend the "[Suspend an app installation](https://docs.github.com/rest/apps/apps#suspend-an-app-installation)" endpoint. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const deleteInstallation: API.OperationMethod<DeleteInstallationRequest, DeleteInstallationResponse, DeleteInstallationError, GithubOpContext>;
export type DeleteTokenError = GithubOpError;
/** Delete an app token OAuth or GitHub application owners can revoke a single token for an OAuth application or a GitHub application with an OAuth authorization. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, GithubOpContext>;
export type GetAuthenticatedError = GithubOpError;
/** Get the authenticated app Returns the GitHub App associated with the authentication credentials used. To see how many app installations are associated with this GitHub App, see the `installations_count` in the response. For more details about your app's installations, see the "[List installations for the authenticated app](https://docs.github.com/rest/apps/apps#list-installations-for-the-authenticated-app)" endpoint. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getAuthenticated: API.OperationMethod<GetAuthenticatedRequest, Integration, GetAuthenticatedError, GithubOpContext>;
export type GetBySlugError = GithubOpError;
/** Get an app > [!NOTE] > The `:app_slug` is just the URL-friendly name of your GitHub App. You can find this on the settings page for your GitHub App (e.g., `https://github.com/settings/apps/:app_slug`). */
export declare const getBySlug: API.OperationMethod<GetBySlugRequest, Integration, GetBySlugError, GithubOpContext>;
export type GetInstallationError = GithubOpError;
/** Get an installation for the authenticated app Enables an authenticated GitHub App to find an installation's information using the installation id. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getInstallation: API.OperationMethod<GetInstallationRequest, Installation, GetInstallationError, GithubOpContext>;
export type GetOrgInstallationError = GithubOpError;
/** Get an organization installation for the authenticated app Enables an authenticated GitHub App to find the organization's installation information. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getOrgInstallation: API.OperationMethod<GetOrgInstallationRequest, Installation, GetOrgInstallationError, GithubOpContext>;
export type GetRepoInstallationError = GithubOpError;
/** Get a repository installation for the authenticated app Enables an authenticated GitHub App to find the repository's installation information. The installation's account type will be either an organization or a user account, depending which account the repository belongs to. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getRepoInstallation: API.OperationMethod<GetRepoInstallationRequest, Installation, GetRepoInstallationError, GithubOpContext>;
export type GetSubscriptionPlanForAccountError = GithubOpError;
/** Get a subscription plan for an account Shows whether the user or organization account actively subscribes to a plan listed by the authenticated GitHub App. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change. GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint. */
export declare const getSubscriptionPlanForAccount: API.OperationMethod<GetSubscriptionPlanForAccountRequest, MarketplacePurchase, GetSubscriptionPlanForAccountError, GithubOpContext>;
export type GetSubscriptionPlanForAccountStubbedError = GithubOpError;
/** Get a subscription plan for an account (stubbed) Shows whether the user or organization account actively subscribes to a plan listed by the authenticated GitHub App. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change. GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint. */
export declare const getSubscriptionPlanForAccountStubbed: API.OperationMethod<GetSubscriptionPlanForAccountStubbedRequest, MarketplacePurchase, GetSubscriptionPlanForAccountStubbedError, GithubOpContext>;
export type GetUserInstallationError = GithubOpError;
/** Get a user installation for the authenticated app Enables an authenticated GitHub App to find the user's installation information. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getUserInstallation: API.OperationMethod<GetUserInstallationRequest, Installation, GetUserInstallationError, GithubOpContext>;
export type GetWebhookConfigForAppError = GithubOpError;
/** Get a webhook configuration for an app Returns the webhook configuration for a GitHub App. For more information about configuring a webhook for your app, see "[Creating a GitHub App](/developers/apps/creating-a-github-app)." You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getWebhookConfigForApp: API.OperationMethod<GetWebhookConfigForAppRequest, WebhookConfig, GetWebhookConfigForAppError, GithubOpContext>;
export type GetWebhookDeliveryError = GithubOpError;
/** Get a delivery for an app webhook Returns a delivery for the webhook configured for a GitHub App. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const getWebhookDelivery: API.OperationMethod<GetWebhookDeliveryRequest, HookDelivery, GetWebhookDeliveryError, GithubOpContext>;
export type ListAccountsForPlanError = GithubOpError;
/** List accounts for a plan Returns user and organization accounts associated with the specified plan, including free plans. For per-seat pricing, you see the list of accounts that have purchased the plan, including the number of seats purchased. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change. GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint. */
export declare const listAccountsForPlan: API.PaginatedOperationMethod<ListAccountsForPlanRequest, ListAccountsForPlanResponse, ListAccountsForPlanError, GithubOpContext, MarketplacePurchase>;
export type ListAccountsForPlanStubbedError = GithubOpError;
/** List accounts for a plan (stubbed) Returns repository and organization accounts associated with the specified plan, including free plans. For per-seat pricing, you see the list of accounts that have purchased the plan, including the number of seats purchased. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change. GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint. */
export declare const listAccountsForPlanStubbed: API.PaginatedOperationMethod<ListAccountsForPlanStubbedRequest, ListAccountsForPlanStubbedResponse, ListAccountsForPlanStubbedError, GithubOpContext, MarketplacePurchase>;
export type ListInstallationReposForAuthenticatedUserError = GithubOpError;
/** List repositories accessible to the user access token List repositories that the authenticated user has explicit permission (`:read`, `:write`, or `:admin`) to access for an installation. The authenticated user has explicit permission to access repositories they own, repositories where they are a collaborator, and repositories that they can access through an organization membership. The access the user has to each repository is included in the hash under the `permissions` key. */
export declare const listInstallationReposForAuthenticatedUser: API.PaginatedOperationMethod<ListInstallationReposForAuthenticatedUserRequest, ListInstallationReposForAuthenticatedUserResponse, ListInstallationReposForAuthenticatedUserError, GithubOpContext, ListInstallationReposForAuthenticatedUserResponseRepositoriesItem>;
export type ListInstallationRequestsForAuthenticatedAppError = GithubOpError;
/** List installation requests for the authenticated app Lists all the pending installation requests for the authenticated GitHub App. */
export declare const listInstallationRequestsForAuthenticatedApp: API.PaginatedOperationMethod<ListInstallationRequestsForAuthenticatedAppRequest, ListInstallationRequestsForAuthenticatedAppResponse, ListInstallationRequestsForAuthenticatedAppError, GithubOpContext, IntegrationInstallationRequest>;
export type ListInstallationsError = GithubOpError;
/** List installations for the authenticated app The permissions the installation has are included under the `permissions` key. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const listInstallations: API.PaginatedOperationMethod<ListInstallationsRequest, ListInstallationsResponse, ListInstallationsError, GithubOpContext, Installation>;
export type ListInstallationsForAuthenticatedUserError = GithubOpError;
/** List app installations accessible to the user access token Lists installations of your GitHub App that the authenticated user has explicit permission (`:read`, `:write`, or `:admin`) to access. The authenticated user has explicit permission to access repositories they own, repositories where they are a collaborator, and repositories that they can access through an organization membership. You can find the permissions for the installation under the `permissions` key. */
export declare const listInstallationsForAuthenticatedUser: API.PaginatedOperationMethod<ListInstallationsForAuthenticatedUserRequest, ListInstallationsForAuthenticatedUserResponse, ListInstallationsForAuthenticatedUserError, GithubOpContext, Installation>;
export type ListPlansError = GithubOpError;
/** List plans Lists all plans that are part of your GitHub Marketplace listing. GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint. */
export declare const listPlans: API.PaginatedOperationMethod<ListPlansRequest, ListPlansResponse, ListPlansError, GithubOpContext, MarketplaceListingPlan>;
export type ListPlansStubbedError = GithubOpError;
/** List plans (stubbed) Lists all plans that are part of your GitHub Marketplace listing. GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint. */
export declare const listPlansStubbed: API.PaginatedOperationMethod<ListPlansStubbedRequest, ListPlansStubbedResponse, ListPlansStubbedError, GithubOpContext, MarketplaceListingPlan>;
export type ListReposAccessibleToInstallationError = GithubOpError;
/** List repositories accessible to the app installation List repositories that an app installation can access. */
export declare const listReposAccessibleToInstallation: API.PaginatedOperationMethod<ListReposAccessibleToInstallationRequest, ListReposAccessibleToInstallationResponse, ListReposAccessibleToInstallationError, GithubOpContext, ListReposAccessibleToInstallationResponseRepositoriesItem>;
export type ListSubscriptionsForAuthenticatedUserError = GithubOpError;
/** List subscriptions for the authenticated user Lists the active subscriptions for the authenticated user. */
export declare const listSubscriptionsForAuthenticatedUser: API.PaginatedOperationMethod<ListSubscriptionsForAuthenticatedUserRequest, ListSubscriptionsForAuthenticatedUserResponse, ListSubscriptionsForAuthenticatedUserError, GithubOpContext, UserMarketplacePurchase>;
export type ListSubscriptionsForAuthenticatedUserStubbedError = GithubOpError;
/** List subscriptions for the authenticated user (stubbed) Lists the active subscriptions for the authenticated user. */
export declare const listSubscriptionsForAuthenticatedUserStubbed: API.PaginatedOperationMethod<ListSubscriptionsForAuthenticatedUserStubbedRequest, ListSubscriptionsForAuthenticatedUserStubbedResponse, ListSubscriptionsForAuthenticatedUserStubbedError, GithubOpContext, UserMarketplacePurchase>;
export type ListWebhookDeliveriesError = GithubOpError;
/** List deliveries for an app webhook Returns a list of webhook deliveries for the webhook configured for a GitHub App. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const listWebhookDeliveries: API.OperationMethod<ListWebhookDeliveriesRequest, ListWebhookDeliveriesResponse, ListWebhookDeliveriesError, GithubOpContext>;
export type RedeliverWebhookDeliveryError = GithubOpError;
/** Redeliver a delivery for an app webhook Redeliver a delivery for the webhook configured for a GitHub App. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const redeliverWebhookDelivery: API.OperationMethod<RedeliverWebhookDeliveryRequest, RedeliverWebhookDeliveryResponse, RedeliverWebhookDeliveryError, GithubOpContext>;
export type RemoveRepoFromInstallationForAuthenticatedUserError = GithubOpError;
/** Remove a repository from an app installation Remove a single repository from an installation. The authenticated user must have admin access to the repository. The installation must have the `repository_selection` of `selected`. To use a PAT (classic) with this endpoint, the `repo` scope is required */
export declare const removeRepoFromInstallationForAuthenticatedUser: API.OperationMethod<RemoveRepoFromInstallationForAuthenticatedUserRequest, RemoveRepoFromInstallationForAuthenticatedUserResponse, RemoveRepoFromInstallationForAuthenticatedUserError, GithubOpContext>;
export type ResetTokenError = GithubOpError;
/** Reset a token OAuth applications and GitHub applications with OAuth authorizations can use this API method to reset a valid OAuth token without end-user involvement. Applications must save the "token" property in the response because changes take effect immediately. Invalid tokens will return `404 NOT FOUND`. */
export declare const resetToken: API.OperationMethod<ResetTokenRequest, Authorization, ResetTokenError, GithubOpContext>;
export type RevokeInstallationAccessTokenError = GithubOpError;
/** Revoke an installation access token Revokes the installation token you're using to authenticate as an installation and access this endpoint. Once an installation token is revoked, the token is invalidated and cannot be used. Other endpoints that require the revoked installation token must have a new installation token to work. You can create a new token using the "[Create an installation access token for an app](https://docs.github.com/rest/apps/apps#create-an-installation-access-token-for-an-app)" endpoint. */
export declare const revokeInstallationAccessToken: API.OperationMethod<RevokeInstallationAccessTokenRequest, RevokeInstallationAccessTokenResponse, RevokeInstallationAccessTokenError, GithubOpContext>;
export type ScopeTokenError = GithubOpError;
/** Create a scoped access token Use a non-scoped user access token to create a repository-scoped and/or permission-scoped user access token. You can specify which repositories the token can access and which permissions are granted to the token. Invalid tokens will return `404 NOT FOUND`. */
export declare const scopeToken: API.OperationMethod<ScopeTokenRequest, Authorization, ScopeTokenError, GithubOpContext>;
export type SuspendInstallationError = GithubOpError;
/** Suspend an app installation Suspends a GitHub App on a user, organization, or enterprise account, which blocks the app from accessing the account's resources. When a GitHub App is suspended, the app's access to the GitHub API or webhook events is blocked for that account. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const suspendInstallation: API.OperationMethod<SuspendInstallationRequest, SuspendInstallationResponse, SuspendInstallationError, GithubOpContext>;
export type UnsuspendInstallationError = GithubOpError;
/** Unsuspend an app installation Removes a GitHub App installation suspension. You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const unsuspendInstallation: API.OperationMethod<UnsuspendInstallationRequest, UnsuspendInstallationResponse, UnsuspendInstallationError, GithubOpContext>;
export type UpdateWebhookConfigForAppError = GithubOpError;
/** Update a webhook configuration for an app Updates the webhook configuration for a GitHub App. For more information about configuring a webhook for your app, see "[Creating a GitHub App](/developers/apps/creating-a-github-app)." You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. */
export declare const updateWebhookConfigForApp: API.OperationMethod<UpdateWebhookConfigForAppRequest, WebhookConfig, UpdateWebhookConfigForAppError, GithubOpContext>;
//# sourceMappingURL=apps.d.ts.map