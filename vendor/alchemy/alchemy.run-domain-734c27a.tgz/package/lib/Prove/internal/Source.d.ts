import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type { Module, Node } from "./Value.ts";
declare const LoadError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "LoadError";
} & Readonly<A>;
/** A source file could not be read, parsed or loaded. */
export declare class LoadError extends LoadError_base<{
    readonly file: string;
    readonly message: string;
}> {
}
export interface Loader {
    /** A source file, parsed and loaded. Each file is read once. */
    readonly load: (file: string) => Effect.Effect<Module, LoadError>;
    /**
     * Name the domain classes the caller holds: a model or an aggregate, and
     * every class it lists. A test runner may load a source file a second time,
     * as classes that are not the caller's. Where a loaded file exports one of
     * those, the loader gives the caller's class in its place.
     */
    readonly adopt: (root: unknown) => void;
    /**
     * An expression written as text, as a node of a file's syntax: a rule kept
     * from an earlier version of the file, to be read where the file's own
     * names mean what they mean now.
     */
    readonly parse: (file: string, text: string) => Effect.Effect<Node, LoadError>;
}
/**
 * Reads TypeScript the way the prover needs it: the syntax tree for function
 * bodies, and the loaded module for the classes, schemas and constants the
 * code refers to.
 */
export declare const loader: Effect.Effect<Loader, LoadError, FileSystem.FileSystem | Path.Path>;
export {};
//# sourceMappingURL=Source.d.ts.map