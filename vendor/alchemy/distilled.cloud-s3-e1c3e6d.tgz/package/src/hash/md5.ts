/**
 * MD5 checksum implementation using Node.js crypto module.
 */

import * as crypto from "node:crypto";
import type { Checksum } from "./checksum.ts";

class NodeMd5 implements Checksum {
  private hash = crypto.createHash("md5");
  update(data: Uint8Array) {
    this.hash.update(data);
  }
  digest(): Uint8Array {
    return new Uint8Array(this.hash.digest());
  }
  reset() {
    this.hash = crypto.createHash("md5");
  }
}

export const getMd5ChecksumAlgorithmFunction = (): new () => Checksum => {
  return NodeMd5;
};
