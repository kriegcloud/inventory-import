import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export type CodeRequestSort = "indexed";
export type CodeRequestOrder = "desc" | "asc";
export interface CodeRequest {
    /** The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching code](https://docs.github.com/search-github/searching-on-github/searching-code)" for a detailed list of qualifiers. */
    q: string;
    /** **This field is closing down.** Sorts the results of your query. Can only be `indexed`, which indicates how recently a file has been indexed by the GitHub search infrastructure. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) */
    sort?: CodeRequestSort | (string & {}) | undefined;
    /** **This field is closing down.** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. */
    order?: CodeRequestOrder | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export type CodeSearchResultItemLineNumbersList = Array<string>;
export type SearchResultTextMatchesItemMatchesItemIndicesList = Array<number>;
export interface SearchResultTextMatchesItemMatchesItem {
    text?: string | undefined;
    indices?: SearchResultTextMatchesItemMatchesItemIndicesList | undefined;
}
export type SearchResultTextMatchesItemMatchesList = Array<SearchResultTextMatchesItemMatchesItem>;
export interface SearchResultTextMatchesItem {
    object_url?: string | undefined;
    object_type?: string | null | undefined;
    property?: string | undefined;
    fragment?: string | undefined;
    matches?: SearchResultTextMatchesItemMatchesList | undefined;
}
export type SearchResultTextMatches = Array<SearchResultTextMatchesItem>;
/** Code Search Result Item */
export interface CodeSearchResultItem {
    name: string;
    path: string;
    sha: string;
    url: string;
    git_url: string;
    html_url: string;
    repository: MinimalRepository;
    score: number;
    file_size?: number | undefined;
    language?: string | null | undefined;
    last_modified_at?: string | undefined;
    line_numbers?: CodeSearchResultItemLineNumbersList | undefined;
    text_matches?: SearchResultTextMatches | undefined;
}
export type CodeResponseItemsList = Array<CodeSearchResultItem>;
export interface CodeResponse {
    total_count: number;
    incomplete_results: boolean;
    items: CodeResponseItemsList;
}
export type CommitsRequestSort = "author-date" | "committer-date";
export type CommitsRequestOrder = "desc" | "asc";
export interface CommitsRequest {
    /** The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching commits](https://docs.github.com/search-github/searching-on-github/searching-commits)" for a detailed list of qualifiers. */
    q: string;
    /** Sorts the results of your query by `author-date` or `committer-date`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) */
    sort?: CommitsRequestSort | (string & {}) | undefined;
    /** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. */
    order?: CommitsRequestOrder | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface CommitSearchResultItemCommitAuthor {
    name: string;
    email: string;
    date: string;
}
/** Metaproperties for Git author/committer information. */
export interface NullableGitUser {
    name?: string | undefined;
    email?: string | undefined;
    date?: string | undefined;
}
export interface CommitSearchResultItemCommitTree {
    sha: string;
    url: string;
}
export interface Verification {
    verified: boolean;
    reason: string;
    payload: string | null;
    signature: string | null;
    verified_at: string | null;
}
export interface CommitSearchResultItemCommit {
    author: CommitSearchResultItemCommitAuthor;
    committer: NullableGitUser | null;
    comment_count: number;
    message: string;
    tree: CommitSearchResultItemCommitTree;
    url: string;
    verification?: Verification | undefined;
}
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
export interface CommitSearchResultItemParentsItem {
    url?: string | undefined;
    html_url?: string | undefined;
    sha?: string | undefined;
}
export type CommitSearchResultItemParentsList = Array<CommitSearchResultItemParentsItem>;
/** Commit Search Result Item */
export interface CommitSearchResultItem {
    url: string;
    sha: string;
    html_url: string;
    comments_url: string;
    commit: CommitSearchResultItemCommit;
    author: SimpleUser | null;
    committer: NullableGitUser | null;
    parents: CommitSearchResultItemParentsList;
    repository: MinimalRepository;
    score: number;
    node_id: string;
    text_matches?: SearchResultTextMatches | undefined;
}
export type CommitsResponseItemsList = Array<CommitSearchResultItem>;
export interface CommitsResponse {
    total_count: number;
    incomplete_results: boolean;
    items: CommitsResponseItemsList;
}
export type IssuesAndPullRequestsRequestSort = "comments" | "reactions" | "reactions-+1" | "reactions--1" | "reactions-smile" | "reactions-thinking_face" | "reactions-heart" | "reactions-tada" | "interactions" | "created" | "updated";
export type IssuesAndPullRequestsRequestOrder = "desc" | "asc";
export type IssuesAndPullRequestsRequestSearchType = "semantic" | "hybrid";
export interface IssuesAndPullRequestsRequest {
    /** The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching issues and pull requests](https://docs.github.com/search-github/searching-on-github/searching-issues-and-pull-requests)" for a detailed list of qualifiers. */
    q: string;
    /** Sorts the results of your query by the number of `comments`, `reactions`, `reactions-+1`, `reactions--1`, `reactions-smile`, `reactions-thinking_face`, `reactions-heart`, `reactions-tada`, or `interactions`. You can also sort results by how recently the items were `created` or `updated`, Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) */
    sort?: IssuesAndPullRequestsRequestSort | (string & {}) | undefined;
    /** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. */
    order?: IssuesAndPullRequestsRequestOrder | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Set to `true` to use advanced search. Example: `http://api.github.com/search/issues?q={query}&advanced_search=true` */
    advanced_search?: string | undefined;
    /** The type of search to perform on issues. When not specified, the default is lexical search. - `semantic` -- performs a pure semantic (vector) search using embedding-based understanding. - `hybrid` -- combines semantic search with lexical search for best results. Semantic and hybrid search require authentication and are rate limited to 10 requests per minute. Only applies to issue searches (`/search/issues`). */
    search_type?: IssuesAndPullRequestsRequestSearchType | (string & {}) | undefined;
}
export type IssueSearchResultItemAssigneesList = Array<SimpleUser>;
export interface IssueSearchResultItemLabelsItem {
    id?: number | undefined;
    node_id?: string | undefined;
    url?: string | undefined;
    name?: string | undefined;
    color?: string | undefined;
    default?: boolean | undefined;
    description?: string | null | undefined;
    /** Timestamp indicating when the label was archived, or `null` if it has not been archived. */
    archived_at?: string | null | undefined;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by?: SimpleUser | null | undefined;
}
export type IssueSearchResultItemLabelsList = Array<IssueSearchResultItemLabelsItem>;
export interface SubIssuesSummary {
    total: number;
    completed: number;
    percent_completed: number;
}
export interface IssueDependenciesSummary {
    blocked_by: number;
    blocking: number;
    total_blocked_by: number;
    total_blocking: number;
}
/** The data type of the issue field */
export type IssueFieldValueDataType = "text" | "single_select" | "multi_select" | "number" | "date";
/** The value of the issue field */
export type IssueFieldValueValue = string | number | number;
/** Details about the selected option (only present for single_select fields) */
export interface IssueFieldValueSingleSelectOption {
    /** Unique identifier for the option. */
    id: number;
    /** The name of the option */
    name: string;
    /** The color of the option */
    color: string;
}
export type IssueFieldValueMultiSelectOptionsItem = IssueFieldValueSingleSelectOption;
/** Details about the selected options */
export type IssueFieldValueMultiSelectOptionsList = Array<IssueFieldValueSingleSelectOption>;
/** A value assigned to an issue field */
export interface IssueFieldValue {
    /** Unique identifier for the issue field. */
    issue_field_id: number;
    /** The human-readable name of the issue field. */
    issue_field_name?: string | undefined;
    node_id: string;
    /** The data type of the issue field */
    data_type: IssueFieldValueDataType;
    /** The value of the issue field */
    value: IssueFieldValueValue | null;
    /** Details about the selected option (only present for single_select fields) */
    single_select_option?: IssueFieldValueSingleSelectOption | null | undefined;
    /** Details about the selected options */
    multi_select_options?: IssueFieldValueMultiSelectOptionsList | null | undefined;
}
export type IssueSearchResultItemIssueFieldValuesList = Array<IssueFieldValue>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: SimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export interface IssueSearchResultItemPullRequest {
    merged_at?: string | null | undefined;
    diff_url: string | null;
    html_url: string | null;
    patch_url: string | null;
    url: string | null;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
/** The color of the issue type. */
export type IssueTypeColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type assigned to the issue. This is only present for issues in repositories where issue types are supported. */
export interface IssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The description of the issue type. */
    description: string | null;
    /** The color of the issue type. */
    color?: IssueTypeColor | null | undefined;
    /** The time the issue type created. */
    created_at?: string | undefined;
    /** The time the issue type last updated. */
    updated_at?: string | undefined;
    /** The enabled state of the issue type. */
    is_enabled?: boolean | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type NullableIntegrationOwner = SimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface NullableIntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
export interface ReactionRollup {
    url: string;
    total_count: number;
    _1: number;
    _1_2: number;
    laugh: number;
    confused: number;
    heart: number;
    hooray: number;
    eyes: number;
    rocket: number;
}
/** Context around who pinned an issue comment and when it was pinned. */
export interface NullablePinnedIssueComment {
    pinned_at: string;
    pinned_by: SimpleUser | null;
}
/** Details about why an issue comment was minimized. */
export interface NullableIssueCommentMinimized {
    /** The reason the comment was minimized. */
    reason: string | null;
}
/** Comments provide a way for people to collaborate on an issue. */
export interface NullableIssueComment {
    /** Unique identifier of the issue comment */
    id: number;
    node_id: string;
    /** URL for the issue comment */
    url: string;
    /** Contents of the issue comment */
    body?: string | undefined;
    body_text?: string | undefined;
    body_html?: string | undefined;
    html_url: string;
    user: SimpleUser | null;
    created_at: string;
    updated_at: string;
    issue_url: string;
    author_association?: AuthorAssociation | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    reactions?: ReactionRollup | undefined;
    pin?: NullablePinnedIssueComment | null | undefined;
    minimized?: NullableIssueCommentMinimized | null | undefined;
}
/** Issue Search Result Item */
export interface IssueSearchResultItem {
    url: string;
    repository_url: string;
    labels_url: string;
    comments_url: string;
    events_url: string;
    html_url: string;
    id: number;
    node_id: string;
    number: number;
    title: string;
    locked: boolean;
    active_lock_reason?: string | null | undefined;
    assignees?: IssueSearchResultItemAssigneesList | null | undefined;
    user: SimpleUser | null;
    labels: IssueSearchResultItemLabelsList;
    sub_issues_summary?: SubIssuesSummary | undefined;
    issue_dependencies_summary?: IssueDependenciesSummary | undefined;
    issue_field_values?: IssueSearchResultItemIssueFieldValuesList | undefined;
    state: string;
    state_reason?: string | null | undefined;
    assignee: SimpleUser | null;
    milestone: NullableMilestone | null;
    comments: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    text_matches?: SearchResultTextMatches | undefined;
    pull_request?: IssueSearchResultItemPullRequest | undefined;
    body?: string | undefined;
    score: number;
    author_association: AuthorAssociation;
    draft?: boolean | undefined;
    repository?: Repository | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
    timeline_url?: string | undefined;
    type?: IssueType | null | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    pinned_comment?: NullableIssueComment | null | undefined;
    reactions?: ReactionRollup | undefined;
}
export type IssuesAndPullRequestsResponseItemsList = Array<IssueSearchResultItem>;
/** The type of search that was performed. Possible values are `lexical`, `semantic`, or `hybrid`. */
export type IssuesAndPullRequestsResponseSearchType = "lexical" | "semantic" | "hybrid";
export type IssuesAndPullRequestsResponseLexicalFallbackReasonItem = "no_text_terms" | "quoted_text" | "non_issue_target" | "or_boolean_not_supported" | "no_accessible_repos" | "server_error" | "only_non_semantic_fields_requested" | "service_unavailable";
/** When a semantic or hybrid search falls back to lexical search, this field contains the reasons for the fallback. Only present when a fallback occurred. */
export type IssuesAndPullRequestsResponseLexicalFallbackReasonList = Array<IssuesAndPullRequestsResponseLexicalFallbackReasonItem>;
export interface IssuesAndPullRequestsResponse {
    total_count: number;
    incomplete_results: boolean;
    items: IssuesAndPullRequestsResponseItemsList;
    /** The type of search that was performed. Possible values are `lexical`, `semantic`, or `hybrid`. */
    search_type: IssuesAndPullRequestsResponseSearchType;
    /** When a semantic or hybrid search falls back to lexical search, this field contains the reasons for the fallback. Only present when a fallback occurred. */
    lexical_fallback_reason?: IssuesAndPullRequestsResponseLexicalFallbackReasonList | undefined;
}
export type LabelsRequestSort = "created" | "updated";
export type LabelsRequestOrder = "desc" | "asc";
export interface LabelsRequest {
    /** The id of the repository. */
    repository_id: number;
    /** The search keywords. This endpoint does not accept qualifiers in the query. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). */
    q: string;
    /** Sorts the results of your query by when the label was `created` or `updated`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) */
    sort?: LabelsRequestSort | (string & {}) | undefined;
    /** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. */
    order?: LabelsRequestOrder | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Label Search Result Item */
export interface LabelSearchResultItem {
    id: number;
    node_id: string;
    url: string;
    name: string;
    color: string;
    default: boolean;
    description: string | null;
    /** Timestamp indicating when the label was archived, or `null` if it has not been archived. */
    archived_at: string | null;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: SimpleUser | null;
    score: number;
    text_matches?: SearchResultTextMatches | undefined;
}
export type LabelsResponseItemsList = Array<LabelSearchResultItem>;
export interface LabelsResponse {
    total_count: number;
    incomplete_results: boolean;
    items: LabelsResponseItemsList;
}
export type ReposRequestSort = "stars" | "forks" | "help-wanted-issues" | "updated";
export type ReposRequestOrder = "desc" | "asc";
export interface ReposRequest {
    /** The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching for repositories](https://docs.github.com/articles/searching-for-repositories/)" for a detailed list of qualifiers. */
    q: string;
    /** Sorts the results of your query by number of `stars`, `forks`, or `help-wanted-issues` or how recently the items were `updated`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) */
    sort?: ReposRequestSort | (string & {}) | undefined;
    /** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. */
    order?: ReposRequestOrder | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type RepoSearchResultItemTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepoSearchResultItemPullRequestCreationPolicy = "all" | "collaborators_only";
export interface RepoSearchResultItemPermissions {
    admin: boolean;
    maintain?: boolean | undefined;
    push: boolean;
    triage?: boolean | undefined;
    pull: boolean;
}
/** Repo Search Result Item */
export interface RepoSearchResultItem {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser | null;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    created_at: string;
    updated_at: string;
    pushed_at: string;
    homepage: string | null;
    size: number;
    stargazers_count: number;
    watchers_count: number;
    language: string | null;
    forks_count: number;
    open_issues_count: number;
    master_branch?: string | undefined;
    default_branch: string;
    score: number;
    forks_url: string;
    keys_url: string;
    collaborators_url: string;
    teams_url: string;
    hooks_url: string;
    issue_events_url: string;
    events_url: string;
    assignees_url: string;
    branches_url: string;
    tags_url: string;
    blobs_url: string;
    git_tags_url: string;
    git_refs_url: string;
    trees_url: string;
    statuses_url: string;
    languages_url: string;
    stargazers_url: string;
    contributors_url: string;
    subscribers_url: string;
    subscription_url: string;
    commits_url: string;
    git_commits_url: string;
    comments_url: string;
    issue_comment_url: string;
    contents_url: string;
    compare_url: string;
    merges_url: string;
    archive_url: string;
    downloads_url: string;
    issues_url: string;
    pulls_url: string;
    milestones_url: string;
    notifications_url: string;
    labels_url: string;
    releases_url: string;
    deployments_url: string;
    git_url: string;
    ssh_url: string;
    clone_url: string;
    svn_url: string;
    forks: number;
    open_issues: number;
    watchers: number;
    topics?: RepoSearchResultItemTopicsList | undefined;
    mirror_url: string | null;
    has_issues: boolean;
    has_projects: boolean;
    has_pages: boolean;
    has_wiki: boolean;
    has_downloads: boolean;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepoSearchResultItemPullRequestCreationPolicy | undefined;
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    license: NullableLicenseSimple | null;
    permissions?: RepoSearchResultItemPermissions | undefined;
    text_matches?: SearchResultTextMatches | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    allow_merge_commit?: boolean | undefined;
    allow_squash_merge?: boolean | undefined;
    allow_rebase_merge?: boolean | undefined;
    allow_auto_merge?: boolean | undefined;
    delete_branch_on_merge?: boolean | undefined;
    allow_forking?: boolean | undefined;
    is_template?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
}
export type ReposResponseItemsList = Array<RepoSearchResultItem>;
export interface ReposResponse {
    total_count: number;
    incomplete_results: boolean;
    items: ReposResponseItemsList;
}
export interface TopicsRequest {
    /** The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). */
    q: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface TopicSearchResultItemRelatedItemTopicRelation {
    id?: number | undefined;
    name?: string | undefined;
    topic_id?: number | undefined;
    relation_type?: string | undefined;
}
export interface TopicSearchResultItemRelatedItem {
    topic_relation?: TopicSearchResultItemRelatedItemTopicRelation | undefined;
}
export type TopicSearchResultItemRelatedList = Array<TopicSearchResultItemRelatedItem>;
export type TopicSearchResultItemAliasesItemTopicRelation = TopicSearchResultItemRelatedItemTopicRelation;
export type TopicSearchResultItemAliasesItem = TopicSearchResultItemRelatedItem;
export type TopicSearchResultItemAliasesList = Array<TopicSearchResultItemRelatedItem>;
/** Topic Search Result Item */
export interface TopicSearchResultItem {
    name: string;
    display_name: string | null;
    short_description: string | null;
    description: string | null;
    created_by: string | null;
    released: string | null;
    created_at: string;
    updated_at: string;
    featured: boolean;
    curated: boolean;
    score: number;
    repository_count?: number | null | undefined;
    logo_url?: string | null | undefined;
    text_matches?: SearchResultTextMatches | undefined;
    related?: TopicSearchResultItemRelatedList | null | undefined;
    aliases?: TopicSearchResultItemAliasesList | null | undefined;
}
export type TopicsResponseItemsList = Array<TopicSearchResultItem>;
export interface TopicsResponse {
    total_count: number;
    incomplete_results: boolean;
    items: TopicsResponseItemsList;
}
export type UsersRequestSort = "followers" | "repositories" | "joined";
export type UsersRequestOrder = "desc" | "asc";
export interface UsersRequest {
    /** The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching users](https://docs.github.com/search-github/searching-on-github/searching-users)" for a detailed list of qualifiers. */
    q: string;
    /** Sorts the results of your query by number of `followers` or `repositories`, or when the person `joined` GitHub. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) */
    sort?: UsersRequestSort | (string & {}) | undefined;
    /** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. */
    order?: UsersRequestOrder | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** User Search Result Item */
export interface UserSearchResultItem {
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    received_events_url: string;
    type: string;
    score: number;
    following_url: string;
    gists_url: string;
    starred_url: string;
    events_url: string;
    public_repos?: number | undefined;
    public_gists?: number | undefined;
    followers?: number | undefined;
    following?: number | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
    name?: string | null | undefined;
    bio?: string | null | undefined;
    email?: string | null | undefined;
    location?: string | null | undefined;
    site_admin: boolean;
    hireable?: boolean | null | undefined;
    text_matches?: SearchResultTextMatches | undefined;
    blog?: string | null | undefined;
    company?: string | null | undefined;
    suspended_at?: string | null | undefined;
    user_view_type?: string | undefined;
}
export type UsersResponseItemsList = Array<UserSearchResultItem>;
export interface UsersResponse {
    total_count: number;
    incomplete_results: boolean;
    items: UsersResponseItemsList;
}
export type CodeError = GithubOpError;
/** Search code Searches for query terms inside of a file. This method returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). When searching for code, you can get text match metadata for the file **content** and file **path** fields when you pass the `text-match` media type. For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you want to find the definition of the `addClass` function inside [jQuery](https://github.com/jquery/jquery) repository, your query would look something like this: `q=addClass+in:file+language:js+repo:jquery/jquery` This query searches for the keyword `addClass` within a file's contents. The query limits the search to files where the language is JavaScript in the `jquery/jquery` repository. Considerations for code search: Due to the complexity of searching code, there are a few restrictions on how searches are performed: * Only the _default branch_ is considered. In most cases, this will be the `master` branch. * Only files smaller than 384 KB are searchable. * You must always include at least one search term when searching source code. For example, searching for [`language:go`](https://github.com/search?utf8=%E2%9C%93&q=language%3Ago&type=Code) is not valid, while [`amazing language:go`](https://github.com/search?utf8=%E2%9C%93&q=amazing+language%3Ago&type=Code) is. This endpoint requires you to authenticate and limits you to 10 requests per minute. */
export declare const code: API.PaginatedOperationMethod<CodeRequest, CodeResponse, CodeError, GithubOpContext, CodeSearchResultItem>;
export type CommitsError = GithubOpError;
/** Search commits Find commits via various criteria on the default branch (usually `main`). This method returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). When searching for commits, you can get text match metadata for the **message** field when you provide the `text-match` media type. For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you want to find commits related to CSS in the [octocat/Spoon-Knife](https://github.com/octocat/Spoon-Knife) repository. Your query would look something like this: `q=repo:octocat/Spoon-Knife+css` */
export declare const commits: API.PaginatedOperationMethod<CommitsRequest, CommitsResponse, CommitsError, GithubOpContext, CommitSearchResultItem>;
export type IssuesAndPullRequestsError = GithubOpError;
/** Search issues and pull requests Find issues by state and keyword. This method returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). When searching for issues, you can get text match metadata for the issue **title**, issue **body**, and issue **comment body** fields when you pass the `text-match` media type. For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you want to find the oldest unresolved Python bugs on Windows. Your query might look something like this. `q=windows+label:bug+language:python+state:open&sort=created&order=asc` This query searches for the keyword `windows`, within any open issue that is labeled as `bug`. The search runs across repositories whose primary language is Python. The results are sorted by creation date in ascending order, which means the oldest issues appear first in the search results. > [!NOTE] > For requests made by GitHub Apps with a user access token, you can't retrieve a combination of issues and pull requests in a single query. Requests that don't include the `is:issue` or `is:pull-request` qualifier will receive an HTTP `422 Unprocessable Entity` response. To get results for both issues and pull requests, you must send separate queries for issues and pull requests. For more information about the `is` qualifier, see "[Searching only issues or pull requests](https://docs.github.com/github/searching-for-information-on-github/searching-issues-and-pull-requests#search-only-issues-or-pull-requests)." */
export declare const issuesAndPullRequests: API.OperationMethod<IssuesAndPullRequestsRequest, IssuesAndPullRequestsResponse, IssuesAndPullRequestsError, GithubOpContext>;
export type LabelsError = GithubOpError;
/** Search labels Find labels in a repository with names or descriptions that match search keywords. Returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). When searching for labels, you can get text match metadata for the label **name** and **description** fields when you pass the `text-match` media type. For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you want to find labels in the `linguist` repository that match `bug`, `defect`, or `enhancement`. Your query might look like this: `q=bug+defect+enhancement&repository_id=64778136` The labels that best match the query appear first in the search results. */
export declare const labels: API.PaginatedOperationMethod<LabelsRequest, LabelsResponse, LabelsError, GithubOpContext, LabelSearchResultItem>;
export type ReposError = GithubOpError;
/** Search repositories Find repositories via various criteria. This method returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). When searching for repositories, you can get text match metadata for the **name** and **description** fields when you pass the `text-match` media type. For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you want to search for popular Tetris repositories written in assembly code, your query might look like this: `q=tetris+language:assembly&sort=stars&order=desc` This query searches for repositories with the word `tetris` in the name, the description, or the README. The results are limited to repositories where the primary language is assembly. The results are sorted by stars in descending order, so that the most popular repositories appear first in the search results. */
export declare const repos: API.PaginatedOperationMethod<ReposRequest, ReposResponse, ReposError, GithubOpContext, RepoSearchResultItem>;
export type TopicsError = GithubOpError;
/** Search topics Find topics via various criteria. Results are sorted by best match. This method returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). See "[Searching topics](https://docs.github.com/articles/searching-topics/)" for a detailed list of qualifiers. When searching for topics, you can get text match metadata for the topic's **short\_description**, **description**, **name**, or **display\_name** field when you pass the `text-match` media type. For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you want to search for topics related to Ruby that are featured on https://github.com/topics. Your query might look like this: `q=ruby+is:featured` This query searches for topics with the keyword `ruby` and limits the results to find only topics that are featured. The topics that are the best match for the query appear first in the search results. */
export declare const topics: API.PaginatedOperationMethod<TopicsRequest, TopicsResponse, TopicsError, GithubOpContext, TopicSearchResultItem>;
export type UsersError = GithubOpError;
/** Search users Find users via various criteria. This method returns up to 100 results [per page](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api). When searching for users, you can get text match metadata for the issue **login**, public **email**, and **name** fields when you pass the `text-match` media type. For more details about highlighting search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For more details about how to receive highlighted search results, see [Text match metadata](https://docs.github.com/rest/search/search#text-match-metadata). For example, if you're looking for a list of popular users, you might try this query: `q=tom+repos:%3E42+followers:%3E1000` This query searches for users with the name `tom`. The results are restricted to users with more than 42 repositories and over 1,000 followers. This endpoint does not accept authentication and will only include publicly visible users. As an alternative, you can use the GraphQL API. The GraphQL API requires authentication and will return private users, including Enterprise Managed Users (EMUs), that you are authorized to view. For more information, see "[GraphQL Queries](https://docs.github.com/graphql/reference/queries#search)." */
export declare const users: API.PaginatedOperationMethod<UsersRequest, UsersResponse, UsersError, GithubOpContext, UserSearchResultItem>;
//# sourceMappingURL=search.d.ts.map