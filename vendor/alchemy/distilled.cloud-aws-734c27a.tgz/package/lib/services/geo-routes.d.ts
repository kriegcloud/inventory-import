import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SensitiveBoolean = boolean;
export interface IsolineAllowOptions {
    Hot?: boolean | undefined;
    Hov?: boolean | undefined;
}
export type TimestampWithTimezoneOffset = string | redacted.Redacted<string>;
export type BoundingBox = number[];
export type Position = number[];
export type LineString = number[][];
export interface Corridor {
    LineString: number[][];
    Radius: number;
}
export type LinearRing = number[][];
export type LinearRings = number[][][];
export type Polyline = string | redacted.Redacted<string>;
export interface PolylineCorridor {
    Polyline: string | redacted.Redacted<string>;
    Radius: number;
}
export type PolylineRing = string | redacted.Redacted<string>;
export type PolylineRingList = (string | redacted.Redacted<string>)[];
export interface IsolineAvoidanceAreaGeometry {
    BoundingBox?: number[] | undefined;
    Corridor?: Corridor | undefined;
    Polygon?: number[][][] | undefined;
    PolylineCorridor?: PolylineCorridor | undefined;
    PolylinePolygon?: (string | redacted.Redacted<string>)[] | undefined;
}
export type IsolineAvoidanceAreaGeometryList = IsolineAvoidanceAreaGeometry[];
export interface IsolineAvoidanceArea {
    Except?: IsolineAvoidanceAreaGeometry[] | undefined;
    Geometry: IsolineAvoidanceAreaGeometry;
}
export type IsolineAvoidanceAreaList = IsolineAvoidanceArea[];
export type TruckRoadType = string | redacted.Redacted<string>;
export type TruckRoadTypeList = (string | redacted.Redacted<string>)[];
export type IsolineZoneCategory = "CongestionPricing" | "Environmental" | "Vignette" | (string & {});
export interface IsolineAvoidanceZoneCategory {
    Category?: IsolineZoneCategory | undefined;
}
export type IsolineAvoidanceZoneCategoryList = IsolineAvoidanceZoneCategory[];
export interface IsolineAvoidanceOptions {
    Areas?: IsolineAvoidanceArea[] | undefined;
    CarShuttleTrains?: boolean | undefined;
    ControlledAccessHighways?: boolean | undefined;
    DirtRoads?: boolean | undefined;
    Ferries?: boolean | undefined;
    SeasonalClosure?: boolean | undefined;
    TollRoads?: boolean | undefined;
    TollTransponders?: boolean | undefined;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[] | undefined;
    Tunnels?: boolean | undefined;
    UTurns?: boolean | undefined;
    ZoneCategories?: IsolineAvoidanceZoneCategory[] | undefined;
}
export type DistanceMeters = number;
export type Heading = number;
export type SensitiveString = string | redacted.Redacted<string>;
export type MatchingStrategy = "MatchAny" | "MatchMostSignificantRoad" | (string & {});
export interface IsolineMatchingOptions {
    NameHint?: string | redacted.Redacted<string> | undefined;
    OnRoadThreshold?: number | undefined;
    Radius?: number | undefined;
    Strategy?: MatchingStrategy | undefined;
}
export type SideOfStreetMatchingStrategy = "AnyStreet" | "DividedStreetOnly" | (string & {});
export interface IsolineSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy | undefined;
}
export interface IsolineDestinationOptions {
    AvoidActionsForDistance?: number | undefined;
    Heading?: number | undefined;
    Matching?: IsolineMatchingOptions | undefined;
    SideOfStreet?: IsolineSideOfStreetOptions | undefined;
}
export type GeometryFormat = "FlexiblePolyline" | "Simple" | (string & {});
export interface IsolineGranularityOptions {
    MaxPoints?: number | undefined;
    MaxResolution?: number | undefined;
}
export type ApiKey = string | redacted.Redacted<string>;
export type IsolineOptimizationObjective = "AccurateCalculation" | "BalancedCalculation" | "FastCalculation" | (string & {});
export type RoutingObjective = "FastestRoute" | "ShortestRoute" | (string & {});
export interface IsolineOriginOptions {
    AvoidActionsForDistance?: number | undefined;
    Heading?: number | undefined;
    Matching?: IsolineMatchingOptions | undefined;
    SideOfStreet?: IsolineSideOfStreetOptions | undefined;
}
export type DistanceThresholdList = number[];
export type DurationSeconds = number;
export type TimeThresholdList = number[];
export interface IsolineThresholds {
    Distance?: number[] | undefined;
    Time?: number[] | undefined;
}
export type TrafficUsage = "IgnoreTrafficData" | "UseTrafficData" | (string & {});
export interface IsolineTrafficOptions {
    FlowEventThresholdOverride?: number | undefined;
    Usage?: TrafficUsage | undefined;
}
export type IsolineTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export type IsolineEngineType = "Electric" | "InternalCombustion" | "PluginHybrid" | (string & {});
export interface IsolineVehicleLicensePlate {
    LastCharacter?: string | undefined;
}
export type SpeedKilometersPerHour = number;
export type SensitiveInteger = number;
export interface IsolineCarOptions {
    EngineType?: IsolineEngineType | undefined;
    LicensePlate?: IsolineVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
}
export interface IsolineScooterOptions {
    EngineType?: IsolineEngineType | undefined;
    LicensePlate?: IsolineVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
}
export type WeightKilograms = number;
export type IsolineHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export type IsolineHazardousCargoTypeList = IsolineHazardousCargoType[];
export type DimensionCentimeters = number;
export interface IsolineTrailerOptions {
    AxleCount?: number | undefined;
    TrailerCount?: number | undefined;
}
export type IsolineTruckType = "LightTruck" | "StraightTruck" | "Tractor" | (string & {});
export type TunnelRestrictionCode = string | redacted.Redacted<string>;
export interface WeightPerAxleGroup {
    Single?: number | undefined;
    Tandem?: number | undefined;
    Triple?: number | undefined;
    Quad?: number | undefined;
    Quint?: number | undefined;
}
export interface IsolineTruckOptions {
    AxleCount?: number | undefined;
    EngineType?: IsolineEngineType | undefined;
    GrossWeight?: number | undefined;
    HazardousCargos?: IsolineHazardousCargoType[] | undefined;
    Height?: number | undefined;
    HeightAboveFirstAxle?: number | undefined;
    KpraLength?: number | undefined;
    Length?: number | undefined;
    LicensePlate?: IsolineVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
    PayloadCapacity?: number | undefined;
    TireCount?: number | undefined;
    Trailer?: IsolineTrailerOptions | undefined;
    TruckType?: IsolineTruckType | undefined;
    TunnelRestrictionCode?: string | redacted.Redacted<string> | undefined;
    WeightPerAxle?: number | undefined;
    WeightPerAxleGroup?: WeightPerAxleGroup | undefined;
    Width?: number | undefined;
}
export interface IsolineTravelModeOptions {
    Car?: IsolineCarOptions | undefined;
    Scooter?: IsolineScooterOptions | undefined;
    Truck?: IsolineTruckOptions | undefined;
}
export interface CalculateIsolinesRequest {
    Allow?: IsolineAllowOptions | undefined;
    ArrivalTime?: string | redacted.Redacted<string> | undefined;
    Avoid?: IsolineAvoidanceOptions | undefined;
    DepartNow?: boolean | undefined;
    DepartureTime?: string | redacted.Redacted<string> | undefined;
    Destination?: number[] | undefined;
    DestinationOptions?: IsolineDestinationOptions | undefined;
    IsolineGeometryFormat?: GeometryFormat | undefined;
    IsolineGranularity?: IsolineGranularityOptions | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    OptimizeIsolineFor?: IsolineOptimizationObjective | undefined;
    OptimizeRoutingFor?: RoutingObjective | undefined;
    Origin?: number[] | undefined;
    OriginOptions?: IsolineOriginOptions | undefined;
    Thresholds: IsolineThresholds;
    Traffic?: IsolineTrafficOptions | undefined;
    TravelMode?: IsolineTravelMode | undefined;
    TravelModeOptions?: IsolineTravelModeOptions | undefined;
}
export interface IsolineConnectionGeometry {
    LineString?: number[][] | undefined;
    Polyline?: string | redacted.Redacted<string> | undefined;
}
export interface IsolineConnection {
    FromPolygonIndex: number;
    Geometry: IsolineConnectionGeometry;
    ToPolygonIndex: number;
}
export type IsolineConnectionList = IsolineConnection[];
export interface IsolineShapeGeometry {
    Polygon?: number[][][] | undefined;
    PolylinePolygon?: (string | redacted.Redacted<string>)[] | undefined;
}
export type IsolineShapeGeometryList = IsolineShapeGeometry[];
export interface Isoline {
    Connections: IsolineConnection[];
    DistanceThreshold?: number | undefined;
    Geometries: IsolineShapeGeometry[];
    TimeThreshold?: number | undefined;
}
export type IsolineList = Isoline[];
export interface CalculateIsolinesResponse {
    ArrivalTime?: string | redacted.Redacted<string> | undefined;
    DepartureTime?: string | redacted.Redacted<string> | undefined;
    IsolineGeometryFormat: GeometryFormat;
    Isolines: Isoline[];
    PricingBucket: string;
    SnappedDestination?: number[] | undefined;
    SnappedOrigin?: number[] | undefined;
}
export interface RouteMatrixAllowOptions {
    Hot?: boolean | undefined;
    Hov?: boolean | undefined;
}
export interface RouteMatrixAvoidanceAreaGeometry {
    BoundingBox?: number[] | undefined;
    Polygon?: number[][][] | undefined;
    PolylinePolygon?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface RouteMatrixAvoidanceArea {
    Geometry: RouteMatrixAvoidanceAreaGeometry;
}
export type RouteMatrixAvoidanceAreaList = RouteMatrixAvoidanceArea[];
export type RouteMatrixZoneCategory = "CongestionPricing" | "Environmental" | "Vignette" | (string & {});
export interface RouteMatrixAvoidanceZoneCategory {
    Category?: RouteMatrixZoneCategory | undefined;
}
export type RouteMatrixAvoidanceZoneCategoryList = RouteMatrixAvoidanceZoneCategory[];
export interface RouteMatrixAvoidanceOptions {
    Areas?: RouteMatrixAvoidanceArea[] | undefined;
    CarShuttleTrains?: boolean | undefined;
    ControlledAccessHighways?: boolean | undefined;
    DirtRoads?: boolean | undefined;
    Ferries?: boolean | undefined;
    TollRoads?: boolean | undefined;
    TollTransponders?: boolean | undefined;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[] | undefined;
    Tunnels?: boolean | undefined;
    UTurns?: boolean | undefined;
    ZoneCategories?: RouteMatrixAvoidanceZoneCategory[] | undefined;
}
export interface RouteMatrixMatchingOptions {
    NameHint?: string | redacted.Redacted<string> | undefined;
    OnRoadThreshold?: number | undefined;
    Radius?: number | undefined;
    Strategy?: MatchingStrategy | undefined;
}
export interface RouteMatrixSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy | undefined;
}
export interface RouteMatrixDestinationOptions {
    AvoidActionsForDistance?: number | undefined;
    Heading?: number | undefined;
    Matching?: RouteMatrixMatchingOptions | undefined;
    SideOfStreet?: RouteMatrixSideOfStreetOptions | undefined;
}
export interface RouteMatrixDestination {
    Options?: RouteMatrixDestinationOptions | undefined;
    Position: number[];
}
export type RouteMatrixDestinationList = RouteMatrixDestination[];
export type CountryCode = string | redacted.Redacted<string>;
export type CountryCodeList = (string | redacted.Redacted<string>)[];
export interface RouteMatrixExclusionOptions {
    Countries: (string | redacted.Redacted<string>)[];
}
export interface RouteMatrixOriginOptions {
    AvoidActionsForDistance?: number | undefined;
    Heading?: number | undefined;
    Matching?: RouteMatrixMatchingOptions | undefined;
    SideOfStreet?: RouteMatrixSideOfStreetOptions | undefined;
}
export interface RouteMatrixOrigin {
    Options?: RouteMatrixOriginOptions | undefined;
    Position: number[];
}
export type RouteMatrixOriginList = RouteMatrixOrigin[];
export interface RouteMatrixAutoCircle {
    Margin?: number | undefined;
    MaxRadius?: number | undefined;
}
export type SensitiveDouble = number;
export interface Circle {
    Center: number[];
    Radius: number;
}
export interface RouteMatrixBoundaryGeometry {
    AutoCircle?: RouteMatrixAutoCircle | undefined;
    Circle?: Circle | undefined;
    BoundingBox?: number[] | undefined;
    Polygon?: number[][][] | undefined;
}
export interface RouteMatrixBoundary {
    Geometry?: RouteMatrixBoundaryGeometry | undefined;
    Unbounded?: boolean | undefined;
}
export interface RouteMatrixTrafficOptions {
    FlowEventThresholdOverride?: number | undefined;
    Usage?: TrafficUsage | undefined;
}
export type RouteMatrixTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export interface RouteMatrixVehicleLicensePlate {
    LastCharacter?: string | undefined;
}
export interface RouteMatrixCarOptions {
    LicensePlate?: RouteMatrixVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
}
export interface RouteMatrixScooterOptions {
    LicensePlate?: RouteMatrixVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
}
export type RouteMatrixHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export type RouteMatrixHazardousCargoTypeList = RouteMatrixHazardousCargoType[];
export interface RouteMatrixTrailerOptions {
    TrailerCount?: number | undefined;
}
export type RouteMatrixTruckType = "LightTruck" | "StraightTruck" | "Tractor" | (string & {});
export interface RouteMatrixTruckOptions {
    AxleCount?: number | undefined;
    GrossWeight?: number | undefined;
    HazardousCargos?: RouteMatrixHazardousCargoType[] | undefined;
    Height?: number | undefined;
    KpraLength?: number | undefined;
    Length?: number | undefined;
    LicensePlate?: RouteMatrixVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
    PayloadCapacity?: number | undefined;
    Trailer?: RouteMatrixTrailerOptions | undefined;
    TruckType?: RouteMatrixTruckType | undefined;
    TunnelRestrictionCode?: string | redacted.Redacted<string> | undefined;
    WeightPerAxle?: number | undefined;
    WeightPerAxleGroup?: WeightPerAxleGroup | undefined;
    Width?: number | undefined;
}
export interface RouteMatrixTravelModeOptions {
    Car?: RouteMatrixCarOptions | undefined;
    Scooter?: RouteMatrixScooterOptions | undefined;
    Truck?: RouteMatrixTruckOptions | undefined;
}
export interface CalculateRouteMatrixRequest {
    Allow?: RouteMatrixAllowOptions | undefined;
    Avoid?: RouteMatrixAvoidanceOptions | undefined;
    DepartNow?: boolean | undefined;
    DepartureTime?: string | redacted.Redacted<string> | undefined;
    Destinations: RouteMatrixDestination[];
    Exclude?: RouteMatrixExclusionOptions | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    OptimizeRoutingFor?: RoutingObjective | undefined;
    Origins: RouteMatrixOrigin[];
    RoutingBoundary?: RouteMatrixBoundary | undefined;
    Traffic?: RouteMatrixTrafficOptions | undefined;
    TravelMode?: RouteMatrixTravelMode | undefined;
    TravelModeOptions?: RouteMatrixTravelModeOptions | undefined;
}
export type RouteMatrixErrorCode = "NoMatch" | "NoMatchDestination" | "NoMatchOrigin" | "NoRoute" | "OutOfBounds" | "OutOfBoundsDestination" | "OutOfBoundsOrigin" | "Other" | "Violation" | (string & {});
export interface RouteMatrixEntry {
    Distance: number;
    Duration: number;
    Error?: RouteMatrixErrorCode | undefined;
}
export type RouteMatrixRow = RouteMatrixEntry[];
export type RouteMatrix = RouteMatrixEntry[][];
export interface CalculateRouteMatrixResponse {
    ErrorCount: number;
    PricingBucket: string;
    RouteMatrix: RouteMatrixEntry[][];
    RoutingBoundary: RouteMatrixBoundary;
}
export interface RouteAllowOptions {
    Hot?: boolean | undefined;
    Hov?: boolean | undefined;
}
export interface RouteAvoidanceAreaGeometry {
    Corridor?: Corridor | undefined;
    BoundingBox?: number[] | undefined;
    Polygon?: number[][][] | undefined;
    PolylineCorridor?: PolylineCorridor | undefined;
    PolylinePolygon?: (string | redacted.Redacted<string>)[] | undefined;
}
export type RouteAvoidanceAreaGeometryList = RouteAvoidanceAreaGeometry[];
export interface RouteAvoidanceArea {
    Except?: RouteAvoidanceAreaGeometry[] | undefined;
    Geometry: RouteAvoidanceAreaGeometry;
}
export type RouteAvoidanceAreaList = RouteAvoidanceArea[];
export type RouteZoneCategory = "CongestionPricing" | "Environmental" | "Vignette" | (string & {});
export interface RouteAvoidanceZoneCategory {
    Category: RouteZoneCategory;
}
export type RouteAvoidanceZoneCategoryList = RouteAvoidanceZoneCategory[];
export interface RouteAvoidanceOptions {
    Areas?: RouteAvoidanceArea[] | undefined;
    CarShuttleTrains?: boolean | undefined;
    ControlledAccessHighways?: boolean | undefined;
    DirtRoads?: boolean | undefined;
    Ferries?: boolean | undefined;
    SeasonalClosure?: boolean | undefined;
    TollRoads?: boolean | undefined;
    TollTransponders?: boolean | undefined;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[] | undefined;
    Tunnels?: boolean | undefined;
    UTurns?: boolean | undefined;
    ZoneCategories?: RouteAvoidanceZoneCategory[] | undefined;
}
export interface RouteMatchingOptions {
    NameHint?: string | redacted.Redacted<string> | undefined;
    OnRoadThreshold?: number | undefined;
    Radius?: number | undefined;
    Strategy?: MatchingStrategy | undefined;
}
export interface RouteSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy | undefined;
}
export interface RouteDestinationOptions {
    AvoidActionsForDistance?: number | undefined;
    AvoidUTurns?: boolean | undefined;
    Heading?: number | undefined;
    Matching?: RouteMatchingOptions | undefined;
    SideOfStreet?: RouteSideOfStreetOptions | undefined;
    StopDuration?: number | undefined;
}
export interface RouteDriverScheduleInterval {
    DriveDuration: number;
    RestDuration: number;
}
export type RouteDriverScheduleIntervalList = RouteDriverScheduleInterval[];
export interface RouteDriverOptions {
    Schedule?: RouteDriverScheduleInterval[] | undefined;
}
export interface RouteExclusionOptions {
    Countries: (string | redacted.Redacted<string>)[];
}
export type MeasurementSystem = "Metric" | "Imperial" | (string & {});
export type LanguageTag = string;
export type LanguageTagList = string[];
export type RouteLegAdditionalFeature = "Elevation" | "Incidents" | "PassThroughWaypoints" | "Summary" | "Tolls" | "TravelStepInstructions" | "TruckRoadTypes" | "TypicalDuration" | "Zones" | "Bookings" | "IntermediateStops" | "NextDepartures" | (string & {});
export type RouteLegAdditionalFeatureList = RouteLegAdditionalFeature[];
export interface RouteOriginOptions {
    AvoidActionsForDistance?: number | undefined;
    AvoidUTurns?: boolean | undefined;
    Heading?: number | undefined;
    Matching?: RouteMatchingOptions | undefined;
    SideOfStreet?: RouteSideOfStreetOptions | undefined;
}
export type RouteSpanAdditionalFeature = "BestCaseDuration" | "CarAccess" | "Country" | "Distance" | "Duration" | "DynamicSpeed" | "FunctionalClassification" | "Gates" | "Incidents" | "Names" | "Notices" | "PedestrianAccess" | "RailwayCrossings" | "Region" | "RoadAttributes" | "RouteNumbers" | "ScooterAccess" | "SpeedLimit" | "TollSystems" | "TruckAccess" | "TruckRoadTypes" | "TypicalDuration" | "Zones" | "Consumption" | (string & {});
export type RouteSpanAdditionalFeatureList = RouteSpanAdditionalFeature[];
export type CurrencyCode = string;
export interface RouteEmissionType {
    Co2EmissionClass?: string | redacted.Redacted<string> | undefined;
    Type: string | redacted.Redacted<string>;
}
export type RouteTollVehicleCategory = "Minibus" | (string & {});
export interface RouteTollOptions {
    AllTransponders?: boolean | undefined;
    AllVignettes?: boolean | undefined;
    Currency?: string | undefined;
    EmissionType?: RouteEmissionType | undefined;
    VehicleCategory?: RouteTollVehicleCategory | undefined;
}
export interface RouteTrafficOptions {
    FlowEventThresholdOverride?: number | undefined;
    Usage?: TrafficUsage | undefined;
}
export type RouteTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | "Intermodal" | "Transit" | (string & {});
export type RouteEngineType = "Electric" | "InternalCombustion" | "PluginHybrid" | (string & {});
export interface RouteVehicleLicensePlate {
    LastCharacter?: string | redacted.Redacted<string> | undefined;
}
export interface RouteCarOptions {
    EngineType?: RouteEngineType | undefined;
    LicensePlate?: RouteVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
}
export interface RoutePedestrianOptions {
    Speed?: number | undefined;
}
export interface RouteScooterOptions {
    EngineType?: RouteEngineType | undefined;
    LicensePlate?: RouteVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
}
export type RouteHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export type RouteHazardousCargoTypeList = RouteHazardousCargoType[];
export interface RouteTrailerOptions {
    AxleCount?: number | undefined;
    TrailerCount?: number | undefined;
}
export type RouteTruckType = "LightTruck" | "StraightTruck" | "Tractor" | (string & {});
export interface RouteTruckOptions {
    AxleCount?: number | undefined;
    EngineType?: RouteEngineType | undefined;
    GrossWeight?: number | undefined;
    HazardousCargos?: RouteHazardousCargoType[] | undefined;
    Height?: number | undefined;
    HeightAboveFirstAxle?: number | undefined;
    KpraLength?: number | undefined;
    Length?: number | undefined;
    LicensePlate?: RouteVehicleLicensePlate | undefined;
    MaxSpeed?: number | undefined;
    Occupancy?: number | undefined;
    PayloadCapacity?: number | undefined;
    TireCount?: number | undefined;
    Trailer?: RouteTrailerOptions | undefined;
    TruckType?: RouteTruckType | undefined;
    TunnelRestrictionCode?: string | redacted.Redacted<string> | undefined;
    WeightPerAxle?: number | undefined;
    WeightPerAxleGroup?: WeightPerAxleGroup | undefined;
    Width?: number | undefined;
}
export type RouteAccessibilityAttribute = "Wheelchair" | (string & {});
export type RouteAccessibilityAttributeList = RouteAccessibilityAttribute[];
export interface RouteIntermodalPedestrianOptions {
    MaxDistance?: number | undefined;
    Speed?: number | undefined;
}
export type RouteRentalMode = "All" | "Car" | (string & {});
export type RouteRentalModeList = RouteRentalMode[];
export type RouteIntermodalEnabledLegs = "FirstLeg" | "LastLeg" | "EntireRoute" | "None" | (string & {});
export type RouteIntermodalEnabledLegsList = RouteIntermodalEnabledLegs[];
export interface RouteIntermodalRentalOptions {
    AllowedModes?: RouteRentalMode[] | undefined;
    EnabledFor?: RouteIntermodalEnabledLegs[] | undefined;
    ExcludedModes?: RouteRentalMode[] | undefined;
}
export type RouteTaxiMode = "All" | "Car" | (string & {});
export type RouteTaxiModeList = RouteTaxiMode[];
export interface RouteIntermodalTaxiOptions {
    AllowedModes?: RouteTaxiMode[] | undefined;
    EnabledFor?: RouteIntermodalEnabledLegs[] | undefined;
    ExcludedModes?: RouteTaxiMode[] | undefined;
}
export type RouteTransitMode = "AerialTramway" | "Airplane" | "All" | "Bus" | "BusRapidTransit" | "CityTrain" | "Ferry" | "FunicularRailway" | "HighSpeedTrain" | "IntercityTrain" | "InterregionalTrain" | "LightRail" | "Monorail" | "PrivateBus" | "RegionalTrain" | "Subway" | (string & {});
export type RouteTransitModeList = RouteTransitMode[];
export interface RouteIntermodalTransitOptions {
    AllowedModes?: RouteTransitMode[] | undefined;
    EnabledFor?: RouteIntermodalEnabledLegs[] | undefined;
    ExcludedModes?: RouteTransitMode[] | undefined;
}
export type RouteVehicleMode = "All" | "Car" | (string & {});
export type RouteVehicleModeList = RouteVehicleMode[];
export interface RouteIntermodalVehicleOptions {
    AllowedModes?: RouteVehicleMode[] | undefined;
    EnabledFor?: RouteIntermodalEnabledLegs[] | undefined;
    ExcludedModes?: RouteVehicleMode[] | undefined;
}
export interface RouteIntermodalOptions {
    AccessibilityAttributes?: RouteAccessibilityAttribute[] | undefined;
    MaxTransfers?: number | undefined;
    Pedestrian?: RouteIntermodalPedestrianOptions | undefined;
    Rental?: RouteIntermodalRentalOptions | undefined;
    Taxi?: RouteIntermodalTaxiOptions | undefined;
    Transit?: RouteIntermodalTransitOptions | undefined;
    Vehicle?: RouteIntermodalVehicleOptions | undefined;
}
export interface RouteTransitPedestrianOptions {
    MaxDistance?: number | undefined;
    Speed?: number | undefined;
}
export interface RouteTransitOptions {
    AccessibilityAttributes?: RouteAccessibilityAttribute[] | undefined;
    AllowedModes?: RouteTransitMode[] | undefined;
    ExcludedModes?: RouteTransitMode[] | undefined;
    MaxTransfers?: number | undefined;
    Pedestrian?: RouteTransitPedestrianOptions | undefined;
}
export interface RouteTravelModeOptions {
    Car?: RouteCarOptions | undefined;
    Pedestrian?: RoutePedestrianOptions | undefined;
    Scooter?: RouteScooterOptions | undefined;
    Truck?: RouteTruckOptions | undefined;
    Intermodal?: RouteIntermodalOptions | undefined;
    Transit?: RouteTransitOptions | undefined;
}
export type RouteTravelStepType = "Default" | "TurnByTurn" | (string & {});
export interface RouteWaypoint {
    AvoidActionsForDistance?: number | undefined;
    AvoidUTurns?: boolean | undefined;
    Heading?: number | undefined;
    Matching?: RouteMatchingOptions | undefined;
    PassThrough?: boolean | undefined;
    Position: number[];
    SideOfStreet?: RouteSideOfStreetOptions | undefined;
    StopDuration?: number | undefined;
}
export type RouteWaypointList = RouteWaypoint[];
export interface CalculateRoutesRequest {
    Allow?: RouteAllowOptions | undefined;
    ArrivalTime?: string | redacted.Redacted<string> | undefined;
    Avoid?: RouteAvoidanceOptions | undefined;
    DepartNow?: boolean | undefined;
    DepartureTime?: string | redacted.Redacted<string> | undefined;
    Destination: number[];
    DestinationOptions?: RouteDestinationOptions | undefined;
    Driver?: RouteDriverOptions | undefined;
    Exclude?: RouteExclusionOptions | undefined;
    InstructionsMeasurementSystem?: MeasurementSystem | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    Languages?: string[] | undefined;
    LegAdditionalFeatures?: RouteLegAdditionalFeature[] | undefined;
    LegGeometryFormat?: GeometryFormat | undefined;
    MaxAlternatives?: number | undefined;
    OptimizeRoutingFor?: RoutingObjective | undefined;
    Origin: number[];
    OriginOptions?: RouteOriginOptions | undefined;
    SpanAdditionalFeatures?: RouteSpanAdditionalFeature[] | undefined;
    Tolls?: RouteTollOptions | undefined;
    Traffic?: RouteTrafficOptions | undefined;
    TravelMode?: RouteTravelMode | undefined;
    TravelModeOptions?: RouteTravelModeOptions | undefined;
    TravelStepType?: RouteTravelStepType | undefined;
    Waypoints?: RouteWaypoint[] | undefined;
}
export type RouteResponseNoticeCode = "MainLanguageNotFound" | "Other" | "TravelTimeExceedsDriverWorkHours" | "TransitDataUnavailable" | "TransitRouteUnavailable" | "NoTransitStationsFound" | (string & {});
export type RouteNoticeImpact = "High" | "Low" | (string & {});
export interface RouteResponseNotice {
    Code: RouteResponseNoticeCode;
    Impact?: RouteNoticeImpact | undefined;
}
export type RouteResponseNoticeList = RouteResponseNotice[];
export type RouteFerryAfterTravelStepType = "Deboard" | (string & {});
export interface RouteFerryAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteFerryAfterTravelStepType;
}
export type RouteFerryAfterTravelStepList = RouteFerryAfterTravelStep[];
export type Position23 = number[];
export interface RouteFerryPlace {
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalPosition?: number[] | undefined;
    Position: number[];
    WaypointIndex?: number | undefined;
}
export interface RouteFerryArrival {
    Place: RouteFerryPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteFerryBeforeTravelStepType = "Board" | (string & {});
export interface RouteFerryBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteFerryBeforeTravelStepType;
}
export type RouteFerryBeforeTravelStepList = RouteFerryBeforeTravelStep[];
export interface RouteFerryDeparture {
    Place: RouteFerryPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteFerryNoticeCode = "AccuratePolylineUnavailable" | "NoSchedule" | "Other" | "ViolatedAvoidFerry" | "ViolatedAvoidRailFerry" | "SeasonalClosure" | "PotentialViolatedVehicleRestrictionUsage" | "ViolatedAvoidAreas" | "ViolatedVehicleRestriction" | (string & {});
export interface RouteFerryNotice {
    Code: RouteFerryNoticeCode;
    Impact?: RouteNoticeImpact | undefined;
}
export type RouteFerryNoticeList = RouteFerryNotice[];
export interface RoutePassThroughPlace {
    OriginalPosition?: number[] | undefined;
    Position: number[];
    WaypointIndex?: number | undefined;
}
export interface RoutePassThroughWaypoint {
    GeometryOffset?: number | undefined;
    Place: RoutePassThroughPlace;
}
export type RoutePassThroughWaypointList = RoutePassThroughWaypoint[];
export type CountryCode3 = string | redacted.Redacted<string>;
export interface LocalizedString {
    Language?: string | undefined;
    Value: string | redacted.Redacted<string>;
}
export type LocalizedStringList = LocalizedString[];
export interface RouteFerrySpan {
    Country?: string | redacted.Redacted<string> | undefined;
    Distance?: number | undefined;
    Duration?: number | undefined;
    GeometryOffset?: number | undefined;
    Names?: LocalizedString[] | undefined;
    Region?: string | redacted.Redacted<string> | undefined;
}
export type RouteFerrySpanList = RouteFerrySpan[];
export interface RouteFerryOverviewSummary {
    Distance: number;
    Duration: number;
}
export interface RouteFerryTravelOnlySummary {
    Duration: number;
}
export interface RouteFerrySummary {
    Overview?: RouteFerryOverviewSummary | undefined;
    TravelOnly?: RouteFerryTravelOnlySummary | undefined;
}
export type RouteFerryTravelStepType = "Depart" | "Continue" | "Arrive" | (string & {});
export interface RouteFerryTravelStep {
    Distance?: number | undefined;
    Duration: number;
    GeometryOffset?: number | undefined;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteFerryTravelStepType;
}
export type RouteFerryTravelStepList = RouteFerryTravelStep[];
export interface RouteFerryLegDetails {
    AfterTravelSteps?: RouteFerryAfterTravelStep[] | undefined;
    Arrival: RouteFerryArrival;
    BeforeTravelSteps?: RouteFerryBeforeTravelStep[] | undefined;
    Departure: RouteFerryDeparture;
    Notices?: RouteFerryNotice[] | undefined;
    PassThroughWaypoints?: RoutePassThroughWaypoint[] | undefined;
    RouteName?: string | redacted.Redacted<string> | undefined;
    Spans?: RouteFerrySpan[] | undefined;
    Summary?: RouteFerrySummary | undefined;
    TravelSteps?: RouteFerryTravelStep[] | undefined;
}
export interface RouteLegGeometry {
    LineString?: number[][] | undefined;
    Polyline?: string | redacted.Redacted<string> | undefined;
}
export type RoutePedestrianAfterTravelStepType = "Wait" | (string & {});
export interface RoutePedestrianAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RoutePedestrianAfterTravelStepType;
}
export type RoutePedestrianAfterTravelStepList = RoutePedestrianAfterTravelStep[];
export type RouteAccessibilityAvailability = "Available" | "Limited" | "Unavailable" | "Unknown" | (string & {});
export interface RouteAccessibilityAvailabilityDetails {
    Wheelchair?: RouteAccessibilityAvailability | undefined;
}
export interface RouteAccessPointDetails {
    Accessibility?: RouteAccessibilityAvailabilityDetails | undefined;
}
export type RouteSideOfStreet = "Left" | "Right" | (string & {});
export interface RouteStationDetails {
    Accessibility?: RouteAccessibilityAvailabilityDetails | undefined;
    PlatformName?: string | redacted.Redacted<string> | undefined;
    ShortName?: string | redacted.Redacted<string> | undefined;
}
export type RoutePedestrianPlaceType = "AccessPoint" | "DockingStation" | "ParkingLot" | "Station" | (string & {});
export interface RoutePedestrianPlace {
    AccessPointDetails?: RouteAccessPointDetails | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalPosition?: number[] | undefined;
    Position: number[];
    SideOfStreet?: RouteSideOfStreet | undefined;
    StationDetails?: RouteStationDetails | undefined;
    Type?: RoutePedestrianPlaceType | undefined;
    WaypointIndex?: number | undefined;
}
export interface RoutePedestrianArrival {
    Place: RoutePedestrianPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export interface RoutePedestrianDeparture {
    Place: RoutePedestrianPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RoutePedestrianNoticeCode = "AccuratePolylineUnavailable" | "Other" | "ViolatedAvoidDirtRoad" | "ViolatedAvoidTunnel" | "ViolatedPedestrianOption" | "ViolatedAvoidAreas" | (string & {});
export interface RoutePedestrianNotice {
    Code: RoutePedestrianNoticeCode;
    Impact?: RouteNoticeImpact | undefined;
}
export type RoutePedestrianNoticeList = RoutePedestrianNotice[];
export interface RouteSpanDynamicSpeedDetails {
    BestCaseSpeed?: number | undefined;
    TurnDuration?: number | undefined;
    TypicalSpeed?: number | undefined;
}
export type IndexList = number[];
export type RouteSpanPedestrianAccessAttribute = "Allowed" | "Indoors" | "NoThroughTraffic" | "Park" | "Stairs" | "TollRoad" | (string & {});
export type RouteSpanPedestrianAccessAttributeList = RouteSpanPedestrianAccessAttribute[];
export type RouteSpanRoadAttribute = "Bridge" | "BuiltUpArea" | "ControlledAccessHighway" | "DirtRoad" | "DividedRoad" | "Motorway" | "PrivateRoad" | "Ramp" | "RightHandTraffic" | "Roundabout" | "Tunnel" | "UnderConstruction" | (string & {});
export type RouteSpanRoadAttributeList = RouteSpanRoadAttribute[];
export type RouteDirection = "East" | "North" | "South" | "West" | (string & {});
export interface RouteNumber {
    Direction?: RouteDirection | undefined;
    Language?: string | undefined;
    Value: string | redacted.Redacted<string>;
}
export type RouteNumberList = RouteNumber[];
export interface RouteSpanSpeedLimitDetails {
    MaxSpeed?: number | undefined;
    Unlimited?: boolean | undefined;
}
export interface RoutePedestrianSpan {
    BestCaseDuration?: number | undefined;
    Country?: string | redacted.Redacted<string> | undefined;
    Distance?: number | undefined;
    Duration?: number | undefined;
    DynamicSpeed?: RouteSpanDynamicSpeedDetails | undefined;
    FunctionalClassification?: number | undefined;
    GeometryOffset?: number | undefined;
    Incidents?: number[] | undefined;
    Names?: LocalizedString[] | undefined;
    PedestrianAccess?: RouteSpanPedestrianAccessAttribute[] | undefined;
    Region?: string | redacted.Redacted<string> | undefined;
    RoadAttributes?: RouteSpanRoadAttribute[] | undefined;
    RouteNumbers?: RouteNumber[] | undefined;
    SpeedLimit?: RouteSpanSpeedLimitDetails | undefined;
    TypicalDuration?: number | undefined;
}
export type RoutePedestrianSpanList = RoutePedestrianSpan[];
export interface RoutePedestrianOverviewSummary {
    Distance: number;
    Duration: number;
}
export interface RoutePedestrianTravelOnlySummary {
    Duration: number;
}
export interface RoutePedestrianSummary {
    Overview?: RoutePedestrianOverviewSummary | undefined;
    TravelOnly?: RoutePedestrianTravelOnlySummary | undefined;
}
export interface RouteContinueStepDetails {
    Intersection: LocalizedString[];
}
export type RouteRoadType = "Highway" | "Rural" | "Urban" | (string & {});
export interface RouteRoad {
    RoadName: LocalizedString[];
    RouteNumber: RouteNumber[];
    Towards: LocalizedString[];
    Type?: RouteRoadType | undefined;
}
export type RouteSteeringDirection = "Left" | "Right" | "Straight" | (string & {});
export type TurnAngle = number;
export type RouteTurnIntensity = "Sharp" | "Slight" | "Typical" | (string & {});
export interface RouteKeepStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export interface RouteRoundaboutEnterStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export type RoundaboutAngle = number;
export interface RouteRoundaboutExitStepDetails {
    Intersection: LocalizedString[];
    RelativeExit?: number | undefined;
    RoundaboutAngle?: number | undefined;
    SteeringDirection?: RouteSteeringDirection | undefined;
}
export interface RouteRoundaboutPassStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export interface RouteSignpostLabel {
    RouteNumber?: RouteNumber | undefined;
    Text?: LocalizedString | undefined;
}
export type RouteSignpostLabelList = RouteSignpostLabel[];
export interface RouteSignpost {
    Labels: RouteSignpostLabel[];
}
export interface RouteTurnStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export type RoutePedestrianTravelStepType = "Arrive" | "Continue" | "Depart" | "Keep" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | (string & {});
export interface RoutePedestrianTravelStep {
    ContinueStepDetails?: RouteContinueStepDetails | undefined;
    CurrentRoad?: RouteRoad | undefined;
    Distance?: number | undefined;
    Duration: number;
    ExitNumber?: LocalizedString[] | undefined;
    GeometryOffset?: number | undefined;
    Instruction?: string | redacted.Redacted<string> | undefined;
    KeepStepDetails?: RouteKeepStepDetails | undefined;
    NextRoad?: RouteRoad | undefined;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails | undefined;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails | undefined;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails | undefined;
    Signpost?: RouteSignpost | undefined;
    TurnStepDetails?: RouteTurnStepDetails | undefined;
    Type: RoutePedestrianTravelStepType;
}
export type RoutePedestrianTravelStepList = RoutePedestrianTravelStep[];
export interface RoutePedestrianLegDetails {
    AfterTravelSteps?: RoutePedestrianAfterTravelStep[] | undefined;
    Arrival: RoutePedestrianArrival;
    Departure: RoutePedestrianDeparture;
    Notices?: RoutePedestrianNotice[] | undefined;
    PassThroughWaypoints?: RoutePassThroughWaypoint[] | undefined;
    Spans?: RoutePedestrianSpan[] | undefined;
    Summary?: RoutePedestrianSummary | undefined;
    TravelSteps?: RoutePedestrianTravelStep[] | undefined;
}
export type RouteLegTravelMode = "Car" | "Ferry" | "Pedestrian" | "Scooter" | "Truck" | "CarShuttleTrain" | "AerialTramway" | "Airplane" | "Bus" | "BusRapidTransit" | "CityTrain" | "FunicularRailway" | "HighSpeedTrain" | "IntercityTrain" | "InterregionalTrain" | "LightRail" | "Monorail" | "PrivateBus" | "RegionalTrain" | "Subway" | (string & {});
export type RouteLegType = "Ferry" | "Pedestrian" | "Vehicle" | "Rental" | "Taxi" | "Transit" | (string & {});
export type EnergyKilowattHours = number;
export type PowerKilowatts = number;
export interface RouteChargeStepDetails {
    ArrivalCharge?: number | undefined;
    ConsumablePower?: number | undefined;
    DesiredCharge?: number | undefined;
}
export type RouteVehicleAfterTravelStepType = "Park" | (string & {});
export interface RouteVehicleAfterTravelStep {
    ChargeStepDetails?: RouteChargeStepDetails | undefined;
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteVehicleAfterTravelStepType;
}
export type RouteVehicleAfterTravelStepList = RouteVehicleAfterTravelStep[];
export type RouteVehiclePlaceType = "AccessPoint" | "DockingStation" | "ParkingLot" | "Station" | (string & {});
export interface RouteVehiclePlace {
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalPosition?: number[] | undefined;
    Position: number[];
    SideOfStreet?: RouteSideOfStreet | undefined;
    WaypointIndex?: number | undefined;
    AccessPointDetails?: RouteAccessPointDetails | undefined;
    StationDetails?: RouteStationDetails | undefined;
    Type?: RouteVehiclePlaceType | undefined;
}
export interface RouteVehicleArrival {
    Place: RouteVehiclePlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export interface RouteVehicleDeparture {
    Place: RouteVehiclePlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteVehicleIncidentSeverity = "Critical" | "High" | "Medium" | "Low" | (string & {});
export type RouteVehicleIncidentType = "Accident" | "Congestion" | "Construction" | "DisabledVehicle" | "LaneRestriction" | "MassTransit" | "Other" | "PlannedEvent" | "RoadClosure" | "RoadHazard" | "Weather" | (string & {});
export interface RouteVehicleIncident {
    Description?: string | redacted.Redacted<string> | undefined;
    EndTime?: string | redacted.Redacted<string> | undefined;
    Severity?: RouteVehicleIncidentSeverity | undefined;
    StartTime?: string | redacted.Redacted<string> | undefined;
    Type?: RouteVehicleIncidentType | undefined;
}
export type RouteVehicleIncidentList = RouteVehicleIncident[];
export type RouteVehicleNoticeCode = "AccuratePolylineUnavailable" | "Other" | "PotentialViolatedAvoidTollRoadUsage" | "PotentialViolatedCarpoolUsage" | "PotentialViolatedTurnRestrictionUsage" | "PotentialViolatedVehicleRestrictionUsage" | "PotentialViolatedZoneRestrictionUsage" | "SeasonalClosure" | "TollsDataTemporarilyUnavailable" | "TollsDataUnavailable" | "TollTransponder" | "ViolatedAvoidControlledAccessHighway" | "ViolatedAvoidDifficultTurns" | "ViolatedAvoidDirtRoad" | "ViolatedAvoidSeasonalClosure" | "ViolatedAvoidTollRoad" | "ViolatedAvoidTollTransponder" | "ViolatedAvoidTruckRoadType" | "ViolatedAvoidTunnel" | "ViolatedAvoidUTurns" | "ViolatedBlockedRoad" | "ViolatedCarpool" | "ViolatedEmergencyGate" | "ViolatedStartDirection" | "ViolatedTurnRestriction" | "ViolatedVehicleRestriction" | "ViolatedZoneRestriction" | "TravelTimeExceedsDriverWorkHours" | (string & {});
export interface RouteNoticeDetailRange {
    Min?: number | undefined;
    Max?: number | undefined;
}
export type RouteWeightConstraintType = "Current" | "Gross" | "Unknown" | (string & {});
export interface RouteWeightConstraint {
    Type: RouteWeightConstraintType;
    Value: number;
}
export interface RouteViolatedConstraints {
    AllHazardsRestricted?: boolean | undefined;
    AxleCount?: RouteNoticeDetailRange | undefined;
    HazardousCargos: RouteHazardousCargoType[];
    MaxHeight?: number | undefined;
    MaxKpraLength?: number | undefined;
    MaxLength?: number | undefined;
    MaxPayloadCapacity?: number | undefined;
    MaxWeight?: RouteWeightConstraint | undefined;
    MaxWeightPerAxle?: number | undefined;
    MaxWeightPerAxleGroup?: WeightPerAxleGroup | undefined;
    MaxWidth?: number | undefined;
    Occupancy?: RouteNoticeDetailRange | undefined;
    RestrictedTimes?: string | undefined;
    TimeDependent?: boolean | undefined;
    TrailerCount?: RouteNoticeDetailRange | undefined;
    TravelMode?: boolean | undefined;
    TruckRoadType?: string | undefined;
    TruckType?: RouteTruckType | undefined;
    TunnelRestrictionCode?: string | redacted.Redacted<string> | undefined;
}
export interface RouteVehicleNoticeDetail {
    Title?: string | redacted.Redacted<string> | undefined;
    ViolatedConstraints?: RouteViolatedConstraints | undefined;
}
export type RouteVehicleNoticeDetailList = RouteVehicleNoticeDetail[];
export interface RouteVehicleNotice {
    Code: RouteVehicleNoticeCode;
    Details: RouteVehicleNoticeDetail[];
    Impact?: RouteNoticeImpact | undefined;
}
export type RouteVehicleNoticeList = RouteVehicleNotice[];
export type RouteSpanCarAccessAttribute = "Allowed" | "NoThroughTraffic" | "TollRoad" | (string & {});
export type RouteSpanCarAccessAttributeList = RouteSpanCarAccessAttribute[];
export type RouteSpanGateAttribute = "Emergency" | "KeyAccess" | "PermissionRequired" | (string & {});
export type RouteSpanRailwayCrossingAttribute = "Protected" | "Unprotected" | (string & {});
export type RouteSpanScooterAccessAttribute = "Allowed" | "NoThroughTraffic" | "TollRoad" | (string & {});
export type RouteSpanScooterAccessAttributeList = RouteSpanScooterAccessAttribute[];
export type RouteSpanTruckAccessAttribute = "Allowed" | "NoThroughTraffic" | "TollRoad" | (string & {});
export type RouteSpanTruckAccessAttributeList = RouteSpanTruckAccessAttribute[];
export interface RouteVehicleSpan {
    BestCaseDuration?: number | undefined;
    CarAccess?: RouteSpanCarAccessAttribute[] | undefined;
    Country?: string | redacted.Redacted<string> | undefined;
    Distance?: number | undefined;
    Duration?: number | undefined;
    DynamicSpeed?: RouteSpanDynamicSpeedDetails | undefined;
    FunctionalClassification?: number | undefined;
    Gate?: RouteSpanGateAttribute | undefined;
    GeometryOffset?: number | undefined;
    Incidents?: number[] | undefined;
    Names?: LocalizedString[] | undefined;
    Notices?: number[] | undefined;
    RailwayCrossing?: RouteSpanRailwayCrossingAttribute | undefined;
    Region?: string | redacted.Redacted<string> | undefined;
    RoadAttributes?: RouteSpanRoadAttribute[] | undefined;
    RouteNumbers?: RouteNumber[] | undefined;
    ScooterAccess?: RouteSpanScooterAccessAttribute[] | undefined;
    SpeedLimit?: RouteSpanSpeedLimitDetails | undefined;
    TollSystems?: number[] | undefined;
    TruckAccess?: RouteSpanTruckAccessAttribute[] | undefined;
    TruckRoadTypes?: number[] | undefined;
    TypicalDuration?: number | undefined;
    Zones?: number[] | undefined;
}
export type RouteVehicleSpanList = RouteVehicleSpan[];
export interface RouteVehicleOverviewSummary {
    BestCaseDuration?: number | undefined;
    Distance: number;
    Duration: number;
    TypicalDuration?: number | undefined;
}
export interface RouteVehicleTravelOnlySummary {
    BestCaseDuration?: number | undefined;
    Duration: number;
    TypicalDuration?: number | undefined;
}
export interface RouteVehicleSummary {
    Overview?: RouteVehicleOverviewSummary | undefined;
    TravelOnly?: RouteVehicleTravelOnlySummary | undefined;
}
export interface RouteTollPaymentSite {
    Name?: string | undefined;
    Position: number[];
}
export type RouteTollPaymentSiteList = RouteTollPaymentSite[];
export interface RouteTollPriceValueRange {
    Min: number;
    Max: number;
}
export interface RouteTollPrice {
    Currency: string;
    Estimate: boolean;
    PerDuration?: number | undefined;
    Range: boolean;
    RangeValue?: RouteTollPriceValueRange | undefined;
    Value: number;
}
export type RouteTollPassValidityPeriodType = "Annual" | "Days" | "ExtendedAnnual" | "Minutes" | "Months" | (string & {});
export interface RouteTollPassValidityPeriod {
    Period: RouteTollPassValidityPeriodType;
    PeriodCount?: number | undefined;
}
export interface RouteTollPass {
    IncludesReturnTrip?: boolean | undefined;
    SeniorPass?: boolean | undefined;
    TransferCount?: number | undefined;
    TripCount?: number | undefined;
    ValidityPeriod?: RouteTollPassValidityPeriod | undefined;
}
export type RouteTollPaymentMethod = "BankCard" | "Cash" | "CashExact" | "CreditCard" | "PassSubscription" | "TravelCard" | "Transponder" | "VideoToll" | (string & {});
export type RouteTollPaymentMethodList = RouteTollPaymentMethod[];
export interface RouteTransponder {
    SystemName?: string | redacted.Redacted<string> | undefined;
}
export type RouteTransponderList = RouteTransponder[];
export interface RouteTollRate {
    ApplicableTimes?: string | redacted.Redacted<string> | undefined;
    ConvertedPrice?: RouteTollPrice | undefined;
    Id: string | redacted.Redacted<string>;
    LocalPrice: RouteTollPrice;
    Name: string | redacted.Redacted<string>;
    Pass?: RouteTollPass | undefined;
    PaymentMethods: RouteTollPaymentMethod[];
    Transponders: RouteTransponder[];
}
export type RouteTollRateList = RouteTollRate[];
export interface RouteToll {
    Country?: string | redacted.Redacted<string> | undefined;
    PaymentSites: RouteTollPaymentSite[];
    Rates: RouteTollRate[];
    Systems: number[];
}
export type RouteTollList = RouteToll[];
export interface RouteTollSystem {
    Name?: string | redacted.Redacted<string> | undefined;
}
export type RouteTollSystemList = RouteTollSystem[];
export interface RouteContinueHighwayStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export interface RouteEnterHighwayStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export interface RouteExitStepDetails {
    Intersection: LocalizedString[];
    RelativeExit?: number | undefined;
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export interface RouteRampStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export type RouteVehicleTravelStepType = "Arrive" | "Continue" | "ContinueHighway" | "Depart" | "EnterHighway" | "Exit" | "Keep" | "Ramp" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | "UTurn" | (string & {});
export interface RouteUTurnStepDetails {
    Intersection: LocalizedString[];
    SteeringDirection?: RouteSteeringDirection | undefined;
    TurnAngle?: number | undefined;
    TurnIntensity?: RouteTurnIntensity | undefined;
}
export interface RouteVehicleTravelStep {
    ContinueHighwayStepDetails?: RouteContinueHighwayStepDetails | undefined;
    ContinueStepDetails?: RouteContinueStepDetails | undefined;
    CurrentRoad?: RouteRoad | undefined;
    Distance?: number | undefined;
    Duration: number;
    EnterHighwayStepDetails?: RouteEnterHighwayStepDetails | undefined;
    ExitNumber?: LocalizedString[] | undefined;
    ExitStepDetails?: RouteExitStepDetails | undefined;
    GeometryOffset?: number | undefined;
    Instruction?: string | redacted.Redacted<string> | undefined;
    KeepStepDetails?: RouteKeepStepDetails | undefined;
    NextRoad?: RouteRoad | undefined;
    RampStepDetails?: RouteRampStepDetails | undefined;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails | undefined;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails | undefined;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails | undefined;
    Signpost?: RouteSignpost | undefined;
    TurnStepDetails?: RouteTurnStepDetails | undefined;
    Type: RouteVehicleTravelStepType;
    UTurnStepDetails?: RouteUTurnStepDetails | undefined;
}
export type RouteVehicleTravelStepList = RouteVehicleTravelStep[];
export interface RouteZone {
    Category?: RouteZoneCategory | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
}
export type RouteZoneList = RouteZone[];
export interface RouteVehicleLegDetails {
    AfterTravelSteps?: RouteVehicleAfterTravelStep[] | undefined;
    Arrival: RouteVehicleArrival;
    Departure: RouteVehicleDeparture;
    Incidents?: RouteVehicleIncident[] | undefined;
    Notices?: RouteVehicleNotice[] | undefined;
    PassThroughWaypoints?: RoutePassThroughWaypoint[] | undefined;
    Spans?: RouteVehicleSpan[] | undefined;
    Summary?: RouteVehicleSummary | undefined;
    Tolls?: RouteToll[] | undefined;
    TollSystems?: RouteTollSystem[] | undefined;
    TravelSteps?: RouteVehicleTravelStep[] | undefined;
    TruckRoadTypes?: (string | redacted.Redacted<string>)[] | undefined;
    Zones?: RouteZone[] | undefined;
}
export type RouteRentalAfterTravelStepType = "Park" | (string & {});
export interface RouteRentalAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteRentalAfterTravelStepType;
}
export type RouteRentalAfterTravelStepList = RouteRentalAfterTravelStep[];
export interface RouteRentalAgency {
    Name: string | redacted.Redacted<string>;
    Url?: string | redacted.Redacted<string> | undefined;
}
export type RouteRentalPlaceType = "AccessPoint" | "DockingStation" | "ParkingLot" | "Station" | (string & {});
export interface RouteRentalPlace {
    AccessPointDetails?: RouteAccessPointDetails | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalPosition?: number[] | undefined;
    Position: number[];
    StationDetails?: RouteStationDetails | undefined;
    Type?: RouteRentalPlaceType | undefined;
    WaypointIndex?: number | undefined;
}
export interface RouteRentalArrival {
    Place: RouteRentalPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteAttributionType = "Disclaimer" | "Tariff" | (string & {});
export type RouteWebLinkDeviceType = "Android" | "Ios" | "Web" | (string & {});
export interface RouteWebLink {
    AnchorText?: string | redacted.Redacted<string> | undefined;
    Description: string | redacted.Redacted<string>;
    DeviceType?: RouteWebLinkDeviceType | undefined;
    Url?: string | redacted.Redacted<string> | undefined;
}
export interface RouteAttribution {
    AttributionType?: RouteAttributionType | undefined;
    WebLink: RouteWebLink;
}
export type RouteAttributionList = RouteAttribution[];
export type RouteRentalBeforeTravelStepType = "Setup" | (string & {});
export interface RouteRentalBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteRentalBeforeTravelStepType;
}
export type RouteRentalBeforeTravelStepList = RouteRentalBeforeTravelStep[];
export type RouteWebLinkList = RouteWebLink[];
export interface RouteRentalDeparture {
    Place: RouteRentalPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export interface RouteRentalOverviewSummary {
    Duration: number;
    Distance: number;
}
export interface RouteRentalTravelOnlySummary {
    Duration: number;
}
export interface RouteRentalSummary {
    Overview?: RouteRentalOverviewSummary | undefined;
    TravelOnly?: RouteRentalTravelOnlySummary | undefined;
}
export interface RouteRentalTransportModeDetails {
    AvailableSeats?: number | undefined;
    Category?: string | redacted.Redacted<string> | undefined;
    Color?: string | redacted.Redacted<string> | undefined;
    Engine?: RouteEngineType | undefined;
    LicensePlate?: string | redacted.Redacted<string> | undefined;
    Mode: RouteRentalMode;
    Model?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    TextColor?: string | redacted.Redacted<string> | undefined;
}
export type RouteRentalTravelStepType = "Arrive" | "Continue" | "Depart" | "Exit" | "Keep" | "Ramp" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | "UTurn" | (string & {});
export interface RouteRentalTravelStep {
    ContinueStepDetails?: RouteContinueStepDetails | undefined;
    Distance?: number | undefined;
    Duration: number;
    ExitStepDetails?: RouteExitStepDetails | undefined;
    GeometryOffset?: number | undefined;
    Instruction?: string | redacted.Redacted<string> | undefined;
    KeepStepDetails?: RouteKeepStepDetails | undefined;
    RampStepDetails?: RouteRampStepDetails | undefined;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails | undefined;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails | undefined;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails | undefined;
    TurnStepDetails?: RouteTurnStepDetails | undefined;
    Type: RouteRentalTravelStepType;
    UTurnStepDetails?: RouteUTurnStepDetails | undefined;
}
export type RouteRentalTravelStepList = RouteRentalTravelStep[];
export interface RouteRentalLegDetails {
    AfterTravelSteps?: RouteRentalAfterTravelStep[] | undefined;
    Agency: RouteRentalAgency;
    Arrival: RouteRentalArrival;
    Attributions?: RouteAttribution[] | undefined;
    BeforeTravelSteps?: RouteRentalBeforeTravelStep[] | undefined;
    BookingWebLinks?: RouteWebLink[] | undefined;
    Departure: RouteRentalDeparture;
    Summary?: RouteRentalSummary | undefined;
    Transport: RouteRentalTransportModeDetails;
    TravelSteps?: RouteRentalTravelStep[] | undefined;
}
export type RouteTaxiAfterTravelStepType = "Park" | (string & {});
export interface RouteTaxiAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteTaxiAfterTravelStepType;
}
export type RouteTaxiAfterTravelStepList = RouteTaxiAfterTravelStep[];
export interface RouteTaxiAgency {
    Name: string | redacted.Redacted<string>;
    Url?: string | redacted.Redacted<string> | undefined;
}
export type RouteTaxiPlaceType = "AccessPoint" | "Station" | (string & {});
export interface RouteTaxiPlace {
    AccessPointDetails?: RouteAccessPointDetails | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalPosition?: number[] | undefined;
    Position: number[];
    StationDetails?: RouteStationDetails | undefined;
    Type?: RouteTaxiPlaceType | undefined;
    WaypointIndex?: number | undefined;
}
export interface RouteTaxiArrival {
    Place: RouteTaxiPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteTaxiBeforeTravelStepType = "Wait" | (string & {});
export interface RouteTaxiBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteTaxiBeforeTravelStepType;
}
export type RouteTaxiBeforeTravelStepList = RouteTaxiBeforeTravelStep[];
export interface RouteTaxiDeparture {
    Place: RouteTaxiPlace;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteTaxiNoticeCode = "AccuratePolylineUnavailable" | "Other" | (string & {});
export interface RouteTaxiNotice {
    Code: RouteTaxiNoticeCode;
    Impact?: RouteNoticeImpact | undefined;
}
export type RouteTaxiNoticeList = RouteTaxiNotice[];
export interface RouteTaxiOverviewSummary {
    Duration: number;
    Distance: number;
}
export interface RouteTaxiTravelOnlySummary {
    Duration: number;
}
export interface RouteTaxiSummary {
    Overview?: RouteTaxiOverviewSummary | undefined;
    TravelOnly?: RouteTaxiTravelOnlySummary | undefined;
}
export interface RouteTaxiTransportModeDetails {
    AvailableSeats?: number | undefined;
    Category?: string | redacted.Redacted<string> | undefined;
    Color?: string | redacted.Redacted<string> | undefined;
    Engine?: RouteEngineType | undefined;
    LicensePlate?: string | redacted.Redacted<string> | undefined;
    Mode: RouteTaxiMode;
    Model?: string | redacted.Redacted<string> | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    TextColor?: string | redacted.Redacted<string> | undefined;
}
export type RouteTaxiTravelStepType = "Arrive" | "Continue" | "Depart" | "Exit" | "Keep" | "Ramp" | "RoundaboutEnter" | "RoundaboutExit" | "RoundaboutPass" | "Turn" | "UTurn" | (string & {});
export interface RouteTaxiTravelStep {
    ContinueStepDetails?: RouteContinueStepDetails | undefined;
    Distance?: number | undefined;
    Duration: number;
    ExitStepDetails?: RouteExitStepDetails | undefined;
    GeometryOffset?: number | undefined;
    Instruction?: string | redacted.Redacted<string> | undefined;
    KeepStepDetails?: RouteKeepStepDetails | undefined;
    RampStepDetails?: RouteRampStepDetails | undefined;
    RoundaboutEnterStepDetails?: RouteRoundaboutEnterStepDetails | undefined;
    RoundaboutExitStepDetails?: RouteRoundaboutExitStepDetails | undefined;
    RoundaboutPassStepDetails?: RouteRoundaboutPassStepDetails | undefined;
    TurnStepDetails?: RouteTurnStepDetails | undefined;
    Type: RouteTaxiTravelStepType;
    UTurnStepDetails?: RouteUTurnStepDetails | undefined;
}
export type RouteTaxiTravelStepList = RouteTaxiTravelStep[];
export interface RouteTaxiLegDetails {
    AfterTravelSteps?: RouteTaxiAfterTravelStep[] | undefined;
    Agency: RouteTaxiAgency;
    Arrival: RouteTaxiArrival;
    Attributions?: RouteAttribution[] | undefined;
    BeforeTravelSteps?: RouteTaxiBeforeTravelStep[] | undefined;
    BookingWebLinks?: RouteWebLink[] | undefined;
    Departure: RouteTaxiDeparture;
    Notices?: RouteTaxiNotice[] | undefined;
    Summary?: RouteTaxiSummary | undefined;
    Transport: RouteTaxiTransportModeDetails;
    TravelSteps?: RouteTaxiTravelStep[] | undefined;
}
export type RouteTransitAfterTravelStepType = "Deboard" | (string & {});
export interface RouteTransitAfterTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteTransitAfterTravelStepType;
}
export type RouteTransitAfterTravelStepList = RouteTransitAfterTravelStep[];
export interface RouteTransitAgency {
    Name: string | redacted.Redacted<string>;
    Url?: string | redacted.Redacted<string> | undefined;
}
export type RouteTransitPlaceType = "Station" | (string & {});
export interface RouteTransitPlace {
    Name?: string | redacted.Redacted<string> | undefined;
    OriginalPosition?: number[] | undefined;
    Position: number[];
    StationDetails?: RouteStationDetails | undefined;
    Type?: RouteTransitPlaceType | undefined;
    WaypointIndex?: number | undefined;
}
export type RouteTransitTripStatus = "Added" | "Cancelled" | "Replaced" | "Scheduled" | (string & {});
export interface RouteTransitArrival {
    Delay?: number | undefined;
    Place: RouteTransitPlace;
    Status?: RouteTransitTripStatus | undefined;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteTransitBeforeTravelStepType = "Board" | (string & {});
export interface RouteTransitBeforeTravelStep {
    Duration: number;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteTransitBeforeTravelStepType;
}
export type RouteTransitBeforeTravelStepList = RouteTransitBeforeTravelStep[];
export interface RouteTransitDeparture {
    Delay?: number | undefined;
    Place: RouteTransitPlace;
    Status?: RouteTransitTripStatus | undefined;
    Time?: string | redacted.Redacted<string> | undefined;
}
export type RouteTransitIncidentEffect = "Delayed" | "Detoured" | "Other" | "ServiceAdded" | "ServiceCancelled" | "ServiceModified" | "ServiceReduced" | "StopMoved" | (string & {});
export type RouteTransitIncidentType = "Accident" | "Construction" | "Demonstration" | "Holiday" | "Maintenance" | "MedicalEmergency" | "Other" | "PoliceActivity" | "Strike" | "TechnicalProblem" | "Weather" | (string & {});
export interface RouteTransitIncident {
    Description?: string | redacted.Redacted<string> | undefined;
    Effect: RouteTransitIncidentEffect;
    EndTime?: string | redacted.Redacted<string> | undefined;
    StartTime?: string | redacted.Redacted<string> | undefined;
    Type: RouteTransitIncidentType;
    Url?: string | redacted.Redacted<string> | undefined;
}
export type RouteTransitIncidentList = RouteTransitIncident[];
export type RouteTransitIntermediateStopAttribute = "NoEntry" | "NoExit" | (string & {});
export type RouteTransitIntermediateStopAttributeList = RouteTransitIntermediateStopAttribute[];
export type HexColor = string | redacted.Redacted<string>;
export interface RouteTransitTransportModeDetails {
    Accessibility?: RouteAccessibilityAvailabilityDetails | undefined;
    Color?: string | redacted.Redacted<string> | undefined;
    Headsign?: string | redacted.Redacted<string> | undefined;
    LongRouteName?: string | redacted.Redacted<string> | undefined;
    Mode: RouteTransitMode;
    RouteName?: string | redacted.Redacted<string> | undefined;
    ShortRouteName?: string | redacted.Redacted<string> | undefined;
    TextColor?: string | redacted.Redacted<string> | undefined;
}
export interface RouteTransitIntermediateStop {
    Attributes?: RouteTransitIntermediateStopAttribute[] | undefined;
    Departure: RouteTransitDeparture;
    Duration: number;
    GeometryOffset?: number | undefined;
    Transport?: RouteTransitTransportModeDetails | undefined;
}
export type RouteTransitIntermediateStopList = RouteTransitIntermediateStop[];
export interface RouteTransitNextDeparture {
    Delay?: number | undefined;
    PlatformName?: string | redacted.Redacted<string> | undefined;
    Status?: RouteTransitTripStatus | undefined;
    Time: string | redacted.Redacted<string>;
    Transport?: RouteTransitTransportModeDetails | undefined;
}
export type RouteTransitNextDepartureList = RouteTransitNextDeparture[];
export type RouteTransitNoticeCode = "AccuratePolylineUnavailable" | "IntermediateStopsUnavailable" | "NoSchedule" | "Other" | "PotentialViolatedVehicleRestrictionUsage" | "ScheduledTimes" | "SeasonalClosure" | "ViolatedAvoidFerry" | "ViolatedAvoidRailFerry" | "ViolatedExcludedTransitMode" | "ViolatedVehicleRestriction" | "ViolatedAvoidAreas" | (string & {});
export interface RouteTransitNotice {
    Code: RouteTransitNoticeCode;
    Impact?: RouteNoticeImpact | undefined;
}
export type RouteTransitNoticeList = RouteTransitNotice[];
export interface RouteTransitSpan {
    Country?: string | redacted.Redacted<string> | undefined;
    Distance?: number | undefined;
    Duration?: number | undefined;
    GeometryOffset?: number | undefined;
    Names?: LocalizedString[] | undefined;
    Region?: string | redacted.Redacted<string> | undefined;
}
export type RouteTransitSpanList = RouteTransitSpan[];
export interface RouteTransitOverviewSummary {
    Distance: number;
    Duration: number;
}
export interface RouteTransitTravelOnlySummary {
    Duration: number;
}
export interface RouteTransitSummary {
    Overview?: RouteTransitOverviewSummary | undefined;
    TravelOnly?: RouteTransitTravelOnlySummary | undefined;
}
export type RouteTransitTravelStepType = "Depart" | (string & {});
export interface RouteTransitTravelStep {
    Distance?: number | undefined;
    Duration: number;
    GeometryOffset?: number | undefined;
    Instruction?: string | redacted.Redacted<string> | undefined;
    Type: RouteTransitTravelStepType;
}
export type RouteTransitTravelStepList = RouteTransitTravelStep[];
export interface RouteTransitLegDetails {
    AfterTravelSteps?: RouteTransitAfterTravelStep[] | undefined;
    Agency?: RouteTransitAgency | undefined;
    Arrival: RouteTransitArrival;
    Attributions?: RouteAttribution[] | undefined;
    BeforeTravelSteps?: RouteTransitBeforeTravelStep[] | undefined;
    BookingWebLinks?: RouteWebLink[] | undefined;
    Departure: RouteTransitDeparture;
    Incidents?: RouteTransitIncident[] | undefined;
    IntermediateStops?: RouteTransitIntermediateStop[] | undefined;
    NextDepartures?: RouteTransitNextDeparture[] | undefined;
    Notices?: RouteTransitNotice[] | undefined;
    PassThroughWaypoints?: RoutePassThroughWaypoint[] | undefined;
    Spans?: RouteTransitSpan[] | undefined;
    Summary?: RouteTransitSummary | undefined;
    Transport: RouteTransitTransportModeDetails;
    TravelSteps?: RouteTransitTravelStep[] | undefined;
}
export interface RouteLeg {
    FerryLegDetails?: RouteFerryLegDetails | undefined;
    Geometry: RouteLegGeometry;
    Language?: string | undefined;
    PedestrianLegDetails?: RoutePedestrianLegDetails | undefined;
    TravelMode: RouteLegTravelMode;
    Type: RouteLegType;
    VehicleLegDetails?: RouteVehicleLegDetails | undefined;
    RentalLegDetails?: RouteRentalLegDetails | undefined;
    TaxiLegDetails?: RouteTaxiLegDetails | undefined;
    TransitLegDetails?: RouteTransitLegDetails | undefined;
}
export type RouteLegList = RouteLeg[];
export interface RouteMajorRoadLabel {
    RoadName?: LocalizedString | undefined;
    RouteNumber?: RouteNumber | undefined;
}
export type RouteMajorRoadLabelList = RouteMajorRoadLabel[];
export interface RouteTollPriceSummary {
    Currency: string;
    Estimate: boolean;
    Range: boolean;
    RangeValue?: RouteTollPriceValueRange | undefined;
    Value: number;
}
export interface RouteTollSummary {
    Total?: RouteTollPriceSummary | undefined;
}
export interface RouteSummary {
    Distance?: number | undefined;
    Duration?: number | undefined;
    Tolls?: RouteTollSummary | undefined;
}
export interface Route {
    Legs: RouteLeg[];
    MajorRoadLabels: RouteMajorRoadLabel[];
    Summary?: RouteSummary | undefined;
}
export type RouteList = Route[];
export interface CalculateRoutesResponse {
    LegGeometryFormat: GeometryFormat;
    Notices: RouteResponseNotice[];
    PricingBucket: string;
    Routes: Route[];
}
export interface WaypointOptimizationAvoidanceAreaGeometry {
    BoundingBox?: number[] | undefined;
}
export interface WaypointOptimizationAvoidanceArea {
    Geometry: WaypointOptimizationAvoidanceAreaGeometry;
}
export type WaypointOptimizationAvoidanceAreaList = WaypointOptimizationAvoidanceArea[];
export interface WaypointOptimizationAvoidanceOptions {
    Areas?: WaypointOptimizationAvoidanceArea[] | undefined;
    CarShuttleTrains?: boolean | undefined;
    ControlledAccessHighways?: boolean | undefined;
    DirtRoads?: boolean | undefined;
    Ferries?: boolean | undefined;
    TollRoads?: boolean | undefined;
    Tunnels?: boolean | undefined;
    UTurns?: boolean | undefined;
}
export type WaypointOptimizationClusteringAlgorithm = "DrivingDistance" | "TopologySegment" | (string & {});
export type WaypointOptimizationDrivingDistance = number;
export interface WaypointOptimizationDrivingDistanceOptions {
    DrivingDistance: number;
}
export interface WaypointOptimizationClusteringOptions {
    Algorithm: WaypointOptimizationClusteringAlgorithm;
    DrivingDistanceOptions?: WaypointOptimizationDrivingDistanceOptions | undefined;
}
export type DayOfWeek = "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday" | (string & {});
export type TimeOfDay = string | redacted.Redacted<string>;
export interface WaypointOptimizationAccessHoursEntry {
    DayOfWeek: DayOfWeek;
    TimeOfDay: string | redacted.Redacted<string>;
}
export interface WaypointOptimizationAccessHours {
    From: WaypointOptimizationAccessHoursEntry;
    To: WaypointOptimizationAccessHoursEntry;
}
export type WaypointId = string;
export interface WaypointOptimizationSideOfStreetOptions {
    Position: number[];
    UseWith?: SideOfStreetMatchingStrategy | undefined;
}
export interface WaypointOptimizationDestinationOptions {
    AccessHours?: WaypointOptimizationAccessHours | undefined;
    AppointmentTime?: string | redacted.Redacted<string> | undefined;
    Heading?: number | undefined;
    Id?: string | undefined;
    ServiceDuration?: number | undefined;
    SideOfStreet?: WaypointOptimizationSideOfStreetOptions | undefined;
}
export interface WaypointOptimizationRestCycleDurations {
    RestDuration: number;
    WorkDuration: number;
}
export interface WaypointOptimizationRestCycles {
    LongCycle: WaypointOptimizationRestCycleDurations;
    ShortCycle: WaypointOptimizationRestCycleDurations;
}
export interface WaypointOptimizationRestProfile {
    Profile: string | redacted.Redacted<string>;
}
export type WaypointOptimizationServiceTimeTreatment = "Rest" | "Work" | (string & {});
export interface WaypointOptimizationDriverOptions {
    RestCycles?: WaypointOptimizationRestCycles | undefined;
    RestProfile?: WaypointOptimizationRestProfile | undefined;
    TreatServiceTimeAs?: WaypointOptimizationServiceTimeTreatment | undefined;
}
export interface WaypointOptimizationExclusionOptions {
    Countries: (string | redacted.Redacted<string>)[];
}
export type WaypointOptimizationSequencingObjective = "FastestRoute" | "ShortestRoute" | (string & {});
export interface WaypointOptimizationOriginOptions {
    Id?: string | undefined;
}
export interface WaypointOptimizationTrafficOptions {
    Usage?: TrafficUsage | undefined;
}
export type WaypointOptimizationTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export interface WaypointOptimizationPedestrianOptions {
    Speed?: number | undefined;
}
export type WaypointOptimizationHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export type WaypointOptimizationHazardousCargoTypeList = WaypointOptimizationHazardousCargoType[];
export interface WaypointOptimizationTrailerOptions {
    TrailerCount?: number | undefined;
}
export type WaypointOptimizationTruckType = "StraightTruck" | "Tractor" | (string & {});
export interface WaypointOptimizationTruckOptions {
    GrossWeight?: number | undefined;
    HazardousCargos?: WaypointOptimizationHazardousCargoType[] | undefined;
    Height?: number | undefined;
    Length?: number | undefined;
    Trailer?: WaypointOptimizationTrailerOptions | undefined;
    TruckType?: WaypointOptimizationTruckType | undefined;
    TunnelRestrictionCode?: string | redacted.Redacted<string> | undefined;
    WeightPerAxle?: number | undefined;
    Width?: number | undefined;
}
export interface WaypointOptimizationTravelModeOptions {
    Pedestrian?: WaypointOptimizationPedestrianOptions | undefined;
    Truck?: WaypointOptimizationTruckOptions | undefined;
}
export type WaypointIndex = number;
export type BeforeWaypointsList = number[];
export interface WaypointOptimizationWaypoint {
    AccessHours?: WaypointOptimizationAccessHours | undefined;
    AppointmentTime?: string | redacted.Redacted<string> | undefined;
    Before?: number[] | undefined;
    Heading?: number | undefined;
    Id?: string | undefined;
    Position: number[];
    ServiceDuration?: number | undefined;
    SideOfStreet?: WaypointOptimizationSideOfStreetOptions | undefined;
}
export type WaypointOptimizationWaypointList = WaypointOptimizationWaypoint[];
export interface OptimizeWaypointsRequest {
    Avoid?: WaypointOptimizationAvoidanceOptions | undefined;
    Clustering?: WaypointOptimizationClusteringOptions | undefined;
    DepartureTime?: string | redacted.Redacted<string> | undefined;
    Destination?: number[] | undefined;
    DestinationOptions?: WaypointOptimizationDestinationOptions | undefined;
    Driver?: WaypointOptimizationDriverOptions | undefined;
    Exclude?: WaypointOptimizationExclusionOptions | undefined;
    Key?: string | redacted.Redacted<string> | undefined;
    OptimizeSequencingFor?: WaypointOptimizationSequencingObjective | undefined;
    Origin: number[];
    OriginOptions?: WaypointOptimizationOriginOptions | undefined;
    Traffic?: WaypointOptimizationTrafficOptions | undefined;
    TravelMode?: WaypointOptimizationTravelMode | undefined;
    TravelModeOptions?: WaypointOptimizationTravelModeOptions | undefined;
    Waypoints?: WaypointOptimizationWaypoint[] | undefined;
}
export interface WaypointOptimizationConnection {
    Distance: number;
    From: string;
    RestDuration: number;
    To: string;
    TravelDuration: number;
    WaitDuration: number;
}
export type WaypointOptimizationConnectionList = WaypointOptimizationConnection[];
export type WaypointOptimizationConstraint = "AccessHours" | "AppointmentTime" | "Before" | "Heading" | "ServiceDuration" | "SideOfStreet" | (string & {});
export interface WaypointOptimizationFailedConstraint {
    Constraint?: WaypointOptimizationConstraint | undefined;
    Reason?: string | redacted.Redacted<string> | undefined;
}
export type WaypointOptimizationFailedConstraintList = WaypointOptimizationFailedConstraint[];
export interface WaypointOptimizationImpedingWaypoint {
    FailedConstraints: WaypointOptimizationFailedConstraint[];
    Id: string;
    Position: number[];
}
export type WaypointOptimizationImpedingWaypointList = WaypointOptimizationImpedingWaypoint[];
export type ClusterIndex = number;
export interface WaypointOptimizationOptimizedWaypoint {
    ArrivalTime?: string | redacted.Redacted<string> | undefined;
    ClusterIndex?: number | undefined;
    DepartureTime?: string | redacted.Redacted<string> | undefined;
    Id: string;
    Position: number[];
}
export type WaypointOptimizationOptimizedWaypointList = WaypointOptimizationOptimizedWaypoint[];
export interface WaypointOptimizationTimeBreakdown {
    RestDuration: number;
    ServiceDuration: number;
    TravelDuration: number;
    WaitDuration: number;
}
export interface OptimizeWaypointsResponse {
    Connections: WaypointOptimizationConnection[];
    Distance: number;
    Duration: number;
    ImpedingWaypoints: WaypointOptimizationImpedingWaypoint[];
    OptimizedWaypoints: WaypointOptimizationOptimizedWaypoint[];
    PricingBucket: string;
    TimeBreakdown: WaypointOptimizationTimeBreakdown;
}
export interface RoadSnapTracePoint {
    Heading?: number | undefined;
    Position: number[];
    Speed?: number | undefined;
    Timestamp?: string | redacted.Redacted<string> | undefined;
}
export type RoadSnapTracePointList = RoadSnapTracePoint[];
export type RoadSnapTravelMode = "Car" | "Pedestrian" | "Scooter" | "Truck" | (string & {});
export type RoadSnapHazardousCargoType = "Combustible" | "Corrosive" | "Explosive" | "Flammable" | "Gas" | "HarmfulToWater" | "Organic" | "Other" | "Poison" | "PoisonousInhalation" | "Radioactive" | (string & {});
export type RoadSnapHazardousCargoTypeList = RoadSnapHazardousCargoType[];
export interface RoadSnapTrailerOptions {
    TrailerCount?: number | undefined;
}
export interface RoadSnapTruckOptions {
    GrossWeight?: number | undefined;
    HazardousCargos?: RoadSnapHazardousCargoType[] | undefined;
    Height?: number | undefined;
    Length?: number | undefined;
    Trailer?: RoadSnapTrailerOptions | undefined;
    TunnelRestrictionCode?: string | redacted.Redacted<string> | undefined;
    Width?: number | undefined;
}
export interface RoadSnapTravelModeOptions {
    Truck?: RoadSnapTruckOptions | undefined;
}
export interface SnapToRoadsRequest {
    Key?: string | redacted.Redacted<string> | undefined;
    SnappedGeometryFormat?: GeometryFormat | undefined;
    SnapRadius?: number | undefined;
    TracePoints: RoadSnapTracePoint[];
    TravelMode?: RoadSnapTravelMode | undefined;
    TravelModeOptions?: RoadSnapTravelModeOptions | undefined;
}
export type RoadSnapNoticeCode = "TracePointsHeadingIgnored" | "TracePointsIgnored" | "TracePointsMovedByLargeDistance" | "TracePointsNotMatched" | "TracePointsOutOfSequence" | "TracePointsSpeedEstimated" | "TracePointsSpeedIgnored" | (string & {});
export type RoadSnapTracePointIndexList = number[];
export interface RoadSnapNotice {
    Code: RoadSnapNoticeCode;
    Title: string | redacted.Redacted<string>;
    TracePointIndexes: number[];
}
export type RoadSnapNoticeList = RoadSnapNotice[];
export interface RoadSnapSnappedGeometry {
    LineString?: number[][] | undefined;
    Polyline?: string | redacted.Redacted<string> | undefined;
}
export interface RoadSnapSnappedTracePoint {
    Confidence: number;
    OriginalPosition: number[];
    SnappedPosition: number[];
}
export type RoadSnapSnappedTracePointList = RoadSnapSnappedTracePoint[];
export interface SnapToRoadsResponse {
    Notices: RoadSnapNotice[];
    PricingBucket: string;
    SnappedGeometry?: RoadSnapSnappedGeometry | undefined;
    SnappedGeometryFormat: GeometryFormat;
    SnappedTracePoints: RoadSnapSnappedTracePoint[];
}
export type ValidationExceptionReason = "UnknownOperation" | "Missing" | "CannotParse" | "FieldValidationFailed" | "Other" | "UnknownField" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CalculateIsolinesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Calculates areas that can be reached within specified time or distance thresholds from a given point. For example, you can use this operation to determine the area within a 30-minute drive of a store location, find neighborhoods within walking distance of a school, or identify delivery zones based on drive time.
 *
 * Isolines (also known as isochrones for time-based calculations) are useful for various applications including:
 *
 * - Service area visualization - Show customers the area you can serve within promised delivery times
 *
 * - Site selection - Analyze potential business locations based on population within travel distance
 *
 * - Site selection - Determine areas that can be reached within specified response times
 *
 * Route preferences such as avoiding toll roads or ferries are treated as preferences rather than absolute restrictions. If a viable route cannot be calculated while honoring all preferences, some may be ignored.
 *
 * For more information, see Calculate isolines in the *Amazon Location Service Developer Guide*.
 */
export declare const calculateIsolines: API.OperationMethod<CalculateIsolinesRequest & RegionInput, CalculateIsolinesResponse, CalculateIsolinesError, Credentials | HttpClient.HttpClient>;
export type CalculateRouteMatrixError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use `CalculateRouteMatrix` to compute results for all pairs of Origins to Destinations. Each row corresponds to one entry in Origins. Each entry in the row corresponds to the route from that entry in Origins to an entry in Destinations positions.
 *
 * For more information, see Calculate route matrix in the *Amazon Location Service Developer Guide*.
 */
export declare const calculateRouteMatrix: API.OperationMethod<CalculateRouteMatrixRequest & RegionInput, CalculateRouteMatrixResponse, CalculateRouteMatrixError, Credentials | HttpClient.HttpClient>;
export type CalculateRoutesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `CalculateRoutes` computes routes given the following required parameters: `Origin` and `Destination`.
 *
 * For more information, see Calculate routes in the *Amazon Location Service Developer Guide*.
 */
export declare const calculateRoutes: API.OperationMethod<CalculateRoutesRequest & RegionInput, CalculateRoutesResponse, CalculateRoutesError, Credentials | HttpClient.HttpClient>;
export type OptimizeWaypointsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `OptimizeWaypoints` calculates the optimal order to travel between a set of waypoints to minimize either the travel time or the distance travelled during the journey, based on road network restrictions and the traffic pattern data.
 *
 * For more information, see Optimize waypoints in the *Amazon Location Service Developer Guide*.
 */
export declare const optimizeWaypoints: API.OperationMethod<OptimizeWaypointsRequest & RegionInput, OptimizeWaypointsResponse, OptimizeWaypointsError, Credentials | HttpClient.HttpClient>;
export type SnapToRoadsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * `SnapToRoads` matches GPS trace to roads most likely traveled on.
 *
 * For more information, see Snap to Roads in the *Amazon Location Service Developer Guide*.
 */
export declare const snapToRoads: API.OperationMethod<SnapToRoadsRequest & RegionInput, SnapToRoadsResponse, SnapToRoadsError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=geo-routes.d.ts.map