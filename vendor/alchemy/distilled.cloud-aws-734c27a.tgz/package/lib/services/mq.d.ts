import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly ErrorAttribute: any;
    readonly message: any;
    readonly ResourceShareErrors: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type AuthenticationStrategy = "SIMPLE" | "LDAP" | "CONFIG_MANAGED" | (string & {});
export interface ConfigurationId {
    Id?: string | undefined;
    Revision?: number | undefined;
}
export type DeploymentMode = "SINGLE_INSTANCE" | "ACTIVE_STANDBY_MULTI_AZ" | "CLUSTER_MULTI_AZ" | (string & {});
export interface EncryptionOptions {
    KmsKeyId?: string | undefined;
    UseAwsOwnedKey?: boolean | undefined;
}
export type EngineType = "ACTIVEMQ" | "RABBITMQ" | (string & {});
export type __listOf__string = string[];
export interface LdapServerMetadataInput {
    Hosts?: string[] | undefined;
    RoleBase?: string | undefined;
    RoleName?: string | undefined;
    RoleSearchMatching?: string | undefined;
    RoleSearchSubtree?: boolean | undefined;
    ServiceAccountPassword?: string | redacted.Redacted<string> | undefined;
    ServiceAccountUsername?: string | undefined;
    UserBase?: string | undefined;
    UserRoleName?: string | undefined;
    UserSearchMatching?: string | undefined;
    UserSearchSubtree?: boolean | undefined;
}
export interface Logs {
    Audit?: boolean | undefined;
    General?: boolean | undefined;
}
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface WeeklyStartTime {
    DayOfWeek?: DayOfWeek | undefined;
    TimeOfDay?: string | undefined;
    TimeZone?: string | undefined;
}
export type BrokerStorageType = "EBS" | "EFS" | (string & {});
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface User {
    ConsoleAccess?: boolean | undefined;
    Groups?: string[] | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Username?: string | undefined;
    ReplicationUser?: boolean | undefined;
}
export type __listOfUser = User[];
export type DataReplicationMode = "NONE" | "CRDR" | (string & {});
export interface CreateBrokerRequest {
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    BrokerName?: string | undefined;
    Configuration?: ConfigurationId | undefined;
    CreatorRequestId?: string | undefined;
    DeploymentMode?: DeploymentMode | undefined;
    EncryptionOptions?: EncryptionOptions | undefined;
    EngineType?: EngineType | undefined;
    EngineVersion?: string | undefined;
    HostInstanceType?: string | undefined;
    LdapServerMetadata?: LdapServerMetadataInput | undefined;
    Logs?: Logs | undefined;
    MaintenanceWindowStartTime?: WeeklyStartTime | undefined;
    PubliclyAccessible?: boolean | undefined;
    SecurityGroups?: string[] | undefined;
    StorageSize?: number | undefined;
    StorageType?: BrokerStorageType | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Users?: User[] | undefined;
    DataReplicationMode?: DataReplicationMode | undefined;
    DataReplicationPrimaryBrokerArn?: string | undefined;
}
export interface CreateBrokerResponse {
    BrokerArn?: string | undefined;
    BrokerId?: string | undefined;
}
export interface CreateConfigurationRequest {
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    EngineType?: EngineType | undefined;
    EngineVersion?: string | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __timestampIso8601 = Date;
export interface ConfigurationRevision {
    Created?: Date | undefined;
    Description?: string | undefined;
    Revision?: number | undefined;
}
export interface CreateConfigurationResponse {
    Arn?: string | undefined;
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    Created?: Date | undefined;
    Id?: string | undefined;
    LatestRevision?: (ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    }) | undefined;
    Name?: string | undefined;
}
export interface CreateTagsRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateTagsResponse {
}
export interface CreateUserRequest {
    BrokerId: string;
    ConsoleAccess?: boolean | undefined;
    Groups?: string[] | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Username: string;
    ReplicationUser?: boolean | undefined;
}
export interface CreateUserResponse {
}
export interface DeleteBrokerRequest {
    BrokerId: string;
}
export interface DeleteBrokerResponse {
    BrokerId?: string | undefined;
}
export interface DeleteConfigurationRequest {
    ConfigurationId: string;
}
export interface DeleteConfigurationResponse {
    ConfigurationId?: string | undefined;
}
export interface DeleteTagsRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface DeleteTagsResponse {
}
export interface DeleteUserRequest {
    BrokerId: string;
    Username: string;
}
export interface DeleteUserResponse {
}
export interface DescribeBrokerRequest {
    BrokerId: string;
}
export interface ActionRequired {
    ActionRequiredCode?: string | undefined;
    ActionRequiredInfo?: string | undefined;
}
export type __listOfActionRequired = ActionRequired[];
export interface BrokerInstance {
    ConsoleURL?: string | undefined;
    Endpoints?: string[] | undefined;
    IpAddress?: string | undefined;
}
export type __listOfBrokerInstance = BrokerInstance[];
export type BrokerState = "CREATION_IN_PROGRESS" | "CREATION_FAILED" | "DELETION_IN_PROGRESS" | "RUNNING" | "REBOOT_IN_PROGRESS" | "CRITICAL_ACTION_REQUIRED" | "REPLICA" | (string & {});
export type __listOfConfigurationId = ConfigurationId[];
export interface Configurations {
    Current?: ConfigurationId | undefined;
    History?: ConfigurationId[] | undefined;
    Pending?: ConfigurationId | undefined;
}
export interface LdapServerMetadataOutput {
    Hosts?: string[] | undefined;
    RoleBase?: string | undefined;
    RoleName?: string | undefined;
    RoleSearchMatching?: string | undefined;
    RoleSearchSubtree?: boolean | undefined;
    ServiceAccountUsername?: string | undefined;
    UserBase?: string | undefined;
    UserRoleName?: string | undefined;
    UserSearchMatching?: string | undefined;
    UserSearchSubtree?: boolean | undefined;
}
export interface PendingLogs {
    Audit?: boolean | undefined;
    General?: boolean | undefined;
}
export interface LogsSummary {
    Audit?: boolean | undefined;
    AuditLogGroup?: string | undefined;
    General?: boolean | undefined;
    GeneralLogGroup?: string | undefined;
    Pending?: PendingLogs | undefined;
}
export type ChangeType = "CREATE" | "UPDATE" | "DELETE" | (string & {});
export interface UserSummary {
    PendingChange?: ChangeType | undefined;
    Username?: string | undefined;
}
export type __listOfUserSummary = UserSummary[];
export interface DataReplicationCounterpart {
    BrokerId?: string | undefined;
    Region?: string | undefined;
}
export interface DataReplicationMetadataOutput {
    DataReplicationCounterpart?: DataReplicationCounterpart | undefined;
    DataReplicationRole?: string | undefined;
}
export interface DescribeBrokerResponse {
    ActionsRequired?: ActionRequired[] | undefined;
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    BrokerArn?: string | undefined;
    BrokerId?: string | undefined;
    BrokerInstances?: BrokerInstance[] | undefined;
    BrokerName?: string | undefined;
    BrokerState?: BrokerState | undefined;
    Configurations?: (Configurations & {
        Current: ConfigurationId & {
            Id: string;
        };
        History: (ConfigurationId & {
            Id: string;
        })[];
        Pending: ConfigurationId & {
            Id: string;
        };
    }) | undefined;
    Created?: Date | undefined;
    DeploymentMode?: DeploymentMode | undefined;
    EncryptionOptions?: (EncryptionOptions & {
        UseAwsOwnedKey: boolean;
    }) | undefined;
    EngineType?: EngineType | undefined;
    EngineVersion?: string | undefined;
    HostInstanceType?: string | undefined;
    LdapServerMetadata?: (LdapServerMetadataOutput & {
        Hosts: __listOf__string;
        RoleBase: string;
        RoleSearchMatching: string;
        ServiceAccountUsername: string;
        UserBase: string;
        UserSearchMatching: string;
    }) | undefined;
    Logs?: (LogsSummary & {
        General: boolean;
        GeneralLogGroup: string;
    }) | undefined;
    MaintenanceWindowStartTime?: (WeeklyStartTime & {
        DayOfWeek: DayOfWeek;
        TimeOfDay: string;
    }) | undefined;
    PendingAuthenticationStrategy?: AuthenticationStrategy | undefined;
    PendingEngineVersion?: string | undefined;
    PendingHostInstanceType?: string | undefined;
    PendingLdapServerMetadata?: (LdapServerMetadataOutput & {
        Hosts: __listOf__string;
        RoleBase: string;
        RoleSearchMatching: string;
        ServiceAccountUsername: string;
        UserBase: string;
        UserSearchMatching: string;
    }) | undefined;
    PendingSecurityGroups?: string[] | undefined;
    PendingStorageSize?: number | undefined;
    PubliclyAccessible?: boolean | undefined;
    SecurityGroups?: string[] | undefined;
    StorageSize?: number | undefined;
    StorageType?: BrokerStorageType | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Users?: (UserSummary & {
        Username: string;
    })[] | undefined;
    DataReplicationMetadata?: (DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    }) | undefined;
    DataReplicationMode?: DataReplicationMode | undefined;
    PendingDataReplicationMetadata?: (DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    }) | undefined;
    PendingDataReplicationMode?: DataReplicationMode | undefined;
}
export type MaxResults = number;
export interface DescribeBrokerEngineTypesRequest {
    EngineType?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface EngineVersion {
    Name?: string | undefined;
}
export type __listOfEngineVersion = EngineVersion[];
export interface BrokerEngineType {
    EngineType?: EngineType | undefined;
    EngineVersions?: EngineVersion[] | undefined;
}
export type __listOfBrokerEngineType = BrokerEngineType[];
export type __integerMin5Max100 = number;
export interface DescribeBrokerEngineTypesResponse {
    BrokerEngineTypes?: BrokerEngineType[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeBrokerInstanceOptionsRequest {
    EngineType?: string | undefined;
    HostInstanceType?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    StorageType?: string | undefined;
}
export interface AvailabilityZone {
    Name?: string | undefined;
}
export type __listOfAvailabilityZone = AvailabilityZone[];
export type __listOfDeploymentMode = DeploymentMode[];
export interface BrokerInstanceOption {
    AvailabilityZones?: AvailabilityZone[] | undefined;
    EngineType?: EngineType | undefined;
    HostInstanceType?: string | undefined;
    StorageType?: BrokerStorageType | undefined;
    SupportedDeploymentModes?: DeploymentMode[] | undefined;
    SupportedEngineVersions?: string[] | undefined;
}
export type __listOfBrokerInstanceOption = BrokerInstanceOption[];
export interface DescribeBrokerInstanceOptionsResponse {
    BrokerInstanceOptions?: BrokerInstanceOption[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeConfigurationRequest {
    ConfigurationId: string;
}
export interface DescribeConfigurationResponse {
    Arn?: string | undefined;
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    Created?: Date | undefined;
    Description?: string | undefined;
    EngineType?: EngineType | undefined;
    EngineVersion?: string | undefined;
    Id?: string | undefined;
    LatestRevision?: (ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    }) | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeConfigurationRevisionRequest {
    ConfigurationId: string;
    ConfigurationRevision: string;
}
export interface DescribeConfigurationRevisionResponse {
    ConfigurationId?: string | undefined;
    Created?: Date | undefined;
    Data?: string | undefined;
    Description?: string | undefined;
}
export interface DescribeSharedResourcesRequest {
    BrokerId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SharedResourceErrorCode = "QUOTA_EXCEEDED" | "SHARE_NOT_FOUND" | "INVITE_FAILED" | "SETUP_INCOMPLETE" | "INTERNAL_ERROR" | "AZ_MISMATCH" | "RESOURCE_CONFIGURATION_NOT_FOUND" | (string & {});
export interface SharedResourceError {
    Code?: SharedResourceErrorCode | undefined;
    Message?: string | undefined;
}
export type SharedResourceStatus = "AVAILABLE" | "SETUP_IN_PROGRESS" | "DELETION_IN_PROGRESS" | "PENDING_CREATE" | "PENDING_DELETE" | "ERROR" | (string & {});
export type SharedResourceType = "RESOURCE_SHARE" | "RESOURCE" | (string & {});
export interface SharedResource {
    DnsNames?: string[] | undefined;
    Error?: SharedResourceError | undefined;
    ResourceArn?: string | undefined;
    ResourceShareArns?: string[] | undefined;
    Status?: SharedResourceStatus | undefined;
    Type?: SharedResourceType | undefined;
}
export type __listOfSharedResource = SharedResource[];
export interface DescribeSharedResourcesResponse {
    NextToken?: string | undefined;
    SharedResources?: (SharedResource & {
        ResourceArn: string;
        Status: SharedResourceStatus;
        Type: SharedResourceType;
        Error: SharedResourceError & {
            Code: SharedResourceErrorCode;
            Message: string;
        };
    })[] | undefined;
}
export interface DescribeUserRequest {
    BrokerId: string;
    Username: string;
}
export interface UserPendingChanges {
    ConsoleAccess?: boolean | undefined;
    Groups?: string[] | undefined;
    PendingChange?: ChangeType | undefined;
}
export interface DescribeUserResponse {
    BrokerId?: string | undefined;
    ConsoleAccess?: boolean | undefined;
    Groups?: string[] | undefined;
    Pending?: (UserPendingChanges & {
        PendingChange: ChangeType;
    }) | undefined;
    Username?: string | undefined;
    ReplicationUser?: boolean | undefined;
}
export interface ListBrokersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface BrokerSummary {
    BrokerArn?: string | undefined;
    BrokerId?: string | undefined;
    BrokerName?: string | undefined;
    BrokerState?: BrokerState | undefined;
    Created?: Date | undefined;
    DeploymentMode?: DeploymentMode | undefined;
    EngineType?: EngineType | undefined;
    HostInstanceType?: string | undefined;
}
export type __listOfBrokerSummary = BrokerSummary[];
export interface ListBrokersResponse {
    BrokerSummaries?: (BrokerSummary & {
        DeploymentMode: DeploymentMode;
        EngineType: EngineType;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConfigurationRevisionsRequest {
    ConfigurationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type __listOfConfigurationRevision = ConfigurationRevision[];
export interface ListConfigurationRevisionsResponse {
    ConfigurationId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Revisions?: (ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    })[] | undefined;
}
export interface ListConfigurationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Configuration {
    Arn?: string | undefined;
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    Created?: Date | undefined;
    Description?: string | undefined;
    EngineType?: EngineType | undefined;
    EngineVersion?: string | undefined;
    Id?: string | undefined;
    LatestRevision?: ConfigurationRevision | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfConfiguration = Configuration[];
export interface ListConfigurationsResponse {
    Configurations?: (Configuration & {
        Arn: string;
        AuthenticationStrategy: AuthenticationStrategy;
        Created: __timestampIso8601;
        Description: string;
        EngineType: EngineType;
        EngineVersion: string;
        Id: string;
        LatestRevision: ConfigurationRevision & {
            Created: __timestampIso8601;
            Revision: number;
        };
        Name: string;
    })[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsRequest {
    ResourceArn: string;
}
export interface ListTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListUsersRequest {
    BrokerId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListUsersResponse {
    BrokerId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Users?: (UserSummary & {
        Username: string;
    })[] | undefined;
}
export type PromoteMode = "SWITCHOVER" | "FAILOVER" | (string & {});
export interface PromoteRequest {
    BrokerId: string;
    Mode?: PromoteMode | undefined;
}
export interface PromoteResponse {
    BrokerId?: string | undefined;
}
export interface RebootBrokerRequest {
    BrokerId: string;
}
export interface RebootBrokerResponse {
}
export interface UpdateBrokerRequest {
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    BrokerId: string;
    Configuration?: ConfigurationId | undefined;
    EngineVersion?: string | undefined;
    HostInstanceType?: string | undefined;
    LdapServerMetadata?: LdapServerMetadataInput | undefined;
    Logs?: Logs | undefined;
    MaintenanceWindowStartTime?: WeeklyStartTime | undefined;
    ResourceShareArns?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    StorageSize?: number | undefined;
    DataReplicationMode?: DataReplicationMode | undefined;
}
export interface UpdateBrokerResponse {
    AuthenticationStrategy?: AuthenticationStrategy | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    BrokerId?: string | undefined;
    Configuration?: (ConfigurationId & {
        Id: string;
    }) | undefined;
    EngineVersion?: string | undefined;
    HostInstanceType?: string | undefined;
    LdapServerMetadata?: (LdapServerMetadataOutput & {
        Hosts: __listOf__string;
        RoleBase: string;
        RoleSearchMatching: string;
        ServiceAccountUsername: string;
        UserBase: string;
        UserSearchMatching: string;
    }) | undefined;
    Logs?: Logs | undefined;
    MaintenanceWindowStartTime?: (WeeklyStartTime & {
        DayOfWeek: DayOfWeek;
        TimeOfDay: string;
    }) | undefined;
    ResourceShareArns?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    DataReplicationMetadata?: (DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    }) | undefined;
    DataReplicationMode?: DataReplicationMode | undefined;
    PendingDataReplicationMetadata?: (DataReplicationMetadataOutput & {
        DataReplicationRole: string;
        DataReplicationCounterpart: DataReplicationCounterpart & {
            BrokerId: string;
            Region: string;
        };
    }) | undefined;
    PendingDataReplicationMode?: DataReplicationMode | undefined;
    StorageSize?: number | undefined;
}
export interface UpdateConfigurationRequest {
    ConfigurationId: string;
    Data?: string | undefined;
    Description?: string | undefined;
}
export type SanitizationWarningReason = "DISALLOWED_ELEMENT_REMOVED" | "DISALLOWED_ATTRIBUTE_REMOVED" | "INVALID_ATTRIBUTE_VALUE_REMOVED" | (string & {});
export interface SanitizationWarning {
    AttributeName?: string | undefined;
    ElementName?: string | undefined;
    Reason?: SanitizationWarningReason | undefined;
}
export type __listOfSanitizationWarning = SanitizationWarning[];
export interface UpdateConfigurationResponse {
    Arn?: string | undefined;
    Created?: Date | undefined;
    Id?: string | undefined;
    LatestRevision?: (ConfigurationRevision & {
        Created: __timestampIso8601;
        Revision: number;
    }) | undefined;
    Name?: string | undefined;
    Warnings?: (SanitizationWarning & {
        Reason: SanitizationWarningReason;
    })[] | undefined;
}
export interface UpdateUserRequest {
    BrokerId: string;
    ConsoleAccess?: boolean | undefined;
    Groups?: string[] | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Username: string;
    ReplicationUser?: boolean | undefined;
}
export interface UpdateUserResponse {
}
export interface ResourceShareError {
    ErrorCode?: string | undefined;
    ResourceShareArn?: string | undefined;
    Status?: string | undefined;
}
export type __listOfResourceShareError = ResourceShareError[];
export type CreateBrokerError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | UnauthorizedException | CommonErrors;
/**
 * Creates a broker. Note: This API is asynchronous.
 *
 * To create a broker, you must either use the AmazonMQFullAccess IAM policy or include the following EC2 permissions in your IAM policy.
 *
 * - ec2:CreateNetworkInterface
 *
 * This permission is required to allow Amazon MQ to create an elastic network interface (ENI) on behalf of your account.
 *
 * - ec2:CreateNetworkInterfacePermission
 *
 * This permission is required to attach the ENI to the broker instance.
 *
 * - ec2:DeleteNetworkInterface
 *
 * - ec2:DeleteNetworkInterfacePermission
 *
 * - ec2:DetachNetworkInterface
 *
 * - ec2:DescribeInternetGateways
 *
 * - ec2:DescribeNetworkInterfaces
 *
 * - ec2:DescribeNetworkInterfacePermissions
 *
 * - ec2:DescribeRouteTables
 *
 * - ec2:DescribeSecurityGroups
 *
 * - ec2:DescribeSubnets
 *
 * - ec2:DescribeVpcs
 *
 * For more information, see Create an IAM User and Get Your Amazon Web Services Credentials and Never Modify or Delete the Amazon MQ Elastic Network Interface in the *Amazon MQ Developer Guide*.
 */
export declare const createBroker: API.OperationMethod<CreateBrokerRequest & RegionInput, CreateBrokerResponse, CreateBrokerError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Creates a new configuration for the specified configuration name. Amazon MQ uses the default configuration (the engine type and version).
 */
export declare const createConfiguration: API.OperationMethod<CreateConfigurationRequest & RegionInput, CreateConfigurationResponse, CreateConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Add a tag to a resource.
 */
export declare const createTags: API.OperationMethod<CreateTagsRequest & RegionInput, CreateTagsResponse, CreateTagsError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Creates an ActiveMQ user.
 *
 * Do not add personally identifiable information (PII) or other confidential or sensitive information in broker usernames. Broker usernames are accessible to other Amazon Web Services services, including CloudWatch Logs. Broker usernames are not intended to be used for private or sensitive data.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes a broker. Note: This API is asynchronous.
 */
export declare const deleteBroker: API.OperationMethod<DeleteBrokerRequest & RegionInput, DeleteBrokerResponse, DeleteBrokerError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes the specified configuration.
 */
export declare const deleteConfiguration: API.OperationMethod<DeleteConfigurationRequest & RegionInput, DeleteConfigurationResponse, DeleteConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes a tag from a resource.
 */
export declare const deleteTags: API.OperationMethod<DeleteTagsRequest & RegionInput, DeleteTagsResponse, DeleteTagsError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Deletes an ActiveMQ user.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns information about the specified broker.
 */
export declare const describeBroker: API.OperationMethod<DescribeBrokerRequest & RegionInput, DescribeBrokerResponse, DescribeBrokerError, Credentials | HttpClient.HttpClient>;
export type DescribeBrokerEngineTypesError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Describe available engine types and versions.
 */
export declare const describeBrokerEngineTypes: API.OperationMethod<DescribeBrokerEngineTypesRequest & RegionInput, DescribeBrokerEngineTypesResponse, DescribeBrokerEngineTypesError, Credentials | HttpClient.HttpClient>;
export type DescribeBrokerInstanceOptionsError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Describe available broker instance options.
 */
export declare const describeBrokerInstanceOptions: API.OperationMethod<DescribeBrokerInstanceOptionsRequest & RegionInput, DescribeBrokerInstanceOptionsResponse, DescribeBrokerInstanceOptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns information about the specified configuration.
 */
export declare const describeConfiguration: API.OperationMethod<DescribeConfigurationRequest & RegionInput, DescribeConfigurationResponse, DescribeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeConfigurationRevisionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns the specified configuration revision for the specified configuration.
 */
export declare const describeConfigurationRevision: API.OperationMethod<DescribeConfigurationRevisionRequest & RegionInput, DescribeConfigurationRevisionResponse, DescribeConfigurationRevisionError, Credentials | HttpClient.HttpClient>;
export type DescribeSharedResourcesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns the resources shared to a broker.
 */
export declare const describeSharedResources: API.PaginatedOperationMethod<DescribeSharedResourcesRequest & RegionInput, DescribeSharedResourcesResponse, DescribeSharedResourcesError, Credentials | HttpClient.HttpClient, SharedResource>;
export type DescribeUserError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns information about an ActiveMQ user.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest & RegionInput, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type ListBrokersError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of all brokers.
 */
export declare const listBrokers: API.PaginatedOperationMethod<ListBrokersRequest & RegionInput, ListBrokersResponse, ListBrokersError, Credentials | HttpClient.HttpClient, BrokerSummary>;
export type ListConfigurationRevisionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of all revisions for the specified configuration.
 */
export declare const listConfigurationRevisions: API.OperationMethod<ListConfigurationRevisionsRequest & RegionInput, ListConfigurationRevisionsResponse, ListConfigurationRevisionsError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationsError = BadRequestException | ForbiddenException | InternalServerErrorException | CommonErrors;
/**
 * Returns a list of all configurations.
 */
export declare const listConfigurations: API.OperationMethod<ListConfigurationsRequest & RegionInput, ListConfigurationsResponse, ListConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Lists tags for a resource.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest & RegionInput, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListUsersError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Returns a list of all ActiveMQ users.
 */
export declare const listUsers: API.OperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient>;
export type PromoteError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Promotes a data replication replica broker to the primary broker role.
 */
export declare const promote: API.OperationMethod<PromoteRequest & RegionInput, PromoteResponse, PromoteError, Credentials | HttpClient.HttpClient>;
export type RebootBrokerError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Reboots a broker. Note: This API is asynchronous.
 */
export declare const rebootBroker: API.OperationMethod<RebootBrokerRequest & RegionInput, RebootBrokerResponse, RebootBrokerError, Credentials | HttpClient.HttpClient>;
export type UpdateBrokerError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Adds a pending configuration change to a broker.
 */
export declare const updateBroker: API.OperationMethod<UpdateBrokerRequest & RegionInput, UpdateBrokerResponse, UpdateBrokerError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Updates the specified configuration.
 */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest & RegionInput, UpdateConfigurationResponse, UpdateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Updates the information for an ActiveMQ user.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=mq.d.ts.map