import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type { Module, Node } from "./Value.ts";
/** What the prover is told not to read. */
export interface Reading {
    /**
     * Pure functions the prover does not read. A call gives a value it does
     * not look inside, and the same value for the same arguments. The prover
     * does this by itself for an exported function whose body it cannot read;
     * name one here that it would read, or that it will not take to be pure.
     */
    readonly opaque?: ReadonlyArray<(...args: ReadonlyArray<never>) => unknown> | undefined;
}
/** A function the prover does not read, as the real code calls it. */
export interface OpaqueFunction {
    readonly name: string;
    readonly call: (...args: ReadonlyArray<unknown>) => unknown;
}
declare const LoadError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "LoadError";
} & Readonly<A>;
/** A source file could not be read, parsed or loaded. */
export declare class LoadError extends LoadError_base<{
    readonly file: string;
    readonly message: string;
}> {
}
export interface Loader {
    /** A source file, parsed and loaded. Each file is read once. */
    readonly load: (file: string) => Effect.Effect<Module, LoadError>;
    /**
     * Name the domain classes the caller holds: a model or an aggregate, and
     * every class it lists. A test runner may load a source file a second time,
     * as classes that are not the caller's. Where a loaded file exports one of
     * those, the loader gives the caller's class in its place.
     */
    readonly adopt: (root: unknown) => void;
    /**
     * An expression written as text, as a node of a file's syntax: a rule kept
     * from an earlier version of the file, to be read where the file's own
     * names mean what they mean now.
     */
    readonly parse: (file: string, text: string) => Effect.Effect<Node, LoadError>;
    /**
     * Whether a value is a function the caller named as opaque. A test runner
     * may load a file a second time, as functions that are not the caller's:
     * one a file exports under the name of a function the caller gave stands
     * for it.
     */
    readonly opaque: (value: unknown, exported?: string) => OpaqueFunction | undefined;
    /**
     * The functions the proof takes to be pure, by name: the ones the caller
     * named as opaque, and each one the prover met and could not read.
     */
    readonly opaques: () => ReadonlyArray<string>;
    /** Record a function the prover could not read, and took to be pure. */
    readonly assume: (name: string) => void;
    /**
     * The file a package specifier names, from the file that imports it:
     * `undefined` when the package is not found.
     */
    readonly resolve: (from: Module, specifier: string) => Effect.Effect<string | undefined>;
    /**
     * What a package gives the file that imports it, as the runtime loads it:
     * `undefined` when it is not found or does not load. Only a package of
     * Node's is loaded, unless the caller named an opaque function.
     */
    readonly runtime: (from: Module, specifier: string) => Effect.Effect<Readonly<Record<string, unknown>> | undefined>;
}
/**
 * Reads TypeScript the way the prover needs it: the syntax tree for function
 * bodies, and the loaded module for the classes, schemas and constants the
 * code refers to.
 */
export declare const loader: (reading?: Reading) => Effect.Effect<Loader, LoadError, FileSystem.FileSystem | Path.Path>;
export {};
//# sourceMappingURL=Source.d.ts.map