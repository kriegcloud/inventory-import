import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const GoneException_base: S.TaggedErrorClass<"GoneException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GoneException extends /*@__PURE__*/ GoneException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly Code: any;
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly Code: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type __stringMin0Max256 = string;
export type __stringMin20Max1600 = string;
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateDiscovererRequest {
    Description?: string | undefined;
    SourceArn?: string | undefined;
    CrossAccount?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DiscovererState = "STARTED" | "STOPPED" | (string & {});
export interface CreateDiscovererResponse {
    Description?: string | undefined;
    DiscovererArn?: string | undefined;
    DiscovererId?: string | undefined;
    SourceArn?: string | undefined;
    State?: DiscovererState | undefined;
    CrossAccount?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateRegistryRequest {
    Description?: string | undefined;
    RegistryName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateRegistryResponse {
    Description?: string | undefined;
    RegistryArn?: string | undefined;
    RegistryName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin1Max100000 = string;
export type Type = "OpenApi3" | "JSONSchemaDraft4" | (string & {});
export interface CreateSchemaRequest {
    Content?: string | undefined;
    Description?: string | undefined;
    RegistryName: string;
    SchemaName: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: Type | undefined;
}
export type __timestampIso8601 = Date;
export interface CreateSchemaResponse {
    Description?: string | undefined;
    LastModified?: Date | undefined;
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaVersion?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: string | undefined;
    VersionCreatedDate?: Date | undefined;
}
export interface DeleteDiscovererRequest {
    DiscovererId: string;
}
export interface DeleteDiscovererResponse {
}
export interface DeleteRegistryRequest {
    RegistryName: string;
}
export interface DeleteRegistryResponse {
}
export interface DeleteResourcePolicyRequest {
    RegistryName?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteSchemaRequest {
    RegistryName: string;
    SchemaName: string;
}
export interface DeleteSchemaResponse {
}
export interface DeleteSchemaVersionRequest {
    RegistryName: string;
    SchemaName: string;
    SchemaVersion: string;
}
export interface DeleteSchemaVersionResponse {
}
export interface DescribeCodeBindingRequest {
    Language: string;
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string | undefined;
}
export type CodeGenerationStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | (string & {});
export interface DescribeCodeBindingResponse {
    CreationDate?: Date | undefined;
    LastModified?: Date | undefined;
    SchemaVersion?: string | undefined;
    Status?: CodeGenerationStatus | undefined;
}
export interface DescribeDiscovererRequest {
    DiscovererId: string;
}
export interface DescribeDiscovererResponse {
    Description?: string | undefined;
    DiscovererArn?: string | undefined;
    DiscovererId?: string | undefined;
    SourceArn?: string | undefined;
    State?: DiscovererState | undefined;
    CrossAccount?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeRegistryRequest {
    RegistryName: string;
}
export interface DescribeRegistryResponse {
    Description?: string | undefined;
    RegistryArn?: string | undefined;
    RegistryName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeSchemaRequest {
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string | undefined;
}
export interface DescribeSchemaResponse {
    Content?: string | undefined;
    Description?: string | undefined;
    LastModified?: Date | undefined;
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaVersion?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: string | undefined;
    VersionCreatedDate?: Date | undefined;
}
export interface ExportSchemaRequest {
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string | undefined;
    Type?: string | undefined;
}
export interface ExportSchemaResponse {
    Content?: string | undefined;
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaVersion?: string | undefined;
    Type?: string | undefined;
}
export interface GetCodeBindingSourceRequest {
    Language: string;
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string | undefined;
}
export interface GetCodeBindingSourceResponse {
    Body?: T.StreamingOutputBody | undefined;
}
export type GetDiscoveredSchemaVersionItemInput = string;
export type __listOfGetDiscoveredSchemaVersionItemInput = string[];
export interface GetDiscoveredSchemaRequest {
    Events?: string[] | undefined;
    Type?: Type | undefined;
}
export interface GetDiscoveredSchemaResponse {
    Content?: string | undefined;
}
export interface GetResourcePolicyRequest {
    RegistryName?: string | undefined;
}
export type SynthesizedJson__string = string;
export interface GetResourcePolicyResponse {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface ListDiscoverersRequest {
    DiscovererIdPrefix?: string | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
    SourceArnPrefix?: string | undefined;
}
export interface DiscovererSummary {
    DiscovererArn?: string | undefined;
    DiscovererId?: string | undefined;
    SourceArn?: string | undefined;
    State?: DiscovererState | undefined;
    CrossAccount?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfDiscovererSummary = DiscovererSummary[];
export interface ListDiscoverersResponse {
    Discoverers?: DiscovererSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRegistriesRequest {
    Limit?: number | undefined;
    NextToken?: string | undefined;
    RegistryNamePrefix?: string | undefined;
    Scope?: string | undefined;
}
export interface RegistrySummary {
    RegistryArn?: string | undefined;
    RegistryName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfRegistrySummary = RegistrySummary[];
export interface ListRegistriesResponse {
    NextToken?: string | undefined;
    Registries?: RegistrySummary[] | undefined;
}
export interface ListSchemasRequest {
    Limit?: number | undefined;
    NextToken?: string | undefined;
    RegistryName: string;
    SchemaNamePrefix?: string | undefined;
}
export interface SchemaSummary {
    LastModified?: Date | undefined;
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    VersionCount?: number | undefined;
}
export type __listOfSchemaSummary = SchemaSummary[];
export interface ListSchemasResponse {
    NextToken?: string | undefined;
    Schemas?: SchemaSummary[] | undefined;
}
export interface ListSchemaVersionsRequest {
    Limit?: number | undefined;
    NextToken?: string | undefined;
    RegistryName: string;
    SchemaName: string;
}
export interface SchemaVersionSummary {
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaVersion?: string | undefined;
    Type?: Type | undefined;
}
export type __listOfSchemaVersionSummary = SchemaVersionSummary[];
export interface ListSchemaVersionsResponse {
    NextToken?: string | undefined;
    SchemaVersions?: SchemaVersionSummary[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutCodeBindingRequest {
    Language: string;
    RegistryName: string;
    SchemaName: string;
    SchemaVersion?: string | undefined;
}
export interface PutCodeBindingResponse {
    CreationDate?: Date | undefined;
    LastModified?: Date | undefined;
    SchemaVersion?: string | undefined;
    Status?: CodeGenerationStatus | undefined;
}
export interface PutResourcePolicyRequest {
    Policy?: string | undefined;
    RegistryName?: string | undefined;
    RevisionId?: string | undefined;
}
export interface PutResourcePolicyResponse {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface SearchSchemasRequest {
    Keywords?: string | undefined;
    Limit?: number | undefined;
    NextToken?: string | undefined;
    RegistryName: string;
}
export interface SearchSchemaVersionSummary {
    CreatedDate?: Date | undefined;
    SchemaVersion?: string | undefined;
    Type?: Type | undefined;
}
export type __listOfSearchSchemaVersionSummary = SearchSchemaVersionSummary[];
export interface SearchSchemaSummary {
    RegistryName?: string | undefined;
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaVersions?: SearchSchemaVersionSummary[] | undefined;
}
export type __listOfSearchSchemaSummary = SearchSchemaSummary[];
export interface SearchSchemasResponse {
    NextToken?: string | undefined;
    Schemas?: SearchSchemaSummary[] | undefined;
}
export interface StartDiscovererRequest {
    DiscovererId: string;
}
export interface StartDiscovererResponse {
    DiscovererId?: string | undefined;
    State?: DiscovererState | undefined;
}
export interface StopDiscovererRequest {
    DiscovererId: string;
}
export interface StopDiscovererResponse {
    DiscovererId?: string | undefined;
    State?: DiscovererState | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export type __listOf__string = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateDiscovererRequest {
    Description?: string | undefined;
    DiscovererId: string;
    CrossAccount?: boolean | undefined;
}
export interface UpdateDiscovererResponse {
    Description?: string | undefined;
    DiscovererArn?: string | undefined;
    DiscovererId?: string | undefined;
    SourceArn?: string | undefined;
    State?: DiscovererState | undefined;
    CrossAccount?: boolean | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateRegistryRequest {
    Description?: string | undefined;
    RegistryName: string;
}
export interface UpdateRegistryResponse {
    Description?: string | undefined;
    RegistryArn?: string | undefined;
    RegistryName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin0Max36 = string;
export interface UpdateSchemaRequest {
    ClientTokenId?: string | undefined;
    Content?: string | undefined;
    Description?: string | undefined;
    RegistryName: string;
    SchemaName: string;
    Type?: Type | undefined;
}
export interface UpdateSchemaResponse {
    Description?: string | undefined;
    LastModified?: Date | undefined;
    SchemaArn?: string | undefined;
    SchemaName?: string | undefined;
    SchemaVersion?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: string | undefined;
    VersionCreatedDate?: Date | undefined;
}
export type CreateDiscovererError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Creates a discoverer.
 */
export declare const createDiscoverer: API.OperationMethod<CreateDiscovererRequest & RegionInput, CreateDiscovererResponse, CreateDiscovererError, Credentials | HttpClient.HttpClient>;
export type CreateRegistryError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Creates a registry.
 */
export declare const createRegistry: API.OperationMethod<CreateRegistryRequest & RegionInput, CreateRegistryResponse, CreateRegistryError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a schema definition.
 *
 * Inactive schemas will be deleted after two years.
 */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest & RegionInput, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Deletes a discoverer.
 */
export declare const deleteDiscoverer: API.OperationMethod<DeleteDiscovererRequest & RegionInput, DeleteDiscovererResponse, DeleteDiscovererError, Credentials | HttpClient.HttpClient>;
export type DeleteRegistryError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Deletes a Registry.
 */
export declare const deleteRegistry: API.OperationMethod<DeleteRegistryRequest & RegionInput, DeleteRegistryResponse, DeleteRegistryError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Delete the resource-based policy attached to the specified registry.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Delete a schema definition.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest & RegionInput, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaVersionError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Delete the schema version definition
 */
export declare const deleteSchemaVersion: API.OperationMethod<DeleteSchemaVersionRequest & RegionInput, DeleteSchemaVersionResponse, DeleteSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeCodeBindingError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Describe the code binding URI.
 */
export declare const describeCodeBinding: API.OperationMethod<DescribeCodeBindingRequest & RegionInput, DescribeCodeBindingResponse, DescribeCodeBindingError, Credentials | HttpClient.HttpClient>;
export type DescribeDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Describes the discoverer.
 */
export declare const describeDiscoverer: API.OperationMethod<DescribeDiscovererRequest & RegionInput, DescribeDiscovererResponse, DescribeDiscovererError, Credentials | HttpClient.HttpClient>;
export type DescribeRegistryError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Describes the registry.
 */
export declare const describeRegistry: API.OperationMethod<DescribeRegistryRequest & RegionInput, DescribeRegistryResponse, DescribeRegistryError, Credentials | HttpClient.HttpClient>;
export type DescribeSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Retrieve the schema definition.
 */
export declare const describeSchema: API.OperationMethod<DescribeSchemaRequest & RegionInput, DescribeSchemaResponse, DescribeSchemaError, Credentials | HttpClient.HttpClient>;
export type ExportSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 *
 */
export declare const exportSchema: API.OperationMethod<ExportSchemaRequest & RegionInput, ExportSchemaResponse, ExportSchemaError, Credentials | HttpClient.HttpClient>;
export type GetCodeBindingSourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnauthorizedException | CommonErrors;
/**
 * Get the code binding source URI.
 */
export declare const getCodeBindingSource: API.OperationMethod<GetCodeBindingSourceRequest & RegionInput, GetCodeBindingSourceResponse, GetCodeBindingSourceError, Credentials | HttpClient.HttpClient>;
export type GetDiscoveredSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Get the discovered schema that was generated based on sampled events.
 */
export declare const getDiscoveredSchema: API.OperationMethod<GetDiscoveredSchemaRequest & RegionInput, GetDiscoveredSchemaResponse, GetDiscoveredSchemaError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a given registry.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListDiscoverersError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * List the discoverers.
 */
export declare const listDiscoverers: API.PaginatedOperationMethod<ListDiscoverersRequest & RegionInput, ListDiscoverersResponse, ListDiscoverersError, Credentials | HttpClient.HttpClient, DiscovererSummary>;
export type ListRegistriesError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * List the registries.
 */
export declare const listRegistries: API.PaginatedOperationMethod<ListRegistriesRequest & RegionInput, ListRegistriesResponse, ListRegistriesError, Credentials | HttpClient.HttpClient, RegistrySummary>;
export type ListSchemasError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * List the schemas.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest & RegionInput, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, SchemaSummary>;
export type ListSchemaVersionsError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Provides a list of the schema versions and related information.
 */
export declare const listSchemaVersions: API.PaginatedOperationMethod<ListSchemaVersionsRequest & RegionInput, ListSchemaVersionsResponse, ListSchemaVersionsError, Credentials | HttpClient.HttpClient, SchemaVersionSummary>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Get tags for resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutCodeBindingError = BadRequestException | ForbiddenException | GoneException | InternalServerErrorException | NotFoundException | TooManyRequestsException | UnauthorizedException | ConflictException | CommonErrors;
/**
 * Put code binding URI
 */
export declare const putCodeBinding: API.OperationMethod<PutCodeBindingRequest & RegionInput, PutCodeBindingResponse, PutCodeBindingError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | PreconditionFailedException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * The name of the policy.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type SearchSchemasError = BadRequestException | ForbiddenException | InternalServerErrorException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Search the schemas
 */
export declare const searchSchemas: API.PaginatedOperationMethod<SearchSchemasRequest & RegionInput, SearchSchemasResponse, SearchSchemasError, Credentials | HttpClient.HttpClient, SearchSchemaSummary>;
export type StartDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Starts the discoverer
 */
export declare const startDiscoverer: API.OperationMethod<StartDiscovererRequest & RegionInput, StartDiscovererResponse, StartDiscovererError, Credentials | HttpClient.HttpClient>;
export type StopDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Stops the discoverer
 */
export declare const stopDiscoverer: API.OperationMethod<StopDiscovererRequest & RegionInput, StopDiscovererResponse, StopDiscovererError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Add tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDiscovererError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates the discoverer
 */
export declare const updateDiscoverer: API.OperationMethod<UpdateDiscovererRequest & RegionInput, UpdateDiscovererResponse, UpdateDiscovererError, Credentials | HttpClient.HttpClient>;
export type UpdateRegistryError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | UnauthorizedException | CommonErrors;
/**
 * Updates a registry.
 */
export declare const updateRegistry: API.OperationMethod<UpdateRegistryRequest & RegionInput, UpdateRegistryResponse, UpdateRegistryError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Updates the schema definition
 *
 * Inactive schemas will be deleted after two years.
 */
export declare const updateSchema: API.OperationMethod<UpdateSchemaRequest & RegionInput, UpdateSchemaResponse, UpdateSchemaError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=schemas.d.ts.map