import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DirectoryUnavailableException_base: S.TaggedErrorClass<"DirectoryUnavailableException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DirectoryUnavailableException extends /*@__PURE__*/ DirectoryUnavailableException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DirectoryId = string;
export type GroupName = string;
export type MemberName = string;
export type Realm = string;
export type ClientToken = string;
export interface AddGroupMemberRequest {
    DirectoryId: string;
    GroupName: string;
    MemberName: string;
    MemberRealm?: string | undefined;
    ClientToken?: string | undefined;
}
export interface AddGroupMemberResult {
}
export type GroupType = "Distribution" | "Security" | (string & {});
export type GroupScope = "DomainLocal" | "Global" | "Universal" | "BuiltinLocal" | (string & {});
export type LdapDisplayName = string;
export type StringAttributeValue = string | redacted.Redacted<string>;
export type NumberAttributeValue = number;
export type BooleanAttributeValue = boolean;
export type StringSetAttributeValue = (string | redacted.Redacted<string>)[];
export type AttributeValue = {
    S: string | redacted.Redacted<string>;
    N?: undefined;
    BOOL?: undefined;
    SS?: undefined;
} | {
    S?: undefined;
    N: number;
    BOOL?: undefined;
    SS?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    BOOL: boolean;
    SS?: undefined;
} | {
    S?: undefined;
    N?: undefined;
    BOOL?: undefined;
    SS: (string | redacted.Redacted<string>)[];
};
export type Attributes = {
    [key: string]: AttributeValue | undefined;
};
export interface CreateGroupRequest {
    DirectoryId: string;
    SAMAccountName: string;
    GroupType?: GroupType | undefined;
    GroupScope?: GroupScope | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export type SID = string;
export interface CreateGroupResult {
    DirectoryId?: string | undefined;
    SAMAccountName?: string | undefined;
    SID?: string | undefined;
}
export type UserName = string;
export type EmailAddress = string | redacted.Redacted<string>;
export type GivenName = string | redacted.Redacted<string>;
export type Surname = string | redacted.Redacted<string>;
export interface CreateUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface CreateUserResult {
    DirectoryId?: string | undefined;
    SID?: string | undefined;
    SAMAccountName?: string | undefined;
}
export interface DeleteGroupRequest {
    DirectoryId: string;
    SAMAccountName: string;
    ClientToken?: string | undefined;
}
export interface DeleteGroupResult {
}
export interface DeleteUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    ClientToken?: string | undefined;
}
export interface DeleteUserResult {
}
export type LdapDisplayNameList = string[];
export interface DescribeGroupRequest {
    DirectoryId: string;
    Realm?: string | undefined;
    SAMAccountName: string;
    OtherAttributes?: string[] | undefined;
}
export type DistinguishedName = string | redacted.Redacted<string>;
export interface DescribeGroupResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    SID?: string | undefined;
    SAMAccountName?: string | undefined;
    DistinguishedName?: string | redacted.Redacted<string> | undefined;
    GroupType?: GroupType | undefined;
    GroupScope?: GroupScope | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export interface DescribeUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    OtherAttributes?: string[] | undefined;
    Realm?: string | undefined;
}
export type UserPrincipalName = string | redacted.Redacted<string>;
export interface DescribeUserResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    SID?: string | undefined;
    SAMAccountName?: string | undefined;
    DistinguishedName?: string | redacted.Redacted<string> | undefined;
    UserPrincipalName?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    Enabled?: boolean | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export interface DisableUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    ClientToken?: string | undefined;
}
export interface DisableUserResult {
}
export type NextToken = string | redacted.Redacted<string>;
export type MaxResults = number;
export interface ListGroupMembersRequest {
    DirectoryId: string;
    Realm?: string | undefined;
    MemberRealm?: string | undefined;
    SAMAccountName: string;
    NextToken?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
}
export type MemberType = "USER" | "GROUP" | "COMPUTER" | (string & {});
export interface Member {
    SID: string;
    SAMAccountName: string;
    MemberType: MemberType;
}
export type MemberList = Member[];
export interface ListGroupMembersResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    MemberRealm?: string | undefined;
    Members?: Member[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListGroupsRequest {
    DirectoryId: string;
    Realm?: string | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
}
export interface GroupSummary {
    SID: string;
    SAMAccountName: string;
    GroupType: GroupType;
    GroupScope: GroupScope;
}
export type GroupSummaryList = GroupSummary[];
export interface ListGroupsResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    Groups?: GroupSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListGroupsForMemberRequest {
    DirectoryId: string;
    Realm?: string | undefined;
    MemberRealm?: string | undefined;
    SAMAccountName: string;
    NextToken?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
}
export interface ListGroupsForMemberResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    MemberRealm?: string | undefined;
    Groups?: GroupSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListUsersRequest {
    DirectoryId: string;
    Realm?: string | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
}
export interface UserSummary {
    SID: string;
    SAMAccountName: string;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    Enabled: boolean;
}
export type UserSummaryList = UserSummary[];
export interface ListUsersResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    Users?: UserSummary[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface RemoveGroupMemberRequest {
    DirectoryId: string;
    GroupName: string;
    MemberName: string;
    MemberRealm?: string | undefined;
    ClientToken?: string | undefined;
}
export interface RemoveGroupMemberResult {
}
export type SearchString = string | redacted.Redacted<string>;
export interface SearchGroupsRequest {
    DirectoryId: string;
    SearchString: string | redacted.Redacted<string>;
    SearchAttributes: string[];
    Realm?: string | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
}
export interface Group {
    SID?: string | undefined;
    SAMAccountName: string;
    DistinguishedName?: string | redacted.Redacted<string> | undefined;
    GroupType?: GroupType | undefined;
    GroupScope?: GroupScope | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export type GroupList = Group[];
export interface SearchGroupsResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    Groups?: Group[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface SearchUsersRequest {
    DirectoryId: string;
    Realm?: string | undefined;
    SearchString: string | redacted.Redacted<string>;
    SearchAttributes: string[];
    NextToken?: string | redacted.Redacted<string> | undefined;
    MaxResults?: number | undefined;
}
export interface User {
    SID?: string | undefined;
    SAMAccountName: string;
    DistinguishedName?: string | redacted.Redacted<string> | undefined;
    UserPrincipalName?: string | redacted.Redacted<string> | undefined;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    Enabled?: boolean | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
}
export type UserList = User[];
export interface SearchUsersResult {
    DirectoryId?: string | undefined;
    Realm?: string | undefined;
    Users?: User[] | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export type UpdateType = "ADD" | "REPLACE" | "REMOVE" | (string & {});
export interface UpdateGroupRequest {
    DirectoryId: string;
    SAMAccountName: string;
    GroupType?: GroupType | undefined;
    GroupScope?: GroupScope | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    UpdateType?: UpdateType | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateGroupResult {
}
export interface UpdateUserRequest {
    DirectoryId: string;
    SAMAccountName: string;
    EmailAddress?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    Surname?: string | redacted.Redacted<string> | undefined;
    OtherAttributes?: {
        [key: string]: AttributeValue | undefined;
    } | undefined;
    UpdateType?: UpdateType | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateUserResult {
}
export type ExceptionMessage = string;
export type AccessDeniedReason = "IAM_AUTH" | "DIRECTORY_AUTH" | "DATA_DISABLED" | (string & {});
export type DirectoryUnavailableReason = "INVALID_DIRECTORY_STATE" | "DIRECTORY_TIMEOUT" | "DIRECTORY_RESOURCES_EXCEEDED" | "NO_DISK_SPACE" | "TRUST_AUTH_FAILURE" | (string & {});
export type ValidationExceptionReason = "INVALID_REALM" | "INVALID_DIRECTORY_TYPE" | "INVALID_SECONDARY_REGION" | "INVALID_NEXT_TOKEN" | "INVALID_ATTRIBUTE_VALUE" | "INVALID_ATTRIBUTE_NAME" | "INVALID_ATTRIBUTE_FOR_USER" | "INVALID_ATTRIBUTE_FOR_GROUP" | "INVALID_ATTRIBUTE_FOR_SEARCH" | "INVALID_ATTRIBUTE_FOR_MODIFY" | "DUPLICATE_ATTRIBUTE" | "MISSING_ATTRIBUTE" | "ATTRIBUTE_EXISTS" | "LDAP_SIZE_LIMIT_EXCEEDED" | "LDAP_UNSUPPORTED_OPERATION" | (string & {});
export type AddGroupMemberError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds an existing user, group, or computer as a group member.
 */
export declare const addGroupMember: API.OperationMethod<AddGroupMemberRequest & RegionInput, AddGroupMemberResult, AddGroupMemberError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new group.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResult, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new user.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResult, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResult, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a user.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResult, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific group.
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest & RegionInput, DescribeGroupResult, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific user.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest & RegionInput, DescribeUserResult, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type DisableUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deactivates an active user account. For information about how to enable an inactive user
 * account, see ResetUserPassword
 * in the *Directory Service API Reference*.
 */
export declare const disableUser: API.OperationMethod<DisableUserRequest & RegionInput, DisableUserResult, DisableUserError, Credentials | HttpClient.HttpClient>;
export type ListGroupMembersError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns member information for the specified group.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the
 * `ListGroupMembers.NextToken` member contains a token that you pass in the next
 * call to `ListGroupMembers`. This retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listGroupMembers: API.PaginatedOperationMethod<ListGroupMembersRequest & RegionInput, ListGroupMembersResult, ListGroupMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListGroupsError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns group information for the specified directory.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `ListGroups.NextToken`
 * member contains a token that you pass in the next call to `ListGroups`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResult, ListGroupsError, Credentials | HttpClient.HttpClient, GroupSummary>;
export type ListGroupsForMemberError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns group information for the specified member.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the
 * `ListGroupsForMember.NextToken` member contains a token that you pass in the next
 * call to `ListGroupsForMember`. This retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listGroupsForMember: API.PaginatedOperationMethod<ListGroupsForMemberRequest & RegionInput, ListGroupsForMemberResult, ListGroupsForMemberError, Credentials | HttpClient.HttpClient, GroupSummary>;
export type ListUsersError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns user information for the specified directory.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `ListUsers.NextToken`
 * member contains a token that you pass in the next call to `ListUsers`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResult, ListUsersError, Credentials | HttpClient.HttpClient, UserSummary>;
export type RemoveGroupMemberError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a member from a group.
 */
export declare const removeGroupMember: API.OperationMethod<RemoveGroupMemberRequest & RegionInput, RemoveGroupMemberResult, RemoveGroupMemberError, Credentials | HttpClient.HttpClient>;
export type SearchGroupsError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches the specified directory for a group. You can find groups that match the
 * `SearchString` parameter with the value of their attributes included in the
 * `SearchString` parameter.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `SearchGroups.NextToken`
 * member contains a token that you pass in the next call to `SearchGroups`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const searchGroups: API.PaginatedOperationMethod<SearchGroupsRequest & RegionInput, SearchGroupsResult, SearchGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type SearchUsersError = AccessDeniedException | DirectoryUnavailableException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches the specified directory for a user. You can find users that match the
 * `SearchString` parameter with the value of their attributes included in the
 * `SearchString` parameter.
 *
 * This operation supports pagination with the use of the `NextToken` request and
 * response parameters. If more results are available, the `SearchUsers.NextToken`
 * member contains a token that you pass in the next call to `SearchUsers`. This
 * retrieves the next set of items.
 *
 * You can also specify a maximum number of return results with the `MaxResults`
 * parameter.
 */
export declare const searchUsers: API.PaginatedOperationMethod<SearchUsersRequest & RegionInput, SearchUsersResult, SearchUsersError, Credentials | HttpClient.HttpClient, User>;
export type UpdateGroupError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates group information.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResult, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = AccessDeniedException | ConflictException | DirectoryUnavailableException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates user information.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResult, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=directory-service-data.d.ts.map