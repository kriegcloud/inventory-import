import * as DateTime from "effect/DateTime";
import * as Effect from "effect/Effect";
import * as Aggregate from "../../Aggregate.ts";
import type { Interpreter } from "../../Prove/internal/Interpreter.ts";
import * as Paths from "../../Prove/internal/Paths.ts";
import * as Smt from "../../Prove/internal/Smt.ts";
import type { V } from "../../Prove/internal/Value.ts";
import * as Value from "../../Prove/internal/Value.ts";
/** One command of a story, with what the real code did with it. */
export interface Move {
    readonly command: unknown;
    /** What each request context the command read held. */
    readonly context: ReadonlyArray<{
        readonly name: string;
        readonly value: unknown;
        /** The request context's class, to provide the value with. */
        readonly tag: unknown;
    }>;
    readonly now: DateTime.Utc;
    readonly outcome: {
        readonly _tag: "Accepted";
        readonly events: ReadonlyArray<unknown>;
        readonly state: unknown;
    } | {
        readonly _tag: "Rejected";
        readonly rejection: unknown;
    };
}
/** Commands sent one after another to a new instance. */
export type Story = ReadonlyArray<Move>;
/** Something a command can do: record an event, or refuse with a rejection. */
export interface Outcome {
    readonly command: string;
    readonly kind: "records" | "rejects";
    readonly tag: string;
    /** The shortest story found that ends in it. */
    readonly story: Story | undefined;
}
export interface Found {
    /** The command sequences run, one per path through the code. */
    readonly sequences: number;
    /** The states whose invariants were checked. */
    readonly states: number;
    /** Whether the search stopped at its budget before every sequence was run. */
    readonly truncated: boolean;
    /** The most commands in a sequence for which every sequence was run. */
    readonly complete: number;
    readonly invariants: ReadonlyArray<{
        readonly name: string;
        /** An invariant is about a state, a transition about one step. */
        readonly kind: "invariant" | "transition";
        /** The shortest story found that breaks it: no commands when a new instance does. */
        readonly broken: Story | undefined;
        /**
         * Whether no command can break it, whatever state the command meets: it
         * then holds after any number of commands, not only the ones run here.
         */
        readonly proved: boolean;
        /** The states reached in which it was looked at. */
        readonly states: number;
    }>;
    /**
     * The commands no state the invariants allow accepts: they never record an
     * event, so nothing said here is about them.
     */
    readonly dead: ReadonlyArray<string>;
    /**
     * The events the aggregate folds that none of its commands records: a
     * decision records them, and no sequence here has one.
     */
    readonly outside: ReadonlyArray<string>;
    readonly outcomes: ReadonlyArray<Outcome>;
    readonly reached: ReadonlyArray<{
        readonly tag: string;
        readonly story: Story | undefined;
    }>;
    /** Code the explorer could not read: sequences through it were not run. */
    readonly unread: ReadonlyArray<Value.NotTranslated>;
    /** Sequences the solver found that the real code does not follow. */
    readonly disagreements: ReadonlyArray<string>;
    /** Why the solver gave up on a question, and how many times. */
    readonly undecided: ReadonlyArray<{
        readonly reason: string;
        readonly times: number;
    }>;
}
export declare const tagOf: (value: V) => string | undefined;
/** A real value as the interpreter's: the initial state has no unknowns. */
export declare const lift: (value: unknown) => V;
/** The `_tag` of each member of a state schema that is a union of tagged structs. */
export declare const stateTags: (schema: unknown) => ReadonlyArray<string>;
export interface Options {
    /** The most commands in a sequence. */
    readonly depth: number;
    /** The most sequences to run. */
    readonly budget: number;
}
/**
 * Run every sequence of commands on a new instance, up to `depth` commands.
 * A command's fields stay unknown along a whole sequence, so a later command
 * can need something of an earlier one's: the solver picks every value at once.
 */
export declare const search: (solver: Smt.Solver, interpreter: Interpreter, aggregate: Aggregate.Any, definition: Paths.Definition, options: Options) => Effect.Effect<Found, Smt.SolverError, never>;
//# sourceMappingURL=Search.d.ts.map