import { NodeServices } from "@effect/platform-node";
import * as Layer from "effect/Layer";
export declare const services: Layer.Layer<import("../Terminal.ts").Terminals | NodeServices.NodeServices, never, never>;
export declare const httpServer: Layer.Layer<import("../Http.ts").HttpServer, never, never>;
//# sourceMappingURL=ContainerNode.d.ts.map