import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AliasLimitExceededException_base: S.TaggedErrorClass<"AliasLimitExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AliasLimitExceededException extends /*@__PURE__*/ AliasLimitExceededException_base {
}
declare const CallbackTimeoutException_base: S.TaggedErrorClass<"CallbackTimeoutException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CallbackTimeoutException extends /*@__PURE__*/ CallbackTimeoutException_base {
}
declare const CapacityProviderLimitExceededException_base: S.TaggedErrorClass<"CapacityProviderLimitExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CapacityProviderLimitExceededException extends /*@__PURE__*/ CapacityProviderLimitExceededException_base {
}
declare const CapacityProviderOperatorRoleNotAssumable_base: S.TaggedErrorClass<"CapacityProviderOperatorRoleNotAssumable", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class CapacityProviderOperatorRoleNotAssumable extends /*@__PURE__*/ CapacityProviderOperatorRoleNotAssumable_base {
}
declare const CapacityProviderSecurityGroupNotFound_base: S.TaggedErrorClass<"CapacityProviderSecurityGroupNotFound", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class CapacityProviderSecurityGroupNotFound extends /*@__PURE__*/ CapacityProviderSecurityGroupNotFound_base {
}
declare const CapacityProviderSubnetNotFound_base: S.TaggedErrorClass<"CapacityProviderSubnetNotFound", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class CapacityProviderSubnetNotFound extends /*@__PURE__*/ CapacityProviderSubnetNotFound_base {
}
declare const CodeArtifactUserDeletedException_base: S.TaggedErrorClass<"CodeArtifactUserDeletedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CodeArtifactUserDeletedException extends /*@__PURE__*/ CodeArtifactUserDeletedException_base {
}
declare const CodeArtifactUserFailedException_base: S.TaggedErrorClass<"CodeArtifactUserFailedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CodeArtifactUserFailedException extends /*@__PURE__*/ CodeArtifactUserFailedException_base {
}
declare const CodeArtifactUserPendingException_base: S.TaggedErrorClass<"CodeArtifactUserPendingException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CodeArtifactUserPendingException extends /*@__PURE__*/ CodeArtifactUserPendingException_base {
}
declare const CodeSigningConfigNotFoundException_base: S.TaggedErrorClass<"CodeSigningConfigNotFoundException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeSigningConfigNotFoundException extends /*@__PURE__*/ CodeSigningConfigNotFoundException_base {
}
declare const CodeStorageExceededException_base: S.TaggedErrorClass<"CodeStorageExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeStorageExceededException extends /*@__PURE__*/ CodeStorageExceededException_base {
}
declare const CodeVerificationFailedException_base: S.TaggedErrorClass<"CodeVerificationFailedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CodeVerificationFailedException extends /*@__PURE__*/ CodeVerificationFailedException_base {
}
declare const DurableExecutionAlreadyStartedException_base: S.TaggedErrorClass<"DurableExecutionAlreadyStartedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DurableExecutionAlreadyStartedException extends /*@__PURE__*/ DurableExecutionAlreadyStartedException_base {
}
declare const EC2AccessDeniedException_base: S.TaggedErrorClass<"EC2AccessDeniedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class EC2AccessDeniedException extends /*@__PURE__*/ EC2AccessDeniedException_base {
}
declare const EC2ThrottledException_base: S.TaggedErrorClass<"EC2ThrottledException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class EC2ThrottledException extends /*@__PURE__*/ EC2ThrottledException_base {
}
declare const EC2UnexpectedException_base: S.TaggedErrorClass<"EC2UnexpectedException", {
    readonly Type: any;
    readonly message: any;
    readonly EC2ErrorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class EC2UnexpectedException extends /*@__PURE__*/ EC2UnexpectedException_base {
}
declare const EFSIOException_base: S.TaggedErrorClass<"EFSIOException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EFSIOException extends /*@__PURE__*/ EFSIOException_base {
}
declare const EFSMountConnectivityException_base: S.TaggedErrorClass<"EFSMountConnectivityException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class EFSMountConnectivityException extends /*@__PURE__*/ EFSMountConnectivityException_base {
}
declare const EFSMountFailureException_base: S.TaggedErrorClass<"EFSMountFailureException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class EFSMountFailureException extends /*@__PURE__*/ EFSMountFailureException_base {
}
declare const EFSMountTimeoutException_base: S.TaggedErrorClass<"EFSMountTimeoutException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class EFSMountTimeoutException extends /*@__PURE__*/ EFSMountTimeoutException_base {
}
declare const ENILimitReachedException_base: S.TaggedErrorClass<"ENILimitReachedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ENILimitReachedException extends /*@__PURE__*/ ENILimitReachedException_base {
}
declare const ENINotReadyException_base: S.TaggedErrorClass<"ENINotReadyException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ENINotReadyException extends /*@__PURE__*/ ENINotReadyException_base {
}
declare const ExecutionRoleMissingPermissions_base: S.TaggedErrorClass<"ExecutionRoleMissingPermissions", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class ExecutionRoleMissingPermissions extends /*@__PURE__*/ ExecutionRoleMissingPermissions_base {
}
declare const ExecutionRoleMissingVpcPermissions_base: S.TaggedErrorClass<"ExecutionRoleMissingVpcPermissions", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class ExecutionRoleMissingVpcPermissions extends /*@__PURE__*/ ExecutionRoleMissingVpcPermissions_base {
}
declare const ExecutionRoleNotAssumable_base: S.TaggedErrorClass<"ExecutionRoleNotAssumable", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class ExecutionRoleNotAssumable extends /*@__PURE__*/ ExecutionRoleNotAssumable_base {
}
declare const FunctionVersionsPerCapacityProviderLimitExceededException_base: S.TaggedErrorClass<"FunctionVersionsPerCapacityProviderLimitExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FunctionVersionsPerCapacityProviderLimitExceededException extends /*@__PURE__*/ FunctionVersionsPerCapacityProviderLimitExceededException_base {
}
declare const InvalidCodeSignatureException_base: S.TaggedErrorClass<"InvalidCodeSignatureException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidCodeSignatureException extends /*@__PURE__*/ InvalidCodeSignatureException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestContentException_base: S.TaggedErrorClass<"InvalidRequestContentException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestContentException extends /*@__PURE__*/ InvalidRequestContentException_base {
}
declare const InvalidRuntimeException_base: S.TaggedErrorClass<"InvalidRuntimeException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidRuntimeException extends /*@__PURE__*/ InvalidRuntimeException_base {
}
declare const InvalidSecurityGroupIDException_base: S.TaggedErrorClass<"InvalidSecurityGroupIDException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidSecurityGroupIDException extends /*@__PURE__*/ InvalidSecurityGroupIDException_base {
}
declare const InvalidSubnetIDException_base: S.TaggedErrorClass<"InvalidSubnetIDException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidSubnetIDException extends /*@__PURE__*/ InvalidSubnetIDException_base {
}
declare const InvalidZipFileException_base: S.TaggedErrorClass<"InvalidZipFileException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InvalidZipFileException extends /*@__PURE__*/ InvalidZipFileException_base {
}
declare const KMSAccessDeniedException_base: S.TaggedErrorClass<"KMSAccessDeniedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class KMSAccessDeniedException extends /*@__PURE__*/ KMSAccessDeniedException_base {
}
declare const KMSDisabledException_base: S.TaggedErrorClass<"KMSDisabledException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class KMSDisabledException extends /*@__PURE__*/ KMSDisabledException_base {
}
declare const KmsGrantPrincipalNotReady_base: S.TaggedErrorClass<"KmsGrantPrincipalNotReady", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class KmsGrantPrincipalNotReady extends /*@__PURE__*/ KmsGrantPrincipalNotReady_base {
}
declare const KMSInvalidStateException_base: S.TaggedErrorClass<"KMSInvalidStateException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class KMSInvalidStateException extends /*@__PURE__*/ KMSInvalidStateException_base {
}
declare const KMSNotFoundException_base: S.TaggedErrorClass<"KMSNotFoundException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class KMSNotFoundException extends /*@__PURE__*/ KMSNotFoundException_base {
}
declare const LambdaInternalKmsError_base: S.TaggedErrorClass<"LambdaInternalKmsError", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LambdaInternalKmsError extends /*@__PURE__*/ LambdaInternalKmsError_base {
}
declare const ModeNotSupportedException_base: S.TaggedErrorClass<"ModeNotSupportedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ModeNotSupportedException extends /*@__PURE__*/ ModeNotSupportedException_base {
}
declare const NoPublishedVersionException_base: S.TaggedErrorClass<"NoPublishedVersionException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NoPublishedVersionException extends /*@__PURE__*/ NoPublishedVersionException_base {
}
declare const ParseError_base: S.TaggedErrorClass<"ParseError", {
    readonly message: any;
}>;
export declare class ParseError extends /*@__PURE__*/ ParseError_base {
}
declare const PolicyLengthExceededException_base: S.TaggedErrorClass<"PolicyLengthExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PolicyLengthExceededException extends /*@__PURE__*/ PolicyLengthExceededException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const ProvisionedConcurrencyConfigNotFoundException_base: S.TaggedErrorClass<"ProvisionedConcurrencyConfigNotFoundException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ProvisionedConcurrencyConfigNotFoundException extends /*@__PURE__*/ ProvisionedConcurrencyConfigNotFoundException_base {
}
declare const PublicPolicyException_base: S.TaggedErrorClass<"PublicPolicyException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PublicPolicyException extends /*@__PURE__*/ PublicPolicyException_base {
}
declare const QueueVisibilityTimeoutTooShort_base: S.TaggedErrorClass<"QueueVisibilityTimeoutTooShort", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class QueueVisibilityTimeoutTooShort extends /*@__PURE__*/ QueueVisibilityTimeoutTooShort_base {
}
declare const RecursiveInvocationException_base: S.TaggedErrorClass<"RecursiveInvocationException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RecursiveInvocationException extends /*@__PURE__*/ RecursiveInvocationException_base {
}
declare const RequestLimitExceeded_base: S.TaggedErrorClass<"RequestLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestLimitExceeded extends /*@__PURE__*/ RequestLimitExceeded_base {
}
declare const RequestTooLargeException_base: S.TaggedErrorClass<"RequestTooLargeException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestTooLargeException extends /*@__PURE__*/ RequestTooLargeException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.TaggedErrorClass<"ResourceNotReadyException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const RuntimeAliasDeletedException_base: S.TaggedErrorClass<"RuntimeAliasDeletedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class RuntimeAliasDeletedException extends /*@__PURE__*/ RuntimeAliasDeletedException_base {
}
declare const RuntimeVersionDeletedException_base: S.TaggedErrorClass<"RuntimeVersionDeletedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class RuntimeVersionDeletedException extends /*@__PURE__*/ RuntimeVersionDeletedException_base {
}
declare const S3FilesMountConnectivityException_base: S.TaggedErrorClass<"S3FilesMountConnectivityException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class S3FilesMountConnectivityException extends /*@__PURE__*/ S3FilesMountConnectivityException_base {
}
declare const S3FilesMountFailureException_base: S.TaggedErrorClass<"S3FilesMountFailureException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class S3FilesMountFailureException extends /*@__PURE__*/ S3FilesMountFailureException_base {
}
declare const S3FilesMountTimeoutException_base: S.TaggedErrorClass<"S3FilesMountTimeoutException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class S3FilesMountTimeoutException extends /*@__PURE__*/ S3FilesMountTimeoutException_base {
}
declare const SecurityGroupNotFound_base: S.TaggedErrorClass<"SecurityGroupNotFound", {
    readonly Type: any;
    readonly message: any;
}>;
export declare class SecurityGroupNotFound extends /*@__PURE__*/ SecurityGroupNotFound_base {
}
declare const SerializedRequestEntityTooLargeException_base: S.TaggedErrorClass<"SerializedRequestEntityTooLargeException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SerializedRequestEntityTooLargeException extends /*@__PURE__*/ SerializedRequestEntityTooLargeException_base {
}
declare const ServiceException_base: S.TaggedErrorClass<"ServiceException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceException extends /*@__PURE__*/ ServiceException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const SnapStartException_base: S.TaggedErrorClass<"SnapStartException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapStartException extends /*@__PURE__*/ SnapStartException_base {
}
declare const SnapStartNotReadyException_base: S.TaggedErrorClass<"SnapStartNotReadyException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SnapStartNotReadyException extends /*@__PURE__*/ SnapStartNotReadyException_base {
}
declare const SnapStartRegenerationFailureException_base: S.TaggedErrorClass<"SnapStartRegenerationFailureException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SnapStartRegenerationFailureException extends /*@__PURE__*/ SnapStartRegenerationFailureException_base {
}
declare const SnapStartTimeoutException_base: S.TaggedErrorClass<"SnapStartTimeoutException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        TimeoutError: true;
    };
});
export declare class SnapStartTimeoutException extends /*@__PURE__*/ SnapStartTimeoutException_base {
}
declare const SubnetIPAddressLimitReachedException_base: S.TaggedErrorClass<"SubnetIPAddressLimitReachedException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class SubnetIPAddressLimitReachedException extends /*@__PURE__*/ SubnetIPAddressLimitReachedException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly retryAfterSeconds: any;
    readonly Type: any;
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const UnsupportedMediaTypeException_base: S.TaggedErrorClass<"UnsupportedMediaTypeException", {
    readonly Type: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedMediaTypeException extends /*@__PURE__*/ UnsupportedMediaTypeException_base {
}
export type LayerNameOrArn = string;
export type LayerVersionNumber = number;
export type StatementId = string;
export type LayerPermissionAllowedAction = string;
export type LayerPermissionAllowedPrincipal = string;
export type OrganizationId = string;
export interface AddLayerVersionPermissionRequest {
    LayerName: string;
    VersionNumber: number;
    StatementId: string;
    Action: string;
    Principal: string;
    OrganizationId?: string | undefined;
    RevisionId?: string | undefined;
}
export interface AddLayerVersionPermissionResponse {
    Statement?: string | undefined;
    RevisionId?: string | undefined;
}
export type NamespacedFunctionName = string;
export type Action = string;
export type Principal = string;
export type Arn = string;
export type FunctionUrlAuthType = "NONE" | "AWS_IAM" | (string & {});
export type InvokedViaFunctionUrl = boolean;
export type SourceOwner = string;
export type EventSourceToken = string;
export type NumericLatestPublishedOrAliasQualifier = string;
export type PrincipalOrgID = string;
export interface AddPermissionRequest {
    FunctionName: string;
    StatementId: string;
    Action: string;
    Principal: string;
    SourceArn?: string | undefined;
    FunctionUrlAuthType?: FunctionUrlAuthType | undefined;
    InvokedViaFunctionUrl?: boolean | undefined;
    SourceAccount?: string | undefined;
    EventSourceToken?: string | undefined;
    Qualifier?: string | undefined;
    RevisionId?: string | undefined;
    PrincipalOrgID?: string | undefined;
}
export interface AddPermissionResponse {
    Statement?: string | undefined;
}
export type DurableExecutionArn = string;
export type CheckpointToken = string;
export type OperationId = string;
export type OperationName = string;
export type OperationType = "EXECUTION" | "CONTEXT" | "STEP" | "WAIT" | "CALLBACK" | "CHAINED_INVOKE" | (string & {});
export type OperationSubType = string;
export type OperationAction = "START" | "SUCCEED" | "FAIL" | "RETRY" | "CANCEL" | (string & {});
export type OperationPayload = string | redacted.Redacted<string>;
export type ErrorMessage = string | redacted.Redacted<string>;
export type ErrorType = string | redacted.Redacted<string>;
export type ErrorData = string | redacted.Redacted<string>;
export type StackTraceEntry = string | redacted.Redacted<string>;
export type StackTraceEntries = (string | redacted.Redacted<string>)[];
export interface ErrorObject {
    ErrorMessage?: string | redacted.Redacted<string> | undefined;
    ErrorType?: string | redacted.Redacted<string> | undefined;
    ErrorData?: string | redacted.Redacted<string> | undefined;
    StackTrace?: (string | redacted.Redacted<string>)[] | undefined;
}
export type ReplayChildren = boolean;
export interface ContextOptions {
    ReplayChildren?: boolean | undefined;
}
export type DurationSeconds = number;
export interface StepOptions {
    NextAttemptDelaySeconds?: number | undefined;
}
export interface WaitOptions {
    WaitSeconds?: number | undefined;
}
export interface CallbackOptions {
    TimeoutSeconds?: number | undefined;
    HeartbeatTimeoutSeconds?: number | undefined;
}
export type TenantId = string;
export type XAmznTraceId = string;
export interface ChainedInvokeOptions {
    FunctionName: string;
    TenantId?: string | undefined;
    XAmznTraceId?: string | undefined;
}
export interface OperationUpdate {
    Id: string;
    ParentId?: string | undefined;
    Name?: string | undefined;
    Type: OperationType;
    SubType?: string | undefined;
    Action: OperationAction;
    Payload?: string | redacted.Redacted<string> | undefined;
    Error?: ErrorObject | undefined;
    ContextOptions?: ContextOptions | undefined;
    StepOptions?: StepOptions | undefined;
    WaitOptions?: WaitOptions | undefined;
    CallbackOptions?: CallbackOptions | undefined;
    ChainedInvokeOptions?: ChainedInvokeOptions | undefined;
}
export type OperationUpdates = OperationUpdate[];
export type ClientToken = string;
export interface CheckpointDurableExecutionRequest {
    DurableExecutionArn: string;
    CheckpointToken: string;
    Updates?: OperationUpdate[] | undefined;
    ClientToken?: string | undefined;
}
export type ExecutionTimestamp = Date;
export type OperationStatus = "STARTED" | "PENDING" | "READY" | "SUCCEEDED" | "FAILED" | "CANCELLED" | "TIMED_OUT" | "STOPPED" | (string & {});
export type InputPayload = string | redacted.Redacted<string>;
export interface ExecutionDetails {
    InputPayload?: string | redacted.Redacted<string> | undefined;
}
export interface ContextDetails {
    ReplayChildren?: boolean | undefined;
    Result?: string | redacted.Redacted<string> | undefined;
    Error?: ErrorObject | undefined;
}
export type AttemptCount = number;
export interface StepDetails {
    Attempt?: number | undefined;
    NextAttemptTimestamp?: Date | undefined;
    Result?: string | redacted.Redacted<string> | undefined;
    Error?: ErrorObject | undefined;
}
export interface WaitDetails {
    ScheduledEndTimestamp?: Date | undefined;
}
export type CallbackId = string;
export interface CallbackDetails {
    CallbackId?: string | undefined;
    Result?: string | redacted.Redacted<string> | undefined;
    Error?: ErrorObject | undefined;
}
export interface ChainedInvokeDetails {
    Result?: string | redacted.Redacted<string> | undefined;
    Error?: ErrorObject | undefined;
}
export interface Operation {
    Id: string;
    ParentId?: string | undefined;
    Name?: string | undefined;
    Type: OperationType;
    SubType?: string | undefined;
    StartTimestamp: Date;
    EndTimestamp?: Date | undefined;
    Status: OperationStatus;
    ExecutionDetails?: ExecutionDetails | undefined;
    ContextDetails?: ContextDetails | undefined;
    StepDetails?: StepDetails | undefined;
    WaitDetails?: WaitDetails | undefined;
    CallbackDetails?: CallbackDetails | undefined;
    ChainedInvokeDetails?: ChainedInvokeDetails | undefined;
}
export type Operations = Operation[];
export interface CheckpointUpdatedExecutionState {
    Operations?: Operation[] | undefined;
    NextMarker?: string | undefined;
}
export interface CheckpointDurableExecutionResponse {
    CheckpointToken?: string | undefined;
    NewExecutionState: CheckpointUpdatedExecutionState;
}
export type FunctionName = string;
export type Alias = string;
export type VersionWithLatestPublished = string;
export type Description = string;
export type AdditionalVersion = string;
export type Weight = number;
export type AdditionalVersionWeights = {
    [key: string]: number | undefined;
};
export interface AliasRoutingConfiguration {
    AdditionalVersionWeights?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface CreateAliasRequest {
    FunctionName: string;
    Name: string;
    FunctionVersion: string;
    Description?: string | undefined;
    RoutingConfig?: AliasRoutingConfiguration | undefined;
}
export type FunctionArn = string;
export type Version = string;
export interface AliasConfiguration {
    AliasArn?: string | undefined;
    Name?: string | undefined;
    FunctionVersion?: string | undefined;
    Description?: string | undefined;
    RoutingConfig?: AliasRoutingConfiguration | undefined;
    RevisionId?: string | undefined;
}
export type CapacityProviderName = string;
export type SubnetId = string;
export type CapacityProviderSubnetIds = string[];
export type SecurityGroupId = string;
export type CapacityProviderSecurityGroupIds = string[];
export interface CapacityProviderVpcConfig {
    SubnetIds: string[];
    SecurityGroupIds: string[];
}
export type RoleArn = string;
export interface CapacityProviderPermissionsConfig {
    CapacityProviderOperatorRoleArn: string;
}
export type Architecture = "x86_64" | "arm64" | (string & {});
export type ArchitecturesList = Architecture[];
export type InstanceType = string;
export type InstanceTypeSet = string[];
export interface InstanceRequirements {
    Architectures?: Architecture[] | undefined;
    AllowedInstanceTypes?: string[] | undefined;
    ExcludedInstanceTypes?: string[] | undefined;
}
export type CapacityProviderMaxVCpuCount = number;
export type CapacityProviderScalingMode = "Auto" | "Manual" | (string & {});
export type CapacityProviderPredefinedMetricType = "LambdaCapacityProviderAverageCPUUtilization" | "LambdaCapacityProviderAverageGPUUtilization" | (string & {});
export type MetricTargetValue = number;
export interface TargetTrackingScalingPolicy {
    PredefinedMetricType: CapacityProviderPredefinedMetricType;
    TargetValue: number;
}
export type CapacityProviderScalingPoliciesList = TargetTrackingScalingPolicy[];
export interface CapacityProviderScalingConfig {
    MaxVCpuCount?: number | undefined;
    ScalingMode?: CapacityProviderScalingMode | undefined;
    ScalingPolicies?: TargetTrackingScalingPolicy[] | undefined;
}
export type KMSKeyArnNonEmpty = string;
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type PropagateTagsMode = "None" | "Explicit" | (string & {});
export interface PropagateTags {
    Mode?: PropagateTagsMode | undefined;
    ExplicitTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SystemLogLevel = "DEBUG" | "INFO" | "WARN" | (string & {});
export type LogGroup = string;
export interface CapacityProviderLoggingConfig {
    SystemLogLevel?: SystemLogLevel | undefined;
    LogGroup?: string | undefined;
}
export interface CapacityProviderTelemetryConfig {
    LoggingConfig?: CapacityProviderLoggingConfig | undefined;
}
export interface CreateCapacityProviderRequest {
    CapacityProviderName: string;
    VpcConfig: CapacityProviderVpcConfig;
    PermissionsConfig: CapacityProviderPermissionsConfig;
    InstanceRequirements?: InstanceRequirements | undefined;
    CapacityProviderScalingConfig?: CapacityProviderScalingConfig | undefined;
    KmsKeyArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    PropagateTags?: PropagateTags | undefined;
    TelemetryConfig?: CapacityProviderTelemetryConfig | undefined;
}
export type CapacityProviderArn = string;
export type CapacityProviderState = "Pending" | "Active" | "Failed" | "Deleting" | (string & {});
export type KMSKeyArn = string;
export interface CapacityProvider {
    CapacityProviderArn: string;
    State: CapacityProviderState;
    VpcConfig: CapacityProviderVpcConfig;
    PermissionsConfig: CapacityProviderPermissionsConfig;
    InstanceRequirements?: InstanceRequirements | undefined;
    CapacityProviderScalingConfig?: CapacityProviderScalingConfig | undefined;
    KmsKeyArn?: string | undefined;
    LastModified?: string | undefined;
    PropagateTags?: PropagateTags | undefined;
    TelemetryConfig?: CapacityProviderTelemetryConfig | undefined;
}
export interface CreateCapacityProviderResponse {
    CapacityProvider: CapacityProvider;
}
export type SigningProfileVersionArns = string[];
export interface AllowedPublishers {
    SigningProfileVersionArns: string[];
}
export type CodeSigningPolicy = "Warn" | "Enforce" | (string & {});
export interface CodeSigningPolicies {
    UntrustedArtifactOnDeployment?: CodeSigningPolicy | undefined;
}
export interface CreateCodeSigningConfigRequest {
    Description?: string | undefined;
    AllowedPublishers: AllowedPublishers;
    CodeSigningPolicies?: CodeSigningPolicies | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CodeSigningConfigId = string;
export type CodeSigningConfigArn = string;
export interface CodeSigningConfig {
    CodeSigningConfigId: string;
    CodeSigningConfigArn: string;
    Description?: string | undefined;
    AllowedPublishers: AllowedPublishers;
    CodeSigningPolicies: CodeSigningPolicies;
    LastModified: string;
}
export interface CreateCodeSigningConfigResponse {
    CodeSigningConfig: CodeSigningConfig;
}
export type Enabled = boolean;
export type BatchSize = number;
export type Pattern = string;
export interface Filter {
    Pattern?: string | undefined;
}
export type FilterList = Filter[];
export interface FilterCriteria {
    Filters?: Filter[] | undefined;
}
export type EventSourceMappingMetric = "EventCount" | "ErrorCount" | "KafkaMetrics" | (string & {});
export type EventSourceMappingMetricList = EventSourceMappingMetric[];
export interface EventSourceMappingMetricsConfig {
    Metrics?: EventSourceMappingMetric[] | undefined;
}
export type EventSourceMappingSystemLogLevel = "DEBUG" | "INFO" | "WARN" | (string & {});
export interface EventSourceMappingLoggingConfig {
    SystemLogLevel?: EventSourceMappingSystemLogLevel | undefined;
}
export type MaximumConcurrency = number;
export interface ScalingConfig {
    MaximumConcurrency?: number | undefined;
}
export type MaximumBatchingWindowInSeconds = number;
export type ParallelizationFactor = number;
export type EventSourcePosition = "TRIM_HORIZON" | "LATEST" | "AT_TIMESTAMP" | (string & {});
export type DestinationArn = string;
export interface OnSuccess {
    Destination?: string | undefined;
}
export interface OnFailure {
    Destination?: string | undefined;
}
export interface DestinationConfig {
    OnSuccess?: OnSuccess | undefined;
    OnFailure?: OnFailure | undefined;
}
export type MaximumRecordAgeInSeconds = number;
export type BisectBatchOnFunctionError = boolean;
export type MaximumRetryAttemptsEventSourceMapping = number;
export type TumblingWindowInSeconds = number;
export type Topic = string;
export type Topics = string[];
export type Queue = string;
export type Queues = string[];
export type SourceAccessType = "BASIC_AUTH" | "VPC_SUBNET" | "VPC_SECURITY_GROUP" | "SASL_SCRAM_512_AUTH" | "SASL_SCRAM_256_AUTH" | "VIRTUAL_HOST" | "CLIENT_CERTIFICATE_TLS_AUTH" | "SERVER_ROOT_CA_CERTIFICATE" | "OAUTHBEARER_AUTH" | "OAUTHBEARER_SCOPE" | "OAUTHBEARER_AUDIENCE" | "OAUTHBEARER_LOGICAL_CLUSTER" | "OAUTHBEARER_IDENTITY_POOL" | "IAM_AUTH" | "IAM_OAUTHBEARER_AUTH" | (string & {});
export type URI = string;
export interface SourceAccessConfiguration {
    Type?: SourceAccessType | undefined;
    URI?: string | undefined;
}
export type SourceAccessConfigurations = SourceAccessConfiguration[];
export type EndPointType = "KAFKA_BOOTSTRAP_SERVERS" | (string & {});
export type Endpoint = string;
export type EndpointLists = string[];
export type Endpoints = {
    [key in EndPointType]?: string[] | undefined;
};
export interface SelfManagedEventSource {
    Endpoints?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type FunctionResponseType = "ReportBatchItemFailures" | (string & {});
export type FunctionResponseTypeList = FunctionResponseType[];
export type SchemaRegistryUri = string;
export type SchemaRegistryEventRecordFormat = "JSON" | "SOURCE" | (string & {});
export type KafkaSchemaRegistryAuthType = "BASIC_AUTH" | "CLIENT_CERTIFICATE_TLS_AUTH" | "SERVER_ROOT_CA_CERTIFICATE" | "OAUTHBEARER_AUTH" | (string & {});
export interface KafkaSchemaRegistryAccessConfig {
    Type?: KafkaSchemaRegistryAuthType | undefined;
    URI?: string | undefined;
}
export type KafkaSchemaRegistryAccessConfigList = KafkaSchemaRegistryAccessConfig[];
export type KafkaSchemaValidationAttribute = "KEY" | "VALUE" | (string & {});
export interface KafkaSchemaValidationConfig {
    Attribute?: KafkaSchemaValidationAttribute | undefined;
}
export type KafkaSchemaValidationConfigList = KafkaSchemaValidationConfig[];
export interface KafkaSchemaRegistryConfig {
    SchemaRegistryURI?: string | undefined;
    EventRecordFormat?: SchemaRegistryEventRecordFormat | undefined;
    AccessConfigs?: KafkaSchemaRegistryAccessConfig[] | undefined;
    SchemaValidationConfigs?: KafkaSchemaValidationConfig[] | undefined;
}
export interface AmazonManagedKafkaEventSourceConfig {
    ConsumerGroupId?: string | undefined;
    SchemaRegistryConfig?: KafkaSchemaRegistryConfig | undefined;
}
export type KafkaEventSourceMappingConsumptionMode = "Stream" | "Queue" | (string & {});
export interface SelfManagedKafkaEventSourceConfig {
    ConsumerGroupId?: string | undefined;
    SchemaRegistryConfig?: KafkaSchemaRegistryConfig | undefined;
    ConsumptionMode?: KafkaEventSourceMappingConsumptionMode | undefined;
}
export type DatabaseName = string;
export type CollectionName = string;
export type FullDocument = "UpdateLookup" | "Default" | (string & {});
export interface DocumentDBEventSourceConfig {
    DatabaseName?: string | undefined;
    CollectionName?: string | undefined;
    FullDocument?: FullDocument | undefined;
}
export type MinimumNumberOfPollers = number;
export type MaximumNumberOfPollers = number;
export type ProvisionedPollerGroupName = string;
export interface ProvisionedPollerConfig {
    MinimumPollers?: number | undefined;
    MaximumPollers?: number | undefined;
    PollerGroupName?: string | undefined;
}
export interface CreateEventSourceMappingRequest {
    EventSourceArn?: string | undefined;
    FunctionName: string;
    Enabled?: boolean | undefined;
    BatchSize?: number | undefined;
    FilterCriteria?: FilterCriteria | undefined;
    KMSKeyArn?: string | undefined;
    MetricsConfig?: EventSourceMappingMetricsConfig | undefined;
    LoggingConfig?: EventSourceMappingLoggingConfig | undefined;
    ScalingConfig?: ScalingConfig | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    ParallelizationFactor?: number | undefined;
    StartingPosition?: EventSourcePosition | undefined;
    StartingPositionTimestamp?: Date | undefined;
    DestinationConfig?: DestinationConfig | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    BisectBatchOnFunctionError?: boolean | undefined;
    MaximumRetryAttempts?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TumblingWindowInSeconds?: number | undefined;
    Topics?: string[] | undefined;
    Queues?: string[] | undefined;
    SourceAccessConfigurations?: SourceAccessConfiguration[] | undefined;
    SelfManagedEventSource?: SelfManagedEventSource | undefined;
    FunctionResponseTypes?: FunctionResponseType[] | undefined;
    AmazonManagedKafkaEventSourceConfig?: AmazonManagedKafkaEventSourceConfig | undefined;
    SelfManagedKafkaEventSourceConfig?: SelfManagedKafkaEventSourceConfig | undefined;
    DocumentDBEventSourceConfig?: DocumentDBEventSourceConfig | undefined;
    ProvisionedPollerConfig?: ProvisionedPollerConfig | undefined;
}
export type UUIDString = string;
export type FilterCriteriaErrorCode = string;
export type FilterCriteriaErrorMessage = string;
export interface FilterCriteriaError {
    ErrorCode?: string | undefined;
    Message?: string | undefined;
}
export type EventSourceMappingArn = string;
export interface EventSourceMappingConfiguration {
    UUID?: string | undefined;
    StartingPosition?: EventSourcePosition | undefined;
    StartingPositionTimestamp?: Date | undefined;
    BatchSize?: number | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    ParallelizationFactor?: number | undefined;
    EventSourceArn?: string | undefined;
    FilterCriteria?: FilterCriteria | undefined;
    FilterCriteriaError?: FilterCriteriaError | undefined;
    KMSKeyArn?: string | undefined;
    MetricsConfig?: EventSourceMappingMetricsConfig | undefined;
    LoggingConfig?: EventSourceMappingLoggingConfig | undefined;
    ScalingConfig?: ScalingConfig | undefined;
    FunctionArn?: string | undefined;
    LastModified?: Date | undefined;
    LastProcessingResult?: string | undefined;
    State?: string | undefined;
    StateTransitionReason?: string | undefined;
    DestinationConfig?: DestinationConfig | undefined;
    Topics?: string[] | undefined;
    Queues?: string[] | undefined;
    SourceAccessConfigurations?: SourceAccessConfiguration[] | undefined;
    SelfManagedEventSource?: SelfManagedEventSource | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    BisectBatchOnFunctionError?: boolean | undefined;
    MaximumRetryAttempts?: number | undefined;
    TumblingWindowInSeconds?: number | undefined;
    FunctionResponseTypes?: FunctionResponseType[] | undefined;
    AmazonManagedKafkaEventSourceConfig?: AmazonManagedKafkaEventSourceConfig | undefined;
    SelfManagedKafkaEventSourceConfig?: SelfManagedKafkaEventSourceConfig | undefined;
    DocumentDBEventSourceConfig?: DocumentDBEventSourceConfig | undefined;
    EventSourceMappingArn?: string | undefined;
    ProvisionedPollerConfig?: ProvisionedPollerConfig | undefined;
}
export type Runtime = "nodejs" | "nodejs4.3" | "nodejs6.10" | "nodejs8.10" | "nodejs10.x" | "nodejs12.x" | "nodejs14.x" | "nodejs16.x" | "nodejs18.x" | "nodejs20.x" | "nodejs22.x" | "nodejs24.x" | "java8" | "java8.al2" | "java11" | "java17" | "java21" | "java25" | "python2.7" | "python3.6" | "python3.7" | "python3.8" | "python3.9" | "python3.10" | "python3.11" | "python3.12" | "python3.13" | "python3.14" | "dotnetcore1.0" | "dotnetcore2.0" | "dotnetcore2.1" | "dotnetcore3.1" | "dotnet6" | "dotnet8" | "dotnet10" | "nodejs4.3-edge" | "go1.x" | "ruby2.5" | "ruby2.7" | "ruby3.2" | "ruby3.3" | "ruby3.4" | "ruby4.0" | "provided" | "provided.al2" | "provided.al2023" | "nodejs26.x" | "python3.15" | "java8.al2023" | "java11.al2023" | "java17.al2023" | "custom" | (string & {});
export type Handler = string;
export type S3Bucket = string;
export type S3Key = string;
export type S3ObjectVersion = string;
export type S3ObjectStorageMode = "COPY" | "REFERENCE" | (string & {});
export interface FunctionCode {
    ZipFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3ObjectVersion?: string | undefined;
    S3ObjectStorageMode?: S3ObjectStorageMode | undefined;
    ImageUri?: string | undefined;
    SourceKMSKeyArn?: string | undefined;
}
export type Timeout = number;
export type MemorySize = number;
export type FunctionVersionLatestPublished = "LATEST_PUBLISHED" | (string & {});
export type SubnetIds = string[];
export type SecurityGroupIds = string[];
export interface VpcConfig {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    Ipv6AllowedForDualStack?: boolean | undefined;
}
export type PackageType = "Zip" | "Image" | (string & {});
export type ResourceArn = string;
export interface DeadLetterConfig {
    TargetArn?: string | undefined;
}
export type EnvironmentVariableName = string | redacted.Redacted<string>;
export type EnvironmentVariableValue = string | redacted.Redacted<string>;
export type EnvironmentVariables = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export interface Environment {
    Variables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
}
export type TracingMode = "Active" | "PassThrough" | (string & {});
export interface TracingConfig {
    Mode?: TracingMode | undefined;
}
export type LayerVersionArn = string;
export type LayerList = string[];
export type FileSystemArn = string;
export type LocalMountPath = string;
export type DirectS3Read = "ENABLED" | "DISABLED" | "AUTO" | (string & {});
export interface S3FilesConfig {
    DirectS3Read?: DirectS3Read | undefined;
}
export interface FileSystemConfig {
    Arn: string;
    LocalMountPath: string;
    S3FilesConfig?: S3FilesConfig | undefined;
}
export type FileSystemConfigList = FileSystemConfig[];
export type StringList = string[];
export type WorkingDirectory = string;
export interface ImageConfig {
    EntryPoint?: string[] | undefined;
    Command?: string[] | undefined;
    WorkingDirectory?: string | undefined;
}
export type EphemeralStorageSize = number;
export interface EphemeralStorage {
    Size: number;
}
export type SnapStartApplyOn = "PublishedVersions" | "None" | (string & {});
export interface SnapStart {
    ApplyOn?: SnapStartApplyOn | undefined;
}
export type LogFormat = "JSON" | "Text" | (string & {});
export type ApplicationLogLevel = "TRACE" | "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export interface LoggingConfig {
    LogFormat?: LogFormat | undefined;
    ApplicationLogLevel?: ApplicationLogLevel | undefined;
    SystemLogLevel?: SystemLogLevel | undefined;
    LogGroup?: string | undefined;
}
export type TenantIsolationMode = "PER_TENANT" | (string & {});
export interface TenancyConfig {
    TenantIsolationMode: TenantIsolationMode;
}
export type PerExecutionEnvironmentMaxConcurrency = number;
export type ExecutionEnvironmentMemoryGiBPerVCpu = number;
export interface LambdaManagedInstancesCapacityProviderConfig {
    CapacityProviderArn: string;
    PerExecutionEnvironmentMaxConcurrency?: number | undefined;
    ExecutionEnvironmentMemoryGiBPerVCpu?: number | undefined;
}
export interface CapacityProviderConfig {
    LambdaManagedInstancesCapacityProviderConfig: LambdaManagedInstancesCapacityProviderConfig;
}
export type RetentionPeriodInDays = number;
export type ExecutionTimeout = number;
export interface DurableConfig {
    KMSKeyArn?: string | undefined;
    RetentionPeriodInDays?: number | undefined;
    ExecutionTimeout?: number | undefined;
}
export type FunctionRuntimeArn = string;
export type FunctionRuntimeAlias = string;
export interface FunctionRuntimeConfig {
    RuntimeArn: string;
    RuntimeAlias: string;
}
export type AcceleratorMemoryGB = 3 | 6 | 12 | 16 | 24 | 48 | (number & {});
export interface AcceleratorConfig {
    AcceleratorMemorySize: AcceleratorMemoryGB;
}
export interface CreateFunctionRequest {
    FunctionName: string;
    Runtime?: Runtime | undefined;
    Role: string;
    Handler?: string | undefined;
    Code: FunctionCode;
    Description?: string | undefined;
    Timeout?: number | undefined;
    MemorySize?: number | undefined;
    Publish?: boolean | undefined;
    PublishTo?: FunctionVersionLatestPublished | undefined;
    VpcConfig?: VpcConfig | undefined;
    PackageType?: PackageType | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    Environment?: Environment | undefined;
    KMSKeyArn?: string | undefined;
    TracingConfig?: TracingConfig | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Layers?: string[] | undefined;
    FileSystemConfigs?: FileSystemConfig[] | undefined;
    CodeSigningConfigArn?: string | undefined;
    ImageConfig?: ImageConfig | undefined;
    Architectures?: Architecture[] | undefined;
    EphemeralStorage?: EphemeralStorage | undefined;
    SnapStart?: SnapStart | undefined;
    LoggingConfig?: LoggingConfig | undefined;
    TenancyConfig?: TenancyConfig | undefined;
    CapacityProviderConfig?: CapacityProviderConfig | undefined;
    DurableConfig?: DurableConfig | undefined;
    RuntimeConfig?: FunctionRuntimeConfig | undefined;
    AcceleratorConfig?: AcceleratorConfig | undefined;
}
export type NameSpacedFunctionArn = string;
export type VpcId = string;
export interface VpcConfigResponse {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    VpcId?: string | undefined;
    Ipv6AllowedForDualStack?: boolean | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface EnvironmentError {
    ErrorCode?: string | undefined;
    Message?: string | redacted.Redacted<string> | undefined;
}
export interface EnvironmentResponse {
    Variables?: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    } | undefined;
    Error?: EnvironmentError | undefined;
}
export interface TracingConfigResponse {
    Mode?: TracingMode | undefined;
}
export interface Layer {
    Arn?: string | undefined;
    CodeSize?: number | undefined;
    SigningProfileVersionArn?: string | undefined;
    SigningJobArn?: string | undefined;
}
export type LayersReferenceList = Layer[];
export type State = "Pending" | "Active" | "Inactive" | "Failed" | "Deactivating" | "Deactivated" | "ActiveNonInvocable" | "Deleting" | (string & {});
export type StateReason = string;
export type StateReasonCode = "Idle" | "Creating" | "Restoring" | "EniLimitExceeded" | "InsufficientRolePermissions" | "InvalidConfiguration" | "InternalError" | "SubnetOutOfIPAddresses" | "InvalidSubnet" | "InvalidSecurityGroup" | "ImageDeleted" | "ImageAccessDenied" | "InvalidImage" | "KMSKeyAccessDenied" | "KMSKeyNotFound" | "InvalidStateKMSKey" | "DisabledKMSKey" | "EFSIOError" | "EFSMountConnectivityError" | "EFSMountFailure" | "EFSMountTimeout" | "InvalidRuntime" | "InvalidZipFileException" | "FunctionError" | "ServiceQuotaExceededException" | "VcpuLimitExceeded" | "CapacityProviderScalingLimitExceeded" | "InsufficientCapacity" | "EC2RequestLimitExceeded" | "FunctionError.InitTimeout" | "FunctionError.RuntimeInitError" | "FunctionError.ExtensionInitError" | "FunctionError.InvalidEntryPoint" | "FunctionError.InvalidWorkingDirectory" | "FunctionError.PermissionDenied" | "FunctionError.TooManyExtensions" | "FunctionError.InitResourceExhausted" | "DisallowedByVpcEncryptionControl" | "DrainingDurableExecutions" | "IncompatibleAcceleratorInstanceTypes" | "DependencyError" | (string & {});
export type LastUpdateStatus = "Successful" | "Failed" | "InProgress" | (string & {});
export type LastUpdateStatusReason = string;
export type LastUpdateStatusReasonCode = "EniLimitExceeded" | "InsufficientRolePermissions" | "InvalidConfiguration" | "InternalError" | "SubnetOutOfIPAddresses" | "InvalidSubnet" | "InvalidSecurityGroup" | "ImageDeleted" | "ImageAccessDenied" | "InvalidImage" | "KMSKeyAccessDenied" | "KMSKeyNotFound" | "InvalidStateKMSKey" | "DisabledKMSKey" | "EFSIOError" | "EFSMountConnectivityError" | "EFSMountFailure" | "EFSMountTimeout" | "InvalidRuntime" | "InvalidZipFileException" | "FunctionError" | "ServiceQuotaExceededException" | "VcpuLimitExceeded" | "CapacityProviderScalingLimitExceeded" | "InsufficientCapacity" | "EC2RequestLimitExceeded" | "FunctionError.InitTimeout" | "FunctionError.RuntimeInitError" | "FunctionError.ExtensionInitError" | "FunctionError.InvalidEntryPoint" | "FunctionError.InvalidWorkingDirectory" | "FunctionError.PermissionDenied" | "FunctionError.TooManyExtensions" | "FunctionError.InitResourceExhausted" | "DisallowedByVpcEncryptionControl" | "IncompatibleAcceleratorInstanceTypes" | "DependencyError" | "Creating" | (string & {});
export interface ImageConfigError {
    ErrorCode?: string | undefined;
    Message?: string | redacted.Redacted<string> | undefined;
}
export interface ImageConfigResponse {
    ImageConfig?: ImageConfig | undefined;
    Error?: ImageConfigError | undefined;
}
export type SnapStartOptimizationStatus = "On" | "Off" | (string & {});
export interface SnapStartResponse {
    ApplyOn?: SnapStartApplyOn | undefined;
    OptimizationStatus?: SnapStartOptimizationStatus | undefined;
}
export type RuntimeVersionArn = string;
export interface RuntimeVersionError {
    ErrorCode?: string | undefined;
    Message?: string | redacted.Redacted<string> | undefined;
}
export interface RuntimeVersionConfig {
    RuntimeVersionArn?: string | undefined;
    Error?: RuntimeVersionError | undefined;
}
export interface FunctionConfiguration {
    FunctionName?: string | undefined;
    FunctionArn?: string | undefined;
    Runtime?: Runtime | undefined;
    Role?: string | undefined;
    Handler?: string | undefined;
    CodeSize?: number | undefined;
    Description?: string | undefined;
    Timeout?: number | undefined;
    MemorySize?: number | undefined;
    LastModified?: string | undefined;
    CodeSha256?: string | undefined;
    Version?: string | undefined;
    VpcConfig?: VpcConfigResponse | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    Environment?: EnvironmentResponse | undefined;
    KMSKeyArn?: string | undefined;
    TracingConfig?: TracingConfigResponse | undefined;
    MasterArn?: string | undefined;
    RevisionId?: string | undefined;
    Layers?: Layer[] | undefined;
    State?: State | undefined;
    StateReason?: string | undefined;
    StateReasonCode?: StateReasonCode | undefined;
    LastUpdateStatus?: LastUpdateStatus | undefined;
    LastUpdateStatusReason?: string | undefined;
    LastUpdateStatusReasonCode?: LastUpdateStatusReasonCode | undefined;
    FileSystemConfigs?: FileSystemConfig[] | undefined;
    SigningProfileVersionArn?: string | undefined;
    SigningJobArn?: string | undefined;
    PackageType?: PackageType | undefined;
    ImageConfigResponse?: ImageConfigResponse | undefined;
    Architectures?: Architecture[] | undefined;
    EphemeralStorage?: EphemeralStorage | undefined;
    SnapStart?: SnapStartResponse | undefined;
    RuntimeVersionConfig?: RuntimeVersionConfig | undefined;
    LoggingConfig?: LoggingConfig | undefined;
    TenancyConfig?: TenancyConfig | undefined;
    CapacityProviderConfig?: CapacityProviderConfig | undefined;
    ConfigSha256?: string | undefined;
    DurableConfig?: DurableConfig | undefined;
    RuntimeConfig?: FunctionRuntimeConfig | undefined;
    AcceleratorConfig?: AcceleratorConfig | undefined;
}
export type FunctionUrlFunctionName = string;
export type FunctionUrlQualifier = string;
export type AllowCredentials = boolean;
export type Header = string;
export type HeadersList = string[];
export type Method = string;
export type AllowMethodsList = string[];
export type Origin = string;
export type AllowOriginsList = string[];
export type MaxAge = number;
export interface Cors {
    AllowCredentials?: boolean | undefined;
    AllowHeaders?: string[] | undefined;
    AllowMethods?: string[] | undefined;
    AllowOrigins?: string[] | undefined;
    ExposeHeaders?: string[] | undefined;
    MaxAge?: number | undefined;
}
export type InvokeMode = "BUFFERED" | "RESPONSE_STREAM" | (string & {});
export interface CreateFunctionUrlConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
    AuthType: FunctionUrlAuthType;
    Cors?: Cors | undefined;
    InvokeMode?: InvokeMode | undefined;
}
export type FunctionUrl = string;
export interface CreateFunctionUrlConfigResponse {
    FunctionUrl: string;
    FunctionArn: string;
    AuthType: FunctionUrlAuthType;
    Cors?: Cors | undefined;
    CreationTime: string;
    InvokeMode?: InvokeMode | undefined;
}
export interface DeleteAliasRequest {
    FunctionName: string;
    Name: string;
}
export interface DeleteAliasResponse {
}
export interface DeleteCapacityProviderRequest {
    CapacityProviderName: string;
}
export interface DeleteCapacityProviderResponse {
    CapacityProvider: CapacityProvider;
}
export interface DeleteCodeSigningConfigRequest {
    CodeSigningConfigArn: string;
}
export interface DeleteCodeSigningConfigResponse {
}
export interface DeleteDurableExecutionRequest {
    DurableExecutionArn: string;
}
export interface DeleteDurableExecutionResponse {
    DeletionRequestTimestamp: Date;
}
export interface DeleteEventSourceMappingRequest {
    UUID: string;
}
export interface DeleteFunctionRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export interface DeleteFunctionResponse {
    StatusCode?: number | undefined;
}
export interface DeleteFunctionCodeSigningConfigRequest {
    FunctionName: string;
}
export interface DeleteFunctionCodeSigningConfigResponse {
}
export interface DeleteFunctionConcurrencyRequest {
    FunctionName: string;
}
export interface DeleteFunctionConcurrencyResponse {
}
export interface DeleteFunctionEventInvokeConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export interface DeleteFunctionEventInvokeConfigResponse {
}
export interface DeleteFunctionUrlConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export interface DeleteFunctionUrlConfigResponse {
}
export interface DeleteLayerVersionRequest {
    LayerName: string;
    VersionNumber: number;
}
export interface DeleteLayerVersionResponse {
}
export type Qualifier = string;
export interface DeleteProvisionedConcurrencyConfigRequest {
    FunctionName: string;
    Qualifier: string;
}
export interface DeleteProvisionedConcurrencyConfigResponse {
}
export type PolicyResourceArn = string;
export type RevisionId = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
    RevisionId?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
}
export interface GetAccountSettingsRequest {
}
export type UnreservedConcurrentExecutions = number;
export interface AccountLimit {
    TotalCodeSize?: number | undefined;
    CodeSizeUnzipped?: number | undefined;
    CodeSizeZipped?: number | undefined;
    ConcurrentExecutions?: number | undefined;
    UnreservedConcurrentExecutions?: number | undefined;
}
export interface AccountUsage {
    TotalCodeSize?: number | undefined;
    FunctionCount?: number | undefined;
}
export interface GetAccountSettingsResponse {
    AccountLimit?: AccountLimit | undefined;
    AccountUsage?: AccountUsage | undefined;
}
export interface GetAliasRequest {
    FunctionName: string;
    Name: string;
}
export interface GetCapacityProviderRequest {
    CapacityProviderName: string;
}
export interface GetCapacityProviderResponse {
    CapacityProvider: CapacityProvider;
}
export interface GetCodeSigningConfigRequest {
    CodeSigningConfigArn: string;
}
export interface GetCodeSigningConfigResponse {
    CodeSigningConfig: CodeSigningConfig;
}
export type IncludeExecutionData = boolean;
export interface GetDurableExecutionRequest {
    DurableExecutionArn: string;
    IncludeExecutionData?: boolean | undefined;
}
export type DurableExecutionName = string;
export type OutputPayload = string | redacted.Redacted<string>;
export type ExecutionStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "TIMED_OUT" | "STOPPED" | "DELETING" | "PAUSING" | "PAUSED" | (string & {});
export interface TraceHeader {
    XAmznTraceId?: string | undefined;
}
export type ExecutionDataIncluded = boolean;
export type PauseReason = string | redacted.Redacted<string>;
export type ExecutionTimeoutPaused = boolean;
export interface PauseDetails {
    PauseRequestTimestamp: Date;
    Reason?: string | redacted.Redacted<string> | undefined;
    ExecutionTimeoutPaused: boolean;
}
export interface GetDurableExecutionResponse {
    DurableExecutionArn: string;
    DurableExecutionName: string;
    FunctionArn: string;
    InputPayload?: string | redacted.Redacted<string> | undefined;
    Result?: string | redacted.Redacted<string> | undefined;
    Error?: ErrorObject | undefined;
    StartTimestamp: Date;
    Status: ExecutionStatus;
    EndTimestamp?: Date | undefined;
    Version?: string | undefined;
    TraceHeader?: TraceHeader | undefined;
    ExecutionDataIncluded?: boolean | undefined;
    DurableConfig?: DurableConfig | undefined;
    PauseDetails?: PauseDetails | undefined;
    ExpectedExecutionTimeoutTimestamp?: Date | undefined;
}
export type ItemCount = number;
export type ReverseOrder = boolean;
export interface GetDurableExecutionHistoryRequest {
    DurableExecutionArn: string;
    IncludeExecutionData?: boolean | undefined;
    MaxItems?: number | undefined;
    Marker?: string | undefined;
    ReverseOrder?: boolean | undefined;
}
export type EventType = "ExecutionStarted" | "ExecutionSucceeded" | "ExecutionFailed" | "ExecutionTimedOut" | "ExecutionStopped" | "ContextStarted" | "ContextSucceeded" | "ContextFailed" | "WaitStarted" | "WaitSucceeded" | "WaitCancelled" | "StepStarted" | "StepSucceeded" | "StepFailed" | "ChainedInvokeStarted" | "ChainedInvokeSucceeded" | "ChainedInvokeFailed" | "ChainedInvokeTimedOut" | "ChainedInvokeStopped" | "CallbackStarted" | "CallbackSucceeded" | "CallbackFailed" | "CallbackTimedOut" | "InvocationCompleted" | "ExecutionPaused" | "ExecutionResumed" | (string & {});
export type EventId = number;
export type Truncated = boolean;
export interface EventInput {
    Payload?: string | redacted.Redacted<string> | undefined;
    Truncated?: boolean | undefined;
}
export interface ExecutionStartedDetails {
    Input: EventInput;
    ExecutionTimeout: number;
}
export interface EventResult {
    Payload?: string | redacted.Redacted<string> | undefined;
    Truncated?: boolean | undefined;
}
export interface ExecutionSucceededDetails {
    Result: EventResult;
}
export interface EventError {
    Payload?: ErrorObject | undefined;
    Truncated?: boolean | undefined;
}
export interface ExecutionFailedDetails {
    Error: EventError;
}
export interface ExecutionTimedOutDetails {
    Error?: EventError | undefined;
}
export interface ExecutionStoppedDetails {
    Error: EventError;
}
export interface ContextStartedDetails {
}
export interface ContextSucceededDetails {
    Result: EventResult;
}
export interface ContextFailedDetails {
    Error: EventError;
}
export interface WaitStartedDetails {
    Duration: number;
    ScheduledEndTimestamp: Date;
}
export interface WaitSucceededDetails {
    Duration?: number | undefined;
}
export interface WaitCancelledDetails {
    Error?: EventError | undefined;
}
export interface StepStartedDetails {
}
export interface RetryDetails {
    CurrentAttempt?: number | undefined;
    NextAttemptDelaySeconds?: number | undefined;
}
export interface StepSucceededDetails {
    Result: EventResult;
    RetryDetails: RetryDetails;
}
export interface StepFailedDetails {
    Error: EventError;
    RetryDetails: RetryDetails;
}
export interface ChainedInvokeStartedDetails {
    FunctionName: string;
    TenantId?: string | undefined;
    Input?: EventInput | undefined;
    ExecutedVersion?: string | undefined;
    DurableExecutionArn?: string | undefined;
}
export interface ChainedInvokeSucceededDetails {
    Result: EventResult;
}
export interface ChainedInvokeFailedDetails {
    Error: EventError;
}
export interface ChainedInvokeTimedOutDetails {
    Error: EventError;
}
export interface ChainedInvokeStoppedDetails {
    Error: EventError;
}
export interface CallbackStartedDetails {
    CallbackId: string;
    HeartbeatTimeout?: number | undefined;
    Timeout?: number | undefined;
}
export interface CallbackSucceededDetails {
    Result: EventResult;
}
export interface CallbackFailedDetails {
    Error: EventError;
}
export interface CallbackTimedOutDetails {
    Error: EventError;
}
export interface InvocationCompletedDetails {
    StartTimestamp: Date;
    EndTimestamp: Date;
    RequestId: string;
    Error?: EventError | undefined;
}
export interface EventPauseReason {
    Payload?: string | redacted.Redacted<string> | undefined;
    Truncated?: boolean | undefined;
}
export interface ExecutionPausedDetails {
    PauseRequestTimestamp: Date;
    Reason?: EventPauseReason | undefined;
    ExecutionTimeoutPaused: boolean;
}
export type ResumeReason = string | redacted.Redacted<string>;
export interface EventResumeReason {
    Payload?: string | redacted.Redacted<string> | undefined;
    Truncated?: boolean | undefined;
}
export interface ExecutionResumedDetails {
    ResumeRequestTimestamp: Date;
    Reason?: EventResumeReason | undefined;
}
export interface Event {
    EventType?: EventType | undefined;
    SubType?: string | undefined;
    EventId?: number | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    EventTimestamp?: Date | undefined;
    ParentId?: string | undefined;
    ExecutionStartedDetails?: ExecutionStartedDetails | undefined;
    ExecutionSucceededDetails?: ExecutionSucceededDetails | undefined;
    ExecutionFailedDetails?: ExecutionFailedDetails | undefined;
    ExecutionTimedOutDetails?: ExecutionTimedOutDetails | undefined;
    ExecutionStoppedDetails?: ExecutionStoppedDetails | undefined;
    ContextStartedDetails?: ContextStartedDetails | undefined;
    ContextSucceededDetails?: ContextSucceededDetails | undefined;
    ContextFailedDetails?: ContextFailedDetails | undefined;
    WaitStartedDetails?: WaitStartedDetails | undefined;
    WaitSucceededDetails?: WaitSucceededDetails | undefined;
    WaitCancelledDetails?: WaitCancelledDetails | undefined;
    StepStartedDetails?: StepStartedDetails | undefined;
    StepSucceededDetails?: StepSucceededDetails | undefined;
    StepFailedDetails?: StepFailedDetails | undefined;
    ChainedInvokeStartedDetails?: ChainedInvokeStartedDetails | undefined;
    ChainedInvokeSucceededDetails?: ChainedInvokeSucceededDetails | undefined;
    ChainedInvokeFailedDetails?: ChainedInvokeFailedDetails | undefined;
    ChainedInvokeTimedOutDetails?: ChainedInvokeTimedOutDetails | undefined;
    ChainedInvokeStoppedDetails?: ChainedInvokeStoppedDetails | undefined;
    CallbackStartedDetails?: CallbackStartedDetails | undefined;
    CallbackSucceededDetails?: CallbackSucceededDetails | undefined;
    CallbackFailedDetails?: CallbackFailedDetails | undefined;
    CallbackTimedOutDetails?: CallbackTimedOutDetails | undefined;
    InvocationCompletedDetails?: InvocationCompletedDetails | undefined;
    ExecutionPausedDetails?: ExecutionPausedDetails | undefined;
    ExecutionResumedDetails?: ExecutionResumedDetails | undefined;
}
export type Events = Event[];
export interface GetDurableExecutionHistoryResponse {
    Events: Event[];
    NextMarker?: string | undefined;
}
export interface GetDurableExecutionStateRequest {
    DurableExecutionArn: string;
    CheckpointToken: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface GetDurableExecutionStateResponse {
    Operations: Operation[];
    NextMarker?: string | undefined;
}
export interface GetEventSourceMappingRequest {
    UUID: string;
}
export interface GetFunctionRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export type SensitiveStringOnServerOnly = string;
export interface ResolvedS3Object {
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3ObjectVersion?: string | undefined;
}
export interface FunctionCodeLocationError {
    ErrorCode?: string | undefined;
    Message?: string | redacted.Redacted<string> | undefined;
}
export interface FunctionCodeLocation {
    RepositoryType?: string | undefined;
    Location?: string | undefined;
    ImageUri?: string | undefined;
    ResolvedImageUri?: string | undefined;
    ResolvedS3Object?: ResolvedS3Object | undefined;
    SourceKMSKeyArn?: string | undefined;
    Error?: FunctionCodeLocationError | undefined;
}
export type TagsErrorCode = string;
export type TagsErrorMessage = string;
export interface TagsError {
    ErrorCode: string;
    Message: string;
}
export type ReservedConcurrentExecutions = number;
export interface Concurrency {
    ReservedConcurrentExecutions?: number | undefined;
}
export interface GetFunctionResponse {
    Configuration?: FunctionConfiguration | undefined;
    Code?: FunctionCodeLocation | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    TagsError?: TagsError | undefined;
    Concurrency?: Concurrency | undefined;
}
export interface GetFunctionCodeSigningConfigRequest {
    FunctionName: string;
}
export interface GetFunctionCodeSigningConfigResponse {
    CodeSigningConfigArn: string;
    FunctionName: string;
}
export interface GetFunctionConcurrencyRequest {
    FunctionName: string;
}
export interface GetFunctionConcurrencyResponse {
    ReservedConcurrentExecutions?: number | undefined;
}
export interface GetFunctionConfigurationRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export interface GetFunctionEventInvokeConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export type MaximumRetryAttempts = number;
export type MaximumEventAgeInSeconds = number;
export interface FunctionEventInvokeConfig {
    LastModified?: Date | undefined;
    FunctionArn?: string | undefined;
    MaximumRetryAttempts?: number | undefined;
    MaximumEventAgeInSeconds?: number | undefined;
    DestinationConfig?: DestinationConfig | undefined;
}
export type UnqualifiedFunctionName = string;
export interface GetFunctionRecursionConfigRequest {
    FunctionName: string;
}
export type RecursiveLoop = "Allow" | "Terminate" | (string & {});
export interface GetFunctionRecursionConfigResponse {
    RecursiveLoop?: RecursiveLoop | undefined;
}
export type PublishedFunctionQualifier = string;
export interface GetFunctionScalingConfigRequest {
    FunctionName: string;
    Qualifier: string;
}
export type FunctionScalingConfigExecutionEnvironments = number;
export interface FunctionScalingConfig {
    MinExecutionEnvironments?: number | undefined;
    MaxExecutionEnvironments?: number | undefined;
}
export interface GetFunctionScalingConfigResponse {
    FunctionArn?: string | undefined;
    AppliedFunctionScalingConfig?: FunctionScalingConfig | undefined;
    RequestedFunctionScalingConfig?: FunctionScalingConfig | undefined;
}
export interface GetFunctionUrlConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export interface GetFunctionUrlConfigResponse {
    FunctionUrl: string;
    FunctionArn: string;
    AuthType: FunctionUrlAuthType;
    Cors?: Cors | undefined;
    CreationTime: string;
    LastModifiedTime: string;
    InvokeMode?: InvokeMode | undefined;
}
export interface GetLayerVersionRequest {
    LayerName: string;
    VersionNumber: number;
}
export interface LayerVersionContentOutput {
    Location?: string | undefined;
    CodeSha256?: string | undefined;
    CodeSize?: number | undefined;
    SigningProfileVersionArn?: string | undefined;
    SigningJobArn?: string | undefined;
    ResolvedS3Object?: ResolvedS3Object | undefined;
}
export type LayerArn = string;
export type CompatibleArchitectures = Architecture[];
export type CompatibleRuntimes = Runtime[];
export type LicenseInfo = string;
export interface GetLayerVersionResponse {
    Content?: LayerVersionContentOutput | undefined;
    LayerArn?: string | undefined;
    LayerVersionArn?: string | undefined;
    Description?: string | undefined;
    CreatedDate?: string | undefined;
    Version?: number | undefined;
    CompatibleArchitectures?: Architecture[] | undefined;
    CompatibleRuntimes?: Runtime[] | undefined;
    LicenseInfo?: string | undefined;
}
export interface GetLayerVersionByArnRequest {
    Arn: string;
}
export interface GetLayerVersionPolicyRequest {
    LayerName: string;
    VersionNumber: number;
}
export interface GetLayerVersionPolicyResponse {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface GetPolicyRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export interface GetPolicyResponse {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface GetProvisionedConcurrencyConfigRequest {
    FunctionName: string;
    Qualifier: string;
}
export type PositiveInteger = number;
export type NonNegativeInteger = number;
export type ProvisionedConcurrencyStatusEnum = "IN_PROGRESS" | "READY" | "FAILED" | (string & {});
export interface GetProvisionedConcurrencyConfigResponse {
    RequestedProvisionedConcurrentExecutions?: number | undefined;
    AvailableProvisionedConcurrentExecutions?: number | undefined;
    AllocatedProvisionedConcurrentExecutions?: number | undefined;
    Status?: ProvisionedConcurrencyStatusEnum | undefined;
    StatusReason?: string | undefined;
    LastModified?: string | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export type ResourcePolicy = string;
export interface GetResourcePolicyResponse {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface GetRuntimeManagementConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
}
export type UpdateRuntimeOn = "Auto" | "Manual" | "FunctionUpdate" | (string & {});
export interface GetRuntimeManagementConfigResponse {
    UpdateRuntimeOn?: UpdateRuntimeOn | undefined;
    FunctionArn?: string | undefined;
    RuntimeVersionArn?: string | undefined;
}
export type InvocationType = "Event" | "RequestResponse" | "DryRun" | (string & {});
export type LogType = "None" | "Tail" | (string & {});
export interface InvocationRequest {
    FunctionName: string;
    InvocationType?: InvocationType | undefined;
    LogType?: LogType | undefined;
    ClientContext?: string | undefined;
    DurableExecutionName?: string | undefined;
    Payload?: T.StreamingInputBody | undefined;
    Qualifier?: string | undefined;
    TenantId?: string | undefined;
}
export interface InvocationResponse {
    StatusCode?: number | undefined;
    FunctionError?: string | undefined;
    LogResult?: string | undefined;
    Payload?: T.StreamingOutputBody | undefined;
    ExecutedVersion?: string | undefined;
    DurableExecutionArn?: string | undefined;
}
export interface InvokeAsyncRequest {
    FunctionName: string;
    InvokeArgs: T.StreamingInputBody;
}
export type HttpStatus = number;
export interface InvokeAsyncResponse {
    Status?: number | undefined;
}
export type ResponseStreamingInvocationType = "RequestResponse" | "DryRun" | (string & {});
export interface InvokeWithResponseStreamRequest {
    FunctionName: string;
    LogType?: LogType | undefined;
    ClientContext?: string | undefined;
    Qualifier?: string | undefined;
    Payload?: T.StreamingInputBody | undefined;
    TenantId?: string | undefined;
    InvocationType?: ResponseStreamingInvocationType | undefined;
}
export interface InvokeResponseStreamUpdate {
    Payload?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export interface InvokeWithResponseStreamCompleteEvent {
    ErrorCode?: string | undefined;
    ErrorDetails?: string | undefined;
    LogResult?: string | undefined;
}
export type InvokeWithResponseStreamResponseEvent = {
    PayloadChunk: InvokeResponseStreamUpdate;
    InvokeComplete?: undefined;
} | {
    PayloadChunk?: undefined;
    InvokeComplete: InvokeWithResponseStreamCompleteEvent;
};
export interface InvokeWithResponseStreamResponse {
    StatusCode?: number | undefined;
    ExecutedVersion?: string | undefined;
    EventStream?: stream.Stream<InvokeWithResponseStreamResponseEvent, Error, never> | undefined;
    ResponseStreamContentType?: string | undefined;
}
export type MaxListItems = number;
export interface ListAliasesRequest {
    FunctionName: string;
    FunctionVersion?: string | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type AliasList = AliasConfiguration[];
export interface ListAliasesResponse {
    NextMarker?: string | undefined;
    Aliases?: AliasConfiguration[] | undefined;
}
export type MaxFiftyListItems = number;
export interface ListCapacityProvidersRequest {
    State?: CapacityProviderState | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type CapacityProvidersList = CapacityProvider[];
export interface ListCapacityProvidersResponse {
    CapacityProviders: CapacityProvider[];
    NextMarker?: string | undefined;
}
export interface ListCodeSigningConfigsRequest {
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type CodeSigningConfigList = CodeSigningConfig[];
export interface ListCodeSigningConfigsResponse {
    NextMarker?: string | undefined;
    CodeSigningConfigs?: CodeSigningConfig[] | undefined;
}
export type ExecutionStatusList = ExecutionStatus[];
export interface ListDurableExecutionsByFunctionRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
    DurableExecutionName?: string | undefined;
    Statuses?: ExecutionStatus[] | undefined;
    StartedAfter?: Date | undefined;
    StartedBefore?: Date | undefined;
    ReverseOrder?: boolean | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface Execution {
    DurableExecutionArn: string;
    DurableExecutionName: string;
    FunctionArn: string;
    Status: ExecutionStatus;
    StartTimestamp: Date;
    EndTimestamp?: Date | undefined;
    KMSKeyArn?: string | undefined;
}
export type DurableExecutions = Execution[];
export interface ListDurableExecutionsByFunctionResponse {
    DurableExecutions?: Execution[] | undefined;
    NextMarker?: string | undefined;
}
export interface ListEventSourceMappingsRequest {
    EventSourceArn?: string | undefined;
    FunctionName?: string | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type EventSourceMappingsList = EventSourceMappingConfiguration[];
export interface ListEventSourceMappingsResponse {
    NextMarker?: string | undefined;
    EventSourceMappings?: EventSourceMappingConfiguration[] | undefined;
}
export type MaxFunctionEventInvokeConfigListItems = number;
export interface ListFunctionEventInvokeConfigsRequest {
    FunctionName: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type FunctionEventInvokeConfigList = FunctionEventInvokeConfig[];
export interface ListFunctionEventInvokeConfigsResponse {
    FunctionEventInvokeConfigs?: FunctionEventInvokeConfig[] | undefined;
    NextMarker?: string | undefined;
}
export type MasterRegion = string;
export type FunctionVersion = "ALL" | (string & {});
export interface ListFunctionsRequest {
    MasterRegion?: string | undefined;
    FunctionVersion?: FunctionVersion | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type FunctionList = FunctionConfiguration[];
export interface ListFunctionsResponse {
    NextMarker?: string | undefined;
    Functions?: FunctionConfiguration[] | undefined;
}
export interface ListFunctionsByCodeSigningConfigRequest {
    CodeSigningConfigArn: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type FunctionArnList = string[];
export interface ListFunctionsByCodeSigningConfigResponse {
    NextMarker?: string | undefined;
    FunctionArns?: string[] | undefined;
}
export type MaxItems = number;
export interface ListFunctionUrlConfigsRequest {
    FunctionName: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface FunctionUrlConfig {
    FunctionUrl: string;
    FunctionArn: string;
    CreationTime: string;
    LastModifiedTime: string;
    Cors?: Cors | undefined;
    AuthType: FunctionUrlAuthType;
    InvokeMode?: InvokeMode | undefined;
}
export type FunctionUrlConfigList = FunctionUrlConfig[];
export interface ListFunctionUrlConfigsResponse {
    FunctionUrlConfigs: FunctionUrlConfig[];
    NextMarker?: string | undefined;
}
export interface ListFunctionVersionsByCapacityProviderRequest {
    CapacityProviderName: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface FunctionVersionsByCapacityProviderListItem {
    FunctionArn: string;
    State: State;
}
export type FunctionVersionsByCapacityProviderList = FunctionVersionsByCapacityProviderListItem[];
export interface ListFunctionVersionsByCapacityProviderResponse {
    CapacityProviderArn: string;
    FunctionVersions: FunctionVersionsByCapacityProviderListItem[];
    NextMarker?: string | undefined;
}
export type MaxLayerListItems = number;
export interface ListLayersRequest {
    CompatibleArchitecture?: Architecture | undefined;
    CompatibleRuntime?: Runtime | undefined;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type LayerName = string;
export interface LayerVersionsListItem {
    LayerVersionArn?: string | undefined;
    Version?: number | undefined;
    Description?: string | undefined;
    CreatedDate?: string | undefined;
    CompatibleArchitectures?: Architecture[] | undefined;
    CompatibleRuntimes?: Runtime[] | undefined;
    LicenseInfo?: string | undefined;
}
export interface LayersListItem {
    LayerName?: string | undefined;
    LayerArn?: string | undefined;
    LatestMatchingVersion?: LayerVersionsListItem | undefined;
}
export type LayersList = LayersListItem[];
export interface ListLayersResponse {
    NextMarker?: string | undefined;
    Layers?: LayersListItem[] | undefined;
}
export interface ListLayerVersionsRequest {
    CompatibleArchitecture?: Architecture | undefined;
    CompatibleRuntime?: Runtime | undefined;
    LayerName: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export type LayerVersionsList = LayerVersionsListItem[];
export interface ListLayerVersionsResponse {
    NextMarker?: string | undefined;
    LayerVersions?: LayerVersionsListItem[] | undefined;
}
export type MaxProvisionedConcurrencyConfigListItems = number;
export interface ListProvisionedConcurrencyConfigsRequest {
    FunctionName: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface ProvisionedConcurrencyConfigListItem {
    FunctionArn?: string | undefined;
    RequestedProvisionedConcurrentExecutions?: number | undefined;
    AvailableProvisionedConcurrentExecutions?: number | undefined;
    AllocatedProvisionedConcurrentExecutions?: number | undefined;
    Status?: ProvisionedConcurrencyStatusEnum | undefined;
    StatusReason?: string | undefined;
    LastModified?: string | undefined;
}
export type ProvisionedConcurrencyConfigList = ProvisionedConcurrencyConfigListItem[];
export interface ListProvisionedConcurrencyConfigsResponse {
    ProvisionedConcurrencyConfigs?: ProvisionedConcurrencyConfigListItem[] | undefined;
    NextMarker?: string | undefined;
}
export type TaggableResource = string;
export interface ListTagsRequest {
    Resource: string;
}
export interface ListTagsResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListVersionsByFunctionRequest {
    FunctionName: string;
    Marker?: string | undefined;
    MaxItems?: number | undefined;
}
export interface ListVersionsByFunctionResponse {
    NextMarker?: string | undefined;
    Versions?: FunctionConfiguration[] | undefined;
}
export interface PauseDurableExecutionRequest {
    DurableExecutionArn: string;
    ClientToken?: string | undefined;
    Reason?: string | redacted.Redacted<string> | undefined;
    ExecutionTimeoutPaused?: boolean | undefined;
}
export interface PauseDurableExecutionResponse {
}
export interface LayerVersionContentInput {
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3ObjectVersion?: string | undefined;
    S3ObjectStorageMode?: S3ObjectStorageMode | undefined;
    ZipFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export interface PublishLayerVersionRequest {
    LayerName: string;
    Description?: string | undefined;
    Content: LayerVersionContentInput;
    CompatibleArchitectures?: Architecture[] | undefined;
    CompatibleRuntimes?: Runtime[] | undefined;
    LicenseInfo?: string | undefined;
}
export interface PublishLayerVersionResponse {
    Content?: LayerVersionContentOutput | undefined;
    LayerArn?: string | undefined;
    LayerVersionArn?: string | undefined;
    Description?: string | undefined;
    CreatedDate?: string | undefined;
    Version?: number | undefined;
    CompatibleArchitectures?: Architecture[] | undefined;
    CompatibleRuntimes?: Runtime[] | undefined;
    LicenseInfo?: string | undefined;
}
export interface PublishVersionRequest {
    FunctionName: string;
    CodeSha256?: string | undefined;
    Description?: string | undefined;
    RevisionId?: string | undefined;
    PublishTo?: FunctionVersionLatestPublished | undefined;
}
export interface PutFunctionCodeSigningConfigRequest {
    CodeSigningConfigArn: string;
    FunctionName: string;
}
export interface PutFunctionCodeSigningConfigResponse {
    CodeSigningConfigArn: string;
    FunctionName: string;
}
export interface PutFunctionConcurrencyRequest {
    FunctionName: string;
    ReservedConcurrentExecutions: number;
}
export interface PutFunctionEventInvokeConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
    MaximumRetryAttempts?: number | undefined;
    MaximumEventAgeInSeconds?: number | undefined;
    DestinationConfig?: DestinationConfig | undefined;
}
export interface PutFunctionRecursionConfigRequest {
    FunctionName: string;
    RecursiveLoop: RecursiveLoop;
}
export interface PutFunctionRecursionConfigResponse {
    RecursiveLoop?: RecursiveLoop | undefined;
}
export interface PutFunctionScalingConfigRequest {
    FunctionName: string;
    Qualifier: string;
    FunctionScalingConfig?: FunctionScalingConfig | undefined;
}
export interface PutFunctionScalingConfigResponse {
    FunctionState?: State | undefined;
}
export interface PutProvisionedConcurrencyConfigRequest {
    FunctionName: string;
    Qualifier: string;
    ProvisionedConcurrentExecutions: number;
}
export interface PutProvisionedConcurrencyConfigResponse {
    RequestedProvisionedConcurrentExecutions?: number | undefined;
    AllocatedProvisionedConcurrentExecutions?: number | undefined;
    AvailableProvisionedConcurrentExecutions?: number | undefined;
    Status?: ProvisionedConcurrencyStatusEnum | undefined;
    StatusReason?: string | undefined;
    LastModified?: string | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    Policy: string;
    RevisionId?: string | undefined;
}
export interface PutResourcePolicyResponse {
    Policy?: string | undefined;
    RevisionId?: string | undefined;
}
export interface PutRuntimeManagementConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
    UpdateRuntimeOn: UpdateRuntimeOn;
    RuntimeVersionArn?: string | undefined;
}
export interface PutRuntimeManagementConfigResponse {
    UpdateRuntimeOn: UpdateRuntimeOn;
    FunctionArn: string;
    RuntimeVersionArn?: string | undefined;
}
export interface RemoveLayerVersionPermissionRequest {
    LayerName: string;
    VersionNumber: number;
    StatementId: string;
    RevisionId?: string | undefined;
}
export interface RemoveLayerVersionPermissionResponse {
}
export type NamespacedStatementId = string;
export interface RemovePermissionRequest {
    FunctionName: string;
    StatementId: string;
    Qualifier?: string | undefined;
    RevisionId?: string | undefined;
}
export interface RemovePermissionResponse {
}
export interface ResumeDurableExecutionRequest {
    DurableExecutionArn: string;
    ClientToken?: string | undefined;
    Reason?: string | redacted.Redacted<string> | undefined;
}
export interface ResumeDurableExecutionResponse {
}
export interface SendDurableExecutionCallbackFailureRequest {
    CallbackId: string;
    Error?: ErrorObject | undefined;
}
export interface SendDurableExecutionCallbackFailureResponse {
}
export interface SendDurableExecutionCallbackHeartbeatRequest {
    CallbackId: string;
}
export interface SendDurableExecutionCallbackHeartbeatResponse {
}
export interface SendDurableExecutionCallbackSuccessRequest {
    CallbackId: string;
    Result?: T.StreamingInputBody | undefined;
}
export interface SendDurableExecutionCallbackSuccessResponse {
}
export interface StopDurableExecutionRequest {
    DurableExecutionArn: string;
    Error?: ErrorObject | undefined;
}
export interface StopDurableExecutionResponse {
    StopTimestamp: Date;
}
export interface TagResourceRequest {
    Resource: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    Resource: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAliasRequest {
    FunctionName: string;
    Name: string;
    FunctionVersion?: string | undefined;
    Description?: string | undefined;
    RoutingConfig?: AliasRoutingConfiguration | undefined;
    RevisionId?: string | undefined;
}
export interface UpdateCapacityProviderRequest {
    CapacityProviderName: string;
    CapacityProviderScalingConfig?: CapacityProviderScalingConfig | undefined;
    PropagateTags?: PropagateTags | undefined;
    TelemetryConfig?: CapacityProviderTelemetryConfig | undefined;
}
export interface UpdateCapacityProviderResponse {
    CapacityProvider: CapacityProvider;
}
export interface UpdateCodeSigningConfigRequest {
    CodeSigningConfigArn: string;
    Description?: string | undefined;
    AllowedPublishers?: AllowedPublishers | undefined;
    CodeSigningPolicies?: CodeSigningPolicies | undefined;
}
export interface UpdateCodeSigningConfigResponse {
    CodeSigningConfig: CodeSigningConfig;
}
export interface UpdateEventSourceMappingRequest {
    UUID: string;
    FunctionName?: string | undefined;
    Enabled?: boolean | undefined;
    BatchSize?: number | undefined;
    FilterCriteria?: FilterCriteria | undefined;
    KMSKeyArn?: string | undefined;
    MetricsConfig?: EventSourceMappingMetricsConfig | undefined;
    LoggingConfig?: EventSourceMappingLoggingConfig | undefined;
    ScalingConfig?: ScalingConfig | undefined;
    MaximumBatchingWindowInSeconds?: number | undefined;
    ParallelizationFactor?: number | undefined;
    DestinationConfig?: DestinationConfig | undefined;
    MaximumRecordAgeInSeconds?: number | undefined;
    BisectBatchOnFunctionError?: boolean | undefined;
    MaximumRetryAttempts?: number | undefined;
    TumblingWindowInSeconds?: number | undefined;
    SourceAccessConfigurations?: SourceAccessConfiguration[] | undefined;
    FunctionResponseTypes?: FunctionResponseType[] | undefined;
    AmazonManagedKafkaEventSourceConfig?: AmazonManagedKafkaEventSourceConfig | undefined;
    SelfManagedKafkaEventSourceConfig?: SelfManagedKafkaEventSourceConfig | undefined;
    DocumentDBEventSourceConfig?: DocumentDBEventSourceConfig | undefined;
    ProvisionedPollerConfig?: ProvisionedPollerConfig | undefined;
}
export interface UpdateFunctionCodeRequest {
    FunctionName: string;
    ZipFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3ObjectVersion?: string | undefined;
    S3ObjectStorageMode?: S3ObjectStorageMode | undefined;
    ImageUri?: string | undefined;
    Architectures?: Architecture[] | undefined;
    Publish?: boolean | undefined;
    PublishTo?: FunctionVersionLatestPublished | undefined;
    DryRun?: boolean | undefined;
    RevisionId?: string | undefined;
    SourceKMSKeyArn?: string | undefined;
}
export interface UpdateFunctionConfigurationRequest {
    FunctionName: string;
    Role?: string | undefined;
    Handler?: string | undefined;
    Description?: string | undefined;
    Timeout?: number | undefined;
    MemorySize?: number | undefined;
    VpcConfig?: VpcConfig | undefined;
    Environment?: Environment | undefined;
    Runtime?: Runtime | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    KMSKeyArn?: string | undefined;
    TracingConfig?: TracingConfig | undefined;
    RevisionId?: string | undefined;
    Layers?: string[] | undefined;
    FileSystemConfigs?: FileSystemConfig[] | undefined;
    ImageConfig?: ImageConfig | undefined;
    EphemeralStorage?: EphemeralStorage | undefined;
    SnapStart?: SnapStart | undefined;
    LoggingConfig?: LoggingConfig | undefined;
    CapacityProviderConfig?: CapacityProviderConfig | undefined;
    DurableConfig?: DurableConfig | undefined;
    RuntimeConfig?: FunctionRuntimeConfig | undefined;
    AcceleratorConfig?: AcceleratorConfig | undefined;
}
export interface UpdateFunctionEventInvokeConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
    MaximumRetryAttempts?: number | undefined;
    MaximumEventAgeInSeconds?: number | undefined;
    DestinationConfig?: DestinationConfig | undefined;
}
export interface UpdateFunctionUrlConfigRequest {
    FunctionName: string;
    Qualifier?: string | undefined;
    AuthType?: FunctionUrlAuthType | undefined;
    Cors?: Cors | undefined;
    InvokeMode?: InvokeMode | undefined;
}
export interface UpdateFunctionUrlConfigResponse {
    FunctionUrl: string;
    FunctionArn: string;
    AuthType: FunctionUrlAuthType;
    Cors?: Cors | undefined;
    CreationTime: string;
    LastModifiedTime: string;
    InvokeMode?: InvokeMode | undefined;
}
export type ThrottleReason = "ConcurrentInvocationLimitExceeded" | "FunctionInvocationRateLimitExceeded" | "ReservedFunctionConcurrentInvocationLimitExceeded" | "ReservedFunctionInvocationRateLimitExceeded" | "CallerRateLimitExceeded" | "ConcurrentSnapshotCreateLimitExceeded" | (string & {});
export type AddLayerVersionPermissionError = InvalidParameterValueException | PolicyLengthExceededException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Adds permissions to the resource-based policy of a version of an Lambda layer. Use this action to grant layer usage permission to other accounts. You can grant permission to a single account, all accounts in an organization, or all Amazon Web Services accounts.
 *
 * To revoke permission, call RemoveLayerVersionPermission with the statement ID that you specified when you added it.
 */
export declare const addLayerVersionPermission: API.OperationMethod<AddLayerVersionPermissionRequest & RegionInput, AddLayerVersionPermissionResponse, AddLayerVersionPermissionError, Credentials | HttpClient.HttpClient>;
export type AddPermissionError = InvalidParameterValueException | PolicyLengthExceededException | PreconditionFailedException | PublicPolicyException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Grants a principal permission to use a function. You can apply the policy at the function level, or specify a qualifier to restrict access to a single version or alias. If you use a qualifier, the invoker must use the full Amazon Resource Name (ARN) of that version or alias to invoke the function. Note: Lambda does not support adding policies to version $LATEST.
 *
 * To grant permission to another account, specify the account ID as the `Principal`. To grant permission to an organization defined in Organizations, specify the organization ID as the `PrincipalOrgID`. For Amazon Web Services services, the principal is a domain-style identifier that the service defines, such as `s3.amazonaws.com` or `sns.amazonaws.com`. For Amazon Web Services services, you can also specify the ARN of the associated resource as the `SourceArn`. If you grant permission to a service principal without specifying the source, other accounts could potentially configure resources in their account to invoke your Lambda function.
 *
 * This operation adds a statement to a resource-based permissions policy for the function. For more information about function policies, see Using resource-based policies for Lambda.
 */
export declare const addPermission: API.OperationMethod<AddPermissionRequest & RegionInput, AddPermissionResponse, AddPermissionError, Credentials | HttpClient.HttpClient>;
export type CheckpointDurableExecutionError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Saves the progress of a durable function execution during runtime. This API is used by the Lambda durable functions SDK to checkpoint completed steps and schedule asynchronous operations. You typically don't need to call this API directly as the SDK handles checkpointing automatically.
 *
 * Each checkpoint operation consumes the current checkpoint token and returns a new one for the next checkpoint. This ensures that checkpoints are applied in the correct order and prevents duplicate or out-of-order state updates.
 */
export declare const checkpointDurableExecution: API.OperationMethod<CheckpointDurableExecutionRequest & RegionInput, CheckpointDurableExecutionResponse, CheckpointDurableExecutionError, Credentials | HttpClient.HttpClient>;
export type CreateAliasError = AliasLimitExceededException | InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Creates an alias for a Lambda Event Function version. Use aliases to provide clients with a function identifier that you can update to invoke a different version.
 *
 * You can also map an alias to split invocation requests between two versions. Use the `RoutingConfig` parameter to specify a second version and the percentage of invocation requests that it receives.
 */
export declare const createAlias: API.OperationMethod<CreateAliasRequest & RegionInput, AliasConfiguration, CreateAliasError, Credentials | HttpClient.HttpClient>;
export type CreateCapacityProviderError = CapacityProviderLimitExceededException | InvalidParameterValueException | ResourceConflictException | ServiceException | TooManyRequestsException | CapacityProviderOperatorRoleNotAssumable | CapacityProviderSecurityGroupNotFound | CapacityProviderSubnetNotFound | CommonErrors;
/**
 * Creates a capacity provider that manages compute resources for Lambda Event Functions
 */
export declare const createCapacityProvider: API.OperationMethod<CreateCapacityProviderRequest & RegionInput, CreateCapacityProviderResponse, CreateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type CreateCodeSigningConfigError = InvalidParameterValueException | ServiceException | CommonErrors;
/**
 * Creates a code signing configuration. A code signing configuration defines a list of allowed signing profiles and defines the code-signing validation policy (action to be taken if deployment validation checks fail).
 */
export declare const createCodeSigningConfig: API.OperationMethod<CreateCodeSigningConfigRequest & RegionInput, CreateCodeSigningConfigResponse, CreateCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type CreateEventSourceMappingError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ResourceInUseException | ExecutionRoleNotAssumable | ExecutionRoleMissingPermissions | QueueVisibilityTimeoutTooShort | CommonErrors;
/**
 * Creates a mapping between an event source and an Lambda Event Function. Lambda reads items from the event source and invokes the function.
 *
 * For details about how to configure different event sources, see the following topics.
 *
 * - Amazon DynamoDB Streams
 *
 * - Amazon Kinesis
 *
 * - Amazon SQS
 *
 * - Amazon MQ and RabbitMQ
 *
 * - Amazon MSK
 *
 * - Apache Kafka
 *
 * - Amazon DocumentDB
 *
 * The following error handling options are available for stream sources (DynamoDB, Kinesis, Amazon MSK, and self-managed Apache Kafka):
 *
 * - `BisectBatchOnFunctionError` - If the function returns an error, split the batch in two and retry.
 *
 * - `MaximumRecordAgeInSeconds` - Discard records older than the specified age. The default value is infinite (-1). When set to infinite (-1), failed records are retried until the record expires
 *
 * - `MaximumRetryAttempts` - Discard records after the specified number of retries. The default value is infinite (-1). When set to infinite (-1), failed records are retried until the record expires.
 *
 * - `OnFailure` - Send discarded records to an Amazon SQS queue, Amazon SNS topic, Kafka topic, or Amazon S3 bucket. For more information, see Adding a destination.
 *
 * The following option is available only for DynamoDB and Kinesis event sources:
 *
 * - `ParallelizationFactor` - Process multiple batches from each shard concurrently.
 *
 * For information about which configuration parameters apply to each event source, see the following topics.
 *
 * - Amazon DynamoDB Streams
 *
 * - Amazon Kinesis
 *
 * - Amazon SQS
 *
 * - Amazon MQ and RabbitMQ
 *
 * - Amazon MSK
 *
 * - Apache Kafka
 *
 * - Amazon DocumentDB
 */
export declare const createEventSourceMapping: API.OperationMethod<CreateEventSourceMappingRequest & RegionInput, EventSourceMappingConfiguration, CreateEventSourceMappingError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionError = CodeSigningConfigNotFoundException | CodeStorageExceededException | CodeVerificationFailedException | FunctionVersionsPerCapacityProviderLimitExceededException | InvalidCodeSignatureException | InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | LambdaInternalKmsError | ExecutionRoleNotAssumable | ExecutionRoleMissingVpcPermissions | KmsGrantPrincipalNotReady | SecurityGroupNotFound | CommonErrors;
/**
 * Creates a Lambda Event Function. To create a function, you need a deployment package and an execution role. The deployment package is a .zip file archive or container image that contains your function code. The execution role grants the function permission to use Amazon Web Services services, such as Amazon CloudWatch Logs for log streaming and X-Ray for request tracing.
 *
 * If the deployment package is a container image, then you set the package type to `Image`. For a container image, the code property must include the URI of a container image in the Amazon ECR registry. You do not need to specify the handler and runtime properties.
 *
 * If the deployment package is a .zip file archive, then you set the package type to `Zip`. For a .zip file archive, the code property specifies the location of the .zip file. You must also specify the handler and runtime properties. The code in the deployment package must be compatible with the target instruction set architecture of the function (`x86-64` or `arm64`). If you do not specify the architecture, then the default value is `x86-64`.
 *
 * When you create a function, Lambda provisions an instance of the function and its supporting resources. If your function connects to a VPC, this process can take a minute or so. During this time, you can't invoke or modify the function. The `State`, `StateReason`, and `StateReasonCode` fields in the response from GetFunctionConfiguration indicate when the function is ready to invoke. For more information, see Lambda function states.
 *
 * A function has an unpublished version, and can have published versions and aliases. The unpublished version changes when you update your function's code and configuration. A published version is a snapshot of your function code and configuration that can't be changed. An alias is a named resource that maps to a version, and can be changed to map to a different version. Use the `Publish` parameter to create version `1` of your function from its initial configuration.
 *
 * The other parameters let you configure version-specific and function-level settings. You can modify version-specific settings later with UpdateFunctionConfiguration. Function-level settings apply to both the unpublished and published versions of the function, and include tags (TagResource) and per-function concurrency limits (PutFunctionConcurrency).
 *
 * You can use code signing if your deployment package is a .zip file archive. To enable code signing for this function, specify the ARN of a code-signing configuration. When a user attempts to deploy a code package with UpdateFunctionCode, Lambda checks that the code package has a valid signature from a trusted publisher. The code-signing configuration includes set of signing profiles, which define the trusted publishers for this function.
 *
 * If another Amazon Web Services account or an Amazon Web Services service invokes your function, use AddPermission to grant permission by creating a resource-based Identity and Access Management (IAM) policy. You can grant permissions at the function level, on a version, or on an alias.
 *
 * To invoke your function directly, use Invoke. To invoke your function in response to events in other Amazon Web Services services, create an event source mapping (CreateEventSourceMapping), or configure a function trigger in the other service. For more information, see Invoking Lambda functions.
 */
export declare const createFunction: API.OperationMethod<CreateFunctionRequest & RegionInput, FunctionConfiguration, CreateFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionUrlConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Creates a Lambda function URL with the specified configuration parameters. A function URL is a dedicated HTTP(S) endpoint that you can use to invoke your function.
 */
export declare const createFunctionUrlConfig: API.OperationMethod<CreateFunctionUrlConfigRequest & RegionInput, CreateFunctionUrlConfigResponse, CreateFunctionUrlConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteAliasError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | CommonErrors;
/**
 * Deletes a Lambda Event Function alias.
 */
export declare const deleteAlias: API.OperationMethod<DeleteAliasRequest & RegionInput, DeleteAliasResponse, DeleteAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteCapacityProviderError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a capacity provider. You cannot delete a capacity provider that is currently being used by Lambda functions.
 */
export declare const deleteCapacityProvider: API.OperationMethod<DeleteCapacityProviderRequest & RegionInput, DeleteCapacityProviderResponse, DeleteCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteCodeSigningConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Deletes the code signing configuration. You can delete the code signing configuration only if no function is using it.
 */
export declare const deleteCodeSigningConfig: API.OperationMethod<DeleteCodeSigningConfigRequest & RegionInput, DeleteCodeSigningConfigResponse, DeleteCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteDurableExecutionError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a completed Lambda durable execution and its data. The execution must be in a terminal state (`SUCCEEDED`, `FAILED`, `STOPPED`, or `TIMED_OUT`). Otherwise, this operation returns a `ResourceConflictException`.
 *
 * The execution has `DELETING` status until the deletion finishes. For more information, see Deleting durable executions.
 */
export declare const deleteDurableExecution: API.OperationMethod<DeleteDurableExecutionRequest & RegionInput, DeleteDurableExecutionResponse, DeleteDurableExecutionError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSourceMappingError = InvalidParameterValueException | ResourceConflictException | ResourceInUseException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an event source mapping. You can get the identifier of a mapping from the output of ListEventSourceMappings.
 *
 * When you delete an event source mapping, it enters a `Deleting` state and might not be completely deleted for several seconds.
 */
export declare const deleteEventSourceMapping: API.OperationMethod<DeleteEventSourceMappingRequest & RegionInput, EventSourceMappingConfiguration, DeleteEventSourceMappingError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a Lambda Event Function. To delete a specific function version, use the `Qualifier` parameter. Otherwise, all versions and aliases are deleted. This doesn't require the user to have explicit permissions for DeleteAlias.
 *
 * A deleted Lambda function cannot be recovered. Ensure that you specify the correct function name and version before deleting.
 *
 * To delete Lambda event source mappings that invoke a function, use DeleteEventSourceMapping. For Amazon Web Services services and resources that invoke your function directly, delete the trigger in the service where you originally configured it.
 */
export declare const deleteFunction: API.OperationMethod<DeleteFunctionRequest & RegionInput, DeleteFunctionResponse, DeleteFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionCodeSigningConfigError = CodeSigningConfigNotFoundException | InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Removes the code signing configuration from the function.
 */
export declare const deleteFunctionCodeSigningConfig: API.OperationMethod<DeleteFunctionCodeSigningConfigRequest & RegionInput, DeleteFunctionCodeSigningConfigResponse, DeleteFunctionCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionConcurrencyError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Removes a concurrent execution limit from a Lambda Event Function.
 */
export declare const deleteFunctionConcurrency: API.OperationMethod<DeleteFunctionConcurrencyRequest & RegionInput, DeleteFunctionConcurrencyResponse, DeleteFunctionConcurrencyError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionEventInvokeConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Deletes the configuration for asynchronous invocation for a function, version, or alias.
 *
 * To configure options for asynchronous invocation, use PutFunctionEventInvokeConfig.
 */
export declare const deleteFunctionEventInvokeConfig: API.OperationMethod<DeleteFunctionEventInvokeConfigRequest & RegionInput, DeleteFunctionEventInvokeConfigResponse, DeleteFunctionEventInvokeConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionUrlConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Deletes a Lambda function URL. When you delete a function URL, you can't recover it. Creating a new function URL results in a different URL address.
 */
export declare const deleteFunctionUrlConfig: API.OperationMethod<DeleteFunctionUrlConfigRequest & RegionInput, DeleteFunctionUrlConfigResponse, DeleteFunctionUrlConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteLayerVersionError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Deletes a version of an Lambda layer. Deleted versions can no longer be viewed or added to functions. To avoid breaking functions, a copy of the version remains in Lambda until no functions refer to it.
 */
export declare const deleteLayerVersion: API.OperationMethod<DeleteLayerVersionRequest & RegionInput, DeleteLayerVersionResponse, DeleteLayerVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteProvisionedConcurrencyConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Deletes the provisioned concurrency configuration for a function.
 */
export declare const deleteProvisionedConcurrencyConfig: API.OperationMethod<DeleteProvisionedConcurrencyConfigRequest & RegionInput, DeleteProvisionedConcurrencyConfigResponse, DeleteProvisionedConcurrencyConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = InvalidParameterValueException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Deletes a resource-based policy from a Lambda resource.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves details about your account's limits and usage in an Amazon Web Services Region.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest & RegionInput, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetAliasError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns details about a Lambda Event Function alias.
 */
export declare const getAlias: API.OperationMethod<GetAliasRequest & RegionInput, AliasConfiguration, GetAliasError, Credentials | HttpClient.HttpClient>;
export type GetCapacityProviderError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves information about a specific capacity provider, including its configuration, state, and associated resources.
 */
export declare const getCapacityProvider: API.OperationMethod<GetCapacityProviderRequest & RegionInput, GetCapacityProviderResponse, GetCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type GetCodeSigningConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Returns information about the specified code signing configuration.
 */
export declare const getCodeSigningConfig: API.OperationMethod<GetCodeSigningConfigRequest & RegionInput, GetCodeSigningConfigResponse, GetCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type GetDurableExecutionError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves detailed information about a specific durable execution, including its current status, input payload, result or error information, and execution metadata such as start time and usage statistics.
 */
export declare const getDurableExecution: API.OperationMethod<GetDurableExecutionRequest & RegionInput, GetDurableExecutionResponse, GetDurableExecutionError, Credentials | HttpClient.HttpClient>;
export type GetDurableExecutionHistoryError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the execution history for a durable execution, showing all the steps, callbacks, and events that occurred during the execution. This provides a detailed audit trail of the execution's progress over time.
 *
 * The history is available while the execution is running and for a retention period after it completes (1-90 days, default 30 days). You can control whether to include execution data such as step results and callback payloads.
 */
export declare const getDurableExecutionHistory: API.PaginatedOperationMethod<GetDurableExecutionHistoryRequest & RegionInput, GetDurableExecutionHistoryResponse, GetDurableExecutionHistoryError, Credentials | HttpClient.HttpClient, Event>;
export type GetDurableExecutionStateError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the current execution state required for the replay process during durable function execution. This API is used by the Lambda durable functions SDK to get state information needed for replay. You typically don't need to call this API directly as the SDK handles state management automatically.
 *
 * The response contains operations ordered by start sequence number in ascending order. Completed operations with children don't include child operation details since they don't need to be replayed.
 */
export declare const getDurableExecutionState: API.PaginatedOperationMethod<GetDurableExecutionStateRequest & RegionInput, GetDurableExecutionStateResponse, GetDurableExecutionStateError, Credentials | HttpClient.HttpClient, Operation>;
export type GetEventSourceMappingError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns details about an event source mapping. You can get the identifier of a mapping from the output of ListEventSourceMappings.
 */
export declare const getEventSourceMapping: API.OperationMethod<GetEventSourceMappingRequest & RegionInput, EventSourceMappingConfiguration, GetEventSourceMappingError, Credentials | HttpClient.HttpClient>;
export type GetFunctionError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about a Lambda Event Function or function version, with a link to download the deployment package that's valid for 10 minutes. If you specify a function version, only details that are specific to that version are returned.
 */
export declare const getFunction: API.OperationMethod<GetFunctionRequest & RegionInput, GetFunctionResponse, GetFunctionError, Credentials | HttpClient.HttpClient>;
export type GetFunctionCodeSigningConfigError = CodeSigningConfigNotFoundException | InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns the code signing configuration for the specified function.
 */
export declare const getFunctionCodeSigningConfig: API.OperationMethod<GetFunctionCodeSigningConfigRequest & RegionInput, GetFunctionCodeSigningConfigResponse, GetFunctionCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type GetFunctionConcurrencyError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Returns details about the reserved concurrency configuration for a function. To set a concurrency limit for a function, use PutFunctionConcurrency.
 */
export declare const getFunctionConcurrency: API.OperationMethod<GetFunctionConcurrencyRequest & RegionInput, GetFunctionConcurrencyResponse, GetFunctionConcurrencyError, Credentials | HttpClient.HttpClient>;
export type GetFunctionConfigurationError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns the version-specific settings of a Lambda Event Function or version. The output includes only options that can vary between versions of a function. To modify these settings, use UpdateFunctionConfiguration.
 *
 * To get all of a function's details, including function-level settings, use GetFunction.
 */
export declare const getFunctionConfiguration: API.OperationMethod<GetFunctionConfigurationRequest & RegionInput, FunctionConfiguration, GetFunctionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetFunctionEventInvokeConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Retrieves the configuration for asynchronous invocation for a function, version, or alias.
 *
 * To configure options for asynchronous invocation, use PutFunctionEventInvokeConfig.
 */
export declare const getFunctionEventInvokeConfig: API.OperationMethod<GetFunctionEventInvokeConfigRequest & RegionInput, FunctionEventInvokeConfig, GetFunctionEventInvokeConfigError, Credentials | HttpClient.HttpClient>;
export type GetFunctionRecursionConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Returns your function's recursive loop detection configuration.
 */
export declare const getFunctionRecursionConfig: API.OperationMethod<GetFunctionRecursionConfigRequest & RegionInput, GetFunctionRecursionConfigResponse, GetFunctionRecursionConfigError, Credentials | HttpClient.HttpClient>;
export type GetFunctionScalingConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the scaling configuration for a Lambda Managed Instances function.
 */
export declare const getFunctionScalingConfig: API.OperationMethod<GetFunctionScalingConfigRequest & RegionInput, GetFunctionScalingConfigResponse, GetFunctionScalingConfigError, Credentials | HttpClient.HttpClient>;
export type GetFunctionUrlConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns details about a Lambda function URL.
 */
export declare const getFunctionUrlConfig: API.OperationMethod<GetFunctionUrlConfigRequest & RegionInput, GetFunctionUrlConfigResponse, GetFunctionUrlConfigError, Credentials | HttpClient.HttpClient>;
export type GetLayerVersionError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Returns information about a version of an Lambda layer, with a link to download the layer archive that's valid for 10 minutes.
 */
export declare const getLayerVersion: API.OperationMethod<GetLayerVersionRequest & RegionInput, GetLayerVersionResponse, GetLayerVersionError, Credentials | HttpClient.HttpClient>;
export type GetLayerVersionByArnError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns information about a version of an Lambda layer, with a link to download the layer archive that's valid for 10 minutes.
 */
export declare const getLayerVersionByArn: API.OperationMethod<GetLayerVersionByArnRequest & RegionInput, GetLayerVersionResponse, GetLayerVersionByArnError, Credentials | HttpClient.HttpClient>;
export type GetLayerVersionPolicyError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Returns the permission policy for a version of an Lambda layer. For more information, see AddLayerVersionPermission.
 */
export declare const getLayerVersionPolicy: API.OperationMethod<GetLayerVersionPolicyRequest & RegionInput, GetLayerVersionPolicyResponse, GetLayerVersionPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns the resource-based IAM policy for a function, version, or alias.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest & RegionInput, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetProvisionedConcurrencyConfigError = InvalidParameterValueException | ProvisionedConcurrencyConfigNotFoundException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Retrieves the provisioned concurrency configuration for a function's alias or version.
 */
export declare const getProvisionedConcurrencyConfig: API.OperationMethod<GetProvisionedConcurrencyConfigRequest & RegionInput, GetProvisionedConcurrencyConfigResponse, GetProvisionedConcurrencyConfigError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the resource-based policy attached to a Lambda resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type GetRuntimeManagementConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Retrieves the runtime management configuration for a function's version. If the runtime update mode is **Manual**, this includes the ARN of the runtime version and the runtime update mode. If the runtime update mode is **Auto** or **Function update**, this includes the runtime update mode and `null` is returned for the ARN. For more information, see Runtime updates.
 */
export declare const getRuntimeManagementConfig: API.OperationMethod<GetRuntimeManagementConfigRequest & RegionInput, GetRuntimeManagementConfigResponse, GetRuntimeManagementConfigError, Credentials | HttpClient.HttpClient>;
export type InvokeError = CodeArtifactUserDeletedException | CodeArtifactUserFailedException | CodeArtifactUserPendingException | DurableExecutionAlreadyStartedException | EC2AccessDeniedException | EC2ThrottledException | EC2UnexpectedException | EFSIOException | EFSMountConnectivityException | EFSMountFailureException | EFSMountTimeoutException | ENILimitReachedException | ENINotReadyException | InvalidParameterValueException | InvalidRequestContentException | InvalidRuntimeException | InvalidSecurityGroupIDException | InvalidSubnetIDException | InvalidZipFileException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ModeNotSupportedException | NoPublishedVersionException | RecursiveInvocationException | RequestTooLargeException | ResourceConflictException | ResourceNotFoundException | ResourceNotReadyException | RuntimeAliasDeletedException | RuntimeVersionDeletedException | S3FilesMountConnectivityException | S3FilesMountFailureException | S3FilesMountTimeoutException | SerializedRequestEntityTooLargeException | ServiceException | ServiceQuotaExceededException | SnapStartException | SnapStartNotReadyException | SnapStartRegenerationFailureException | SnapStartTimeoutException | SubnetIPAddressLimitReachedException | TooManyRequestsException | UnsupportedMediaTypeException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Invokes a Lambda Event Function. You can invoke a function synchronously (and wait for the response), or asynchronously. By default, Lambda invokes your function synchronously (i.e. the`InvocationType` is `RequestResponse`). To invoke a function asynchronously, set `InvocationType` to `Event`. Lambda passes the `ClientContext` object to your function for synchronous invocations only.
 *
 * For synchronous invocations, the maximum payload size is 6 MB. For asynchronous invocations, the maximum payload size is 1 MB.
 *
 * For synchronous invocation, details about the function response, including errors, are included in the response body and headers. For either invocation type, you can find more information in the execution log and trace.
 *
 * When an error occurs, your function may be invoked multiple times. Retry behavior varies by error type, client, event source, and invocation type. For example, if you invoke a function asynchronously and it returns an error, Lambda executes the function up to two more times. For more information, see Error handling and automatic retries in Lambda.
 *
 * For asynchronous invocation, Lambda adds events to a queue before sending them to your function. If your function does not have enough capacity to keep up with the queue, events may be lost. Occasionally, your function may receive the same event multiple times, even if no error occurs. To retain events that were not processed, configure your function with a dead-letter queue.
 *
 * The status code in the API response doesn't reflect function errors. Error codes are reserved for errors that prevent your function from executing, such as permissions errors, quota errors, or issues with your function's code and configuration. For example, Lambda returns `TooManyRequestsException` if running the function would cause you to exceed a concurrency limit at either the account level (`ConcurrentInvocationLimitExceeded`) or function level (`ReservedFunctionConcurrentInvocationLimitExceeded`).
 *
 * For functions with a long timeout, your client might disconnect during synchronous invocation while it waits for a response. Configure your HTTP client, SDK, firewall, proxy, or operating system to allow for long connections with timeout or keep-alive settings. Synchronous invocations can run for up to 30 minutes. Set the read timeout of your client higher than the function timeout, and turn on TCP keep-alive.
 *
 * This operation requires permission for the lambda:InvokeFunction action. For details on how to set up permissions for cross-account invocations, see Granting function access to other accounts.
 */
export declare const invoke: API.OperationMethod<InvocationRequest & RegionInput, InvocationResponse, InvokeError, Credentials | HttpClient.HttpClient>;
export type InvokeAsyncError = EC2AccessDeniedException | EC2ThrottledException | EC2UnexpectedException | EFSIOException | EFSMountConnectivityException | EFSMountFailureException | EFSMountTimeoutException | ENILimitReachedException | InvalidRequestContentException | InvalidRuntimeException | InvalidSecurityGroupIDException | InvalidSubnetIDException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ModeNotSupportedException | ResourceConflictException | ResourceNotFoundException | S3FilesMountConnectivityException | S3FilesMountFailureException | S3FilesMountTimeoutException | ServiceException | ServiceQuotaExceededException | SnapStartException | SnapStartNotReadyException | SnapStartRegenerationFailureException | SnapStartTimeoutException | SubnetIPAddressLimitReachedException | CommonErrors;
/**
 * For asynchronous function invocation, use Invoke.
 *
 * Invokes a function asynchronously.
 *
 * The payload limit is 256KB. For larger payloads, for up to 1MB, use Invoke.
 *
 * If you do use the InvokeAsync action, note that it doesn't support the use of X-Ray active tracing. Trace ID is not propagated to the function, even if X-Ray active tracing is turned on.
 */
export declare const invokeAsync: API.OperationMethod<InvokeAsyncRequest & RegionInput, InvokeAsyncResponse, InvokeAsyncError, Credentials | HttpClient.HttpClient>;
export type InvokeWithResponseStreamError = CodeArtifactUserDeletedException | CodeArtifactUserFailedException | CodeArtifactUserPendingException | EC2AccessDeniedException | EC2ThrottledException | EC2UnexpectedException | EFSIOException | EFSMountConnectivityException | EFSMountFailureException | EFSMountTimeoutException | ENILimitReachedException | InvalidParameterValueException | InvalidRequestContentException | InvalidRuntimeException | InvalidSecurityGroupIDException | InvalidSubnetIDException | InvalidZipFileException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | NoPublishedVersionException | RecursiveInvocationException | RequestTooLargeException | ResourceConflictException | ResourceNotFoundException | ResourceNotReadyException | RuntimeAliasDeletedException | RuntimeVersionDeletedException | S3FilesMountConnectivityException | S3FilesMountFailureException | S3FilesMountTimeoutException | SerializedRequestEntityTooLargeException | ServiceException | ServiceQuotaExceededException | SnapStartException | SnapStartNotReadyException | SnapStartRegenerationFailureException | SnapStartTimeoutException | SubnetIPAddressLimitReachedException | TooManyRequestsException | UnsupportedMediaTypeException | CommonErrors;
/**
 * Configure your Lambda Event Functions to stream response payloads back to clients. For more information, see Configuring a Lambda function to stream responses.
 *
 * This operation requires permission for the lambda:InvokeFunction action. For details on how to set up permissions for cross-account invocations, see Granting function access to other accounts.
 */
export declare const invokeWithResponseStream: API.OperationMethod<InvokeWithResponseStreamRequest & RegionInput, InvokeWithResponseStreamResponse, InvokeWithResponseStreamError, Credentials | HttpClient.HttpClient>;
export type ListAliasesError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of aliases for a Lambda Event Function.
 */
export declare const listAliases: API.PaginatedOperationMethod<ListAliasesRequest & RegionInput, ListAliasesResponse, ListAliasesError, Credentials | HttpClient.HttpClient, AliasConfiguration>;
export type ListCapacityProvidersError = InvalidParameterValueException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of capacity providers in your account.
 */
export declare const listCapacityProviders: API.PaginatedOperationMethod<ListCapacityProvidersRequest & RegionInput, ListCapacityProvidersResponse, ListCapacityProvidersError, Credentials | HttpClient.HttpClient, CapacityProvider>;
export type ListCodeSigningConfigsError = InvalidParameterValueException | ServiceException | CommonErrors;
/**
 * Returns a list of code signing configurations. A request returns up to 10,000 configurations per call. You can use the `MaxItems` parameter to return fewer configurations per call.
 */
export declare const listCodeSigningConfigs: API.PaginatedOperationMethod<ListCodeSigningConfigsRequest & RegionInput, ListCodeSigningConfigsResponse, ListCodeSigningConfigsError, Credentials | HttpClient.HttpClient, CodeSigningConfig>;
export type ListDurableExecutionsByFunctionError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of durable executions for a specified Lambda function. You can filter the results by execution name, status, and start time range. This API supports pagination for large result sets.
 */
export declare const listDurableExecutionsByFunction: API.PaginatedOperationMethod<ListDurableExecutionsByFunctionRequest & RegionInput, ListDurableExecutionsByFunctionResponse, ListDurableExecutionsByFunctionError, Credentials | HttpClient.HttpClient, Execution>;
export type ListEventSourceMappingsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists event source mappings. Specify an `EventSourceArn` to show only event source mappings for a single event source.
 */
export declare const listEventSourceMappings: API.PaginatedOperationMethod<ListEventSourceMappingsRequest & RegionInput, ListEventSourceMappingsResponse, ListEventSourceMappingsError, Credentials | HttpClient.HttpClient, EventSourceMappingConfiguration>;
export type ListFunctionEventInvokeConfigsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Retrieves a list of configurations for asynchronous invocation for a Lambda Event Function. To retrieve more configurations, use the `Marker` parameter.
 *
 * To configure options for asynchronous invocation, use PutFunctionEventInvokeConfig.
 */
export declare const listFunctionEventInvokeConfigs: API.PaginatedOperationMethod<ListFunctionEventInvokeConfigsRequest & RegionInput, ListFunctionEventInvokeConfigsResponse, ListFunctionEventInvokeConfigsError, Credentials | HttpClient.HttpClient, FunctionEventInvokeConfig>;
export type ListFunctionsError = InvalidParameterValueException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of Lambda Event Functions, with the version-specific configuration of each. Lambda returns up to 50 functions per call.
 *
 * Set `FunctionVersion` to `ALL` to include all published versions of each function in addition to the unpublished version.
 *
 * The `ListFunctions` operation returns a subset of the FunctionConfiguration fields. To get the additional fields (State, StateReasonCode, StateReason, LastUpdateStatus, LastUpdateStatusReason, LastUpdateStatusReasonCode, RuntimeVersionConfig) for a function or version, use GetFunction.
 */
export declare const listFunctions: API.PaginatedOperationMethod<ListFunctionsRequest & RegionInput, ListFunctionsResponse, ListFunctionsError, Credentials | HttpClient.HttpClient, FunctionConfiguration>;
export type ListFunctionsByCodeSigningConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * List the functions that use the specified code signing configuration. You can use this method prior to deleting a code signing configuration, to verify that no functions are using it.
 */
export declare const listFunctionsByCodeSigningConfig: API.PaginatedOperationMethod<ListFunctionsByCodeSigningConfigRequest & RegionInput, ListFunctionsByCodeSigningConfigResponse, ListFunctionsByCodeSigningConfigError, Credentials | HttpClient.HttpClient, FunctionArn>;
export type ListFunctionUrlConfigsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of Lambda function URLs for the specified function.
 */
export declare const listFunctionUrlConfigs: API.PaginatedOperationMethod<ListFunctionUrlConfigsRequest & RegionInput, ListFunctionUrlConfigsResponse, ListFunctionUrlConfigsError, Credentials | HttpClient.HttpClient, FunctionUrlConfig>;
export type ListFunctionVersionsByCapacityProviderError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of function versions that are configured to use a specific capacity provider.
 */
export declare const listFunctionVersionsByCapacityProvider: API.PaginatedOperationMethod<ListFunctionVersionsByCapacityProviderRequest & RegionInput, ListFunctionVersionsByCapacityProviderResponse, ListFunctionVersionsByCapacityProviderError, Credentials | HttpClient.HttpClient, FunctionVersionsByCapacityProviderListItem>;
export type ListLayersError = InvalidParameterValueException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Lists Lambda layers and shows information about the latest version of each. Specify a runtime identifier to list only layers that indicate that they're compatible with that runtime. Specify a compatible architecture to include only layers that are compatible with that instruction set architecture.
 */
export declare const listLayers: API.PaginatedOperationMethod<ListLayersRequest & RegionInput, ListLayersResponse, ListLayersError, Credentials | HttpClient.HttpClient, LayersListItem>;
export type ListLayerVersionsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Lists the versions of an Lambda layer. Versions that have been deleted aren't listed. Specify a runtime identifier to list only versions that indicate that they're compatible with that runtime. Specify a compatible architecture to include only layer versions that are compatible with that architecture.
 */
export declare const listLayerVersions: API.PaginatedOperationMethod<ListLayerVersionsRequest & RegionInput, ListLayerVersionsResponse, ListLayerVersionsError, Credentials | HttpClient.HttpClient, LayerVersionsListItem>;
export type ListProvisionedConcurrencyConfigsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Retrieves a list of provisioned concurrency configurations for a function.
 */
export declare const listProvisionedConcurrencyConfigs: API.PaginatedOperationMethod<ListProvisionedConcurrencyConfigsRequest & RegionInput, ListProvisionedConcurrencyConfigsResponse, ListProvisionedConcurrencyConfigsError, Credentials | HttpClient.HttpClient, ProvisionedConcurrencyConfigListItem>;
export type ListTagsError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Returns a function, event source mapping, or code signing configuration's tags. You can also view function tags with GetFunction.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest & RegionInput, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListVersionsByFunctionError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of versions of a Lambda Event Function, with the version-specific configuration of each. Lambda returns up to 50 versions per call.
 */
export declare const listVersionsByFunction: API.PaginatedOperationMethod<ListVersionsByFunctionRequest & RegionInput, ListVersionsByFunctionResponse, ListVersionsByFunctionError, Credentials | HttpClient.HttpClient, FunctionConfiguration>;
export type PauseDurableExecutionError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Pauses a running durable execution. While an execution is paused, Lambda doesn't invoke your function, but pending operations such as waits and callbacks continue to complete.
 *
 * If an invocation is in progress, the execution status changes to `PAUSING` until the invocation reaches its next checkpoint, and then changes to `PAUSED`. This operation returns a successful response while the execution status is still `RUNNING`, and the status changes when Lambda processes the request. For more information about pausing executions, see Pausing and resuming durable executions.
 */
export declare const pauseDurableExecution: API.OperationMethod<PauseDurableExecutionRequest & RegionInput, PauseDurableExecutionResponse, PauseDurableExecutionError, Credentials | HttpClient.HttpClient>;
export type PublishLayerVersionError = CodeStorageExceededException | InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Creates an Lambda layer from a ZIP archive. Each time you call `PublishLayerVersion` with the same layer name, a new version is created.
 *
 * Add layers to your function with CreateFunction or UpdateFunctionConfiguration.
 */
export declare const publishLayerVersion: API.OperationMethod<PublishLayerVersionRequest & RegionInput, PublishLayerVersionResponse, PublishLayerVersionError, Credentials | HttpClient.HttpClient>;
export type PublishVersionError = CodeStorageExceededException | FunctionVersionsPerCapacityProviderLimitExceededException | InvalidParameterValueException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Creates a version from the current code and configuration of a Lambda Event Function. Use versions to create a snapshot of your function code and configuration that doesn't change.
 *
 * Lambda doesn't publish a version if the function's configuration and code haven't changed since the last version. Use UpdateFunctionCode or UpdateFunctionConfiguration to update the function before publishing a version.
 *
 * Clients can invoke versions directly or with an alias. To create an alias, use CreateAlias.
 */
export declare const publishVersion: API.OperationMethod<PublishVersionRequest & RegionInput, FunctionConfiguration, PublishVersionError, Credentials | HttpClient.HttpClient>;
export type PutFunctionCodeSigningConfigError = CodeSigningConfigNotFoundException | InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Update the code signing configuration for the function. Changes to the code signing configuration take effect the next time a user tries to deploy a code package to the function.
 */
export declare const putFunctionCodeSigningConfig: API.OperationMethod<PutFunctionCodeSigningConfigRequest & RegionInput, PutFunctionCodeSigningConfigResponse, PutFunctionCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type PutFunctionConcurrencyError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Sets the maximum number of simultaneous executions for a Lambda Event Function, and reserves capacity for that concurrency level.
 *
 * Concurrency settings apply to the function as a whole, including all published versions and the unpublished version. Reserving concurrency both ensures that your function has capacity to process the specified number of events simultaneously, and prevents it from scaling beyond that level. Use GetFunction to see the current setting for a function.
 *
 * Use GetAccountSettings to see your Regional concurrency limit. You can reserve concurrency for as many functions as you like, as long as you leave at least 100 simultaneous executions unreserved for functions that aren't configured with a per-function limit. For more information, see Lambda function scaling.
 */
export declare const putFunctionConcurrency: API.OperationMethod<PutFunctionConcurrencyRequest & RegionInput, Concurrency, PutFunctionConcurrencyError, Credentials | HttpClient.HttpClient>;
export type PutFunctionEventInvokeConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Configures options for asynchronous invocation on a function, version, or alias. If a configuration already exists for a function, version, or alias, this operation overwrites it. If you exclude any settings, they are removed. To set one option without affecting existing settings for other options, use UpdateFunctionEventInvokeConfig.
 *
 * By default, Lambda retries an asynchronous invocation twice if the function returns an error. It retains events in a queue for up to six hours. When an event fails all processing attempts or stays in the asynchronous invocation queue for too long, Lambda discards it. To retain discarded events, configure a dead-letter queue with UpdateFunctionConfiguration.
 *
 * To send an invocation record to a queue, topic, S3 bucket, function, or event bus, specify a destination. You can configure separate destinations for successful invocations (on-success) and events that fail all processing attempts (on-failure). You can configure destinations in addition to or instead of a dead-letter queue.
 *
 * S3 buckets are supported only for on-failure destinations. To retain records of successful invocations, use another destination type.
 */
export declare const putFunctionEventInvokeConfig: API.OperationMethod<PutFunctionEventInvokeConfigRequest & RegionInput, FunctionEventInvokeConfig, PutFunctionEventInvokeConfigError, Credentials | HttpClient.HttpClient>;
export type PutFunctionRecursionConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Sets the recursive loop detection configuration for a Lambda Event Function.
 *
 * When you configure a Lambda function to output to the same service or resource that invokes the function, it's possible to create an infinite recursive loop. For example, a Lambda function might write a message to an Amazon Simple Queue Service (Amazon SQS) queue, which then invokes the same function. This invocation causes the function to write another message to the queue, which in turn invokes the function again.
 *
 * Lambda can detect certain types of recursive loops shortly after they occur. When Lambda detects a recursive loop and your function's recursive loop detection configuration is set to `Terminate`, it stops your function being invoked and notifies you.
 */
export declare const putFunctionRecursionConfig: API.OperationMethod<PutFunctionRecursionConfigRequest & RegionInput, PutFunctionRecursionConfigResponse, PutFunctionRecursionConfigError, Credentials | HttpClient.HttpClient>;
export type PutFunctionScalingConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Sets the scaling configuration for a Lambda Managed Instances function. The scaling configuration defines the minimum and maximum number of execution environments that can be provisioned for the function, allowing you to control scaling behavior and resource allocation.
 */
export declare const putFunctionScalingConfig: API.OperationMethod<PutFunctionScalingConfigRequest & RegionInput, PutFunctionScalingConfigResponse, PutFunctionScalingConfigError, Credentials | HttpClient.HttpClient>;
export type PutProvisionedConcurrencyConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Adds a provisioned concurrency configuration to a function's alias or version.
 */
export declare const putProvisionedConcurrencyConfig: API.OperationMethod<PutProvisionedConcurrencyConfigRequest & RegionInput, PutProvisionedConcurrencyConfigResponse, PutProvisionedConcurrencyConfigError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = InvalidParameterValueException | PolicyLengthExceededException | PreconditionFailedException | PublicPolicyException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Adds a resource-based policy to a Lambda resource. Resource-based policies grant access to other Amazon Web Services accounts, organizations, or services. Resource-based policies apply to a single Lambda resource (for example, a function, function version, or function alias).
 *
 * This operation replaces any existing policy on the Lambda resource. If you previously added permissions using the AddPermission operation, the new policy overwrites those permissions.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutRuntimeManagementConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Sets the runtime management configuration for a function's version. For more information, see Runtime updates.
 */
export declare const putRuntimeManagementConfig: API.OperationMethod<PutRuntimeManagementConfigRequest & RegionInput, PutRuntimeManagementConfigResponse, PutRuntimeManagementConfigError, Credentials | HttpClient.HttpClient>;
export type RemoveLayerVersionPermissionError = InvalidParameterValueException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Removes a statement from the permissions policy for a version of an Lambda layer. For more information, see AddLayerVersionPermission.
 */
export declare const removeLayerVersionPermission: API.OperationMethod<RemoveLayerVersionPermissionRequest & RegionInput, RemoveLayerVersionPermissionResponse, RemoveLayerVersionPermissionError, Credentials | HttpClient.HttpClient>;
export type RemovePermissionError = InvalidParameterValueException | PreconditionFailedException | PublicPolicyException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Revokes function-use permission from an Amazon Web Services service or another Amazon Web Services account. You can get the ID of the statement from the output of GetPolicy.
 */
export declare const removePermission: API.OperationMethod<RemovePermissionRequest & RegionInput, RemovePermissionResponse, RemovePermissionError, Credentials | HttpClient.HttpClient>;
export type ResumeDurableExecutionError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Resumes a paused durable execution. If the pause interrupted an invocation, or an operation completed while the execution was paused, Lambda invokes your function. Otherwise, the execution continues to wait for its pending operations.
 *
 * If the execution status is `PAUSING`, this operation cancels the pause, and the in-progress invocation continues. This operation returns a successful response while the execution status is still `PAUSED` or `PAUSING`, and the status changes to `RUNNING` when Lambda processes the request. For more information about resuming executions, see Pausing and resuming durable executions.
 */
export declare const resumeDurableExecution: API.OperationMethod<ResumeDurableExecutionRequest & RegionInput, ResumeDurableExecutionResponse, ResumeDurableExecutionError, Credentials | HttpClient.HttpClient>;
export type SendDurableExecutionCallbackFailureError = CallbackTimeoutException | InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Sends a failure response for a callback operation in a durable execution. Use this API when an external system cannot complete a callback operation successfully.
 */
export declare const sendDurableExecutionCallbackFailure: API.OperationMethod<SendDurableExecutionCallbackFailureRequest & RegionInput, SendDurableExecutionCallbackFailureResponse, SendDurableExecutionCallbackFailureError, Credentials | HttpClient.HttpClient>;
export type SendDurableExecutionCallbackHeartbeatError = CallbackTimeoutException | InvalidParameterValueException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Sends a heartbeat signal for a long-running callback operation to prevent timeout. Use this API to extend the callback timeout period while the external operation is still in progress.
 */
export declare const sendDurableExecutionCallbackHeartbeat: API.OperationMethod<SendDurableExecutionCallbackHeartbeatRequest & RegionInput, SendDurableExecutionCallbackHeartbeatResponse, SendDurableExecutionCallbackHeartbeatError, Credentials | HttpClient.HttpClient>;
export type SendDurableExecutionCallbackSuccessError = CallbackTimeoutException | InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Sends a successful completion response for a callback operation in a durable execution. Use this API when an external system has successfully completed a callback operation.
 */
export declare const sendDurableExecutionCallbackSuccess: API.OperationMethod<SendDurableExecutionCallbackSuccessRequest & RegionInput, SendDurableExecutionCallbackSuccessResponse, SendDurableExecutionCallbackSuccessError, Credentials | HttpClient.HttpClient>;
export type StopDurableExecutionError = InvalidParameterValueException | KMSAccessDeniedException | KMSDisabledException | KMSInvalidStateException | KMSNotFoundException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Stops a running or paused durable execution. The execution transitions to STOPPED status and cannot be resumed. Any in-progress operations are terminated.
 */
export declare const stopDurableExecution: API.OperationMethod<StopDurableExecutionRequest & RegionInput, StopDurableExecutionResponse, StopDurableExecutionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Adds tags to a function, event source mapping, or code signing configuration.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Removes tags from a function, event source mapping, or code signing configuration.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAliasError = InvalidParameterValueException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Updates the configuration of a Lambda Event Function alias.
 */
export declare const updateAlias: API.OperationMethod<UpdateAliasRequest & RegionInput, AliasConfiguration, UpdateAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateCapacityProviderError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration of an existing capacity provider.
 */
export declare const updateCapacityProvider: API.OperationMethod<UpdateCapacityProviderRequest & RegionInput, UpdateCapacityProviderResponse, UpdateCapacityProviderError, Credentials | HttpClient.HttpClient>;
export type UpdateCodeSigningConfigError = InvalidParameterValueException | ResourceNotFoundException | ServiceException | CommonErrors;
/**
 * Update the code signing configuration. Changes to the code signing configuration take effect the next time a user tries to deploy a code package to the function.
 */
export declare const updateCodeSigningConfig: API.OperationMethod<UpdateCodeSigningConfigRequest & RegionInput, UpdateCodeSigningConfigResponse, UpdateCodeSigningConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateEventSourceMappingError = InvalidParameterValueException | ResourceConflictException | ResourceInUseException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | ExecutionRoleNotAssumable | ExecutionRoleMissingPermissions | QueueVisibilityTimeoutTooShort | CommonErrors;
/**
 * Updates an event source mapping. You can change the function that Lambda invokes, or pause invocation and resume later from the same location.
 *
 * For details about how to configure different event sources, see the following topics.
 *
 * - Amazon DynamoDB Streams
 *
 * - Amazon Kinesis
 *
 * - Amazon SQS
 *
 * - Amazon MQ and RabbitMQ
 *
 * - Amazon MSK
 *
 * - Apache Kafka
 *
 * - Amazon DocumentDB
 *
 * The following error handling options are available for stream sources (DynamoDB, Kinesis, Amazon MSK, and self-managed Apache Kafka):
 *
 * - `BisectBatchOnFunctionError` - If the function returns an error, split the batch in two and retry.
 *
 * - `MaximumRecordAgeInSeconds` - Discard records older than the specified age. The default value is infinite (-1). When set to infinite (-1), failed records are retried until the record expires
 *
 * - `MaximumRetryAttempts` - Discard records after the specified number of retries. The default value is infinite (-1). When set to infinite (-1), failed records are retried until the record expires.
 *
 * - `OnFailure` - Send discarded records to an Amazon SQS queue, Amazon SNS topic, Kafka topic, or Amazon S3 bucket. For more information, see Adding a destination.
 *
 * The following option is available only for DynamoDB and Kinesis event sources:
 *
 * - `ParallelizationFactor` - Process multiple batches from each shard concurrently.
 *
 * For information about which configuration parameters apply to each event source, see the following topics.
 *
 * - Amazon DynamoDB Streams
 *
 * - Amazon Kinesis
 *
 * - Amazon SQS
 *
 * - Amazon MQ and RabbitMQ
 *
 * - Amazon MSK
 *
 * - Apache Kafka
 *
 * - Amazon DocumentDB
 */
export declare const updateEventSourceMapping: API.OperationMethod<UpdateEventSourceMappingRequest & RegionInput, EventSourceMappingConfiguration, UpdateEventSourceMappingError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionCodeError = CodeSigningConfigNotFoundException | CodeStorageExceededException | CodeVerificationFailedException | InvalidCodeSignatureException | InvalidParameterValueException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | ExecutionRoleNotAssumable | ExecutionRoleMissingVpcPermissions | KmsGrantPrincipalNotReady | CommonErrors;
/**
 * Updates a Lambda Event Function's code. If code signing is enabled for the function, the code package must be signed by a trusted publisher. For more information, see Configuring code signing for Lambda.
 *
 * If the function's package type is `Image`, then you must specify the code package in `ImageUri` as the URI of a container image in the Amazon ECR registry.
 *
 * If the function's package type is `Zip`, then you must specify the deployment package as a .zip file archive. Enter the Amazon S3 bucket and key of the code .zip file location. You can also provide the function code inline using the `ZipFile` field.
 *
 * The code in the deployment package must be compatible with the target instruction set architecture of the function (`x86-64` or `arm64`).
 *
 * The function's code is locked when you publish a version. You can't modify the code of a published version, only the unpublished version.
 *
 * For a function defined as a container image, Lambda resolves the image tag to an image digest. In Amazon ECR, if you update the image tag to a new image, Lambda does not automatically update the function.
 */
export declare const updateFunctionCode: API.OperationMethod<UpdateFunctionCodeRequest & RegionInput, FunctionConfiguration, UpdateFunctionCodeError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionConfigurationError = CodeSigningConfigNotFoundException | CodeVerificationFailedException | InvalidCodeSignatureException | InvalidParameterValueException | PreconditionFailedException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | ExecutionRoleNotAssumable | ExecutionRoleMissingVpcPermissions | KmsGrantPrincipalNotReady | SecurityGroupNotFound | CommonErrors;
/**
 * Modifies the version-specific settings of a Lambda Event Function.
 *
 * When you update a function, Lambda provisions an instance of the function and its supporting resources. If your function connects to a VPC, this process can take a minute. During this time, you can't modify the function, but you can still invoke it. The `LastUpdateStatus`, `LastUpdateStatusReason`, and `LastUpdateStatusReasonCode` fields in the response from GetFunctionConfiguration indicate when the update is complete and the function is processing events with the new configuration. For more information, see Lambda function states.
 *
 * These settings can vary between versions of a function and are locked when you publish a version. You can't modify the configuration of a published version, only the unpublished version.
 *
 * To configure function concurrency, use PutFunctionConcurrency. To grant invoke permissions to an Amazon Web Services account or Amazon Web Services service, use AddPermission.
 */
export declare const updateFunctionConfiguration: API.OperationMethod<UpdateFunctionConfigurationRequest & RegionInput, FunctionConfiguration, UpdateFunctionConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionEventInvokeConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | CommonErrors;
/**
 * Updates the configuration for asynchronous invocation for a function, version, or alias.
 *
 * To configure options for asynchronous invocation, use PutFunctionEventInvokeConfig.
 */
export declare const updateFunctionEventInvokeConfig: API.OperationMethod<UpdateFunctionEventInvokeConfigRequest & RegionInput, FunctionEventInvokeConfig, UpdateFunctionEventInvokeConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionUrlConfigError = InvalidParameterValueException | ResourceConflictException | ResourceNotFoundException | ServiceException | TooManyRequestsException | RequestLimitExceeded | ParseError | CommonErrors;
/**
 * Updates the configuration for a function URL of a Lambda Event Function.
 */
export declare const updateFunctionUrlConfig: API.OperationMethod<UpdateFunctionUrlConfigRequest & RegionInput, UpdateFunctionUrlConfigResponse, UpdateFunctionUrlConfigError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lambda.d.ts.map