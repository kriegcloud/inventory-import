import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidGrantException_base: S.TaggedErrorClass<"InvalidGrantException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGrantException extends /*@__PURE__*/ InvalidGrantException_base {
}
declare const InvalidScopeException_base: S.TaggedErrorClass<"InvalidScopeException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidScopeException extends /*@__PURE__*/ InvalidScopeException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsError_base: S.TaggedErrorClass<"TooManyRequestsError", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class TooManyRequestsError extends /*@__PURE__*/ TooManyRequestsError_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly error: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientCredentialsGrantType = string;
export type Resource = string;
export type TokenDuration = number;
export interface CreateBearerTokenRequest {
    grantType: string;
    resource: string;
    durationSeconds?: number | undefined;
}
export type OAuthAccessToken = string | redacted.Redacted<string>;
export type BearerTokenType = string;
export type BearerTokenExpiresIn = number;
export interface CreateBearerTokenResponse {
    accessToken: string | redacted.Redacted<string>;
    tokenType: string;
    expiresIn: number;
}
export type ClientId = string;
export type GrantType = string;
export type AuthorizationCode = string;
export type RedirectUri = string;
export type CodeVerifier = string;
export type RefreshToken = string | redacted.Redacted<string>;
export interface CreateOAuth2TokenRequestBody {
    clientId: string;
    grantType: string;
    code?: string | undefined;
    redirectUri?: string | undefined;
    codeVerifier?: string | undefined;
    refreshToken?: string | redacted.Redacted<string> | undefined;
}
export interface CreateOAuth2TokenRequest {
    tokenInput: CreateOAuth2TokenRequestBody;
}
export interface AccessToken {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken: string;
}
export type TokenType = string;
export type ExpiresIn = number;
export type IdToken = string;
export interface CreateOAuth2TokenResponseBody {
    accessToken: AccessToken;
    tokenType: string;
    expiresIn: number;
    refreshToken: string | redacted.Redacted<string>;
    idToken?: string | undefined;
}
export interface CreateOAuth2TokenResponse {
    tokenOutput: CreateOAuth2TokenResponseBody;
}
export interface CreateOAuth2TokenWithIAMRequest {
    grantType: string;
    resource: string;
}
export type TokenExpiresIn = number;
export interface CreateOAuth2TokenWithIAMResponse {
    accessToken: string | redacted.Redacted<string>;
    tokenType: string;
    expiresIn: number;
}
export type TokenExchangeGrantType = string;
export type SubjectToken = string | redacted.Redacted<string>;
export type SubjectTokenType = string;
export type Scope = string;
export interface CreateOAuth2TokenWithTokenExchangeRequest {
    grantType: string;
    subjectToken?: string | redacted.Redacted<string> | undefined;
    subjectTokenType?: string | undefined;
    resource?: string | undefined;
    scope?: string | undefined;
}
export type IssuedOAuthAccessTokenType = string;
export interface CreateOAuth2TokenWithTokenExchangeResponse {
    accessToken: string | redacted.Redacted<string>;
    issuedTokenType?: string | undefined;
    tokenType: string;
    expiresIn: number;
}
export type TargetId = string;
export interface DeleteConsoleAuthorizationConfigurationInput {
    targetId?: string | undefined;
}
export interface DeleteConsoleAuthorizationConfigurationOutput {
    targetId: string;
    scope: string;
    consoleAuthorizationEnabled: boolean;
}
export type StatementId = string;
export type ClientToken = string;
export interface DeleteResourcePermissionStatementInput {
    statementId: string;
    clientToken?: string | undefined;
}
export interface DeleteResourcePermissionStatementOutput {
}
export interface GetConsoleAuthorizationConfigurationInput {
    targetId?: string | undefined;
}
export interface GetConsoleAuthorizationConfigurationOutput {
    targetId: string;
    scope: string;
    consoleAuthorizationEnabled: boolean;
}
export interface GetResourcePolicyInput {
}
export type Principal = {
    [key: string]: string | undefined;
};
export type PolicyActions = string[];
export type ConditionType = string;
export type ConditionValues = string[];
export type Condition = {
    [key: string]: string[] | undefined;
};
export type ConditionBlock = {
    [key: string]: {
        [key: string]: string[] | undefined;
    } | undefined;
};
export interface PolicyStatement {
    effect?: string | undefined;
    principal?: {
        [key: string]: string | undefined;
    } | undefined;
    action?: string[] | undefined;
    resource?: string | undefined;
    condition?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
}
export type PolicyStatements = PolicyStatement[];
export interface SigninResourceBasedPolicy {
    version?: string | undefined;
    statement?: PolicyStatement[] | undefined;
}
export interface GetResourcePolicyOutput {
    signinResourceBasedPolicy: SigninResourceBasedPolicy;
}
export type IntrospectionToken = string | redacted.Redacted<string>;
export type TokenTypeHint = string;
export interface IntrospectOAuth2TokenWithIAMRequest {
    token: string | redacted.Redacted<string>;
    tokenTypeHint?: string | undefined;
}
export type IntrospectedTokenType = string;
export type AccountId = string;
export interface IntrospectOAuth2TokenWithIAMResponse {
    active: boolean;
    clientId?: string | undefined;
    userId?: string | undefined;
    tokenType?: string | undefined;
    exp?: number | undefined;
    iat?: number | undefined;
    nbf?: number | undefined;
    sub?: string | undefined;
    aud?: string | undefined;
    iss?: string | undefined;
    jti?: string | undefined;
    accountId?: string | undefined;
    signinSession?: string | undefined;
    resource?: string | undefined;
}
export type ConsolePermissionMaxResults = number;
export type NextToken = string;
export interface ListResourcePermissionStatementsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface PermissionStatementSummary {
    sid: string;
    condition?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
}
export type PermissionStatementSummaries = PermissionStatementSummary[];
export interface ListResourcePermissionStatementsOutput {
    permissionStatements: PermissionStatementSummary[];
    nextToken?: string | undefined;
}
export interface PutConsoleAuthorizationConfigurationInput {
    targetId?: string | undefined;
}
export interface PutConsoleAuthorizationConfigurationOutput {
    targetId: string;
    scope: string;
    consoleAuthorizationEnabled: boolean;
}
export type SourceVpc = string;
export type SourceVpce = string;
export type VpcSourceIp = string;
export type SourceIp = string;
export type RequestedRegion = string;
export type ExcludedPrincipal = string;
export interface PutResourcePermissionStatementInput {
    sourceVpc?: string | undefined;
    signinSourceVpce?: string | undefined;
    consoleSourceVpce?: string | undefined;
    vpcSourceIp?: string | undefined;
    sourceIp?: string | undefined;
    requestedRegion?: string | undefined;
    excludedPrincipal?: string | undefined;
    clientToken?: string | undefined;
}
export interface PutResourcePermissionStatementOutput {
    statementId: string;
}
export type RevocationToken = string | redacted.Redacted<string>;
export interface RevokeOAuth2TokenWithIAMRequest {
    token: string | redacted.Redacted<string>;
}
export interface RevokeOAuth2TokenWithIAMResponse {
}
export type OAuth2ErrorCode = "TOKEN_EXPIRED" | "USER_CREDENTIALS_CHANGED" | "INSUFFICIENT_PERMISSIONS" | "AUTHCODE_EXPIRED" | "server_error" | "INVALID_REQUEST" | "RESOURCE_NOT_FOUND" | "CONFLICT" | "SERVICE_QUOTA_EXCEEDED" | "unsupported_grant_type" | "invalid_request" | "invalid_grant" | "invalid_scope" | "invalid_target" | "rate_exceeded" | "service_unavailable" | (string & {});
export type CreateBearerTokenError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Creates a bearer token that represents your IAM credentials and can be used to access a supported AWS service. By default, the token is valid for 12 hours.
 */
export declare const createBearerToken: API.OperationMethod<CreateBearerTokenRequest & RegionInput, CreateBearerTokenResponse, CreateBearerTokenError, Credentials | HttpClient.HttpClient>;
export type CreateOAuth2TokenError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Exchanges an authorization code or refresh token for an OAuth 2.0 access token and refresh token.
 */
export declare const createOAuth2Token: API.OperationMethod<CreateOAuth2TokenRequest & RegionInput, CreateOAuth2TokenResponse, CreateOAuth2TokenError, Credentials | HttpClient.HttpClient>;
export type CreateOAuth2TokenWithIAMError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Exchanges client credentials for an OAuth 2.0 access token scoped to a resource, which you can use to access AWS services from applications.
 */
export declare const createOAuth2TokenWithIAM: API.OperationMethod<CreateOAuth2TokenWithIAMRequest & RegionInput, CreateOAuth2TokenWithIAMResponse, CreateOAuth2TokenWithIAMError, Credentials | HttpClient.HttpClient>;
export type CreateOAuth2TokenWithTokenExchangeError = InternalServerException | InvalidGrantException | InvalidScopeException | ServiceUnavailableException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Exchanges a supported token for an OAuth 2.0 access token scoped to a resource, which you can use to access AWS services from applications.
 */
export declare const createOAuth2TokenWithTokenExchange: API.OperationMethod<CreateOAuth2TokenWithTokenExchangeRequest & RegionInput, CreateOAuth2TokenWithTokenExchangeResponse, CreateOAuth2TokenWithTokenExchangeError, Credentials | HttpClient.HttpClient>;
export type DeleteConsoleAuthorizationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Delete console authorization configuration with automatic scope detection
 */
export declare const deleteConsoleAuthorizationConfiguration: API.OperationMethod<DeleteConsoleAuthorizationConfigurationInput & RegionInput, DeleteConsoleAuthorizationConfigurationOutput, DeleteConsoleAuthorizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePermissionStatementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Remove a permission statement from the account's SignIn resource-based policy
 */
export declare const deleteResourcePermissionStatement: API.OperationMethod<DeleteResourcePermissionStatementInput & RegionInput, DeleteResourcePermissionStatementOutput, DeleteResourcePermissionStatementError, Credentials | HttpClient.HttpClient>;
export type GetConsoleAuthorizationConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Get console authorization configuration with automatic scope detection
 */
export declare const getConsoleAuthorizationConfiguration: API.OperationMethod<GetConsoleAuthorizationConfigurationInput & RegionInput, GetConsoleAuthorizationConfigurationOutput, GetConsoleAuthorizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | CommonErrors;
/**
 * Retrieve the account's consolidated SignIn resource-based policy
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput & RegionInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type IntrospectOAuth2TokenWithIAMError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Inspects the metadata and active state of an OAuth 2.0 access token or refresh token.
 *
 * Implements RFC 7662 OAuth 2.0 Token Introspection over a SigV4-authenticated
 * endpoint. Returns the claims associated with a token issued by AWS Sign-In.
 */
export declare const introspectOAuth2TokenWithIAM: API.OperationMethod<IntrospectOAuth2TokenWithIAMRequest & RegionInput, IntrospectOAuth2TokenWithIAMResponse, IntrospectOAuth2TokenWithIAMError, Credentials | HttpClient.HttpClient>;
export type ListResourcePermissionStatementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Retrieve all permission statements in the account's SignIn resource-based policy
 */
export declare const listResourcePermissionStatements: API.PaginatedOperationMethod<ListResourcePermissionStatementsInput & RegionInput, ListResourcePermissionStatementsOutput, ListResourcePermissionStatementsError, Credentials | HttpClient.HttpClient, PermissionStatementSummary>;
export type PutConsoleAuthorizationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Enable console authorization configuration with automatic scope detection
 */
export declare const putConsoleAuthorizationConfiguration: API.OperationMethod<PutConsoleAuthorizationConfigurationInput & RegionInput, PutConsoleAuthorizationConfigurationOutput, PutConsoleAuthorizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutResourcePermissionStatementError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Create a permission statement in the account's SignIn resource-based policy
 */
export declare const putResourcePermissionStatement: API.OperationMethod<PutResourcePermissionStatementInput & RegionInput, PutResourcePermissionStatementOutput, PutResourcePermissionStatementError, Credentials | HttpClient.HttpClient>;
export type RevokeOAuth2TokenWithIAMError = AccessDeniedException | InternalServerException | TooManyRequestsError | ValidationException | CommonErrors;
/**
 * Revokes an OAuth 2.0 refresh token and its associated token chain.
 */
export declare const revokeOAuth2TokenWithIAM: API.OperationMethod<RevokeOAuth2TokenWithIAMRequest & RegionInput, RevokeOAuth2TokenWithIAMResponse, RevokeOAuth2TokenWithIAMError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=signin.d.ts.map