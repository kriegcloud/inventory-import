import * as Layer from "effect/Layer";
import { type SqlMigrationSnapshot } from "./Embedded.ts";
/** Supply the generated migration records to every entrypoint and object activation. */
export declare const withSqlMigrations: (entrypoint: unknown, migrations: Readonly<Record<string, SqlMigrationSnapshot>>) => Layer.Layer<any, never, never>;
//# sourceMappingURL=EmbeddedEntrypoint.d.ts.map