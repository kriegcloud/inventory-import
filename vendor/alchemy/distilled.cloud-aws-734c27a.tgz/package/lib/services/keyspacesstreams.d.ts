import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly errorCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ShardIterator = string;
export interface GetRecordsInput {
    shardIterator: string;
    maxResults?: number | undefined;
}
export type OriginType = "USER" | "REPLICATION" | "TTL" | (string & {});
export interface KeyspacesMetadata {
    expirationTime?: string | undefined;
    writeTime?: string | undefined;
}
export interface KeyspacesCell {
    value?: KeyspacesCellValue | undefined;
    metadata?: KeyspacesMetadata | undefined;
}
export type KeyspacesCellList = KeyspacesCell[];
export interface KeyspacesCellMapDefinition {
    key?: KeyspacesCellValue | undefined;
    value?: KeyspacesCellValue | undefined;
    metadata?: KeyspacesMetadata | undefined;
}
export type KeyspacesCellMap = KeyspacesCellMapDefinition[];
export type KeyspacesUdtMap = {
    [key: string]: KeyspacesCell | undefined;
};
export type KeyspacesCellValue = {
    asciiT: string;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT: string;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT: Uint8Array;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT: boolean;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT: string;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT: string;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT: string;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT: string;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT: string;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT: string;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT: string;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT: string;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT: KeyspacesCell[];
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT: KeyspacesCellMapDefinition[];
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT: KeyspacesCell[];
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT: string;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT: string;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT: string;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT: string;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT: string;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT: string;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT: KeyspacesCell[];
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT: string;
    varcharT?: undefined;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT: string;
    varintT?: undefined;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT: string;
    udtT?: undefined;
} | {
    asciiT?: undefined;
    bigintT?: undefined;
    blobT?: undefined;
    boolT?: undefined;
    counterT?: undefined;
    dateT?: undefined;
    decimalT?: undefined;
    doubleT?: undefined;
    durationT?: undefined;
    floatT?: undefined;
    inetT?: undefined;
    intT?: undefined;
    listT?: undefined;
    mapT?: undefined;
    setT?: undefined;
    smallintT?: undefined;
    textT?: undefined;
    timeT?: undefined;
    timestampT?: undefined;
    timeuuidT?: undefined;
    tinyintT?: undefined;
    tupleT?: undefined;
    uuidT?: undefined;
    varcharT?: undefined;
    varintT?: undefined;
    udtT: {
        [key: string]: KeyspacesCell | undefined;
    };
};
export type KeyspacesKeysMap = {
    [key: string]: KeyspacesCellValue | undefined;
};
export type KeyspacesCells = {
    [key: string]: KeyspacesCell | undefined;
};
export interface KeyspacesRow {
    valueCells?: {
        [key: string]: KeyspacesCell | undefined;
    } | undefined;
    staticCells?: {
        [key: string]: KeyspacesCell | undefined;
    } | undefined;
    rowMetadata?: KeyspacesMetadata | undefined;
}
export type SequenceNumber = string;
export interface Record {
    eventVersion?: string | undefined;
    createdAt?: Date | undefined;
    origin?: OriginType | undefined;
    partitionKeys?: {
        [key: string]: KeyspacesCellValue | undefined;
    } | undefined;
    clusteringKeys?: {
        [key: string]: KeyspacesCellValue | undefined;
    } | undefined;
    newImage?: KeyspacesRow | undefined;
    oldImage?: KeyspacesRow | undefined;
    sequenceNumber?: string | undefined;
}
export type RecordList = Record[];
export type IteratorPosition = "AT_TIP" | "BEHIND_TIP" | (string & {});
export interface IteratorDescription {
    iteratorPosition?: IteratorPosition | undefined;
}
export interface GetRecordsOutput {
    changeRecords?: Record[] | undefined;
    nextShardIterator?: string | undefined;
    iteratorDescription?: IteratorDescription | undefined;
}
export type StreamArn = string;
export type ShardId = string;
export type ShardIteratorType = "TRIM_HORIZON" | "LATEST" | "AT_SEQUENCE_NUMBER" | "AFTER_SEQUENCE_NUMBER" | (string & {});
export interface GetShardIteratorInput {
    streamArn: string;
    shardId: string;
    shardIteratorType: ShardIteratorType;
    sequenceNumber?: string | undefined;
}
export interface GetShardIteratorOutput {
    shardIterator?: string | undefined;
}
export type ShardFilterType = "CHILD_SHARDS" | (string & {});
export interface ShardFilter {
    type?: ShardFilterType | undefined;
    shardId?: string | undefined;
}
export type ShardIdToken = string;
export interface GetStreamInput {
    streamArn: string;
    maxResults?: number | undefined;
    shardFilter?: ShardFilter | undefined;
    nextToken?: string | undefined;
}
export type StreamStatus = "ENABLING" | "ENABLED" | "DISABLING" | "DISABLED" | (string & {});
export type StreamViewType = "NEW_IMAGE" | "OLD_IMAGE" | "NEW_AND_OLD_IMAGES" | "KEYS_ONLY" | (string & {});
export type KeyspaceName = string;
export type TableName = string;
export interface SequenceNumberRange {
    startingSequenceNumber?: string | undefined;
    endingSequenceNumber?: string | undefined;
}
export type ShardIdList = string[];
export interface Shard {
    shardId?: string | undefined;
    sequenceNumberRange?: SequenceNumberRange | undefined;
    parentShardIds?: string[] | undefined;
}
export type ShardDescriptionList = Shard[];
export interface GetStreamOutput {
    streamArn: string;
    streamLabel: string;
    streamStatus: StreamStatus;
    streamViewType: StreamViewType;
    creationRequestDateTime: Date;
    keyspaceName: string;
    tableName: string;
    shards?: Shard[] | undefined;
    nextToken?: string | undefined;
}
export type StreamArnToken = string;
export interface ListStreamsInput {
    keyspaceName?: string | undefined;
    tableName?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface Stream {
    streamArn: string;
    keyspaceName: string;
    tableName: string;
    streamLabel: string;
}
export type StreamList = Stream[];
export interface ListStreamsOutput {
    streams?: Stream[] | undefined;
    nextToken?: string | undefined;
}
export type ValidationExceptionType = "InvalidFormat" | "TrimmedDataAccess" | "ExpiredIterator" | "ExpiredNextToken" | (string & {});
export type GetRecordsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves data records from a specified shard in an Amazon Keyspaces data stream. This operation returns a collection of data records from the shard, including the primary key columns and information about modifications made to the captured table data. Each record represents a single data modification in the Amazon Keyspaces table and includes metadata about when the change occurred.
 */
export declare const getRecords: API.OperationMethod<GetRecordsInput & RegionInput, GetRecordsOutput, GetRecordsError, Credentials | HttpClient.HttpClient>;
export type GetShardIteratorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a shard iterator that serves as a bookmark for reading data from a specific position in an Amazon Keyspaces data stream's shard. The shard iterator specifies the shard position from which to start reading data records sequentially. You can specify whether to begin reading at the latest record, the oldest record, or at a particular sequence number within the shard.
 */
export declare const getShardIterator: API.OperationMethod<GetShardIteratorInput & RegionInput, GetShardIteratorOutput, GetShardIteratorError, Credentials | HttpClient.HttpClient>;
export type GetStreamError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns detailed information about a specific data capture stream for an Amazon Keyspaces table. The information includes the stream's Amazon Resource Name (ARN), creation time, current status, retention period, shard composition, and associated table details. This operation helps you monitor and manage the configuration of your Amazon Keyspaces data streams.
 */
export declare const getStream: API.PaginatedOperationMethod<GetStreamInput & RegionInput, GetStreamOutput, GetStreamError, Credentials | HttpClient.HttpClient, Shard>;
export type ListStreamsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all data capture streams associated with your Amazon Keyspaces account or for a specific keyspace or table. The response includes information such as stream ARNs, table associations, creation timestamps, and current status. This operation helps you discover and manage all active data streams in your Amazon Keyspaces environment.
 */
export declare const listStreams: API.PaginatedOperationMethod<ListStreamsInput & RegionInput, ListStreamsOutput, ListStreamsError, Credentials | HttpClient.HttpClient, Stream>;
export {};
//# sourceMappingURL=keyspacesstreams.d.ts.map