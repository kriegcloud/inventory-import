/**
 * How gRPC calls reach a server.
 *
 * A transport is an Effect `HttpClient`: it sends the request
 * `protocol-grpc` builds (`POST`, `application/grpc`, one frame) and returns
 * the response with its body as a stream, so a server-streaming call reads
 * each message as it arrives. gRPC puts the call's status in the trailers;
 * a transport that can read them hands them over with {@link respond}, and
 * the protocol reads them with {@link trailersOf} once the body has ended.
 *
 * By default `protocol-grpc` sends through the caller's `HttpClient`
 * (`fetch`), which works where a proxy bridges HTTP/1.1 to gRPC (envoy) and
 * puts the status in the headers. A transport built here is Effect code: the
 * body is an Effect `Stream` read in the caller's fiber, and the trailers an
 * `Effect` that fails when the transport can't read them, so no failure
 * turns into an empty value on the way. Provide a different transport for one
 * scope with {@link layer}:
 *
 * - `@distilled.cloud/core/grpc-transport-node-http2` speaks HTTP/2 with
 *   `node:http2`, for servers that offer nothing else;
 * - `@distilled.cloud/core/grpc-transport-cloudflare-sockets` speaks HTTP/1.1
 *   over a `cloudflare:sockets` TLS socket, for a Cloudflare Worker calling a
 *   gRPC server that is itself behind Cloudflare (a Worker's `fetch` to such
 *   a site takes Cloudflare's internal path, which resets gRPC upstreams);
 * - `@distilled.cloud/core/grpc-transport-cloudflare-http2` speaks HTTP/2
 *   over a `cloudflare:sockets` socket, for a Cloudflare Worker calling a
 *   server that offers nothing else (workerd has no working `node:http2`).
 *
 * None is imported by this module, so a bundle only carries the ones it
 * provides.
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as HttpClient from "effect/http/HttpClient";
import * as HttpClientError from "effect/http/HttpClientError";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import * as HttpClientResponse from "effect/http/HttpClientResponse";
import * as Layer from "effect/Layer";
import * as Stream from "effect/Stream";
/**
 * The `HttpClient` gRPC calls go through. `undefined` (the default) sends
 * through the caller's `HttpClient`.
 */
export declare const GrpcTransport: Context.Reference<HttpClient.HttpClient | undefined>;
/** Send gRPC calls in this scope through `client`. */
export declare const layer: (client: HttpClient.HttpClient) => Layer.Layer<never>;
/** Header and trailer names are lowercase; values as received. */
export type Trailers = Readonly<Record<string, string>>;
/** What a transport hands over for a response. */
export interface Reply {
    readonly status: number;
    readonly headers: Trailers;
    /**
     * The body as it arrives. It runs in the fiber that reads the response, so
     * that fiber's interruption and finalizers reach the connection.
     */
    readonly body: Stream.Stream<Uint8Array, unknown>;
    /** The trailers, once the body has ended. Fails when they can't be read. */
    readonly trailers: Effect.Effect<Trailers, unknown>;
    /**
     * Whether the trailers always arrive. HTTP/2 delivers them end to end;
     * over HTTP/1.1 a bridging proxy may drop them, so the protocol then
     * treats a reply with messages and no status as OK.
     * @default true
     */
    readonly reliableTrailers?: boolean;
}
/**
 * Whether `status` is a final HTTP status a response can carry (200 to 599).
 * A transport fails the call with a transport error for any other.
 */
export declare const isResponseStatus: (status: number) => boolean;
/**
 * Whether a response with `status` has no body (RFC 9110 sections 15.3.5,
 * 15.3.6 and 15.4.5). Its transport lets the connection go at once.
 */
export declare const hasNoBody: (status: number) => boolean;
/**
 * Build a transport's response from its {@link Reply}. Fails with the
 * `TypeError` of a head that is no valid HTTP head (a header name that is no
 * token, a value with a line break), as `fetch` would. A response with
 * {@link hasNoBody} has an empty body and no trailers.
 */
export declare const respond: (request: HttpClientRequest.HttpClientRequest, reply: Reply) => Effect.Effect<HttpClientResponse.HttpClientResponse, unknown>;
/**
 * Whether `response` came from a transport whose trailers always arrive
 * ({@link Reply.reliableTrailers}), so a missing status is an error.
 */
export declare const hasTrailers: (response: HttpClientResponse.HttpClientResponse) => boolean;
/**
 * The trailers of a response a transport built with {@link respond}, read
 * after its body; empty for any other response (`fetch` exposes none). A
 * transport that can't read them fails with a `DecodeError`.
 */
export declare const trailersOf: (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<Trailers, HttpClientError.HttpClientError>;
//# sourceMappingURL=grpc-transport.d.ts.map