import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type GatewayArn = string;
export type ServerArn = string;
export interface AssociateGatewayToServerInput {
    GatewayArn: string;
    ServerArn: string;
}
export interface AssociateGatewayToServerOutput {
    GatewayArn?: string | undefined;
}
export type ActivationKey = string;
export type Name = string;
export type GatewayType = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export interface CreateGatewayInput {
    ActivationKey: string;
    GatewayDisplayName: string;
    GatewayType: string;
    Tags?: Tag[] | undefined;
}
export interface CreateGatewayOutput {
    GatewayArn?: string | undefined;
}
export interface DeleteGatewayInput {
    GatewayArn: string;
}
export interface DeleteGatewayOutput {
    GatewayArn?: string | undefined;
}
export interface DeleteHypervisorInput {
    HypervisorArn: string;
}
export interface DeleteHypervisorOutput {
    HypervisorArn?: string | undefined;
}
export interface DisassociateGatewayFromServerInput {
    GatewayArn: string;
}
export interface DisassociateGatewayFromServerOutput {
    GatewayArn?: string | undefined;
}
export interface GetBandwidthRateLimitScheduleInput {
    GatewayArn: string;
}
export type AverageUploadRateLimit = number;
export type HourOfDay = number;
export type MinuteOfHour = number;
export type DayOfWeek = number;
export type DaysOfWeek = number[];
export interface BandwidthRateLimitInterval {
    AverageUploadRateLimitInBitsPerSec?: number | undefined;
    StartHourOfDay: number;
    EndHourOfDay: number;
    StartMinuteOfHour: number;
    EndMinuteOfHour: number;
    DaysOfWeek: number[];
}
export type BandwidthRateLimitIntervals = BandwidthRateLimitInterval[];
export interface GetBandwidthRateLimitScheduleOutput {
    GatewayArn?: string | undefined;
    BandwidthRateLimitIntervals?: BandwidthRateLimitInterval[] | undefined;
}
export interface GetGatewayInput {
    GatewayArn: string;
}
export type HypervisorId = string;
export type DayOfMonth = number;
export interface MaintenanceStartTime {
    DayOfMonth?: number | undefined;
    DayOfWeek?: number | undefined;
    HourOfDay: number;
    MinuteOfHour: number;
}
export type VpcEndpoint = string;
export interface GatewayDetails {
    GatewayArn?: string | undefined;
    GatewayDisplayName?: string | undefined;
    GatewayType?: string | undefined;
    HypervisorId?: string | undefined;
    LastSeenTime?: Date | undefined;
    MaintenanceStartTime?: MaintenanceStartTime | undefined;
    NextUpdateAvailabilityTime?: Date | undefined;
    VpcEndpoint?: string | undefined;
    DeprecationDate?: Date | undefined;
    SoftwareVersion?: string | undefined;
}
export interface GetGatewayOutput {
    Gateway?: GatewayDetails | undefined;
}
export interface GetHypervisorInput {
    HypervisorArn: string;
}
export type Host = string;
export type KmsKeyArn = string;
export type LogGroupArn = string;
export type HypervisorState = string;
export type SyncMetadataStatus = string;
export interface HypervisorDetails {
    Host?: string | undefined;
    HypervisorArn?: string | undefined;
    KmsKeyArn?: string | undefined;
    Name?: string | undefined;
    LogGroupArn?: string | undefined;
    State?: string | undefined;
    LastSuccessfulMetadataSyncTime?: Date | undefined;
    LatestMetadataSyncStatusMessage?: string | undefined;
    LatestMetadataSyncStatus?: string | undefined;
}
export interface GetHypervisorOutput {
    Hypervisor?: HypervisorDetails | undefined;
}
export interface GetHypervisorPropertyMappingsInput {
    HypervisorArn: string;
}
export type VmwareCategory = string;
export type VmwareTagName = string;
export interface VmwareToAwsTagMapping {
    VmwareCategory: string;
    VmwareTagName: string;
    AwsTagKey: string;
    AwsTagValue: string;
}
export type VmwareToAwsTagMappings = VmwareToAwsTagMapping[];
export type IamRoleArn = string;
export interface GetHypervisorPropertyMappingsOutput {
    HypervisorArn?: string | undefined;
    VmwareToAwsTagMappings?: VmwareToAwsTagMapping[] | undefined;
    IamRoleArn?: string | undefined;
}
export type ResourceArn = string;
export interface GetVirtualMachineInput {
    ResourceArn: string;
}
export type Path = string;
export interface VmwareTag {
    VmwareCategory?: string | undefined;
    VmwareTagName?: string | undefined;
    VmwareTagDescription?: string | undefined;
}
export type VmwareTags = VmwareTag[];
export interface VirtualMachineDetails {
    HostName?: string | undefined;
    HypervisorId?: string | undefined;
    Name?: string | undefined;
    Path?: string | undefined;
    ResourceArn?: string | undefined;
    LastBackupDate?: Date | undefined;
    VmwareTags?: VmwareTag[] | undefined;
}
export interface GetVirtualMachineOutput {
    VirtualMachine?: VirtualMachineDetails | undefined;
}
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface ImportHypervisorConfigurationInput {
    Name: string;
    Host: string;
    Username?: string | redacted.Redacted<string> | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    KmsKeyArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportHypervisorConfigurationOutput {
    HypervisorArn?: string | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListGatewaysInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Gateway {
    GatewayArn?: string | undefined;
    GatewayDisplayName?: string | undefined;
    GatewayType?: string | undefined;
    HypervisorId?: string | undefined;
    LastSeenTime?: Date | undefined;
}
export type Gateways = Gateway[];
export interface ListGatewaysOutput {
    Gateways?: Gateway[] | undefined;
    NextToken?: string | undefined;
}
export interface ListHypervisorsInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface Hypervisor {
    Host?: string | undefined;
    HypervisorArn?: string | undefined;
    KmsKeyArn?: string | undefined;
    Name?: string | undefined;
    State?: string | undefined;
}
export type Hypervisors = Hypervisor[];
export interface ListHypervisorsOutput {
    Hypervisors?: Hypervisor[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ListVirtualMachinesInput {
    HypervisorArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface VirtualMachine {
    HostName?: string | undefined;
    HypervisorId?: string | undefined;
    Name?: string | undefined;
    Path?: string | undefined;
    ResourceArn?: string | undefined;
    LastBackupDate?: Date | undefined;
}
export type VirtualMachines = VirtualMachine[];
export interface ListVirtualMachinesOutput {
    VirtualMachines?: VirtualMachine[] | undefined;
    NextToken?: string | undefined;
}
export interface PutBandwidthRateLimitScheduleInput {
    GatewayArn: string;
    BandwidthRateLimitIntervals: BandwidthRateLimitInterval[];
}
export interface PutBandwidthRateLimitScheduleOutput {
    GatewayArn?: string | undefined;
}
export interface PutHypervisorPropertyMappingsInput {
    HypervisorArn: string;
    VmwareToAwsTagMappings: VmwareToAwsTagMapping[];
    IamRoleArn: string;
}
export interface PutHypervisorPropertyMappingsOutput {
    HypervisorArn?: string | undefined;
}
export interface PutMaintenanceStartTimeInput {
    GatewayArn: string;
    HourOfDay: number;
    MinuteOfHour: number;
    DayOfWeek?: number | undefined;
    DayOfMonth?: number | undefined;
}
export interface PutMaintenanceStartTimeOutput {
    GatewayArn?: string | undefined;
}
export interface StartVirtualMachinesMetadataSyncInput {
    HypervisorArn: string;
}
export interface StartVirtualMachinesMetadataSyncOutput {
    HypervisorArn?: string | undefined;
}
export interface TagResourceInput {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
    ResourceARN?: string | undefined;
}
export interface TestHypervisorConfigurationInput {
    GatewayArn: string;
    Host: string;
    Username?: string | redacted.Redacted<string> | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export interface TestHypervisorConfigurationOutput {
}
export type TagKeys = string[];
export interface UntagResourceInput {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
    ResourceARN?: string | undefined;
}
export interface UpdateGatewayInformationInput {
    GatewayArn: string;
    GatewayDisplayName?: string | undefined;
}
export interface UpdateGatewayInformationOutput {
    GatewayArn?: string | undefined;
}
export interface UpdateGatewaySoftwareNowInput {
    GatewayArn: string;
}
export interface UpdateGatewaySoftwareNowOutput {
    GatewayArn?: string | undefined;
}
export interface UpdateHypervisorInput {
    HypervisorArn: string;
    Host?: string | undefined;
    Username?: string | redacted.Redacted<string> | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Name?: string | undefined;
    LogGroupArn?: string | undefined;
}
export interface UpdateHypervisorOutput {
    HypervisorArn?: string | undefined;
}
export type AssociateGatewayToServerError = ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates a backup gateway with your server. After you complete the association process, you can back up and restore your VMs through the gateway.
 */
export declare const associateGatewayToServer: API.OperationMethod<AssociateGatewayToServerInput & RegionInput, AssociateGatewayToServerOutput, AssociateGatewayToServerError, Credentials | HttpClient.HttpClient>;
export type CreateGatewayError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a backup gateway. After you create a gateway, you can associate it with a server using the `AssociateGatewayToServer` operation.
 */
export declare const createGateway: API.OperationMethod<CreateGatewayInput & RegionInput, CreateGatewayOutput, CreateGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a backup gateway.
 */
export declare const deleteGateway: API.OperationMethod<DeleteGatewayInput & RegionInput, DeleteGatewayOutput, DeleteGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteHypervisorError = AccessDeniedException | ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a hypervisor.
 */
export declare const deleteHypervisor: API.OperationMethod<DeleteHypervisorInput & RegionInput, DeleteHypervisorOutput, DeleteHypervisorError, Credentials | HttpClient.HttpClient>;
export type DisassociateGatewayFromServerError = ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a backup gateway from the specified server. After the disassociation process finishes, the gateway can no longer access the virtual machines on the server.
 */
export declare const disassociateGatewayFromServer: API.OperationMethod<DisassociateGatewayFromServerInput & RegionInput, DisassociateGatewayFromServerOutput, DisassociateGatewayFromServerError, Credentials | HttpClient.HttpClient>;
export type GetBandwidthRateLimitScheduleError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the bandwidth rate limit schedule for a specified gateway. By default, gateways do not have bandwidth rate limit schedules, which means no bandwidth rate limiting is in effect. Use this to get a gateway's bandwidth rate limit schedule.
 */
export declare const getBandwidthRateLimitSchedule: API.OperationMethod<GetBandwidthRateLimitScheduleInput & RegionInput, GetBandwidthRateLimitScheduleOutput, GetBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type GetGatewayError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * By providing the ARN (Amazon Resource Name), this API returns the gateway.
 */
export declare const getGateway: API.OperationMethod<GetGatewayInput & RegionInput, GetGatewayOutput, GetGatewayError, Credentials | HttpClient.HttpClient>;
export type GetHypervisorError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action requests information about the specified hypervisor to which the gateway will connect. A hypervisor is hardware, software, or firmware that creates and manages virtual machines, and allocates resources to them.
 */
export declare const getHypervisor: API.OperationMethod<GetHypervisorInput & RegionInput, GetHypervisorOutput, GetHypervisorError, Credentials | HttpClient.HttpClient>;
export type GetHypervisorPropertyMappingsError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action retrieves the property mappings for the specified hypervisor. A hypervisor property mapping displays the relationship of entity properties available from the hypervisor to the properties available in Amazon Web Services.
 */
export declare const getHypervisorPropertyMappings: API.OperationMethod<GetHypervisorPropertyMappingsInput & RegionInput, GetHypervisorPropertyMappingsOutput, GetHypervisorPropertyMappingsError, Credentials | HttpClient.HttpClient>;
export type GetVirtualMachineError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * By providing the ARN (Amazon Resource Name), this API returns the virtual machine.
 */
export declare const getVirtualMachine: API.OperationMethod<GetVirtualMachineInput & RegionInput, GetVirtualMachineOutput, GetVirtualMachineError, Credentials | HttpClient.HttpClient>;
export type ImportHypervisorConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Connect to a hypervisor by importing its configuration.
 */
export declare const importHypervisorConfiguration: API.OperationMethod<ImportHypervisorConfigurationInput & RegionInput, ImportHypervisorConfigurationOutput, ImportHypervisorConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListGatewaysError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists backup gateways owned by an Amazon Web Services account in an Amazon Web Services Region. The returned list is ordered by gateway Amazon Resource Name (ARN).
 */
export declare const listGateways: API.PaginatedOperationMethod<ListGatewaysInput & RegionInput, ListGatewaysOutput, ListGatewaysError, Credentials | HttpClient.HttpClient, Gateway>;
export type ListHypervisorsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists your hypervisors.
 */
export declare const listHypervisors: API.PaginatedOperationMethod<ListHypervisorsInput & RegionInput, ListHypervisorsOutput, ListHypervisorsError, Credentials | HttpClient.HttpClient, Hypervisor>;
export type ListTagsForResourceError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags applied to the resource identified by its Amazon Resource Name (ARN).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVirtualMachinesError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists your virtual machines.
 */
export declare const listVirtualMachines: API.PaginatedOperationMethod<ListVirtualMachinesInput & RegionInput, ListVirtualMachinesOutput, ListVirtualMachinesError, Credentials | HttpClient.HttpClient, VirtualMachine>;
export type PutBandwidthRateLimitScheduleError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action sets the bandwidth rate limit schedule for a specified gateway. By default, gateways do not have a bandwidth rate limit schedule, which means no bandwidth rate limiting is in effect. Use this to initiate a gateway's bandwidth rate limit schedule.
 */
export declare const putBandwidthRateLimitSchedule: API.OperationMethod<PutBandwidthRateLimitScheduleInput & RegionInput, PutBandwidthRateLimitScheduleOutput, PutBandwidthRateLimitScheduleError, Credentials | HttpClient.HttpClient>;
export type PutHypervisorPropertyMappingsError = AccessDeniedException | ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action sets the property mappings for the specified hypervisor. A hypervisor property mapping displays the relationship of entity properties available from the hypervisor to the properties available in Amazon Web Services.
 */
export declare const putHypervisorPropertyMappings: API.OperationMethod<PutHypervisorPropertyMappingsInput & RegionInput, PutHypervisorPropertyMappingsOutput, PutHypervisorPropertyMappingsError, Credentials | HttpClient.HttpClient>;
export type PutMaintenanceStartTimeError = ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Set the maintenance start time for a gateway.
 */
export declare const putMaintenanceStartTime: API.OperationMethod<PutMaintenanceStartTimeInput & RegionInput, PutMaintenanceStartTimeOutput, PutMaintenanceStartTimeError, Credentials | HttpClient.HttpClient>;
export type StartVirtualMachinesMetadataSyncError = AccessDeniedException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action sends a request to sync metadata across the specified virtual machines.
 */
export declare const startVirtualMachinesMetadataSync: API.OperationMethod<StartVirtualMachinesMetadataSyncInput & RegionInput, StartVirtualMachinesMetadataSyncOutput, StartVirtualMachinesMetadataSyncError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag the resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestHypervisorConfigurationError = ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tests your hypervisor configuration to validate that backup gateway can connect with the hypervisor and its resources.
 */
export declare const testHypervisorConfiguration: API.OperationMethod<TestHypervisorConfigurationInput & RegionInput, TestHypervisorConfigurationOutput, TestHypervisorConfigurationError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from the resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayInformationError = ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a gateway's name. Specify which gateway to update using the Amazon Resource Name (ARN) of the gateway in your request.
 */
export declare const updateGatewayInformation: API.OperationMethod<UpdateGatewayInformationInput & RegionInput, UpdateGatewayInformationOutput, UpdateGatewayInformationError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewaySoftwareNowError = ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the gateway virtual machine (VM) software. The request immediately triggers the software update.
 *
 * When you make this request, you get a `200 OK` success response immediately. However, it might take some time for the update to complete.
 */
export declare const updateGatewaySoftwareNow: API.OperationMethod<UpdateGatewaySoftwareNowInput & RegionInput, UpdateGatewaySoftwareNowOutput, UpdateGatewaySoftwareNowError, Credentials | HttpClient.HttpClient>;
export type UpdateHypervisorError = AccessDeniedException | ConflictException | ResourceNotFoundException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a hypervisor metadata, including its host, username, and password. Specify which hypervisor to update using the Amazon Resource Name (ARN) of the hypervisor in your request.
 */
export declare const updateHypervisor: API.OperationMethod<UpdateHypervisorInput & RegionInput, UpdateHypervisorOutput, UpdateHypervisorError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=backup-gateway.d.ts.map