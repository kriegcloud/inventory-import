import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetRequest {
}
export type GetResponseBodyMap = {
    [key: string]: string | undefined;
};
export type GetResponse = GetResponseBodyMap;
export type GetError = GithubOpError;
/** Get emojis Lists all the emojis available to use on GitHub. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, GithubOpContext>;
//# sourceMappingURL=emojis.d.ts.map