import type * as SchemaAST from "effect/SchemaAST";
import type { Brand, Run, V } from "./Value.ts";
/** A check the prover does not read, and the part of a value it is on. */
export interface Unread {
    /** The properties that lead to the part, from the top. */
    readonly path: ReadonlyArray<string>;
    /** The part, as a reader names it: `state.code`. */
    readonly at: string;
    /** The check, as its schema says it. */
    readonly check: string;
}
/** The checks of a schema the prover does not read, each with the part it is on. */
export declare const unread: (schema: unknown, name: string) => ReadonlyArray<Unread>;
/** The most items the prover gives a list whose length the schema leaves open. */
export declare const MAX_ITEMS = 2;
/**
 * The items of a list an input holds, on this path: a length the run chooses,
 * and an input for each item. A list the schema lets grow past `MAX_ITEMS` is
 * tried only up to there, and the run says so.
 */
export declare const force: (list: V & {
    readonly _tag: "List";
}, run: Run) => V;
/** The type side of a schema: what `decide` and `evolve` see. */
export declare const typeOf: (schema: unknown) => SchemaAST.AST | undefined;
/**
 * Every value a schema allows, as one symbolic value: an input constant per
 * leaf, with the schema's bounds assumed. A union is a choice the run makes.
 */
export declare const symbolic: (ast: SchemaAST.AST, name: string, run: Run, brand?: Brand) => V;
/**
 * Assume a value passes a schema's checks, where the prover reads them: a
 * domain class refuses to construct otherwise, so nothing is committed.
 * Returns `false` when the value can never pass.
 */
export declare const assumeFits: (value: V, ast: SchemaAST.AST, run: Run) => boolean;
/**
 * That a value is one a schema allows, as a formula: what `symbolic` assumes
 * of an input, asked of a value the code made. Where the prover does not read
 * a schema, the formula is `true`.
 */
export declare const fits: (value: V, ast: SchemaAST.AST, run?: Run) => string;
/** A reason a counterexample's input cannot be built as a real value. */
export interface Unbuildable {
    readonly _tag: "Unbuildable";
    readonly reason: string;
}
/**
 * The real value of a symbolic one in a counterexample: each input constant
 * takes the value the solver found.
 */
export declare const concretize: (value: V, model: ReadonlyMap<string, number | bigint | string | boolean>, 
/** The items each list was given on the path the values come from. */
lists?: ReadonlyMap<string, V>) => {
    readonly value: unknown;
} | Unbuildable;
/** A value as it would be written in TypeScript, on one line. */
export declare const show: (value: unknown) => string;
//# sourceMappingURL=Symbolic.d.ts.map