import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const DryRunOperationException_base: S.TaggedErrorClass<"DryRunOperationException", {
    readonly message: any;
}>;
export declare class DryRunOperationException extends /*@__PURE__*/ DryRunOperationException_base {
}
declare const EntitlementAlreadyExistsException_base: S.TaggedErrorClass<"EntitlementAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class EntitlementAlreadyExistsException extends /*@__PURE__*/ EntitlementAlreadyExistsException_base {
}
declare const EntitlementNotFoundException_base: S.TaggedErrorClass<"EntitlementNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EntitlementNotFoundException extends /*@__PURE__*/ EntitlementNotFoundException_base {
}
declare const IncompatibleImageException_base: S.TaggedErrorClass<"IncompatibleImageException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleImageException extends /*@__PURE__*/ IncompatibleImageException_base {
}
declare const InvalidAccountStatusException_base: S.TaggedErrorClass<"InvalidAccountStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAccountStatusException extends /*@__PURE__*/ InvalidAccountStatusException_base {
}
declare const InvalidParameterCombinationException_base: S.TaggedErrorClass<"InvalidParameterCombinationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterCombinationException extends /*@__PURE__*/ InvalidParameterCombinationException_base {
}
declare const InvalidRoleException_base: S.TaggedErrorClass<"InvalidRoleException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRoleException extends /*@__PURE__*/ InvalidRoleException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OperationNotPermittedException_base: S.TaggedErrorClass<"OperationNotPermittedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotPermittedException extends /*@__PURE__*/ OperationNotPermittedException_base {
}
declare const RequestLimitExceededException_base: S.TaggedErrorClass<"RequestLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class RequestLimitExceededException extends /*@__PURE__*/ RequestLimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotAvailableException_base: S.TaggedErrorClass<"ResourceNotAvailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotAvailableException extends /*@__PURE__*/ ResourceNotAvailableException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type Arn = string;
export type Name = string;
export interface AssociateAppBlockBuilderAppBlockRequest {
    AppBlockArn?: string | undefined;
    AppBlockBuilderName?: string | undefined;
}
export interface AppBlockBuilderAppBlockAssociation {
    AppBlockArn?: string | undefined;
    AppBlockBuilderName?: string | undefined;
}
export interface AssociateAppBlockBuilderAppBlockResult {
    AppBlockBuilderAppBlockAssociation?: (AppBlockBuilderAppBlockAssociation & {
        AppBlockArn: Arn;
        AppBlockBuilderName: Name;
    }) | undefined;
}
export interface AssociateApplicationFleetRequest {
    FleetName?: string | undefined;
    ApplicationArn?: string | undefined;
}
export interface ApplicationFleetAssociation {
    FleetName?: string | undefined;
    ApplicationArn?: string | undefined;
}
export interface AssociateApplicationFleetResult {
    ApplicationFleetAssociation?: (ApplicationFleetAssociation & {
        FleetName: string;
        ApplicationArn: Arn;
    }) | undefined;
}
export interface AssociateApplicationToEntitlementRequest {
    StackName?: string | undefined;
    EntitlementName?: string | undefined;
    ApplicationIdentifier?: string | undefined;
}
export interface AssociateApplicationToEntitlementResult {
}
export interface AssociateFleetRequest {
    FleetName?: string | undefined;
    StackName?: string | undefined;
}
export interface AssociateFleetResult {
}
export type StringList = string[];
export interface AssociateSoftwareToImageBuilderRequest {
    ImageBuilderName?: string | undefined;
    SoftwareNames?: string[] | undefined;
}
export interface AssociateSoftwareToImageBuilderResult {
}
export type Username = string | redacted.Redacted<string>;
export type AuthenticationType = "API" | "SAML" | "USERPOOL" | "AWS_AD" | (string & {});
export interface UserStackAssociation {
    StackName?: string | undefined;
    UserName?: string | redacted.Redacted<string> | undefined;
    AuthenticationType?: AuthenticationType | undefined;
    SendEmailNotification?: boolean | undefined;
}
export type UserStackAssociationList = UserStackAssociation[];
export interface BatchAssociateUserStackRequest {
    UserStackAssociations?: UserStackAssociation[] | undefined;
}
export type UserStackAssociationErrorCode = "STACK_NOT_FOUND" | "USER_NAME_NOT_FOUND" | "DIRECTORY_NOT_FOUND" | "INTERNAL_ERROR" | (string & {});
export interface UserStackAssociationError {
    UserStackAssociation?: UserStackAssociation | undefined;
    ErrorCode?: UserStackAssociationErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type UserStackAssociationErrorList = UserStackAssociationError[];
export interface BatchAssociateUserStackResult {
    errors?: (UserStackAssociationError & {
        UserStackAssociation: UserStackAssociation & {
            StackName: string;
            UserName: Username;
            AuthenticationType: AuthenticationType;
        };
    })[] | undefined;
}
export interface BatchDisassociateUserStackRequest {
    UserStackAssociations?: UserStackAssociation[] | undefined;
}
export interface BatchDisassociateUserStackResult {
    errors?: (UserStackAssociationError & {
        UserStackAssociation: UserStackAssociation & {
            StackName: string;
            UserName: Username;
            AuthenticationType: AuthenticationType;
        };
    })[] | undefined;
}
export type RegionName = string;
export type Description = string;
export interface CopyImageRequest {
    SourceImageName?: string | undefined;
    DestinationImageName?: string | undefined;
    DestinationRegion?: string | undefined;
    DestinationImageDescription?: string | undefined;
}
export interface CopyImageResponse {
    DestinationImageName?: string | undefined;
}
export type DisplayName = string;
export type S3Bucket = string;
export type S3Key = string;
export interface S3Location {
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
}
export interface ScriptDetails {
    ScriptS3Location?: S3Location | undefined;
    ExecutablePath?: string | undefined;
    ExecutableParameters?: string | undefined;
    TimeoutInSeconds?: number | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type Tags = {
    [key: string]: string | undefined;
};
export type PackagingType = "CUSTOM" | "APPSTREAM2" | (string & {});
export interface CreateAppBlockRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    SourceS3Location?: S3Location | undefined;
    SetupScriptDetails?: ScriptDetails | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    PostSetupScriptDetails?: ScriptDetails | undefined;
    PackagingType?: PackagingType | undefined;
}
export type AppBlockState = "INACTIVE" | "ACTIVE" | (string & {});
export interface ErrorDetails {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type ErrorDetailsList = ErrorDetails[];
export interface AppBlock {
    Name?: string | undefined;
    Arn?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    SourceS3Location?: S3Location | undefined;
    SetupScriptDetails?: ScriptDetails | undefined;
    CreatedTime?: Date | undefined;
    PostSetupScriptDetails?: ScriptDetails | undefined;
    PackagingType?: PackagingType | undefined;
    State?: AppBlockState | undefined;
    AppBlockErrors?: ErrorDetails[] | undefined;
}
export interface CreateAppBlockResult {
    AppBlock?: (AppBlock & {
        Name: string;
        Arn: Arn;
        SourceS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
        SetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
        PostSetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
    }) | undefined;
}
export type AppBlockBuilderPlatformType = "WINDOWS_SERVER_2019" | (string & {});
export type SubnetIdList = string[];
export type SecurityGroupIdList = string[];
export interface VpcConfig {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export type AccessEndpointType = "STREAMING" | (string & {});
export interface AccessEndpoint {
    EndpointType?: AccessEndpointType | undefined;
    VpceId?: string | undefined;
}
export type AccessEndpointList = AccessEndpoint[];
export interface CreateAppBlockBuilderRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Platform?: AppBlockBuilderPlatformType | undefined;
    InstanceType?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    IamRoleArn?: string | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    DisableIMDSV1?: boolean | undefined;
}
export type AppBlockBuilderState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | (string & {});
export type FleetErrorCode = "IAM_SERVICE_ROLE_MISSING_ENI_DESCRIBE_ACTION" | "IAM_SERVICE_ROLE_MISSING_ENI_CREATE_ACTION" | "IAM_SERVICE_ROLE_MISSING_ENI_DELETE_ACTION" | "NETWORK_INTERFACE_LIMIT_EXCEEDED" | "INTERNAL_SERVICE_ERROR" | "IAM_SERVICE_ROLE_IS_MISSING" | "MACHINE_ROLE_IS_MISSING" | "STS_DISABLED_IN_REGION" | "SUBNET_HAS_INSUFFICIENT_IP_ADDRESSES" | "IAM_SERVICE_ROLE_MISSING_DESCRIBE_SUBNET_ACTION" | "SUBNET_NOT_FOUND" | "IMAGE_NOT_FOUND" | "INVALID_SUBNET_CONFIGURATION" | "SECURITY_GROUPS_NOT_FOUND" | "IGW_NOT_ATTACHED" | "IAM_SERVICE_ROLE_MISSING_DESCRIBE_SECURITY_GROUPS_ACTION" | "FLEET_STOPPED" | "FLEET_INSTANCE_PROVISIONING_FAILURE" | "DOMAIN_JOIN_ERROR_FILE_NOT_FOUND" | "DOMAIN_JOIN_ERROR_ACCESS_DENIED" | "DOMAIN_JOIN_ERROR_LOGON_FAILURE" | "DOMAIN_JOIN_ERROR_INVALID_PARAMETER" | "DOMAIN_JOIN_ERROR_MORE_DATA" | "DOMAIN_JOIN_ERROR_NO_SUCH_DOMAIN" | "DOMAIN_JOIN_ERROR_NOT_SUPPORTED" | "DOMAIN_JOIN_NERR_INVALID_WORKGROUP_NAME" | "DOMAIN_JOIN_NERR_WORKSTATION_NOT_STARTED" | "DOMAIN_JOIN_ERROR_DS_MACHINE_ACCOUNT_QUOTA_EXCEEDED" | "DOMAIN_JOIN_NERR_PASSWORD_EXPIRED" | "DOMAIN_JOIN_INTERNAL_SERVICE_ERROR" | "VALIDATION_ERROR" | (string & {});
export interface ResourceError {
    ErrorCode?: FleetErrorCode | undefined;
    ErrorMessage?: string | undefined;
    ErrorTimestamp?: Date | undefined;
}
export type ResourceErrors = ResourceError[];
export type AppBlockBuilderStateChangeReasonCode = "INTERNAL_ERROR" | (string & {});
export interface AppBlockBuilderStateChangeReason {
    Code?: AppBlockBuilderStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface AppBlockBuilder {
    Arn?: string | undefined;
    Name?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    Platform?: AppBlockBuilderPlatformType | undefined;
    InstanceType?: string | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    IamRoleArn?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    State?: AppBlockBuilderState | undefined;
    CreatedTime?: Date | undefined;
    AppBlockBuilderErrors?: ResourceError[] | undefined;
    StateChangeReason?: AppBlockBuilderStateChangeReason | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    DisableIMDSV1?: boolean | undefined;
}
export interface CreateAppBlockBuilderResult {
    AppBlockBuilder?: (AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    }) | undefined;
}
export interface CreateAppBlockBuilderStreamingURLRequest {
    AppBlockBuilderName?: string | undefined;
    Validity?: number | undefined;
}
export interface CreateAppBlockBuilderStreamingURLResult {
    StreamingURL?: string | undefined;
    Expires?: Date | undefined;
}
export type PlatformType = "WINDOWS" | "WINDOWS_SERVER_2016" | "WINDOWS_SERVER_2019" | "WINDOWS_SERVER_2022" | "WINDOWS_SERVER_2025" | "WINDOWS_11" | "AMAZON_LINUX2" | "RHEL8" | "ROCKY_LINUX8" | "UBUNTU_PRO_2404" | (string & {});
export type Platforms = PlatformType[];
export interface CreateApplicationRequest {
    Name?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    IconS3Location?: S3Location | undefined;
    LaunchPath?: string | undefined;
    WorkingDirectory?: string | undefined;
    LaunchParameters?: string | undefined;
    Platforms?: PlatformType[] | undefined;
    InstanceFamilies?: string[] | undefined;
    AppBlockArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Metadata = {
    [key: string]: string | undefined;
};
export interface Application {
    Name?: string | undefined;
    DisplayName?: string | undefined;
    IconURL?: string | undefined;
    LaunchPath?: string | undefined;
    LaunchParameters?: string | undefined;
    Enabled?: boolean | undefined;
    Metadata?: {
        [key: string]: string | undefined;
    } | undefined;
    WorkingDirectory?: string | undefined;
    Description?: string | undefined;
    Arn?: string | undefined;
    AppBlockArn?: string | undefined;
    IconS3Location?: S3Location | undefined;
    Platforms?: PlatformType[] | undefined;
    InstanceFamilies?: string[] | undefined;
    CreatedTime?: Date | undefined;
}
export interface CreateApplicationResult {
    Application?: (Application & {
        IconS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    }) | undefined;
}
export type DirectoryName = string;
export type OrganizationalUnitDistinguishedName = string;
export type OrganizationalUnitDistinguishedNamesList = string[];
export type AccountName = string | redacted.Redacted<string>;
export type AccountPassword = string | redacted.Redacted<string>;
export interface ServiceAccountCredentials {
    AccountName?: string | redacted.Redacted<string> | undefined;
    AccountPassword?: string | redacted.Redacted<string> | undefined;
}
export type CertificateBasedAuthStatus = "DISABLED" | "ENABLED" | "ENABLED_NO_DIRECTORY_LOGIN_FALLBACK" | (string & {});
export interface CertificateBasedAuthProperties {
    Status?: CertificateBasedAuthStatus | undefined;
    CertificateAuthorityArn?: string | undefined;
}
export interface CreateDirectoryConfigRequest {
    DirectoryName?: string | undefined;
    OrganizationalUnitDistinguishedNames?: string[] | undefined;
    ServiceAccountCredentials?: ServiceAccountCredentials | undefined;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties | undefined;
}
export interface DirectoryConfig {
    DirectoryName?: string | undefined;
    OrganizationalUnitDistinguishedNames?: string[] | undefined;
    ServiceAccountCredentials?: ServiceAccountCredentials | undefined;
    CreatedTime?: Date | undefined;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties | undefined;
}
export interface CreateDirectoryConfigResult {
    DirectoryConfig?: (DirectoryConfig & {
        DirectoryName: DirectoryName;
        ServiceAccountCredentials: ServiceAccountCredentials & {
            AccountName: AccountName;
            AccountPassword: AccountPassword;
        };
    }) | undefined;
}
export type AppVisibility = "ALL" | "ASSOCIATED" | (string & {});
export interface EntitlementAttribute {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type EntitlementAttributeList = EntitlementAttribute[];
export interface CreateEntitlementRequest {
    Name?: string | undefined;
    StackName?: string | undefined;
    Description?: string | undefined;
    AppVisibility?: AppVisibility | undefined;
    Attributes?: EntitlementAttribute[] | undefined;
}
export interface Entitlement {
    Name?: string | undefined;
    StackName?: string | undefined;
    Description?: string | undefined;
    AppVisibility?: AppVisibility | undefined;
    Attributes?: EntitlementAttribute[] | undefined;
    CreatedTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface CreateEntitlementResult {
    Entitlement?: (Entitlement & {
        Name: Name;
        StackName: Name;
        AppVisibility: AppVisibility;
        Attributes: (EntitlementAttribute & {
            Name: string;
            Value: string;
        })[];
    }) | undefined;
}
export type AmiName = string;
export interface CreateExportImageTaskRequest {
    ImageName?: string | undefined;
    AmiName?: string | undefined;
    IamRoleArn?: string | undefined;
    TagSpecifications?: {
        [key: string]: string | undefined;
    } | undefined;
    AmiDescription?: string | undefined;
}
export type UUID = string;
export type ExportImageTaskState = "EXPORTING" | "COMPLETED" | "FAILED" | "TIMED_OUT" | (string & {});
export type PhotonAmiId = string;
export interface ExportImageTask {
    TaskId?: string | undefined;
    ImageArn?: string | undefined;
    AmiName?: string | undefined;
    CreatedDate?: Date | undefined;
    AmiDescription?: string | undefined;
    State?: ExportImageTaskState | undefined;
    AmiId?: string | undefined;
    TagSpecifications?: {
        [key: string]: string | undefined;
    } | undefined;
    ErrorDetails?: ErrorDetails[] | undefined;
}
export interface CreateExportImageTaskResult {
    ExportImageTask?: (ExportImageTask & {
        TaskId: UUID;
        ImageArn: Arn;
        AmiName: AmiName;
        CreatedDate: Date;
    }) | undefined;
}
export type FleetType = "ALWAYS_ON" | "ON_DEMAND" | "ELASTIC" | (string & {});
export interface ComputeCapacity {
    DesiredInstances?: number | undefined;
    DesiredSessions?: number | undefined;
}
export interface DomainJoinInfo {
    DirectoryName?: string | undefined;
    OrganizationalUnitDistinguishedName?: string | undefined;
}
export type StreamView = "APP" | "DESKTOP" | (string & {});
export type UsbDeviceFilterString = string;
export type UsbDeviceFilterStrings = string[];
export interface VolumeConfig {
    VolumeSizeInGb?: number | undefined;
}
export interface CreateFleetRequest {
    Name?: string | undefined;
    ImageName?: string | undefined;
    ImageArn?: string | undefined;
    InstanceType?: string | undefined;
    FleetType?: FleetType | undefined;
    ComputeCapacity?: ComputeCapacity | undefined;
    VpcConfig?: VpcConfig | undefined;
    MaxUserDurationInSeconds?: number | undefined;
    DisconnectTimeoutInSeconds?: number | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    DomainJoinInfo?: DomainJoinInfo | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    IdleDisconnectTimeoutInSeconds?: number | undefined;
    IamRoleArn?: string | undefined;
    StreamView?: StreamView | undefined;
    Platform?: PlatformType | undefined;
    MaxConcurrentSessions?: number | undefined;
    UsbDeviceFilterStrings?: string[] | undefined;
    SessionScriptS3Location?: S3Location | undefined;
    MaxSessionsPerInstance?: number | undefined;
    RootVolumeConfig?: VolumeConfig | undefined;
    DisableIMDSV1?: boolean | undefined;
}
export interface ComputeCapacityStatus {
    Desired?: number | undefined;
    Running?: number | undefined;
    InUse?: number | undefined;
    Available?: number | undefined;
    DesiredUserSessions?: number | undefined;
    AvailableUserSessions?: number | undefined;
    ActiveUserSessions?: number | undefined;
    ActualUserSessions?: number | undefined;
    Draining?: number | undefined;
    DrainModeActiveUserSessions?: number | undefined;
    DrainModeUnusedUserSessions?: number | undefined;
}
export type FleetState = "STARTING" | "RUNNING" | "STOPPING" | "STOPPED" | (string & {});
export interface FleetError {
    ErrorCode?: FleetErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type FleetErrors = FleetError[];
export interface Fleet {
    Arn?: string | undefined;
    Name?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    ImageName?: string | undefined;
    ImageArn?: string | undefined;
    InstanceType?: string | undefined;
    FleetType?: FleetType | undefined;
    ComputeCapacityStatus?: ComputeCapacityStatus | undefined;
    MaxUserDurationInSeconds?: number | undefined;
    DisconnectTimeoutInSeconds?: number | undefined;
    State?: FleetState | undefined;
    VpcConfig?: VpcConfig | undefined;
    CreatedTime?: Date | undefined;
    FleetErrors?: FleetError[] | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    DomainJoinInfo?: DomainJoinInfo | undefined;
    IdleDisconnectTimeoutInSeconds?: number | undefined;
    IamRoleArn?: string | undefined;
    StreamView?: StreamView | undefined;
    Platform?: PlatformType | undefined;
    MaxConcurrentSessions?: number | undefined;
    UsbDeviceFilterStrings?: string[] | undefined;
    SessionScriptS3Location?: S3Location | undefined;
    MaxSessionsPerInstance?: number | undefined;
    RootVolumeConfig?: VolumeConfig | undefined;
    DisableIMDSV1?: boolean | undefined;
}
export interface CreateFleetResult {
    Fleet?: (Fleet & {
        Arn: Arn;
        Name: string;
        InstanceType: string;
        ComputeCapacityStatus: ComputeCapacityStatus & {
            Desired: number;
        };
        State: FleetState;
        SessionScriptS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    }) | undefined;
}
export type AppstreamAgentVersion = string;
export type AgentAction = "COMPUTER_VISION" | "COMPUTER_INPUT" | "FORWARD_MCP_TOOLS" | (string & {});
export type Permission = "ENABLED" | "DISABLED" | (string & {});
export interface AgentAccessSetting {
    AgentAction?: AgentAction | undefined;
    Permission?: Permission | undefined;
}
export type AgentAccessSettingList = AgentAccessSetting[];
export type S3BucketArn = string;
export type ScreenResolution = "W_1280xH_720" | (string & {});
export type ScreenImageFormat = "PNG" | "JPEG" | (string & {});
export type UserControlMode = "VIEW_ONLY" | "VIEW_STOP" | "DISABLED" | (string & {});
export interface ImageBuilderAgentAccessConfig {
    Settings?: AgentAccessSetting[] | undefined;
    S3BucketArn?: string | undefined;
    ScreenshotsUploadEnabled?: boolean | undefined;
    ScreenResolution?: ScreenResolution | undefined;
    ScreenImageFormat?: ScreenImageFormat | undefined;
    UserControlMode?: UserControlMode | undefined;
}
export interface CreateImageBuilderRequest {
    Name?: string | undefined;
    ImageName?: string | undefined;
    ImageArn?: string | undefined;
    InstanceType?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    IamRoleArn?: string | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    DomainJoinInfo?: DomainJoinInfo | undefined;
    AppstreamAgentVersion?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    RootVolumeConfig?: VolumeConfig | undefined;
    SoftwaresToInstall?: string[] | undefined;
    SoftwaresToUninstall?: string[] | undefined;
    DisableIMDSV1?: boolean | undefined;
    AgentAccessConfig?: ImageBuilderAgentAccessConfig | undefined;
}
export type ImageBuilderState = "PENDING" | "UPDATING_AGENT" | "RUNNING" | "STOPPING" | "STOPPED" | "REBOOTING" | "SNAPSHOTTING" | "DELETING" | "FAILED" | "UPDATING" | "PENDING_QUALIFICATION" | "PENDING_SYNCING_APPS" | "SYNCING_APPS" | "PENDING_IMAGE_IMPORT" | (string & {});
export type ImageBuilderStateChangeReasonCode = "INTERNAL_ERROR" | "IMAGE_UNAVAILABLE" | (string & {});
export interface ImageBuilderStateChangeReason {
    Code?: ImageBuilderStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface NetworkAccessConfiguration {
    EniPrivateIpAddress?: string | undefined;
    EniIpv6Addresses?: string[] | undefined;
    EniId?: string | undefined;
}
export type LatestAppstreamAgentVersion = "TRUE" | "FALSE" | (string & {});
export interface ImageBuilder {
    Name?: string | undefined;
    Arn?: string | undefined;
    ImageArn?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    InstanceType?: string | undefined;
    Platform?: PlatformType | undefined;
    IamRoleArn?: string | undefined;
    State?: ImageBuilderState | undefined;
    StateChangeReason?: ImageBuilderStateChangeReason | undefined;
    CreatedTime?: Date | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    DomainJoinInfo?: DomainJoinInfo | undefined;
    NetworkAccessConfiguration?: NetworkAccessConfiguration | undefined;
    ImageBuilderErrors?: ResourceError[] | undefined;
    AppstreamAgentVersion?: string | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    RootVolumeConfig?: VolumeConfig | undefined;
    LatestAppstreamAgentVersion?: LatestAppstreamAgentVersion | undefined;
    DisableIMDSV1?: boolean | undefined;
    AgentAccessConfig?: ImageBuilderAgentAccessConfig | undefined;
}
export interface CreateImageBuilderResult {
    ImageBuilder?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        AgentAccessConfig: ImageBuilderAgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export interface CreateImageBuilderStreamingURLRequest {
    Name?: string | undefined;
    Validity?: number | undefined;
}
export interface CreateImageBuilderStreamingURLResult {
    StreamingURL?: string | undefined;
    Expires?: Date | undefined;
}
export type WorkspaceImageId = string;
export type ImageImportDescription = string;
export type ImageImportDisplayName = string;
export type InstanceType = string;
export interface RuntimeValidationConfig {
    IntendedInstanceType?: string | undefined;
}
export type AgentSoftwareVersion = "CURRENT_LATEST" | "ALWAYS_LATEST" | (string & {});
export type AppName = string;
export type AppDisplayName = string;
export type FilePath = string | redacted.Redacted<string>;
export type LaunchParameters = string | redacted.Redacted<string>;
export interface ApplicationConfig {
    Name?: string | undefined;
    DisplayName?: string | undefined;
    AbsoluteAppPath?: string | redacted.Redacted<string> | undefined;
    AbsoluteIconPath?: string | redacted.Redacted<string> | undefined;
    AbsoluteManifestPath?: string | redacted.Redacted<string> | undefined;
    WorkingDirectory?: string | redacted.Redacted<string> | undefined;
    LaunchParameters?: string | redacted.Redacted<string> | undefined;
}
export type AppCatalogConfig = ApplicationConfig[];
export interface CreateImportedImageRequest {
    Name?: string | undefined;
    SourceAmiId?: string | undefined;
    WorkspaceImageId?: string | undefined;
    IamRoleArn?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RuntimeValidationConfig?: RuntimeValidationConfig | undefined;
    AgentSoftwareVersion?: AgentSoftwareVersion | undefined;
    AppCatalogConfig?: ApplicationConfig[] | undefined;
    DryRun?: boolean | undefined;
}
export type ImageState = "PENDING" | "AVAILABLE" | "FAILED" | "COPYING" | "DELETING" | "CREATING" | "IMPORTING" | "VALIDATING" | (string & {});
export type VisibilityType = "PUBLIC" | "PRIVATE" | "SHARED" | (string & {});
export type ImageStateChangeReasonCode = "INTERNAL_ERROR" | "IMAGE_BUILDER_NOT_AVAILABLE" | "IMAGE_COPY_FAILURE" | "IMAGE_UPDATE_FAILURE" | "IMAGE_IMPORT_FAILURE" | (string & {});
export interface ImageStateChangeReason {
    Code?: ImageStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export type Applications = Application[];
export interface ImagePermissions {
    allowFleet?: boolean | undefined;
    allowImageBuilder?: boolean | undefined;
}
export type DynamicAppProvidersEnabled = "ENABLED" | "DISABLED" | (string & {});
export type ImageSharedWithOthers = "TRUE" | "FALSE" | (string & {});
export type ImageType = "CUSTOM" | "NATIVE" | "BYOL" | (string & {});
export type NvidiaGridDriverVersion = string;
export interface ImageSoftwareMetadata {
    nvidiaGridDriverVersion?: string | undefined;
}
export interface Image {
    Name?: string | undefined;
    Arn?: string | undefined;
    BaseImageArn?: string | undefined;
    DisplayName?: string | undefined;
    State?: ImageState | undefined;
    Visibility?: VisibilityType | undefined;
    ImageBuilderSupported?: boolean | undefined;
    ImageBuilderName?: string | undefined;
    Platform?: PlatformType | undefined;
    Description?: string | undefined;
    StateChangeReason?: ImageStateChangeReason | undefined;
    Applications?: Application[] | undefined;
    CreatedTime?: Date | undefined;
    PublicBaseImageReleasedDate?: Date | undefined;
    AppstreamAgentVersion?: string | undefined;
    ImagePermissions?: ImagePermissions | undefined;
    ImageErrors?: ResourceError[] | undefined;
    LatestAppstreamAgentVersion?: LatestAppstreamAgentVersion | undefined;
    SupportedInstanceFamilies?: string[] | undefined;
    DynamicAppProvidersEnabled?: DynamicAppProvidersEnabled | undefined;
    ImageSharedWithOthers?: ImageSharedWithOthers | undefined;
    ManagedSoftwareIncluded?: boolean | undefined;
    ImageType?: ImageType | undefined;
    ImageSoftwareMetadata?: ImageSoftwareMetadata | undefined;
}
export interface CreateImportedImageResult {
    Image?: (Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    }) | undefined;
}
export type StorageConnectorType = "HOMEFOLDERS" | "GOOGLE_DRIVE" | "ONE_DRIVE" | (string & {});
export type ResourceIdentifier = string;
export type Domain = string;
export type DomainList = string[];
export interface StorageConnector {
    ConnectorType?: StorageConnectorType | undefined;
    ResourceIdentifier?: string | undefined;
    Domains?: string[] | undefined;
    DomainsRequireAdminConsent?: string[] | undefined;
}
export type StorageConnectorList = StorageConnector[];
export type RedirectURL = string;
export type FeedbackURL = string;
export type Action = "CLIPBOARD_COPY_FROM_LOCAL_DEVICE" | "CLIPBOARD_COPY_TO_LOCAL_DEVICE" | "FILE_UPLOAD" | "FILE_DOWNLOAD" | "PRINTING_TO_LOCAL_DEVICE" | "DOMAIN_PASSWORD_SIGNIN" | "DOMAIN_SMART_CARD_SIGNIN" | "AUTO_TIME_ZONE_REDIRECTION" | (string & {});
export interface UserSetting {
    Action?: Action | undefined;
    Permission?: Permission | undefined;
    MaximumLength?: number | undefined;
}
export type UserSettingList = UserSetting[];
export type SettingsGroup = string;
export interface ApplicationSettings {
    Enabled?: boolean | undefined;
    SettingsGroup?: string | undefined;
}
export type EmbedHostDomain = string;
export type EmbedHostDomains = string[];
export type PreferredProtocol = "TCP" | "UDP" | (string & {});
export interface StreamingExperienceSettings {
    PreferredProtocol?: PreferredProtocol | undefined;
}
export type UrlPattern = string;
export type UrlPatternList = string[];
export interface UrlRedirectionConfig {
    Enabled?: boolean | undefined;
    AllowedUrls?: string[] | undefined;
    DeniedUrls?: string[] | undefined;
}
export interface ContentRedirection {
    HostToClient?: UrlRedirectionConfig | undefined;
}
export type KmsKeyArn = string;
export interface AgentAccessConfig {
    Settings?: AgentAccessSetting[] | undefined;
    S3BucketArn?: string | undefined;
    ScreenshotsUploadEnabled?: boolean | undefined;
    ReplaySessionEnabled?: boolean | undefined;
    KmsKeyArn?: string | undefined;
    ScreenResolution?: ScreenResolution | undefined;
    ScreenImageFormat?: ScreenImageFormat | undefined;
    UserControlMode?: UserControlMode | undefined;
}
export type StorageConnectorAuthentication = "FORCE_REAUTHENTICATION" | "REUSE_CREDENTIALS" | (string & {});
export interface CreateStackRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    StorageConnectors?: StorageConnector[] | undefined;
    RedirectURL?: string | undefined;
    FeedbackURL?: string | undefined;
    UserSettings?: UserSetting[] | undefined;
    ApplicationSettings?: ApplicationSettings | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    EmbedHostDomains?: string[] | undefined;
    StreamingExperienceSettings?: StreamingExperienceSettings | undefined;
    ContentRedirection?: ContentRedirection | undefined;
    AgentAccessConfig?: AgentAccessConfig | undefined;
    StorageConnectorAuthentication?: StorageConnectorAuthentication | undefined;
}
export type StackErrorCode = "STORAGE_CONNECTOR_ERROR" | "INTERNAL_SERVICE_ERROR" | (string & {});
export interface StackError {
    ErrorCode?: StackErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type StackErrors = StackError[];
export interface ApplicationSettingsResponse {
    Enabled?: boolean | undefined;
    SettingsGroup?: string | undefined;
    S3BucketName?: string | undefined;
}
export interface Stack {
    Arn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    CreatedTime?: Date | undefined;
    StorageConnectors?: StorageConnector[] | undefined;
    RedirectURL?: string | undefined;
    FeedbackURL?: string | undefined;
    StackErrors?: StackError[] | undefined;
    UserSettings?: UserSetting[] | undefined;
    ApplicationSettings?: ApplicationSettingsResponse | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    EmbedHostDomains?: string[] | undefined;
    StreamingExperienceSettings?: StreamingExperienceSettings | undefined;
    ContentRedirection?: ContentRedirection | undefined;
    AgentAccessConfig?: AgentAccessConfig | undefined;
    StorageConnectorAuthentication?: StorageConnectorAuthentication | undefined;
}
export interface CreateStackResult {
    Stack?: (Stack & {
        Name: string;
        StorageConnectors: (StorageConnector & {
            ConnectorType: StorageConnectorType;
        })[];
        UserSettings: (UserSetting & {
            Action: Action;
            Permission: Permission;
        })[];
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        ContentRedirection: ContentRedirection & {
            HostToClient: UrlRedirectionConfig & {
                Enabled: boolean;
            };
        };
        AgentAccessConfig: AgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export type StreamingUrlUserId = string;
export interface CreateStreamingURLRequest {
    StackName?: string | undefined;
    FleetName?: string | undefined;
    UserId?: string | undefined;
    ApplicationId?: string | undefined;
    Validity?: number | undefined;
    SessionContext?: string | undefined;
}
export interface CreateStreamingURLResult {
    StreamingURL?: string | undefined;
    Expires?: Date | undefined;
}
export type ThemeFooterLinkDisplayName = string;
export type ThemeFooterLinkURL = string;
export interface ThemeFooterLink {
    DisplayName?: string | undefined;
    FooterLinkURL?: string | undefined;
}
export type ThemeFooterLinks = ThemeFooterLink[];
export type ThemeTitleText = string;
export type ThemeStyling = "LIGHT_BLUE" | "BLUE" | "PINK" | "RED" | (string & {});
export interface CreateThemeForStackRequest {
    StackName?: string | undefined;
    FooterLinks?: ThemeFooterLink[] | undefined;
    TitleText?: string | undefined;
    ThemeStyling?: ThemeStyling | undefined;
    OrganizationLogoS3Location?: S3Location | undefined;
    FaviconS3Location?: S3Location | undefined;
}
export type ThemeState = "ENABLED" | "DISABLED" | (string & {});
export interface Theme {
    StackName?: string | undefined;
    State?: ThemeState | undefined;
    ThemeTitleText?: string | undefined;
    ThemeStyling?: ThemeStyling | undefined;
    ThemeFooterLinks?: ThemeFooterLink[] | undefined;
    ThemeOrganizationLogoURL?: string | undefined;
    ThemeFaviconURL?: string | undefined;
    CreatedTime?: Date | undefined;
}
export interface CreateThemeForStackResult {
    Theme?: Theme | undefined;
}
export interface CreateUpdatedImageRequest {
    existingImageName?: string | undefined;
    newImageName?: string | undefined;
    newImageDescription?: string | undefined;
    newImageDisplayName?: string | undefined;
    newImageTags?: {
        [key: string]: string | undefined;
    } | undefined;
    dryRun?: boolean | undefined;
}
export interface CreateUpdatedImageResult {
    image?: (Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    }) | undefined;
    canUpdateImage?: boolean | undefined;
}
export interface CreateUsageReportSubscriptionRequest {
}
export type UsageReportSchedule = "DAILY" | (string & {});
export interface CreateUsageReportSubscriptionResult {
    S3BucketName?: string | undefined;
    Schedule?: UsageReportSchedule | undefined;
}
export type MessageAction = "SUPPRESS" | "RESEND" | (string & {});
export type UserAttributeValue = string | redacted.Redacted<string>;
export interface CreateUserRequest {
    UserName?: string | redacted.Redacted<string> | undefined;
    MessageAction?: MessageAction | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    AuthenticationType?: AuthenticationType | undefined;
}
export interface CreateUserResult {
}
export interface DeleteAppBlockRequest {
    Name?: string | undefined;
}
export interface DeleteAppBlockResult {
}
export interface DeleteAppBlockBuilderRequest {
    Name?: string | undefined;
}
export interface DeleteAppBlockBuilderResult {
}
export interface DeleteApplicationRequest {
    Name?: string | undefined;
}
export interface DeleteApplicationResult {
}
export interface DeleteDirectoryConfigRequest {
    DirectoryName?: string | undefined;
}
export interface DeleteDirectoryConfigResult {
}
export interface DeleteEntitlementRequest {
    Name?: string | undefined;
    StackName?: string | undefined;
}
export interface DeleteEntitlementResult {
}
export interface DeleteFleetRequest {
    Name?: string | undefined;
}
export interface DeleteFleetResult {
}
export interface DeleteImageRequest {
    Name?: string | undefined;
}
export interface DeleteImageResult {
    Image?: (Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    }) | undefined;
}
export interface DeleteImageBuilderRequest {
    Name?: string | undefined;
}
export interface DeleteImageBuilderResult {
    ImageBuilder?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        AgentAccessConfig: ImageBuilderAgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export type AwsAccountId = string;
export interface DeleteImagePermissionsRequest {
    Name?: string | undefined;
    SharedAccountId?: string | undefined;
}
export interface DeleteImagePermissionsResult {
}
export interface DeleteStackRequest {
    Name?: string | undefined;
}
export interface DeleteStackResult {
}
export interface DeleteThemeForStackRequest {
    StackName?: string | undefined;
}
export interface DeleteThemeForStackResult {
}
export interface DeleteUsageReportSubscriptionRequest {
}
export interface DeleteUsageReportSubscriptionResult {
}
export interface DeleteUserRequest {
    UserName?: string | redacted.Redacted<string> | undefined;
    AuthenticationType?: AuthenticationType | undefined;
}
export interface DeleteUserResult {
}
export interface DescribeAppBlockBuilderAppBlockAssociationsRequest {
    AppBlockArn?: string | undefined;
    AppBlockBuilderName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AppBlockBuilderAppBlockAssociationsList = AppBlockBuilderAppBlockAssociation[];
export interface DescribeAppBlockBuilderAppBlockAssociationsResult {
    AppBlockBuilderAppBlockAssociations?: (AppBlockBuilderAppBlockAssociation & {
        AppBlockArn: Arn;
        AppBlockBuilderName: Name;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeAppBlockBuildersRequest {
    Names?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AppBlockBuilderList = AppBlockBuilder[];
export interface DescribeAppBlockBuildersResult {
    AppBlockBuilders?: (AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type ArnList = string[];
export interface DescribeAppBlocksRequest {
    Arns?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AppBlocks = AppBlock[];
export interface DescribeAppBlocksResult {
    AppBlocks?: (AppBlock & {
        Name: string;
        Arn: Arn;
        SourceS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
        SetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
        PostSetupScriptDetails: ScriptDetails & {
            ScriptS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
            ExecutablePath: string;
            TimeoutInSeconds: number;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeApplicationFleetAssociationsRequest {
    FleetName?: string | undefined;
    ApplicationArn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ApplicationFleetAssociationList = ApplicationFleetAssociation[];
export interface DescribeApplicationFleetAssociationsResult {
    ApplicationFleetAssociations?: (ApplicationFleetAssociation & {
        FleetName: string;
        ApplicationArn: Arn;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeApplicationsRequest {
    Arns?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DescribeApplicationsResult {
    Applications?: (Application & {
        IconS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeAppLicenseUsageRequest {
    BillingPeriod?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AdminAppLicenseUsageRecord {
    UserArn?: string | undefined;
    BillingPeriod?: string | undefined;
    OwnerAWSAccountId?: string | undefined;
    SubscriptionFirstUsedDate?: Date | undefined;
    SubscriptionLastUsedDate?: Date | undefined;
    LicenseType?: string | undefined;
    UserId?: string | undefined;
}
export type AdminAppLicenseUsageList = AdminAppLicenseUsageRecord[];
export interface DescribeAppLicenseUsageResult {
    AppLicenseUsages?: (AdminAppLicenseUsageRecord & {
        UserArn: string;
        BillingPeriod: string;
        OwnerAWSAccountId: AwsAccountId;
        SubscriptionFirstUsedDate: Date;
        SubscriptionLastUsedDate: Date;
        LicenseType: string;
        UserId: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type DirectoryNameList = string[];
export interface DescribeDirectoryConfigsRequest {
    DirectoryNames?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DirectoryConfigList = DirectoryConfig[];
export interface DescribeDirectoryConfigsResult {
    DirectoryConfigs?: (DirectoryConfig & {
        DirectoryName: DirectoryName;
        ServiceAccountCredentials: ServiceAccountCredentials & {
            AccountName: AccountName;
            AccountPassword: AccountPassword;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeEntitlementsRequest {
    Name?: string | undefined;
    StackName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type EntitlementList = Entitlement[];
export interface DescribeEntitlementsResult {
    Entitlements?: (Entitlement & {
        Name: Name;
        StackName: Name;
        AppVisibility: AppVisibility;
        Attributes: (EntitlementAttribute & {
            Name: string;
            Value: string;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFleetsRequest {
    Names?: string[] | undefined;
    NextToken?: string | undefined;
}
export type FleetList = Fleet[];
export interface DescribeFleetsResult {
    Fleets?: (Fleet & {
        Arn: Arn;
        Name: string;
        InstanceType: string;
        ComputeCapacityStatus: ComputeCapacityStatus & {
            Desired: number;
        };
        State: FleetState;
        SessionScriptS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeImageBuildersRequest {
    Names?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ImageBuilderList = ImageBuilder[];
export interface DescribeImageBuildersResult {
    ImageBuilders?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        AgentAccessConfig: ImageBuilderAgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResults = number;
export type AwsAccountIdList = string[];
export interface DescribeImagePermissionsRequest {
    Name?: string | undefined;
    MaxResults?: number | undefined;
    SharedAwsAccountIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface SharedImagePermissions {
    sharedAccountId?: string | undefined;
    imagePermissions?: ImagePermissions | undefined;
}
export type SharedImagePermissionsList = SharedImagePermissions[];
export interface DescribeImagePermissionsResult {
    Name?: string | undefined;
    SharedImagePermissionsList?: (SharedImagePermissions & {
        sharedAccountId: AwsAccountId;
        imagePermissions: ImagePermissions;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type DescribeImagesMaxResults = number;
export interface DescribeImagesRequest {
    Names?: string[] | undefined;
    Arns?: string[] | undefined;
    Type?: VisibilityType | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ImageList = Image[];
export interface DescribeImagesResult {
    Images?: (Image & {
        Name: string;
        Applications: (Application & {
            IconS3Location: S3Location & {
                S3Bucket: S3Bucket;
            };
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type UserId = string;
export interface DescribeSessionsRequest {
    StackName?: string | undefined;
    FleetName?: string | undefined;
    UserId?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
    AuthenticationType?: AuthenticationType | undefined;
    InstanceId?: string | undefined;
}
export type SessionState = "ACTIVE" | "PENDING" | "EXPIRED" | (string & {});
export type SessionConnectionState = "CONNECTED" | "NOT_CONNECTED" | (string & {});
export type InstanceDrainStatus = "ACTIVE" | "DRAINING" | "NOT_APPLICABLE" | (string & {});
export interface Session {
    Id?: string | undefined;
    UserId?: string | undefined;
    StackName?: string | undefined;
    FleetName?: string | undefined;
    State?: SessionState | undefined;
    ConnectionState?: SessionConnectionState | undefined;
    StartTime?: Date | undefined;
    MaxExpirationTime?: Date | undefined;
    AuthenticationType?: AuthenticationType | undefined;
    NetworkAccessConfiguration?: NetworkAccessConfiguration | undefined;
    InstanceId?: string | undefined;
    InstanceDrainStatus?: InstanceDrainStatus | undefined;
}
export type SessionList = Session[];
export interface DescribeSessionsResult {
    Sessions?: (Session & {
        Id: string;
        UserId: UserId;
        StackName: string;
        FleetName: string;
        State: SessionState;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeSoftwareAssociationsRequest {
    AssociatedResource?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SoftwareDeploymentStatus = "STAGED_FOR_INSTALLATION" | "PENDING_INSTALLATION" | "INSTALLED" | "STAGED_FOR_UNINSTALLATION" | "PENDING_UNINSTALLATION" | "FAILED_TO_INSTALL" | "FAILED_TO_UNINSTALL" | (string & {});
export interface SoftwareAssociations {
    SoftwareName?: string | undefined;
    Status?: SoftwareDeploymentStatus | undefined;
    DeploymentError?: ErrorDetails[] | undefined;
}
export type SoftwareAssociationsList = SoftwareAssociations[];
export interface DescribeSoftwareAssociationsResult {
    AssociatedResource?: string | undefined;
    SoftwareAssociations?: SoftwareAssociations[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeStacksRequest {
    Names?: string[] | undefined;
    NextToken?: string | undefined;
}
export type StackList = Stack[];
export interface DescribeStacksResult {
    Stacks?: (Stack & {
        Name: string;
        StorageConnectors: (StorageConnector & {
            ConnectorType: StorageConnectorType;
        })[];
        UserSettings: (UserSetting & {
            Action: Action;
            Permission: Permission;
        })[];
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        ContentRedirection: ContentRedirection & {
            HostToClient: UrlRedirectionConfig & {
                Enabled: boolean;
            };
        };
        AgentAccessConfig: AgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeThemeForStackRequest {
    StackName?: string | undefined;
}
export interface DescribeThemeForStackResult {
    Theme?: Theme | undefined;
}
export interface DescribeUsageReportSubscriptionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type UsageReportExecutionErrorCode = "RESOURCE_NOT_FOUND" | "ACCESS_DENIED" | "INTERNAL_SERVICE_ERROR" | (string & {});
export interface LastReportGenerationExecutionError {
    ErrorCode?: UsageReportExecutionErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type LastReportGenerationExecutionErrors = LastReportGenerationExecutionError[];
export interface UsageReportSubscription {
    S3BucketName?: string | undefined;
    Schedule?: UsageReportSchedule | undefined;
    LastGeneratedReportDate?: Date | undefined;
    SubscriptionErrors?: LastReportGenerationExecutionError[] | undefined;
}
export type UsageReportSubscriptionList = UsageReportSubscription[];
export interface DescribeUsageReportSubscriptionsResult {
    UsageReportSubscriptions?: UsageReportSubscription[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeUsersRequest {
    AuthenticationType?: AuthenticationType | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface User {
    Arn?: string | undefined;
    UserName?: string | redacted.Redacted<string> | undefined;
    Enabled?: boolean | undefined;
    Status?: string | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    CreatedTime?: Date | undefined;
    AuthenticationType?: AuthenticationType | undefined;
}
export type UserList = User[];
export interface DescribeUsersResult {
    Users?: (User & {
        AuthenticationType: AuthenticationType;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeUserStackAssociationsRequest {
    StackName?: string | undefined;
    UserName?: string | redacted.Redacted<string> | undefined;
    AuthenticationType?: AuthenticationType | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeUserStackAssociationsResult {
    UserStackAssociations?: (UserStackAssociation & {
        StackName: string;
        UserName: Username;
        AuthenticationType: AuthenticationType;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DisableUserRequest {
    UserName?: string | redacted.Redacted<string> | undefined;
    AuthenticationType?: AuthenticationType | undefined;
}
export interface DisableUserResult {
}
export interface DisassociateAppBlockBuilderAppBlockRequest {
    AppBlockArn?: string | undefined;
    AppBlockBuilderName?: string | undefined;
}
export interface DisassociateAppBlockBuilderAppBlockResult {
}
export interface DisassociateApplicationFleetRequest {
    FleetName?: string | undefined;
    ApplicationArn?: string | undefined;
}
export interface DisassociateApplicationFleetResult {
}
export interface DisassociateApplicationFromEntitlementRequest {
    StackName?: string | undefined;
    EntitlementName?: string | undefined;
    ApplicationIdentifier?: string | undefined;
}
export interface DisassociateApplicationFromEntitlementResult {
}
export interface DisassociateFleetRequest {
    FleetName?: string | undefined;
    StackName?: string | undefined;
}
export interface DisassociateFleetResult {
}
export interface DisassociateSoftwareFromImageBuilderRequest {
    ImageBuilderName?: string | undefined;
    SoftwareNames?: string[] | undefined;
}
export interface DisassociateSoftwareFromImageBuilderResult {
}
export interface DrainSessionInstanceRequest {
    SessionId?: string | undefined;
}
export interface DrainSessionInstanceResult {
}
export interface EnableUserRequest {
    UserName?: string | redacted.Redacted<string> | undefined;
    AuthenticationType?: AuthenticationType | undefined;
}
export interface EnableUserResult {
}
export interface ExpireSessionRequest {
    SessionId?: string | undefined;
}
export interface ExpireSessionResult {
}
export interface GetExportImageTaskRequest {
    TaskId?: string | undefined;
}
export interface GetExportImageTaskResult {
    ExportImageTask?: (ExportImageTask & {
        TaskId: UUID;
        ImageArn: Arn;
        AmiName: AmiName;
        CreatedDate: Date;
    }) | undefined;
}
export interface ListAssociatedFleetsRequest {
    StackName?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListAssociatedFleetsResult {
    Names?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAssociatedStacksRequest {
    FleetName?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListAssociatedStacksResult {
    Names?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEntitledApplicationsRequest {
    StackName?: string | undefined;
    EntitlementName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface EntitledApplication {
    ApplicationIdentifier?: string | undefined;
}
export type EntitledApplicationList = EntitledApplication[];
export interface ListEntitledApplicationsResult {
    EntitledApplications?: (EntitledApplication & {
        ApplicationIdentifier: string;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type FilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type Filters = Filter[];
export interface ListExportImageTasksRequest {
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ExportImageTasks = ExportImageTask[];
export interface ListExportImageTasksResult {
    ExportImageTasks?: (ExportImageTask & {
        TaskId: UUID;
        ImageArn: Arn;
        AmiName: AmiName;
        CreatedDate: Date;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn?: string | undefined;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartAppBlockBuilderRequest {
    Name?: string | undefined;
}
export interface StartAppBlockBuilderResult {
    AppBlockBuilder?: (AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    }) | undefined;
}
export interface StartFleetRequest {
    Name?: string | undefined;
}
export interface StartFleetResult {
}
export interface StartImageBuilderRequest {
    Name?: string | undefined;
    AppstreamAgentVersion?: string | undefined;
}
export interface StartImageBuilderResult {
    ImageBuilder?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        AgentAccessConfig: ImageBuilderAgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export interface StartSoftwareDeploymentToImageBuilderRequest {
    ImageBuilderName?: string | undefined;
    RetryFailedDeployments?: boolean | undefined;
}
export interface StartSoftwareDeploymentToImageBuilderResult {
}
export interface StopAppBlockBuilderRequest {
    Name?: string | undefined;
}
export interface StopAppBlockBuilderResult {
    AppBlockBuilder?: (AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    }) | undefined;
}
export interface StopFleetRequest {
    Name?: string | undefined;
}
export interface StopFleetResult {
}
export interface StopImageBuilderRequest {
    Name?: string | undefined;
}
export interface StopImageBuilderResult {
    ImageBuilder?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        AgentAccessConfig: ImageBuilderAgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export interface TagResourceRequest {
    ResourceArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export type AppBlockBuilderAttribute = "IAM_ROLE_ARN" | "ACCESS_ENDPOINTS" | "VPC_CONFIGURATION_SECURITY_GROUP_IDS" | (string & {});
export type AppBlockBuilderAttributes = AppBlockBuilderAttribute[];
export interface UpdateAppBlockBuilderRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    Platform?: PlatformType | undefined;
    InstanceType?: string | undefined;
    VpcConfig?: VpcConfig | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    IamRoleArn?: string | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    AttributesToDelete?: AppBlockBuilderAttribute[] | undefined;
    DisableIMDSV1?: boolean | undefined;
}
export interface UpdateAppBlockBuilderResult {
    AppBlockBuilder?: (AppBlockBuilder & {
        Arn: Arn;
        Name: string;
        Platform: AppBlockBuilderPlatformType;
        InstanceType: string;
        VpcConfig: VpcConfig;
        State: AppBlockBuilderState;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
    }) | undefined;
}
export type ApplicationAttribute = "LAUNCH_PARAMETERS" | "WORKING_DIRECTORY" | (string & {});
export type ApplicationAttributes = ApplicationAttribute[];
export interface UpdateApplicationRequest {
    Name?: string | undefined;
    DisplayName?: string | undefined;
    Description?: string | undefined;
    IconS3Location?: S3Location | undefined;
    LaunchPath?: string | undefined;
    WorkingDirectory?: string | undefined;
    LaunchParameters?: string | undefined;
    AppBlockArn?: string | undefined;
    AttributesToDelete?: ApplicationAttribute[] | undefined;
}
export interface UpdateApplicationResult {
    Application?: (Application & {
        IconS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    }) | undefined;
}
export interface UpdateDirectoryConfigRequest {
    DirectoryName?: string | undefined;
    OrganizationalUnitDistinguishedNames?: string[] | undefined;
    ServiceAccountCredentials?: ServiceAccountCredentials | undefined;
    CertificateBasedAuthProperties?: CertificateBasedAuthProperties | undefined;
}
export interface UpdateDirectoryConfigResult {
    DirectoryConfig?: (DirectoryConfig & {
        DirectoryName: DirectoryName;
        ServiceAccountCredentials: ServiceAccountCredentials & {
            AccountName: AccountName;
            AccountPassword: AccountPassword;
        };
    }) | undefined;
}
export interface UpdateEntitlementRequest {
    Name?: string | undefined;
    StackName?: string | undefined;
    Description?: string | undefined;
    AppVisibility?: AppVisibility | undefined;
    Attributes?: EntitlementAttribute[] | undefined;
}
export interface UpdateEntitlementResult {
    Entitlement?: (Entitlement & {
        Name: Name;
        StackName: Name;
        AppVisibility: AppVisibility;
        Attributes: (EntitlementAttribute & {
            Name: string;
            Value: string;
        })[];
    }) | undefined;
}
export type FleetAttribute = "VPC_CONFIGURATION" | "VPC_CONFIGURATION_SECURITY_GROUP_IDS" | "DOMAIN_JOIN_INFO" | "IAM_ROLE_ARN" | "USB_DEVICE_FILTER_STRINGS" | "SESSION_SCRIPT_S3_LOCATION" | "MAX_SESSIONS_PER_INSTANCE" | "VOLUME_CONFIGURATION" | (string & {});
export type FleetAttributes = FleetAttribute[];
export interface UpdateFleetRequest {
    ImageName?: string | undefined;
    ImageArn?: string | undefined;
    Name?: string | undefined;
    InstanceType?: string | undefined;
    ComputeCapacity?: ComputeCapacity | undefined;
    VpcConfig?: VpcConfig | undefined;
    MaxUserDurationInSeconds?: number | undefined;
    DisconnectTimeoutInSeconds?: number | undefined;
    DeleteVpcConfig?: boolean | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    EnableDefaultInternetAccess?: boolean | undefined;
    DomainJoinInfo?: DomainJoinInfo | undefined;
    IdleDisconnectTimeoutInSeconds?: number | undefined;
    AttributesToDelete?: FleetAttribute[] | undefined;
    IamRoleArn?: string | undefined;
    StreamView?: StreamView | undefined;
    Platform?: PlatformType | undefined;
    MaxConcurrentSessions?: number | undefined;
    UsbDeviceFilterStrings?: string[] | undefined;
    SessionScriptS3Location?: S3Location | undefined;
    MaxSessionsPerInstance?: number | undefined;
    RootVolumeConfig?: VolumeConfig | undefined;
    DisableIMDSV1?: boolean | undefined;
}
export interface UpdateFleetResult {
    Fleet?: (Fleet & {
        Arn: Arn;
        Name: string;
        InstanceType: string;
        ComputeCapacityStatus: ComputeCapacityStatus & {
            Desired: number;
        };
        State: FleetState;
        SessionScriptS3Location: S3Location & {
            S3Bucket: S3Bucket;
        };
    }) | undefined;
}
export interface ImageBuilderAgentAccessConfigForUpdate {
    Settings?: AgentAccessSetting[] | undefined;
    S3BucketArn?: string | undefined;
    ScreenshotsUploadEnabled?: boolean | undefined;
    ScreenResolution?: ScreenResolution | undefined;
    ScreenImageFormat?: ScreenImageFormat | undefined;
    UserControlMode?: UserControlMode | undefined;
}
export type ImageBuilderAttribute = "AGENT_ACCESS_CONFIG" | (string & {});
export type ImageBuilderAttributes = ImageBuilderAttribute[];
export interface UpdateImageBuilderRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    DisplayName?: string | undefined;
    AgentAccessConfig?: ImageBuilderAgentAccessConfigForUpdate | undefined;
    AttributesToDelete?: ImageBuilderAttribute[] | undefined;
}
export interface UpdateImageBuilderResult {
    ImageBuilder?: (ImageBuilder & {
        Name: string;
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        AgentAccessConfig: ImageBuilderAgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export interface UpdateImagePermissionsRequest {
    Name?: string | undefined;
    SharedAccountId?: string | undefined;
    ImagePermissions?: ImagePermissions | undefined;
}
export interface UpdateImagePermissionsResult {
}
export type StackAttribute = "STORAGE_CONNECTORS" | "STORAGE_CONNECTOR_HOMEFOLDERS" | "STORAGE_CONNECTOR_GOOGLE_DRIVE" | "STORAGE_CONNECTOR_ONE_DRIVE" | "REDIRECT_URL" | "FEEDBACK_URL" | "THEME_NAME" | "USER_SETTINGS" | "EMBED_HOST_DOMAINS" | "IAM_ROLE_ARN" | "ACCESS_ENDPOINTS" | "STREAMING_EXPERIENCE_SETTINGS" | "CONTENT_REDIRECTION" | "AGENT_ACCESS_CONFIG" | "STORAGE_CONNECTOR_AUTHENTICATION" | "AGENT_ACCESS_CONFIG_KMS_KEY_ARN" | (string & {});
export type StackAttributes = StackAttribute[];
export interface AgentAccessConfigForUpdate {
    Settings?: AgentAccessSetting[] | undefined;
    S3BucketArn?: string | undefined;
    ScreenshotsUploadEnabled?: boolean | undefined;
    ReplaySessionEnabled?: boolean | undefined;
    KmsKeyArn?: string | undefined;
    ScreenResolution?: ScreenResolution | undefined;
    ScreenImageFormat?: ScreenImageFormat | undefined;
    UserControlMode?: UserControlMode | undefined;
}
export interface UpdateStackRequest {
    DisplayName?: string | undefined;
    Description?: string | undefined;
    Name?: string | undefined;
    StorageConnectors?: StorageConnector[] | undefined;
    DeleteStorageConnectors?: boolean | undefined;
    RedirectURL?: string | undefined;
    FeedbackURL?: string | undefined;
    AttributesToDelete?: StackAttribute[] | undefined;
    UserSettings?: UserSetting[] | undefined;
    ApplicationSettings?: ApplicationSettings | undefined;
    AccessEndpoints?: AccessEndpoint[] | undefined;
    EmbedHostDomains?: string[] | undefined;
    StreamingExperienceSettings?: StreamingExperienceSettings | undefined;
    ContentRedirection?: ContentRedirection | undefined;
    AgentAccessConfig?: AgentAccessConfigForUpdate | undefined;
    StorageConnectorAuthentication?: StorageConnectorAuthentication | undefined;
}
export interface UpdateStackResult {
    Stack?: (Stack & {
        Name: string;
        StorageConnectors: (StorageConnector & {
            ConnectorType: StorageConnectorType;
        })[];
        UserSettings: (UserSetting & {
            Action: Action;
            Permission: Permission;
        })[];
        AccessEndpoints: (AccessEndpoint & {
            EndpointType: AccessEndpointType;
        })[];
        ContentRedirection: ContentRedirection & {
            HostToClient: UrlRedirectionConfig & {
                Enabled: boolean;
            };
        };
        AgentAccessConfig: AgentAccessConfig & {
            Settings: (AgentAccessSetting & {
                AgentAction: AgentAction;
                Permission: Permission;
            })[];
            ScreenResolution: ScreenResolution;
            ScreenImageFormat: ScreenImageFormat;
        };
    }) | undefined;
}
export type ThemeAttribute = "FOOTER_LINKS" | (string & {});
export type ThemeAttributes = ThemeAttribute[];
export interface UpdateThemeForStackRequest {
    StackName?: string | undefined;
    FooterLinks?: ThemeFooterLink[] | undefined;
    TitleText?: string | undefined;
    ThemeStyling?: ThemeStyling | undefined;
    OrganizationLogoS3Location?: S3Location | undefined;
    FaviconS3Location?: S3Location | undefined;
    State?: ThemeState | undefined;
    AttributesToDelete?: ThemeAttribute[] | undefined;
}
export interface UpdateThemeForStackResult {
    Theme?: Theme | undefined;
}
export type ErrorMessage = string;
export type AssociateAppBlockBuilderAppBlockError = ConcurrentModificationException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified app block builder with the specified app block.
 */
export declare const associateAppBlockBuilderAppBlock: API.OperationMethod<AssociateAppBlockBuilderAppBlockRequest & RegionInput, AssociateAppBlockBuilderAppBlockResult, AssociateAppBlockBuilderAppBlockError, Credentials | HttpClient.HttpClient>;
export type AssociateApplicationFleetError = ConcurrentModificationException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified application with the specified fleet. This is only supported for Elastic fleets.
 */
export declare const associateApplicationFleet: API.OperationMethod<AssociateApplicationFleetRequest & RegionInput, AssociateApplicationFleetResult, AssociateApplicationFleetError, Credentials | HttpClient.HttpClient>;
export type AssociateApplicationToEntitlementError = EntitlementNotFoundException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates an application to entitle.
 */
export declare const associateApplicationToEntitlement: API.OperationMethod<AssociateApplicationToEntitlementRequest & RegionInput, AssociateApplicationToEntitlementResult, AssociateApplicationToEntitlementError, Credentials | HttpClient.HttpClient>;
export type AssociateFleetError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates the specified fleet with the specified stack.
 */
export declare const associateFleet: API.OperationMethod<AssociateFleetRequest & RegionInput, AssociateFleetResult, AssociateFleetError, Credentials | HttpClient.HttpClient>;
export type AssociateSoftwareToImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Associates license included application(s) with an existing image builder instance.
 */
export declare const associateSoftwareToImageBuilder: API.OperationMethod<AssociateSoftwareToImageBuilderRequest & RegionInput, AssociateSoftwareToImageBuilderResult, AssociateSoftwareToImageBuilderError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateUserStackError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Associates the specified users with the specified stacks. Users in a user pool cannot be assigned to stacks with fleets that are joined to an Active Directory domain.
 */
export declare const batchAssociateUserStack: API.OperationMethod<BatchAssociateUserStackRequest & RegionInput, BatchAssociateUserStackResult, BatchAssociateUserStackError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateUserStackError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Disassociates the specified users from the specified stacks.
 */
export declare const batchDisassociateUserStack: API.OperationMethod<BatchDisassociateUserStackRequest & RegionInput, BatchDisassociateUserStackResult, BatchDisassociateUserStackError, Credentials | HttpClient.HttpClient>;
export type CopyImageError = IncompatibleImageException | InvalidAccountStatusException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Copies the image within the same region or to a new region within the same AWS account. Note that any tags you added to the image will not be copied.
 */
export declare const copyImage: API.OperationMethod<CopyImageRequest & RegionInput, CopyImageResponse, CopyImageError, Credentials | HttpClient.HttpClient>;
export type CreateAppBlockError = ConcurrentModificationException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates an app block.
 *
 * App blocks are a WorkSpaces Applications resource that stores the details about the
 * virtual hard disk in an S3 bucket. It also stores the setup script with details about
 * how to mount the virtual hard disk. The virtual hard disk includes the application
 * binaries and other files necessary to launch your applications. Multiple applications
 * can be assigned to a single app block.
 *
 * This is only supported for Elastic fleets.
 */
export declare const createAppBlock: API.OperationMethod<CreateAppBlockRequest & RegionInput, CreateAppBlockResult, CreateAppBlockError, Credentials | HttpClient.HttpClient>;
export type CreateAppBlockBuilderError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an app block builder.
 */
export declare const createAppBlockBuilder: API.OperationMethod<CreateAppBlockBuilderRequest & RegionInput, CreateAppBlockBuilderResult, CreateAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type CreateAppBlockBuilderStreamingURLError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a URL to start a create app block builder streaming session.
 */
export declare const createAppBlockBuilderStreamingURL: API.OperationMethod<CreateAppBlockBuilderStreamingURLRequest & RegionInput, CreateAppBlockBuilderStreamingURLResult, CreateAppBlockBuilderStreamingURLError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = ConcurrentModificationException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an application.
 *
 * Applications are a WorkSpaces Applications resource that stores the details about how to
 * launch applications on Elastic fleet streaming instances. An application consists of the
 * launch details, icon, and display name. Applications are associated with an app block
 * that contains the application binaries and other files. The applications assigned to an
 * Elastic fleet are the applications users can launch.
 *
 * This is only supported for Elastic fleets.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResult, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateDirectoryConfigError = InvalidAccountStatusException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a Directory Config object in WorkSpaces Applications. This object includes the configuration information required to join fleets and image builders to Microsoft Active Directory domains.
 */
export declare const createDirectoryConfig: API.OperationMethod<CreateDirectoryConfigRequest & RegionInput, CreateDirectoryConfigResult, CreateDirectoryConfigError, Credentials | HttpClient.HttpClient>;
export type CreateEntitlementError = EntitlementAlreadyExistsException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new entitlement. Entitlements control access to specific applications within
 * a stack, based on user attributes. Entitlements apply to SAML 2.0 federated user
 * identities. WorkSpaces Applications user pool and streaming URL users are entitled to all
 * applications in a stack. Entitlements don't apply to the desktop stream view
 * application, or to applications managed by a dynamic app provider using the Dynamic
 * Application Framework.
 */
export declare const createEntitlement: API.OperationMethod<CreateEntitlementRequest & RegionInput, CreateEntitlementResult, CreateEntitlementError, Credentials | HttpClient.HttpClient>;
export type CreateExportImageTaskError = ConcurrentModificationException | InvalidAccountStatusException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a task to export a WorkSpaces Applications image to an EC2 AMI. This allows you to use your customized WorkSpaces Applications images with other AWS services or for backup purposes.
 */
export declare const createExportImageTask: API.OperationMethod<CreateExportImageTaskRequest & RegionInput, CreateExportImageTaskResult, CreateExportImageTaskError, Credentials | HttpClient.HttpClient>;
export type CreateFleetError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a fleet. A fleet consists of streaming instances that your users access for their applications and desktops.
 */
export declare const createFleet: API.OperationMethod<CreateFleetRequest & RegionInput, CreateFleetResult, CreateFleetError, Credentials | HttpClient.HttpClient>;
export type CreateImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceAlreadyExistsException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an image builder. An image builder is a virtual machine that is used to create an image.
 *
 * The initial state of the builder is `PENDING`. When it is ready, the state is `RUNNING`.
 */
export declare const createImageBuilder: API.OperationMethod<CreateImageBuilderRequest & RegionInput, CreateImageBuilderResult, CreateImageBuilderError, Credentials | HttpClient.HttpClient>;
export type CreateImageBuilderStreamingURLError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a URL to start an image builder streaming session.
 */
export declare const createImageBuilderStreamingURL: API.OperationMethod<CreateImageBuilderStreamingURLRequest & RegionInput, CreateImageBuilderStreamingURLResult, CreateImageBuilderStreamingURLError, Credentials | HttpClient.HttpClient>;
export type CreateImportedImageError = DryRunOperationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a custom WorkSpaces Applications image by importing an EC2 AMI. This allows you to use your own customized AMI to create WorkSpaces Applications images that support additional instance types beyond the standard stream.* instances.
 */
export declare const createImportedImage: API.OperationMethod<CreateImportedImageRequest & RegionInput, CreateImportedImageResult, CreateImportedImageError, Credentials | HttpClient.HttpClient>;
export type CreateStackError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a stack to start streaming applications to users. A stack consists of an associated fleet, user access policies, and storage configurations.
 */
export declare const createStack: API.OperationMethod<CreateStackRequest & RegionInput, CreateStackResult, CreateStackError, Credentials | HttpClient.HttpClient>;
export type CreateStreamingURLError = InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a temporary URL to start an WorkSpaces Applications streaming session for the specified user. A streaming URL enables application streaming to be tested without user setup.
 */
export declare const createStreamingURL: API.OperationMethod<CreateStreamingURLRequest & RegionInput, CreateStreamingURLResult, CreateStreamingURLError, Credentials | HttpClient.HttpClient>;
export type CreateThemeForStackError = ConcurrentModificationException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const createThemeForStack: API.OperationMethod<CreateThemeForStackRequest & RegionInput, CreateThemeForStackResult, CreateThemeForStackError, Credentials | HttpClient.HttpClient>;
export type CreateUpdatedImageError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new image with the latest Windows operating system updates, driver updates, and WorkSpaces Applications agent software.
 *
 * For more information, see the "Update an Image by Using
 * Managed WorkSpaces Applications Image Updates" section in Administer Your WorkSpaces Applications Images, in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const createUpdatedImage: API.OperationMethod<CreateUpdatedImageRequest & RegionInput, CreateUpdatedImageResult, CreateUpdatedImageError, Credentials | HttpClient.HttpClient>;
export type CreateUsageReportSubscriptionError = InvalidAccountStatusException | InvalidRoleException | LimitExceededException | CommonErrors;
/**
 * Creates a usage report subscription. Usage reports are generated daily.
 */
export declare const createUsageReportSubscription: API.OperationMethod<CreateUsageReportSubscriptionRequest & RegionInput, CreateUsageReportSubscriptionResult, CreateUsageReportSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = InvalidAccountStatusException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a new user in the user pool.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResult, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteAppBlockError = ConcurrentModificationException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an app block.
 */
export declare const deleteAppBlock: API.OperationMethod<DeleteAppBlockRequest & RegionInput, DeleteAppBlockResult, DeleteAppBlockError, Credentials | HttpClient.HttpClient>;
export type DeleteAppBlockBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an app block builder.
 *
 * An app block builder can only be deleted when it has no association with an app
 * block.
 */
export declare const deleteAppBlockBuilder: API.OperationMethod<DeleteAppBlockBuilderRequest & RegionInput, DeleteAppBlockBuilderResult, DeleteAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResult, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectoryConfigError = ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified Directory Config object from WorkSpaces Applications. This object includes the information required to join streaming instances to an Active Directory domain.
 */
export declare const deleteDirectoryConfig: API.OperationMethod<DeleteDirectoryConfigRequest & RegionInput, DeleteDirectoryConfigResult, DeleteDirectoryConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteEntitlementError = ConcurrentModificationException | EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified entitlement.
 */
export declare const deleteEntitlement: API.OperationMethod<DeleteEntitlementRequest & RegionInput, DeleteEntitlementResult, DeleteEntitlementError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetError = ConcurrentModificationException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified fleet.
 */
export declare const deleteFleet: API.OperationMethod<DeleteFleetRequest & RegionInput, DeleteFleetResult, DeleteFleetError, Credentials | HttpClient.HttpClient>;
export type DeleteImageError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified image. You cannot delete an image when it is in use.
 * After you delete an image, you cannot provision new capacity using the image.
 */
export declare const deleteImage: API.OperationMethod<DeleteImageRequest & RegionInput, DeleteImageResult, DeleteImageError, Credentials | HttpClient.HttpClient>;
export type DeleteImageBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified image builder and releases the capacity.
 */
export declare const deleteImageBuilder: API.OperationMethod<DeleteImageBuilderRequest & RegionInput, DeleteImageBuilderResult, DeleteImageBuilderError, Credentials | HttpClient.HttpClient>;
export type DeleteImagePermissionsError = ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes permissions for the specified private image. After you delete permissions for an image, AWS accounts to which you previously granted these permissions can no longer use the image.
 */
export declare const deleteImagePermissions: API.OperationMethod<DeleteImagePermissionsRequest & RegionInput, DeleteImagePermissionsResult, DeleteImagePermissionsError, Credentials | HttpClient.HttpClient>;
export type DeleteStackError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified stack. After the stack is deleted, the application streaming environment provided by the stack is no longer available to users. Also, any reservations made for application streaming sessions for the stack are released.
 */
export declare const deleteStack: API.OperationMethod<DeleteStackRequest & RegionInput, DeleteStackResult, DeleteStackError, Credentials | HttpClient.HttpClient>;
export type DeleteThemeForStackError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const deleteThemeForStack: API.OperationMethod<DeleteThemeForStackRequest & RegionInput, DeleteThemeForStackResult, DeleteThemeForStackError, Credentials | HttpClient.HttpClient>;
export type DeleteUsageReportSubscriptionError = InvalidAccountStatusException | ResourceNotFoundException | CommonErrors;
/**
 * Disables usage report generation.
 */
export declare const deleteUsageReportSubscription: API.OperationMethod<DeleteUsageReportSubscriptionRequest & RegionInput, DeleteUsageReportSubscriptionResult, DeleteUsageReportSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ResourceNotFoundException | CommonErrors;
/**
 * Deletes a user from the user pool.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResult, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeAppBlockBuilderAppBlockAssociationsError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Retrieves a list that describes one or more app block builder associations.
 */
export declare const describeAppBlockBuilderAppBlockAssociations: API.PaginatedOperationMethod<DescribeAppBlockBuilderAppBlockAssociationsRequest & RegionInput, DescribeAppBlockBuilderAppBlockAssociationsResult, DescribeAppBlockBuilderAppBlockAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeAppBlockBuildersError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more app block builders.
 */
export declare const describeAppBlockBuilders: API.PaginatedOperationMethod<DescribeAppBlockBuildersRequest & RegionInput, DescribeAppBlockBuildersResult, DescribeAppBlockBuildersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeAppBlocksError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more app blocks.
 */
export declare const describeAppBlocks: API.OperationMethod<DescribeAppBlocksRequest & RegionInput, DescribeAppBlocksResult, DescribeAppBlocksError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationFleetAssociationsError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Retrieves a list that describes one or more application fleet associations. Either ApplicationArn or FleetName must be specified.
 */
export declare const describeApplicationFleetAssociations: API.OperationMethod<DescribeApplicationFleetAssociationsRequest & RegionInput, DescribeApplicationFleetAssociationsResult, DescribeApplicationFleetAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationsError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more applications.
 */
export declare const describeApplications: API.OperationMethod<DescribeApplicationsRequest & RegionInput, DescribeApplicationsResult, DescribeApplicationsError, Credentials | HttpClient.HttpClient>;
export type DescribeAppLicenseUsageError = InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves license included application usage information.
 */
export declare const describeAppLicenseUsage: API.OperationMethod<DescribeAppLicenseUsageRequest & RegionInput, DescribeAppLicenseUsageResult, DescribeAppLicenseUsageError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectoryConfigsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified Directory Config objects for WorkSpaces Applications, if the names for these objects are provided. Otherwise, all Directory Config objects in the account are described. These objects include the configuration information required to join fleets and image builders to Microsoft Active Directory domains.
 *
 * Although the response syntax in this topic includes the account password, this password is not returned in the actual response.
 */
export declare const describeDirectoryConfigs: API.OperationMethod<DescribeDirectoryConfigsRequest & RegionInput, DescribeDirectoryConfigsResult, DescribeDirectoryConfigsError, Credentials | HttpClient.HttpClient>;
export type DescribeEntitlementsError = EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one of more entitlements.
 */
export declare const describeEntitlements: API.OperationMethod<DescribeEntitlementsRequest & RegionInput, DescribeEntitlementsResult, DescribeEntitlementsError, Credentials | HttpClient.HttpClient>;
export type DescribeFleetsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified fleets, if the fleet names are provided. Otherwise, all fleets in the account are described.
 */
export declare const describeFleets: API.OperationMethod<DescribeFleetsRequest & RegionInput, DescribeFleetsResult, DescribeFleetsError, Credentials | HttpClient.HttpClient>;
export type DescribeImageBuildersError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified image builders, if the image builder names are provided. Otherwise, all image builders in the account are described.
 *
 * The description of each image builder includes its agent access configuration, if agent access is enabled.
 */
export declare const describeImageBuilders: API.OperationMethod<DescribeImageBuildersRequest & RegionInput, DescribeImageBuildersResult, DescribeImageBuildersError, Credentials | HttpClient.HttpClient>;
export type DescribeImagePermissionsError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes the permissions for shared AWS account IDs on a private image that you own.
 */
export declare const describeImagePermissions: API.PaginatedOperationMethod<DescribeImagePermissionsRequest & RegionInput, DescribeImagePermissionsResult, DescribeImagePermissionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeImagesError = InvalidParameterCombinationException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified images, if the image names or image ARNs are provided. Otherwise, all images in the account are described.
 */
export declare const describeImages: API.PaginatedOperationMethod<DescribeImagesRequest & RegionInput, DescribeImagesResult, DescribeImagesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeSessionsError = InvalidParameterCombinationException | CommonErrors;
/**
 * Retrieves a list that describes the streaming sessions for a specified stack and fleet. If a UserId is provided for the stack and fleet,
 * only streaming sessions for that user are described. If an authentication type is not provided,
 * the default is to authenticate users using a streaming URL.
 */
export declare const describeSessions: API.OperationMethod<DescribeSessionsRequest & RegionInput, DescribeSessionsResult, DescribeSessionsError, Credentials | HttpClient.HttpClient>;
export type DescribeSoftwareAssociationsError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves license included application associations for a specified resource.
 */
export declare const describeSoftwareAssociations: API.OperationMethod<DescribeSoftwareAssociationsRequest & RegionInput, DescribeSoftwareAssociationsResult, DescribeSoftwareAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeStacksError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified stacks, if the stack names are provided. Otherwise, all stacks in the account are described.
 */
export declare const describeStacks: API.OperationMethod<DescribeStacksRequest & RegionInput, DescribeStacksResult, DescribeStacksError, Credentials | HttpClient.HttpClient>;
export type DescribeThemeForStackError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes the theme for a specified stack. A theme is custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const describeThemeForStack: API.OperationMethod<DescribeThemeForStackRequest & RegionInput, DescribeThemeForStackResult, DescribeThemeForStackError, Credentials | HttpClient.HttpClient>;
export type DescribeUsageReportSubscriptionsError = InvalidAccountStatusException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more usage report subscriptions.
 */
export declare const describeUsageReportSubscriptions: API.OperationMethod<DescribeUsageReportSubscriptionsRequest & RegionInput, DescribeUsageReportSubscriptionsResult, DescribeUsageReportSubscriptionsError, Credentials | HttpClient.HttpClient>;
export type DescribeUsersError = InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list that describes one or more specified users in the user pool.
 */
export declare const describeUsers: API.OperationMethod<DescribeUsersRequest & RegionInput, DescribeUsersResult, DescribeUsersError, Credentials | HttpClient.HttpClient>;
export type DescribeUserStackAssociationsError = InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Retrieves a list that describes the UserStackAssociation objects. You must specify either or both of the following:
 *
 * - The stack name
 *
 * - The user name (email address of the user associated with the stack) and the authentication type for the user
 */
export declare const describeUserStackAssociations: API.OperationMethod<DescribeUserStackAssociationsRequest & RegionInput, DescribeUserStackAssociationsResult, DescribeUserStackAssociationsError, Credentials | HttpClient.HttpClient>;
export type DisableUserError = ResourceNotFoundException | CommonErrors;
/**
 * Disables the specified user in the user pool. Users can't sign in to WorkSpaces Applications until they are re-enabled. This action does not delete the user.
 */
export declare const disableUser: API.OperationMethod<DisableUserRequest & RegionInput, DisableUserResult, DisableUserError, Credentials | HttpClient.HttpClient>;
export type DisassociateAppBlockBuilderAppBlockError = ConcurrentModificationException | InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a specified app block builder from a specified app block.
 */
export declare const disassociateAppBlockBuilderAppBlock: API.OperationMethod<DisassociateAppBlockBuilderAppBlockRequest & RegionInput, DisassociateAppBlockBuilderAppBlockResult, DisassociateAppBlockBuilderAppBlockError, Credentials | HttpClient.HttpClient>;
export type DisassociateApplicationFleetError = ConcurrentModificationException | InvalidParameterCombinationException | OperationNotPermittedException | CommonErrors;
/**
 * Disassociates the specified application from the fleet.
 */
export declare const disassociateApplicationFleet: API.OperationMethod<DisassociateApplicationFleetRequest & RegionInput, DisassociateApplicationFleetResult, DisassociateApplicationFleetError, Credentials | HttpClient.HttpClient>;
export type DisassociateApplicationFromEntitlementError = EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified application from the specified entitlement.
 */
export declare const disassociateApplicationFromEntitlement: API.OperationMethod<DisassociateApplicationFromEntitlementRequest & RegionInput, DisassociateApplicationFromEntitlementResult, DisassociateApplicationFromEntitlementError, Credentials | HttpClient.HttpClient>;
export type DisassociateFleetError = ConcurrentModificationException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified fleet from the specified stack.
 */
export declare const disassociateFleet: API.OperationMethod<DisassociateFleetRequest & RegionInput, DisassociateFleetResult, DisassociateFleetError, Credentials | HttpClient.HttpClient>;
export type DisassociateSoftwareFromImageBuilderError = ConcurrentModificationException | InvalidParameterCombinationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Removes license included application(s) association(s) from an image builder instance.
 */
export declare const disassociateSoftwareFromImageBuilder: API.OperationMethod<DisassociateSoftwareFromImageBuilderRequest & RegionInput, DisassociateSoftwareFromImageBuilderResult, DisassociateSoftwareFromImageBuilderError, Credentials | HttpClient.HttpClient>;
export type DrainSessionInstanceError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Drains the instance hosting the specified streaming session. The instance stops accepting new sessions while existing sessions continue uninterrupted. Once all sessions end, the instance is reclaimed and replaced. This only applies to multi-session fleets.
 */
export declare const drainSessionInstance: API.OperationMethod<DrainSessionInstanceRequest & RegionInput, DrainSessionInstanceResult, DrainSessionInstanceError, Credentials | HttpClient.HttpClient>;
export type EnableUserError = InvalidAccountStatusException | ResourceNotFoundException | CommonErrors;
/**
 * Enables a user in the user pool. After being enabled, users can sign in to WorkSpaces Applications and open applications from the stacks to which they are assigned.
 */
export declare const enableUser: API.OperationMethod<EnableUserRequest & RegionInput, EnableUserResult, EnableUserError, Credentials | HttpClient.HttpClient>;
export type ExpireSessionError = CommonErrors;
/**
 * Immediately stops the specified streaming session.
 */
export declare const expireSession: API.OperationMethod<ExpireSessionRequest & RegionInput, ExpireSessionResult, ExpireSessionError, Credentials | HttpClient.HttpClient>;
export type GetExportImageTaskError = OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about an export image task, including its current state, progress, and any error details.
 */
export declare const getExportImageTask: API.OperationMethod<GetExportImageTaskRequest & RegionInput, GetExportImageTaskResult, GetExportImageTaskError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedFleetsError = CommonErrors;
/**
 * Retrieves the name of the fleet that is associated with the specified stack.
 */
export declare const listAssociatedFleets: API.OperationMethod<ListAssociatedFleetsRequest & RegionInput, ListAssociatedFleetsResult, ListAssociatedFleetsError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedStacksError = CommonErrors;
/**
 * Retrieves the name of the stack with which the specified fleet is associated.
 */
export declare const listAssociatedStacks: API.OperationMethod<ListAssociatedStacksRequest & RegionInput, ListAssociatedStacksResult, ListAssociatedStacksError, Credentials | HttpClient.HttpClient>;
export type ListEntitledApplicationsError = EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of entitled applications.
 */
export declare const listEntitledApplications: API.OperationMethod<ListEntitledApplicationsRequest & RegionInput, ListEntitledApplicationsResult, ListEntitledApplicationsError, Credentials | HttpClient.HttpClient>;
export type ListExportImageTasksError = OperationNotPermittedException | CommonErrors;
/**
 * Lists export image tasks, with optional filtering and pagination. Use this operation to monitor the status of multiple export operations.
 */
export declare const listExportImageTasks: API.OperationMethod<ListExportImageTasksRequest & RegionInput, ListExportImageTasksResult, ListExportImageTasksError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of all tags for the specified WorkSpaces Applications resource. You can tag WorkSpaces Applications image builders, images, fleets, and stacks.
 *
 * For more information about tags, see Tagging Your Resources in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartAppBlockBuilderError = ConcurrentModificationException | InvalidAccountStatusException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Starts an app block builder.
 *
 * An app block builder can only be started when it's associated with an app
 * block.
 *
 * Starting an app block builder starts a new instance, which is equivalent to an elastic
 * fleet instance with application builder assistance functionality.
 */
export declare const startAppBlockBuilder: API.OperationMethod<StartAppBlockBuilderRequest & RegionInput, StartAppBlockBuilderResult, StartAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type StartFleetError = ConcurrentModificationException | InvalidAccountStatusException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified fleet.
 */
export declare const startFleet: API.OperationMethod<StartFleetRequest & RegionInput, StartFleetResult, StartFleetError, Credentials | HttpClient.HttpClient>;
export type StartImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified image builder.
 */
export declare const startImageBuilder: API.OperationMethod<StartImageBuilderRequest & RegionInput, StartImageBuilderResult, StartImageBuilderError, Credentials | HttpClient.HttpClient>;
export type StartSoftwareDeploymentToImageBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Initiates license included applications deployment to an image builder instance.
 */
export declare const startSoftwareDeploymentToImageBuilder: API.OperationMethod<StartSoftwareDeploymentToImageBuilderRequest & RegionInput, StartSoftwareDeploymentToImageBuilderResult, StartSoftwareDeploymentToImageBuilderError, Credentials | HttpClient.HttpClient>;
export type StopAppBlockBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Stops an app block builder.
 *
 * Stopping an app block builder terminates the instance, and the instance state is not
 * persisted.
 */
export declare const stopAppBlockBuilder: API.OperationMethod<StopAppBlockBuilderRequest & RegionInput, StopAppBlockBuilderResult, StopAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type StopFleetError = ConcurrentModificationException | ResourceNotFoundException | CommonErrors;
/**
 * Stops the specified fleet.
 */
export declare const stopFleet: API.OperationMethod<StopFleetRequest & RegionInput, StopFleetResult, StopFleetError, Credentials | HttpClient.HttpClient>;
export type StopImageBuilderError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Stops the specified image builder.
 */
export declare const stopImageBuilder: API.OperationMethod<StopImageBuilderRequest & RegionInput, StopImageBuilderResult, StopImageBuilderError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidAccountStatusException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Adds or overwrites one or more tags for the specified WorkSpaces Applications resource. You can tag WorkSpaces Applications image builders, images, fleets, and stacks.
 *
 * Each tag consists of a key and an optional value. If a resource already has a tag with the same key,
 * this operation updates its value.
 *
 * To list the current tags for your resources, use ListTagsForResource.
 * To disassociate tags from your resources, use UntagResource.
 *
 * For more information about tags, see Tagging Your Resources in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Disassociates one or more specified tags from the specified WorkSpaces Applications resource.
 *
 * To list the current tags for your resources, use ListTagsForResource.
 *
 * For more information about tags, see Tagging Your Resources in the *Amazon WorkSpaces Applications Administration Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAppBlockBuilderError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceInUseException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an app block builder.
 *
 * If the app block builder is in the `STARTING` or `STOPPING`
 * state, you can't update it. If the app block builder is in the `RUNNING`
 * state, you can only update the DisplayName and Description. If the app block builder is
 * in the `STOPPED` state, you can update any attribute except the Name.
 */
export declare const updateAppBlockBuilder: API.OperationMethod<UpdateAppBlockBuilderRequest & RegionInput, UpdateAppBlockBuilderResult, UpdateAppBlockBuilderError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = ConcurrentModificationException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResult, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectoryConfigError = ConcurrentModificationException | IncompatibleImageException | InvalidRoleException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified Directory Config object in WorkSpaces Applications. This object includes the configuration information required to join fleets and image builders to Microsoft Active Directory domains.
 */
export declare const updateDirectoryConfig: API.OperationMethod<UpdateDirectoryConfigRequest & RegionInput, UpdateDirectoryConfigResult, UpdateDirectoryConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateEntitlementError = ConcurrentModificationException | EntitlementNotFoundException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified entitlement.
 */
export declare const updateEntitlement: API.OperationMethod<UpdateEntitlementRequest & RegionInput, UpdateEntitlementResult, UpdateEntitlementError, Credentials | HttpClient.HttpClient>;
export type UpdateFleetError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | RequestLimitExceededException | ResourceInUseException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified fleet.
 *
 * If the fleet is in the `STOPPED` state, you can update any attribute except
 * the fleet name.
 *
 * If the fleet is in the `RUNNING` state, you can update the following based
 * on the fleet type:
 *
 * - Always-On and On-Demand fleet types
 *
 * You can update the `DisplayName`, `ComputeCapacity`,
 * `ImageARN`, `ImageName`,
 * `IdleDisconnectTimeoutInSeconds`, and
 * `DisconnectTimeoutInSeconds` attributes.
 *
 * - Elastic fleet type
 *
 * You can update the `DisplayName`,
 * `IdleDisconnectTimeoutInSeconds`,
 * `DisconnectTimeoutInSeconds`, `MaxConcurrentSessions`, `SessionScriptS3Location`
 * and `UsbDeviceFilterStrings` attributes.
 *
 * If the fleet is in the `STARTING` or `STOPPED` state, you can't update it.
 */
export declare const updateFleet: API.OperationMethod<UpdateFleetRequest & RegionInput, UpdateFleetResult, UpdateFleetError, Credentials | HttpClient.HttpClient>;
export type UpdateImageBuilderError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | OperationNotPermittedException | RequestLimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified fields for the specified image builder. The image builder must be in the STOPPED state.
 */
export declare const updateImageBuilder: API.OperationMethod<UpdateImageBuilderRequest & RegionInput, UpdateImageBuilderResult, UpdateImageBuilderError, Credentials | HttpClient.HttpClient>;
export type UpdateImagePermissionsError = LimitExceededException | ResourceNotAvailableException | ResourceNotFoundException | CommonErrors;
/**
 * Adds or updates permissions for the specified private image.
 */
export declare const updateImagePermissions: API.OperationMethod<UpdateImagePermissionsRequest & RegionInput, UpdateImagePermissionsResult, UpdateImagePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateStackError = ConcurrentModificationException | IncompatibleImageException | InvalidAccountStatusException | InvalidParameterCombinationException | InvalidRoleException | LimitExceededException | OperationNotPermittedException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified fields for the specified stack.
 */
export declare const updateStack: API.OperationMethod<UpdateStackRequest & RegionInput, UpdateStackResult, UpdateStackError, Credentials | HttpClient.HttpClient>;
export type UpdateThemeForStackError = ConcurrentModificationException | InvalidAccountStatusException | InvalidParameterCombinationException | LimitExceededException | OperationNotPermittedException | ResourceNotFoundException | CommonErrors;
/**
 * Updates custom branding that customizes the appearance of the streaming application catalog page.
 */
export declare const updateThemeForStack: API.OperationMethod<UpdateThemeForStackRequest & RegionInput, UpdateThemeForStackResult, UpdateThemeForStackError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appstream.d.ts.map