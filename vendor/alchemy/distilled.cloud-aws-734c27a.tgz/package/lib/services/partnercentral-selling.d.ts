import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly ErrorList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CatalogIdentifier = string;
export type EngagementInvitationArnOrIdentifier = string;
export interface AcceptEngagementInvitationRequest {
    Catalog: string;
    Identifier: string;
}
export interface AcceptEngagementInvitationResponse {
}
export type OpportunityIdentifier = string;
export type Email = string | redacted.Redacted<string>;
export type Name = string | redacted.Redacted<string>;
export type PhoneNumber = string | redacted.Redacted<string>;
export type JobTitle = string | redacted.Redacted<string>;
export interface AssigneeContact {
    Email: string | redacted.Redacted<string>;
    FirstName: string | redacted.Redacted<string>;
    LastName: string | redacted.Redacted<string>;
    Phone?: string | redacted.Redacted<string> | undefined;
    BusinessTitle: string | redacted.Redacted<string>;
}
export interface AssignOpportunityRequest {
    Catalog: string;
    Identifier: string;
    Assignee: AssigneeContact;
}
export interface AssignOpportunityResponse {
}
export type RelatedEntityType = "Solutions" | "AwsProducts" | "AwsMarketplaceOffers" | "AwsMarketplaceOfferSets" | "AwsMarketplaceSolutions" | "AwsMarketplaceProducts" | (string & {});
export interface AssociateOpportunityRequest {
    Catalog: string;
    OpportunityIdentifier: string;
    RelatedEntityType: RelatedEntityType;
    RelatedEntityIdentifier: string;
}
export interface AssociateOpportunityResponse {
}
export type ClientToken = string;
export type EngagementTitle = string;
export type EngagementDescription = string;
export type EngagementContextIdentifier = string;
export type EngagementContextType = "CustomerProject" | "Lead" | "ProspectingResult" | (string & {});
export type Industry = "Aerospace" | "Agriculture" | "Automotive" | "Computers and Electronics" | "Consumer Goods" | "Education" | "Energy - Oil and Gas" | "Energy - Power and Utilities" | "Financial Services" | "Gaming" | "Government" | "Healthcare" | "Hospitality" | "Life Sciences" | "Manufacturing" | "Marketing and Advertising" | "Media and Entertainment" | "Mining" | "Non-Profit Organization" | "Professional Services" | "Real Estate and Construction" | "Retail" | "Software and Internet" | "Telecommunications" | "Transportation and Logistics" | "Travel" | "Wholesale and Distribution" | "Other" | (string & {});
export type CompanyName = string | redacted.Redacted<string>;
export type CompanyWebsiteUrl = string | redacted.Redacted<string>;
export type CountryCode = "US" | "AF" | "AX" | "AL" | "DZ" | "AS" | "AD" | "AO" | "AI" | "AQ" | "AG" | "AR" | "AM" | "AW" | "AU" | "AT" | "AZ" | "BS" | "BH" | "BD" | "BB" | "BY" | "BE" | "BZ" | "BJ" | "BM" | "BT" | "BO" | "BQ" | "BA" | "BW" | "BV" | "BR" | "IO" | "BN" | "BG" | "BF" | "BI" | "KH" | "CM" | "CA" | "CV" | "KY" | "CF" | "TD" | "CL" | "CN" | "CX" | "CC" | "CO" | "KM" | "CG" | "CK" | "CR" | "CI" | "HR" | "CU" | "CW" | "CY" | "CZ" | "CD" | "DK" | "DJ" | "DM" | "DO" | "EC" | "EG" | "SV" | "GQ" | "ER" | "EE" | "ET" | "FK" | "FO" | "FJ" | "FI" | "FR" | "GF" | "PF" | "TF" | "GA" | "GM" | "GE" | "DE" | "GH" | "GI" | "GR" | "GL" | "GD" | "GP" | "GU" | "GT" | "GG" | "GN" | "GW" | "GY" | "HT" | "HM" | "VA" | "HN" | "HK" | "HU" | "IS" | "IN" | "ID" | "IR" | "IQ" | "IE" | "IM" | "IL" | "IT" | "JM" | "JP" | "JE" | "JO" | "KZ" | "KE" | "KI" | "KR" | "KW" | "KG" | "LA" | "LV" | "LB" | "LS" | "LR" | "LY" | "LI" | "LT" | "LU" | "MO" | "MK" | "MG" | "MW" | "MY" | "MV" | "ML" | "MT" | "MH" | "MQ" | "MR" | "MU" | "YT" | "MX" | "FM" | "MD" | "MC" | "MN" | "ME" | "MS" | "MA" | "MZ" | "MM" | "NA" | "NR" | "NP" | "NL" | "AN" | "NC" | "NZ" | "NI" | "NE" | "NG" | "NU" | "NF" | "MP" | "NO" | "OM" | "PK" | "PW" | "PS" | "PA" | "PG" | "PY" | "PE" | "PH" | "PN" | "PL" | "PT" | "PR" | "QA" | "RE" | "RO" | "RU" | "RW" | "BL" | "SH" | "KN" | "LC" | "MF" | "PM" | "VC" | "WS" | "SM" | "ST" | "SA" | "SN" | "RS" | "SC" | "SL" | "SG" | "SX" | "SK" | "SI" | "SB" | "SO" | "ZA" | "GS" | "SS" | "ES" | "LK" | "SD" | "SR" | "SJ" | "SZ" | "SE" | "CH" | "SY" | "TW" | "TJ" | "TZ" | "TH" | "TL" | "TG" | "TK" | "TO" | "TT" | "TN" | "TR" | "TM" | "TC" | "TV" | "UG" | "UA" | "AE" | "GB" | "UM" | "UY" | "UZ" | "VU" | "VE" | "VN" | "VG" | "VI" | "WF" | "EH" | "YE" | "ZM" | "ZW" | (string & {});
export interface EngagementCustomer {
    Industry: Industry;
    CompanyName: string | redacted.Redacted<string>;
    WebsiteUrl: string | redacted.Redacted<string>;
    CountryCode: CountryCode;
}
export type EngagementCustomerProjectTitle = string;
export type EngagementCustomerBusinessProblem = string | redacted.Redacted<string>;
export interface EngagementCustomerProjectDetails {
    Title: string;
    BusinessProblem: string | redacted.Redacted<string>;
    TargetCompletionDate: string;
}
export interface CustomerProjectsContext {
    Customer?: EngagementCustomer | undefined;
    Project?: EngagementCustomerProjectDetails | undefined;
}
export interface LeadInsights {
    LeadReadinessScore?: string | undefined;
}
export type LeadQualificationStatus = string;
export type LeadIndustry = string;
export type LeadWebsiteUrl = string | redacted.Redacted<string>;
export type LeadCountryCode = string | redacted.Redacted<string>;
export interface LeadAddress {
    City?: string | undefined;
    PostalCode?: string | undefined;
    StateOrRegion?: string | undefined;
    CountryCode?: string | redacted.Redacted<string> | undefined;
}
export type AwsMaturity = string;
export type LeadMarketSegment = string;
export interface LeadCustomer {
    Industry?: string | undefined;
    CompanyName: string | redacted.Redacted<string>;
    WebsiteUrl?: string | redacted.Redacted<string> | undefined;
    Address?: LeadAddress | undefined;
    AwsMaturity?: string | undefined;
    MarketSegment?: string | undefined;
}
export type LeadSourceType = string;
export type LeadSourceId = string;
export type LeadSourceName = string;
export type EngagementUseCase = string;
export type CustomerAction = string;
export type LeadBusinessProblem = string | redacted.Redacted<string>;
export type LeadJobTitle = string | redacted.Redacted<string>;
export type LeadEmail = string | redacted.Redacted<string>;
export type LeadPhoneNumber = string | redacted.Redacted<string>;
export interface LeadContact {
    BusinessTitle: string | redacted.Redacted<string>;
    Email: string | redacted.Redacted<string>;
    FirstName: string | redacted.Redacted<string>;
    LastName: string | redacted.Redacted<string>;
    Phone?: string | redacted.Redacted<string> | undefined;
}
export interface LeadInteraction {
    SourceType?: string | undefined;
    SourceId?: string | undefined;
    SourceName?: string | undefined;
    Usecase?: string | undefined;
    InteractionDate?: Date | undefined;
    CustomerAction?: string | undefined;
    BusinessProblem?: string | redacted.Redacted<string> | undefined;
    Contact: LeadContact;
}
export type LeadInteractionList = LeadInteraction[];
export interface LeadContext {
    Insights?: LeadInsights | undefined;
    QualificationStatus?: string | undefined;
    Customer: LeadCustomer;
    Interactions: LeadInteraction[];
}
export type ProspectingAccountName = string;
export type ProspectingGeo = string;
export type ProspectingRegion = string;
export type ProspectingSubRegion = string;
export type ProspectingSubIndustry = string;
export type ProspectingSegment = string;
export type ProspectingCompanySize = string;
export type EligibleProgramsList = string[];
export type ProspectingPublicProfileSummary = string;
export interface ProspectingResultCustomer {
    AccountName?: string | undefined;
    Geo?: string | undefined;
    Region?: string | undefined;
    SubRegion?: string | undefined;
    Country?: CountryCode | undefined;
    Industry?: Industry | undefined;
    SubIndustry?: string | undefined;
    Segment?: string | undefined;
    CompanySize?: string | undefined;
    EligiblePrograms?: string[] | undefined;
    PublicProfileSummary?: string | undefined;
}
export type EngagementScoreLevel = string;
export interface ProspectingInsights {
    MarketplaceEngagementScore?: string | undefined;
    SolutionScore?: string | undefined;
    SolutionCategory?: string | undefined;
    SolutionSubCategory?: string | undefined;
}
export type ProspectingTaskIdentifier = string;
export type TaskArn = string;
export type TaskName = string;
export interface ProspectingResultAws {
    Customer?: ProspectingResultCustomer | undefined;
    Insights?: ProspectingInsights | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    TaskName?: string | undefined;
}
export interface ProspectingResult {
    Aws?: ProspectingResultAws | undefined;
}
export type EngagementContextPayload = {
    CustomerProject: CustomerProjectsContext;
    Lead?: undefined;
    ProspectingResult?: undefined;
} | {
    CustomerProject?: undefined;
    Lead: LeadContext;
    ProspectingResult?: undefined;
} | {
    CustomerProject?: undefined;
    Lead?: undefined;
    ProspectingResult: ProspectingResult;
};
export interface EngagementContextDetails {
    Id?: string | undefined;
    Type: EngagementContextType;
    Payload?: EngagementContextPayload | undefined;
}
export type EngagementContexts = EngagementContextDetails[];
export interface CreateEngagementRequest {
    Catalog: string;
    ClientToken: string;
    Title?: string | undefined;
    Description?: string | undefined;
    Contexts?: EngagementContextDetails[] | undefined;
}
export type EngagementIdentifier = string;
export type EngagementArn = string;
export interface CreateEngagementResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
    ModifiedAt?: Date | undefined;
}
export type EngagementArnOrIdentifier = string;
export interface CreateEngagementContextRequest {
    Catalog: string;
    EngagementIdentifier: string;
    ClientToken: string;
    Type: EngagementContextType;
    Payload: EngagementContextPayload;
}
export interface CreateEngagementContextResponse {
    EngagementId?: string | undefined;
    EngagementArn?: string | undefined;
    EngagementLastModifiedAt?: Date | undefined;
    ContextId?: string | undefined;
}
export type InvitationMessage = string | redacted.Redacted<string>;
export type Alias = string | redacted.Redacted<string>;
export type AwsAccount = string | redacted.Redacted<string>;
export interface AccountReceiver {
    Alias?: string | redacted.Redacted<string> | undefined;
    AwsAccountId: string | redacted.Redacted<string>;
}
export type Receiver = {
    Account: AccountReceiver;
};
export type SenderContactEmail = string | redacted.Redacted<string>;
export interface SenderContact {
    Email: string | redacted.Redacted<string>;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    BusinessTitle?: string | redacted.Redacted<string> | undefined;
    Phone?: string | redacted.Redacted<string> | undefined;
}
export type SenderContactList = SenderContact[];
export type ReceiverResponsibility = "Distributor" | "Reseller" | "Hardware Partner" | "Managed Service Provider" | "Software Partner" | "Services Partner" | "Training Partner" | "Co-Sell Facilitator" | "Facilitator" | (string & {});
export type ReceiverResponsibilityList = ReceiverResponsibility[];
export type Amount = string | redacted.Redacted<string>;
export type CurrencyCode = "USD" | "EUR" | "GBP" | "AUD" | "CAD" | "CNY" | "NZD" | "INR" | "JPY" | "CHF" | "SEK" | "AED" | "AFN" | "ALL" | "AMD" | "ANG" | "AOA" | "ARS" | "AWG" | "AZN" | "BAM" | "BBD" | "BDT" | "BGN" | "BHD" | "BIF" | "BMD" | "BND" | "BOB" | "BOV" | "BRL" | "BSD" | "BTN" | "BWP" | "BYN" | "BZD" | "CDF" | "CHE" | "CHW" | "CLF" | "CLP" | "COP" | "COU" | "CRC" | "CUC" | "CUP" | "CVE" | "CZK" | "DJF" | "DKK" | "DOP" | "DZD" | "EGP" | "ERN" | "ETB" | "FJD" | "FKP" | "GEL" | "GHS" | "GIP" | "GMD" | "GNF" | "GTQ" | "GYD" | "HKD" | "HNL" | "HRK" | "HTG" | "HUF" | "IDR" | "ILS" | "IQD" | "IRR" | "ISK" | "JMD" | "JOD" | "KES" | "KGS" | "KHR" | "KMF" | "KPW" | "KRW" | "KWD" | "KYD" | "KZT" | "LAK" | "LBP" | "LKR" | "LRD" | "LSL" | "LYD" | "MAD" | "MDL" | "MGA" | "MKD" | "MMK" | "MNT" | "MOP" | "MRU" | "MUR" | "MVR" | "MWK" | "MXN" | "MXV" | "MYR" | "MZN" | "NAD" | "NGN" | "NIO" | "NOK" | "NPR" | "OMR" | "PAB" | "PEN" | "PGK" | "PHP" | "PKR" | "PLN" | "PYG" | "QAR" | "RON" | "RSD" | "RUB" | "RWF" | "SAR" | "SBD" | "SCR" | "SDG" | "SGD" | "SHP" | "SLL" | "SOS" | "SRD" | "SSP" | "STN" | "SVC" | "SYP" | "SZL" | "THB" | "TJS" | "TMT" | "TND" | "TOP" | "TRY" | "TTD" | "TWD" | "TZS" | "UAH" | "UGX" | "USN" | "UYI" | "UYU" | "UZS" | "VEF" | "VND" | "VUV" | "WST" | "XAF" | "XCD" | "XDR" | "XOF" | "XPF" | "XSU" | "XUA" | "YER" | "ZAR" | "ZMW" | "ZWL" | (string & {});
export type PaymentFrequency = "Monthly" | (string & {});
export type EstimationUrl = string;
export interface ExpectedCustomerSpend {
    Amount?: string | redacted.Redacted<string> | undefined;
    CurrencyCode: CurrencyCode;
    Frequency: PaymentFrequency;
    TargetCompany: string;
    EstimationUrl?: string | undefined;
}
export type ExpectedCustomerSpendList = ExpectedCustomerSpend[];
export interface ProjectDetails {
    BusinessProblem: string | redacted.Redacted<string>;
    Title: string;
    TargetCompletionDate: string;
    ExpectedCustomerSpend: ExpectedCustomerSpend[];
}
export interface OpportunityInvitationPayload {
    SenderContacts?: SenderContact[] | undefined;
    ReceiverResponsibilities: ReceiverResponsibility[];
    Customer: EngagementCustomer;
    Project: ProjectDetails;
}
export interface LeadInvitationCustomer {
    Industry?: string | undefined;
    CompanyName: string | redacted.Redacted<string>;
    WebsiteUrl?: string | redacted.Redacted<string> | undefined;
    CountryCode?: string | redacted.Redacted<string> | undefined;
    AwsMaturity?: string | undefined;
    MarketSegment?: string | undefined;
}
export interface LeadInvitationInteraction {
    SourceType?: string | undefined;
    SourceId?: string | undefined;
    SourceName?: string | undefined;
    Usecase?: string | undefined;
    ContactBusinessTitle: string | redacted.Redacted<string>;
}
export interface LeadInvitationPayload {
    Customer: LeadInvitationCustomer;
    Interaction: LeadInvitationInteraction;
}
export type Payload = {
    OpportunityInvitation: OpportunityInvitationPayload;
    LeadInvitation?: undefined;
} | {
    OpportunityInvitation?: undefined;
    LeadInvitation: LeadInvitationPayload;
};
export interface Invitation {
    Message: string | redacted.Redacted<string>;
    Receiver: Receiver;
    Payload: Payload;
}
export interface CreateEngagementInvitationRequest {
    Catalog: string;
    ClientToken: string;
    EngagementIdentifier: string;
    Invitation: Invitation;
}
export type EngagementInvitationIdentifier = string;
export type EngagementInvitationArn = string;
export interface CreateEngagementInvitationResponse {
    Id: string;
    Arn: string;
}
export type PrimaryNeedFromAws = "Co-Sell - Architectural Validation" | "Co-Sell - Business Presentation" | "Co-Sell - Competitive Information" | "Co-Sell - Pricing Assistance" | "Co-Sell - Technical Consultation" | "Co-Sell - Total Cost of Ownership Evaluation" | "Co-Sell - Deal Support" | "Co-Sell - Support for Public Tender / RFx" | (string & {});
export type PrimaryNeedsFromAws = PrimaryNeedFromAws[];
export type NationalSecurity = "Yes" | "No" | (string & {});
export type WebsiteUrl = string | redacted.Redacted<string>;
export type AddressPart = string | redacted.Redacted<string>;
export interface Address {
    City?: string | redacted.Redacted<string> | undefined;
    PostalCode?: string | redacted.Redacted<string> | undefined;
    StateOrRegion?: string | redacted.Redacted<string> | undefined;
    CountryCode?: CountryCode | undefined;
    StreetAddress?: string | redacted.Redacted<string> | undefined;
}
export type DunsNumber = string | redacted.Redacted<string>;
export interface Account {
    Industry?: Industry | undefined;
    OtherIndustry?: string | undefined;
    CompanyName: string | redacted.Redacted<string>;
    WebsiteUrl?: string | redacted.Redacted<string> | undefined;
    AwsAccountId?: string | redacted.Redacted<string> | undefined;
    Address?: Address | undefined;
    Duns?: string | redacted.Redacted<string> | undefined;
}
export interface Contact {
    Email?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    BusinessTitle?: string | redacted.Redacted<string> | undefined;
    Phone?: string | redacted.Redacted<string> | undefined;
}
export type CustomerContactsList = Contact[];
export interface Customer {
    Account?: Account | undefined;
    Contacts?: Contact[] | undefined;
}
export type DeliveryModel = "SaaS or PaaS" | "BYOL or AMI" | "Managed Services" | "Professional Services" | "Resell" | "Other" | (string & {});
export type DeliveryModels = DeliveryModel[];
export type ExpectedContractDurationTerm = "Months" | (string & {});
export interface ExpectedContractDuration {
    Term: ExpectedContractDurationTerm;
    Value: string;
}
export type PiiString = string | redacted.Redacted<string>;
export type ApnPrograms = string[];
export type SalesActivity = "Initialized discussions with customer" | "Customer has shown interest in solution" | "Conducted POC / Demo" | "In evaluation / planning stage" | "Agreed on solution to Business Problem" | "Completed Action Plan" | "Finalized Deployment Need" | "SOW Signed" | (string & {});
export type SalesActivities = SalesActivity[];
export type CompetitorName = "Oracle Cloud" | "On-Prem" | "Co-location" | "Akamai" | "AliCloud" | "Google Cloud Platform" | "IBM Softlayer" | "Microsoft Azure" | "Other- Cost Optimization" | "No Competition" | "*Other" | (string & {});
export type AwsPartition = "aws-eusc" | (string & {});
export interface Project {
    DeliveryModels?: DeliveryModel[] | undefined;
    ExpectedCustomerSpend?: ExpectedCustomerSpend[] | undefined;
    ExpectedContractDuration?: ExpectedContractDuration | undefined;
    Title?: string | redacted.Redacted<string> | undefined;
    ApnPrograms?: string[] | undefined;
    CustomerBusinessProblem?: string | redacted.Redacted<string> | undefined;
    CustomerUseCase?: string | undefined;
    RelatedOpportunityIdentifier?: string | undefined;
    SalesActivities?: SalesActivity[] | undefined;
    CompetitorName?: CompetitorName | undefined;
    OtherCompetitorNames?: string | undefined;
    OtherSolutionDescription?: string | redacted.Redacted<string> | undefined;
    AdditionalComments?: string | undefined;
    AwsPartition?: AwsPartition | undefined;
}
export type OpportunityType = "Net New Business" | "Flat Renewal" | "Expansion" | (string & {});
export type MarketingSource = "Marketing Activity" | "None" | (string & {});
export type UseCases = string[];
export type Channel = "AWS Marketing Central" | "Content Syndication" | "Display" | "Email" | "Live Event" | "Out Of Home (OOH)" | "Print" | "Search" | "Social" | "Telemarketing" | "TV" | "Video" | "Virtual Event" | (string & {});
export type Channels = Channel[];
export type AwsFundingUsed = "Yes" | "No" | (string & {});
export interface Marketing {
    CampaignName?: string | undefined;
    Source?: MarketingSource | undefined;
    UseCases?: string[] | undefined;
    Channels?: Channel[] | undefined;
    AwsFundingUsed?: AwsFundingUsed | undefined;
}
export type RevenueModel = "Contract" | "Pay-as-you-go" | "Subscription" | (string & {});
export interface MonetaryValue {
    Amount: string;
    CurrencyCode: CurrencyCode;
}
export interface SoftwareRevenue {
    DeliveryModel?: RevenueModel | undefined;
    Value?: MonetaryValue | undefined;
    EffectiveDate?: string | undefined;
    ExpirationDate?: string | undefined;
}
export type Stage = "Prospect" | "Qualified" | "Technical Validation" | "Business Validation" | "Committed" | "Launched" | "Closed Lost" | (string & {});
export type ClosedLostReason = "Customer Deficiency" | "Delay / Cancellation of Project" | "Legal / Tax / Regulatory" | "Lost to Competitor - Google" | "Lost to Competitor - Microsoft" | "Lost to Competitor - SoftLayer" | "Lost to Competitor - VMWare" | "Lost to Competitor - Other" | "No Opportunity" | "On Premises Deployment" | "Partner Gap" | "Price" | "Security / Compliance" | "Technical Limitations" | "Customer Experience" | "Other" | "People/Relationship/Governance" | "Product/Technology" | "Financial/Commercial" | (string & {});
export type ReviewStatus = "Pending Submission" | "Submitted" | "In review" | "Approved" | "Rejected" | "Action Required" | (string & {});
export interface NextStepsHistory {
    Value: string;
    Time: Date;
}
export type NextStepsHistories = NextStepsHistory[];
export interface LifeCycle {
    Stage?: Stage | undefined;
    ClosedLostReason?: ClosedLostReason | undefined;
    NextSteps?: string | redacted.Redacted<string> | undefined;
    TargetCloseDate?: string | undefined;
    ReviewStatus?: ReviewStatus | undefined;
    ReviewComments?: string | undefined;
    ReviewStatusReason?: string | undefined;
    NextStepsHistory?: NextStepsHistory[] | undefined;
}
export type OpportunityOrigin = "AWS Referral" | "Partner Referral" | (string & {});
export type PartnerOpportunityTeamMembersList = Contact[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateOpportunityRequest {
    Catalog: string;
    PrimaryNeedsFromAws?: PrimaryNeedFromAws[] | undefined;
    NationalSecurity?: NationalSecurity | undefined;
    PartnerOpportunityIdentifier?: string | undefined;
    Customer?: Customer | undefined;
    Project?: Project | undefined;
    OpportunityType?: OpportunityType | undefined;
    Marketing?: Marketing | undefined;
    SoftwareRevenue?: SoftwareRevenue | undefined;
    ClientToken: string;
    LifeCycle?: LifeCycle | undefined;
    Origin?: OpportunityOrigin | undefined;
    OpportunityTeam?: Contact[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateOpportunityResponse {
    Id: string;
    PartnerOpportunityIdentifier?: string | undefined;
    LastModifiedDate?: Date | undefined;
}
export type ResourceType = "Opportunity" | (string & {});
export type ResourceIdentifier = string;
export type ResourceTemplateName = string;
export interface CreateResourceSnapshotRequest {
    Catalog: string;
    EngagementIdentifier: string;
    ResourceType: ResourceType;
    ResourceIdentifier: string;
    ResourceSnapshotTemplateIdentifier: string;
    ClientToken: string;
}
export type ResourceArn = string;
export type ResourceSnapshotRevision = number;
export interface CreateResourceSnapshotResponse {
    Arn?: string | undefined;
    Revision?: number | undefined;
}
export interface CreateResourceSnapshotJobRequest {
    Catalog: string;
    ClientToken: string;
    EngagementIdentifier: string;
    ResourceType: ResourceType;
    ResourceIdentifier: string;
    ResourceSnapshotTemplateIdentifier: string;
    Tags?: Tag[] | undefined;
}
export type ResourceSnapshotJobIdentifier = string;
export type ResourceSnapshotJobArn = string;
export interface CreateResourceSnapshotJobResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
}
export interface DeleteResourceSnapshotJobRequest {
    Catalog: string;
    ResourceSnapshotJobIdentifier: string;
}
export interface DeleteResourceSnapshotJobResponse {
}
export interface DisassociateOpportunityRequest {
    Catalog: string;
    OpportunityIdentifier: string;
    RelatedEntityType: RelatedEntityType;
    RelatedEntityIdentifier: string;
}
export interface DisassociateOpportunityResponse {
}
export interface GetAwsOpportunitySummaryRequest {
    Catalog: string;
    RelatedOpportunityIdentifier: string;
}
export type SalesInvolvementType = "For Visibility Only" | "Co-Sell" | (string & {});
export type Visibility = "Full" | "Limited" | (string & {});
export type AwsClosedLostReason = "Administrative" | "Business Associate Agreement" | "Company Acquired/Dissolved" | "Competitive Offering" | "Customer Data Requirement" | "Customer Deficiency" | "Customer Experience" | "Delay / Cancellation of Project" | "Duplicate" | "Duplicate Opportunity" | "Executive Blocker" | "Failed Vetting" | "Feature Limitation" | "Financial/Commercial" | "Insufficient Amazon Value" | "Insufficient AWS Value" | "International Constraints" | "Legal / Tax / Regulatory" | "Legal Terms and Conditions" | "Lost to Competitor" | "Lost to Competitor - Google" | "Lost to Competitor - Microsoft" | "Lost to Competitor - Other" | "Lost to Competitor - Rackspace" | "Lost to Competitor - SoftLayer" | "Lost to Competitor - VMWare" | "No Customer Reference" | "No Integration Resources" | "No Opportunity" | "No Perceived Value of MP" | "No Response" | "Not Committed to AWS" | "No Update" | "On Premises Deployment" | "Other" | "Other (Details in Description)" | "Partner Gap" | "Past Due" | "People/Relationship/Governance" | "Platform Technology Limitation" | "Preference for Competitor" | "Price" | "Product/Technology" | "Product Not on AWS" | "Security / Compliance" | "Self-Service" | "Technical Limitations" | "Term Sheet Impasse" | (string & {});
export type AwsOpportunityStage = "Not Started" | "In Progress" | "Prospect" | "Engaged" | "Identified" | "Qualify" | "Research" | "Seller Engaged" | "Evaluating" | "Seller Registered" | "Term Sheet Negotiation" | "Contract Negotiation" | "Onboarding" | "Building Integration" | "Qualified" | "On-hold" | "Technical Validation" | "Business Validation" | "Committed" | "Launched" | "Deferred to Partner" | "Closed Lost" | "Completed" | "Closed Incomplete" | (string & {});
export interface ProfileNextStepsHistory {
    Value: string;
    Time: Date;
}
export type ProfileNextStepsHistories = ProfileNextStepsHistory[];
export interface AwsOpportunityLifeCycle {
    TargetCloseDate?: string | undefined;
    ClosedLostReason?: AwsClosedLostReason | undefined;
    Stage?: AwsOpportunityStage | undefined;
    NextSteps?: string | redacted.Redacted<string> | undefined;
    NextStepsHistory?: ProfileNextStepsHistory[] | undefined;
}
export type AwsMemberBusinessTitle = "AWSSalesRep" | "AWSAccountOwner" | "WWPSPDM" | "PDM" | "PSM" | "ISVSM" | "Signatory" | (string & {});
export interface AwsTeamMember {
    Email?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    BusinessTitle?: AwsMemberBusinessTitle | undefined;
}
export type AwsOpportunityTeamMembersList = AwsTeamMember[];
export type EngagementScore = "High" | "Medium" | "Low" | (string & {});
export type MonetaryAmount = string | redacted.Redacted<string>;
export type AmountMap = {
    [key: string]: string | redacted.Redacted<string> | undefined;
};
export type StringList = string[];
export interface AwsProductOptimization {
    Description: string;
    SavingsAmount: string | redacted.Redacted<string>;
}
export type AwsProductOptimizationsList = AwsProductOptimization[];
export interface AwsProductDetails {
    ProductCode: string;
    ServiceCode?: string | undefined;
    Categories: string[];
    Amount?: string | redacted.Redacted<string> | undefined;
    OptimizedAmount?: string | redacted.Redacted<string> | undefined;
    PotentialSavingsAmount?: string | redacted.Redacted<string> | undefined;
    Optimizations: AwsProductOptimization[];
}
export type AwsProductsList = AwsProductDetails[];
export interface AwsProductInsights {
    CurrencyCode: CurrencyCode;
    Frequency: PaymentFrequency;
    TotalAmount?: string | redacted.Redacted<string> | undefined;
    TotalOptimizedAmount?: string | redacted.Redacted<string> | undefined;
    TotalPotentialSavingsAmount?: string | redacted.Redacted<string> | undefined;
    TotalAmountByCategory: {
        [key: string]: string | redacted.Redacted<string> | undefined;
    };
    AwsProducts: AwsProductDetails[];
}
export interface AwsProductsSpendInsightsBySource {
    Partner?: AwsProductInsights | undefined;
    AWS?: AwsProductInsights | undefined;
}
export interface OpportunityQuality {
    Score?: number | undefined;
    Trend?: string | undefined;
}
export type RecommendationAttributeMap = {
    [key: string]: string | undefined;
};
export interface Recommendation {
    Type: string;
    Details: string;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RecommendationList = Recommendation[];
export interface AwsOpportunityInsights {
    NextBestActions?: string | undefined;
    EngagementScore?: EngagementScore | undefined;
    AwsProductsSpendInsightsBySource?: AwsProductsSpendInsightsBySource | undefined;
    OpportunityQuality?: OpportunityQuality | undefined;
    Recommendations?: Recommendation[] | undefined;
}
export type InvolvementTypeChangeReason = "Expansion Opportunity" | "Change in Deal Information" | "Customer Requested" | "Technical Complexity" | "Risk Mitigation" | (string & {});
export type AwsProductIdentifier = string;
export type AwsProductIdentifiers = string[];
export type SolutionIdentifier = string;
export type SolutionIdentifiers = string[];
export type AwsMarketplaceSolutionIdentifier = string;
export type AwsMarketplaceSolutionIdentifiers = string[];
export type AwsMarketplaceProductArn = string;
export type AwsMarketplaceProductIdentifiers = string[];
export interface AwsOpportunityRelatedEntities {
    AwsProducts?: string[] | undefined;
    Solutions?: string[] | undefined;
    AwsMarketplaceSolutions?: string[] | undefined;
    AwsMarketplaceProducts?: string[] | undefined;
}
export interface AwsOpportunityCustomer {
    Contacts?: Contact[] | undefined;
}
export interface AwsOpportunityProject {
    ExpectedCustomerSpend?: ExpectedCustomerSpend[] | undefined;
    AwsPartition?: AwsPartition | undefined;
}
export interface AwsSoftwareRevenue {
    Value?: MonetaryValue | undefined;
    Discount?: string | undefined;
    EffectiveDate?: string | undefined;
    ExpirationDate?: string | undefined;
}
export interface GetAwsOpportunitySummaryResponse {
    RelatedOpportunityId?: string | undefined;
    Origin?: OpportunityOrigin | undefined;
    InvolvementType?: SalesInvolvementType | undefined;
    Visibility?: Visibility | undefined;
    LifeCycle?: AwsOpportunityLifeCycle | undefined;
    OpportunityTeam?: AwsTeamMember[] | undefined;
    Insights?: AwsOpportunityInsights | undefined;
    InvolvementTypeChangeReason?: InvolvementTypeChangeReason | undefined;
    RelatedEntityIds?: AwsOpportunityRelatedEntities | undefined;
    Customer?: AwsOpportunityCustomer | undefined;
    Project?: AwsOpportunityProject | undefined;
    CosellMotion?: string | undefined;
    SoftwareRevenue?: AwsSoftwareRevenue | undefined;
    Catalog: string;
}
export interface GetEngagementRequest {
    Catalog: string;
    Identifier: string;
}
export interface GetEngagementResponse {
    Id?: string | undefined;
    Arn?: string | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    CreatedAt?: Date | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
    MemberCount?: number | undefined;
    ModifiedAt?: Date | undefined;
    ModifiedBy?: string | redacted.Redacted<string> | undefined;
    Contexts?: EngagementContextDetails[] | undefined;
}
export interface GetEngagementInvitationRequest {
    Catalog: string;
    Identifier: string;
}
export type EngagementInvitationPayloadType = "OpportunityInvitation" | "LeadInvitation" | (string & {});
export type InvitationStatus = "ACCEPTED" | "PENDING" | "REJECTED" | "EXPIRED" | (string & {});
export type RejectionReasonString = string;
export type MemberCompanyName = string | redacted.Redacted<string>;
export interface EngagementMemberSummary {
    CompanyName?: string | redacted.Redacted<string> | undefined;
    WebsiteUrl?: string | undefined;
}
export type EngagementMemberSummaries = EngagementMemberSummary[];
export interface InvitationProspectingResultAws {
    Customer?: ProspectingResultCustomer | undefined;
    Insights?: ProspectingInsights | undefined;
}
export interface EnrichmentContext {
    ProspectingResultAws?: InvitationProspectingResultAws | undefined;
    LeadInsights?: LeadInsights | undefined;
}
export interface GetEngagementInvitationResponse {
    Arn?: string | undefined;
    PayloadType?: EngagementInvitationPayloadType | undefined;
    Id: string;
    EngagementId?: string | undefined;
    EngagementTitle?: string | undefined;
    Status?: InvitationStatus | undefined;
    InvitationDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    SenderAwsAccountId?: string | redacted.Redacted<string> | undefined;
    SenderCompanyName?: string | undefined;
    Receiver?: Receiver | undefined;
    Catalog: string;
    RejectionReason?: string | undefined;
    Payload?: Payload | undefined;
    InvitationMessage?: string | redacted.Redacted<string> | undefined;
    EngagementDescription?: string | undefined;
    ExistingMembers?: EngagementMemberSummary[] | undefined;
    EnrichmentContext?: EnrichmentContext | undefined;
}
export interface GetOpportunityRequest {
    Catalog: string;
    Identifier: string;
}
export type OpportunityArn = string;
export type AwsMarketplaceOfferIdentifier = string;
export type AwsMarketplaceOfferIdentifiers = string[];
export type AwsMarketplaceOfferSetIdentifier = string;
export type AwsMarketplaceOfferSetIdentifiers = string[];
export interface RelatedEntityIdentifiers {
    AwsMarketplaceOffers?: string[] | undefined;
    AwsMarketplaceOfferSets?: string[] | undefined;
    Solutions?: string[] | undefined;
    AwsProducts?: string[] | undefined;
    AwsMarketplaceSolutions?: string[] | undefined;
    AwsMarketplaceProducts?: string[] | undefined;
}
export interface GetOpportunityResponse {
    Catalog: string;
    PrimaryNeedsFromAws?: PrimaryNeedFromAws[] | undefined;
    NationalSecurity?: NationalSecurity | undefined;
    PartnerOpportunityIdentifier?: string | undefined;
    Customer?: Customer | undefined;
    Project?: Project | undefined;
    OpportunityType?: OpportunityType | undefined;
    Marketing?: Marketing | undefined;
    SoftwareRevenue?: SoftwareRevenue | undefined;
    Id: string;
    Arn?: string | undefined;
    LastModifiedDate: Date;
    CreatedDate: Date;
    RelatedEntityIdentifiers: RelatedEntityIdentifiers;
    LifeCycle?: LifeCycle | undefined;
    OpportunityTeam?: Contact[] | undefined;
}
export interface GetProspectingFromEngagementTaskRequest {
    Catalog: string;
    TaskIdentifier: string;
}
export type ProspectingTaskArn = string;
export type ProspectingTaskStatus = "PENDING" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export interface EngagementProspectingResult {
    EngagementIdentifier: string;
    EngagementContextId?: string | undefined;
    Status: ProspectingTaskStatus;
    ReasonCode?: string | undefined;
    Message?: string | undefined;
}
export type EngagementProspectingResultList = EngagementProspectingResult[];
export interface GetProspectingFromEngagementTaskResponse {
    TaskId: string;
    TaskArn: string;
    TaskName: string;
    StartTime: Date;
    EndTime?: Date | undefined;
    Engagements: EngagementProspectingResult[];
}
export interface GetResourceSnapshotRequest {
    Catalog: string;
    EngagementIdentifier: string;
    ResourceType: ResourceType;
    ResourceIdentifier: string;
    ResourceSnapshotTemplateIdentifier: string;
    Revision?: number | undefined;
}
export interface LifeCycleForView {
    TargetCloseDate?: string | undefined;
    ReviewStatus?: ReviewStatus | undefined;
    Stage?: Stage | undefined;
    NextSteps?: string | redacted.Redacted<string> | undefined;
}
export interface ProjectView {
    DeliveryModels?: DeliveryModel[] | undefined;
    ExpectedCustomerSpend?: ExpectedCustomerSpend[] | undefined;
    ExpectedContractDuration?: ExpectedContractDuration | undefined;
    CustomerUseCase?: string | undefined;
    SalesActivities?: SalesActivity[] | undefined;
    OtherSolutionDescription?: string | redacted.Redacted<string> | undefined;
}
export interface OpportunitySummaryView {
    OpportunityType?: OpportunityType | undefined;
    Lifecycle?: LifeCycleForView | undefined;
    OpportunityTeam?: Contact[] | undefined;
    PrimaryNeedsFromAws?: PrimaryNeedFromAws[] | undefined;
    Customer?: Customer | undefined;
    Project?: ProjectView | undefined;
    RelatedEntityIdentifiers?: RelatedEntityIdentifiers | undefined;
}
export interface AwsOpportunitySummaryFullView {
    RelatedOpportunityId?: string | undefined;
    Origin?: OpportunityOrigin | undefined;
    InvolvementType?: SalesInvolvementType | undefined;
    Visibility?: Visibility | undefined;
    LifeCycle?: AwsOpportunityLifeCycle | undefined;
    OpportunityTeam?: AwsTeamMember[] | undefined;
    Insights?: AwsOpportunityInsights | undefined;
    InvolvementTypeChangeReason?: InvolvementTypeChangeReason | undefined;
    RelatedEntityIds?: AwsOpportunityRelatedEntities | undefined;
    Customer?: AwsOpportunityCustomer | undefined;
    Project?: AwsOpportunityProject | undefined;
    CosellMotion?: string | undefined;
    SoftwareRevenue?: AwsSoftwareRevenue | undefined;
}
export type ResourceSnapshotPayload = {
    OpportunitySummary: OpportunitySummaryView;
    AwsOpportunitySummaryFullView?: undefined;
} | {
    OpportunitySummary?: undefined;
    AwsOpportunitySummaryFullView: AwsOpportunitySummaryFullView;
};
export type AwsAccountIdOrAliasList = (string | redacted.Redacted<string>)[];
export interface GetResourceSnapshotResponse {
    Catalog: string;
    Arn?: string | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    EngagementId?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceId?: string | undefined;
    ResourceSnapshotTemplateName?: string | undefined;
    Revision?: number | undefined;
    Payload?: ResourceSnapshotPayload | undefined;
    TargetMemberAccounts?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface GetResourceSnapshotJobRequest {
    Catalog: string;
    ResourceSnapshotJobIdentifier: string;
}
export type ResourceSnapshotJobStatus = "Running" | "Stopped" | (string & {});
export interface GetResourceSnapshotJobResponse {
    Catalog: string;
    Id?: string | undefined;
    Arn?: string | undefined;
    EngagementId?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceId?: string | undefined;
    ResourceArn?: string | undefined;
    ResourceSnapshotTemplateName?: string | undefined;
    CreatedAt?: Date | undefined;
    Status?: ResourceSnapshotJobStatus | undefined;
    LastSuccessfulExecutionDate?: Date | undefined;
    LastFailure?: string | undefined;
}
export interface GetSellingSystemSettingsRequest {
    Catalog: string;
}
export type ResourceSnapshotJobRoleArn = string;
export interface GetSellingSystemSettingsResponse {
    Catalog: string;
    ResourceSnapshotJobRoleArn?: string | undefined;
}
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export type ListTasksSortName = "StartTime" | (string & {});
export interface ListTasksSortBase {
    SortOrder: SortOrder;
    SortBy: ListTasksSortName;
}
export type TaskStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export type TaskStatuses = TaskStatus[];
export type OpportunityIdentifiers = string[];
export type EngagementInvitationIdentifiers = string[];
export type TaskArnOrIdentifier = string;
export type TaskIdentifiers = string[];
export interface ListEngagementByAcceptingInvitationTasksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: ListTasksSortBase | undefined;
    Catalog: string;
    TaskStatus?: TaskStatus[] | undefined;
    OpportunityIdentifier?: string[] | undefined;
    EngagementInvitationIdentifier?: string[] | undefined;
    TaskIdentifier?: string[] | undefined;
}
export type TaskIdentifier = string;
export type ReasonCode = "InvitationAccessDenied" | "InvitationValidationFailed" | "EngagementAccessDenied" | "OpportunityAccessDenied" | "ResourceSnapshotJobAccessDenied" | "ResourceSnapshotJobValidationFailed" | "ResourceSnapshotJobConflict" | "EngagementValidationFailed" | "EngagementConflict" | "OpportunitySubmissionFailed" | "EngagementInvitationConflict" | "InternalError" | "OpportunityValidationFailed" | "OpportunityConflict" | "ResourceSnapshotAccessDenied" | "ResourceSnapshotValidationFailed" | "ResourceSnapshotConflict" | "ServiceQuotaExceeded" | "RequestThrottled" | "ContextNotFound" | "CustomerProjectContextNotPermitted" | "DisqualifiedLeadNotPermitted" | (string & {});
export interface ListEngagementByAcceptingInvitationTaskSummary {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    StartTime?: Date | undefined;
    TaskStatus?: TaskStatus | undefined;
    Message?: string | undefined;
    ReasonCode?: ReasonCode | undefined;
    OpportunityId?: string | undefined;
    ResourceSnapshotJobId?: string | undefined;
    EngagementInvitationId?: string | undefined;
}
export type ListEngagementByAcceptingInvitationTaskSummaries = ListEngagementByAcceptingInvitationTaskSummary[];
export interface ListEngagementByAcceptingInvitationTasksResponse {
    TaskSummaries?: ListEngagementByAcceptingInvitationTaskSummary[] | undefined;
    NextToken?: string | undefined;
}
export type EngagementIdentifiers = string[];
export interface ListEngagementFromOpportunityTasksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: ListTasksSortBase | undefined;
    Catalog: string;
    TaskStatus?: TaskStatus[] | undefined;
    TaskIdentifier?: string[] | undefined;
    OpportunityIdentifier?: string[] | undefined;
    EngagementIdentifier?: string[] | undefined;
}
export interface ListEngagementFromOpportunityTaskSummary {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    StartTime?: Date | undefined;
    TaskStatus?: TaskStatus | undefined;
    Message?: string | undefined;
    ReasonCode?: ReasonCode | undefined;
    OpportunityId?: string | undefined;
    ResourceSnapshotJobId?: string | undefined;
    EngagementId?: string | undefined;
    EngagementInvitationId?: string | undefined;
}
export type ListEngagementFromOpportunityTaskSummaries = ListEngagementFromOpportunityTaskSummary[];
export interface ListEngagementFromOpportunityTasksResponse {
    TaskSummaries?: ListEngagementFromOpportunityTaskSummary[] | undefined;
    NextToken?: string | undefined;
}
export type PageSize = number;
export type OpportunityEngagementInvitationSortName = "InvitationDate" | (string & {});
export interface OpportunityEngagementInvitationSort {
    SortOrder: SortOrder;
    SortBy: OpportunityEngagementInvitationSortName;
}
export type EngagementInvitationsPayloadType = EngagementInvitationPayloadType[];
export type ParticipantType = "SENDER" | "RECEIVER" | (string & {});
export type InvitationStatusList = InvitationStatus[];
export interface ListEngagementInvitationsRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: OpportunityEngagementInvitationSort | undefined;
    PayloadType?: EngagementInvitationPayloadType[] | undefined;
    ParticipantType: ParticipantType;
    Status?: InvitationStatus[] | undefined;
    EngagementIdentifier?: string[] | undefined;
    SenderAwsAccountId?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface EngagementInvitationSummary {
    Arn?: string | undefined;
    PayloadType?: EngagementInvitationPayloadType | undefined;
    Id: string;
    EngagementId?: string | undefined;
    EngagementTitle?: string | undefined;
    Status?: InvitationStatus | undefined;
    InvitationDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    SenderAwsAccountId?: string | redacted.Redacted<string> | undefined;
    SenderCompanyName?: string | undefined;
    Receiver?: Receiver | undefined;
    Catalog: string;
    ParticipantType?: ParticipantType | undefined;
}
export type EngagementInvitationSummaries = EngagementInvitationSummary[];
export interface ListEngagementInvitationsResponse {
    EngagementInvitationSummaries?: EngagementInvitationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MemberPageSize = number;
export interface ListEngagementMembersRequest {
    Catalog: string;
    Identifier: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface EngagementMember {
    CompanyName?: string | redacted.Redacted<string> | undefined;
    WebsiteUrl?: string | undefined;
    AccountId?: string | redacted.Redacted<string> | undefined;
}
export type EngagementMembers = EngagementMember[];
export interface ListEngagementMembersResponse {
    EngagementMemberList: EngagementMember[];
    NextToken?: string | undefined;
}
export interface ListEngagementResourceAssociationsRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    EngagementIdentifier?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceIdentifier?: string | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
}
export interface EngagementResourceAssociationSummary {
    Catalog: string;
    EngagementId?: string | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceId?: string | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
}
export type EngagementResourceAssociationSummaryList = EngagementResourceAssociationSummary[];
export interface ListEngagementResourceAssociationsResponse {
    EngagementResourceAssociationSummaries: EngagementResourceAssociationSummary[];
    NextToken?: string | undefined;
}
export type AwsAccountList = (string | redacted.Redacted<string>)[];
export type EngagementContextTypeList = EngagementContextType[];
export type EngagementSortName = "CreatedDate" | (string & {});
export interface EngagementSort {
    SortOrder: SortOrder;
    SortBy: EngagementSortName;
}
export type EngagementPageSize = number;
export interface ListEngagementsRequest {
    Catalog: string;
    CreatedBy?: (string | redacted.Redacted<string>)[] | undefined;
    ExcludeCreatedBy?: (string | redacted.Redacted<string>)[] | undefined;
    ContextTypes?: EngagementContextType[] | undefined;
    ExcludeContextTypes?: EngagementContextType[] | undefined;
    Sort?: EngagementSort | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    EngagementIdentifier?: string[] | undefined;
}
export interface EngagementSummary {
    Arn?: string | undefined;
    Id?: string | undefined;
    Title?: string | undefined;
    CreatedAt?: Date | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
    MemberCount?: number | undefined;
    ModifiedAt?: Date | undefined;
    ModifiedBy?: string | redacted.Redacted<string> | undefined;
    ContextTypes?: EngagementContextType[] | undefined;
}
export type EngagementSummaryList = EngagementSummary[];
export interface ListEngagementsResponse {
    EngagementSummaryList: EngagementSummary[];
    NextToken?: string | undefined;
}
export type OpportunitySortName = "LastModifiedDate" | "Identifier" | "CustomerCompanyName" | "CreatedDate" | "TargetCloseDate" | (string & {});
export interface OpportunitySort {
    SortOrder: SortOrder;
    SortBy: OpportunitySortName;
}
export interface LastModifiedDate {
    AfterLastModifiedDate?: Date | undefined;
    BeforeLastModifiedDate?: Date | undefined;
}
export type FilterIdentifier = string[];
export type FilterLifeCycleStage = Stage[];
export type FilterLifeCycleReviewStatus = ReviewStatus[];
export interface CreatedDateFilter {
    AfterCreatedDate?: Date | undefined;
    BeforeCreatedDate?: Date | undefined;
}
export interface TargetCloseDateFilter {
    AfterTargetCloseDate?: string | undefined;
    BeforeTargetCloseDate?: string | undefined;
}
export interface ListOpportunitiesRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: OpportunitySort | undefined;
    LastModifiedDate?: LastModifiedDate | undefined;
    Identifier?: string[] | undefined;
    LifeCycleStage?: Stage[] | undefined;
    LifeCycleReviewStatus?: ReviewStatus[] | undefined;
    CustomerCompanyName?: string[] | undefined;
    CreatedDate?: CreatedDateFilter | undefined;
    TargetCloseDate?: TargetCloseDateFilter | undefined;
}
export interface LifeCycleSummary {
    Stage?: Stage | undefined;
    ClosedLostReason?: ClosedLostReason | undefined;
    NextSteps?: string | redacted.Redacted<string> | undefined;
    TargetCloseDate?: string | undefined;
    ReviewStatus?: ReviewStatus | undefined;
    ReviewComments?: string | undefined;
    ReviewStatusReason?: string | undefined;
}
export interface AddressSummary {
    City?: string | redacted.Redacted<string> | undefined;
    PostalCode?: string | redacted.Redacted<string> | undefined;
    StateOrRegion?: string | redacted.Redacted<string> | undefined;
    CountryCode?: CountryCode | undefined;
}
export interface AccountSummary {
    Industry?: Industry | undefined;
    OtherIndustry?: string | undefined;
    CompanyName: string | redacted.Redacted<string>;
    WebsiteUrl?: string | redacted.Redacted<string> | undefined;
    Address?: AddressSummary | undefined;
}
export interface CustomerSummary {
    Account?: AccountSummary | undefined;
}
export interface ProjectSummary {
    DeliveryModels?: DeliveryModel[] | undefined;
    ExpectedCustomerSpend?: ExpectedCustomerSpend[] | undefined;
    ExpectedContractDuration?: ExpectedContractDuration | undefined;
}
export interface OpportunitySummary {
    Catalog: string;
    Id?: string | undefined;
    Arn?: string | undefined;
    PartnerOpportunityIdentifier?: string | undefined;
    OpportunityType?: OpportunityType | undefined;
    LastModifiedDate?: Date | undefined;
    CreatedDate?: Date | undefined;
    LifeCycle?: LifeCycleSummary | undefined;
    Customer?: CustomerSummary | undefined;
    Project?: ProjectSummary | undefined;
}
export type OpportunitySummaries = OpportunitySummary[];
export interface ListOpportunitiesResponse {
    OpportunitySummaries: OpportunitySummary[];
    NextToken?: string | undefined;
}
export type ContextIdentifier = string;
export type ContextIdentifiers = string[];
export interface ListOpportunityFromEngagementTasksRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: ListTasksSortBase | undefined;
    Catalog: string;
    TaskStatus?: TaskStatus[] | undefined;
    TaskIdentifier?: string[] | undefined;
    OpportunityIdentifier?: string[] | undefined;
    EngagementIdentifier?: string[] | undefined;
    ContextIdentifier?: string[] | undefined;
}
export interface ListOpportunityFromEngagementTaskSummary {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    StartTime?: Date | undefined;
    TaskStatus?: TaskStatus | undefined;
    Message?: string | undefined;
    ReasonCode?: ReasonCode | undefined;
    OpportunityId?: string | undefined;
    ResourceSnapshotJobId?: string | undefined;
    EngagementId?: string | undefined;
    ContextId?: string | undefined;
}
export type ListOpportunityFromEngagementTaskSummaries = ListOpportunityFromEngagementTaskSummary[];
export interface ListOpportunityFromEngagementTasksResponse {
    TaskSummaries?: ListOpportunityFromEngagementTaskSummary[] | undefined;
    NextToken?: string | undefined;
}
export type TaskIdentifierList = string[];
export type TaskNameList = string[];
export type ProspectingFromEngagementTaskSortName = "StartTime" | "TaskName" | "FailedEngagementCount" | (string & {});
export interface ProspectingFromEngagementTaskSort {
    SortOrder: SortOrder;
    SortBy: ProspectingFromEngagementTaskSortName;
}
export interface ListProspectingFromEngagementTasksRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    TaskIdentifier?: string[] | undefined;
    TaskName?: string[] | undefined;
    StartAfter?: Date | undefined;
    StartBefore?: Date | undefined;
    Sort?: ProspectingFromEngagementTaskSort | undefined;
}
export interface ProspectingTaskSummary {
    TaskId: string;
    TaskArn: string;
    TaskName: string;
    StartTime: Date;
    EndTime?: Date | undefined;
    TotalEngagementCount: number;
    CompletedEngagementCount: number;
    FailedEngagementCount: number;
}
export type ProspectingTaskSummaryList = ProspectingTaskSummary[];
export interface ListProspectingFromEngagementTasksResponse {
    NextToken?: string | undefined;
    TaskSummaries: ProspectingTaskSummary[];
}
export type SortBy = "CreatedDate" | (string & {});
export interface SortObject {
    SortBy?: SortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export interface ListResourceSnapshotJobsRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    EngagementIdentifier?: string | undefined;
    Status?: ResourceSnapshotJobStatus | undefined;
    Sort?: SortObject | undefined;
}
export interface ResourceSnapshotJobSummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    EngagementId?: string | undefined;
    Status?: ResourceSnapshotJobStatus | undefined;
}
export type ResourceSnapshotJobSummaryList = ResourceSnapshotJobSummary[];
export interface ListResourceSnapshotJobsResponse {
    ResourceSnapshotJobSummaries: ResourceSnapshotJobSummary[];
    NextToken?: string | undefined;
}
export interface ListResourceSnapshotsRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    EngagementIdentifier: string;
    ResourceType?: ResourceType | undefined;
    ResourceIdentifier?: string | undefined;
    ResourceSnapshotTemplateIdentifier?: string | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
}
export type ResourceSnapshotArn = string;
export interface ResourceSnapshotSummary {
    Arn?: string | undefined;
    Revision?: number | undefined;
    ResourceType?: ResourceType | undefined;
    ResourceId?: string | undefined;
    ResourceSnapshotTemplateName?: string | undefined;
    CreatedBy?: string | redacted.Redacted<string> | undefined;
}
export type ResourceSnapshotSummaryList = ResourceSnapshotSummary[];
export interface ListResourceSnapshotsResponse {
    ResourceSnapshotSummaries: ResourceSnapshotSummary[];
    NextToken?: string | undefined;
}
export type SolutionSortName = "Identifier" | "Name" | "Status" | "Category" | "CreatedDate" | (string & {});
export interface SolutionSort {
    SortOrder: SortOrder;
    SortBy: SolutionSortName;
}
export type SolutionStatus = "Active" | "Inactive" | "Draft" | (string & {});
export type FilterStatus = SolutionStatus[];
export type AwsMarketplaceSolutionArn = string;
export type AwsMarketplaceSolutionArnList = string[];
export interface ListSolutionsRequest {
    Catalog: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Sort?: SolutionSort | undefined;
    Status?: SolutionStatus[] | undefined;
    Identifier?: string[] | undefined;
    Category?: string[] | undefined;
    AwsMarketplaceSolutionArn?: string[] | undefined;
}
export type SolutionArn = string;
export interface SolutionBase {
    Catalog: string;
    Id: string;
    Arn?: string | undefined;
    Name: string;
    Status: SolutionStatus;
    Category: string;
    CreatedDate: Date;
    AwsMarketplaceSolutionArn?: string | undefined;
}
export type SolutionList = SolutionBase[];
export interface ListSolutionsResponse {
    SolutionSummaries: SolutionBase[];
    NextToken?: string | undefined;
}
export type TaggableResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags: Tag[];
}
export type ResourceSnapshotJobRoleIdentifier = string;
export interface PutSellingSystemSettingsRequest {
    Catalog: string;
    ResourceSnapshotJobRoleIdentifier?: string | undefined;
}
export interface PutSellingSystemSettingsResponse {
    Catalog: string;
    ResourceSnapshotJobRoleArn?: string | undefined;
}
export interface RejectEngagementInvitationRequest {
    Catalog: string;
    Identifier: string;
    RejectionReason?: string | undefined;
}
export interface RejectEngagementInvitationResponse {
}
export interface StartEngagementByAcceptingInvitationTaskRequest {
    Catalog: string;
    ClientToken: string;
    Identifier: string;
    Tags?: Tag[] | undefined;
}
export interface StartEngagementByAcceptingInvitationTaskResponse {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    StartTime?: Date | undefined;
    TaskStatus?: TaskStatus | undefined;
    Message?: string | undefined;
    ReasonCode?: ReasonCode | undefined;
    OpportunityId?: string | undefined;
    ResourceSnapshotJobId?: string | undefined;
    EngagementInvitationId?: string | undefined;
}
export interface AwsSubmission {
    InvolvementType: SalesInvolvementType;
    Visibility?: Visibility | undefined;
}
export interface StartEngagementFromOpportunityTaskRequest {
    Catalog: string;
    ClientToken: string;
    Identifier: string;
    AwsSubmission: AwsSubmission;
    Tags?: Tag[] | undefined;
}
export interface StartEngagementFromOpportunityTaskResponse {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    StartTime?: Date | undefined;
    TaskStatus?: TaskStatus | undefined;
    Message?: string | undefined;
    ReasonCode?: ReasonCode | undefined;
    OpportunityId?: string | undefined;
    ResourceSnapshotJobId?: string | undefined;
    EngagementId?: string | undefined;
    EngagementInvitationId?: string | undefined;
}
export interface StartOpportunityFromEngagementTaskRequest {
    Catalog: string;
    ClientToken: string;
    Identifier: string;
    ContextIdentifier: string;
    Tags?: Tag[] | undefined;
}
export interface StartOpportunityFromEngagementTaskResponse {
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    StartTime?: Date | undefined;
    TaskStatus?: TaskStatus | undefined;
    Message?: string | undefined;
    ReasonCode?: ReasonCode | undefined;
    OpportunityId?: string | undefined;
    ResourceSnapshotJobId?: string | undefined;
    EngagementId?: string | undefined;
    ContextId?: string | undefined;
}
export type EngagementIdentifierList = string[];
export interface StartProspectingFromEngagementTaskRequest {
    Catalog: string;
    Identifiers: string[];
    TaskName: string;
    ClientToken: string;
}
export interface StartProspectingFromEngagementTaskResponse {
    Identifiers: string[];
    TaskName: string;
    Message?: string | undefined;
    ReasonCode?: string | undefined;
    StartTime: Date;
    TaskId?: string | undefined;
    TaskArn?: string | undefined;
    TaskStatus: ProspectingTaskStatus;
}
export interface StartResourceSnapshotJobRequest {
    Catalog: string;
    ResourceSnapshotJobIdentifier: string;
}
export interface StartResourceSnapshotJobResponse {
}
export interface StopResourceSnapshotJobRequest {
    Catalog: string;
    ResourceSnapshotJobIdentifier: string;
}
export interface StopResourceSnapshotJobResponse {
}
export interface SubmitOpportunityRequest {
    Catalog: string;
    Identifier: string;
    InvolvementType: SalesInvolvementType;
    Visibility?: Visibility | undefined;
}
export interface SubmitOpportunityResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateLeadContext {
    QualificationStatus?: string | undefined;
    Customer: LeadCustomer;
    Interaction?: LeadInteraction | undefined;
    Insights?: LeadInsights | undefined;
}
export type UpdateEngagementContextPayload = {
    Lead: UpdateLeadContext;
    CustomerProject?: undefined;
    ProspectingResult?: undefined;
} | {
    Lead?: undefined;
    CustomerProject: CustomerProjectsContext;
    ProspectingResult?: undefined;
} | {
    Lead?: undefined;
    CustomerProject?: undefined;
    ProspectingResult: ProspectingResult;
};
export interface UpdateEngagementContextRequest {
    Catalog: string;
    EngagementIdentifier: string;
    ContextIdentifier: string;
    EngagementLastModifiedAt: Date;
    Type: EngagementContextType;
    Payload: UpdateEngagementContextPayload;
}
export interface UpdateEngagementContextResponse {
    EngagementId: string;
    EngagementArn: string;
    EngagementLastModifiedAt: Date;
    ContextId: string;
}
export interface UpdateOpportunityRequest {
    Catalog: string;
    PrimaryNeedsFromAws?: PrimaryNeedFromAws[] | undefined;
    NationalSecurity?: NationalSecurity | undefined;
    PartnerOpportunityIdentifier?: string | undefined;
    Customer?: Customer | undefined;
    Project?: Project | undefined;
    OpportunityType?: OpportunityType | undefined;
    Marketing?: Marketing | undefined;
    SoftwareRevenue?: SoftwareRevenue | undefined;
    LastModifiedDate: Date;
    Identifier: string;
    LifeCycle?: LifeCycle | undefined;
}
export interface UpdateOpportunityResponse {
    Id: string;
    LastModifiedDate: Date;
}
export type AccessDeniedExceptionErrorCode = "INCOMPATIBLE_BENEFIT_AWS_PARTNER_STATE" | (string & {});
export type ValidationExceptionReason = "REQUEST_VALIDATION_FAILED" | "BUSINESS_VALIDATION_FAILED" | (string & {});
export type ValidationExceptionErrorCode = "REQUIRED_FIELD_MISSING" | "INVALID_ENUM_VALUE" | "INVALID_STRING_FORMAT" | "INVALID_VALUE" | "NOT_ENOUGH_VALUES" | "TOO_MANY_VALUES" | "INVALID_RESOURCE_STATE" | "DUPLICATE_KEY_VALUE" | "VALUE_OUT_OF_RANGE" | "ACTION_NOT_PERMITTED" | (string & {});
export interface ValidationExceptionError {
    FieldName?: string | undefined;
    Message: string;
    Code: ValidationExceptionErrorCode;
}
export type ValidationExceptionErrorList = ValidationExceptionError[];
export type AcceptEngagementInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use the `AcceptEngagementInvitation` action to accept an engagement invitation shared by AWS. Accepting the invitation indicates your willingness to participate in the engagement, granting you access to all engagement-related data.
 */
export declare const acceptEngagementInvitation: API.OperationMethod<AcceptEngagementInvitationRequest & RegionInput, AcceptEngagementInvitationResponse, AcceptEngagementInvitationError, Credentials | HttpClient.HttpClient>;
export type AssignOpportunityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables you to reassign an existing `Opportunity` to another user within your Partner Central account. The specified user receives the opportunity, and it appears on their Partner Central dashboard, allowing them to take necessary actions or proceed with the opportunity.
 *
 * This is useful for distributing opportunities to the appropriate team members or departments within your organization, ensuring that each opportunity is handled by the right person. By default, the opportunity owner is the one who creates it. Currently, there's no API to enumerate the list of available users.
 */
export declare const assignOpportunity: API.OperationMethod<AssignOpportunityRequest & RegionInput, AssignOpportunityResponse, AssignOpportunityError, Credentials | HttpClient.HttpClient>;
export type AssociateOpportunityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables you to create a formal association between an `Opportunity` and various related entities, enriching the context and details of the opportunity for better collaboration and decision making. You can associate an opportunity with the following entity types:
 *
 * - Partner Solution: A software product or consulting practice created and delivered by Partners. Partner Solutions help customers address business challenges using Amazon Web Services services.
 *
 * - Amazon Web Services Products: Amazon Web Services offers many products and services that provide scalable, reliable, and cost-effective infrastructure solutions. For the latest list of Amazon Web Services products, see Amazon Web Services products.
 *
 * - Amazon Web Services Marketplace private offer: Allows Amazon Web Services Marketplace sellers to extend custom pricing and terms to individual Amazon Web Services customers. Sellers can negotiate custom prices, payment schedules, and end user license terms through private offers, enabling Amazon Web Services customers to acquire software solutions tailored to their specific needs. For more information, see Private offers in Amazon Web Services Marketplace.
 *
 * To obtain identifiers for these entities, use the following methods:
 *
 * - Solution: Use the `ListSolutions` operation.
 *
 * - AWS Products: For the latest list of Amazon Web Services products, see Amazon Web Services products.
 *
 * - Amazon Web Services Marketplace private offer: Use the Using the Amazon Web Services Marketplace Catalog API to list entities. Specifically, use the `ListEntities` operation to retrieve a list of private offers. The request returns the details of available private offers. For more information, see ListEntities.
 */
export declare const associateOpportunity: API.OperationMethod<AssociateOpportunityRequest & RegionInput, AssociateOpportunityResponse, AssociateOpportunityError, Credentials | HttpClient.HttpClient>;
export type CreateEngagementError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `CreateEngagement` action allows you to create an `Engagement`, which serves as a collaborative space between different parties such as AWS Partners and AWS Sellers. This action automatically adds the caller's AWS account as an active member of the newly created `Engagement`.
 */
export declare const createEngagement: API.OperationMethod<CreateEngagementRequest & RegionInput, CreateEngagementResponse, CreateEngagementError, Credentials | HttpClient.HttpClient>;
export type CreateEngagementContextError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new context within an existing engagement. This action allows you to add contextual information such as customer projects or documents to an engagement, providing additional details that help facilitate collaboration between engagement members.
 */
export declare const createEngagementContext: API.OperationMethod<CreateEngagementContextRequest & RegionInput, CreateEngagementContextResponse, CreateEngagementContextError, Credentials | HttpClient.HttpClient>;
export type CreateEngagementInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action creates an invitation from a sender to a single receiver to join an engagement.
 */
export declare const createEngagementInvitation: API.OperationMethod<CreateEngagementInvitationRequest & RegionInput, CreateEngagementInvitationResponse, CreateEngagementInvitationError, Credentials | HttpClient.HttpClient>;
export type CreateOpportunityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an `Opportunity` record in Partner Central. Use this operation to create a potential business opportunity for submission to Amazon Web Services. Creating an opportunity sets `Lifecycle.ReviewStatus` to `Pending Submission`.
 *
 * To submit an opportunity, follow these steps:
 *
 * - To create the opportunity, use `CreateOpportunity`.
 *
 * - To associate a solution with the opportunity, use `AssociateOpportunity`.
 *
 * - To start the engagement with AWS, use `StartEngagementFromOpportunity`.
 *
 * After submission, you can't edit the opportunity until the review is complete. But opportunities in the `Pending Submission` state must have complete details. You can update the opportunity while it's in the `Pending Submission` state.
 *
 * There's a set of mandatory fields to create opportunities, but consider providing optional fields to enrich the opportunity record.
 */
export declare const createOpportunity: API.OperationMethod<CreateOpportunityRequest & RegionInput, CreateOpportunityResponse, CreateOpportunityError, Credentials | HttpClient.HttpClient>;
export type CreateResourceSnapshotError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action allows you to create an immutable snapshot of a specific resource, such as an opportunity, within the context of an engagement. The snapshot captures a subset of the resource's data based on the schema defined by the provided template.
 */
export declare const createResourceSnapshot: API.OperationMethod<CreateResourceSnapshotRequest & RegionInput, CreateResourceSnapshotResponse, CreateResourceSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateResourceSnapshotJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this action to create a job to generate a snapshot of the specified resource within an engagement. It initiates an asynchronous process to create a resource snapshot. The job creates a new snapshot only if the resource state has changed, adhering to the same access control and immutability rules as direct snapshot creation.
 */
export declare const createResourceSnapshotJob: API.OperationMethod<CreateResourceSnapshotJobRequest & RegionInput, CreateResourceSnapshotJobResponse, CreateResourceSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceSnapshotJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this action to deletes a previously created resource snapshot job. The job must be in a stopped state before it can be deleted.
 */
export declare const deleteResourceSnapshotJob: API.OperationMethod<DeleteResourceSnapshotJobRequest & RegionInput, DeleteResourceSnapshotJobResponse, DeleteResourceSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type DisassociateOpportunityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows you to remove an existing association between an `Opportunity` and related entities, such as a Partner Solution, Amazon Web Services product, or an Amazon Web Services Marketplace offer. This operation is the counterpart to `AssociateOpportunity`, and it provides flexibility to manage associations as business needs change.
 *
 * Use this operation to update the associations of an `Opportunity` due to changes in the related entities, or if an association was made in error. Ensuring accurate associations helps maintain clarity and accuracy to track and manage business opportunities. When you replace an entity, first attach the new entity and then disassociate the one to be removed, especially if it's the last remaining entity that's required.
 */
export declare const disassociateOpportunity: API.OperationMethod<DisassociateOpportunityRequest & RegionInput, DisassociateOpportunityResponse, DisassociateOpportunityError, Credentials | HttpClient.HttpClient>;
export type GetAwsOpportunitySummaryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a summary of an AWS Opportunity. This summary includes high-level details about the opportunity sourced from AWS, such as lifecycle information, customer details, and involvement type. It is useful for tracking updates on the AWS opportunity corresponding to an opportunity in the partner's account.
 */
export declare const getAwsOpportunitySummary: API.OperationMethod<GetAwsOpportunitySummaryRequest & RegionInput, GetAwsOpportunitySummaryResponse, GetAwsOpportunitySummaryError, Credentials | HttpClient.HttpClient>;
export type GetEngagementError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this action to retrieve the engagement record for a given `EngagementIdentifier`.
 */
export declare const getEngagement: API.OperationMethod<GetEngagementRequest & RegionInput, GetEngagementResponse, GetEngagementError, Credentials | HttpClient.HttpClient>;
export type GetEngagementInvitationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of an engagement invitation shared by AWS with a partner. The information includes aspects such as customer, project details, and lifecycle information. To connect an engagement invitation with an opportunity, match the invitation's `Payload.Project.Title` with opportunity `Project.Title`.
 */
export declare const getEngagementInvitation: API.OperationMethod<GetEngagementInvitationRequest & RegionInput, GetEngagementInvitationResponse, GetEngagementInvitationError, Credentials | HttpClient.HttpClient>;
export type GetOpportunityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Fetches the `Opportunity` record from Partner Central by a given `Identifier`.
 *
 * Use the `ListOpportunities` action or the event notification (from Amazon EventBridge) to obtain this identifier.
 */
export declare const getOpportunity: API.OperationMethod<GetOpportunityRequest & RegionInput, GetOpportunityResponse, GetOpportunityError, Credentials | HttpClient.HttpClient>;
export type GetProspectingFromEngagementTaskError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details and current status of a prospecting task previously started with `StartProspectingFromEngagementTask` to enable polling for completion and access to per-engagement processing results.
 */
export declare const getProspectingFromEngagementTask: API.OperationMethod<GetProspectingFromEngagementTaskRequest & RegionInput, GetProspectingFromEngagementTaskResponse, GetProspectingFromEngagementTaskError, Credentials | HttpClient.HttpClient>;
export type GetResourceSnapshotError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this action to retrieve a specific snapshot record.
 */
export declare const getResourceSnapshot: API.OperationMethod<GetResourceSnapshotRequest & RegionInput, GetResourceSnapshotResponse, GetResourceSnapshotError, Credentials | HttpClient.HttpClient>;
export type GetResourceSnapshotJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this action to retrieves information about a specific resource snapshot job.
 */
export declare const getResourceSnapshotJob: API.OperationMethod<GetResourceSnapshotJobRequest & RegionInput, GetResourceSnapshotJobResponse, GetResourceSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type GetSellingSystemSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the currently set system settings, which include the IAM Role used for resource snapshot jobs.
 */
export declare const getSellingSystemSettings: API.OperationMethod<GetSellingSystemSettingsRequest & RegionInput, GetSellingSystemSettingsResponse, GetSellingSystemSettingsError, Credentials | HttpClient.HttpClient>;
export type ListEngagementByAcceptingInvitationTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all in-progress, completed, or failed StartEngagementByAcceptingInvitationTask tasks that were initiated by the caller's account.
 */
export declare const listEngagementByAcceptingInvitationTasks: API.PaginatedOperationMethod<ListEngagementByAcceptingInvitationTasksRequest & RegionInput, ListEngagementByAcceptingInvitationTasksResponse, ListEngagementByAcceptingInvitationTasksError, Credentials | HttpClient.HttpClient, ListEngagementByAcceptingInvitationTaskSummary>;
export type ListEngagementFromOpportunityTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all in-progress, completed, or failed `EngagementFromOpportunity` tasks that were initiated by the caller's account.
 */
export declare const listEngagementFromOpportunityTasks: API.PaginatedOperationMethod<ListEngagementFromOpportunityTasksRequest & RegionInput, ListEngagementFromOpportunityTasksResponse, ListEngagementFromOpportunityTasksError, Credentials | HttpClient.HttpClient, ListEngagementFromOpportunityTaskSummary>;
export type ListEngagementInvitationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of engagement invitations sent to the partner. This allows partners to view all pending or past engagement invitations, helping them track opportunities shared by AWS.
 */
export declare const listEngagementInvitations: API.PaginatedOperationMethod<ListEngagementInvitationsRequest & RegionInput, ListEngagementInvitationsResponse, ListEngagementInvitationsError, Credentials | HttpClient.HttpClient, EngagementInvitationSummary>;
export type ListEngagementMembersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of member partners in an Engagement. This operation can only be invoked by members of the Engagement. The `ListEngagementMembers` operation allows you to fetch information about the members of a specific Engagement. This action is restricted to members of the Engagement being queried.
 */
export declare const listEngagementMembers: API.PaginatedOperationMethod<ListEngagementMembersRequest & RegionInput, ListEngagementMembersResponse, ListEngagementMembersError, Credentials | HttpClient.HttpClient, EngagementMember>;
export type ListEngagementResourceAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations between resources and engagements where the caller is a member and has at least one snapshot in the engagement.
 */
export declare const listEngagementResourceAssociations: API.PaginatedOperationMethod<ListEngagementResourceAssociationsRequest & RegionInput, ListEngagementResourceAssociationsResponse, ListEngagementResourceAssociationsError, Credentials | HttpClient.HttpClient, EngagementResourceAssociationSummary>;
export type ListEngagementsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action allows users to retrieve a list of Engagement records from Partner Central. This action can be used to manage and track various engagements across different stages of the partner selling process.
 */
export declare const listEngagements: API.PaginatedOperationMethod<ListEngagementsRequest & RegionInput, ListEngagementsResponse, ListEngagementsError, Credentials | HttpClient.HttpClient, EngagementSummary>;
export type ListOpportunitiesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This request accepts a list of filters that retrieve opportunity subsets as well as sort options. This feature is available to partners from Partner Central using the `ListOpportunities` API action.
 *
 * To synchronize your system with Amazon Web Services, list only the opportunities that were newly created or updated. We recommend you rely on events emitted by the service into your Amazon Web Services account's Amazon EventBridge default event bus. You can also use the `ListOpportunities` action.
 *
 * We recommend the following approach:
 *
 * - Find the latest `LastModifiedDate` that you stored, and only use the values that came from Amazon Web Services. Don't use values generated by your system.
 *
 * - When you send a `ListOpportunities` request, submit the date in ISO 8601 format in the `AfterLastModifiedDate` filter.
 *
 * - Amazon Web Services only returns opportunities created or updated on or after that date and time. Use `NextToken` to iterate over all pages.
 */
export declare const listOpportunities: API.PaginatedOperationMethod<ListOpportunitiesRequest & RegionInput, ListOpportunitiesResponse, ListOpportunitiesError, Credentials | HttpClient.HttpClient, OpportunitySummary>;
export type ListOpportunityFromEngagementTasksError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all in-progress, completed, or failed opportunity creation tasks from engagements that were initiated by the caller's account.
 */
export declare const listOpportunityFromEngagementTasks: API.PaginatedOperationMethod<ListOpportunityFromEngagementTasksRequest & RegionInput, ListOpportunityFromEngagementTasksResponse, ListOpportunityFromEngagementTasksError, Credentials | HttpClient.HttpClient, ListOpportunityFromEngagementTaskSummary>;
export type ListProspectingFromEngagementTasksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all prospecting tasks initiated by the caller's account. Supports optional filters by task identifier, task name, or start time range. Results can be sorted using configurable options. The response is paginated. Use the `NextToken` value from each response to retrieve subsequent pages.
 */
export declare const listProspectingFromEngagementTasks: API.PaginatedOperationMethod<ListProspectingFromEngagementTasksRequest & RegionInput, ListProspectingFromEngagementTasksResponse, ListProspectingFromEngagementTasksError, Credentials | HttpClient.HttpClient, ProspectingTaskSummary>;
export type ListResourceSnapshotJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists resource snapshot jobs owned by the customer. This operation supports various filtering scenarios, including listing all jobs owned by the caller, jobs for a specific engagement, jobs with a specific status, or any combination of these filters.
 */
export declare const listResourceSnapshotJobs: API.PaginatedOperationMethod<ListResourceSnapshotJobsRequest & RegionInput, ListResourceSnapshotJobsResponse, ListResourceSnapshotJobsError, Credentials | HttpClient.HttpClient, ResourceSnapshotJobSummary>;
export type ListResourceSnapshotsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of resource view snapshots based on specified criteria. This operation supports various use cases, including:
 *
 * - Fetching all snapshots associated with an engagement.
 *
 * - Retrieving snapshots of a specific resource type within an engagement.
 *
 * - Obtaining snapshots for a particular resource using a specified template.
 *
 * - Accessing the latest snapshot of a resource within an engagement.
 *
 * - Filtering snapshots by resource owner.
 */
export declare const listResourceSnapshots: API.PaginatedOperationMethod<ListResourceSnapshotsRequest & RegionInput, ListResourceSnapshotsResponse, ListResourceSnapshotsError, Credentials | HttpClient.HttpClient, ResourceSnapshotSummary>;
export type ListSolutionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of Partner Solutions that the partner registered on Partner Central. This API is used to generate a list of solutions that an end user selects from for association with an opportunity.
 */
export declare const listSolutions: API.PaginatedOperationMethod<ListSolutionsRequest & RegionInput, ListSolutionsResponse, ListSolutionsError, Credentials | HttpClient.HttpClient, SolutionBase>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutSellingSystemSettingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the currently set system settings, which include the IAM Role used for resource snapshot jobs.
 */
export declare const putSellingSystemSettings: API.OperationMethod<PutSellingSystemSettingsRequest & RegionInput, PutSellingSystemSettingsResponse, PutSellingSystemSettingsError, Credentials | HttpClient.HttpClient>;
export type RejectEngagementInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action rejects an `EngagementInvitation` that AWS shared. Rejecting an invitation indicates that the partner doesn't want to pursue the opportunity, and all related data will become inaccessible thereafter.
 */
export declare const rejectEngagementInvitation: API.OperationMethod<RejectEngagementInvitationRequest & RegionInput, RejectEngagementInvitationResponse, RejectEngagementInvitationError, Credentials | HttpClient.HttpClient>;
export type StartEngagementByAcceptingInvitationTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action starts the engagement by accepting an `EngagementInvitation`. The task is asynchronous and involves the following steps: accepting the invitation, creating an opportunity in the partner's account from the AWS opportunity, and copying details for tracking. When completed, an `Opportunity Created` event is generated, indicating that the opportunity has been successfully created in the partner's account.
 */
export declare const startEngagementByAcceptingInvitationTask: API.OperationMethod<StartEngagementByAcceptingInvitationTaskRequest & RegionInput, StartEngagementByAcceptingInvitationTaskResponse, StartEngagementByAcceptingInvitationTaskError, Credentials | HttpClient.HttpClient>;
export type StartEngagementFromOpportunityTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Similar to `StartEngagementByAcceptingInvitationTask`, this action is asynchronous and performs multiple steps before completion. This action orchestrates a comprehensive workflow that combines multiple API operations into a single task to create and initiate an engagement from an existing opportunity. It automatically executes a sequence of operations including `GetOpportunity`, `CreateEngagement` (if it doesn't exist), `CreateResourceSnapshot`, `CreateResourceSnapshotJob`, `CreateEngagementInvitation` (if not already invited/accepted), and `SubmitOpportunity`.
 */
export declare const startEngagementFromOpportunityTask: API.OperationMethod<StartEngagementFromOpportunityTaskRequest & RegionInput, StartEngagementFromOpportunityTaskResponse, StartEngagementFromOpportunityTaskError, Credentials | HttpClient.HttpClient>;
export type StartOpportunityFromEngagementTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This action creates an opportunity from an existing engagement context. The task is asynchronous and orchestrates the process of converting engagement contextual information into a structured opportunity record within the partner's account.
 */
export declare const startOpportunityFromEngagementTask: API.OperationMethod<StartOpportunityFromEngagementTaskRequest & RegionInput, StartOpportunityFromEngagementTaskResponse, StartOpportunityFromEngagementTaskError, Credentials | HttpClient.HttpClient>;
export type StartProspectingFromEngagementTaskError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a task to convert one or more engagement contexts into new prospecting leads. The task runs asynchronously. To poll for status, use `GetProspectingFromEngagementTask`, or use `ListProspectingFromEngagementTasks` to monitor multiple tasks.
 */
export declare const startProspectingFromEngagementTask: API.OperationMethod<StartProspectingFromEngagementTaskRequest & RegionInput, StartProspectingFromEngagementTaskResponse, StartProspectingFromEngagementTaskError, Credentials | HttpClient.HttpClient>;
export type StartResourceSnapshotJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a resource snapshot job that has been previously created.
 */
export declare const startResourceSnapshotJob: API.OperationMethod<StartResourceSnapshotJobRequest & RegionInput, StartResourceSnapshotJobResponse, StartResourceSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type StopResourceSnapshotJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a resource snapshot job. The job must be started prior to being stopped.
 */
export declare const stopResourceSnapshotJob: API.OperationMethod<StopResourceSnapshotJobRequest & RegionInput, StopResourceSnapshotJobResponse, StopResourceSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type SubmitOpportunityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this action to submit an Opportunity that was previously created by partner for AWS review. After you perform this action, the Opportunity becomes non-editable until it is reviewed by AWS and has ` LifeCycle.ReviewStatus ` as either `Approved` or `Action Required`.
 */
export declare const submitOpportunity: API.OperationMethod<SubmitOpportunityRequest & RegionInput, SubmitOpportunityResponse, SubmitOpportunityError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEngagementContextError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the context information for an existing engagement with new or modified data.
 */
export declare const updateEngagementContext: API.OperationMethod<UpdateEngagementContextRequest & RegionInput, UpdateEngagementContextResponse, UpdateEngagementContextError, Credentials | HttpClient.HttpClient>;
export type UpdateOpportunityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the `Opportunity` record identified by a given `Identifier`. This operation allows you to modify the details of an existing opportunity to reflect the latest information and progress. Use this action to keep the opportunity record up-to-date and accurate.
 *
 * When you perform updates, include the entire payload with each request. If any field is omitted, the API assumes that the field is set to `null`. The best practice is to always perform a `GetOpportunity` to retrieve the latest values, then send the complete payload with the updated values to be changed.
 */
export declare const updateOpportunity: API.OperationMethod<UpdateOpportunityRequest & RegionInput, UpdateOpportunityResponse, UpdateOpportunityError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=partnercentral-selling.d.ts.map