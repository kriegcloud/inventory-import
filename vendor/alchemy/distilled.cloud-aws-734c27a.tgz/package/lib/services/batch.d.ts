import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ClientException_base: S.TaggedErrorClass<"ClientException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ClientException extends /*@__PURE__*/ ClientException_base {
}
declare const ComputeEnvironmentBeingModified_base: S.TaggedErrorClass<"ComputeEnvironmentBeingModified", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentBeingModified extends /*@__PURE__*/ ComputeEnvironmentBeingModified_base {
}
declare const ComputeEnvironmentInUse_base: S.TaggedErrorClass<"ComputeEnvironmentInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentInUse extends /*@__PURE__*/ ComputeEnvironmentInUse_base {
}
declare const ComputeEnvironmentNotFound_base: S.TaggedErrorClass<"ComputeEnvironmentNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ComputeEnvironmentNotFound extends /*@__PURE__*/ ComputeEnvironmentNotFound_base {
}
declare const ComputeEnvironmentNotValid_base: S.TaggedErrorClass<"ComputeEnvironmentNotValid", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ComputeEnvironmentNotValid extends /*@__PURE__*/ ComputeEnvironmentNotValid_base {
}
declare const JobQueueAlreadyExists_base: S.TaggedErrorClass<"JobQueueAlreadyExists", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class JobQueueAlreadyExists extends /*@__PURE__*/ JobQueueAlreadyExists_base {
}
declare const JobQueueBeingModified_base: S.TaggedErrorClass<"JobQueueBeingModified", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class JobQueueBeingModified extends /*@__PURE__*/ JobQueueBeingModified_base {
}
declare const JobQueueNotFound_base: S.TaggedErrorClass<"JobQueueNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class JobQueueNotFound extends /*@__PURE__*/ JobQueueNotFound_base {
}
declare const ServerException_base: S.TaggedErrorClass<"ServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServerException extends /*@__PURE__*/ ServerException_base {
}
export interface CancelJobRequest {
    jobId?: string | undefined;
    reason?: string | undefined;
}
export interface CancelJobResponse {
}
export type StringList = string[];
export interface CancelJobsRequest {
    jobs?: string[] | undefined;
    reason?: string | undefined;
}
export interface CancelJobsErrorDetail {
    job?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type CancelJobsErrorDetailList = CancelJobsErrorDetail[];
export interface CancelJobsResponse {
    successful: string[];
    errors: (CancelJobsErrorDetail & {
        job: string;
        code: string;
        message: string;
    })[];
}
export type CEType = "MANAGED" | "UNMANAGED" | (string & {});
export type CEState = "ENABLED" | "DISABLED" | (string & {});
export type CRType = "EC2" | "SPOT" | "FARGATE" | "FARGATE_SPOT" | "ECS_MANAGED_INSTANCES" | (string & {});
export type CRAllocationStrategy = "BEST_FIT" | "BEST_FIT_PROGRESSIVE" | "BEST_FIT_PROGRESSIVE_ORDERED" | "SPOT_CAPACITY_OPTIMIZED" | "SPOT_PRICE_CAPACITY_OPTIMIZED" | "SPOT_CAPACITY_OPTIMIZED_PRIORITIZED" | (string & {});
export type TagsMap = {
    [key: string]: string | undefined;
};
export type UserdataType = "EKS_BOOTSTRAP_SH" | "EKS_NODEADM" | (string & {});
export interface LaunchTemplateSpecificationOverride {
    launchTemplateId?: string | undefined;
    launchTemplateName?: string | undefined;
    version?: string | undefined;
    targetInstanceTypes?: string[] | undefined;
    userdataType?: UserdataType | undefined;
}
export type LaunchTemplateSpecificationOverrideList = LaunchTemplateSpecificationOverride[];
export interface LaunchTemplateSpecification {
    launchTemplateId?: string | undefined;
    launchTemplateName?: string | undefined;
    version?: string | undefined;
    overrides?: LaunchTemplateSpecificationOverride[] | undefined;
    userdataType?: UserdataType | undefined;
}
export type ImageType = string;
export type ImageIdOverride = string;
export type KubernetesVersion = string;
export interface Ec2Configuration {
    imageType?: string | undefined;
    imageIdOverride?: string | undefined;
    batchImageStatus?: string | undefined;
    imageKubernetesVersion?: string | undefined;
}
export type Ec2ConfigurationList = Ec2Configuration[];
export interface ComputeScalingPolicy {
    minScaleDownDelayMinutes?: number | undefined;
}
export interface ManagedInstancesNetworkConfiguration {
    subnets?: string[] | undefined;
    securityGroups?: string[] | undefined;
}
export interface InstanceRequirementsRequest {
    allowedInstanceTypes?: string[] | undefined;
}
export interface ManagedInstancesStorageConfiguration {
    storageSizeGiB?: number | undefined;
}
export interface CapacityReservationRequest {
    reservationGroupArn?: string | undefined;
    reservationPreference?: string | undefined;
}
export interface ManagedInstancesLocalStorageConfiguration {
    useLocalStorage?: boolean | undefined;
}
export interface InstanceLaunchTemplate {
    ec2InstanceProfileArn?: string | undefined;
    networkConfiguration?: ManagedInstancesNetworkConfiguration | undefined;
    instanceRequirements?: InstanceRequirementsRequest | undefined;
    capacityOptionType?: string | undefined;
    storageConfiguration?: ManagedInstancesStorageConfiguration | undefined;
    monitoring?: string | undefined;
    fipsEnabled?: boolean | undefined;
    capacityReservations?: CapacityReservationRequest | undefined;
    instanceMetadataTagsPropagation?: boolean | undefined;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration | undefined;
}
export interface InfrastructureOptimization {
    scaleInAfter?: number | undefined;
}
export interface ManagedInstancesProvider {
    propagateTags?: string | undefined;
    infrastructureRoleArn?: string | undefined;
    instanceLaunchTemplate?: InstanceLaunchTemplate | undefined;
    infrastructureOptimization?: InfrastructureOptimization | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagrisTagsMap = {
    [key: string]: string | undefined;
};
export interface ComputeResource {
    type?: CRType | undefined;
    allocationStrategy?: CRAllocationStrategy | undefined;
    minvCpus?: number | undefined;
    maxvCpus?: number | undefined;
    desiredvCpus?: number | undefined;
    instanceTypes?: string[] | undefined;
    imageId?: string | undefined;
    subnets?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    ec2KeyPair?: string | undefined;
    instanceRole?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    placementGroup?: string | undefined;
    bidPercentage?: number | undefined;
    spotIamFleetRole?: string | undefined;
    launchTemplate?: LaunchTemplateSpecification | undefined;
    ec2Configuration?: Ec2Configuration[] | undefined;
    scalingPolicy?: ComputeScalingPolicy | undefined;
    managedInstancesProvider?: ManagedInstancesProvider | undefined;
    capacityTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EksAccessEntryDesiredState = "ENABLED" | "DISABLED" | "INHERIT_FROM_CLUSTER" | (string & {});
export type EksAccessEntryStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface EksAccessEntry {
    desiredState?: EksAccessEntryDesiredState | undefined;
    status?: EksAccessEntryStatus | undefined;
}
export interface EksConfiguration {
    eksClusterArn?: string | undefined;
    kubernetesNamespace?: string | undefined;
    accessEntry?: EksAccessEntry | undefined;
}
export type ContainerInsights = "ENABLED" | "ENHANCED" | "DISABLED" | (string & {});
export interface EcsSettings {
    containerInsights?: ContainerInsights | undefined;
}
export interface CreateComputeEnvironmentRequest {
    computeEnvironmentName?: string | undefined;
    type?: CEType | undefined;
    state?: CEState | undefined;
    unmanagedvCpus?: number | undefined;
    computeResources?: ComputeResource | undefined;
    serviceRole?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    eksConfiguration?: EksConfiguration | undefined;
    context?: string | undefined;
    ecsSettings?: EcsSettings | undefined;
}
export interface CreateComputeEnvironmentResponse {
    computeEnvironmentName?: string | undefined;
    computeEnvironmentArn?: string | undefined;
}
export interface CreateConsumableResourceRequest {
    consumableResourceName?: string | undefined;
    totalQuantity?: number | undefined;
    resourceType?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
}
export type JQState = "ENABLED" | "DISABLED" | (string & {});
export interface ComputeEnvironmentOrder {
    order?: number | undefined;
    computeEnvironment?: string | undefined;
}
export type ComputeEnvironmentOrders = ComputeEnvironmentOrder[];
export interface ServiceEnvironmentOrder {
    order?: number | undefined;
    serviceEnvironment?: string | undefined;
}
export type ServiceEnvironmentOrders = ServiceEnvironmentOrder[];
export type JobQueueType = "EKS" | "ECS" | "ECS_FARGATE" | "SAGEMAKER_TRAINING" | "ECS_MANAGED_INSTANCES" | (string & {});
export type JobStateTimeLimitActionsState = "RUNNABLE" | (string & {});
export type JobStateTimeLimitActionsAction = "CANCEL" | "TERMINATE" | (string & {});
export interface JobStateTimeLimitAction {
    reason?: string | undefined;
    state?: JobStateTimeLimitActionsState | undefined;
    maxTimeSeconds?: number | undefined;
    action?: JobStateTimeLimitActionsAction | undefined;
}
export type JobStateTimeLimitActions = JobStateTimeLimitAction[];
export interface CreateJobQueueRequest {
    jobQueueName?: string | undefined;
    state?: JQState | undefined;
    schedulingPolicyArn?: string | undefined;
    priority?: number | undefined;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[] | undefined;
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[] | undefined;
    jobQueueType?: JobQueueType | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    jobStateTimeLimitActions?: JobStateTimeLimitAction[] | undefined;
}
export interface CreateJobQueueResponse {
    jobQueueName: string;
    jobQueueArn: string;
}
export interface QuotaShareCapacityLimit {
    maxCapacity?: number | undefined;
    capacityUnit?: string | undefined;
}
export type QuotaShareCapacityLimits = QuotaShareCapacityLimit[];
export type QuotaShareResourceSharingStrategy = "RESERVE" | "LEND" | "LEND_AND_BORROW" | (string & {});
export interface QuotaShareResourceSharingConfiguration {
    strategy?: QuotaShareResourceSharingStrategy | undefined;
    borrowLimit?: number | undefined;
}
export type QuotaShareInSharePreemptionState = "ENABLED" | "DISABLED" | (string & {});
export interface QuotaSharePreemptionConfiguration {
    inSharePreemption?: QuotaShareInSharePreemptionState | undefined;
}
export type QuotaShareState = "ENABLED" | "DISABLED" | (string & {});
export interface CreateQuotaShareRequest {
    quotaShareName?: string | undefined;
    jobQueue?: string | undefined;
    capacityLimits?: QuotaShareCapacityLimit[] | undefined;
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration | undefined;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration | undefined;
    state?: QuotaShareState | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateQuotaShareResponse {
    quotaShareName?: string | undefined;
    quotaShareArn?: string | undefined;
}
export type QuotaShareIdleResourceAssignmentStrategy = "FIFO" | (string & {});
export interface QuotaSharePolicy {
    idleResourceAssignmentStrategy?: QuotaShareIdleResourceAssignmentStrategy | undefined;
}
export interface ShareAttributes {
    shareIdentifier?: string | undefined;
    weightFactor?: number | undefined;
}
export type ShareAttributesList = ShareAttributes[];
export interface FairsharePolicy {
    shareDecaySeconds?: number | undefined;
    computeReservation?: number | undefined;
    shareDistribution?: ShareAttributes[] | undefined;
}
export interface CreateSchedulingPolicyRequest {
    name?: string | undefined;
    quotaSharePolicy?: QuotaSharePolicy | undefined;
    fairsharePolicy?: FairsharePolicy | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSchedulingPolicyResponse {
    name: string;
    arn: string;
}
export type ServiceEnvironmentType = "SAGEMAKER_TRAINING" | (string & {});
export type ServiceEnvironmentState = "ENABLED" | "DISABLED" | (string & {});
export interface CapacityLimit {
    maxCapacity?: number | undefined;
    capacityUnit?: string | undefined;
}
export type CapacityLimits = CapacityLimit[];
export interface CreateServiceEnvironmentRequest {
    serviceEnvironmentName?: string | undefined;
    serviceEnvironmentType?: ServiceEnvironmentType | undefined;
    state?: ServiceEnvironmentState | undefined;
    capacityLimits?: CapacityLimit[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateServiceEnvironmentResponse {
    serviceEnvironmentName: string;
    serviceEnvironmentArn: string;
}
export interface DeleteComputeEnvironmentRequest {
    computeEnvironment?: string | undefined;
}
export interface DeleteComputeEnvironmentResponse {
}
export interface DeleteConsumableResourceRequest {
    consumableResource?: string | undefined;
}
export interface DeleteConsumableResourceResponse {
}
export interface DeleteJobQueueRequest {
    jobQueue?: string | undefined;
}
export interface DeleteJobQueueResponse {
}
export interface DeleteQuotaShareRequest {
    quotaShareArn?: string | undefined;
}
export interface DeleteQuotaShareResponse {
}
export interface DeleteSchedulingPolicyRequest {
    arn?: string | undefined;
}
export interface DeleteSchedulingPolicyResponse {
}
export interface DeleteServiceEnvironmentRequest {
    serviceEnvironment?: string | undefined;
}
export interface DeleteServiceEnvironmentResponse {
}
export interface DeregisterJobDefinitionRequest {
    jobDefinition?: string | undefined;
}
export interface DeregisterJobDefinitionResponse {
}
export interface DescribeComputeEnvironmentsRequest {
    computeEnvironments?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type CEStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export type JobExecutionTimeoutMinutes = number;
export interface UpdatePolicy {
    terminateJobsOnUpdate?: boolean | undefined;
    jobExecutionTimeoutMinutes?: number | undefined;
}
export type OrchestrationType = "ECS" | "EKS" | (string & {});
export interface ComputeEnvironmentDetail {
    computeEnvironmentName?: string | undefined;
    computeEnvironmentArn?: string | undefined;
    unmanagedvCpus?: number | undefined;
    ecsClusterArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    type?: CEType | undefined;
    state?: CEState | undefined;
    status?: CEStatus | undefined;
    statusReason?: string | undefined;
    computeResources?: ComputeResource | undefined;
    serviceRole?: string | undefined;
    updatePolicy?: UpdatePolicy | undefined;
    eksConfiguration?: EksConfiguration | undefined;
    containerOrchestrationType?: OrchestrationType | undefined;
    uuid?: string | undefined;
    context?: string | undefined;
    ecsSettings?: EcsSettings | undefined;
}
export type ComputeEnvironmentDetailList = ComputeEnvironmentDetail[];
export interface DescribeComputeEnvironmentsResponse {
    computeEnvironments?: (ComputeEnvironmentDetail & {
        computeEnvironmentName: string;
        computeEnvironmentArn: string;
        computeResources: ComputeResource & {
            type: CRType;
            maxvCpus: number;
            ec2Configuration: (Ec2Configuration & {
                imageType: ImageType;
            })[];
            managedInstancesProvider: ManagedInstancesProvider & {
                infrastructureRoleArn: string;
                instanceLaunchTemplate: InstanceLaunchTemplate & {
                    ec2InstanceProfileArn: string;
                    networkConfiguration: ManagedInstancesNetworkConfiguration & {
                        subnets: StringList;
                        securityGroups: StringList;
                    };
                };
            };
        };
        eksConfiguration: EksConfiguration & {
            eksClusterArn: string;
            kubernetesNamespace: string;
            accessEntry: EksAccessEntry & {
                desiredState: EksAccessEntryDesiredState;
            };
        };
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeConsumableResourceRequest {
    consumableResource?: string | undefined;
}
export interface DescribeConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
    totalQuantity?: number | undefined;
    inUseQuantity?: number | undefined;
    availableQuantity?: number | undefined;
    resourceType?: string | undefined;
    createdAt?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeJobDefinitionsRequest {
    jobDefinitions?: string[] | undefined;
    maxResults?: number | undefined;
    jobDefinitionName?: string | undefined;
    status?: string | undefined;
    nextToken?: string | undefined;
}
export type ParametersMap = {
    [key: string]: string | undefined;
};
export type RetryAction = "RETRY" | "EXIT" | (string & {});
export interface EvaluateOnExit {
    onStatusReason?: string | undefined;
    onReason?: string | undefined;
    onExitCode?: string | undefined;
    action?: RetryAction | undefined;
}
export type EvaluateOnExitList = EvaluateOnExit[];
export interface RetryStrategy {
    attempts?: number | undefined;
    evaluateOnExit?: EvaluateOnExit[] | undefined;
}
export interface Host {
    sourcePath?: string | undefined;
}
export type EFSTransitEncryption = "ENABLED" | "DISABLED" | (string & {});
export type EFSAuthorizationConfigIAM = "ENABLED" | "DISABLED" | (string & {});
export interface EFSAuthorizationConfig {
    accessPointId?: string | undefined;
    iam?: EFSAuthorizationConfigIAM | undefined;
}
export interface EFSVolumeConfiguration {
    fileSystemId?: string | undefined;
    rootDirectory?: string | undefined;
    transitEncryption?: EFSTransitEncryption | undefined;
    transitEncryptionPort?: number | undefined;
    authorizationConfig?: EFSAuthorizationConfig | undefined;
}
export interface S3FilesVolumeConfiguration {
    fileSystemArn?: string | undefined;
    rootDirectory?: string | undefined;
    transitEncryptionPort?: number | undefined;
    accessPointArn?: string | undefined;
}
export interface Volume {
    host?: Host | undefined;
    name?: string | undefined;
    efsVolumeConfiguration?: EFSVolumeConfiguration | undefined;
    s3filesVolumeConfiguration?: S3FilesVolumeConfiguration | undefined;
}
export type Volumes = Volume[];
export interface KeyValuePair {
    name?: string | undefined;
    value?: string | undefined;
}
export type EnvironmentVariables = KeyValuePair[];
export interface MountPoint {
    containerPath?: string | undefined;
    readOnly?: boolean | undefined;
    sourceVolume?: string | undefined;
}
export type MountPoints = MountPoint[];
export interface Ulimit {
    hardLimit?: number | undefined;
    name?: string | undefined;
    softLimit?: number | undefined;
}
export type Ulimits = Ulimit[];
export type ResourceType = "GPU" | "VCPU" | "MEMORY" | (string & {});
export interface ResourceRequirement {
    value?: string | undefined;
    type?: ResourceType | undefined;
}
export type ResourceRequirements = ResourceRequirement[];
export type DeviceCgroupPermission = "READ" | "WRITE" | "MKNOD" | (string & {});
export type DeviceCgroupPermissions = DeviceCgroupPermission[];
export interface Device {
    hostPath?: string | undefined;
    containerPath?: string | undefined;
    permissions?: DeviceCgroupPermission[] | undefined;
}
export type DevicesList = Device[];
export interface Tmpfs {
    containerPath?: string | undefined;
    size?: number | undefined;
    mountOptions?: string[] | undefined;
}
export type TmpfsList = Tmpfs[];
export interface LinuxParameters {
    devices?: Device[] | undefined;
    initProcessEnabled?: boolean | undefined;
    sharedMemorySize?: number | undefined;
    tmpfs?: Tmpfs[] | undefined;
    maxSwap?: number | undefined;
    swappiness?: number | undefined;
}
export type LogDriver = "json-file" | "syslog" | "journald" | "gelf" | "fluentd" | "awslogs" | "splunk" | "awsfirelens" | (string & {});
export type LogConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export interface Secret {
    name?: string | undefined;
    valueFrom?: string | undefined;
}
export type SecretList = Secret[];
export interface LogConfiguration {
    logDriver?: LogDriver | undefined;
    options?: {
        [key: string]: string | undefined;
    } | undefined;
    secretOptions?: Secret[] | undefined;
}
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export interface NetworkConfiguration {
    assignPublicIp?: AssignPublicIp | undefined;
}
export interface FargatePlatformConfiguration {
    platformVersion?: string | undefined;
}
export interface EphemeralStorage {
    sizeInGiB?: number | undefined;
}
export interface RuntimePlatform {
    operatingSystemFamily?: string | undefined;
    cpuArchitecture?: string | undefined;
}
export interface RepositoryCredentials {
    credentialsParameter?: string | undefined;
}
export interface ContainerProperties {
    image?: string | undefined;
    vcpus?: number | undefined;
    memory?: number | undefined;
    command?: string[] | undefined;
    jobRoleArn?: string | undefined;
    executionRoleArn?: string | undefined;
    volumes?: Volume[] | undefined;
    environment?: KeyValuePair[] | undefined;
    mountPoints?: MountPoint[] | undefined;
    readonlyRootFilesystem?: boolean | undefined;
    privileged?: boolean | undefined;
    ulimits?: Ulimit[] | undefined;
    user?: string | undefined;
    instanceType?: string | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
    linuxParameters?: LinuxParameters | undefined;
    logConfiguration?: LogConfiguration | undefined;
    secrets?: Secret[] | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    fargatePlatformConfiguration?: FargatePlatformConfiguration | undefined;
    enableExecuteCommand?: boolean | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    runtimePlatform?: RuntimePlatform | undefined;
    repositoryCredentials?: RepositoryCredentials | undefined;
}
export interface JobTimeout {
    attemptDurationSeconds?: number | undefined;
}
export interface TaskContainerDependency {
    containerName?: string | undefined;
    condition?: string | undefined;
}
export type TaskContainerDependencyList = TaskContainerDependency[];
export type FirelensConfigurationType = "fluentd" | "fluentbit" | (string & {});
export type FirelensConfigurationOptionsMap = {
    [key: string]: string | undefined;
};
export interface FirelensConfiguration {
    type?: FirelensConfigurationType | undefined;
    options?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TaskContainerProperties {
    command?: string[] | undefined;
    dependsOn?: TaskContainerDependency[] | undefined;
    environment?: KeyValuePair[] | undefined;
    essential?: boolean | undefined;
    firelensConfiguration?: FirelensConfiguration | undefined;
    image?: string | undefined;
    linuxParameters?: LinuxParameters | undefined;
    logConfiguration?: LogConfiguration | undefined;
    mountPoints?: MountPoint[] | undefined;
    name?: string | undefined;
    privileged?: boolean | undefined;
    readonlyRootFilesystem?: boolean | undefined;
    repositoryCredentials?: RepositoryCredentials | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
    secrets?: Secret[] | undefined;
    ulimits?: Ulimit[] | undefined;
    user?: string | undefined;
    startTimeout?: number | undefined;
    stopTimeout?: number | undefined;
}
export type ListTaskContainerProperties = TaskContainerProperties[];
export interface EcsTaskProperties {
    containers?: TaskContainerProperties[] | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    executionRoleArn?: string | undefined;
    platformVersion?: string | undefined;
    ipcMode?: string | undefined;
    taskRoleArn?: string | undefined;
    pidMode?: string | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    runtimePlatform?: RuntimePlatform | undefined;
    volumes?: Volume[] | undefined;
    enableExecuteCommand?: boolean | undefined;
    networkMode?: string | undefined;
}
export type ListEcsTaskProperties = EcsTaskProperties[];
export interface EcsProperties {
    taskProperties?: EcsTaskProperties[] | undefined;
}
export interface ImagePullSecret {
    name?: string | undefined;
}
export type ImagePullSecrets = ImagePullSecret[];
export interface EksContainerEnvironmentVariable {
    name?: string | undefined;
    value?: string | undefined;
}
export type EksContainerEnvironmentVariables = EksContainerEnvironmentVariable[];
export type Quantity = string;
export type EksLimits = {
    [key: string]: string | undefined;
};
export type EksRequests = {
    [key: string]: string | undefined;
};
export interface EksContainerResourceRequirements {
    limits?: {
        [key: string]: string | undefined;
    } | undefined;
    requests?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EksContainerVolumeMount {
    name?: string | undefined;
    mountPath?: string | undefined;
    subPath?: string | undefined;
    readOnly?: boolean | undefined;
}
export type EksContainerVolumeMounts = EksContainerVolumeMount[];
export type EksContainerLinuxCapability = string;
export type EksContainerLinuxCapabilityList = string[];
export interface EksContainerLinuxCapabilities {
    add?: string[] | undefined;
    drop?: string[] | undefined;
}
export type EksSeccompProfileType = "RuntimeDefault" | "Localhost" | "Unconfined" | (string & {});
export type EksSeccompLocalhostProfile = string;
export interface EksSeccompProfile {
    type?: EksSeccompProfileType | undefined;
    localhostProfile?: string | undefined;
}
export interface EksContainerSecurityContext {
    runAsUser?: number | undefined;
    runAsGroup?: number | undefined;
    privileged?: boolean | undefined;
    allowPrivilegeEscalation?: boolean | undefined;
    readOnlyRootFilesystem?: boolean | undefined;
    runAsNonRoot?: boolean | undefined;
    capabilities?: EksContainerLinuxCapabilities | undefined;
    seccompProfile?: EksSeccompProfile | undefined;
}
export interface EksContainer {
    name?: string | undefined;
    image?: string | undefined;
    imagePullPolicy?: string | undefined;
    command?: string[] | undefined;
    args?: string[] | undefined;
    env?: EksContainerEnvironmentVariable[] | undefined;
    resources?: EksContainerResourceRequirements | undefined;
    volumeMounts?: EksContainerVolumeMount[] | undefined;
    securityContext?: EksContainerSecurityContext | undefined;
}
export type EksContainers = EksContainer[];
export interface EksHostPath {
    path?: string | undefined;
}
export interface EksEmptyDir {
    medium?: string | undefined;
    sizeLimit?: string | undefined;
}
export interface EksSecret {
    secretName?: string | undefined;
    optional?: boolean | undefined;
}
export interface EksPersistentVolumeClaim {
    claimName?: string | undefined;
    readOnly?: boolean | undefined;
}
export interface EksVolume {
    name?: string | undefined;
    hostPath?: EksHostPath | undefined;
    emptyDir?: EksEmptyDir | undefined;
    secret?: EksSecret | undefined;
    persistentVolumeClaim?: EksPersistentVolumeClaim | undefined;
}
export type EksVolumes = EksVolume[];
export type EksLabelsMap = {
    [key: string]: string | undefined;
};
export type EksAnnotationsMap = {
    [key: string]: string | undefined;
};
export interface EksMetadata {
    labels?: {
        [key: string]: string | undefined;
    } | undefined;
    annotations?: {
        [key: string]: string | undefined;
    } | undefined;
    namespace?: string | undefined;
}
export interface EksPodSecurityContext {
    runAsUser?: number | undefined;
    runAsGroup?: number | undefined;
    runAsNonRoot?: boolean | undefined;
    seccompProfile?: EksSeccompProfile | undefined;
    fsGroup?: number | undefined;
}
export interface EksPodProperties {
    serviceAccountName?: string | undefined;
    hostNetwork?: boolean | undefined;
    dnsPolicy?: string | undefined;
    imagePullSecrets?: ImagePullSecret[] | undefined;
    containers?: EksContainer[] | undefined;
    initContainers?: EksContainer[] | undefined;
    volumes?: EksVolume[] | undefined;
    metadata?: EksMetadata | undefined;
    shareProcessNamespace?: boolean | undefined;
    securityContext?: EksPodSecurityContext | undefined;
}
export interface EksProperties {
    podProperties?: EksPodProperties | undefined;
}
export interface ConsumableResourceRequirement {
    consumableResource?: string | undefined;
    quantity?: number | undefined;
}
export type ConsumableResourceList = ConsumableResourceRequirement[];
export interface ConsumableResourceProperties {
    consumableResourceList?: ConsumableResourceRequirement[] | undefined;
}
export interface NodeRangeProperty {
    targetNodes?: string | undefined;
    container?: ContainerProperties | undefined;
    instanceTypes?: string[] | undefined;
    ecsProperties?: EcsProperties | undefined;
    eksProperties?: EksProperties | undefined;
    consumableResourceProperties?: ConsumableResourceProperties | undefined;
}
export type NodeRangeProperties = NodeRangeProperty[];
export interface NodeProperties {
    numNodes?: number | undefined;
    mainNode?: number | undefined;
    nodeRangeProperties?: NodeRangeProperty[] | undefined;
}
export type PlatformCapability = "EC2" | "FARGATE" | "MANAGED_INSTANCES" | (string & {});
export type PlatformCapabilityList = PlatformCapability[];
export interface JobDefinition {
    jobDefinitionName?: string | undefined;
    jobDefinitionArn?: string | undefined;
    revision?: number | undefined;
    status?: string | undefined;
    type?: string | undefined;
    schedulingPriority?: number | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    retryStrategy?: RetryStrategy | undefined;
    containerProperties?: ContainerProperties | undefined;
    timeout?: JobTimeout | undefined;
    nodeProperties?: NodeProperties | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    propagateTags?: boolean | undefined;
    platformCapabilities?: PlatformCapability[] | undefined;
    ecsProperties?: EcsProperties | undefined;
    eksProperties?: EksProperties | undefined;
    containerOrchestrationType?: OrchestrationType | undefined;
    consumableResourceProperties?: ConsumableResourceProperties | undefined;
}
export type JobDefinitionList = JobDefinition[];
export interface DescribeJobDefinitionsResponse {
    jobDefinitions?: (JobDefinition & {
        jobDefinitionName: string;
        jobDefinitionArn: string;
        revision: number;
        type: string;
        retryStrategy: RetryStrategy & {
            evaluateOnExit: (EvaluateOnExit & {
                action: RetryAction;
            })[];
        };
        containerProperties: ContainerProperties & {
            volumes: (Volume & {
                efsVolumeConfiguration: EFSVolumeConfiguration & {
                    fileSystemId: string;
                };
                s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                    fileSystemArn: string;
                };
            })[];
            ulimits: (Ulimit & {
                hardLimit: number;
                name: string;
                softLimit: number;
            })[];
            resourceRequirements: (ResourceRequirement & {
                value: string;
                type: ResourceType;
            })[];
            linuxParameters: LinuxParameters & {
                devices: (Device & {
                    hostPath: string;
                })[];
                tmpfs: (Tmpfs & {
                    containerPath: string;
                    size: number;
                })[];
            };
            logConfiguration: LogConfiguration & {
                logDriver: LogDriver;
                secretOptions: (Secret & {
                    name: string;
                    valueFrom: string;
                })[];
            };
            secrets: (Secret & {
                name: string;
                valueFrom: string;
            })[];
            ephemeralStorage: EphemeralStorage & {
                sizeInGiB: number;
            };
            repositoryCredentials: RepositoryCredentials & {
                credentialsParameter: string;
            };
        };
        nodeProperties: NodeProperties & {
            numNodes: number;
            mainNode: number;
            nodeRangeProperties: (NodeRangeProperty & {
                targetNodes: string;
                container: ContainerProperties & {
                    volumes: (Volume & {
                        efsVolumeConfiguration: EFSVolumeConfiguration & {
                            fileSystemId: string;
                        };
                        s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                            fileSystemArn: string;
                        };
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ephemeralStorage: EphemeralStorage & {
                        sizeInGiB: number;
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                };
                ecsProperties: EcsProperties & {
                    taskProperties: (EcsTaskProperties & {
                        containers: (TaskContainerProperties & {
                            image: string;
                            firelensConfiguration: FirelensConfiguration & {
                                type: FirelensConfigurationType;
                            };
                            linuxParameters: LinuxParameters & {
                                devices: (Device & {
                                    hostPath: string;
                                })[];
                                tmpfs: (Tmpfs & {
                                    containerPath: string;
                                    size: number;
                                })[];
                            };
                            logConfiguration: LogConfiguration & {
                                logDriver: LogDriver;
                                secretOptions: (Secret & {
                                    name: string;
                                    valueFrom: string;
                                })[];
                            };
                            repositoryCredentials: RepositoryCredentials & {
                                credentialsParameter: string;
                            };
                            resourceRequirements: (ResourceRequirement & {
                                value: string;
                                type: ResourceType;
                            })[];
                            secrets: (Secret & {
                                name: string;
                                valueFrom: string;
                            })[];
                            ulimits: (Ulimit & {
                                hardLimit: number;
                                name: string;
                                softLimit: number;
                            })[];
                        })[];
                        ephemeralStorage: EphemeralStorage & {
                            sizeInGiB: number;
                        };
                        volumes: (Volume & {
                            efsVolumeConfiguration: EFSVolumeConfiguration & {
                                fileSystemId: string;
                            };
                            s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                                fileSystemArn: string;
                            };
                        })[];
                    })[];
                };
                eksProperties: EksProperties & {
                    podProperties: EksPodProperties & {
                        imagePullSecrets: (ImagePullSecret & {
                            name: string;
                        })[];
                        containers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                            securityContext: EksContainerSecurityContext & {
                                seccompProfile: EksSeccompProfile & {
                                    type: EksSeccompProfileType;
                                };
                            };
                        })[];
                        initContainers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                            securityContext: EksContainerSecurityContext & {
                                seccompProfile: EksSeccompProfile & {
                                    type: EksSeccompProfileType;
                                };
                            };
                        })[];
                        volumes: (EksVolume & {
                            name: string;
                            secret: EksSecret & {
                                secretName: string;
                            };
                            persistentVolumeClaim: EksPersistentVolumeClaim & {
                                claimName: string;
                            };
                        })[];
                        securityContext: EksPodSecurityContext & {
                            seccompProfile: EksSeccompProfile & {
                                type: EksSeccompProfileType;
                            };
                        };
                    };
                };
            })[];
        };
        ecsProperties: EcsProperties & {
            taskProperties: (EcsTaskProperties & {
                containers: (TaskContainerProperties & {
                    image: string;
                    firelensConfiguration: FirelensConfiguration & {
                        type: FirelensConfigurationType;
                    };
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                })[];
                ephemeralStorage: EphemeralStorage & {
                    sizeInGiB: number;
                };
                volumes: (Volume & {
                    efsVolumeConfiguration: EFSVolumeConfiguration & {
                        fileSystemId: string;
                    };
                    s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                        fileSystemArn: string;
                    };
                })[];
            })[];
        };
        eksProperties: EksProperties & {
            podProperties: EksPodProperties & {
                imagePullSecrets: (ImagePullSecret & {
                    name: string;
                })[];
                containers: (EksContainer & {
                    image: string;
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                    securityContext: EksContainerSecurityContext & {
                        seccompProfile: EksSeccompProfile & {
                            type: EksSeccompProfileType;
                        };
                    };
                })[];
                initContainers: (EksContainer & {
                    image: string;
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                    securityContext: EksContainerSecurityContext & {
                        seccompProfile: EksSeccompProfile & {
                            type: EksSeccompProfileType;
                        };
                    };
                })[];
                volumes: (EksVolume & {
                    name: string;
                    secret: EksSecret & {
                        secretName: string;
                    };
                    persistentVolumeClaim: EksPersistentVolumeClaim & {
                        claimName: string;
                    };
                })[];
                securityContext: EksPodSecurityContext & {
                    seccompProfile: EksSeccompProfile & {
                        type: EksSeccompProfileType;
                    };
                };
            };
        };
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeJobQueuesRequest {
    jobQueues?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type JQStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export interface JobQueueDetail {
    jobQueueName?: string | undefined;
    jobQueueArn?: string | undefined;
    state?: JQState | undefined;
    schedulingPolicyArn?: string | undefined;
    status?: JQStatus | undefined;
    statusReason?: string | undefined;
    priority?: number | undefined;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[] | undefined;
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[] | undefined;
    jobQueueType?: JobQueueType | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    jobStateTimeLimitActions?: JobStateTimeLimitAction[] | undefined;
}
export type JobQueueDetailList = JobQueueDetail[];
export interface DescribeJobQueuesResponse {
    jobQueues?: (JobQueueDetail & {
        jobQueueName: string;
        jobQueueArn: string;
        state: JQState;
        priority: number;
        computeEnvironmentOrder: (ComputeEnvironmentOrder & {
            order: number;
            computeEnvironment: string;
        })[];
        serviceEnvironmentOrder: (ServiceEnvironmentOrder & {
            order: number;
            serviceEnvironment: string;
        })[];
        jobStateTimeLimitActions: (JobStateTimeLimitAction & {
            reason: string;
            state: JobStateTimeLimitActionsState;
            maxTimeSeconds: number;
            action: JobStateTimeLimitActionsAction;
        })[];
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeJobsRequest {
    jobs?: string[] | undefined;
}
export type JobStatus = "SUBMITTED" | "PENDING" | "RUNNABLE" | "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface NetworkInterface {
    attachmentId?: string | undefined;
    ipv6Address?: string | undefined;
    privateIpv4Address?: string | undefined;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface AttemptContainerDetail {
    containerInstanceArn?: string | undefined;
    taskArn?: string | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
    logStreamName?: string | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
}
export interface AttemptTaskContainerDetails {
    exitCode?: number | undefined;
    name?: string | undefined;
    reason?: string | undefined;
    logStreamName?: string | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
}
export type ListAttemptTaskContainerDetails = AttemptTaskContainerDetails[];
export interface AttemptEcsTaskDetails {
    containerInstanceArn?: string | undefined;
    taskArn?: string | undefined;
    containers?: AttemptTaskContainerDetails[] | undefined;
}
export type ListAttemptEcsTaskDetails = AttemptEcsTaskDetails[];
export interface AttemptDetail {
    container?: AttemptContainerDetail | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    statusReason?: string | undefined;
    taskProperties?: AttemptEcsTaskDetails[] | undefined;
}
export type AttemptDetails = AttemptDetail[];
export type ArrayJobDependency = "N_TO_N" | "SEQUENTIAL" | (string & {});
export interface JobDependency {
    jobId?: string | undefined;
    type?: ArrayJobDependency | undefined;
}
export type JobDependencyList = JobDependency[];
export interface ContainerDetail {
    image?: string | undefined;
    vcpus?: number | undefined;
    memory?: number | undefined;
    command?: string[] | undefined;
    jobRoleArn?: string | undefined;
    executionRoleArn?: string | undefined;
    volumes?: Volume[] | undefined;
    environment?: KeyValuePair[] | undefined;
    mountPoints?: MountPoint[] | undefined;
    readonlyRootFilesystem?: boolean | undefined;
    ulimits?: Ulimit[] | undefined;
    privileged?: boolean | undefined;
    user?: string | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
    containerInstanceArn?: string | undefined;
    taskArn?: string | undefined;
    logStreamName?: string | undefined;
    instanceType?: string | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
    linuxParameters?: LinuxParameters | undefined;
    logConfiguration?: LogConfiguration | undefined;
    secrets?: Secret[] | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    fargatePlatformConfiguration?: FargatePlatformConfiguration | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    runtimePlatform?: RuntimePlatform | undefined;
    repositoryCredentials?: RepositoryCredentials | undefined;
    enableExecuteCommand?: boolean | undefined;
}
export interface NodeDetails {
    nodeIndex?: number | undefined;
    isMainNode?: boolean | undefined;
}
export type ArrayJobStatusSummary = {
    [key: string]: number | undefined;
};
export interface ArrayPropertiesDetail {
    statusSummary?: {
        [key: string]: number | undefined;
    } | undefined;
    statusSummaryLastUpdatedAt?: number | undefined;
    size?: number | undefined;
    index?: number | undefined;
}
export interface EksContainerDetail {
    name?: string | undefined;
    image?: string | undefined;
    imagePullPolicy?: string | undefined;
    command?: string[] | undefined;
    args?: string[] | undefined;
    env?: EksContainerEnvironmentVariable[] | undefined;
    resources?: EksContainerResourceRequirements | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
    volumeMounts?: EksContainerVolumeMount[] | undefined;
    securityContext?: EksContainerSecurityContext | undefined;
}
export type EksContainerDetails = EksContainerDetail[];
export interface EksPodPropertiesDetail {
    serviceAccountName?: string | undefined;
    hostNetwork?: boolean | undefined;
    dnsPolicy?: string | undefined;
    imagePullSecrets?: ImagePullSecret[] | undefined;
    containers?: EksContainerDetail[] | undefined;
    initContainers?: EksContainerDetail[] | undefined;
    volumes?: EksVolume[] | undefined;
    podName?: string | undefined;
    nodeName?: string | undefined;
    metadata?: EksMetadata | undefined;
    shareProcessNamespace?: boolean | undefined;
    securityContext?: EksPodSecurityContext | undefined;
}
export interface EksPropertiesDetail {
    podProperties?: EksPodPropertiesDetail | undefined;
}
export interface EksAttemptContainerDetail {
    name?: string | undefined;
    containerID?: string | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
}
export type EksAttemptContainerDetails = EksAttemptContainerDetail[];
export interface EksAttemptDetail {
    containers?: EksAttemptContainerDetail[] | undefined;
    initContainers?: EksAttemptContainerDetail[] | undefined;
    eksClusterArn?: string | undefined;
    podName?: string | undefined;
    podNamespace?: string | undefined;
    nodeName?: string | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    statusReason?: string | undefined;
}
export type EksAttemptDetails = EksAttemptDetail[];
export interface TaskContainerDetails {
    command?: string[] | undefined;
    dependsOn?: TaskContainerDependency[] | undefined;
    environment?: KeyValuePair[] | undefined;
    essential?: boolean | undefined;
    firelensConfiguration?: FirelensConfiguration | undefined;
    image?: string | undefined;
    linuxParameters?: LinuxParameters | undefined;
    logConfiguration?: LogConfiguration | undefined;
    mountPoints?: MountPoint[] | undefined;
    name?: string | undefined;
    privileged?: boolean | undefined;
    readonlyRootFilesystem?: boolean | undefined;
    repositoryCredentials?: RepositoryCredentials | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
    secrets?: Secret[] | undefined;
    ulimits?: Ulimit[] | undefined;
    user?: string | undefined;
    startTimeout?: number | undefined;
    stopTimeout?: number | undefined;
    exitCode?: number | undefined;
    reason?: string | undefined;
    logStreamName?: string | undefined;
    networkInterfaces?: NetworkInterface[] | undefined;
}
export type ListTaskContainerDetails = TaskContainerDetails[];
export interface EcsTaskDetails {
    containers?: TaskContainerDetails[] | undefined;
    containerInstanceArn?: string | undefined;
    taskArn?: string | undefined;
    ephemeralStorage?: EphemeralStorage | undefined;
    executionRoleArn?: string | undefined;
    platformVersion?: string | undefined;
    ipcMode?: string | undefined;
    taskRoleArn?: string | undefined;
    pidMode?: string | undefined;
    networkConfiguration?: NetworkConfiguration | undefined;
    runtimePlatform?: RuntimePlatform | undefined;
    volumes?: Volume[] | undefined;
    enableExecuteCommand?: boolean | undefined;
    networkMode?: string | undefined;
}
export type ListEcsTaskDetails = EcsTaskDetails[];
export interface EcsPropertiesDetail {
    taskProperties?: EcsTaskDetails[] | undefined;
}
export interface JobDetail {
    jobArn?: string | undefined;
    jobName?: string | undefined;
    jobId?: string | undefined;
    jobQueue?: string | undefined;
    status?: JobStatus | undefined;
    shareIdentifier?: string | undefined;
    schedulingPriority?: number | undefined;
    attempts?: AttemptDetail[] | undefined;
    statusReason?: string | undefined;
    createdAt?: number | undefined;
    retryStrategy?: RetryStrategy | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    dependsOn?: JobDependency[] | undefined;
    jobDefinition?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    container?: ContainerDetail | undefined;
    nodeDetails?: NodeDetails | undefined;
    nodeProperties?: NodeProperties | undefined;
    arrayProperties?: ArrayPropertiesDetail | undefined;
    timeout?: JobTimeout | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    propagateTags?: boolean | undefined;
    platformCapabilities?: PlatformCapability[] | undefined;
    eksProperties?: EksPropertiesDetail | undefined;
    eksAttempts?: EksAttemptDetail[] | undefined;
    ecsProperties?: EcsPropertiesDetail | undefined;
    isCancelled?: boolean | undefined;
    isTerminated?: boolean | undefined;
    consumableResourceProperties?: ConsumableResourceProperties | undefined;
}
export type JobDetailList = JobDetail[];
export interface DescribeJobsResponse {
    jobs?: (JobDetail & {
        jobName: string;
        jobId: string;
        jobQueue: string;
        status: JobStatus;
        startedAt: number;
        jobDefinition: string;
        retryStrategy: RetryStrategy & {
            evaluateOnExit: (EvaluateOnExit & {
                action: RetryAction;
            })[];
        };
        container: ContainerDetail & {
            volumes: (Volume & {
                efsVolumeConfiguration: EFSVolumeConfiguration & {
                    fileSystemId: string;
                };
                s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                    fileSystemArn: string;
                };
            })[];
            ulimits: (Ulimit & {
                hardLimit: number;
                name: string;
                softLimit: number;
            })[];
            resourceRequirements: (ResourceRequirement & {
                value: string;
                type: ResourceType;
            })[];
            linuxParameters: LinuxParameters & {
                devices: (Device & {
                    hostPath: string;
                })[];
                tmpfs: (Tmpfs & {
                    containerPath: string;
                    size: number;
                })[];
            };
            logConfiguration: LogConfiguration & {
                logDriver: LogDriver;
                secretOptions: (Secret & {
                    name: string;
                    valueFrom: string;
                })[];
            };
            secrets: (Secret & {
                name: string;
                valueFrom: string;
            })[];
            ephemeralStorage: EphemeralStorage & {
                sizeInGiB: number;
            };
            repositoryCredentials: RepositoryCredentials & {
                credentialsParameter: string;
            };
        };
        nodeProperties: NodeProperties & {
            numNodes: number;
            mainNode: number;
            nodeRangeProperties: (NodeRangeProperty & {
                targetNodes: string;
                container: ContainerProperties & {
                    volumes: (Volume & {
                        efsVolumeConfiguration: EFSVolumeConfiguration & {
                            fileSystemId: string;
                        };
                        s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                            fileSystemArn: string;
                        };
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ephemeralStorage: EphemeralStorage & {
                        sizeInGiB: number;
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                };
                ecsProperties: EcsProperties & {
                    taskProperties: (EcsTaskProperties & {
                        containers: (TaskContainerProperties & {
                            image: string;
                            firelensConfiguration: FirelensConfiguration & {
                                type: FirelensConfigurationType;
                            };
                            linuxParameters: LinuxParameters & {
                                devices: (Device & {
                                    hostPath: string;
                                })[];
                                tmpfs: (Tmpfs & {
                                    containerPath: string;
                                    size: number;
                                })[];
                            };
                            logConfiguration: LogConfiguration & {
                                logDriver: LogDriver;
                                secretOptions: (Secret & {
                                    name: string;
                                    valueFrom: string;
                                })[];
                            };
                            repositoryCredentials: RepositoryCredentials & {
                                credentialsParameter: string;
                            };
                            resourceRequirements: (ResourceRequirement & {
                                value: string;
                                type: ResourceType;
                            })[];
                            secrets: (Secret & {
                                name: string;
                                valueFrom: string;
                            })[];
                            ulimits: (Ulimit & {
                                hardLimit: number;
                                name: string;
                                softLimit: number;
                            })[];
                        })[];
                        ephemeralStorage: EphemeralStorage & {
                            sizeInGiB: number;
                        };
                        volumes: (Volume & {
                            efsVolumeConfiguration: EFSVolumeConfiguration & {
                                fileSystemId: string;
                            };
                            s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                                fileSystemArn: string;
                            };
                        })[];
                    })[];
                };
                eksProperties: EksProperties & {
                    podProperties: EksPodProperties & {
                        imagePullSecrets: (ImagePullSecret & {
                            name: string;
                        })[];
                        containers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                            securityContext: EksContainerSecurityContext & {
                                seccompProfile: EksSeccompProfile & {
                                    type: EksSeccompProfileType;
                                };
                            };
                        })[];
                        initContainers: (EksContainer & {
                            image: string;
                            env: (EksContainerEnvironmentVariable & {
                                name: string;
                            })[];
                            securityContext: EksContainerSecurityContext & {
                                seccompProfile: EksSeccompProfile & {
                                    type: EksSeccompProfileType;
                                };
                            };
                        })[];
                        volumes: (EksVolume & {
                            name: string;
                            secret: EksSecret & {
                                secretName: string;
                            };
                            persistentVolumeClaim: EksPersistentVolumeClaim & {
                                claimName: string;
                            };
                        })[];
                        securityContext: EksPodSecurityContext & {
                            seccompProfile: EksSeccompProfile & {
                                type: EksSeccompProfileType;
                            };
                        };
                    };
                };
            })[];
        };
        eksProperties: EksPropertiesDetail & {
            podProperties: EksPodPropertiesDetail & {
                imagePullSecrets: (ImagePullSecret & {
                    name: string;
                })[];
                containers: (EksContainerDetail & {
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                    securityContext: EksContainerSecurityContext & {
                        seccompProfile: EksSeccompProfile & {
                            type: EksSeccompProfileType;
                        };
                    };
                })[];
                initContainers: (EksContainerDetail & {
                    env: (EksContainerEnvironmentVariable & {
                        name: string;
                    })[];
                    securityContext: EksContainerSecurityContext & {
                        seccompProfile: EksSeccompProfile & {
                            type: EksSeccompProfileType;
                        };
                    };
                })[];
                volumes: (EksVolume & {
                    name: string;
                    secret: EksSecret & {
                        secretName: string;
                    };
                    persistentVolumeClaim: EksPersistentVolumeClaim & {
                        claimName: string;
                    };
                })[];
                securityContext: EksPodSecurityContext & {
                    seccompProfile: EksSeccompProfile & {
                        type: EksSeccompProfileType;
                    };
                };
            };
        };
        ecsProperties: EcsPropertiesDetail & {
            taskProperties: (EcsTaskDetails & {
                containers: (TaskContainerDetails & {
                    firelensConfiguration: FirelensConfiguration & {
                        type: FirelensConfigurationType;
                    };
                    linuxParameters: LinuxParameters & {
                        devices: (Device & {
                            hostPath: string;
                        })[];
                        tmpfs: (Tmpfs & {
                            containerPath: string;
                            size: number;
                        })[];
                    };
                    logConfiguration: LogConfiguration & {
                        logDriver: LogDriver;
                        secretOptions: (Secret & {
                            name: string;
                            valueFrom: string;
                        })[];
                    };
                    repositoryCredentials: RepositoryCredentials & {
                        credentialsParameter: string;
                    };
                    resourceRequirements: (ResourceRequirement & {
                        value: string;
                        type: ResourceType;
                    })[];
                    secrets: (Secret & {
                        name: string;
                        valueFrom: string;
                    })[];
                    ulimits: (Ulimit & {
                        hardLimit: number;
                        name: string;
                        softLimit: number;
                    })[];
                })[];
                ephemeralStorage: EphemeralStorage & {
                    sizeInGiB: number;
                };
                volumes: (Volume & {
                    efsVolumeConfiguration: EFSVolumeConfiguration & {
                        fileSystemId: string;
                    };
                    s3filesVolumeConfiguration: S3FilesVolumeConfiguration & {
                        fileSystemArn: string;
                    };
                })[];
            })[];
        };
    })[] | undefined;
}
export interface DescribeQuotaShareRequest {
    quotaShareArn?: string | undefined;
}
export type QuotaShareStatus = "CREATING" | "VALID" | "INVALID" | "UPDATING" | "DELETING" | (string & {});
export interface DescribeQuotaShareResponse {
    quotaShareName?: string | undefined;
    quotaShareArn?: string | undefined;
    jobQueueArn?: string | undefined;
    capacityLimits?: (QuotaShareCapacityLimit & {
        maxCapacity: number;
        capacityUnit: string;
    })[] | undefined;
    resourceSharingConfiguration?: (QuotaShareResourceSharingConfiguration & {
        strategy: QuotaShareResourceSharingStrategy;
    }) | undefined;
    preemptionConfiguration?: (QuotaSharePreemptionConfiguration & {
        inSharePreemption: QuotaShareInSharePreemptionState;
    }) | undefined;
    state?: QuotaShareState | undefined;
    status?: QuotaShareStatus | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeSchedulingPoliciesRequest {
    arns?: string[] | undefined;
}
export interface SchedulingPolicyDetail {
    name?: string | undefined;
    arn?: string | undefined;
    quotaSharePolicy?: QuotaSharePolicy | undefined;
    fairsharePolicy?: FairsharePolicy | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SchedulingPolicyDetailList = SchedulingPolicyDetail[];
export interface DescribeSchedulingPoliciesResponse {
    schedulingPolicies?: (SchedulingPolicyDetail & {
        name: string;
        arn: string;
        quotaSharePolicy: QuotaSharePolicy & {
            idleResourceAssignmentStrategy: QuotaShareIdleResourceAssignmentStrategy;
        };
        fairsharePolicy: FairsharePolicy & {
            shareDistribution: (ShareAttributes & {
                shareIdentifier: string;
            })[];
        };
    })[] | undefined;
}
export interface DescribeServiceEnvironmentsRequest {
    serviceEnvironments?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ServiceEnvironmentStatus = "CREATING" | "UPDATING" | "DELETING" | "DELETED" | "VALID" | "INVALID" | (string & {});
export interface ServiceEnvironmentDetail {
    serviceEnvironmentName?: string | undefined;
    serviceEnvironmentArn?: string | undefined;
    serviceEnvironmentType?: ServiceEnvironmentType | undefined;
    state?: ServiceEnvironmentState | undefined;
    status?: ServiceEnvironmentStatus | undefined;
    capacityLimits?: CapacityLimit[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ServiceEnvironmentDetailList = ServiceEnvironmentDetail[];
export interface DescribeServiceEnvironmentsResponse {
    serviceEnvironments?: (ServiceEnvironmentDetail & {
        serviceEnvironmentName: string;
        serviceEnvironmentArn: string;
        serviceEnvironmentType: ServiceEnvironmentType;
        capacityLimits: CapacityLimits;
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeServiceJobRequest {
    jobId?: string | undefined;
}
export type ServiceResourceIdName = "TrainingJobArn" | (string & {});
export interface ServiceResourceId {
    name?: ServiceResourceIdName | undefined;
    value?: string | undefined;
}
export interface ServiceJobAttemptDetail {
    serviceResourceId?: ServiceResourceId | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    statusReason?: string | undefined;
}
export type ServiceJobAttemptDetails = ServiceJobAttemptDetail[];
export interface ServiceJobCapacityUsageDetail {
    capacityUnit?: string | undefined;
    quantity?: number | undefined;
}
export type ServiceJobCapacityUsageDetailList = ServiceJobCapacityUsageDetail[];
export interface LatestServiceJobAttempt {
    serviceResourceId?: ServiceResourceId | undefined;
}
export type ServiceJobRetryAction = "RETRY" | "EXIT" | (string & {});
export interface ServiceJobEvaluateOnExit {
    action?: ServiceJobRetryAction | undefined;
    onStatusReason?: string | undefined;
}
export type ServiceJobEvaluateOnExitList = ServiceJobEvaluateOnExit[];
export interface ServiceJobRetryStrategy {
    attempts?: number | undefined;
    evaluateOnExit?: ServiceJobEvaluateOnExit[] | undefined;
}
export type ServiceJobType = "SAGEMAKER_TRAINING" | (string & {});
export interface ServiceJobPreemptionConfiguration {
    preemptionRetriesBeforeTermination?: number | undefined;
}
export interface ServiceJobPreemptedAttempt {
    serviceResourceId?: ServiceResourceId | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    statusReason?: string | undefined;
}
export type ServiceJobRecentPreemptedAttemptList = ServiceJobPreemptedAttempt[];
export interface ServiceJobPreemptionSummary {
    preemptedAttemptCount?: number | undefined;
    recentPreemptedAttempts?: ServiceJobPreemptedAttempt[] | undefined;
}
export type ServiceJobStatus = "SUBMITTED" | "PENDING" | "RUNNABLE" | "SCHEDULED" | "STARTING" | "RUNNING" | "SUCCEEDED" | "FAILED" | (string & {});
export interface ServiceJobTimeout {
    attemptDurationSeconds?: number | undefined;
}
export interface DescribeServiceJobResponse {
    attempts?: (ServiceJobAttemptDetail & {
        serviceResourceId: ServiceResourceId & {
            name: ServiceResourceIdName;
            value: string;
        };
    })[] | undefined;
    capacityUsage?: ServiceJobCapacityUsageDetail[] | undefined;
    createdAt?: number | undefined;
    isTerminated?: boolean | undefined;
    jobArn?: string | undefined;
    jobId: string;
    jobName: string;
    jobQueue: string;
    latestAttempt?: (LatestServiceJobAttempt & {
        serviceResourceId: ServiceResourceId & {
            name: ServiceResourceIdName;
            value: string;
        };
    }) | undefined;
    retryStrategy?: (ServiceJobRetryStrategy & {
        attempts: number;
    }) | undefined;
    scheduledAt?: number | undefined;
    schedulingPriority?: number | undefined;
    serviceRequestPayload?: string | undefined;
    serviceJobType: ServiceJobType;
    shareIdentifier?: string | undefined;
    quotaShareName?: string | undefined;
    preemptionConfiguration?: ServiceJobPreemptionConfiguration | undefined;
    preemptionSummary?: (ServiceJobPreemptionSummary & {
        recentPreemptedAttempts: (ServiceJobPreemptedAttempt & {
            serviceResourceId: ServiceResourceId & {
                name: ServiceResourceIdName;
                value: string;
            };
        })[];
    }) | undefined;
    startedAt: number;
    status: ServiceJobStatus;
    statusReason?: string | undefined;
    stoppedAt?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    timeoutConfig?: ServiceJobTimeout | undefined;
}
export interface GetJobQueueSnapshotRequest {
    jobQueue?: string | undefined;
}
export interface FrontOfQueueJobSummary {
    jobArn?: string | undefined;
    earliestTimeAtPosition?: number | undefined;
}
export type FrontOfQueueJobSummaryList = FrontOfQueueJobSummary[];
export interface FrontOfQueueDetail {
    jobs?: FrontOfQueueJobSummary[] | undefined;
    lastUpdatedAt?: number | undefined;
}
export interface FrontOfQuotaShareJobSummary {
    jobArn?: string | undefined;
    earliestTimeAtPosition?: number | undefined;
}
export type FrontOfQuotaShareJobSummaryList = FrontOfQuotaShareJobSummary[];
export type FrontOfQuotaSharesJobSummaryMap = {
    [key: string]: FrontOfQuotaShareJobSummary[] | undefined;
};
export interface FrontOfQuotaSharesDetail {
    quotaShares?: {
        [key: string]: FrontOfQuotaShareJobSummary[] | undefined;
    } | undefined;
    lastUpdatedAt?: number | undefined;
}
export interface QueueSnapshotCapacityUsage {
    capacityUnit?: string | undefined;
    quantity?: number | undefined;
}
export type QueueSnapshotCapacityUsageList = QueueSnapshotCapacityUsage[];
export interface FairshareCapacityUsage {
    capacityUnit?: string | undefined;
    quantity?: number | undefined;
}
export type FairshareCapacityUsageList = FairshareCapacityUsage[];
export interface FairshareCapacityUtilization {
    shareIdentifier?: string | undefined;
    capacityUsage?: FairshareCapacityUsage[] | undefined;
}
export type FairshareCapacityUtilizationList = FairshareCapacityUtilization[];
export interface FairshareUtilizationDetail {
    activeShareCount?: number | undefined;
    topCapacityUtilization?: FairshareCapacityUtilization[] | undefined;
}
export interface QuotaShareCapacityUsage {
    capacityUnit?: string | undefined;
    quantity?: number | undefined;
}
export type QuotaShareCapacityUsageList = QuotaShareCapacityUsage[];
export interface QuotaShareCapacityUtilization {
    quotaShareName?: string | undefined;
    capacityUsage?: QuotaShareCapacityUsage[] | undefined;
}
export type QuotaShareCapacityUtilizationList = QuotaShareCapacityUtilization[];
export interface QuotaShareUtilizationDetail {
    topCapacityUtilization?: QuotaShareCapacityUtilization[] | undefined;
}
export interface QueueSnapshotUtilizationDetail {
    totalCapacityUsage?: QueueSnapshotCapacityUsage[] | undefined;
    fairshareUtilization?: FairshareUtilizationDetail | undefined;
    quotaShareUtilization?: QuotaShareUtilizationDetail | undefined;
    lastUpdatedAt?: number | undefined;
}
export interface GetJobQueueSnapshotResponse {
    frontOfQueue?: FrontOfQueueDetail | undefined;
    frontOfQuotaShares?: FrontOfQuotaSharesDetail | undefined;
    queueUtilization?: QueueSnapshotUtilizationDetail | undefined;
}
export interface KeyValuesPair {
    name?: string | undefined;
    values?: string[] | undefined;
}
export type ListConsumableResourcesFilterList = KeyValuesPair[];
export interface ListConsumableResourcesRequest {
    filters?: KeyValuesPair[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ConsumableResourceSummary {
    consumableResourceArn?: string | undefined;
    consumableResourceName?: string | undefined;
    totalQuantity?: number | undefined;
    inUseQuantity?: number | undefined;
    resourceType?: string | undefined;
}
export type ConsumableResourceSummaryList = ConsumableResourceSummary[];
export interface ListConsumableResourcesResponse {
    consumableResources: (ConsumableResourceSummary & {
        consumableResourceArn: string;
        consumableResourceName: string;
    })[];
    nextToken?: string | undefined;
}
export type ListJobsFilterList = KeyValuesPair[];
export interface ListJobsRequest {
    jobQueue?: string | undefined;
    arrayJobId?: string | undefined;
    multiNodeJobId?: string | undefined;
    jobStatus?: JobStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: KeyValuesPair[] | undefined;
}
export interface JobCapacityUsageSummary {
    capacityUnit?: string | undefined;
    quantity?: number | undefined;
}
export type JobCapacityUsageSummaryList = JobCapacityUsageSummary[];
export interface ContainerSummary {
    exitCode?: number | undefined;
    reason?: string | undefined;
}
export interface ArrayPropertiesSummary {
    size?: number | undefined;
    index?: number | undefined;
    statusSummary?: {
        [key: string]: number | undefined;
    } | undefined;
    statusSummaryLastUpdatedAt?: number | undefined;
}
export interface NodePropertiesSummary {
    isMainNode?: boolean | undefined;
    numNodes?: number | undefined;
    nodeIndex?: number | undefined;
}
export interface JobSummary {
    jobArn?: string | undefined;
    jobId?: string | undefined;
    jobName?: string | undefined;
    capacityUsage?: JobCapacityUsageSummary[] | undefined;
    createdAt?: number | undefined;
    scheduledAt?: number | undefined;
    shareIdentifier?: string | undefined;
    status?: JobStatus | undefined;
    statusReason?: string | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    container?: ContainerSummary | undefined;
    arrayProperties?: ArrayPropertiesSummary | undefined;
    nodeProperties?: NodePropertiesSummary | undefined;
    jobDefinition?: string | undefined;
    isCancelled?: boolean | undefined;
    isTerminated?: boolean | undefined;
}
export type JobSummaryList = JobSummary[];
export interface ListJobsResponse {
    jobSummaryList: (JobSummary & {
        jobId: string;
        jobName: string;
    })[];
    nextToken?: string | undefined;
}
export type ListJobsByConsumableResourceFilterList = KeyValuesPair[];
export interface ListJobsByConsumableResourceRequest {
    consumableResource?: string | undefined;
    filters?: KeyValuesPair[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListJobsByConsumableResourceSummary {
    jobArn?: string | undefined;
    jobQueueArn?: string | undefined;
    jobName?: string | undefined;
    jobDefinitionArn?: string | undefined;
    shareIdentifier?: string | undefined;
    jobStatus?: string | undefined;
    quantity?: number | undefined;
    statusReason?: string | undefined;
    startedAt?: number | undefined;
    createdAt?: number | undefined;
    consumableResourceProperties?: ConsumableResourceProperties | undefined;
}
export type ListJobsByConsumableResourceSummaryList = ListJobsByConsumableResourceSummary[];
export interface ListJobsByConsumableResourceResponse {
    jobs: (ListJobsByConsumableResourceSummary & {
        jobArn: string;
        jobQueueArn: string;
        jobName: string;
        jobStatus: string;
        quantity: number;
        createdAt: number;
        consumableResourceProperties: ConsumableResourceProperties;
    })[];
    nextToken?: string | undefined;
}
export interface ListQuotaSharesRequest {
    jobQueue?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface QuotaShareDetail {
    quotaShareName?: string | undefined;
    quotaShareArn?: string | undefined;
    jobQueueArn?: string | undefined;
    capacityLimits?: QuotaShareCapacityLimit[] | undefined;
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration | undefined;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration | undefined;
    state?: QuotaShareState | undefined;
    status?: QuotaShareStatus | undefined;
}
export type QuotaShareList = QuotaShareDetail[];
export interface ListQuotaSharesResponse {
    quotaShares?: (QuotaShareDetail & {
        capacityLimits: (QuotaShareCapacityLimit & {
            maxCapacity: number;
            capacityUnit: string;
        })[];
        resourceSharingConfiguration: QuotaShareResourceSharingConfiguration & {
            strategy: QuotaShareResourceSharingStrategy;
        };
        preemptionConfiguration: QuotaSharePreemptionConfiguration & {
            inSharePreemption: QuotaShareInSharePreemptionState;
        };
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSchedulingPoliciesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SchedulingPolicyListingDetail {
    arn?: string | undefined;
}
export type SchedulingPolicyListingDetailList = SchedulingPolicyListingDetail[];
export interface ListSchedulingPoliciesResponse {
    schedulingPolicies?: (SchedulingPolicyListingDetail & {
        arn: string;
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface ListServiceJobsRequest {
    jobQueue?: string | undefined;
    jobStatus?: ServiceJobStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: KeyValuesPair[] | undefined;
}
export interface ServiceJobCapacityUsageSummary {
    capacityUnit?: string | undefined;
    quantity?: number | undefined;
}
export type ServiceJobCapacityUsageSummaryList = ServiceJobCapacityUsageSummary[];
export interface ServiceJobSummary {
    latestAttempt?: LatestServiceJobAttempt | undefined;
    capacityUsage?: ServiceJobCapacityUsageSummary[] | undefined;
    createdAt?: number | undefined;
    jobArn?: string | undefined;
    jobId?: string | undefined;
    jobName?: string | undefined;
    scheduledAt?: number | undefined;
    serviceJobType?: ServiceJobType | undefined;
    shareIdentifier?: string | undefined;
    quotaShareName?: string | undefined;
    status?: ServiceJobStatus | undefined;
    statusReason?: string | undefined;
    startedAt?: number | undefined;
    stoppedAt?: number | undefined;
    isTerminated?: boolean | undefined;
}
export type ServiceJobSummaryList = ServiceJobSummary[];
export interface ListServiceJobsResponse {
    jobSummaryList: (ServiceJobSummary & {
        jobId: string;
        jobName: string;
        serviceJobType: ServiceJobType;
        latestAttempt: LatestServiceJobAttempt & {
            serviceResourceId: ServiceResourceId & {
                name: ServiceResourceIdName;
                value: string;
            };
        };
    })[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type JobDefinitionType = "container" | "multinode" | (string & {});
export interface RegisterJobDefinitionRequest {
    jobDefinitionName?: string | undefined;
    type?: JobDefinitionType | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    schedulingPriority?: number | undefined;
    containerProperties?: ContainerProperties | undefined;
    nodeProperties?: NodeProperties | undefined;
    retryStrategy?: RetryStrategy | undefined;
    propagateTags?: boolean | undefined;
    timeout?: JobTimeout | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    platformCapabilities?: PlatformCapability[] | undefined;
    eksProperties?: EksProperties | undefined;
    ecsProperties?: EcsProperties | undefined;
    consumableResourceProperties?: ConsumableResourceProperties | undefined;
}
export interface RegisterJobDefinitionResponse {
    jobDefinitionName: string;
    jobDefinitionArn: string;
    revision: number;
}
export interface ArrayProperties {
    size?: number | undefined;
}
export interface ContainerOverrides {
    vcpus?: number | undefined;
    memory?: number | undefined;
    command?: string[] | undefined;
    instanceType?: string | undefined;
    environment?: KeyValuePair[] | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
}
export interface TaskContainerOverrides {
    command?: string[] | undefined;
    environment?: KeyValuePair[] | undefined;
    name?: string | undefined;
    resourceRequirements?: ResourceRequirement[] | undefined;
}
export type ListTaskContainerOverrides = TaskContainerOverrides[];
export interface TaskPropertiesOverride {
    containers?: TaskContainerOverrides[] | undefined;
}
export type ListTaskPropertiesOverride = TaskPropertiesOverride[];
export interface EcsPropertiesOverride {
    taskProperties?: TaskPropertiesOverride[] | undefined;
}
export interface EksContainerOverride {
    name?: string | undefined;
    image?: string | undefined;
    command?: string[] | undefined;
    args?: string[] | undefined;
    env?: EksContainerEnvironmentVariable[] | undefined;
    resources?: EksContainerResourceRequirements | undefined;
}
export type EksContainerOverrideList = EksContainerOverride[];
export interface EksPodPropertiesOverride {
    containers?: EksContainerOverride[] | undefined;
    initContainers?: EksContainerOverride[] | undefined;
    metadata?: EksMetadata | undefined;
}
export interface EksPropertiesOverride {
    podProperties?: EksPodPropertiesOverride | undefined;
}
export interface NodePropertyOverride {
    targetNodes?: string | undefined;
    containerOverrides?: ContainerOverrides | undefined;
    ecsPropertiesOverride?: EcsPropertiesOverride | undefined;
    instanceTypes?: string[] | undefined;
    eksPropertiesOverride?: EksPropertiesOverride | undefined;
    consumableResourcePropertiesOverride?: ConsumableResourceProperties | undefined;
}
export type NodePropertyOverrides = NodePropertyOverride[];
export interface NodeOverrides {
    numNodes?: number | undefined;
    nodePropertyOverrides?: NodePropertyOverride[] | undefined;
}
export interface SubmitJobRequest {
    jobName?: string | undefined;
    jobQueue?: string | undefined;
    shareIdentifier?: string | undefined;
    schedulingPriorityOverride?: number | undefined;
    arrayProperties?: ArrayProperties | undefined;
    dependsOn?: JobDependency[] | undefined;
    jobDefinition?: string | undefined;
    parameters?: {
        [key: string]: string | undefined;
    } | undefined;
    containerOverrides?: ContainerOverrides | undefined;
    nodeOverrides?: NodeOverrides | undefined;
    retryStrategy?: RetryStrategy | undefined;
    propagateTags?: boolean | undefined;
    timeout?: JobTimeout | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    eksPropertiesOverride?: EksPropertiesOverride | undefined;
    ecsPropertiesOverride?: EcsPropertiesOverride | undefined;
    consumableResourcePropertiesOverride?: ConsumableResourceProperties | undefined;
}
export interface SubmitJobResponse {
    jobArn?: string | undefined;
    jobName: string;
    jobId: string;
}
export type ClientRequestToken = string;
export interface SubmitServiceJobRequest {
    jobName?: string | undefined;
    jobQueue?: string | undefined;
    retryStrategy?: ServiceJobRetryStrategy | undefined;
    schedulingPriority?: number | undefined;
    serviceRequestPayload?: string | undefined;
    serviceJobType?: ServiceJobType | undefined;
    shareIdentifier?: string | undefined;
    quotaShareName?: string | undefined;
    preemptionConfiguration?: ServiceJobPreemptionConfiguration | undefined;
    timeoutConfig?: ServiceJobTimeout | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface SubmitServiceJobResponse {
    jobArn?: string | undefined;
    jobName: string;
    jobId: string;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface TerminateJobRequest {
    jobId?: string | undefined;
    reason?: string | undefined;
}
export interface TerminateJobResponse {
}
export interface TerminateJobsRequest {
    jobs?: string[] | undefined;
    reason?: string | undefined;
}
export interface TerminateJobsErrorDetail {
    job?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type TerminateJobsErrorDetailList = TerminateJobsErrorDetail[];
export interface TerminateJobsResponse {
    successful: string[];
    errors: (TerminateJobsErrorDetail & {
        job: string;
        code: string;
        message: string;
    })[];
}
export interface TerminateServiceJobRequest {
    jobId?: string | undefined;
    reason?: string | undefined;
}
export interface TerminateServiceJobResponse {
}
export interface TerminateServiceJobsRequest {
    jobs?: string[] | undefined;
    reason?: string | undefined;
}
export interface TerminateServiceJobsErrorDetail {
    job?: string | undefined;
    code?: string | undefined;
    message?: string | undefined;
}
export type TerminateServiceJobsErrorDetailList = TerminateServiceJobsErrorDetail[];
export interface TerminateServiceJobsResponse {
    successful: string[];
    errors: (TerminateServiceJobsErrorDetail & {
        job: string;
        code: string;
        message: string;
    })[];
}
export type TagKeysList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export type CRUpdateAllocationStrategy = "BEST_FIT_PROGRESSIVE" | "BEST_FIT_PROGRESSIVE_ORDERED" | "SPOT_CAPACITY_OPTIMIZED" | "SPOT_PRICE_CAPACITY_OPTIMIZED" | "SPOT_CAPACITY_OPTIMIZED_PRIORITIZED" | (string & {});
export interface InstanceLaunchTemplateUpdate {
    ec2InstanceProfileArn?: string | undefined;
    networkConfiguration?: ManagedInstancesNetworkConfiguration | undefined;
    instanceRequirements?: InstanceRequirementsRequest | undefined;
    storageConfiguration?: ManagedInstancesStorageConfiguration | undefined;
    monitoring?: string | undefined;
    capacityReservations?: CapacityReservationRequest | undefined;
    instanceMetadataTagsPropagation?: boolean | undefined;
    localStorageConfiguration?: ManagedInstancesLocalStorageConfiguration | undefined;
}
export interface UpdateManagedInstancesProviderConfiguration {
    propagateTags?: string | undefined;
    infrastructureRoleArn?: string | undefined;
    instanceLaunchTemplate?: InstanceLaunchTemplateUpdate | undefined;
    infrastructureOptimization?: InfrastructureOptimization | undefined;
}
export interface ComputeResourceUpdate {
    minvCpus?: number | undefined;
    maxvCpus?: number | undefined;
    desiredvCpus?: number | undefined;
    subnets?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    allocationStrategy?: CRUpdateAllocationStrategy | undefined;
    instanceTypes?: string[] | undefined;
    ec2KeyPair?: string | undefined;
    instanceRole?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    placementGroup?: string | undefined;
    bidPercentage?: number | undefined;
    launchTemplate?: LaunchTemplateSpecification | undefined;
    ec2Configuration?: Ec2Configuration[] | undefined;
    updateToLatestImageVersion?: boolean | undefined;
    type?: CRType | undefined;
    imageId?: string | undefined;
    scalingPolicy?: ComputeScalingPolicy | undefined;
    managedInstancesProvider?: UpdateManagedInstancesProviderConfiguration | undefined;
    capacityTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EksConfigurationUpdate {
    accessEntry?: EksAccessEntry | undefined;
}
export interface UpdateComputeEnvironmentRequest {
    computeEnvironment?: string | undefined;
    state?: CEState | undefined;
    unmanagedvCpus?: number | undefined;
    computeResources?: ComputeResourceUpdate | undefined;
    serviceRole?: string | undefined;
    updatePolicy?: UpdatePolicy | undefined;
    context?: string | undefined;
    ecsSettings?: EcsSettings | undefined;
    eksConfiguration?: EksConfigurationUpdate | undefined;
}
export interface UpdateComputeEnvironmentResponse {
    computeEnvironmentName?: string | undefined;
    computeEnvironmentArn?: string | undefined;
}
export interface UpdateConsumableResourceRequest {
    consumableResource?: string | undefined;
    operation?: string | undefined;
    quantity?: number | undefined;
    clientToken?: string | undefined;
}
export interface UpdateConsumableResourceResponse {
    consumableResourceName: string;
    consumableResourceArn: string;
    totalQuantity?: number | undefined;
}
export interface UpdateJobQueueRequest {
    jobQueue?: string | undefined;
    state?: JQState | undefined;
    schedulingPolicyArn?: string | undefined;
    priority?: number | undefined;
    computeEnvironmentOrder?: ComputeEnvironmentOrder[] | undefined;
    serviceEnvironmentOrder?: ServiceEnvironmentOrder[] | undefined;
    jobStateTimeLimitActions?: JobStateTimeLimitAction[] | undefined;
}
export interface UpdateJobQueueResponse {
    jobQueueName?: string | undefined;
    jobQueueArn?: string | undefined;
}
export interface UpdateQuotaShareRequest {
    quotaShareArn?: string | undefined;
    capacityLimits?: QuotaShareCapacityLimit[] | undefined;
    resourceSharingConfiguration?: QuotaShareResourceSharingConfiguration | undefined;
    preemptionConfiguration?: QuotaSharePreemptionConfiguration | undefined;
    state?: QuotaShareState | undefined;
}
export interface UpdateQuotaShareResponse {
    quotaShareName?: string | undefined;
    quotaShareArn?: string | undefined;
}
export interface UpdateSchedulingPolicyRequest {
    arn?: string | undefined;
    quotaSharePolicy?: QuotaSharePolicy | undefined;
    fairsharePolicy?: FairsharePolicy | undefined;
}
export interface UpdateSchedulingPolicyResponse {
}
export interface UpdateServiceEnvironmentRequest {
    serviceEnvironment?: string | undefined;
    state?: ServiceEnvironmentState | undefined;
    capacityLimits?: CapacityLimit[] | undefined;
}
export interface UpdateServiceEnvironmentResponse {
    serviceEnvironmentName: string;
    serviceEnvironmentArn: string;
}
export interface UpdateServiceJobRequest {
    jobId?: string | undefined;
    schedulingPriority?: number | undefined;
}
export interface UpdateServiceJobResponse {
    jobArn?: string | undefined;
    jobName?: string | undefined;
    jobId?: string | undefined;
}
export type CancelJobError = ClientException | ServerException | CommonErrors;
/**
 * Cancels a job in an Batch job queue. Jobs that are in a `SUBMITTED`, `PENDING`, or `RUNNABLE` state are cancelled and the job status is updated to `FAILED`.
 *
 * A `PENDING` job is cancelled after all dependency jobs are completed.
 * Therefore, it might take longer than expected to cancel a job in `PENDING`
 * status.
 *
 * When you try to cancel an array parent job in `PENDING`, Batch attempts to
 * cancel all child jobs. The array parent job is cancelled when all child jobs are
 * completed.
 *
 * Jobs that progressed to the `STARTING` or
 * `RUNNING` state aren't cancelled. However, the API operation still succeeds, even
 * if no job is cancelled. These jobs must be terminated with the TerminateJob or
 * TerminateJobs operation.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest & RegionInput, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CancelJobsError = ClientException | ServerException | CommonErrors;
/**
 * Cancels up to 50 jobs in an Batch job queue. This is a bulk version of CancelJob. Jobs that are in a
 * `SUBMITTED`, `PENDING`, or `RUNNABLE` state are cancelled
 * and the job status is updated to `FAILED`.
 *
 * A `PENDING` job is cancelled after all dependency jobs are completed.
 * Therefore, it might take longer than expected to cancel a job in `PENDING`
 * status.
 *
 * When you try to cancel an array parent job in `PENDING`, Batch attempts to
 * cancel all child jobs. The array parent job is cancelled when all child jobs are
 * completed.
 *
 * Jobs that progressed to the `STARTING` or `RUNNING` state aren't
 * cancelled. These jobs must be terminated with the TerminateJob or
 * TerminateJobs operation.
 *
 * Batch reports the result for each job individually in the response. Jobs that
 * were processed successfully are reported in the `successful` list. Jobs that
 * encountered errors are reported in the `errors` list. The response returns an
 * HTTP status code of `200` even when some jobs encountered errors, so check the
 * `errors` list. Jobs that can't be found are treated as successfully
 * processed.
 *
 * This operation requires `batch:CancelJob` permission for each job in the
 * request. There is no separate `batch:CancelJobs` IAM action. If a caller's IAM
 * policy grants `batch:CancelJob`, they can use both the singular
 * CancelJob and bulk `CancelJobs` operations.
 */
export declare const cancelJobs: API.OperationMethod<CancelJobsRequest & RegionInput, CancelJobsResponse, CancelJobsError, Credentials | HttpClient.HttpClient>;
export type CreateComputeEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch compute environment. You can create `MANAGED` or
 * `UNMANAGED` compute environments. `MANAGED` compute environments can
 * use Amazon EC2 or Fargate resources. `UNMANAGED` compute environments can only use
 * EC2 resources.
 *
 * In a managed compute environment, Batch manages the capacity and instance types of the
 * compute resources within the environment. This is based on the compute resource specification
 * that you define or the launch template that you
 * specify when you create the compute environment. Either, you can choose to use EC2 On-Demand
 * Instances and EC2 Spot Instances. Or, you can use Fargate and Fargate Spot capacity in
 * your managed compute environment. You can optionally set a maximum price so that Spot
 * Instances only launch when the Spot Instance price is less than a specified percentage of the
 * On-Demand price.
 *
 * In an unmanaged compute environment, you can manage your own EC2 compute resources and
 * have flexibility with how you configure your compute resources. For example, you can use
 * custom AMIs. However, you must verify that each of your AMIs meet the Amazon ECS container instance
 * AMI specification. For more information, see container instance AMIs in the
 * *Amazon Elastic Container Service Developer Guide*. After you created your unmanaged compute environment,
 * you can use the DescribeComputeEnvironments operation to find the Amazon ECS
 * cluster that's associated with it. Then, launch your container instances into that Amazon ECS
 * cluster. For more information, see Launching an Amazon ECS container
 * instance in the *Amazon Elastic Container Service Developer Guide*.
 *
 * Batch doesn't automatically upgrade the AMIs in a compute environment after it's
 * created. For more information on how to update a compute environment's AMI, see Updating compute environments in the *Batch User Guide*.
 */
export declare const createComputeEnvironment: API.OperationMethod<CreateComputeEnvironmentRequest & RegionInput, CreateComputeEnvironmentResponse, CreateComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch consumable resource.
 */
export declare const createConsumableResource: API.OperationMethod<CreateConsumableResourceRequest & RegionInput, CreateConsumableResourceResponse, CreateConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type CreateJobQueueError = ClientException | ServerException | ComputeEnvironmentNotValid | JobQueueAlreadyExists | CommonErrors;
/**
 * Creates an Batch job queue. When you create a job queue, you associate one or more
 * compute environments to the queue and assign an order of preference for the compute
 * environments.
 *
 * You also set a priority to the job queue that determines the order that the Batch
 * scheduler places jobs onto its associated compute environments. For example, if a compute
 * environment is associated with more than one job queue, the job queue with a higher priority
 * is given preference for scheduling jobs to that compute environment.
 */
export declare const createJobQueue: API.OperationMethod<CreateJobQueueRequest & RegionInput, CreateJobQueueResponse, CreateJobQueueError, Credentials | HttpClient.HttpClient>;
export type CreateQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch quota share. Each quota share operates as a virtual queue with a configured compute capacity, resource sharing strategy, and borrow limits.
 */
export declare const createQuotaShare: API.OperationMethod<CreateQuotaShareRequest & RegionInput, CreateQuotaShareResponse, CreateQuotaShareError, Credentials | HttpClient.HttpClient>;
export type CreateSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Creates an Batch scheduling policy.
 */
export declare const createSchedulingPolicy: API.OperationMethod<CreateSchedulingPolicyRequest & RegionInput, CreateSchedulingPolicyResponse, CreateSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Creates a service environment for running service jobs. Service environments define capacity limits for specific service types such as SageMaker Training jobs.
 */
export declare const createServiceEnvironment: API.OperationMethod<CreateServiceEnvironmentRequest & RegionInput, CreateServiceEnvironmentResponse, CreateServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteComputeEnvironmentError = ClientException | ServerException | ComputeEnvironmentNotFound | ComputeEnvironmentInUse | ComputeEnvironmentBeingModified | CommonErrors;
/**
 * Deletes an Batch compute environment.
 *
 * Before you can delete a compute environment, you must set its state to
 * `DISABLED` with the UpdateComputeEnvironment API operation and
 * disassociate it from any job queues with the UpdateJobQueue API operation.
 * Compute environments that use Fargate resources must terminate all active jobs on that
 * compute environment before deleting the compute environment. If this isn't done, the compute
 * environment enters an invalid state.
 */
export declare const deleteComputeEnvironment: API.OperationMethod<DeleteComputeEnvironmentRequest & RegionInput, DeleteComputeEnvironmentResponse, DeleteComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified consumable resource.
 */
export declare const deleteConsumableResource: API.OperationMethod<DeleteConsumableResourceRequest & RegionInput, DeleteConsumableResourceResponse, DeleteConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteJobQueueError = ClientException | ServerException | JobQueueNotFound | JobQueueBeingModified | CommonErrors;
/**
 * Deletes the specified job queue. You must first disable submissions for a queue with the
 * UpdateJobQueue operation. All jobs in the queue are eventually terminated
 * when you delete a job queue.
 *
 * It's not necessary to disassociate compute environments from a queue before submitting a
 * `DeleteJobQueue` request.
 */
export declare const deleteJobQueue: API.OperationMethod<DeleteJobQueueRequest & RegionInput, DeleteJobQueueResponse, DeleteJobQueueError, Credentials | HttpClient.HttpClient>;
export type DeleteQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified quota share. You must first disable submissions for the share by
 * updating the state to `DISABLED` using the UpdateQuotaShare operation.
 * All jobs in the share are eventually terminated when you delete a quota share.
 */
export declare const deleteQuotaShare: API.OperationMethod<DeleteQuotaShareRequest & RegionInput, DeleteQuotaShareResponse, DeleteQuotaShareError, Credentials | HttpClient.HttpClient>;
export type DeleteSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Deletes the specified scheduling policy.
 *
 * You can't delete a scheduling policy that's used in any job queues.
 */
export declare const deleteSchedulingPolicy: API.OperationMethod<DeleteSchedulingPolicyRequest & RegionInput, DeleteSchedulingPolicyResponse, DeleteSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Deletes a Service environment. Before you can delete a service environment, you must first set its state to `DISABLED` with the `UpdateServiceEnvironment` API operation and disassociate it from any job queues with the `UpdateJobQueue` API operation.
 */
export declare const deleteServiceEnvironment: API.OperationMethod<DeleteServiceEnvironmentRequest & RegionInput, DeleteServiceEnvironmentResponse, DeleteServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeregisterJobDefinitionError = ClientException | ServerException | CommonErrors;
/**
 * Deregisters an Batch job definition. Job definitions are permanently deleted after 180
 * days.
 */
export declare const deregisterJobDefinition: API.OperationMethod<DeregisterJobDefinitionRequest & RegionInput, DeregisterJobDefinitionResponse, DeregisterJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeComputeEnvironmentsError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your compute environments.
 *
 * If you're using an unmanaged compute environment, you can use the
 * `DescribeComputeEnvironment` operation to determine the
 * `ecsClusterArn` that you launch your Amazon ECS container instances into.
 */
export declare const describeComputeEnvironments: API.PaginatedOperationMethod<DescribeComputeEnvironmentsRequest & RegionInput, DescribeComputeEnvironmentsResponse, DescribeComputeEnvironmentsError, Credentials | HttpClient.HttpClient, ComputeEnvironmentDetail>;
export type DescribeConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Returns a description of the specified consumable resource.
 */
export declare const describeConsumableResource: API.OperationMethod<DescribeConsumableResourceRequest & RegionInput, DescribeConsumableResourceResponse, DescribeConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeJobDefinitionsError = ClientException | ServerException | CommonErrors;
/**
 * Describes a list of job definitions. You can specify a `status` (such as
 * `ACTIVE`) to only return job definitions that match that status.
 */
export declare const describeJobDefinitions: API.PaginatedOperationMethod<DescribeJobDefinitionsRequest & RegionInput, DescribeJobDefinitionsResponse, DescribeJobDefinitionsError, Credentials | HttpClient.HttpClient, JobDefinition>;
export type DescribeJobQueuesError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your job queues.
 */
export declare const describeJobQueues: API.PaginatedOperationMethod<DescribeJobQueuesRequest & RegionInput, DescribeJobQueuesResponse, DescribeJobQueuesError, Credentials | HttpClient.HttpClient, JobQueueDetail>;
export type DescribeJobsError = ClientException | ServerException | CommonErrors;
/**
 * Describes a list of Batch jobs.
 */
export declare const describeJobs: API.OperationMethod<DescribeJobsRequest & RegionInput, DescribeJobsResponse, DescribeJobsError, Credentials | HttpClient.HttpClient>;
export type DescribeQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Returns a description of the specified quota share.
 */
export declare const describeQuotaShare: API.OperationMethod<DescribeQuotaShareRequest & RegionInput, DescribeQuotaShareResponse, DescribeQuotaShareError, Credentials | HttpClient.HttpClient>;
export type DescribeSchedulingPoliciesError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your scheduling policies.
 */
export declare const describeSchedulingPolicies: API.OperationMethod<DescribeSchedulingPoliciesRequest & RegionInput, DescribeSchedulingPoliciesResponse, DescribeSchedulingPoliciesError, Credentials | HttpClient.HttpClient>;
export type DescribeServiceEnvironmentsError = ClientException | ServerException | CommonErrors;
/**
 * Describes one or more of your service environments.
 */
export declare const describeServiceEnvironments: API.PaginatedOperationMethod<DescribeServiceEnvironmentsRequest & RegionInput, DescribeServiceEnvironmentsResponse, DescribeServiceEnvironmentsError, Credentials | HttpClient.HttpClient, ServiceEnvironmentDetail>;
export type DescribeServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * The details of a service job.
 */
export declare const describeServiceJob: API.OperationMethod<DescribeServiceJobRequest & RegionInput, DescribeServiceJobResponse, DescribeServiceJobError, Credentials | HttpClient.HttpClient>;
export type GetJobQueueSnapshotError = ClientException | ServerException | CommonErrors;
/**
 * Provides a snapshot of job queue state, including ordering of `RUNNABLE` jobs, as well as capacity utilization for already dispatched jobs.
 * The first 100 `RUNNABLE` jobs in the job queue are listed in order of dispatch. For job queues with an attached
 * quota-share policy, the first `RUNNABLE` job in each quota share is also listed. Capacity utilization for the job queue is provided, as well as
 * break downs by share for job queues with attached fair-share or quota-share scheduling policies.
 */
export declare const getJobQueueSnapshot: API.OperationMethod<GetJobQueueSnapshotRequest & RegionInput, GetJobQueueSnapshotResponse, GetJobQueueSnapshotError, Credentials | HttpClient.HttpClient>;
export type ListConsumableResourcesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch consumable resources.
 */
export declare const listConsumableResources: API.PaginatedOperationMethod<ListConsumableResourcesRequest & RegionInput, ListConsumableResourcesResponse, ListConsumableResourcesError, Credentials | HttpClient.HttpClient, ConsumableResourceSummary>;
export type ListJobsError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch jobs.
 *
 * You must specify only one of the following items:
 *
 * - A job queue ID to return a list of jobs in that job queue
 *
 * - A multi-node parallel job ID to return a list of nodes for that job
 *
 * - An array job ID to return a list of the children for that job
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListJobsByConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch jobs that require a specific consumable resource.
 */
export declare const listJobsByConsumableResource: API.PaginatedOperationMethod<ListJobsByConsumableResourceRequest & RegionInput, ListJobsByConsumableResourceResponse, ListJobsByConsumableResourceError, Credentials | HttpClient.HttpClient, ListJobsByConsumableResourceSummary>;
export type ListQuotaSharesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch quota shares associated with a job queue.
 */
export declare const listQuotaShares: API.PaginatedOperationMethod<ListQuotaSharesRequest & RegionInput, ListQuotaSharesResponse, ListQuotaSharesError, Credentials | HttpClient.HttpClient, QuotaShareDetail>;
export type ListSchedulingPoliciesError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of Batch scheduling policies.
 */
export declare const listSchedulingPolicies: API.PaginatedOperationMethod<ListSchedulingPoliciesRequest & RegionInput, ListSchedulingPoliciesResponse, ListSchedulingPoliciesError, Credentials | HttpClient.HttpClient, SchedulingPolicyListingDetail>;
export type ListServiceJobsError = ClientException | ServerException | CommonErrors;
/**
 * Returns a list of service jobs for a specified job queue.
 */
export declare const listServiceJobs: API.PaginatedOperationMethod<ListServiceJobsRequest & RegionInput, ListServiceJobsResponse, ListServiceJobsError, Credentials | HttpClient.HttpClient, ServiceJobSummary>;
export type ListTagsForResourceError = ClientException | ServerException | CommonErrors;
/**
 * Lists the tags for an Batch resource. Batch resources that support tags are compute environments, jobs, job definitions, job queues,
 * and scheduling policies. ARNs for child jobs of array and multi-node parallel (MNP) jobs aren't supported.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterJobDefinitionError = ClientException | ServerException | CommonErrors;
/**
 * Registers an Batch job definition.
 */
export declare const registerJobDefinition: API.OperationMethod<RegisterJobDefinitionRequest & RegionInput, RegisterJobDefinitionResponse, RegisterJobDefinitionError, Credentials | HttpClient.HttpClient>;
export type SubmitJobError = ClientException | ServerException | CommonErrors;
/**
 * Submits an Batch job from a job definition. Parameters that are specified during SubmitJob override parameters defined in the job definition. vCPU and memory
 * requirements that are specified in the `resourceRequirements` objects in the job
 * definition are the exception. They can't be overridden this way using the `memory`
 * and `vcpus` parameters. Rather, you must specify updates to job definition
 * parameters in a `resourceRequirements` object that's included in the
 * `containerOverrides` parameter.
 *
 * Job queues with a scheduling policy are limited to 500 active share identifiers at
 * a time.
 *
 * Jobs that run on Fargate resources can't be guaranteed to run for more than 14 days.
 * This is because, after 14 days, Fargate resources might become unavailable and job might be
 * terminated.
 */
export declare const submitJob: API.OperationMethod<SubmitJobRequest & RegionInput, SubmitJobResponse, SubmitJobError, Credentials | HttpClient.HttpClient>;
export type SubmitServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Submits a service job to a specified job queue to run on SageMaker AI. A service job is a unit of work that you submit to Batch for execution on SageMaker AI.
 */
export declare const submitServiceJob: API.OperationMethod<SubmitServiceJobRequest & RegionInput, SubmitServiceJobResponse, SubmitServiceJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ClientException | ServerException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource aren't specified in the request parameters, they aren't
 * changed. When a resource is deleted, the tags that are associated with that resource are
 * deleted as well. Batch resources that support tags are compute environments, jobs, job definitions, job queues,
 * and scheduling policies. ARNs for child jobs of array and multi-node parallel (MNP) jobs aren't supported.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TerminateJobError = ClientException | ServerException | CommonErrors;
/**
 * Terminates a job in a job queue. Jobs that are in the `STARTING` or
 * `RUNNING` state are terminated, which causes them to transition to
 * `FAILED`. Jobs that have not progressed to the `STARTING` state are
 * cancelled.
 */
export declare const terminateJob: API.OperationMethod<TerminateJobRequest & RegionInput, TerminateJobResponse, TerminateJobError, Credentials | HttpClient.HttpClient>;
export type TerminateJobsError = ClientException | ServerException | CommonErrors;
/**
 * Terminates up to 50 jobs in a job queue. This is a bulk version of TerminateJob. Jobs that are in the `STARTING` or
 * `RUNNING` state are terminated, which causes them to transition to
 * `FAILED`. Jobs that have not progressed to the `STARTING` state are
 * cancelled.
 *
 * Batch reports the result for each job individually in the response. Jobs that
 * were processed successfully are reported in the `successful` list. Jobs that
 * encountered errors are reported in the `errors` list. The response returns an
 * HTTP status code of `200` even when some jobs encountered errors, so check the
 * `errors` list. Jobs that can't be found are treated as successfully
 * processed.
 *
 * This operation requires `batch:TerminateJob` permission for each job in the
 * request. There is no separate `batch:TerminateJobs` IAM action. If a caller's IAM
 * policy grants `batch:TerminateJob`, they can use both the singular
 * TerminateJob and bulk `TerminateJobs` operations.
 */
export declare const terminateJobs: API.OperationMethod<TerminateJobsRequest & RegionInput, TerminateJobsResponse, TerminateJobsError, Credentials | HttpClient.HttpClient>;
export type TerminateServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Terminates a service job in a job queue.
 */
export declare const terminateServiceJob: API.OperationMethod<TerminateServiceJobRequest & RegionInput, TerminateServiceJobResponse, TerminateServiceJobError, Credentials | HttpClient.HttpClient>;
export type TerminateServiceJobsError = ClientException | ServerException | CommonErrors;
/**
 * Terminates up to 50 service jobs in a job queue. This is a bulk version of TerminateServiceJob.
 *
 * Batch reports the result for each service job individually in the response. Service jobs that were processed successfully are reported in the `successful` list. Service jobs that encountered errors are reported in the `errors` list. The response returns an HTTP status code of `200` even when some service jobs encountered errors, so check the `errors` list. Service jobs that can't be found are treated as successfully processed.
 *
 * This operation requires `batch:TerminateServiceJob` permission for each service job in the
 * request. There is no separate `batch:TerminateServiceJobs` IAM action. If a caller's IAM
 * policy grants `batch:TerminateServiceJob`, they can use both the singular
 * `TerminateServiceJob` and bulk `TerminateServiceJobs` operations.
 */
export declare const terminateServiceJobs: API.OperationMethod<TerminateServiceJobsRequest & RegionInput, TerminateServiceJobsResponse, TerminateServiceJobsError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ClientException | ServerException | CommonErrors;
/**
 * Deletes specified tags from an Batch resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateComputeEnvironmentError = ClientException | ServerException | ComputeEnvironmentNotFound | ComputeEnvironmentBeingModified | CommonErrors;
/**
 * Updates an Batch compute environment.
 */
export declare const updateComputeEnvironment: API.OperationMethod<UpdateComputeEnvironmentRequest & RegionInput, UpdateComputeEnvironmentResponse, UpdateComputeEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateConsumableResourceError = ClientException | ServerException | CommonErrors;
/**
 * Updates a consumable resource.
 */
export declare const updateConsumableResource: API.OperationMethod<UpdateConsumableResourceRequest & RegionInput, UpdateConsumableResourceResponse, UpdateConsumableResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateJobQueueError = ClientException | ServerException | JobQueueNotFound | JobQueueBeingModified | CommonErrors;
/**
 * Updates a job queue.
 */
export declare const updateJobQueue: API.OperationMethod<UpdateJobQueueRequest & RegionInput, UpdateJobQueueResponse, UpdateJobQueueError, Credentials | HttpClient.HttpClient>;
export type UpdateQuotaShareError = ClientException | ServerException | CommonErrors;
/**
 * Updates a quota share.
 */
export declare const updateQuotaShare: API.OperationMethod<UpdateQuotaShareRequest & RegionInput, UpdateQuotaShareResponse, UpdateQuotaShareError, Credentials | HttpClient.HttpClient>;
export type UpdateSchedulingPolicyError = ClientException | ServerException | CommonErrors;
/**
 * Updates a scheduling policy.
 */
export declare const updateSchedulingPolicy: API.OperationMethod<UpdateSchedulingPolicyRequest & RegionInput, UpdateSchedulingPolicyResponse, UpdateSchedulingPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceEnvironmentError = ClientException | ServerException | CommonErrors;
/**
 * Updates a service environment. You can update the state of a service environment from `ENABLED` to `DISABLED` to prevent new service jobs from being placed in the service environment.
 */
export declare const updateServiceEnvironment: API.OperationMethod<UpdateServiceEnvironmentRequest & RegionInput, UpdateServiceEnvironmentResponse, UpdateServiceEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceJobError = ClientException | ServerException | CommonErrors;
/**
 * Updates the priority of a specified service job in an Batch job queue.
 */
export declare const updateServiceJob: API.OperationMethod<UpdateServiceJobRequest & RegionInput, UpdateServiceJobResponse, UpdateServiceJobError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=batch.d.ts.map