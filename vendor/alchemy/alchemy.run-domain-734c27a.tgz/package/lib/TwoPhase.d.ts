import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Aggregate from "./Aggregate.ts";
import type { DecisionKit, DecisionRead, DecisionReceiptJson, DecisionResult, Json } from "./Platform.ts";
import type { TraceJson } from "./Telemetry.ts";
/** An instance's address: its aggregate and id. */
export interface Address {
    readonly aggregate: string;
    readonly id: string;
}
/** What an instance is asked to hold until the decision commits or aborts. */
export interface Prepare {
    /** The attempt this intent belongs to: one per try of a decision. */
    readonly txId: string;
    /** The instance that drives the decision and holds its outcome: the first, in stream order. */
    readonly primary: Address;
    /** The version the instance was read at: it must still have it. */
    readonly version: number;
    /** The events to record on it (encoded); none for one that was only read. */
    readonly events: ReadonlyArray<Json>;
    readonly commandId: string;
    /** Epoch milliseconds the decision was made at: every event's time. */
    readonly now: number;
    readonly correlationId: string;
    readonly trace?: TraceJson;
}
/** What another instance is to record: its address, and its part of the decision. */
export interface Part extends Address {
    readonly version: number;
    readonly events: ReadonlyArray<Json>;
}
/**
 * The whole decision, as the primary holds it: its own part, every other
 * instance's, and the receipt. Enough to finish the commit from storage
 * alone.
 */
export interface Plan extends Prepare {
    /** Every other instance, in stream order. */
    readonly others: ReadonlyArray<Part>;
    /** The decision's receipt, kept under the command id once it commits. */
    readonly receipt: DecisionReceiptJson;
}
/** What became of an attempt. */
export type Outcome = "Committed" | "Aborted";
declare const Unreachable_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Unreachable";
} & Readonly<A>;
/** Another instance couldn't be reached. Before the commit point, that aborts the attempt. */
export declare class Unreachable extends Unreachable_base<{
    readonly cause: unknown;
}> {
}
/** What {@link Participant.read} answers. */
export type ReadResult = 
/** Another decision's intent holds the instance. */
{
    readonly _tag: "Busy";
} | {
    readonly _tag: "Read";
    readonly state: Json;
    readonly version: number;
};
/** What {@link Participant.prepare} answers. */
export type PrepareResult = {
    readonly _tag: "Prepared";
}
/** The instance moved on since it was read. */
 | {
    readonly _tag: "Conflict";
}
/** Another decision's intent holds the instance. */
 | {
    readonly _tag: "Busy";
};
/**
 * Another instance of the decision, as the primary calls it. Every call may
 * be repeated.
 */
export interface Participant {
    /** Its state and version, once any intent it holds is settled. */
    readonly read: Effect.Effect<ReadResult, Unreachable>;
    /** Check its version and hold the intent. */
    readonly prepare: (prepare: Prepare) => Effect.Effect<PrepareResult, Unreachable>;
    /** The attempt committed: turn the intent into events. Nothing, if it holds no such intent. */
    readonly commit: (txId: string) => Effect.Effect<void, Unreachable>;
    /** The attempt aborted: drop the intent. Nothing, if it holds no such intent. */
    readonly abort: (txId: string) => Effect.Effect<void, Unreachable>;
}
/**
 * The primary's own storage. Each call is one atomic step, and the only
 * place a decision's outcome changes.
 */
export interface Primary {
    /**
     * Its state and version, once any intent it holds is settled; `Decided`
     * when the command id already committed here.
     */
    readonly read: (commandId: string) => Effect.Effect<ReadResult | {
        readonly _tag: "Decided";
        readonly receipt: DecisionReceiptJson;
    }>;
    /**
     * Check its own version and hold the plan, with a durable wake-up that
     * finishes it should this call die.
     */
    readonly hold: (plan: Plan) => Effect.Effect<{
        readonly _tag: "Held";
    } | {
        readonly _tag: "Conflict";
    } | {
        readonly _tag: "Busy";
    } | {
        readonly _tag: "Decided";
        readonly receipt: DecisionReceiptJson;
    }>;
    /**
     * The commit point: turn its part into events, keep the receipt, and
     * record `Committed` for the others. `Gone` when it neither holds the
     * attempt nor has it recorded as committed.
     */
    readonly commit: (txId: string) => Effect.Effect<"Committed" | "Gone">;
    /**
     * Give the attempt up, and record `Aborted` for the others. Answers
     * `Committed` when it committed first: then it is delivered, not undone.
     */
    readonly abort: (txId: string) => Effect.Effect<Outcome>;
    /** These instances have the outcome. Once every one has, it is forgotten. */
    readonly delivered: (txId: string, others: ReadonlyArray<Address>) => Effect.Effect<void>;
}
/** What drives a decision: the primary's storage, and the way to each other instance. */
export interface Drive {
    readonly primary: Primary;
    readonly participant: (address: Address) => Participant;
}
/**
 * Tell `others` what became of an attempt, and note who received it. An
 * instance this doesn't reach is told again by the primary's wake-up.
 */
export declare const deliver: (drive: Drive, txId: string, outcome: Outcome, others: ReadonlyArray<Address>) => Effect.Effect<void>;
/**
 * Carry a plan the primary holds to its end: prepare the others, commit, and
 * deliver. Every step may be repeated, so this runs again, unchanged, when
 * the call that started it died, and two runs of it may overlap.
 */
export declare const finish: (drive: Drive, plan: Plan) => Effect.Effect<Outcome>;
/** What the primary is given to decide one command. */
export interface DecideInput {
    readonly kit: DecisionKit;
    readonly command: Json;
    readonly meta: Aggregate.SendMeta;
    readonly drive: Drive;
    /** A fresh id for each attempt. */
    readonly txId: Effect.Effect<string>;
}
/**
 * Decide a command and commit what it records, as the primary: the steps in
 * this module's header. An attempt that loses a race lets go of everything
 * and starts over, against the new states.
 */
export declare const decide: ({ kit, command, meta, drive, txId, }: DecideInput) => Effect.Effect<DecisionResult>;
/** What a commit strategy is given for one send. */
export interface CommitInput {
    readonly kit: DecisionKit;
    readonly command: Json;
    readonly meta: Aggregate.SendMeta;
    /** Ask an instance to decide the command as its primary: see {@link decide}. */
    readonly primary: (read: DecisionRead) => Effect.Effect<DecisionResult>;
}
/** Decide a command and commit what it records, across the instances it reads. */
export type CommitStrategy = (input: CommitInput) => Effect.Effect<DecisionResult>;
/**
 * The two-phase commit described in this module's header: hand the command
 * to the first instance it reads, which drives the rest.
 */
export declare const twoPhase: CommitStrategy;
/**
 * How decisions commit on a platform whose instances each keep their own
 * storage. Two-phase commit by default; provide another strategy to the
 * platform's Layer to replace it.
 */
export declare const DecisionCommit: Context.Reference<CommitStrategy>;
export {};
//# sourceMappingURL=TwoPhase.d.ts.map