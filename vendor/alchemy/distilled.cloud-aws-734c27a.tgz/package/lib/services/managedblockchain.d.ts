import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const IllegalActionException_base: S.TaggedErrorClass<"IllegalActionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IllegalActionException extends /*@__PURE__*/ IllegalActionException_base {
}
declare const InternalServiceErrorException_base: S.TaggedErrorClass<"InternalServiceErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceErrorException extends /*@__PURE__*/ InternalServiceErrorException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceLimitExceededException_base: S.TaggedErrorClass<"ResourceLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceLimitExceededException extends /*@__PURE__*/ ResourceLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotReadyException_base: S.TaggedErrorClass<"ResourceNotReadyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotReadyException extends /*@__PURE__*/ ResourceNotReadyException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type ClientRequestTokenString = string;
export type AccessorType = "BILLING_TOKEN" | (string & {});
export type TagKey = string;
export type TagValue = string;
export type InputTagMap = {
    [key: string]: string | undefined;
};
export type AccessorNetworkType = "ETHEREUM_GOERLI" | "ETHEREUM_MAINNET" | "ETHEREUM_MAINNET_AND_GOERLI" | "POLYGON_MAINNET" | "POLYGON_MUMBAI" | (string & {});
export interface CreateAccessorInput {
    ClientRequestToken: string;
    AccessorType: AccessorType;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkType?: AccessorNetworkType | undefined;
}
export type ResourceIdString = string;
export type AccessorBillingTokenString = string;
export interface CreateAccessorOutput {
    AccessorId?: string | undefined;
    BillingToken?: string | undefined;
    NetworkType?: AccessorNetworkType | undefined;
}
export type NetworkMemberNameString = string;
export type DescriptionString = string;
export type UsernameString = string;
export type PasswordString = string | redacted.Redacted<string>;
export interface MemberFabricConfiguration {
    AdminUsername: string;
    AdminPassword: string | redacted.Redacted<string>;
}
export interface MemberFrameworkConfiguration {
    Fabric?: MemberFabricConfiguration | undefined;
}
export type Enabled = boolean;
export interface LogConfiguration {
    Enabled?: boolean | undefined;
}
export interface LogConfigurations {
    Cloudwatch?: LogConfiguration | undefined;
}
export interface MemberFabricLogPublishingConfiguration {
    CaLogs?: LogConfigurations | undefined;
}
export interface MemberLogPublishingConfiguration {
    Fabric?: MemberFabricLogPublishingConfiguration | undefined;
}
export type ArnString = string;
export interface MemberConfiguration {
    Name: string;
    Description?: string | undefined;
    FrameworkConfiguration: MemberFrameworkConfiguration;
    LogPublishingConfiguration?: MemberLogPublishingConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    KmsKeyArn?: string | undefined;
}
export interface CreateMemberInput {
    ClientRequestToken: string;
    InvitationId: string;
    NetworkId: string;
    MemberConfiguration: MemberConfiguration;
}
export interface CreateMemberOutput {
    MemberId?: string | undefined;
}
export type NameString = string;
export type Framework = "HYPERLEDGER_FABRIC" | "ETHEREUM" | (string & {});
export type FrameworkVersionString = string;
export type Edition = "STARTER" | "STANDARD" | (string & {});
export interface NetworkFabricConfiguration {
    Edition: Edition;
}
export interface NetworkFrameworkConfiguration {
    Fabric?: NetworkFabricConfiguration | undefined;
}
export type ThresholdPercentageInt = number;
export type ProposalDurationInt = number;
export type ThresholdComparator = "GREATER_THAN" | "GREATER_THAN_OR_EQUAL_TO" | (string & {});
export interface ApprovalThresholdPolicy {
    ThresholdPercentage?: number | undefined;
    ProposalDurationInHours?: number | undefined;
    ThresholdComparator?: ThresholdComparator | undefined;
}
export interface VotingPolicy {
    ApprovalThresholdPolicy?: ApprovalThresholdPolicy | undefined;
}
export interface CreateNetworkInput {
    ClientRequestToken: string;
    Name: string;
    Description?: string | undefined;
    Framework: Framework;
    FrameworkVersion: string;
    FrameworkConfiguration?: NetworkFrameworkConfiguration | undefined;
    VotingPolicy: VotingPolicy;
    MemberConfiguration: MemberConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateNetworkOutput {
    NetworkId?: string | undefined;
    MemberId?: string | undefined;
}
export type InstanceTypeString = string;
export type AvailabilityZoneString = string;
export interface NodeFabricLogPublishingConfiguration {
    ChaincodeLogs?: LogConfigurations | undefined;
    PeerLogs?: LogConfigurations | undefined;
}
export interface NodeLogPublishingConfiguration {
    Fabric?: NodeFabricLogPublishingConfiguration | undefined;
}
export type StateDBType = "LevelDB" | "CouchDB" | (string & {});
export interface NodeConfiguration {
    InstanceType: string;
    AvailabilityZone?: string | undefined;
    LogPublishingConfiguration?: NodeLogPublishingConfiguration | undefined;
    StateDB?: StateDBType | undefined;
}
export interface CreateNodeInput {
    ClientRequestToken: string;
    NetworkId: string;
    MemberId?: string | undefined;
    NodeConfiguration: NodeConfiguration;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateNodeOutput {
    NodeId?: string | undefined;
}
export type PrincipalString = string;
export interface InviteAction {
    Principal: string;
}
export type InviteActionList = InviteAction[];
export interface RemoveAction {
    MemberId: string;
}
export type RemoveActionList = RemoveAction[];
export interface ProposalActions {
    Invitations?: InviteAction[] | undefined;
    Removals?: RemoveAction[] | undefined;
}
export interface CreateProposalInput {
    ClientRequestToken: string;
    NetworkId: string;
    MemberId: string;
    Actions: ProposalActions;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateProposalOutput {
    ProposalId?: string | undefined;
}
export interface DeleteAccessorInput {
    AccessorId: string;
}
export interface DeleteAccessorOutput {
}
export interface DeleteMemberInput {
    NetworkId: string;
    MemberId: string;
}
export interface DeleteMemberOutput {
}
export interface DeleteNodeInput {
    NetworkId: string;
    MemberId?: string | undefined;
    NodeId: string;
}
export interface DeleteNodeOutput {
}
export interface GetAccessorInput {
    AccessorId: string;
}
export type AccessorStatus = "AVAILABLE" | "PENDING_DELETION" | "DELETED" | (string & {});
export type OutputTagMap = {
    [key: string]: string | undefined;
};
export interface Accessor {
    Id?: string | undefined;
    Type?: AccessorType | undefined;
    BillingToken?: string | undefined;
    Status?: AccessorStatus | undefined;
    CreationDate?: Date | undefined;
    Arn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    NetworkType?: AccessorNetworkType | undefined;
}
export interface GetAccessorOutput {
    Accessor?: Accessor | undefined;
}
export interface GetMemberInput {
    NetworkId: string;
    MemberId: string;
}
export interface MemberFabricAttributes {
    AdminUsername?: string | undefined;
    CaEndpoint?: string | undefined;
}
export interface MemberFrameworkAttributes {
    Fabric?: MemberFabricAttributes | undefined;
}
export type MemberStatus = "CREATING" | "AVAILABLE" | "CREATE_FAILED" | "UPDATING" | "DELETING" | "DELETED" | "INACCESSIBLE_ENCRYPTION_KEY" | (string & {});
export interface Member {
    NetworkId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    FrameworkAttributes?: MemberFrameworkAttributes | undefined;
    LogPublishingConfiguration?: MemberLogPublishingConfiguration | undefined;
    Status?: MemberStatus | undefined;
    CreationDate?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export interface GetMemberOutput {
    Member?: Member | undefined;
}
export interface GetNetworkInput {
    NetworkId: string;
}
export interface NetworkFabricAttributes {
    OrderingServiceEndpoint?: string | undefined;
    Edition?: Edition | undefined;
}
export interface NetworkEthereumAttributes {
    ChainId?: string | undefined;
}
export interface NetworkFrameworkAttributes {
    Fabric?: NetworkFabricAttributes | undefined;
    Ethereum?: NetworkEthereumAttributes | undefined;
}
export type NetworkStatus = "CREATING" | "AVAILABLE" | "CREATE_FAILED" | "DELETING" | "DELETED" | (string & {});
export interface Network {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Framework?: Framework | undefined;
    FrameworkVersion?: string | undefined;
    FrameworkAttributes?: NetworkFrameworkAttributes | undefined;
    VpcEndpointServiceName?: string | undefined;
    VotingPolicy?: VotingPolicy | undefined;
    Status?: NetworkStatus | undefined;
    CreationDate?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
}
export interface GetNetworkOutput {
    Network?: Network | undefined;
}
export interface GetNodeInput {
    NetworkId: string;
    MemberId?: string | undefined;
    NodeId: string;
}
export interface NodeFabricAttributes {
    PeerEndpoint?: string | undefined;
    PeerEventEndpoint?: string | undefined;
}
export interface NodeEthereumAttributes {
    HttpEndpoint?: string | undefined;
    WebSocketEndpoint?: string | undefined;
}
export interface NodeFrameworkAttributes {
    Fabric?: NodeFabricAttributes | undefined;
    Ethereum?: NodeEthereumAttributes | undefined;
}
export type NodeStatus = "CREATING" | "AVAILABLE" | "UNHEALTHY" | "CREATE_FAILED" | "UPDATING" | "DELETING" | "DELETED" | "FAILED" | "INACCESSIBLE_ENCRYPTION_KEY" | (string & {});
export interface Node {
    NetworkId?: string | undefined;
    MemberId?: string | undefined;
    Id?: string | undefined;
    InstanceType?: string | undefined;
    AvailabilityZone?: string | undefined;
    FrameworkAttributes?: NodeFrameworkAttributes | undefined;
    LogPublishingConfiguration?: NodeLogPublishingConfiguration | undefined;
    StateDB?: StateDBType | undefined;
    Status?: NodeStatus | undefined;
    CreationDate?: Date | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
    KmsKeyArn?: string | undefined;
}
export interface GetNodeOutput {
    Node?: Node | undefined;
}
export interface GetProposalInput {
    NetworkId: string;
    ProposalId: string;
}
export type ProposalStatus = "IN_PROGRESS" | "APPROVED" | "REJECTED" | "EXPIRED" | "ACTION_FAILED" | (string & {});
export type VoteCount = number;
export interface Proposal {
    ProposalId?: string | undefined;
    NetworkId?: string | undefined;
    Description?: string | undefined;
    Actions?: ProposalActions | undefined;
    ProposedByMemberId?: string | undefined;
    ProposedByMemberName?: string | undefined;
    Status?: ProposalStatus | undefined;
    CreationDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    YesVoteCount?: number | undefined;
    NoVoteCount?: number | undefined;
    OutstandingVoteCount?: number | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    Arn?: string | undefined;
}
export interface GetProposalOutput {
    Proposal?: Proposal | undefined;
}
export type AccessorListMaxResults = number;
export type PaginationToken = string;
export interface ListAccessorsInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    NetworkType?: AccessorNetworkType | undefined;
}
export interface AccessorSummary {
    Id?: string | undefined;
    Type?: AccessorType | undefined;
    Status?: AccessorStatus | undefined;
    CreationDate?: Date | undefined;
    Arn?: string | undefined;
    NetworkType?: AccessorNetworkType | undefined;
}
export type AccessorSummaryList = AccessorSummary[];
export interface ListAccessorsOutput {
    Accessors?: AccessorSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ProposalListMaxResults = number;
export interface ListInvitationsInput {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InvitationStatus = "PENDING" | "ACCEPTED" | "ACCEPTING" | "REJECTED" | "EXPIRED" | (string & {});
export interface NetworkSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Framework?: Framework | undefined;
    FrameworkVersion?: string | undefined;
    Status?: NetworkStatus | undefined;
    CreationDate?: Date | undefined;
    Arn?: string | undefined;
}
export interface Invitation {
    InvitationId?: string | undefined;
    CreationDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    Status?: InvitationStatus | undefined;
    NetworkSummary?: NetworkSummary | undefined;
    Arn?: string | undefined;
}
export type InvitationList = Invitation[];
export interface ListInvitationsOutput {
    Invitations?: Invitation[] | undefined;
    NextToken?: string | undefined;
}
export type IsOwned = boolean;
export type MemberListMaxResults = number;
export interface ListMembersInput {
    NetworkId: string;
    Name?: string | undefined;
    Status?: MemberStatus | undefined;
    IsOwned?: boolean | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface MemberSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Status?: MemberStatus | undefined;
    CreationDate?: Date | undefined;
    IsOwned?: boolean | undefined;
    Arn?: string | undefined;
}
export type MemberSummaryList = MemberSummary[];
export interface ListMembersOutput {
    Members?: MemberSummary[] | undefined;
    NextToken?: string | undefined;
}
export type NetworkListMaxResults = number;
export interface ListNetworksInput {
    Name?: string | undefined;
    Framework?: Framework | undefined;
    Status?: NetworkStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type NetworkSummaryList = NetworkSummary[];
export interface ListNetworksOutput {
    Networks?: NetworkSummary[] | undefined;
    NextToken?: string | undefined;
}
export type NodeListMaxResults = number;
export interface ListNodesInput {
    NetworkId: string;
    MemberId?: string | undefined;
    Status?: NodeStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface NodeSummary {
    Id?: string | undefined;
    Status?: NodeStatus | undefined;
    CreationDate?: Date | undefined;
    AvailabilityZone?: string | undefined;
    InstanceType?: string | undefined;
    Arn?: string | undefined;
}
export type NodeSummaryList = NodeSummary[];
export interface ListNodesOutput {
    Nodes?: NodeSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProposalsInput {
    NetworkId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ProposalSummary {
    ProposalId?: string | undefined;
    Description?: string | undefined;
    ProposedByMemberId?: string | undefined;
    ProposedByMemberName?: string | undefined;
    Status?: ProposalStatus | undefined;
    CreationDate?: Date | undefined;
    ExpirationDate?: Date | undefined;
    Arn?: string | undefined;
}
export type ProposalSummaryList = ProposalSummary[];
export interface ListProposalsOutput {
    Proposals?: ProposalSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProposalVotesInput {
    NetworkId: string;
    ProposalId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type VoteValue = "YES" | "NO" | (string & {});
export interface VoteSummary {
    Vote?: VoteValue | undefined;
    MemberName?: string | undefined;
    MemberId?: string | undefined;
}
export type ProposalVoteList = VoteSummary[];
export interface ListProposalVotesOutput {
    ProposalVotes?: VoteSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RejectInvitationInput {
    InvitationId: string;
}
export interface RejectInvitationOutput {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateMemberInput {
    NetworkId: string;
    MemberId: string;
    LogPublishingConfiguration?: MemberLogPublishingConfiguration | undefined;
}
export interface UpdateMemberOutput {
}
export interface UpdateNodeInput {
    NetworkId: string;
    MemberId?: string | undefined;
    NodeId: string;
    LogPublishingConfiguration?: NodeLogPublishingConfiguration | undefined;
}
export interface UpdateNodeOutput {
}
export interface VoteOnProposalInput {
    NetworkId: string;
    ProposalId: string;
    VoterMemberId: string;
    Vote: VoteValue;
}
export interface VoteOnProposalOutput {
}
export type ExceptionMessage = string;
export type CreateAccessorError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a new accessor for use with Amazon Managed Blockchain service that supports token based access.
 * The accessor contains information required for token based access.
 */
export declare const createAccessor: API.OperationMethod<CreateAccessorInput & RegionInput, CreateAccessorOutput, CreateAccessorError, Credentials | HttpClient.HttpClient>;
export type CreateMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a member within a Managed Blockchain network.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const createMember: API.OperationMethod<CreateMemberInput & RegionInput, CreateMemberOutput, CreateMemberError, Credentials | HttpClient.HttpClient>;
export type CreateNetworkError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a new blockchain network using Amazon Managed Blockchain.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const createNetwork: API.OperationMethod<CreateNetworkInput & RegionInput, CreateNetworkOutput, CreateNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceAlreadyExistsException | ResourceLimitExceededException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a node on the specified blockchain network.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const createNode: API.OperationMethod<CreateNodeInput & RegionInput, CreateNodeOutput, CreateNodeError, Credentials | HttpClient.HttpClient>;
export type CreateProposalError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | TooManyTagsException | CommonErrors;
/**
 * Creates a proposal for a change to the network that other members of the network can vote on, for example, a proposal to add a new member to the network. Any member can create a proposal.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const createProposal: API.OperationMethod<CreateProposalInput & RegionInput, CreateProposalOutput, CreateProposalError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessorError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an accessor that your Amazon Web Services account owns. An accessor object is a container that has the
 * information required for token based access to your Ethereum nodes including, the
 * `BILLING_TOKEN`. After an accessor is deleted, the status of the accessor changes
 * from `AVAILABLE` to `PENDING_DELETION`. An accessor in the
 * `PENDING_DELETION` state can't be used for new WebSocket requests or
 * HTTP requests. However, WebSocket connections that were initiated while the accessor was in the
 * `AVAILABLE` state remain open until they expire (up to 2 hours).
 */
export declare const deleteAccessor: API.OperationMethod<DeleteAccessorInput & RegionInput, DeleteAccessorOutput, DeleteAccessorError, Credentials | HttpClient.HttpClient>;
export type DeleteMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | CommonErrors;
/**
 * Deletes a member. Deleting a member removes the member and all associated resources from the network. `DeleteMember` can only be called for a specified `MemberId` if the principal performing the action is associated with the Amazon Web Services account that owns the member. In all other cases, the `DeleteMember` action is carried out as the result of an approved proposal to remove a member. If `MemberId` is the last member in a network specified by the last Amazon Web Services account, the network is deleted also.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const deleteMember: API.OperationMethod<DeleteMemberInput & RegionInput, DeleteMemberOutput, DeleteMemberError, Credentials | HttpClient.HttpClient>;
export type DeleteNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | ThrottlingException | CommonErrors;
/**
 * Deletes a node that your Amazon Web Services account owns. All data on the node is lost and cannot be recovered.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const deleteNode: API.OperationMethod<DeleteNodeInput & RegionInput, DeleteNodeOutput, DeleteNodeError, Credentials | HttpClient.HttpClient>;
export type GetAccessorError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about an accessor. An accessor object is a container that has the
 * information required for token based access to your Ethereum nodes.
 */
export declare const getAccessor: API.OperationMethod<GetAccessorInput & RegionInput, GetAccessorOutput, GetAccessorError, Credentials | HttpClient.HttpClient>;
export type GetMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a member.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const getMember: API.OperationMethod<GetMemberInput & RegionInput, GetMemberOutput, GetMemberError, Credentials | HttpClient.HttpClient>;
export type GetNetworkError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a network.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const getNetwork: API.OperationMethod<GetNetworkInput & RegionInput, GetNetworkOutput, GetNetworkError, Credentials | HttpClient.HttpClient>;
export type GetNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a node.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const getNode: API.OperationMethod<GetNodeInput & RegionInput, GetNodeOutput, GetNodeError, Credentials | HttpClient.HttpClient>;
export type GetProposalError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns detailed information about a proposal.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const getProposal: API.OperationMethod<GetProposalInput & RegionInput, GetProposalOutput, GetProposalError, Credentials | HttpClient.HttpClient>;
export type ListAccessorsError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns a list of the accessors and their properties. Accessor objects are containers that have the
 * information required for token based access to your Ethereum nodes.
 */
export declare const listAccessors: API.PaginatedOperationMethod<ListAccessorsInput & RegionInput, ListAccessorsOutput, ListAccessorsError, Credentials | HttpClient.HttpClient, AccessorSummary>;
export type ListInvitationsError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceLimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all invitations for the current Amazon Web Services account.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsInput & RegionInput, ListInvitationsOutput, ListInvitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMembersError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns a list of the members in a network and properties of their configurations.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersInput & RegionInput, ListMembersOutput, ListMembersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNetworksError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns information about the networks in which the current Amazon Web Services account participates.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const listNetworks: API.PaginatedOperationMethod<ListNetworksInput & RegionInput, ListNetworksOutput, ListNetworksError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNodesError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns information about the nodes within a network.
 *
 * Applies to Hyperledger Fabric and Ethereum.
 */
export declare const listNodes: API.PaginatedOperationMethod<ListNodesInput & RegionInput, ListNodesOutput, ListNodesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProposalsError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns a list of proposals for the network.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listProposals: API.PaginatedOperationMethod<ListProposalsInput & RegionInput, ListProposalsOutput, ListProposalsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProposalVotesError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Returns the list of votes for a specified proposal, including the value of each vote and the unique identifier of the member that cast the vote.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const listProposalVotes: API.PaginatedOperationMethod<ListProposalVotesInput & RegionInput, ListProposalVotesOutput, ListProposalVotesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | CommonErrors;
/**
 * Returns a list of tags for the specified resource. Each tag consists of a key and optional value.
 *
 * For more information about tags, see Tagging Resources in the *Amazon Managed Blockchain Ethereum Developer Guide*, or Tagging Resources in the *Amazon Managed Blockchain Hyperledger Fabric Developer Guide*.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RejectInvitationError = AccessDeniedException | IllegalActionException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Rejects an invitation to join a network. This action can be called by a principal in an Amazon Web Services account that has received an invitation to create a member and join a network.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const rejectInvitation: API.OperationMethod<RejectInvitationInput & RegionInput, RejectInvitationOutput, RejectInvitationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | TooManyTagsException | CommonErrors;
/**
 * Adds or overwrites the specified tags for the specified Amazon Managed Blockchain resource. Each tag consists of a key and optional value.
 *
 * When you specify a tag key that already exists, the tag value is overwritten with the new value. Use `UntagResource` to remove tag keys.
 *
 * A resource can have up to 50 tags. If you try to create more than 50 tags for a resource, your request fails and returns an error.
 *
 * For more information about tags, see Tagging Resources in the *Amazon Managed Blockchain Ethereum Developer Guide*, or Tagging Resources in the *Amazon Managed Blockchain Hyperledger Fabric Developer Guide*.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ResourceNotReadyException | CommonErrors;
/**
 * Removes the specified tags from the Amazon Managed Blockchain resource.
 *
 * For more information about tags, see Tagging Resources in the *Amazon Managed Blockchain Ethereum Developer Guide*, or Tagging Resources in the *Amazon Managed Blockchain Hyperledger Fabric Developer Guide*.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMemberError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a member configuration with new parameters.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const updateMember: API.OperationMethod<UpdateMemberInput & RegionInput, UpdateMemberOutput, UpdateMemberError, Credentials | HttpClient.HttpClient>;
export type UpdateNodeError = AccessDeniedException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a node configuration with new parameters.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const updateNode: API.OperationMethod<UpdateNodeInput & RegionInput, UpdateNodeOutput, UpdateNodeError, Credentials | HttpClient.HttpClient>;
export type VoteOnProposalError = AccessDeniedException | IllegalActionException | InternalServiceErrorException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Casts a vote for a specified `ProposalId` on behalf of a member. The member to vote as, specified by `VoterMemberId`, must be in the same Amazon Web Services account as the principal that calls the action.
 *
 * Applies only to Hyperledger Fabric.
 */
export declare const voteOnProposal: API.OperationMethod<VoteOnProposalInput & RegionInput, VoteOnProposalOutput, VoteOnProposalError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=managedblockchain.d.ts.map