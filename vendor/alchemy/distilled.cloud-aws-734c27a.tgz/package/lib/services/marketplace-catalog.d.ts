import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceNotSupportedException_base: S.TaggedErrorClass<"ResourceNotSupportedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotSupportedException extends /*@__PURE__*/ ResourceNotSupportedException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly ValidationExceptionFieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Catalog = string;
export type EntityId = string;
export interface EntityRequest {
    Catalog: string;
    EntityId: string;
}
export type EntityRequestList = EntityRequest[];
export interface BatchDescribeEntitiesRequest {
    EntityRequestList: EntityRequest[];
}
export type EntityType = string;
export type ARN = string;
export type Identifier = string;
export type DateTimeISO8601 = string;
export type JsonDocumentType = unknown;
export interface EntityDetail {
    EntityType?: string | undefined;
    EntityArn?: string | undefined;
    EntityIdentifier?: string | undefined;
    LastModifiedDate?: string | undefined;
    DetailsDocument?: any | undefined;
}
export type EntityDetails = {
    [key: string]: EntityDetail | undefined;
};
export type BatchDescribeErrorCodeString = string;
export type BatchDescribeErrorMessageContent = string;
export interface BatchDescribeErrorDetail {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type Errors = {
    [key: string]: BatchDescribeErrorDetail | undefined;
};
export interface BatchDescribeEntitiesResponse {
    EntityDetails?: {
        [key: string]: EntityDetail | undefined;
    } | undefined;
    Errors?: {
        [key: string]: BatchDescribeErrorDetail | undefined;
    } | undefined;
}
export type ResourceId = string;
export interface CancelChangeSetRequest {
    Catalog: string;
    ChangeSetId: string;
}
export interface CancelChangeSetResponse {
    ChangeSetId?: string | undefined;
    ChangeSetArn?: string | undefined;
}
export type ResourceARN = string;
export interface DeleteResourcePolicyRequest {
    ResourceArn: string;
}
export interface DeleteResourcePolicyResponse {
}
export type AssessmentIdentifier = string;
export type DescribeAssessmentMaxResultInteger = number;
export type NextToken = string;
export interface DescribeAssessmentRequest {
    Catalog: string;
    AssessmentIdentifier: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type VersionedFrameworkId = string;
export interface AssessmentTargetSummary {
    EntityId?: string | undefined;
    ChangeSetId?: string | undefined;
}
export interface AMISecuritySummary {
    DeliveryOptionId?: string | undefined;
}
export interface ContainerSecuritySummary {
    DeliveryOptionId?: string | undefined;
}
export type FrameworkSummary = {
    AMISecuritySummary: AMISecuritySummary;
    ContainerSecuritySummary?: undefined;
} | {
    AMISecuritySummary?: undefined;
    ContainerSecuritySummary: ContainerSecuritySummary;
};
export type AssessmentResult = "PASS" | "FAIL" | (string & {});
export type ControlAssessmentResult = "PASS" | "FAIL" | "NOT_EXECUTED" | "EXEMPTION_PASS" | (string & {});
export type ErrorCode = string;
export type ErrorMessage = string;
export type ScopeName = string;
export type ScopeValue = string;
export interface ErrorScope {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type ErrorScopeList = ErrorScope[];
export interface ControlError {
    Code?: string | undefined;
    Message?: string | undefined;
    Scope?: ErrorScope[] | undefined;
}
export type ControlErrorList = ControlError[];
export interface ControlAssessment {
    ControlId?: string | undefined;
    ControlAssessmentResult?: ControlAssessmentResult | undefined;
    Errors?: ControlError[] | undefined;
}
export type ControlAssessmentList = ControlAssessment[];
export interface DescribeAssessmentResponse {
    AssessmentArn?: string | undefined;
    AssessmentId?: string | undefined;
    FrameworkId?: string | undefined;
    AssessmentTargetSummary?: AssessmentTargetSummary | undefined;
    FrameworkSummary?: FrameworkSummary | undefined;
    AssessmentResult?: AssessmentResult | undefined;
    CreatedAt?: string | undefined;
    ExpiresAt?: string | undefined;
    ControlAssessments?: ControlAssessment[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeChangeSetRequest {
    Catalog: string;
    ChangeSetId: string;
}
export type ChangeSetName = string;
export type Intent = "VALIDATE" | "APPLY" | (string & {});
export type ChangeStatus = "PREPARING" | "APPLYING" | "SUCCEEDED" | "CANCELLED" | "FAILED" | (string & {});
export type FailureCode = "CLIENT_ERROR" | "SERVER_FAULT" | (string & {});
export type ExceptionMessageContent = string;
export type ChangeType = string;
export interface Entity {
    Type: string;
    Identifier?: string | undefined;
}
export type Json = string;
export type ErrorCodeString = string;
export interface ErrorDetail {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type ErrorDetailList = ErrorDetail[];
export type ChangeName = string;
export interface ChangeSummary {
    ChangeType?: string | undefined;
    Entity?: Entity | undefined;
    Details?: string | undefined;
    DetailsDocument?: any | undefined;
    ErrorDetailList?: ErrorDetail[] | undefined;
    ChangeName?: string | undefined;
}
export type ChangeSetDescription = ChangeSummary[];
export interface DescribeChangeSetResponse {
    ChangeSetId?: string | undefined;
    ChangeSetArn?: string | undefined;
    ChangeSetName?: string | undefined;
    Intent?: Intent | undefined;
    StartTime?: string | undefined;
    EndTime?: string | undefined;
    Status?: ChangeStatus | undefined;
    FailureCode?: FailureCode | undefined;
    FailureDescription?: string | undefined;
    ChangeSet?: ChangeSummary[] | undefined;
}
export interface DescribeEntityRequest {
    Catalog: string;
    EntityId: string;
}
export interface DescribeEntityResponse {
    EntityType?: string | undefined;
    EntityIdentifier?: string | undefined;
    EntityArn?: string | undefined;
    LastModifiedDate?: string | undefined;
    Details?: string | undefined;
    DetailsDocument?: any | undefined;
}
export interface GetResourcePolicyRequest {
    ResourceArn: string;
}
export type ResourcePolicyJson = string;
export interface GetResourcePolicyResponse {
    Policy?: string | undefined;
}
export type FrameworkId = string;
export interface AssessmentTargetFilter {
    EntityId?: string | undefined;
    ChangeSetId?: string | undefined;
}
export interface AMISecurityFilters {
    DeliveryOptionId?: string | undefined;
}
export interface ContainerSecurityFilters {
    DeliveryOptionId?: string | undefined;
}
export type FrameworkFilters = {
    AMISecurityFilters: AMISecurityFilters;
    ContainerSecurityFilters?: undefined;
} | {
    AMISecurityFilters?: undefined;
    ContainerSecurityFilters: ContainerSecurityFilters;
};
export type ListAssessmentsMaxResultInteger = number;
export interface ListAssessmentsRequest {
    Catalog: string;
    FrameworkId?: string | undefined;
    AssessmentTargetFilter?: AssessmentTargetFilter | undefined;
    FrameworkFilters?: FrameworkFilters | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AssessmentSummary {
    AssessmentArn?: string | undefined;
    AssessmentId?: string | undefined;
    FrameworkId?: string | undefined;
    AssessmentTargetSummary?: AssessmentTargetSummary | undefined;
    FrameworkSummary?: FrameworkSummary | undefined;
    AssessmentResult?: AssessmentResult | undefined;
    CreatedAt?: string | undefined;
    ExpiresAt?: string | undefined;
}
export type AssessmentSummaryList = AssessmentSummary[];
export interface ListAssessmentsResponse {
    AssessmentSummaryList?: AssessmentSummary[] | undefined;
    NextToken?: string | undefined;
}
export type FilterName = string;
export type FilterValueContent = string;
export type ValueList = string[];
export interface Filter {
    Name?: string | undefined;
    ValueList?: string[] | undefined;
}
export type FilterList = Filter[];
export type SortBy = string;
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface Sort {
    SortBy?: string | undefined;
    SortOrder?: SortOrder | undefined;
}
export type ListChangeSetsMaxResultInteger = number;
export interface ListChangeSetsRequest {
    Catalog: string;
    FilterList?: Filter[] | undefined;
    Sort?: Sort | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ResourceIdList = string[];
export interface ChangeSetSummaryListItem {
    ChangeSetId?: string | undefined;
    ChangeSetArn?: string | undefined;
    ChangeSetName?: string | undefined;
    StartTime?: string | undefined;
    EndTime?: string | undefined;
    Status?: ChangeStatus | undefined;
    EntityIdList?: string[] | undefined;
    FailureCode?: FailureCode | undefined;
}
export type ChangeSetSummaryList = ChangeSetSummaryListItem[];
export interface ListChangeSetsResponse {
    ChangeSetSummaryList?: ChangeSetSummaryListItem[] | undefined;
    NextToken?: string | undefined;
}
export type ListEntitiesMaxResultInteger = number;
export type OwnershipType = "SELF" | "SHARED" | (string & {});
export type DataProductEntityIdString = string;
export type DataProductEntityIdFilterValueList = string[];
export interface DataProductEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type DataProductTitleString = string;
export type DataProductTitleFilterValueList = string[];
export interface DataProductTitleFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type DataProductVisibilityString = "Limited" | "Public" | "Restricted" | "Unavailable" | "Draft" | (string & {});
export type DataProductVisibilityFilterValueList = DataProductVisibilityString[];
export interface DataProductVisibilityFilter {
    ValueList?: DataProductVisibilityString[] | undefined;
}
export interface DataProductLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface DataProductLastModifiedDateFilter {
    DateRange?: DataProductLastModifiedDateFilterDateRange | undefined;
}
export interface DataProductFilters {
    EntityId?: DataProductEntityIdFilter | undefined;
    ProductTitle?: DataProductTitleFilter | undefined;
    Visibility?: DataProductVisibilityFilter | undefined;
    LastModifiedDate?: DataProductLastModifiedDateFilter | undefined;
}
export type SaaSProductEntityIdString = string;
export type SaaSProductEntityIdFilterValueList = string[];
export interface SaaSProductEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type SaaSProductTitleString = string;
export type SaaSProductTitleFilterValueList = string[];
export interface SaaSProductTitleFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type SaaSProductVisibilityString = "Limited" | "Public" | "Restricted" | "Draft" | (string & {});
export type SaaSProductVisibilityFilterValueList = SaaSProductVisibilityString[];
export interface SaaSProductVisibilityFilter {
    ValueList?: SaaSProductVisibilityString[] | undefined;
}
export interface SaaSProductLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface SaaSProductLastModifiedDateFilter {
    DateRange?: SaaSProductLastModifiedDateFilterDateRange | undefined;
}
export interface SaaSProductFilters {
    EntityId?: SaaSProductEntityIdFilter | undefined;
    ProductTitle?: SaaSProductTitleFilter | undefined;
    Visibility?: SaaSProductVisibilityFilter | undefined;
    LastModifiedDate?: SaaSProductLastModifiedDateFilter | undefined;
}
export type AmiProductEntityIdString = string;
export type AmiProductEntityIdFilterValueList = string[];
export interface AmiProductEntityIdFilter {
    ValueList?: string[] | undefined;
}
export interface AmiProductLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface AmiProductLastModifiedDateFilter {
    DateRange?: AmiProductLastModifiedDateFilterDateRange | undefined;
}
export type AmiProductTitleString = string;
export type AmiProductTitleFilterValueList = string[];
export interface AmiProductTitleFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type AmiProductVisibilityString = "Limited" | "Public" | "Restricted" | "Draft" | (string & {});
export type AmiProductVisibilityFilterValueList = AmiProductVisibilityString[];
export interface AmiProductVisibilityFilter {
    ValueList?: AmiProductVisibilityString[] | undefined;
}
export interface AmiProductFilters {
    EntityId?: AmiProductEntityIdFilter | undefined;
    LastModifiedDate?: AmiProductLastModifiedDateFilter | undefined;
    ProductTitle?: AmiProductTitleFilter | undefined;
    Visibility?: AmiProductVisibilityFilter | undefined;
}
export type OfferEntityIdString = string;
export type OfferEntityIdFilterValueList = string[];
export interface OfferEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type OfferNameString = string;
export type OfferNameFilterValueList = string[];
export interface OfferNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type OfferProductIdString = string;
export type OfferProductIdFilterValueList = string[];
export interface OfferProductIdFilter {
    ValueList?: string[] | undefined;
}
export type OfferResaleAuthorizationIdString = string;
export type OfferResaleAuthorizationIdFilterValueList = string[];
export interface OfferResaleAuthorizationIdFilter {
    ValueList?: string[] | undefined;
}
export interface OfferReleaseDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface OfferReleaseDateFilter {
    DateRange?: OfferReleaseDateFilterDateRange | undefined;
}
export interface OfferAvailabilityEndDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface OfferAvailabilityEndDateFilter {
    DateRange?: OfferAvailabilityEndDateFilterDateRange | undefined;
}
export type OfferBuyerAccountsFilterWildcard = string;
export interface OfferBuyerAccountsFilter {
    WildCardValue?: string | undefined;
}
export type OfferStateString = "Draft" | "Released" | (string & {});
export type OfferStateFilterValueList = OfferStateString[];
export interface OfferStateFilter {
    ValueList?: OfferStateString[] | undefined;
}
export type OfferTargetingString = "BuyerAccounts" | "ParticipatingPrograms" | "CountryCodes" | "None" | (string & {});
export type OfferTargetingFilterValueList = OfferTargetingString[];
export interface OfferTargetingFilter {
    ValueList?: OfferTargetingString[] | undefined;
}
export interface OfferLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface OfferLastModifiedDateFilter {
    DateRange?: OfferLastModifiedDateFilterDateRange | undefined;
}
export type OfferSetIdString = string;
export type OfferSetIdFilterValueList = string[];
export interface OfferSetIdFilter {
    ValueList?: string[] | undefined;
}
export type OfferTargetAgreementIdString = string;
export type OfferTargetAgreementIdFilterValueList = string[];
export interface OfferTargetAgreementIdFilter {
    ValueList?: string[] | undefined;
}
export type OfferTargetAgreementIntentString = "Renew" | (string & {});
export type OfferTargetAgreementIntentFilterValueList = OfferTargetAgreementIntentString[];
export interface OfferTargetAgreementIntentFilter {
    ValueList?: OfferTargetAgreementIntentString[] | undefined;
}
export type OfferCreatedBySourceString = "Seller" | "AwsMarketplace" | (string & {});
export type OfferCreatedBySourceFilterValueList = OfferCreatedBySourceString[];
export interface OfferCreatedBySourceFilter {
    ValueList?: OfferCreatedBySourceString[] | undefined;
}
export interface OfferFilters {
    EntityId?: OfferEntityIdFilter | undefined;
    Name?: OfferNameFilter | undefined;
    ProductId?: OfferProductIdFilter | undefined;
    ResaleAuthorizationId?: OfferResaleAuthorizationIdFilter | undefined;
    ReleaseDate?: OfferReleaseDateFilter | undefined;
    AvailabilityEndDate?: OfferAvailabilityEndDateFilter | undefined;
    BuyerAccounts?: OfferBuyerAccountsFilter | undefined;
    State?: OfferStateFilter | undefined;
    Targeting?: OfferTargetingFilter | undefined;
    LastModifiedDate?: OfferLastModifiedDateFilter | undefined;
    OfferSetId?: OfferSetIdFilter | undefined;
    TargetAgreementId?: OfferTargetAgreementIdFilter | undefined;
    TargetAgreementIntent?: OfferTargetAgreementIntentFilter | undefined;
    CreatedBySource?: OfferCreatedBySourceFilter | undefined;
}
export type ContainerProductEntityIdString = string;
export type ContainerProductEntityIdFilterValueList = string[];
export interface ContainerProductEntityIdFilter {
    ValueList?: string[] | undefined;
}
export interface ContainerProductLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface ContainerProductLastModifiedDateFilter {
    DateRange?: ContainerProductLastModifiedDateFilterDateRange | undefined;
}
export type ContainerProductTitleString = string;
export type ContainerProductTitleFilterValueList = string[];
export interface ContainerProductTitleFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ContainerProductVisibilityString = "Limited" | "Public" | "Restricted" | "Draft" | (string & {});
export type ContainerProductVisibilityFilterValueList = ContainerProductVisibilityString[];
export interface ContainerProductVisibilityFilter {
    ValueList?: ContainerProductVisibilityString[] | undefined;
}
export interface ContainerProductFilters {
    EntityId?: ContainerProductEntityIdFilter | undefined;
    LastModifiedDate?: ContainerProductLastModifiedDateFilter | undefined;
    ProductTitle?: ContainerProductTitleFilter | undefined;
    Visibility?: ContainerProductVisibilityFilter | undefined;
}
export type ResaleAuthorizationEntityIdString = string;
export type ResaleAuthorizationEntityIdFilterValueList = string[];
export interface ResaleAuthorizationEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type ResaleAuthorizationNameString = string;
export type ResaleAuthorizationNameFilterValueList = string[];
export type ResaleAuthorizationNameFilterWildcard = string;
export interface ResaleAuthorizationNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ResaleAuthorizationProductIdString = string;
export type ResaleAuthorizationProductIdFilterValueList = string[];
export type ResaleAuthorizationProductIdFilterWildcard = string;
export interface ResaleAuthorizationProductIdFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export interface ResaleAuthorizationCreatedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export type ResaleAuthorizationCreatedDateFilterValueList = string[];
export interface ResaleAuthorizationCreatedDateFilter {
    DateRange?: ResaleAuthorizationCreatedDateFilterDateRange | undefined;
    ValueList?: string[] | undefined;
}
export interface ResaleAuthorizationAvailabilityEndDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export type ResaleAuthorizationAvailabilityEndDateFilterValueList = string[];
export interface ResaleAuthorizationAvailabilityEndDateFilter {
    DateRange?: ResaleAuthorizationAvailabilityEndDateFilterDateRange | undefined;
    ValueList?: string[] | undefined;
}
export type ResaleAuthorizationManufacturerAccountIdString = string;
export type ResaleAuthorizationManufacturerAccountIdFilterValueList = string[];
export type ResaleAuthorizationManufacturerAccountIdFilterWildcard = string;
export interface ResaleAuthorizationManufacturerAccountIdFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ResaleAuthorizationProductNameString = string;
export type ResaleAuthorizationProductNameFilterValueList = string[];
export type ResaleAuthorizationProductNameFilterWildcard = string;
export interface ResaleAuthorizationProductNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ResaleAuthorizationManufacturerLegalNameString = string;
export type ResaleAuthorizationManufacturerLegalNameFilterValueList = string[];
export type ResaleAuthorizationManufacturerLegalNameFilterWildcard = string;
export interface ResaleAuthorizationManufacturerLegalNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ResaleAuthorizationResellerAccountIDString = string;
export type ResaleAuthorizationResellerAccountIDFilterValueList = string[];
export type ResaleAuthorizationResellerAccountIDFilterWildcard = string;
export interface ResaleAuthorizationResellerAccountIDFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ResaleAuthorizationResellerLegalNameString = string;
export type ResaleAuthorizationResellerLegalNameFilterValueList = string[];
export type ResaleAuthorizationResellerLegalNameFilterWildcard = string;
export interface ResaleAuthorizationResellerLegalNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type ResaleAuthorizationStatusString = "Draft" | "Active" | "Restricted" | (string & {});
export type ResaleAuthorizationStatusFilterValueList = ResaleAuthorizationStatusString[];
export interface ResaleAuthorizationStatusFilter {
    ValueList?: ResaleAuthorizationStatusString[] | undefined;
}
export type ResaleAuthorizationOfferExtendedStatusString = string;
export type ResaleAuthorizationOfferExtendedStatusFilterValueList = string[];
export interface ResaleAuthorizationOfferExtendedStatusFilter {
    ValueList?: string[] | undefined;
}
export interface ResaleAuthorizationLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface ResaleAuthorizationLastModifiedDateFilter {
    DateRange?: ResaleAuthorizationLastModifiedDateFilterDateRange | undefined;
}
export type ResaleAuthorizationResellerRoleString = "ChannelPartner" | "Distributor" | (string & {});
export type ResaleAuthorizationResellerRoleFilterValueList = ResaleAuthorizationResellerRoleString[];
export interface ResaleAuthorizationResellerRoleFilter {
    ValueList?: ResaleAuthorizationResellerRoleString[] | undefined;
}
export type ResaleAuthorizationSourceAuthorizationString = string;
export type ResaleAuthorizationSourceAuthorizationFilterValueList = string[];
export interface ResaleAuthorizationSourceAuthorizationFilter {
    ValueList?: string[] | undefined;
}
export type ResaleAuthorizationIssuerAccountIdString = string;
export type ResaleAuthorizationIssuerAccountIdFilterValueList = string[];
export interface ResaleAuthorizationIssuerAccountIdFilter {
    ValueList?: string[] | undefined;
}
export interface ResaleAuthorizationFilters {
    EntityId?: ResaleAuthorizationEntityIdFilter | undefined;
    Name?: ResaleAuthorizationNameFilter | undefined;
    ProductId?: ResaleAuthorizationProductIdFilter | undefined;
    CreatedDate?: ResaleAuthorizationCreatedDateFilter | undefined;
    AvailabilityEndDate?: ResaleAuthorizationAvailabilityEndDateFilter | undefined;
    ManufacturerAccountId?: ResaleAuthorizationManufacturerAccountIdFilter | undefined;
    ProductName?: ResaleAuthorizationProductNameFilter | undefined;
    ManufacturerLegalName?: ResaleAuthorizationManufacturerLegalNameFilter | undefined;
    ResellerAccountID?: ResaleAuthorizationResellerAccountIDFilter | undefined;
    ResellerLegalName?: ResaleAuthorizationResellerLegalNameFilter | undefined;
    Status?: ResaleAuthorizationStatusFilter | undefined;
    OfferExtendedStatus?: ResaleAuthorizationOfferExtendedStatusFilter | undefined;
    LastModifiedDate?: ResaleAuthorizationLastModifiedDateFilter | undefined;
    ResellerRole?: ResaleAuthorizationResellerRoleFilter | undefined;
    SourceAuthorization?: ResaleAuthorizationSourceAuthorizationFilter | undefined;
    IssuerAccountId?: ResaleAuthorizationIssuerAccountIdFilter | undefined;
}
export type MachineLearningProductEntityIdString = string;
export type MachineLearningProductEntityIdFilterValueList = string[];
export interface MachineLearningProductEntityIdFilter {
    ValueList?: string[] | undefined;
}
export interface MachineLearningProductLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface MachineLearningProductLastModifiedDateFilter {
    DateRange?: MachineLearningProductLastModifiedDateFilterDateRange | undefined;
}
export type MachineLearningProductTitleString = string;
export type MachineLearningProductTitleFilterValueList = string[];
export interface MachineLearningProductTitleFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type MachineLearningProductVisibilityString = "Limited" | "Public" | "Restricted" | "Draft" | (string & {});
export type MachineLearningProductVisibilityFilterValueList = MachineLearningProductVisibilityString[];
export interface MachineLearningProductVisibilityFilter {
    ValueList?: MachineLearningProductVisibilityString[] | undefined;
}
export interface MachineLearningProductFilters {
    EntityId?: MachineLearningProductEntityIdFilter | undefined;
    LastModifiedDate?: MachineLearningProductLastModifiedDateFilter | undefined;
    ProductTitle?: MachineLearningProductTitleFilter | undefined;
    Visibility?: MachineLearningProductVisibilityFilter | undefined;
}
export type OfferSetEntityIdString = string;
export type OfferSetEntityIdFilterValueList = string[];
export interface OfferSetEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type OfferSetNameString = string;
export type OfferSetNameFilterValueList = string[];
export interface OfferSetNameFilter {
    ValueList?: string[] | undefined;
}
export type OfferSetStateString = "Draft" | "Released" | (string & {});
export type OfferSetStateFilterValueList = OfferSetStateString[];
export interface OfferSetStateFilter {
    ValueList?: OfferSetStateString[] | undefined;
}
export interface OfferSetReleaseDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface OfferSetReleaseDateFilter {
    DateRange?: OfferSetReleaseDateFilterDateRange | undefined;
}
export type OfferSetAssociatedOfferIdsString = string;
export type OfferSetAssociatedOfferIdsFilterValueList = string[];
export interface OfferSetAssociatedOfferIdsFilter {
    ValueList?: string[] | undefined;
}
export type OfferSetSolutionIdString = string;
export type OfferSetSolutionIdFilterValueList = string[];
export interface OfferSetSolutionIdFilter {
    ValueList?: string[] | undefined;
}
export interface OfferSetLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface OfferSetLastModifiedDateFilter {
    DateRange?: OfferSetLastModifiedDateFilterDateRange | undefined;
}
export interface OfferSetFilters {
    EntityId?: OfferSetEntityIdFilter | undefined;
    Name?: OfferSetNameFilter | undefined;
    State?: OfferSetStateFilter | undefined;
    ReleaseDate?: OfferSetReleaseDateFilter | undefined;
    AssociatedOfferIds?: OfferSetAssociatedOfferIdsFilter | undefined;
    SolutionId?: OfferSetSolutionIdFilter | undefined;
    LastModifiedDate?: OfferSetLastModifiedDateFilter | undefined;
}
export type ExpressPrivateOfferConfigurationEntityIdString = string;
export type ExpressPrivateOfferConfigurationEntityIdFilterValueList = string[];
export interface ExpressPrivateOfferConfigurationEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type ExpressPrivateOfferConfigurationProductIdString = string;
export type ExpressPrivateOfferConfigurationProductIdFilterValueList = string[];
export interface ExpressPrivateOfferConfigurationProductIdFilter {
    ValueList?: string[] | undefined;
}
export type ExpressPrivateOfferConfigurationStateString = "ACTIVE" | "INACTIVE" | (string & {});
export type ExpressPrivateOfferConfigurationStateFilterValueList = ExpressPrivateOfferConfigurationStateString[];
export interface ExpressPrivateOfferConfigurationStateFilter {
    ValueList?: ExpressPrivateOfferConfigurationStateString[] | undefined;
}
export interface ExpressPrivateOfferConfigurationFilters {
    EntityId?: ExpressPrivateOfferConfigurationEntityIdFilter | undefined;
    ProductId?: ExpressPrivateOfferConfigurationProductIdFilter | undefined;
    State?: ExpressPrivateOfferConfigurationStateFilter | undefined;
}
export type SubsidiaryAuthorizationEntityIdString = string;
export type SubsidiaryAuthorizationEntityIdFilterValueList = string[];
export interface SubsidiaryAuthorizationEntityIdFilter {
    ValueList?: string[] | undefined;
}
export type SubsidiaryAuthorizationStatusString = "Draft" | "Active" | "Restricted" | (string & {});
export type SubsidiaryAuthorizationStatusFilterValueList = SubsidiaryAuthorizationStatusString[];
export interface SubsidiaryAuthorizationStatusFilter {
    ValueList?: SubsidiaryAuthorizationStatusString[] | undefined;
}
export type SubsidiaryAuthorizationResourceIdString = string;
export type SubsidiaryAuthorizationResourceIdFilterValueList = string[];
export interface SubsidiaryAuthorizationResourceIdFilter {
    ValueList?: string[] | undefined;
}
export type SubsidiaryAuthorizationResourceNameString = string;
export type SubsidiaryAuthorizationResourceNameFilterValueList = string[];
export type SubsidiaryAuthorizationResourceNameFilterWildcard = string;
export interface SubsidiaryAuthorizationResourceNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type SubsidiaryAuthorizationNameString = string;
export type SubsidiaryAuthorizationNameFilterValueList = string[];
export type SubsidiaryAuthorizationNameFilterWildcard = string;
export interface SubsidiaryAuthorizationNameFilter {
    ValueList?: string[] | undefined;
    WildCardValue?: string | undefined;
}
export type SubsidiaryAuthorizationSubsidiaryAccountIdString = string;
export type SubsidiaryAuthorizationSubsidiaryAccountIdFilterValueList = string[];
export interface SubsidiaryAuthorizationSubsidiaryAccountIdFilter {
    ValueList?: string[] | undefined;
}
export interface SubsidiaryAuthorizationCreatedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface SubsidiaryAuthorizationCreatedDateFilter {
    DateRange?: SubsidiaryAuthorizationCreatedDateFilterDateRange | undefined;
}
export interface SubsidiaryAuthorizationLastModifiedDateFilterDateRange {
    AfterValue?: string | undefined;
    BeforeValue?: string | undefined;
}
export interface SubsidiaryAuthorizationLastModifiedDateFilter {
    DateRange?: SubsidiaryAuthorizationLastModifiedDateFilterDateRange | undefined;
}
export interface SubsidiaryAuthorizationFilters {
    EntityId?: SubsidiaryAuthorizationEntityIdFilter | undefined;
    Status?: SubsidiaryAuthorizationStatusFilter | undefined;
    ResourceId?: SubsidiaryAuthorizationResourceIdFilter | undefined;
    ResourceName?: SubsidiaryAuthorizationResourceNameFilter | undefined;
    Name?: SubsidiaryAuthorizationNameFilter | undefined;
    SubsidiaryAccountId?: SubsidiaryAuthorizationSubsidiaryAccountIdFilter | undefined;
    CreatedDate?: SubsidiaryAuthorizationCreatedDateFilter | undefined;
    LastModifiedDate?: SubsidiaryAuthorizationLastModifiedDateFilter | undefined;
}
export type EntityTypeFilters = {
    DataProductFilters: DataProductFilters;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters: SaaSProductFilters;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters: AmiProductFilters;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters: OfferFilters;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters: ContainerProductFilters;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters: ResaleAuthorizationFilters;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters: MachineLearningProductFilters;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters: OfferSetFilters;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters: ExpressPrivateOfferConfigurationFilters;
    SubsidiaryAuthorizationFilters?: undefined;
} | {
    DataProductFilters?: undefined;
    SaaSProductFilters?: undefined;
    AmiProductFilters?: undefined;
    OfferFilters?: undefined;
    ContainerProductFilters?: undefined;
    ResaleAuthorizationFilters?: undefined;
    MachineLearningProductFilters?: undefined;
    OfferSetFilters?: undefined;
    ExpressPrivateOfferConfigurationFilters?: undefined;
    SubsidiaryAuthorizationFilters: SubsidiaryAuthorizationFilters;
};
export type DataProductSortBy = "EntityId" | "ProductTitle" | "Visibility" | "LastModifiedDate" | (string & {});
export interface DataProductSort {
    SortBy?: DataProductSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type SaaSProductSortBy = "EntityId" | "ProductTitle" | "Visibility" | "LastModifiedDate" | "DeliveryOptionTypes" | (string & {});
export interface SaaSProductSort {
    SortBy?: SaaSProductSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type AmiProductSortBy = "EntityId" | "LastModifiedDate" | "ProductTitle" | "Visibility" | (string & {});
export interface AmiProductSort {
    SortBy?: AmiProductSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type OfferSortBy = "EntityId" | "Name" | "ProductId" | "ResaleAuthorizationId" | "ReleaseDate" | "AvailabilityEndDate" | "BuyerAccounts" | "State" | "Targeting" | "LastModifiedDate" | "OfferSetId" | "TargetAgreementId" | "TargetAgreementIntent" | "CreatedBySource" | (string & {});
export interface OfferSort {
    SortBy?: OfferSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type ContainerProductSortBy = "EntityId" | "LastModifiedDate" | "ProductTitle" | "Visibility" | "CompatibleAWSServices" | (string & {});
export interface ContainerProductSort {
    SortBy?: ContainerProductSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type ResaleAuthorizationSortBy = "EntityId" | "Name" | "ProductId" | "ProductName" | "ManufacturerAccountId" | "ManufacturerLegalName" | "ResellerAccountID" | "ResellerLegalName" | "Status" | "OfferExtendedStatus" | "CreatedDate" | "AvailabilityEndDate" | "LastModifiedDate" | "ResellerRole" | "SourceAuthorization" | "IssuerAccountId" | (string & {});
export interface ResaleAuthorizationSort {
    SortBy?: ResaleAuthorizationSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type MachineLearningProductSortBy = "EntityId" | "LastModifiedDate" | "ProductTitle" | "Visibility" | (string & {});
export interface MachineLearningProductSort {
    SortBy?: MachineLearningProductSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type OfferSetSortBy = "Name" | "State" | "ReleaseDate" | "SolutionId" | "EntityId" | "LastModifiedDate" | (string & {});
export interface OfferSetSort {
    SortBy?: OfferSetSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type ExpressPrivateOfferConfigurationSortBy = "EntityId" | "LastModifiedDate" | "ProductId" | "State" | (string & {});
export interface ExpressPrivateOfferConfigurationSort {
    SortBy?: ExpressPrivateOfferConfigurationSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type SubsidiaryAuthorizationSortBy = "EntityId" | "Status" | "ResourceId" | "SubsidiaryAccountId" | "CreatedDate" | "LastModifiedDate" | (string & {});
export interface SubsidiaryAuthorizationSort {
    SortBy?: SubsidiaryAuthorizationSortBy | undefined;
    SortOrder?: SortOrder | undefined;
}
export type EntityTypeSort = {
    DataProductSort: DataProductSort;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort: SaaSProductSort;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort: AmiProductSort;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort: OfferSort;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort: ContainerProductSort;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort: ResaleAuthorizationSort;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort: MachineLearningProductSort;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort: OfferSetSort;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort: ExpressPrivateOfferConfigurationSort;
    SubsidiaryAuthorizationSort?: undefined;
} | {
    DataProductSort?: undefined;
    SaaSProductSort?: undefined;
    AmiProductSort?: undefined;
    OfferSort?: undefined;
    ContainerProductSort?: undefined;
    ResaleAuthorizationSort?: undefined;
    MachineLearningProductSort?: undefined;
    OfferSetSort?: undefined;
    ExpressPrivateOfferConfigurationSort?: undefined;
    SubsidiaryAuthorizationSort: SubsidiaryAuthorizationSort;
};
export interface ListEntitiesRequest {
    Catalog: string;
    EntityType: string;
    FilterList?: Filter[] | undefined;
    Sort?: Sort | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    OwnershipType?: OwnershipType | undefined;
    EntityTypeFilters?: EntityTypeFilters | undefined;
    EntityTypeSort?: EntityTypeSort | undefined;
}
export type EntityNameString = string;
export type VisibilityValue = string;
export interface AmiProductSummary {
    ProductTitle?: string | undefined;
    Visibility?: AmiProductVisibilityString | undefined;
}
export interface ContainerProductSummary {
    ProductTitle?: string | undefined;
    Visibility?: ContainerProductVisibilityString | undefined;
}
export interface DataProductSummary {
    ProductTitle?: string | undefined;
    Visibility?: DataProductVisibilityString | undefined;
}
export interface SaaSProductSummary {
    ProductTitle?: string | undefined;
    Visibility?: SaaSProductVisibilityString | undefined;
}
export type OfferBuyerAccountsString = string;
export type OfferBuyerAccountsList = string[];
export type OfferTargetingList = OfferTargetingString[];
export interface OfferSummary {
    Name?: string | undefined;
    ProductId?: string | undefined;
    ResaleAuthorizationId?: string | undefined;
    ReleaseDate?: string | undefined;
    AvailabilityEndDate?: string | undefined;
    BuyerAccounts?: string[] | undefined;
    State?: OfferStateString | undefined;
    Targeting?: OfferTargetingString[] | undefined;
    OfferSetId?: string | undefined;
    TargetAgreementId?: string | undefined;
    TargetAgreementIntent?: OfferTargetAgreementIntentString | undefined;
    CreatedBySource?: OfferCreatedBySourceString | undefined;
}
export interface ResaleAuthorizationSummary {
    Name?: string | undefined;
    ProductId?: string | undefined;
    ProductName?: string | undefined;
    ManufacturerAccountId?: string | undefined;
    ManufacturerLegalName?: string | undefined;
    ResellerAccountID?: string | undefined;
    ResellerLegalName?: string | undefined;
    Status?: ResaleAuthorizationStatusString | undefined;
    OfferExtendedStatus?: string | undefined;
    CreatedDate?: string | undefined;
    AvailabilityEndDate?: string | undefined;
    ResellerRole?: ResaleAuthorizationResellerRoleString | undefined;
    SourceAuthorization?: string | undefined;
    IssuerAccountId?: string | undefined;
}
export interface MachineLearningProductSummary {
    ProductTitle?: string | undefined;
    Visibility?: MachineLearningProductVisibilityString | undefined;
}
export type OfferSetAssociatedOfferIdsList = string[];
export interface OfferSetSummary {
    Name?: string | undefined;
    State?: OfferSetStateString | undefined;
    ReleaseDate?: string | undefined;
    AssociatedOfferIds?: string[] | undefined;
    SolutionId?: string | undefined;
}
export interface ExpressPrivateOfferConfigurationSummary {
    ProductId?: string | undefined;
    State?: ExpressPrivateOfferConfigurationStateString | undefined;
}
export type SubsidiaryAuthorizationSummaryNameString = string;
export type SubsidiaryAuthorizationSummaryStatusString = string;
export type SubsidiaryAuthorizationSummaryResourceIdString = string;
export type SubsidiaryAuthorizationSummaryResourceNameString = string;
export type SubsidiaryAuthorizationSummarySubsidiaryAccountIdString = string;
export interface SubsidiaryAuthorizationSummary {
    Name?: string | undefined;
    Status?: string | undefined;
    ResourceId?: string | undefined;
    ResourceName?: string | undefined;
    SubsidiaryAccountId?: string | undefined;
    CreatedDate?: string | undefined;
}
export interface EntitySummary {
    Name?: string | undefined;
    EntityType?: string | undefined;
    EntityId?: string | undefined;
    EntityArn?: string | undefined;
    LastModifiedDate?: string | undefined;
    Visibility?: string | undefined;
    AmiProductSummary?: AmiProductSummary | undefined;
    ContainerProductSummary?: ContainerProductSummary | undefined;
    DataProductSummary?: DataProductSummary | undefined;
    SaaSProductSummary?: SaaSProductSummary | undefined;
    OfferSummary?: OfferSummary | undefined;
    ResaleAuthorizationSummary?: ResaleAuthorizationSummary | undefined;
    MachineLearningProductSummary?: MachineLearningProductSummary | undefined;
    OfferSetSummary?: OfferSetSummary | undefined;
    ExpressPrivateOfferConfigurationSummary?: ExpressPrivateOfferConfigurationSummary | undefined;
    SubsidiaryAuthorizationSummary?: SubsidiaryAuthorizationSummary | undefined;
}
export type EntitySummaryList = EntitySummary[];
export interface ListEntitiesResponse {
    EntitySummaryList?: EntitySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface ListTagsForResourceResponse {
    ResourceArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface PutResourcePolicyRequest {
    ResourceArn: string;
    Policy: string;
}
export interface PutResourcePolicyResponse {
}
export interface Change {
    ChangeType: string;
    Entity: Entity;
    EntityTags?: Tag[] | undefined;
    Details?: string | undefined;
    DetailsDocument?: any | undefined;
    ChangeName?: string | undefined;
}
export type RequestedChangeList = Change[];
export type ClientRequestToken = string;
export interface StartChangeSetRequest {
    Catalog: string;
    ChangeSet: Change[];
    ChangeSetName?: string | undefined;
    ClientRequestToken?: string | undefined;
    ChangeSetTags?: Tag[] | undefined;
    Intent?: Intent | undefined;
}
export interface StartChangeSetResponse {
    ChangeSetId?: string | undefined;
    ChangeSetArn?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ValidationExceptionReason = "UnknownOperation" | "CannotParse" | "FieldValidationFailed" | "Other" | (string & {});
export type FieldName = string;
export interface ValidationExceptionField {
    Reason?: ValidationExceptionReason | undefined;
    EntityType?: string | undefined;
    EntityId?: string | undefined;
    ChangeType?: string | undefined;
    Field?: string | undefined;
    Message?: string | undefined;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type BatchDescribeEntitiesError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns metadata and content for multiple entities. This is the Batch version of the `DescribeEntity` API and uses the same IAM permission action as `DescribeEntity` API.
 */
export declare const batchDescribeEntities: API.OperationMethod<BatchDescribeEntitiesRequest & RegionInput, BatchDescribeEntitiesResponse, BatchDescribeEntitiesError, Credentials | HttpClient.HttpClient>;
export type CancelChangeSetError = AccessDeniedException | InternalServiceException | ResourceInUseException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Used to cancel an open change request. Must be sent before the status of the request
 * changes to `APPLYING`, the final stage of completing your change request. You
 * can describe a change during the 60-day request history retention period for API
 * calls.
 */
export declare const cancelChangeSet: API.OperationMethod<CancelChangeSetRequest & RegionInput, CancelChangeSetResponse, CancelChangeSetError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a resource-based policy on an entity that is identified by its resource
 * ARN.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeAssessmentError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata and detailed results of a single assessment, including the
 * framework that was evaluated, the overall assessment result, and a paginated list of
 * individual control evaluation results.
 *
 * To list available assessments before describing one, use the
 * `ListAssessments` action.
 */
export declare const describeAssessment: API.PaginatedOperationMethod<DescribeAssessmentRequest & RegionInput, DescribeAssessmentResponse, DescribeAssessmentError, Credentials | HttpClient.HttpClient, ControlAssessment>;
export type DescribeChangeSetError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides information about a given change set.
 */
export declare const describeChangeSet: API.OperationMethod<DescribeChangeSetRequest & RegionInput, DescribeChangeSetResponse, DescribeChangeSetError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ResourceNotSupportedException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the metadata and content of the entity.
 */
export declare const describeEntity: API.OperationMethod<DescribeEntityRequest & RegionInput, DescribeEntityResponse, DescribeEntityError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a resource-based policy of an entity that is identified by its resource
 * ARN.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyRequest & RegionInput, GetResourcePolicyResponse, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListAssessmentsError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of assessments associated with an entity or change set in
 * AWS Marketplace. An *assessment* is the result of evaluating a
 * product or change set against a framework, such as AMI Security or Container
 * Security.
 *
 * Use the `AssessmentTargetFilter` to scope results to a specific entity or
 * change set, and use `FrameworkFilters` to scope results to a single
 * framework. To retrieve detailed control-level results for an individual assessment, use
 * the `DescribeAssessment` action.
 *
 * Results are sorted by assessment creation time in descending order.
 */
export declare const listAssessments: API.PaginatedOperationMethod<ListAssessmentsRequest & RegionInput, ListAssessmentsResponse, ListAssessmentsError, Credentials | HttpClient.HttpClient, AssessmentSummary>;
export type ListChangeSetsError = AccessDeniedException | InternalServiceException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the list of change sets owned by the account being used to make the call. You
 * can filter this list by providing any combination of `entityId`,
 * `ChangeSetName`, and status. If you provide more than one filter, the API
 * operation applies a logical AND between the filters.
 *
 * You can describe a change during the 60-day request history retention period for API
 * calls.
 */
export declare const listChangeSets: API.PaginatedOperationMethod<ListChangeSetsRequest & RegionInput, ListChangeSetsResponse, ListChangeSetsError, Credentials | HttpClient.HttpClient, ChangeSetSummaryListItem>;
export type ListEntitiesError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides the list of entities of a given type.
 */
export declare const listEntities: API.PaginatedOperationMethod<ListEntitiesRequest & RegionInput, ListEntitiesResponse, ListEntitiesError, Credentials | HttpClient.HttpClient, EntitySummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags that have been added to a resource (either an entity or change set).
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches a resource-based policy to an entity. Examples of an entity include:
 * `AmiProduct` and `ContainerProduct`.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartChangeSetError = AccessDeniedException | InternalServiceException | ResourceInUseException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows you to request changes for your entities. Within a single
 * `ChangeSet`, you can't start the same change type against the same entity
 * multiple times. Additionally, when a `ChangeSet` is running, all the entities
 * targeted by the different changes are locked until the change set has completed (either
 * succeeded, cancelled, or failed). If you try to start a change set containing a change
 * against an entity that is already locked, you will receive a
 * `ResourceInUseException` error.
 *
 * For example, you can't start the `ChangeSet` described in the example later in this topic because it contains two changes to run the same
 * change type (`AddRevisions`) against the same entity
 * (`entity-id@1`).
 *
 * For more information about working with change sets, see Working with change sets. For information about change types for
 * single-AMI products, see Working with single-AMI products. Also, for more information about change
 * types available for container-based products, see Working with container products.
 *
 * To download "DetailsDocument" shapes, see Python
 * and Java shapes on GitHub.
 */
export declare const startChangeSet: API.OperationMethod<StartChangeSetRequest & RegionInput, StartChangeSetResponse, StartChangeSetError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags a resource (either an entity or change set).
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServiceException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or list of tags from a resource (either an entity or change set).
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=marketplace-catalog.d.ts.map