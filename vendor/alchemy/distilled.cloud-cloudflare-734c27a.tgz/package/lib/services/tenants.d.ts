import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface GetEntitlementRequest {
    tenantId: string;
}
export type EntitlementsGetResponseAllowAddSubdomainType = "bool";
export interface EntitlementsGetResponseAllowAddSubdomain {
    type: EntitlementsGetResponseAllowAddSubdomainType;
    value: boolean;
}
export type EntitlementsGetResponseAllowAutoAcceptInvitesType = "bool";
export interface EntitlementsGetResponseAllowAutoAcceptInvites {
    type: EntitlementsGetResponseAllowAutoAcceptInvitesType;
    value: boolean;
}
export type EntitlementsGetResponseCnameSetupAllowedType = "bool";
export interface EntitlementsGetResponseCnameSetupAllowed {
    type: EntitlementsGetResponseCnameSetupAllowedType;
    value: boolean;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType = "max_count";
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocationType;
    value: number;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType = "bool";
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocationType;
    value: boolean;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType = "";
export interface EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation {
    type: EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocationType;
    value?: unknown | null | undefined;
}
export type EntitlementsGetResponseCustomEntitlementsItemAllocation = EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIMaxCountAllocation | EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPIBoolAllocation | EntitlementsGetResponseCustomEntitlementsItemAllocationOrganizationsAPINullAllocation;
export interface EntitlementsGetResponseCustomEntitlementsItemFeature {
    key: string;
}
export interface EntitlementsGetResponseCustomEntitlementsItem {
    allocation: EntitlementsGetResponseCustomEntitlementsItemAllocation;
    feature: EntitlementsGetResponseCustomEntitlementsItemFeature;
}
export type EntitlementsGetResponseCustomEntitlementsList = Array<EntitlementsGetResponseCustomEntitlementsItem>;
export type EntitlementsGetResponseMhsCertificateCountType = "max_count";
export interface EntitlementsGetResponseMhsCertificateCount {
    type: EntitlementsGetResponseMhsCertificateCountType;
    value: number;
}
export type EntitlementsGetResponsePartialSetupAllowedType = "bool";
export interface EntitlementsGetResponsePartialSetupAllowed {
    type: EntitlementsGetResponsePartialSetupAllowedType;
    value: boolean;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetEntitlementResponse {
    allowAddSubdomain: EntitlementsGetResponseAllowAddSubdomain;
    allowAutoAcceptInvites: EntitlementsGetResponseAllowAutoAcceptInvites;
    cnameSetupAllowed: EntitlementsGetResponseCnameSetupAllowed;
    customEntitlements: EntitlementsGetResponseCustomEntitlementsList;
    mhsCertificateCount: EntitlementsGetResponseMhsCertificateCount;
    partialSetupAllowed: EntitlementsGetResponsePartialSetupAllowed;
}
export interface GetTenantRequest {
    tenantId: string;
}
export interface GetResponseTenantContacts {
    email?: string | null | undefined;
    website?: string | null | undefined;
}
export type GetResponseTenantLabelsList = Array<string>;
export interface GetResponseTenantMetadataDnsNsPool {
    primary?: string | null | undefined;
    secondary?: string | null | undefined;
}
export interface GetResponseTenantMetadataDns {
    nsPool: GetResponseTenantMetadataDnsNsPool;
}
export interface GetResponseTenantMetadata {
    dns?: GetResponseTenantMetadataDns | null | undefined;
}
export type GetResponseTenantUnitsItemUnitMembershipsList = Array<unknown>;
export interface GetResponseTenantUnitsItem {
    unitMemberships: GetResponseTenantUnitsItemUnitMembershipsList;
    unitMetadata: unknown;
    unitName: string;
    unitStatus: string;
    unitTag: string;
}
export type GetResponseTenantUnitsList = Array<GetResponseTenantUnitsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTenantResponse {
    cdate: string;
    edate: string;
    tenantContacts: GetResponseTenantContacts;
    tenantLabels: GetResponseTenantLabelsList;
    tenantMetadata: GetResponseTenantMetadata;
    tenantName: string;
    tenantNetwork: unknown;
    tenantStatus: string;
    tenantTag: string;
    tenantType: string;
    tenantUnits: GetResponseTenantUnitsList;
    customerId?: string | null | undefined;
}
export interface AccountsListRequestAccountPubname {
    /** (case-insensitive) Filter the list of accounts to where the account_pubname contains a particular string. */
    contains?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname ends with a particular string. */
    endsWith?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the account_pubname starts with a particular string. */
    startsWith?: string | undefined;
}
export type AccountsListRequestDirection = "asc" | "desc";
export interface AccountsListRequestName {
    /** (case-insensitive) Filter the list of accounts to where the name contains a particular string. */
    contains?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the name ends with a particular string. */
    endsWith?: string | undefined;
    /** (case-insensitive) Filter the list of accounts to where the name starts with a particular string. */
    startsWith?: string | undefined;
}
export type AccountsListRequestOrderBy = "account_name";
export type AccountsListRequestStatus = "active" | "deleted";
export interface ListAccountsRequest {
    tenantId: string;
    accountPubname?: AccountsListRequestAccountPubname | undefined;
    /** Sort direction for the order_by field. Valid values: `asc`, `desc`. Defaults to `asc` when order_by is specified. */
    direction?: AccountsListRequestDirection | (string & {}) | undefined;
    /** Whether to calculate and return the exact `result_info.total_size` for cursor pagination. Defaults to true. When false, `total_size` is omitted. */
    includeTotal?: boolean | undefined;
    name?: AccountsListRequestName | undefined;
    /** Field to order results by. Currently supported values: `account_name`. */
    orderBy?: AccountsListRequestOrderBy | (string & {}) | undefined;
    /** The amount of items to return. Defaults to 10. */
    pageSize?: number | undefined;
    /** An opaque token returned from the last list response that when provided will retrieve the next page. */
    pageToken?: string | undefined;
    /** Filter accounts by lifecycle status. Defaults to `active`. */
    status?: AccountsListRequestStatus | (string & {}) | undefined;
}
export type AccountsListResultItemAccountType = "standard" | "enterprise";
export interface AccountsListResultItemSettings {
    accessApprovalExpiry: string;
    apiAccessEnabled: boolean;
    enforceTwoFactor: boolean;
    useAccountCustomNsByDefault: boolean;
}
export interface AccountsListResultItem {
    accountPubname: string;
    accountTag: string;
    accountType: AccountsListResultItemAccountType;
    createdOn: string;
    settings: AccountsListResultItemSettings;
}
export type AccountsListResultList = Array<AccountsListResultItem>;
export interface ListAccountsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccountsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListAccountTypesRequest {
    tenantId: string;
}
export type AccountTypesListResultList = Array<string>;
export interface ListAccountTypesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: AccountTypesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListMembershipsRequest {
    tenantId: string;
}
export interface MembershipsListResultItem {
    userEmail: string;
    userName: string;
    userTag: string;
}
export type MembershipsListResultList = Array<MembershipsListResultItem>;
export interface ListMembershipsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MembershipsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type GetEntitlementError = CloudflareOpError;
/** Retrieves the innate and custom entitlement allocations available to this tenant. */
export declare const getEntitlement: API.OperationMethod<GetEntitlementRequest, GetEntitlementResponse, GetEntitlementError, CloudflareOpContext>;
export type GetTenantError = CloudflareOpError;
/** Retrieves a tenant's identity, status, metadata, contacts, and organizational units. */
export declare const getTenant: API.OperationMethod<GetTenantRequest, GetTenantResponse, GetTenantError, CloudflareOpContext>;
export type ListAccountsError = CloudflareOpError;
/** Lists all Cloudflare accounts across this tenant's hierarchy using the legacy Account response shape. Use `GET /organizations/{organization_id}/accounts` to list only accounts immediately attached to a specific Organization using the modern Account response shape. Use `page_token` and `page_size` for cursor pagination. */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, CloudflareOpContext, AccountsListResultItem>;
export type ListAccountTypesError = CloudflareOpError;
/** Lists the account types this tenant is allowed to provision. */
export declare const listAccountTypes: API.PaginatedOperationMethod<ListAccountTypesRequest, ListAccountTypesResponse, ListAccountTypesError, CloudflareOpContext, string>;
export type ListMembershipsError = CloudflareOpError;
/** Lists active Cloudflare users with memberships in this tenant. */
export declare const listMemberships: API.PaginatedOperationMethod<ListMembershipsRequest, ListMembershipsResponse, ListMembershipsError, CloudflareOpContext, MembershipsListResultItem>;
//# sourceMappingURL=tenants.d.ts.map