import * as Effect from "effect/Effect";
import type * as S from "effect/Schema";
import type { Request as ProtocolRequest } from "../client/request.ts";
/**
 * The smallest body the AWS SDKs compress (`request_min_compression_size_bytes`
 * defaults to 10 KiB): a smaller one is sent as is.
 */
export declare const MIN_COMPRESSION_SIZE_BYTES = 10240;
/**
 * `@requestCompression`: gzip a buffered body of at least
 * {@link MIN_COMPRESSION_SIZE_BYTES} and append `gzip` to its
 * Content-Encoding, as the AWS SDKs do (smithy-typescript
 * `compressionMiddleware`). gzip is the only encoding Smithy defines. A
 * streaming body is sent as is: no AWS operation streams a compressed input.
 */
export declare const applyRequestCompression: (schema: S.Top, request: ProtocolRequest) => Effect.Effect<ProtocolRequest>;
//# sourceMappingURL=compression.d.ts.map