import type { Database } from "@alchemy.run/cloudflare/D1/Database";
import { QueryDatabase } from "@alchemy.run/cloudflare/D1/QueryDatabase";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import { KeyStore } from "../KeyStore.ts";
/** Options for {@link D1KeyStore}. */
export interface D1KeyStoreOptions {
    /**
     * The table that holds one row per subject. It is created on first use.
     * @default "vault_keys"
     */
    readonly table?: string;
}
/**
 * A Vault's keys in a D1 database, one row per subject. Give the keys a
 * database of their own: D1 Time Travel restores a database up to 30 days
 * back, deleted keys included, so wrap them with `SecretKeyWrap` and rotate
 * its root key to put older copies out of reach.
 *
 * ### Keeping keys in D1
 * **Example:** A database for the Vault's keys
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as Domain from "@alchemy.run/domain";
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankHandlers } from "./Bank.model.ts";
 *
 * export const KeysDatabase = Cloudflare.D1.Database("KeysDatabase");
 *
 * export const BankLive = Bank.layer(BankHandlers).pipe(
 *   Layer.provide(Domain.VaultLive),
 *   Layer.provide(DomainCloudflare.D1KeyStore(KeysDatabase)),
 *   Layer.provide(Domain.NoKeyWrap),
 *   Layer.provide(
 *     Layer.mergeAll(DomainCloudflare.layerDurableObjects(), Cloudflare.D1.QueryDatabaseBinding),
 *   ),
 * );
 * ```
 *
 * @layer
 * @provides Domain.KeyStore
 */
export declare const D1KeyStore: <E = never, R = never>(database: Database | Effect.Effect<Database, E, R>, options?: D1KeyStoreOptions) => Layer.Layer<KeyStore, E, R | QueryDatabase>;
//# sourceMappingURL=D1KeyStore.d.ts.map