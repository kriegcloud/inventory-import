import type * as Effect from "effect/Effect";
import type { Sort, Term } from "./Smt.ts";
/** A node of the parsed source. Only the fields the prover reads are typed. */
export interface Node {
    readonly type: string;
    readonly start: number;
    readonly end: number;
    readonly [key: string]: any;
}
/** One parsed source file, and the same module loaded for its runtime values. */
export interface Module {
    readonly path: string;
    /** The file's text: a node's `start` and `end` are places in it. */
    readonly source: string;
    readonly lineStarts: ReadonlyArray<number>;
    readonly program: Node;
    readonly declarations: ReadonlyMap<string, Declaration>;
    readonly imports: ReadonlyMap<string, Import>;
    /** The specifiers of `export * from`. */
    readonly stars: ReadonlyArray<string>;
    /** The file each relative specifier names. */
    readonly resolved: ReadonlyMap<string, string>;
    /** The module as Node loaded it: classes, schemas and constants. */
    readonly exports: Readonly<Record<string, unknown>>;
}
export type Declaration = {
    readonly _tag: "Const";
    readonly init: Node | undefined;
}
/** A name a pattern binds: `const { a, b: [c] } = made` declares `a` and `c`. */
 | {
    readonly _tag: "Pattern";
    readonly pattern: Node;
    readonly init: Node;
} | {
    readonly _tag: "Function";
    readonly node: Node;
} | {
    readonly _tag: "Class";
    readonly node: Node;
};
export interface Import {
    readonly specifier: string;
    /** The exported name, `*` for the namespace, or `default`. */
    readonly imported: string;
}
export interface Scope {
    readonly variables: Map<string, V>;
    readonly parent: Scope | undefined;
}
/** Where a function was written: the scope it closes over and its file. */
export interface Env {
    readonly scope: Scope;
    readonly module: Module;
}
/** A domain class instance: an event, a rejection or a command. */
export interface Brand {
    /**
     * `Option`: an `effect/Option`, whose `_tag` is `Some` or `None`.
     * `Recorded`: an event a decision recorded on an instance it read, whose
     * `cls` is that instance's place among the ones read.
     * `Matcher`: an `effect/Match` matcher being built, whose `cls` is the
     * value it matches and the cases it has so far.
     * `Duration`: an `effect/Duration` of a whole number of milliseconds, kept
     * in its one field, `millis`.
     * `Result`: an `effect/Result`, whose `_tag` is `Success` or `Failure`.
     * `BigDecimal`: an `effect/BigDecimal`, kept in its one field, `value`:
     * the text of a decimal the prover knows, or a real number of the solver's.
     * `HashSet` and `HashMap`: an `effect/HashSet` kept in `items`, and an
     * `effect/HashMap` kept in `entries` as pairs. No two items, and no two
     * keys, are equal on the path the value is on.
     * `Data`: an instance of a class of `effect/Data` or `effect/Schema`,
     * whose `cls` is the class.
     * `Ref`: an `effect/Ref` the code made, with what it holds now in `value`.
     * `Rational`: an `effect/Rational`, kept in `value` as a `BigDecimal` is.
     * `Redacted`: an `effect/Redacted`, with what it hides in `value`.
     */
    readonly kind: "Event" | "Rejection" | "Command" | "Option" | "Recorded" | "Matcher" | "Duration" | "Result" | "BigDecimal" | "HashSet" | "HashMap" | "Data" | "Ref" | "Rational" | "Redacted";
    readonly cls: unknown;
}
export type OpticStep = {
    readonly _tag: "Tag";
    readonly tag: string;
} | {
    readonly _tag: "Key";
    readonly key: string;
};
/**
 * A value while the prover runs the code. Concrete values are computed as
 * JavaScript would; a `Term` stands for every value an input can take.
 */
export type V = {
    readonly _tag: "Num";
    readonly value: number;
} | {
    readonly _tag: "Big";
    readonly value: bigint;
} | {
    readonly _tag: "Str";
    readonly value: string;
} | {
    readonly _tag: "Bool";
    readonly value: boolean;
} | {
    readonly _tag: "Null";
} | {
    readonly _tag: "Undef";
} | {
    readonly _tag: "Term";
    readonly term: Term;
    /** A `bigint`: it has no largest value, and never meets a `number`. */
    readonly big?: true;
    /**
     * One whole number divided by another. JavaScript rounds the result,
     * so only what is exact of it is translated: its floor and ceiling,
     * and how it compares with a whole number.
     */
    readonly quotient?: {
        readonly dividend: string;
        readonly divisor: number;
    };
} | {
    readonly _tag: "Obj";
    readonly fields: Readonly<Record<string, V>>;
    readonly brand?: Brand;
} | {
    readonly _tag: "Arr";
    readonly items: ReadonlyArray<V>;
}
/**
 * A list an input holds, before the code looks at it. Looking gives it a
 * length, which the run chooses, and an input for each item.
 */
 | {
    readonly _tag: "List";
    readonly name: string;
    readonly ast: unknown;
    /**
     * The list holds a hash set's items, or a hash map's pairs: no two
     * items, or no two keys, are equal.
     */
    readonly distinct?: "items" | "keys";
    /**
     * The list is what `split` gave of a string an input holds. Its first
     * and last parts are known without counting the parts; looking at the
     * rest gives it a number of parts, which the run chooses.
     */
    readonly split?: {
        readonly self: V;
        readonly separator: string;
        readonly first: V;
        /** `undefined` where the last part is not what follows the last separator. */
        readonly last?: V;
        readonly parts: (run: Run) => V;
    };
}
/**
 * A field of an input, before the code looks at it: whether an optional
 * field is there, which member of a union it is. It is a field of an
 * object, and what `??` or a function of `effect/Option` is given when it
 * reads one, until that looks at it. Reading the field makes the choice,
 * which the run takes each way; a field no code reads is never chosen, and
 * one read only for a value or a default is one conditional value.
 */
 | {
    readonly _tag: "Pending";
    readonly name: string;
    readonly ast: unknown;
    /** Whether the field may be left out. */
    readonly optional: boolean;
} | {
    readonly _tag: "Fn";
    readonly node: Node;
    readonly env: Env;
    /** Wrapped by `Effect.fn`: calling it gives an effect. */
    readonly effectful: boolean;
    /**
     * The function as its file exports it. Where the prover cannot read the
     * body, a call is a value it does not look inside, and this gives it.
     */
    readonly real?: {
        readonly name: string;
        readonly call: (...args: ReadonlyArray<unknown>) => unknown;
    };
} | {
    readonly _tag: "Native";
    readonly name: string;
    readonly call: (args: ReadonlyArray<V>, site: Site) => Eval<V>;
    /**
     * What a function written both ways was given, before `pipe` gives it
     * what it works on: `Option.getOrElse(() => 0)`.
     */
    readonly given?: ReadonlyArray<V>;
} | {
    readonly _tag: "Optic";
    readonly path: ReadonlyArray<OpticStep>;
} | {
    readonly _tag: "Lib";
    readonly module: string;
    readonly path: ReadonlyArray<string>;
    /** What the package gives here as the runtime loads it, where the prover looked. */
    readonly host?: unknown;
} | {
    readonly _tag: "Namespace";
    readonly module: Module;
} | {
    readonly _tag: "Host";
    readonly value: unknown;
    readonly name: string;
} | {
    readonly _tag: "Effect";
    readonly run: Eval<V>;
}
/**
 * An `effect/Stream`, as the library runs one: opening it gives a pull, and
 * each pull gives the next chunk of items, or `undefined` at the end.
 */
 | {
    readonly _tag: "Stream";
    readonly open: Eval<Pull>;
} | {
    readonly _tag: "Time";
    readonly millis: Term;
} | {
    readonly _tag: "Opaque";
    readonly what: string;
}
/**
 * What a function the prover does not read returned. The prover does not
 * look inside it: it is passed along, kept and recorded, and it is the same
 * value as another call of the function on the same arguments.
 */
 | {
    readonly _tag: "Applied";
    /** The function's name. */
    readonly name: string;
    /** The real function: it gives the value where the real code is run. */
    readonly call: (...args: ReadonlyArray<unknown>) => unknown;
    readonly args: ReadonlyArray<V>;
    /** Why the prover does not read the function, as what follows its name in a message. */
    readonly why: string;
    /** Text two calls share only when they are the same function on the same arguments. */
    readonly key: string;
};
export declare const num: (value: number) => V;
export declare const str: (value: string) => V;
export declare const bool: (value: boolean) => V;
export declare const nil: V;
export declare const undef: V;
export declare const term: (sort: Sort, text: string) => V;
export declare const obj: (fields: Readonly<Record<string, V>>, brand?: Brand) => V;
/** What a run keeps for an optional field it chose to leave out. */
export declare const absent: V;
/** `Option.none()`: there is one, as in the library. */
export declare const none: V;
/** `Option.some(value)`. */
export declare const some: (value: V) => V;
/** What an `Option` holds: `undefined` when the value is not one. */
export declare const optionOf: (v: V | undefined) => {
    readonly _tag: "None";
} | {
    readonly _tag: "Some";
    readonly value: V;
} | undefined;
/** A value as text two values share only when they are known to be the same. */
export declare const keyOf: (v: V) => string;
/** A call of an opaque function on these arguments. */
export declare const applied: (name: string, call: (...args: ReadonlyArray<unknown>) => unknown, args: ReadonlyArray<V>, why: string) => V;
/** A part of what an opaque function returned: the real function's result, read the same way. */
export declare const derived: (from: V & {
    readonly _tag: "Applied";
}, what: string, part: (value: unknown) => unknown) => V & {
    readonly _tag: "Applied";
};
/** Whether a value is a `bigint`. */
export declare const isBig: (v: V) => boolean;
/** A place in the source, for a message that names it. */
export interface Site {
    readonly module: Module;
    readonly node: Node;
}
/** The next chunk of a stream's items, or `undefined` when it has ended. */
export type Pull = Eval<ReadonlyArray<V> | undefined>;
declare const Rejected_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Rejected";
} & Readonly<A>;
/** `decide` refused the command. */
export declare class Rejected extends Rejected_base<{
    readonly rejection: V;
    /** The effect died: nothing that handles a failure handles it. */
    readonly defect?: boolean;
}> {
}
declare const NotTranslated_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "NotTranslated";
} & Readonly<A>;
/** The prover met code it cannot turn into a formula. */
export declare class NotTranslated extends NotTranslated_base<{
    readonly file: string;
    readonly line: number;
    readonly reason: string;
    /**
     * Whether the code reaches outside what the prover reads: a global, a
     * function it has no model for, a value it was given and changes. Nothing
     * then says the function it is in gives the same result for the same
     * arguments.
     */
    readonly reaches: boolean;
}> {
}
declare const Infeasible_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "Infeasible";
} & Readonly<A>;
/** The inputs this path assumes cannot occur. */
export declare class Infeasible extends Infeasible_base<{}> {
}
export type Stop = Rejected | NotTranslated | Infeasible;
export type Eval<A> = Effect.Effect<A, Stop>;
export declare const lineOf: (module: Module, offset: number) => number;
export declare const notTranslated: (site: Site, reason: string, reaches?: boolean) => NotTranslated;
/** A function the prover does not look inside: its real implementation checks each answer. */
export interface Application {
    readonly term: string;
    readonly argument: string;
    /** The sort of the argument. */
    readonly sort: Sort;
    /** The real function, on the argument's value in a counterexample. */
    readonly real: (argument: number) => string;
    /** Whether different arguments always give different results. */
    readonly injective: boolean;
}
/**
 * One run of the code along one path. A run replays the choices in `prefix`,
 * then takes the first option at every new one; the driver re-runs with the
 * last choice advanced until every path has been taken.
 */
export declare class Run {
    private readonly prefix;
    /** Picks at a choice the prefix does not make: without it, the first option. */
    private readonly pick?;
    private cursor;
    readonly taken: Array<{
        chosen: number;
        readonly of: number;
    }>;
    /** Declarations for the solver, by name. */
    readonly declarations: Map<string, string>;
    /** The input constants, in the order they were made. */
    readonly constants: Array<string>;
    /** What holds on this path. */
    readonly conditions: Array<string>;
    readonly applications: Map<string, Application>;
    /** The request contexts the code read, by key: each is an input, made once. */
    readonly contexts: Map<string, {
        readonly tag: unknown;
        readonly value: V;
    }>;
    /**
     * The lists the code looked at, by name, with the items this path gave
     * each; under `?name`, the fields it looked at, with what this path chose
     * for each; and under `??name`, the fields read only for a value or a
     * default, with the input that says whether each is there.
     */
    readonly lists: Map<string, V>;
    /** Each object an input holds with every field chosen, as this run settled it. */
    readonly settled: WeakMap<object, V>;
    /** The lists tried only up to a length, by name: longer ones were not looked at. */
    readonly bounds: Map<string, number>;
    /** The constants that are a `bigint`: they have no largest value. */
    readonly bigs: Set<string>;
    /**
     * Each hash set and hash map the code read in order, with the order this
     * path gave its items. The real one gives them in the order of their
     * hashes, which the prover does not know: every order is a path.
     */
    readonly orders: Array<{
        readonly kind: "HashSet" | "HashMap";
        /** What the set or the map holds, in no order: one that holds the same is read in the same order. */
        readonly key: string;
        readonly items: ReadonlyArray<V>;
    }>;
    /**
     * Each result of an opaque function the code tested, by the call's key:
     * whether it is truthy is an input, which the real function decides.
     */
    readonly tests: Map<string, {
        readonly term: Term;
        readonly applied: V;
        /** What the real result says of the term: `undefined` when it is not of the kind the code took it for. */
        readonly read: (value: unknown) => number | bigint | string | boolean | undefined;
    }>;
    /**
     * The command being run, when a run has several: a prefix on the name of
     * each request context it reads, so every command reads its own.
     */
    label: string;
    private readonly decided;
    constructor(prefix: ReadonlyArray<number>, 
    /** Picks at a choice the prefix does not make: without it, the first option. */
    pick?: ((of: number) => number) | undefined);
    /**
     * A run that goes on from the end of this one: what holds here holds there,
     * and its choices start over. One command of a sequence is then read once,
     * however many sequences go on from it.
     */
    fork(prefix: ReadonlyArray<number>, pick?: (of: number) => number): Run;
    /** Pick one of `of` options. */
    choose(of: number): number;
    /** A fresh input of the given sort. */
    constant(name: string, sort: Sort, big?: boolean): Term;
    assume(condition: string): void;
    /** The side of a condition this path is on, where it has taken one. */
    sideOf(condition: string): boolean | undefined;
    /**
     * Take one side of a condition, and remember which. Where only one side
     * can occur, `only` is that side: it is taken, and no path is made for the other.
     */
    branch(condition: string, only?: boolean): boolean;
    /** Whether what an opaque function returned is truthy: an input, the same for the same call. */
    truthy(applied: V & {
        readonly _tag: "Applied";
    }): Term;
    /**
     * Something the code reads of what an opaque function returned: the text
     * it is, how many items it has, whether it is a `Some`. It is an input,
     * the same for the same call, and the real function says what it is on
     * the arguments the solver picks.
     */
    observe(applied: V & {
        readonly _tag: "Applied";
    }, what: string, sort: Sort, read: (value: unknown) => number | bigint | string | boolean | undefined): Term;
    /** `name(argument)`, for a function known only by its real implementation. */
    apply(name: string, argument: Term, result: Sort, real: (argument: number) => string, known?: (result: Term) => string, injective?: boolean): Term;
}
/** The choices of the next path after `taken`, or `undefined` when every path was taken. */
export declare const nextPrefix: (taken: ReadonlyArray<{
    readonly chosen: number;
    readonly of: number;
}>) => ReadonlyArray<number> | undefined;
export {};
//# sourceMappingURL=Value.d.ts.map