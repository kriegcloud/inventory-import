import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import type * as HttpClientRequest from "effect/http/HttpClientRequest";
import type * as HttpClientResponse from "effect/http/HttpClientResponse";
import * as Layer from "effect/Layer";
import type * as AST from "effect/SchemaAST";
import type * as Stream from "effect/Stream";
import { rawResponseRootSymbol, resolveNode } from "./annotations.ts";
import * as API from "./api.ts";
import { HTTP_STATUS_MAP, InternalServerError } from "./errors.ts";
import { recordPageHeaders } from "./pagination.ts";
import { unwrapRedactedDeep } from "./plain-values.ts";
import {
  buildRequest,
  getAnn,
  getProps,
  hasPropAnn,
  mapKeys,
  mapsVerbatim,
  matchTypedError,
  responseErrorFields,
  responseHeaderMembers,
  withResponseHeaders,
  type ResponseHeaderMember,
} from "./protocol-http.ts";
import { checkResponse, withholdActual } from "./response-validation.ts";
import { parseRetryAfterForStatus } from "./retry-after.ts";
import * as Send from "./send.ts";
import { holdsSensitive, sensitiveValueSymbol, wrapSensitive } from "./sensitive.ts";
/**
 * Generic REST protocol factory for simple bearer/header-auth JSON APIs
 * (Neon, Fly.io, PlanetScale, Supabase, Turso, ...).
 *
 * `makeRestProtocol(options)` builds a core {@link API.Protocol} layer:
 *
 *   request:  credentials resolved from the CALLING fiber's context on every
 *             request (the layer itself is memoized per process -- see
 *             `core/api`), auth headers + base URL from the provider's
 *             options, request built by `buildRequest` from
 *             `core/protocol-http` (deep-unwrapping any `Redacted` input
 *             values first)
 *
 *   response: 2xx JSON -> optional `transformResponse` -> recursive wire->TS
 *             key mapping (`mapKeys`) -> in strict mode, a schema check
 *             failing with the provider's `parseError` (see
 *             `core/response-validation`) -> `Redacted` wrapping of members
 *             marked with {@link SensitiveValue}; non-2xx -> typed error:
 *             the provider's `classifyError`, then per-op matcher
 *             classes (`matchTypedError`), then the status
 *             map (default `HTTP_STATUS_MAP`), then an `InternalServerError`
 *             for unmapped 5xx, then the provider's `unknownError` fallback
 *             -- with `retryAfter` durations stamped from the standard hint
 *             headers on retryable statuses.
 *
 *   stream:   an `API.makeStreaming` operation with a `framing` config
 *             ({@link StreamFraming}) emits each frame of the body as it
 *             arrives, decoded as one element of the output's `items`; a
 *             plain call collects them.
 *
 * Anything provider-specific (envelope quirks, bespoke error codes) belongs
 * in the provider package -- via these options or a hand-written protocol.
 */
import { httpSymbol, makeAnnotation, type HttpTrait } from "./trait.ts";
import type { UnknownErrorProps } from "./unknown-error.ts";

// =============================================================================
// Traits
// =============================================================================

export { sensitiveValueSymbol };
/**
 * Marks a string member, map value or list element as sensitive (mirrors
 * `smithy.api#sensitive`). The REST protocol wraps decoded values in
 * `Redacted` on the way out (an untyped `S.Unknown` value whole) and
 * accepts `string | Redacted<string>` on the way in (unwrapped before
 * serialization). Takes an ignored argument so generators can inline the
 * smithy trait value (`T.SensitiveValue({})`).
 */
export const SensitiveValue = (_value?: unknown) => makeAnnotation(sensitiveValueSymbol, true);

export const rawResponseSymbol = /*@__PURE__*/ Symbol.for("@distilled.cloud/core/raw-response");
/**
 * Marks the sole output member that carries a bare (array/scalar) response
 * body (mirrors `com.distilled.openapi#rawResponse`).
 */
export const RawResponse = (_value?: unknown) => makeAnnotation(rawResponseSymbol, true);

/**
 * Marks a response schema whose ENTIRE value is the response body (the
 * generator's `rootPipe` for synthesized bare-payload wrappers): the emitted
 * response type IS the payload type and the protocol returns the mapped body
 * directly.
 */
export { rawResponseRootSymbol };
export const RawResponseRoot = () => makeAnnotation(rawResponseRootSymbol, true);

export const binaryResponseSymbol = /*@__PURE__*/ Symbol.for(
  "@distilled.cloud/core/binary-response",
);

/** Decode a successful raw binary response as bytes, without text conversion. */
export const BinaryResponse = () => makeAnnotation(binaryResponseSymbol, true);

// =============================================================================
// Value helpers
// =============================================================================

export { unwrapRedactedDeep };

export { wrapSensitive };

/**
 * Whether any member, map value or list element reachable from `ast` is
 * marked {@link SensitiveValue}. Such an output is decoded through
 * {@link wrapSensitive}, and its parse errors withhold the response body (see
 * {@link checkSuccess}, which every REST-style protocol's success path uses).
 */
export const hasSensitiveMember: (ast: AST.AST) => boolean = holdsSensitive;

// =============================================================================
// Protocol factory
// =============================================================================

/** What the wire said about a failure, for the `unknownError` fallback. */
export interface RestErrorInfo {
  readonly status: number;
  /** Error code from the envelope (services vary between string and number). */
  readonly code?: string | number;
  readonly message: string;
  /** Parsed JSON body, or the raw text when the body wasn't JSON. */
  readonly body: unknown;
  readonly headers: Record<string, string | undefined>;
}

/**
 * The core {@link UnknownErrorProps} of a failure, for an SDK's
 * `unknownError`: `new UnknownNeonError(unknownErrorProps(info))`. A number
 * code becomes its string.
 */
export const unknownErrorProps = (info: RestErrorInfo): UnknownErrorProps => ({
  status: info.status,
  code: info.code === undefined ? undefined : String(info.code),
  message: info.message,
  body: info.body,
});

/**
 * A 2xx body that failed strict validation, or a non-JSON 2xx body for an
 * output with sensitive members, for the `parseError` option.
 */
export interface RestParseErrorInfo {
  /** `"[REDACTED]"` when the output has sensitive members. */
  readonly body: unknown;
  readonly cause: unknown;
}

export interface RestErrorEnvelope {
  readonly code?: string | number;
  readonly message?: string;
}

export interface RestProtocolOptions<C> {
  /**
   * Resolve credentials ON THE CALLING FIBER -- evaluated per request, never
   * at layer build time, so context-provided credentials and token refreshes
   * are picked up. Either an effect, or -- for the distilled
   * credentials-service convention -- the `Credentials` service key whose
   * value is that effect (read from the calling fiber's context; an
   * already-resolved `Effect.succeed` value costs no extra fiber step). Its
   * error/requirement channels are
   * erased at the protocol boundary (Protocol effects carry none) and
   * reintroduced for callers by the generated `<Sdk>OpError` /
   * `<Sdk>OpContext` annotations.
   */
  readonly credentials: Effect.Effect<C, any, any> | Context.Key<any, Effect.Effect<C, any, any>>;
  /**
   * API base URL from the resolved credentials. Receives the operation's
   * route so APIs with more than one endpoint (e.g. S2's account vs
   * per-basin hosts, chosen by path) can route per request; single-endpoint
   * providers ignore the argument. `server` is the operation's host name
   * (`T.Http({ server })`) for APIs that serve some operations from another
   * host; map it to a base URL from the credentials. A THROWN error (e.g. a
   * required scope missing from the credentials) is caught and surfaced on
   * the calling effect's error channel rather than dying as a defect.
   */
  readonly baseUrl: (
    credentials: C,
    target: { readonly uri: string; readonly method: string; readonly server?: string | undefined },
  ) => string;
  /** Auth (and any fixed) headers from the resolved credentials. */
  readonly headers: (credentials: C) => Record<string, string>;
  /**
   * Extract `{ code?, message? }` from a parsed non-2xx JSON body. Default:
   * lenient `{ code?, message? | error? }` (covers the common REST error
   * envelopes).
   */
  readonly errorEnvelope?: (body: unknown) => RestErrorEnvelope | undefined;
  /**
   * JSON pointer to the object that holds a failure's fields when the
   * provider nests them, e.g. `"/error"` for `{ error: { status, details } }`.
   * A typed error's declared fields are read there first, then at the top
   * level of the body.
   */
  readonly errorFieldsAt?: string;
  /**
   * HTTP status -> error class constructed as `new Cls({ message, retryAfter
   * })`. Default: core `HTTP_STATUS_MAP`. Consulted after per-op typed error
   * matching; unmapped 5xx fall back to `InternalServerError`, everything
   * else to {@link unknownError}.
   */
  readonly statusMap?: Readonly<Record<number, new (args: any) => any>>;
  /**
   * The provider's own reading of a failure, consulted before per-op typed
   * matching and the status map: return the error to fail with, or
   * `undefined` to decode the failure as usual. For rules a status alone
   * can't express, e.g. a 403 that is a rate limit because of its headers.
   */
  readonly classifyError?: (info: RestErrorInfo) => unknown;
  /**
   * Fallback error for failures nothing else matched: the SDK's
   * `Unknown<Sdk>Error`, built from {@link unknownErrorProps}. Only non-5xx
   * statuses reach it (unmapped 5xx are `InternalServerError`), so the class
   * carries no retryable category.
   */
  readonly unknownError: (info: RestErrorInfo) => unknown;
  /**
   * The SDK's `<Sdk>ParseError`, raised when a 2xx body does not match the
   * operation's output schema in strict mode (see
   * `core/response-validation`), and in every mode when a 2xx body for an
   * output with sensitive members is not JSON. `body` is the parsed JSON, or
   * the raw text when the body wasn't JSON, and `"[REDACTED]"` for an output
   * with sensitive members; `cause` is the schema error, or `"Invalid JSON
   * response"`.
   */
  readonly parseError: (info: RestParseErrorInfo) => unknown;
  /** Transform the parsed 2xx JSON before decoding (e.g. stripNulls). */
  readonly transformResponse?: (body: unknown) => unknown;
  /** Passed through to `buildRequest` (member-header transforms). */
  readonly mapMemberHeader?: (name: string, value: string) => string;
  /** Passed through to `buildRequest` (wire names for unmodeled input keys). */
  readonly unknownKeyToWire?: (key: string) => string;
  /** Passed through to `buildRequest`: send `{}` when a bodied call has no body members. */
  readonly emptyJsonBody?: boolean;
}

/** The body of a streamed 2xx response, for {@link StreamFraming.stream}. */
export interface FramedBody {
  readonly body: Stream.Stream<Uint8Array, unknown>;
  /**
   * Decode one parsed frame as one element of the output's `items`, as a
   * 2xx body decodes (key mapping, strict validation, `Redacted`).
   */
  readonly item: (json: unknown, text: string) => Effect.Effect<unknown, unknown>;
  /** The SDK's parse error for a frame that is not JSON. */
  readonly invalid: (text: string) => unknown;
}

/** A plain call's framed body, read whole: the output JSON, or not JSON. */
export interface CollectedBody {
  readonly json: unknown;
  readonly nonJson: boolean;
}

/**
 * How a server-streaming operation's body is framed (`API.makeStreaming`,
 * output `{ items }`): its `framing` config, e.g. `ndjson` from
 * core/ndjson. An operation without one can't stream (`.stream()` fails
 * with `SdkError`, see `API.cannotStream`).
 */
export interface StreamFraming {
  /**
   * A plain call's whole body as `{ items }`, or `undefined` when the
   * response's `Content-Type` is not this framing (decoded as usual).
   */
  readonly collect: (text: string, contentType: string | undefined) => CollectedBody | undefined;
  /**
   * Each frame as it arrives, through `item`. `open` sends the request and
   * fails with the operation's typed error on a failed status.
   */
  readonly stream: (open: Effect.Effect<FramedBody, unknown>) => Stream.Stream<unknown, unknown>;
}

const defaultErrorEnvelope = (body: unknown): RestErrorEnvelope | undefined => {
  if (body === null || typeof body !== "object") return undefined;
  const b = body as Record<string, unknown>;
  const code = typeof b.code === "string" || typeof b.code === "number" ? b.code : undefined;
  const message =
    typeof b.message === "string" ? b.message : typeof b.error === "string" ? b.error : undefined;
  return { code, message };
};

// Bridge: Protocol.decode is typed as Effect<unknown> (no error channel),
// but REST failures are real typed errors that operations re-surface via
// their `errors: [...]` lists. Fail with the instance and erase the type
// here; the generated operation annotations reintroduce it for callers.
const fail = (e: unknown): Effect.Effect<never> => Effect.fail(e) as Effect.Effect<never>;

// =============================================================================
// 2xx bodies
// =============================================================================

/** A 2xx body a protocol read, for {@link checkSuccess}. */
export interface SuccessBody {
  /** The value to check and return: the body mapped onto the output's TS names. */
  readonly value: unknown;
  /** What a parse error reports as `body` for an output without sensitive members. */
  readonly body: unknown;
  /** Whether the body was not JSON. */
  readonly nonJson: boolean;
}

/** The outcome of {@link checkSuccess}: the value, or the parse error's fields. */
export type SuccessCheck =
  | { readonly ok: true; readonly value: unknown }
  | { readonly ok: false; readonly error: RestParseErrorInfo };

/**
 * Check a 2xx body against the operation's output schema and deliver its
 * sensitive values as `Redacted`. Every REST-style protocol ends its success
 * path here, so all of them treat a body that can hold a secret alike:
 *
 * - The checked value comes back through {@link wrapSensitive}.
 * - A mismatch (validating modes, see `core/response-validation`) reports
 *   `read.body` and the schema error.
 * - For an output with sensitive members ({@link hasSensitiveMember}), a
 *   non-JSON body fails in every mode with `"Invalid JSON response"`, and a
 *   mismatch reports `body: "[REDACTED]"` and the schema error without the
 *   value it found (`withholdActual`).
 *
 * Synchronous, for protocols that already hold the calling fiber's context;
 * {@link validateSuccess} is the `Effect` form.
 */
export const checkSuccess = (
  context: Context.Context<any>,
  outputAst: AST.AST,
  read: SuccessBody,
): SuccessCheck => {
  const sensitive = hasSensitiveMember(outputAst);
  if (read.nonJson && sensitive) {
    return { ok: false, error: { body: "[REDACTED]", cause: "Invalid JSON response" } };
  }
  const invalid = checkResponse(context, outputAst, read.value);
  if (invalid !== undefined) {
    return {
      ok: false,
      error: sensitive
        ? { body: "[REDACTED]", cause: withholdActual(invalid) }
        : { body: read.body, cause: invalid },
    };
  }
  return { ok: true, value: sensitive ? wrapSensitive(outputAst, read.value) : read.value };
};

/**
 * {@link checkSuccess} on the calling fiber, failing with `parseError` (the
 * SDK's `<Sdk>ParseError`) built from the withheld-or-not fields.
 */
export const validateSuccess = <E>(
  outputAst: AST.AST,
  read: SuccessBody,
  parseError: (info: RestParseErrorInfo) => E,
): Effect.Effect<unknown, E> =>
  Effect.withFiber((fiber) => {
    const checked = checkSuccess(fiber.context as Context.Context<any>, outputAst, read);
    return checked.ok ? Effect.succeed(checked.value) : Effect.fail(parseError(checked.error));
  });

/** Per-operation decode facts, read from the output schema once. */
interface DecodePlan {
  readonly binary: boolean;
  readonly verbatim: boolean;
  /**
   * A member of a structure output that receives the whole body
   * (`T.RawResponse()` next to header members), e.g. a bare JSON array with
   * its next-page token in a response header.
   */
  readonly bodyMember: AST.PropertySignature | undefined;
  /** The output is a bare string, so an empty body decodes to `""`. */
  readonly text: boolean;
  /** Members read from response headers (`T.Header`). */
  readonly headers: ReadonlyArray<ResponseHeaderMember>;
}

const decodePlans = /*@__PURE__*/ new WeakMap<AST.AST, DecodePlan>();
const decodePlanFor = (outputAst: AST.AST): DecodePlan => {
  let plan = decodePlans.get(outputAst);
  if (plan === undefined) {
    plan = {
      binary: getAnn(outputAst, binaryResponseSymbol) !== undefined,
      verbatim: mapsVerbatim(outputAst, "decode"),
      text: resolveNode(outputAst)._tag === "String",
      headers: responseHeaderMembers(outputAst),
      bodyMember: getProps(outputAst).find((prop) => hasPropAnn(prop, rawResponseSymbol)),
    };
    decodePlans.set(outputAst, plan);
  }
  return plan;
};

/**
 * The outcome of decoding a response body: the value, or the failure the
 * call fails with. Plain data, so decoding stays synchronous.
 */
type Decoded =
  | { readonly ok: true; readonly value: unknown }
  | { readonly ok: false; readonly error: unknown };

/**
 * Build a `Layer<Protocol>` for a simple REST JSON API. Assign the result to
 * a module-level const in the provider's `protocol.ts` -- `API.make` memoizes
 * protocol layers by value identity.
 */
export const makeRestProtocol = <C>(options: RestProtocolOptions<C>): Layer.Layer<API.Protocol> => {
  const errorEnvelope = options.errorEnvelope ?? defaultErrorEnvelope;
  const statusMap: Readonly<Record<number, (new (args: any) => any) | undefined>> =
    options.statusMap ?? HTTP_STATUS_MAP;
  const credentialsKey = Context.isKey(options.credentials)
    ? (options.credentials as Context.Key<any, Effect.Effect<C, any, any>>)
    : undefined;
  const credentialsEffect = options.credentials as Effect.Effect<C>;

  /** The calling fiber's credentials, then `f` on them. */
  const withCredentials = <B>(
    context: Context.Context<any>,
    f: (creds: C) => Effect.Effect<B, any, any>,
  ): Effect.Effect<B, any, any> =>
    API.withValue(
      credentialsKey === undefined ? credentialsEffect : Context.get(context, credentialsKey),
      f,
    );

  /**
   * The request; fails with the error a refusing `baseUrl` threw, or with
   * `InvalidInput` for a label that would address another resource.
   */
  const requestFor = (
    creds: C,
    input: unknown,
    inputAst: AST.AST,
  ): Effect.Effect<HttpClientRequest.HttpClientRequest> => {
    const http = getAnn(inputAst, httpSymbol) as HttpTrait | undefined;
    let baseUrl: string;
    try {
      baseUrl = options.baseUrl(creds, {
        uri: http?.uri ?? "",
        method: http?.method ?? "",
        server: http?.server,
      });
    } catch (e) {
      // A baseUrl that refuses the route (missing scope in the
      // credentials) fails the call with that error, typed for callers by
      // the operation's declared error channel.
      return fail(e);
    }
    return buildRequest({
      input: unwrapRedactedDeep(input),
      inputAst,
      baseUrl,
      headers: options.headers(creds),
      mapMemberHeader: options.mapMemberHeader,
      unknownKeyToWire: options.unknownKeyToWire,
      emptyJsonBody: options.emptyJsonBody,
    }) as Effect.Effect<HttpClientRequest.HttpClientRequest>;
  };

  /** Map a read response body to the call's outcome. */
  const decodeText = (
    context: Context.Context<any>,
    status: number,
    headers: Record<string, string | undefined>,
    text: string,
    outputAst: AST.AST,
    errorClasses: ReadonlyArray<unknown>,
    framing: StreamFraming | undefined,
  ): Decoded => {
    // Read as text and parse tolerantly -- error pages are often non-JSON.
    let json: unknown;
    let nonJson = false;
    if (text.trim().length > 0) {
      try {
        json = JSON.parse(text);
      } catch {
        nonJson = true;
      }
    }

    if (status >= 400) {
      const env = (nonJson ? undefined : errorEnvelope(json)) ?? {};
      const message = env.message ?? (nonJson && text.trim() ? text.trim() : `HTTP ${status}`);

      // 0. The provider's own reading of the failure.
      if (options.classifyError) {
        const classified = options.classifyError({
          status,
          code: env.code,
          message,
          body: nonJson ? text : json,
          headers,
        });
        if (classified !== undefined) return { ok: false, error: classified };
      }

      // The body and headers every error below carries.
      const response = { body: nonJson ? text : json, headers, fieldsAt: options.errorFieldsAt };

      // 1. Per-operation typed error (matcher metadata on the class).
      const typed = matchTypedError(
        errorClasses,
        status,
        [
          {
            code: typeof env.code === "number" ? env.code : undefined,
            message,
          },
        ],
        response,
      );
      if (typed !== undefined) return { ok: false, error: typed };

      // 2. Status-mapped class (retryAfter only stamps on retryable
      //    statuses -- parseRetryAfterForStatus gates on that).
      const StatusErrorClass = statusMap[status];
      if (StatusErrorClass) {
        return {
          ok: false,
          error: new StatusErrorClass({
            message,
            ...responseErrorFields(undefined, response),
            retryAfter: parseRetryAfterForStatus(status, headers),
          }),
        };
      }

      // 3. Unmapped 5xx (e.g. proxy-specific statuses) -> retryable server
      //    error rather than the unknown fallback.
      if (status >= 500) {
        return {
          ok: false,
          error: new InternalServerError({
            message,
            ...responseErrorFields(undefined, response),
            retryAfter: parseRetryAfterForStatus(status, headers),
          }),
        };
      }

      // 4. Provider fallback.
      return {
        ok: false,
        error: options.unknownError({
          status,
          code: env.code,
          message,
          body: nonJson ? text : json,
          headers,
        }),
      };
    }

    // A framed (streamed) body that a plain call collects: its frames are
    // the output's `items`.
    const collected = framing?.collect(text, headers["content-type"]);
    return collected === undefined
      ? decodeSuccess(context, headers, text, json, nonJson, outputAst)
      : decodeSuccess(context, headers, text, collected.json, collected.nonJson, outputAst);
  };

  /**
   * A 2xx body: the response body IS the payload (no envelope). Wire->TS
   * key mapping is schema-driven; `RawResponseRoot` responses are the body
   * verbatim (mapKeys handles arrays/scalars structurally either way).
   * Strict mode (core/response-validation) checks the mapped body against
   * the output schema -- a non-JSON body reaches it as a string and fails
   * there unless the operation's output is itself a string. For an output
   * with sensitive members, a non-JSON body fails in every mode and parse
   * errors withhold the body.
   */
  const decodeSuccess = (
    context: Context.Context<any>,
    headers: Record<string, string | undefined>,
    text: string,
    json: unknown,
    nonJson: boolean,
    outputAst: AST.AST,
  ): Decoded => {
    const plan = decodePlanFor(outputAst);
    let body: unknown = nonJson ? text : json === undefined ? (plan.text ? "" : {}) : json;
    if (options.transformResponse) body = options.transformResponse(body);
    const mapped =
      plan.bodyMember !== undefined
        ? { [plan.bodyMember.name]: mapKeys(plan.bodyMember.type, body, "decode") }
        : plan.verbatim
          ? body
          : mapKeys(outputAst, body, "decode");
    const checked = checkSuccess(context, outputAst, {
      value: withResponseHeaders(plan.headers, mapped, headers),
      body: nonJson ? text : json,
      nonJson,
    });
    return checked.ok ? checked : { ok: false, error: options.parseError(checked.error) };
  };

  const decodeResponse = (
    context: Context.Context<any>,
    response: HttpClientResponse.HttpClientResponse,
    outputAst: AST.AST,
    errorClasses: ReadonlyArray<unknown>,
    framing: StreamFraming | undefined,
  ): Effect.Effect<unknown> =>
    // A body read that fails (reset or abort mid-body) fails the call with
    // its `HttpClientError`, which every operation's error channel declares.
    (response.status >= 200 && response.status < 300 && decodePlanFor(outputAst).binary
      ? Effect.map(response.arrayBuffer, (bytes) => new Uint8Array(bytes))
      : Effect.flatMap(response.text, (text) => {
          recordPageHeaders(context, response.headers);
          const decoded = decodeText(
            context,
            response.status,
            response.headers as Record<string, string | undefined>,
            text ?? "",
            outputAst,
            errorClasses,
            framing,
          );
          return decoded.ok ? Effect.succeed(decoded.value) : fail(decoded.error);
        })) as Effect.Effect<unknown>;

  /**
   * Send `op`'s request on the calling fiber; decode the response, or open
   * it as a stream (`openFramed`).
   */
  const send = (
    op: API.PreparedOperation,
    input: unknown,
    streaming: boolean,
  ): Effect.Effect<unknown> =>
    Effect.withFiber((fiber) => {
      const context = fiber.context as Context.Context<any>;
      return withCredentials(context, (creds) => {
        const client = Context.get(context, HttpClient.HttpClient);
        return Effect.flatMap(requestFor(creds, input, op.inputAst), (request) =>
          Effect.flatMap(Send.send(context, client, request), (response) =>
            streaming
              ? openFramed(context, response, op)
              : decodeResponse(
                  context,
                  response,
                  op.outputAst,
                  op.errors,
                  op.config.framing as StreamFraming | undefined,
                ),
          ),
        );
      });
    }) as Effect.Effect<unknown>;

  /**
   * A streaming call's response: its body and a frame decoder. A failed
   * status fails with the operation's typed error, as a plain call does.
   */
  const openFramed = (
    context: Context.Context<any>,
    response: HttpClientResponse.HttpClientResponse,
    op: API.PreparedOperation,
  ): Effect.Effect<unknown> =>
    response.status >= 400
      ? decodeResponse(context, response, op.outputAst, op.errors, undefined)
      : Effect.succeed<FramedBody>({
          body: response.stream,
          item: (json, text) => {
            const headers = response.headers as Record<string, string | undefined>;
            // A frame schema of its own (an operation that streams only when
            // its input asks), else one element of the output's `items`.
            const itemAst = op.config.items?.ast;
            if (itemAst !== undefined) {
              const decoded = decodeSuccess(context, headers, text, json, false, itemAst);
              return decoded.ok ? Effect.succeed(decoded.value) : fail(decoded.error);
            }
            const decoded = decodeSuccess(
              context,
              headers,
              text,
              { items: [json] },
              false,
              op.outputAst,
            );
            return decoded.ok
              ? Effect.succeed(
                  (decoded.value as { readonly items: ReadonlyArray<unknown> }).items[0],
                )
              : fail(decoded.error);
          },
          invalid: (text) =>
            options.parseError({
              body: hasSensitiveMember(op.outputAst) ? "[REDACTED]" : text,
              cause: "Invalid JSON frame",
            }),
        });

  return Layer.succeed(
    API.Protocol,
    API.Protocol.of({
      // Erase encode's credentials requirement (resolved on the calling
      // fiber; see RestProtocolOptions.credentials).
      encode: ({ input, inputAst }) =>
        Effect.withFiber((fiber) =>
          withCredentials(fiber.context as Context.Context<any>, (creds) =>
            requestFor(creds, input, inputAst),
          ),
        ) as Effect.Effect<HttpClientRequest.HttpClientRequest>,
      decode: ({ response, outputAst, errors, config }) =>
        Effect.withFiber((fiber) =>
          decodeResponse(
            fiber.context as Context.Context<any>,
            response,
            outputAst,
            errors,
            config.framing as StreamFraming | undefined,
          ),
        ),
      call: (op, input) => send(op, input, false),
      stream: (op, input) => {
        const framing = op.config.framing as StreamFraming | undefined;
        return framing === undefined
          ? API.cannotStream(op)
          : framing.stream(send(op, input, true) as Effect.Effect<FramedBody>);
      },
    }),
  );
};
