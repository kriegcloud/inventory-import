import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const RepositoryConfigNotFound_base: S.TaggedErrorClass<"RepositoryConfigNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class RepositoryConfigNotFound extends /*@__PURE__*/ RepositoryConfigNotFound_base {
}
export interface CancelBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
}
export type CancelBuildResultBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export interface CancelBuildResult {
    buildOutcome?: CancelBuildResultBuildOutcome | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    stoppedOn?: string | null | undefined;
}
export type CancelBuildResponse = CancelBuildResult;
export interface CreateTokenRequest {
    /** Account identifier. */
    accountId: string;
    buildTokenName: string;
    buildTokenSecret: string;
    cloudflareTokenId: string;
}
export interface CreateTokenResult {
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    cloudflareTokenId?: string | null | undefined;
    ownerType?: string | null | undefined;
}
export type CreateTokenResponse = CreateTokenResult;
export type CreateTriggerRequestBranchExcludesList = Array<string>;
export type CreateTriggerRequestBranchIncludesList = Array<string>;
export type CreateTriggerRequestPathExcludesList = Array<string>;
export type CreateTriggerRequestPathIncludesList = Array<string>;
export interface CreateTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Branch patterns that must not start builds. */
    branchExcludes: CreateTriggerRequestBranchExcludesList;
    /** Branch patterns that can start builds. */
    branchIncludes: CreateTriggerRequestBranchIncludesList;
    /** Command to build the Worker. */
    buildCommand: string;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid: string;
    /** Command to deploy the Worker. */
    deployCommand: string;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId: string;
    /** Path patterns that must not start builds. */
    pathExcludes: CreateTriggerRequestPathExcludesList;
    /** Path patterns that can start builds. */
    pathIncludes: CreateTriggerRequestPathIncludesList;
    /** Repository connection UUID. */
    repoConnectionUuid: string;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory: string;
    /** Human-readable name of the build trigger. */
    triggerName: string;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | undefined;
}
export type CreateTriggerResultBranchExcludesList = Array<string>;
export type CreateTriggerResultBranchIncludesList = Array<string>;
export type CreateTriggerResultPathExcludesList = Array<string>;
export type CreateTriggerResultPathIncludesList = Array<string>;
export type CreateTriggerResultRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface CreateTriggerResultRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: CreateTriggerResultRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface CreateTriggerResult {
    /** Branch patterns that must not start builds. */
    branchExcludes?: CreateTriggerResultBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: CreateTriggerResultBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: CreateTriggerResultPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: CreateTriggerResultPathIncludesList | null | undefined;
    repoConnection?: CreateTriggerResultRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export type CreateTriggerResponse = CreateTriggerResult;
export interface DeleteReposConnectionRequest {
    /** Account identifier. */
    accountId: string;
    /** Repository connection UUID. */
    repoConnectionUuid: string;
}
export type DeleteReposConnectionResponse = unknown;
export interface DeleteTokenRequest {
    /** Account identifier. */
    accountId: string;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid: string;
}
export type DeleteTokenResponse = unknown;
export interface DeleteTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export type DeleteTriggerResponse = unknown;
export interface DeleteTriggersEnvironmentVariableRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Environment variable key. */
    environmentVariableKey: string;
}
export type DeleteTriggersEnvironmentVariableResponse = unknown;
export interface DeployHooksCreateRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Git branch name. */
    branch: string;
    /** Deploy hook name (1-58 characters). */
    deployHookName: string;
}
export interface DeployHooksCreateResult {
    /** Git branch name. */
    branch?: string | null | undefined;
    createdOn?: string | null | undefined;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null | undefined;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
}
export type DeployHooksCreateResponse = DeployHooksCreateResult;
export interface DeployHooksDeleteRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export type DeployHooksDeleteResult = DeployHooksCreateResult;
export type DeployHooksDeleteResponse = DeployHooksCreateResult;
export interface DeployHooksGetRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export type DeployHooksGetResult = DeployHooksCreateResult;
export type DeployHooksGetResponse = DeployHooksCreateResult;
export interface DeployHooksListRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
}
export interface DeployHooksListResultItemLatestBuild {
    createdOn?: string | null | undefined;
}
export interface DeployHooksListResultItem {
    /** Git branch name. */
    branch?: string | null | undefined;
    createdOn?: string | null | undefined;
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null | undefined;
    /** Deploy hook UUID. */
    deployHookUuid?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    latestBuild?: DeployHooksListResultItemLatestBuild | null | undefined;
    modifiedOn?: string | null | undefined;
}
export type DeployHooksListResultList = Array<DeployHooksListResultItem>;
export type DeployHooksListResponse = DeployHooksListResultList;
export interface DeployHooksTriggerRequest {
    /** Deploy hook UUID. */
    deployHookUuid: string;
}
export type DeployHooksTriggerResultStatus = "queued" | "initializing" | "running" | "stopped";
export interface DeployHooksTriggerResult {
    /** True if a pending build already exists for this branch */
    alreadyExists?: boolean | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    status?: DeployHooksTriggerResultStatus | null | undefined;
}
export type DeployHooksTriggerResponse = DeployHooksTriggerResult;
export interface DeployHooksUpdateRequest {
    /** Account identifier. */
    accountId: string;
    /** Human-readable name of the Worker. */
    scriptName: string;
    /** Deploy hook UUID. */
    deployHookUuid: string;
    /** Git branch name. */
    branch: string;
    /** Deploy hook name (1-58 characters). */
    deployHookName: string;
}
export type DeployHooksUpdateResult = DeployHooksCreateResult;
export type DeployHooksUpdateResponse = DeployHooksCreateResult;
export interface GetAccountLimitsRequest {
    /** Account identifier. */
    accountId: string;
}
export interface GetAccountLimitsResult {
    /** When build minutes will refresh (only for non-paid plans) */
    buildMinutesRefreshOn?: string | null | undefined;
    /** Whether build minutes limit has been reached (only for non-paid plans) */
    hasReachedBuildMinutesLimit?: boolean | null | undefined;
}
export type GetAccountLimitsResponse = GetAccountLimitsResult;
export interface GetBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
}
export type GetBuildResultBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type GetBuildResultBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type GetBuildResultBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type GetBuildResultBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildResultBuildTriggerMetadata {
    author?: string | null | undefined;
    /** Git branch name. */
    branch?: string | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    buildTriggerSource?: GetBuildResultBuildTriggerMetadataBuildTriggerSource | null | undefined;
    /** Git commit hash */
    commitHash?: string | null | undefined;
    commitMessage?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    environmentVariables?: GetBuildResultBuildTriggerMetadataEnvironmentVariablesMap | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: GetBuildResultBuildTriggerMetadataProviderType | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
}
export interface GetBuildResultDeployHook {
    /** Deploy hook name (1-58 characters). */
    deployHookName?: string | null | undefined;
}
export interface GetBuildResultPullRequest {
    closedOn?: string | null | undefined;
    createdOn?: string | null | undefined;
    pullRequestUrl?: string | null | undefined;
}
export type GetBuildResultStatus = "queued" | "initializing" | "running" | "stopped";
export type GetBuildResultTriggerBranchExcludesList = Array<string>;
export type GetBuildResultTriggerBranchIncludesList = Array<string>;
export type GetBuildResultTriggerPathExcludesList = Array<string>;
export type GetBuildResultTriggerPathIncludesList = Array<string>;
export type GetBuildResultTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildResultTriggerRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: GetBuildResultTriggerRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface GetBuildResultTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: GetBuildResultTriggerBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: GetBuildResultTriggerBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: GetBuildResultTriggerPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: GetBuildResultTriggerPathIncludesList | null | undefined;
    repoConnection?: GetBuildResultTriggerRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export interface GetBuildResult {
    buildOutcome?: GetBuildResultBuildOutcome | null | undefined;
    buildTriggerMetadata?: GetBuildResultBuildTriggerMetadata | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deployHook?: GetBuildResultDeployHook | null | undefined;
    initializingOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null | undefined;
    pullRequest?: GetBuildResultPullRequest | null | undefined;
    runningOn?: string | null | undefined;
    status?: GetBuildResultStatus | null | undefined;
    stoppedOn?: string | null | undefined;
    /** Trigger information without build_token_uuid */
    trigger?: GetBuildResultTrigger | null | undefined;
}
export type GetBuildResponse = GetBuildResult;
export interface GetBuildsByVersionRequest {
    /** Account identifier. */
    accountId: string;
    /** Comma-separated list of version UUIDs (max 20). */
    versionIds: string;
}
export type GetBuildsByVersionResultBuildsValueBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type GetBuildsByVersionResultBuildsValueBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type GetBuildsByVersionResultBuildsValueBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type GetBuildsByVersionResultBuildsValueBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildsByVersionResultBuildsValueBuildTriggerMetadata {
    author?: string | null | undefined;
    /** Git branch name. */
    branch?: string | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    buildTriggerSource?: GetBuildsByVersionResultBuildsValueBuildTriggerMetadataBuildTriggerSource | null | undefined;
    /** Git commit hash */
    commitHash?: string | null | undefined;
    commitMessage?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    environmentVariables?: GetBuildsByVersionResultBuildsValueBuildTriggerMetadataEnvironmentVariablesMap | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: GetBuildsByVersionResultBuildsValueBuildTriggerMetadataProviderType | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
}
export type GetBuildsByVersionResultBuildsValueDeployHook = GetBuildResultDeployHook;
export type GetBuildsByVersionResultBuildsValuePullRequest = GetBuildResultPullRequest;
export type GetBuildsByVersionResultBuildsValueStatus = "queued" | "initializing" | "running" | "stopped";
export type GetBuildsByVersionResultBuildsValueTriggerBranchExcludesList = Array<string>;
export type GetBuildsByVersionResultBuildsValueTriggerBranchIncludesList = Array<string>;
export type GetBuildsByVersionResultBuildsValueTriggerPathExcludesList = Array<string>;
export type GetBuildsByVersionResultBuildsValueTriggerPathIncludesList = Array<string>;
export type GetBuildsByVersionResultBuildsValueTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetBuildsByVersionResultBuildsValueTriggerRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: GetBuildsByVersionResultBuildsValueTriggerRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface GetBuildsByVersionResultBuildsValueTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: GetBuildsByVersionResultBuildsValueTriggerBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: GetBuildsByVersionResultBuildsValueTriggerBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: GetBuildsByVersionResultBuildsValueTriggerPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: GetBuildsByVersionResultBuildsValueTriggerPathIncludesList | null | undefined;
    repoConnection?: GetBuildsByVersionResultBuildsValueTriggerRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export interface GetBuildsByVersionResultBuildsValue {
    buildOutcome?: GetBuildsByVersionResultBuildsValueBuildOutcome | null | undefined;
    buildTriggerMetadata?: GetBuildsByVersionResultBuildsValueBuildTriggerMetadata | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deployHook?: GetBuildResultDeployHook | null | undefined;
    initializingOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null | undefined;
    pullRequest?: GetBuildResultPullRequest | null | undefined;
    runningOn?: string | null | undefined;
    status?: GetBuildsByVersionResultBuildsValueStatus | null | undefined;
    stoppedOn?: string | null | undefined;
    /** Trigger information without build_token_uuid */
    trigger?: GetBuildsByVersionResultBuildsValueTrigger | null | undefined;
}
export type GetBuildsByVersionResultBuildsMap = {
    [key: string]: GetBuildsByVersionResultBuildsValue | undefined;
};
export interface GetBuildsByVersionResult {
    builds?: GetBuildsByVersionResultBuildsMap | null | undefined;
}
export type GetBuildsByVersionResponse = GetBuildsByVersionResult;
export interface GetBuildsLogRequest {
    /** Account identifier. */
    accountId: string;
    /** Build UUID. */
    buildUuid: string;
    /** Pagination cursor for log retrieval. */
    cursor?: string | undefined;
}
export type GetBuildsLogResultLinesItem = string | number;
export type GetBuildsLogResultLinesList = Array<GetBuildsLogResultLinesItem>;
export interface GetBuildsLogResult {
    /** Pagination cursor for log retrieval. */
    cursor?: string | null | undefined;
    lines?: GetBuildsLogResultLinesList | null | undefined;
    truncated?: boolean | null | undefined;
}
export type GetBuildsLogResponse = GetBuildsLogResult;
export interface GetLatestBuildsRequest {
    /** Account identifier. */
    accountId: string;
    /** Comma-separated list of system-generated worker script tags (max 20). */
    externalScriptIds: string;
}
export type GetLatestBuildsResultBuildsValueBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type GetLatestBuildsResultBuildsValueBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type GetLatestBuildsResultBuildsValueBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type GetLatestBuildsResultBuildsValueBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetLatestBuildsResultBuildsValueBuildTriggerMetadata {
    author?: string | null | undefined;
    /** Git branch name. */
    branch?: string | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    buildTriggerSource?: GetLatestBuildsResultBuildsValueBuildTriggerMetadataBuildTriggerSource | null | undefined;
    /** Git commit hash */
    commitHash?: string | null | undefined;
    commitMessage?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    environmentVariables?: GetLatestBuildsResultBuildsValueBuildTriggerMetadataEnvironmentVariablesMap | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: GetLatestBuildsResultBuildsValueBuildTriggerMetadataProviderType | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
}
export type GetLatestBuildsResultBuildsValueDeployHook = GetBuildResultDeployHook;
export type GetLatestBuildsResultBuildsValuePullRequest = GetBuildResultPullRequest;
export type GetLatestBuildsResultBuildsValueStatus = "queued" | "initializing" | "running" | "stopped";
export type GetLatestBuildsResultBuildsValueTriggerBranchExcludesList = Array<string>;
export type GetLatestBuildsResultBuildsValueTriggerBranchIncludesList = Array<string>;
export type GetLatestBuildsResultBuildsValueTriggerPathExcludesList = Array<string>;
export type GetLatestBuildsResultBuildsValueTriggerPathIncludesList = Array<string>;
export type GetLatestBuildsResultBuildsValueTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetLatestBuildsResultBuildsValueTriggerRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: GetLatestBuildsResultBuildsValueTriggerRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface GetLatestBuildsResultBuildsValueTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: GetLatestBuildsResultBuildsValueTriggerBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: GetLatestBuildsResultBuildsValueTriggerBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: GetLatestBuildsResultBuildsValueTriggerPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: GetLatestBuildsResultBuildsValueTriggerPathIncludesList | null | undefined;
    repoConnection?: GetLatestBuildsResultBuildsValueTriggerRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export interface GetLatestBuildsResultBuildsValue {
    buildOutcome?: GetLatestBuildsResultBuildsValueBuildOutcome | null | undefined;
    buildTriggerMetadata?: GetLatestBuildsResultBuildsValueBuildTriggerMetadata | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deployHook?: GetBuildResultDeployHook | null | undefined;
    initializingOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null | undefined;
    pullRequest?: GetBuildResultPullRequest | null | undefined;
    runningOn?: string | null | undefined;
    status?: GetLatestBuildsResultBuildsValueStatus | null | undefined;
    stoppedOn?: string | null | undefined;
    /** Trigger information without build_token_uuid */
    trigger?: GetLatestBuildsResultBuildsValueTrigger | null | undefined;
}
export type GetLatestBuildsResultBuildsMap = {
    [key: string]: GetLatestBuildsResultBuildsValue | undefined;
};
export interface GetLatestBuildsResult {
    builds?: GetLatestBuildsResultBuildsMap | null | undefined;
}
export type GetLatestBuildsResponse = GetLatestBuildsResult;
export type GetReposConfigAutofillRequestProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface GetReposConfigAutofillRequest {
    /** Account identifier. */
    accountId: string;
    /** Source control provider. */
    providerType: GetReposConfigAutofillRequestProviderType | (string & {});
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId: string;
    /** Provider-specific repository identifier. */
    repoId: string;
    /** Git branch name. */
    branch: string;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | undefined;
}
export type GetReposConfigAutofillResultEnvWorkerNamesMap = {
    [key: string]: string | undefined;
};
export type GetReposConfigAutofillResultPackageManager = "npm" | "yarn" | "pnpm" | "bun" | "uv";
export type GetReposConfigAutofillResultScriptsMap = {
    [key: string]: string | undefined;
};
export interface GetReposConfigAutofillResult {
    configFile?: string | null | undefined;
    defaultWorkerName?: string | null | undefined;
    envWorkerNames?: GetReposConfigAutofillResultEnvWorkerNamesMap | null | undefined;
    /** Package manager inferred from repository lockfiles; defaults to npm when none is detected. */
    packageManager?: GetReposConfigAutofillResultPackageManager | null | undefined;
    scripts?: GetReposConfigAutofillResultScriptsMap | null | undefined;
}
export type GetReposConfigAutofillResponse = GetReposConfigAutofillResult;
export interface ListBuildsRequest {
    /** Account identifier. */
    accountId: string;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId: string;
    /** Page number for pagination */
    page?: number | undefined;
    /** Number of items per page */
    perPage?: number | undefined;
}
export type ListBuildsResultItemBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type ListBuildsResultItemBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface ListBuildsResultItemBuildTriggerMetadata {
    author?: string | null | undefined;
    /** Git branch name. */
    branch?: string | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    buildTriggerSource?: ListBuildsResultItemBuildTriggerMetadataBuildTriggerSource | null | undefined;
    /** Git commit hash */
    commitHash?: string | null | undefined;
    commitMessage?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    environmentVariables?: ListBuildsResultItemBuildTriggerMetadataEnvironmentVariablesMap | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: ListBuildsResultItemBuildTriggerMetadataProviderType | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
}
export type ListBuildsResultItemDeployHook = GetBuildResultDeployHook;
export type ListBuildsResultItemPullRequest = GetBuildResultPullRequest;
export type ListBuildsResultItemStatus = "queued" | "initializing" | "running" | "stopped";
export type ListBuildsResultItemTriggerBranchExcludesList = Array<string>;
export type ListBuildsResultItemTriggerBranchIncludesList = Array<string>;
export type ListBuildsResultItemTriggerPathExcludesList = Array<string>;
export type ListBuildsResultItemTriggerPathIncludesList = Array<string>;
export type ListBuildsResultItemTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface ListBuildsResultItemTriggerRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: ListBuildsResultItemTriggerRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface ListBuildsResultItemTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: ListBuildsResultItemTriggerBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: ListBuildsResultItemTriggerBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: ListBuildsResultItemTriggerPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: ListBuildsResultItemTriggerPathIncludesList | null | undefined;
    repoConnection?: ListBuildsResultItemTriggerRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export interface ListBuildsResultItem {
    buildOutcome?: ListBuildsResultItemBuildOutcome | null | undefined;
    buildTriggerMetadata?: ListBuildsResultItemBuildTriggerMetadata | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deployHook?: GetBuildResultDeployHook | null | undefined;
    initializingOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null | undefined;
    pullRequest?: GetBuildResultPullRequest | null | undefined;
    runningOn?: string | null | undefined;
    status?: ListBuildsResultItemStatus | null | undefined;
    stoppedOn?: string | null | undefined;
    /** Trigger information without build_token_uuid */
    trigger?: ListBuildsResultItemTrigger | null | undefined;
}
export type ListBuildsResultList = Array<ListBuildsResultItem>;
export type ListBuildsResponse = ListBuildsResultList;
export interface ListTokensRequest {
    /** Account identifier. */
    accountId: string;
    /** Page number for pagination */
    page?: number | undefined;
    /** Number of items per page */
    perPage?: number | undefined;
}
export type ListTokensResultItem = CreateTokenResult;
export type ListTokensResultList = Array<CreateTokenResult>;
export type ListTokensResponse = ListTokensResultList;
export interface ListTriggersRequest {
    /** Account identifier. */
    accountId: string;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId: string;
}
export type ListTriggersResultItemBranchExcludesList = Array<string>;
export type ListTriggersResultItemBranchIncludesList = Array<string>;
export type ListTriggersResultItemPathExcludesList = Array<string>;
export type ListTriggersResultItemPathIncludesList = Array<string>;
export type ListTriggersResultItemRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface ListTriggersResultItemRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: ListTriggersResultItemRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface ListTriggersResultItem {
    /** Branch patterns that must not start builds. */
    branchExcludes?: ListTriggersResultItemBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: ListTriggersResultItemBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: ListTriggersResultItemPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: ListTriggersResultItemPathIncludesList | null | undefined;
    repoConnection?: ListTriggersResultItemRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export type ListTriggersResultList = Array<ListTriggersResultItem>;
export type ListTriggersResponse = ListTriggersResultList;
export interface ListTriggersEnvironmentVariablesRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export interface ListTriggersEnvironmentVariablesResultValue {
    createdOn: string;
    /** Whether to hide the value after it is saved. Secret values remain available to builds but appear as `null` when you list variables; non-secret values remain visible. */
    isSecret: boolean;
    /** Value is null for secret environment variables */
    value?: string | null | undefined;
}
export type ListTriggersEnvironmentVariablesResultMap = {
    [key: string]: ListTriggersEnvironmentVariablesResultValue | undefined;
};
export type ListTriggersEnvironmentVariablesResponse = ListTriggersEnvironmentVariablesResultMap;
export type TriggersCreateBuildRequestSeedRepoProvider = "github" | "gitlab";
export interface TriggersCreateBuildRequestSeedRepoFilesItem {
    content: string;
    filename: string;
    /** Whether content is Base64-encoded. */
    isBase64?: boolean | undefined;
    /** Existing text in the target file to replace with content. */
    replace?: string | undefined;
}
export type TriggersCreateBuildRequestSeedRepoFilesList = Array<TriggersCreateBuildRequestSeedRepoFilesItem>;
export interface TriggersCreateBuildRequestSeedRepo {
    /** Repository owner or namespace. */
    owner: string;
    /** Source control provider for the seed repository. */
    provider: TriggersCreateBuildRequestSeedRepoProvider | (string & {});
    /** Repository name. */
    repository: string;
    /** Repository branch to seed. */
    branch?: string | undefined;
    /** Files to add or replace for this build. Maximum 2. */
    files?: TriggersCreateBuildRequestSeedRepoFilesList | undefined;
    /** Path within the repository to seed. */
    path?: string | undefined;
}
export interface TriggersCreateBuildRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Git branch name (required if commit_hash not provided) */
    branch?: string | undefined;
    /** Git commit hash (required if branch not provided) */
    commitHash?: string | undefined;
    /** Optional repository and file overrides used to seed this build. */
    seedRepo?: TriggersCreateBuildRequestSeedRepo | undefined;
}
export type TriggersCreateBuildResultBuildOutcome = "success" | "fail" | "skipped" | "cancelled" | "terminated";
export type TriggersCreateBuildResultBuildTriggerMetadataBuildTriggerSource = "push" | "pull_request" | "manual" | "api";
export type TriggersCreateBuildResultBuildTriggerMetadataEnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export type TriggersCreateBuildResultBuildTriggerMetadataProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface TriggersCreateBuildResultBuildTriggerMetadata {
    author?: string | null | undefined;
    /** Git branch name. */
    branch?: string | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    buildTriggerSource?: TriggersCreateBuildResultBuildTriggerMetadataBuildTriggerSource | null | undefined;
    /** Git commit hash */
    commitHash?: string | null | undefined;
    commitMessage?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    environmentVariables?: TriggersCreateBuildResultBuildTriggerMetadataEnvironmentVariablesMap | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: TriggersCreateBuildResultBuildTriggerMetadataProviderType | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
}
export type TriggersCreateBuildResultDeployHook = GetBuildResultDeployHook;
export type TriggersCreateBuildResultPullRequest = GetBuildResultPullRequest;
export type TriggersCreateBuildResultStatus = "queued" | "initializing" | "running" | "stopped";
export type TriggersCreateBuildResultTriggerBranchExcludesList = Array<string>;
export type TriggersCreateBuildResultTriggerBranchIncludesList = Array<string>;
export type TriggersCreateBuildResultTriggerPathExcludesList = Array<string>;
export type TriggersCreateBuildResultTriggerPathIncludesList = Array<string>;
export type TriggersCreateBuildResultTriggerRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface TriggersCreateBuildResultTriggerRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: TriggersCreateBuildResultTriggerRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface TriggersCreateBuildResultTrigger {
    /** Branch patterns that must not start builds. */
    branchExcludes?: TriggersCreateBuildResultTriggerBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: TriggersCreateBuildResultTriggerBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: TriggersCreateBuildResultTriggerPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: TriggersCreateBuildResultTriggerPathIncludesList | null | undefined;
    repoConnection?: TriggersCreateBuildResultTriggerRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export interface TriggersCreateBuildResult {
    buildOutcome?: TriggersCreateBuildResultBuildOutcome | null | undefined;
    buildTriggerMetadata?: TriggersCreateBuildResultBuildTriggerMetadata | null | undefined;
    /** Build UUID. */
    buildUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deployHook?: GetBuildResultDeployHook | null | undefined;
    initializingOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** URL serving the Worker version this build deployed. Only returned by Get build by UUID, and only once the build has produced a preview artifact. */
    previewUrl?: string | null | undefined;
    pullRequest?: GetBuildResultPullRequest | null | undefined;
    runningOn?: string | null | undefined;
    status?: TriggersCreateBuildResultStatus | null | undefined;
    stoppedOn?: string | null | undefined;
    /** Trigger information without build_token_uuid */
    trigger?: TriggersCreateBuildResultTrigger | null | undefined;
}
export type TriggersCreateBuildResponse = TriggersCreateBuildResult;
export interface TriggersPurgeCacheRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
}
export type TriggersPurgeCacheResponse = unknown;
export type UpdateTriggerRequestBranchExcludesList = Array<string>;
export type UpdateTriggerRequestBranchIncludesList = Array<string>;
export type UpdateTriggerRequestPathExcludesList = Array<string>;
export type UpdateTriggerRequestPathIncludesList = Array<string>;
export interface UpdateTriggerRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Branch patterns that must not start builds. */
    branchExcludes?: UpdateTriggerRequestBranchExcludesList | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: UpdateTriggerRequestBranchIncludesList | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: UpdateTriggerRequestPathExcludesList | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: UpdateTriggerRequestPathIncludesList | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | undefined;
}
export type UpdateTriggerResultBranchExcludesList = Array<string>;
export type UpdateTriggerResultBranchIncludesList = Array<string>;
export type UpdateTriggerResultPathExcludesList = Array<string>;
export type UpdateTriggerResultPathIncludesList = Array<string>;
export type UpdateTriggerResultRepoConnectionProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface UpdateTriggerResultRepoConnection {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: UpdateTriggerResultRepoConnectionProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export interface UpdateTriggerResult {
    /** Branch patterns that must not start builds. */
    branchExcludes?: UpdateTriggerResultBranchExcludesList | null | undefined;
    /** Branch patterns that can start builds. */
    branchIncludes?: UpdateTriggerResultBranchIncludesList | null | undefined;
    /** Whether builds reuse cached dependencies and build artifacts. */
    buildCachingEnabled?: boolean | null | undefined;
    /** Command to build the Worker. */
    buildCommand?: string | null | undefined;
    buildTokenName?: string | null | undefined;
    /** UUID of the build token used when deploying the Worker. */
    buildTokenUuid?: string | null | undefined;
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    /** Command to deploy the Worker. */
    deployCommand?: string | null | undefined;
    /** System-generated tag of the Worker. This is not the Worker name. */
    externalScriptId?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Path patterns that must not start builds. */
    pathExcludes?: UpdateTriggerResultPathExcludesList | null | undefined;
    /** Path patterns that can start builds. */
    pathIncludes?: UpdateTriggerResultPathIncludesList | null | undefined;
    repoConnection?: UpdateTriggerResultRepoConnection | null | undefined;
    /** Repository directory in which build and deploy commands run. */
    rootDirectory?: string | null | undefined;
    /** Human-readable name of the build trigger. */
    triggerName?: string | null | undefined;
    /** Trigger UUID. */
    triggerUuid?: string | null | undefined;
}
export type UpdateTriggerResponse = UpdateTriggerResult;
export type UpsertReposConnectionRequestProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface UpsertReposConnectionRequest {
    /** Account identifier. */
    accountId: string;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId: string;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName: string;
    /** Source control provider. */
    providerType: UpsertReposConnectionRequestProviderType | (string & {});
    /** Provider-specific repository identifier. */
    repoId: string;
    /** Human-readable repository name. */
    repoName: string;
}
export type UpsertReposConnectionResultProviderType = "github" | "gitlab" | "gitlab_internal" | "origin";
export interface UpsertReposConnectionResult {
    createdOn?: string | null | undefined;
    deletedOn?: string | null | undefined;
    modifiedOn?: string | null | undefined;
    /** Provider-specific identifier of the account or namespace that owns the repository. */
    providerAccountId?: string | null | undefined;
    /** Human-readable name of the account or namespace that owns the repository. */
    providerAccountName?: string | null | undefined;
    /** Source control provider. */
    providerType?: UpsertReposConnectionResultProviderType | null | undefined;
    /** Repository connection UUID. */
    repoConnectionUuid?: string | null | undefined;
    /** Provider-specific repository identifier. */
    repoId?: string | null | undefined;
    /** Human-readable repository name. */
    repoName?: string | null | undefined;
}
export type UpsertReposConnectionResponse = UpsertReposConnectionResult;
export interface UpsertTriggersEnvironmentVariableRequestBodyValue {
    /** Whether to hide the value after it is saved. Secret values remain available to builds but appear as `null` when you list variables; non-secret values remain visible. */
    isSecret: boolean;
    /** Value made available to the build. Maximum length is 5000 characters. */
    value: string;
}
export type UpsertTriggersEnvironmentVariableRequestBodyMap = {
    [key: string]: UpsertTriggersEnvironmentVariableRequestBodyValue | undefined;
};
export interface UpsertTriggersEnvironmentVariableRequest {
    /** Account identifier. */
    accountId: string;
    /** Trigger UUID. */
    triggerUuid: string;
    /** Map of environment-variable names to build-time values. Names must begin with a letter or underscore and contain only letters, numbers, and underscores. */
    body: UpsertTriggersEnvironmentVariableRequestBodyMap;
}
export type UpsertTriggersEnvironmentVariableResultValue = ListTriggersEnvironmentVariablesResultValue;
export type UpsertTriggersEnvironmentVariableResultMap = {
    [key: string]: ListTriggersEnvironmentVariablesResultValue | undefined;
};
export type UpsertTriggersEnvironmentVariableResponse = UpsertTriggersEnvironmentVariableResultMap;
export type CancelBuildError = CloudflareOpError;
/** Cancel a queued or running build. */
export declare const cancelBuild: API.OperationMethod<CancelBuildRequest, CancelBuildResponse, CancelBuildError, CloudflareOpContext>;
export type CreateTokenError = CloudflareOpError;
/** Create a new build authentication token */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type CreateTriggerError = CloudflareOpError;
/** Create a trigger defining the repository connection, Worker tag, commands, filters, cache setting, and build token. */
export declare const createTrigger: API.OperationMethod<CreateTriggerRequest, CreateTriggerResponse, CreateTriggerError, CloudflareOpContext>;
export type DeleteReposConnectionError = CloudflareOpError;
/** Delete a saved repository connection. */
export declare const deleteReposConnection: API.OperationMethod<DeleteReposConnectionRequest, DeleteReposConnectionResponse, DeleteReposConnectionError, CloudflareOpContext>;
export type DeleteTokenError = CloudflareOpError;
/** Delete a stored build token owned by the current user. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type DeleteTriggerError = CloudflareOpError;
/** Delete a trigger and cancel its unfinished builds. */
export declare const deleteTrigger: API.OperationMethod<DeleteTriggerRequest, DeleteTriggerResponse, DeleteTriggerError, CloudflareOpContext>;
export type DeleteTriggersEnvironmentVariableError = CloudflareOpError;
/** Delete one build-time variable or secret by key. */
export declare const deleteTriggersEnvironmentVariable: API.OperationMethod<DeleteTriggersEnvironmentVariableRequest, DeleteTriggersEnvironmentVariableResponse, DeleteTriggersEnvironmentVariableError, CloudflareOpContext>;
export type DeployHooksCreateError = CloudflareOpError;
/** Create an HTTP hook that starts a build for a selected Worker branch. */
export declare const deployHooksCreate: API.OperationMethod<DeployHooksCreateRequest, DeployHooksCreateResponse, DeployHooksCreateError, CloudflareOpContext>;
export type DeployHooksDeleteError = CloudflareOpError;
/** Delete a deploy hook so its UUID can no longer start builds. */
export declare const deployHooksDelete: API.OperationMethod<DeployHooksDeleteRequest, DeployHooksDeleteResponse, DeployHooksDeleteError, CloudflareOpContext>;
export type DeployHooksGetError = CloudflareOpError;
/** Retrieve the name, branch, Worker identifier, and timestamps for a deploy hook. */
export declare const deployHooksGet: API.OperationMethod<DeployHooksGetRequest, DeployHooksGetResponse, DeployHooksGetError, CloudflareOpContext>;
export type DeployHooksListError = CloudflareOpError;
/** List the branch-specific deploy hooks configured for a Worker. */
export declare const deployHooksList: API.OperationMethod<DeployHooksListRequest, DeployHooksListResponse, DeployHooksListError, CloudflareOpContext>;
export type DeployHooksTriggerError = CloudflareOpError;
/** Trigger a build using a deploy hook. This endpoint does not require authentication - the deploy_hook_uuid acts as a secret token. */
export declare const deployHooksTrigger: API.OperationMethod<DeployHooksTriggerRequest, DeployHooksTriggerResponse, DeployHooksTriggerError, CloudflareOpContext>;
export type DeployHooksUpdateError = CloudflareOpError;
/** Replace the name and target branch for a deploy hook. */
export declare const deployHooksUpdate: API.OperationMethod<DeployHooksUpdateRequest, DeployHooksUpdateResponse, DeployHooksUpdateError, CloudflareOpContext>;
export type GetAccountLimitsError = CloudflareOpError;
/** Return whether the account's build-minute allowance is exhausted and when it refreshes. */
export declare const getAccountLimits: API.OperationMethod<GetAccountLimitsRequest, GetAccountLimitsResponse, GetAccountLimitsError, CloudflareOpContext>;
export type GetBuildError = CloudflareOpError;
/** Retrieve status, outcome, timestamps, trigger settings, and source metadata for a build UUID. */
export declare const getBuild: API.OperationMethod<GetBuildRequest, GetBuildResponse, GetBuildError, CloudflareOpContext>;
export type GetBuildsByVersionError = CloudflareOpError;
/** Retrieve builds associated with one or more Worker version IDs. */
export declare const getBuildsByVersion: API.OperationMethod<GetBuildsByVersionRequest, GetBuildsByVersionResponse, GetBuildsByVersionError, CloudflareOpContext>;
export type GetBuildsLogError = CloudflareOpError;
/** Retrieve cursor-paginated log lines for a build UUID. */
export declare const getBuildsLog: API.OperationMethod<GetBuildsLogRequest, GetBuildsLogResponse, GetBuildsLogError, CloudflareOpContext>;
export type GetLatestBuildsError = CloudflareOpError;
/** Retrieve the most recent builds for multiple worker scripts */
export declare const getLatestBuilds: API.OperationMethod<GetLatestBuildsRequest, GetLatestBuildsResponse, GetLatestBuildsError, CloudflareOpContext>;
export type GetReposConfigAutofillError = RepositoryConfigNotFound | CloudflareOpError;
/** Analyze repository for automatic configuration detection */
export declare const getReposConfigAutofill: API.OperationMethod<GetReposConfigAutofillRequest, GetReposConfigAutofillResponse, GetReposConfigAutofillError, CloudflareOpContext>;
export type ListBuildsError = CloudflareOpError;
/** List paginated build records associated with a Worker tag. */
export declare const listBuilds: API.OperationMethod<ListBuildsRequest, ListBuildsResponse, ListBuildsError, CloudflareOpContext>;
export type ListTokensError = CloudflareOpError;
/** List metadata for build tokens available to the current user without returning their secrets. */
export declare const listTokens: API.OperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext>;
export type ListTriggersError = CloudflareOpError;
/** List trigger UUIDs and build settings associated with a Worker tag. */
export declare const listTriggers: API.OperationMethod<ListTriggersRequest, ListTriggersResponse, ListTriggersError, CloudflareOpContext>;
export type ListTriggersEnvironmentVariablesError = CloudflareOpError;
/** List build-time variables configured for a trigger. Secret values are not returned. */
export declare const listTriggersEnvironmentVariables: API.OperationMethod<ListTriggersEnvironmentVariablesRequest, ListTriggersEnvironmentVariablesResponse, ListTriggersEnvironmentVariablesError, CloudflareOpContext>;
export type TriggersCreateBuildError = CloudflareOpError;
/** Start a build for a branch or commit using the selected trigger. */
export declare const triggersCreateBuild: API.OperationMethod<TriggersCreateBuildRequest, TriggersCreateBuildResponse, TriggersCreateBuildError, CloudflareOpContext>;
export type TriggersPurgeCacheError = CloudflareOpError;
/** Delete cached dependencies and build artifacts associated with a trigger. */
export declare const triggersPurgeCache: API.OperationMethod<TriggersPurgeCacheRequest, TriggersPurgeCacheResponse, TriggersPurgeCacheError, CloudflareOpContext>;
export type UpdateTriggerError = CloudflareOpError;
/** Update commands, cache settings, or branch and path filters for a trigger. */
export declare const updateTrigger: API.OperationMethod<UpdateTriggerRequest, UpdateTriggerResponse, UpdateTriggerError, CloudflareOpContext>;
export type UpsertReposConnectionError = CloudflareOpError;
/** Save the repository connection required by build triggers. */
export declare const upsertReposConnection: API.OperationMethod<UpsertReposConnectionRequest, UpsertReposConnectionResponse, UpsertReposConnectionError, CloudflareOpContext>;
export type UpsertTriggersEnvironmentVariableError = CloudflareOpError;
/** Add or replace build-time variables and secrets without changing unspecified keys. */
export declare const upsertTriggersEnvironmentVariable: API.OperationMethod<UpsertTriggersEnvironmentVariableRequest, UpsertTriggersEnvironmentVariableResponse, UpsertTriggersEnvironmentVariableError, CloudflareOpContext>;
//# sourceMappingURL=workers_builds.d.ts.map