/**
 * Environment configuration for credentials, endpoints and regions: the
 * small part of `effect/Config` that SDKs use, as plain Effects.
 *
 * Importing `effect/Config` costs about 280 KB of heap per process (it pulls
 * in ConfigProvider, Schema-based parsing and their dependencies), and every
 * SDK whose credentials read the environment paid it at import. These
 * readers do the same lookups without it:
 *
 * - When the caller provided a `ConfigProvider` (found by its context key),
 *   the value comes from that provider, so `ConfigProvider.fromUnknown(...)`
 *   in tests and custom providers on Workers keep working.
 * - Otherwise the value comes from `process.env`, which is what Effect's
 *   default provider reads.
 *
 * A missing variable fails with {@link ConfigError} (with its `key`), which `withDefault`, `option` and `orElse` handle. A provided
 * `ConfigProvider` that cannot read its source fails with its `SourceError`,
 * which those helpers pass through.
 *
 * Credentials read these on every request, so without a provider a whole
 * reader tree (`all`, `withDefault`, `orElse`, ...) runs as one synchronous
 * read of `process.env` in a single fiber step: each reader carries a plain
 * `read` function next to its effect, and the combinators compose those.
 * A missing value inside the tree is a plain marker; the tagged error is
 * only built if the whole tree fails.
 */
import type { SourceError } from "effect/ConfigProvider";
import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Redact from "effect/Redacted";
import * as Schema from "./schema-lite-typed.ts";
declare const ConfigError_base: Schema.TaggedErrorClass<"ConfigError", {
    readonly message: import("effect/Schema").String;
    readonly key: import("effect/Schema").optional<import("effect/Schema").String>;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConfigurationError: true;
    };
});
/**
 * Configuration error - missing or invalid configuration. `key` is the
 * configuration value (e.g. an environment variable) when one is missing.
 */
export declare class ConfigError extends /*@__PURE__*/ ConfigError_base {
}
/** The string value of environment variable `name`. */
export declare const String: (name: string) => Effect.Effect<string, ConfigError | SourceError>;
/** The value of `name`, redacted. */
export declare const Redacted: (name: string) => Effect.Effect<Redact.Redacted<string>, ConfigError | SourceError>;
/**
 * The failure of a missing value: {@link ConfigError}, matched by its tag
 * (Effect's own config errors share it). `option`, `withDefault` and `orElse` handle
 * only this failure; any other failure of `self` propagates.
 */
type Missed = {
    readonly _tag: "ConfigError";
};
/** The value as an `Option`: `None` when missing. */
export declare const option: <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<Option.Option<A>, Exclude<E, Missed>, R>;
/** Use `value` when missing. */
export declare const withDefault: <B>(value: B) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A | B, Exclude<E, Missed>, R>;
/** Try `that` when missing. */
export declare const orElse: <A2, E2, R2>(that: () => Effect.Effect<A2, E2, R2>) => <A, E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<A | A2, Exclude<E, Missed> | E2, R | R2>;
export declare const map: <A, B>(f: (a: A) => B) => <E, R>(self: Effect.Effect<A, E, R>) => Effect.Effect<B, E, R>;
/** Read every value of a struct of readers. */
export declare const all: <const T extends Record<string, Effect.Effect<any, any, any>>>(readers: T) => Effect.Effect<{ -readonly [K in keyof T]: Effect.Success<T[K]>; }, Effect.Error<T[keyof T]>, Effect.Services<T[keyof T]>>;
export {};
//# sourceMappingURL=config.d.ts.map