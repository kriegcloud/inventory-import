import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type ResourceName = string;
export type GatewayRoutePriority = number;
export type HttpPathExact = string;
export type HttpPathRegex = string;
export interface HttpPathMatch {
    exact?: string | undefined;
    regex?: string | undefined;
}
export type QueryParameterName = string;
export interface QueryParameterMatch {
    exact?: string | undefined;
}
export interface HttpQueryParameter {
    name: string;
    match?: QueryParameterMatch | undefined;
}
export type HttpQueryParameters = HttpQueryParameter[];
export type HttpMethod = string;
export type ExactHostName = string;
export type SuffixHostname = string;
export interface GatewayRouteHostnameMatch {
    exact?: string | undefined;
    suffix?: string | undefined;
}
export type HeaderName = string;
export type HeaderMatch = string;
export interface MatchRange {
    start: number;
    end: number;
}
export type HeaderMatchMethod = {
    exact: string;
    regex?: undefined;
    range?: undefined;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex: string;
    range?: undefined;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range: MatchRange;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range?: undefined;
    prefix: string;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range?: undefined;
    prefix?: undefined;
    suffix: string;
};
export interface HttpGatewayRouteHeader {
    name: string;
    invert?: boolean | undefined;
    match?: HeaderMatchMethod | undefined;
}
export type HttpGatewayRouteHeaders = HttpGatewayRouteHeader[];
export type ListenerPort = number;
export interface HttpGatewayRouteMatch {
    prefix?: string | undefined;
    path?: HttpPathMatch | undefined;
    queryParameters?: HttpQueryParameter[] | undefined;
    method?: string | undefined;
    hostname?: GatewayRouteHostnameMatch | undefined;
    headers?: HttpGatewayRouteHeader[] | undefined;
    port?: number | undefined;
}
export interface GatewayRouteVirtualService {
    virtualServiceName: string;
}
export interface GatewayRouteTarget {
    virtualService: GatewayRouteVirtualService;
    port?: number | undefined;
}
export type DefaultGatewayRouteRewrite = string;
export type HttpGatewayRoutePrefix = string;
export interface HttpGatewayRoutePrefixRewrite {
    defaultPrefix?: string | undefined;
    value?: string | undefined;
}
export interface HttpGatewayRoutePathRewrite {
    exact?: string | undefined;
}
export interface GatewayRouteHostnameRewrite {
    defaultTargetHostname?: string | undefined;
}
export interface HttpGatewayRouteRewrite {
    prefix?: HttpGatewayRoutePrefixRewrite | undefined;
    path?: HttpGatewayRoutePathRewrite | undefined;
    hostname?: GatewayRouteHostnameRewrite | undefined;
}
export interface HttpGatewayRouteAction {
    target: GatewayRouteTarget;
    rewrite?: HttpGatewayRouteRewrite | undefined;
}
export interface HttpGatewayRoute {
    match: HttpGatewayRouteMatch;
    action: HttpGatewayRouteAction;
}
export type ServiceName = string;
export type GrpcMetadataMatchMethod = {
    exact: string;
    regex?: undefined;
    range?: undefined;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex: string;
    range?: undefined;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range: MatchRange;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range?: undefined;
    prefix: string;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range?: undefined;
    prefix?: undefined;
    suffix: string;
};
export interface GrpcGatewayRouteMetadata {
    name: string;
    invert?: boolean | undefined;
    match?: GrpcMetadataMatchMethod | undefined;
}
export type GrpcGatewayRouteMetadataList = GrpcGatewayRouteMetadata[];
export interface GrpcGatewayRouteMatch {
    serviceName?: string | undefined;
    hostname?: GatewayRouteHostnameMatch | undefined;
    metadata?: GrpcGatewayRouteMetadata[] | undefined;
    port?: number | undefined;
}
export interface GrpcGatewayRouteRewrite {
    hostname?: GatewayRouteHostnameRewrite | undefined;
}
export interface GrpcGatewayRouteAction {
    target: GatewayRouteTarget;
    rewrite?: GrpcGatewayRouteRewrite | undefined;
}
export interface GrpcGatewayRoute {
    match: GrpcGatewayRouteMatch;
    action: GrpcGatewayRouteAction;
}
export interface GatewayRouteSpec {
    priority?: number | undefined;
    httpRoute?: HttpGatewayRoute | undefined;
    http2Route?: HttpGatewayRoute | undefined;
    grpcRoute?: GrpcGatewayRoute | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface TagRef {
    key: string;
    value: string;
}
export type TagList = TagRef[];
export type AccountId = string;
export interface CreateGatewayRouteInput {
    gatewayRouteName: string;
    meshName: string;
    virtualGatewayName: string;
    spec: GatewayRouteSpec;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export type Arn = string;
export interface ResourceMetadata {
    arn: string;
    version: number;
    uid: string;
    createdAt: Date;
    lastUpdatedAt: Date;
    meshOwner: string;
    resourceOwner: string;
}
export type GatewayRouteStatusCode = string;
export interface GatewayRouteStatus {
    status: string;
}
export interface GatewayRouteData {
    meshName: string;
    gatewayRouteName: string;
    virtualGatewayName: string;
    spec: GatewayRouteSpec;
    metadata: ResourceMetadata;
    status: GatewayRouteStatus;
}
export interface CreateGatewayRouteOutput {
    gatewayRoute: GatewayRouteData;
}
export type EgressFilterType = string;
export interface EgressFilter {
    type: string;
}
export type IpPreference = string;
export interface MeshServiceDiscovery {
    ipPreference?: string | undefined;
}
export interface MeshSpec {
    egressFilter?: EgressFilter | undefined;
    serviceDiscovery?: MeshServiceDiscovery | undefined;
}
export interface CreateMeshInput {
    meshName: string;
    spec?: MeshSpec | undefined;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
}
export type MeshStatusCode = string;
export interface MeshStatus {
    status?: string | undefined;
}
export interface MeshData {
    meshName: string;
    spec: MeshSpec;
    metadata: ResourceMetadata;
    status: MeshStatus;
}
export interface CreateMeshOutput {
    mesh: MeshData;
}
export type RoutePriority = number;
export type HttpScheme = string;
export interface HttpRouteHeader {
    name: string;
    invert?: boolean | undefined;
    match?: HeaderMatchMethod | undefined;
}
export type HttpRouteHeaders = HttpRouteHeader[];
export interface HttpRouteMatch {
    prefix?: string | undefined;
    path?: HttpPathMatch | undefined;
    queryParameters?: HttpQueryParameter[] | undefined;
    method?: string | undefined;
    scheme?: string | undefined;
    headers?: HttpRouteHeader[] | undefined;
    port?: number | undefined;
}
export type PercentInt = number;
export interface WeightedTarget {
    virtualNode: string;
    weight: number;
    port?: number | undefined;
}
export type WeightedTargets = WeightedTarget[];
export interface HttpRouteAction {
    weightedTargets: WeightedTarget[];
}
export type DurationValue = number;
export type DurationUnit = string;
export interface Duration {
    value?: number | undefined;
    unit?: string | undefined;
}
export type MaxRetries = number;
export type HttpRetryPolicyEvent = string;
export type HttpRetryPolicyEvents = string[];
export type TcpRetryPolicyEvent = string;
export type TcpRetryPolicyEvents = string[];
export interface HttpRetryPolicy {
    perRetryTimeout: Duration;
    maxRetries: number;
    httpRetryEvents?: string[] | undefined;
    tcpRetryEvents?: string[] | undefined;
}
export interface HttpTimeout {
    perRequest?: Duration | undefined;
    idle?: Duration | undefined;
}
export interface HttpRoute {
    match: HttpRouteMatch;
    action: HttpRouteAction;
    retryPolicy?: HttpRetryPolicy | undefined;
    timeout?: HttpTimeout | undefined;
}
export interface TcpRouteAction {
    weightedTargets: WeightedTarget[];
}
export interface TcpTimeout {
    idle?: Duration | undefined;
}
export interface TcpRouteMatch {
    port?: number | undefined;
}
export interface TcpRoute {
    action: TcpRouteAction;
    timeout?: TcpTimeout | undefined;
    match?: TcpRouteMatch | undefined;
}
export interface GrpcRouteAction {
    weightedTargets: WeightedTarget[];
}
export type MethodName = string;
export type GrpcRouteMetadataMatchMethod = {
    exact: string;
    regex?: undefined;
    range?: undefined;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex: string;
    range?: undefined;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range: MatchRange;
    prefix?: undefined;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range?: undefined;
    prefix: string;
    suffix?: undefined;
} | {
    exact?: undefined;
    regex?: undefined;
    range?: undefined;
    prefix?: undefined;
    suffix: string;
};
export interface GrpcRouteMetadata {
    name: string;
    invert?: boolean | undefined;
    match?: GrpcRouteMetadataMatchMethod | undefined;
}
export type GrpcRouteMetadataList = GrpcRouteMetadata[];
export interface GrpcRouteMatch {
    serviceName?: string | undefined;
    methodName?: string | undefined;
    metadata?: GrpcRouteMetadata[] | undefined;
    port?: number | undefined;
}
export type GrpcRetryPolicyEvent = string;
export type GrpcRetryPolicyEvents = string[];
export interface GrpcRetryPolicy {
    perRetryTimeout: Duration;
    maxRetries: number;
    httpRetryEvents?: string[] | undefined;
    tcpRetryEvents?: string[] | undefined;
    grpcRetryEvents?: string[] | undefined;
}
export interface GrpcTimeout {
    perRequest?: Duration | undefined;
    idle?: Duration | undefined;
}
export interface GrpcRoute {
    action: GrpcRouteAction;
    match: GrpcRouteMatch;
    retryPolicy?: GrpcRetryPolicy | undefined;
    timeout?: GrpcTimeout | undefined;
}
export interface RouteSpec {
    priority?: number | undefined;
    httpRoute?: HttpRoute | undefined;
    tcpRoute?: TcpRoute | undefined;
    http2Route?: HttpRoute | undefined;
    grpcRoute?: GrpcRoute | undefined;
}
export interface CreateRouteInput {
    routeName: string;
    meshName: string;
    virtualRouterName: string;
    spec: RouteSpec;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export type RouteStatusCode = string;
export interface RouteStatus {
    status: string;
}
export interface RouteData {
    meshName: string;
    virtualRouterName: string;
    routeName: string;
    spec: RouteSpec;
    metadata: ResourceMetadata;
    status: RouteStatus;
}
export interface CreateRouteOutput {
    route: RouteData;
}
export type PortNumber = number;
export type PortSet = number[];
export type FilePath = string;
export interface VirtualGatewayListenerTlsFileCertificate {
    certificateChain: string;
    privateKey: string;
}
export type VirtualGatewaySdsSecretName = string;
export interface VirtualGatewayListenerTlsSdsCertificate {
    secretName: string;
}
export type VirtualGatewayClientTlsCertificate = {
    file: VirtualGatewayListenerTlsFileCertificate;
    sds?: undefined;
} | {
    file?: undefined;
    sds: VirtualGatewayListenerTlsSdsCertificate;
};
export type VirtualGatewayCertificateAuthorityArns = string[];
export interface VirtualGatewayTlsValidationContextAcmTrust {
    certificateAuthorityArns: string[];
}
export interface VirtualGatewayTlsValidationContextFileTrust {
    certificateChain: string;
}
export interface VirtualGatewayTlsValidationContextSdsTrust {
    secretName: string;
}
export type VirtualGatewayTlsValidationContextTrust = {
    acm: VirtualGatewayTlsValidationContextAcmTrust;
    file?: undefined;
    sds?: undefined;
} | {
    acm?: undefined;
    file: VirtualGatewayTlsValidationContextFileTrust;
    sds?: undefined;
} | {
    acm?: undefined;
    file?: undefined;
    sds: VirtualGatewayTlsValidationContextSdsTrust;
};
export type SubjectAlternativeName = string;
export type SubjectAlternativeNameList = string[];
export interface SubjectAlternativeNameMatchers {
    exact: string[];
}
export interface SubjectAlternativeNames {
    match: SubjectAlternativeNameMatchers;
}
export interface VirtualGatewayTlsValidationContext {
    trust: VirtualGatewayTlsValidationContextTrust;
    subjectAlternativeNames?: SubjectAlternativeNames | undefined;
}
export interface VirtualGatewayClientPolicyTls {
    enforce?: boolean | undefined;
    ports?: number[] | undefined;
    certificate?: VirtualGatewayClientTlsCertificate | undefined;
    validation: VirtualGatewayTlsValidationContext;
}
export interface VirtualGatewayClientPolicy {
    tls?: VirtualGatewayClientPolicyTls | undefined;
}
export interface VirtualGatewayBackendDefaults {
    clientPolicy?: VirtualGatewayClientPolicy | undefined;
}
export type VirtualGatewayHealthCheckTimeoutMillis = number;
export type VirtualGatewayHealthCheckIntervalMillis = number;
export type VirtualGatewayPortProtocol = string;
export type VirtualGatewayHealthCheckThreshold = number;
export interface VirtualGatewayHealthCheckPolicy {
    timeoutMillis: number;
    intervalMillis: number;
    protocol: string;
    port?: number | undefined;
    path?: string | undefined;
    healthyThreshold: number;
    unhealthyThreshold: number;
}
export interface VirtualGatewayPortMapping {
    port: number;
    protocol: string;
}
export type VirtualGatewayListenerTlsMode = string;
export type VirtualGatewayListenerTlsValidationContextTrust = {
    file: VirtualGatewayTlsValidationContextFileTrust;
    sds?: undefined;
} | {
    file?: undefined;
    sds: VirtualGatewayTlsValidationContextSdsTrust;
};
export interface VirtualGatewayListenerTlsValidationContext {
    trust: VirtualGatewayListenerTlsValidationContextTrust;
    subjectAlternativeNames?: SubjectAlternativeNames | undefined;
}
export interface VirtualGatewayListenerTlsAcmCertificate {
    certificateArn: string;
}
export type VirtualGatewayListenerTlsCertificate = {
    acm: VirtualGatewayListenerTlsAcmCertificate;
    file?: undefined;
    sds?: undefined;
} | {
    acm?: undefined;
    file: VirtualGatewayListenerTlsFileCertificate;
    sds?: undefined;
} | {
    acm?: undefined;
    file?: undefined;
    sds: VirtualGatewayListenerTlsSdsCertificate;
};
export interface VirtualGatewayListenerTls {
    mode: string;
    validation?: VirtualGatewayListenerTlsValidationContext | undefined;
    certificate: VirtualGatewayListenerTlsCertificate;
}
export type MaxConnections = number;
export type MaxPendingRequests = number;
export interface VirtualGatewayHttpConnectionPool {
    maxConnections: number;
    maxPendingRequests?: number | undefined;
}
export type MaxRequests = number;
export interface VirtualGatewayHttp2ConnectionPool {
    maxRequests: number;
}
export interface VirtualGatewayGrpcConnectionPool {
    maxRequests: number;
}
export type VirtualGatewayConnectionPool = {
    http: VirtualGatewayHttpConnectionPool;
    http2?: undefined;
    grpc?: undefined;
} | {
    http?: undefined;
    http2: VirtualGatewayHttp2ConnectionPool;
    grpc?: undefined;
} | {
    http?: undefined;
    http2?: undefined;
    grpc: VirtualGatewayGrpcConnectionPool;
};
export interface VirtualGatewayListener {
    healthCheck?: VirtualGatewayHealthCheckPolicy | undefined;
    portMapping: VirtualGatewayPortMapping;
    tls?: VirtualGatewayListenerTls | undefined;
    connectionPool?: VirtualGatewayConnectionPool | undefined;
}
export type VirtualGatewayListeners = VirtualGatewayListener[];
export type TextFormat = string;
export type JsonKey = string;
export type JsonValue = string;
export interface JsonFormatRef {
    key: string;
    value: string;
}
export type JsonFormat = JsonFormatRef[];
export type LoggingFormat = {
    text: string;
    json?: undefined;
} | {
    text?: undefined;
    json: JsonFormatRef[];
};
export interface VirtualGatewayFileAccessLog {
    path: string;
    format?: LoggingFormat | undefined;
}
export type VirtualGatewayAccessLog = {
    file: VirtualGatewayFileAccessLog;
};
export interface VirtualGatewayLogging {
    accessLog?: VirtualGatewayAccessLog | undefined;
}
export interface VirtualGatewaySpec {
    backendDefaults?: VirtualGatewayBackendDefaults | undefined;
    listeners: VirtualGatewayListener[];
    logging?: VirtualGatewayLogging | undefined;
}
export interface CreateVirtualGatewayInput {
    virtualGatewayName: string;
    meshName: string;
    spec: VirtualGatewaySpec;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export type VirtualGatewayStatusCode = string;
export interface VirtualGatewayStatus {
    status: string;
}
export interface VirtualGatewayData {
    meshName: string;
    virtualGatewayName: string;
    spec: VirtualGatewaySpec;
    metadata: ResourceMetadata;
    status: VirtualGatewayStatus;
}
export interface CreateVirtualGatewayOutput {
    virtualGateway: VirtualGatewayData;
}
export type Hostname = string;
export type DnsResponseType = string;
export interface DnsServiceDiscovery {
    hostname: string;
    responseType?: string | undefined;
    ipPreference?: string | undefined;
}
export type AwsCloudMapName = string;
export type AwsCloudMapInstanceAttributeKey = string;
export type AwsCloudMapInstanceAttributeValue = string;
export interface AwsCloudMapInstanceAttribute {
    key: string;
    value: string;
}
export type AwsCloudMapInstanceAttributes = AwsCloudMapInstanceAttribute[];
export interface AwsCloudMapServiceDiscovery {
    namespaceName: string;
    serviceName: string;
    attributes?: AwsCloudMapInstanceAttribute[] | undefined;
    ipPreference?: string | undefined;
}
export type ServiceDiscovery = {
    dns: DnsServiceDiscovery;
    awsCloudMap?: undefined;
} | {
    dns?: undefined;
    awsCloudMap: AwsCloudMapServiceDiscovery;
};
export type PortProtocol = string;
export interface PortMapping {
    port: number;
    protocol: string;
}
export type ListenerTlsMode = string;
export interface ListenerTlsAcmCertificate {
    certificateArn: string;
}
export interface ListenerTlsFileCertificate {
    certificateChain: string;
    privateKey: string;
}
export type SdsSecretName = string;
export interface ListenerTlsSdsCertificate {
    secretName: string;
}
export type ListenerTlsCertificate = {
    acm: ListenerTlsAcmCertificate;
    file?: undefined;
    sds?: undefined;
} | {
    acm?: undefined;
    file: ListenerTlsFileCertificate;
    sds?: undefined;
} | {
    acm?: undefined;
    file?: undefined;
    sds: ListenerTlsSdsCertificate;
};
export interface TlsValidationContextFileTrust {
    certificateChain: string;
}
export interface TlsValidationContextSdsTrust {
    secretName: string;
}
export type ListenerTlsValidationContextTrust = {
    file: TlsValidationContextFileTrust;
    sds?: undefined;
} | {
    file?: undefined;
    sds: TlsValidationContextSdsTrust;
};
export interface ListenerTlsValidationContext {
    trust: ListenerTlsValidationContextTrust;
    subjectAlternativeNames?: SubjectAlternativeNames | undefined;
}
export interface ListenerTls {
    mode: string;
    certificate: ListenerTlsCertificate;
    validation?: ListenerTlsValidationContext | undefined;
}
export type HealthCheckTimeoutMillis = number;
export type HealthCheckIntervalMillis = number;
export type HealthCheckThreshold = number;
export interface HealthCheckPolicy {
    timeoutMillis: number;
    intervalMillis: number;
    protocol: string;
    port?: number | undefined;
    path?: string | undefined;
    healthyThreshold: number;
    unhealthyThreshold: number;
}
export type ListenerTimeout = {
    tcp: TcpTimeout;
    http?: undefined;
    http2?: undefined;
    grpc?: undefined;
} | {
    tcp?: undefined;
    http: HttpTimeout;
    http2?: undefined;
    grpc?: undefined;
} | {
    tcp?: undefined;
    http?: undefined;
    http2: HttpTimeout;
    grpc?: undefined;
} | {
    tcp?: undefined;
    http?: undefined;
    http2?: undefined;
    grpc: GrpcTimeout;
};
export type OutlierDetectionMaxServerErrors = number;
export type OutlierDetectionMaxEjectionPercent = number;
export interface OutlierDetection {
    maxServerErrors: number;
    interval: Duration;
    baseEjectionDuration: Duration;
    maxEjectionPercent: number;
}
export interface VirtualNodeTcpConnectionPool {
    maxConnections: number;
}
export interface VirtualNodeHttpConnectionPool {
    maxConnections: number;
    maxPendingRequests?: number | undefined;
}
export interface VirtualNodeHttp2ConnectionPool {
    maxRequests: number;
}
export interface VirtualNodeGrpcConnectionPool {
    maxRequests: number;
}
export type VirtualNodeConnectionPool = {
    tcp: VirtualNodeTcpConnectionPool;
    http?: undefined;
    http2?: undefined;
    grpc?: undefined;
} | {
    tcp?: undefined;
    http: VirtualNodeHttpConnectionPool;
    http2?: undefined;
    grpc?: undefined;
} | {
    tcp?: undefined;
    http?: undefined;
    http2: VirtualNodeHttp2ConnectionPool;
    grpc?: undefined;
} | {
    tcp?: undefined;
    http?: undefined;
    http2?: undefined;
    grpc: VirtualNodeGrpcConnectionPool;
};
export interface Listener {
    portMapping: PortMapping;
    tls?: ListenerTls | undefined;
    healthCheck?: HealthCheckPolicy | undefined;
    timeout?: ListenerTimeout | undefined;
    outlierDetection?: OutlierDetection | undefined;
    connectionPool?: VirtualNodeConnectionPool | undefined;
}
export type Listeners = Listener[];
export type ClientTlsCertificate = {
    file: ListenerTlsFileCertificate;
    sds?: undefined;
} | {
    file?: undefined;
    sds: ListenerTlsSdsCertificate;
};
export type CertificateAuthorityArns = string[];
export interface TlsValidationContextAcmTrust {
    certificateAuthorityArns: string[];
}
export type TlsValidationContextTrust = {
    acm: TlsValidationContextAcmTrust;
    file?: undefined;
    sds?: undefined;
} | {
    acm?: undefined;
    file: TlsValidationContextFileTrust;
    sds?: undefined;
} | {
    acm?: undefined;
    file?: undefined;
    sds: TlsValidationContextSdsTrust;
};
export interface TlsValidationContext {
    trust: TlsValidationContextTrust;
    subjectAlternativeNames?: SubjectAlternativeNames | undefined;
}
export interface ClientPolicyTls {
    enforce?: boolean | undefined;
    ports?: number[] | undefined;
    certificate?: ClientTlsCertificate | undefined;
    validation: TlsValidationContext;
}
export interface ClientPolicy {
    tls?: ClientPolicyTls | undefined;
}
export interface VirtualServiceBackend {
    virtualServiceName: string;
    clientPolicy?: ClientPolicy | undefined;
}
export type Backend = {
    virtualService: VirtualServiceBackend;
};
export type Backends = Backend[];
export interface BackendDefaults {
    clientPolicy?: ClientPolicy | undefined;
}
export interface FileAccessLog {
    path: string;
    format?: LoggingFormat | undefined;
}
export type AccessLog = {
    file: FileAccessLog;
};
export interface Logging {
    accessLog?: AccessLog | undefined;
}
export interface VirtualNodeSpec {
    serviceDiscovery?: ServiceDiscovery | undefined;
    listeners?: Listener[] | undefined;
    backends?: Backend[] | undefined;
    backendDefaults?: BackendDefaults | undefined;
    logging?: Logging | undefined;
}
export interface CreateVirtualNodeInput {
    virtualNodeName: string;
    meshName: string;
    spec: VirtualNodeSpec;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export type VirtualNodeStatusCode = string;
export interface VirtualNodeStatus {
    status: string;
}
export interface VirtualNodeData {
    meshName: string;
    virtualNodeName: string;
    spec: VirtualNodeSpec;
    metadata: ResourceMetadata;
    status: VirtualNodeStatus;
}
export interface CreateVirtualNodeOutput {
    virtualNode: VirtualNodeData;
}
export interface VirtualRouterListener {
    portMapping: PortMapping;
}
export type VirtualRouterListeners = VirtualRouterListener[];
export interface VirtualRouterSpec {
    listeners?: VirtualRouterListener[] | undefined;
}
export interface CreateVirtualRouterInput {
    virtualRouterName: string;
    meshName: string;
    spec: VirtualRouterSpec;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export type VirtualRouterStatusCode = string;
export interface VirtualRouterStatus {
    status: string;
}
export interface VirtualRouterData {
    meshName: string;
    virtualRouterName: string;
    spec: VirtualRouterSpec;
    metadata: ResourceMetadata;
    status: VirtualRouterStatus;
}
export interface CreateVirtualRouterOutput {
    virtualRouter: VirtualRouterData;
}
export interface VirtualNodeServiceProvider {
    virtualNodeName: string;
}
export interface VirtualRouterServiceProvider {
    virtualRouterName: string;
}
export type VirtualServiceProvider = {
    virtualNode: VirtualNodeServiceProvider;
    virtualRouter?: undefined;
} | {
    virtualNode?: undefined;
    virtualRouter: VirtualRouterServiceProvider;
};
export interface VirtualServiceSpec {
    provider?: VirtualServiceProvider | undefined;
}
export interface CreateVirtualServiceInput {
    virtualServiceName: string;
    meshName: string;
    spec: VirtualServiceSpec;
    tags?: TagRef[] | undefined;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export type VirtualServiceStatusCode = string;
export interface VirtualServiceStatus {
    status: string;
}
export interface VirtualServiceData {
    meshName: string;
    virtualServiceName: string;
    spec: VirtualServiceSpec;
    metadata: ResourceMetadata;
    status: VirtualServiceStatus;
}
export interface CreateVirtualServiceOutput {
    virtualService: VirtualServiceData;
}
export interface DeleteGatewayRouteInput {
    gatewayRouteName: string;
    meshName: string;
    virtualGatewayName: string;
    meshOwner?: string | undefined;
}
export interface DeleteGatewayRouteOutput {
    gatewayRoute: GatewayRouteData;
}
export interface DeleteMeshInput {
    meshName: string;
}
export interface DeleteMeshOutput {
    mesh: MeshData;
}
export interface DeleteRouteInput {
    routeName: string;
    meshName: string;
    virtualRouterName: string;
    meshOwner?: string | undefined;
}
export interface DeleteRouteOutput {
    route: RouteData;
}
export interface DeleteVirtualGatewayInput {
    virtualGatewayName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DeleteVirtualGatewayOutput {
    virtualGateway: VirtualGatewayData;
}
export interface DeleteVirtualNodeInput {
    virtualNodeName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DeleteVirtualNodeOutput {
    virtualNode: VirtualNodeData;
}
export interface DeleteVirtualRouterInput {
    virtualRouterName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DeleteVirtualRouterOutput {
    virtualRouter: VirtualRouterData;
}
export interface DeleteVirtualServiceInput {
    virtualServiceName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DeleteVirtualServiceOutput {
    virtualService: VirtualServiceData;
}
export interface DescribeGatewayRouteInput {
    gatewayRouteName: string;
    meshName: string;
    virtualGatewayName: string;
    meshOwner?: string | undefined;
}
export interface DescribeGatewayRouteOutput {
    gatewayRoute: GatewayRouteData;
}
export interface DescribeMeshInput {
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DescribeMeshOutput {
    mesh: MeshData;
}
export interface DescribeRouteInput {
    routeName: string;
    meshName: string;
    meshOwner?: string | undefined;
    virtualRouterName: string;
}
export interface DescribeRouteOutput {
    route: RouteData;
}
export interface DescribeVirtualGatewayInput {
    virtualGatewayName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DescribeVirtualGatewayOutput {
    virtualGateway: VirtualGatewayData;
}
export interface DescribeVirtualNodeInput {
    virtualNodeName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DescribeVirtualNodeOutput {
    virtualNode: VirtualNodeData;
}
export interface DescribeVirtualRouterInput {
    virtualRouterName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DescribeVirtualRouterOutput {
    virtualRouter: VirtualRouterData;
}
export interface DescribeVirtualServiceInput {
    virtualServiceName: string;
    meshName: string;
    meshOwner?: string | undefined;
}
export interface DescribeVirtualServiceOutput {
    virtualService: VirtualServiceData;
}
export type ListGatewayRoutesLimit = number;
export interface ListGatewayRoutesInput {
    meshName: string;
    virtualGatewayName: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
    meshOwner?: string | undefined;
}
export interface GatewayRouteRef {
    meshName: string;
    gatewayRouteName: string;
    virtualGatewayName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type GatewayRouteList = GatewayRouteRef[];
export interface ListGatewayRoutesOutput {
    gatewayRoutes: GatewayRouteRef[];
    nextToken?: string | undefined;
}
export type ListMeshesLimit = number;
export interface ListMeshesInput {
    nextToken?: string | undefined;
    limit?: number | undefined;
}
export interface MeshRef {
    meshName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type MeshList = MeshRef[];
export interface ListMeshesOutput {
    meshes: MeshRef[];
    nextToken?: string | undefined;
}
export type ListRoutesLimit = number;
export interface ListRoutesInput {
    meshName: string;
    virtualRouterName: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
    meshOwner?: string | undefined;
}
export interface RouteRef {
    meshName: string;
    virtualRouterName: string;
    routeName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type RouteList = RouteRef[];
export interface ListRoutesOutput {
    routes: RouteRef[];
    nextToken?: string | undefined;
}
export type TagsLimit = number;
export interface ListTagsForResourceInput {
    resourceArn: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
}
export interface ListTagsForResourceOutput {
    tags: TagRef[];
    nextToken?: string | undefined;
}
export type ListVirtualGatewaysLimit = number;
export interface ListVirtualGatewaysInput {
    meshName: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
    meshOwner?: string | undefined;
}
export interface VirtualGatewayRef {
    meshName: string;
    virtualGatewayName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type VirtualGatewayList = VirtualGatewayRef[];
export interface ListVirtualGatewaysOutput {
    virtualGateways: VirtualGatewayRef[];
    nextToken?: string | undefined;
}
export type ListVirtualNodesLimit = number;
export interface ListVirtualNodesInput {
    meshName: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
    meshOwner?: string | undefined;
}
export interface VirtualNodeRef {
    meshName: string;
    virtualNodeName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type VirtualNodeList = VirtualNodeRef[];
export interface ListVirtualNodesOutput {
    virtualNodes: VirtualNodeRef[];
    nextToken?: string | undefined;
}
export type ListVirtualRoutersLimit = number;
export interface ListVirtualRoutersInput {
    meshName: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
    meshOwner?: string | undefined;
}
export interface VirtualRouterRef {
    meshName: string;
    virtualRouterName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type VirtualRouterList = VirtualRouterRef[];
export interface ListVirtualRoutersOutput {
    virtualRouters: VirtualRouterRef[];
    nextToken?: string | undefined;
}
export type ListVirtualServicesLimit = number;
export interface ListVirtualServicesInput {
    meshName: string;
    nextToken?: string | undefined;
    limit?: number | undefined;
    meshOwner?: string | undefined;
}
export interface VirtualServiceRef {
    meshName: string;
    virtualServiceName: string;
    meshOwner: string;
    resourceOwner: string;
    arn: string;
    version: number;
    createdAt: Date;
    lastUpdatedAt: Date;
}
export type VirtualServiceList = VirtualServiceRef[];
export interface ListVirtualServicesOutput {
    virtualServices: VirtualServiceRef[];
    nextToken?: string | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: TagRef[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateGatewayRouteInput {
    gatewayRouteName: string;
    meshName: string;
    virtualGatewayName: string;
    spec: GatewayRouteSpec;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export interface UpdateGatewayRouteOutput {
    gatewayRoute: GatewayRouteData;
}
export interface UpdateMeshInput {
    meshName: string;
    spec?: MeshSpec | undefined;
    clientToken?: string | undefined;
}
export interface UpdateMeshOutput {
    mesh: MeshData;
}
export interface UpdateRouteInput {
    routeName: string;
    meshName: string;
    virtualRouterName: string;
    spec: RouteSpec;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export interface UpdateRouteOutput {
    route: RouteData;
}
export interface UpdateVirtualGatewayInput {
    virtualGatewayName: string;
    meshName: string;
    spec: VirtualGatewaySpec;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export interface UpdateVirtualGatewayOutput {
    virtualGateway: VirtualGatewayData;
}
export interface UpdateVirtualNodeInput {
    virtualNodeName: string;
    meshName: string;
    spec: VirtualNodeSpec;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export interface UpdateVirtualNodeOutput {
    virtualNode: VirtualNodeData;
}
export interface UpdateVirtualRouterInput {
    virtualRouterName: string;
    meshName: string;
    spec: VirtualRouterSpec;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export interface UpdateVirtualRouterOutput {
    virtualRouter: VirtualRouterData;
}
export interface UpdateVirtualServiceInput {
    virtualServiceName: string;
    meshName: string;
    spec: VirtualServiceSpec;
    clientToken?: string | undefined;
    meshOwner?: string | undefined;
}
export interface UpdateVirtualServiceOutput {
    virtualService: VirtualServiceData;
}
export type CreateGatewayRouteError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a gateway route.
 *
 * A gateway route is attached to a virtual gateway and routes traffic to an existing
 * virtual service. If a route matches a request, it can distribute traffic to a target
 * virtual service.
 *
 * For more information about gateway routes, see Gateway routes.
 */
export declare const createGatewayRoute: API.OperationMethod<CreateGatewayRouteInput & RegionInput, CreateGatewayRouteOutput, CreateGatewayRouteError, Credentials | HttpClient.HttpClient>;
export type CreateMeshError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a service mesh.
 *
 * A service mesh is a logical boundary for network traffic between services that are
 * represented by resources within the mesh. After you create your service mesh, you can
 * create virtual services, virtual nodes, virtual routers, and routes to distribute traffic
 * between the applications in your mesh.
 *
 * For more information about service meshes, see Service meshes.
 */
export declare const createMesh: API.OperationMethod<CreateMeshInput & RegionInput, CreateMeshOutput, CreateMeshError, Credentials | HttpClient.HttpClient>;
export type CreateRouteError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a route that is associated with a virtual router.
 *
 * You can route several different protocols and define a retry policy for a route.
 * Traffic can be routed to one or more virtual nodes.
 *
 * For more information about routes, see Routes.
 */
export declare const createRoute: API.OperationMethod<CreateRouteInput & RegionInput, CreateRouteOutput, CreateRouteError, Credentials | HttpClient.HttpClient>;
export type CreateVirtualGatewayError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a virtual gateway.
 *
 * A virtual gateway allows resources outside your mesh to communicate to resources that
 * are inside your mesh. The virtual gateway represents an Envoy proxy running in an Amazon ECS task, in a Kubernetes service, or on an Amazon EC2 instance. Unlike a
 * virtual node, which represents an Envoy running with an application, a virtual gateway
 * represents Envoy deployed by itself.
 *
 * For more information about virtual gateways, see Virtual gateways.
 */
export declare const createVirtualGateway: API.OperationMethod<CreateVirtualGatewayInput & RegionInput, CreateVirtualGatewayOutput, CreateVirtualGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateVirtualNodeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a virtual node within a service mesh.
 *
 * A virtual node acts as a logical pointer to a particular task group, such as an Amazon ECS service or a Kubernetes deployment. When you create a virtual node, you can
 * specify the service discovery information for your task group, and whether the proxy
 * running in a task group will communicate with other proxies using Transport Layer Security
 * (TLS).
 *
 * You define a `listener` for any inbound traffic that your virtual node
 * expects. Any virtual service that your virtual node expects to communicate to is specified
 * as a `backend`.
 *
 * The response metadata for your new virtual node contains the `arn` that is
 * associated with the virtual node. Set this value to the full ARN; for example,
 * `arn:aws:appmesh:us-west-2:123456789012:myMesh/default/virtualNode/myApp`)
 * as the `APPMESH_RESOURCE_ARN` environment variable for your task group's Envoy
 * proxy container in your task definition or pod spec. This is then mapped to the
 * `node.id` and `node.cluster` Envoy parameters.
 *
 * By default, App Mesh uses the name of the resource you specified in
 * `APPMESH_RESOURCE_ARN` when Envoy is referring to itself in metrics and
 * traces. You can override this behavior by setting the
 * `APPMESH_RESOURCE_CLUSTER` environment variable with your own name.
 *
 * For more information about virtual nodes, see Virtual nodes. You must be using `1.15.0` or later of the Envoy image when
 * setting these variables. For more information aboutApp Mesh Envoy variables, see
 * Envoy
 * image in the App Mesh User Guide.
 */
export declare const createVirtualNode: API.OperationMethod<CreateVirtualNodeInput & RegionInput, CreateVirtualNodeOutput, CreateVirtualNodeError, Credentials | HttpClient.HttpClient>;
export type CreateVirtualRouterError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a virtual router within a service mesh.
 *
 * Specify a `listener` for any inbound traffic that your virtual router
 * receives. Create a virtual router for each protocol and port that you need to route.
 * Virtual routers handle traffic for one or more virtual services within your mesh. After you
 * create your virtual router, create and associate routes for your virtual router that direct
 * incoming requests to different virtual nodes.
 *
 * For more information about virtual routers, see Virtual routers.
 */
export declare const createVirtualRouter: API.OperationMethod<CreateVirtualRouterInput & RegionInput, CreateVirtualRouterOutput, CreateVirtualRouterError, Credentials | HttpClient.HttpClient>;
export type CreateVirtualServiceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Creates a virtual service within a service mesh.
 *
 * A virtual service is an abstraction of a real service that is provided by a virtual node
 * directly or indirectly by means of a virtual router. Dependent services call your virtual
 * service by its `virtualServiceName`, and those requests are routed to the
 * virtual node or virtual router that is specified as the provider for the virtual
 * service.
 *
 * For more information about virtual services, see Virtual services.
 */
export declare const createVirtualService: API.OperationMethod<CreateVirtualServiceInput & RegionInput, CreateVirtualServiceOutput, CreateVirtualServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteGatewayRouteError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing gateway route.
 */
export declare const deleteGatewayRoute: API.OperationMethod<DeleteGatewayRouteInput & RegionInput, DeleteGatewayRouteOutput, DeleteGatewayRouteError, Credentials | HttpClient.HttpClient>;
export type DeleteMeshError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing service mesh.
 *
 * You must delete all resources (virtual services, routes, virtual routers, and virtual
 * nodes) in the service mesh before you can delete the mesh itself.
 */
export declare const deleteMesh: API.OperationMethod<DeleteMeshInput & RegionInput, DeleteMeshOutput, DeleteMeshError, Credentials | HttpClient.HttpClient>;
export type DeleteRouteError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing route.
 */
export declare const deleteRoute: API.OperationMethod<DeleteRouteInput & RegionInput, DeleteRouteOutput, DeleteRouteError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualGatewayError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing virtual gateway. You cannot delete a virtual gateway if any gateway
 * routes are associated to it.
 */
export declare const deleteVirtualGateway: API.OperationMethod<DeleteVirtualGatewayInput & RegionInput, DeleteVirtualGatewayOutput, DeleteVirtualGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualNodeError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing virtual node.
 *
 * You must delete any virtual services that list a virtual node as a service provider
 * before you can delete the virtual node itself.
 */
export declare const deleteVirtualNode: API.OperationMethod<DeleteVirtualNodeInput & RegionInput, DeleteVirtualNodeOutput, DeleteVirtualNodeError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualRouterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing virtual router.
 *
 * You must delete any routes associated with the virtual router before you can delete the
 * router itself.
 */
export declare const deleteVirtualRouter: API.OperationMethod<DeleteVirtualRouterInput & RegionInput, DeleteVirtualRouterOutput, DeleteVirtualRouterError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualServiceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ResourceInUseException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an existing virtual service.
 */
export declare const deleteVirtualService: API.OperationMethod<DeleteVirtualServiceInput & RegionInput, DeleteVirtualServiceOutput, DeleteVirtualServiceError, Credentials | HttpClient.HttpClient>;
export type DescribeGatewayRouteError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing gateway route.
 */
export declare const describeGatewayRoute: API.OperationMethod<DescribeGatewayRouteInput & RegionInput, DescribeGatewayRouteOutput, DescribeGatewayRouteError, Credentials | HttpClient.HttpClient>;
export type DescribeMeshError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing service mesh.
 */
export declare const describeMesh: API.OperationMethod<DescribeMeshInput & RegionInput, DescribeMeshOutput, DescribeMeshError, Credentials | HttpClient.HttpClient>;
export type DescribeRouteError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing route.
 */
export declare const describeRoute: API.OperationMethod<DescribeRouteInput & RegionInput, DescribeRouteOutput, DescribeRouteError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualGatewayError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing virtual gateway.
 */
export declare const describeVirtualGateway: API.OperationMethod<DescribeVirtualGatewayInput & RegionInput, DescribeVirtualGatewayOutput, DescribeVirtualGatewayError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualNodeError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing virtual node.
 */
export declare const describeVirtualNode: API.OperationMethod<DescribeVirtualNodeInput & RegionInput, DescribeVirtualNodeOutput, DescribeVirtualNodeError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualRouterError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing virtual router.
 */
export declare const describeVirtualRouter: API.OperationMethod<DescribeVirtualRouterInput & RegionInput, DescribeVirtualRouterOutput, DescribeVirtualRouterError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualServiceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Describes an existing virtual service.
 */
export declare const describeVirtualService: API.OperationMethod<DescribeVirtualServiceInput & RegionInput, DescribeVirtualServiceOutput, DescribeVirtualServiceError, Credentials | HttpClient.HttpClient>;
export type ListGatewayRoutesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing gateway routes that are associated to a virtual
 * gateway.
 */
export declare const listGatewayRoutes: API.PaginatedOperationMethod<ListGatewayRoutesInput & RegionInput, ListGatewayRoutesOutput, ListGatewayRoutesError, Credentials | HttpClient.HttpClient, GatewayRouteRef>;
export type ListMeshesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing service meshes.
 */
export declare const listMeshes: API.PaginatedOperationMethod<ListMeshesInput & RegionInput, ListMeshesOutput, ListMeshesError, Credentials | HttpClient.HttpClient, MeshRef>;
export type ListRoutesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing routes in a service mesh.
 */
export declare const listRoutes: API.PaginatedOperationMethod<ListRoutesInput & RegionInput, ListRoutesOutput, ListRoutesError, Credentials | HttpClient.HttpClient, RouteRef>;
export type ListTagsForResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * List the tags for an App Mesh resource.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient, TagRef>;
export type ListVirtualGatewaysError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing virtual gateways in a service mesh.
 */
export declare const listVirtualGateways: API.PaginatedOperationMethod<ListVirtualGatewaysInput & RegionInput, ListVirtualGatewaysOutput, ListVirtualGatewaysError, Credentials | HttpClient.HttpClient, VirtualGatewayRef>;
export type ListVirtualNodesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing virtual nodes.
 */
export declare const listVirtualNodes: API.PaginatedOperationMethod<ListVirtualNodesInput & RegionInput, ListVirtualNodesOutput, ListVirtualNodesError, Credentials | HttpClient.HttpClient, VirtualNodeRef>;
export type ListVirtualRoutersError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing virtual routers in a service mesh.
 */
export declare const listVirtualRouters: API.PaginatedOperationMethod<ListVirtualRoutersInput & RegionInput, ListVirtualRoutersOutput, ListVirtualRoutersError, Credentials | HttpClient.HttpClient, VirtualRouterRef>;
export type ListVirtualServicesError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of existing virtual services in a service mesh.
 */
export declare const listVirtualServices: API.PaginatedOperationMethod<ListVirtualServicesInput & RegionInput, ListVirtualServicesOutput, ListVirtualServicesError, Credentials | HttpClient.HttpClient, VirtualServiceRef>;
export type TagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | TooManyTagsException | CommonErrors;
/**
 * Associates the specified tags to a resource with the specified `resourceArn`.
 * If existing tags on a resource aren't specified in the request parameters, they aren't
 * changed. When a resource is deleted, the tags associated with that resource are also
 * deleted.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Deletes specified tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateGatewayRouteError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing gateway route that is associated to a specified virtual gateway in a
 * service mesh.
 */
export declare const updateGatewayRoute: API.OperationMethod<UpdateGatewayRouteInput & RegionInput, UpdateGatewayRouteOutput, UpdateGatewayRouteError, Credentials | HttpClient.HttpClient>;
export type UpdateMeshError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing service mesh.
 */
export declare const updateMesh: API.OperationMethod<UpdateMeshInput & RegionInput, UpdateMeshOutput, UpdateMeshError, Credentials | HttpClient.HttpClient>;
export type UpdateRouteError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing route for a specified service mesh and virtual router.
 */
export declare const updateRoute: API.OperationMethod<UpdateRouteInput & RegionInput, UpdateRouteOutput, UpdateRouteError, Credentials | HttpClient.HttpClient>;
export type UpdateVirtualGatewayError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing virtual gateway in a specified service mesh.
 */
export declare const updateVirtualGateway: API.OperationMethod<UpdateVirtualGatewayInput & RegionInput, UpdateVirtualGatewayOutput, UpdateVirtualGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateVirtualNodeError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing virtual node in a specified service mesh.
 */
export declare const updateVirtualNode: API.OperationMethod<UpdateVirtualNodeInput & RegionInput, UpdateVirtualNodeOutput, UpdateVirtualNodeError, Credentials | HttpClient.HttpClient>;
export type UpdateVirtualRouterError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing virtual router in a specified service mesh.
 */
export declare const updateVirtualRouter: API.OperationMethod<UpdateVirtualRouterInput & RegionInput, UpdateVirtualRouterOutput, UpdateVirtualRouterError, Credentials | HttpClient.HttpClient>;
export type UpdateVirtualServiceError = BadRequestException | ConflictException | ForbiddenException | InternalServerErrorException | LimitExceededException | NotFoundException | ServiceUnavailableException | TooManyRequestsException | CommonErrors;
/**
 * Updates an existing virtual service in a specified service mesh.
 */
export declare const updateVirtualService: API.OperationMethod<UpdateVirtualServiceInput & RegionInput, UpdateVirtualServiceOutput, UpdateVirtualServiceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=app-mesh.d.ts.map