import type { HttpClient } from "effect/http/HttpClient";
import * as Layer from "effect/Layer";
import type { PlatformError } from "effect/PlatformError";
import { type AlchemyContext } from "../AlchemyContext.ts";
import { ArtifactStore } from "../Artifacts.ts";
import { type CredentialsStore } from "../Auth/Credentials.ts";
import { type ProfileStore } from "../Auth/Profile.ts";
import * as Interaction from "../Interaction.ts";
import { PlatformServices } from "../Util/PlatformServices.ts";
/** The services {@link layer} provides; every Alchemist operation runs under them. */
export type Services = AlchemyContext | ArtifactStore | CredentialsStore | HttpClient | Interaction.Interaction | ProfileStore | PlatformServices;
/**
 * All services required by the programmatic Alchemist API.
 *
 * Log lines print on the console. Typed events are log records too; observe
 * them around a call with {@link import("../Events.ts").onEvent}.
 * The non-interactive Interaction default serves the engine paths that need
 * one (state-store confirms fail typed; profile probes never prompt).
 *
 * @example
 * ```ts
 * Effect.runPromise(
 *   program.pipe(Effect.provide(Alchemist.layer()), Effect.scoped),
 * )
 * ```
 */
export declare const layer: () => Layer.Layer<Services, PlatformError>;
//# sourceMappingURL=Runtime.d.ts.map