import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccountSuspendedException_base: S.TaggedErrorClass<"AccountSuspendedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AccountSuspendedException extends /*@__PURE__*/ AccountSuspendedException_base {
}
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MailFromDomainNotVerifiedException_base: S.TaggedErrorClass<"MailFromDomainNotVerifiedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MailFromDomainNotVerifiedException extends /*@__PURE__*/ MailFromDomainNotVerifiedException_base {
}
declare const MessageRejected_base: S.TaggedErrorClass<"MessageRejected", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MessageRejected extends /*@__PURE__*/ MessageRejected_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const SendingPausedException_base: S.TaggedErrorClass<"SendingPausedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SendingPausedException extends /*@__PURE__*/ SendingPausedException_base {
}
declare const TooManyRequestsException_base: S.TaggedErrorClass<"TooManyRequestsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class TooManyRequestsException extends /*@__PURE__*/ TooManyRequestsException_base {
}
export type ConfigurationSetName = string;
export type CustomRedirectDomain = string;
export interface TrackingOptions {
    CustomRedirectDomain: string;
}
export type TlsPolicy = "REQUIRE" | "OPTIONAL" | (string & {});
export type PoolName = string;
export interface DeliveryOptions {
    TlsPolicy?: TlsPolicy | undefined;
    SendingPoolName?: string | undefined;
}
export type Enabled = boolean;
export type LastFreshStart = Date;
export interface ReputationOptions {
    ReputationMetricsEnabled?: boolean | undefined;
    LastFreshStart?: Date | undefined;
}
export interface SendingOptions {
    SendingEnabled?: boolean | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateConfigurationSetRequest {
    ConfigurationSetName: string;
    TrackingOptions?: TrackingOptions | undefined;
    DeliveryOptions?: DeliveryOptions | undefined;
    ReputationOptions?: ReputationOptions | undefined;
    SendingOptions?: SendingOptions | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateConfigurationSetResponse {
}
export type EventDestinationName = string;
export type EventType = "SEND" | "REJECT" | "BOUNCE" | "COMPLAINT" | "DELIVERY" | "OPEN" | "CLICK" | "RENDERING_FAILURE" | (string & {});
export type EventTypes = EventType[];
export type AmazonResourceName = string;
export interface KinesisFirehoseDestination {
    IamRoleArn: string;
    DeliveryStreamArn: string;
}
export type DimensionName = string;
export type DimensionValueSource = "MESSAGE_TAG" | "EMAIL_HEADER" | "LINK_TAG" | (string & {});
export type DefaultDimensionValue = string;
export interface CloudWatchDimensionConfiguration {
    DimensionName: string;
    DimensionValueSource: DimensionValueSource;
    DefaultDimensionValue: string;
}
export type CloudWatchDimensionConfigurations = CloudWatchDimensionConfiguration[];
export interface CloudWatchDestination {
    DimensionConfigurations: CloudWatchDimensionConfiguration[];
}
export interface SnsDestination {
    TopicArn: string;
}
export interface PinpointDestination {
    ApplicationArn?: string | undefined;
}
export interface EventDestinationDefinition {
    Enabled?: boolean | undefined;
    MatchingEventTypes?: EventType[] | undefined;
    KinesisFirehoseDestination?: KinesisFirehoseDestination | undefined;
    CloudWatchDestination?: CloudWatchDestination | undefined;
    SnsDestination?: SnsDestination | undefined;
    PinpointDestination?: PinpointDestination | undefined;
}
export interface CreateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
    EventDestination: EventDestinationDefinition;
}
export interface CreateConfigurationSetEventDestinationResponse {
}
export interface CreateDedicatedIpPoolRequest {
    PoolName: string;
    Tags?: Tag[] | undefined;
}
export interface CreateDedicatedIpPoolResponse {
}
export type ReportName = string;
export type EmailAddress = string;
export type MessageData = string;
export type Charset = string;
export interface Content {
    Data: string;
    Charset?: string | undefined;
}
export interface Body {
    Text?: Content | undefined;
    Html?: Content | undefined;
}
export interface Message {
    Subject: Content;
    Body: Body;
}
export type RawMessageData = Uint8Array;
export interface RawMessage {
    Data: Uint8Array;
}
export type TemplateArn = string;
export type TemplateData = string;
export interface Template {
    TemplateArn?: string | undefined;
    TemplateData?: string | undefined;
}
export interface EmailContent {
    Simple?: Message | undefined;
    Raw?: RawMessage | undefined;
    Template?: Template | undefined;
}
export interface CreateDeliverabilityTestReportRequest {
    ReportName?: string | undefined;
    FromEmailAddress: string;
    Content: EmailContent;
    Tags?: Tag[] | undefined;
}
export type ReportId = string;
export type DeliverabilityTestStatus = "IN_PROGRESS" | "COMPLETED" | (string & {});
export interface CreateDeliverabilityTestReportResponse {
    ReportId: string;
    DeliverabilityTestStatus: DeliverabilityTestStatus;
}
export type Identity = string;
export interface CreateEmailIdentityRequest {
    EmailIdentity: string;
    Tags?: Tag[] | undefined;
}
export type IdentityType = "EMAIL_ADDRESS" | "DOMAIN" | "MANAGED_DOMAIN" | (string & {});
export type DkimStatus = "PENDING" | "SUCCESS" | "FAILED" | "TEMPORARY_FAILURE" | "NOT_STARTED" | (string & {});
export type DnsToken = string;
export type DnsTokenList = string[];
export interface DkimAttributes {
    SigningEnabled?: boolean | undefined;
    Status?: DkimStatus | undefined;
    Tokens?: string[] | undefined;
}
export interface CreateEmailIdentityResponse {
    IdentityType?: IdentityType | undefined;
    VerifiedForSendingStatus?: boolean | undefined;
    DkimAttributes?: DkimAttributes | undefined;
}
export interface DeleteConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface DeleteConfigurationSetResponse {
}
export interface DeleteConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
}
export interface DeleteConfigurationSetEventDestinationResponse {
}
export interface DeleteDedicatedIpPoolRequest {
    PoolName: string;
}
export interface DeleteDedicatedIpPoolResponse {
}
export interface DeleteEmailIdentityRequest {
    EmailIdentity: string;
}
export interface DeleteEmailIdentityResponse {
}
export interface GetAccountRequest {
}
export type Max24HourSend = number;
export type MaxSendRate = number;
export type SentLast24Hours = number;
export interface SendQuota {
    Max24HourSend?: number | undefined;
    MaxSendRate?: number | undefined;
    SentLast24Hours?: number | undefined;
}
export type GeneralEnforcementStatus = string;
export interface GetAccountResponse {
    SendQuota?: SendQuota | undefined;
    SendingEnabled?: boolean | undefined;
    DedicatedIpAutoWarmupEnabled?: boolean | undefined;
    EnforcementStatus?: string | undefined;
    ProductionAccessEnabled?: boolean | undefined;
}
export type BlacklistItemName = string;
export type BlacklistItemNames = string[];
export interface GetBlacklistReportsRequest {
    BlacklistItemNames: string[];
}
export type RblName = string;
export type BlacklistingDescription = string;
export interface BlacklistEntry {
    RblName?: string | undefined;
    ListingTime?: Date | undefined;
    Description?: string | undefined;
}
export type BlacklistEntries = BlacklistEntry[];
export type BlacklistReport = {
    [key: string]: BlacklistEntry[] | undefined;
};
export interface GetBlacklistReportsResponse {
    BlacklistReport: {
        [key: string]: BlacklistEntry[] | undefined;
    };
}
export interface GetConfigurationSetRequest {
    ConfigurationSetName: string;
}
export interface GetConfigurationSetResponse {
    ConfigurationSetName?: string | undefined;
    TrackingOptions?: TrackingOptions | undefined;
    DeliveryOptions?: DeliveryOptions | undefined;
    ReputationOptions?: ReputationOptions | undefined;
    SendingOptions?: SendingOptions | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetConfigurationSetEventDestinationsRequest {
    ConfigurationSetName: string;
}
export interface EventDestination {
    Name: string;
    Enabled?: boolean | undefined;
    MatchingEventTypes: EventType[];
    KinesisFirehoseDestination?: KinesisFirehoseDestination | undefined;
    CloudWatchDestination?: CloudWatchDestination | undefined;
    SnsDestination?: SnsDestination | undefined;
    PinpointDestination?: PinpointDestination | undefined;
}
export type EventDestinations = EventDestination[];
export interface GetConfigurationSetEventDestinationsResponse {
    EventDestinations?: EventDestination[] | undefined;
}
export type Ip = string;
export interface GetDedicatedIpRequest {
    Ip: string;
}
export type WarmupStatus = "IN_PROGRESS" | "DONE" | (string & {});
export type Percentage100Wrapper = number;
export interface DedicatedIp {
    Ip: string;
    WarmupStatus: WarmupStatus;
    WarmupPercentage: number;
    PoolName?: string | undefined;
}
export interface GetDedicatedIpResponse {
    DedicatedIp?: DedicatedIp | undefined;
}
export type NextToken = string;
export type MaxItems = number;
export interface GetDedicatedIpsRequest {
    PoolName?: string | undefined;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type DedicatedIpList = DedicatedIp[];
export interface GetDedicatedIpsResponse {
    DedicatedIps?: DedicatedIp[] | undefined;
    NextToken?: string | undefined;
}
export interface GetDeliverabilityDashboardOptionsRequest {
}
export type DeliverabilityDashboardAccountStatus = "ACTIVE" | "PENDING_EXPIRATION" | "DISABLED" | (string & {});
export type Domain = string;
export type IspName = string;
export type IspNameList = string[];
export interface InboxPlacementTrackingOption {
    Global?: boolean | undefined;
    TrackedIsps?: string[] | undefined;
}
export interface DomainDeliverabilityTrackingOption {
    Domain?: string | undefined;
    SubscriptionStartDate?: Date | undefined;
    InboxPlacementTrackingOption?: InboxPlacementTrackingOption | undefined;
}
export type DomainDeliverabilityTrackingOptions = DomainDeliverabilityTrackingOption[];
export interface GetDeliverabilityDashboardOptionsResponse {
    DashboardEnabled: boolean;
    SubscriptionExpiryDate?: Date | undefined;
    AccountStatus?: DeliverabilityDashboardAccountStatus | undefined;
    ActiveSubscribedDomains?: DomainDeliverabilityTrackingOption[] | undefined;
    PendingExpirationSubscribedDomains?: DomainDeliverabilityTrackingOption[] | undefined;
}
export interface GetDeliverabilityTestReportRequest {
    ReportId: string;
}
export type DeliverabilityTestSubject = string;
export interface DeliverabilityTestReport {
    ReportId?: string | undefined;
    ReportName?: string | undefined;
    Subject?: string | undefined;
    FromEmailAddress?: string | undefined;
    CreateDate?: Date | undefined;
    DeliverabilityTestStatus?: DeliverabilityTestStatus | undefined;
}
export type Percentage = number;
export interface PlacementStatistics {
    InboxPercentage?: number | undefined;
    SpamPercentage?: number | undefined;
    MissingPercentage?: number | undefined;
    SpfPercentage?: number | undefined;
    DkimPercentage?: number | undefined;
}
export interface IspPlacement {
    IspName?: string | undefined;
    PlacementStatistics?: PlacementStatistics | undefined;
}
export type IspPlacements = IspPlacement[];
export type MessageContent = string;
export interface GetDeliverabilityTestReportResponse {
    DeliverabilityTestReport: DeliverabilityTestReport;
    OverallPlacement: PlacementStatistics;
    IspPlacements: IspPlacement[];
    Message?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type CampaignId = string;
export interface GetDomainDeliverabilityCampaignRequest {
    CampaignId: string;
}
export type ImageUrl = string;
export type Subject = string;
export type IpList = string[];
export type Volume = number;
export type Esp = string;
export type Esps = string[];
export interface DomainDeliverabilityCampaign {
    CampaignId?: string | undefined;
    ImageUrl?: string | undefined;
    Subject?: string | undefined;
    FromAddress?: string | undefined;
    SendingIps?: string[] | undefined;
    FirstSeenDateTime?: Date | undefined;
    LastSeenDateTime?: Date | undefined;
    InboxCount?: number | undefined;
    SpamCount?: number | undefined;
    ReadRate?: number | undefined;
    DeleteRate?: number | undefined;
    ReadDeleteRate?: number | undefined;
    ProjectedVolume?: number | undefined;
    Esps?: string[] | undefined;
}
export interface GetDomainDeliverabilityCampaignResponse {
    DomainDeliverabilityCampaign: DomainDeliverabilityCampaign;
}
export interface GetDomainStatisticsReportRequest {
    Domain: string;
    StartDate: Date;
    EndDate: Date;
}
export interface VolumeStatistics {
    InboxRawCount?: number | undefined;
    SpamRawCount?: number | undefined;
    ProjectedInbox?: number | undefined;
    ProjectedSpam?: number | undefined;
}
export interface DomainIspPlacement {
    IspName?: string | undefined;
    InboxRawCount?: number | undefined;
    SpamRawCount?: number | undefined;
    InboxPercentage?: number | undefined;
    SpamPercentage?: number | undefined;
}
export type DomainIspPlacements = DomainIspPlacement[];
export interface OverallVolume {
    VolumeStatistics?: VolumeStatistics | undefined;
    ReadRatePercent?: number | undefined;
    DomainIspPlacements?: DomainIspPlacement[] | undefined;
}
export interface DailyVolume {
    StartDate?: Date | undefined;
    VolumeStatistics?: VolumeStatistics | undefined;
    DomainIspPlacements?: DomainIspPlacement[] | undefined;
}
export type DailyVolumes = DailyVolume[];
export interface GetDomainStatisticsReportResponse {
    OverallVolume: OverallVolume;
    DailyVolumes: DailyVolume[];
}
export interface GetEmailIdentityRequest {
    EmailIdentity: string;
}
export type MailFromDomainName = string;
export type MailFromDomainStatus = "PENDING" | "SUCCESS" | "FAILED" | "TEMPORARY_FAILURE" | (string & {});
export type BehaviorOnMxFailure = "USE_DEFAULT_VALUE" | "REJECT_MESSAGE" | (string & {});
export interface MailFromAttributes {
    MailFromDomain: string;
    MailFromDomainStatus: MailFromDomainStatus;
    BehaviorOnMxFailure: BehaviorOnMxFailure;
}
export interface GetEmailIdentityResponse {
    IdentityType?: IdentityType | undefined;
    FeedbackForwardingStatus?: boolean | undefined;
    VerifiedForSendingStatus?: boolean | undefined;
    DkimAttributes?: DkimAttributes | undefined;
    MailFromAttributes?: MailFromAttributes | undefined;
    Tags?: Tag[] | undefined;
}
export interface ListConfigurationSetsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type ConfigurationSetNameList = string[];
export interface ListConfigurationSetsResponse {
    ConfigurationSets?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDedicatedIpPoolsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type ListOfDedicatedIpPools = string[];
export interface ListDedicatedIpPoolsResponse {
    DedicatedIpPools?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeliverabilityTestReportsRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type DeliverabilityTestReports = DeliverabilityTestReport[];
export interface ListDeliverabilityTestReportsResponse {
    DeliverabilityTestReports: DeliverabilityTestReport[];
    NextToken?: string | undefined;
}
export interface ListDomainDeliverabilityCampaignsRequest {
    StartDate: Date;
    EndDate: Date;
    SubscribedDomain: string;
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export type DomainDeliverabilityCampaignList = DomainDeliverabilityCampaign[];
export interface ListDomainDeliverabilityCampaignsResponse {
    DomainDeliverabilityCampaigns: DomainDeliverabilityCampaign[];
    NextToken?: string | undefined;
}
export interface ListEmailIdentitiesRequest {
    NextToken?: string | undefined;
    PageSize?: number | undefined;
}
export interface IdentityInfo {
    IdentityType?: IdentityType | undefined;
    IdentityName?: string | undefined;
    SendingEnabled?: boolean | undefined;
}
export type IdentityInfoList = IdentityInfo[];
export interface ListEmailIdentitiesResponse {
    EmailIdentities?: IdentityInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags: Tag[];
}
export interface PutAccountDedicatedIpWarmupAttributesRequest {
    AutoWarmupEnabled?: boolean | undefined;
}
export interface PutAccountDedicatedIpWarmupAttributesResponse {
}
export interface PutAccountSendingAttributesRequest {
    SendingEnabled?: boolean | undefined;
}
export interface PutAccountSendingAttributesResponse {
}
export type SendingPoolName = string;
export interface PutConfigurationSetDeliveryOptionsRequest {
    ConfigurationSetName: string;
    TlsPolicy?: TlsPolicy | undefined;
    SendingPoolName?: string | undefined;
}
export interface PutConfigurationSetDeliveryOptionsResponse {
}
export interface PutConfigurationSetReputationOptionsRequest {
    ConfigurationSetName: string;
    ReputationMetricsEnabled?: boolean | undefined;
}
export interface PutConfigurationSetReputationOptionsResponse {
}
export interface PutConfigurationSetSendingOptionsRequest {
    ConfigurationSetName: string;
    SendingEnabled?: boolean | undefined;
}
export interface PutConfigurationSetSendingOptionsResponse {
}
export interface PutConfigurationSetTrackingOptionsRequest {
    ConfigurationSetName: string;
    CustomRedirectDomain?: string | undefined;
}
export interface PutConfigurationSetTrackingOptionsResponse {
}
export interface PutDedicatedIpInPoolRequest {
    Ip: string;
    DestinationPoolName: string;
}
export interface PutDedicatedIpInPoolResponse {
}
export interface PutDedicatedIpWarmupAttributesRequest {
    Ip: string;
    WarmupPercentage: number;
}
export interface PutDedicatedIpWarmupAttributesResponse {
}
export interface PutDeliverabilityDashboardOptionRequest {
    DashboardEnabled: boolean;
    SubscribedDomains?: DomainDeliverabilityTrackingOption[] | undefined;
}
export interface PutDeliverabilityDashboardOptionResponse {
}
export interface PutEmailIdentityDkimAttributesRequest {
    EmailIdentity: string;
    SigningEnabled?: boolean | undefined;
}
export interface PutEmailIdentityDkimAttributesResponse {
}
export interface PutEmailIdentityFeedbackAttributesRequest {
    EmailIdentity: string;
    EmailForwardingEnabled?: boolean | undefined;
}
export interface PutEmailIdentityFeedbackAttributesResponse {
}
export interface PutEmailIdentityMailFromAttributesRequest {
    EmailIdentity: string;
    MailFromDomain?: string | undefined;
    BehaviorOnMxFailure?: BehaviorOnMxFailure | undefined;
}
export interface PutEmailIdentityMailFromAttributesResponse {
}
export type EmailAddressList = string[];
export interface Destination {
    ToAddresses?: string[] | undefined;
    CcAddresses?: string[] | undefined;
    BccAddresses?: string[] | undefined;
}
export type MessageTagName = string;
export type MessageTagValue = string;
export interface MessageTag {
    Name: string;
    Value: string;
}
export type MessageTagList = MessageTag[];
export interface SendEmailRequest {
    FromEmailAddress?: string | undefined;
    Destination: Destination;
    ReplyToAddresses?: string[] | undefined;
    FeedbackForwardingEmailAddress?: string | undefined;
    Content: EmailContent;
    EmailTags?: MessageTag[] | undefined;
    ConfigurationSetName?: string | undefined;
}
export type OutboundMessageId = string;
export interface SendEmailResponse {
    MessageId?: string | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConfigurationSetEventDestinationRequest {
    ConfigurationSetName: string;
    EventDestinationName: string;
    EventDestination: EventDestinationDefinition;
}
export interface UpdateConfigurationSetEventDestinationResponse {
}
export type ErrorMessage = string;
export type CreateConfigurationSetError = AlreadyExistsException | BadRequestException | ConcurrentModificationException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Create a configuration set. *Configuration sets* are groups of
 * rules that you can apply to the emails you send using Amazon Pinpoint. You apply a configuration
 * set to an email by including a reference to the configuration set in the headers of the
 * email. When you apply a configuration set to an email, all of the rules in that
 * configuration set are applied to the email.
 */
export declare const createConfigurationSet: API.OperationMethod<CreateConfigurationSetRequest & RegionInput, CreateConfigurationSetResponse, CreateConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationSetEventDestinationError = AlreadyExistsException | BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Create an event destination. In Amazon Pinpoint, *events* include message
 * sends, deliveries, opens, clicks, bounces, and complaints. Event
 * destinations are places that you can send information about these events
 * to. For example, you can send event data to Amazon SNS to receive notifications when you
 * receive bounces or complaints, or you can use Amazon Kinesis Data Firehose to stream data to Amazon S3 for long-term
 * storage.
 *
 * A single configuration set can include more than one event destination.
 */
export declare const createConfigurationSetEventDestination: API.OperationMethod<CreateConfigurationSetEventDestinationRequest & RegionInput, CreateConfigurationSetEventDestinationResponse, CreateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateDedicatedIpPoolError = AlreadyExistsException | BadRequestException | ConcurrentModificationException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Create a new pool of dedicated IP addresses. A pool can include one or more dedicated
 * IP addresses that are associated with your Amazon Pinpoint account. You can associate a pool with
 * a configuration set. When you send an email that uses that configuration set, Amazon Pinpoint
 * sends it using only the IP addresses in the associated pool.
 */
export declare const createDedicatedIpPool: API.OperationMethod<CreateDedicatedIpPoolRequest & RegionInput, CreateDedicatedIpPoolResponse, CreateDedicatedIpPoolError, Credentials | HttpClient.HttpClient>;
export type CreateDeliverabilityTestReportError = AccountSuspendedException | BadRequestException | ConcurrentModificationException | LimitExceededException | MailFromDomainNotVerifiedException | MessageRejected | NotFoundException | SendingPausedException | TooManyRequestsException | CommonErrors;
/**
 * Create a new predictive inbox placement test. Predictive inbox placement tests can help you predict how your messages will be handled
 * by various email providers around the world. When you perform a predictive inbox placement test, you provide a
 * sample message that contains the content that you plan to send to your customers. Amazon Pinpoint
 * then sends that message to special email addresses spread across several major email
 * providers. After about 24 hours, the test is complete, and you can use the
 * `GetDeliverabilityTestReport` operation to view the results of the
 * test.
 */
export declare const createDeliverabilityTestReport: API.OperationMethod<CreateDeliverabilityTestReportRequest & RegionInput, CreateDeliverabilityTestReportResponse, CreateDeliverabilityTestReportError, Credentials | HttpClient.HttpClient>;
export type CreateEmailIdentityError = BadRequestException | ConcurrentModificationException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Verifies an email identity for use with Amazon Pinpoint. In Amazon Pinpoint, an identity is an email
 * address or domain that you use when you send email. Before you can use an identity to
 * send email with Amazon Pinpoint, you first have to verify it. By verifying an address, you
 * demonstrate that you're the owner of the address, and that you've given Amazon Pinpoint permission
 * to send email from the address.
 *
 * When you verify an email address, Amazon Pinpoint sends an email to the address. Your email
 * address is verified as soon as you follow the link in the verification email.
 *
 * When you verify a domain, this operation provides a set of DKIM tokens, which you can
 * convert into CNAME tokens. You add these CNAME tokens to the DNS configuration for your
 * domain. Your domain is verified when Amazon Pinpoint detects these records in the DNS
 * configuration for your domain. It usually takes around 72 hours to complete the domain
 * verification process.
 */
export declare const createEmailIdentity: API.OperationMethod<CreateEmailIdentityRequest & RegionInput, CreateEmailIdentityResponse, CreateEmailIdentityError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an existing configuration set.
 *
 * In Amazon Pinpoint, *configuration sets* are groups of rules that you can
 * apply to the emails you send. You apply a configuration set to an email by including a
 * reference to the configuration set in the headers of the email. When you apply a
 * configuration set to an email, all of the rules in that configuration set are applied to
 * the email.
 */
export declare const deleteConfigurationSet: API.OperationMethod<DeleteConfigurationSetRequest & RegionInput, DeleteConfigurationSetResponse, DeleteConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationSetEventDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete an event destination.
 *
 * In Amazon Pinpoint, *events* include message sends, deliveries, opens,
 * clicks, bounces, and complaints. *Event destinations* are places that
 * you can send information about these events to. For example, you can send event data to
 * Amazon SNS to receive notifications when you receive bounces or complaints, or you can use
 * Amazon Kinesis Data Firehose to stream data to Amazon S3 for long-term storage.
 */
export declare const deleteConfigurationSetEventDestination: API.OperationMethod<DeleteConfigurationSetEventDestinationRequest & RegionInput, DeleteConfigurationSetEventDestinationResponse, DeleteConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteDedicatedIpPoolError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Delete a dedicated IP pool.
 */
export declare const deleteDedicatedIpPool: API.OperationMethod<DeleteDedicatedIpPoolRequest & RegionInput, DeleteDedicatedIpPoolResponse, DeleteDedicatedIpPoolError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailIdentityError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Deletes an email identity that you previously verified for use with Amazon Pinpoint. An identity
 * can be either an email address or a domain name.
 */
export declare const deleteEmailIdentity: API.OperationMethod<DeleteEmailIdentityRequest & RegionInput, DeleteEmailIdentityResponse, DeleteEmailIdentityError, Credentials | HttpClient.HttpClient>;
export type GetAccountError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Obtain information about the email-sending status and capabilities of your Amazon Pinpoint
 * account in the current AWS Region.
 */
export declare const getAccount: API.OperationMethod<GetAccountRequest & RegionInput, GetAccountResponse, GetAccountError, Credentials | HttpClient.HttpClient>;
export type GetBlacklistReportsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of the blacklists that your dedicated IP addresses appear on.
 */
export declare const getBlacklistReports: API.OperationMethod<GetBlacklistReportsRequest & RegionInput, GetBlacklistReportsResponse, GetBlacklistReportsError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationSetError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get information about an existing configuration set, including the dedicated IP pool
 * that it's associated with, whether or not it's enabled for sending email, and
 * more.
 *
 * In Amazon Pinpoint, *configuration sets* are groups of rules that you can
 * apply to the emails you send. You apply a configuration set to an email by including a
 * reference to the configuration set in the headers of the email. When you apply a
 * configuration set to an email, all of the rules in that configuration set are applied to
 * the email.
 */
export declare const getConfigurationSet: API.OperationMethod<GetConfigurationSetRequest & RegionInput, GetConfigurationSetResponse, GetConfigurationSetError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationSetEventDestinationsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of event destinations that are associated with a configuration
 * set.
 *
 * In Amazon Pinpoint, *events* include message sends, deliveries, opens,
 * clicks, bounces, and complaints. *Event destinations* are places that
 * you can send information about these events to. For example, you can send event data to
 * Amazon SNS to receive notifications when you receive bounces or complaints, or you can use
 * Amazon Kinesis Data Firehose to stream data to Amazon S3 for long-term storage.
 */
export declare const getConfigurationSetEventDestinations: API.OperationMethod<GetConfigurationSetEventDestinationsRequest & RegionInput, GetConfigurationSetEventDestinationsResponse, GetConfigurationSetEventDestinationsError, Credentials | HttpClient.HttpClient>;
export type GetDedicatedIpError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Get information about a dedicated IP address, including the name of the dedicated IP
 * pool that it's associated with, as well information about the automatic warm-up process
 * for the address.
 */
export declare const getDedicatedIp: API.OperationMethod<GetDedicatedIpRequest & RegionInput, GetDedicatedIpResponse, GetDedicatedIpError, Credentials | HttpClient.HttpClient>;
export type GetDedicatedIpsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * List the dedicated IP addresses that are associated with your Amazon Pinpoint
 * account.
 */
export declare const getDedicatedIps: API.PaginatedOperationMethod<GetDedicatedIpsRequest & RegionInput, GetDedicatedIpsResponse, GetDedicatedIpsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetDeliverabilityDashboardOptionsError = BadRequestException | LimitExceededException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve information about the status of the Deliverability dashboard for your Amazon Pinpoint account.
 * When the Deliverability dashboard is enabled, you gain access to reputation, deliverability, and
 * other metrics for the domains that you use to send email using Amazon Pinpoint. You also gain the
 * ability to perform predictive inbox placement tests.
 *
 * When you use the Deliverability dashboard, you pay a monthly subscription charge, in addition
 * to any other fees that you accrue by using Amazon Pinpoint. For more information about the
 * features and cost of a Deliverability dashboard subscription, see Amazon Pinpoint Pricing.
 */
export declare const getDeliverabilityDashboardOptions: API.OperationMethod<GetDeliverabilityDashboardOptionsRequest & RegionInput, GetDeliverabilityDashboardOptionsResponse, GetDeliverabilityDashboardOptionsError, Credentials | HttpClient.HttpClient>;
export type GetDeliverabilityTestReportError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve the results of a predictive inbox placement test.
 */
export declare const getDeliverabilityTestReport: API.OperationMethod<GetDeliverabilityTestReportRequest & RegionInput, GetDeliverabilityTestReportResponse, GetDeliverabilityTestReportError, Credentials | HttpClient.HttpClient>;
export type GetDomainDeliverabilityCampaignError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve all the deliverability data for a specific campaign. This data is available
 * for a campaign only if the campaign sent email by using a domain that the
 * Deliverability dashboard is enabled for (`PutDeliverabilityDashboardOption`
 * operation).
 */
export declare const getDomainDeliverabilityCampaign: API.OperationMethod<GetDomainDeliverabilityCampaignRequest & RegionInput, GetDomainDeliverabilityCampaignResponse, GetDomainDeliverabilityCampaignError, Credentials | HttpClient.HttpClient>;
export type GetDomainStatisticsReportError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve inbox placement and engagement rates for the domains that you use to send
 * email.
 */
export declare const getDomainStatisticsReport: API.OperationMethod<GetDomainStatisticsReportRequest & RegionInput, GetDomainStatisticsReportResponse, GetDomainStatisticsReportError, Credentials | HttpClient.HttpClient>;
export type GetEmailIdentityError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Provides information about a specific identity associated with your Amazon Pinpoint account,
 * including the identity's verification status, its DKIM authentication status, and its
 * custom Mail-From settings.
 */
export declare const getEmailIdentity: API.OperationMethod<GetEmailIdentityRequest & RegionInput, GetEmailIdentityResponse, GetEmailIdentityError, Credentials | HttpClient.HttpClient>;
export type ListConfigurationSetsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List all of the configuration sets associated with your Amazon Pinpoint account in the current
 * region.
 *
 * In Amazon Pinpoint, *configuration sets* are groups of rules that you can
 * apply to the emails you send. You apply a configuration set to an email by including a
 * reference to the configuration set in the headers of the email. When you apply a
 * configuration set to an email, all of the rules in that configuration set are applied to
 * the email.
 */
export declare const listConfigurationSets: API.PaginatedOperationMethod<ListConfigurationSetsRequest & RegionInput, ListConfigurationSetsResponse, ListConfigurationSetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDedicatedIpPoolsError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * List all of the dedicated IP pools that exist in your Amazon Pinpoint account in the current
 * AWS Region.
 */
export declare const listDedicatedIpPools: API.PaginatedOperationMethod<ListDedicatedIpPoolsRequest & RegionInput, ListDedicatedIpPoolsResponse, ListDedicatedIpPoolsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDeliverabilityTestReportsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Show a list of the predictive inbox placement tests that you've performed, regardless of their statuses. For
 * predictive inbox placement tests that are complete, you can use the `GetDeliverabilityTestReport`
 * operation to view the results.
 */
export declare const listDeliverabilityTestReports: API.PaginatedOperationMethod<ListDeliverabilityTestReportsRequest & RegionInput, ListDeliverabilityTestReportsResponse, ListDeliverabilityTestReportsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDomainDeliverabilityCampaignsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve deliverability data for all the campaigns that used a specific domain to send
 * email during a specified time range. This data is available for a domain only if you
 * enabled the Deliverability dashboard (`PutDeliverabilityDashboardOption` operation)
 * for the domain.
 */
export declare const listDomainDeliverabilityCampaigns: API.PaginatedOperationMethod<ListDomainDeliverabilityCampaignsRequest & RegionInput, ListDomainDeliverabilityCampaignsResponse, ListDomainDeliverabilityCampaignsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListEmailIdentitiesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Returns a list of all of the email identities that are associated with your Amazon Pinpoint
 * account. An identity can be either an email address or a domain. This operation returns
 * identities that are verified as well as those that aren't.
 */
export declare const listEmailIdentities: API.PaginatedOperationMethod<ListEmailIdentitiesRequest & RegionInput, ListEmailIdentitiesResponse, ListEmailIdentitiesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Retrieve a list of the tags (keys and values) that are associated with a specified
 * resource. A *tag* is a label that you optionally define and associate
 * with a resource in Amazon Pinpoint. Each tag consists of a required tag
 * key and an optional associated *tag value*. A tag key
 * is a general label that acts as a category for more specific tag values. A tag value
 * acts as a descriptor within a tag key.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutAccountDedicatedIpWarmupAttributesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable the automatic warm-up feature for dedicated IP addresses.
 */
export declare const putAccountDedicatedIpWarmupAttributes: API.OperationMethod<PutAccountDedicatedIpWarmupAttributesRequest & RegionInput, PutAccountDedicatedIpWarmupAttributesResponse, PutAccountDedicatedIpWarmupAttributesError, Credentials | HttpClient.HttpClient>;
export type PutAccountSendingAttributesError = BadRequestException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable the ability of your account to send email.
 */
export declare const putAccountSendingAttributes: API.OperationMethod<PutAccountSendingAttributesRequest & RegionInput, PutAccountSendingAttributesResponse, PutAccountSendingAttributesError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetDeliveryOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Associate a configuration set with a dedicated IP pool. You can use dedicated IP pools
 * to create groups of dedicated IP addresses for sending specific types of email.
 */
export declare const putConfigurationSetDeliveryOptions: API.OperationMethod<PutConfigurationSetDeliveryOptionsRequest & RegionInput, PutConfigurationSetDeliveryOptionsResponse, PutConfigurationSetDeliveryOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetReputationOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable collection of reputation metrics for emails that you send using a
 * particular configuration set in a specific AWS Region.
 */
export declare const putConfigurationSetReputationOptions: API.OperationMethod<PutConfigurationSetReputationOptionsRequest & RegionInput, PutConfigurationSetReputationOptionsResponse, PutConfigurationSetReputationOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetSendingOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable email sending for messages that use a particular configuration set
 * in a specific AWS Region.
 */
export declare const putConfigurationSetSendingOptions: API.OperationMethod<PutConfigurationSetSendingOptionsRequest & RegionInput, PutConfigurationSetSendingOptionsResponse, PutConfigurationSetSendingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutConfigurationSetTrackingOptionsError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Specify a custom domain to use for open and click tracking elements in email that you
 * send using Amazon Pinpoint.
 */
export declare const putConfigurationSetTrackingOptions: API.OperationMethod<PutConfigurationSetTrackingOptionsRequest & RegionInput, PutConfigurationSetTrackingOptionsResponse, PutConfigurationSetTrackingOptionsError, Credentials | HttpClient.HttpClient>;
export type PutDedicatedIpInPoolError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Move a dedicated IP address to an existing dedicated IP pool.
 *
 * The dedicated IP address that you specify must already exist, and must be
 * associated with your Amazon Pinpoint account.
 *
 * The dedicated IP pool you specify must already exist. You can create a new pool by
 * using the `CreateDedicatedIpPool` operation.
 */
export declare const putDedicatedIpInPool: API.OperationMethod<PutDedicatedIpInPoolRequest & RegionInput, PutDedicatedIpInPoolResponse, PutDedicatedIpInPoolError, Credentials | HttpClient.HttpClient>;
export type PutDedicatedIpWarmupAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 *
 */
export declare const putDedicatedIpWarmupAttributes: API.OperationMethod<PutDedicatedIpWarmupAttributesRequest & RegionInput, PutDedicatedIpWarmupAttributesResponse, PutDedicatedIpWarmupAttributesError, Credentials | HttpClient.HttpClient>;
export type PutDeliverabilityDashboardOptionError = AlreadyExistsException | BadRequestException | LimitExceededException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Enable or disable the Deliverability dashboard for your Amazon Pinpoint account. When you enable the
 * Deliverability dashboard, you gain access to reputation, deliverability, and other metrics for
 * the domains that you use to send email using Amazon Pinpoint. You also gain the ability to perform
 * predictive inbox placement tests.
 *
 * When you use the Deliverability dashboard, you pay a monthly subscription charge, in addition
 * to any other fees that you accrue by using Amazon Pinpoint. For more information about the
 * features and cost of a Deliverability dashboard subscription, see Amazon Pinpoint Pricing.
 */
export declare const putDeliverabilityDashboardOption: API.OperationMethod<PutDeliverabilityDashboardOptionRequest & RegionInput, PutDeliverabilityDashboardOptionResponse, PutDeliverabilityDashboardOptionError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityDkimAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to enable or disable DKIM authentication for an email identity.
 */
export declare const putEmailIdentityDkimAttributes: API.OperationMethod<PutEmailIdentityDkimAttributesRequest & RegionInput, PutEmailIdentityDkimAttributesResponse, PutEmailIdentityDkimAttributesError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityFeedbackAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to enable or disable feedback forwarding for an identity. This setting determines
 * what happens when an identity is used to send an email that results in a bounce or
 * complaint event.
 *
 * When you enable feedback forwarding, Amazon Pinpoint sends you email notifications when bounce
 * or complaint events occur. Amazon Pinpoint sends this notification to the address that you
 * specified in the Return-Path header of the original email.
 *
 * When you disable feedback forwarding, Amazon Pinpoint sends notifications through other
 * mechanisms, such as by notifying an Amazon SNS topic. You're required to have a method of
 * tracking bounces and complaints. If you haven't set up another mechanism for receiving
 * bounce or complaint notifications, Amazon Pinpoint sends an email notification when these events
 * occur (even if this setting is disabled).
 */
export declare const putEmailIdentityFeedbackAttributes: API.OperationMethod<PutEmailIdentityFeedbackAttributesRequest & RegionInput, PutEmailIdentityFeedbackAttributesResponse, PutEmailIdentityFeedbackAttributesError, Credentials | HttpClient.HttpClient>;
export type PutEmailIdentityMailFromAttributesError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Used to enable or disable the custom Mail-From domain configuration for an email
 * identity.
 */
export declare const putEmailIdentityMailFromAttributes: API.OperationMethod<PutEmailIdentityMailFromAttributesRequest & RegionInput, PutEmailIdentityMailFromAttributesResponse, PutEmailIdentityMailFromAttributesError, Credentials | HttpClient.HttpClient>;
export type SendEmailError = AccountSuspendedException | BadRequestException | LimitExceededException | MailFromDomainNotVerifiedException | MessageRejected | NotFoundException | SendingPausedException | TooManyRequestsException | CommonErrors;
/**
 * Sends an email message. You can use the Amazon Pinpoint Email API to send two types of
 * messages:
 *
 * - **Simple** - A standard email message. When
 * you create this type of message, you specify the sender, the recipient, and the
 * message body, and Amazon Pinpoint assembles the message for you.
 *
 * - **Raw** - A raw, MIME-formatted email
 * message. When you send this type of email, you have to specify all of the
 * message headers, as well as the message body. You can use this message type to
 * send messages that contain attachments. The message that you specify has to be a
 * valid MIME message.
 */
export declare const sendEmail: API.OperationMethod<SendEmailRequest & RegionInput, SendEmailResponse, SendEmailError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Add one or more tags (keys and values) to a specified resource. A
 * *tag* is a label that you optionally define and associate with a
 * resource in Amazon Pinpoint. Tags can help you categorize and manage resources in different ways,
 * such as by purpose, owner, environment, or other criteria. A resource can have as many
 * as 50 tags.
 *
 * Each tag consists of a required *tag key* and an
 * associated *tag value*, both of which you define. A tag key is a
 * general label that acts as a category for more specific tag values. A tag value acts as
 * a descriptor within a tag key.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConcurrentModificationException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Remove one or more tags (keys and values) from a specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationSetEventDestinationError = BadRequestException | NotFoundException | TooManyRequestsException | CommonErrors;
/**
 * Update the configuration of an event destination for a configuration set.
 *
 * In Amazon Pinpoint, *events* include message sends, deliveries, opens,
 * clicks, bounces, and complaints. *Event destinations* are places that
 * you can send information about these events to. For example, you can send event data to
 * Amazon SNS to receive notifications when you receive bounces or complaints, or you can use
 * Amazon Kinesis Data Firehose to stream data to Amazon S3 for long-term storage.
 */
export declare const updateConfigurationSetEventDestination: API.OperationMethod<UpdateConfigurationSetEventDestinationRequest & RegionInput, UpdateConfigurationSetEventDestinationResponse, UpdateConfigurationSetEventDestinationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=pinpoint-email.d.ts.map