export * from "@distilled.cloud/s3/ErrorMessage";
//# sourceMappingURL=error-message.d.ts.map