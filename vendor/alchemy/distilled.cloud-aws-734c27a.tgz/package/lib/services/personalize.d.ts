import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyTagKeysException_base: S.TaggedErrorClass<"TooManyTagKeysException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagKeysException extends /*@__PURE__*/ TooManyTagKeysException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type Name = string;
export type Arn = string;
export type NumBatchResults = number;
export type S3Location = string;
export type KmsKeyArn = string;
export interface S3DataConfig {
    path: string;
    kmsKeyArn?: string | undefined;
}
export interface BatchInferenceJobInput {
    s3DataSource: S3DataConfig;
}
export interface BatchInferenceJobOutput {
    s3DataDestination: S3DataConfig;
}
export type RoleArn = string;
export type ParameterName = string;
export type ParameterValue = string;
export type HyperParameters = {
    [key: string]: string | undefined;
};
export type RankingInfluenceType = "POPULARITY" | "FRESHNESS" | (string & {});
export type RankingInfluenceWeight = number;
export type RankingInfluence = {
    [key in RankingInfluenceType]?: number | undefined;
};
export interface BatchInferenceJobConfig {
    itemExplorationConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    rankingInfluence?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    tagKey: string | redacted.Redacted<string>;
    tagValue: string | redacted.Redacted<string>;
}
export type Tags = Tag[];
export type BatchInferenceJobMode = "BATCH_INFERENCE" | "THEME_GENERATION" | (string & {});
export type ColumnName = string;
export interface FieldsForThemeGeneration {
    itemName: string;
}
export interface ThemeGenerationConfig {
    fieldsForThemeGeneration: FieldsForThemeGeneration;
}
export interface CreateBatchInferenceJobRequest {
    jobName: string;
    solutionVersionArn: string;
    filterArn?: string | undefined;
    numResults?: number | undefined;
    jobInput: BatchInferenceJobInput;
    jobOutput: BatchInferenceJobOutput;
    roleArn: string;
    batchInferenceJobConfig?: BatchInferenceJobConfig | undefined;
    tags?: Tag[] | undefined;
    batchInferenceJobMode?: BatchInferenceJobMode | undefined;
    themeGenerationConfig?: ThemeGenerationConfig | undefined;
}
export interface CreateBatchInferenceJobResponse {
    batchInferenceJobArn?: string | undefined;
}
export interface BatchSegmentJobInput {
    s3DataSource: S3DataConfig;
}
export interface BatchSegmentJobOutput {
    s3DataDestination: S3DataConfig;
}
export interface CreateBatchSegmentJobRequest {
    jobName: string;
    solutionVersionArn: string;
    filterArn?: string | undefined;
    numResults?: number | undefined;
    jobInput: BatchSegmentJobInput;
    jobOutput: BatchSegmentJobOutput;
    roleArn: string;
    tags?: Tag[] | undefined;
}
export interface CreateBatchSegmentJobResponse {
    batchSegmentJobArn?: string | undefined;
}
export type TransactionsPerSecond = number;
export interface CampaignConfig {
    itemExplorationConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    enableMetadataWithRecommendations?: boolean | undefined;
    syncWithLatestSolutionVersion?: boolean | undefined;
    rankingInfluence?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface CreateCampaignRequest {
    name: string;
    solutionVersionArn: string;
    minProvisionedTPS?: number | undefined;
    campaignConfig?: CampaignConfig | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateCampaignResponse {
    campaignArn?: string | undefined;
}
export interface DataSource {
    dataLocation?: string | undefined;
}
export interface CreateDataDeletionJobRequest {
    jobName: string;
    datasetGroupArn: string;
    dataSource: DataSource;
    roleArn: string;
    tags?: Tag[] | undefined;
}
export interface CreateDataDeletionJobResponse {
    dataDeletionJobArn?: string | undefined;
}
export type DatasetType = string;
export interface CreateDatasetRequest {
    name: string;
    schemaArn: string;
    datasetGroupArn: string;
    datasetType: string;
    tags?: Tag[] | undefined;
}
export interface CreateDatasetResponse {
    datasetArn?: string | undefined;
}
export type IngestionMode = "BULK" | "PUT" | "ALL" | (string & {});
export interface DatasetExportJobOutput {
    s3DataDestination: S3DataConfig;
}
export interface CreateDatasetExportJobRequest {
    jobName: string;
    datasetArn: string;
    ingestionMode?: IngestionMode | undefined;
    roleArn: string;
    jobOutput: DatasetExportJobOutput;
    tags?: Tag[] | undefined;
}
export interface CreateDatasetExportJobResponse {
    datasetExportJobArn?: string | undefined;
}
export type Domain = "ECOMMERCE" | "VIDEO_ON_DEMAND" | (string & {});
export interface CreateDatasetGroupRequest {
    name: string;
    roleArn?: string | undefined;
    kmsKeyArn?: string | undefined;
    domain?: Domain | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateDatasetGroupResponse {
    datasetGroupArn?: string | undefined;
    domain?: Domain | undefined;
}
export type ImportMode = "FULL" | "INCREMENTAL" | (string & {});
export interface CreateDatasetImportJobRequest {
    jobName: string;
    datasetArn: string;
    dataSource: DataSource;
    roleArn?: string | undefined;
    tags?: Tag[] | undefined;
    importMode?: ImportMode | undefined;
    publishAttributionMetricsToS3?: boolean | undefined;
}
export interface CreateDatasetImportJobResponse {
    datasetImportJobArn?: string | undefined;
}
export interface CreateEventTrackerRequest {
    name: string;
    datasetGroupArn: string;
    tags?: Tag[] | undefined;
}
export type TrackingId = string;
export interface CreateEventTrackerResponse {
    eventTrackerArn?: string | undefined;
    trackingId?: string | undefined;
}
export type FilterExpression = string | redacted.Redacted<string>;
export interface CreateFilterRequest {
    name: string;
    datasetGroupArn: string;
    filterExpression: string | redacted.Redacted<string>;
    tags?: Tag[] | undefined;
}
export interface CreateFilterResponse {
    filterArn?: string | undefined;
}
export type EventType = string;
export type MetricName = string;
export type MetricExpression = string;
export interface MetricAttribute {
    eventType: string;
    metricName: string;
    expression: string;
}
export type MetricAttributes = MetricAttribute[];
export interface MetricAttributionOutput {
    s3DataDestination?: S3DataConfig | undefined;
    roleArn: string;
}
export interface CreateMetricAttributionRequest {
    name: string;
    datasetGroupArn: string;
    metrics: MetricAttribute[];
    metricsOutputConfig: MetricAttributionOutput;
}
export interface CreateMetricAttributionResponse {
    metricAttributionArn?: string | undefined;
}
export type ColumnNamesList = string[];
export type ExcludedDatasetColumns = {
    [key: string]: string[] | undefined;
};
export type IncludedDatasetColumns = {
    [key: string]: string[] | undefined;
};
export interface TrainingDataConfig {
    excludedDatasetColumns?: {
        [key: string]: string[] | undefined;
    } | undefined;
    includedDatasetColumns?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface RecommenderConfig {
    itemExplorationConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    minRecommendationRequestsPerSecond?: number | undefined;
    trainingDataConfig?: TrainingDataConfig | undefined;
    enableMetadataWithRecommendations?: boolean | undefined;
}
export interface CreateRecommenderRequest {
    name: string;
    datasetGroupArn: string;
    recipeArn: string;
    recommenderConfig?: RecommenderConfig | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateRecommenderResponse {
    recommenderArn?: string | undefined;
}
export type AvroSchema = string;
export interface CreateSchemaRequest {
    name: string;
    schema: string;
    domain?: Domain | undefined;
}
export interface CreateSchemaResponse {
    schemaArn?: string | undefined;
}
export type PerformAutoML = boolean;
export type PerformAutoTraining = boolean;
export type PerformIncrementalUpdate = boolean;
export type EventValueThreshold = string;
export type HPOObjectiveType = string;
export type MetricRegex = string;
export interface HPOObjective {
    type?: string | undefined;
    metricName?: string | undefined;
    metricRegex?: string | undefined;
}
export type HPOResource = string;
export interface HPOResourceConfig {
    maxNumberOfTrainingJobs?: string | undefined;
    maxParallelTrainingJobs?: string | undefined;
}
export type IntegerMinValue = number;
export type IntegerMaxValue = number;
export interface IntegerHyperParameterRange {
    name?: string | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
}
export type IntegerHyperParameterRanges = IntegerHyperParameterRange[];
export type ContinuousMinValue = number;
export type ContinuousMaxValue = number;
export interface ContinuousHyperParameterRange {
    name?: string | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
}
export type ContinuousHyperParameterRanges = ContinuousHyperParameterRange[];
export type CategoricalValue = string;
export type CategoricalValues = string[];
export interface CategoricalHyperParameterRange {
    name?: string | undefined;
    values?: string[] | undefined;
}
export type CategoricalHyperParameterRanges = CategoricalHyperParameterRange[];
export interface HyperParameterRanges {
    integerHyperParameterRanges?: IntegerHyperParameterRange[] | undefined;
    continuousHyperParameterRanges?: ContinuousHyperParameterRange[] | undefined;
    categoricalHyperParameterRanges?: CategoricalHyperParameterRange[] | undefined;
}
export interface HPOConfig {
    hpoObjective?: HPOObjective | undefined;
    hpoResourceConfig?: HPOResourceConfig | undefined;
    algorithmHyperParameterRanges?: HyperParameterRanges | undefined;
}
export type FeatureTransformationParameters = {
    [key: string]: string | undefined;
};
export type ArnList = string[];
export interface AutoMLConfig {
    metricName?: string | undefined;
    recipeList?: string[] | undefined;
}
export type EventTypeThresholdValue = number;
export type EventTypeWeight = number;
export interface EventParameters {
    eventType?: string | undefined;
    eventValueThreshold?: number | undefined;
    weight?: number | undefined;
}
export type EventParametersList = EventParameters[];
export interface EventsConfig {
    eventParametersList?: EventParameters[] | undefined;
}
export type ItemAttribute = string;
export type ObjectiveSensitivity = "LOW" | "MEDIUM" | "HIGH" | "OFF" | (string & {});
export interface OptimizationObjective {
    itemAttribute?: string | undefined;
    objectiveSensitivity?: ObjectiveSensitivity | undefined;
}
export type SchedulingExpression = string;
export interface AutoTrainingConfig {
    schedulingExpression?: string | undefined;
}
export interface SolutionConfig {
    eventValueThreshold?: string | undefined;
    hpoConfig?: HPOConfig | undefined;
    algorithmHyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    featureTransformationParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    autoMLConfig?: AutoMLConfig | undefined;
    eventsConfig?: EventsConfig | undefined;
    optimizationObjective?: OptimizationObjective | undefined;
    trainingDataConfig?: TrainingDataConfig | undefined;
    autoTrainingConfig?: AutoTrainingConfig | undefined;
}
export interface CreateSolutionRequest {
    name: string;
    performHPO?: boolean | undefined;
    performAutoML?: boolean | undefined;
    performAutoTraining?: boolean | undefined;
    performIncrementalUpdate?: boolean | undefined;
    recipeArn?: string | undefined;
    datasetGroupArn: string;
    eventType?: string | undefined;
    solutionConfig?: SolutionConfig | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateSolutionResponse {
    solutionArn?: string | undefined;
}
export type TrainingMode = "FULL" | "UPDATE" | "AUTOTRAIN" | (string & {});
export interface CreateSolutionVersionRequest {
    name?: string | undefined;
    solutionArn: string;
    trainingMode?: TrainingMode | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateSolutionVersionResponse {
    solutionVersionArn?: string | undefined;
}
export interface DeleteCampaignRequest {
    campaignArn: string;
}
export interface DeleteCampaignResponse {
}
export interface DeleteDatasetRequest {
    datasetArn: string;
}
export interface DeleteDatasetResponse {
}
export interface DeleteDatasetGroupRequest {
    datasetGroupArn: string;
}
export interface DeleteDatasetGroupResponse {
}
export interface DeleteEventTrackerRequest {
    eventTrackerArn: string;
}
export interface DeleteEventTrackerResponse {
}
export interface DeleteFilterRequest {
    filterArn: string;
}
export interface DeleteFilterResponse {
}
export interface DeleteMetricAttributionRequest {
    metricAttributionArn: string;
}
export interface DeleteMetricAttributionResponse {
}
export interface DeleteRecommenderRequest {
    recommenderArn: string;
}
export interface DeleteRecommenderResponse {
}
export interface DeleteSchemaRequest {
    schemaArn: string;
}
export interface DeleteSchemaResponse {
}
export interface DeleteSolutionRequest {
    solutionArn: string;
}
export interface DeleteSolutionResponse {
}
export interface DescribeAlgorithmRequest {
    algorithmArn: string;
}
export type DockerURI = string;
export interface AlgorithmImage {
    name?: string | undefined;
    dockerURI: string;
}
export type Tunable = boolean;
export interface DefaultIntegerHyperParameterRange {
    name?: string | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
    isTunable?: boolean | undefined;
}
export type DefaultIntegerHyperParameterRanges = DefaultIntegerHyperParameterRange[];
export interface DefaultContinuousHyperParameterRange {
    name?: string | undefined;
    minValue?: number | undefined;
    maxValue?: number | undefined;
    isTunable?: boolean | undefined;
}
export type DefaultContinuousHyperParameterRanges = DefaultContinuousHyperParameterRange[];
export interface DefaultCategoricalHyperParameterRange {
    name?: string | undefined;
    values?: string[] | undefined;
    isTunable?: boolean | undefined;
}
export type DefaultCategoricalHyperParameterRanges = DefaultCategoricalHyperParameterRange[];
export interface DefaultHyperParameterRanges {
    integerHyperParameterRanges?: DefaultIntegerHyperParameterRange[] | undefined;
    continuousHyperParameterRanges?: DefaultContinuousHyperParameterRange[] | undefined;
    categoricalHyperParameterRanges?: DefaultCategoricalHyperParameterRange[] | undefined;
}
export type ResourceConfig = {
    [key: string]: string | undefined;
};
export type TrainingInputMode = string;
export interface Algorithm {
    name?: string | undefined;
    algorithmArn?: string | undefined;
    algorithmImage?: AlgorithmImage | undefined;
    defaultHyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    defaultHyperParameterRanges?: DefaultHyperParameterRanges | undefined;
    defaultResourceConfig?: {
        [key: string]: string | undefined;
    } | undefined;
    trainingInputMode?: string | undefined;
    roleArn?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeAlgorithmResponse {
    algorithm?: Algorithm | undefined;
}
export interface DescribeBatchInferenceJobRequest {
    batchInferenceJobArn: string;
}
export type FailureReason = string;
export type Status = string;
export interface BatchInferenceJob {
    jobName?: string | undefined;
    batchInferenceJobArn?: string | undefined;
    filterArn?: string | undefined;
    failureReason?: string | undefined;
    solutionVersionArn?: string | undefined;
    numResults?: number | undefined;
    jobInput?: BatchInferenceJobInput | undefined;
    jobOutput?: BatchInferenceJobOutput | undefined;
    batchInferenceJobConfig?: BatchInferenceJobConfig | undefined;
    roleArn?: string | undefined;
    batchInferenceJobMode?: BatchInferenceJobMode | undefined;
    themeGenerationConfig?: ThemeGenerationConfig | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeBatchInferenceJobResponse {
    batchInferenceJob?: BatchInferenceJob | undefined;
}
export interface DescribeBatchSegmentJobRequest {
    batchSegmentJobArn: string;
}
export interface BatchSegmentJob {
    jobName?: string | undefined;
    batchSegmentJobArn?: string | undefined;
    filterArn?: string | undefined;
    failureReason?: string | undefined;
    solutionVersionArn?: string | undefined;
    numResults?: number | undefined;
    jobInput?: BatchSegmentJobInput | undefined;
    jobOutput?: BatchSegmentJobOutput | undefined;
    roleArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeBatchSegmentJobResponse {
    batchSegmentJob?: BatchSegmentJob | undefined;
}
export interface DescribeCampaignRequest {
    campaignArn: string;
}
export interface CampaignUpdateSummary {
    solutionVersionArn?: string | undefined;
    minProvisionedTPS?: number | undefined;
    campaignConfig?: CampaignConfig | undefined;
    status?: string | undefined;
    failureReason?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface Campaign {
    name?: string | undefined;
    campaignArn?: string | undefined;
    solutionVersionArn?: string | undefined;
    minProvisionedTPS?: number | undefined;
    campaignConfig?: CampaignConfig | undefined;
    status?: string | undefined;
    failureReason?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    latestCampaignUpdate?: CampaignUpdateSummary | undefined;
}
export interface DescribeCampaignResponse {
    campaign?: Campaign | undefined;
}
export interface DescribeDataDeletionJobRequest {
    dataDeletionJobArn: string;
}
export interface DataDeletionJob {
    jobName?: string | undefined;
    dataDeletionJobArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    dataSource?: DataSource | undefined;
    roleArn?: string | undefined;
    status?: string | undefined;
    numDeleted?: number | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export interface DescribeDataDeletionJobResponse {
    dataDeletionJob?: DataDeletionJob | undefined;
}
export interface DescribeDatasetRequest {
    datasetArn: string;
}
export interface DatasetUpdateSummary {
    schemaArn?: string | undefined;
    status?: string | undefined;
    failureReason?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface Dataset {
    name?: string | undefined;
    datasetArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    datasetType?: string | undefined;
    schemaArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    latestDatasetUpdate?: DatasetUpdateSummary | undefined;
    trackingId?: string | undefined;
}
export interface DescribeDatasetResponse {
    dataset?: Dataset | undefined;
}
export interface DescribeDatasetExportJobRequest {
    datasetExportJobArn: string;
}
export interface DatasetExportJob {
    jobName?: string | undefined;
    datasetExportJobArn?: string | undefined;
    datasetArn?: string | undefined;
    ingestionMode?: IngestionMode | undefined;
    roleArn?: string | undefined;
    status?: string | undefined;
    jobOutput?: DatasetExportJobOutput | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export interface DescribeDatasetExportJobResponse {
    datasetExportJob?: DatasetExportJob | undefined;
}
export interface DescribeDatasetGroupRequest {
    datasetGroupArn: string;
}
export interface DatasetGroup {
    name?: string | undefined;
    datasetGroupArn?: string | undefined;
    status?: string | undefined;
    roleArn?: string | undefined;
    kmsKeyArn?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
    domain?: Domain | undefined;
}
export interface DescribeDatasetGroupResponse {
    datasetGroup?: DatasetGroup | undefined;
}
export interface DescribeDatasetImportJobRequest {
    datasetImportJobArn: string;
}
export interface DatasetImportJob {
    jobName?: string | undefined;
    datasetImportJobArn?: string | undefined;
    datasetArn?: string | undefined;
    dataSource?: DataSource | undefined;
    roleArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
    importMode?: ImportMode | undefined;
    publishAttributionMetricsToS3?: boolean | undefined;
}
export interface DescribeDatasetImportJobResponse {
    datasetImportJob?: DatasetImportJob | undefined;
}
export interface DescribeEventTrackerRequest {
    eventTrackerArn: string;
}
export type AccountId = string;
export interface EventTracker {
    name?: string | undefined;
    eventTrackerArn?: string | undefined;
    accountId?: string | undefined;
    trackingId?: string | undefined;
    datasetGroupArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeEventTrackerResponse {
    eventTracker?: EventTracker | undefined;
}
export interface DescribeFeatureTransformationRequest {
    featureTransformationArn: string;
}
export type FeaturizationParameters = {
    [key: string]: string | undefined;
};
export interface FeatureTransformation {
    name?: string | undefined;
    featureTransformationArn?: string | undefined;
    defaultParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    status?: string | undefined;
}
export interface DescribeFeatureTransformationResponse {
    featureTransformation?: FeatureTransformation | undefined;
}
export interface DescribeFilterRequest {
    filterArn: string;
}
export interface Filter {
    name?: string | undefined;
    filterArn?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    datasetGroupArn?: string | undefined;
    failureReason?: string | undefined;
    filterExpression?: string | redacted.Redacted<string> | undefined;
    status?: string | undefined;
}
export interface DescribeFilterResponse {
    filter?: Filter | undefined;
}
export interface DescribeMetricAttributionRequest {
    metricAttributionArn: string;
}
export interface MetricAttribution {
    name?: string | undefined;
    metricAttributionArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    metricsOutputConfig?: MetricAttributionOutput | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export interface DescribeMetricAttributionResponse {
    metricAttribution?: MetricAttribution | undefined;
}
export interface DescribeRecipeRequest {
    recipeArn: string;
}
export type Description = string;
export type RecipeType = string;
export interface Recipe {
    name?: string | undefined;
    recipeArn?: string | undefined;
    algorithmArn?: string | undefined;
    featureTransformationArn?: string | undefined;
    status?: string | undefined;
    description?: string | undefined;
    creationDateTime?: Date | undefined;
    recipeType?: string | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export interface DescribeRecipeResponse {
    recipe?: Recipe | undefined;
}
export interface DescribeRecommenderRequest {
    recommenderArn: string;
}
export interface RecommenderUpdateSummary {
    recommenderConfig?: RecommenderConfig | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    status?: string | undefined;
    failureReason?: string | undefined;
}
export type MetricValue = number;
export type Metrics = {
    [key: string]: number | undefined;
};
export interface Recommender {
    recommenderArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    name?: string | undefined;
    recipeArn?: string | undefined;
    recommenderConfig?: RecommenderConfig | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    status?: string | undefined;
    failureReason?: string | undefined;
    latestRecommenderUpdate?: RecommenderUpdateSummary | undefined;
    modelMetrics?: {
        [key: string]: number | undefined;
    } | undefined;
}
export interface DescribeRecommenderResponse {
    recommender?: Recommender | undefined;
}
export interface DescribeSchemaRequest {
    schemaArn: string;
}
export interface DatasetSchema {
    name?: string | undefined;
    schemaArn?: string | undefined;
    schema?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    domain?: Domain | undefined;
}
export interface DescribeSchemaResponse {
    schema?: DatasetSchema | undefined;
}
export interface DescribeSolutionRequest {
    solutionArn: string;
}
export type PerformHPO = boolean;
export interface AutoMLResult {
    bestRecipeArn?: string | undefined;
}
export type TrainingType = "AUTOMATIC" | "MANUAL" | (string & {});
export interface SolutionVersionSummary {
    solutionVersionArn?: string | undefined;
    status?: string | undefined;
    trainingMode?: TrainingMode | undefined;
    trainingType?: TrainingType | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export interface SolutionUpdateConfig {
    autoTrainingConfig?: AutoTrainingConfig | undefined;
    eventsConfig?: EventsConfig | undefined;
}
export interface SolutionUpdateSummary {
    solutionUpdateConfig?: SolutionUpdateConfig | undefined;
    status?: string | undefined;
    performAutoTraining?: boolean | undefined;
    performIncrementalUpdate?: boolean | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export interface Solution {
    name?: string | undefined;
    solutionArn?: string | undefined;
    performHPO?: boolean | undefined;
    performAutoML?: boolean | undefined;
    performAutoTraining?: boolean | undefined;
    performIncrementalUpdate?: boolean | undefined;
    recipeArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    eventType?: string | undefined;
    solutionConfig?: SolutionConfig | undefined;
    autoMLResult?: AutoMLResult | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    latestSolutionVersion?: SolutionVersionSummary | undefined;
    latestSolutionUpdate?: SolutionUpdateSummary | undefined;
}
export interface DescribeSolutionResponse {
    solution?: Solution | undefined;
}
export interface DescribeSolutionVersionRequest {
    solutionVersionArn: string;
}
export type TrainingHours = number;
export interface TunedHPOParams {
    algorithmHyperParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SolutionVersion {
    name?: string | undefined;
    solutionVersionArn?: string | undefined;
    solutionArn?: string | undefined;
    performHPO?: boolean | undefined;
    performAutoML?: boolean | undefined;
    performIncrementalUpdate?: boolean | undefined;
    recipeArn?: string | undefined;
    eventType?: string | undefined;
    datasetGroupArn?: string | undefined;
    solutionConfig?: SolutionConfig | undefined;
    trainingHours?: number | undefined;
    trainingMode?: TrainingMode | undefined;
    tunedHPOParams?: TunedHPOParams | undefined;
    status?: string | undefined;
    failureReason?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    trainingType?: TrainingType | undefined;
}
export interface DescribeSolutionVersionResponse {
    solutionVersion?: SolutionVersion | undefined;
}
export interface GetSolutionMetricsRequest {
    solutionVersionArn: string;
}
export interface GetSolutionMetricsResponse {
    solutionVersionArn?: string | undefined;
    metrics?: {
        [key: string]: number | undefined;
    } | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListBatchInferenceJobsRequest {
    solutionVersionArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BatchInferenceJobSummary {
    batchInferenceJobArn?: string | undefined;
    jobName?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
    solutionVersionArn?: string | undefined;
    batchInferenceJobMode?: BatchInferenceJobMode | undefined;
}
export type BatchInferenceJobs = BatchInferenceJobSummary[];
export interface ListBatchInferenceJobsResponse {
    batchInferenceJobs?: BatchInferenceJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListBatchSegmentJobsRequest {
    solutionVersionArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BatchSegmentJobSummary {
    batchSegmentJobArn?: string | undefined;
    jobName?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
    solutionVersionArn?: string | undefined;
}
export type BatchSegmentJobs = BatchSegmentJobSummary[];
export interface ListBatchSegmentJobsResponse {
    batchSegmentJobs?: BatchSegmentJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCampaignsRequest {
    solutionArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CampaignSummary {
    name?: string | undefined;
    campaignArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export type Campaigns = CampaignSummary[];
export interface ListCampaignsResponse {
    campaigns?: CampaignSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataDeletionJobsRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataDeletionJobSummary {
    dataDeletionJobArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    jobName?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export type DataDeletionJobs = DataDeletionJobSummary[];
export interface ListDataDeletionJobsResponse {
    dataDeletionJobs?: DataDeletionJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDatasetExportJobsRequest {
    datasetArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DatasetExportJobSummary {
    datasetExportJobArn?: string | undefined;
    jobName?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export type DatasetExportJobs = DatasetExportJobSummary[];
export interface ListDatasetExportJobsResponse {
    datasetExportJobs?: DatasetExportJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDatasetGroupsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DatasetGroupSummary {
    name?: string | undefined;
    datasetGroupArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
    domain?: Domain | undefined;
}
export type DatasetGroups = DatasetGroupSummary[];
export interface ListDatasetGroupsResponse {
    datasetGroups?: DatasetGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDatasetImportJobsRequest {
    datasetArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DatasetImportJobSummary {
    datasetImportJobArn?: string | undefined;
    jobName?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
    importMode?: ImportMode | undefined;
}
export type DatasetImportJobs = DatasetImportJobSummary[];
export interface ListDatasetImportJobsResponse {
    datasetImportJobs?: DatasetImportJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDatasetsRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DatasetSummary {
    name?: string | undefined;
    datasetArn?: string | undefined;
    datasetType?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type Datasets = DatasetSummary[];
export interface ListDatasetsResponse {
    datasets?: DatasetSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListEventTrackersRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface EventTrackerSummary {
    name?: string | undefined;
    eventTrackerArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type EventTrackers = EventTrackerSummary[];
export interface ListEventTrackersResponse {
    eventTrackers?: EventTrackerSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFiltersRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface FilterSummary {
    name?: string | undefined;
    filterArn?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    datasetGroupArn?: string | undefined;
    failureReason?: string | undefined;
    status?: string | undefined;
}
export type Filters = FilterSummary[];
export interface ListFiltersResponse {
    Filters?: FilterSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMetricAttributionMetricsRequest {
    metricAttributionArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListMetricAttributionMetricsResponse {
    metrics?: MetricAttribute[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMetricAttributionsRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface MetricAttributionSummary {
    name?: string | undefined;
    metricAttributionArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    failureReason?: string | undefined;
}
export type MetricAttributions = MetricAttributionSummary[];
export interface ListMetricAttributionsResponse {
    metricAttributions?: MetricAttributionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type RecipeProvider = "SERVICE" | (string & {});
export interface ListRecipesRequest {
    recipeProvider?: RecipeProvider | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    domain?: Domain | undefined;
}
export interface RecipeSummary {
    name?: string | undefined;
    recipeArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    domain?: Domain | undefined;
}
export type Recipes = RecipeSummary[];
export interface ListRecipesResponse {
    recipes?: RecipeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRecommendersRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface RecommenderSummary {
    name?: string | undefined;
    recommenderArn?: string | undefined;
    datasetGroupArn?: string | undefined;
    recipeArn?: string | undefined;
    recommenderConfig?: RecommenderConfig | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
}
export type Recommenders = RecommenderSummary[];
export interface ListRecommendersResponse {
    recommenders?: RecommenderSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSchemasRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DatasetSchemaSummary {
    name?: string | undefined;
    schemaArn?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    domain?: Domain | undefined;
}
export type Schemas = DatasetSchemaSummary[];
export interface ListSchemasResponse {
    schemas?: DatasetSchemaSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSolutionsRequest {
    datasetGroupArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SolutionSummary {
    name?: string | undefined;
    solutionArn?: string | undefined;
    status?: string | undefined;
    creationDateTime?: Date | undefined;
    lastUpdatedDateTime?: Date | undefined;
    recipeArn?: string | undefined;
}
export type Solutions = SolutionSummary[];
export interface ListSolutionsResponse {
    solutions?: SolutionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSolutionVersionsRequest {
    solutionArn?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SolutionVersions = SolutionVersionSummary[];
export interface ListSolutionVersionsResponse {
    solutionVersions?: SolutionVersionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface StartRecommenderRequest {
    recommenderArn: string;
}
export interface StartRecommenderResponse {
    recommenderArn?: string | undefined;
}
export interface StopRecommenderRequest {
    recommenderArn: string;
}
export interface StopRecommenderResponse {
    recommenderArn?: string | undefined;
}
export interface StopSolutionVersionCreationRequest {
    solutionVersionArn: string;
}
export interface StopSolutionVersionCreationResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateCampaignRequest {
    campaignArn: string;
    solutionVersionArn?: string | undefined;
    minProvisionedTPS?: number | undefined;
    campaignConfig?: CampaignConfig | undefined;
}
export interface UpdateCampaignResponse {
    campaignArn?: string | undefined;
}
export interface UpdateDatasetRequest {
    datasetArn: string;
    schemaArn: string;
}
export interface UpdateDatasetResponse {
    datasetArn?: string | undefined;
}
export type MetricAttributesNamesList = string[];
export interface UpdateMetricAttributionRequest {
    addMetrics?: MetricAttribute[] | undefined;
    removeMetrics?: string[] | undefined;
    metricsOutputConfig?: MetricAttributionOutput | undefined;
    metricAttributionArn?: string | undefined;
}
export interface UpdateMetricAttributionResponse {
    metricAttributionArn?: string | undefined;
}
export interface UpdateRecommenderRequest {
    recommenderArn: string;
    recommenderConfig: RecommenderConfig;
}
export interface UpdateRecommenderResponse {
    recommenderArn?: string | undefined;
}
export interface UpdateSolutionRequest {
    solutionArn: string;
    performAutoTraining?: boolean | undefined;
    performIncrementalUpdate?: boolean | undefined;
    solutionUpdateConfig?: SolutionUpdateConfig | undefined;
}
export interface UpdateSolutionResponse {
    solutionArn?: string | undefined;
}
export type ErrorMessage = string;
export type CreateBatchInferenceJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Generates batch recommendations based on a list of items or users stored in Amazon S3
 * and exports the recommendations to an Amazon S3 bucket.
 *
 * To generate batch recommendations, specify the ARN of a solution version and an Amazon S3 URI for the input and output data.
 * For user personalization, popular items, and personalized ranking solutions, the batch inference job generates a list of
 * recommended items for each user ID in the input file. For related items solutions, the job generates a list of recommended
 * items for each item ID in the input file.
 *
 * For more information, see Creating a batch inference job
 * .
 *
 * If you use the Similar-Items recipe, Amazon Personalize can add descriptive themes to batch recommendations.
 * To generate themes, set the job's mode to
 * `THEME_GENERATION` and specify the name of the field that contains item names in the
 * input data.
 *
 * For more information about generating themes, see Batch recommendations with themes from Content Generator
 * .
 *
 * You can't get batch recommendations with the Trending-Now or Next-Best-Action recipes.
 */
export declare const createBatchInferenceJob: API.OperationMethod<CreateBatchInferenceJobRequest & RegionInput, CreateBatchInferenceJobResponse, CreateBatchInferenceJobError, Credentials | HttpClient.HttpClient>;
export type CreateBatchSegmentJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates a batch segment job. The operation can handle up to 50 million records and the
 * input file must be in JSON format. For more information, see
 * Getting batch recommendations and user segments.
 */
export declare const createBatchSegmentJob: API.OperationMethod<CreateBatchSegmentJobRequest & RegionInput, CreateBatchSegmentJobResponse, CreateBatchSegmentJobError, Credentials | HttpClient.HttpClient>;
export type CreateCampaignError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * You incur campaign costs while it is active. To avoid unnecessary costs, make sure to delete the campaign when you are finished. For information about campaign
 * costs, see Amazon Personalize pricing.
 *
 * Creates a campaign that deploys a solution version. When a client calls the
 * GetRecommendations
 * and
 * GetPersonalizedRanking
 * APIs, a campaign is specified in the request.
 *
 * **Minimum Provisioned TPS and Auto-Scaling**
 *
 * A high `minProvisionedTPS` will increase your cost. We recommend starting with 1 for `minProvisionedTPS` (the default). Track
 * your usage using Amazon CloudWatch metrics, and increase the `minProvisionedTPS`
 * as necessary.
 *
 * When you create an Amazon Personalize campaign, you can specify the minimum provisioned transactions per second
 * (`minProvisionedTPS`) for the campaign. This is the baseline transaction throughput for the campaign provisioned by
 * Amazon Personalize. It sets the minimum billing charge for the campaign while it is active. A transaction is a single `GetRecommendations` or
 * `GetPersonalizedRanking` request. The default `minProvisionedTPS` is 1.
 *
 * If your TPS increases beyond the `minProvisionedTPS`, Amazon Personalize auto-scales the provisioned capacity up
 * and down, but never below `minProvisionedTPS`.
 * There's a short time delay while the capacity is increased
 * that might cause loss of transactions. When your traffic reduces, capacity returns to the `minProvisionedTPS`.
 *
 * You are charged for the
 * the minimum provisioned TPS or, if your requests exceed the `minProvisionedTPS`, the actual TPS.
 * The actual TPS is the total number of recommendation requests you make.
 * We recommend starting with a low `minProvisionedTPS`, track
 * your usage using Amazon CloudWatch metrics, and then increase the `minProvisionedTPS` as necessary.
 *
 * For more information about campaign costs, see Amazon Personalize pricing.
 *
 * **Status**
 *
 * A campaign can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * To get the campaign status, call DescribeCampaign.
 *
 * Wait until the `status` of the campaign
 * is `ACTIVE` before asking the campaign for recommendations.
 *
 * **Related APIs**
 *
 * - ListCampaigns
 *
 * - DescribeCampaign
 *
 * - UpdateCampaign
 *
 * - DeleteCampaign
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest & RegionInput, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type CreateDataDeletionJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates a batch job that deletes all
 * references to specific users from an Amazon Personalize dataset group in batches. You specify the users to delete in a CSV file of userIds in
 * an Amazon S3 bucket. After a job completes, Amazon Personalize no longer trains
 * on the users' data and no longer considers the users when generating user segments.
 * For more information about creating a data deletion job, see Deleting users.
 *
 * - Your input file must be a CSV file with a single USER_ID column that lists the users IDs. For more information
 * about preparing the CSV file, see Preparing your data deletion file and uploading it to Amazon S3.
 *
 * - To give Amazon Personalize permission to access your input CSV file of userIds, you must specify an IAM service role that has permission to
 * read from the data source. This role
 * needs `GetObject` and `ListBucket` permissions for the bucket and its content.
 * These permissions are the same as importing data. For information on granting access to your Amazon S3
 * bucket, see Giving
 * Amazon Personalize Access to Amazon S3 Resources.
 *
 * After you create a job, it can take up to a day to delete all references to the users from datasets and models. Until the job completes,
 * Amazon Personalize continues to use the data when training. And if you use a User Segmentation recipe, the users might appear in user segments.
 *
 * **Status**
 *
 * A data deletion job can have one of the following statuses:
 *
 * - PENDING > IN_PROGRESS > COMPLETED -or- FAILED
 *
 * To get the status of the data deletion job, call DescribeDataDeletionJob API operation and specify the Amazon Resource Name
 * (ARN) of the job. If the status is FAILED, the response
 * includes a `failureReason` key, which describes why the job
 * failed.
 *
 * **Related APIs**
 *
 * - ListDataDeletionJobs
 *
 * - DescribeDataDeletionJob
 */
export declare const createDataDeletionJob: API.OperationMethod<CreateDataDeletionJobRequest & RegionInput, CreateDataDeletionJobResponse, CreateDataDeletionJobError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates an empty dataset and adds it to the specified dataset group.
 * Use CreateDatasetImportJob to import your training data to a
 * dataset.
 *
 * There are 5 types of datasets:
 *
 * - Item interactions
 *
 * - Items
 *
 * - Users
 *
 * - Action interactions
 *
 * - Actions
 *
 * Each dataset type has an associated schema with required field types.
 * Only the `Item interactions` dataset is required in order to train a
 * model (also referred to as creating a solution).
 *
 * A dataset can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE
 * FAILED
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * To get the status of the dataset, call DescribeDataset.
 *
 * **Related APIs**
 *
 * - CreateDatasetGroup
 *
 * - ListDatasets
 *
 * - DescribeDataset
 *
 * - DeleteDataset
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest & RegionInput, CreateDatasetResponse, CreateDatasetError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetExportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates a job that exports data from your dataset to an Amazon S3 bucket.
 * To allow Amazon Personalize to export the training data, you must specify an
 * service-linked IAM role that gives Amazon Personalize `PutObject`
 * permissions for your Amazon S3 bucket. For information, see Exporting a dataset in the Amazon Personalize developer guide.
 *
 * **Status**
 *
 * A dataset export job can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE
 * FAILED
 *
 * To get the status of the export job, call DescribeDatasetExportJob, and specify the Amazon Resource Name
 * (ARN) of the dataset export job. The dataset export is complete when the
 * status shows as ACTIVE. If the status shows as CREATE FAILED, the response
 * includes a `failureReason` key, which describes why the job
 * failed.
 */
export declare const createDatasetExportJob: API.OperationMethod<CreateDatasetExportJobRequest & RegionInput, CreateDatasetExportJobResponse, CreateDatasetExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetGroupError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | TooManyTagsException | CommonErrors;
/**
 * Creates an empty dataset group. A dataset group is a container for
 * Amazon Personalize resources. A dataset group can contain at most three datasets, one
 * for each type of dataset:
 *
 * - Item interactions
 *
 * - Items
 *
 * - Users
 *
 * - Actions
 *
 * - Action interactions
 *
 * A dataset group can be a Domain dataset group, where you specify a
 * domain and use pre-configured resources like recommenders, or a
 * Custom dataset group, where you use custom resources, such as a solution
 * with a solution version, that you deploy with a campaign. If you start
 * with a Domain dataset group, you can still add custom resources such as
 * solutions and solution versions trained with recipes for custom use cases
 * and deployed with campaigns.
 *
 * A dataset group can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE
 * FAILED
 *
 * - DELETE PENDING
 *
 * To get the status of the dataset group, call DescribeDatasetGroup. If the status shows as CREATE FAILED, the
 * response includes a `failureReason` key, which describes why
 * the creation failed.
 *
 * You must wait until the `status` of the dataset group is
 * `ACTIVE` before adding a dataset to the group.
 *
 * You can specify an Key Management Service (KMS) key to encrypt the datasets in
 * the group. If you specify a KMS key, you must also include an Identity and Access Management
 * (IAM) role that has permission to access the key.
 *
 * **APIs that require a dataset group ARN in the request**
 *
 * - CreateDataset
 *
 * - CreateEventTracker
 *
 * - CreateSolution
 *
 * **Related APIs**
 *
 * - ListDatasetGroups
 *
 * - DescribeDatasetGroup
 *
 * - DeleteDatasetGroup
 */
export declare const createDatasetGroup: API.OperationMethod<CreateDatasetGroupRequest & RegionInput, CreateDatasetGroupResponse, CreateDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDatasetImportJobError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates a job that imports training data from your data source (an
 * Amazon S3 bucket) to an Amazon Personalize dataset. To allow Amazon Personalize to import the
 * training data, you must specify an IAM service role that has permission to
 * read from the data source, as Amazon Personalize makes a copy of your data and
 * processes it internally. For information on granting access to your Amazon S3
 * bucket, see Giving
 * Amazon Personalize Access to Amazon S3 Resources.
 *
 * If you already created a recommender or deployed a custom solution version with a campaign, how new bulk records
 * influence recommendations depends on the domain use case or recipe that you use. For more information, see How new data influences
 * real-time recommendations.
 *
 * By default, a dataset import job replaces any existing data in the
 * dataset that you imported in bulk. To add new records without replacing
 * existing data, specify INCREMENTAL for the import mode in the
 * CreateDatasetImportJob operation.
 *
 * **Status**
 *
 * A dataset import job can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE
 * FAILED
 *
 * To get the status of the import job, call DescribeDatasetImportJob, providing the Amazon Resource Name
 * (ARN) of the dataset import job. The dataset import is complete when the
 * status shows as ACTIVE. If the status shows as CREATE FAILED, the response
 * includes a `failureReason` key, which describes why the job
 * failed.
 *
 * Importing takes time. You must wait until the status shows as ACTIVE
 * before training a model using the dataset.
 *
 * **Related APIs**
 *
 * - ListDatasetImportJobs
 *
 * - DescribeDatasetImportJob
 */
export declare const createDatasetImportJob: API.OperationMethod<CreateDatasetImportJobRequest & RegionInput, CreateDatasetImportJobResponse, CreateDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type CreateEventTrackerError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates an event tracker that you use when adding event data to a specified dataset
 * group using the
 * PutEvents API.
 *
 * Only one event tracker can be associated with a dataset group. You will get
 * an error if you call `CreateEventTracker` using the same dataset group as an
 * existing event tracker.
 *
 * When you create an event tracker, the response includes a tracking ID, which you pass as a parameter when you use the
 * PutEvents operation.
 * Amazon Personalize then appends the event data to the Item interactions dataset of the dataset group you specify
 * in your event tracker.
 *
 * The event tracker can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * To get the status of the event tracker, call DescribeEventTracker.
 *
 * The event tracker must be in the ACTIVE state before using the tracking ID.
 *
 * **Related APIs**
 *
 * - ListEventTrackers
 *
 * - DescribeEventTracker
 *
 * - DeleteEventTracker
 */
export declare const createEventTracker: API.OperationMethod<CreateEventTrackerRequest & RegionInput, CreateEventTrackerResponse, CreateEventTrackerError, Credentials | HttpClient.HttpClient>;
export type CreateFilterError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates a recommendation filter. For more information, see Filtering recommendations and user segments.
 */
export declare const createFilter: API.OperationMethod<CreateFilterRequest & RegionInput, CreateFilterResponse, CreateFilterError, Credentials | HttpClient.HttpClient>;
export type CreateMetricAttributionError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a metric attribution.
 * A metric attribution creates reports on the data that you import into Amazon Personalize. Depending on how you imported the data, you can view reports in Amazon CloudWatch or Amazon S3.
 * For more information, see Measuring impact of recommendations.
 */
export declare const createMetricAttribution: API.OperationMethod<CreateMetricAttributionRequest & RegionInput, CreateMetricAttributionResponse, CreateMetricAttributionError, Credentials | HttpClient.HttpClient>;
export type CreateRecommenderError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Creates a recommender with the recipe (a Domain dataset group use case) you specify.
 * You create recommenders for a Domain dataset group and specify the recommender's Amazon Resource Name (ARN) when you make a
 * GetRecommendations
 * request.
 *
 * **Minimum recommendation requests per second**
 *
 * A high `minRecommendationRequestsPerSecond` will increase your bill. We recommend starting with 1 for `minRecommendationRequestsPerSecond` (the default). Track
 * your usage using Amazon CloudWatch metrics, and increase the `minRecommendationRequestsPerSecond`
 * as necessary.
 *
 * When you create a recommender, you can configure the recommender's minimum recommendation requests per second. The minimum recommendation requests per second
 * (`minRecommendationRequestsPerSecond`) specifies the baseline recommendation request throughput provisioned by
 * Amazon Personalize. The default minRecommendationRequestsPerSecond is `1`. A recommendation request is a single `GetRecommendations` operation.
 * Request throughput is measured in requests per second and Amazon Personalize uses your requests per second to derive
 * your requests per hour and the price of your recommender usage.
 *
 * If your requests per second increases beyond
 * `minRecommendationRequestsPerSecond`, Amazon Personalize auto-scales the provisioned capacity up and down,
 * but never below `minRecommendationRequestsPerSecond`.
 * There's a short time delay while the capacity is increased that might cause loss of
 * requests.
 *
 * Your bill is the greater of either the minimum requests per hour (based on minRecommendationRequestsPerSecond)
 * or the actual number of requests. The actual request throughput used is calculated as the average requests/second within a one-hour window.
 *
 * We recommend starting with the default `minRecommendationRequestsPerSecond`, track
 * your usage using Amazon CloudWatch metrics, and then increase the `minRecommendationRequestsPerSecond`
 * as necessary.
 *
 * **Status**
 *
 * A recommender can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * - STOP PENDING > STOP IN_PROGRESS > INACTIVE > START PENDING > START IN_PROGRESS > ACTIVE
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * To get the recommender status, call DescribeRecommender.
 *
 * Wait until the `status` of the recommender
 * is `ACTIVE` before asking the recommender for recommendations.
 *
 * **Related APIs**
 *
 * - ListRecommenders
 *
 * - DescribeRecommender
 *
 * - UpdateRecommender
 *
 * - DeleteRecommender
 */
export declare const createRecommender: API.OperationMethod<CreateRecommenderRequest & RegionInput, CreateRecommenderResponse, CreateRecommenderError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates an Amazon Personalize schema from the specified schema string. The schema you create
 * must be in Avro JSON format.
 *
 * Amazon Personalize recognizes three schema variants. Each schema is associated with a dataset
 * type and has a set of required field and keywords. If you are creating a schema for a dataset in a Domain dataset group, you
 * provide the domain of the Domain dataset group.
 * You specify a schema when you call CreateDataset.
 *
 * **Related APIs**
 *
 * - ListSchemas
 *
 * - DescribeSchema
 *
 * - DeleteSchema
 */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest & RegionInput, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type CreateSolutionError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * By default, all new solutions use automatic training. With automatic training, you incur training costs while
 * your solution is active. To avoid unnecessary costs, when you are finished you can
 * update the solution to turn off automatic training.
 * For information about training
 * costs, see Amazon Personalize pricing.
 *
 * Creates the configuration for training a model (creating a solution version). This configuration
 * includes the recipe to use for model training and optional training configuration, such as columns to use
 * in training and feature transformation parameters. For more information about configuring a solution, see Creating and configuring a solution.
 *
 * By default, new solutions use automatic training to create solution versions every 7 days. You can change the training frequency.
 * Automatic solution version creation starts within one hour after the solution is ACTIVE. If you manually create a solution version within
 * the hour, the solution skips the first automatic training. For more information,
 * see Configuring automatic training.
 *
 * To turn off automatic training, set `performAutoTraining` to false. If you turn off automatic training, you must manually create a solution version
 * by calling the CreateSolutionVersion operation.
 *
 * After training starts, you can
 * get the solution version's Amazon Resource Name (ARN) with the ListSolutionVersions API operation.
 * To get its status, use the DescribeSolutionVersion.
 *
 * After training completes you can evaluate model accuracy by calling
 * GetSolutionMetrics. When you are satisfied with the solution version, you
 * deploy it using CreateCampaign. The campaign provides recommendations
 * to a client through the
 * GetRecommendations API.
 *
 * Amazon Personalize doesn't support configuring the `hpoObjective`
 * for solution hyperparameter optimization at this time.
 *
 * **Status**
 *
 * A solution can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * To get the status of the solution, call DescribeSolution. If you use
 * manual training, the status must be ACTIVE before you call `CreateSolutionVersion`.
 *
 * **Related APIs**
 *
 * - UpdateSolution
 *
 * - ListSolutions
 *
 * - CreateSolutionVersion
 *
 * - DescribeSolution
 *
 * - DeleteSolution
 *
 * - ListSolutionVersions
 *
 * - DescribeSolutionVersion
 */
export declare const createSolution: API.OperationMethod<CreateSolutionRequest & RegionInput, CreateSolutionResponse, CreateSolutionError, Credentials | HttpClient.HttpClient>;
export type CreateSolutionVersionError = InvalidInputException | LimitExceededException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Trains or retrains an active solution in a Custom dataset group. A solution is created using the CreateSolution
 * operation and must be in the ACTIVE state before calling
 * `CreateSolutionVersion`. A new version of the solution is created every time you
 * call this operation.
 *
 * **Status**
 *
 * A solution version can be in one of the following states:
 *
 * - CREATE PENDING
 *
 * - CREATE IN_PROGRESS
 *
 * - ACTIVE
 *
 * - CREATE FAILED
 *
 * - CREATE STOPPING
 *
 * - CREATE STOPPED
 *
 * To get the status of the version, call DescribeSolutionVersion. Wait
 * until the status shows as ACTIVE before calling `CreateCampaign`.
 *
 * If the status shows as CREATE FAILED, the response includes a `failureReason`
 * key, which describes why the job failed.
 *
 * **Related APIs**
 *
 * - ListSolutionVersions
 *
 * - DescribeSolutionVersion
 *
 * - ListSolutions
 *
 * - CreateSolution
 *
 * - DescribeSolution
 *
 * - DeleteSolution
 */
export declare const createSolutionVersion: API.OperationMethod<CreateSolutionVersionRequest & RegionInput, CreateSolutionVersionResponse, CreateSolutionVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Removes a campaign by deleting the solution deployment. The solution that
 * the campaign is based on is not deleted and can be redeployed when needed. A deleted campaign can no
 * longer be specified in a
 * GetRecommendations
 * request.
 * For information on creating campaigns, see CreateCampaign.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest & RegionInput, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataset. You can't delete a dataset if an associated
 * `DatasetImportJob` or `SolutionVersion` is in the
 * CREATE PENDING or IN PROGRESS state. For more information about deleting datasets,
 * see Deleting a dataset.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest & RegionInput, DeleteDatasetResponse, DeleteDatasetError, Credentials | HttpClient.HttpClient>;
export type DeleteDatasetGroupError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a dataset group. Before you delete a dataset group, you must
 * delete the following:
 *
 * - All associated event trackers.
 *
 * - All associated solutions.
 *
 * - All datasets in the dataset group.
 */
export declare const deleteDatasetGroup: API.OperationMethod<DeleteDatasetGroupRequest & RegionInput, DeleteDatasetGroupResponse, DeleteDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEventTrackerError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the event tracker. Does not delete the dataset from
 * the dataset group. For more
 * information on event trackers, see CreateEventTracker.
 */
export declare const deleteEventTracker: API.OperationMethod<DeleteEventTrackerRequest & RegionInput, DeleteEventTrackerResponse, DeleteEventTrackerError, Credentials | HttpClient.HttpClient>;
export type DeleteFilterError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a filter.
 */
export declare const deleteFilter: API.OperationMethod<DeleteFilterRequest & RegionInput, DeleteFilterResponse, DeleteFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteMetricAttributionError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a metric attribution.
 */
export declare const deleteMetricAttribution: API.OperationMethod<DeleteMetricAttributionRequest & RegionInput, DeleteMetricAttributionResponse, DeleteMetricAttributionError, Credentials | HttpClient.HttpClient>;
export type DeleteRecommenderError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deactivates and removes a recommender. A deleted recommender can no longer be specified in a GetRecommendations
 * request.
 */
export declare const deleteRecommender: API.OperationMethod<DeleteRecommenderRequest & RegionInput, DeleteRecommenderResponse, DeleteRecommenderError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a schema. Before deleting a schema, you must delete all
 * datasets referencing the schema. For more information on schemas, see
 * CreateSchema.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest & RegionInput, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteSolutionError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes all versions of a solution and the `Solution` object itself.
 * Before deleting a solution, you must delete all campaigns based on
 * the solution. To determine what campaigns are using the solution, call
 * ListCampaigns and supply the Amazon Resource Name (ARN) of the solution.
 * You can't delete a solution if an associated `SolutionVersion` is in the
 * CREATE PENDING or IN PROGRESS state.
 * For more information on solutions, see CreateSolution.
 */
export declare const deleteSolution: API.OperationMethod<DeleteSolutionRequest & RegionInput, DeleteSolutionResponse, DeleteSolutionError, Credentials | HttpClient.HttpClient>;
export type DescribeAlgorithmError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the given algorithm.
 */
export declare const describeAlgorithm: API.OperationMethod<DescribeAlgorithmRequest & RegionInput, DescribeAlgorithmResponse, DescribeAlgorithmError, Credentials | HttpClient.HttpClient>;
export type DescribeBatchInferenceJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the properties of a batch inference job including name, Amazon Resource Name (ARN),
 * status, input and output configurations, and the ARN of the solution version used to generate
 * the recommendations.
 */
export declare const describeBatchInferenceJob: API.OperationMethod<DescribeBatchInferenceJobRequest & RegionInput, DescribeBatchInferenceJobResponse, DescribeBatchInferenceJobError, Credentials | HttpClient.HttpClient>;
export type DescribeBatchSegmentJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the properties of a batch segment job including name, Amazon Resource Name (ARN),
 * status, input and output configurations, and the ARN of the solution version used to generate
 * segments.
 */
export declare const describeBatchSegmentJob: API.OperationMethod<DescribeBatchSegmentJobRequest & RegionInput, DescribeBatchSegmentJobResponse, DescribeBatchSegmentJobError, Credentials | HttpClient.HttpClient>;
export type DescribeCampaignError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the given campaign, including its status.
 *
 * A campaign can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * When the `status` is `CREATE FAILED`, the response includes the
 * `failureReason` key, which describes why.
 *
 * For more information on campaigns, see CreateCampaign.
 */
export declare const describeCampaign: API.OperationMethod<DescribeCampaignRequest & RegionInput, DescribeCampaignResponse, DescribeCampaignError, Credentials | HttpClient.HttpClient>;
export type DescribeDataDeletionJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the data deletion job created by CreateDataDeletionJob, including the job status.
 */
export declare const describeDataDeletionJob: API.OperationMethod<DescribeDataDeletionJobRequest & RegionInput, DescribeDataDeletionJobResponse, DescribeDataDeletionJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the given dataset. For more information on datasets, see
 * CreateDataset.
 */
export declare const describeDataset: API.OperationMethod<DescribeDatasetRequest & RegionInput, DescribeDatasetResponse, DescribeDatasetError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetExportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the dataset export job created by CreateDatasetExportJob, including the export job status.
 */
export declare const describeDatasetExportJob: API.OperationMethod<DescribeDatasetExportJobRequest & RegionInput, DescribeDatasetExportJobResponse, DescribeDatasetExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetGroupError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the given dataset group. For more information on dataset
 * groups, see CreateDatasetGroup.
 */
export declare const describeDatasetGroup: API.OperationMethod<DescribeDatasetGroupRequest & RegionInput, DescribeDatasetGroupResponse, DescribeDatasetGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeDatasetImportJobError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the dataset import job created by CreateDatasetImportJob, including the import job status.
 */
export declare const describeDatasetImportJob: API.OperationMethod<DescribeDatasetImportJobRequest & RegionInput, DescribeDatasetImportJobResponse, DescribeDatasetImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeEventTrackerError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes an event tracker. The response includes the `trackingId` and
 * `status` of the event tracker.
 * For more information on event trackers, see CreateEventTracker.
 */
export declare const describeEventTracker: API.OperationMethod<DescribeEventTrackerRequest & RegionInput, DescribeEventTrackerResponse, DescribeEventTrackerError, Credentials | HttpClient.HttpClient>;
export type DescribeFeatureTransformationError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the given feature transformation.
 */
export declare const describeFeatureTransformation: API.OperationMethod<DescribeFeatureTransformationRequest & RegionInput, DescribeFeatureTransformationResponse, DescribeFeatureTransformationError, Credentials | HttpClient.HttpClient>;
export type DescribeFilterError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a filter's properties.
 */
export declare const describeFilter: API.OperationMethod<DescribeFilterRequest & RegionInput, DescribeFilterResponse, DescribeFilterError, Credentials | HttpClient.HttpClient>;
export type DescribeMetricAttributionError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a metric attribution.
 */
export declare const describeMetricAttribution: API.OperationMethod<DescribeMetricAttributionRequest & RegionInput, DescribeMetricAttributionResponse, DescribeMetricAttributionError, Credentials | HttpClient.HttpClient>;
export type DescribeRecipeError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a recipe.
 *
 * A recipe contains three items:
 *
 * - An algorithm that trains a model.
 *
 * - Hyperparameters that govern the training.
 *
 * - Feature transformation information for modifying the input data before training.
 *
 * Amazon Personalize provides a set of predefined recipes. You specify a recipe when you create a
 * solution with the CreateSolution API.
 * `CreateSolution` trains a model by using the algorithm
 * in the specified recipe and a training dataset. The solution, when deployed as a campaign,
 * can provide recommendations using the
 * GetRecommendations API.
 */
export declare const describeRecipe: API.OperationMethod<DescribeRecipeRequest & RegionInput, DescribeRecipeResponse, DescribeRecipeError, Credentials | HttpClient.HttpClient>;
export type DescribeRecommenderError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the given recommender, including its status.
 *
 * A recommender can be in one of the following states:
 *
 * - CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * - STOP PENDING > STOP IN_PROGRESS > INACTIVE > START PENDING > START IN_PROGRESS > ACTIVE
 *
 * - DELETE PENDING > DELETE IN_PROGRESS
 *
 * When the `status` is `CREATE FAILED`, the response includes the
 * `failureReason` key, which describes why.
 *
 * The `modelMetrics` key is null when
 * the recommender is being created or deleted.
 *
 * For more information on recommenders, see CreateRecommender.
 */
export declare const describeRecommender: API.OperationMethod<DescribeRecommenderRequest & RegionInput, DescribeRecommenderResponse, DescribeRecommenderError, Credentials | HttpClient.HttpClient>;
export type DescribeSchemaError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a schema. For more information on schemas, see
 * CreateSchema.
 */
export declare const describeSchema: API.OperationMethod<DescribeSchemaRequest & RegionInput, DescribeSchemaResponse, DescribeSchemaError, Credentials | HttpClient.HttpClient>;
export type DescribeSolutionError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a solution.
 * For more information on solutions, see CreateSolution.
 */
export declare const describeSolution: API.OperationMethod<DescribeSolutionRequest & RegionInput, DescribeSolutionResponse, DescribeSolutionError, Credentials | HttpClient.HttpClient>;
export type DescribeSolutionVersionError = InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Describes a specific version of a solution. For more information on solutions, see CreateSolution
 */
export declare const describeSolutionVersion: API.OperationMethod<DescribeSolutionVersionRequest & RegionInput, DescribeSolutionVersionResponse, DescribeSolutionVersionError, Credentials | HttpClient.HttpClient>;
export type GetSolutionMetricsError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the metrics for the specified solution version.
 */
export declare const getSolutionMetrics: API.OperationMethod<GetSolutionMetricsRequest & RegionInput, GetSolutionMetricsResponse, GetSolutionMetricsError, Credentials | HttpClient.HttpClient>;
export type ListBatchInferenceJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Gets a list of the batch inference jobs that have been performed off of a solution
 * version.
 */
export declare const listBatchInferenceJobs: API.PaginatedOperationMethod<ListBatchInferenceJobsRequest & RegionInput, ListBatchInferenceJobsResponse, ListBatchInferenceJobsError, Credentials | HttpClient.HttpClient, BatchInferenceJobSummary>;
export type ListBatchSegmentJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Gets a list of the batch segment jobs that have been performed off of a solution
 * version that you specify.
 */
export declare const listBatchSegmentJobs: API.PaginatedOperationMethod<ListBatchSegmentJobsRequest & RegionInput, ListBatchSegmentJobsResponse, ListBatchSegmentJobsError, Credentials | HttpClient.HttpClient, BatchSegmentJobSummary>;
export type ListCampaignsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of campaigns that use the given solution.
 * When a solution is not specified, all the campaigns associated with the account are listed.
 * The response provides the properties for each campaign, including the Amazon Resource Name (ARN).
 * For more information on campaigns, see CreateCampaign.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest & RegionInput, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListDataDeletionJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of data deletion jobs for a dataset group ordered by creation time,
 * with the most recent first.
 * When
 * a dataset group is not specified, all the data deletion jobs associated with
 * the account are listed. The response provides the properties for each
 * job, including the Amazon Resource Name (ARN). For more
 * information on data deletion jobs, see Deleting users.
 */
export declare const listDataDeletionJobs: API.OperationMethod<ListDataDeletionJobsRequest & RegionInput, ListDataDeletionJobsResponse, ListDataDeletionJobsError, Credentials | HttpClient.HttpClient>;
export type ListDatasetExportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset export jobs that use the given dataset. When
 * a dataset is not specified, all the dataset export jobs associated with
 * the account are listed. The response provides the properties for each
 * dataset export job, including the Amazon Resource Name (ARN). For more
 * information on dataset export jobs, see CreateDatasetExportJob. For more information on datasets, see
 * CreateDataset.
 */
export declare const listDatasetExportJobs: API.PaginatedOperationMethod<ListDatasetExportJobsRequest & RegionInput, ListDatasetExportJobsResponse, ListDatasetExportJobsError, Credentials | HttpClient.HttpClient, DatasetExportJobSummary>;
export type ListDatasetGroupsError = InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset groups. The response provides the properties
 * for each dataset group, including the Amazon Resource Name (ARN). For more
 * information on dataset groups, see CreateDatasetGroup.
 */
export declare const listDatasetGroups: API.PaginatedOperationMethod<ListDatasetGroupsRequest & RegionInput, ListDatasetGroupsResponse, ListDatasetGroupsError, Credentials | HttpClient.HttpClient, DatasetGroupSummary>;
export type ListDatasetImportJobsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of dataset import jobs that use the given dataset. When
 * a dataset is not specified, all the dataset import jobs associated with
 * the account are listed. The response provides the properties for each
 * dataset import job, including the Amazon Resource Name (ARN). For more
 * information on dataset import jobs, see CreateDatasetImportJob. For more information on datasets, see
 * CreateDataset.
 */
export declare const listDatasetImportJobs: API.PaginatedOperationMethod<ListDatasetImportJobsRequest & RegionInput, ListDatasetImportJobsResponse, ListDatasetImportJobsError, Credentials | HttpClient.HttpClient, DatasetImportJobSummary>;
export type ListDatasetsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns the list of datasets contained in the given dataset group. The
 * response provides the properties for each dataset, including the Amazon
 * Resource Name (ARN). For more information on datasets, see CreateDataset.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest & RegionInput, ListDatasetsResponse, ListDatasetsError, Credentials | HttpClient.HttpClient, DatasetSummary>;
export type ListEventTrackersError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns the list of event trackers associated with the account.
 * The response provides the properties for each event tracker, including the Amazon Resource
 * Name (ARN) and tracking ID. For more
 * information on event trackers, see CreateEventTracker.
 */
export declare const listEventTrackers: API.PaginatedOperationMethod<ListEventTrackersRequest & RegionInput, ListEventTrackersResponse, ListEventTrackersError, Credentials | HttpClient.HttpClient, EventTrackerSummary>;
export type ListFiltersError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Lists all filters that belong to a given dataset group.
 */
export declare const listFilters: API.PaginatedOperationMethod<ListFiltersRequest & RegionInput, ListFiltersResponse, ListFiltersError, Credentials | HttpClient.HttpClient, FilterSummary>;
export type ListMetricAttributionMetricsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Lists the metrics for the metric attribution.
 */
export declare const listMetricAttributionMetrics: API.PaginatedOperationMethod<ListMetricAttributionMetricsRequest & RegionInput, ListMetricAttributionMetricsResponse, ListMetricAttributionMetricsError, Credentials | HttpClient.HttpClient, MetricAttribute>;
export type ListMetricAttributionsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Lists metric attributions.
 */
export declare const listMetricAttributions: API.PaginatedOperationMethod<ListMetricAttributionsRequest & RegionInput, ListMetricAttributionsResponse, ListMetricAttributionsError, Credentials | HttpClient.HttpClient, MetricAttributionSummary>;
export type ListRecipesError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of available recipes. The response provides the properties
 * for each recipe, including the recipe's Amazon Resource Name (ARN).
 */
export declare const listRecipes: API.PaginatedOperationMethod<ListRecipesRequest & RegionInput, ListRecipesResponse, ListRecipesError, Credentials | HttpClient.HttpClient, RecipeSummary>;
export type ListRecommendersError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of recommenders in a given Domain dataset group.
 * When a Domain dataset group is not specified, all the recommenders associated with the account are listed.
 * The response provides the properties for each recommender, including the Amazon Resource Name (ARN).
 * For more information on recommenders, see CreateRecommender.
 */
export declare const listRecommenders: API.PaginatedOperationMethod<ListRecommendersRequest & RegionInput, ListRecommendersResponse, ListRecommendersError, Credentials | HttpClient.HttpClient, RecommenderSummary>;
export type ListSchemasError = InvalidNextTokenException | CommonErrors;
/**
 * Returns the list of schemas associated with the account. The response provides the
 * properties for each schema, including the Amazon Resource Name (ARN).
 * For more information on schemas, see CreateSchema.
 */
export declare const listSchemas: API.PaginatedOperationMethod<ListSchemasRequest & RegionInput, ListSchemasResponse, ListSchemasError, Credentials | HttpClient.HttpClient, DatasetSchemaSummary>;
export type ListSolutionsError = InvalidInputException | InvalidNextTokenException | CommonErrors;
/**
 * Returns a list of solutions in a given dataset group.
 * When a dataset group is not specified, all the solutions associated with the account are listed.
 * The response provides the properties for each solution, including the Amazon Resource Name (ARN).
 * For more information on solutions, see CreateSolution.
 */
export declare const listSolutions: API.PaginatedOperationMethod<ListSolutionsRequest & RegionInput, ListSolutionsResponse, ListSolutionsError, Credentials | HttpClient.HttpClient, SolutionSummary>;
export type ListSolutionVersionsError = InvalidInputException | InvalidNextTokenException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of solution versions for the given solution. When a solution is not
 * specified, all the solution versions associated with the account are listed. The response
 * provides the properties for each solution version, including the Amazon Resource Name (ARN).
 */
export declare const listSolutionVersions: API.PaginatedOperationMethod<ListSolutionVersionsRequest & RegionInput, ListSolutionVersionsResponse, ListSolutionVersionsError, Credentials | HttpClient.HttpClient, SolutionVersionSummary>;
export type ListTagsForResourceError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Get a list of tags attached to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartRecommenderError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Starts a recommender that is INACTIVE. Starting a recommender does not
 * create any new models, but resumes billing and automatic retraining for the recommender.
 */
export declare const startRecommender: API.OperationMethod<StartRecommenderRequest & RegionInput, StartRecommenderResponse, StartRecommenderError, Credentials | HttpClient.HttpClient>;
export type StopRecommenderError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Stops a recommender that is ACTIVE. Stopping a recommender halts billing and automatic retraining for the recommender.
 */
export declare const stopRecommender: API.OperationMethod<StopRecommenderRequest & RegionInput, StopRecommenderResponse, StopRecommenderError, Credentials | HttpClient.HttpClient>;
export type StopSolutionVersionCreationError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Stops creating a solution version that is in a state of CREATE_PENDING or CREATE IN_PROGRESS.
 *
 * Depending on the current state of the solution version, the solution version state changes as follows:
 *
 * - CREATE_PENDING > CREATE_STOPPED
 *
 * or
 *
 * - CREATE_IN_PROGRESS > CREATE_STOPPING > CREATE_STOPPED
 *
 * You are billed for all of the training completed up
 * until you stop the solution version creation. You cannot resume creating a solution version once it has been stopped.
 */
export declare const stopSolutionVersionCreation: API.OperationMethod<StopSolutionVersionCreationRequest & RegionInput, StopSolutionVersionCreationResponse, StopSolutionVersionCreationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidInputException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Add a list of tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | TooManyTagKeysException | CommonErrors;
/**
 * Removes the specified tags that are attached to a resource. For more information, see Removing tags from Amazon Personalize resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a campaign to deploy a retrained solution version with an existing campaign, change your campaign's `minProvisionedTPS`,
 * or modify your campaign's configuration. For example, you can set `enableMetadataWithRecommendations` to true for an existing campaign.
 *
 * To update a campaign to start automatically using the latest solution version, specify the following:
 *
 * - For the `SolutionVersionArn` parameter, specify the Amazon Resource Name (ARN) of your solution in
 * `SolutionArn/$LATEST` format.
 *
 * - In the `campaignConfig`, set `syncWithLatestSolutionVersion` to `true`.
 *
 * To update a campaign, the campaign status must be ACTIVE or CREATE FAILED.
 * Check the campaign status using the DescribeCampaign operation.
 *
 * You can still get recommendations from a campaign while an update is in progress.
 * The campaign will use the previous solution version and campaign configuration to generate recommendations until the latest campaign update status is `Active`.
 *
 * For more information about updating a campaign, including code samples, see Updating a campaign.
 * For more information about campaigns, see Creating a campaign.
 */
export declare const updateCampaign: API.OperationMethod<UpdateCampaignRequest & RegionInput, UpdateCampaignResponse, UpdateCampaignError, Credentials | HttpClient.HttpClient>;
export type UpdateDatasetError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Update a dataset to replace its schema with a new or existing one. For more information, see Replacing a dataset's schema.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest & RegionInput, UpdateDatasetResponse, UpdateDatasetError, Credentials | HttpClient.HttpClient>;
export type UpdateMetricAttributionError = InvalidInputException | ResourceAlreadyExistsException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a metric attribution.
 */
export declare const updateMetricAttribution: API.OperationMethod<UpdateMetricAttributionRequest & RegionInput, UpdateMetricAttributionResponse, UpdateMetricAttributionError, Credentials | HttpClient.HttpClient>;
export type UpdateRecommenderError = InvalidInputException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the recommender to modify the recommender configuration.
 * If you update the recommender to modify the columns used in training, Amazon Personalize automatically starts a full retraining of
 * the models backing your recommender. While the update completes, you can still get recommendations from the recommender. The recommender
 * uses the previous configuration until the update completes.
 * To track the status of this update,
 * use the `latestRecommenderUpdate` returned in the DescribeRecommender
 * operation.
 */
export declare const updateRecommender: API.OperationMethod<UpdateRecommenderRequest & RegionInput, UpdateRecommenderResponse, UpdateRecommenderError, Credentials | HttpClient.HttpClient>;
export type UpdateSolutionError = InvalidInputException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an Amazon Personalize solution to use a different automatic training configuration. When you update a solution,
 * you can change whether the solution uses
 * automatic training, and you can change the training frequency. For more information about updating a solution, see
 * Updating a solution.
 *
 * A solution update can be in one of the
 * following states:
 *
 * CREATE PENDING > CREATE IN_PROGRESS > ACTIVE -or- CREATE FAILED
 *
 * To get the status of a solution update, call the
 * DescribeSolution API operation and find the status
 * in the `latestSolutionUpdate`.
 */
export declare const updateSolution: API.OperationMethod<UpdateSolutionRequest & RegionInput, UpdateSolutionResponse, UpdateSolutionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=personalize.d.ts.map