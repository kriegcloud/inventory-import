/**
 * INTERNAL — deterministic identity for a Docker build: context + Dockerfile
 * + platform + build args, with Docker's own semantics (`.dockerignore`
 * pattern matching, symlink targets, permission bits, empty directories).
 * Cloud-agnostic — consumed by `AWS.ECR.Image` and `AWS.Lambda.Function`
 * image packaging; NOT exported from the Docker barrel.
 */
import { type IgnoreRules } from "alchemy/Util/Ignore";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
declare const BuildHashInvalidProps_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "BuildHashInvalidProps";
} & Readonly<A>;
export declare class BuildHashInvalidProps extends BuildHashInvalidProps_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export interface DockerBuildSource {
    context: string;
    dockerfile: string;
    platform: string;
    buildArgs?: Record<string, string>;
}
export type DockerBuildHashMode = "all" | "effective";
/**
 * Resolve and validate a Docker build context and Dockerfile.
 *
 * Dockerfile paths are relative to the build context unless absolute.
 */
export declare const resolveDockerBuildPaths: (source: Pick<DockerBuildSource, "context" | "dockerfile">) => Effect.Effect<{
    context: string;
    dockerfile: string;
}, BuildHashInvalidProps | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
/**
 * Select the effective files sent for a Docker build.
 *
 * Dockerfile-specific ignore files take precedence over `.dockerignore`.
 * The Dockerfile and selected ignore file stay in the upload even when an
 * ignore rule matches them, as Docker clients must send both to the builder.
 */
export declare const selectDockerBuildContext: (source: Pick<DockerBuildSource, "context" | "dockerfile">) => Effect.Effect<{
    context: string;
    dockerfile: string;
    dockerfilePath: string | undefined;
    includes: (relativePath: string) => boolean;
    rules: IgnoreRules | undefined;
    force: string[];
}, BuildHashInvalidProps | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
/**
 * Hash a Docker build context together with the Dockerfile, platform, and
 * build arguments. In `effective` mode, the selected `.dockerignore` is
 * applied exactly once before files are hashed. Absolute paths do not
 * participate.
 */
export declare const hashDockerBuildInputs: (source: DockerBuildSource, mode: DockerBuildHashMode, options?: {
    /**
     * Directory names left out of the hash at any depth, on top of
     * `.dockerignore` and `.alchemy` — e.g. `.git` and `node_modules` for a
     * dev watcher that must not restart on git's index writes or re-hash
     * installed dependencies on every edit.
     */
    readonly excludeNames?: ReadonlyArray<string>;
} | undefined) => Effect.Effect<string, BuildHashInvalidProps | import("effect/PlatformError").PlatformError, FileSystem.FileSystem | Path.Path>;
export {};
//# sourceMappingURL=BuildHash.d.ts.map