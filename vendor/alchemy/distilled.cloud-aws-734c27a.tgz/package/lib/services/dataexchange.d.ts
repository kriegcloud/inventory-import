import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceLimitExceededException_base: S.TaggedErrorClass<"ServiceLimitExceededException", {
    readonly LimitName: any;
    readonly LimitValue: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceLimitExceededException extends /*@__PURE__*/ ServiceLimitExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly ExceptionCause: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DataGrantArn = string;
export interface AcceptDataGrantRequest {
    DataGrantArn: string;
}
export type DataGrantName = string;
export type SenderPrincipal = string;
export type ReceiverPrincipal = string;
export type DataGrantDescription = string;
export type DataGrantAcceptanceState = string;
export type GrantDistributionScope = string;
export type Id = string;
export type Arn = string;
export interface AcceptDataGrantResponse {
    Name: string;
    SenderPrincipal?: string | undefined;
    ReceiverPrincipal: string;
    Description?: string | undefined;
    AcceptanceState: string;
    AcceptedAt?: Date | undefined;
    EndsAt?: Date | undefined;
    GrantDistributionScope: string;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface CancelJobRequest {
    JobId: string;
}
export interface CancelJobResponse {
}
export type Description = string;
export type MapOf__string = {
    [key: string]: string | undefined;
};
export interface CreateDataGrantRequest {
    Name: string;
    GrantDistributionScope: string;
    ReceiverPrincipal: string;
    SourceDataSetId: string;
    EndsAt?: Date | undefined;
    Description?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDataGrantResponse {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    Description?: string | undefined;
    AcceptanceState: string;
    AcceptedAt?: Date | undefined;
    EndsAt?: Date | undefined;
    GrantDistributionScope: string;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AssetType = string;
export type Name = string;
export interface CreateDataSetRequest {
    AssetType: string;
    Description: string;
    Name: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type Origin = string;
export interface OriginDetails {
    ProductId?: string | undefined;
    DataGrantId?: string | undefined;
}
export interface CreateDataSetResponse {
    Arn?: string | undefined;
    AssetType?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Origin?: string | undefined;
    OriginDetails?: OriginDetails | undefined;
    SourceId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
}
export type ServerSideEncryptionTypes = string;
export interface ExportServerSideEncryption {
    KmsKeyArn?: string | undefined;
    Type: string;
}
export interface AutoExportRevisionDestinationEntry {
    Bucket: string;
    KeyPattern?: string | undefined;
}
export interface AutoExportRevisionToS3RequestDetails {
    Encryption?: ExportServerSideEncryption | undefined;
    RevisionDestination: AutoExportRevisionDestinationEntry;
}
export interface Action {
    ExportRevisionToS3?: AutoExportRevisionToS3RequestDetails | undefined;
}
export interface RevisionPublished {
    DataSetId: string;
}
export interface Event {
    RevisionPublished?: RevisionPublished | undefined;
}
export interface CreateEventActionRequest {
    Action: Action;
    Event: Event;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateEventActionResponse {
    Action?: Action | undefined;
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Event?: Event | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
}
export interface Tag {
    Key: string;
    Value: string;
}
export type ListOfTag = Tag[];
export interface AssetConfiguration {
    Tags?: Tag[] | undefined;
}
export interface ExportAssetToSignedUrlRequestDetails {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export interface AssetDestinationEntry {
    AssetId: string;
    Bucket: string;
    Key?: string | undefined;
}
export type ListOfAssetDestinationEntry = AssetDestinationEntry[];
export interface ExportAssetsToS3RequestDetails {
    AssetDestinations: AssetDestinationEntry[];
    DataSetId: string;
    Encryption?: ExportServerSideEncryption | undefined;
    RevisionId: string;
}
export interface RevisionDestinationEntry {
    Bucket: string;
    KeyPattern?: string | undefined;
    RevisionId: string;
}
export type ListOfRevisionDestinationEntry = RevisionDestinationEntry[];
export interface ExportRevisionsToS3RequestDetails {
    DataSetId: string;
    Encryption?: ExportServerSideEncryption | undefined;
    RevisionDestinations: RevisionDestinationEntry[];
}
export type AssetName = string;
export type __stringMin24Max24PatternAZaZ094AZaZ092AZaZ093 = string;
export interface ImportAssetFromSignedUrlRequestDetails {
    AssetName: string;
    DataSetId: string;
    Md5Hash: string;
    RevisionId: string;
}
export interface AssetSourceEntry {
    Bucket: string;
    Key: string;
}
export type ListOfAssetSourceEntry = AssetSourceEntry[];
export interface ImportAssetsFromS3RequestDetails {
    AssetSources: AssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export interface RedshiftDataShareAssetSourceEntry {
    DataShareArn: string;
}
export type ListOfRedshiftDataShareAssetSourceEntry = RedshiftDataShareAssetSourceEntry[];
export interface ImportAssetsFromRedshiftDataSharesRequestDetails {
    AssetSources: RedshiftDataShareAssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export type ApiDescription = string;
export type ProtocolType = string;
export interface ImportAssetFromApiGatewayApiRequestDetails {
    ApiDescription?: string | undefined;
    ApiId: string;
    ApiKey?: string | redacted.Redacted<string> | undefined;
    ApiName: string;
    ApiSpecificationMd5Hash: string;
    DataSetId: string;
    ProtocolType: string;
    RevisionId: string;
    Stage: string;
}
export type ListOf__string = string[];
export type KmsKeyArn = string;
export interface KmsKeyToGrant {
    KmsKeyArn: string;
}
export type ListOfKmsKeysToGrant = KmsKeyToGrant[];
export interface S3DataAccessAssetSourceEntry {
    Bucket: string;
    KeyPrefixes?: string[] | undefined;
    Keys?: string[] | undefined;
    KmsKeysToGrant?: KmsKeyToGrant[] | undefined;
}
export interface CreateS3DataAccessFromS3BucketRequestDetails {
    AssetSource: S3DataAccessAssetSourceEntry;
    DataSetId: string;
    RevisionId: string;
}
export type AwsAccountId = string;
export type ListOfLFTagValues = string[];
export interface LFTag {
    TagKey: string;
    TagValues: string[];
}
export type ListOfLFTags = LFTag[];
export type DatabaseLFTagPolicyPermission = string;
export type ListOfDatabaseLFTagPolicyPermissions = string[];
export interface DatabaseLFTagPolicyAndPermissions {
    Expression: LFTag[];
    Permissions: string[];
}
export type TableTagPolicyLFPermission = string;
export type ListOfTableTagPolicyLFPermissions = string[];
export interface TableLFTagPolicyAndPermissions {
    Expression: LFTag[];
    Permissions: string[];
}
export type RoleArn = string;
export interface ImportAssetsFromLakeFormationTagPolicyRequestDetails {
    CatalogId: string;
    Database?: DatabaseLFTagPolicyAndPermissions | undefined;
    Table?: TableLFTagPolicyAndPermissions | undefined;
    RoleArn: string;
    DataSetId: string;
    RevisionId: string;
}
export interface RequestDetails {
    ExportAssetToSignedUrl?: ExportAssetToSignedUrlRequestDetails | undefined;
    ExportAssetsToS3?: ExportAssetsToS3RequestDetails | undefined;
    ExportRevisionsToS3?: ExportRevisionsToS3RequestDetails | undefined;
    ImportAssetFromSignedUrl?: ImportAssetFromSignedUrlRequestDetails | undefined;
    ImportAssetsFromS3?: ImportAssetsFromS3RequestDetails | undefined;
    ImportAssetsFromRedshiftDataShares?: ImportAssetsFromRedshiftDataSharesRequestDetails | undefined;
    ImportAssetFromApiGatewayApi?: ImportAssetFromApiGatewayApiRequestDetails | undefined;
    CreateS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketRequestDetails | undefined;
    ImportAssetsFromLakeFormationTagPolicy?: ImportAssetsFromLakeFormationTagPolicyRequestDetails | undefined;
}
export type Type = string;
export interface CreateJobRequest {
    AssetConfiguration?: AssetConfiguration | undefined;
    Details: RequestDetails;
    Type: string;
}
export interface ExportAssetToSignedUrlResponseDetails {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
    SignedUrl?: string | undefined;
    SignedUrlExpiresAt?: Date | undefined;
}
export interface ExportAssetsToS3ResponseDetails {
    AssetDestinations: AssetDestinationEntry[];
    DataSetId: string;
    Encryption?: ExportServerSideEncryption | undefined;
    RevisionId: string;
}
export interface ExportRevisionsToS3ResponseDetails {
    DataSetId: string;
    Encryption?: ExportServerSideEncryption | undefined;
    RevisionDestinations: RevisionDestinationEntry[];
    EventActionArn?: string | undefined;
}
export interface ImportAssetFromSignedUrlResponseDetails {
    AssetName: string;
    DataSetId: string;
    Md5Hash?: string | undefined;
    RevisionId: string;
    SignedUrl?: string | undefined;
    SignedUrlExpiresAt?: Date | undefined;
}
export interface ImportAssetsFromS3ResponseDetails {
    AssetSources: AssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export interface ImportAssetsFromRedshiftDataSharesResponseDetails {
    AssetSources: RedshiftDataShareAssetSourceEntry[];
    DataSetId: string;
    RevisionId: string;
}
export interface ImportAssetFromApiGatewayApiResponseDetails {
    ApiDescription?: string | undefined;
    ApiId: string;
    ApiKey?: string | redacted.Redacted<string> | undefined;
    ApiName: string;
    ApiSpecificationMd5Hash: string;
    ApiSpecificationUploadUrl: string;
    ApiSpecificationUploadUrlExpiresAt: Date;
    DataSetId: string;
    ProtocolType: string;
    RevisionId: string;
    Stage: string;
}
export interface CreateS3DataAccessFromS3BucketResponseDetails {
    AssetSource: S3DataAccessAssetSourceEntry;
    DataSetId: string;
    RevisionId: string;
}
export interface ImportAssetsFromLakeFormationTagPolicyResponseDetails {
    CatalogId: string;
    Database?: DatabaseLFTagPolicyAndPermissions | undefined;
    Table?: TableLFTagPolicyAndPermissions | undefined;
    RoleArn: string;
    DataSetId: string;
    RevisionId: string;
}
export interface ResponseDetails {
    ExportAssetToSignedUrl?: ExportAssetToSignedUrlResponseDetails | undefined;
    ExportAssetsToS3?: ExportAssetsToS3ResponseDetails | undefined;
    ExportRevisionsToS3?: ExportRevisionsToS3ResponseDetails | undefined;
    ImportAssetFromSignedUrl?: ImportAssetFromSignedUrlResponseDetails | undefined;
    ImportAssetsFromS3?: ImportAssetsFromS3ResponseDetails | undefined;
    ImportAssetsFromRedshiftDataShares?: ImportAssetsFromRedshiftDataSharesResponseDetails | undefined;
    ImportAssetFromApiGatewayApi?: ImportAssetFromApiGatewayApiResponseDetails | undefined;
    CreateS3DataAccessFromS3Bucket?: CreateS3DataAccessFromS3BucketResponseDetails | undefined;
    ImportAssetsFromLakeFormationTagPolicy?: ImportAssetsFromLakeFormationTagPolicyResponseDetails | undefined;
}
export type Code = string;
export interface ImportAssetFromSignedUrlJobErrorDetails {
    AssetName: string;
}
export interface Details {
    ImportAssetFromSignedUrlJobErrorDetails?: ImportAssetFromSignedUrlJobErrorDetails | undefined;
    ImportAssetsFromS3JobErrorDetails?: AssetSourceEntry[] | undefined;
}
export type JobErrorLimitName = string;
export type JobErrorResourceTypes = string;
export interface JobError {
    Code: string;
    Details?: Details | undefined;
    LimitName?: string | undefined;
    LimitValue?: number | undefined;
    Message: string;
    ResourceId?: string | undefined;
    ResourceType?: string | undefined;
}
export type ListOfJobError = JobError[];
export type State = string;
export interface CreateJobResponse {
    Arn?: string | undefined;
    AssetConfiguration?: AssetConfiguration | undefined;
    CreatedAt?: Date | undefined;
    Details?: ResponseDetails | undefined;
    Errors?: JobError[] | undefined;
    Id?: string | undefined;
    State?: string | undefined;
    Type?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export type __stringMin0Max16384 = string;
export interface CreateRevisionRequest {
    Comment?: string | undefined;
    DataSetId: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin10Max512 = string;
export interface CreateRevisionResponse {
    Arn?: string | undefined;
    Comment?: string | undefined;
    CreatedAt?: Date | undefined;
    DataSetId?: string | undefined;
    Finalized?: boolean | undefined;
    Id?: string | undefined;
    SourceId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
    RevocationComment?: string | undefined;
    Revoked?: boolean | undefined;
    RevokedAt?: Date | undefined;
}
export interface DeleteAssetRequest {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export interface DeleteAssetResponse {
}
export type DataGrantId = string;
export interface DeleteDataGrantRequest {
    DataGrantId: string;
}
export interface DeleteDataGrantResponse {
}
export interface DeleteDataSetRequest {
    DataSetId: string;
}
export interface DeleteDataSetResponse {
}
export interface DeleteEventActionRequest {
    EventActionId: string;
}
export interface DeleteEventActionResponse {
}
export interface DeleteRevisionRequest {
    DataSetId: string;
    RevisionId: string;
}
export interface DeleteRevisionResponse {
}
export interface GetAssetRequest {
    AssetId: string;
    DataSetId: string;
    RevisionId: string;
}
export type __doubleMin0 = number;
export interface S3SnapshotAsset {
    Size: number;
}
export interface RedshiftDataShareAsset {
    Arn: string;
}
export interface ApiGatewayApiAsset {
    ApiDescription?: string | undefined;
    ApiEndpoint?: string | undefined;
    ApiId?: string | undefined;
    ApiKey?: string | redacted.Redacted<string> | undefined;
    ApiName?: string | undefined;
    ApiSpecificationDownloadUrl?: string | undefined;
    ApiSpecificationDownloadUrlExpiresAt?: Date | undefined;
    ProtocolType?: string | undefined;
    Stage?: string | undefined;
}
export interface S3DataAccessAsset {
    Bucket: string;
    KeyPrefixes?: string[] | undefined;
    Keys?: string[] | undefined;
    S3AccessPointAlias?: string | undefined;
    S3AccessPointArn?: string | undefined;
    KmsKeysToGrant?: KmsKeyToGrant[] | undefined;
}
export type LFResourceType = string;
export interface DatabaseLFTagPolicy {
    Expression: LFTag[];
}
export interface TableLFTagPolicy {
    Expression: LFTag[];
}
export interface LFResourceDetails {
    Database?: DatabaseLFTagPolicy | undefined;
    Table?: TableLFTagPolicy | undefined;
}
export interface LFTagPolicyDetails {
    CatalogId: string;
    ResourceType: string;
    ResourceDetails: LFResourceDetails;
}
export interface LakeFormationDataPermissionDetails {
    LFTagPolicy?: LFTagPolicyDetails | undefined;
}
export type LakeFormationDataPermissionType = string;
export type LFPermission = string;
export type ListOfLFPermissions = string[];
export interface LakeFormationDataPermissionAsset {
    LakeFormationDataPermissionDetails: LakeFormationDataPermissionDetails;
    LakeFormationDataPermissionType: string;
    Permissions: string[];
    RoleArn?: string | undefined;
}
export interface AssetDetails {
    S3SnapshotAsset?: S3SnapshotAsset | undefined;
    RedshiftDataShareAsset?: RedshiftDataShareAsset | undefined;
    ApiGatewayApiAsset?: ApiGatewayApiAsset | undefined;
    S3DataAccessAsset?: S3DataAccessAsset | undefined;
    LakeFormationDataPermissionAsset?: LakeFormationDataPermissionAsset | undefined;
}
export interface GetAssetResponse {
    Arn?: string | undefined;
    AssetDetails?: AssetDetails | undefined;
    AssetType?: string | undefined;
    CreatedAt?: Date | undefined;
    DataSetId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    RevisionId?: string | undefined;
    SourceId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetDataGrantRequest {
    DataGrantId: string;
}
export interface GetDataGrantResponse {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    Description?: string | undefined;
    AcceptanceState: string;
    AcceptedAt?: Date | undefined;
    EndsAt?: Date | undefined;
    GrantDistributionScope: string;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDataSetRequest {
    DataSetId: string;
}
export interface GetDataSetResponse {
    Arn?: string | undefined;
    AssetType?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Origin?: string | undefined;
    OriginDetails?: OriginDetails | undefined;
    SourceId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetEventActionRequest {
    EventActionId: string;
}
export interface GetEventActionResponse {
    Action?: Action | undefined;
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Event?: Event | undefined;
    Id?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetJobRequest {
    JobId: string;
}
export interface GetJobResponse {
    Arn?: string | undefined;
    AssetConfiguration?: AssetConfiguration | undefined;
    CreatedAt?: Date | undefined;
    Details?: ResponseDetails | undefined;
    Errors?: JobError[] | undefined;
    Id?: string | undefined;
    State?: string | undefined;
    Type?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetReceivedDataGrantRequest {
    DataGrantArn: string;
}
export interface GetReceivedDataGrantResponse {
    Name: string;
    SenderPrincipal?: string | undefined;
    ReceiverPrincipal: string;
    Description?: string | undefined;
    AcceptanceState: string;
    AcceptedAt?: Date | undefined;
    EndsAt?: Date | undefined;
    GrantDistributionScope: string;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface GetRevisionRequest {
    DataSetId: string;
    RevisionId: string;
}
export interface GetRevisionResponse {
    Arn?: string | undefined;
    Comment?: string | undefined;
    CreatedAt?: Date | undefined;
    DataSetId?: string | undefined;
    Finalized?: boolean | undefined;
    Id?: string | undefined;
    SourceId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    UpdatedAt?: Date | undefined;
    RevocationComment?: string | undefined;
    Revoked?: boolean | undefined;
    RevokedAt?: Date | undefined;
}
export type MaxResults = number;
export interface ListDataGrantsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DataGrantSummaryEntry {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    AcceptanceState: string;
    AcceptedAt?: Date | undefined;
    EndsAt?: Date | undefined;
    DataSetId: string;
    SourceDataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type ListOfDataGrantSummaryEntry = DataGrantSummaryEntry[];
export type NextToken = string;
export interface ListDataGrantsResponse {
    DataGrantSummaries?: DataGrantSummaryEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDataSetRevisionsRequest {
    DataSetId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RevisionEntry {
    Arn: string;
    Comment?: string | undefined;
    CreatedAt: Date;
    DataSetId: string;
    Finalized?: boolean | undefined;
    Id: string;
    SourceId?: string | undefined;
    UpdatedAt: Date;
    RevocationComment?: string | undefined;
    Revoked?: boolean | undefined;
    RevokedAt?: Date | undefined;
}
export type ListOfRevisionEntry = RevisionEntry[];
export interface ListDataSetRevisionsResponse {
    NextToken?: string | undefined;
    Revisions?: RevisionEntry[] | undefined;
}
export interface ListDataSetsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Origin?: string | undefined;
}
export interface DataSetEntry {
    Arn: string;
    AssetType: string;
    CreatedAt: Date;
    Description: string;
    Id: string;
    Name: string;
    Origin: string;
    OriginDetails?: OriginDetails | undefined;
    SourceId?: string | undefined;
    UpdatedAt: Date;
}
export type ListOfDataSetEntry = DataSetEntry[];
export interface ListDataSetsResponse {
    DataSets?: DataSetEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventActionsRequest {
    EventSourceId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface EventActionEntry {
    Action: Action;
    Arn: string;
    CreatedAt: Date;
    Event: Event;
    Id: string;
    UpdatedAt: Date;
}
export type ListOfEventActionEntry = EventActionEntry[];
export interface ListEventActionsResponse {
    EventActions?: EventActionEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListJobsRequest {
    DataSetId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    RevisionId?: string | undefined;
}
export interface JobEntry {
    Arn: string;
    AssetConfiguration?: AssetConfiguration | undefined;
    CreatedAt: Date;
    Details: ResponseDetails;
    Errors?: JobError[] | undefined;
    Id: string;
    State: string;
    Type: string;
    UpdatedAt: Date;
}
export type ListOfJobEntry = JobEntry[];
export interface ListJobsResponse {
    Jobs?: JobEntry[] | undefined;
    NextToken?: string | undefined;
}
export type AcceptanceStateFilterValue = string;
export type AcceptanceStateFilterValues = string[];
export interface ListReceivedDataGrantsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AcceptanceState?: string[] | undefined;
}
export interface ReceivedDataGrantSummariesEntry {
    Name: string;
    SenderPrincipal: string;
    ReceiverPrincipal: string;
    AcceptanceState: string;
    AcceptedAt?: Date | undefined;
    EndsAt?: Date | undefined;
    DataSetId: string;
    Id: string;
    Arn: string;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type ListOfReceivedDataGrantSummariesEntry = ReceivedDataGrantSummariesEntry[];
export interface ListReceivedDataGrantsResponse {
    DataGrantSummaries?: ReceivedDataGrantSummariesEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRevisionAssetsRequest {
    DataSetId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    RevisionId: string;
}
export interface AssetEntry {
    Arn: string;
    AssetDetails: AssetDetails;
    AssetType: string;
    CreatedAt: Date;
    DataSetId: string;
    Id: string;
    Name: string;
    RevisionId: string;
    SourceId?: string | undefined;
    UpdatedAt: Date;
}
export type ListOfAssetEntry = AssetEntry[];
export interface ListRevisionAssetsResponse {
    Assets?: AssetEntry[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RevokeRevisionRequest {
    DataSetId: string;
    RevisionId: string;
    RevocationComment: string;
}
export interface RevokeRevisionResponse {
    Arn?: string | undefined;
    Comment?: string | undefined;
    CreatedAt?: Date | undefined;
    DataSetId?: string | undefined;
    Finalized?: boolean | undefined;
    Id?: string | undefined;
    SourceId?: string | undefined;
    UpdatedAt?: Date | undefined;
    RevocationComment?: string | undefined;
    Revoked?: boolean | undefined;
    RevokedAt?: Date | undefined;
}
export interface SendApiAssetRequest {
    Body?: string | undefined;
    QueryStringParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AssetId: string;
    DataSetId: string;
    RequestHeaders?: {
        [key: string]: string | undefined;
    } | undefined;
    Method?: string | undefined;
    Path?: string | undefined;
    RevisionId: string;
}
export interface SendApiAssetResponse {
    Body?: string | undefined;
    ResponseHeaders?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface LakeFormationTagPolicyDetails {
    Database?: string | undefined;
    Table?: string | undefined;
}
export type ListOfLakeFormationTagPolicies = LakeFormationTagPolicyDetails[];
export interface RedshiftDataShareDetails {
    Arn: string;
    Database: string;
    Function?: string | undefined;
    Table?: string | undefined;
    Schema?: string | undefined;
    View?: string | undefined;
}
export type ListOfRedshiftDataShares = RedshiftDataShareDetails[];
export interface S3DataAccessDetails {
    KeyPrefixes?: string[] | undefined;
    Keys?: string[] | undefined;
}
export type ListOfS3DataAccesses = S3DataAccessDetails[];
export interface ScopeDetails {
    LakeFormationTagPolicies?: LakeFormationTagPolicyDetails[] | undefined;
    RedshiftDataShares?: RedshiftDataShareDetails[] | undefined;
    S3DataAccesses?: S3DataAccessDetails[] | undefined;
}
export type ClientToken = string;
export type __stringMin0Max4096 = string;
export interface DataUpdateRequestDetails {
    DataUpdatedAt?: Date | undefined;
}
export interface DeprecationRequestDetails {
    DeprecationAt: Date;
}
export type SchemaChangeType = string;
export interface SchemaChangeDetails {
    Name: string;
    Type: string;
    Description?: string | undefined;
}
export type ListOfSchemaChangeDetails = SchemaChangeDetails[];
export interface SchemaChangeRequestDetails {
    Changes?: SchemaChangeDetails[] | undefined;
    SchemaChangeAt: Date;
}
export interface NotificationDetails {
    DataUpdate?: DataUpdateRequestDetails | undefined;
    Deprecation?: DeprecationRequestDetails | undefined;
    SchemaChange?: SchemaChangeRequestDetails | undefined;
}
export type NotificationType = string;
export interface SendDataSetNotificationRequest {
    Scope?: ScopeDetails | undefined;
    ClientToken?: string | undefined;
    Comment?: string | undefined;
    DataSetId: string;
    Details?: NotificationDetails | undefined;
    Type: string;
}
export interface SendDataSetNotificationResponse {
}
export interface StartJobRequest {
    JobId: string;
}
export interface StartJobResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAssetRequest {
    AssetId: string;
    DataSetId: string;
    Name: string;
    RevisionId: string;
}
export interface UpdateAssetResponse {
    Arn?: string | undefined;
    AssetDetails?: AssetDetails | undefined;
    AssetType?: string | undefined;
    CreatedAt?: Date | undefined;
    DataSetId?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    RevisionId?: string | undefined;
    SourceId?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export interface UpdateDataSetRequest {
    DataSetId: string;
    Description?: string | undefined;
    Name?: string | undefined;
}
export interface UpdateDataSetResponse {
    Arn?: string | undefined;
    AssetType?: string | undefined;
    CreatedAt?: Date | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Origin?: string | undefined;
    OriginDetails?: OriginDetails | undefined;
    SourceId?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export interface UpdateEventActionRequest {
    Action?: Action | undefined;
    EventActionId: string;
}
export interface UpdateEventActionResponse {
    Action?: Action | undefined;
    Arn?: string | undefined;
    CreatedAt?: Date | undefined;
    Event?: Event | undefined;
    Id?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export interface UpdateRevisionRequest {
    Comment?: string | undefined;
    DataSetId: string;
    Finalized?: boolean | undefined;
    RevisionId: string;
}
export interface UpdateRevisionResponse {
    Arn?: string | undefined;
    Comment?: string | undefined;
    CreatedAt?: Date | undefined;
    DataSetId?: string | undefined;
    Finalized?: boolean | undefined;
    Id?: string | undefined;
    SourceId?: string | undefined;
    UpdatedAt?: Date | undefined;
    RevocationComment?: string | undefined;
    Revoked?: boolean | undefined;
    RevokedAt?: Date | undefined;
}
export type ResourceType = string;
export type ExceptionCause = string;
export type LimitName = string;
export type AcceptDataGrantError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation accepts a data grant.
 */
export declare const acceptDataGrant: API.OperationMethod<AcceptDataGrantRequest & RegionInput, AcceptDataGrantResponse, AcceptDataGrantError, Credentials | HttpClient.HttpClient>;
export type CancelJobError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation cancels a job. Jobs can be cancelled only when they are in the WAITING state.
 */
export declare const cancelJob: API.OperationMethod<CancelJobRequest & RegionInput, CancelJobResponse, CancelJobError, Credentials | HttpClient.HttpClient>;
export type CreateDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a data grant.
 */
export declare const createDataGrant: API.OperationMethod<CreateDataGrantRequest & RegionInput, CreateDataGrantResponse, CreateDataGrantError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetError = AccessDeniedException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a data set.
 */
export declare const createDataSet: API.OperationMethod<CreateDataSetRequest & RegionInput, CreateDataSetResponse, CreateDataSetError, Credentials | HttpClient.HttpClient>;
export type CreateEventActionError = AccessDeniedException | InternalServerException | ServiceLimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates an event action.
 */
export declare const createEventAction: API.OperationMethod<CreateEventActionRequest & RegionInput, CreateEventActionResponse, CreateEventActionError, Credentials | HttpClient.HttpClient>;
export type CreateJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a job.
 */
export declare const createJob: API.OperationMethod<CreateJobRequest & RegionInput, CreateJobResponse, CreateJobError, Credentials | HttpClient.HttpClient>;
export type CreateRevisionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation creates a revision for a data set.
 */
export declare const createRevision: API.OperationMethod<CreateRevisionRequest & RegionInput, CreateRevisionResponse, CreateRevisionError, Credentials | HttpClient.HttpClient>;
export type DeleteAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes an asset.
 */
export declare const deleteAsset: API.OperationMethod<DeleteAssetRequest & RegionInput, DeleteAssetResponse, DeleteAssetError, Credentials | HttpClient.HttpClient>;
export type DeleteDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a data grant.
 */
export declare const deleteDataGrant: API.OperationMethod<DeleteDataGrantRequest & RegionInput, DeleteDataGrantResponse, DeleteDataGrantError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a data set.
 */
export declare const deleteDataSet: API.OperationMethod<DeleteDataSetRequest & RegionInput, DeleteDataSetResponse, DeleteDataSetError, Credentials | HttpClient.HttpClient>;
export type DeleteEventActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes the event action.
 */
export declare const deleteEventAction: API.OperationMethod<DeleteEventActionRequest & RegionInput, DeleteEventActionResponse, DeleteEventActionError, Credentials | HttpClient.HttpClient>;
export type DeleteRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation deletes a revision.
 */
export declare const deleteRevision: API.OperationMethod<DeleteRevisionRequest & RegionInput, DeleteRevisionResponse, DeleteRevisionError, Credentials | HttpClient.HttpClient>;
export type GetAssetError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about an asset.
 */
export declare const getAsset: API.OperationMethod<GetAssetRequest & RegionInput, GetAssetResponse, GetAssetError, Credentials | HttpClient.HttpClient>;
export type GetDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a data grant.
 */
export declare const getDataGrant: API.OperationMethod<GetDataGrantRequest & RegionInput, GetDataGrantResponse, GetDataGrantError, Credentials | HttpClient.HttpClient>;
export type GetDataSetError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a data set.
 */
export declare const getDataSet: API.OperationMethod<GetDataSetRequest & RegionInput, GetDataSetResponse, GetDataSetError, Credentials | HttpClient.HttpClient>;
export type GetEventActionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation retrieves information about an event action.
 */
export declare const getEventAction: API.OperationMethod<GetEventActionRequest & RegionInput, GetEventActionResponse, GetEventActionError, Credentials | HttpClient.HttpClient>;
export type GetJobError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a job.
 */
export declare const getJob: API.OperationMethod<GetJobRequest & RegionInput, GetJobResponse, GetJobError, Credentials | HttpClient.HttpClient>;
export type GetReceivedDataGrantError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a received data grant.
 */
export declare const getReceivedDataGrant: API.OperationMethod<GetReceivedDataGrantRequest & RegionInput, GetReceivedDataGrantResponse, GetReceivedDataGrantError, Credentials | HttpClient.HttpClient>;
export type GetRevisionError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about a revision.
 */
export declare const getRevision: API.OperationMethod<GetRevisionRequest & RegionInput, GetRevisionResponse, GetRevisionError, Credentials | HttpClient.HttpClient>;
export type ListDataGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about all data grants.
 */
export declare const listDataGrants: API.PaginatedOperationMethod<ListDataGrantsRequest & RegionInput, ListDataGrantsResponse, ListDataGrantsError, Credentials | HttpClient.HttpClient, DataGrantSummaryEntry>;
export type ListDataSetRevisionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists a data set's revisions sorted by CreatedAt in descending order.
 */
export declare const listDataSetRevisions: API.PaginatedOperationMethod<ListDataSetRevisionsRequest & RegionInput, ListDataSetRevisionsResponse, ListDataSetRevisionsError, Credentials | HttpClient.HttpClient, RevisionEntry>;
export type ListDataSetsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your data sets. When listing by origin OWNED, results are sorted by CreatedAt in descending order. When listing by origin ENTITLED, there is no order.
 */
export declare const listDataSets: API.PaginatedOperationMethod<ListDataSetsRequest & RegionInput, ListDataSetsResponse, ListDataSetsError, Credentials | HttpClient.HttpClient, DataSetEntry>;
export type ListEventActionsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your event actions.
 */
export declare const listEventActions: API.PaginatedOperationMethod<ListEventActionsRequest & RegionInput, ListEventActionsResponse, ListEventActionsError, Credentials | HttpClient.HttpClient, EventActionEntry>;
export type ListJobsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists your jobs sorted by CreatedAt in descending order.
 */
export declare const listJobs: API.PaginatedOperationMethod<ListJobsRequest & RegionInput, ListJobsResponse, ListJobsError, Credentials | HttpClient.HttpClient, JobEntry>;
export type ListReceivedDataGrantsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation returns information about all received data grants.
 */
export declare const listReceivedDataGrants: API.PaginatedOperationMethod<ListReceivedDataGrantsRequest & RegionInput, ListReceivedDataGrantsResponse, ListReceivedDataGrantsError, Credentials | HttpClient.HttpClient, ReceivedDataGrantSummariesEntry>;
export type ListRevisionAssetsError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation lists a revision's assets sorted alphabetically in descending order.
 */
export declare const listRevisionAssets: API.PaginatedOperationMethod<ListRevisionAssetsRequest & RegionInput, ListRevisionAssetsResponse, ListRevisionAssetsError, Credentials | HttpClient.HttpClient, AssetEntry>;
export type ListTagsForResourceError = CommonErrors;
/**
 * This operation lists the tags on the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RevokeRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation revokes subscribers' access to a revision.
 */
export declare const revokeRevision: API.OperationMethod<RevokeRevisionRequest & RegionInput, RevokeRevisionResponse, RevokeRevisionError, Credentials | HttpClient.HttpClient>;
export type SendApiAssetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation invokes an API Gateway API asset. The request is proxied to the provider's API Gateway API.
 */
export declare const sendApiAsset: API.OperationMethod<SendApiAssetRequest & RegionInput, SendApiAssetResponse, SendApiAssetError, Credentials | HttpClient.HttpClient>;
export type SendDataSetNotificationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The type of event associated with the data set.
 */
export declare const sendDataSetNotification: API.OperationMethod<SendDataSetNotificationRequest & RegionInput, SendDataSetNotificationResponse, SendDataSetNotificationError, Credentials | HttpClient.HttpClient>;
export type StartJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation starts a job.
 */
export declare const startJob: API.OperationMethod<StartJobRequest & RegionInput, StartJobResponse, StartJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = CommonErrors;
/**
 * This operation tags a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * This operation removes one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates an asset.
 */
export declare const updateAsset: API.OperationMethod<UpdateAssetRequest & RegionInput, UpdateAssetResponse, UpdateAssetError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates a data set.
 */
export declare const updateDataSet: API.OperationMethod<UpdateDataSetRequest & RegionInput, UpdateDataSetResponse, UpdateDataSetError, Credentials | HttpClient.HttpClient>;
export type UpdateEventActionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates the event action.
 */
export declare const updateEventAction: API.OperationMethod<UpdateEventActionRequest & RegionInput, UpdateEventActionResponse, UpdateEventActionError, Credentials | HttpClient.HttpClient>;
export type UpdateRevisionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * This operation updates a revision.
 */
export declare const updateRevision: API.OperationMethod<UpdateRevisionRequest & RegionInput, UpdateRevisionResponse, UpdateRevisionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dataexchange.d.ts.map