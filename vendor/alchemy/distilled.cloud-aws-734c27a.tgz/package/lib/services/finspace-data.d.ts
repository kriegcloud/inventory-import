import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type PermissionGroupId = string;
export type UserId = string;
export type ClientToken = string;
export interface AssociateUserToPermissionGroupRequest {
    permissionGroupId: string;
    userId: string;
    clientToken?: string | undefined;
}
export type StatusCode = number;
export interface AssociateUserToPermissionGroupResponse {
    statusCode?: number | undefined;
}
export type DatasetId = string;
export type ChangeType = "REPLACE" | "APPEND" | "MODIFY" | (string & {});
export type StringMapKey = string;
export type StringMapValue = string;
export type SourceParams = {
    [key: string]: string | undefined;
};
export type FormatParams = {
    [key: string]: string | undefined;
};
export interface CreateChangesetRequest {
    clientToken?: string | undefined;
    datasetId: string;
    changeType: ChangeType;
    sourceParams: {
        [key: string]: string | undefined;
    };
    formatParams: {
        [key: string]: string | undefined;
    };
}
export type ChangesetId = string;
export interface CreateChangesetResponse {
    datasetId?: string | undefined;
    changesetId?: string | undefined;
}
export type DatasetTitle = string;
export type DatasetKind = "TABULAR" | "NON_TABULAR" | (string & {});
export type DatasetDescription = string;
export type OwnerName = string;
export type PhoneNumber = string;
export type Email = string | redacted.Redacted<string>;
export interface DatasetOwnerInfo {
    name?: string | undefined;
    phoneNumber?: string | undefined;
    email?: string | redacted.Redacted<string> | undefined;
}
export type StringValueLength1to250 = string;
export interface ResourcePermission {
    permission?: string | undefined;
}
export type ResourcePermissionsList = ResourcePermission[];
export interface PermissionGroupParams {
    permissionGroupId?: string | undefined;
    datasetPermissions?: ResourcePermission[] | undefined;
}
export type AliasString = string;
export type ColumnDataType = "STRING" | "CHAR" | "INTEGER" | "TINYINT" | "SMALLINT" | "BIGINT" | "FLOAT" | "DOUBLE" | "DATE" | "DATETIME" | "BOOLEAN" | "BINARY" | (string & {});
export type ColumnName = string;
export type ColumnDescription = string;
export interface ColumnDefinition {
    dataType?: ColumnDataType | undefined;
    columnName?: string | undefined;
    columnDescription?: string | undefined;
}
export type ColumnList = ColumnDefinition[];
export type ColumnNameList = string[];
export interface SchemaDefinition {
    columns?: ColumnDefinition[] | undefined;
    primaryKeyColumns?: string[] | undefined;
}
export interface SchemaUnion {
    tabularSchemaConfig?: SchemaDefinition | undefined;
}
export interface CreateDatasetRequest {
    clientToken?: string | undefined;
    datasetTitle: string;
    kind: DatasetKind;
    datasetDescription?: string | undefined;
    ownerInfo?: DatasetOwnerInfo | undefined;
    permissionGroupParams: PermissionGroupParams;
    alias?: string | undefined;
    schemaDefinition?: SchemaUnion | undefined;
}
export interface CreateDatasetResponse {
    datasetId?: string | undefined;
}
export type StringValueLength1to255 = string;
export type SortColumnList = string[];
export type PartitionColumnList = string[];
export type TimestampEpoch = number;
export type DataViewDestinationType = string;
export type ExportFileFormat = "PARQUET" | "DELIMITED_TEXT" | (string & {});
export type S3DestinationFormatOptions = {
    [key: string]: string | undefined;
};
export interface DataViewDestinationTypeParams {
    destinationType: string;
    s3DestinationExportFileFormat?: ExportFileFormat | undefined;
    s3DestinationExportFileFormatOptions?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDataViewRequest {
    clientToken?: string | undefined;
    datasetId: string;
    autoUpdate?: boolean | undefined;
    sortColumns?: string[] | undefined;
    partitionColumns?: string[] | undefined;
    asOfTimestamp?: number | undefined;
    destinationTypeParams: DataViewDestinationTypeParams;
}
export type DataViewId = string;
export interface CreateDataViewResponse {
    datasetId?: string | undefined;
    dataViewId?: string | undefined;
}
export type PermissionGroupName = string | redacted.Redacted<string>;
export type PermissionGroupDescription = string | redacted.Redacted<string>;
export type ApplicationPermission = "CreateDataset" | "ManageClusters" | "ManageUsersAndGroups" | "ManageAttributeSets" | "ViewAuditData" | "AccessNotebooks" | "GetTemporaryCredentials" | (string & {});
export type ApplicationPermissionList = ApplicationPermission[];
export interface CreatePermissionGroupRequest {
    name: string | redacted.Redacted<string>;
    description?: string | redacted.Redacted<string> | undefined;
    applicationPermissions: ApplicationPermission[];
    clientToken?: string | undefined;
}
export interface CreatePermissionGroupResponse {
    permissionGroupId?: string | undefined;
}
export type UserType = "SUPER_USER" | "APP_USER" | (string & {});
export type FirstName = string | redacted.Redacted<string>;
export type LastName = string | redacted.Redacted<string>;
export type ApiAccess = "ENABLED" | "DISABLED" | (string & {});
export type RoleArn = string;
export interface CreateUserRequest {
    emailAddress: string | redacted.Redacted<string>;
    type: UserType;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    apiAccess?: ApiAccess | undefined;
    apiAccessPrincipalArn?: string | undefined;
    clientToken?: string | undefined;
}
export interface CreateUserResponse {
    userId?: string | undefined;
}
export interface DeleteDatasetRequest {
    clientToken?: string | undefined;
    datasetId: string;
}
export interface DeleteDatasetResponse {
    datasetId?: string | undefined;
}
export interface DeletePermissionGroupRequest {
    permissionGroupId: string;
    clientToken?: string | undefined;
}
export interface DeletePermissionGroupResponse {
    permissionGroupId?: string | undefined;
}
export interface DisableUserRequest {
    userId: string;
    clientToken?: string | undefined;
}
export interface DisableUserResponse {
    userId?: string | undefined;
}
export interface DisassociateUserFromPermissionGroupRequest {
    permissionGroupId: string;
    userId: string;
    clientToken?: string | undefined;
}
export interface DisassociateUserFromPermissionGroupResponse {
    statusCode?: number | undefined;
}
export interface EnableUserRequest {
    userId: string;
    clientToken?: string | undefined;
}
export interface EnableUserResponse {
    userId?: string | undefined;
}
export interface GetChangesetRequest {
    datasetId: string;
    changesetId: string;
}
export type ChangesetArn = string;
export type IngestionStatus = "PENDING" | "FAILED" | "SUCCESS" | "RUNNING" | "STOP_REQUESTED" | (string & {});
export type ErrorMessage = string;
export type ErrorCategory = "VALIDATION" | "SERVICE_QUOTA_EXCEEDED" | "ACCESS_DENIED" | "RESOURCE_NOT_FOUND" | "THROTTLING" | "INTERNAL_SERVICE_EXCEPTION" | "CANCELLED" | "USER_RECOVERABLE" | (string & {});
export interface ChangesetErrorInfo {
    errorMessage?: string | undefined;
    errorCategory?: ErrorCategory | undefined;
}
export interface GetChangesetResponse {
    changesetId?: string | undefined;
    changesetArn?: string | undefined;
    datasetId?: string | undefined;
    changeType?: ChangeType | undefined;
    sourceParams?: {
        [key: string]: string | undefined;
    } | undefined;
    formatParams?: {
        [key: string]: string | undefined;
    } | undefined;
    createTime?: number | undefined;
    status?: IngestionStatus | undefined;
    errorInfo?: ChangesetErrorInfo | undefined;
    activeUntilTimestamp?: number | undefined;
    activeFromTimestamp?: number | undefined;
    updatesChangesetId?: string | undefined;
    updatedByChangesetId?: string | undefined;
}
export interface GetDatasetRequest {
    datasetId: string;
}
export type DatasetArn = string;
export type DatasetStatus = "PENDING" | "FAILED" | "SUCCESS" | "RUNNING" | (string & {});
export interface GetDatasetResponse {
    datasetId?: string | undefined;
    datasetArn?: string | undefined;
    datasetTitle?: string | undefined;
    kind?: DatasetKind | undefined;
    datasetDescription?: string | undefined;
    createTime?: number | undefined;
    lastModifiedTime?: number | undefined;
    schemaDefinition?: SchemaUnion | undefined;
    alias?: string | undefined;
    status?: DatasetStatus | undefined;
}
export interface GetDataViewRequest {
    dataViewId: string;
    datasetId: string;
}
export interface DataViewErrorInfo {
    errorMessage?: string | undefined;
    errorCategory?: ErrorCategory | undefined;
}
export type DataViewArn = string;
export type DataViewStatus = "RUNNING" | "STARTING" | "FAILED" | "CANCELLED" | "TIMEOUT" | "SUCCESS" | "PENDING" | "FAILED_CLEANUP_FAILED" | (string & {});
export interface GetDataViewResponse {
    autoUpdate?: boolean | undefined;
    partitionColumns?: string[] | undefined;
    datasetId?: string | undefined;
    asOfTimestamp?: number | undefined;
    errorInfo?: DataViewErrorInfo | undefined;
    lastModifiedTime?: number | undefined;
    createTime?: number | undefined;
    sortColumns?: string[] | undefined;
    dataViewId?: string | undefined;
    dataViewArn?: string | undefined;
    destinationTypeParams?: DataViewDestinationTypeParams | undefined;
    status?: DataViewStatus | undefined;
}
export interface GetExternalDataViewAccessDetailsRequest {
    dataViewId: string;
    datasetId: string;
}
export type AccessKeyId = string;
export type SecretAccessKey = string | redacted.Redacted<string>;
export type SessionToken = string | redacted.Redacted<string>;
export interface AwsCredentials {
    accessKeyId?: string | undefined;
    secretAccessKey?: string | redacted.Redacted<string> | undefined;
    sessionToken?: string | redacted.Redacted<string> | undefined;
    expiration?: number | undefined;
}
export type S3BucketName = string;
export type S3Key = string;
export interface S3Location {
    bucket: string;
    key: string;
}
export interface GetExternalDataViewAccessDetailsResponse {
    credentials?: AwsCredentials | undefined;
    s3Location?: S3Location | undefined;
}
export interface GetPermissionGroupRequest {
    permissionGroupId: string;
}
export type PermissionGroupMembershipStatus = "ADDITION_IN_PROGRESS" | "ADDITION_SUCCESS" | "REMOVAL_IN_PROGRESS" | (string & {});
export interface PermissionGroup {
    permissionGroupId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    applicationPermissions?: ApplicationPermission[] | undefined;
    createTime?: number | undefined;
    lastModifiedTime?: number | undefined;
    membershipStatus?: PermissionGroupMembershipStatus | undefined;
}
export interface GetPermissionGroupResponse {
    permissionGroup?: PermissionGroup | undefined;
}
export type SessionDuration = number;
export type IdType = string;
export interface GetProgrammaticAccessCredentialsRequest {
    durationInMinutes?: number | undefined;
    environmentId: string;
}
export type StringValueLength1to2552 = string;
export type StringValueMaxLength1000 = string;
export interface Credentials {
    accessKeyId?: string | undefined;
    secretAccessKey?: string | undefined;
    sessionToken?: string | undefined;
}
export interface GetProgrammaticAccessCredentialsResponse {
    credentials?: Credentials | undefined;
    durationInMinutes?: number | undefined;
}
export interface GetUserRequest {
    userId: string;
}
export type UserStatus = "CREATING" | "ENABLED" | "DISABLED" | (string & {});
export interface GetUserResponse {
    userId?: string | undefined;
    status?: UserStatus | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    emailAddress?: string | redacted.Redacted<string> | undefined;
    type?: UserType | undefined;
    apiAccess?: ApiAccess | undefined;
    apiAccessPrincipalArn?: string | undefined;
    createTime?: number | undefined;
    lastEnabledTime?: number | undefined;
    lastDisabledTime?: number | undefined;
    lastModifiedTime?: number | undefined;
    lastLoginTime?: number | undefined;
}
export type LocationType = "INGESTION" | "SAGEMAKER" | (string & {});
export interface GetWorkingLocationRequest {
    locationType?: LocationType | undefined;
}
export type StringValueLength1to1024 = string;
export type StringValueLength1to63 = string;
export interface GetWorkingLocationResponse {
    s3Uri?: string | undefined;
    s3Path?: string | undefined;
    s3Bucket?: string | undefined;
}
export type ResultLimit = number;
export type PaginationToken = string;
export interface ListChangesetsRequest {
    datasetId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ChangesetSummary {
    changesetId?: string | undefined;
    changesetArn?: string | undefined;
    datasetId?: string | undefined;
    changeType?: ChangeType | undefined;
    sourceParams?: {
        [key: string]: string | undefined;
    } | undefined;
    formatParams?: {
        [key: string]: string | undefined;
    } | undefined;
    createTime?: number | undefined;
    status?: IngestionStatus | undefined;
    errorInfo?: ChangesetErrorInfo | undefined;
    activeUntilTimestamp?: number | undefined;
    activeFromTimestamp?: number | undefined;
    updatesChangesetId?: string | undefined;
    updatedByChangesetId?: string | undefined;
}
export type ChangesetList = ChangesetSummary[];
export interface ListChangesetsResponse {
    changesets?: ChangesetSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDatasetsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Dataset {
    datasetId?: string | undefined;
    datasetArn?: string | undefined;
    datasetTitle?: string | undefined;
    kind?: DatasetKind | undefined;
    datasetDescription?: string | undefined;
    ownerInfo?: DatasetOwnerInfo | undefined;
    createTime?: number | undefined;
    lastModifiedTime?: number | undefined;
    schemaDefinition?: SchemaUnion | undefined;
    alias?: string | undefined;
}
export type DatasetList = Dataset[];
export interface ListDatasetsResponse {
    datasets?: Dataset[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataViewsRequest {
    datasetId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataViewSummary {
    dataViewId?: string | undefined;
    dataViewArn?: string | undefined;
    datasetId?: string | undefined;
    asOfTimestamp?: number | undefined;
    partitionColumns?: string[] | undefined;
    sortColumns?: string[] | undefined;
    status?: DataViewStatus | undefined;
    errorInfo?: DataViewErrorInfo | undefined;
    destinationTypeProperties?: DataViewDestinationTypeParams | undefined;
    autoUpdate?: boolean | undefined;
    createTime?: number | undefined;
    lastModifiedTime?: number | undefined;
}
export type DataViewList = DataViewSummary[];
export interface ListDataViewsResponse {
    nextToken?: string | undefined;
    dataViews?: DataViewSummary[] | undefined;
}
export interface ListPermissionGroupsRequest {
    nextToken?: string | undefined;
    maxResults: number;
}
export type PermissionGroupList = PermissionGroup[];
export interface ListPermissionGroupsResponse {
    permissionGroups?: PermissionGroup[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPermissionGroupsByUserRequest {
    userId: string;
    nextToken?: string | undefined;
    maxResults: number;
}
export interface PermissionGroupByUser {
    permissionGroupId?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    membershipStatus?: PermissionGroupMembershipStatus | undefined;
}
export type PermissionGroupByUserList = PermissionGroupByUser[];
export interface ListPermissionGroupsByUserResponse {
    permissionGroups?: PermissionGroupByUser[] | undefined;
    nextToken?: string | undefined;
}
export interface ListUsersRequest {
    nextToken?: string | undefined;
    maxResults: number;
}
export interface User {
    userId?: string | undefined;
    status?: UserStatus | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    emailAddress?: string | redacted.Redacted<string> | undefined;
    type?: UserType | undefined;
    apiAccess?: ApiAccess | undefined;
    apiAccessPrincipalArn?: string | undefined;
    createTime?: number | undefined;
    lastEnabledTime?: number | undefined;
    lastDisabledTime?: number | undefined;
    lastModifiedTime?: number | undefined;
    lastLoginTime?: number | undefined;
}
export type UserList = User[];
export interface ListUsersResponse {
    users?: User[] | undefined;
    nextToken?: string | undefined;
}
export interface ListUsersByPermissionGroupRequest {
    permissionGroupId: string;
    nextToken?: string | undefined;
    maxResults: number;
}
export interface UserByPermissionGroup {
    userId?: string | undefined;
    status?: UserStatus | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    emailAddress?: string | redacted.Redacted<string> | undefined;
    type?: UserType | undefined;
    apiAccess?: ApiAccess | undefined;
    apiAccessPrincipalArn?: string | undefined;
    membershipStatus?: PermissionGroupMembershipStatus | undefined;
}
export type UserByPermissionGroupList = UserByPermissionGroup[];
export interface ListUsersByPermissionGroupResponse {
    users?: UserByPermissionGroup[] | undefined;
    nextToken?: string | undefined;
}
export interface ResetUserPasswordRequest {
    userId: string;
    clientToken?: string | undefined;
}
export type Password = string | redacted.Redacted<string>;
export interface ResetUserPasswordResponse {
    userId?: string | undefined;
    temporaryPassword?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateChangesetRequest {
    clientToken?: string | undefined;
    datasetId: string;
    changesetId: string;
    sourceParams: {
        [key: string]: string | undefined;
    };
    formatParams: {
        [key: string]: string | undefined;
    };
}
export interface UpdateChangesetResponse {
    changesetId?: string | undefined;
    datasetId?: string | undefined;
}
export interface UpdateDatasetRequest {
    clientToken?: string | undefined;
    datasetId: string;
    datasetTitle: string;
    kind: DatasetKind;
    datasetDescription?: string | undefined;
    alias?: string | undefined;
    schemaDefinition?: SchemaUnion | undefined;
}
export interface UpdateDatasetResponse {
    datasetId?: string | undefined;
}
export interface UpdatePermissionGroupRequest {
    permissionGroupId: string;
    name?: string | redacted.Redacted<string> | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    applicationPermissions?: ApplicationPermission[] | undefined;
    clientToken?: string | undefined;
}
export interface UpdatePermissionGroupResponse {
    permissionGroupId?: string | undefined;
}
export interface UpdateUserRequest {
    userId: string;
    type?: UserType | undefined;
    firstName?: string | redacted.Redacted<string> | undefined;
    lastName?: string | redacted.Redacted<string> | undefined;
    apiAccess?: ApiAccess | undefined;
    apiAccessPrincipalArn?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateUserResponse {
    userId?: string | undefined;
}
export type ErrorMessage2 = string;
export type AssociateUserToPermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a user to a permission group to grant permissions for actions a user can perform in FinSpace.
 */
export declare const associateUserToPermissionGroup: API.OperationMethod<AssociateUserToPermissionGroupRequest & RegionInput, AssociateUserToPermissionGroupResponse, AssociateUserToPermissionGroupError, Creds | HttpClient.HttpClient>;
export type CreateChangesetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Changeset in a FinSpace Dataset.
 */
export declare const createChangeset: API.OperationMethod<CreateChangesetRequest & RegionInput, CreateChangesetResponse, CreateChangesetError, Creds | HttpClient.HttpClient>;
export type CreateDatasetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new FinSpace Dataset.
 */
export declare const createDataset: API.OperationMethod<CreateDatasetRequest & RegionInput, CreateDatasetResponse, CreateDatasetError, Creds | HttpClient.HttpClient>;
export type CreateDataViewError = ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Dataview for a Dataset.
 */
export declare const createDataView: API.OperationMethod<CreateDataViewRequest & RegionInput, CreateDataViewResponse, CreateDataViewError, Creds | HttpClient.HttpClient>;
export type CreatePermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a group of permissions for various actions that a user can perform in FinSpace.
 */
export declare const createPermissionGroup: API.OperationMethod<CreatePermissionGroupRequest & RegionInput, CreatePermissionGroupResponse, CreatePermissionGroupError, Creds | HttpClient.HttpClient>;
export type CreateUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new user in FinSpace.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Creds | HttpClient.HttpClient>;
export type DeleteDatasetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a FinSpace Dataset.
 */
export declare const deleteDataset: API.OperationMethod<DeleteDatasetRequest & RegionInput, DeleteDatasetResponse, DeleteDatasetError, Creds | HttpClient.HttpClient>;
export type DeletePermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a permission group. This action is irreversible.
 */
export declare const deletePermissionGroup: API.OperationMethod<DeletePermissionGroupRequest & RegionInput, DeletePermissionGroupResponse, DeletePermissionGroupError, Creds | HttpClient.HttpClient>;
export type DisableUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Denies access to the FinSpace web application and API for the specified user.
 */
export declare const disableUser: API.OperationMethod<DisableUserRequest & RegionInput, DisableUserResponse, DisableUserError, Creds | HttpClient.HttpClient>;
export type DisassociateUserFromPermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a user from a permission group.
 */
export declare const disassociateUserFromPermissionGroup: API.OperationMethod<DisassociateUserFromPermissionGroupRequest & RegionInput, DisassociateUserFromPermissionGroupResponse, DisassociateUserFromPermissionGroupError, Creds | HttpClient.HttpClient>;
export type EnableUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows the specified user to access the FinSpace web application and API.
 */
export declare const enableUser: API.OperationMethod<EnableUserRequest & RegionInput, EnableUserResponse, EnableUserError, Creds | HttpClient.HttpClient>;
export type GetChangesetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about a Changeset.
 */
export declare const getChangeset: API.OperationMethod<GetChangesetRequest & RegionInput, GetChangesetResponse, GetChangesetError, Creds | HttpClient.HttpClient>;
export type GetDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a Dataset.
 */
export declare const getDataset: API.OperationMethod<GetDatasetRequest & RegionInput, GetDatasetResponse, GetDatasetError, Creds | HttpClient.HttpClient>;
export type GetDataViewError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a Dataview.
 */
export declare const getDataView: API.OperationMethod<GetDataViewRequest & RegionInput, GetDataViewResponse, GetDataViewError, Creds | HttpClient.HttpClient>;
export type GetExternalDataViewAccessDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the credentials to access the external Dataview from an S3 location. To call this API:
 *
 * - You must retrieve the programmatic credentials.
 *
 * - You must be a member of a FinSpace user group, where the dataset that you want to access has `Read Dataset Data` permissions.
 */
export declare const getExternalDataViewAccessDetails: API.OperationMethod<GetExternalDataViewAccessDetailsRequest & RegionInput, GetExternalDataViewAccessDetailsResponse, GetExternalDataViewAccessDetailsError, Creds | HttpClient.HttpClient>;
export type GetPermissionGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of a specific permission group.
 */
export declare const getPermissionGroup: API.OperationMethod<GetPermissionGroupRequest & RegionInput, GetPermissionGroupResponse, GetPermissionGroupError, Creds | HttpClient.HttpClient>;
export type GetProgrammaticAccessCredentialsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Request programmatic credentials to use with FinSpace SDK. For more information, see Step 2. Access credentials programmatically using IAM access key id and secret access key.
 */
export declare const getProgrammaticAccessCredentials: API.OperationMethod<GetProgrammaticAccessCredentialsRequest & RegionInput, GetProgrammaticAccessCredentialsResponse, GetProgrammaticAccessCredentialsError, Creds | HttpClient.HttpClient>;
export type GetUserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details for a specific user.
 */
export declare const getUser: API.OperationMethod<GetUserRequest & RegionInput, GetUserResponse, GetUserError, Creds | HttpClient.HttpClient>;
export type GetWorkingLocationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A temporary Amazon S3 location, where you can copy your files from a source location to stage or use
 * as a scratch space in FinSpace notebook.
 */
export declare const getWorkingLocation: API.OperationMethod<GetWorkingLocationRequest & RegionInput, GetWorkingLocationResponse, GetWorkingLocationError, Creds | HttpClient.HttpClient>;
export type ListChangesetsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the FinSpace Changesets for a Dataset.
 */
export declare const listChangesets: API.PaginatedOperationMethod<ListChangesetsRequest & RegionInput, ListChangesetsResponse, ListChangesetsError, Creds | HttpClient.HttpClient, ChangesetSummary>;
export type ListDatasetsError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the active Datasets that a user has access to.
 */
export declare const listDatasets: API.PaginatedOperationMethod<ListDatasetsRequest & RegionInput, ListDatasetsResponse, ListDatasetsError, Creds | HttpClient.HttpClient, Dataset>;
export type ListDataViewsError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available Dataviews for a Dataset.
 */
export declare const listDataViews: API.PaginatedOperationMethod<ListDataViewsRequest & RegionInput, ListDataViewsResponse, ListDataViewsError, Creds | HttpClient.HttpClient, DataViewSummary>;
export type ListPermissionGroupsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available permission groups in FinSpace.
 */
export declare const listPermissionGroups: API.PaginatedOperationMethod<ListPermissionGroupsRequest & RegionInput, ListPermissionGroupsResponse, ListPermissionGroupsError, Creds | HttpClient.HttpClient, PermissionGroup>;
export type ListPermissionGroupsByUserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the permission groups that are associated with a specific user.
 */
export declare const listPermissionGroupsByUser: API.OperationMethod<ListPermissionGroupsByUserRequest & RegionInput, ListPermissionGroupsByUserResponse, ListPermissionGroupsByUserError, Creds | HttpClient.HttpClient>;
export type ListUsersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all available users in FinSpace.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Creds | HttpClient.HttpClient, User>;
export type ListUsersByPermissionGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists details of all the users in a specific permission group.
 */
export declare const listUsersByPermissionGroup: API.OperationMethod<ListUsersByPermissionGroupRequest & RegionInput, ListUsersByPermissionGroupResponse, ListUsersByPermissionGroupError, Creds | HttpClient.HttpClient>;
export type ResetUserPasswordError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resets the password for a specified user ID and generates a temporary one. Only a superuser can reset password for other users. Resetting the password immediately invalidates the previous password associated with the user.
 */
export declare const resetUserPassword: API.OperationMethod<ResetUserPasswordRequest & RegionInput, ResetUserPasswordResponse, ResetUserPasswordError, Creds | HttpClient.HttpClient>;
export type UpdateChangesetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a FinSpace Changeset.
 */
export declare const updateChangeset: API.OperationMethod<UpdateChangesetRequest & RegionInput, UpdateChangesetResponse, UpdateChangesetError, Creds | HttpClient.HttpClient>;
export type UpdateDatasetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a FinSpace Dataset.
 */
export declare const updateDataset: API.OperationMethod<UpdateDatasetRequest & RegionInput, UpdateDatasetResponse, UpdateDatasetError, Creds | HttpClient.HttpClient>;
export type UpdatePermissionGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the details of a permission group. You cannot modify a `permissionGroupID`.
 */
export declare const updatePermissionGroup: API.OperationMethod<UpdatePermissionGroupRequest & RegionInput, UpdatePermissionGroupResponse, UpdatePermissionGroupError, Creds | HttpClient.HttpClient>;
export type UpdateUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the details of the specified user. You cannot update the `userId` for a user.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=finspace-data.d.ts.map