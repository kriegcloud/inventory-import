import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type { ConfiguredStack } from "../Stack.ts";
import { UserFacingError } from "../UserFacingError.ts";
declare const StackEntrypointError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "StackEntrypointError";
} & Readonly<A>;
export declare class StackEntrypointError extends StackEntrypointError_base<{
    readonly message: string;
}> {
    readonly [UserFacingError] = true;
}
export declare const DEFAULT_ENTRYPOINT = "alchemy.run.ts";
/**
 * The absolute path of the stack entrypoint, or the user-facing error for
 * a missing one. Kept free of the engine so the `alchemy dev` supervisor can
 * check the entry before it starts an exec child.
 */
export declare const resolveStackEntrypoint: (main: string) => Effect.Effect<string, import("effect/PlatformError").PlatformError | StackEntrypointError, FileSystem.FileSystem | Path.Path>;
export interface StackModuleLoader {
    readonly import: (url: string) => Promise<{
        readonly default?: unknown;
    }>;
}
export declare const StackModuleLoader: Context.Reference<StackModuleLoader>;
/**
 * Import a stack entrypoint and return its default export, the stack value
 * every stack operation takes.
 */
export declare const importStack: (main: string) => Effect.Effect<ConfiguredStack<unknown, unknown>, import("effect/PlatformError").PlatformError | StackEntrypointError, FileSystem.FileSystem | Path.Path>;
/**
 * Which project and credentials an operation acts under. The optional fields
 * fall back to the same defaults the CLI uses.
 */
export interface Target {
    /** Stack entrypoint. @default "alchemy.run.ts" */
    readonly entrypoint?: string;
    /** Profile whose credentials the run uses. Falls back to the active profile. */
    readonly profile?: string;
    /** `.env` file layered under the process environment. */
    readonly envFile?: string;
}
export {};
//# sourceMappingURL=Entrypoint.d.ts.map