import * as Effect from "effect/Effect";
/**
 * Per-process tokens for the local dev servers (the RPC spawner and its
 * sidecars). Each server only answers requests that carry its token as the
 * first path segment of its URL. The URL is handed to clients over the
 * child's stdout pipe or its environment.
 */
/** A fresh 256-bit token, hex encoded. */
export declare const makeRpcToken: Effect.Effect<string, never, never>;
/** `base` with `token` as its path: `http://127.0.0.1:1234` → `http://127.0.0.1:1234/<token>`. */
export declare const withRpcToken: (base: string, token: string) => string;
/**
 * Append `path` to a tokened server URL, keeping the token: use this
 * instead of `new URL("/path", url)`, which drops it.
 */
export declare const rpcSubpath: (url: string | URL, path: string) => string;
/**
 * The rest of `pathname` after the `/<token>` prefix (`""` for the root,
 * `"/parent"`, …), or `undefined` when the request does not carry the token.
 */
export declare const matchRpcToken: (pathname: string, token: string) => string | undefined;
/** The pathname of a request URL that may be relative (Node) or absolute (Bun). */
export declare const requestPathname: (url: string | undefined) => string;
//# sourceMappingURL=RpcToken.d.ts.map