import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly retryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const PreconditionFailedException_base: S.TaggedErrorClass<"PreconditionFailedException", {
    readonly message: any;
}>;
export declare class PreconditionFailedException extends /*@__PURE__*/ PreconditionFailedException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly referenceType: any;
    readonly exampleReference: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
export type BotName = string;
export interface CreateBotVersionRequest {
    name: string;
    checksum?: string | undefined;
}
export type Description = string;
export type IntentName = string;
export type Version = string;
export interface Intent {
    intentName: string;
    intentVersion: string;
}
export type IntentList = Intent[];
export type ContentType = "PlainText" | "SSML" | "CustomPayload" | (string & {});
export type ContentString = string;
export type GroupNumber = number;
export interface Message {
    contentType: ContentType;
    content: string;
    groupNumber?: number | undefined;
}
export type MessageList = Message[];
export type PromptMaxAttempts = number;
export type ResponseCard = string;
export interface Prompt {
    messages: Message[];
    maxAttempts: number;
    responseCard?: string | undefined;
}
export interface Statement {
    messages: Message[];
    responseCard?: string | undefined;
}
export type Status = "BUILDING" | "READY" | "READY_BASIC_TESTING" | "FAILED" | "NOT_BUILT" | (string & {});
export type SessionTTL = number;
export type Locale = "de-DE" | "en-AU" | "en-GB" | "en-IN" | "en-US" | "es-419" | "es-ES" | "es-US" | "fr-FR" | "fr-CA" | "it-IT" | "ja-JP" | "ko-KR" | (string & {});
export interface CreateBotVersionResponse {
    name?: string | undefined;
    description?: string | undefined;
    intents?: Intent[] | undefined;
    clarificationPrompt?: Prompt | undefined;
    abortStatement?: Statement | undefined;
    status?: Status | undefined;
    failureReason?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    voiceId?: string | undefined;
    checksum?: string | undefined;
    version?: string | undefined;
    locale?: Locale | undefined;
    childDirected?: boolean | undefined;
    enableModelImprovements?: boolean | undefined;
    detectSentiment?: boolean | undefined;
}
export interface CreateIntentVersionRequest {
    name: string;
    checksum?: string | undefined;
}
export type SlotName = string;
export type SlotConstraint = "Required" | "Optional" | (string & {});
export type CustomOrBuiltinSlotTypeName = string;
export type Priority = number;
export type Utterance = string;
export type SlotUtteranceList = string[];
export type ObfuscationSetting = "NONE" | "DEFAULT_OBFUSCATION" | (string & {});
export type SlotDefaultValueString = string;
export interface SlotDefaultValue {
    defaultValue: string;
}
export type SlotDefaultValueList = SlotDefaultValue[];
export interface SlotDefaultValueSpec {
    defaultValueList: SlotDefaultValue[];
}
export interface Slot {
    name: string;
    description?: string | undefined;
    slotConstraint: SlotConstraint;
    slotType?: string | undefined;
    slotTypeVersion?: string | undefined;
    valueElicitationPrompt?: Prompt | undefined;
    priority?: number | undefined;
    sampleUtterances?: string[] | undefined;
    responseCard?: string | undefined;
    obfuscationSetting?: ObfuscationSetting | undefined;
    defaultValueSpec?: SlotDefaultValueSpec | undefined;
}
export type SlotList = Slot[];
export type IntentUtteranceList = string[];
export interface FollowUpPrompt {
    prompt: Prompt;
    rejectionStatement: Statement;
}
export type LambdaARN = string;
export type MessageVersion = string;
export interface CodeHook {
    uri: string;
    messageVersion: string;
}
export type FulfillmentActivityType = "ReturnIntent" | "CodeHook" | (string & {});
export interface FulfillmentActivity {
    type: FulfillmentActivityType;
    codeHook?: CodeHook | undefined;
}
export type BuiltinIntentSignature = string;
export type KendraIndexArn = string;
export type QueryFilterString = string;
export type RoleArn = string;
export interface KendraConfiguration {
    kendraIndex: string;
    queryFilterString?: string | undefined;
    role: string;
}
export type InputContextName = string;
export interface InputContext {
    name: string;
}
export type InputContextList = InputContext[];
export type OutputContextName = string;
export type ContextTimeToLiveInSeconds = number;
export type ContextTurnsToLive = number;
export interface OutputContext {
    name: string;
    timeToLiveInSeconds: number;
    turnsToLive: number;
}
export type OutputContextList = OutputContext[];
export interface CreateIntentVersionResponse {
    name?: string | undefined;
    description?: string | undefined;
    slots?: Slot[] | undefined;
    sampleUtterances?: string[] | undefined;
    confirmationPrompt?: Prompt | undefined;
    rejectionStatement?: Statement | undefined;
    followUpPrompt?: FollowUpPrompt | undefined;
    conclusionStatement?: Statement | undefined;
    dialogCodeHook?: CodeHook | undefined;
    fulfillmentActivity?: FulfillmentActivity | undefined;
    parentIntentSignature?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    checksum?: string | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
}
export type SlotTypeName = string;
export interface CreateSlotTypeVersionRequest {
    name: string;
    checksum?: string | undefined;
}
export type Value = string;
export type SynonymList = string[];
export interface EnumerationValue {
    value: string;
    synonyms?: string[] | undefined;
}
export type EnumerationValues = EnumerationValue[];
export type SlotValueSelectionStrategy = "ORIGINAL_VALUE" | "TOP_RESOLUTION" | (string & {});
export type RegexPattern = string;
export interface SlotTypeRegexConfiguration {
    pattern: string;
}
export interface SlotTypeConfiguration {
    regexConfiguration?: SlotTypeRegexConfiguration | undefined;
}
export type SlotTypeConfigurations = SlotTypeConfiguration[];
export interface CreateSlotTypeVersionResponse {
    name?: string | undefined;
    description?: string | undefined;
    enumerationValues?: EnumerationValue[] | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    checksum?: string | undefined;
    valueSelectionStrategy?: SlotValueSelectionStrategy | undefined;
    parentSlotTypeSignature?: string | undefined;
    slotTypeConfigurations?: SlotTypeConfiguration[] | undefined;
}
export interface DeleteBotRequest {
    name: string;
}
export interface DeleteBotResponse {
}
export type AliasName = string;
export interface DeleteBotAliasRequest {
    name: string;
    botName: string;
}
export interface DeleteBotAliasResponse {
}
export type BotChannelName = string;
export interface DeleteBotChannelAssociationRequest {
    name: string;
    botName: string;
    botAlias: string;
}
export interface DeleteBotChannelAssociationResponse {
}
export type NumericalVersion = string;
export interface DeleteBotVersionRequest {
    name: string;
    version: string;
}
export interface DeleteBotVersionResponse {
}
export interface DeleteIntentRequest {
    name: string;
}
export interface DeleteIntentResponse {
}
export interface DeleteIntentVersionRequest {
    name: string;
    version: string;
}
export interface DeleteIntentVersionResponse {
}
export interface DeleteSlotTypeRequest {
    name: string;
}
export interface DeleteSlotTypeResponse {
}
export interface DeleteSlotTypeVersionRequest {
    name: string;
    version: string;
}
export interface DeleteSlotTypeVersionResponse {
}
export type UserId = string;
export interface DeleteUtterancesRequest {
    botName: string;
    userId: string;
}
export interface DeleteUtterancesResponse {
}
export interface GetBotRequest {
    name: string;
    versionOrAlias: string;
}
export type ConfidenceThreshold = number;
export interface GetBotResponse {
    name?: string | undefined;
    description?: string | undefined;
    intents?: Intent[] | undefined;
    enableModelImprovements?: boolean | undefined;
    nluIntentConfidenceThreshold?: number | undefined;
    clarificationPrompt?: Prompt | undefined;
    abortStatement?: Statement | undefined;
    status?: Status | undefined;
    failureReason?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    voiceId?: string | undefined;
    checksum?: string | undefined;
    version?: string | undefined;
    locale?: Locale | undefined;
    childDirected?: boolean | undefined;
    detectSentiment?: boolean | undefined;
}
export interface GetBotAliasRequest {
    name: string;
    botName: string;
}
export type LogType = "AUDIO" | "TEXT" | (string & {});
export type Destination = "CLOUDWATCH_LOGS" | "S3" | (string & {});
export type KmsKeyArn = string;
export type ResourceArn = string;
export type ResourcePrefix = string;
export interface LogSettingsResponse {
    logType?: LogType | undefined;
    destination?: Destination | undefined;
    kmsKeyArn?: string | undefined;
    resourceArn?: string | undefined;
    resourcePrefix?: string | undefined;
}
export type LogSettingsResponseList = LogSettingsResponse[];
export type IamRoleArn = string;
export interface ConversationLogsResponse {
    logSettings?: LogSettingsResponse[] | undefined;
    iamRoleArn?: string | undefined;
}
export interface GetBotAliasResponse {
    name?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botName?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    checksum?: string | undefined;
    conversationLogs?: ConversationLogsResponse | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface GetBotAliasesRequest {
    botName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    nameContains?: string | undefined;
}
export interface BotAliasMetadata {
    name?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botName?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    checksum?: string | undefined;
    conversationLogs?: ConversationLogsResponse | undefined;
}
export type BotAliasMetadataList = BotAliasMetadata[];
export interface GetBotAliasesResponse {
    BotAliases?: BotAliasMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface GetBotChannelAssociationRequest {
    name: string;
    botName: string;
    botAlias: string;
}
export type ChannelType = "Facebook" | "Slack" | "Twilio-Sms" | "Kik" | (string & {});
export type ChannelConfigurationMap = {
    [key: string]: string | undefined;
};
export type ChannelStatus = "IN_PROGRESS" | "CREATED" | "FAILED" | (string & {});
export interface GetBotChannelAssociationResponse {
    name?: string | undefined;
    description?: string | undefined;
    botAlias?: string | undefined;
    botName?: string | undefined;
    createdDate?: Date | undefined;
    type?: ChannelType | undefined;
    botConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    status?: ChannelStatus | undefined;
    failureReason?: string | undefined;
}
export type AliasNameOrListAll = string;
export interface GetBotChannelAssociationsRequest {
    botName: string;
    botAlias: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    nameContains?: string | undefined;
}
export interface BotChannelAssociation {
    name?: string | undefined;
    description?: string | undefined;
    botAlias?: string | undefined;
    botName?: string | undefined;
    createdDate?: Date | undefined;
    type?: ChannelType | undefined;
    botConfiguration?: {
        [key: string]: string | undefined;
    } | undefined;
    status?: ChannelStatus | undefined;
    failureReason?: string | undefined;
}
export type BotChannelAssociationList = BotChannelAssociation[];
export interface GetBotChannelAssociationsResponse {
    botChannelAssociations?: BotChannelAssociation[] | undefined;
    nextToken?: string | undefined;
}
export interface GetBotsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    nameContains?: string | undefined;
}
export interface BotMetadata {
    name?: string | undefined;
    description?: string | undefined;
    status?: Status | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
}
export type BotMetadataList = BotMetadata[];
export interface GetBotsResponse {
    bots?: BotMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface GetBotVersionsRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GetBotVersionsResponse {
    bots?: BotMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface GetBuiltinIntentRequest {
    signature: string;
}
export type LocaleList = Locale[];
export interface BuiltinIntentSlot {
    name?: string | undefined;
}
export type BuiltinIntentSlotList = BuiltinIntentSlot[];
export interface GetBuiltinIntentResponse {
    signature?: string | undefined;
    supportedLocales?: Locale[] | undefined;
    slots?: BuiltinIntentSlot[] | undefined;
}
export interface GetBuiltinIntentsRequest {
    locale?: Locale | undefined;
    signatureContains?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface BuiltinIntentMetadata {
    signature?: string | undefined;
    supportedLocales?: Locale[] | undefined;
}
export type BuiltinIntentMetadataList = BuiltinIntentMetadata[];
export interface GetBuiltinIntentsResponse {
    intents?: BuiltinIntentMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface GetBuiltinSlotTypesRequest {
    locale?: Locale | undefined;
    signatureContains?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type BuiltinSlotTypeSignature = string;
export interface BuiltinSlotTypeMetadata {
    signature?: string | undefined;
    supportedLocales?: Locale[] | undefined;
}
export type BuiltinSlotTypeMetadataList = BuiltinSlotTypeMetadata[];
export interface GetBuiltinSlotTypesResponse {
    slotTypes?: BuiltinSlotTypeMetadata[] | undefined;
    nextToken?: string | undefined;
}
export type Name = string;
export type ResourceType = "BOT" | "INTENT" | "SLOT_TYPE" | (string & {});
export type ExportType = "ALEXA_SKILLS_KIT" | "LEX" | (string & {});
export interface GetExportRequest {
    name: string;
    version: string;
    resourceType: ResourceType;
    exportType: ExportType;
}
export type ExportStatus = "IN_PROGRESS" | "READY" | "FAILED" | (string & {});
export interface GetExportResponse {
    name?: string | undefined;
    version?: string | undefined;
    resourceType?: ResourceType | undefined;
    exportType?: ExportType | undefined;
    exportStatus?: ExportStatus | undefined;
    failureReason?: string | undefined;
    url?: string | undefined;
}
export interface GetImportRequest {
    importId: string;
}
export type MergeStrategy = "OVERWRITE_LATEST" | "FAIL_ON_CONFLICT" | (string & {});
export type ImportStatus = "IN_PROGRESS" | "COMPLETE" | "FAILED" | (string & {});
export type StringList = string[];
export interface GetImportResponse {
    name?: string | undefined;
    resourceType?: ResourceType | undefined;
    mergeStrategy?: MergeStrategy | undefined;
    importId?: string | undefined;
    importStatus?: ImportStatus | undefined;
    failureReason?: string[] | undefined;
    createdDate?: Date | undefined;
}
export interface GetIntentRequest {
    name: string;
    version: string;
}
export interface GetIntentResponse {
    name?: string | undefined;
    description?: string | undefined;
    slots?: Slot[] | undefined;
    sampleUtterances?: string[] | undefined;
    confirmationPrompt?: Prompt | undefined;
    rejectionStatement?: Statement | undefined;
    followUpPrompt?: FollowUpPrompt | undefined;
    conclusionStatement?: Statement | undefined;
    dialogCodeHook?: CodeHook | undefined;
    fulfillmentActivity?: FulfillmentActivity | undefined;
    parentIntentSignature?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    checksum?: string | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
}
export interface GetIntentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    nameContains?: string | undefined;
}
export interface IntentMetadata {
    name?: string | undefined;
    description?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
}
export type IntentMetadataList = IntentMetadata[];
export interface GetIntentsResponse {
    intents?: IntentMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface GetIntentVersionsRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GetIntentVersionsResponse {
    intents?: IntentMetadata[] | undefined;
    nextToken?: string | undefined;
}
export type MigrationId = string;
export interface GetMigrationRequest {
    migrationId: string;
}
export type V2BotId = string;
export type MigrationStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type MigrationStrategy = "CREATE_NEW" | "UPDATE_EXISTING" | (string & {});
export type MigrationAlertType = "ERROR" | "WARN" | (string & {});
export type MigrationAlertMessage = string;
export type MigrationAlertDetail = string;
export type MigrationAlertDetails = string[];
export type MigrationAlertReferenceURL = string;
export type MigrationAlertReferenceURLs = string[];
export interface MigrationAlert {
    type?: MigrationAlertType | undefined;
    message?: string | undefined;
    details?: string[] | undefined;
    referenceURLs?: string[] | undefined;
}
export type MigrationAlerts = MigrationAlert[];
export interface GetMigrationResponse {
    migrationId?: string | undefined;
    v1BotName?: string | undefined;
    v1BotVersion?: string | undefined;
    v1BotLocale?: Locale | undefined;
    v2BotId?: string | undefined;
    v2BotRole?: string | undefined;
    migrationStatus?: MigrationStatus | undefined;
    migrationStrategy?: MigrationStrategy | undefined;
    migrationTimestamp?: Date | undefined;
    alerts?: MigrationAlert[] | undefined;
}
export type MigrationSortAttribute = "V1_BOT_NAME" | "MIGRATION_DATE_TIME" | (string & {});
export type SortOrder = "ASCENDING" | "DESCENDING" | (string & {});
export interface GetMigrationsRequest {
    sortByAttribute?: MigrationSortAttribute | undefined;
    sortByOrder?: SortOrder | undefined;
    v1BotNameContains?: string | undefined;
    migrationStatusEquals?: MigrationStatus | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface MigrationSummary {
    migrationId?: string | undefined;
    v1BotName?: string | undefined;
    v1BotVersion?: string | undefined;
    v1BotLocale?: Locale | undefined;
    v2BotId?: string | undefined;
    v2BotRole?: string | undefined;
    migrationStatus?: MigrationStatus | undefined;
    migrationStrategy?: MigrationStrategy | undefined;
    migrationTimestamp?: Date | undefined;
}
export type MigrationSummaryList = MigrationSummary[];
export interface GetMigrationsResponse {
    migrationSummaries?: MigrationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface GetSlotTypeRequest {
    name: string;
    version: string;
}
export interface GetSlotTypeResponse {
    name?: string | undefined;
    description?: string | undefined;
    enumerationValues?: EnumerationValue[] | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    checksum?: string | undefined;
    valueSelectionStrategy?: SlotValueSelectionStrategy | undefined;
    parentSlotTypeSignature?: string | undefined;
    slotTypeConfigurations?: SlotTypeConfiguration[] | undefined;
}
export interface GetSlotTypesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    nameContains?: string | undefined;
}
export interface SlotTypeMetadata {
    name?: string | undefined;
    description?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
}
export type SlotTypeMetadataList = SlotTypeMetadata[];
export interface GetSlotTypesResponse {
    slotTypes?: SlotTypeMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface GetSlotTypeVersionsRequest {
    name: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GetSlotTypeVersionsResponse {
    slotTypes?: SlotTypeMetadata[] | undefined;
    nextToken?: string | undefined;
}
export type BotVersions = string[];
export type StatusType = "Detected" | "Missed" | (string & {});
export interface GetUtterancesViewRequest {
    botName: string;
    botVersions: string[];
    statusType: StatusType;
}
export type UtteranceString = string;
export type Count = number;
export interface UtteranceData {
    utteranceString?: string | undefined;
    count?: number | undefined;
    distinctUsers?: number | undefined;
    firstUtteredDate?: Date | undefined;
    lastUtteredDate?: Date | undefined;
}
export type ListOfUtterance = UtteranceData[];
export interface UtteranceList {
    botVersion?: string | undefined;
    utterances?: UtteranceData[] | undefined;
}
export type ListsOfUtterances = UtteranceList[];
export interface GetUtterancesViewResponse {
    botName?: string | undefined;
    utterances?: UtteranceList[] | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export type ProcessBehavior = "SAVE" | "BUILD" | (string & {});
export interface PutBotRequest {
    name: string;
    description?: string | undefined;
    intents?: Intent[] | undefined;
    enableModelImprovements?: boolean | undefined;
    nluIntentConfidenceThreshold?: number | undefined;
    clarificationPrompt?: Prompt | undefined;
    abortStatement?: Statement | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    voiceId?: string | undefined;
    checksum?: string | undefined;
    processBehavior?: ProcessBehavior | undefined;
    locale: Locale;
    childDirected: boolean;
    detectSentiment?: boolean | undefined;
    createVersion?: boolean | undefined;
    tags?: Tag[] | undefined;
}
export interface PutBotResponse {
    name?: string | undefined;
    description?: string | undefined;
    intents?: Intent[] | undefined;
    enableModelImprovements?: boolean | undefined;
    nluIntentConfidenceThreshold?: number | undefined;
    clarificationPrompt?: Prompt | undefined;
    abortStatement?: Statement | undefined;
    status?: Status | undefined;
    failureReason?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    idleSessionTTLInSeconds?: number | undefined;
    voiceId?: string | undefined;
    checksum?: string | undefined;
    version?: string | undefined;
    locale?: Locale | undefined;
    childDirected?: boolean | undefined;
    createVersion?: boolean | undefined;
    detectSentiment?: boolean | undefined;
    tags?: Tag[] | undefined;
}
export interface LogSettingsRequest {
    logType: LogType;
    destination: Destination;
    kmsKeyArn?: string | undefined;
    resourceArn: string;
}
export type LogSettingsRequestList = LogSettingsRequest[];
export interface ConversationLogsRequest {
    logSettings: LogSettingsRequest[];
    iamRoleArn: string;
}
export interface PutBotAliasRequest {
    name: string;
    description?: string | undefined;
    botVersion: string;
    botName: string;
    checksum?: string | undefined;
    conversationLogs?: ConversationLogsRequest | undefined;
    tags?: Tag[] | undefined;
}
export interface PutBotAliasResponse {
    name?: string | undefined;
    description?: string | undefined;
    botVersion?: string | undefined;
    botName?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    checksum?: string | undefined;
    conversationLogs?: ConversationLogsResponse | undefined;
    tags?: Tag[] | undefined;
}
export interface PutIntentRequest {
    name: string;
    description?: string | undefined;
    slots?: Slot[] | undefined;
    sampleUtterances?: string[] | undefined;
    confirmationPrompt?: Prompt | undefined;
    rejectionStatement?: Statement | undefined;
    followUpPrompt?: FollowUpPrompt | undefined;
    conclusionStatement?: Statement | undefined;
    dialogCodeHook?: CodeHook | undefined;
    fulfillmentActivity?: FulfillmentActivity | undefined;
    parentIntentSignature?: string | undefined;
    checksum?: string | undefined;
    createVersion?: boolean | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
}
export interface PutIntentResponse {
    name?: string | undefined;
    description?: string | undefined;
    slots?: Slot[] | undefined;
    sampleUtterances?: string[] | undefined;
    confirmationPrompt?: Prompt | undefined;
    rejectionStatement?: Statement | undefined;
    followUpPrompt?: FollowUpPrompt | undefined;
    conclusionStatement?: Statement | undefined;
    dialogCodeHook?: CodeHook | undefined;
    fulfillmentActivity?: FulfillmentActivity | undefined;
    parentIntentSignature?: string | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    checksum?: string | undefined;
    createVersion?: boolean | undefined;
    kendraConfiguration?: KendraConfiguration | undefined;
    inputContexts?: InputContext[] | undefined;
    outputContexts?: OutputContext[] | undefined;
}
export interface PutSlotTypeRequest {
    name: string;
    description?: string | undefined;
    enumerationValues?: EnumerationValue[] | undefined;
    checksum?: string | undefined;
    valueSelectionStrategy?: SlotValueSelectionStrategy | undefined;
    createVersion?: boolean | undefined;
    parentSlotTypeSignature?: string | undefined;
    slotTypeConfigurations?: SlotTypeConfiguration[] | undefined;
}
export interface PutSlotTypeResponse {
    name?: string | undefined;
    description?: string | undefined;
    enumerationValues?: EnumerationValue[] | undefined;
    lastUpdatedDate?: Date | undefined;
    createdDate?: Date | undefined;
    version?: string | undefined;
    checksum?: string | undefined;
    valueSelectionStrategy?: SlotValueSelectionStrategy | undefined;
    createVersion?: boolean | undefined;
    parentSlotTypeSignature?: string | undefined;
    slotTypeConfigurations?: SlotTypeConfiguration[] | undefined;
}
export interface StartImportRequest {
    payload: Uint8Array;
    resourceType: ResourceType;
    mergeStrategy: MergeStrategy;
    tags?: Tag[] | undefined;
}
export interface StartImportResponse {
    name?: string | undefined;
    resourceType?: ResourceType | undefined;
    mergeStrategy?: MergeStrategy | undefined;
    importId?: string | undefined;
    importStatus?: ImportStatus | undefined;
    tags?: Tag[] | undefined;
    createdDate?: Date | undefined;
}
export type V2BotName = string;
export interface StartMigrationRequest {
    v1BotName: string;
    v1BotVersion: string;
    v2BotName: string;
    v2BotRole: string;
    migrationStrategy: MigrationStrategy;
}
export interface StartMigrationResponse {
    v1BotName?: string | undefined;
    v1BotVersion?: string | undefined;
    v1BotLocale?: Locale | undefined;
    v2BotId?: string | undefined;
    v2BotRole?: string | undefined;
    migrationId?: string | undefined;
    migrationStrategy?: MigrationStrategy | undefined;
    migrationTimestamp?: Date | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ReferenceType = "Intent" | "Bot" | "BotAlias" | "BotChannel" | (string & {});
export interface ResourceReference {
    name?: string | undefined;
    version?: string | undefined;
}
export type CreateBotVersionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | PreconditionFailedException | CommonErrors;
/**
 * Creates a new version of the bot based on the `$LATEST`
 * version. If the `$LATEST` version of this resource hasn't
 * changed since you created the last version, Amazon Lex doesn't create a new
 * version. It returns the last created version.
 *
 * You can update only the `$LATEST` version of the bot.
 * You can't update the numbered versions that you create with the
 * `CreateBotVersion` operation.
 *
 * When you create the first version of a bot, Amazon Lex sets the version
 * to 1. Subsequent versions increment by 1. For more information, see versioning-intro.
 *
 * This operation requires permission for the
 * `lex:CreateBotVersion` action.
 */
export declare const createBotVersion: API.OperationMethod<CreateBotVersionRequest & RegionInput, CreateBotVersionResponse, CreateBotVersionError, Credentials | HttpClient.HttpClient>;
export type CreateIntentVersionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | PreconditionFailedException | CommonErrors;
/**
 * Creates a new version of an intent based on the
 * `$LATEST` version of the intent. If the `$LATEST`
 * version of this intent hasn't changed since you last updated it, Amazon Lex
 * doesn't create a new version. It returns the last version you
 * created.
 *
 * You can update only the `$LATEST` version of the
 * intent. You can't update the numbered versions that you create with the
 * `CreateIntentVersion` operation.
 *
 * When you create a version of an intent, Amazon Lex sets the version to
 * 1. Subsequent versions increment by 1. For more information, see versioning-intro.
 *
 * This operation requires permissions to perform the
 * `lex:CreateIntentVersion` action.
 */
export declare const createIntentVersion: API.OperationMethod<CreateIntentVersionRequest & RegionInput, CreateIntentVersionResponse, CreateIntentVersionError, Credentials | HttpClient.HttpClient>;
export type CreateSlotTypeVersionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | PreconditionFailedException | CommonErrors;
/**
 * Creates a new version of a slot type based on the
 * `$LATEST` version of the specified slot type. If the
 * `$LATEST` version of this resource has not changed since the
 * last version that you created, Amazon Lex doesn't create a new version. It
 * returns the last version that you created.
 *
 * You can update only the `$LATEST` version of a slot
 * type. You can't update the numbered versions that you create with the
 * `CreateSlotTypeVersion` operation.
 *
 * When you create a version of a slot type, Amazon Lex sets the version to
 * 1. Subsequent versions increment by 1. For more information, see versioning-intro.
 *
 * This operation requires permissions for the
 * `lex:CreateSlotTypeVersion` action.
 */
export declare const createSlotTypeVersion: API.OperationMethod<CreateSlotTypeVersionRequest & RegionInput, CreateSlotTypeVersionResponse, CreateSlotTypeVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteBotError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes all versions of the bot, including the `$LATEST`
 * version. To delete a specific version of the bot, use the DeleteBotVersion operation. The `DeleteBot`
 * operation doesn't immediately remove the bot schema. Instead, it is marked
 * for deletion and removed later.
 *
 * Amazon Lex stores utterances indefinitely for improving the ability of
 * your bot to respond to user inputs. These utterances are not removed when
 * the bot is deleted. To remove the utterances, use the DeleteUtterances operation.
 *
 * If a bot has an alias, you can't delete it. Instead, the
 * `DeleteBot` operation returns a
 * `ResourceInUseException` exception that includes a reference
 * to the alias that refers to the bot. To remove the reference to the bot,
 * delete the alias. If you get the same exception again, delete the
 * referring alias until the `DeleteBot` operation is
 * successful.
 *
 * This operation requires permissions for the
 * `lex:DeleteBot` action.
 */
export declare const deleteBot: API.OperationMethod<DeleteBotRequest & RegionInput, DeleteBotResponse, DeleteBotError, Credentials | HttpClient.HttpClient>;
export type DeleteBotAliasError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes an alias for the specified bot.
 *
 * You can't delete an alias that is used in the association between a
 * bot and a messaging channel. If an alias is used in a channel association,
 * the `DeleteBot` operation returns a
 * `ResourceInUseException` exception that includes a reference
 * to the channel association that refers to the bot. You can remove the
 * reference to the alias by deleting the channel association. If you get the
 * same exception again, delete the referring association until the
 * `DeleteBotAlias` operation is successful.
 */
export declare const deleteBotAlias: API.OperationMethod<DeleteBotAliasRequest & RegionInput, DeleteBotAliasResponse, DeleteBotAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteBotChannelAssociationError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Deletes the association between an Amazon Lex bot and a messaging
 * platform.
 *
 * This operation requires permission for the
 * `lex:DeleteBotChannelAssociation` action.
 */
export declare const deleteBotChannelAssociation: API.OperationMethod<DeleteBotChannelAssociationRequest & RegionInput, DeleteBotChannelAssociationResponse, DeleteBotChannelAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteBotVersionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes a specific version of a bot. To delete all versions of a
 * bot, use the DeleteBot operation.
 *
 * This operation requires permissions for the
 * `lex:DeleteBotVersion` action.
 */
export declare const deleteBotVersion: API.OperationMethod<DeleteBotVersionRequest & RegionInput, DeleteBotVersionResponse, DeleteBotVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteIntentError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes all versions of the intent, including the
 * `$LATEST` version. To delete a specific version of the
 * intent, use the DeleteIntentVersion operation.
 *
 * You can delete a version of an intent only if it is not
 * referenced. To delete an intent that is referred to in one or more bots
 * (see how-it-works), you must remove those references
 * first.
 *
 * If you get the `ResourceInUseException` exception, it
 * provides an example reference that shows where the intent is referenced.
 * To remove the reference to the intent, either update the bot or delete
 * it. If you get the same exception when you attempt to delete the intent
 * again, repeat until the intent has no references and the call to
 * `DeleteIntent` is successful.
 *
 * This operation requires permission for the
 * `lex:DeleteIntent` action.
 */
export declare const deleteIntent: API.OperationMethod<DeleteIntentRequest & RegionInput, DeleteIntentResponse, DeleteIntentError, Credentials | HttpClient.HttpClient>;
export type DeleteIntentVersionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes a specific version of an intent. To delete all versions of
 * a intent, use the DeleteIntent operation.
 *
 * This operation requires permissions for the
 * `lex:DeleteIntentVersion` action.
 */
export declare const deleteIntentVersion: API.OperationMethod<DeleteIntentVersionRequest & RegionInput, DeleteIntentVersionResponse, DeleteIntentVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteSlotTypeError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes all versions of the slot type, including the
 * `$LATEST` version. To delete a specific version of the slot
 * type, use the DeleteSlotTypeVersion operation.
 *
 * You can delete a version of a slot type only if it is not
 * referenced. To delete a slot type that is referred to in one or more
 * intents, you must remove those references first.
 *
 * If you get the `ResourceInUseException` exception,
 * the exception provides an example reference that shows the intent where
 * the slot type is referenced. To remove the reference to the slot type,
 * either update the intent or delete it. If you get the same exception
 * when you attempt to delete the slot type again, repeat until the slot
 * type has no references and the `DeleteSlotType` call is
 * successful.
 *
 * This operation requires permission for the
 * `lex:DeleteSlotType` action.
 */
export declare const deleteSlotType: API.OperationMethod<DeleteSlotTypeRequest & RegionInput, DeleteSlotTypeResponse, DeleteSlotTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteSlotTypeVersionError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | ResourceInUseException | CommonErrors;
/**
 * Deletes a specific version of a slot type. To delete all versions
 * of a slot type, use the DeleteSlotType operation.
 *
 * This operation requires permissions for the
 * `lex:DeleteSlotTypeVersion` action.
 */
export declare const deleteSlotTypeVersion: API.OperationMethod<DeleteSlotTypeVersionRequest & RegionInput, DeleteSlotTypeVersionResponse, DeleteSlotTypeVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteUtterancesError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Deletes stored utterances.
 *
 * Amazon Lex stores the utterances that users send to your bot. Utterances
 * are stored for 15 days for use with the GetUtterancesView operation, and then stored indefinitely for use in improving the
 * ability of your bot to respond to user input.
 *
 * Use the `DeleteUtterances` operation to manually delete
 * stored utterances for a specific user. When you use the
 * `DeleteUtterances` operation, utterances stored for improving
 * your bot's ability to respond to user input are deleted immediately.
 * Utterances stored for use with the `GetUtterancesView`
 * operation are deleted after 15 days.
 *
 * This operation requires permissions for the
 * `lex:DeleteUtterances` action.
 */
export declare const deleteUtterances: API.OperationMethod<DeleteUtterancesRequest & RegionInput, DeleteUtterancesResponse, DeleteUtterancesError, Credentials | HttpClient.HttpClient>;
export type GetBotError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns metadata information for a specific bot. You must provide
 * the bot name and the bot version or alias.
 *
 * This operation requires permissions for the
 * `lex:GetBot` action.
 */
export declare const getBot: API.OperationMethod<GetBotRequest & RegionInput, GetBotResponse, GetBotError, Credentials | HttpClient.HttpClient>;
export type GetBotAliasError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns information about an Amazon Lex bot alias. For more information
 * about aliases, see versioning-aliases.
 *
 * This operation requires permissions for the
 * `lex:GetBotAlias` action.
 */
export declare const getBotAlias: API.OperationMethod<GetBotAliasRequest & RegionInput, GetBotAliasResponse, GetBotAliasError, Credentials | HttpClient.HttpClient>;
export type GetBotAliasesError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Returns a list of aliases for a specified Amazon Lex bot.
 *
 * This operation requires permissions for the
 * `lex:GetBotAliases` action.
 */
export declare const getBotAliases: API.PaginatedOperationMethod<GetBotAliasesRequest & RegionInput, GetBotAliasesResponse, GetBotAliasesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBotChannelAssociationError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns information about the association between an Amazon Lex bot and
 * a messaging platform.
 *
 * This operation requires permissions for the
 * `lex:GetBotChannelAssociation` action.
 */
export declare const getBotChannelAssociation: API.OperationMethod<GetBotChannelAssociationRequest & RegionInput, GetBotChannelAssociationResponse, GetBotChannelAssociationError, Credentials | HttpClient.HttpClient>;
export type GetBotChannelAssociationsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Returns a list of all of the channels associated with the
 * specified bot.
 *
 * The `GetBotChannelAssociations` operation requires
 * permissions for the `lex:GetBotChannelAssociations`
 * action.
 */
export declare const getBotChannelAssociations: API.PaginatedOperationMethod<GetBotChannelAssociationsRequest & RegionInput, GetBotChannelAssociationsResponse, GetBotChannelAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBotsError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns bot information as follows:
 *
 * - If you provide the `nameContains` field, the
 * response includes information for the `$LATEST` version of
 * all bots whose name contains the specified string.
 *
 * - If you don't specify the `nameContains` field, the
 * operation returns information about the `$LATEST` version
 * of all of your bots.
 *
 * This operation requires permission for the `lex:GetBots`
 * action.
 */
export declare const getBots: API.PaginatedOperationMethod<GetBotsRequest & RegionInput, GetBotsResponse, GetBotsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBotVersionsError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Gets information about all of the versions of a bot.
 *
 * The `GetBotVersions` operation returns a
 * `BotMetadata` object for each version of a bot. For example,
 * if a bot has three numbered versions, the `GetBotVersions`
 * operation returns four `BotMetadata` objects in the response,
 * one for each numbered version and one for the `$LATEST`
 * version.
 *
 * The `GetBotVersions` operation always returns at least
 * one version, the `$LATEST` version.
 *
 * This operation requires permissions for the
 * `lex:GetBotVersions` action.
 */
export declare const getBotVersions: API.PaginatedOperationMethod<GetBotVersionsRequest & RegionInput, GetBotVersionsResponse, GetBotVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBuiltinIntentError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns information about a built-in intent.
 *
 * This operation requires permission for the
 * `lex:GetBuiltinIntent` action.
 */
export declare const getBuiltinIntent: API.OperationMethod<GetBuiltinIntentRequest & RegionInput, GetBuiltinIntentResponse, GetBuiltinIntentError, Credentials | HttpClient.HttpClient>;
export type GetBuiltinIntentsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Gets a list of built-in intents that meet the specified
 * criteria.
 *
 * This operation requires permission for the
 * `lex:GetBuiltinIntents` action.
 */
export declare const getBuiltinIntents: API.PaginatedOperationMethod<GetBuiltinIntentsRequest & RegionInput, GetBuiltinIntentsResponse, GetBuiltinIntentsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetBuiltinSlotTypesError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Gets a list of built-in slot types that meet the specified
 * criteria.
 *
 * For a list of built-in slot types, see Slot Type Reference in the Alexa Skills
 * Kit.
 *
 * This operation requires permission for the
 * `lex:GetBuiltInSlotTypes` action.
 */
export declare const getBuiltinSlotTypes: API.PaginatedOperationMethod<GetBuiltinSlotTypesRequest & RegionInput, GetBuiltinSlotTypesResponse, GetBuiltinSlotTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetExportError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Exports the contents of a Amazon Lex resource in a specified format.
 */
export declare const getExport: API.OperationMethod<GetExportRequest & RegionInput, GetExportResponse, GetExportError, Credentials | HttpClient.HttpClient>;
export type GetImportError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Gets information about an import job started with the
 * `StartImport` operation.
 */
export declare const getImport: API.OperationMethod<GetImportRequest & RegionInput, GetImportResponse, GetImportError, Credentials | HttpClient.HttpClient>;
export type GetIntentError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns information about an intent. In addition to the intent
 * name, you must specify the intent version.
 *
 * This operation requires permissions to perform the
 * `lex:GetIntent` action.
 */
export declare const getIntent: API.OperationMethod<GetIntentRequest & RegionInput, GetIntentResponse, GetIntentError, Credentials | HttpClient.HttpClient>;
export type GetIntentsError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns intent information as follows:
 *
 * - If you specify the `nameContains` field, returns the
 * `$LATEST` version of all intents that contain the
 * specified string.
 *
 * - If you don't specify the `nameContains` field,
 * returns information about the `$LATEST` version of all
 * intents.
 *
 * The operation requires permission for the
 * `lex:GetIntents` action.
 */
export declare const getIntents: API.PaginatedOperationMethod<GetIntentsRequest & RegionInput, GetIntentsResponse, GetIntentsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetIntentVersionsError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Gets information about all of the versions of an intent.
 *
 * The `GetIntentVersions` operation returns an
 * `IntentMetadata` object for each version of an intent. For
 * example, if an intent has three numbered versions, the
 * `GetIntentVersions` operation returns four
 * `IntentMetadata` objects in the response, one for each
 * numbered version and one for the `$LATEST` version.
 *
 * The `GetIntentVersions` operation always returns at
 * least one version, the `$LATEST` version.
 *
 * This operation requires permissions for the
 * `lex:GetIntentVersions` action.
 */
export declare const getIntentVersions: API.PaginatedOperationMethod<GetIntentVersionsRequest & RegionInput, GetIntentVersionsResponse, GetIntentVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetMigrationError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Provides details about an ongoing or complete migration from an
 * Amazon Lex V1 bot to an Amazon Lex V2 bot. Use this operation to view the migration
 * alerts and warnings related to the migration.
 */
export declare const getMigration: API.OperationMethod<GetMigrationRequest & RegionInput, GetMigrationResponse, GetMigrationError, Credentials | HttpClient.HttpClient>;
export type GetMigrationsError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Gets a list of migrations between Amazon Lex V1 and Amazon Lex V2.
 */
export declare const getMigrations: API.PaginatedOperationMethod<GetMigrationsRequest & RegionInput, GetMigrationsResponse, GetMigrationsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSlotTypeError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns information about a specific version of a slot type. In
 * addition to specifying the slot type name, you must specify the slot type
 * version.
 *
 * This operation requires permissions for the
 * `lex:GetSlotType` action.
 */
export declare const getSlotType: API.OperationMethod<GetSlotTypeRequest & RegionInput, GetSlotTypeResponse, GetSlotTypeError, Credentials | HttpClient.HttpClient>;
export type GetSlotTypesError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Returns slot type information as follows:
 *
 * - If you specify the `nameContains` field, returns the
 * `$LATEST` version of all slot types that contain the
 * specified string.
 *
 * - If you don't specify the `nameContains` field,
 * returns information about the `$LATEST` version of all slot
 * types.
 *
 * The operation requires permission for the
 * `lex:GetSlotTypes` action.
 */
export declare const getSlotTypes: API.PaginatedOperationMethod<GetSlotTypesRequest & RegionInput, GetSlotTypesResponse, GetSlotTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type GetSlotTypeVersionsError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Gets information about all versions of a slot type.
 *
 * The `GetSlotTypeVersions` operation returns a
 * `SlotTypeMetadata` object for each version of a slot type.
 * For example, if a slot type has three numbered versions, the
 * `GetSlotTypeVersions` operation returns four
 * `SlotTypeMetadata` objects in the response, one for each
 * numbered version and one for the `$LATEST` version.
 *
 * The `GetSlotTypeVersions` operation always returns at
 * least one version, the `$LATEST` version.
 *
 * This operation requires permissions for the
 * `lex:GetSlotTypeVersions` action.
 */
export declare const getSlotTypeVersions: API.PaginatedOperationMethod<GetSlotTypeVersionsRequest & RegionInput, GetSlotTypeVersionsResponse, GetSlotTypeVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUtterancesViewError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Use the `GetUtterancesView` operation to get information
 * about the utterances that your users have made to your bot. You can use
 * this list to tune the utterances that your bot responds to.
 *
 * For example, say that you have created a bot to order flowers.
 * After your users have used your bot for a while, use the
 * `GetUtterancesView` operation to see the requests that they
 * have made and whether they have been successful. You might find that the
 * utterance "I want flowers" is not being recognized. You could add this
 * utterance to the `OrderFlowers` intent so that your bot
 * recognizes that utterance.
 *
 * After you publish a new version of a bot, you can get information
 * about the old version and the new so that you can compare the performance
 * across the two versions.
 *
 * Utterance statistics are generated once a day. Data is available
 * for the last 15 days. You can request information for up to 5 versions of
 * your bot in each request. Amazon Lex returns the most frequent utterances
 * received by the bot in the last 15 days. The response contains information
 * about a maximum of 100 utterances for each version.
 *
 * If you set `childDirected` field to true when you
 * created your bot, if you are using slot obfuscation with one or more
 * slots, or if you opted out of participating in improving Amazon Lex, utterances
 * are not available.
 *
 * This operation requires permissions for the
 * `lex:GetUtterancesView` action.
 */
export declare const getUtterancesView: API.OperationMethod<GetUtterancesViewRequest & RegionInput, GetUtterancesViewResponse, GetUtterancesViewError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Gets a list of tags associated with the specified resource. Only bots,
 * bot aliases, and bot channels can have tags associated with them.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutBotError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | PreconditionFailedException | CommonErrors;
/**
 * Creates an Amazon Lex conversational bot or replaces an existing bot.
 * When you create or update a bot you are only required to specify a name, a
 * locale, and whether the bot is directed toward children under age 13. You
 * can use this to add intents later, or to remove intents from an existing
 * bot. When you create a bot with the minimum information, the bot is
 * created or updated but Amazon Lex returns the `` response
 * `FAILED`. You can build the bot after you add one or more
 * intents. For more information about Amazon Lex bots, see how-it-works.
 *
 * If you specify the name of an existing bot, the fields in the
 * request replace the existing values in the `$LATEST` version of
 * the bot. Amazon Lex removes any fields that you don't provide values for in the
 * request, except for the `idleTTLInSeconds` and
 * `privacySettings` fields, which are set to their default
 * values. If you don't specify values for required fields, Amazon Lex throws an
 * exception.
 *
 * This operation requires permissions for the `lex:PutBot`
 * action. For more information, see security-iam.
 */
export declare const putBot: API.OperationMethod<PutBotRequest & RegionInput, PutBotResponse, PutBotError, Credentials | HttpClient.HttpClient>;
export type PutBotAliasError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | PreconditionFailedException | CommonErrors;
/**
 * Creates an alias for the specified version of the bot or replaces
 * an alias for the specified bot. To change the version of the bot that the
 * alias points to, replace the alias. For more information about aliases,
 * see versioning-aliases.
 *
 * This operation requires permissions for the
 * `lex:PutBotAlias` action.
 */
export declare const putBotAlias: API.OperationMethod<PutBotAliasRequest & RegionInput, PutBotAliasResponse, PutBotAliasError, Credentials | HttpClient.HttpClient>;
export type PutIntentError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | PreconditionFailedException | CommonErrors;
/**
 * Creates an intent or replaces an existing intent.
 *
 * To define the interaction between the user and your bot, you use
 * one or more intents. For a pizza ordering bot, for example, you would
 * create an `OrderPizza` intent.
 *
 * To create an intent or replace an existing intent, you must provide
 * the following:
 *
 * - Intent name. For example, `OrderPizza`.
 *
 * - Sample utterances. For example, "Can I order a pizza, please."
 * and "I want to order a pizza."
 *
 * - Information to be gathered. You specify slot types for the
 * information that your bot will request from the user. You can specify
 * standard slot types, such as a date or a time, or custom slot types
 * such as the size and crust of a pizza.
 *
 * - How the intent will be fulfilled. You can provide a Lambda
 * function or configure the intent to return the intent information to
 * the client application. If you use a Lambda function, when all of the
 * intent information is available, Amazon Lex invokes your Lambda function.
 * If you configure your intent to return the intent information to the
 * client application.
 *
 * You can specify other optional information in the request, such
 * as:
 *
 * - A confirmation prompt to ask the user to confirm an intent. For
 * example, "Shall I order your pizza?"
 *
 * - A conclusion statement to send to the user after the intent has
 * been fulfilled. For example, "I placed your pizza order."
 *
 * - A follow-up prompt that asks the user for additional activity.
 * For example, asking "Do you want to order a drink with your
 * pizza?"
 *
 * If you specify an existing intent name to update the intent, Amazon Lex
 * replaces the values in the `$LATEST` version of the intent with
 * the values in the request. Amazon Lex removes fields that you don't provide in
 * the request. If you don't specify the required fields, Amazon Lex throws an
 * exception. When you update the `$LATEST` version of an intent,
 * the `status` field of any bot that uses the
 * `$LATEST` version of the intent is set to
 * `NOT_BUILT`.
 *
 * For more information, see how-it-works.
 *
 * This operation requires permissions for the
 * `lex:PutIntent` action.
 */
export declare const putIntent: API.OperationMethod<PutIntentRequest & RegionInput, PutIntentResponse, PutIntentError, Credentials | HttpClient.HttpClient>;
export type PutSlotTypeError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | PreconditionFailedException | CommonErrors;
/**
 * Creates a custom slot type or replaces an existing custom slot
 * type.
 *
 * To create a custom slot type, specify a name for the slot type and
 * a set of enumeration values, which are the values that a slot of this type
 * can assume. For more information, see how-it-works.
 *
 * If you specify the name of an existing slot type, the fields in the
 * request replace the existing values in the `$LATEST` version of
 * the slot type. Amazon Lex removes the fields that you don't provide in the
 * request. If you don't specify required fields, Amazon Lex throws an exception.
 * When you update the `$LATEST` version of a slot type, if a bot
 * uses the `$LATEST` version of an intent that contains the slot
 * type, the bot's `status` field is set to
 * `NOT_BUILT`.
 *
 * This operation requires permissions for the
 * `lex:PutSlotType` action.
 */
export declare const putSlotType: API.OperationMethod<PutSlotTypeRequest & RegionInput, PutSlotTypeResponse, PutSlotTypeError, Credentials | HttpClient.HttpClient>;
export type StartImportError = BadRequestException | InternalFailureException | LimitExceededException | CommonErrors;
/**
 * Starts a job to import a resource to Amazon Lex.
 */
export declare const startImport: API.OperationMethod<StartImportRequest & RegionInput, StartImportResponse, StartImportError, Credentials | HttpClient.HttpClient>;
export type StartMigrationError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Starts migrating a bot from Amazon Lex V1 to Amazon Lex V2. Migrate your bot when
 * you want to take advantage of the new features of Amazon Lex V2.
 *
 * For more information, see Migrating a bot in the Amazon Lex
 * developer guide.
 */
export declare const startMigration: API.OperationMethod<StartMigrationRequest & RegionInput, StartMigrationResponse, StartMigrationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Adds the specified tags to the specified resource. If a tag key
 * already exists, the existing value is replaced with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | ConflictException | InternalFailureException | LimitExceededException | NotFoundException | CommonErrors;
/**
 * Removes tags from a bot, bot alias or bot channel.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=lex-model-building-service.d.ts.map