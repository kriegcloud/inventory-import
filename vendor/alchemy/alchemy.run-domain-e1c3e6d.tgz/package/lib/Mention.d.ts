/**
 * A model's commands, views, streams and queries as things an `AI.Process`
 * can mention, and what turns one of an Api's calls into a tool.
 *
 * Nothing here imports `@alchemy.run/ai`: a mention is an object with a
 * well-known key, and what a session acts as is a service read by its key.
 *
 * @module
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Headers from "effect/http/Headers";
import * as Schema from "effect/Schema";
import type * as Model from "./Model.ts";
import { type Operation } from "./ReadRpcs.ts";
import * as RequestContext from "./RequestContext.ts";
/**
 * The tool's name: `<api>_<name>_<operation>`, with any other character
 * than a letter, digit, `_` or `-` replaced by `_`.
 */
export declare const toolName: (op: {
    readonly api: string;
    readonly name: string;
    readonly operation: string;
}) => string;
/**
 * What the model reads about the tool: a command's `description`, or a
 * sentence for the call; a read follows its sentence with its entry's
 * `description` (`Get the current AccountSummary of a key. An account's
 * balance and owner.`).
 */
export declare const toolDescription: (op: Operation) => string;
/**
 * A call that returns once. A stream (`watch`, `events`) is not one tool
 * result: it stays on the Api's own clients.
 */
export declare const isToolCall: (op: Operation) => boolean;
export type Client = Record<string, unknown>;
/**
 * Send one call through the Api's client: a command takes its input
 * and command id; a query its input and options; a read its key and options.
 */
export declare const invoke: (client: Client, op: Operation, payload: unknown, headers?: Headers.Input) => Effect.Effect<unknown, unknown, never>;
/** One call's name, what a model is told of it, and whether its result is wrapped. */
export declare const specOf: (api: string, op: Operation) => {
    name: string;
    wrapped: boolean;
    spec: {
        description: string;
        parameters: Schema.toCodecJson<Schema.Top>;
        success: Schema.toCodecJson<Schema.Top>;
        failure: Schema.toCodecJson<Schema.Top>;
    };
};
/** Which of a model's entries a mention gives, by name. */
export interface Entries {
    readonly commands?: ReadonlyArray<string>;
    readonly views?: ReadonlyArray<string>;
    readonly streams?: ReadonlyArray<string>;
    readonly queries?: ReadonlyArray<string>;
}
/**
 * Something an `AI.Process` can mention: its name in the prose, the tools
 * mentioning it gives, and how what a session acts as is stored. `R` is
 * what running the process then requires, and `As` what a session must be
 * started as.
 */
export interface Mention<R = never, As = never> {
    readonly "~alchemy/AI/Mention": {
        readonly name: string;
        readonly tools: Effect.Effect<ReadonlyArray<never>, never, R>;
        /** Absent when nothing mentioned is behind a middleware. */
        readonly as: ((context: Context.Context<never>) => Effect.Effect<RequestContext.Json>) | undefined;
    };
    /** Phantom: what a session of a process that mentions this must be started as. */
    readonly "~as"?: As;
}
/**
 * Some of a model's entries as a mention. Each call is a tool named
 * `<model>_<name>_<operation>`, with the call's own schemas; a rejection
 * comes back to the model as the tool's failure.
 *
 * A call runs the middleware of what it calls, as an Api's server does.
 * A middleware with a Layer where the process runs is run with it. One
 * without, which only says who is calling, is answered by what the session
 * acts as: the request context it was started with is provided in its
 * place. A command is sent under the id of the tool call that asked for
 * it, so the model never chooses a command's id.
 *
 * @internal
 */
export declare const of: (model: Model.Any, entries: Entries) => Mention<unknown, unknown>;
//# sourceMappingURL=Mention.d.ts.map