import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Nuke from "../Nuke.ts";
import type { ProviderMode } from "../ProviderMode.ts";
import type { ConfiguredStack } from "../Stack.ts";
import { type ConfigOptions } from "./Operations.ts";
export interface ScanOptions extends ConfigOptions {
    /** The stack whose providers are scanned; nothing reads its state. */
    readonly stack: ConfiguredStack<unknown, unknown>;
    /** Scan the emulators `alchemy dev` runs instead of the real cloud. */
    readonly dev?: boolean;
    /** Provider-id globs to include. Omitted means every provider. */
    readonly include?: ReadonlyArray<string>;
    /** Provider-id globs to exclude. Applied after `include`. */
    readonly exclude?: ReadonlyArray<string>;
    /** Providers scanned in parallel. @default 16 */
    readonly concurrency?: number | "unbounded";
    /** Timeout for each provider's `list`. @default 60 */
    readonly providerTimeoutSeconds?: number;
}
/** One discovered cloud object, bound to the provider that can delete it. */
export type Resource = Nuke.Target;
/** Everything a stack's providers can see; only {@link execute} deletes it. */
export interface NukeScan {
    /** `local` when the scan ran with `dev: true`, otherwise `live`. */
    readonly mode: ProviderMode;
    readonly resources: ReadonlyArray<Resource>;
    /** Providers whose `list` failed; they contribute no resources. */
    readonly failures: ReadonlyArray<Nuke.ProviderFailure>;
    /**
     * The built provider context; lives in the caller's `Scope`.
     * @internal {@link execute} deletes under it.
     */
    readonly context: Context.Context<never>;
}
/**
 * List everything the stack's registered providers can see in the account.
 * The stack is imported only for its providers: nothing here reads state or
 * is scoped to a stage.
 */
export declare const scan: (options: ScanOptions) => Effect.Effect<{
    mode: ProviderMode;
    resources: readonly Nuke.Target[];
    failures: readonly Nuke.ProviderFailure[];
    context: Context.Context<import("../AdoptPolicy.ts").AdoptPolicy | import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | import("../index.ts").AuthProviders | import("../Stack.ts").Stack | import("../Stage.ts").Stage | import("../State/State.ts").State>;
}, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError, import("../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | import("effect/Path").Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
export interface ExecuteOptions {
    /** The scan whose resources are deleted. */
    readonly scan: NukeScan;
    /** The subset of `scan.resources` to delete. @default every planned resource */
    readonly resources?: ReadonlyArray<Resource>;
    /**
     * `coordinated` deletes in passes until one makes no progress;
     * `independent` retries each resource on its own.
     * @default { type: "coordinated" }
     */
    readonly strategy?: Nuke.Strategy;
    /** Providers deleted in parallel. @default 16 */
    readonly concurrency?: number | "unbounded";
    /** Timeout for each `delete`. @default 120 */
    readonly providerTimeoutSeconds?: number;
}
export type Result = Nuke.Result;
/**
 * Permanently delete scanned resources. Progress is emitted through
 * events: `apply.resource.status` and `nuke.*` events.
 */
export declare const execute: (options: ExecuteOptions) => Effect.Effect<Nuke.Result, never, never>;
//# sourceMappingURL=Nuke.d.ts.map