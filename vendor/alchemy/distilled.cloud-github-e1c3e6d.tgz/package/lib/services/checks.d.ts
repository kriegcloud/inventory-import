import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. */
export type CreateRequestStatus = "queued" | "in_progress" | "completed" | "waiting" | "requested" | "pending";
/** **Required if you provide `completed_at` or a `status` of `completed`**. The final conclusion of the check. **Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this. */
export type CreateRequestConclusion = "action_required" | "cancelled" | "failure" | "neutral" | "success" | "skipped" | "stale" | "timed_out";
/** The level of the annotation. */
export type CreateRequestOutputAnnotationsItemAnnotationLevel = "notice" | "warning" | "failure";
export interface CreateRequestOutputAnnotationsItem {
    /** The path of the file to add an annotation to. For example, `assets/css/main.css`. */
    path: string;
    /** The start line of the annotation. Line numbers start at 1. */
    start_line: number;
    /** The end line of the annotation. */
    end_line: number;
    /** The start column of the annotation. Annotations only support `start_column` and `end_column` on the same line. Omit this parameter if `start_line` and `end_line` have different values. Column numbers start at 1. */
    start_column?: number | undefined;
    /** The end column of the annotation. Annotations only support `start_column` and `end_column` on the same line. Omit this parameter if `start_line` and `end_line` have different values. */
    end_column?: number | undefined;
    /** The level of the annotation. */
    annotation_level: CreateRequestOutputAnnotationsItemAnnotationLevel | (string & {});
    /** A short description of the feedback for these lines of code. The maximum size is 64 KB. */
    message: string;
    /** The title that represents the annotation. The maximum size is 255 characters. */
    title?: string | undefined;
    /** Details about this annotation. The maximum size is 64 KB. */
    raw_details?: string | undefined;
}
/** Adds information from your analysis to specific lines of code. Annotations are visible on GitHub in the **Checks** and **Files changed** tab of the pull request. The Checks API limits the number of annotations to a maximum of 50 per API request. To create more than 50 annotations, you have to make multiple requests to the [Update a check run](https://docs.github.com/rest/checks/runs#update-a-check-run) endpoint. Each time you update the check run, annotations are appended to the list of annotations that already exist for the check run. GitHub Actions are limited to 10 warning annotations and 10 error annotations per step. For details about how you can view annotations on GitHub, see "[About status checks](https://docs.github.com/articles/about-status-checks#checks)". */
export type CreateRequestOutputAnnotationsList = Array<CreateRequestOutputAnnotationsItem>;
export interface CreateRequestOutputImagesItem {
    /** The alternative text for the image. */
    alt: string;
    /** The full URL of the image. */
    image_url: string;
    /** A short image description. */
    caption?: string | undefined;
}
/** Adds images to the output displayed in the GitHub pull request UI. */
export type CreateRequestOutputImagesList = Array<CreateRequestOutputImagesItem>;
/** Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run. */
export interface CreateRequestOutput {
    /** The title of the check run. */
    title: string;
    /** The summary of the check run. This parameter supports Markdown. **Maximum length**: 65535 characters. */
    summary: string;
    /** The details of the check run. This parameter supports Markdown. **Maximum length**: 65535 characters. */
    text?: string | undefined;
    /** Adds information from your analysis to specific lines of code. Annotations are visible on GitHub in the **Checks** and **Files changed** tab of the pull request. The Checks API limits the number of annotations to a maximum of 50 per API request. To create more than 50 annotations, you have to make multiple requests to the [Update a check run](https://docs.github.com/rest/checks/runs#update-a-check-run) endpoint. Each time you update the check run, annotations are appended to the list of annotations that already exist for the check run. GitHub Actions are limited to 10 warning annotations and 10 error annotations per step. For details about how you can view annotations on GitHub, see "[About status checks](https://docs.github.com/articles/about-status-checks#checks)". */
    annotations?: CreateRequestOutputAnnotationsList | undefined;
    /** Adds images to the output displayed in the GitHub pull request UI. */
    images?: CreateRequestOutputImagesList | undefined;
}
export interface CreateRequestActionsItem {
    /** The text to be displayed on a button in the web UI. The maximum size is 20 characters. */
    label: string;
    /** A short explanation of what this action would do. The maximum size is 40 characters. */
    description: string;
    /** A reference for the action on the integrator's system. The maximum size is 20 characters. */
    identifier: string;
}
/** Displays a button on GitHub that can be clicked to alert your app to do additional tasks. For example, a code linting app can display a button that automatically fixes detected errors. The button created in this object is displayed after the check run completes. When a user clicks the button, GitHub sends the [`check_run.requested_action` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) to your app. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)." */
export type CreateRequestActionsList = Array<CreateRequestActionsItem>;
export interface CreateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the check. For example, "code-coverage". */
    name: string;
    /** The SHA of the commit. */
    head_sha: string;
    /** The URL of the integrator's site that has the full details of the check. If the integrator does not provide this, then the homepage of the GitHub app is used. */
    details_url?: string | undefined;
    /** A reference for the run on the integrator's system. */
    external_id?: string | undefined;
    /** The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. */
    status?: CreateRequestStatus | (string & {}) | undefined;
    /** The time that the check run began. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    started_at?: string | undefined;
    /** **Required if you provide `completed_at` or a `status` of `completed`**. The final conclusion of the check. **Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this. */
    conclusion?: CreateRequestConclusion | (string & {}) | undefined;
    /** The time the check completed. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    completed_at?: string | undefined;
    /** Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run. */
    output?: CreateRequestOutput | undefined;
    /** Displays a button on GitHub that can be clicked to alert your app to do additional tasks. For example, a code linting app can display a button that automatically fixes detected errors. The button created in this object is displayed after the check run completes. When a user clicks the button, GitHub sends the [`check_run.requested_action` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) to your app. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)." */
    actions?: CreateRequestActionsList | undefined;
}
/** The phase of the lifecycle that the check is currently in. Statuses of waiting, requested, and pending are reserved for GitHub Actions check runs. */
export type CheckRunStatus = "queued" | "in_progress" | "completed" | "waiting" | "requested" | "pending";
export type CheckRunConclusion = "success" | "failure" | "neutral" | "cancelled" | "skipped" | "timed_out" | "action_required";
export interface CheckRunOutput {
    title: string | null;
    summary: string | null;
    text: string | null;
    annotations_count: number;
    annotations_url: string;
}
export interface CheckRunCheckSuite {
    id: number;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type NullableIntegrationOwner = SimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface NullableIntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
export interface PullRequestMinimalHeadRepo {
    id: number;
    url: string;
    name: string;
}
export interface PullRequestMinimalHead {
    ref: string;
    sha: string;
    repo: PullRequestMinimalHeadRepo;
}
export type PullRequestMinimalBaseRepo = PullRequestMinimalHeadRepo;
export type PullRequestMinimalBase = PullRequestMinimalHead;
export interface PullRequestMinimal {
    id: number;
    number: number;
    url: string;
    head: PullRequestMinimalHead;
    base: PullRequestMinimalHead;
}
/** Pull requests that are open with a `head_sha` or `head_branch` that matches the check. The returned pull requests do not necessarily indicate pull requests that triggered the check. */
export type CheckRunPullRequestsList = Array<PullRequestMinimal>;
/** A deployment created as the result of an Actions check run from a workflow that references an environment */
export interface DeploymentSimple {
    url: string;
    /** Unique identifier of the deployment */
    id: number;
    node_id: string;
    /** Parameter to specify a task to execute */
    task: string;
    original_environment?: string | undefined;
    /** Name for the target deployment environment. */
    environment: string;
    description: string | null;
    created_at: string;
    updated_at: string;
    statuses_url: string;
    repository_url: string;
    /** Specifies if the given environment is will no longer exist at some point in the future. Default: false. */
    transient_environment?: boolean | undefined;
    /** Specifies if the given environment is one that end-users directly interact with. Default: false. */
    production_environment?: boolean | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
}
/** A check performed on the code of a given code change */
export interface CheckRun {
    /** The id of the check. */
    id: number;
    /** The SHA of the commit that is being checked. */
    head_sha: string;
    node_id: string;
    external_id: string | null;
    url: string;
    html_url: string | null;
    details_url: string | null;
    /** The phase of the lifecycle that the check is currently in. Statuses of waiting, requested, and pending are reserved for GitHub Actions check runs. */
    status: CheckRunStatus;
    conclusion: CheckRunConclusion | null;
    started_at: string | null;
    completed_at: string | null;
    output: CheckRunOutput;
    /** The name of the check. */
    name: string;
    check_suite: CheckRunCheckSuite | null;
    app: NullableIntegration | null;
    /** Pull requests that are open with a `head_sha` or `head_branch` that matches the check. The returned pull requests do not necessarily indicate pull requests that triggered the check. */
    pull_requests: CheckRunPullRequestsList;
    deployment?: DeploymentSimple | undefined;
}
export interface CreateSuiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The sha of the head commit. */
    head_sha: string;
}
/** The phase of the lifecycle that the check suite is currently in. Statuses of waiting, requested, and pending are reserved for GitHub Actions check suites. */
export type CheckSuiteStatus = "queued" | "in_progress" | "completed" | "waiting" | "requested" | "pending";
export type CheckSuiteConclusion = "success" | "failure" | "neutral" | "cancelled" | "skipped" | "timed_out" | "action_required" | "startup_failure" | "stale";
export type CheckSuitePullRequestsList = Array<PullRequestMinimal>;
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
/** Information about the Git author */
export interface SimpleCommitAuthor {
    /** Name of the commit's author */
    name: string;
    /** Git email address of the commit's author */
    email: string;
}
/** Information about the Git committer */
export interface SimpleCommitCommitter {
    /** Name of the commit's committer */
    name: string;
    /** Git email address of the commit's committer */
    email: string;
}
/** A commit. */
export interface SimpleCommit {
    /** SHA for the commit */
    id: string;
    /** SHA for the commit's tree */
    tree_id: string;
    /** Message describing the purpose of the commit */
    message: string;
    /** Timestamp of the commit */
    timestamp: string;
    /** Information about the Git author */
    author: SimpleCommitAuthor | null;
    /** Information about the Git committer */
    committer: SimpleCommitCommitter | null;
}
/** A suite of checks performed on the code of a given code change */
export interface CheckSuite {
    id: number;
    node_id: string;
    head_branch: string | null;
    /** The SHA of the head commit that is being checked. */
    head_sha: string;
    /** The phase of the lifecycle that the check suite is currently in. Statuses of waiting, requested, and pending are reserved for GitHub Actions check suites. */
    status: CheckSuiteStatus | null;
    conclusion: CheckSuiteConclusion | null;
    url: string | null;
    before: string | null;
    after: string | null;
    pull_requests: CheckSuitePullRequestsList | null;
    app: NullableIntegration | null;
    repository: MinimalRepository;
    created_at: string | null;
    updated_at: string | null;
    head_commit: SimpleCommit;
    latest_check_runs_count: number;
    check_runs_url: string;
    rerequestable?: boolean | undefined;
    runs_rerequestable?: boolean | undefined;
}
export interface GetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check run. */
    check_run_id: number;
}
export interface GetSuiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check suite. */
    check_suite_id: number;
}
export interface ListAnnotationsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check run. */
    check_run_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Check Annotation */
export interface CheckAnnotation {
    path: string;
    start_line: number;
    end_line: number;
    start_column: number | null;
    end_column: number | null;
    annotation_level: string | null;
    title: string | null;
    message: string | null;
    raw_details: string | null;
    blob_href: string;
}
export type ListAnnotationsResponseBodyList = Array<CheckAnnotation>;
export type ListAnnotationsResponse = ListAnnotationsResponseBodyList;
export type ListForRefRequestStatus = "queued" | "in_progress" | "completed";
export type ListForRefRequestFilter = "latest" | "all";
export interface ListForRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** Returns check runs with the specified `name`. */
    check_name?: string | undefined;
    /** Returns check runs with the specified `status`. */
    status?: ListForRefRequestStatus | (string & {}) | undefined;
    /** Filters check runs by their `completed_at` timestamp. `latest` returns the most recent check runs. */
    filter?: ListForRefRequestFilter | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    app_id?: number | undefined;
}
export type ListForRefResponseCheckRunsList = Array<CheckRun>;
export interface ListForRefResponse {
    total_count: number;
    check_runs: ListForRefResponseCheckRunsList;
}
export type ListForSuiteRequestStatus = "queued" | "in_progress" | "completed";
export type ListForSuiteRequestFilter = "latest" | "all";
export interface ListForSuiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check suite. */
    check_suite_id: number;
    /** Returns check runs with the specified `name`. */
    check_name?: string | undefined;
    /** Returns check runs with the specified `status`. */
    status?: ListForSuiteRequestStatus | (string & {}) | undefined;
    /** Filters check runs by their `completed_at` timestamp. `latest` returns the most recent check runs. */
    filter?: ListForSuiteRequestFilter | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForSuiteResponseCheckRunsList = Array<CheckRun>;
export interface ListForSuiteResponse {
    total_count: number;
    check_runs: ListForSuiteResponseCheckRunsList;
}
export interface ListSuitesForRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** Filters check suites by GitHub App `id`. */
    app_id?: number | undefined;
    /** Returns check runs with the specified `name`. */
    check_name?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListSuitesForRefResponseCheckSuitesList = Array<CheckSuite>;
export interface ListSuitesForRefResponse {
    total_count: number;
    check_suites: ListSuitesForRefResponseCheckSuitesList;
}
export interface RerequestSuiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check suite. */
    check_suite_id: number;
}
export type RerequestSuiteResponse = unknown;
export interface RunRerequestRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check run. */
    check_run_id: number;
}
export type RunRerequestResponse = unknown;
export interface SetSuitesPreferencesRequestAutoTriggerChecksItem {
    /** The `id` of the GitHub App. */
    app_id: number;
    /** Set to `true` to enable automatic creation of CheckSuite events upon pushes to the repository, or `false` to disable them. */
    setting: boolean;
}
/** Enables or disables automatic creation of CheckSuite events upon pushes to the repository. Enabled by default. */
export type SetSuitesPreferencesRequestAutoTriggerChecksList = Array<SetSuitesPreferencesRequestAutoTriggerChecksItem>;
export interface SetSuitesPreferencesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Enables or disables automatic creation of CheckSuite events upon pushes to the repository. Enabled by default. */
    auto_trigger_checks?: SetSuitesPreferencesRequestAutoTriggerChecksList | undefined;
}
export interface CheckSuitePreferencePreferencesAutoTriggerChecksItem {
    app_id: number;
    setting: boolean;
}
export type CheckSuitePreferencePreferencesAutoTriggerChecksList = Array<CheckSuitePreferencePreferencesAutoTriggerChecksItem>;
export interface CheckSuitePreferencePreferences {
    auto_trigger_checks?: CheckSuitePreferencePreferencesAutoTriggerChecksList | undefined;
}
/** Check suite configuration preferences for a repository. */
export interface CheckSuitePreference {
    preferences: CheckSuitePreferencePreferences;
    repository: MinimalRepository;
}
/** The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. */
export type UpdateRequestStatus = "queued" | "in_progress" | "completed" | "waiting" | "requested" | "pending";
/** **Required if you provide `completed_at` or a `status` of `completed`**. The final conclusion of the check. **Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this. */
export type UpdateRequestConclusion = "action_required" | "cancelled" | "failure" | "neutral" | "success" | "skipped" | "stale" | "timed_out";
/** The level of the annotation. */
export type UpdateRequestOutputAnnotationsItemAnnotationLevel = "notice" | "warning" | "failure";
export interface UpdateRequestOutputAnnotationsItem {
    /** The path of the file to add an annotation to. For example, `assets/css/main.css`. */
    path: string;
    /** The start line of the annotation. Line numbers start at 1. */
    start_line: number;
    /** The end line of the annotation. */
    end_line: number;
    /** The start column of the annotation. Annotations only support `start_column` and `end_column` on the same line. Omit this parameter if `start_line` and `end_line` have different values. Column numbers start at 1. */
    start_column?: number | undefined;
    /** The end column of the annotation. Annotations only support `start_column` and `end_column` on the same line. Omit this parameter if `start_line` and `end_line` have different values. */
    end_column?: number | undefined;
    /** The level of the annotation. */
    annotation_level: UpdateRequestOutputAnnotationsItemAnnotationLevel | (string & {});
    /** A short description of the feedback for these lines of code. The maximum size is 64 KB. */
    message: string;
    /** The title that represents the annotation. The maximum size is 255 characters. */
    title?: string | undefined;
    /** Details about this annotation. The maximum size is 64 KB. */
    raw_details?: string | undefined;
}
/** Adds information from your analysis to specific lines of code. Annotations are visible in GitHub's pull request UI. Annotations are visible in GitHub's pull request UI. The Checks API limits the number of annotations to a maximum of 50 per API request. To create more than 50 annotations, you have to make multiple requests to the [Update a check run](https://docs.github.com/rest/checks/runs#update-a-check-run) endpoint. Each time you update the check run, annotations are appended to the list of annotations that already exist for the check run. GitHub Actions are limited to 10 warning annotations and 10 error annotations per step. For details about annotations in the UI, see "[About status checks](https://docs.github.com/articles/about-status-checks#checks)". */
export type UpdateRequestOutputAnnotationsList = Array<UpdateRequestOutputAnnotationsItem>;
export type UpdateRequestOutputImagesItem = CreateRequestOutputImagesItem;
/** Adds images to the output displayed in the GitHub pull request UI. */
export type UpdateRequestOutputImagesList = Array<CreateRequestOutputImagesItem>;
/** Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run. */
export interface UpdateRequestOutput {
    /** **Required**. */
    title?: string | undefined;
    /** Can contain Markdown. */
    summary: string;
    /** Can contain Markdown. */
    text?: string | undefined;
    /** Adds information from your analysis to specific lines of code. Annotations are visible in GitHub's pull request UI. Annotations are visible in GitHub's pull request UI. The Checks API limits the number of annotations to a maximum of 50 per API request. To create more than 50 annotations, you have to make multiple requests to the [Update a check run](https://docs.github.com/rest/checks/runs#update-a-check-run) endpoint. Each time you update the check run, annotations are appended to the list of annotations that already exist for the check run. GitHub Actions are limited to 10 warning annotations and 10 error annotations per step. For details about annotations in the UI, see "[About status checks](https://docs.github.com/articles/about-status-checks#checks)". */
    annotations?: UpdateRequestOutputAnnotationsList | undefined;
    /** Adds images to the output displayed in the GitHub pull request UI. */
    images?: UpdateRequestOutputImagesList | undefined;
}
export type UpdateRequestActionsItem = CreateRequestActionsItem;
/** Possible further actions the integrator can perform, which a user may trigger. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)." */
export type UpdateRequestActionsList = Array<CreateRequestActionsItem>;
export interface UpdateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the check run. */
    check_run_id: number;
    /** The name of the check. For example, "code-coverage". */
    name?: string | undefined;
    /** The URL of the integrator's site that has the full details of the check. */
    details_url?: string | undefined;
    /** A reference for the run on the integrator's system. */
    external_id?: string | undefined;
    /** This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    started_at?: string | undefined;
    /** The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. */
    status?: UpdateRequestStatus | (string & {}) | undefined;
    /** **Required if you provide `completed_at` or a `status` of `completed`**. The final conclusion of the check. **Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this. */
    conclusion?: UpdateRequestConclusion | (string & {}) | undefined;
    /** The time the check completed. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    completed_at?: string | undefined;
    /** Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run. */
    output?: UpdateRequestOutput | undefined;
    /** Possible further actions the integrator can perform, which a user may trigger. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)." */
    actions?: UpdateRequestActionsList | undefined;
}
export type CreateError = GithubOpError;
/** Create a check run Creates a new check run for a specific commit in a repository. To create a check run, you must use a GitHub App. OAuth apps and authenticated users are not able to create a check suite. In a check suite, GitHub limits the number of check runs with the same name to 1000. Once these check runs exceed 1000, GitHub will start to automatically delete older check runs. > [!NOTE] > The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array. */
export declare const create: API.OperationMethod<CreateRequest, CheckRun, CreateError, GithubOpContext>;
export type CreateSuiteError = GithubOpError;
/** Create a check suite Creates a check suite manually. By default, check suites are automatically created when you create a [check run](https://docs.github.com/rest/checks/runs). You only need to use this endpoint for manually creating check suites when you've disabled automatic creation using "[Update repository preferences for check suites](https://docs.github.com/rest/checks/suites#update-repository-preferences-for-check-suites)". > [!NOTE] > The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array and a `null` value for `head_branch`. OAuth apps and personal access tokens (classic) cannot use this endpoint. */
export declare const createSuite: API.OperationMethod<CreateSuiteRequest, CheckSuite, CreateSuiteError, GithubOpContext>;
export type GetError = GithubOpError;
/** Get a check run Gets a single check run using its `id`. > [!NOTE] > The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository. */
export declare const get: API.OperationMethod<GetRequest, CheckRun, GetError, GithubOpContext>;
export type GetSuiteError = GithubOpError;
/** Get a check suite Gets a single check suite using its `id`. > [!NOTE] > The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array and a `null` value for `head_branch`. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository. */
export declare const getSuite: API.OperationMethod<GetSuiteRequest, CheckSuite, GetSuiteError, GithubOpContext>;
export type ListAnnotationsError = GithubOpError;
/** List check run annotations Lists annotations for a check run using the annotation `id`. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository. */
export declare const listAnnotations: API.PaginatedOperationMethod<ListAnnotationsRequest, ListAnnotationsResponse, ListAnnotationsError, GithubOpContext, CheckAnnotation>;
export type ListForRefError = GithubOpError;
/** List check runs for a Git reference Lists check runs for a commit ref. The `ref` can be a SHA, branch name, or a tag name. > [!NOTE] > The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array. If there are more than 1000 check suites on a single git reference, this endpoint will limit check runs to the 1000 most recent check suites. To iterate over all possible check runs, use the [List check suites for a Git reference](https://docs.github.com/rest/reference/checks#list-check-suites-for-a-git-reference) endpoint and provide the `check_suite_id` parameter to the [List check runs in a check suite](https://docs.github.com/rest/reference/checks#list-check-runs-in-a-check-suite) endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository. */
export declare const listForRef: API.PaginatedOperationMethod<ListForRefRequest, ListForRefResponse, ListForRefError, GithubOpContext, CheckRun>;
export type ListForSuiteError = GithubOpError;
/** List check runs in a check suite Lists check runs for a check suite using its `id`. > [!NOTE] > The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository. */
export declare const listForSuite: API.PaginatedOperationMethod<ListForSuiteRequest, ListForSuiteResponse, ListForSuiteError, GithubOpContext, CheckRun>;
export type ListSuitesForRefError = GithubOpError;
/** List check suites for a Git reference Lists check suites for a commit `ref`. The `ref` can be a SHA, branch name, or a tag name. > [!NOTE] > The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array and a `null` value for `head_branch`. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository. */
export declare const listSuitesForRef: API.PaginatedOperationMethod<ListSuitesForRefRequest, ListSuitesForRefResponse, ListSuitesForRefError, GithubOpContext, CheckSuite>;
export type RerequestSuiteError = GithubOpError;
/** Rerequest a check suite Triggers GitHub to rerequest an existing check suite, without pushing new code to a repository. This endpoint will trigger the [`check_suite` webhook](https://docs.github.com/webhooks/event-payloads/#check_suite) event with the action `rerequested`. When a check suite is `rerequested`, its `status` is reset to `queued` and the `conclusion` is cleared. */
export declare const rerequestSuite: API.OperationMethod<RerequestSuiteRequest, RerequestSuiteResponse, RerequestSuiteError, GithubOpContext>;
export type RunRerequestError = GithubOpError;
/** Rerequest a check run Triggers GitHub to rerequest an existing check run, without pushing new code to a repository. This endpoint will trigger the [`check_run` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) event with the action `rerequested`. When a check run is `rerequested`, the `status` of the check suite it belongs to is reset to `queued` and the `conclusion` is cleared. The check run itself is not updated. GitHub apps recieving the [`check_run` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) with the `rerequested` action should then decide if the check run should be reset or updated and call the [update `check_run` endpoint](https://docs.github.com/rest/checks/runs#update-a-check-run) to update the check_run if desired. For more information about how to re-run GitHub Actions jobs, see "[Re-run a job from a workflow run](https://docs.github.com/rest/actions/workflow-runs#re-run-a-job-from-a-workflow-run)". */
export declare const runRerequest: API.OperationMethod<RunRerequestRequest, RunRerequestResponse, RunRerequestError, GithubOpContext>;
export type SetSuitesPreferencesError = GithubOpError;
/** Update repository preferences for check suites Changes the default automatic flow when creating check suites. By default, a check suite is automatically created each time code is pushed to a repository. When you disable the automatic creation of check suites, you can manually [Create a check suite](https://docs.github.com/rest/checks/suites#create-a-check-suite). You must have admin permissions in the repository to set preferences for check suites. */
export declare const setSuitesPreferences: API.OperationMethod<SetSuitesPreferencesRequest, CheckSuitePreference, SetSuitesPreferencesError, GithubOpContext>;
export type UpdateError = GithubOpError;
/** Update a check run Updates a check run for a specific commit in a repository. > [!NOTE] > The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array. OAuth apps and personal access tokens (classic) cannot use this endpoint. */
export declare const update: API.OperationMethod<UpdateRequest, CheckRun, UpdateError, GithubOpContext>;
//# sourceMappingURL=checks.d.ts.map