/**
 * Idempotency Token Generation - auto-fills @idempotencyToken fields with UUIDs.
 *
 * The AWS SDK automatically generates UUIDs for fields marked with @idempotencyToken
 * when the user doesn't provide a value. This ensures request retry safety.
 */

import type * as S from "effect/Schema";
import type * as AST from "effect/SchemaAST";
import { hasIdempotencyToken } from "../traits.ts";

/**
 * Find property names that have the @idempotencyToken annotation.
 * This is done once at request builder creation time.
 */
export const findIdempotencyTokenProps = (schema: S.Top): string[] => {
  const ast = schema.ast;

  // Unwrap Suspend if needed
  const unwrapped = ast._tag === "Suspend" ? ast.thunk() : ast;

  // For Declaration (S.Class), get the Objects from encoding chain
  let resolved = unwrapped;
  if (resolved._tag === "Declaration" && resolved.encoding?.length) {
    resolved = resolved.encoding[0].to;
  }

  if (resolved._tag !== "Objects") {
    return [];
  }

  const props: string[] = [];

  // Check each property signature for idempotencyToken annotation
  for (const prop of resolved.propertySignatures) {
    const propName = prop.name;
    if (typeof propName !== "string") continue;

    if (hasIdempotencyToken(prop as AST.PropertySignature)) {
      props.push(propName);
    }
  }

  return props;
};

/**
 * Fill in undefined idempotency tokens with generated UUIDs.
 * Uses pre-computed property names for efficiency.
 */
export const fillIdempotencyTokens = (input: unknown, idempotencyTokenProps: string[]): unknown => {
  // Fast path: no idempotency tokens to fill
  if (idempotencyTokenProps.length === 0) {
    return input;
  }

  // Check if input is an object
  if (input === null || typeof input !== "object") {
    return input;
  }

  const inputObj = input as Record<string, unknown>;
  let modified = false;
  let result: Record<string, unknown> | undefined;

  // Only check the pre-computed properties
  for (const propName of idempotencyTokenProps) {
    if (inputObj[propName] === undefined) {
      if (!result) {
        result = { ...inputObj };
      }
      // `globalThis.crypto`, not `node:crypto`, so this stays on the browser
      // graph that the Cognito and STS credential providers pull in.
      result[propName] = globalThis.crypto.randomUUID();
      modified = true;
    }
  }

  return modified ? result : input;
};
