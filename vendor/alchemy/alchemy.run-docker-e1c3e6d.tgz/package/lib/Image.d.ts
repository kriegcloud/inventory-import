import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type * as Redacted from "effect/Redacted";
import { type BuildCacheOptions } from "./BuildCache.ts";
import { Docker } from "./Docker.ts";
import type { Providers } from "./Providers.ts";
import { type ImageRegistry } from "./Registry.ts";
export interface DockerBuildOptions extends BuildCacheOptions {
    /**
     * Build context directory.
     *
     * @default Current working directory.
     */
    context?: string;
    /**
     * Dockerfile path, relative to the context unless absolute.
     *
     * @default "Dockerfile"
     */
    dockerfile?: string;
    /** Target platform, e.g. `"linux/amd64"`. */
    platform?: string;
    /**
     * Docker build arguments (`--build-arg`). Never pass secrets here: build
     * args are visible in the image history. Use {@link secrets} instead.
     */
    args?: Record<string, string>;
    /**
     * BuildKit secrets, keyed by id. Mount one in a `RUN` step with
     * `--mount=type=secret,id=<id>` and read it from `/run/secrets/<id>`, or
     * add `env=<NAME>` to expose it as an environment variable for that step.
     * A secret never enters the image, its build history, or `docker`'s argv.
     */
    secrets?: Record<string, Redacted.Redacted<string>>;
    /** Multi-stage build target. */
    target?: string;
    /** Additional Docker build options. */
    options?: string[];
}
export interface ImageProps {
    /**
     * Repository/name for the built image.
     *
     * @default Generated from stack, stage, logical id, and instance id.
     */
    name?: string;
    /** Image tag. @default "latest" */
    tag?: string;
    /**
     * Registry credentials. The image is pushed to this registry (unless
     * `skipPush`), and the build itself authenticates with them, so private
     * base images and `type=registry` caches hosted there resolve without a
     * host `docker login`. Credentials already in `DOCKER_AUTH_CONFIG` for
     * other registries are kept. Build-time authentication needs Buildx 0.26+
     * (Docker Desktop 4.44+) or the legacy builder; older Buildx plugins ignore
     * it, so a private base image there still needs `docker login`.
     */
    registry?: ImageRegistry;
    /** Skip registry push even when `registry` is set. @default false */
    skipPush?: boolean;
    /** Docker context name or context resource. */
    context?: Docker.ContextRef;
    /** Docker build configuration. */
    build: DockerBuildOptions;
}
export interface Image extends Resource<"Docker.Image", ImageProps, {
    /** Image repository/name without tag. */
    name: string;
    /** Final image reference. Includes registry host when pushed there. */
    imageRef: string;
    /** Local image id after build/tag. */
    imageId: string;
    /** Registry digest after push when available. */
    repoDigest?: string;
    /** Tag used for the local image. */
    tag: string;
    /** Build timestamp in milliseconds since epoch. */
    builtAt: number;
}, never, Providers> {
}
/**
 * Builds, tags, and optionally pushes Docker images through the active Docker
 * context.
 *
 * This resource uses the Docker CLI and whatever daemon or remote context the
 * CLI is configured to target. It is separate from `Cloudflare.Container`;
 * registry image references are the boundary between Docker-managed images and
 * cloud container platforms.
 *
 * `Image` always builds from a Dockerfile. To pull (and optionally re-tag and
 * push) an existing registry image, use `Docker.RemoteImage`.
 *
 *
 * ### Building Images
 * **Example:** Build from a Dockerfile
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   tag: "latest",
 *   build: {
 *     context: "./app",
 *     dockerfile: "Dockerfile",
 *     args: { NODE_ENV: "production" },
 *   },
 * });
 * ```
 *
 * ### Build Secrets
 * **Example:** Install from a private npm registry
 * ```typescript
 * // Dockerfile:
 * //   RUN --mount=type=secret,id=NPM_TOKEN,env=NPM_TOKEN npm ci
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   build: {
 *     context: "./app",
 *     secrets: { NPM_TOKEN: Config.Redacted("NPM_TOKEN") },
 *   },
 * });
 * ```
 *
 * The secret is mounted only into the `RUN` step that asks for it; it never
 * lands in an image layer or the build history.
 *
 * ### Registry Push
 * **Example:** Push with Redacted credentials
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   build: { context: "./app" },
 *   registry: {
 *     server: "ghcr.io",
 *     username: "octocat",
 *     password: Config.Redacted("GITHUB_TOKEN"),
 *   },
 * });
 * ```
 *
 * ### Private Base Images
 * **Example:** Build FROM a private base image
 * ```typescript
 * // Dockerfile: FROM registry.example.com/base:v1
 * const image = yield* Docker.Image("app", {
 *   name: "registry.example.com/app",
 *   build: { context: "./app" },
 *   // Authenticates the base-image pull, then the push.
 *   registry: {
 *     server: "registry.example.com",
 *     username: "deploy",
 *     password: Config.Redacted("REGISTRY_PASSWORD"),
 *   },
 * });
 * ```
 *
 * ### Caching Build Layers
 * Builds reuse the local BuildKit cache of the machine they run on, and
 * nothing but the image is pushed. A builder that has never built the image,
 * such as a fresh CI runner, reruns every step. Set `build.cache: true` to keep
 * every stage's layers at the image repository's `:buildcache` tag, so fresh
 * builders skip unchanged steps. For another backend, pass BuildKit's own
 * `--cache-from` / `--cache-to` values as `from` and `to`.
 *
 * **Example:** Cache layers in the image's registry
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "registry.example.com/app",
 *   build: { context: "./app", cache: true },
 *   registry: {
 *     server: "registry.example.com",
 *     username: "deploy",
 *     password: Config.Redacted("REGISTRY_PASSWORD"),
 *   },
 * });
 * ```
 *
 * **Example:** Cache layers in GitHub Actions
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   build: {
 *     context: "./app",
 *     cache: {
 *       from: ["type=gha,scope=app"],
 *       to: ["type=gha,scope=app,mode=max"],
 *     },
 *   },
 * });
 * ```
 *
 * ### Docker Context
 * **Example:** Build in a named Docker context
 * ```typescript
 * const image = yield* Docker.Image("app", {
 *   name: "my-app",
 *   context: "remote-build",
 *   build: { context: "./app" },
 * });
 * ```
 *
 * @resource
 * @product Image
 */
export declare const Image: import("alchemy/Resource").ResourceClass<Image>;
export declare const ImageProvider: () => import("effect/Layer").Layer<Provider.Provider<Image>, never, Docker | FileSystem.FileSystem | Path.Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
//# sourceMappingURL=Image.d.ts.map