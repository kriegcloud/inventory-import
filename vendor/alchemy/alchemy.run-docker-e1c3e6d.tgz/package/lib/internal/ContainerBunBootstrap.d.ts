export declare const makeServerBootstrap: (handler: string) => (importPath: string) => string;
export declare const makeJobBootstrap: (handler: string) => (importPath: string) => string;
//# sourceMappingURL=ContainerBunBootstrap.d.ts.map