import * as Effect from "effect/Effect";
import type * as Aggregate from "../../Aggregate.ts";
import type { Interpreter } from "./Interpreter.ts";
import * as Paths from "./Paths.ts";
import * as Smt from "./Smt.ts";
/** An invariant to add, as its name and the code to write. */
export interface Suggestion {
    readonly name: string;
    readonly source: string;
}
/**
 * An invariant that makes `target` provable, where a simple one does: a rule
 * that is true of a new instance, that every command keeps, and that rules
 * out the states the proof of `target` fails from. It is the fewest of the
 * guessed rules that do, written as one invariant.
 *
 * A proof starts from any state the invariants allow. One that is true of
 * every state the aggregate reaches can still fail, from a state no sequence
 * of commands leads to. The fix is an invariant that says so, and this finds
 * it where it is about whole numbers not going below zero or above one
 * another.
 */
export declare const suggest: (solver: Smt.Solver, interpreter: Interpreter, aggregate: Aggregate.Any, definition: Paths.Definition, target: string) => Effect.Effect<Suggestion | undefined, Smt.SolverError, never>;
//# sourceMappingURL=Suggest.d.ts.map