import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as HttpClient from "effect/http/HttpClient";
import * as HttpServer from "effect/http/HttpServer";
import * as Layer from "effect/Layer";
import * as ChildProcessSpawner from "effect/process/ChildProcessSpawner";
import * as Schema from "effect/Schema";
import * as Scope from "effect/Scope";
import { type RpcServerEnvironment } from "./RpcServerEnvironment.ts";
declare const RpcSpawner_base: Context.ServiceClass<RpcSpawner, "alchemy/Local/RpcSpawner", {
    readonly url: string;
}>;
export declare class RpcSpawner extends RpcSpawner_base {
}
/**
 * The spawner forks one child per distinct `serverEntryUrl`. Stack-specific
 * context (stack name/stage, AlchemyContext) is NOT part of the spawn key —
 * it travels per RPC session (see `SESSION_ENV_PARAM`), so many stacks
 * (e.g. every test file in a run) share a single sidecar process.
 */
export declare const RpcSpawnPayload: Schema.Struct<{
    readonly serverEntryUrl: Schema.String;
}>;
export type RpcSpawnPayload = typeof RpcSpawnPayload.Type;
/**
 * One line of sidecar child output, tagged with the channel it arrived on.
 * Streamed as NDJSON over the spawner's {@link LOGS_PATH} endpoint.
 */
export interface SidecarLogLine {
    readonly channel: "stdout" | "stderr";
    readonly line: string;
}
export declare const HeartbeatFrame: Schema.Struct<{
    readonly channel: Schema.Literal<"heartbeat">;
}>;
export type HeartbeatFrame = typeof HeartbeatFrame.Type;
/**
 * Path on the spawner's HTTP server that streams sidecar output as NDJSON
 * ({@link SidecarLogLine} per line). Consumed by {@link forwardSidecarLogs}
 * from the exec child, which owns the terminal renderer.
 */
export declare const LOGS_PATH = "/logs";
/** The {@link LOGS_PATH} endpoint of a spawner URL, keeping its token. */
export declare const spawnerLogsUrl: (spawnerUrl: string) => string;
/** Options for the {@link RpcSpawner} that forks sidecar processes. */
export type RpcSpawnerOptions = Pick<RpcServerEnvironment, "profile" | "envFile"> & {
    /**
     * Prefixes of environment variables withheld from sidecar processes (and,
     * through them, from their own children). Sidecars otherwise inherit this
     * process's entire environment.
     */
    readonly omitEnv?: ReadonlyArray<string>;
};
export declare const make: (args_0: RpcSpawnerOptions) => Effect.Effect<{
    readonly url: string;
}, never, ChildProcessSpawner.ChildProcessSpawner | HttpServer.HttpServer | Scope.Scope>;
export declare const layerServer: (environment: RpcSpawnerOptions) => Layer.Layer<RpcSpawner, import("effect/http/HttpServerError").ServeError, ChildProcessSpawner.ChildProcessSpawner>;
export declare const parseSidecarLogLine: (raw: string) => SidecarLogLine | undefined;
/**
 * Pull the sidecars' log records from the spawner (the outer `alchemy dev`
 * process) into THIS process's loggers. The exec child owns the terminal
 * renderer, so the records render above the repainting progress region
 * instead of racing it on the shared tty; it forwards them on to the
 * supervisor, which writes the run log. Forks in the ambient scope and never fails: when no spawner is
 * configured (`ALCHEMY_RPC_SPAWNER_URL` absent — plain deploy/destroy) it is
 * a no-op, and if the connection drops the spawner's own fallback printing
 * takes over.
 */
export declare const forwardSidecarLogs: Effect.Effect<void, never, HttpClient.HttpClient | Scope.Scope>;
export {};
//# sourceMappingURL=RpcSpawner.d.ts.map