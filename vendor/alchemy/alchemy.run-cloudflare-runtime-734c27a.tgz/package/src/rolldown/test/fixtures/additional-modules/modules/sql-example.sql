SELECT * FROM users;
