import * as Effect from "effect/Effect";
/**
 * The runtime a bundled program (`main`) runs on: `node` or `bun`, optionally
 * followed by a version. The version is the base image's tag, so it can be
 * as precise as the release you need:
 *
 * | `runtime` | base image |
 * | --- | --- |
 * | `"node"`, `"node26"` | `node:26-slim` |
 * | `"node24"` | `node:24-slim` |
 * | `"node26.13.1"` | `node:26.13.1-slim` |
 * | `"bun"`, `"bun1"` | `oven/bun:1` |
 * | `"bun1.3"` | `oven/bun:1.3` |
 * | `"bun1.3.13"` | `oven/bun:1.3.13` |
 *
 * Bun changes between minor and patch releases, so pin at least the minor
 * (`"bun1.3"`), or the exact release when one breaks you (`"bun1.3.13"`).
 * Tags still move when an image is rebuilt over a new OS layer; for a
 * byte-identical image, set your own `image` digest beside `runtime`.
 */
export type ContainerRuntime = "node" | "bun" | `node${number}` | `node${number}.${number}` | `bun${number}` | `bun${number}.${number}`;
/** The runtime bundled programs use when a resource sets none. */
export declare const DEFAULT_CONTAINER_RUNTIME = "node";
/** How Alchemy bundles and starts a program on one runtime. */
export interface ContainerRuntimeSettings {
    readonly preset: "bun" | "node";
    /** Base image used when the workload supplies no image or Dockerfile. */
    readonly baseImage: string;
    /** Arguments before the generated bundle path, for example `["node"]`. */
    readonly command: readonly [string, ...string[]];
    /** Package export conditions for the generated bundle. */
    readonly conditions: readonly string[];
    /** Imports the runtime provides or the image installs beside the bundle. */
    readonly external?: readonly string[];
    /** Command that installs packages the application leaves external, for example `["npm", "install"]`. */
    readonly installPackages: readonly [string, ...string[]];
    /**
     * Absolute path or file URL to a module exporting the `services` and
     * `httpServer` Effect layers. The module is bundled into the image.
     */
    readonly platformModule: string;
    /**
     * Bun's own process templates. They keep the images Alchemy built before
     * the shared process entry existed, so Bun deployments don't rebuild.
     */
    readonly compatibilityBootstrap?: Readonly<Record<"server" | "job", (handler: string) => (importPath: string) => string>>;
}
declare const InvalidContainerRuntime_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidContainerRuntime";
} & Readonly<A>;
/** A `runtime` that isn't `node` or `bun` followed by an optional version. */
export declare class InvalidContainerRuntime extends InvalidContainerRuntime_base<{
    readonly runtime: string;
    readonly message: string;
}> {
}
/**
 * The settings for a resource's `runtime`, or for
 * {@link DEFAULT_CONTAINER_RUNTIME} when it sets none.
 */
export declare const resolveContainerRuntime: (runtime: ContainerRuntime | undefined) => Effect.Effect<ContainerRuntimeSettings, InvalidContainerRuntime>;
/** The base image of {@link DEFAULT_CONTAINER_RUNTIME}. */
export declare const DEFAULT_CONTAINER_BASE_IMAGE: string;
/** The settings of the runtime the image-only sandbox agent runs on. */
export declare const SANDBOX_AGENT_RUNTIME: ContainerRuntimeSettings;
export declare const containerPlatformModulePath: (module: string) => string;
export declare const makeContainerBootstrap: (platformModule: string, bootstrapModule: string, handler: string, mode: "server" | "job", options?: {
    readonly deferEntrypointImport?: boolean;
}) => (importPath: string) => string;
export {};
//# sourceMappingURL=ContainerRuntime.d.ts.map