import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AlreadyExistsException_base: S.TaggedErrorClass<"AlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class AlreadyExistsException extends /*@__PURE__*/ AlreadyExistsException_base {
}
declare const CFNRegistryException_base: S.TaggedErrorClass<"CFNRegistryException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CFNRegistryException extends /*@__PURE__*/ CFNRegistryException_base {
}
declare const ChangeSetNotFoundException_base: S.TaggedErrorClass<"ChangeSetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ChangeSetNotFoundException extends /*@__PURE__*/ ChangeSetNotFoundException_base {
}
declare const ConcurrentResourcesLimitExceededException_base: S.TaggedErrorClass<"ConcurrentResourcesLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ConcurrentResourcesLimitExceededException extends /*@__PURE__*/ ConcurrentResourcesLimitExceededException_base {
}
declare const CreatedButModifiedException_base: S.TaggedErrorClass<"CreatedButModifiedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class CreatedButModifiedException extends /*@__PURE__*/ CreatedButModifiedException_base {
}
declare const GeneratedTemplateNotFoundException_base: S.TaggedErrorClass<"GeneratedTemplateNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GeneratedTemplateNotFoundException extends /*@__PURE__*/ GeneratedTemplateNotFoundException_base {
}
declare const HookResultNotFoundException_base: S.TaggedErrorClass<"HookResultNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class HookResultNotFoundException extends /*@__PURE__*/ HookResultNotFoundException_base {
}
declare const InsufficientCapabilitiesException_base: S.TaggedErrorClass<"InsufficientCapabilitiesException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientCapabilitiesException extends /*@__PURE__*/ InsufficientCapabilitiesException_base {
}
declare const InvalidChangeSetStatusException_base: S.TaggedErrorClass<"InvalidChangeSetStatusException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidChangeSetStatusException extends /*@__PURE__*/ InvalidChangeSetStatusException_base {
}
declare const InvalidOperationException_base: S.TaggedErrorClass<"InvalidOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidOperationException extends /*@__PURE__*/ InvalidOperationException_base {
}
declare const InvalidStateTransitionException_base: S.TaggedErrorClass<"InvalidStateTransitionException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidStateTransitionException extends /*@__PURE__*/ InvalidStateTransitionException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NameAlreadyExistsException_base: S.TaggedErrorClass<"NameAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class NameAlreadyExistsException extends /*@__PURE__*/ NameAlreadyExistsException_base {
}
declare const NoUpdateToPerform_base: S.TaggedErrorClass<"NoUpdateToPerform", {
    readonly message: any;
}>;
export declare class NoUpdateToPerform extends /*@__PURE__*/ NoUpdateToPerform_base {
}
declare const OperationIdAlreadyExistsException_base: S.TaggedErrorClass<"OperationIdAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class OperationIdAlreadyExistsException extends /*@__PURE__*/ OperationIdAlreadyExistsException_base {
}
declare const OperationInProgressException_base: S.TaggedErrorClass<"OperationInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class OperationInProgressException extends /*@__PURE__*/ OperationInProgressException_base {
}
declare const OperationNotFoundException_base: S.TaggedErrorClass<"OperationNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotFoundException extends /*@__PURE__*/ OperationNotFoundException_base {
}
declare const OperationStatusCheckFailedException_base: S.TaggedErrorClass<"OperationStatusCheckFailedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationStatusCheckFailedException extends /*@__PURE__*/ OperationStatusCheckFailedException_base {
}
declare const ResourceScanInProgressException_base: S.TaggedErrorClass<"ResourceScanInProgressException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceScanInProgressException extends /*@__PURE__*/ ResourceScanInProgressException_base {
}
declare const ResourceScanLimitExceededException_base: S.TaggedErrorClass<"ResourceScanLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceScanLimitExceededException extends /*@__PURE__*/ ResourceScanLimitExceededException_base {
}
declare const ResourceScanNotFoundException_base: S.TaggedErrorClass<"ResourceScanNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceScanNotFoundException extends /*@__PURE__*/ ResourceScanNotFoundException_base {
}
declare const StackInstanceNotFoundException_base: S.TaggedErrorClass<"StackInstanceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackInstanceNotFoundException extends /*@__PURE__*/ StackInstanceNotFoundException_base {
}
declare const StackNotFound_base: S.TaggedErrorClass<"StackNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class StackNotFound extends /*@__PURE__*/ StackNotFound_base {
}
declare const StackNotFoundException_base: S.TaggedErrorClass<"StackNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackNotFoundException extends /*@__PURE__*/ StackNotFoundException_base {
}
declare const StackRefactorNotFoundException_base: S.TaggedErrorClass<"StackRefactorNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackRefactorNotFoundException extends /*@__PURE__*/ StackRefactorNotFoundException_base {
}
declare const StackSetNotEmptyException_base: S.TaggedErrorClass<"StackSetNotEmptyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StackSetNotEmptyException extends /*@__PURE__*/ StackSetNotEmptyException_base {
}
declare const StackSetNotFoundException_base: S.TaggedErrorClass<"StackSetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StackSetNotFoundException extends /*@__PURE__*/ StackSetNotFoundException_base {
}
declare const StaleRequestException_base: S.TaggedErrorClass<"StaleRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class StaleRequestException extends /*@__PURE__*/ StaleRequestException_base {
}
declare const TokenAlreadyExistsException_base: S.TaggedErrorClass<"TokenAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class TokenAlreadyExistsException extends /*@__PURE__*/ TokenAlreadyExistsException_base {
}
declare const TypeConfigurationNotFoundException_base: S.TaggedErrorClass<"TypeConfigurationNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TypeConfigurationNotFoundException extends /*@__PURE__*/ TypeConfigurationNotFoundException_base {
}
declare const TypeNotFoundException_base: S.TaggedErrorClass<"TypeNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TypeNotFoundException extends /*@__PURE__*/ TypeNotFoundException_base {
}
export interface ActivateOrganizationsAccessInput {
}
export interface ActivateOrganizationsAccessOutput {
}
export type ThirdPartyType = "RESOURCE" | "MODULE" | "HOOK" | (string & {});
export type ThirdPartyTypeArn = string;
export type PublisherId = string;
export type TypeName = string;
export type AutoUpdate = boolean;
export type RoleARN2 = string;
export type LogGroupName = string;
export interface LoggingConfig {
    LogRoleArn?: string | undefined;
    LogGroupName?: string | undefined;
}
export type VersionBump = "MAJOR" | "MINOR" | (string & {});
export type MajorVersion = number;
export interface ActivateTypeInput {
    Type?: ThirdPartyType | undefined;
    PublicTypeArn?: string | undefined;
    PublisherId?: string | undefined;
    TypeName?: string | undefined;
    TypeNameAlias?: string | undefined;
    AutoUpdate?: boolean | undefined;
    LoggingConfig?: LoggingConfig | undefined;
    ExecutionRoleArn?: string | undefined;
    VersionBump?: VersionBump | undefined;
    MajorVersion?: number | undefined;
}
export type PrivateTypeArn = string;
export interface ActivateTypeOutput {
    Arn?: string | undefined;
}
export type TypeArn = string;
export type TypeConfigurationAlias = string;
export type TypeConfigurationArn = string;
export interface TypeConfigurationIdentifier {
    TypeArn?: string | undefined;
    TypeConfigurationAlias?: string | undefined;
    TypeConfigurationArn?: string | undefined;
    Type?: ThirdPartyType | undefined;
    TypeName?: string | undefined;
}
export type TypeConfigurationIdentifiers = TypeConfigurationIdentifier[];
export interface BatchDescribeTypeConfigurationsInput {
    TypeConfigurationIdentifiers?: TypeConfigurationIdentifier[] | undefined;
}
export type ErrorCode = string;
export type ErrorMessage = string;
export interface BatchDescribeTypeConfigurationsError_ {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
    TypeConfigurationIdentifier?: TypeConfigurationIdentifier | undefined;
}
export type BatchDescribeTypeConfigurationsErrors = BatchDescribeTypeConfigurationsError_[];
export type UnprocessedTypeConfigurations = TypeConfigurationIdentifier[];
export type TypeConfiguration = string;
export type IsDefaultConfiguration = boolean;
export interface TypeConfigurationDetails {
    Arn?: string | undefined;
    Alias?: string | undefined;
    Configuration?: string | undefined;
    LastUpdated?: Date | undefined;
    TypeArn?: string | undefined;
    TypeName?: string | undefined;
    IsDefaultConfiguration?: boolean | undefined;
}
export type TypeConfigurationDetailsList = TypeConfigurationDetails[];
export interface BatchDescribeTypeConfigurationsOutput {
    Errors?: BatchDescribeTypeConfigurationsError_[] | undefined;
    UnprocessedTypeConfigurations?: TypeConfigurationIdentifier[] | undefined;
    TypeConfigurations?: TypeConfigurationDetails[] | undefined;
}
export type StackName = string;
export type ClientRequestToken = string;
export interface CancelUpdateStackInput {
    StackName?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface CancelUpdateStackResponse {
}
export type StackNameOrId = string;
export type RoleARN = string;
export type ResourceToSkip = string;
export type ResourcesToSkip = string[];
export type ForceRollback = boolean;
export interface ContinueUpdateRollbackInput {
    StackName?: string | undefined;
    RoleARN?: string | undefined;
    ResourcesToSkip?: string[] | undefined;
    ClientRequestToken?: string | undefined;
    ForceRollback?: boolean | undefined;
}
export interface ContinueUpdateRollbackOutput {
}
export type TemplateBody = string;
export type TemplateURL = string;
export type UsePreviousTemplate = boolean;
export type ParameterKey = string;
export type ParameterValue = string;
export type UsePreviousValue = boolean;
export interface Parameter {
    ParameterKey?: string | undefined;
    ParameterValue?: string | undefined;
    UsePreviousValue?: boolean | undefined;
    ResolvedValue?: string | undefined;
}
export type Parameters = Parameter[];
export type Capability = "CAPABILITY_IAM" | "CAPABILITY_NAMED_IAM" | "CAPABILITY_AUTO_EXPAND" | (string & {});
export type Capabilities = Capability[];
export type ResourceType = string;
export type ResourceTypes = string[];
export type Arn = string;
export type Type = string;
export interface RollbackTrigger {
    Arn?: string | undefined;
    Type?: string | undefined;
}
export type RollbackTriggers = RollbackTrigger[];
export type MonitoringTimeInMinutes = number;
export interface RollbackConfiguration {
    RollbackTriggers?: RollbackTrigger[] | undefined;
    MonitoringTimeInMinutes?: number | undefined;
}
export type NotificationARN = string;
export type NotificationARNs = string[];
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type Tags = Tag[];
export type ChangeSetName = string;
export type ClientToken = string;
export type Description = string;
export type ChangeSetType = "CREATE" | "UPDATE" | "IMPORT" | (string & {});
export type LogicalResourceId = string;
export type ResourceIdentifierPropertyKey = string;
export type ResourceIdentifierPropertyValue = string;
export type ResourceIdentifierProperties = {
    [key: string]: string | undefined;
};
export interface ResourceToImport {
    ResourceType?: string | undefined;
    LogicalResourceId?: string | undefined;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ResourcesToImport = ResourceToImport[];
export type IncludeNestedStacks = boolean;
export type OnStackFailure = "DO_NOTHING" | "ROLLBACK" | "DELETE" | (string & {});
export type ImportExistingResources = boolean;
export type DeploymentMode = "REVERT_DRIFT" | (string & {});
export type DeploymentConfigMode = "STANDARD" | "EXPRESS" | (string & {});
export type DisableRollback = boolean;
export interface DeploymentConfig {
    Mode?: DeploymentConfigMode | undefined;
    DisableRollback?: boolean | undefined;
}
export type DisableValidation = boolean;
export interface CreateChangeSetInput {
    StackName?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    UsePreviousTemplate?: boolean | undefined;
    Parameters?: Parameter[] | undefined;
    Capabilities?: Capability[] | undefined;
    ResourceTypes?: string[] | undefined;
    RoleARN?: string | undefined;
    RollbackConfiguration?: RollbackConfiguration | undefined;
    NotificationARNs?: string[] | undefined;
    Tags?: Tag[] | undefined;
    ChangeSetName?: string | undefined;
    ClientToken?: string | undefined;
    Description?: string | undefined;
    ChangeSetType?: ChangeSetType | undefined;
    ResourcesToImport?: ResourceToImport[] | undefined;
    IncludeNestedStacks?: boolean | undefined;
    OnStackFailure?: OnStackFailure | undefined;
    ImportExistingResources?: boolean | undefined;
    DeploymentMode?: DeploymentMode | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
    DisableValidation?: boolean | undefined;
}
export type ChangeSetId = string;
export type StackId = string;
export interface CreateChangeSetOutput {
    Id?: string | undefined;
    StackId?: string | undefined;
}
export interface ResourceDefinition {
    ResourceType?: string | undefined;
    LogicalResourceId?: string | undefined;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ResourceDefinitions = ResourceDefinition[];
export type GeneratedTemplateName = string;
export type GeneratedTemplateDeletionPolicy = "DELETE" | "RETAIN" | (string & {});
export type GeneratedTemplateUpdateReplacePolicy = "DELETE" | "RETAIN" | (string & {});
export interface TemplateConfiguration {
    DeletionPolicy?: GeneratedTemplateDeletionPolicy | undefined;
    UpdateReplacePolicy?: GeneratedTemplateUpdateReplacePolicy | undefined;
}
export interface CreateGeneratedTemplateInput {
    Resources?: ResourceDefinition[] | undefined;
    GeneratedTemplateName?: string | undefined;
    StackName?: string | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
}
export type GeneratedTemplateId = string;
export interface CreateGeneratedTemplateOutput {
    GeneratedTemplateId?: string | undefined;
}
export type TimeoutMinutes = number;
export type OnFailure = "DO_NOTHING" | "ROLLBACK" | "DELETE" | (string & {});
export type StackPolicyBody = string;
export type StackPolicyURL = string;
export type EnableTerminationProtection = boolean;
export type RetainExceptOnCreate = boolean;
export interface CreateStackInput {
    StackName?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    Parameters?: Parameter[] | undefined;
    DisableRollback?: boolean | undefined;
    RollbackConfiguration?: RollbackConfiguration | undefined;
    TimeoutInMinutes?: number | undefined;
    NotificationARNs?: string[] | undefined;
    Capabilities?: Capability[] | undefined;
    ResourceTypes?: string[] | undefined;
    RoleARN?: string | undefined;
    OnFailure?: OnFailure | undefined;
    StackPolicyBody?: string | undefined;
    StackPolicyURL?: string | undefined;
    Tags?: Tag[] | undefined;
    ClientRequestToken?: string | undefined;
    EnableTerminationProtection?: boolean | undefined;
    RetainExceptOnCreate?: boolean | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
    DisableValidation?: boolean | undefined;
}
export type OperationId = string;
export interface CreateStackOutput {
    StackId?: string | undefined;
    OperationId?: string | undefined;
}
export type StackSetName = string;
export type Account = string;
export type AccountList = string[];
export type AccountsUrl = string;
export type OrganizationalUnitId = string;
export type OrganizationalUnitIdList = string[];
export type AccountFilterType = "NONE" | "INTERSECTION" | "DIFFERENCE" | "UNION" | (string & {});
export interface DeploymentTargets {
    Accounts?: string[] | undefined;
    AccountsUrl?: string | undefined;
    OrganizationalUnitIds?: string[] | undefined;
    AccountFilterType?: AccountFilterType | undefined;
}
export type Region = string;
export type RegionList = string[];
export type RegionConcurrencyType = "SEQUENTIAL" | "PARALLEL" | (string & {});
export type FailureToleranceCount = number;
export type FailureTolerancePercentage = number;
export type MaxConcurrentCount = number;
export type MaxConcurrentPercentage = number;
export type ConcurrencyMode = "STRICT_FAILURE_TOLERANCE" | "SOFT_FAILURE_TOLERANCE" | (string & {});
export interface StackSetOperationPreferences {
    RegionConcurrencyType?: RegionConcurrencyType | undefined;
    RegionOrder?: string[] | undefined;
    FailureToleranceCount?: number | undefined;
    FailureTolerancePercentage?: number | undefined;
    MaxConcurrentCount?: number | undefined;
    MaxConcurrentPercentage?: number | undefined;
    ConcurrencyMode?: ConcurrencyMode | undefined;
}
export type CallAs = "SELF" | "DELEGATED_ADMIN" | (string & {});
export interface CreateStackInstancesInput {
    StackSetName?: string | undefined;
    Accounts?: string[] | undefined;
    DeploymentTargets?: DeploymentTargets | undefined;
    Regions?: string[] | undefined;
    ParameterOverrides?: Parameter[] | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface CreateStackInstancesOutput {
    OperationId?: string | undefined;
}
export type EnableStackCreation = boolean;
export interface ResourceLocation {
    StackName?: string | undefined;
    LogicalResourceId?: string | undefined;
}
export interface ResourceMapping {
    Source?: ResourceLocation | undefined;
    Destination?: ResourceLocation | undefined;
}
export type ResourceMappings = ResourceMapping[];
export interface StackDefinition {
    StackName?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
}
export type StackDefinitions = StackDefinition[];
export interface CreateStackRefactorInput {
    Description?: string | undefined;
    EnableStackCreation?: boolean | undefined;
    ResourceMappings?: ResourceMapping[] | undefined;
    StackDefinitions?: StackDefinition[] | undefined;
}
export type StackRefactorId = string;
export interface CreateStackRefactorOutput {
    StackRefactorId: string;
}
export type ExecutionRoleName = string;
export type PermissionModels = "SERVICE_MANAGED" | "SELF_MANAGED" | (string & {});
export type AutoDeploymentNullable = boolean;
export type RetainStacksOnAccountRemovalNullable = boolean;
export type StackSetARN = string;
export type StackSetARNList = string[];
export interface AutoDeployment {
    Enabled?: boolean | undefined;
    RetainStacksOnAccountRemoval?: boolean | undefined;
    DependsOn?: string[] | undefined;
}
export type ManagedExecutionNullable = boolean;
export interface ManagedExecution {
    Active?: boolean | undefined;
}
export interface CreateStackSetInput {
    StackSetName?: string | undefined;
    Description?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    StackId?: string | undefined;
    Parameters?: Parameter[] | undefined;
    Capabilities?: Capability[] | undefined;
    Tags?: Tag[] | undefined;
    AdministrationRoleARN?: string | undefined;
    ExecutionRoleName?: string | undefined;
    PermissionModel?: PermissionModels | undefined;
    AutoDeployment?: AutoDeployment | undefined;
    CallAs?: CallAs | undefined;
    ClientRequestToken?: string | undefined;
    ManagedExecution?: ManagedExecution | undefined;
}
export type StackSetId = string;
export interface CreateStackSetOutput {
    StackSetId?: string | undefined;
}
export interface DeactivateOrganizationsAccessInput {
}
export interface DeactivateOrganizationsAccessOutput {
}
export interface DeactivateTypeInput {
    TypeName?: string | undefined;
    Type?: ThirdPartyType | undefined;
    Arn?: string | undefined;
}
export interface DeactivateTypeOutput {
}
export type ChangeSetNameOrId = string;
export interface DeleteChangeSetInput {
    ChangeSetName?: string | undefined;
    StackName?: string | undefined;
}
export interface DeleteChangeSetOutput {
}
export interface DeleteGeneratedTemplateInput {
    GeneratedTemplateName?: string | undefined;
}
export interface DeleteGeneratedTemplateResponse {
}
export type RetainResources = string[];
export type DeletionMode = "STANDARD" | "FORCE_DELETE_STACK" | (string & {});
export interface DeleteStackInput {
    StackName?: string | undefined;
    RetainResources?: string[] | undefined;
    RoleARN?: string | undefined;
    ClientRequestToken?: string | undefined;
    DeletionMode?: DeletionMode | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
}
export interface DeleteStackResponse {
}
export type RetainStacks = boolean;
export interface DeleteStackInstancesInput {
    StackSetName?: string | undefined;
    Accounts?: string[] | undefined;
    DeploymentTargets?: DeploymentTargets | undefined;
    Regions?: string[] | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    RetainStacks?: boolean | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface DeleteStackInstancesOutput {
    OperationId?: string | undefined;
}
export interface DeleteStackSetInput {
    StackSetName?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface DeleteStackSetOutput {
}
export type RegistryType = "RESOURCE" | "MODULE" | "HOOK" | (string & {});
export type TypeVersionId = string;
export interface DeregisterTypeInput {
    Arn?: string | undefined;
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    VersionId?: string | undefined;
}
export interface DeregisterTypeOutput {
}
export type NextToken = string;
export interface DescribeAccountLimitsInput {
    NextToken?: string | undefined;
}
export type LimitName = string;
export type LimitValue = number;
export interface AccountLimit {
    Name?: string | undefined;
    Value?: number | undefined;
}
export type AccountLimitList = AccountLimit[];
export interface DescribeAccountLimitsOutput {
    AccountLimits?: AccountLimit[] | undefined;
    NextToken?: string | undefined;
}
export type IncludePropertyValues = boolean;
export interface DescribeChangeSetInput {
    ChangeSetName?: string | undefined;
    StackName?: string | undefined;
    NextToken?: string | undefined;
    IncludePropertyValues?: boolean | undefined;
}
export type CreationTime = Date;
export type ExecutionStatus = "UNAVAILABLE" | "AVAILABLE" | "EXECUTE_IN_PROGRESS" | "EXECUTE_COMPLETE" | "EXECUTE_FAILED" | "OBSOLETE" | (string & {});
export type ChangeSetStatus = "CREATE_PENDING" | "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "DELETE_PENDING" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | "FAILED" | (string & {});
export type ChangeSetStatusReason = string;
export type StackDriftStatus = "DRIFTED" | "IN_SYNC" | "UNKNOWN" | "NOT_CHECKED" | (string & {});
export type ChangeType = "Resource" | (string & {});
export type HookInvocationCount = number;
export type PolicyAction = "Delete" | "Retain" | "Snapshot" | "ReplaceAndDelete" | "ReplaceAndRetain" | "ReplaceAndSnapshot" | (string & {});
export type ChangeAction = "Add" | "Modify" | "Remove" | "Import" | "Dynamic" | "SyncWithActual" | (string & {});
export type PhysicalResourceId = string;
export type Replacement = "True" | "False" | "Conditional" | (string & {});
export type ResourceAttribute = "Properties" | "Metadata" | "CreationPolicy" | "UpdatePolicy" | "DeletionPolicy" | "UpdateReplacePolicy" | "Tags" | (string & {});
export type Scope = ResourceAttribute[];
export type StackResourceDriftStatus = "IN_SYNC" | "MODIFIED" | "DELETED" | "NOT_CHECKED" | "UNKNOWN" | "UNSUPPORTED" | (string & {});
export type ResourcePropertyPath = string;
export type DriftIgnoredReason = "MANAGED_BY_AWS" | "WRITE_ONLY_PROPERTY" | "SENSITIVE_PROPERTY" | (string & {});
export interface ResourceDriftIgnoredAttribute {
    Path?: string | undefined;
    Reason?: DriftIgnoredReason | undefined;
}
export type ResourceDriftIgnoredAttributes = ResourceDriftIgnoredAttribute[];
export type PropertyName = string;
export type RequiresRecreation = "Never" | "Conditionally" | "Always" | (string & {});
export type BeforeValue = string;
export type AfterValue = string;
export type BeforeValueFrom = "PREVIOUS_DEPLOYMENT_STATE" | "ACTUAL_STATE" | (string & {});
export type AfterValueFrom = "TEMPLATE" | (string & {});
export type ResourceDriftPreviousValue = string;
export type ResourceDriftActualValue = string;
export interface LiveResourceDrift {
    PreviousValue?: string | undefined;
    ActualValue?: string | undefined;
    DriftDetectionTimestamp?: Date | undefined;
}
export type AttributeChangeType = "Add" | "Remove" | "Modify" | "SyncWithActual" | (string & {});
export interface ResourceTargetDefinition {
    Attribute?: ResourceAttribute | undefined;
    Name?: string | undefined;
    RequiresRecreation?: RequiresRecreation | undefined;
    Path?: string | undefined;
    BeforeValue?: string | undefined;
    AfterValue?: string | undefined;
    BeforeValueFrom?: BeforeValueFrom | undefined;
    AfterValueFrom?: AfterValueFrom | undefined;
    Drift?: LiveResourceDrift | undefined;
    AttributeChangeType?: AttributeChangeType | undefined;
}
export type EvaluationType = "Static" | "Dynamic" | (string & {});
export type ChangeSource = "ResourceReference" | "ParameterReference" | "ResourceAttribute" | "DirectModification" | "Automatic" | "NoModification" | (string & {});
export type CausingEntity = string;
export interface ResourceChangeDetail {
    Target?: ResourceTargetDefinition | undefined;
    Evaluation?: EvaluationType | undefined;
    ChangeSource?: ChangeSource | undefined;
    CausingEntity?: string | undefined;
}
export type ResourceChangeDetails = ResourceChangeDetail[];
export type TypeHierarchy = string;
export type LogicalIdHierarchy = string;
export interface ModuleInfo {
    TypeHierarchy?: string | undefined;
    LogicalIdHierarchy?: string | undefined;
}
export type BeforeContext = string;
export type AfterContext = string;
export type PreviousDeploymentContext = string;
export interface ResourceChange {
    PolicyAction?: PolicyAction | undefined;
    Action?: ChangeAction | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Replacement?: Replacement | undefined;
    Scope?: ResourceAttribute[] | undefined;
    ResourceDriftStatus?: StackResourceDriftStatus | undefined;
    ResourceDriftIgnoredAttributes?: ResourceDriftIgnoredAttribute[] | undefined;
    Details?: ResourceChangeDetail[] | undefined;
    ChangeSetId?: string | undefined;
    ModuleInfo?: ModuleInfo | undefined;
    BeforeContext?: string | undefined;
    AfterContext?: string | undefined;
    PreviousDeploymentContext?: string | undefined;
}
export interface Change {
    Type?: ChangeType | undefined;
    HookInvocationCount?: number | undefined;
    ResourceChange?: ResourceChange | undefined;
}
export type Changes = Change[];
export interface DescribeChangeSetOutput {
    ChangeSetName?: string | undefined;
    ChangeSetId?: string | undefined;
    StackId?: string | undefined;
    StackName?: string | undefined;
    Description?: string | undefined;
    Parameters?: Parameter[] | undefined;
    CreationTime?: Date | undefined;
    ExecutionStatus?: ExecutionStatus | undefined;
    Status?: ChangeSetStatus | undefined;
    StatusReason?: string | undefined;
    StackDriftStatus?: StackDriftStatus | undefined;
    NotificationARNs?: string[] | undefined;
    RollbackConfiguration?: (RollbackConfiguration & {
        RollbackTriggers: (RollbackTrigger & {
            Arn: Arn;
            Type: Type;
        })[];
    }) | undefined;
    Capabilities?: Capability[] | undefined;
    Tags?: (Tag & {
        Key: TagKey;
        Value: TagValue;
    })[] | undefined;
    Changes?: Change[] | undefined;
    NextToken?: string | undefined;
    IncludeNestedStacks?: boolean | undefined;
    ParentChangeSetId?: string | undefined;
    RootChangeSetId?: string | undefined;
    OnStackFailure?: OnStackFailure | undefined;
    ImportExistingResources?: boolean | undefined;
    DeploymentMode?: DeploymentMode | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
}
export interface DescribeChangeSetHooksInput {
    ChangeSetName?: string | undefined;
    StackName?: string | undefined;
    NextToken?: string | undefined;
    LogicalResourceId?: string | undefined;
}
export type HookInvocationPoint = "PRE_PROVISION" | (string & {});
export type HookFailureMode = "FAIL" | "WARN" | (string & {});
export type HookTypeName = string;
export type HookTypeVersionId = string;
export type HookTypeConfigurationVersionId = string;
export type HookTargetType = "RESOURCE" | (string & {});
export type HookTargetTypeName = string;
export interface ChangeSetHookResourceTargetDetails {
    LogicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    ResourceAction?: ChangeAction | undefined;
}
export interface ChangeSetHookTargetDetails {
    TargetType?: HookTargetType | undefined;
    ResourceTargetDetails?: ChangeSetHookResourceTargetDetails | undefined;
}
export interface ChangeSetHook {
    InvocationPoint?: HookInvocationPoint | undefined;
    FailureMode?: HookFailureMode | undefined;
    TypeName?: string | undefined;
    TypeVersionId?: string | undefined;
    TypeConfigurationVersionId?: string | undefined;
    TargetDetails?: ChangeSetHookTargetDetails | undefined;
}
export type ChangeSetHooks = ChangeSetHook[];
export type ChangeSetHooksStatus = "PLANNING" | "PLANNED" | "UNAVAILABLE" | (string & {});
export interface DescribeChangeSetHooksOutput {
    ChangeSetId?: string | undefined;
    ChangeSetName?: string | undefined;
    Hooks?: ChangeSetHook[] | undefined;
    Status?: ChangeSetHooksStatus | undefined;
    NextToken?: string | undefined;
    StackId?: string | undefined;
    StackName?: string | undefined;
}
export type FailedEventsFilter = boolean;
export interface EventFilter {
    FailedEvents?: boolean | undefined;
}
export interface DescribeEventsInput {
    StackName?: string | undefined;
    ChangeSetName?: string | undefined;
    OperationId?: string | undefined;
    Filters?: EventFilter | undefined;
    NextToken?: string | undefined;
}
export type EventId = string;
export type OperationType = "CREATE_STACK" | "UPDATE_STACK" | "DELETE_STACK" | "CONTINUE_ROLLBACK" | "ROLLBACK" | "CREATE_CHANGESET" | (string & {});
export type BeaconStackOperationStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export type EventType = "STACK_EVENT" | "PROGRESS_EVENT" | "VALIDATION_ERROR" | "PROVISIONING_ERROR" | "HOOK_INVOCATION_ERROR" | (string & {});
export type ResourceStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATE_COMPLETE" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "DELETE_COMPLETE" | "DELETE_SKIPPED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | "UPDATE_COMPLETE" | "IMPORT_FAILED" | "IMPORT_COMPLETE" | "IMPORT_IN_PROGRESS" | "IMPORT_ROLLBACK_IN_PROGRESS" | "IMPORT_ROLLBACK_FAILED" | "IMPORT_ROLLBACK_COMPLETE" | "EXPORT_FAILED" | "EXPORT_COMPLETE" | "EXPORT_IN_PROGRESS" | "EXPORT_ROLLBACK_IN_PROGRESS" | "EXPORT_ROLLBACK_FAILED" | "EXPORT_ROLLBACK_COMPLETE" | "UPDATE_ROLLBACK_IN_PROGRESS" | "UPDATE_ROLLBACK_COMPLETE" | "UPDATE_ROLLBACK_FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETE" | "ROLLBACK_FAILED" | (string & {});
export type ResourceStatusReason = string;
export type ResourceProperties = string;
export type HookType = string;
export type HookStatus = "HOOK_IN_PROGRESS" | "HOOK_COMPLETE_SUCCEEDED" | "HOOK_COMPLETE_FAILED" | "HOOK_FAILED" | (string & {});
export type HookStatusReason = string;
export type DetailedStatus = "CONFIGURATION_COMPLETE" | "VALIDATION_FAILED" | (string & {});
export type ValidationName = string;
export type ValidationStatus = "FAILED" | "SKIPPED" | (string & {});
export type ValidationStatusReason = string;
export type ValidationPath = string;
export interface OperationEvent {
    EventId?: string | undefined;
    StackId?: string | undefined;
    OperationId?: string | undefined;
    OperationType?: OperationType | undefined;
    OperationStatus?: BeaconStackOperationStatus | undefined;
    EventType?: EventType | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Timestamp?: Date | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ResourceStatusReason?: string | undefined;
    ResourceProperties?: string | undefined;
    ClientRequestToken?: string | undefined;
    HookType?: string | undefined;
    HookStatus?: HookStatus | undefined;
    HookStatusReason?: string | undefined;
    HookInvocationPoint?: HookInvocationPoint | undefined;
    HookFailureMode?: HookFailureMode | undefined;
    DetailedStatus?: DetailedStatus | undefined;
    ValidationFailureMode?: HookFailureMode | undefined;
    ValidationName?: string | undefined;
    ValidationStatus?: ValidationStatus | undefined;
    ValidationStatusReason?: string | undefined;
    ValidationPath?: string | undefined;
}
export type OperationEvents = OperationEvent[];
export interface DescribeEventsOutput {
    OperationEvents?: OperationEvent[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeGeneratedTemplateInput {
    GeneratedTemplateName?: string | undefined;
}
export type GeneratedTemplateResourceStatus = "PENDING" | "IN_PROGRESS" | "FAILED" | "COMPLETE" | (string & {});
export type WarningType = "MUTUALLY_EXCLUSIVE_PROPERTIES" | "UNSUPPORTED_PROPERTIES" | "MUTUALLY_EXCLUSIVE_TYPES" | "EXCLUDED_PROPERTIES" | "EXCLUDED_RESOURCES" | (string & {});
export type PropertyPath = string;
export type RequiredProperty = boolean;
export type PropertyDescription = string;
export interface WarningProperty {
    PropertyPath?: string | undefined;
    Required?: boolean | undefined;
    Description?: string | undefined;
}
export type WarningProperties = WarningProperty[];
export interface WarningDetail {
    Type?: WarningType | undefined;
    Properties?: WarningProperty[] | undefined;
}
export type WarningDetails = WarningDetail[];
export interface ResourceDetail {
    ResourceType?: string | undefined;
    LogicalResourceId?: string | undefined;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    } | undefined;
    ResourceStatus?: GeneratedTemplateResourceStatus | undefined;
    ResourceStatusReason?: string | undefined;
    Warnings?: WarningDetail[] | undefined;
}
export type ResourceDetails = ResourceDetail[];
export type GeneratedTemplateStatus = "CREATE_PENDING" | "UPDATE_PENDING" | "DELETE_PENDING" | "CREATE_IN_PROGRESS" | "UPDATE_IN_PROGRESS" | "DELETE_IN_PROGRESS" | "FAILED" | "COMPLETE" | (string & {});
export type TemplateStatusReason = string;
export type LastUpdatedTime = Date;
export type ResourcesSucceeded = number;
export type ResourcesFailed = number;
export type ResourcesProcessing = number;
export type ResourcesPending = number;
export interface TemplateProgress {
    ResourcesSucceeded?: number | undefined;
    ResourcesFailed?: number | undefined;
    ResourcesProcessing?: number | undefined;
    ResourcesPending?: number | undefined;
}
export type TotalWarnings = number;
export interface DescribeGeneratedTemplateOutput {
    GeneratedTemplateId?: string | undefined;
    GeneratedTemplateName?: string | undefined;
    Resources?: ResourceDetail[] | undefined;
    Status?: GeneratedTemplateStatus | undefined;
    StatusReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Progress?: TemplateProgress | undefined;
    StackId?: string | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
    TotalWarnings?: number | undefined;
}
export interface DescribeOrganizationsAccessInput {
    CallAs?: CallAs | undefined;
}
export type OrganizationStatus = "ENABLED" | "DISABLED" | "DISABLED_PERMANENTLY" | (string & {});
export interface DescribeOrganizationsAccessOutput {
    Status?: OrganizationStatus | undefined;
}
export interface DescribePublisherInput {
    PublisherId?: string | undefined;
}
export type PublisherStatus = "VERIFIED" | "UNVERIFIED" | (string & {});
export type IdentityProvider = "AWS_Marketplace" | "GitHub" | "Bitbucket" | (string & {});
export type PublisherProfile = string;
export interface DescribePublisherOutput {
    PublisherId?: string | undefined;
    PublisherStatus?: PublisherStatus | undefined;
    IdentityProvider?: IdentityProvider | undefined;
    PublisherProfile?: string | undefined;
}
export type ResourceScanId = string;
export interface DescribeResourceScanInput {
    ResourceScanId?: string | undefined;
}
export type ResourceScanStatus = "IN_PROGRESS" | "FAILED" | "COMPLETE" | "EXPIRED" | (string & {});
export type ResourceScanStatusReason = string;
export type PercentageCompleted = number;
export type ResourcesScanned = number;
export type ResourcesRead = number;
export type ResourceTypeFilter = string;
export type ResourceTypeFilters = string[];
export interface ScanFilter {
    Types?: string[] | undefined;
}
export type ScanFilters = ScanFilter[];
export interface DescribeResourceScanOutput {
    ResourceScanId?: string | undefined;
    Status?: ResourceScanStatus | undefined;
    StatusReason?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    PercentageCompleted?: number | undefined;
    ResourceTypes?: string[] | undefined;
    ResourcesScanned?: number | undefined;
    ResourcesRead?: number | undefined;
    ScanFilters?: ScanFilter[] | undefined;
}
export type StackDriftDetectionId = string;
export interface DescribeStackDriftDetectionStatusInput {
    StackDriftDetectionId?: string | undefined;
}
export type StackDriftDetectionStatus = "DETECTION_IN_PROGRESS" | "DETECTION_FAILED" | "DETECTION_COMPLETE" | (string & {});
export type StackDriftDetectionStatusReason = string;
export type BoxedInteger = number;
export interface DescribeStackDriftDetectionStatusOutput {
    StackId: string;
    StackDriftDetectionId: string;
    StackDriftStatus?: StackDriftStatus | undefined;
    DetectionStatus: StackDriftDetectionStatus;
    DetectionStatusReason?: string | undefined;
    DriftedStackResourceCount?: number | undefined;
    Timestamp: Date;
}
export interface DescribeStackEventsInput {
    StackName?: string | undefined;
    NextToken?: string | undefined;
}
export type HookInvocationId = string;
export interface StackEvent {
    StackId?: string | undefined;
    EventId?: string | undefined;
    StackName?: string | undefined;
    OperationId?: string | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Timestamp?: Date | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ResourceStatusReason?: string | undefined;
    ResourceProperties?: string | undefined;
    ClientRequestToken?: string | undefined;
    HookType?: string | undefined;
    HookStatus?: HookStatus | undefined;
    HookStatusReason?: string | undefined;
    HookInvocationPoint?: HookInvocationPoint | undefined;
    HookInvocationId?: string | undefined;
    HookFailureMode?: HookFailureMode | undefined;
    DetailedStatus?: DetailedStatus | undefined;
}
export type StackEvents = StackEvent[];
export interface DescribeStackEventsOutput {
    StackEvents?: (StackEvent & {
        StackId: StackId;
        EventId: EventId;
        StackName: StackName;
        Timestamp: Date;
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeStackInstanceInput {
    StackSetName?: string | undefined;
    StackInstanceAccount?: string | undefined;
    StackInstanceRegion?: string | undefined;
    CallAs?: CallAs | undefined;
}
export type StackInstanceStatus = "CURRENT" | "OUTDATED" | "INOPERABLE" | (string & {});
export type StackInstanceDetailedStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | "INOPERABLE" | "SKIPPED_SUSPENDED_ACCOUNT" | "FAILED_IMPORT" | (string & {});
export interface StackInstanceComprehensiveStatus {
    DetailedStatus?: StackInstanceDetailedStatus | undefined;
}
export type Reason = string;
export interface StackInstance {
    StackSetId?: string | undefined;
    Region?: string | undefined;
    Account?: string | undefined;
    StackId?: string | undefined;
    ParameterOverrides?: Parameter[] | undefined;
    Status?: StackInstanceStatus | undefined;
    StackInstanceStatus?: StackInstanceComprehensiveStatus | undefined;
    StatusReason?: string | undefined;
    OrganizationalUnitId?: string | undefined;
    DriftStatus?: StackDriftStatus | undefined;
    LastDriftCheckTimestamp?: Date | undefined;
    LastOperationId?: string | undefined;
}
export interface DescribeStackInstanceOutput {
    StackInstance?: StackInstance | undefined;
}
export interface DescribeStackRefactorInput {
    StackRefactorId?: string | undefined;
}
export type StackIds = string[];
export type StackRefactorExecutionStatus = "UNAVAILABLE" | "AVAILABLE" | "OBSOLETE" | "EXECUTE_IN_PROGRESS" | "EXECUTE_COMPLETE" | "EXECUTE_FAILED" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_COMPLETE" | "ROLLBACK_FAILED" | (string & {});
export type ExecutionStatusReason = string;
export type StackRefactorStatus = "CREATE_IN_PROGRESS" | "CREATE_COMPLETE" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_COMPLETE" | "DELETE_FAILED" | (string & {});
export type StackRefactorStatusReason = string;
export interface DescribeStackRefactorOutput {
    Description?: string | undefined;
    StackRefactorId?: string | undefined;
    StackIds?: string[] | undefined;
    ExecutionStatus?: StackRefactorExecutionStatus | undefined;
    ExecutionStatusReason?: string | undefined;
    Status?: StackRefactorStatus | undefined;
    StatusReason?: string | undefined;
}
export interface DescribeStackResourceInput {
    StackName?: string | undefined;
    LogicalResourceId?: string | undefined;
}
export type Metadata = string;
export interface StackResourceDriftInformation {
    StackResourceDriftStatus?: StackResourceDriftStatus | undefined;
    LastCheckTimestamp?: Date | undefined;
}
export interface StackResourceDetail {
    StackName?: string | undefined;
    StackId?: string | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ResourceStatusReason?: string | undefined;
    Description?: string | undefined;
    Metadata?: string | undefined;
    DriftInformation?: StackResourceDriftInformation | undefined;
    ModuleInfo?: ModuleInfo | undefined;
}
export interface DescribeStackResourceOutput {
    StackResourceDetail?: (StackResourceDetail & {
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        LastUpdatedTimestamp: Date;
        ResourceStatus: ResourceStatus;
        DriftInformation: StackResourceDriftInformation & {
            StackResourceDriftStatus: StackResourceDriftStatus;
        };
    }) | undefined;
}
export type StackResourceDriftStatusFilters = StackResourceDriftStatus[];
export type BoxedMaxResults = number;
export interface DescribeStackResourceDriftsInput {
    StackName?: string | undefined;
    StackResourceDriftStatusFilters?: StackResourceDriftStatus[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Key = string;
export type Value = string;
export interface PhysicalResourceIdContextKeyValuePair {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type PhysicalResourceIdContext = PhysicalResourceIdContextKeyValuePair[];
export type Properties = string;
export type PropertyValue = string;
export type DifferenceType = "ADD" | "REMOVE" | "NOT_EQUAL" | (string & {});
export interface PropertyDifference {
    PropertyPath?: string | undefined;
    ExpectedValue?: string | undefined;
    ActualValue?: string | undefined;
    DifferenceType?: DifferenceType | undefined;
}
export type PropertyDifferences = PropertyDifference[];
export type StackResourceDriftStatusReason = string;
export interface StackResourceDrift {
    StackId?: string | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    PhysicalResourceIdContext?: PhysicalResourceIdContextKeyValuePair[] | undefined;
    ResourceType?: string | undefined;
    ExpectedProperties?: string | undefined;
    ActualProperties?: string | undefined;
    PropertyDifferences?: PropertyDifference[] | undefined;
    StackResourceDriftStatus?: StackResourceDriftStatus | undefined;
    Timestamp?: Date | undefined;
    ModuleInfo?: ModuleInfo | undefined;
    DriftStatusReason?: string | undefined;
}
export type StackResourceDrifts = StackResourceDrift[];
export interface DescribeStackResourceDriftsOutput {
    StackResourceDrifts: (StackResourceDrift & {
        StackId: StackId;
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        StackResourceDriftStatus: StackResourceDriftStatus;
        Timestamp: Date;
        PhysicalResourceIdContext: (PhysicalResourceIdContextKeyValuePair & {
            Key: Key;
            Value: Value;
        })[];
        PropertyDifferences: (PropertyDifference & {
            PropertyPath: PropertyPath;
            ExpectedValue: PropertyValue;
            ActualValue: PropertyValue;
            DifferenceType: DifferenceType;
        })[];
    })[];
    NextToken?: string | undefined;
}
export interface DescribeStackResourcesInput {
    StackName?: string | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
}
export interface StackResource {
    StackName?: string | undefined;
    StackId?: string | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    Timestamp?: Date | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ResourceStatusReason?: string | undefined;
    Description?: string | undefined;
    DriftInformation?: StackResourceDriftInformation | undefined;
    ModuleInfo?: ModuleInfo | undefined;
}
export type StackResources = StackResource[];
export interface DescribeStackResourcesOutput {
    StackResources?: (StackResource & {
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        Timestamp: Date;
        ResourceStatus: ResourceStatus;
        DriftInformation: StackResourceDriftInformation & {
            StackResourceDriftStatus: StackResourceDriftStatus;
        };
    })[] | undefined;
}
export interface DescribeStacksInput {
    StackName?: string | undefined;
    NextToken?: string | undefined;
}
export type DeletionTime = Date;
export type StackStatus = "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "CREATE_COMPLETE" | "ROLLBACK_IN_PROGRESS" | "ROLLBACK_FAILED" | "ROLLBACK_COMPLETE" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | "DELETE_COMPLETE" | "UPDATE_IN_PROGRESS" | "UPDATE_COMPLETE_CLEANUP_IN_PROGRESS" | "UPDATE_COMPLETE" | "UPDATE_FAILED" | "UPDATE_ROLLBACK_IN_PROGRESS" | "UPDATE_ROLLBACK_FAILED" | "UPDATE_ROLLBACK_COMPLETE_CLEANUP_IN_PROGRESS" | "UPDATE_ROLLBACK_COMPLETE" | "REVIEW_IN_PROGRESS" | "IMPORT_IN_PROGRESS" | "IMPORT_COMPLETE" | "IMPORT_ROLLBACK_IN_PROGRESS" | "IMPORT_ROLLBACK_FAILED" | "IMPORT_ROLLBACK_COMPLETE" | (string & {});
export type StackStatusReason = string;
export type OutputKey = string;
export type OutputValue = string;
export type ExportName = string;
export interface Output {
    OutputKey?: string | undefined;
    OutputValue?: string | undefined;
    Description?: string | undefined;
    ExportName?: string | undefined;
}
export type Outputs = Output[];
export interface StackDriftInformation {
    StackDriftStatus?: StackDriftStatus | undefined;
    LastCheckTimestamp?: Date | undefined;
}
export interface OperationEntry {
    OperationType?: OperationType | undefined;
    OperationId?: string | undefined;
}
export type LastOperations = OperationEntry[];
export type AliasName = string;
export interface Stack {
    StackId?: string | undefined;
    StackName?: string | undefined;
    ChangeSetId?: string | undefined;
    Description?: string | undefined;
    Parameters?: Parameter[] | undefined;
    CreationTime?: Date | undefined;
    DeletionTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    RollbackConfiguration?: RollbackConfiguration | undefined;
    StackStatus?: StackStatus | undefined;
    StackStatusReason?: string | undefined;
    DisableRollback?: boolean | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
    NotificationARNs?: string[] | undefined;
    TimeoutInMinutes?: number | undefined;
    Capabilities?: Capability[] | undefined;
    Outputs?: Output[] | undefined;
    RoleARN?: string | undefined;
    Tags?: Tag[] | undefined;
    EnableTerminationProtection?: boolean | undefined;
    ParentId?: string | undefined;
    RootId?: string | undefined;
    DriftInformation?: StackDriftInformation | undefined;
    RetainExceptOnCreate?: boolean | undefined;
    DeletionMode?: DeletionMode | undefined;
    DetailedStatus?: DetailedStatus | undefined;
    LastOperations?: OperationEntry[] | undefined;
    AliasName?: string | undefined;
}
export type Stacks = Stack[];
export interface DescribeStacksOutput {
    Stacks?: (Stack & {
        StackName: StackName;
        CreationTime: CreationTime;
        StackStatus: StackStatus;
        RollbackConfiguration: RollbackConfiguration & {
            RollbackTriggers: (RollbackTrigger & {
                Arn: Arn;
                Type: Type;
            })[];
        };
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        DriftInformation: StackDriftInformation & {
            StackDriftStatus: StackDriftStatus;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeStackSetInput {
    StackSetName?: string | undefined;
    CallAs?: CallAs | undefined;
}
export type StackSetStatus = "ACTIVE" | "DELETED" | (string & {});
export type StackSetDriftStatus = "DRIFTED" | "IN_SYNC" | "NOT_CHECKED" | (string & {});
export type StackSetDriftDetectionStatus = "COMPLETED" | "FAILED" | "PARTIAL_SUCCESS" | "IN_PROGRESS" | "STOPPED" | (string & {});
export type TotalStackInstancesCount = number;
export type DriftedStackInstancesCount = number;
export type InSyncStackInstancesCount = number;
export type InProgressStackInstancesCount = number;
export type FailedStackInstancesCount = number;
export interface StackSetDriftDetectionDetails {
    DriftStatus?: StackSetDriftStatus | undefined;
    DriftDetectionStatus?: StackSetDriftDetectionStatus | undefined;
    LastDriftCheckTimestamp?: Date | undefined;
    TotalStackInstancesCount?: number | undefined;
    DriftedStackInstancesCount?: number | undefined;
    InSyncStackInstancesCount?: number | undefined;
    InProgressStackInstancesCount?: number | undefined;
    FailedStackInstancesCount?: number | undefined;
}
export interface StackSet {
    StackSetName?: string | undefined;
    StackSetId?: string | undefined;
    Description?: string | undefined;
    Status?: StackSetStatus | undefined;
    TemplateBody?: string | undefined;
    Parameters?: Parameter[] | undefined;
    Capabilities?: Capability[] | undefined;
    Tags?: Tag[] | undefined;
    StackSetARN?: string | undefined;
    AdministrationRoleARN?: string | undefined;
    ExecutionRoleName?: string | undefined;
    StackSetDriftDetectionDetails?: StackSetDriftDetectionDetails | undefined;
    AutoDeployment?: AutoDeployment | undefined;
    PermissionModel?: PermissionModels | undefined;
    OrganizationalUnitIds?: string[] | undefined;
    ManagedExecution?: ManagedExecution | undefined;
    Regions?: string[] | undefined;
}
export interface DescribeStackSetOutput {
    StackSet?: (StackSet & {
        Tags: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
    }) | undefined;
}
export interface DescribeStackSetOperationInput {
    StackSetName?: string | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export type StackSetOperationAction = "CREATE" | "UPDATE" | "DELETE" | "DETECT_DRIFT" | (string & {});
export type StackSetOperationStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "STOPPING" | "STOPPED" | "QUEUED" | (string & {});
export type RetainStacksNullable = boolean;
export type StackSetOperationStatusReason = string;
export interface StackSetOperationStatusDetails {
    FailedStackInstancesCount?: number | undefined;
}
export interface StackSetOperation {
    OperationId?: string | undefined;
    StackSetId?: string | undefined;
    Action?: StackSetOperationAction | undefined;
    Status?: StackSetOperationStatus | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    RetainStacks?: boolean | undefined;
    AdministrationRoleARN?: string | undefined;
    ExecutionRoleName?: string | undefined;
    CreationTimestamp?: Date | undefined;
    EndTimestamp?: Date | undefined;
    DeploymentTargets?: DeploymentTargets | undefined;
    StackSetDriftDetectionDetails?: StackSetDriftDetectionDetails | undefined;
    StatusReason?: string | undefined;
    StatusDetails?: StackSetOperationStatusDetails | undefined;
}
export interface DescribeStackSetOperationOutput {
    StackSetOperation?: StackSetOperation | undefined;
}
export type PublicVersionNumber = string;
export interface DescribeTypeInput {
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    Arn?: string | undefined;
    VersionId?: string | undefined;
    PublisherId?: string | undefined;
    PublicVersionNumber?: string | undefined;
}
export type IsDefaultVersion = boolean;
export type TypeTestsStatus = "PASSED" | "FAILED" | "IN_PROGRESS" | "NOT_TESTED" | (string & {});
export type TypeTestsStatusDescription = string;
export type TypeSchema = string;
export type ProvisioningType = "NON_PROVISIONABLE" | "IMMUTABLE" | "FULLY_MUTABLE" | (string & {});
export type DeprecatedStatus = "LIVE" | "DEPRECATED" | (string & {});
export type SupportedMajorVersion = number;
export type SupportedMajorVersions = number[];
export interface RequiredActivatedType {
    TypeNameAlias?: string | undefined;
    OriginalTypeName?: string | undefined;
    PublisherId?: string | undefined;
    SupportedMajorVersions?: number[] | undefined;
}
export type RequiredActivatedTypes = RequiredActivatedType[];
export type Visibility = "PUBLIC" | "PRIVATE" | (string & {});
export type OptionalSecureUrl = string;
export type ConfigurationSchema = string;
export type IsActivated = boolean;
export interface DescribeTypeOutput {
    Arn?: string | undefined;
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    DefaultVersionId?: string | undefined;
    IsDefaultVersion?: boolean | undefined;
    TypeTestsStatus?: TypeTestsStatus | undefined;
    TypeTestsStatusDescription?: string | undefined;
    Description?: string | undefined;
    Schema?: string | undefined;
    ProvisioningType?: ProvisioningType | undefined;
    DeprecatedStatus?: DeprecatedStatus | undefined;
    LoggingConfig?: (LoggingConfig & {
        LogRoleArn: RoleARN2;
        LogGroupName: LogGroupName;
    }) | undefined;
    RequiredActivatedTypes?: RequiredActivatedType[] | undefined;
    ExecutionRoleArn?: string | undefined;
    Visibility?: Visibility | undefined;
    SourceUrl?: string | undefined;
    DocumentationUrl?: string | undefined;
    LastUpdated?: Date | undefined;
    TimeCreated?: Date | undefined;
    ConfigurationSchema?: string | undefined;
    PublisherId?: string | undefined;
    OriginalTypeName?: string | undefined;
    OriginalTypeArn?: string | undefined;
    PublicVersionNumber?: string | undefined;
    LatestPublicVersion?: string | undefined;
    IsActivated?: boolean | undefined;
    AutoUpdate?: boolean | undefined;
}
export type RegistrationToken = string;
export interface DescribeTypeRegistrationInput {
    RegistrationToken?: string | undefined;
}
export type RegistrationStatus = "COMPLETE" | "IN_PROGRESS" | "FAILED" | (string & {});
export interface DescribeTypeRegistrationOutput {
    ProgressStatus?: RegistrationStatus | undefined;
    Description?: string | undefined;
    TypeArn?: string | undefined;
    TypeVersionArn?: string | undefined;
}
export type LogicalResourceIds = string[];
export interface DetectStackDriftInput {
    StackName?: string | undefined;
    LogicalResourceIds?: string[] | undefined;
}
export interface DetectStackDriftOutput {
    StackDriftDetectionId: string;
}
export interface DetectStackResourceDriftInput {
    StackName?: string | undefined;
    LogicalResourceId?: string | undefined;
}
export interface DetectStackResourceDriftOutput {
    StackResourceDrift: StackResourceDrift & {
        StackId: StackId;
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        StackResourceDriftStatus: StackResourceDriftStatus;
        Timestamp: Date;
        PhysicalResourceIdContext: (PhysicalResourceIdContextKeyValuePair & {
            Key: Key;
            Value: Value;
        })[];
        PropertyDifferences: (PropertyDifference & {
            PropertyPath: PropertyPath;
            ExpectedValue: PropertyValue;
            ActualValue: PropertyValue;
            DifferenceType: DifferenceType;
        })[];
    };
}
export type StackSetNameOrId = string;
export interface DetectStackSetDriftInput {
    StackSetName?: string | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface DetectStackSetDriftOutput {
    OperationId?: string | undefined;
}
export interface EstimateTemplateCostInput {
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    Parameters?: Parameter[] | undefined;
}
export type Url = string;
export interface EstimateTemplateCostOutput {
    Url?: string | undefined;
}
export interface ExecuteChangeSetInput {
    ChangeSetName?: string | undefined;
    StackName?: string | undefined;
    ClientRequestToken?: string | undefined;
    DisableRollback?: boolean | undefined;
    RetainExceptOnCreate?: boolean | undefined;
}
export interface ExecuteChangeSetOutput {
}
export interface ExecuteStackRefactorInput {
    StackRefactorId?: string | undefined;
}
export interface ExecuteStackRefactorResponse {
}
export type TemplateFormat = "JSON" | "YAML" | (string & {});
export interface GetGeneratedTemplateInput {
    Format?: TemplateFormat | undefined;
    GeneratedTemplateName?: string | undefined;
}
export interface GetGeneratedTemplateOutput {
    Status?: GeneratedTemplateStatus | undefined;
    TemplateBody?: string | undefined;
}
export interface GetHookResultInput {
    HookResultId?: string | undefined;
}
export type HookTypeArn = string;
export type HookTargetId = string;
export type HookTargetAction = "CREATE" | "UPDATE" | "DELETE" | "IMPORT" | (string & {});
export interface HookTarget {
    TargetType?: HookTargetType | undefined;
    TargetTypeName?: string | undefined;
    TargetId?: string | undefined;
    Action?: HookTargetAction | undefined;
}
export type AnnotationName = string;
export type AnnotationStatus = "PASSED" | "FAILED" | "SKIPPED" | (string & {});
export type RemediationMessageStatusMessage = string;
export type RemediationMessageRemediationMessage = string;
export type AnnotationRemediationLink = string;
export type AnnotationSeverityLevel = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export interface Annotation {
    AnnotationName?: string | undefined;
    Status?: AnnotationStatus | undefined;
    StatusMessage?: string | undefined;
    RemediationMessage?: string | undefined;
    RemediationLink?: string | undefined;
    SeverityLevel?: AnnotationSeverityLevel | undefined;
}
export type AnnotationList = Annotation[];
export interface GetHookResultOutput {
    HookResultId?: string | undefined;
    InvocationPoint?: HookInvocationPoint | undefined;
    FailureMode?: HookFailureMode | undefined;
    TypeName?: string | undefined;
    OriginalTypeName?: string | undefined;
    TypeVersionId?: string | undefined;
    TypeConfigurationVersionId?: string | undefined;
    TypeArn?: string | undefined;
    Status?: HookStatus | undefined;
    HookStatusReason?: string | undefined;
    InvokedAt?: Date | undefined;
    Target?: (HookTarget & {
        TargetType: HookTargetType;
        TargetTypeName: HookTargetTypeName;
        TargetId: HookTargetId;
        Action: HookTargetAction;
    }) | undefined;
    Annotations?: Annotation[] | undefined;
}
export interface GetStackPolicyInput {
    StackName?: string | undefined;
}
export interface GetStackPolicyOutput {
    StackPolicyBody?: string | undefined;
}
export type TemplateStage = "Original" | "Processed" | (string & {});
export interface GetTemplateInput {
    StackName?: string | undefined;
    ChangeSetName?: string | undefined;
    TemplateStage?: TemplateStage | undefined;
}
export type StageList = TemplateStage[];
export interface GetTemplateOutput {
    TemplateBody?: string | undefined;
    StagesAvailable?: TemplateStage[] | undefined;
}
export type TreatUnrecognizedResourceTypesAsWarnings = boolean;
export interface TemplateSummaryConfig {
    TreatUnrecognizedResourceTypesAsWarnings?: boolean | undefined;
}
export interface GetTemplateSummaryInput {
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    StackName?: string | undefined;
    StackSetName?: string | undefined;
    CallAs?: CallAs | undefined;
    TemplateSummaryConfig?: TemplateSummaryConfig | undefined;
}
export type ParameterType = string;
export type NoEcho = boolean;
export type AllowedValue = string;
export type AllowedValues = string[];
export interface ParameterConstraints {
    AllowedValues?: string[] | undefined;
}
export interface ParameterDeclaration {
    ParameterKey?: string | undefined;
    DefaultValue?: string | undefined;
    ParameterType?: string | undefined;
    NoEcho?: boolean | undefined;
    Description?: string | undefined;
    ParameterConstraints?: ParameterConstraints | undefined;
}
export type ParameterDeclarations = ParameterDeclaration[];
export type CapabilitiesReason = string;
export type Version = string;
export type TransformName = string;
export type TransformsList = string[];
export type ResourceIdentifiers = string[];
export interface ResourceIdentifierSummary {
    ResourceType?: string | undefined;
    LogicalResourceIds?: string[] | undefined;
    ResourceIdentifiers?: string[] | undefined;
}
export type ResourceIdentifierSummaries = ResourceIdentifierSummary[];
export interface Warnings {
    UnrecognizedResourceTypes?: string[] | undefined;
}
export interface GetTemplateSummaryOutput {
    Parameters?: ParameterDeclaration[] | undefined;
    Description?: string | undefined;
    Capabilities?: Capability[] | undefined;
    CapabilitiesReason?: string | undefined;
    ResourceTypes?: string[] | undefined;
    Version?: string | undefined;
    Metadata?: string | undefined;
    DeclaredTransforms?: string[] | undefined;
    ResourceIdentifierSummaries?: ResourceIdentifierSummary[] | undefined;
    Warnings?: Warnings | undefined;
}
export type StackIdList = string[];
export type StackIdsUrl = string;
export interface ImportStacksToStackSetInput {
    StackSetName?: string | undefined;
    StackIds?: string[] | undefined;
    StackIdsUrl?: string | undefined;
    OrganizationalUnitIds?: string[] | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface ImportStacksToStackSetOutput {
    OperationId?: string | undefined;
}
export interface ListChangeSetsInput {
    StackName?: string | undefined;
    NextToken?: string | undefined;
}
export interface ChangeSetSummary {
    StackId?: string | undefined;
    StackName?: string | undefined;
    ChangeSetId?: string | undefined;
    ChangeSetName?: string | undefined;
    ExecutionStatus?: ExecutionStatus | undefined;
    Status?: ChangeSetStatus | undefined;
    StatusReason?: string | undefined;
    CreationTime?: Date | undefined;
    Description?: string | undefined;
    IncludeNestedStacks?: boolean | undefined;
    ParentChangeSetId?: string | undefined;
    RootChangeSetId?: string | undefined;
    ImportExistingResources?: boolean | undefined;
}
export type ChangeSetSummaries = ChangeSetSummary[];
export interface ListChangeSetsOutput {
    Summaries?: ChangeSetSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListExportsInput {
    NextToken?: string | undefined;
}
export type ExportValue = string;
export interface Export {
    ExportingStackId?: string | undefined;
    Name?: string | undefined;
    Value?: string | undefined;
}
export type Exports = Export[];
export interface ListExportsOutput {
    Exports?: Export[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResults = number;
export interface ListGeneratedTemplatesInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type NumberOfResources = number;
export interface TemplateSummary {
    GeneratedTemplateId?: string | undefined;
    GeneratedTemplateName?: string | undefined;
    Status?: GeneratedTemplateStatus | undefined;
    StatusReason?: string | undefined;
    CreationTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    NumberOfResources?: number | undefined;
}
export type TemplateSummaries = TemplateSummary[];
export interface ListGeneratedTemplatesOutput {
    Summaries?: TemplateSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ListHookResultsTargetType = "CHANGE_SET" | "STACK" | "RESOURCE" | "CLOUD_CONTROL" | (string & {});
export type HookResultId = string;
export interface ListHookResultsInput {
    TargetType?: ListHookResultsTargetType | undefined;
    TargetId?: string | undefined;
    TypeArn?: string | undefined;
    Status?: HookStatus | undefined;
    NextToken?: string | undefined;
}
export interface HookResultSummary {
    HookResultId?: string | undefined;
    InvocationPoint?: HookInvocationPoint | undefined;
    FailureMode?: HookFailureMode | undefined;
    TypeName?: string | undefined;
    TypeVersionId?: string | undefined;
    TypeConfigurationVersionId?: string | undefined;
    Status?: HookStatus | undefined;
    HookStatusReason?: string | undefined;
    InvokedAt?: Date | undefined;
    TargetType?: ListHookResultsTargetType | undefined;
    TargetId?: string | undefined;
    TypeArn?: string | undefined;
    HookExecutionTarget?: string | undefined;
}
export type HookResultSummaries = HookResultSummary[];
export interface ListHookResultsOutput {
    TargetType?: ListHookResultsTargetType | undefined;
    TargetId?: string | undefined;
    HookResults?: HookResultSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListImportsInput {
    ExportName?: string | undefined;
    NextToken?: string | undefined;
}
export type Imports = string[];
export interface ListImportsOutput {
    Imports?: string[] | undefined;
    NextToken?: string | undefined;
}
export type JazzResourceIdentifierPropertyKey = string;
export type JazzResourceIdentifierPropertyValue = string;
export type JazzResourceIdentifierProperties = {
    [key: string]: string | undefined;
};
export interface ScannedResourceIdentifier {
    ResourceType?: string | undefined;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ScannedResourceIdentifiers = ScannedResourceIdentifier[];
export interface ListResourceScanRelatedResourcesInput {
    ResourceScanId?: string | undefined;
    Resources?: ScannedResourceIdentifier[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ManagedByStack = boolean;
export interface ScannedResource {
    ResourceType?: string | undefined;
    ResourceIdentifier?: {
        [key: string]: string | undefined;
    } | undefined;
    ManagedByStack?: boolean | undefined;
}
export type RelatedResources = ScannedResource[];
export interface ListResourceScanRelatedResourcesOutput {
    RelatedResources?: ScannedResource[] | undefined;
    NextToken?: string | undefined;
}
export type ResourceIdentifier = string;
export type ResourceTypePrefix = string;
export type ResourceScannerMaxResults = number;
export interface ListResourceScanResourcesInput {
    ResourceScanId?: string | undefined;
    ResourceIdentifier?: string | undefined;
    ResourceTypePrefix?: string | undefined;
    TagKey?: string | undefined;
    TagValue?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ScannedResources = ScannedResource[];
export interface ListResourceScanResourcesOutput {
    Resources?: ScannedResource[] | undefined;
    NextToken?: string | undefined;
}
export type ScanType = "FULL" | "PARTIAL" | (string & {});
export interface ListResourceScansInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ScanTypeFilter?: ScanType | undefined;
}
export interface ResourceScanSummary {
    ResourceScanId?: string | undefined;
    Status?: ResourceScanStatus | undefined;
    StatusReason?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    PercentageCompleted?: number | undefined;
    ScanType?: ScanType | undefined;
}
export type ResourceScanSummaries = ResourceScanSummary[];
export interface ListResourceScansOutput {
    ResourceScanSummaries?: ResourceScanSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStackInstanceResourceDriftsInput {
    StackSetName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    StackInstanceResourceDriftStatuses?: StackResourceDriftStatus[] | undefined;
    StackInstanceAccount?: string | undefined;
    StackInstanceRegion?: string | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface StackInstanceResourceDriftsSummary {
    StackId?: string | undefined;
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    PhysicalResourceIdContext?: PhysicalResourceIdContextKeyValuePair[] | undefined;
    ResourceType?: string | undefined;
    PropertyDifferences?: PropertyDifference[] | undefined;
    StackResourceDriftStatus?: StackResourceDriftStatus | undefined;
    Timestamp?: Date | undefined;
}
export type StackInstanceResourceDriftsSummaries = StackInstanceResourceDriftsSummary[];
export interface ListStackInstanceResourceDriftsOutput {
    Summaries?: (StackInstanceResourceDriftsSummary & {
        StackId: StackId;
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        StackResourceDriftStatus: StackResourceDriftStatus;
        Timestamp: Date;
        PhysicalResourceIdContext: (PhysicalResourceIdContextKeyValuePair & {
            Key: Key;
            Value: Value;
        })[];
        PropertyDifferences: (PropertyDifference & {
            PropertyPath: PropertyPath;
            ExpectedValue: PropertyValue;
            ActualValue: PropertyValue;
            DifferenceType: DifferenceType;
        })[];
    })[] | undefined;
    NextToken?: string | undefined;
}
export type StackInstanceFilterName = "DETAILED_STATUS" | "LAST_OPERATION_ID" | "DRIFT_STATUS" | (string & {});
export type StackInstanceFilterValues = string;
export interface StackInstanceFilter {
    Name?: StackInstanceFilterName | undefined;
    Values?: string | undefined;
}
export type StackInstanceFilters = StackInstanceFilter[];
export interface ListStackInstancesInput {
    StackSetName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: StackInstanceFilter[] | undefined;
    StackInstanceAccount?: string | undefined;
    StackInstanceRegion?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface StackInstanceSummary {
    StackSetId?: string | undefined;
    Region?: string | undefined;
    Account?: string | undefined;
    StackId?: string | undefined;
    Status?: StackInstanceStatus | undefined;
    StatusReason?: string | undefined;
    StackInstanceStatus?: StackInstanceComprehensiveStatus | undefined;
    OrganizationalUnitId?: string | undefined;
    DriftStatus?: StackDriftStatus | undefined;
    LastDriftCheckTimestamp?: Date | undefined;
    LastOperationId?: string | undefined;
}
export type StackInstanceSummaries = StackInstanceSummary[];
export interface ListStackInstancesOutput {
    Summaries?: StackInstanceSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStackRefactorActionsInput {
    StackRefactorId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type StackRefactorActionType = "MOVE" | "CREATE" | (string & {});
export type StackRefactorActionEntity = "RESOURCE" | "STACK" | (string & {});
export type StackRefactorResourceIdentifier = string;
export type StackRefactorDetection = "AUTO" | "MANUAL" | (string & {});
export type DetectionReason = string;
export type StackRefactorTagResources = Tag[];
export type StackRefactorUntagResources = string[];
export interface StackRefactorAction {
    Action?: StackRefactorActionType | undefined;
    Entity?: StackRefactorActionEntity | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceIdentifier?: string | undefined;
    Description?: string | undefined;
    Detection?: StackRefactorDetection | undefined;
    DetectionReason?: string | undefined;
    TagResources?: Tag[] | undefined;
    UntagResources?: string[] | undefined;
    ResourceMapping?: ResourceMapping | undefined;
}
export type StackRefactorActions = StackRefactorAction[];
export interface ListStackRefactorActionsOutput {
    StackRefactorActions: (StackRefactorAction & {
        TagResources: (Tag & {
            Key: TagKey;
            Value: TagValue;
        })[];
        ResourceMapping: ResourceMapping & {
            Source: ResourceLocation & {
                StackName: StackName;
                LogicalResourceId: LogicalResourceId;
            };
            Destination: ResourceLocation & {
                StackName: StackName;
                LogicalResourceId: LogicalResourceId;
            };
        };
    })[];
    NextToken?: string | undefined;
}
export type StackRefactorExecutionStatusFilter = StackRefactorExecutionStatus[];
export interface ListStackRefactorsInput {
    ExecutionStatusFilter?: StackRefactorExecutionStatus[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface StackRefactorSummary {
    StackRefactorId?: string | undefined;
    Description?: string | undefined;
    ExecutionStatus?: StackRefactorExecutionStatus | undefined;
    ExecutionStatusReason?: string | undefined;
    Status?: StackRefactorStatus | undefined;
    StatusReason?: string | undefined;
}
export type StackRefactorSummaries = StackRefactorSummary[];
export interface ListStackRefactorsOutput {
    StackRefactorSummaries: StackRefactorSummary[];
    NextToken?: string | undefined;
}
export interface ListStackResourcesInput {
    StackName?: string | undefined;
    NextToken?: string | undefined;
}
export interface StackResourceDriftInformationSummary {
    StackResourceDriftStatus?: StackResourceDriftStatus | undefined;
    LastCheckTimestamp?: Date | undefined;
}
export interface StackResourceSummary {
    LogicalResourceId?: string | undefined;
    PhysicalResourceId?: string | undefined;
    ResourceType?: string | undefined;
    LastUpdatedTimestamp?: Date | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ResourceStatusReason?: string | undefined;
    DriftInformation?: StackResourceDriftInformationSummary | undefined;
    ModuleInfo?: ModuleInfo | undefined;
}
export type StackResourceSummaries = StackResourceSummary[];
export interface ListStackResourcesOutput {
    StackResourceSummaries?: (StackResourceSummary & {
        LogicalResourceId: LogicalResourceId;
        ResourceType: ResourceType;
        LastUpdatedTimestamp: Date;
        ResourceStatus: ResourceStatus;
        DriftInformation: StackResourceDriftInformationSummary & {
            StackResourceDriftStatus: StackResourceDriftStatus;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type StackStatusFilter = StackStatus[];
export interface ListStacksInput {
    NextToken?: string | undefined;
    StackStatusFilter?: StackStatus[] | undefined;
}
export type TemplateDescription = string;
export interface StackDriftInformationSummary {
    StackDriftStatus?: StackDriftStatus | undefined;
    LastCheckTimestamp?: Date | undefined;
}
export interface StackSummary {
    StackId?: string | undefined;
    StackName?: string | undefined;
    TemplateDescription?: string | undefined;
    CreationTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    DeletionTime?: Date | undefined;
    StackStatus?: StackStatus | undefined;
    StackStatusReason?: string | undefined;
    ParentId?: string | undefined;
    RootId?: string | undefined;
    DriftInformation?: StackDriftInformationSummary | undefined;
    LastOperations?: OperationEntry[] | undefined;
}
export type StackSummaries = StackSummary[];
export interface ListStacksOutput {
    StackSummaries?: (StackSummary & {
        StackName: StackName;
        CreationTime: CreationTime;
        StackStatus: StackStatus;
        DriftInformation: StackDriftInformationSummary & {
            StackDriftStatus: StackDriftStatus;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStackSetAutoDeploymentTargetsInput {
    StackSetName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CallAs?: CallAs | undefined;
}
export interface StackSetAutoDeploymentTargetSummary {
    OrganizationalUnitId?: string | undefined;
    Regions?: string[] | undefined;
}
export type StackSetAutoDeploymentTargetSummaries = StackSetAutoDeploymentTargetSummary[];
export interface ListStackSetAutoDeploymentTargetsOutput {
    Summaries?: StackSetAutoDeploymentTargetSummary[] | undefined;
    NextToken?: string | undefined;
}
export type OperationResultFilterName = "OPERATION_RESULT_STATUS" | (string & {});
export type OperationResultFilterValues = string;
export interface OperationResultFilter {
    Name?: OperationResultFilterName | undefined;
    Values?: string | undefined;
}
export type OperationResultFilters = OperationResultFilter[];
export interface ListStackSetOperationResultsInput {
    StackSetName?: string | undefined;
    OperationId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CallAs?: CallAs | undefined;
    Filters?: OperationResultFilter[] | undefined;
}
export type StackSetOperationResultStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | (string & {});
export type AccountGateStatus = "SUCCEEDED" | "FAILED" | "SKIPPED" | (string & {});
export type AccountGateStatusReason = string;
export interface AccountGateResult {
    Status?: AccountGateStatus | undefined;
    StatusReason?: string | undefined;
}
export interface StackSetOperationResultSummary {
    Account?: string | undefined;
    Region?: string | undefined;
    Status?: StackSetOperationResultStatus | undefined;
    StatusReason?: string | undefined;
    AccountGateResult?: AccountGateResult | undefined;
    OrganizationalUnitId?: string | undefined;
}
export type StackSetOperationResultSummaries = StackSetOperationResultSummary[];
export interface ListStackSetOperationResultsOutput {
    Summaries?: StackSetOperationResultSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStackSetOperationsInput {
    StackSetName?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    CallAs?: CallAs | undefined;
}
export interface StackSetOperationSummary {
    OperationId?: string | undefined;
    Action?: StackSetOperationAction | undefined;
    Status?: StackSetOperationStatus | undefined;
    CreationTimestamp?: Date | undefined;
    EndTimestamp?: Date | undefined;
    StatusReason?: string | undefined;
    StatusDetails?: StackSetOperationStatusDetails | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
}
export type StackSetOperationSummaries = StackSetOperationSummary[];
export interface ListStackSetOperationsOutput {
    Summaries?: StackSetOperationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListStackSetsInput {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Status?: StackSetStatus | undefined;
    CallAs?: CallAs | undefined;
}
export interface StackSetSummary {
    StackSetName?: string | undefined;
    StackSetId?: string | undefined;
    Description?: string | undefined;
    Status?: StackSetStatus | undefined;
    AutoDeployment?: AutoDeployment | undefined;
    PermissionModel?: PermissionModels | undefined;
    DriftStatus?: StackDriftStatus | undefined;
    LastDriftCheckTimestamp?: Date | undefined;
    ManagedExecution?: ManagedExecution | undefined;
}
export type StackSetSummaries = StackSetSummary[];
export interface ListStackSetsOutput {
    Summaries?: StackSetSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTypeRegistrationsInput {
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    TypeArn?: string | undefined;
    RegistrationStatusFilter?: RegistrationStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type RegistrationTokenList = string[];
export interface ListTypeRegistrationsOutput {
    RegistrationTokenList?: string[] | undefined;
    NextToken?: string | undefined;
}
export type Category = "REGISTERED" | "ACTIVATED" | "THIRD_PARTY" | "AWS_TYPES" | (string & {});
export type TypeNamePrefix = string;
export interface TypeFilters {
    Category?: Category | undefined;
    PublisherId?: string | undefined;
    TypeNamePrefix?: string | undefined;
}
export interface ListTypesInput {
    Visibility?: Visibility | undefined;
    ProvisioningType?: ProvisioningType | undefined;
    DeprecatedStatus?: DeprecatedStatus | undefined;
    Type?: RegistryType | undefined;
    Filters?: TypeFilters | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PublisherName = string;
export interface TypeSummary {
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    DefaultVersionId?: string | undefined;
    TypeArn?: string | undefined;
    LastUpdated?: Date | undefined;
    Description?: string | undefined;
    PublisherId?: string | undefined;
    OriginalTypeName?: string | undefined;
    PublicVersionNumber?: string | undefined;
    LatestPublicVersion?: string | undefined;
    PublisherIdentity?: IdentityProvider | undefined;
    PublisherName?: string | undefined;
    IsActivated?: boolean | undefined;
}
export type TypeSummaries = TypeSummary[];
export interface ListTypesOutput {
    TypeSummaries?: TypeSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTypeVersionsInput {
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    Arn?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    DeprecatedStatus?: DeprecatedStatus | undefined;
    PublisherId?: string | undefined;
}
export interface TypeVersionSummary {
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    VersionId?: string | undefined;
    IsDefaultVersion?: boolean | undefined;
    Arn?: string | undefined;
    TimeCreated?: Date | undefined;
    Description?: string | undefined;
    PublicVersionNumber?: string | undefined;
}
export type TypeVersionSummaries = TypeVersionSummary[];
export interface ListTypeVersionsOutput {
    TypeVersionSummaries?: TypeVersionSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface PublishTypeInput {
    Type?: ThirdPartyType | undefined;
    Arn?: string | undefined;
    TypeName?: string | undefined;
    PublicVersionNumber?: string | undefined;
}
export interface PublishTypeOutput {
    PublicTypeArn?: string | undefined;
}
export type OperationStatus = "PENDING" | "IN_PROGRESS" | "SUCCESS" | "FAILED" | (string & {});
export type StatusMessage = string;
export type HandlerErrorCode = "NotUpdatable" | "InvalidRequest" | "AccessDenied" | "InvalidCredentials" | "AlreadyExists" | "NotFound" | "ResourceConflict" | "Throttling" | "ServiceLimitExceeded" | "NotStabilized" | "GeneralServiceException" | "ServiceInternalError" | "NetworkFailure" | "InternalFailure" | "InvalidTypeConfiguration" | "HandlerInternalFailure" | "NonCompliant" | "Unknown" | "UnsupportedTarget" | (string & {});
export type ResourceModel = string;
export interface RecordHandlerProgressInput {
    BearerToken?: string | undefined;
    OperationStatus?: OperationStatus | undefined;
    CurrentOperationStatus?: OperationStatus | undefined;
    StatusMessage?: string | undefined;
    ErrorCode?: HandlerErrorCode | undefined;
    ResourceModel?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface RecordHandlerProgressOutput {
}
export type AcceptTermsAndConditions = boolean;
export type ConnectionArn = string;
export interface RegisterPublisherInput {
    AcceptTermsAndConditions?: boolean | undefined;
    ConnectionArn?: string | undefined;
}
export interface RegisterPublisherOutput {
    PublisherId?: string | undefined;
}
export type S3Url = string;
export type RequestToken = string;
export interface RegisterTypeInput {
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    SchemaHandlerPackage?: string | undefined;
    LoggingConfig?: LoggingConfig | undefined;
    ExecutionRoleArn?: string | undefined;
    ClientRequestToken?: string | undefined;
}
export interface RegisterTypeOutput {
    RegistrationToken?: string | undefined;
}
export interface RemoveAliasInput {
    AliasName?: string | undefined;
}
export interface RemoveAliasResponse {
}
export interface RollbackStackInput {
    StackName?: string | undefined;
    RoleARN?: string | undefined;
    ClientRequestToken?: string | undefined;
    RetainExceptOnCreate?: boolean | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
}
export interface RollbackStackOutput {
    StackId?: string | undefined;
    OperationId?: string | undefined;
}
export interface SetAliasInput {
    StackName?: string | undefined;
    AliasName?: string | undefined;
}
export interface SetAliasResponse {
}
export interface SetStackPolicyInput {
    StackName?: string | undefined;
    StackPolicyBody?: string | undefined;
    StackPolicyURL?: string | undefined;
}
export interface SetStackPolicyResponse {
}
export interface SetTypeConfigurationInput {
    TypeArn?: string | undefined;
    Configuration?: string | undefined;
    ConfigurationAlias?: string | undefined;
    TypeName?: string | undefined;
    Type?: ThirdPartyType | undefined;
}
export interface SetTypeConfigurationOutput {
    ConfigurationArn?: string | undefined;
}
export interface SetTypeDefaultVersionInput {
    Arn?: string | undefined;
    Type?: RegistryType | undefined;
    TypeName?: string | undefined;
    VersionId?: string | undefined;
}
export interface SetTypeDefaultVersionOutput {
}
export type ResourceSignalUniqueId = string;
export type ResourceSignalStatus = "SUCCESS" | "FAILURE" | (string & {});
export interface SignalResourceInput {
    StackName?: string | undefined;
    LogicalResourceId?: string | undefined;
    UniqueId?: string | undefined;
    Status?: ResourceSignalStatus | undefined;
}
export interface SignalResourceResponse {
}
export interface StartResourceScanInput {
    ClientRequestToken?: string | undefined;
    ScanFilters?: ScanFilter[] | undefined;
}
export interface StartResourceScanOutput {
    ResourceScanId?: string | undefined;
}
export interface StopStackSetOperationInput {
    StackSetName?: string | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface StopStackSetOperationOutput {
}
export type S3Bucket = string;
export interface TestTypeInput {
    Arn?: string | undefined;
    Type?: ThirdPartyType | undefined;
    TypeName?: string | undefined;
    VersionId?: string | undefined;
    LogDeliveryBucket?: string | undefined;
}
export interface TestTypeOutput {
    TypeVersionArn?: string | undefined;
}
export type JazzLogicalResourceIds = string[];
export type RefreshAllResources = boolean;
export interface UpdateGeneratedTemplateInput {
    GeneratedTemplateName?: string | undefined;
    NewGeneratedTemplateName?: string | undefined;
    AddResources?: ResourceDefinition[] | undefined;
    RemoveResources?: string[] | undefined;
    RefreshAllResources?: boolean | undefined;
    TemplateConfiguration?: TemplateConfiguration | undefined;
}
export interface UpdateGeneratedTemplateOutput {
    GeneratedTemplateId?: string | undefined;
}
export type StackPolicyDuringUpdateBody = string;
export type StackPolicyDuringUpdateURL = string;
export interface UpdateStackInput {
    StackName?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    UsePreviousTemplate?: boolean | undefined;
    StackPolicyDuringUpdateBody?: string | undefined;
    StackPolicyDuringUpdateURL?: string | undefined;
    Parameters?: Parameter[] | undefined;
    Capabilities?: Capability[] | undefined;
    ResourceTypes?: string[] | undefined;
    RoleARN?: string | undefined;
    RollbackConfiguration?: RollbackConfiguration | undefined;
    StackPolicyBody?: string | undefined;
    StackPolicyURL?: string | undefined;
    NotificationARNs?: string[] | undefined;
    Tags?: Tag[] | undefined;
    DisableRollback?: boolean | undefined;
    ClientRequestToken?: string | undefined;
    RetainExceptOnCreate?: boolean | undefined;
    DeploymentConfig?: DeploymentConfig | undefined;
    DisableValidation?: boolean | undefined;
}
export interface UpdateStackOutput {
    StackId?: string | undefined;
    OperationId?: string | undefined;
}
export interface UpdateStackInstancesInput {
    StackSetName?: string | undefined;
    Accounts?: string[] | undefined;
    DeploymentTargets?: DeploymentTargets | undefined;
    Regions?: string[] | undefined;
    ParameterOverrides?: Parameter[] | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    OperationId?: string | undefined;
    CallAs?: CallAs | undefined;
}
export interface UpdateStackInstancesOutput {
    OperationId?: string | undefined;
}
export interface UpdateStackSetInput {
    StackSetName?: string | undefined;
    Description?: string | undefined;
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
    UsePreviousTemplate?: boolean | undefined;
    Parameters?: Parameter[] | undefined;
    Capabilities?: Capability[] | undefined;
    Tags?: Tag[] | undefined;
    OperationPreferences?: StackSetOperationPreferences | undefined;
    AdministrationRoleARN?: string | undefined;
    ExecutionRoleName?: string | undefined;
    DeploymentTargets?: DeploymentTargets | undefined;
    PermissionModel?: PermissionModels | undefined;
    AutoDeployment?: AutoDeployment | undefined;
    OperationId?: string | undefined;
    Accounts?: string[] | undefined;
    Regions?: string[] | undefined;
    CallAs?: CallAs | undefined;
    ManagedExecution?: ManagedExecution | undefined;
}
export interface UpdateStackSetOutput {
    OperationId?: string | undefined;
}
export interface UpdateTerminationProtectionInput {
    EnableTerminationProtection?: boolean | undefined;
    StackName?: string | undefined;
}
export interface UpdateTerminationProtectionOutput {
    StackId?: string | undefined;
}
export interface ValidateTemplateInput {
    TemplateBody?: string | undefined;
    TemplateURL?: string | undefined;
}
export interface TemplateParameter {
    ParameterKey?: string | undefined;
    DefaultValue?: string | undefined;
    NoEcho?: boolean | undefined;
    Description?: string | undefined;
}
export type TemplateParameters = TemplateParameter[];
export interface ValidateTemplateOutput {
    Parameters?: TemplateParameter[] | undefined;
    Description?: string | undefined;
    Capabilities?: Capability[] | undefined;
    CapabilitiesReason?: string | undefined;
    DeclaredTransforms?: string[] | undefined;
}
export type ActivateOrganizationsAccessError = InvalidOperationException | OperationNotFoundException | CommonErrors;
/**
 * Activate trusted access with Organizations. With trusted access between StackSets
 * and Organizations activated, the management account has permissions to create
 * and manage StackSets for your organization.
 */
export declare const activateOrganizationsAccess: API.OperationMethod<ActivateOrganizationsAccessInput & RegionInput, ActivateOrganizationsAccessOutput, ActivateOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type ActivateTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Activates a public third-party extension, such as a resource or module, to make it
 * available for use in stack templates in your current account and Region. It can also create
 * CloudFormation Hooks, which allow you to evaluate resource configurations before CloudFormation
 * provisions them. Hooks integrate with both CloudFormation and Cloud Control API operations.
 *
 * After you activate an extension, you can use SetTypeConfiguration to set specific properties for the extension.
 *
 * To see which extensions have been activated, use ListTypes. To see
 * configuration details for an extension, use DescribeType.
 *
 * For more information, see Activate a
 * third-party public extension in your account in the
 * *CloudFormation User Guide*. For information about creating Hooks, see the
 * CloudFormation Hooks User Guide.
 */
export declare const activateType: API.OperationMethod<ActivateTypeInput & RegionInput, ActivateTypeOutput, ActivateTypeError, Credentials | HttpClient.HttpClient>;
export type BatchDescribeTypeConfigurationsError = CFNRegistryException | TypeConfigurationNotFoundException | CommonErrors;
/**
 * Returns configuration data for the specified CloudFormation extensions, from the CloudFormation
 * registry in your current account and Region.
 *
 * For more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 */
export declare const batchDescribeTypeConfigurations: API.OperationMethod<BatchDescribeTypeConfigurationsInput & RegionInput, BatchDescribeTypeConfigurationsOutput, BatchDescribeTypeConfigurationsError, Credentials | HttpClient.HttpClient>;
export type CancelUpdateStackError = TokenAlreadyExistsException | CommonErrors;
/**
 * Cancels an update on the specified stack. If the call completes successfully, the stack
 * rolls back the update and reverts to the previous stack configuration.
 *
 * You can cancel only stacks that are in the `UPDATE_IN_PROGRESS` state.
 */
export declare const cancelUpdateStack: API.OperationMethod<CancelUpdateStackInput & RegionInput, CancelUpdateStackResponse, CancelUpdateStackError, Credentials | HttpClient.HttpClient>;
export type ContinueUpdateRollbackError = TokenAlreadyExistsException | CommonErrors;
/**
 * Continues rolling back a stack from `UPDATE_ROLLBACK_FAILED` to
 * `UPDATE_ROLLBACK_COMPLETE` state. Depending on the cause of the failure, you can
 * manually fix the error and continue the rollback. By continuing the rollback, you can return
 * your stack to a working state (the `UPDATE_ROLLBACK_COMPLETE` state) and then try
 * to update the stack again.
 *
 * A stack enters the `UPDATE_ROLLBACK_FAILED` state when CloudFormation can't roll
 * back all changes after a failed stack update. For example, this might occur when a stack
 * attempts to roll back to an old database that was deleted outside of CloudFormation. Because
 * CloudFormation doesn't know the instance was deleted, it assumes the instance still exists and
 * attempts to roll back to it, causing the update rollback to fail.
 *
 * For more information, see Continue rolling back an update in the *CloudFormation User Guide*. For
 * information for troubleshooting a failed update rollback, see Update rollback failed.
 *
 * `ForceRollback` and `ResourcesToSkip` are mutually exclusive.
 * For details, see ContinueUpdateRollbackInput$ForceRollback.
 */
export declare const continueUpdateRollback: API.OperationMethod<ContinueUpdateRollbackInput & RegionInput, ContinueUpdateRollbackOutput, ContinueUpdateRollbackError, Credentials | HttpClient.HttpClient>;
export type CreateChangeSetError = AlreadyExistsException | InsufficientCapabilitiesException | LimitExceededException | CommonErrors;
/**
 * Creates a list of changes that will be applied to a stack so that you can review the
 * changes before executing them. You can create a change set for a stack that doesn't exist or
 * an existing stack. If you create a change set for a stack that doesn't exist, the change set
 * shows all of the resources that CloudFormation will create. If you create a change set for an
 * existing stack, CloudFormation compares the stack's information with the information that you
 * submit in the change set and lists the differences. Use change sets to understand which
 * resources CloudFormation will create or change, and how it will change resources in an existing
 * stack, before you create or update a stack.
 *
 * To create a change set for a stack that doesn't exist, for the `ChangeSetType`
 * parameter, specify `CREATE`. To create a change set for an existing stack, specify
 * `UPDATE` for the `ChangeSetType` parameter. To create a change set for
 * an import operation, specify `IMPORT` for the `ChangeSetType` parameter.
 * After the `CreateChangeSet` call successfully completes, CloudFormation starts creating
 * the change set. To check the status of the change set or to review it, use the DescribeChangeSet action.
 *
 * When you are satisfied with the changes the change set will make, execute the change set
 * by using the ExecuteChangeSet action. CloudFormation doesn't make changes until
 * you execute the change set.
 *
 * To create a change set for the entire stack hierarchy, set
 * `IncludeNestedStacks` to `True`.
 */
export declare const createChangeSet: API.OperationMethod<CreateChangeSetInput & RegionInput, CreateChangeSetOutput, CreateChangeSetError, Credentials | HttpClient.HttpClient>;
export type CreateGeneratedTemplateError = AlreadyExistsException | ConcurrentResourcesLimitExceededException | LimitExceededException | CommonErrors;
/**
 * Creates a template from existing resources that are not already managed with CloudFormation.
 * You can check the status of the template generation using the
 * `DescribeGeneratedTemplate` API action.
 */
export declare const createGeneratedTemplate: API.OperationMethod<CreateGeneratedTemplateInput & RegionInput, CreateGeneratedTemplateOutput, CreateGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateStackError = AlreadyExistsException | InsufficientCapabilitiesException | LimitExceededException | TokenAlreadyExistsException | CommonErrors;
/**
 * Creates a stack as specified in the template. After the call completes successfully, the
 * stack creation starts. You can check the status of the stack through the DescribeStacks operation.
 *
 * For more information about creating a stack and monitoring stack progress, see Managing Amazon Web Services
 * resources as a single unit with CloudFormation stacks in the
 * *CloudFormation User Guide*.
 */
export declare const createStack: API.OperationMethod<CreateStackInput & RegionInput, CreateStackOutput, CreateStackError, Credentials | HttpClient.HttpClient>;
export type CreateStackInstancesError = InvalidOperationException | LimitExceededException | OperationIdAlreadyExistsException | OperationInProgressException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Creates stack instances for the specified accounts, within the specified Amazon Web Services Regions. A
 * stack instance refers to a stack in a specific account and Region. You must specify at least
 * one value for either `Accounts` or `DeploymentTargets`, and you must
 * specify at least one value for `Regions`.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `CreateStackInstances` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const createStackInstances: API.OperationMethod<CreateStackInstancesInput & RegionInput, CreateStackInstancesOutput, CreateStackInstancesError, Credentials | HttpClient.HttpClient>;
export type CreateStackRefactorError = CommonErrors;
/**
 * Creates a refactor across multiple stacks, with the list of stacks and resources that are
 * affected.
 */
export declare const createStackRefactor: API.OperationMethod<CreateStackRefactorInput & RegionInput, CreateStackRefactorOutput, CreateStackRefactorError, Credentials | HttpClient.HttpClient>;
export type CreateStackSetError = CreatedButModifiedException | LimitExceededException | NameAlreadyExistsException | CommonErrors;
/**
 * Creates a StackSet.
 */
export declare const createStackSet: API.OperationMethod<CreateStackSetInput & RegionInput, CreateStackSetOutput, CreateStackSetError, Credentials | HttpClient.HttpClient>;
export type DeactivateOrganizationsAccessError = InvalidOperationException | OperationNotFoundException | CommonErrors;
/**
 * Deactivates trusted access with Organizations. If trusted access is deactivated,
 * the management account does not have permissions to create and manage
 * service-managed StackSets for your organization.
 */
export declare const deactivateOrganizationsAccess: API.OperationMethod<DeactivateOrganizationsAccessInput & RegionInput, DeactivateOrganizationsAccessOutput, DeactivateOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type DeactivateTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Deactivates a public third-party extension, such as a resource or module, or a CloudFormation
 * Hook when you no longer use it.
 *
 * Deactivating an extension deletes the configuration details that are associated with it.
 * To temporarily disable a CloudFormation Hook instead, you can use SetTypeConfiguration.
 *
 * Once deactivated, an extension can't be used in any CloudFormation operation. This includes
 * stack update operations where the stack template includes the extension, even if no updates
 * are being made to the extension. In addition, deactivated extensions aren't automatically
 * updated if a new version of the extension is released.
 *
 * To see which extensions are currently activated, use ListTypes.
 */
export declare const deactivateType: API.OperationMethod<DeactivateTypeInput & RegionInput, DeactivateTypeOutput, DeactivateTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteChangeSetError = InvalidChangeSetStatusException | CommonErrors;
/**
 * Deletes the specified change set. Deleting change sets ensures that no one executes the
 * wrong change set.
 *
 * If the call successfully completes, CloudFormation successfully deleted the change set.
 *
 * If `IncludeNestedStacks` specifies `True` during the creation of the
 * nested change set, then `DeleteChangeSet` will delete all change sets that belong
 * to the stacks hierarchy and will also delete all change sets for nested stacks with the status
 * of `REVIEW_IN_PROGRESS`.
 */
export declare const deleteChangeSet: API.OperationMethod<DeleteChangeSetInput & RegionInput, DeleteChangeSetOutput, DeleteChangeSetError, Credentials | HttpClient.HttpClient>;
export type DeleteGeneratedTemplateError = ConcurrentResourcesLimitExceededException | GeneratedTemplateNotFoundException | CommonErrors;
/**
 * Deleted a generated template.
 */
export declare const deleteGeneratedTemplate: API.OperationMethod<DeleteGeneratedTemplateInput & RegionInput, DeleteGeneratedTemplateResponse, DeleteGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteStackError = TokenAlreadyExistsException | CommonErrors;
/**
 * Deletes a specified stack. Once the call completes successfully, stack deletion starts.
 * Deleted stacks don't show up in the DescribeStacks operation if the deletion
 * has been completed successfully.
 *
 * For more information about deleting a stack, see Delete a stack from
 * the CloudFormation console in the *CloudFormation User Guide*.
 */
export declare const deleteStack: API.OperationMethod<DeleteStackInput & RegionInput, DeleteStackResponse, DeleteStackError, Credentials | HttpClient.HttpClient>;
export type DeleteStackInstancesError = InvalidOperationException | OperationIdAlreadyExistsException | OperationInProgressException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Deletes stack instances for the specified accounts, in the specified Amazon Web Services Regions.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `DeleteStackInstances` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const deleteStackInstances: API.OperationMethod<DeleteStackInstancesInput & RegionInput, DeleteStackInstancesOutput, DeleteStackInstancesError, Credentials | HttpClient.HttpClient>;
export type DeleteStackSetError = OperationInProgressException | StackSetNotEmptyException | CommonErrors;
/**
 * Deletes a StackSet. Before you can delete a StackSet, all its member stack instances must
 * be deleted. For more information about how to complete this, see DeleteStackInstances.
 */
export declare const deleteStackSet: API.OperationMethod<DeleteStackSetInput & RegionInput, DeleteStackSetOutput, DeleteStackSetError, Credentials | HttpClient.HttpClient>;
export type DeregisterTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Marks an extension or extension version as `DEPRECATED` in the CloudFormation
 * registry, removing it from active use. Deprecated extensions or extension versions cannot be
 * used in CloudFormation operations.
 *
 * To deregister an entire extension, you must individually deregister all active versions of
 * that extension. If an extension has only a single active version, deregistering that version
 * results in the extension itself being deregistered and marked as deprecated in the
 * registry.
 *
 * You can't deregister the default version of an extension if there are other active version
 * of that extension. If you do deregister the default version of an extension, the extension
 * type itself is deregistered as well and marked as deprecated.
 *
 * To view the deprecation status of an extension or extension version, use DescribeType.
 *
 * For more information, see Remove
 * third-party private extensions from your account in the
 * *CloudFormation User Guide*.
 */
export declare const deregisterType: API.OperationMethod<DeregisterTypeInput & RegionInput, DeregisterTypeOutput, DeregisterTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountLimitsError = CommonErrors;
/**
 * Retrieves your account's CloudFormation limits, such as the maximum number of stacks that you
 * can create in your account. For more information about account limits, see Understand CloudFormation quotas in the *CloudFormation User Guide*.
 */
export declare const describeAccountLimits: API.PaginatedOperationMethod<DescribeAccountLimitsInput & RegionInput, DescribeAccountLimitsOutput, DescribeAccountLimitsError, Credentials | HttpClient.HttpClient, AccountLimit>;
export type DescribeChangeSetError = ChangeSetNotFoundException | CommonErrors;
/**
 * Returns the inputs for the change set and a list of changes that CloudFormation will make if
 * you execute the change set. For more information, see Update
 * CloudFormation stacks using change sets in the
 * *CloudFormation User Guide*.
 */
export declare const describeChangeSet: API.PaginatedOperationMethod<DescribeChangeSetInput & RegionInput, DescribeChangeSetOutput, DescribeChangeSetError, Credentials | HttpClient.HttpClient, Change>;
export type DescribeChangeSetHooksError = ChangeSetNotFoundException | CommonErrors;
/**
 * Returns Hook-related information for the change set and a list of changes that
 * CloudFormation makes when you run the change set.
 */
export declare const describeChangeSetHooks: API.OperationMethod<DescribeChangeSetHooksInput & RegionInput, DescribeChangeSetHooksOutput, DescribeChangeSetHooksError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns CloudFormation events based on flexible query criteria. Groups events by operation ID,
 * enabling you to focus on individual stack operations during deployment.
 *
 * An operation is any action performed on a stack, including stack lifecycle actions
 * (Create, Update, Delete, Rollback), change set creation, nested stack creation, and automatic
 * rollbacks triggered by failures. Each operation has a unique identifier (Operation ID) and
 * represents a discrete change attempt on the stack.
 *
 * Returns different types of events including:
 *
 * - **Progress events** - Status updates during stack operation
 * execution.
 *
 * - **Validation errors** - Failures from CloudFormation Early
 * Validations.
 *
 * - **Provisioning errors** - Resource creation and update
 * failures.
 *
 * - **Hook invocation errors** - Failures from CloudFormation
 * Hook during stack operations.
 *
 * One of `ChangeSetName`, `OperationId` or `StackName`
 * must be specified as input.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsInput & RegionInput, DescribeEventsOutput, DescribeEventsError, Credentials | HttpClient.HttpClient, OperationEvent>;
export type DescribeGeneratedTemplateError = GeneratedTemplateNotFoundException | CommonErrors;
/**
 * Describes a generated template. The output includes details about the progress of the
 * creation of a generated template started by a `CreateGeneratedTemplate` API action
 * or the update of a generated template started with an `UpdateGeneratedTemplate` API
 * action.
 */
export declare const describeGeneratedTemplate: API.OperationMethod<DescribeGeneratedTemplateInput & RegionInput, DescribeGeneratedTemplateOutput, DescribeGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationsAccessError = InvalidOperationException | OperationNotFoundException | CommonErrors;
/**
 * Retrieves information about the account's `OrganizationAccess` status. This API
 * can be called either by the management account or the delegated administrator by using the
 * `CallAs` parameter. This API can also be called without the `CallAs`
 * parameter by the management account.
 */
export declare const describeOrganizationsAccess: API.OperationMethod<DescribeOrganizationsAccessInput & RegionInput, DescribeOrganizationsAccessOutput, DescribeOrganizationsAccessError, Credentials | HttpClient.HttpClient>;
export type DescribePublisherError = CFNRegistryException | CommonErrors;
/**
 * Returns information about a CloudFormation extension publisher.
 *
 * If you don't supply a `PublisherId`, and you have registered as an extension
 * publisher, `DescribePublisher` returns information about your own publisher
 * account.
 *
 * For more information about registering as a publisher, see:
 *
 * - RegisterPublisher
 *
 * - Publishing extensions
 * to make them available for public use in the
 * *CloudFormation Command Line Interface (CLI) User Guide*
 */
export declare const describePublisher: API.OperationMethod<DescribePublisherInput & RegionInput, DescribePublisherOutput, DescribePublisherError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceScanError = ResourceScanNotFoundException | CommonErrors;
/**
 * Describes details of a resource scan.
 */
export declare const describeResourceScan: API.OperationMethod<DescribeResourceScanInput & RegionInput, DescribeResourceScanOutput, DescribeResourceScanError, Credentials | HttpClient.HttpClient>;
export type DescribeStackDriftDetectionStatusError = CommonErrors;
/**
 * Returns information about a stack drift detection operation. A stack drift detection
 * operation detects whether a stack's actual configuration differs, or has
 * *drifted*, from its expected configuration, as defined in the stack
 * template and any values specified as template parameters. A stack is considered to have
 * drifted if one or more of its resources have drifted. For more information about stack and
 * resource drift, see Detect unmanaged
 * configuration changes to stacks and resources with drift detection.
 *
 * Use DetectStackDrift to initiate a stack drift detection operation.
 * `DetectStackDrift` returns a `StackDriftDetectionId` you can use to
 * monitor the progress of the operation using `DescribeStackDriftDetectionStatus`.
 * Once the drift detection operation has completed, use DescribeStackResourceDrifts to return drift information about the stack and its
 * resources.
 */
export declare const describeStackDriftDetectionStatus: API.OperationMethod<DescribeStackDriftDetectionStatusInput & RegionInput, DescribeStackDriftDetectionStatusOutput, DescribeStackDriftDetectionStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeStackEventsError = CommonErrors;
/**
 * Returns all stack related events for a specified stack in reverse chronological order. For
 * more information about a stack's event history, see Understand CloudFormation stack creation events in the
 * *CloudFormation User Guide*.
 *
 * You can list events for stacks that have failed to create or have been deleted by
 * specifying the unique stack identifier (stack ID).
 */
export declare const describeStackEvents: API.PaginatedOperationMethod<DescribeStackEventsInput & RegionInput, DescribeStackEventsOutput, DescribeStackEventsError, Credentials | HttpClient.HttpClient, StackEvent>;
export type DescribeStackInstanceError = StackInstanceNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns the stack instance that's associated with the specified StackSet, Amazon Web Services account,
 * and Amazon Web Services Region.
 *
 * For a list of stack instances that are associated with a specific StackSet, use ListStackInstances.
 */
export declare const describeStackInstance: API.OperationMethod<DescribeStackInstanceInput & RegionInput, DescribeStackInstanceOutput, DescribeStackInstanceError, Credentials | HttpClient.HttpClient>;
export type DescribeStackRefactorError = StackRefactorNotFoundException | CommonErrors;
/**
 * Describes the stack refactor status.
 */
export declare const describeStackRefactor: API.OperationMethod<DescribeStackRefactorInput & RegionInput, DescribeStackRefactorOutput, DescribeStackRefactorError, Credentials | HttpClient.HttpClient>;
export type DescribeStackResourceError = CommonErrors;
/**
 * Returns a description of the specified resource in the specified stack.
 *
 * For deleted stacks, DescribeStackResource returns resource information for up to 90 days
 * after the stack has been deleted.
 */
export declare const describeStackResource: API.OperationMethod<DescribeStackResourceInput & RegionInput, DescribeStackResourceOutput, DescribeStackResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeStackResourceDriftsError = CommonErrors;
/**
 * Returns drift information for the resources that have been checked for drift in the
 * specified stack. This includes actual and expected configuration values for resources where
 * CloudFormation detects configuration drift.
 *
 * For a given stack, there will be one `StackResourceDrift` for each stack
 * resource that has been checked for drift. Resources that haven't yet been checked for drift
 * aren't included. Resources that don't currently support drift detection aren't checked, and so
 * not included. For a list of resources that support drift detection, see Resource
 * type support for imports and drift detection.
 *
 * Use DetectStackResourceDrift to detect drift on individual resources, or
 * DetectStackDrift to detect drift on all supported resources for a given
 * stack.
 */
export declare const describeStackResourceDrifts: API.PaginatedOperationMethod<DescribeStackResourceDriftsInput & RegionInput, DescribeStackResourceDriftsOutput, DescribeStackResourceDriftsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeStackResourcesError = CommonErrors;
/**
 * Returns Amazon Web Services resource descriptions for running and deleted stacks. If
 * `StackName` is specified, all the associated resources that are part of the stack
 * are returned. If `PhysicalResourceId` is specified, the associated resources of the
 * stack that the resource belongs to are returned.
 *
 * Only the first 100 resources will be returned. If your stack has more resources than
 * this, you should use `ListStackResources` instead.
 *
 * For deleted stacks, `DescribeStackResources` returns resource information for
 * up to 90 days after the stack has been deleted.
 *
 * You must specify either `StackName` or `PhysicalResourceId`, but not
 * both. In addition, you can specify `LogicalResourceId` to filter the returned
 * result. For more information about resources, the `LogicalResourceId` and
 * `PhysicalResourceId`, see the CloudFormation User Guide.
 *
 * A `ValidationError` is returned if you specify both `StackName`
 * and `PhysicalResourceId` in the same request.
 */
export declare const describeStackResources: API.OperationMethod<DescribeStackResourcesInput & RegionInput, DescribeStackResourcesOutput, DescribeStackResourcesError, Credentials | HttpClient.HttpClient>;
export type DescribeStacksError = StackNotFound | CommonErrors;
/**
 * Returns the description for the specified stack; if no stack name was specified, then it
 * returns the description for all the stacks created. For more information about a stack's event
 * history, see Understand CloudFormation stack creation events in the
 * *CloudFormation User Guide*.
 *
 * If the stack doesn't exist, a `ValidationError` is returned.
 */
export declare const describeStacks: API.PaginatedOperationMethod<DescribeStacksInput & RegionInput, DescribeStacksOutput, DescribeStacksError, Credentials | HttpClient.HttpClient, Stack>;
export type DescribeStackSetError = StackSetNotFoundException | CommonErrors;
/**
 * Returns the description of the specified StackSet.
 *
 * This API provides *strongly consistent* reads meaning it will always
 * return the most up-to-date data.
 */
export declare const describeStackSet: API.OperationMethod<DescribeStackSetInput & RegionInput, DescribeStackSetOutput, DescribeStackSetError, Credentials | HttpClient.HttpClient>;
export type DescribeStackSetOperationError = OperationNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns the description of the specified StackSet operation.
 *
 * This API provides *strongly consistent* reads meaning it will always
 * return the most up-to-date data.
 */
export declare const describeStackSetOperation: API.OperationMethod<DescribeStackSetOperationInput & RegionInput, DescribeStackSetOperationOutput, DescribeStackSetOperationError, Credentials | HttpClient.HttpClient>;
export type DescribeTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Returns detailed information about an extension from the CloudFormation registry in your
 * current account and Region.
 *
 * If you specify a `VersionId`, `DescribeType` returns information
 * about that specific extension version. Otherwise, it returns information about the default
 * extension version.
 *
 * For more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 */
export declare const describeType: API.OperationMethod<DescribeTypeInput & RegionInput, DescribeTypeOutput, DescribeTypeError, Credentials | HttpClient.HttpClient>;
export type DescribeTypeRegistrationError = CFNRegistryException | CommonErrors;
/**
 * Returns information about an extension's registration, including its current status and
 * type and version identifiers.
 *
 * When you initiate a registration request using RegisterType, you can
 * then use DescribeTypeRegistration to monitor the progress of that
 * registration request.
 *
 * Once the registration request has completed, use DescribeType to return
 * detailed information about an extension.
 */
export declare const describeTypeRegistration: API.OperationMethod<DescribeTypeRegistrationInput & RegionInput, DescribeTypeRegistrationOutput, DescribeTypeRegistrationError, Credentials | HttpClient.HttpClient>;
export type DetectStackDriftError = CommonErrors;
/**
 * Detects whether a stack's actual configuration differs, or has
 * *drifted*, from its expected configuration, as defined in the stack
 * template and any values specified as template parameters. For each resource in the stack that
 * supports drift detection, CloudFormation compares the actual configuration of the resource with
 * its expected template configuration. Only resource properties explicitly defined in the stack
 * template are checked for drift. A stack is considered to have drifted if one or more of its
 * resources differ from their expected template configurations. For more information, see Detect unmanaged configuration changes to stacks and resources with drift
 * detection.
 *
 * Use `DetectStackDrift` to detect drift on all supported resources for a given
 * stack, or DetectStackResourceDrift to detect drift on individual
 * resources.
 *
 * For a list of stack resources that currently support drift detection, see Resource
 * type support for imports and drift detection.
 *
 * `DetectStackDrift` can take up to several minutes, depending on the number of
 * resources contained within the stack. Use DescribeStackDriftDetectionStatus
 * to monitor the progress of a detect stack drift operation. Once the drift detection operation
 * has completed, use DescribeStackResourceDrifts to return drift information
 * about the stack and its resources.
 *
 * When detecting drift on a stack, CloudFormation doesn't detect drift on any nested stacks
 * belonging to that stack. Perform `DetectStackDrift` directly on the nested stack
 * itself.
 */
export declare const detectStackDrift: API.OperationMethod<DetectStackDriftInput & RegionInput, DetectStackDriftOutput, DetectStackDriftError, Credentials | HttpClient.HttpClient>;
export type DetectStackResourceDriftError = CommonErrors;
/**
 * Returns information about whether a resource's actual configuration differs, or has
 * *drifted*, from its expected configuration, as defined in the stack
 * template and any values specified as template parameters. This information includes actual and
 * expected property values for resources in which CloudFormation detects drift. Only resource
 * properties explicitly defined in the stack template are checked for drift. For more
 * information about stack and resource drift, see Detect unmanaged
 * configuration changes to stacks and resources with drift detection.
 *
 * Use `DetectStackResourceDrift` to detect drift on individual resources, or
 * DetectStackDrift to detect drift on all resources in a given stack that
 * support drift detection.
 *
 * Resources that don't currently support drift detection can't be checked. For a list of
 * resources that support drift detection, see Resource
 * type support for imports and drift detection.
 */
export declare const detectStackResourceDrift: API.OperationMethod<DetectStackResourceDriftInput & RegionInput, DetectStackResourceDriftOutput, DetectStackResourceDriftError, Credentials | HttpClient.HttpClient>;
export type DetectStackSetDriftError = InvalidOperationException | OperationInProgressException | StackSetNotFoundException | CommonErrors;
/**
 * Detect drift on a StackSet. When CloudFormation performs drift detection on a StackSet, it
 * performs drift detection on the stack associated with each stack instance in the StackSet. For
 * more information, see Performing drift detection on
 * CloudFormation StackSets.
 *
 * `DetectStackSetDrift` returns the `OperationId` of the StackSet
 * drift detection operation. Use this operation id with DescribeStackSetOperation to monitor the progress of the drift detection
 * operation. The drift detection operation may take some time, depending on the number of stack
 * instances included in the StackSet, in addition to the number of resources included in each
 * stack.
 *
 * Once the operation has completed, use the following actions to return drift
 * information:
 *
 * - Use DescribeStackSet to return detailed information about the stack
 * set, including detailed information about the last *completed* drift
 * operation performed on the StackSet. (Information about drift operations that are in
 * progress isn't included.)
 *
 * - Use ListStackInstances to return a list of stack instances belonging
 * to the StackSet, including the drift status and last drift time checked of each
 * instance.
 *
 * - Use DescribeStackInstance to return detailed information about a
 * specific stack instance, including its drift status and last drift time checked.
 *
 * You can only run a single drift detection operation on a given StackSet at one
 * time.
 *
 * To stop a drift detection StackSet operation, use StopStackSetOperation.
 */
export declare const detectStackSetDrift: API.OperationMethod<DetectStackSetDriftInput & RegionInput, DetectStackSetDriftOutput, DetectStackSetDriftError, Credentials | HttpClient.HttpClient>;
export type EstimateTemplateCostError = CommonErrors;
/**
 * Returns the estimated monthly cost of a template. The return value is an Amazon Web Services Simple
 * Monthly Calculator URL with a query string that describes the resources required to run the
 * template.
 */
export declare const estimateTemplateCost: API.OperationMethod<EstimateTemplateCostInput & RegionInput, EstimateTemplateCostOutput, EstimateTemplateCostError, Credentials | HttpClient.HttpClient>;
export type ExecuteChangeSetError = ChangeSetNotFoundException | InsufficientCapabilitiesException | InvalidChangeSetStatusException | TokenAlreadyExistsException | CommonErrors;
/**
 * Updates a stack using the input information that was provided when the specified change
 * set was created. After the call successfully completes, CloudFormation starts updating the stack.
 * Use the DescribeStacks action to view the status of the update.
 *
 * When you execute a change set, CloudFormation deletes all other change sets associated with
 * the stack because they aren't valid for the updated stack.
 *
 * If a stack policy is associated with the stack, CloudFormation enforces the policy during the
 * update. You can't specify a temporary stack policy that overrides the current policy.
 *
 * To create a change set for the entire stack hierarchy, `IncludeNestedStacks`
 * must have been set to `True`.
 */
export declare const executeChangeSet: API.OperationMethod<ExecuteChangeSetInput & RegionInput, ExecuteChangeSetOutput, ExecuteChangeSetError, Credentials | HttpClient.HttpClient>;
export type ExecuteStackRefactorError = CommonErrors;
/**
 * Executes the stack refactor operation.
 */
export declare const executeStackRefactor: API.OperationMethod<ExecuteStackRefactorInput & RegionInput, ExecuteStackRefactorResponse, ExecuteStackRefactorError, Credentials | HttpClient.HttpClient>;
export type GetGeneratedTemplateError = GeneratedTemplateNotFoundException | CommonErrors;
/**
 * Retrieves a generated template. If the template is in an `InProgress` or
 * `Pending` status then the template returned will be the template when the
 * template was last in a `Complete` status. If the template has not yet been in a
 * `Complete` status then an empty template will be returned.
 */
export declare const getGeneratedTemplate: API.OperationMethod<GetGeneratedTemplateInput & RegionInput, GetGeneratedTemplateOutput, GetGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type GetHookResultError = HookResultNotFoundException | CommonErrors;
/**
 * Retrieves detailed information and remediation guidance for a Hook invocation
 * result.
 *
 * If the Hook uses a KMS key to encrypt annotations, callers of the
 * `GetHookResult` operation must have `kms:Decrypt` permissions. For
 * more information, see KMS key policy
 * and permissions for encrypting CloudFormation Hooks results at rest in the
 * *CloudFormation Hooks User Guide*.
 */
export declare const getHookResult: API.OperationMethod<GetHookResultInput & RegionInput, GetHookResultOutput, GetHookResultError, Credentials | HttpClient.HttpClient>;
export type GetStackPolicyError = CommonErrors;
/**
 * Returns the stack policy for a specified stack. If a stack doesn't have a policy, a null
 * value is returned.
 */
export declare const getStackPolicy: API.OperationMethod<GetStackPolicyInput & RegionInput, GetStackPolicyOutput, GetStackPolicyError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = ChangeSetNotFoundException | CommonErrors;
/**
 * Returns the template body for a specified stack. You can get the template for running or
 * deleted stacks.
 *
 * For deleted stacks, `GetTemplate` returns the template for up to 90 days after
 * the stack has been deleted.
 *
 * If the template doesn't exist, a `ValidationError` is returned.
 */
export declare const getTemplate: API.OperationMethod<GetTemplateInput & RegionInput, GetTemplateOutput, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetTemplateSummaryError = StackSetNotFoundException | CommonErrors;
/**
 * Returns information about a new or existing template. The `GetTemplateSummary`
 * action is useful for viewing parameter information, such as default parameter values and
 * parameter types, before you create or update a stack or StackSet.
 *
 * You can use the `GetTemplateSummary` action when you submit a template, or you
 * can get template information for a StackSet, or a running or deleted stack.
 *
 * For deleted stacks, `GetTemplateSummary` returns the template information for
 * up to 90 days after the stack has been deleted. If the template doesn't exist, a
 * `ValidationError` is returned.
 */
export declare const getTemplateSummary: API.OperationMethod<GetTemplateSummaryInput & RegionInput, GetTemplateSummaryOutput, GetTemplateSummaryError, Credentials | HttpClient.HttpClient>;
export type ImportStacksToStackSetError = InvalidOperationException | LimitExceededException | OperationIdAlreadyExistsException | OperationInProgressException | StackNotFoundException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Import existing stacks into a new StackSets. Use the stack import operation to import up
 * to 10 stacks into a new StackSet in the same account as the source stack or in a different
 * administrator account and Region, by specifying the stack ID of the stack you intend to
 * import.
 */
export declare const importStacksToStackSet: API.OperationMethod<ImportStacksToStackSetInput & RegionInput, ImportStacksToStackSetOutput, ImportStacksToStackSetError, Credentials | HttpClient.HttpClient>;
export type ListChangeSetsError = CommonErrors;
/**
 * Returns the ID and status of each active change set for a stack. For example, CloudFormation
 * lists change sets that are in the `CREATE_IN_PROGRESS` or
 * `CREATE_PENDING` state.
 */
export declare const listChangeSets: API.PaginatedOperationMethod<ListChangeSetsInput & RegionInput, ListChangeSetsOutput, ListChangeSetsError, Credentials | HttpClient.HttpClient, ChangeSetSummary>;
export type ListExportsError = CommonErrors;
/**
 * Lists all exported output values in the account and Region in which you call this action.
 * Use this action to see the exported output values that you can import into other stacks. To
 * import values, use the Fn::ImportValue function.
 *
 * For more information, see Get exported outputs
 * from a deployed CloudFormation stack.
 */
export declare const listExports: API.PaginatedOperationMethod<ListExportsInput & RegionInput, ListExportsOutput, ListExportsError, Credentials | HttpClient.HttpClient, Export>;
export type ListGeneratedTemplatesError = CommonErrors;
/**
 * Lists your generated templates in this Region.
 */
export declare const listGeneratedTemplates: API.PaginatedOperationMethod<ListGeneratedTemplatesInput & RegionInput, ListGeneratedTemplatesOutput, ListGeneratedTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListHookResultsError = HookResultNotFoundException | CommonErrors;
/**
 * Returns summaries of invoked Hooks. For more information, see View invocation
 * summaries for CloudFormation Hooks in the *CloudFormation Hooks User Guide*.
 *
 * This operation supports the following parameter combinations:
 *
 * - No parameters: Returns all Hook invocation summaries.
 *
 * - `TypeArn` only: Returns summaries for a specific Hook.
 *
 * - `TypeArn` and `Status`: Returns summaries for a specific Hook
 * filtered by status.
 *
 * - `TargetId` and `TargetType`: Returns summaries for a specific
 * Hook invocation target.
 */
export declare const listHookResults: API.OperationMethod<ListHookResultsInput & RegionInput, ListHookResultsOutput, ListHookResultsError, Credentials | HttpClient.HttpClient>;
export type ListImportsError = CommonErrors;
/**
 * Lists all stacks that are importing an exported output value. To modify or remove an
 * exported output value, first use this action to see which stacks are using it. To see the
 * exported output values in your account, see ListExports.
 *
 * For more information about importing an exported output value, see the Fn::ImportValue function.
 */
export declare const listImports: API.PaginatedOperationMethod<ListImportsInput & RegionInput, ListImportsOutput, ListImportsError, Credentials | HttpClient.HttpClient, StackName>;
export type ListResourceScanRelatedResourcesError = ResourceScanInProgressException | ResourceScanNotFoundException | CommonErrors;
/**
 * Lists the related resources for a list of resources from a resource scan. The response
 * indicates whether each returned resource is already managed by CloudFormation.
 */
export declare const listResourceScanRelatedResources: API.PaginatedOperationMethod<ListResourceScanRelatedResourcesInput & RegionInput, ListResourceScanRelatedResourcesOutput, ListResourceScanRelatedResourcesError, Credentials | HttpClient.HttpClient, ScannedResource>;
export type ListResourceScanResourcesError = ResourceScanInProgressException | ResourceScanNotFoundException | CommonErrors;
/**
 * Lists the resources from a resource scan. The results can be filtered by resource
 * identifier, resource type prefix, tag key, and tag value. Only resources that match all
 * specified filters are returned. The response indicates whether each returned resource is
 * already managed by CloudFormation.
 */
export declare const listResourceScanResources: API.PaginatedOperationMethod<ListResourceScanResourcesInput & RegionInput, ListResourceScanResourcesOutput, ListResourceScanResourcesError, Credentials | HttpClient.HttpClient, ScannedResource>;
export type ListResourceScansError = CommonErrors;
/**
 * List the resource scans from newest to oldest. By default it will return up to 10 resource
 * scans.
 */
export declare const listResourceScans: API.PaginatedOperationMethod<ListResourceScansInput & RegionInput, ListResourceScansOutput, ListResourceScansError, Credentials | HttpClient.HttpClient, ResourceScanSummary>;
export type ListStackInstanceResourceDriftsError = OperationNotFoundException | StackInstanceNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns drift information for resources in a stack instance.
 *
 * `ListStackInstanceResourceDrifts` returns drift information for the most
 * recent drift detection operation. If an operation is in progress, it may only return partial
 * results.
 */
export declare const listStackInstanceResourceDrifts: API.OperationMethod<ListStackInstanceResourceDriftsInput & RegionInput, ListStackInstanceResourceDriftsOutput, ListStackInstanceResourceDriftsError, Credentials | HttpClient.HttpClient>;
export type ListStackInstancesError = StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about stack instances that are associated with the specified
 * StackSet. You can filter for stack instances that are associated with a specific Amazon Web Services account
 * name or Region, or that have a specific status.
 */
export declare const listStackInstances: API.PaginatedOperationMethod<ListStackInstancesInput & RegionInput, ListStackInstancesOutput, ListStackInstancesError, Credentials | HttpClient.HttpClient, StackInstanceSummary>;
export type ListStackRefactorActionsError = CommonErrors;
/**
 * Lists the stack refactor actions that will be taken after calling the ExecuteStackRefactor action.
 */
export declare const listStackRefactorActions: API.PaginatedOperationMethod<ListStackRefactorActionsInput & RegionInput, ListStackRefactorActionsOutput, ListStackRefactorActionsError, Credentials | HttpClient.HttpClient, StackRefactorAction>;
export type ListStackRefactorsError = CommonErrors;
/**
 * Lists all account stack refactor operations and their statuses.
 */
export declare const listStackRefactors: API.PaginatedOperationMethod<ListStackRefactorsInput & RegionInput, ListStackRefactorsOutput, ListStackRefactorsError, Credentials | HttpClient.HttpClient, StackRefactorSummary>;
export type ListStackResourcesError = CommonErrors;
/**
 * Returns descriptions of all resources of the specified stack.
 *
 * For deleted stacks, ListStackResources returns resource information for up to 90 days
 * after the stack has been deleted.
 */
export declare const listStackResources: API.PaginatedOperationMethod<ListStackResourcesInput & RegionInput, ListStackResourcesOutput, ListStackResourcesError, Credentials | HttpClient.HttpClient, StackResourceSummary>;
export type ListStacksError = CommonErrors;
/**
 * Returns the summary information for stacks whose status matches the specified
 * `StackStatusFilter`. Summary information for stacks that have been deleted is
 * kept for 90 days after the stack is deleted. If no `StackStatusFilter` is
 * specified, summary information for all stacks is returned (including existing stacks and
 * stacks that have been deleted).
 */
export declare const listStacks: API.PaginatedOperationMethod<ListStacksInput & RegionInput, ListStacksOutput, ListStacksError, Credentials | HttpClient.HttpClient, StackSummary>;
export type ListStackSetAutoDeploymentTargetsError = StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about deployment targets for a StackSet.
 */
export declare const listStackSetAutoDeploymentTargets: API.OperationMethod<ListStackSetAutoDeploymentTargetsInput & RegionInput, ListStackSetAutoDeploymentTargetsOutput, ListStackSetAutoDeploymentTargetsError, Credentials | HttpClient.HttpClient>;
export type ListStackSetOperationResultsError = OperationNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about the results of a StackSet operation.
 *
 * This API provides *eventually consistent* reads meaning it may take
 * some time but will eventually return the most up-to-date data.
 */
export declare const listStackSetOperationResults: API.PaginatedOperationMethod<ListStackSetOperationResultsInput & RegionInput, ListStackSetOperationResultsOutput, ListStackSetOperationResultsError, Credentials | HttpClient.HttpClient, StackSetOperationResultSummary>;
export type ListStackSetOperationsError = StackSetNotFoundException | CommonErrors;
/**
 * Returns summary information about operations performed on a StackSet.
 *
 * This API provides *eventually consistent* reads meaning it may take
 * some time but will eventually return the most up-to-date data.
 */
export declare const listStackSetOperations: API.PaginatedOperationMethod<ListStackSetOperationsInput & RegionInput, ListStackSetOperationsOutput, ListStackSetOperationsError, Credentials | HttpClient.HttpClient, StackSetOperationSummary>;
export type ListStackSetsError = CommonErrors;
/**
 * Returns summary information about StackSets that are associated with the user.
 *
 * This API provides *strongly consistent* reads meaning it will always
 * return the most up-to-date data.
 *
 * - [Self-managed permissions] If you set the `CallAs` parameter to
 * `SELF` while signed in to your Amazon Web Services account, `ListStackSets`
 * returns all self-managed StackSets in your Amazon Web Services account.
 *
 * - [Service-managed permissions] If you set the `CallAs` parameter to
 * `SELF` while signed in to the organization's management account,
 * `ListStackSets` returns all StackSets in the management account.
 *
 * - [Service-managed permissions] If you set the `CallAs` parameter to
 * `DELEGATED_ADMIN` while signed in to your member account,
 * `ListStackSets` returns all StackSets with service-managed permissions in the
 * management account.
 */
export declare const listStackSets: API.PaginatedOperationMethod<ListStackSetsInput & RegionInput, ListStackSetsOutput, ListStackSetsError, Credentials | HttpClient.HttpClient, StackSetSummary>;
export type ListTypeRegistrationsError = CFNRegistryException | CommonErrors;
/**
 * Returns a list of registration tokens for the specified extension(s).
 */
export declare const listTypeRegistrations: API.PaginatedOperationMethod<ListTypeRegistrationsInput & RegionInput, ListTypeRegistrationsOutput, ListTypeRegistrationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTypesError = CFNRegistryException | CommonErrors;
/**
 * Returns summary information about all extensions, including your private resource types,
 * modules, and Hooks as well as all public extensions from Amazon Web Services and third-party
 * publishers.
 */
export declare const listTypes: API.PaginatedOperationMethod<ListTypesInput & RegionInput, ListTypesOutput, ListTypesError, Credentials | HttpClient.HttpClient, TypeSummary>;
export type ListTypeVersionsError = CFNRegistryException | CommonErrors;
/**
 * Returns summary information about the versions of an extension.
 */
export declare const listTypeVersions: API.PaginatedOperationMethod<ListTypeVersionsInput & RegionInput, ListTypeVersionsOutput, ListTypeVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PublishTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Publishes the specified extension to the CloudFormation registry as a public extension in this
 * Region. Public extensions are available for use by all CloudFormation users. For more information
 * about publishing extensions, see Publishing extensions to
 * make them available for public use in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 *
 * To publish an extension, you must be registered as a publisher with CloudFormation. For more
 * information, see RegisterPublisher.
 */
export declare const publishType: API.OperationMethod<PublishTypeInput & RegionInput, PublishTypeOutput, PublishTypeError, Credentials | HttpClient.HttpClient>;
export type RecordHandlerProgressError = InvalidStateTransitionException | OperationStatusCheckFailedException | CommonErrors;
/**
 * Reports progress of a resource handler to CloudFormation.
 *
 * Reserved for use by the CloudFormation
 * CLI. Don't use this API in your code.
 */
export declare const recordHandlerProgress: API.OperationMethod<RecordHandlerProgressInput & RegionInput, RecordHandlerProgressOutput, RecordHandlerProgressError, Credentials | HttpClient.HttpClient>;
export type RegisterPublisherError = CFNRegistryException | CommonErrors;
/**
 * Registers your account as a publisher of public extensions in the CloudFormation registry.
 * Public extensions are available for use by all CloudFormation users. This publisher ID applies to
 * your account in all Amazon Web Services Regions.
 *
 * For information about requirements for registering as a public extension publisher, see
 * Prerequisite: Registering your account to publish CloudFormation extensions in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 */
export declare const registerPublisher: API.OperationMethod<RegisterPublisherInput & RegionInput, RegisterPublisherOutput, RegisterPublisherError, Credentials | HttpClient.HttpClient>;
export type RegisterTypeError = CFNRegistryException | CommonErrors;
/**
 * Registers an extension with the CloudFormation service. Registering an extension makes it
 * available for use in CloudFormation templates in your Amazon Web Services account, and includes:
 *
 * - Validating the extension schema.
 *
 * - Determining which handlers, if any, have been specified for the extension.
 *
 * - Making the extension available for use in your account.
 *
 * For more information about how to develop extensions and ready them for registration, see
 * Creating resource types using the CloudFormation CLI in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 *
 * You can have a maximum of 50 resource extension versions registered at a time. This
 * maximum is per account and per Region. Use DeregisterType
 * to deregister specific extension versions if necessary.
 *
 * Once you have initiated a registration request using RegisterType, you
 * can use DescribeTypeRegistration to monitor the progress of the registration
 * request.
 *
 * Once you have registered a private extension in your account and Region, use SetTypeConfiguration to specify configuration properties for the extension. For
 * more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 */
export declare const registerType: API.OperationMethod<RegisterTypeInput & RegionInput, RegisterTypeOutput, RegisterTypeError, Credentials | HttpClient.HttpClient>;
export type RemoveAliasError = CommonErrors;
/**
 * Removes an alias from a stack. After the alias is removed successfully, it can no longer be used to
 * reference the stack in API calls.
 */
export declare const removeAlias: API.OperationMethod<RemoveAliasInput & RegionInput, RemoveAliasResponse, RemoveAliasError, Credentials | HttpClient.HttpClient>;
export type RollbackStackError = TokenAlreadyExistsException | CommonErrors;
/**
 * When specifying `RollbackStack`, you preserve the state of previously
 * provisioned resources when an operation fails. You can check the status of the stack through
 * the DescribeStacks operation.
 *
 * Rolls back the specified stack to the last known stable state from
 * `CREATE_FAILED` or `UPDATE_FAILED` stack statuses.
 *
 * This operation will delete a stack if it doesn't contain a last known stable state. A last
 * known stable state includes any status in a `*_COMPLETE`. This includes the
 * following stack statuses.
 *
 * - `CREATE_COMPLETE`
 *
 * - `UPDATE_COMPLETE`
 *
 * - `UPDATE_ROLLBACK_COMPLETE`
 *
 * - `IMPORT_COMPLETE`
 *
 * - `IMPORT_ROLLBACK_COMPLETE`
 */
export declare const rollbackStack: API.OperationMethod<RollbackStackInput & RegionInput, RollbackStackOutput, RollbackStackError, Credentials | HttpClient.HttpClient>;
export type SetAliasError = AlreadyExistsException | LimitExceededException | CommonErrors;
/**
 * Assigns an alias to an existing stack. An alias is an alternative name for a stack that
 * can be used in place of the stack name in any CloudFormation API call that accepts the
 * `StackName` parameter. This enables you to effectively rename a stack without
 * recreating it.
 *
 * After setting an alias, both the original stack name and the alias resolve to the same
 * stack. Setting an alias does not change the stack's ARN, physical resource IDs, or any
 * deployed resources.
 *
 * Each stack can have at most one alias. To change a stack's alias, first remove the
 * existing alias using RemoveAlias, then set a new one.
 */
export declare const setAlias: API.OperationMethod<SetAliasInput & RegionInput, SetAliasResponse, SetAliasError, Credentials | HttpClient.HttpClient>;
export type SetStackPolicyError = CommonErrors;
/**
 * Sets a stack policy for a specified stack.
 */
export declare const setStackPolicy: API.OperationMethod<SetStackPolicyInput & RegionInput, SetStackPolicyResponse, SetStackPolicyError, Credentials | HttpClient.HttpClient>;
export type SetTypeConfigurationError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Specifies the configuration data for a CloudFormation extension, such as a resource or Hook,
 * in the given account and Region.
 *
 * For more information, see Edit configuration
 * data for extensions in your account in the
 * *CloudFormation User Guide*.
 *
 * To view the current configuration data for an extension, refer to the
 * `ConfigurationSchema` element of DescribeType.
 *
 * It's strongly recommended that you use dynamic references to restrict sensitive
 * configuration definitions, such as third-party credentials. For more information, see Specify values stored in other services using dynamic references in the
 * *CloudFormation User Guide*.
 *
 * For more information about setting the configuration data for resource types, see Defining the account-level configuration of an extension in the
 * *CloudFormation Command Line Interface (CLI) User Guide*. For more information about setting the configuration
 * data for Hooks, see the CloudFormation Hooks User Guide.
 */
export declare const setTypeConfiguration: API.OperationMethod<SetTypeConfigurationInput & RegionInput, SetTypeConfigurationOutput, SetTypeConfigurationError, Credentials | HttpClient.HttpClient>;
export type SetTypeDefaultVersionError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Specify the default version of an extension. The default version of an extension will be
 * used in CloudFormation operations.
 */
export declare const setTypeDefaultVersion: API.OperationMethod<SetTypeDefaultVersionInput & RegionInput, SetTypeDefaultVersionOutput, SetTypeDefaultVersionError, Credentials | HttpClient.HttpClient>;
export type SignalResourceError = CommonErrors;
/**
 * Sends a signal to the specified resource with a success or failure status. You can use the
 * `SignalResource` operation in conjunction with a creation policy or update
 * policy. CloudFormation doesn't proceed with a stack creation or update until resources receive the
 * required number of signals or the timeout period is exceeded. The `SignalResource`
 * operation is useful in cases where you want to send signals from anywhere other than an Amazon EC2
 * instance.
 */
export declare const signalResource: API.OperationMethod<SignalResourceInput & RegionInput, SignalResourceResponse, SignalResourceError, Credentials | HttpClient.HttpClient>;
export type StartResourceScanError = ResourceScanInProgressException | ResourceScanLimitExceededException | CommonErrors;
/**
 * Starts a scan of the resources in this account in this Region. You can the status of a
 * scan using the `ListResourceScans` API action.
 */
export declare const startResourceScan: API.OperationMethod<StartResourceScanInput & RegionInput, StartResourceScanOutput, StartResourceScanError, Credentials | HttpClient.HttpClient>;
export type StopStackSetOperationError = InvalidOperationException | OperationNotFoundException | StackSetNotFoundException | CommonErrors;
/**
 * Stops an in-progress operation on a StackSet and its associated stack instances. StackSets
 * will cancel all the unstarted stack instance deployments and wait for those are in-progress to
 * complete.
 */
export declare const stopStackSetOperation: API.OperationMethod<StopStackSetOperationInput & RegionInput, StopStackSetOperationOutput, StopStackSetOperationError, Credentials | HttpClient.HttpClient>;
export type TestTypeError = CFNRegistryException | TypeNotFoundException | CommonErrors;
/**
 * Tests a registered extension to make sure it meets all necessary requirements for being
 * published in the CloudFormation registry.
 *
 * - For resource types, this includes passing all contracts tests defined for the
 * type.
 *
 * - For modules, this includes determining if the module's model meets all necessary
 * requirements.
 *
 * For more information, see Testing your public extension before publishing in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 *
 * If you don't specify a version, CloudFormation uses the default version of the extension in
 * your account and Region for testing.
 *
 * To perform testing, CloudFormation assumes the execution role specified when the type was
 * registered. For more information, see RegisterType.
 *
 * Once you've initiated testing on an extension using `TestType`, you can pass
 * the returned `TypeVersionArn` into DescribeType to
 * monitor the current test status and test status description for the extension.
 *
 * An extension must have a test status of `PASSED` before it can be published.
 * For more information, see Publishing extensions
 * to make them available for public use in the
 * *CloudFormation Command Line Interface (CLI) User Guide*.
 */
export declare const testType: API.OperationMethod<TestTypeInput & RegionInput, TestTypeOutput, TestTypeError, Credentials | HttpClient.HttpClient>;
export type UpdateGeneratedTemplateError = AlreadyExistsException | GeneratedTemplateNotFoundException | LimitExceededException | CommonErrors;
/**
 * Updates a generated template. This can be used to change the name, add and remove
 * resources, refresh resources, and change the `DeletionPolicy` and
 * `UpdateReplacePolicy` settings. You can check the status of the update to the
 * generated template using the `DescribeGeneratedTemplate` API action.
 */
export declare const updateGeneratedTemplate: API.OperationMethod<UpdateGeneratedTemplateInput & RegionInput, UpdateGeneratedTemplateOutput, UpdateGeneratedTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateStackError = InsufficientCapabilitiesException | TokenAlreadyExistsException | NoUpdateToPerform | CommonErrors;
/**
 * Updates a stack as specified in the template. After the call completes successfully, the
 * stack update starts. You can check the status of the stack through the DescribeStacks action.
 *
 * To get a copy of the template for an existing stack, you can use the GetTemplate action.
 *
 * For more information about updating a stack and monitoring the progress of the update, see
 * Managing
 * Amazon Web Services resources as a single unit with CloudFormation stacks in the
 * *CloudFormation User Guide*.
 */
export declare const updateStack: API.OperationMethod<UpdateStackInput & RegionInput, UpdateStackOutput, UpdateStackError, Credentials | HttpClient.HttpClient>;
export type UpdateStackInstancesError = InvalidOperationException | OperationIdAlreadyExistsException | OperationInProgressException | StackInstanceNotFoundException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Updates the parameter values for stack instances for the specified accounts, within the
 * specified Amazon Web Services Regions. A stack instance refers to a stack in a specific account and
 * Region.
 *
 * You can only update stack instances in Amazon Web Services Regions and accounts where they already
 * exist; to create additional stack instances, use CreateStackInstances.
 *
 * During StackSet updates, any parameters overridden for a stack instance aren't updated,
 * but retain their overridden value.
 *
 * You can only update the parameter *values* that are specified in the
 * StackSet. To add or delete a parameter itself, use UpdateStackSet
 * to update the StackSet template. If you add a parameter to a template, before you can override
 * the parameter value specified in the StackSet you must first use UpdateStackSet
 * to update all stack instances with the updated template and parameter value specified in the
 * StackSet. Once a stack instance has been updated with the new parameter, you can then override
 * the parameter value using `UpdateStackInstances`.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `UpdateStackInstances` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const updateStackInstances: API.OperationMethod<UpdateStackInstancesInput & RegionInput, UpdateStackInstancesOutput, UpdateStackInstancesError, Credentials | HttpClient.HttpClient>;
export type UpdateStackSetError = InvalidOperationException | OperationIdAlreadyExistsException | OperationInProgressException | StackInstanceNotFoundException | StackSetNotFoundException | StaleRequestException | CommonErrors;
/**
 * Updates the StackSet and associated stack instances in the specified accounts and
 * Amazon Web Services Regions.
 *
 * Even if the StackSet operation created by updating the StackSet fails (completely or
 * partially, below or above a specified failure tolerance), the StackSet is updated with your
 * changes. Subsequent CreateStackInstances calls on the specified StackSet use
 * the updated StackSet.
 *
 * The maximum number of organizational unit (OUs) supported by a
 * `UpdateStackSet` operation is 50.
 *
 * If you need more than 50, consider the following options:
 *
 * - *Batch processing:* If you don't want to expose your OU
 * hierarchy, split up the operations into multiple calls with less than 50 OUs
 * each.
 *
 * - *Parent OU strategy:* If you don't mind exposing the OU
 * hierarchy, target a parent OU that contains all desired child OUs.
 */
export declare const updateStackSet: API.OperationMethod<UpdateStackSetInput & RegionInput, UpdateStackSetOutput, UpdateStackSetError, Credentials | HttpClient.HttpClient>;
export type UpdateTerminationProtectionError = CommonErrors;
/**
 * Updates termination protection for the specified stack. If a user attempts to delete a
 * stack with termination protection enabled, the operation fails and the stack remains
 * unchanged. For more information, see Protect a CloudFormation
 * stack from being deleted in the *CloudFormation User Guide*.
 *
 * For nested stacks,
 * termination protection is set on the root stack and can't be changed directly on the nested
 * stack.
 */
export declare const updateTerminationProtection: API.OperationMethod<UpdateTerminationProtectionInput & RegionInput, UpdateTerminationProtectionOutput, UpdateTerminationProtectionError, Credentials | HttpClient.HttpClient>;
export type ValidateTemplateError = CommonErrors;
/**
 * Validates a specified template. CloudFormation first checks if the template is valid JSON. If
 * it isn't, CloudFormation checks if the template is valid YAML. If both these checks fail,
 * CloudFormation returns a template validation error.
 */
export declare const validateTemplate: API.OperationMethod<ValidateTemplateInput & RegionInput, ValidateTemplateOutput, ValidateTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudformation.d.ts.map