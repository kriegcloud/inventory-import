import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface GetPreferencesRequest {
}
export type SavingsEstimationMode = "BeforeDiscounts" | "AfterDiscounts" | (string & {});
export type MemberAccountDiscountVisibility = "All" | "None" | (string & {});
export type Term = "OneYear" | "ThreeYears" | (string & {});
export type PaymentOption = "AllUpfront" | "PartialUpfront" | "NoUpfront" | (string & {});
export interface PreferredCommitment {
    term?: Term | undefined;
    paymentOption?: PaymentOption | undefined;
}
export interface GetPreferencesResponse {
    savingsEstimationMode?: SavingsEstimationMode | undefined;
    memberAccountDiscountVisibility?: MemberAccountDiscountVisibility | undefined;
    preferredCommitment?: PreferredCommitment | undefined;
}
export interface GetRecommendationRequest {
    recommendationId: string;
}
export type ResourceType = "Ec2Instance" | "LambdaFunction" | "EbsVolume" | "EcsService" | "Ec2AutoScalingGroup" | "Ec2InstanceSavingsPlans" | "ComputeSavingsPlans" | "SageMakerSavingsPlans" | "Ec2ReservedInstances" | "RdsReservedInstances" | "OpenSearchReservedInstances" | "RedshiftReservedInstances" | "ElastiCacheReservedInstances" | "RdsDbInstanceStorage" | "RdsDbInstance" | "AuroraDbClusterStorage" | "DynamoDbReservedCapacity" | "MemoryDbReservedInstances" | "NatGateway" | "DynamoDBTable" | "ElastiCacheCluster" | "MemoryDBCluster" | "DocumentDBCluster" | "WorkSpaces" | "SageMakerEndpoint" | (string & {});
export type Source = "ComputeOptimizer" | "CostExplorer" | (string & {});
export type Datetime = Date;
export type ImplementationEffort = "VeryLow" | "Low" | "Medium" | "High" | "VeryHigh" | (string & {});
export type ActionType = "Rightsize" | "Stop" | "Upgrade" | "PurchaseSavingsPlans" | "PurchaseReservedInstances" | "MigrateToGraviton" | "Delete" | "ScaleIn" | (string & {});
export interface ComputeConfiguration {
    vCpu?: number | undefined;
    memorySizeInMB?: number | undefined;
    architecture?: string | undefined;
    platform?: string | undefined;
}
export interface LambdaFunctionConfiguration {
    compute?: ComputeConfiguration | undefined;
}
export interface Usage {
    usageType?: string | undefined;
    usageAmount?: number | undefined;
    operation?: string | undefined;
    productCode?: string | undefined;
    unit?: string | undefined;
}
export type UsageList = Usage[];
export interface EstimatedDiscounts {
    savingsPlansDiscount?: number | undefined;
    reservedInstancesDiscount?: number | undefined;
    otherDiscount?: number | undefined;
}
export interface ResourcePricing {
    estimatedCostBeforeDiscounts?: number | undefined;
    estimatedNetUnusedAmortizedCommitments?: number | undefined;
    estimatedDiscounts?: EstimatedDiscounts | undefined;
    estimatedCostAfterDiscounts?: number | undefined;
}
export interface ResourceCostCalculation {
    usages?: Usage[] | undefined;
    pricing?: ResourcePricing | undefined;
}
export interface LambdaFunction {
    configuration?: LambdaFunctionConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface EcsServiceConfiguration {
    compute?: ComputeConfiguration | undefined;
}
export interface EcsService {
    configuration?: EcsServiceConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface InstanceConfiguration {
    type?: string | undefined;
}
export interface Ec2InstanceConfiguration {
    instance?: InstanceConfiguration | undefined;
}
export interface Ec2Instance {
    configuration?: Ec2InstanceConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface StorageConfiguration {
    type?: string | undefined;
    sizeInGb?: number | undefined;
}
export interface BlockStoragePerformanceConfiguration {
    iops?: number | undefined;
    throughput?: number | undefined;
}
export interface EbsVolumeConfiguration {
    storage?: StorageConfiguration | undefined;
    performance?: BlockStoragePerformanceConfiguration | undefined;
    attachmentState?: string | undefined;
}
export interface EbsVolume {
    configuration?: EbsVolumeConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface MixedInstanceConfiguration {
    type?: string | undefined;
}
export type MixedInstanceConfigurationList = MixedInstanceConfiguration[];
export type Ec2AutoScalingGroupType = "SingleInstanceType" | "MixedInstanceTypes" | (string & {});
export type AllocationStrategy = "Prioritized" | "LowestPrice" | (string & {});
export interface Ec2AutoScalingGroupConfiguration {
    instance?: InstanceConfiguration | undefined;
    mixedInstances?: MixedInstanceConfiguration[] | undefined;
    type?: Ec2AutoScalingGroupType | undefined;
    allocationStrategy?: AllocationStrategy | undefined;
}
export interface Ec2AutoScalingGroup {
    configuration?: Ec2AutoScalingGroupConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface Ec2ReservedInstancesConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    normalizedUnitsToPurchase?: string | undefined;
    numberOfInstancesToPurchase?: string | undefined;
    offeringClass?: string | undefined;
    instanceFamily?: string | undefined;
    instanceType?: string | undefined;
    currentGeneration?: string | undefined;
    platform?: string | undefined;
    tenancy?: string | undefined;
    sizeFlexEligible?: boolean | undefined;
}
export interface ReservedInstancesPricing {
    estimatedOnDemandCost?: number | undefined;
    monthlyReservationEligibleCost?: number | undefined;
    savingsPercentage?: number | undefined;
    estimatedMonthlyAmortizedReservationCost?: number | undefined;
}
export interface ReservedInstancesCostCalculation {
    pricing?: ReservedInstancesPricing | undefined;
}
export interface Ec2ReservedInstances {
    configuration?: Ec2ReservedInstancesConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface RdsReservedInstancesConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    normalizedUnitsToPurchase?: string | undefined;
    numberOfInstancesToPurchase?: string | undefined;
    instanceFamily?: string | undefined;
    instanceType?: string | undefined;
    sizeFlexEligible?: boolean | undefined;
    currentGeneration?: string | undefined;
    licenseModel?: string | undefined;
    databaseEdition?: string | undefined;
    databaseEngine?: string | undefined;
    deploymentOption?: string | undefined;
}
export interface RdsReservedInstances {
    configuration?: RdsReservedInstancesConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface ElastiCacheReservedInstancesConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    normalizedUnitsToPurchase?: string | undefined;
    numberOfInstancesToPurchase?: string | undefined;
    instanceFamily?: string | undefined;
    instanceType?: string | undefined;
    currentGeneration?: string | undefined;
    sizeFlexEligible?: boolean | undefined;
}
export interface ElastiCacheReservedInstances {
    configuration?: ElastiCacheReservedInstancesConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface OpenSearchReservedInstancesConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    normalizedUnitsToPurchase?: string | undefined;
    numberOfInstancesToPurchase?: string | undefined;
    instanceType?: string | undefined;
    currentGeneration?: string | undefined;
    sizeFlexEligible?: boolean | undefined;
}
export interface OpenSearchReservedInstances {
    configuration?: OpenSearchReservedInstancesConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface RedshiftReservedInstancesConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    normalizedUnitsToPurchase?: string | undefined;
    numberOfInstancesToPurchase?: string | undefined;
    instanceFamily?: string | undefined;
    instanceType?: string | undefined;
    sizeFlexEligible?: boolean | undefined;
    currentGeneration?: string | undefined;
}
export interface RedshiftReservedInstances {
    configuration?: RedshiftReservedInstancesConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface Ec2InstanceSavingsPlansConfiguration {
    accountScope?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    hourlyCommitment?: string | undefined;
    instanceFamily?: string | undefined;
    savingsPlansRegion?: string | undefined;
}
export interface SavingsPlansPricing {
    monthlySavingsPlansEligibleCost?: number | undefined;
    estimatedMonthlyCommitment?: number | undefined;
    savingsPercentage?: number | undefined;
    estimatedOnDemandCost?: number | undefined;
}
export interface SavingsPlansCostCalculation {
    pricing?: SavingsPlansPricing | undefined;
}
export interface Ec2InstanceSavingsPlans {
    configuration?: Ec2InstanceSavingsPlansConfiguration | undefined;
    costCalculation?: SavingsPlansCostCalculation | undefined;
}
export interface ComputeSavingsPlansConfiguration {
    accountScope?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    hourlyCommitment?: string | undefined;
}
export interface ComputeSavingsPlans {
    configuration?: ComputeSavingsPlansConfiguration | undefined;
    costCalculation?: SavingsPlansCostCalculation | undefined;
}
export interface SageMakerSavingsPlansConfiguration {
    accountScope?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    hourlyCommitment?: string | undefined;
}
export interface SageMakerSavingsPlans {
    configuration?: SageMakerSavingsPlansConfiguration | undefined;
    costCalculation?: SavingsPlansCostCalculation | undefined;
}
export interface DbInstanceConfiguration {
    dbInstanceClass?: string | undefined;
}
export interface RdsDbInstanceConfiguration {
    instance?: DbInstanceConfiguration | undefined;
}
export interface RdsDbInstance {
    configuration?: RdsDbInstanceConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface RdsDbInstanceStorageConfiguration {
    storageType?: string | undefined;
    allocatedStorageInGb?: number | undefined;
    iops?: number | undefined;
    storageThroughput?: number | undefined;
}
export interface RdsDbInstanceStorage {
    configuration?: RdsDbInstanceStorageConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface AuroraDbClusterStorageConfiguration {
    storageType?: string | undefined;
}
export interface AuroraDbClusterStorage {
    configuration?: AuroraDbClusterStorageConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface DynamoDbReservedCapacityConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    numberOfCapacityUnitsToPurchase?: string | undefined;
    capacityUnits?: string | undefined;
}
export interface DynamoDbReservedCapacity {
    configuration?: DynamoDbReservedCapacityConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface MemoryDbReservedInstancesConfiguration {
    accountScope?: string | undefined;
    service?: string | undefined;
    term?: string | undefined;
    paymentOption?: string | undefined;
    reservedInstancesRegion?: string | undefined;
    upfrontCost?: string | undefined;
    monthlyRecurringCost?: string | undefined;
    normalizedUnitsToPurchase?: string | undefined;
    numberOfInstancesToPurchase?: string | undefined;
    instanceType?: string | undefined;
    instanceFamily?: string | undefined;
    sizeFlexEligible?: boolean | undefined;
    currentGeneration?: string | undefined;
}
export interface MemoryDbReservedInstances {
    configuration?: MemoryDbReservedInstancesConfiguration | undefined;
    costCalculation?: ReservedInstancesCostCalculation | undefined;
}
export interface NatGatewayConfiguration {
    activeConnectionCount?: number | undefined;
    packetsInFromSource?: number | undefined;
    packetsInFromDestination?: number | undefined;
}
export interface NatGateway {
    configuration?: NatGatewayConfiguration | undefined;
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface DynamoDbTable {
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface ElastiCacheCluster {
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface MemoryDbCluster {
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface DocumentDbCluster {
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface WorkSpaces {
    costCalculation?: ResourceCostCalculation | undefined;
}
export interface SageMakerEndpoint {
    costCalculation?: ResourceCostCalculation | undefined;
}
export type ResourceDetails = {
    lambdaFunction: LambdaFunction;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService: EcsService;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance: Ec2Instance;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume: EbsVolume;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup: Ec2AutoScalingGroup;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances: Ec2ReservedInstances;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances: RdsReservedInstances;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances: ElastiCacheReservedInstances;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances: OpenSearchReservedInstances;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances: RedshiftReservedInstances;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans: Ec2InstanceSavingsPlans;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans: ComputeSavingsPlans;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans: SageMakerSavingsPlans;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance: RdsDbInstance;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage: RdsDbInstanceStorage;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage: AuroraDbClusterStorage;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity: DynamoDbReservedCapacity;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances: MemoryDbReservedInstances;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway: NatGateway;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable: DynamoDbTable;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster: ElastiCacheCluster;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster: MemoryDbCluster;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster: DocumentDbCluster;
    workSpaces?: undefined;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces: WorkSpaces;
    sageMakerEndpoint?: undefined;
} | {
    lambdaFunction?: undefined;
    ecsService?: undefined;
    ec2Instance?: undefined;
    ebsVolume?: undefined;
    ec2AutoScalingGroup?: undefined;
    ec2ReservedInstances?: undefined;
    rdsReservedInstances?: undefined;
    elastiCacheReservedInstances?: undefined;
    openSearchReservedInstances?: undefined;
    redshiftReservedInstances?: undefined;
    ec2InstanceSavingsPlans?: undefined;
    computeSavingsPlans?: undefined;
    sageMakerSavingsPlans?: undefined;
    rdsDbInstance?: undefined;
    rdsDbInstanceStorage?: undefined;
    auroraDbClusterStorage?: undefined;
    dynamoDbReservedCapacity?: undefined;
    memoryDbReservedInstances?: undefined;
    natGateway?: undefined;
    dynamoDbTable?: undefined;
    elastiCacheCluster?: undefined;
    memoryDbCluster?: undefined;
    documentDbCluster?: undefined;
    workSpaces?: undefined;
    sageMakerEndpoint: SageMakerEndpoint;
};
export interface Tag {
    key?: string | undefined;
    value?: string | undefined;
}
export type TagList = Tag[];
export interface GetRecommendationResponse {
    recommendationId?: string | undefined;
    resourceId?: string | undefined;
    resourceArn?: string | undefined;
    accountId?: string | undefined;
    currencyCode?: string | undefined;
    recommendationLookbackPeriodInDays?: number | undefined;
    costCalculationLookbackPeriodInDays?: number | undefined;
    estimatedSavingsPercentage?: number | undefined;
    estimatedSavingsOverCostCalculationLookbackPeriod?: number | undefined;
    currentResourceType?: ResourceType | undefined;
    recommendedResourceType?: ResourceType | undefined;
    region?: string | undefined;
    source?: Source | undefined;
    lastRefreshTimestamp?: Date | undefined;
    estimatedMonthlySavings?: number | undefined;
    estimatedMonthlyCost?: number | undefined;
    implementationEffort?: ImplementationEffort | undefined;
    restartNeeded?: boolean | undefined;
    actionType?: ActionType | undefined;
    rollbackPossible?: boolean | undefined;
    currentResourceDetails?: ResourceDetails | undefined;
    recommendedResourceDetails?: ResourceDetails | undefined;
    tags?: Tag[] | undefined;
}
export type GranularityType = "Daily" | "Monthly" | (string & {});
export interface TimePeriod {
    start: string;
    end: string;
}
export type MaxResults = number;
export type Order = "Asc" | "Desc" | (string & {});
export interface OrderBy {
    dimension?: string | undefined;
    order?: Order | undefined;
}
export interface ListEfficiencyMetricsRequest {
    groupBy?: string | undefined;
    granularity: GranularityType;
    timePeriod: TimePeriod;
    maxResults?: number | undefined;
    orderBy?: OrderBy | undefined;
    nextToken?: string | undefined;
}
export interface MetricsByTime {
    score?: number | undefined;
    savings?: number | undefined;
    spend?: number | undefined;
    timestamp?: string | undefined;
}
export type MetricsByTimeList = MetricsByTime[];
export interface EfficiencyMetricsByGroup {
    metricsByTime?: MetricsByTime[] | undefined;
    group?: string | undefined;
    message?: string | undefined;
}
export type EfficiencyMetricsByGroupList = EfficiencyMetricsByGroup[];
export interface ListEfficiencyMetricsResponse {
    efficiencyMetricsByGroup?: EfficiencyMetricsByGroup[] | undefined;
    nextToken?: string | undefined;
}
export type AccountId = string;
export interface ListEnrollmentStatusesRequest {
    includeOrganizationInfo?: boolean | undefined;
    accountId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type EnrollmentStatus = "Active" | "Inactive" | (string & {});
export interface AccountEnrollmentStatus {
    accountId?: string | undefined;
    status?: EnrollmentStatus | undefined;
    lastUpdatedTimestamp?: Date | undefined;
    createdTimestamp?: Date | undefined;
}
export type AccountEnrollmentStatuses = AccountEnrollmentStatus[];
export interface ListEnrollmentStatusesResponse {
    items?: AccountEnrollmentStatus[] | undefined;
    includeMemberAccounts?: boolean | undefined;
    nextToken?: string | undefined;
}
export type ImplementationEffortList = ImplementationEffort[];
export type AccountIdList = string[];
export type RegionList = string[];
export type ResourceTypeList = ResourceType[];
export type ActionTypeList = ActionType[];
export type ResourceIdList = string[];
export type ResourceArnList = string[];
export type RecommendationIdList = string[];
export interface Filter {
    restartNeeded?: boolean | undefined;
    rollbackPossible?: boolean | undefined;
    implementationEfforts?: ImplementationEffort[] | undefined;
    accountIds?: string[] | undefined;
    regions?: string[] | undefined;
    resourceTypes?: ResourceType[] | undefined;
    actionTypes?: ActionType[] | undefined;
    tags?: Tag[] | undefined;
    resourceIds?: string[] | undefined;
    resourceArns?: string[] | undefined;
    recommendationIds?: string[] | undefined;
}
export interface ListRecommendationsRequest {
    filter?: Filter | undefined;
    orderBy?: OrderBy | undefined;
    includeAllRecommendations?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface Recommendation {
    recommendationId?: string | undefined;
    accountId?: string | undefined;
    region?: string | undefined;
    resourceId?: string | undefined;
    resourceArn?: string | undefined;
    currentResourceType?: string | undefined;
    recommendedResourceType?: string | undefined;
    estimatedMonthlySavings?: number | undefined;
    estimatedSavingsPercentage?: number | undefined;
    estimatedMonthlyCost?: number | undefined;
    currencyCode?: string | undefined;
    implementationEffort?: string | undefined;
    restartNeeded?: boolean | undefined;
    actionType?: string | undefined;
    rollbackPossible?: boolean | undefined;
    currentResourceSummary?: string | undefined;
    recommendedResourceSummary?: string | undefined;
    lastRefreshTimestamp?: Date | undefined;
    recommendationLookbackPeriodInDays?: number | undefined;
    source?: Source | undefined;
    tags?: Tag[] | undefined;
}
export type RecommendationList = Recommendation[];
export interface ListRecommendationsResponse {
    items?: Recommendation[] | undefined;
    nextToken?: string | undefined;
}
export type SummaryMetrics = "SavingsPercentage" | (string & {});
export type SummaryMetricsList = SummaryMetrics[];
export interface ListRecommendationSummariesRequest {
    filter?: Filter | undefined;
    groupBy: string;
    maxResults?: number | undefined;
    metrics?: SummaryMetrics[] | undefined;
    nextToken?: string | undefined;
}
export interface RecommendationSummary {
    group?: string | undefined;
    estimatedMonthlySavings?: number | undefined;
    recommendationCount?: number | undefined;
}
export type RecommendationSummariesList = RecommendationSummary[];
export interface SummaryMetricsResult {
    savingsPercentage?: string | undefined;
}
export interface ListRecommendationSummariesResponse {
    estimatedTotalDedupedSavings?: number | undefined;
    items?: RecommendationSummary[] | undefined;
    groupBy?: string | undefined;
    currencyCode?: string | undefined;
    metrics?: SummaryMetricsResult | undefined;
    nextToken?: string | undefined;
}
export interface UpdateEnrollmentStatusRequest {
    status: EnrollmentStatus;
    includeMemberAccounts?: boolean | undefined;
}
export interface UpdateEnrollmentStatusResponse {
    status?: string | undefined;
}
export interface UpdatePreferencesRequest {
    savingsEstimationMode?: SavingsEstimationMode | undefined;
    memberAccountDiscountVisibility?: MemberAccountDiscountVisibility | undefined;
    preferredCommitment?: PreferredCommitment | undefined;
}
export interface UpdatePreferencesResponse {
    savingsEstimationMode?: SavingsEstimationMode | undefined;
    memberAccountDiscountVisibility?: MemberAccountDiscountVisibility | undefined;
    preferredCommitment?: PreferredCommitment | undefined;
}
export type ValidationExceptionReason = "FieldValidationFailed" | "Other" | (string & {});
export interface ValidationExceptionDetail {
    fieldName: string;
    message: string;
}
export type ValidationExceptionDetails = ValidationExceptionDetail[];
export type GetPreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a set of preferences for an account in order to add account-specific preferences into the service. These preferences impact how the savings associated with recommendations are presented--estimated savings after discounts or estimated savings before discounts, for example.
 */
export declare const getPreferences: API.OperationMethod<GetPreferencesRequest & RegionInput, GetPreferencesResponse, GetPreferencesError, Credentials | HttpClient.HttpClient>;
export type GetRecommendationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns both the current and recommended resource configuration and the estimated cost impact for a recommendation.
 *
 * The `recommendationId` is only valid for up to a maximum of 24 hours as recommendations are refreshed daily. To retrieve the `recommendationId`, use the `ListRecommendations` API.
 */
export declare const getRecommendation: API.OperationMethod<GetRecommendationRequest & RegionInput, GetRecommendationResponse, GetRecommendationError, Credentials | HttpClient.HttpClient>;
export type ListEfficiencyMetricsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns cost efficiency metrics aggregated over time and optionally grouped by a specified dimension. The metrics provide insights into your cost optimization progress by tracking estimated savings, spending, and measures how effectively you're optimizing your Cloud resources.
 *
 * The operation supports both daily and monthly time granularities and allows grouping results by account ID, Amazon Web Services Region. Results are returned as time-series data, enabling you to analyze trends in your cost optimization performance over the specified time period.
 */
export declare const listEfficiencyMetrics: API.PaginatedOperationMethod<ListEfficiencyMetricsRequest & RegionInput, ListEfficiencyMetricsResponse, ListEfficiencyMetricsError, Credentials | HttpClient.HttpClient, EfficiencyMetricsByGroup>;
export type ListEnrollmentStatusesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the enrollment status for an account. It can also return the list of accounts that are enrolled under the organization.
 */
export declare const listEnrollmentStatuses: API.PaginatedOperationMethod<ListEnrollmentStatusesRequest & RegionInput, ListEnrollmentStatusesResponse, ListEnrollmentStatusesError, Credentials | HttpClient.HttpClient, AccountEnrollmentStatus>;
export type ListRecommendationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of recommendations.
 */
export declare const listRecommendations: API.PaginatedOperationMethod<ListRecommendationsRequest & RegionInput, ListRecommendationsResponse, ListRecommendationsError, Credentials | HttpClient.HttpClient, Recommendation>;
export type ListRecommendationSummariesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a concise representation of savings estimates for resources. Also returns de-duped savings across different types of recommendations.
 *
 * The following filters are not supported for this API: `recommendationIds`, `resourceArns`, and `resourceIds`.
 */
export declare const listRecommendationSummaries: API.PaginatedOperationMethod<ListRecommendationSummariesRequest & RegionInput, ListRecommendationSummariesResponse, ListRecommendationSummariesError, Credentials | HttpClient.HttpClient, RecommendationSummary>;
export type UpdateEnrollmentStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the enrollment (opt in and opt out) status of an account to the Cost Optimization Hub service.
 *
 * If the account is a management account of an organization, this action can also be used to enroll member accounts of the organization.
 *
 * You must have the appropriate permissions to opt in to Cost Optimization Hub and to view its recommendations. When you opt in, Cost Optimization Hub automatically creates a service-linked role in your account to access its data.
 */
export declare const updateEnrollmentStatus: API.OperationMethod<UpdateEnrollmentStatusRequest & RegionInput, UpdateEnrollmentStatusResponse, UpdateEnrollmentStatusError, Credentials | HttpClient.HttpClient>;
export type UpdatePreferencesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a set of preferences for an account in order to add account-specific preferences into the service. These preferences impact how the savings associated with recommendations are presented.
 */
export declare const updatePreferences: API.OperationMethod<UpdatePreferencesRequest & RegionInput, UpdatePreferencesResponse, UpdatePreferencesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cost-optimization-hub.d.ts.map