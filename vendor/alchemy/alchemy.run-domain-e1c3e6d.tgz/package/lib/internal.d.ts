import * as Cause from "effect/Cause";
import * as DateTime from "effect/DateTime";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Schema from "effect/Schema";
import * as SchemaAST from "effect/SchemaAST";
import { DefinitionError } from "./DefinitionError.ts";
export { DefinitionError } from "./DefinitionError.ts";
/**
 * The one defect a client receives in place of any other: a defect's text
 * can hold stacks, file paths and nested errors (an adapter's SQL error).
 *
 * @internal
 */
export declare const internalError: () => Error;
/**
 * Keep what of a cause a client may see: interrupts, and the failures
 * `declared` keeps. Anything else (a defect, an undeclared failure) is
 * logged here with its whole cause, and becomes {@link internalError}.
 *
 * @internal
 */
export declare const redactCause: (declared: (error: unknown) => boolean, rpc: string) => <E>(cause: Cause.Cause<E>) => Effect.Effect<never, E>;
/**
 * The schema of a command's or a query's `input`. With no fields it is an
 * empty record, not `Schema.Struct({})`: an empty Struct accepts any value
 * but `null`, and its JSON Schema has no `type`, so an agent calling the tool
 * may send the string `"{}"`. The empty record is a JSON object with no
 * properties. The declared type stays `Schema.Struct<F>`.
 *
 * @internal
 */
export declare const inputSchema: <F extends Schema.Struct.Fields>(fields: F | undefined) => Schema.Struct<F>;
/**
 * The `_tag` a rejection class declares: the literal its schema gives
 * `_tag`, so any tagged error class can be a rejection.
 *
 * @internal
 */
export declare const rejectionTag: (rejection: Schema.Top) => string;
/**
 * Where a schema has no JSON form: the paths under `path` of each declaration
 * (such as `Schema.instanceOf`) with no `toCodecJson` annotation. Its values
 * can't be stored or sent: they fail when they are encoded, in production.
 * `Schema.Unknown` and `Schema.Any` pass, because a value decides those.
 *
 * @internal
 */
export declare const pathsWithoutJson: (ast: SchemaAST.AST, path: string, seen?: Set<SchemaAST.AST>) => ReadonlyArray<string>;
/**
 * An effectful decision, run at the time its command is handled at. The clock
 * reads that time for as long as `decide` runs, so `Clock.currentTimeMillis`
 * and `DateTime.now` give what `decide` is given as `now`: a decision is the
 * same however late it runs, and the prover reads the clock as that input.
 *
 * @internal
 */
export declare const decidedAt: <A, E, R>(decision: Effect.Effect<A, E, R>, now: DateTime.Utc) => Effect.Effect<A, E, R>;
/** What `decide` returned, once its Effect (if any) ran. @internal */
export type Settled = {
    readonly _tag: "Decided";
    readonly decision: unknown;
} | {
    readonly _tag: "Failed";
    readonly cause: Cause.Cause<unknown>;
};
/**
 * Settle an effectful decision. A rejection is a `YieldableError`, so it is
 * an Effect too: running it fails with the rejection itself, which is the
 * decision. Any other failure, such as a defect, stays a failure.
 *
 * @internal
 */
export declare const settle: (exit: Exit.Exit<unknown, unknown>) => Settled;
/** A decision, judged against the command's declaration. @internal */
export type Judged = {
    readonly _tag: "Accepted";
    readonly events: ReadonlyArray<{
        readonly _tag: string;
    }>;
} | {
    readonly _tag: "Rejected";
    readonly rejection: {
        readonly _tag: string;
    };
} | {
    readonly _tag: "Undeclared";
    readonly error: DefinitionError;
};
/**
 * Judge a settled decision: the events to commit, the rejection, or the
 * {@link DefinitionError} for an event or rejection the command does not
 * declare.
 *
 * @internal
 */
export declare const judge: (aggregateName: string, command: {
    readonly tag: string;
    readonly events: ReadonlyArray<{
        readonly tag: string;
    }>;
    readonly rejects: ReadonlyArray<Schema.Top>;
}, decision: unknown) => Judged;
/** The id a ref or a Schema key value addresses. @internal */
export declare const targetId: (target: unknown) => string;
/** One input for a view's evolve. @internal */
export interface LocalViewInput {
    readonly name: string;
    readonly event: {
        readonly _tag: string;
    };
    /** A ref for an aggregate source, the key value for a Schema-keyed view. */
    readonly source: unknown;
    readonly state?: unknown;
    readonly envelope: {
        readonly at: unknown;
    };
    readonly key?: unknown;
}
/**
 * Apply one input to one key of a view, with the view's own `keyOf` and
 * `evolve`, as the kernel applies a delivery: each route whose `keyOf`
 * reaches the key runs its handler. An input that reaches no route of the
 * key leaves the state as it is.
 *
 * @internal
 */
export declare const evolveView: (view: {
    readonly definition: {
        readonly state?: unknown;
        readonly initial?: unknown;
        readonly keyOf?: unknown;
        readonly evolve?: unknown;
    };
}, state: unknown, input: LocalViewInput) => unknown;
/**
 * Call a command's client with a decoded wire payload.
 *
 * @internal
 */
export declare const sendPayload: (send: unknown, payload: unknown, options: object) => Effect.Effect<unknown, unknown>;
//# sourceMappingURL=internal.d.ts.map