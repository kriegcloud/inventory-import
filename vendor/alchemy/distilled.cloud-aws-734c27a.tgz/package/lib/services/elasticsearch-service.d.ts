import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BaseException_base: S.TaggedErrorClass<"BaseException", {
    readonly message: any;
}>;
export declare class BaseException extends /*@__PURE__*/ BaseException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const DisabledOperationException_base: S.TaggedErrorClass<"DisabledOperationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DisabledOperationException extends /*@__PURE__*/ DisabledOperationException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidPaginationTokenException_base: S.TaggedErrorClass<"InvalidPaginationTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidPaginationTokenException extends /*@__PURE__*/ InvalidPaginationTokenException_base {
}
declare const InvalidTypeException_base: S.TaggedErrorClass<"InvalidTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidTypeException extends /*@__PURE__*/ InvalidTypeException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CrossClusterSearchConnectionId = string;
export interface AcceptInboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export type OwnerId = string;
export type DomainName = string;
export type Region = string;
export interface DomainInformation {
    OwnerId?: string | undefined;
    DomainName: string;
    Region?: string | undefined;
}
export type InboundCrossClusterSearchConnectionStatusCode = "PENDING_ACCEPTANCE" | "APPROVED" | "REJECTING" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export type CrossClusterSearchConnectionStatusMessage = string;
export interface InboundCrossClusterSearchConnectionStatus {
    StatusCode?: InboundCrossClusterSearchConnectionStatusCode | undefined;
    Message?: string | undefined;
}
export interface InboundCrossClusterSearchConnection {
    SourceDomainInfo?: DomainInformation | undefined;
    DestinationDomainInfo?: DomainInformation | undefined;
    CrossClusterSearchConnectionId?: string | undefined;
    ConnectionStatus?: InboundCrossClusterSearchConnectionStatus | undefined;
}
export interface AcceptInboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: InboundCrossClusterSearchConnection | undefined;
}
export type ARN = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface AddTagsRequest {
    ARN: string;
    TagList: Tag[];
}
export interface AddTagsResponse {
}
export type PackageID = string;
export interface AssociatePackageRequest {
    PackageID: string;
    DomainName: string;
}
export type PackageName = string;
export type PackageType = "TXT-DICTIONARY" | (string & {});
export type LastUpdated = Date;
export type DomainPackageStatus = "ASSOCIATING" | "ASSOCIATION_FAILED" | "ACTIVE" | "DISSOCIATING" | "DISSOCIATION_FAILED" | (string & {});
export type PackageVersion = string;
export type ReferencePath = string;
export type ErrorType = string;
export type ErrorMessage = string;
export interface ErrorDetails {
    ErrorType?: string | undefined;
    ErrorMessage?: string | undefined;
}
export interface DomainPackageDetails {
    PackageID?: string | undefined;
    PackageName?: string | undefined;
    PackageType?: PackageType | undefined;
    LastUpdated?: Date | undefined;
    DomainName?: string | undefined;
    DomainPackageStatus?: DomainPackageStatus | undefined;
    PackageVersion?: string | undefined;
    ReferencePath?: string | undefined;
    ErrorDetails?: ErrorDetails | undefined;
}
export interface AssociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails | undefined;
}
export type AWSAccount = string;
export interface AuthorizeVpcEndpointAccessRequest {
    DomainName: string;
    Account: string;
}
export type PrincipalType = "AWS_ACCOUNT" | "AWS_SERVICE" | (string & {});
export interface AuthorizedPrincipal {
    PrincipalType?: PrincipalType | undefined;
    Principal?: string | undefined;
}
export interface AuthorizeVpcEndpointAccessResponse {
    AuthorizedPrincipal: AuthorizedPrincipal;
}
export type DryRun = boolean;
export interface CancelDomainConfigChangeRequest {
    DomainName: string;
    DryRun?: boolean | undefined;
}
export type GUID = string;
export type GUIDList = string[];
export interface CancelledChangeProperty {
    PropertyName?: string | undefined;
    CancelledValue?: string | undefined;
    ActiveValue?: string | undefined;
}
export type CancelledChangePropertyList = CancelledChangeProperty[];
export interface CancelDomainConfigChangeResponse {
    DryRun?: boolean | undefined;
    CancelledChangeIds?: string[] | undefined;
    CancelledChangeProperties?: CancelledChangeProperty[] | undefined;
}
export interface CancelElasticsearchServiceSoftwareUpdateRequest {
    DomainName: string;
}
export type DeploymentStatus = "PENDING_UPDATE" | "IN_PROGRESS" | "COMPLETED" | "NOT_ELIGIBLE" | "ELIGIBLE" | (string & {});
export type DeploymentCloseDateTimeStamp = Date;
export interface ServiceSoftwareOptions {
    CurrentVersion?: string | undefined;
    NewVersion?: string | undefined;
    UpdateAvailable?: boolean | undefined;
    Cancellable?: boolean | undefined;
    UpdateStatus?: DeploymentStatus | undefined;
    Description?: string | undefined;
    AutomatedUpdateDate?: Date | undefined;
    OptionalDeployment?: boolean | undefined;
}
export interface CancelElasticsearchServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions | undefined;
}
export type ElasticsearchVersionString = string;
export type ESPartitionInstanceType = "m3.medium.elasticsearch" | "m3.large.elasticsearch" | "m3.xlarge.elasticsearch" | "m3.2xlarge.elasticsearch" | "m4.large.elasticsearch" | "m4.xlarge.elasticsearch" | "m4.2xlarge.elasticsearch" | "m4.4xlarge.elasticsearch" | "m4.10xlarge.elasticsearch" | "m5.large.elasticsearch" | "m5.xlarge.elasticsearch" | "m5.2xlarge.elasticsearch" | "m5.4xlarge.elasticsearch" | "m5.12xlarge.elasticsearch" | "r5.large.elasticsearch" | "r5.xlarge.elasticsearch" | "r5.2xlarge.elasticsearch" | "r5.4xlarge.elasticsearch" | "r5.12xlarge.elasticsearch" | "c5.large.elasticsearch" | "c5.xlarge.elasticsearch" | "c5.2xlarge.elasticsearch" | "c5.4xlarge.elasticsearch" | "c5.9xlarge.elasticsearch" | "c5.18xlarge.elasticsearch" | "ultrawarm1.medium.elasticsearch" | "ultrawarm1.large.elasticsearch" | "t2.micro.elasticsearch" | "t2.small.elasticsearch" | "t2.medium.elasticsearch" | "r3.large.elasticsearch" | "r3.xlarge.elasticsearch" | "r3.2xlarge.elasticsearch" | "r3.4xlarge.elasticsearch" | "r3.8xlarge.elasticsearch" | "i2.xlarge.elasticsearch" | "i2.2xlarge.elasticsearch" | "d2.xlarge.elasticsearch" | "d2.2xlarge.elasticsearch" | "d2.4xlarge.elasticsearch" | "d2.8xlarge.elasticsearch" | "c4.large.elasticsearch" | "c4.xlarge.elasticsearch" | "c4.2xlarge.elasticsearch" | "c4.4xlarge.elasticsearch" | "c4.8xlarge.elasticsearch" | "r4.large.elasticsearch" | "r4.xlarge.elasticsearch" | "r4.2xlarge.elasticsearch" | "r4.4xlarge.elasticsearch" | "r4.8xlarge.elasticsearch" | "r4.16xlarge.elasticsearch" | "i3.large.elasticsearch" | "i3.xlarge.elasticsearch" | "i3.2xlarge.elasticsearch" | "i3.4xlarge.elasticsearch" | "i3.8xlarge.elasticsearch" | "i3.16xlarge.elasticsearch" | (string & {});
export type IntegerClass = number;
export interface ZoneAwarenessConfig {
    AvailabilityZoneCount?: number | undefined;
}
export type ESWarmPartitionInstanceType = "ultrawarm1.medium.elasticsearch" | "ultrawarm1.large.elasticsearch" | (string & {});
export interface ColdStorageOptions {
    Enabled: boolean;
}
export interface ElasticsearchClusterConfig {
    InstanceType?: ESPartitionInstanceType | undefined;
    InstanceCount?: number | undefined;
    DedicatedMasterEnabled?: boolean | undefined;
    ZoneAwarenessEnabled?: boolean | undefined;
    ZoneAwarenessConfig?: ZoneAwarenessConfig | undefined;
    DedicatedMasterType?: ESPartitionInstanceType | undefined;
    DedicatedMasterCount?: number | undefined;
    WarmEnabled?: boolean | undefined;
    WarmType?: ESWarmPartitionInstanceType | undefined;
    WarmCount?: number | undefined;
    ColdStorageOptions?: ColdStorageOptions | undefined;
}
export type VolumeType = "standard" | "gp2" | "io1" | "gp3" | (string & {});
export interface EBSOptions {
    EBSEnabled?: boolean | undefined;
    VolumeType?: VolumeType | undefined;
    VolumeSize?: number | undefined;
    Iops?: number | undefined;
    Throughput?: number | undefined;
}
export type PolicyDocument = string;
export interface SnapshotOptions {
    AutomatedSnapshotStartHour?: number | undefined;
}
export type StringList = string[];
export interface VPCOptions {
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export type UserPoolId = string;
export type IdentityPoolId = string;
export type RoleArn = string;
export interface CognitoOptions {
    Enabled?: boolean | undefined;
    UserPoolId?: string | undefined;
    IdentityPoolId?: string | undefined;
    RoleArn?: string | undefined;
}
export type KmsKeyId = string;
export interface EncryptionAtRestOptions {
    Enabled?: boolean | undefined;
    KmsKeyId?: string | undefined;
}
export interface NodeToNodeEncryptionOptions {
    Enabled?: boolean | undefined;
}
export type AdvancedOptions = {
    [key: string]: string | undefined;
};
export type LogType = "INDEX_SLOW_LOGS" | "SEARCH_SLOW_LOGS" | "ES_APPLICATION_LOGS" | "AUDIT_LOGS" | (string & {});
export type CloudWatchLogsLogGroupArn = string;
export interface LogPublishingOption {
    CloudWatchLogsLogGroupArn?: string | undefined;
    Enabled?: boolean | undefined;
}
export type LogPublishingOptions = {
    [key in LogType]?: LogPublishingOption | undefined;
};
export type TLSSecurityPolicy = "Policy-Min-TLS-1-0-2019-07" | "Policy-Min-TLS-1-2-2019-07" | "Policy-Min-TLS-1-2-PFS-2023-10" | "Policy-Min-TLS-1-2-RFC9151-FIPS-2024-08" | (string & {});
export type DomainNameFqdn = string;
export interface DomainEndpointOptions {
    EnforceHTTPS?: boolean | undefined;
    TLSSecurityPolicy?: TLSSecurityPolicy | undefined;
    CustomEndpointEnabled?: boolean | undefined;
    CustomEndpoint?: string | undefined;
    CustomEndpointCertificateArn?: string | undefined;
}
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export interface MasterUserOptions {
    MasterUserARN?: string | undefined;
    MasterUserName?: string | redacted.Redacted<string> | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
}
export type SAMLMetadata = string;
export type SAMLEntityId = string;
export interface SAMLIdp {
    MetadataContent: string;
    EntityId: string;
}
export type BackendRole = string;
export interface SAMLOptionsInput {
    Enabled?: boolean | undefined;
    Idp?: SAMLIdp | undefined;
    MasterUserName?: string | redacted.Redacted<string> | undefined;
    MasterBackendRole?: string | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
    SessionTimeoutMinutes?: number | undefined;
}
export interface AdvancedSecurityOptionsInput {
    Enabled?: boolean | undefined;
    InternalUserDatabaseEnabled?: boolean | undefined;
    MasterUserOptions?: MasterUserOptions | undefined;
    SAMLOptions?: SAMLOptionsInput | undefined;
    AnonymousAuthEnabled?: boolean | undefined;
}
export type AutoTuneDesiredState = "ENABLED" | "DISABLED" | (string & {});
export type StartAt = Date;
export type DurationValue = number;
export type TimeUnit = "HOURS" | (string & {});
export interface Duration {
    Value?: number | undefined;
    Unit?: TimeUnit | undefined;
}
export interface AutoTuneMaintenanceSchedule {
    StartAt?: Date | undefined;
    Duration?: Duration | undefined;
    CronExpressionForRecurrence?: string | undefined;
}
export type AutoTuneMaintenanceScheduleList = AutoTuneMaintenanceSchedule[];
export interface AutoTuneOptionsInput {
    DesiredState?: AutoTuneDesiredState | undefined;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[] | undefined;
}
export type DeploymentStrategy = "Default" | "CapacityOptimized" | (string & {});
export interface DeploymentStrategyOptions {
    DeploymentStrategy: DeploymentStrategy;
}
export type UpdateTimestamp = Date;
export interface AutomatedSnapshotPauseRequestOptions {
    Enabled: boolean;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type DomainUseCase = "SEARCH" | "VECTOR" | "OBSERVABILITY" | "MIXED" | (string & {});
export type DomainEngineMode = "GENERAL" | "OPTIMIZED" | (string & {});
export interface CreateElasticsearchDomainRequest {
    DomainName: string;
    ElasticsearchVersion?: string | undefined;
    ElasticsearchClusterConfig?: ElasticsearchClusterConfig | undefined;
    EBSOptions?: EBSOptions | undefined;
    AccessPolicies?: string | undefined;
    SnapshotOptions?: SnapshotOptions | undefined;
    VPCOptions?: VPCOptions | undefined;
    CognitoOptions?: CognitoOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    DomainEndpointOptions?: DomainEndpointOptions | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput | undefined;
    AutoTuneOptions?: AutoTuneOptionsInput | undefined;
    TagList?: Tag[] | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptions | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions | undefined;
    UseCase?: DomainUseCase | undefined;
    EngineMode?: DomainEngineMode | undefined;
}
export type DomainId = string;
export type ServiceUrl = string;
export type EndpointsMap = {
    [key: string]: string | undefined;
};
export interface VPCDerivedInfo {
    VPCId?: string | undefined;
    SubnetIds?: string[] | undefined;
    AvailabilityZones?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export interface SAMLOptionsOutput {
    Enabled?: boolean | undefined;
    Idp?: SAMLIdp | undefined;
    SubjectKey?: string | undefined;
    RolesKey?: string | undefined;
    SessionTimeoutMinutes?: number | undefined;
}
export type DisableTimestamp = Date;
export interface AdvancedSecurityOptions {
    Enabled?: boolean | undefined;
    InternalUserDatabaseEnabled?: boolean | undefined;
    SAMLOptions?: SAMLOptionsOutput | undefined;
    AnonymousAuthDisableDate?: Date | undefined;
    AnonymousAuthEnabled?: boolean | undefined;
}
export type AutoTuneState = "ENABLED" | "DISABLED" | "ENABLE_IN_PROGRESS" | "DISABLE_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_SCHEDULED" | "DISABLED_AND_ROLLBACK_IN_PROGRESS" | "DISABLED_AND_ROLLBACK_COMPLETE" | "DISABLED_AND_ROLLBACK_ERROR" | "ERROR" | (string & {});
export interface AutoTuneOptionsOutput {
    State?: AutoTuneState | undefined;
    ErrorMessage?: string | undefined;
}
export type Message = string;
export type ConfigChangeStatus = "Pending" | "Initializing" | "Validating" | "ValidationFailed" | "ApplyingChanges" | "Completed" | "PendingUserInput" | "Cancelled" | (string & {});
export type InitiatedBy = "CUSTOMER" | "SERVICE" | (string & {});
export interface ChangeProgressDetails {
    ChangeId?: string | undefined;
    Message?: string | undefined;
    ConfigChangeStatus?: ConfigChangeStatus | undefined;
    StartTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    InitiatedBy?: InitiatedBy | undefined;
}
export type DomainProcessingStatusType = "Creating" | "Active" | "Modifying" | "UpgradingEngineVersion" | "UpdatingServiceSoftware" | "Isolated" | "Deleting" | (string & {});
export type PropertyValueType = "PLAIN_TEXT" | "STRINGIFIED_JSON" | (string & {});
export interface ModifyingProperties {
    Name?: string | undefined;
    ActiveValue?: string | undefined;
    PendingValue?: string | undefined;
    ValueType?: PropertyValueType | undefined;
}
export type ModifyingPropertiesList = ModifyingProperties[];
export type PauseState = "Active" | "Completed" | "Scheduled" | "Disabled" | (string & {});
export interface AutomatedSnapshotPauseOptions {
    Enabled: boolean;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    State?: PauseState | undefined;
}
export interface ElasticsearchDomainStatus {
    DomainId: string;
    DomainName: string;
    ARN: string;
    Created?: boolean | undefined;
    Deleted?: boolean | undefined;
    Endpoint?: string | undefined;
    Endpoints?: {
        [key: string]: string | undefined;
    } | undefined;
    Processing?: boolean | undefined;
    UpgradeProcessing?: boolean | undefined;
    ElasticsearchVersion?: string | undefined;
    ElasticsearchClusterConfig: ElasticsearchClusterConfig;
    EBSOptions?: EBSOptions | undefined;
    AccessPolicies?: string | undefined;
    SnapshotOptions?: SnapshotOptions | undefined;
    VPCOptions?: VPCDerivedInfo | undefined;
    CognitoOptions?: CognitoOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    ServiceSoftwareOptions?: ServiceSoftwareOptions | undefined;
    DomainEndpointOptions?: DomainEndpointOptions | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptions | undefined;
    AutoTuneOptions?: AutoTuneOptionsOutput | undefined;
    ChangeProgressDetails?: ChangeProgressDetails | undefined;
    DomainProcessingStatus?: DomainProcessingStatusType | undefined;
    ModifyingProperties?: ModifyingProperties[] | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptions | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptions | undefined;
    UseCase?: DomainUseCase | undefined;
    EngineMode?: DomainEngineMode | undefined;
}
export interface CreateElasticsearchDomainResponse {
    DomainStatus?: ElasticsearchDomainStatus | undefined;
}
export type ConnectionAlias = string;
export interface CreateOutboundCrossClusterSearchConnectionRequest {
    SourceDomainInfo: DomainInformation;
    DestinationDomainInfo: DomainInformation;
    ConnectionAlias: string;
}
export type OutboundCrossClusterSearchConnectionStatusCode = "PENDING_ACCEPTANCE" | "VALIDATING" | "VALIDATION_FAILED" | "PROVISIONING" | "ACTIVE" | "REJECTED" | "DELETING" | "DELETED" | (string & {});
export interface OutboundCrossClusterSearchConnectionStatus {
    StatusCode?: OutboundCrossClusterSearchConnectionStatusCode | undefined;
    Message?: string | undefined;
}
export interface CreateOutboundCrossClusterSearchConnectionResponse {
    SourceDomainInfo?: DomainInformation | undefined;
    DestinationDomainInfo?: DomainInformation | undefined;
    ConnectionAlias?: string | undefined;
    ConnectionStatus?: OutboundCrossClusterSearchConnectionStatus | undefined;
    CrossClusterSearchConnectionId?: string | undefined;
}
export type PackageDescription = string;
export type S3BucketName = string;
export type S3Key = string;
export interface PackageSource {
    S3BucketName?: string | undefined;
    S3Key?: string | undefined;
}
export interface CreatePackageRequest {
    PackageName: string;
    PackageType: PackageType;
    PackageDescription?: string | undefined;
    PackageSource: PackageSource;
}
export type PackageStatus = "COPYING" | "COPY_FAILED" | "VALIDATING" | "VALIDATION_FAILED" | "AVAILABLE" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export type CreatedAt = Date;
export interface PackageDetails {
    PackageID?: string | undefined;
    PackageName?: string | undefined;
    PackageType?: PackageType | undefined;
    PackageDescription?: string | undefined;
    PackageStatus?: PackageStatus | undefined;
    CreatedAt?: Date | undefined;
    LastUpdatedAt?: Date | undefined;
    AvailablePackageVersion?: string | undefined;
    ErrorDetails?: ErrorDetails | undefined;
}
export interface CreatePackageResponse {
    PackageDetails?: PackageDetails | undefined;
}
export type DomainArn = string;
export type ClientToken = string;
export interface CreateVpcEndpointRequest {
    DomainArn: string;
    VpcOptions: VPCOptions;
    ClientToken?: string | undefined;
}
export type VpcEndpointId = string;
export type VpcEndpointStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETE_FAILED" | (string & {});
export type Endpoint = string;
export interface VpcEndpoint {
    VpcEndpointId?: string | undefined;
    VpcEndpointOwner?: string | undefined;
    DomainArn?: string | undefined;
    VpcOptions?: VPCDerivedInfo | undefined;
    Status?: VpcEndpointStatus | undefined;
    Endpoint?: string | undefined;
}
export interface CreateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export interface DeleteElasticsearchDomainRequest {
    DomainName: string;
}
export interface DeleteElasticsearchDomainResponse {
    DomainStatus?: ElasticsearchDomainStatus | undefined;
}
export interface DeleteElasticsearchServiceRoleRequest {
}
export interface DeleteElasticsearchServiceRoleResponse {
}
export interface DeleteInboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export interface DeleteInboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: InboundCrossClusterSearchConnection | undefined;
}
export interface DeleteOutboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export interface OutboundCrossClusterSearchConnection {
    SourceDomainInfo?: DomainInformation | undefined;
    DestinationDomainInfo?: DomainInformation | undefined;
    CrossClusterSearchConnectionId?: string | undefined;
    ConnectionAlias?: string | undefined;
    ConnectionStatus?: OutboundCrossClusterSearchConnectionStatus | undefined;
}
export interface DeleteOutboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: OutboundCrossClusterSearchConnection | undefined;
}
export interface DeletePackageRequest {
    PackageID: string;
}
export interface DeletePackageResponse {
    PackageDetails?: PackageDetails | undefined;
}
export interface DeleteVpcEndpointRequest {
    VpcEndpointId: string;
}
export interface VpcEndpointSummary {
    VpcEndpointId?: string | undefined;
    VpcEndpointOwner?: string | undefined;
    DomainArn?: string | undefined;
    Status?: VpcEndpointStatus | undefined;
}
export interface DeleteVpcEndpointResponse {
    VpcEndpointSummary: VpcEndpointSummary;
}
export type MaxResults = number;
export type NextToken = string;
export interface DescribeDomainAutoTunesRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AutoTuneType = "SCHEDULED_ACTION" | (string & {});
export type AutoTuneDate = Date;
export type ScheduledAutoTuneActionType = "JVM_HEAP_SIZE_TUNING" | "JVM_YOUNG_GEN_TUNING" | (string & {});
export type ScheduledAutoTuneDescription = string;
export type ScheduledAutoTuneSeverityType = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface ScheduledAutoTuneDetails {
    Date?: Date | undefined;
    ActionType?: ScheduledAutoTuneActionType | undefined;
    Action?: string | undefined;
    Severity?: ScheduledAutoTuneSeverityType | undefined;
}
export interface AutoTuneDetails {
    ScheduledAutoTuneDetails?: ScheduledAutoTuneDetails | undefined;
}
export interface AutoTune {
    AutoTuneType?: AutoTuneType | undefined;
    AutoTuneDetails?: AutoTuneDetails | undefined;
}
export type AutoTuneList = AutoTune[];
export interface DescribeDomainAutoTunesResponse {
    AutoTunes?: AutoTune[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeDomainChangeProgressRequest {
    DomainName: string;
    ChangeId?: string | undefined;
}
export type OverallChangeStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "FAILED" | (string & {});
export type TotalNumberOfStages = number;
export type ChangeProgressStageName = string;
export type ChangeProgressStageStatus = string;
export type Description = string;
export interface ChangeProgressStage {
    Name?: string | undefined;
    Status?: string | undefined;
    Description?: string | undefined;
    LastUpdated?: Date | undefined;
}
export type ChangeProgressStageList = ChangeProgressStage[];
export type TrafficPercent = number;
export interface TrafficPercents {
    PrimaryReadTrafficPercent: number;
    CloneReadTrafficPercent: number;
}
export type ClonedBlueGreenScheduledActionType = "AutomaticCutoverToPrimaryCluster" | "DeletePrimaryCluster" | (string & {});
export interface ClonedBlueGreenScheduledAction {
    Action?: ClonedBlueGreenScheduledActionType | undefined;
    ScheduledTime?: Date | undefined;
}
export interface ClonedBlueGreenUpgradeDetails {
    TrafficSplit?: TrafficPercents | undefined;
    ScheduledAction?: ClonedBlueGreenScheduledAction | undefined;
    RetentionInHours?: number | undefined;
}
export interface ChangeProgressStatusDetails {
    ChangeId?: string | undefined;
    StartTime?: Date | undefined;
    Status?: OverallChangeStatus | undefined;
    PendingProperties?: string[] | undefined;
    CompletedProperties?: string[] | undefined;
    TotalNumberOfStages?: number | undefined;
    ChangeProgressStages?: ChangeProgressStage[] | undefined;
    ConfigChangeStatus?: ConfigChangeStatus | undefined;
    LastUpdatedTime?: Date | undefined;
    InitiatedBy?: InitiatedBy | undefined;
    ClonedBlueGreenUpgradeDetails?: ClonedBlueGreenUpgradeDetails | undefined;
}
export interface DescribeDomainChangeProgressResponse {
    ChangeProgressStatus?: ChangeProgressStatusDetails | undefined;
}
export interface DescribeElasticsearchDomainRequest {
    DomainName: string;
}
export interface DescribeElasticsearchDomainResponse {
    DomainStatus: ElasticsearchDomainStatus;
}
export interface DescribeElasticsearchDomainConfigRequest {
    DomainName: string;
}
export type UIntValue = number;
export type OptionState = "RequiresIndexDocuments" | "Processing" | "Active" | (string & {});
export interface OptionStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number | undefined;
    State: OptionState;
    PendingDeletion?: boolean | undefined;
}
export interface ElasticsearchVersionStatus {
    Options: string;
    Status: OptionStatus;
}
export interface ElasticsearchClusterConfigStatus {
    Options: ElasticsearchClusterConfig;
    Status: OptionStatus;
}
export interface EBSOptionsStatus {
    Options: EBSOptions;
    Status: OptionStatus;
}
export interface AccessPoliciesStatus {
    Options: string;
    Status: OptionStatus;
}
export interface SnapshotOptionsStatus {
    Options: SnapshotOptions;
    Status: OptionStatus;
}
export interface VPCDerivedInfoStatus {
    Options: VPCDerivedInfo;
    Status: OptionStatus;
}
export interface CognitoOptionsStatus {
    Options: CognitoOptions;
    Status: OptionStatus;
}
export interface EncryptionAtRestOptionsStatus {
    Options: EncryptionAtRestOptions;
    Status: OptionStatus;
}
export interface NodeToNodeEncryptionOptionsStatus {
    Options: NodeToNodeEncryptionOptions;
    Status: OptionStatus;
}
export interface AdvancedOptionsStatus {
    Options: {
        [key: string]: string | undefined;
    };
    Status: OptionStatus;
}
export interface LogPublishingOptionsStatus {
    Options?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    Status?: OptionStatus | undefined;
}
export interface DomainEndpointOptionsStatus {
    Options: DomainEndpointOptions;
    Status: OptionStatus;
}
export interface AdvancedSecurityOptionsStatus {
    Options: AdvancedSecurityOptions;
    Status: OptionStatus;
}
export type RollbackOnDisable = "NO_ROLLBACK" | "DEFAULT_ROLLBACK" | (string & {});
export interface AutoTuneOptions {
    DesiredState?: AutoTuneDesiredState | undefined;
    RollbackOnDisable?: RollbackOnDisable | undefined;
    MaintenanceSchedules?: AutoTuneMaintenanceSchedule[] | undefined;
}
export interface AutoTuneStatus {
    CreationDate: Date;
    UpdateDate: Date;
    UpdateVersion?: number | undefined;
    State: AutoTuneState;
    ErrorMessage?: string | undefined;
    PendingDeletion?: boolean | undefined;
}
export interface AutoTuneOptionsStatus {
    Options?: AutoTuneOptions | undefined;
    Status?: AutoTuneStatus | undefined;
}
export interface DeploymentStrategyOptionsStatus {
    Options: DeploymentStrategyOptions;
    Status: OptionStatus;
}
export interface AutomatedSnapshotPauseOptionsStatus {
    Options: AutomatedSnapshotPauseOptions;
    Status: OptionStatus;
}
export interface UseCaseStatus {
    Options: DomainUseCase;
    Status: OptionStatus;
}
export interface EngineModeStatus {
    Options: DomainEngineMode;
    Status: OptionStatus;
}
export interface ElasticsearchDomainConfig {
    ElasticsearchVersion?: ElasticsearchVersionStatus | undefined;
    ElasticsearchClusterConfig?: ElasticsearchClusterConfigStatus | undefined;
    EBSOptions?: EBSOptionsStatus | undefined;
    AccessPolicies?: AccessPoliciesStatus | undefined;
    SnapshotOptions?: SnapshotOptionsStatus | undefined;
    VPCOptions?: VPCDerivedInfoStatus | undefined;
    CognitoOptions?: CognitoOptionsStatus | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptionsStatus | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptionsStatus | undefined;
    AdvancedOptions?: AdvancedOptionsStatus | undefined;
    LogPublishingOptions?: LogPublishingOptionsStatus | undefined;
    DomainEndpointOptions?: DomainEndpointOptionsStatus | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsStatus | undefined;
    AutoTuneOptions?: AutoTuneOptionsStatus | undefined;
    ChangeProgressDetails?: ChangeProgressDetails | undefined;
    ModifyingProperties?: ModifyingProperties[] | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptionsStatus | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseOptionsStatus | undefined;
    UseCase?: UseCaseStatus | undefined;
    EngineMode?: EngineModeStatus | undefined;
}
export interface DescribeElasticsearchDomainConfigResponse {
    DomainConfig: ElasticsearchDomainConfig;
}
export type DomainNameList = string[];
export interface DescribeElasticsearchDomainsRequest {
    DomainNames: string[];
}
export type ElasticsearchDomainStatusList = ElasticsearchDomainStatus[];
export interface DescribeElasticsearchDomainsResponse {
    DomainStatusList: ElasticsearchDomainStatus[];
}
export interface DescribeElasticsearchInstanceTypeLimitsRequest {
    DomainName?: string | undefined;
    InstanceType: ESPartitionInstanceType;
    ElasticsearchVersion: string;
}
export type InstanceRole = string;
export type StorageTypeName = string;
export type StorageSubTypeName = string;
export type LimitName = string;
export type LimitValue = string;
export type LimitValueList = string[];
export interface StorageTypeLimit {
    LimitName?: string | undefined;
    LimitValues?: string[] | undefined;
}
export type StorageTypeLimitList = StorageTypeLimit[];
export interface StorageType {
    StorageTypeName?: string | undefined;
    StorageSubTypeName?: string | undefined;
    StorageTypeLimits?: StorageTypeLimit[] | undefined;
}
export type StorageTypeList = StorageType[];
export type MinimumInstanceCount = number;
export type MaximumInstanceCount = number;
export interface InstanceCountLimits {
    MinimumInstanceCount?: number | undefined;
    MaximumInstanceCount?: number | undefined;
}
export interface InstanceLimits {
    InstanceCountLimits?: InstanceCountLimits | undefined;
}
export interface AdditionalLimit {
    LimitName?: string | undefined;
    LimitValues?: string[] | undefined;
}
export type AdditionalLimitList = AdditionalLimit[];
export interface Limits {
    StorageTypes?: StorageType[] | undefined;
    InstanceLimits?: InstanceLimits | undefined;
    AdditionalLimits?: AdditionalLimit[] | undefined;
}
export type LimitsByRole = {
    [key: string]: Limits | undefined;
};
export interface DescribeElasticsearchInstanceTypeLimitsResponse {
    LimitsByRole?: {
        [key: string]: Limits | undefined;
    } | undefined;
}
export type NonEmptyString = string;
export type ValueStringList = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type FilterList = Filter[];
export interface DescribeInboundCrossClusterSearchConnectionsRequest {
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InboundCrossClusterSearchConnections = InboundCrossClusterSearchConnection[];
export interface DescribeInboundCrossClusterSearchConnectionsResponse {
    CrossClusterSearchConnections?: InboundCrossClusterSearchConnection[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeOutboundCrossClusterSearchConnectionsRequest {
    Filters?: Filter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type OutboundCrossClusterSearchConnections = OutboundCrossClusterSearchConnection[];
export interface DescribeOutboundCrossClusterSearchConnectionsResponse {
    CrossClusterSearchConnections?: OutboundCrossClusterSearchConnection[] | undefined;
    NextToken?: string | undefined;
}
export type DescribePackagesFilterName = "PackageID" | "PackageName" | "PackageStatus" | (string & {});
export type DescribePackagesFilterValue = string;
export type DescribePackagesFilterValues = string[];
export interface DescribePackagesFilter {
    Name?: DescribePackagesFilterName | undefined;
    Value?: string[] | undefined;
}
export type DescribePackagesFilterList = DescribePackagesFilter[];
export interface DescribePackagesRequest {
    Filters?: DescribePackagesFilter[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type PackageDetailsList = PackageDetails[];
export interface DescribePackagesResponse {
    PackageDetailsList?: PackageDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeReservedElasticsearchInstanceOfferingsRequest {
    ReservedElasticsearchInstanceOfferingId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ReservedElasticsearchInstancePaymentOption = "ALL_UPFRONT" | "PARTIAL_UPFRONT" | "NO_UPFRONT" | (string & {});
export interface RecurringCharge {
    RecurringChargeAmount?: number | undefined;
    RecurringChargeFrequency?: string | undefined;
}
export type RecurringChargeList = RecurringCharge[];
export interface ReservedElasticsearchInstanceOffering {
    ReservedElasticsearchInstanceOfferingId?: string | undefined;
    ElasticsearchInstanceType?: ESPartitionInstanceType | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CurrencyCode?: string | undefined;
    PaymentOption?: ReservedElasticsearchInstancePaymentOption | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
}
export type ReservedElasticsearchInstanceOfferingList = ReservedElasticsearchInstanceOffering[];
export interface DescribeReservedElasticsearchInstanceOfferingsResponse {
    NextToken?: string | undefined;
    ReservedElasticsearchInstanceOfferings?: ReservedElasticsearchInstanceOffering[] | undefined;
}
export interface DescribeReservedElasticsearchInstancesRequest {
    ReservedElasticsearchInstanceId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ReservationToken = string;
export interface ReservedElasticsearchInstance {
    ReservationName?: string | undefined;
    ReservedElasticsearchInstanceId?: string | undefined;
    ReservedElasticsearchInstanceOfferingId?: string | undefined;
    ElasticsearchInstanceType?: ESPartitionInstanceType | undefined;
    StartTime?: Date | undefined;
    Duration?: number | undefined;
    FixedPrice?: number | undefined;
    UsagePrice?: number | undefined;
    CurrencyCode?: string | undefined;
    ElasticsearchInstanceCount?: number | undefined;
    State?: string | undefined;
    PaymentOption?: ReservedElasticsearchInstancePaymentOption | undefined;
    RecurringCharges?: RecurringCharge[] | undefined;
}
export type ReservedElasticsearchInstanceList = ReservedElasticsearchInstance[];
export interface DescribeReservedElasticsearchInstancesResponse {
    NextToken?: string | undefined;
    ReservedElasticsearchInstances?: ReservedElasticsearchInstance[] | undefined;
}
export type VpcEndpointIdList = string[];
export interface DescribeVpcEndpointsRequest {
    VpcEndpointIds: string[];
}
export type VpcEndpoints = VpcEndpoint[];
export type VpcEndpointErrorCode = "ENDPOINT_NOT_FOUND" | "SERVER_ERROR" | (string & {});
export interface VpcEndpointError {
    VpcEndpointId?: string | undefined;
    ErrorCode?: VpcEndpointErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type VpcEndpointErrorList = VpcEndpointError[];
export interface DescribeVpcEndpointsResponse {
    VpcEndpoints: VpcEndpoint[];
    VpcEndpointErrors: VpcEndpointError[];
}
export interface DissociatePackageRequest {
    PackageID: string;
    DomainName: string;
}
export interface DissociatePackageResponse {
    DomainPackageDetails?: DomainPackageDetails | undefined;
}
export interface GetCompatibleElasticsearchVersionsRequest {
    DomainName?: string | undefined;
}
export type ElasticsearchVersionList = string[];
export interface CompatibleVersionsMap {
    SourceVersion?: string | undefined;
    TargetVersions?: string[] | undefined;
}
export type CompatibleElasticsearchVersionsList = CompatibleVersionsMap[];
export interface GetCompatibleElasticsearchVersionsResponse {
    CompatibleElasticsearchVersions?: CompatibleVersionsMap[] | undefined;
}
export interface GetPackageVersionHistoryRequest {
    PackageID: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type CommitMessage = string;
export interface PackageVersionHistory {
    PackageVersion?: string | undefined;
    CommitMessage?: string | undefined;
    CreatedAt?: Date | undefined;
}
export type PackageVersionHistoryList = PackageVersionHistory[];
export interface GetPackageVersionHistoryResponse {
    PackageID?: string | undefined;
    PackageVersionHistoryList?: PackageVersionHistory[] | undefined;
    NextToken?: string | undefined;
}
export interface GetUpgradeHistoryRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type UpgradeName = string;
export type StartTimestamp = Date;
export type UpgradeStatus = "IN_PROGRESS" | "SUCCEEDED" | "SUCCEEDED_WITH_ISSUES" | "FAILED" | (string & {});
export type UpgradeStep = "PRE_UPGRADE_CHECK" | "SNAPSHOT" | "UPGRADE" | (string & {});
export type Issue = string;
export type Issues = string[];
export interface UpgradeStepItem {
    UpgradeStep?: UpgradeStep | undefined;
    UpgradeStepStatus?: UpgradeStatus | undefined;
    Issues?: string[] | undefined;
    ProgressPercent?: number | undefined;
}
export type UpgradeStepsList = UpgradeStepItem[];
export interface UpgradeHistory {
    UpgradeName?: string | undefined;
    StartTimestamp?: Date | undefined;
    UpgradeStatus?: UpgradeStatus | undefined;
    StepsList?: UpgradeStepItem[] | undefined;
}
export type UpgradeHistoryList = UpgradeHistory[];
export interface GetUpgradeHistoryResponse {
    UpgradeHistories?: UpgradeHistory[] | undefined;
    NextToken?: string | undefined;
}
export interface GetUpgradeStatusRequest {
    DomainName: string;
}
export interface GetUpgradeStatusResponse {
    UpgradeStep?: UpgradeStep | undefined;
    StepStatus?: UpgradeStatus | undefined;
    UpgradeName?: string | undefined;
}
export type EngineType = "OpenSearch" | "Elasticsearch" | (string & {});
export interface ListDomainNamesRequest {
    EngineType?: EngineType | undefined;
}
export interface DomainInfo {
    DomainName?: string | undefined;
    EngineType?: EngineType | undefined;
}
export type DomainInfoList = DomainInfo[];
export interface ListDomainNamesResponse {
    DomainNames?: DomainInfo[] | undefined;
}
export interface ListDomainsForPackageRequest {
    PackageID: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type DomainPackageDetailsList = DomainPackageDetails[];
export interface ListDomainsForPackageResponse {
    DomainPackageDetailsList?: DomainPackageDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface ListElasticsearchInstanceTypesRequest {
    ElasticsearchVersion: string;
    DomainName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ElasticsearchInstanceTypeList = ESPartitionInstanceType[];
export interface ListElasticsearchInstanceTypesResponse {
    ElasticsearchInstanceTypes?: ESPartitionInstanceType[] | undefined;
    NextToken?: string | undefined;
}
export interface ListElasticsearchVersionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListElasticsearchVersionsResponse {
    ElasticsearchVersions?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPackagesForDomainRequest {
    DomainName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListPackagesForDomainResponse {
    DomainPackageDetailsList?: DomainPackageDetails[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsRequest {
    ARN: string;
}
export interface ListTagsResponse {
    TagList?: Tag[] | undefined;
}
export interface ListVpcEndpointAccessRequest {
    DomainName: string;
    NextToken?: string | undefined;
}
export type AuthorizedPrincipalList = AuthorizedPrincipal[];
export interface ListVpcEndpointAccessResponse {
    AuthorizedPrincipalList: AuthorizedPrincipal[];
    NextToken: string;
}
export interface ListVpcEndpointsRequest {
    NextToken?: string | undefined;
}
export type VpcEndpointSummaryList = VpcEndpointSummary[];
export interface ListVpcEndpointsResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export interface ListVpcEndpointsForDomainRequest {
    DomainName: string;
    NextToken?: string | undefined;
}
export interface ListVpcEndpointsForDomainResponse {
    VpcEndpointSummaryList: VpcEndpointSummary[];
    NextToken: string;
}
export type InstanceCount = number;
export interface PurchaseReservedElasticsearchInstanceOfferingRequest {
    ReservedElasticsearchInstanceOfferingId: string;
    ReservationName: string;
    InstanceCount?: number | undefined;
}
export interface PurchaseReservedElasticsearchInstanceOfferingResponse {
    ReservedElasticsearchInstanceId?: string | undefined;
    ReservationName?: string | undefined;
}
export interface RejectInboundCrossClusterSearchConnectionRequest {
    CrossClusterSearchConnectionId: string;
}
export interface RejectInboundCrossClusterSearchConnectionResponse {
    CrossClusterSearchConnection?: InboundCrossClusterSearchConnection | undefined;
}
export interface RemoveTagsRequest {
    ARN: string;
    TagKeys: string[];
}
export interface RemoveTagsResponse {
}
export interface RevokeVpcEndpointAccessRequest {
    DomainName: string;
    Account: string;
}
export interface RevokeVpcEndpointAccessResponse {
}
export interface StartElasticsearchServiceSoftwareUpdateRequest {
    DomainName: string;
}
export interface StartElasticsearchServiceSoftwareUpdateResponse {
    ServiceSoftwareOptions?: ServiceSoftwareOptions | undefined;
}
export type TrafficStrategy = "ShiftReadTrafficPercent" | (string & {});
export interface TrafficSplitRequestOptions {
    Strategy: TrafficStrategy;
    CloneReadTrafficPercent: number;
}
export type CutoverTarget = "ClonedCluster" | "PrimaryCluster" | (string & {});
export interface CutoverRequestOptions {
    Target: CutoverTarget;
}
export type RetentionAction = "RollbackToPrimaryCluster" | "DeletePrimaryCluster" | (string & {});
export type RetentionOptions = {
    RetentionInHours: number;
    RetentionAction?: undefined;
} | {
    RetentionInHours?: undefined;
    RetentionAction: RetentionAction;
};
export interface UpdateCloneRequest {
    DomainName: string;
    TrafficSplitOptions?: TrafficSplitRequestOptions | undefined;
    CutoverOptions?: CutoverRequestOptions | undefined;
    RetentionOptions?: RetentionOptions | undefined;
}
export type CutoverStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface CutoverOptions {
    Target: CutoverTarget;
    Status: CutoverStatus;
}
export type TrafficSplitStatus = "InProgress" | "Completed" | "Failed" | (string & {});
export interface TrafficSplitOptions {
    Current: TrafficPercents;
    Target: TrafficPercents;
    Status: TrafficSplitStatus;
}
export interface UpdateCloneResponse {
    DomainName: string;
    ChangeId: string;
    CutoverOptions?: CutoverOptions | undefined;
    TrafficSplitOptions?: TrafficSplitOptions | undefined;
    RetentionOptions?: RetentionOptions | undefined;
}
export interface UpdateElasticsearchDomainConfigRequest {
    DomainName: string;
    ElasticsearchClusterConfig?: ElasticsearchClusterConfig | undefined;
    EBSOptions?: EBSOptions | undefined;
    SnapshotOptions?: SnapshotOptions | undefined;
    VPCOptions?: VPCOptions | undefined;
    CognitoOptions?: CognitoOptions | undefined;
    AdvancedOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    AccessPolicies?: string | undefined;
    LogPublishingOptions?: {
        [key: string]: LogPublishingOption | undefined;
    } | undefined;
    DomainEndpointOptions?: DomainEndpointOptions | undefined;
    AdvancedSecurityOptions?: AdvancedSecurityOptionsInput | undefined;
    NodeToNodeEncryptionOptions?: NodeToNodeEncryptionOptions | undefined;
    EncryptionAtRestOptions?: EncryptionAtRestOptions | undefined;
    AutoTuneOptions?: AutoTuneOptions | undefined;
    DryRun?: boolean | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOptions | undefined;
    AutomatedSnapshotPauseOptions?: AutomatedSnapshotPauseRequestOptions | undefined;
    UseCase?: DomainUseCase | undefined;
    EngineMode?: DomainEngineMode | undefined;
}
export type DeploymentType = string;
export interface DryRunResults {
    DeploymentType?: string | undefined;
    Message?: string | undefined;
}
export interface UpdateElasticsearchDomainConfigResponse {
    DomainConfig: ElasticsearchDomainConfig;
    DryRunResults?: DryRunResults | undefined;
}
export interface UpdatePackageRequest {
    PackageID: string;
    PackageSource: PackageSource;
    PackageDescription?: string | undefined;
    CommitMessage?: string | undefined;
}
export interface UpdatePackageResponse {
    PackageDetails?: PackageDetails | undefined;
}
export interface UpdateVpcEndpointRequest {
    VpcEndpointId: string;
    VpcOptions: VPCOptions;
}
export interface UpdateVpcEndpointResponse {
    VpcEndpoint: VpcEndpoint;
}
export type DeploymentStrategyOverride = "ClonedBlueGreen" | (string & {});
export interface ClonedBlueGreenOptions {
    RetentionOptions?: RetentionOptions | undefined;
}
export interface DeploymentStrategyOverrideOptions {
    DeploymentStrategy: DeploymentStrategyOverride;
    ClonedBlueGreenOptions?: ClonedBlueGreenOptions | undefined;
}
export interface UpgradeElasticsearchDomainRequest {
    DomainName: string;
    TargetVersion: string;
    PerformCheckOnly?: boolean | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOverrideOptions | undefined;
}
export interface UpgradeElasticsearchDomainResponse {
    DomainName?: string | undefined;
    TargetVersion?: string | undefined;
    PerformCheckOnly?: boolean | undefined;
    DeploymentStrategyOptions?: DeploymentStrategyOverrideOptions | undefined;
    ChangeProgressDetails?: ChangeProgressDetails | undefined;
}
export type AcceptInboundCrossClusterSearchConnectionError = DisabledOperationException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination domain owner to accept an inbound cross-cluster search connection request.
 */
export declare const acceptInboundCrossClusterSearchConnection: API.OperationMethod<AcceptInboundCrossClusterSearchConnectionRequest & RegionInput, AcceptInboundCrossClusterSearchConnectionResponse, AcceptInboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type AddTagsError = BaseException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Attaches tags to an existing Elasticsearch domain. Tags are a set of case-sensitive key value pairs. An Elasticsearch domain may have up to 10 tags. See
 * Tagging Amazon Elasticsearch Service Domains for more information.
 */
export declare const addTags: API.OperationMethod<AddTagsRequest & RegionInput, AddTagsResponse, AddTagsError, Credentials | HttpClient.HttpClient>;
export type AssociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Associates a package with an Amazon ES domain.
 */
export declare const associatePackage: API.OperationMethod<AssociatePackageRequest & RegionInput, AssociatePackageResponse, AssociatePackageError, Credentials | HttpClient.HttpClient>;
export type AuthorizeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides access to an Amazon OpenSearch Service domain through the use of an interface VPC endpoint.
 */
export declare const authorizeVpcEndpointAccess: API.OperationMethod<AuthorizeVpcEndpointAccessRequest & RegionInput, AuthorizeVpcEndpointAccessResponse, AuthorizeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type CancelDomainConfigChangeError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a pending configuration change on an Amazon OpenSearch Service domain.
 */
export declare const cancelDomainConfigChange: API.OperationMethod<CancelDomainConfigChangeRequest & RegionInput, CancelDomainConfigChangeResponse, CancelDomainConfigChangeError, Credentials | HttpClient.HttpClient>;
export type CancelElasticsearchServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels a scheduled service software update for an Amazon ES domain. You can only perform this operation before the `AutomatedUpdateDate` and when the `UpdateStatus` is in the `PENDING_UPDATE` state.
 */
export declare const cancelElasticsearchServiceSoftwareUpdate: API.OperationMethod<CancelElasticsearchServiceSoftwareUpdateRequest & RegionInput, CancelElasticsearchServiceSoftwareUpdateResponse, CancelElasticsearchServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type CreateElasticsearchDomainError = BaseException | DisabledOperationException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a new Elasticsearch domain. For more information,
 * see Creating Elasticsearch Domains in the *Amazon Elasticsearch Service Developer Guide*.
 */
export declare const createElasticsearchDomain: API.OperationMethod<CreateElasticsearchDomainRequest & RegionInput, CreateElasticsearchDomainResponse, CreateElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export type CreateOutboundCrossClusterSearchConnectionError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a new cross-cluster search connection from a source domain to a destination domain.
 */
export declare const createOutboundCrossClusterSearchConnection: API.OperationMethod<CreateOutboundCrossClusterSearchConnectionRequest & RegionInput, CreateOutboundCrossClusterSearchConnectionResponse, CreateOutboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type CreatePackageError = AccessDeniedException | BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Create a package for use with Amazon ES domains.
 */
export declare const createPackage: API.OperationMethod<CreatePackageRequest & RegionInput, CreatePackageResponse, CreatePackageError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | LimitExceededException | ValidationException | CommonErrors;
/**
 * Creates an Amazon OpenSearch Service-managed VPC endpoint.
 */
export declare const createVpcEndpoint: API.OperationMethod<CreateVpcEndpointRequest & RegionInput, CreateVpcEndpointResponse, CreateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteElasticsearchDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Permanently deletes the specified Elasticsearch domain and all of its data. Once a domain is deleted, it cannot be recovered.
 */
export declare const deleteElasticsearchDomain: API.OperationMethod<DeleteElasticsearchDomainRequest & RegionInput, DeleteElasticsearchDomainResponse, DeleteElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteElasticsearchServiceRoleError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Deletes the service-linked role that Elasticsearch Service uses to manage and maintain VPC domains. Role deletion will fail if any existing VPC domains use the role. You must delete any such Elasticsearch domains before deleting the role. See Deleting Elasticsearch Service Role in *VPC Endpoints for Amazon Elasticsearch Service Domains*.
 */
export declare const deleteElasticsearchServiceRole: API.OperationMethod<DeleteElasticsearchServiceRoleRequest & RegionInput, DeleteElasticsearchServiceRoleResponse, DeleteElasticsearchServiceRoleError, Credentials | HttpClient.HttpClient>;
export type DeleteInboundCrossClusterSearchConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination domain owner to delete an existing inbound cross-cluster search connection.
 */
export declare const deleteInboundCrossClusterSearchConnection: API.OperationMethod<DeleteInboundCrossClusterSearchConnectionRequest & RegionInput, DeleteInboundCrossClusterSearchConnectionResponse, DeleteInboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteOutboundCrossClusterSearchConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the source domain owner to delete an existing outbound cross-cluster search connection.
 */
export declare const deleteOutboundCrossClusterSearchConnection: API.OperationMethod<DeleteOutboundCrossClusterSearchConnectionRequest & RegionInput, DeleteOutboundCrossClusterSearchConnectionResponse, DeleteOutboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the package.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest & RegionInput, DeletePackageResponse, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const deleteVpcEndpoint: API.OperationMethod<DeleteVpcEndpointRequest & RegionInput, DeleteVpcEndpointResponse, DeleteVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainAutoTunesError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides scheduled Auto-Tune action details for the Elasticsearch domain, such as Auto-Tune action type, description, severity, and scheduled date.
 */
export declare const describeDomainAutoTunes: API.PaginatedOperationMethod<DescribeDomainAutoTunesRequest & RegionInput, DescribeDomainAutoTunesResponse, DescribeDomainAutoTunesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeDomainChangeProgressError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about the current blue/green deployment happening on a domain, including
 * a change ID, status, and progress stages.
 */
export declare const describeDomainChangeProgress: API.OperationMethod<DescribeDomainChangeProgressRequest & RegionInput, DescribeDomainChangeProgressResponse, DescribeDomainChangeProgressError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchDomainError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns domain configuration information about the specified Elasticsearch domain, including the domain ID, domain endpoint, and domain ARN.
 */
export declare const describeElasticsearchDomain: API.OperationMethod<DescribeElasticsearchDomainRequest & RegionInput, DescribeElasticsearchDomainResponse, DescribeElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchDomainConfigError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Provides cluster configuration information about the specified Elasticsearch domain, such as the state, creation date, update version, and update date for cluster options.
 */
export declare const describeElasticsearchDomainConfig: API.OperationMethod<DescribeElasticsearchDomainConfigRequest & RegionInput, DescribeElasticsearchDomainConfigResponse, DescribeElasticsearchDomainConfigError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchDomainsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Returns domain configuration information about the specified Elasticsearch domains, including the domain ID, domain endpoint, and domain ARN.
 */
export declare const describeElasticsearchDomains: API.OperationMethod<DescribeElasticsearchDomainsRequest & RegionInput, DescribeElasticsearchDomainsResponse, DescribeElasticsearchDomainsError, Credentials | HttpClient.HttpClient>;
export type DescribeElasticsearchInstanceTypeLimitsError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describe Elasticsearch Limits for a given InstanceType and ElasticsearchVersion.
 * When modifying existing Domain, specify the
 *
 * DomainName
 *
 * to know what Limits are supported for modifying.
 */
export declare const describeElasticsearchInstanceTypeLimits: API.OperationMethod<DescribeElasticsearchInstanceTypeLimitsRequest & RegionInput, DescribeElasticsearchInstanceTypeLimitsResponse, DescribeElasticsearchInstanceTypeLimitsError, Credentials | HttpClient.HttpClient>;
export type DescribeInboundCrossClusterSearchConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the inbound cross-cluster search connections for a destination domain.
 */
export declare const describeInboundCrossClusterSearchConnections: API.PaginatedOperationMethod<DescribeInboundCrossClusterSearchConnectionsRequest & RegionInput, DescribeInboundCrossClusterSearchConnectionsResponse, DescribeInboundCrossClusterSearchConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeOutboundCrossClusterSearchConnectionsError = DisabledOperationException | InvalidPaginationTokenException | CommonErrors;
/**
 * Lists all the outbound cross-cluster search connections for a source domain.
 */
export declare const describeOutboundCrossClusterSearchConnections: API.PaginatedOperationMethod<DescribeOutboundCrossClusterSearchConnectionsRequest & RegionInput, DescribeOutboundCrossClusterSearchConnectionsResponse, DescribeOutboundCrossClusterSearchConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePackagesError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes all packages available to Amazon ES. Includes options for filtering, limiting the number of results, and pagination.
 */
export declare const describePackages: API.PaginatedOperationMethod<DescribePackagesRequest & RegionInput, DescribePackagesResponse, DescribePackagesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedElasticsearchInstanceOfferingsError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists available reserved Elasticsearch instance offerings.
 */
export declare const describeReservedElasticsearchInstanceOfferings: API.PaginatedOperationMethod<DescribeReservedElasticsearchInstanceOfferingsRequest & RegionInput, DescribeReservedElasticsearchInstanceOfferingsResponse, DescribeReservedElasticsearchInstanceOfferingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReservedElasticsearchInstancesError = DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about reserved Elasticsearch instances for this account.
 */
export declare const describeReservedElasticsearchInstances: API.PaginatedOperationMethod<DescribeReservedElasticsearchInstancesRequest & RegionInput, DescribeReservedElasticsearchInstancesResponse, DescribeReservedElasticsearchInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeVpcEndpointsError = BaseException | DisabledOperationException | InternalException | ValidationException | CommonErrors;
/**
 * Describes one or more Amazon OpenSearch Service-managed VPC endpoints.
 */
export declare const describeVpcEndpoints: API.OperationMethod<DescribeVpcEndpointsRequest & RegionInput, DescribeVpcEndpointsResponse, DescribeVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type DissociatePackageError = AccessDeniedException | BaseException | ConflictException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Dissociates a package from the Amazon ES domain.
 */
export declare const dissociatePackage: API.OperationMethod<DissociatePackageRequest & RegionInput, DissociatePackageResponse, DissociatePackageError, Credentials | HttpClient.HttpClient>;
export type GetCompatibleElasticsearchVersionsError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of upgrade compatible Elastisearch versions.
 * You can optionally pass a
 *
 * DomainName
 *
 * to get all upgrade compatible Elasticsearch versions for that specific domain.
 */
export declare const getCompatibleElasticsearchVersions: API.OperationMethod<GetCompatibleElasticsearchVersionsRequest & RegionInput, GetCompatibleElasticsearchVersionsResponse, GetCompatibleElasticsearchVersionsError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionHistoryError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of versions of the package, along with their creation time and commit message.
 */
export declare const getPackageVersionHistory: API.PaginatedOperationMethod<GetPackageVersionHistoryRequest & RegionInput, GetPackageVersionHistoryResponse, GetPackageVersionHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeHistoryError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the complete history of the last 10 upgrades that were performed on the domain.
 */
export declare const getUpgradeHistory: API.PaginatedOperationMethod<GetUpgradeHistoryRequest & RegionInput, GetUpgradeHistoryResponse, GetUpgradeHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type GetUpgradeStatusError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the latest status of the last upgrade or upgrade eligibility check that was performed on the domain.
 */
export declare const getUpgradeStatus: API.OperationMethod<GetUpgradeStatusRequest & RegionInput, GetUpgradeStatusResponse, GetUpgradeStatusError, Credentials | HttpClient.HttpClient>;
export type ListDomainNamesError = BaseException | ValidationException | CommonErrors;
/**
 * Returns the name of all Elasticsearch domains owned by the current user's account.
 */
export declare const listDomainNames: API.OperationMethod<ListDomainNamesRequest & RegionInput, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient>;
export type ListDomainsForPackageError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all Amazon ES domains associated with the package.
 */
export declare const listDomainsForPackage: API.PaginatedOperationMethod<ListDomainsForPackageRequest & RegionInput, ListDomainsForPackageResponse, ListDomainsForPackageError, Credentials | HttpClient.HttpClient, unknown>;
export type ListElasticsearchInstanceTypesError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List all Elasticsearch instance types that are supported for given ElasticsearchVersion
 */
export declare const listElasticsearchInstanceTypes: API.PaginatedOperationMethod<ListElasticsearchInstanceTypesRequest & RegionInput, ListElasticsearchInstanceTypesResponse, ListElasticsearchInstanceTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListElasticsearchVersionsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List all supported Elasticsearch versions
 */
export declare const listElasticsearchVersions: API.PaginatedOperationMethod<ListElasticsearchVersionsRequest & RegionInput, ListElasticsearchVersionsResponse, ListElasticsearchVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPackagesForDomainError = AccessDeniedException | BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists all packages associated with the Amazon ES domain.
 */
export declare const listPackagesForDomain: API.PaginatedOperationMethod<ListPackagesForDomainRequest & RegionInput, ListPackagesForDomainResponse, ListPackagesForDomainError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns all tags for the given Elasticsearch domain.
 */
export declare const listTags: API.OperationMethod<ListTagsRequest & RegionInput, ListTagsResponse, ListTagsError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves information about each principal that is allowed to access a
 * given Amazon OpenSearch Service domain through the use of an interface VPC endpoint.
 */
export declare const listVpcEndpointAccess: API.OperationMethod<ListVpcEndpointAccessRequest & RegionInput, ListVpcEndpointAccessResponse, ListVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsError = BaseException | DisabledOperationException | InternalException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints in the current account and Region.
 */
export declare const listVpcEndpoints: API.OperationMethod<ListVpcEndpointsRequest & RegionInput, ListVpcEndpointsResponse, ListVpcEndpointsError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsForDomainError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves all Amazon OpenSearch Service-managed VPC endpoints associated with a particular domain.
 */
export declare const listVpcEndpointsForDomain: API.OperationMethod<ListVpcEndpointsForDomainRequest & RegionInput, ListVpcEndpointsForDomainResponse, ListVpcEndpointsForDomainError, Credentials | HttpClient.HttpClient>;
export type PurchaseReservedElasticsearchInstanceOfferingError = DisabledOperationException | InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to purchase reserved Elasticsearch instances.
 */
export declare const purchaseReservedElasticsearchInstanceOffering: API.OperationMethod<PurchaseReservedElasticsearchInstanceOfferingRequest & RegionInput, PurchaseReservedElasticsearchInstanceOfferingResponse, PurchaseReservedElasticsearchInstanceOfferingError, Credentials | HttpClient.HttpClient>;
export type RejectInboundCrossClusterSearchConnectionError = DisabledOperationException | ResourceNotFoundException | CommonErrors;
/**
 * Allows the destination domain owner to reject an inbound cross-cluster search connection request.
 */
export declare const rejectInboundCrossClusterSearchConnection: API.OperationMethod<RejectInboundCrossClusterSearchConnectionRequest & RegionInput, RejectInboundCrossClusterSearchConnectionResponse, RejectInboundCrossClusterSearchConnectionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsError = BaseException | InternalException | ValidationException | CommonErrors;
/**
 * Removes the specified set of tags from the specified Elasticsearch domain.
 */
export declare const removeTags: API.OperationMethod<RemoveTagsRequest & RegionInput, RemoveTagsResponse, RemoveTagsError, Credentials | HttpClient.HttpClient>;
export type RevokeVpcEndpointAccessError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Revokes access to an Amazon OpenSearch Service domain that was provided through an interface
 * VPC endpoint.
 */
export declare const revokeVpcEndpointAccess: API.OperationMethod<RevokeVpcEndpointAccessRequest & RegionInput, RevokeVpcEndpointAccessResponse, RevokeVpcEndpointAccessError, Credentials | HttpClient.HttpClient>;
export type StartElasticsearchServiceSoftwareUpdateError = BaseException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Schedules a service software update for an Amazon ES domain.
 */
export declare const startElasticsearchServiceSoftwareUpdate: API.OperationMethod<StartElasticsearchServiceSoftwareUpdateRequest & RegionInput, StartElasticsearchServiceSoftwareUpdateResponse, StartElasticsearchServiceSoftwareUpdateError, Credentials | HttpClient.HttpClient>;
export type UpdateCloneError = BaseException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Manages a cloned blue/green upgrade that is in progress on a domain. Use it to shift a percentage of search traffic to the cloned cluster, to cut over to the cloned cluster or back to the primary cluster, or to change the retention period. Specify exactly one of `TrafficSplitOptions`, `CutoverOptions`, or `RetentionOptions` in each request.
 */
export declare const updateClone: API.OperationMethod<UpdateCloneRequest & RegionInput, UpdateCloneResponse, UpdateCloneError, Credentials | HttpClient.HttpClient>;
export type UpdateElasticsearchDomainConfigError = BaseException | InternalException | InvalidTypeException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies the cluster configuration of the specified Elasticsearch domain, setting as setting the instance type and the number of instances.
 */
export declare const updateElasticsearchDomainConfig: API.OperationMethod<UpdateElasticsearchDomainConfigRequest & RegionInput, UpdateElasticsearchDomainConfigResponse, UpdateElasticsearchDomainConfigError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageError = AccessDeniedException | BaseException | InternalException | LimitExceededException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a package for use with Amazon ES domains.
 */
export declare const updatePackage: API.OperationMethod<UpdatePackageRequest & RegionInput, UpdatePackageResponse, UpdatePackageError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcEndpointError = BaseException | ConflictException | DisabledOperationException | InternalException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Modifies an Amazon OpenSearch Service-managed interface VPC endpoint.
 */
export declare const updateVpcEndpoint: API.OperationMethod<UpdateVpcEndpointRequest & RegionInput, UpdateVpcEndpointResponse, UpdateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type UpgradeElasticsearchDomainError = BaseException | DisabledOperationException | InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Allows you to either upgrade your domain or perform an Upgrade eligibility check to a compatible Elasticsearch version.
 */
export declare const upgradeElasticsearchDomain: API.OperationMethod<UpgradeElasticsearchDomainRequest & RegionInput, UpgradeElasticsearchDomainResponse, UpgradeElasticsearchDomainError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=elasticsearch-service.d.ts.map