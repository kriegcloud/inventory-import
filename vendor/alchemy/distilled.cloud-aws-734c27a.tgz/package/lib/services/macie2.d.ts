import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const MacieNotEnabled_base: S.TaggedErrorClass<"MacieNotEnabled", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class MacieNotEnabled extends /*@__PURE__*/ MacieNotEnabled_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnprocessableEntityException_base: S.TaggedErrorClass<"UnprocessableEntityException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnprocessableEntityException extends /*@__PURE__*/ UnprocessableEntityException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AcceptInvitationRequest {
    administratorAccountId?: string | undefined;
    invitationId?: string | undefined;
    masterAccount?: string | undefined;
}
export interface AcceptInvitationResponse {
}
export type __listOf__string = string[];
export interface BatchGetCustomDataIdentifiersRequest {
    ids?: string[] | undefined;
}
export type __timestampIso8601 = Date;
export interface BatchGetCustomDataIdentifierSummary {
    arn?: string | undefined;
    createdAt?: Date | undefined;
    deleted?: boolean | undefined;
    description?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
}
export type __listOfBatchGetCustomDataIdentifierSummary = BatchGetCustomDataIdentifierSummary[];
export interface BatchGetCustomDataIdentifiersResponse {
    customDataIdentifiers?: BatchGetCustomDataIdentifierSummary[] | undefined;
    notFoundIdentifierIds?: string[] | undefined;
}
export type AutomatedDiscoveryAccountStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AutomatedDiscoveryAccountUpdate {
    accountId?: string | undefined;
    status?: AutomatedDiscoveryAccountStatus | undefined;
}
export type __listOfAutomatedDiscoveryAccountUpdate = AutomatedDiscoveryAccountUpdate[];
export interface BatchUpdateAutomatedDiscoveryAccountsRequest {
    accounts?: AutomatedDiscoveryAccountUpdate[] | undefined;
}
export type AutomatedDiscoveryAccountUpdateErrorCode = "ACCOUNT_PAUSED" | "ACCOUNT_NOT_FOUND" | (string & {});
export interface AutomatedDiscoveryAccountUpdateError {
    accountId?: string | undefined;
    errorCode?: AutomatedDiscoveryAccountUpdateErrorCode | undefined;
}
export type __listOfAutomatedDiscoveryAccountUpdateError = AutomatedDiscoveryAccountUpdateError[];
export interface BatchUpdateAutomatedDiscoveryAccountsResponse {
    errors?: AutomatedDiscoveryAccountUpdateError[] | undefined;
}
export type __stringMin1Max512PatternSS = string;
export type __stringMin3Max255PatternAZaZ093255 = string;
export type __stringMin1Max1024PatternSS = string;
export interface S3WordsList {
    bucketName?: string | undefined;
    objectKey?: string | undefined;
}
export interface AllowListCriteria {
    regex?: string | undefined;
    s3WordsList?: S3WordsList | undefined;
}
export type __stringMin1Max128Pattern = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAllowListRequest {
    clientToken?: string | undefined;
    criteria?: AllowListCriteria | undefined;
    description?: string | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __stringMin71Max89PatternArnAwsAwsCnAwsUsGovMacie2AZ19920D12AllowListAZ0922 = string;
export type __stringMin22Max22PatternAZ0922 = string;
export interface CreateAllowListResponse {
    arn?: string | undefined;
    id?: string | undefined;
}
export type JobType = "ONE_TIME" | "SCHEDULED" | (string & {});
export type ManagedDataIdentifierSelector = "ALL" | "EXCLUDE" | "INCLUDE" | "NONE" | "RECOMMENDED" | (string & {});
export type JobComparator = "EQ" | "GT" | "GTE" | "LT" | "LTE" | "NE" | "CONTAINS" | "STARTS_WITH" | (string & {});
export type SimpleCriterionKeyForJob = "ACCOUNT_ID" | "S3_BUCKET_NAME" | "S3_BUCKET_EFFECTIVE_PERMISSION" | "S3_BUCKET_SHARED_ACCESS" | (string & {});
export interface SimpleCriterionForJob {
    comparator?: JobComparator | undefined;
    key?: SimpleCriterionKeyForJob | undefined;
    values?: string[] | undefined;
}
export interface TagCriterionPairForJob {
    key?: string | undefined;
    value?: string | undefined;
}
export type __listOfTagCriterionPairForJob = TagCriterionPairForJob[];
export interface TagCriterionForJob {
    comparator?: JobComparator | undefined;
    tagValues?: TagCriterionPairForJob[] | undefined;
}
export interface CriteriaForJob {
    simpleCriterion?: SimpleCriterionForJob | undefined;
    tagCriterion?: TagCriterionForJob | undefined;
}
export type __listOfCriteriaForJob = CriteriaForJob[];
export interface CriteriaBlockForJob {
    and?: CriteriaForJob[] | undefined;
}
export interface S3BucketCriteriaForJob {
    excludes?: CriteriaBlockForJob | undefined;
    includes?: CriteriaBlockForJob | undefined;
}
export interface S3BucketDefinitionForJob {
    accountId?: string | undefined;
    buckets?: string[] | undefined;
}
export type __listOfS3BucketDefinitionForJob = S3BucketDefinitionForJob[];
export type ScopeFilterKey = "OBJECT_EXTENSION" | "OBJECT_LAST_MODIFIED_DATE" | "OBJECT_SIZE" | "OBJECT_KEY" | (string & {});
export interface SimpleScopeTerm {
    comparator?: JobComparator | undefined;
    key?: ScopeFilterKey | undefined;
    values?: string[] | undefined;
}
export interface TagValuePair {
    key?: string | undefined;
    value?: string | undefined;
}
export type __listOfTagValuePair = TagValuePair[];
export type TagTarget = "S3_OBJECT" | (string & {});
export interface TagScopeTerm {
    comparator?: JobComparator | undefined;
    key?: string | undefined;
    tagValues?: TagValuePair[] | undefined;
    target?: TagTarget | undefined;
}
export interface JobScopeTerm {
    simpleScopeTerm?: SimpleScopeTerm | undefined;
    tagScopeTerm?: TagScopeTerm | undefined;
}
export type __listOfJobScopeTerm = JobScopeTerm[];
export interface JobScopingBlock {
    and?: JobScopeTerm[] | undefined;
}
export interface Scoping {
    excludes?: JobScopingBlock | undefined;
    includes?: JobScopingBlock | undefined;
}
export interface S3JobDefinition {
    bucketCriteria?: S3BucketCriteriaForJob | undefined;
    bucketDefinitions?: S3BucketDefinitionForJob[] | undefined;
    scoping?: Scoping | undefined;
}
export interface DailySchedule {
}
export interface MonthlySchedule {
    dayOfMonth?: number | undefined;
}
export type DayOfWeek = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export interface WeeklySchedule {
    dayOfWeek?: DayOfWeek | undefined;
}
export interface JobScheduleFrequency {
    dailySchedule?: DailySchedule | undefined;
    monthlySchedule?: MonthlySchedule | undefined;
    weeklySchedule?: WeeklySchedule | undefined;
}
export interface CreateClassificationJobRequest {
    allowListIds?: string[] | undefined;
    clientToken?: string | undefined;
    customDataIdentifierIds?: string[] | undefined;
    description?: string | undefined;
    initialRun?: boolean | undefined;
    jobType?: JobType | undefined;
    managedDataIdentifierIds?: string[] | undefined;
    managedDataIdentifierSelector?: ManagedDataIdentifierSelector | undefined;
    name?: string | undefined;
    s3JobDefinition?: S3JobDefinition | undefined;
    samplingPercentage?: number | undefined;
    scheduleFrequency?: JobScheduleFrequency | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateClassificationJobResponse {
    jobArn?: string | undefined;
    jobId?: string | undefined;
}
export type DataIdentifierSeverity = "LOW" | "MEDIUM" | "HIGH" | (string & {});
export interface SeverityLevel {
    occurrencesThreshold?: number | undefined;
    severity?: DataIdentifierSeverity | undefined;
}
export type SeverityLevelList = SeverityLevel[];
export interface CreateCustomDataIdentifierRequest {
    clientToken?: string | undefined;
    description?: string | undefined;
    ignoreWords?: string[] | undefined;
    keywords?: string[] | undefined;
    maximumMatchDistance?: number | undefined;
    name?: string | undefined;
    regex?: string | undefined;
    severityLevels?: SeverityLevel[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateCustomDataIdentifierResponse {
    customDataIdentifierId?: string | undefined;
}
export type FindingsFilterAction = "ARCHIVE" | "NOOP" | (string & {});
export interface CriterionAdditionalProperties {
    eq?: string[] | undefined;
    eqExactMatch?: string[] | undefined;
    gt?: number | undefined;
    gte?: number | undefined;
    lt?: number | undefined;
    lte?: number | undefined;
    neq?: string[] | undefined;
}
export type Criterion = {
    [key: string]: CriterionAdditionalProperties | undefined;
};
export interface FindingCriteria {
    criterion?: {
        [key: string]: CriterionAdditionalProperties | undefined;
    } | undefined;
}
export interface CreateFindingsFilterRequest {
    action?: FindingsFilterAction | undefined;
    clientToken?: string | undefined;
    description?: string | undefined;
    findingCriteria?: FindingCriteria | undefined;
    name?: string | undefined;
    position?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateFindingsFilterResponse {
    arn?: string | undefined;
    id?: string | undefined;
}
export interface CreateInvitationsRequest {
    accountIds?: string[] | undefined;
    disableEmailNotification?: boolean | undefined;
    message?: string | undefined;
}
export type ErrorCode = "ClientError" | "InternalError" | (string & {});
export interface UnprocessedAccount {
    accountId?: string | undefined;
    errorCode?: ErrorCode | undefined;
    errorMessage?: string | undefined;
}
export type __listOfUnprocessedAccount = UnprocessedAccount[];
export interface CreateInvitationsResponse {
    unprocessedAccounts?: UnprocessedAccount[] | undefined;
}
export interface AccountDetail {
    accountId?: string | undefined;
    email?: string | undefined;
}
export interface CreateMemberRequest {
    account?: AccountDetail | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateMemberResponse {
    arn?: string | undefined;
}
export type FindingType = "SensitiveData:S3Object/Multiple" | "SensitiveData:S3Object/Financial" | "SensitiveData:S3Object/Personal" | "SensitiveData:S3Object/Credentials" | "SensitiveData:S3Object/CustomIdentifier" | "Policy:IAMUser/S3BucketPublic" | "Policy:IAMUser/S3BucketSharedExternally" | "Policy:IAMUser/S3BucketReplicatedExternally" | "Policy:IAMUser/S3BucketEncryptionDisabled" | "Policy:IAMUser/S3BlockPublicAccessDisabled" | "Policy:IAMUser/S3BucketSharedWithCloudFront" | (string & {});
export type __listOfFindingType = FindingType[];
export interface CreateSampleFindingsRequest {
    findingTypes?: FindingType[] | undefined;
}
export interface CreateSampleFindingsResponse {
}
export interface DeclineInvitationsRequest {
    accountIds?: string[] | undefined;
}
export interface DeclineInvitationsResponse {
    unprocessedAccounts?: UnprocessedAccount[] | undefined;
}
export interface DeleteAllowListRequest {
    id: string;
    ignoreJobChecks?: string | undefined;
}
export interface DeleteAllowListResponse {
}
export interface DeleteCustomDataIdentifierRequest {
    id: string;
}
export interface DeleteCustomDataIdentifierResponse {
}
export interface DeleteFindingsFilterRequest {
    id: string;
}
export interface DeleteFindingsFilterResponse {
}
export interface DeleteInvitationsRequest {
    accountIds?: string[] | undefined;
}
export interface DeleteInvitationsResponse {
    unprocessedAccounts?: UnprocessedAccount[] | undefined;
}
export interface DeleteMemberRequest {
    id: string;
}
export interface DeleteMemberResponse {
}
export interface BucketCriteriaAdditionalProperties {
    eq?: string[] | undefined;
    gt?: number | undefined;
    gte?: number | undefined;
    lt?: number | undefined;
    lte?: number | undefined;
    neq?: string[] | undefined;
    prefix?: string | undefined;
}
export type BucketCriteria = {
    [key: string]: BucketCriteriaAdditionalProperties | undefined;
};
export type OrderBy = "ASC" | "DESC" | (string & {});
export interface BucketSortCriteria {
    attributeName?: string | undefined;
    orderBy?: OrderBy | undefined;
}
export interface DescribeBucketsRequest {
    criteria?: {
        [key: string]: BucketCriteriaAdditionalProperties | undefined;
    } | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortCriteria?: BucketSortCriteria | undefined;
}
export type AllowsUnencryptedObjectUploads = "TRUE" | "FALSE" | "UNKNOWN" | (string & {});
export type AutomatedDiscoveryMonitoringStatus = "MONITORED" | "NOT_MONITORED" | (string & {});
export type BucketMetadataErrorCode = "ACCESS_DENIED" | "BUCKET_COUNT_EXCEEDS_QUOTA" | (string & {});
export type IsDefinedInJob = "TRUE" | "FALSE" | "UNKNOWN" | (string & {});
export type IsMonitoredByJob = "TRUE" | "FALSE" | "UNKNOWN" | (string & {});
export interface JobDetails {
    isDefinedInJob?: IsDefinedInJob | undefined;
    isMonitoredByJob?: IsMonitoredByJob | undefined;
    lastJobId?: string | undefined;
    lastJobRunTime?: Date | undefined;
}
export interface ObjectCountByEncryptionType {
    customerManaged?: number | undefined;
    kmsManaged?: number | undefined;
    s3Managed?: number | undefined;
    unencrypted?: number | undefined;
    unknown?: number | undefined;
}
export type EffectivePermission = "PUBLIC" | "NOT_PUBLIC" | "UNKNOWN" | (string & {});
export interface BlockPublicAccess {
    blockPublicAcls?: boolean | undefined;
    blockPublicPolicy?: boolean | undefined;
    ignorePublicAcls?: boolean | undefined;
    restrictPublicBuckets?: boolean | undefined;
}
export interface AccountLevelPermissions {
    blockPublicAccess?: BlockPublicAccess | undefined;
}
export interface AccessControlList {
    allowsPublicReadAccess?: boolean | undefined;
    allowsPublicWriteAccess?: boolean | undefined;
}
export interface BucketPolicy {
    allowsPublicReadAccess?: boolean | undefined;
    allowsPublicWriteAccess?: boolean | undefined;
}
export interface BucketLevelPermissions {
    accessControlList?: AccessControlList | undefined;
    blockPublicAccess?: BlockPublicAccess | undefined;
    bucketPolicy?: BucketPolicy | undefined;
}
export interface BucketPermissionConfiguration {
    accountLevelPermissions?: AccountLevelPermissions | undefined;
    bucketLevelPermissions?: BucketLevelPermissions | undefined;
}
export interface BucketPublicAccess {
    effectivePermission?: EffectivePermission | undefined;
    permissionConfiguration?: BucketPermissionConfiguration | undefined;
}
export interface ReplicationDetails {
    replicated?: boolean | undefined;
    replicatedExternally?: boolean | undefined;
    replicationAccounts?: string[] | undefined;
}
export type Type = "NONE" | "AES256" | "aws:kms" | "aws:kms:dsse" | (string & {});
export interface BucketServerSideEncryption {
    kmsMasterKeyId?: string | undefined;
    type?: Type | undefined;
}
export type SharedAccess = "EXTERNAL" | "INTERNAL" | "NOT_SHARED" | "UNKNOWN" | (string & {});
export interface KeyValuePair {
    key?: string | undefined;
    value?: string | undefined;
}
export type __listOfKeyValuePair = KeyValuePair[];
export interface ObjectLevelStatistics {
    fileType?: number | undefined;
    storageClass?: number | undefined;
    total?: number | undefined;
}
export interface BucketMetadata {
    accountId?: string | undefined;
    allowsUnencryptedObjectUploads?: AllowsUnencryptedObjectUploads | undefined;
    automatedDiscoveryMonitoringStatus?: AutomatedDiscoveryMonitoringStatus | undefined;
    bucketArn?: string | undefined;
    bucketCreatedAt?: Date | undefined;
    bucketName?: string | undefined;
    classifiableObjectCount?: number | undefined;
    classifiableSizeInBytes?: number | undefined;
    errorCode?: BucketMetadataErrorCode | undefined;
    errorMessage?: string | undefined;
    jobDetails?: JobDetails | undefined;
    lastAutomatedDiscoveryTime?: Date | undefined;
    lastUpdated?: Date | undefined;
    objectCount?: number | undefined;
    objectCountByEncryptionType?: ObjectCountByEncryptionType | undefined;
    publicAccess?: BucketPublicAccess | undefined;
    region?: string | undefined;
    replicationDetails?: ReplicationDetails | undefined;
    sensitivityScore?: number | undefined;
    serverSideEncryption?: BucketServerSideEncryption | undefined;
    sharedAccess?: SharedAccess | undefined;
    sizeInBytes?: number | undefined;
    sizeInBytesCompressed?: number | undefined;
    tags?: KeyValuePair[] | undefined;
    unclassifiableObjectCount?: ObjectLevelStatistics | undefined;
    unclassifiableObjectSizeInBytes?: ObjectLevelStatistics | undefined;
    versioning?: boolean | undefined;
}
export type __listOfBucketMetadata = BucketMetadata[];
export interface DescribeBucketsResponse {
    buckets?: BucketMetadata[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeClassificationJobRequest {
    jobId: string;
}
export type JobStatus = "RUNNING" | "PAUSED" | "CANCELLED" | "COMPLETE" | "IDLE" | "USER_PAUSED" | (string & {});
export type LastRunErrorStatusCode = "NONE" | "ERROR" | (string & {});
export interface LastRunErrorStatus {
    code?: LastRunErrorStatusCode | undefined;
}
export interface Statistics {
    approximateNumberOfObjectsToProcess?: number | undefined;
    numberOfRuns?: number | undefined;
}
export interface UserPausedDetails {
    jobExpiresAt?: Date | undefined;
    jobImminentExpirationHealthEventArn?: string | undefined;
    jobPausedAt?: Date | undefined;
}
export interface DescribeClassificationJobResponse {
    allowListIds?: string[] | undefined;
    clientToken?: string | undefined;
    createdAt?: Date | undefined;
    customDataIdentifierIds?: string[] | undefined;
    description?: string | undefined;
    initialRun?: boolean | undefined;
    jobArn?: string | undefined;
    jobId?: string | undefined;
    jobStatus?: JobStatus | undefined;
    jobType?: JobType | undefined;
    lastRunErrorStatus?: LastRunErrorStatus | undefined;
    lastRunTime?: Date | undefined;
    managedDataIdentifierIds?: string[] | undefined;
    managedDataIdentifierSelector?: ManagedDataIdentifierSelector | undefined;
    name?: string | undefined;
    s3JobDefinition?: (S3JobDefinition & {
        bucketDefinitions: (S3BucketDefinitionForJob & {
            accountId: string;
            buckets: __listOf__string;
        })[];
    }) | undefined;
    samplingPercentage?: number | undefined;
    scheduleFrequency?: JobScheduleFrequency | undefined;
    statistics?: Statistics | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    userPausedDetails?: UserPausedDetails | undefined;
}
export interface DescribeOrganizationConfigurationRequest {
}
export interface DescribeOrganizationConfigurationResponse {
    autoEnable?: boolean | undefined;
    maxAccountLimitReached?: boolean | undefined;
}
export interface DisableMacieRequest {
}
export interface DisableMacieResponse {
}
export interface DisableOrganizationAdminAccountRequest {
    adminAccountId?: string | undefined;
}
export interface DisableOrganizationAdminAccountResponse {
}
export interface DisassociateFromAdministratorAccountRequest {
}
export interface DisassociateFromAdministratorAccountResponse {
}
export interface DisassociateFromMasterAccountRequest {
}
export interface DisassociateFromMasterAccountResponse {
}
export interface DisassociateMemberRequest {
    id: string;
}
export interface DisassociateMemberResponse {
}
export type FindingPublishingFrequency = "FIFTEEN_MINUTES" | "ONE_HOUR" | "SIX_HOURS" | (string & {});
export type MacieStatus = "PAUSED" | "ENABLED" | (string & {});
export interface EnableMacieRequest {
    clientToken?: string | undefined;
    findingPublishingFrequency?: FindingPublishingFrequency | undefined;
    status?: MacieStatus | undefined;
}
export interface EnableMacieResponse {
}
export interface EnableOrganizationAdminAccountRequest {
    adminAccountId?: string | undefined;
    clientToken?: string | undefined;
}
export interface EnableOrganizationAdminAccountResponse {
}
export interface GetAdministratorAccountRequest {
}
export type RelationshipStatus = "Enabled" | "Paused" | "Invited" | "Created" | "Removed" | "Resigned" | "EmailVerificationInProgress" | "EmailVerificationFailed" | "RegionDisabled" | "AccountSuspended" | (string & {});
export interface Invitation {
    accountId?: string | undefined;
    invitationId?: string | undefined;
    invitedAt?: Date | undefined;
    relationshipStatus?: RelationshipStatus | undefined;
}
export interface GetAdministratorAccountResponse {
    administrator?: Invitation | undefined;
}
export interface GetAllowListRequest {
    id: string;
}
export type AllowListStatusCode = "OK" | "S3_OBJECT_NOT_FOUND" | "S3_USER_ACCESS_DENIED" | "S3_OBJECT_ACCESS_DENIED" | "S3_THROTTLED" | "S3_OBJECT_OVERSIZE" | "S3_OBJECT_EMPTY" | "UNKNOWN_ERROR" | (string & {});
export interface AllowListStatus {
    code?: AllowListStatusCode | undefined;
    description?: string | undefined;
}
export interface GetAllowListResponse {
    arn?: string | undefined;
    createdAt?: Date | undefined;
    criteria?: (AllowListCriteria & {
        s3WordsList: S3WordsList & {
            bucketName: __stringMin3Max255PatternAZaZ093255;
            objectKey: __stringMin1Max1024PatternSS;
        };
    }) | undefined;
    description?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    status?: (AllowListStatus & {
        code: AllowListStatusCode;
    }) | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    updatedAt?: Date | undefined;
}
export interface GetAutomatedDiscoveryConfigurationRequest {
}
export type AutoEnableMode = "ALL" | "NEW" | "NONE" | (string & {});
export type ClassificationScopeId = string;
export type SensitivityInspectionTemplateId = string;
export type AutomatedDiscoveryStatus = "ENABLED" | "DISABLED" | (string & {});
export interface GetAutomatedDiscoveryConfigurationResponse {
    autoEnableOrganizationMembers?: AutoEnableMode | undefined;
    classificationScopeId?: string | undefined;
    disabledAt?: Date | undefined;
    firstEnabledAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    sensitivityInspectionTemplateId?: string | undefined;
    status?: AutomatedDiscoveryStatus | undefined;
}
export interface GetBucketStatisticsRequest {
    accountId?: string | undefined;
}
export interface BucketCountByEffectivePermission {
    publiclyAccessible?: number | undefined;
    publiclyReadable?: number | undefined;
    publiclyWritable?: number | undefined;
    unknown?: number | undefined;
}
export interface BucketCountByEncryptionType {
    kmsManaged?: number | undefined;
    s3Managed?: number | undefined;
    unencrypted?: number | undefined;
    unknown?: number | undefined;
}
export interface BucketCountPolicyAllowsUnencryptedObjectUploads {
    allowsUnencryptedObjectUploads?: number | undefined;
    deniesUnencryptedObjectUploads?: number | undefined;
    unknown?: number | undefined;
}
export interface BucketCountBySharedAccessType {
    external?: number | undefined;
    internal?: number | undefined;
    notShared?: number | undefined;
    unknown?: number | undefined;
}
export interface SensitivityAggregations {
    classifiableSizeInBytes?: number | undefined;
    publiclyAccessibleCount?: number | undefined;
    totalCount?: number | undefined;
    totalSizeInBytes?: number | undefined;
}
export interface BucketStatisticsBySensitivity {
    classificationError?: SensitivityAggregations | undefined;
    notClassified?: SensitivityAggregations | undefined;
    notSensitive?: SensitivityAggregations | undefined;
    sensitive?: SensitivityAggregations | undefined;
}
export interface GetBucketStatisticsResponse {
    bucketCount?: number | undefined;
    bucketCountByEffectivePermission?: BucketCountByEffectivePermission | undefined;
    bucketCountByEncryptionType?: BucketCountByEncryptionType | undefined;
    bucketCountByObjectEncryptionRequirement?: BucketCountPolicyAllowsUnencryptedObjectUploads | undefined;
    bucketCountBySharedAccessType?: BucketCountBySharedAccessType | undefined;
    bucketStatisticsBySensitivity?: BucketStatisticsBySensitivity | undefined;
    classifiableObjectCount?: number | undefined;
    classifiableSizeInBytes?: number | undefined;
    lastUpdated?: Date | undefined;
    objectCount?: number | undefined;
    sizeInBytes?: number | undefined;
    sizeInBytesCompressed?: number | undefined;
    unclassifiableObjectCount?: ObjectLevelStatistics | undefined;
    unclassifiableObjectSizeInBytes?: ObjectLevelStatistics | undefined;
}
export interface GetClassificationExportConfigurationRequest {
}
export interface S3Destination {
    bucketName?: string | undefined;
    expectedBucketOwner?: string | undefined;
    keyPrefix?: string | undefined;
    kmsKeyArn?: string | undefined;
}
export interface ClassificationExportConfiguration {
    s3Destination?: S3Destination | undefined;
}
export interface GetClassificationExportConfigurationResponse {
    configuration?: (ClassificationExportConfiguration & {
        s3Destination: S3Destination & {
            bucketName: string;
            kmsKeyArn: string;
        };
    }) | undefined;
}
export interface GetClassificationScopeRequest {
    id: string;
}
export type ClassificationScopeName = string;
export type S3BucketName = string;
export type __listOfS3BucketName = string[];
export interface S3ClassificationScopeExclusion {
    bucketNames?: string[] | undefined;
}
export interface S3ClassificationScope {
    excludes?: S3ClassificationScopeExclusion | undefined;
}
export interface GetClassificationScopeResponse {
    id?: string | undefined;
    name?: string | undefined;
    s3?: (S3ClassificationScope & {
        excludes: S3ClassificationScopeExclusion & {
            bucketNames: __listOfS3BucketName;
        };
    }) | undefined;
}
export interface GetCustomDataIdentifierRequest {
    id: string;
}
export interface GetCustomDataIdentifierResponse {
    arn?: string | undefined;
    createdAt?: Date | undefined;
    deleted?: boolean | undefined;
    description?: string | undefined;
    id?: string | undefined;
    ignoreWords?: string[] | undefined;
    keywords?: string[] | undefined;
    maximumMatchDistance?: number | undefined;
    name?: string | undefined;
    regex?: string | undefined;
    severityLevels?: (SeverityLevel & {
        occurrencesThreshold: number;
        severity: DataIdentifierSeverity;
    })[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface SortCriteria {
    attributeName?: string | undefined;
    orderBy?: OrderBy | undefined;
}
export interface GetFindingsRequest {
    findingIds?: string[] | undefined;
    sortCriteria?: SortCriteria | undefined;
}
export type FindingCategory = "CLASSIFICATION" | "POLICY" | (string & {});
export type OriginType = "SENSITIVE_DATA_DISCOVERY_JOB" | "AUTOMATED_SENSITIVE_DATA_DISCOVERY" | (string & {});
export interface Cell {
    cellReference?: string | undefined;
    column?: number | undefined;
    columnName?: string | undefined;
    row?: number | undefined;
}
export type Cells = Cell[];
export interface Range {
    end?: number | undefined;
    start?: number | undefined;
    startColumn?: number | undefined;
}
export type Ranges = Range[];
export interface Page {
    lineRange?: Range | undefined;
    offsetRange?: Range | undefined;
    pageNumber?: number | undefined;
}
export type Pages = Page[];
export interface Record {
    jsonPath?: string | undefined;
    recordIndex?: number | undefined;
}
export type Records = Record[];
export interface Occurrences {
    cells?: Cell[] | undefined;
    lineRanges?: Range[] | undefined;
    offsetRanges?: Range[] | undefined;
    pages?: Page[] | undefined;
    records?: Record[] | undefined;
}
export interface CustomDetection {
    arn?: string | undefined;
    count?: number | undefined;
    name?: string | undefined;
    occurrences?: Occurrences | undefined;
}
export type CustomDetections = CustomDetection[];
export interface CustomDataIdentifiers {
    detections?: CustomDetection[] | undefined;
    totalCount?: number | undefined;
}
export type SensitiveDataItemCategory = "FINANCIAL_INFORMATION" | "PERSONAL_INFORMATION" | "CREDENTIALS" | "CUSTOM_IDENTIFIER" | (string & {});
export interface DefaultDetection {
    count?: number | undefined;
    occurrences?: Occurrences | undefined;
    type?: string | undefined;
}
export type DefaultDetections = DefaultDetection[];
export interface SensitiveDataItem {
    category?: SensitiveDataItemCategory | undefined;
    detections?: DefaultDetection[] | undefined;
    totalCount?: number | undefined;
}
export type SensitiveData = SensitiveDataItem[];
export interface ClassificationResultStatus {
    code?: string | undefined;
    reason?: string | undefined;
}
export interface ClassificationResult {
    additionalOccurrences?: boolean | undefined;
    customDataIdentifiers?: CustomDataIdentifiers | undefined;
    mimeType?: string | undefined;
    sensitiveData?: SensitiveDataItem[] | undefined;
    sizeClassified?: number | undefined;
    status?: ClassificationResultStatus | undefined;
}
export interface ClassificationDetails {
    detailedResultsLocation?: string | undefined;
    jobArn?: string | undefined;
    jobId?: string | undefined;
    originType?: OriginType | undefined;
    result?: ClassificationResult | undefined;
}
export type FindingActionType = "AWS_API_CALL" | (string & {});
export interface ApiCallDetails {
    api?: string | undefined;
    apiServiceName?: string | undefined;
    firstSeen?: Date | undefined;
    lastSeen?: Date | undefined;
}
export interface FindingAction {
    actionType?: FindingActionType | undefined;
    apiCallDetails?: ApiCallDetails | undefined;
}
export interface DomainDetails {
    domainName?: string | undefined;
}
export interface IpCity {
    name?: string | undefined;
}
export interface IpCountry {
    code?: string | undefined;
    name?: string | undefined;
}
export interface IpGeoLocation {
    lat?: number | undefined;
    lon?: number | undefined;
}
export interface IpOwner {
    asn?: string | undefined;
    asnOrg?: string | undefined;
    isp?: string | undefined;
    org?: string | undefined;
}
export interface IpAddressDetails {
    ipAddressV4?: string | undefined;
    ipCity?: IpCity | undefined;
    ipCountry?: IpCountry | undefined;
    ipGeoLocation?: IpGeoLocation | undefined;
    ipOwner?: IpOwner | undefined;
}
export interface SessionContextAttributes {
    creationDate?: Date | undefined;
    mfaAuthenticated?: boolean | undefined;
}
export interface SessionIssuer {
    accountId?: string | undefined;
    arn?: string | undefined;
    principalId?: string | undefined;
    type?: string | undefined;
    userName?: string | undefined;
}
export interface SessionContext {
    attributes?: SessionContextAttributes | undefined;
    sessionIssuer?: SessionIssuer | undefined;
}
export interface AssumedRole {
    accessKeyId?: string | undefined;
    accountId?: string | undefined;
    arn?: string | undefined;
    principalId?: string | undefined;
    sessionContext?: SessionContext | undefined;
}
export interface AwsAccount {
    accountId?: string | undefined;
    principalId?: string | undefined;
}
export interface AwsService {
    invokedBy?: string | undefined;
}
export interface FederatedUser {
    accessKeyId?: string | undefined;
    accountId?: string | undefined;
    arn?: string | undefined;
    principalId?: string | undefined;
    sessionContext?: SessionContext | undefined;
}
export interface IamUser {
    accountId?: string | undefined;
    arn?: string | undefined;
    principalId?: string | undefined;
    userName?: string | undefined;
}
export interface UserIdentityRoot {
    accountId?: string | undefined;
    arn?: string | undefined;
    principalId?: string | undefined;
}
export type UserIdentityType = "AssumedRole" | "IAMUser" | "FederatedUser" | "Root" | "AWSAccount" | "AWSService" | (string & {});
export interface UserIdentity {
    assumedRole?: AssumedRole | undefined;
    awsAccount?: AwsAccount | undefined;
    awsService?: AwsService | undefined;
    federatedUser?: FederatedUser | undefined;
    iamUser?: IamUser | undefined;
    root?: UserIdentityRoot | undefined;
    type?: UserIdentityType | undefined;
}
export interface FindingActor {
    domainDetails?: DomainDetails | undefined;
    ipAddressDetails?: IpAddressDetails | undefined;
    userIdentity?: UserIdentity | undefined;
}
export interface PolicyDetails {
    action?: FindingAction | undefined;
    actor?: FindingActor | undefined;
}
export type EncryptionType = "NONE" | "AES256" | "aws:kms" | "UNKNOWN" | "aws:kms:dsse" | (string & {});
export interface ServerSideEncryption {
    encryptionType?: EncryptionType | undefined;
    kmsMasterKeyId?: string | undefined;
}
export interface S3BucketOwner {
    displayName?: string | undefined;
    id?: string | undefined;
}
export type KeyValuePairList = KeyValuePair[];
export interface S3Bucket {
    allowsUnencryptedObjectUploads?: AllowsUnencryptedObjectUploads | undefined;
    arn?: string | undefined;
    createdAt?: Date | undefined;
    defaultServerSideEncryption?: ServerSideEncryption | undefined;
    name?: string | undefined;
    owner?: S3BucketOwner | undefined;
    publicAccess?: BucketPublicAccess | undefined;
    tags?: KeyValuePair[] | undefined;
}
export type StorageClass = "STANDARD" | "REDUCED_REDUNDANCY" | "STANDARD_IA" | "INTELLIGENT_TIERING" | "DEEP_ARCHIVE" | "ONEZONE_IA" | "GLACIER" | "GLACIER_IR" | "OUTPOSTS" | (string & {});
export interface S3Object {
    bucketArn?: string | undefined;
    eTag?: string | undefined;
    extension?: string | undefined;
    key?: string | undefined;
    lastModified?: Date | undefined;
    path?: string | undefined;
    publicAccess?: boolean | undefined;
    serverSideEncryption?: ServerSideEncryption | undefined;
    size?: number | undefined;
    storageClass?: StorageClass | undefined;
    tags?: KeyValuePair[] | undefined;
    versionId?: string | undefined;
}
export interface ResourcesAffected {
    s3Bucket?: S3Bucket | undefined;
    s3Object?: S3Object | undefined;
}
export type SeverityDescription = "Low" | "Medium" | "High" | (string & {});
export interface Severity {
    description?: SeverityDescription | undefined;
    score?: number | undefined;
}
export interface Finding {
    accountId?: string | undefined;
    archived?: boolean | undefined;
    category?: FindingCategory | undefined;
    classificationDetails?: ClassificationDetails | undefined;
    count?: number | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    id?: string | undefined;
    partition?: string | undefined;
    policyDetails?: PolicyDetails | undefined;
    region?: string | undefined;
    resourcesAffected?: ResourcesAffected | undefined;
    sample?: boolean | undefined;
    schemaVersion?: string | undefined;
    severity?: Severity | undefined;
    title?: string | undefined;
    type?: FindingType | undefined;
    updatedAt?: Date | undefined;
}
export type __listOfFinding = Finding[];
export interface GetFindingsResponse {
    findings?: Finding[] | undefined;
}
export interface GetFindingsFilterRequest {
    id: string;
}
export interface GetFindingsFilterResponse {
    action?: FindingsFilterAction | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    findingCriteria?: FindingCriteria | undefined;
    id?: string | undefined;
    name?: string | undefined;
    position?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetFindingsPublicationConfigurationRequest {
}
export interface SecurityHubConfiguration {
    publishClassificationFindings?: boolean | undefined;
    publishPolicyFindings?: boolean | undefined;
}
export interface GetFindingsPublicationConfigurationResponse {
    securityHubConfiguration?: (SecurityHubConfiguration & {
        publishClassificationFindings: boolean;
        publishPolicyFindings: boolean;
    }) | undefined;
}
export type GroupBy = "resourcesAffected.s3Bucket.name" | "type" | "classificationDetails.jobId" | "severity.description" | (string & {});
export type FindingStatisticsSortAttributeName = "groupKey" | "count" | (string & {});
export interface FindingStatisticsSortCriteria {
    attributeName?: FindingStatisticsSortAttributeName | undefined;
    orderBy?: OrderBy | undefined;
}
export interface GetFindingStatisticsRequest {
    findingCriteria?: FindingCriteria | undefined;
    groupBy?: GroupBy | undefined;
    size?: number | undefined;
    sortCriteria?: FindingStatisticsSortCriteria | undefined;
}
export interface GroupCount {
    count?: number | undefined;
    groupKey?: string | undefined;
}
export type __listOfGroupCount = GroupCount[];
export interface GetFindingStatisticsResponse {
    countsByGroup?: GroupCount[] | undefined;
}
export interface GetInvitationsCountRequest {
}
export interface GetInvitationsCountResponse {
    invitationsCount?: number | undefined;
}
export interface GetMacieSessionRequest {
}
export interface GetMacieSessionResponse {
    createdAt?: Date | undefined;
    findingPublishingFrequency?: FindingPublishingFrequency | undefined;
    serviceRole?: string | undefined;
    status?: MacieStatus | undefined;
    updatedAt?: Date | undefined;
}
export interface GetMasterAccountRequest {
}
export interface GetMasterAccountResponse {
    master?: Invitation | undefined;
}
export interface GetMemberRequest {
    id: string;
}
export interface GetMemberResponse {
    accountId?: string | undefined;
    administratorAccountId?: string | undefined;
    arn?: string | undefined;
    email?: string | undefined;
    invitedAt?: Date | undefined;
    masterAccountId?: string | undefined;
    relationshipStatus?: RelationshipStatus | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    updatedAt?: Date | undefined;
}
export interface GetResourceProfileRequest {
    resourceArn?: string | undefined;
}
export interface ResourceStatistics {
    totalBytesClassified?: number | undefined;
    totalDetections?: number | undefined;
    totalDetectionsSuppressed?: number | undefined;
    totalItemsClassified?: number | undefined;
    totalItemsSensitive?: number | undefined;
    totalItemsSkipped?: number | undefined;
    totalItemsSkippedInvalidEncryption?: number | undefined;
    totalItemsSkippedInvalidKms?: number | undefined;
    totalItemsSkippedPermissionDenied?: number | undefined;
}
export interface GetResourceProfileResponse {
    profileUpdatedAt?: Date | undefined;
    sensitivityScore?: number | undefined;
    sensitivityScoreOverridden?: boolean | undefined;
    statistics?: ResourceStatistics | undefined;
}
export interface GetRevealConfigurationRequest {
}
export type __stringMin1Max2048 = string;
export type RevealStatus = "ENABLED" | "DISABLED" | (string & {});
export interface RevealConfiguration {
    kmsKeyId?: string | undefined;
    status?: RevealStatus | undefined;
}
export type RetrievalMode = "CALLER_CREDENTIALS" | "ASSUME_ROLE" | (string & {});
export type __stringMin1Max64PatternW = string;
export interface RetrievalConfiguration {
    externalId?: string | undefined;
    retrievalMode?: RetrievalMode | undefined;
    roleName?: string | undefined;
}
export interface GetRevealConfigurationResponse {
    configuration?: (RevealConfiguration & {
        status: RevealStatus;
    }) | undefined;
    retrievalConfiguration?: (RetrievalConfiguration & {
        retrievalMode: RetrievalMode;
    }) | undefined;
}
export interface GetSensitiveDataOccurrencesRequest {
    findingId: string;
}
export type __stringMin1Max128 = string;
export interface DetectedDataDetails {
    value?: string | redacted.Redacted<string> | undefined;
}
export type __listOfDetectedDataDetails = DetectedDataDetails[];
export type SensitiveDataOccurrences = {
    [key: string]: DetectedDataDetails[] | undefined;
};
export type RevealRequestStatus = "SUCCESS" | "PROCESSING" | "ERROR" | (string & {});
export interface GetSensitiveDataOccurrencesResponse {
    error?: string | undefined;
    sensitiveDataOccurrences?: {
        [key: string]: (DetectedDataDetails & {
            value: __stringMin1Max128;
        })[] | undefined;
    } | undefined;
    status?: RevealRequestStatus | undefined;
}
export interface GetSensitiveDataOccurrencesAvailabilityRequest {
    findingId: string;
}
export type AvailabilityCode = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export type UnavailabilityReasonCode = "OBJECT_EXCEEDS_SIZE_QUOTA" | "UNSUPPORTED_OBJECT_TYPE" | "UNSUPPORTED_FINDING_TYPE" | "INVALID_CLASSIFICATION_RESULT" | "OBJECT_UNAVAILABLE" | "ACCOUNT_NOT_IN_ORGANIZATION" | "MISSING_GET_MEMBER_PERMISSION" | "ROLE_TOO_PERMISSIVE" | "MEMBER_ROLE_TOO_PERMISSIVE" | "INVALID_RESULT_SIGNATURE" | "RESULT_NOT_SIGNED" | (string & {});
export type __listOfUnavailabilityReasonCode = UnavailabilityReasonCode[];
export interface GetSensitiveDataOccurrencesAvailabilityResponse {
    code?: AvailabilityCode | undefined;
    reasons?: UnavailabilityReasonCode[] | undefined;
}
export interface GetSensitivityInspectionTemplateRequest {
    id: string;
}
export interface SensitivityInspectionTemplateExcludes {
    managedDataIdentifierIds?: string[] | undefined;
}
export interface SensitivityInspectionTemplateIncludes {
    allowListIds?: string[] | undefined;
    customDataIdentifierIds?: string[] | undefined;
    managedDataIdentifierIds?: string[] | undefined;
}
export interface GetSensitivityInspectionTemplateResponse {
    description?: string | undefined;
    excludes?: SensitivityInspectionTemplateExcludes | undefined;
    includes?: SensitivityInspectionTemplateIncludes | undefined;
    name?: string | undefined;
    sensitivityInspectionTemplateId?: string | undefined;
}
export type UsageStatisticsFilterComparator = "GT" | "GTE" | "LT" | "LTE" | "EQ" | "NE" | "CONTAINS" | (string & {});
export type UsageStatisticsFilterKey = "accountId" | "serviceLimit" | "freeTrialStartDate" | "total" | (string & {});
export interface UsageStatisticsFilter {
    comparator?: UsageStatisticsFilterComparator | undefined;
    key?: UsageStatisticsFilterKey | undefined;
    values?: string[] | undefined;
}
export type __listOfUsageStatisticsFilter = UsageStatisticsFilter[];
export type UsageStatisticsSortKey = "accountId" | "total" | "serviceLimitValue" | "freeTrialStartDate" | (string & {});
export interface UsageStatisticsSortBy {
    key?: UsageStatisticsSortKey | undefined;
    orderBy?: OrderBy | undefined;
}
export type TimeRange = "MONTH_TO_DATE" | "PAST_30_DAYS" | (string & {});
export interface GetUsageStatisticsRequest {
    filterBy?: UsageStatisticsFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortBy?: UsageStatisticsSortBy | undefined;
    timeRange?: TimeRange | undefined;
}
export type Currency = "USD" | (string & {});
export type Unit = "TERABYTES" | (string & {});
export interface ServiceLimit {
    isServiceLimited?: boolean | undefined;
    unit?: Unit | undefined;
    value?: number | undefined;
}
export type UsageType = "DATA_INVENTORY_EVALUATION" | "SENSITIVE_DATA_DISCOVERY" | "AUTOMATED_SENSITIVE_DATA_DISCOVERY" | "AUTOMATED_OBJECT_MONITORING" | (string & {});
export interface UsageByAccount {
    currency?: Currency | undefined;
    estimatedCost?: string | undefined;
    serviceLimit?: ServiceLimit | undefined;
    type?: UsageType | undefined;
}
export type __listOfUsageByAccount = UsageByAccount[];
export interface UsageRecord {
    accountId?: string | undefined;
    automatedDiscoveryFreeTrialStartDate?: Date | undefined;
    freeTrialStartDate?: Date | undefined;
    usage?: UsageByAccount[] | undefined;
}
export type __listOfUsageRecord = UsageRecord[];
export interface GetUsageStatisticsResponse {
    nextToken?: string | undefined;
    records?: UsageRecord[] | undefined;
    timeRange?: TimeRange | undefined;
}
export interface GetUsageTotalsRequest {
    timeRange?: string | undefined;
}
export interface UsageTotal {
    currency?: Currency | undefined;
    estimatedCost?: string | undefined;
    type?: UsageType | undefined;
}
export type __listOfUsageTotal = UsageTotal[];
export interface GetUsageTotalsResponse {
    timeRange?: TimeRange | undefined;
    usageTotals?: UsageTotal[] | undefined;
}
export type MaxResults = number;
export interface ListAllowListsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AllowListSummary {
    arn?: string | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    updatedAt?: Date | undefined;
}
export type __listOfAllowListSummary = AllowListSummary[];
export interface ListAllowListsResponse {
    allowLists?: AllowListSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAutomatedDiscoveryAccountsRequest {
    accountIds?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AutomatedDiscoveryAccount {
    accountId?: string | undefined;
    status?: AutomatedDiscoveryAccountStatus | undefined;
}
export type __listOfAutomatedDiscoveryAccount = AutomatedDiscoveryAccount[];
export interface ListAutomatedDiscoveryAccountsResponse {
    items?: AutomatedDiscoveryAccount[] | undefined;
    nextToken?: string | undefined;
}
export type ListJobsFilterKey = "jobType" | "jobStatus" | "createdAt" | "name" | (string & {});
export interface ListJobsFilterTerm {
    comparator?: JobComparator | undefined;
    key?: ListJobsFilterKey | undefined;
    values?: string[] | undefined;
}
export type __listOfListJobsFilterTerm = ListJobsFilterTerm[];
export interface ListJobsFilterCriteria {
    excludes?: ListJobsFilterTerm[] | undefined;
    includes?: ListJobsFilterTerm[] | undefined;
}
export type ListJobsSortAttributeName = "createdAt" | "jobStatus" | "name" | "jobType" | (string & {});
export interface ListJobsSortCriteria {
    attributeName?: ListJobsSortAttributeName | undefined;
    orderBy?: OrderBy | undefined;
}
export interface ListClassificationJobsRequest {
    filterCriteria?: ListJobsFilterCriteria | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortCriteria?: ListJobsSortCriteria | undefined;
}
export interface JobSummary {
    bucketCriteria?: S3BucketCriteriaForJob | undefined;
    bucketDefinitions?: S3BucketDefinitionForJob[] | undefined;
    createdAt?: Date | undefined;
    jobId?: string | undefined;
    jobStatus?: JobStatus | undefined;
    jobType?: JobType | undefined;
    lastRunErrorStatus?: LastRunErrorStatus | undefined;
    name?: string | undefined;
    userPausedDetails?: UserPausedDetails | undefined;
}
export type __listOfJobSummary = JobSummary[];
export interface ListClassificationJobsResponse {
    items?: (JobSummary & {
        bucketDefinitions: (S3BucketDefinitionForJob & {
            accountId: string;
            buckets: __listOf__string;
        })[];
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface ListClassificationScopesRequest {
    name?: string | undefined;
    nextToken?: string | undefined;
}
export interface ClassificationScopeSummary {
    id?: string | undefined;
    name?: string | undefined;
}
export type __listOfClassificationScopeSummary = ClassificationScopeSummary[];
export type NextToken = string;
export interface ListClassificationScopesResponse {
    classificationScopes?: ClassificationScopeSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCustomDataIdentifiersRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface CustomDataIdentifierSummary {
    arn?: string | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
}
export type __listOfCustomDataIdentifierSummary = CustomDataIdentifierSummary[];
export interface ListCustomDataIdentifiersResponse {
    items?: CustomDataIdentifierSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFindingsRequest {
    findingCriteria?: FindingCriteria | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortCriteria?: SortCriteria | undefined;
}
export interface ListFindingsResponse {
    findingIds?: string[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFindingsFiltersRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FindingsFilterListItem {
    action?: FindingsFilterAction | undefined;
    arn?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfFindingsFilterListItem = FindingsFilterListItem[];
export interface ListFindingsFiltersResponse {
    findingsFilterListItems?: FindingsFilterListItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListInvitationsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type __listOfInvitation = Invitation[];
export interface ListInvitationsResponse {
    invitations?: Invitation[] | undefined;
    nextToken?: string | undefined;
}
export interface ListManagedDataIdentifiersRequest {
    nextToken?: string | undefined;
}
export interface ManagedDataIdentifierSummary {
    category?: SensitiveDataItemCategory | undefined;
    id?: string | undefined;
}
export type __listOfManagedDataIdentifierSummary = ManagedDataIdentifierSummary[];
export interface ListManagedDataIdentifiersResponse {
    items?: ManagedDataIdentifierSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListMembersRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    onlyAssociated?: string | undefined;
}
export interface Member {
    accountId?: string | undefined;
    administratorAccountId?: string | undefined;
    arn?: string | undefined;
    email?: string | undefined;
    invitedAt?: Date | undefined;
    masterAccountId?: string | undefined;
    relationshipStatus?: RelationshipStatus | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    updatedAt?: Date | undefined;
}
export type __listOfMember = Member[];
export interface ListMembersResponse {
    members?: Member[] | undefined;
    nextToken?: string | undefined;
}
export interface ListOrganizationAdminAccountsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AdminStatus = "ENABLED" | "DISABLING_IN_PROGRESS" | (string & {});
export interface AdminAccount {
    accountId?: string | undefined;
    status?: AdminStatus | undefined;
}
export type __listOfAdminAccount = AdminAccount[];
export interface ListOrganizationAdminAccountsResponse {
    adminAccounts?: AdminAccount[] | undefined;
    nextToken?: string | undefined;
}
export interface ListResourceProfileArtifactsRequest {
    nextToken?: string | undefined;
    resourceArn?: string | undefined;
}
export interface ResourceProfileArtifact {
    arn?: string | undefined;
    classificationResultStatus?: string | undefined;
    sensitive?: boolean | undefined;
}
export type __listOfResourceProfileArtifact = ResourceProfileArtifact[];
export interface ListResourceProfileArtifactsResponse {
    artifacts?: (ResourceProfileArtifact & {
        arn: string;
        classificationResultStatus: string;
    })[] | undefined;
    nextToken?: string | undefined;
}
export interface ListResourceProfileDetectionsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    resourceArn?: string | undefined;
}
export type DataIdentifierType = "CUSTOM" | "MANAGED" | (string & {});
export interface Detection {
    arn?: string | undefined;
    count?: number | undefined;
    id?: string | undefined;
    name?: string | undefined;
    suppressed?: boolean | undefined;
    type?: DataIdentifierType | undefined;
}
export type __listOfDetection = Detection[];
export interface ListResourceProfileDetectionsResponse {
    detections?: Detection[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSensitivityInspectionTemplatesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface SensitivityInspectionTemplatesEntry {
    id?: string | undefined;
    name?: string | undefined;
}
export type __listOfSensitivityInspectionTemplatesEntry = SensitivityInspectionTemplatesEntry[];
export interface ListSensitivityInspectionTemplatesResponse {
    nextToken?: string | undefined;
    sensitivityInspectionTemplates?: SensitivityInspectionTemplatesEntry[] | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutClassificationExportConfigurationRequest {
    configuration?: ClassificationExportConfiguration | undefined;
}
export interface PutClassificationExportConfigurationResponse {
    configuration?: (ClassificationExportConfiguration & {
        s3Destination: S3Destination & {
            bucketName: string;
            kmsKeyArn: string;
        };
    }) | undefined;
}
export interface PutFindingsPublicationConfigurationRequest {
    clientToken?: string | undefined;
    securityHubConfiguration?: SecurityHubConfiguration | undefined;
}
export interface PutFindingsPublicationConfigurationResponse {
}
export type SearchResourcesComparator = "EQ" | "NE" | (string & {});
export type SearchResourcesSimpleCriterionKey = "ACCOUNT_ID" | "S3_BUCKET_NAME" | "S3_BUCKET_EFFECTIVE_PERMISSION" | "S3_BUCKET_SHARED_ACCESS" | "AUTOMATED_DISCOVERY_MONITORING_STATUS" | (string & {});
export interface SearchResourcesSimpleCriterion {
    comparator?: SearchResourcesComparator | undefined;
    key?: SearchResourcesSimpleCriterionKey | undefined;
    values?: string[] | undefined;
}
export interface SearchResourcesTagCriterionPair {
    key?: string | undefined;
    value?: string | undefined;
}
export type __listOfSearchResourcesTagCriterionPair = SearchResourcesTagCriterionPair[];
export interface SearchResourcesTagCriterion {
    comparator?: SearchResourcesComparator | undefined;
    tagValues?: SearchResourcesTagCriterionPair[] | undefined;
}
export interface SearchResourcesCriteria {
    simpleCriterion?: SearchResourcesSimpleCriterion | undefined;
    tagCriterion?: SearchResourcesTagCriterion | undefined;
}
export type __listOfSearchResourcesCriteria = SearchResourcesCriteria[];
export interface SearchResourcesCriteriaBlock {
    and?: SearchResourcesCriteria[] | undefined;
}
export interface SearchResourcesBucketCriteria {
    excludes?: SearchResourcesCriteriaBlock | undefined;
    includes?: SearchResourcesCriteriaBlock | undefined;
}
export type SearchResourcesSortAttributeName = "ACCOUNT_ID" | "RESOURCE_NAME" | "S3_CLASSIFIABLE_OBJECT_COUNT" | "S3_CLASSIFIABLE_SIZE_IN_BYTES" | (string & {});
export interface SearchResourcesSortCriteria {
    attributeName?: SearchResourcesSortAttributeName | undefined;
    orderBy?: OrderBy | undefined;
}
export interface SearchResourcesRequest {
    bucketCriteria?: SearchResourcesBucketCriteria | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    sortCriteria?: SearchResourcesSortCriteria | undefined;
}
export interface MatchingBucket {
    accountId?: string | undefined;
    automatedDiscoveryMonitoringStatus?: AutomatedDiscoveryMonitoringStatus | undefined;
    bucketName?: string | undefined;
    classifiableObjectCount?: number | undefined;
    classifiableSizeInBytes?: number | undefined;
    errorCode?: BucketMetadataErrorCode | undefined;
    errorMessage?: string | undefined;
    jobDetails?: JobDetails | undefined;
    lastAutomatedDiscoveryTime?: Date | undefined;
    objectCount?: number | undefined;
    objectCountByEncryptionType?: ObjectCountByEncryptionType | undefined;
    sensitivityScore?: number | undefined;
    sizeInBytes?: number | undefined;
    sizeInBytesCompressed?: number | undefined;
    unclassifiableObjectCount?: ObjectLevelStatistics | undefined;
    unclassifiableObjectSizeInBytes?: ObjectLevelStatistics | undefined;
}
export interface MatchingResource {
    matchingBucket?: MatchingBucket | undefined;
}
export type __listOfMatchingResource = MatchingResource[];
export interface SearchResourcesResponse {
    matchingResources?: MatchingResource[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface TestCustomDataIdentifierRequest {
    ignoreWords?: string[] | undefined;
    keywords?: string[] | undefined;
    maximumMatchDistance?: number | undefined;
    regex?: string | undefined;
    sampleText?: string | undefined;
}
export interface TestCustomDataIdentifierResponse {
    matchCount?: number | undefined;
}
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateAllowListRequest {
    criteria?: AllowListCriteria | undefined;
    description?: string | undefined;
    id: string;
    name?: string | undefined;
}
export interface UpdateAllowListResponse {
    arn?: string | undefined;
    id?: string | undefined;
}
export interface UpdateAutomatedDiscoveryConfigurationRequest {
    autoEnableOrganizationMembers?: AutoEnableMode | undefined;
    status?: AutomatedDiscoveryStatus | undefined;
}
export interface UpdateAutomatedDiscoveryConfigurationResponse {
}
export interface UpdateClassificationJobRequest {
    jobId: string;
    jobStatus?: JobStatus | undefined;
}
export interface UpdateClassificationJobResponse {
}
export type ClassificationScopeUpdateOperation = "ADD" | "REPLACE" | "REMOVE" | (string & {});
export interface S3ClassificationScopeExclusionUpdate {
    bucketNames?: string[] | undefined;
    operation?: ClassificationScopeUpdateOperation | undefined;
}
export interface S3ClassificationScopeUpdate {
    excludes?: S3ClassificationScopeExclusionUpdate | undefined;
}
export interface UpdateClassificationScopeRequest {
    id: string;
    s3?: S3ClassificationScopeUpdate | undefined;
}
export interface UpdateClassificationScopeResponse {
}
export interface UpdateFindingsFilterRequest {
    action?: FindingsFilterAction | undefined;
    clientToken?: string | undefined;
    description?: string | undefined;
    findingCriteria?: FindingCriteria | undefined;
    id: string;
    name?: string | undefined;
    position?: number | undefined;
}
export interface UpdateFindingsFilterResponse {
    arn?: string | undefined;
    id?: string | undefined;
}
export interface UpdateMacieSessionRequest {
    findingPublishingFrequency?: FindingPublishingFrequency | undefined;
    status?: MacieStatus | undefined;
}
export interface UpdateMacieSessionResponse {
}
export interface UpdateMemberSessionRequest {
    id: string;
    status?: MacieStatus | undefined;
}
export interface UpdateMemberSessionResponse {
}
export interface UpdateOrganizationConfigurationRequest {
    autoEnable?: boolean | undefined;
}
export interface UpdateOrganizationConfigurationResponse {
}
export interface UpdateResourceProfileRequest {
    resourceArn?: string | undefined;
    sensitivityScoreOverride?: number | undefined;
}
export interface UpdateResourceProfileResponse {
}
export interface SuppressDataIdentifier {
    id?: string | undefined;
    type?: DataIdentifierType | undefined;
}
export type __listOfSuppressDataIdentifier = SuppressDataIdentifier[];
export interface UpdateResourceProfileDetectionsRequest {
    resourceArn?: string | undefined;
    suppressDataIdentifiers?: SuppressDataIdentifier[] | undefined;
}
export interface UpdateResourceProfileDetectionsResponse {
}
export interface UpdateRetrievalConfiguration {
    retrievalMode?: RetrievalMode | undefined;
    roleName?: string | undefined;
}
export interface UpdateRevealConfigurationRequest {
    configuration?: RevealConfiguration | undefined;
    retrievalConfiguration?: UpdateRetrievalConfiguration | undefined;
}
export interface UpdateRevealConfigurationResponse {
    configuration?: (RevealConfiguration & {
        status: RevealStatus;
    }) | undefined;
    retrievalConfiguration?: (RetrievalConfiguration & {
        retrievalMode: RetrievalMode;
    }) | undefined;
}
export interface UpdateSensitivityInspectionTemplateRequest {
    description?: string | undefined;
    excludes?: SensitivityInspectionTemplateExcludes | undefined;
    id: string;
    includes?: SensitivityInspectionTemplateIncludes | undefined;
}
export interface UpdateSensitivityInspectionTemplateResponse {
}
export type AcceptInvitationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Accepts an Amazon Macie membership invitation that was received from a specific account.
 */
export declare const acceptInvitation: API.OperationMethod<AcceptInvitationRequest & RegionInput, AcceptInvitationResponse, AcceptInvitationError, Credentials | HttpClient.HttpClient>;
export type BatchGetCustomDataIdentifiersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about one or more custom data identifiers.
 */
export declare const batchGetCustomDataIdentifiers: API.OperationMethod<BatchGetCustomDataIdentifiersRequest & RegionInput, BatchGetCustomDataIdentifiersResponse, BatchGetCustomDataIdentifiersError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateAutomatedDiscoveryAccountsError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes the status of automated sensitive data discovery for one or more accounts.
 */
export declare const batchUpdateAutomatedDiscoveryAccounts: API.OperationMethod<BatchUpdateAutomatedDiscoveryAccountsRequest & RegionInput, BatchUpdateAutomatedDiscoveryAccountsResponse, BatchUpdateAutomatedDiscoveryAccountsError, Credentials | HttpClient.HttpClient>;
export type CreateAllowListError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | MacieNotEnabled | CommonErrors;
/**
 * Creates and defines the settings for an allow list.
 */
export declare const createAllowList: API.OperationMethod<CreateAllowListRequest & RegionInput, CreateAllowListResponse, CreateAllowListError, Credentials | HttpClient.HttpClient>;
export type CreateClassificationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | MacieNotEnabled | CommonErrors;
/**
 * Creates and defines the settings for a classification job.
 */
export declare const createClassificationJob: API.OperationMethod<CreateClassificationJobRequest & RegionInput, CreateClassificationJobResponse, CreateClassificationJobError, Credentials | HttpClient.HttpClient>;
export type CreateCustomDataIdentifierError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | MacieNotEnabled | CommonErrors;
/**
 * Creates and defines the criteria and other settings for a custom data identifier.
 */
export declare const createCustomDataIdentifier: API.OperationMethod<CreateCustomDataIdentifierRequest & RegionInput, CreateCustomDataIdentifierResponse, CreateCustomDataIdentifierError, Credentials | HttpClient.HttpClient>;
export type CreateFindingsFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | MacieNotEnabled | CommonErrors;
/**
 * Creates and defines the criteria and other settings for a findings filter.
 */
export declare const createFindingsFilter: API.OperationMethod<CreateFindingsFilterRequest & RegionInput, CreateFindingsFilterResponse, CreateFindingsFilterError, Credentials | HttpClient.HttpClient>;
export type CreateInvitationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends an Amazon Macie membership invitation to one or more accounts.
 */
export declare const createInvitations: API.OperationMethod<CreateInvitationsRequest & RegionInput, CreateInvitationsResponse, CreateInvitationsError, Credentials | HttpClient.HttpClient>;
export type CreateMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an account with an Amazon Macie administrator account.
 */
export declare const createMember: API.OperationMethod<CreateMemberRequest & RegionInput, CreateMemberResponse, CreateMemberError, Credentials | HttpClient.HttpClient>;
export type CreateSampleFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates sample findings.
 */
export declare const createSampleFindings: API.OperationMethod<CreateSampleFindingsRequest & RegionInput, CreateSampleFindingsResponse, CreateSampleFindingsError, Credentials | HttpClient.HttpClient>;
export type DeclineInvitationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Declines Amazon Macie membership invitations that were received from specific accounts.
 */
export declare const declineInvitations: API.OperationMethod<DeclineInvitationsRequest & RegionInput, DeclineInvitationsResponse, DeclineInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteAllowListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an allow list.
 */
export declare const deleteAllowList: API.OperationMethod<DeleteAllowListRequest & RegionInput, DeleteAllowListResponse, DeleteAllowListError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomDataIdentifierError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Soft deletes a custom data identifier.
 */
export declare const deleteCustomDataIdentifier: API.OperationMethod<DeleteCustomDataIdentifierRequest & RegionInput, DeleteCustomDataIdentifierResponse, DeleteCustomDataIdentifierError, Credentials | HttpClient.HttpClient>;
export type DeleteFindingsFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a findings filter.
 */
export declare const deleteFindingsFilter: API.OperationMethod<DeleteFindingsFilterRequest & RegionInput, DeleteFindingsFilterResponse, DeleteFindingsFilterError, Credentials | HttpClient.HttpClient>;
export type DeleteInvitationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes Amazon Macie membership invitations that were received from specific accounts.
 */
export declare const deleteInvitations: API.OperationMethod<DeleteInvitationsRequest & RegionInput, DeleteInvitationsResponse, DeleteInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the association between an Amazon Macie administrator account and an account.
 */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest & RegionInput, DeleteMemberResponse, DeleteMemberError, Credentials | HttpClient.HttpClient>;
export type DescribeBucketsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) statistical data and other information about one or more S3 buckets that Amazon Macie monitors and analyzes for an account.
 */
export declare const describeBuckets: API.PaginatedOperationMethod<DescribeBucketsRequest & RegionInput, DescribeBucketsResponse, DescribeBucketsError, Credentials | HttpClient.HttpClient, BucketMetadata>;
export type DescribeClassificationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status and settings for a classification job.
 */
export declare const describeClassificationJob: API.OperationMethod<DescribeClassificationJobRequest & RegionInput, DescribeClassificationJobResponse, DescribeClassificationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the Amazon Macie configuration settings for an organization in Organizations.
 */
export declare const describeOrganizationConfiguration: API.OperationMethod<DescribeOrganizationConfigurationRequest & RegionInput, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DisableMacieError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables Amazon Macie and deletes all settings and resources for a Macie account.
 */
export declare const disableMacie: API.OperationMethod<DisableMacieRequest & RegionInput, DisableMacieResponse, DisableMacieError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationAdminAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables an account as the delegated Amazon Macie administrator account for an organization in Organizations.
 */
export declare const disableOrganizationAdminAccount: API.OperationMethod<DisableOrganizationAdminAccountRequest & RegionInput, DisableOrganizationAdminAccountResponse, DisableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromAdministratorAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a member account from its Amazon Macie administrator account.
 */
export declare const disassociateFromAdministratorAccount: API.OperationMethod<DisassociateFromAdministratorAccountRequest & RegionInput, DisassociateFromAdministratorAccountResponse, DisassociateFromAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromMasterAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * (Deprecated) Disassociates a member account from its Amazon Macie administrator account. This operation has been replaced by the DisassociateFromAdministratorAccount operation.
 */
export declare const disassociateFromMasterAccount: API.OperationMethod<DisassociateFromMasterAccountRequest & RegionInput, DisassociateFromMasterAccountResponse, DisassociateFromMasterAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an Amazon Macie administrator account from a member account.
 */
export declare const disassociateMember: API.OperationMethod<DisassociateMemberRequest & RegionInput, DisassociateMemberResponse, DisassociateMemberError, Credentials | HttpClient.HttpClient>;
export type EnableMacieError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables Amazon Macie and specifies the configuration settings for a Macie account.
 */
export declare const enableMacie: API.OperationMethod<EnableMacieRequest & RegionInput, EnableMacieResponse, EnableMacieError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationAdminAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Designates an account as the delegated Amazon Macie administrator account for an organization in Organizations.
 */
export declare const enableOrganizationAdminAccount: API.OperationMethod<EnableOrganizationAdminAccountRequest & RegionInput, EnableOrganizationAdminAccountResponse, EnableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetAdministratorAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the Amazon Macie administrator account for an account.
 */
export declare const getAdministratorAccount: API.OperationMethod<GetAdministratorAccountRequest & RegionInput, GetAdministratorAccountResponse, GetAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type GetAllowListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the settings and status of an allow list.
 */
export declare const getAllowList: API.OperationMethod<GetAllowListRequest & RegionInput, GetAllowListResponse, GetAllowListError, Credentials | HttpClient.HttpClient>;
export type GetAutomatedDiscoveryConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration settings and status of automated sensitive data discovery for an organization or standalone account.
 */
export declare const getAutomatedDiscoveryConfiguration: API.OperationMethod<GetAutomatedDiscoveryConfigurationRequest & RegionInput, GetAutomatedDiscoveryConfigurationResponse, GetAutomatedDiscoveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetBucketStatisticsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) aggregated statistical data about all the S3 buckets that Amazon Macie monitors and analyzes for an account.
 */
export declare const getBucketStatistics: API.OperationMethod<GetBucketStatisticsRequest & RegionInput, GetBucketStatisticsResponse, GetBucketStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetClassificationExportConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration settings for storing data classification results.
 */
export declare const getClassificationExportConfiguration: API.OperationMethod<GetClassificationExportConfigurationRequest & RegionInput, GetClassificationExportConfigurationResponse, GetClassificationExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetClassificationScopeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the classification scope settings for an account.
 */
export declare const getClassificationScope: API.OperationMethod<GetClassificationScopeRequest & RegionInput, GetClassificationScopeResponse, GetClassificationScopeError, Credentials | HttpClient.HttpClient>;
export type GetCustomDataIdentifierError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the criteria and other settings for a custom data identifier.
 */
export declare const getCustomDataIdentifier: API.OperationMethod<GetCustomDataIdentifierRequest & RegionInput, GetCustomDataIdentifierResponse, GetCustomDataIdentifierError, Credentials | HttpClient.HttpClient>;
export type GetFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the details of one or more findings.
 */
export declare const getFindings: API.OperationMethod<GetFindingsRequest & RegionInput, GetFindingsResponse, GetFindingsError, Credentials | HttpClient.HttpClient>;
export type GetFindingsFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the criteria and other settings for a findings filter.
 */
export declare const getFindingsFilter: API.OperationMethod<GetFindingsFilterRequest & RegionInput, GetFindingsFilterResponse, GetFindingsFilterError, Credentials | HttpClient.HttpClient>;
export type GetFindingsPublicationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the configuration settings for publishing findings to Security Hub.
 */
export declare const getFindingsPublicationConfiguration: API.OperationMethod<GetFindingsPublicationConfigurationRequest & RegionInput, GetFindingsPublicationConfigurationResponse, GetFindingsPublicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetFindingStatisticsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) aggregated statistical data about findings.
 */
export declare const getFindingStatistics: API.OperationMethod<GetFindingStatisticsRequest & RegionInput, GetFindingStatisticsResponse, GetFindingStatisticsError, Credentials | HttpClient.HttpClient>;
export type GetInvitationsCountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the count of Amazon Macie membership invitations that were received by an account.
 */
export declare const getInvitationsCount: API.OperationMethod<GetInvitationsCountRequest & RegionInput, GetInvitationsCountResponse, GetInvitationsCountError, Credentials | HttpClient.HttpClient>;
export type GetMacieSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status and configuration settings for an Amazon Macie account.
 */
export declare const getMacieSession: API.OperationMethod<GetMacieSessionRequest & RegionInput, GetMacieSessionResponse, GetMacieSessionError, Credentials | HttpClient.HttpClient>;
export type GetMasterAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * (Deprecated) Retrieves information about the Amazon Macie administrator account for an account. This operation has been replaced by the GetAdministratorAccount operation.
 */
export declare const getMasterAccount: API.OperationMethod<GetMasterAccountRequest & RegionInput, GetMasterAccountResponse, GetMasterAccountError, Credentials | HttpClient.HttpClient>;
export type GetMemberError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an account that's associated with an Amazon Macie administrator account.
 */
export declare const getMember: API.OperationMethod<GetMemberRequest & RegionInput, GetMemberResponse, GetMemberError, Credentials | HttpClient.HttpClient>;
export type GetResourceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) sensitive data discovery statistics and the sensitivity score for an S3 bucket.
 */
export declare const getResourceProfile: API.OperationMethod<GetResourceProfileRequest & RegionInput, GetResourceProfileResponse, GetResourceProfileError, Credentials | HttpClient.HttpClient>;
export type GetRevealConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status and configuration settings for retrieving occurrences of sensitive data reported by findings.
 */
export declare const getRevealConfiguration: API.OperationMethod<GetRevealConfigurationRequest & RegionInput, GetRevealConfigurationResponse, GetRevealConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetSensitiveDataOccurrencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | UnprocessableEntityException | CommonErrors;
/**
 * Retrieves occurrences of sensitive data reported by a finding.
 */
export declare const getSensitiveDataOccurrences: API.OperationMethod<GetSensitiveDataOccurrencesRequest & RegionInput, GetSensitiveDataOccurrencesResponse, GetSensitiveDataOccurrencesError, Credentials | HttpClient.HttpClient>;
export type GetSensitiveDataOccurrencesAvailabilityError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Checks whether occurrences of sensitive data can be retrieved for a finding.
 */
export declare const getSensitiveDataOccurrencesAvailability: API.OperationMethod<GetSensitiveDataOccurrencesAvailabilityRequest & RegionInput, GetSensitiveDataOccurrencesAvailabilityResponse, GetSensitiveDataOccurrencesAvailabilityError, Credentials | HttpClient.HttpClient>;
export type GetSensitivityInspectionTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the settings for the sensitivity inspection template for an account.
 */
export declare const getSensitivityInspectionTemplate: API.OperationMethod<GetSensitivityInspectionTemplateRequest & RegionInput, GetSensitivityInspectionTemplateResponse, GetSensitivityInspectionTemplateError, Credentials | HttpClient.HttpClient>;
export type GetUsageStatisticsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) quotas and aggregated usage data for one or more accounts.
 */
export declare const getUsageStatistics: API.PaginatedOperationMethod<GetUsageStatisticsRequest & RegionInput, GetUsageStatisticsResponse, GetUsageStatisticsError, Credentials | HttpClient.HttpClient, UsageRecord>;
export type GetUsageTotalsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) aggregated usage data for an account.
 */
export declare const getUsageTotals: API.OperationMethod<GetUsageTotalsRequest & RegionInput, GetUsageTotalsResponse, GetUsageTotalsError, Credentials | HttpClient.HttpClient>;
export type ListAllowListsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about all the allow lists for an account.
 */
export declare const listAllowLists: API.PaginatedOperationMethod<ListAllowListsRequest & RegionInput, ListAllowListsResponse, ListAllowListsError, Credentials | HttpClient.HttpClient, AllowListSummary>;
export type ListAutomatedDiscoveryAccountsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status of automated sensitive data discovery for one or more accounts.
 */
export declare const listAutomatedDiscoveryAccounts: API.PaginatedOperationMethod<ListAutomatedDiscoveryAccountsRequest & RegionInput, ListAutomatedDiscoveryAccountsResponse, ListAutomatedDiscoveryAccountsError, Credentials | HttpClient.HttpClient, AutomatedDiscoveryAccount>;
export type ListClassificationJobsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about one or more classification jobs.
 */
export declare const listClassificationJobs: API.PaginatedOperationMethod<ListClassificationJobsRequest & RegionInput, ListClassificationJobsResponse, ListClassificationJobsError, Credentials | HttpClient.HttpClient, JobSummary>;
export type ListClassificationScopesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about the classification scope for an account.
 */
export declare const listClassificationScopes: API.PaginatedOperationMethod<ListClassificationScopesRequest & RegionInput, ListClassificationScopesResponse, ListClassificationScopesError, Credentials | HttpClient.HttpClient, ClassificationScopeSummary>;
export type ListCustomDataIdentifiersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about the custom data identifiers for an account.
 */
export declare const listCustomDataIdentifiers: API.PaginatedOperationMethod<ListCustomDataIdentifiersRequest & RegionInput, ListCustomDataIdentifiersResponse, ListCustomDataIdentifiersError, Credentials | HttpClient.HttpClient, CustomDataIdentifierSummary>;
export type ListFindingsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about one or more findings.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest & RegionInput, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, string>;
export type ListFindingsFiltersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about all the findings filters for an account.
 */
export declare const listFindingsFilters: API.PaginatedOperationMethod<ListFindingsFiltersRequest & RegionInput, ListFindingsFiltersResponse, ListFindingsFiltersError, Credentials | HttpClient.HttpClient, FindingsFilterListItem>;
export type ListInvitationsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about Amazon Macie membership invitations that were received by an account.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest & RegionInput, ListInvitationsResponse, ListInvitationsError, Credentials | HttpClient.HttpClient, Invitation>;
export type ListManagedDataIdentifiersError = CommonErrors;
/**
 * Retrieves information about all the managed data identifiers that Amazon Macie currently provides.
 */
export declare const listManagedDataIdentifiers: API.PaginatedOperationMethod<ListManagedDataIdentifiersRequest & RegionInput, ListManagedDataIdentifiersResponse, ListManagedDataIdentifiersError, Credentials | HttpClient.HttpClient, ManagedDataIdentifierSummary>;
export type ListMembersError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the accounts that are associated with an Amazon Macie administrator account.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest & RegionInput, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListOrganizationAdminAccountsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the delegated Amazon Macie administrator account for an organization in Organizations.
 */
export declare const listOrganizationAdminAccounts: API.PaginatedOperationMethod<ListOrganizationAdminAccountsRequest & RegionInput, ListOrganizationAdminAccountsResponse, ListOrganizationAdminAccountsError, Credentials | HttpClient.HttpClient, AdminAccount>;
export type ListResourceProfileArtifactsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about objects that Amazon Macie selected from an S3 bucket for automated sensitive data discovery.
 */
export declare const listResourceProfileArtifacts: API.PaginatedOperationMethod<ListResourceProfileArtifactsRequest & RegionInput, ListResourceProfileArtifactsResponse, ListResourceProfileArtifactsError, Credentials | HttpClient.HttpClient, ResourceProfileArtifact>;
export type ListResourceProfileDetectionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the types and amount of sensitive data that Amazon Macie found in an S3 bucket.
 */
export declare const listResourceProfileDetections: API.PaginatedOperationMethod<ListResourceProfileDetectionsRequest & RegionInput, ListResourceProfileDetectionsResponse, ListResourceProfileDetectionsError, Credentials | HttpClient.HttpClient, Detection>;
export type ListSensitivityInspectionTemplatesError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a subset of information about the sensitivity inspection template for an account.
 */
export declare const listSensitivityInspectionTemplates: API.PaginatedOperationMethod<ListSensitivityInspectionTemplatesRequest & RegionInput, ListSensitivityInspectionTemplatesResponse, ListSensitivityInspectionTemplatesError, Credentials | HttpClient.HttpClient, SensitivityInspectionTemplatesEntry>;
export type ListTagsForResourceError = CommonErrors;
/**
 * Retrieves the tags (keys and values) that are associated with an Amazon Macie resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PutClassificationExportConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates the configuration settings for storing data classification results.
 */
export declare const putClassificationExportConfiguration: API.OperationMethod<PutClassificationExportConfigurationRequest & RegionInput, PutClassificationExportConfigurationResponse, PutClassificationExportConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutFindingsPublicationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configuration settings for publishing findings to Security Hub.
 */
export declare const putFindingsPublicationConfiguration: API.OperationMethod<PutFindingsPublicationConfigurationRequest & RegionInput, PutFindingsPublicationConfigurationResponse, PutFindingsPublicationConfigurationError, Credentials | HttpClient.HttpClient>;
export type SearchResourcesError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves (queries) statistical data and other information about Amazon Web Services resources that Amazon Macie monitors and analyzes for an account.
 */
export declare const searchResources: API.PaginatedOperationMethod<SearchResourcesRequest & RegionInput, SearchResourcesResponse, SearchResourcesError, Credentials | HttpClient.HttpClient, MatchingResource>;
export type TagResourceError = CommonErrors;
/**
 * Adds or updates one or more tags (keys and values) that are associated with an Amazon Macie resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestCustomDataIdentifierError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tests criteria for a custom data identifier.
 */
export declare const testCustomDataIdentifier: API.OperationMethod<TestCustomDataIdentifierRequest & RegionInput, TestCustomDataIdentifierResponse, TestCustomDataIdentifierError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = CommonErrors;
/**
 * Removes one or more tags (keys and values) from an Amazon Macie resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAllowListError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings for an allow list.
 */
export declare const updateAllowList: API.OperationMethod<UpdateAllowListRequest & RegionInput, UpdateAllowListResponse, UpdateAllowListError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomatedDiscoveryConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes the configuration settings and status of automated sensitive data discovery for an organization or standalone account.
 */
export declare const updateAutomatedDiscoveryConfiguration: API.OperationMethod<UpdateAutomatedDiscoveryConfigurationRequest & RegionInput, UpdateAutomatedDiscoveryConfigurationResponse, UpdateAutomatedDiscoveryConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateClassificationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes the status of a classification job.
 */
export declare const updateClassificationJob: API.OperationMethod<UpdateClassificationJobRequest & RegionInput, UpdateClassificationJobResponse, UpdateClassificationJobError, Credentials | HttpClient.HttpClient>;
export type UpdateClassificationScopeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the classification scope settings for an account.
 */
export declare const updateClassificationScope: API.OperationMethod<UpdateClassificationScopeRequest & RegionInput, UpdateClassificationScopeResponse, UpdateClassificationScopeError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsFilterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the criteria and other settings for a findings filter.
 */
export declare const updateFindingsFilter: API.OperationMethod<UpdateFindingsFilterRequest & RegionInput, UpdateFindingsFilterResponse, UpdateFindingsFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateMacieSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Suspends or re-enables Amazon Macie, or updates the configuration settings for a Macie account.
 */
export declare const updateMacieSession: API.OperationMethod<UpdateMacieSessionRequest & RegionInput, UpdateMacieSessionResponse, UpdateMacieSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateMemberSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables an Amazon Macie administrator to suspend or re-enable Macie for a member account.
 */
export declare const updateMemberSession: API.OperationMethod<UpdateMemberSessionRequest & RegionInput, UpdateMemberSessionResponse, UpdateMemberSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the Amazon Macie configuration settings for an organization in Organizations.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest & RegionInput, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceProfileError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the sensitivity score for an S3 bucket.
 */
export declare const updateResourceProfile: API.OperationMethod<UpdateResourceProfileRequest & RegionInput, UpdateResourceProfileResponse, UpdateResourceProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceProfileDetectionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the sensitivity scoring settings for an S3 bucket.
 */
export declare const updateResourceProfileDetections: API.OperationMethod<UpdateResourceProfileDetectionsRequest & RegionInput, UpdateResourceProfileDetectionsResponse, UpdateResourceProfileDetectionsError, Credentials | HttpClient.HttpClient>;
export type UpdateRevealConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status and configuration settings for retrieving occurrences of sensitive data reported by findings.
 */
export declare const updateRevealConfiguration: API.OperationMethod<UpdateRevealConfigurationRequest & RegionInput, UpdateRevealConfigurationResponse, UpdateRevealConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSensitivityInspectionTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the settings for the sensitivity inspection template for an account.
 */
export declare const updateSensitivityInspectionTemplate: API.OperationMethod<UpdateSensitivityInspectionTemplateRequest & RegionInput, UpdateSensitivityInspectionTemplateResponse, UpdateSensitivityInspectionTemplateError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=macie2.d.ts.map