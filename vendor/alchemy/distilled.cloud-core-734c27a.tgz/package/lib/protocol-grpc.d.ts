/**
 * gRPC (binary protobuf) protocol for proto-sourced SDKs.
 *
 * Proto SDKs are generated as REST-shaped operations: each RPC is
 * `POST /<package>.<Service>/<Method>` with a proto3 JSON body. Servers that
 * accept JSON (Connect, grpc-gateway) use {@link makeRestProtocol} directly.
 * Servers that only speak gRPC use this protocol, which builds the request
 * with the REST protocol and speaks gRPC on the wire:
 *
 * - **Request**: the proto3 JSON body is transcoded to one protobuf message
 *   ({@link encodeMessage}) in one gRPC frame, sent as `application/grpc`.
 * - **Transport**: the call goes through the `HttpClient` the
 *   `GrpcTransport` reference holds, or the caller's `HttpClient` when it
 *   holds none (see `@distilled.cloud/core/grpc-transport`). Plain `fetch`
 *   works where a proxy bridges HTTP/1.1 to gRPC (envoy).
 * - **gRPC-Web**: with `web: true` the request is sent as
 *   `application/grpc-web+proto`, which servers such as `tonic-web` answer
 *   over HTTP/1.1. The reply's trailers arrive as the last frame of its body,
 *   so plain `fetch` sees every status.
 * - **Status**: the call's `grpc-status` is read from the trailers, or from
 *   the headers of a trailers-only reply. A transport that can't see
 *   trailers (`fetch`) leaves only the headers; a reply with message frames
 *   and no status there is treated as OK.
 * - **Errors**: a non-zero status becomes the operation's typed error. The
 *   REST decoder receives `{ code, status, message }` (`{ code: 5, status:
 *   "NOT_FOUND", ... }`) with the HTTP status grpc-gateway maps the code to
 *   (`NOT_FOUND` -> 404, `UNAVAILABLE` -> 503, ...), so error matchers key on
 *   the numeric gRPC `code`, and categories and retries follow the HTTP
 *   status.
 * - **Response**: protobuf messages are transcoded back to proto3 JSON and
 *   decoded by the operation's output schema, so schemas, sensitive values
 *   and response validation behave exactly as for REST.
 *
 * A server-streaming method's output is `{ items: [message, ...] }`. Calling
 * the operation collects the whole stream; its `.stream(input)` (see
 * `API.makeStreaming`) emits each message as it arrives, and stopping the
 * stream cancels the call.
 *
 * {@link Deadline} bounds calls in its scope: it is sent as `grpc-timeout`
 * and enforced here, and a call that runs past it fails with
 * `DEADLINE_EXCEEDED` (code 4).
 */
import * as Context from "effect/Context";
import * as Duration from "effect/Duration";
import * as Layer from "effect/Layer";
import * as API from "./api.ts";
import { type ProtoDescriptors } from "./protobuf.ts";
import { type RestProtocolOptions } from "./protocol-rest.ts";
/** gRPC status code -> name. */
export declare const GRPC_STATUS_NAMES: Readonly<Record<number, string>>;
/** gRPC status code -> HTTP status (grpc-gateway's mapping). */
export declare const GRPC_HTTP_STATUS: Readonly<Record<number, number>>;
/**
 * The deadline of gRPC calls in its scope, from when each call starts.
 * `undefined` (the default) sets none.
 *
 * ```ts
 * router.taskExecWait(input).pipe(Effect.provideService(Deadline, "30 seconds"));
 * ```
 */
export declare const Deadline: Context.Reference<Duration.Input | undefined>;
export interface GrpcProtocolOptions<C> extends RestProtocolOptions<C> {
    /** The SDK's generated descriptors (`src/descriptors.ts`). */
    readonly descriptors: ProtoDescriptors;
    /**
     * The error for a non-zero status no typed error matched, from its gRPC
     * code. By default the REST decoder classifies it by the HTTP status the
     * code maps to (`UNAVAILABLE` -> `ServiceUnavailable`, which retries), which
     * keeps retries working but merges codes that share a status
     * (`INVALID_ARGUMENT`, `FAILED_PRECONDITION` and `OUT_OF_RANGE` are all
     * `BadRequest`).
     */
    readonly statusError?: (info: StatusInfo) => unknown;
    /**
     * Send gRPC-Web (`application/grpc-web+proto`) instead of gRPC, for a
     * server that answers HTTP/1.1 only that way (`tonic-web`). The reply
     * carries its trailers in its body, so `fetch` sees every status.
     */
    readonly web?: boolean;
}
/** A non-OK gRPC status, as `statusError` receives it. */
export interface StatusInfo {
    readonly code: number;
    readonly message: string;
    /** `google.rpc.Status.details` from `grpc-status-details-bin`, as proto3 JSON `Any`s. */
    readonly details: ReadonlyArray<unknown>;
    readonly headers: Readonly<Record<string, string>>;
}
/** gRPC's mapping of an HTTP status, for a reply that carries no gRPC status. */
export declare const HTTP_GRPC_STATUS: Readonly<Record<number, number>>;
/**
 * A gRPC protocol over the given REST protocol options. See the module
 * documentation for the wire behavior.
 */
export declare const makeGrpcProtocol: <C>(options: GrpcProtocolOptions<C>) => Layer.Layer<API.Protocol>;
//# sourceMappingURL=protocol-grpc.d.ts.map