import * as Layer from "effect/Layer";
export declare const TelemetryDebug: {
    /** Turns on debug spans and debug log lines for every distilled call it is provided to. */
    readonly layer: Layer.Layer<never>;
};
//# sourceMappingURL=telemetry-debug.d.ts.map