import type { IncomingMessage } from "node:http";
import { describe, expect, test } from "vitest";
import { proxyRequestHeaders, resolveForwardedHost } from "../forwarded-host.ts";

describe("resolveForwardedHost", () => {
  test("prefers the forwarded host over the immediate proxy host", () => {
    expect(
      resolveForwardedHost(
        { host: "localhost:5173", "x-forwarded-host": "example.ngrok.app" },
        "127.0.0.1:9999",
      ),
    ).toBe("example.ngrok.app");
  });

  test("uses the first forwarded host when a proxy chain appends to the header", () => {
    expect(
      resolveForwardedHost(
        {
          host: "localhost:5173",
          "x-forwarded-host": "example.ngrok.app, localhost:5173",
        },
        "127.0.0.1:9999",
      ),
    ).toBe("example.ngrok.app");
  });

  test("uses the first forwarded host when Node exposes repeated headers as an array", () => {
    expect(
      resolveForwardedHost(
        {
          host: "localhost:5173",
          "x-forwarded-host": ["example.ngrok.app", "localhost:5173"],
        },
        "127.0.0.1:9999",
      ),
    ).toBe("example.ngrok.app");
  });

  test("falls back to the request host or the provided fallback", () => {
    expect(resolveForwardedHost({ host: "localhost:5173" }, "127.0.0.1:9999")).toBe(
      "localhost:5173",
    );
    expect(resolveForwardedHost({}, "127.0.0.1:9999")).toBe("127.0.0.1:9999");
  });
});

describe("proxyRequestHeaders", () => {
  const proxySharedSecret = "server-instance-secret";
  test.each([
    [{ host: "localhost:5173" }, false, "http://localhost:5173"],
    [{ host: "localhost:5173" }, true, "https://localhost:5173"],
    [{ host: "localhost:80" }, true, "https://localhost:80"],
    [
      {
        host: "localhost:5173",
        "x-forwarded-host": "public.example, proxy.internal",
        "x-forwarded-proto": "https, http",
      },
      false,
      "https://public.example",
    ],
    [{ host: "localhost:5173", "x-forwarded-proto": "HTTPS" }, false, "https://localhost:5173"],
  ])("signs the original URL including protocol and port", (headers, encrypted, origin) => {
    const result = proxyRequestHeaders(
      {
        headers: {
          ...headers,
          "alchemy-runtime-original-url": "https://forged.example/",
          "alchemy-runtime-proxy-shared-secret": "forged",
        },
        socket: { encrypted, remoteAddress: "::ffff:192.0.2.1" },
      } as unknown as IncomingMessage,
      new URL("http://127.0.0.1:9999//callback/%2F?x=1&x=2"),
      proxySharedSecret,
    );
    expect(result["alchemy-runtime-original-url"]).toBe(`${origin}//callback/%2F?x=1&x=2`);
    expect(result.host).toBe(new URL(origin).host);
    expect(result["alchemy-runtime-proxy-shared-secret"]).toBe(proxySharedSecret);
    // A client's own `X-Forwarded-Host` passes through; otherwise it is the
    // dev server's host, as under `@cloudflare/vite-plugin`.
    expect(result["x-forwarded-host"]).toBe(
      "x-forwarded-host" in headers ? headers["x-forwarded-host"] : headers.host,
    );
    expect(result["cf-connecting-ip"]).toBe("192.0.2.1");
  });
});
