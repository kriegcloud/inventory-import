import * as Effect from "effect/Effect";
/**
 * Time this process's shutdown in the run log: a Debug record when SIGINT or
 * SIGTERM arrives, and one when `effect` has finished (finalizers included),
 * with the time since the signal. Silent when the process ends on its own.
 */
export declare const logShutdown: (name: string) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/** Run `effect` and log how long it took, as a step of a shutdown. */
export declare const timedShutdownStep: (step: string) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
//# sourceMappingURL=Shutdown.d.ts.map