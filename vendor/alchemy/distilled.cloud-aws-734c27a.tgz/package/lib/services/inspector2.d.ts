import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AccountId = string;
export interface AssociateMemberRequest {
    accountId: string;
}
export interface AssociateMemberResponse {
    accountId: string;
}
export type ScanConfigurationArn = string;
export type ProjectId = string;
export type CodeSecurityResource = {
    projectId: string;
};
export interface AssociateConfigurationRequest {
    scanConfigurationArn: string;
    resource: CodeSecurityResource;
}
export type AssociateConfigurationRequestList = AssociateConfigurationRequest[];
export interface BatchAssociateCodeSecurityScanConfigurationRequest {
    associateConfigurationRequests: AssociateConfigurationRequest[];
}
export type AssociationResultStatusCode = "INTERNAL_ERROR" | "ACCESS_DENIED" | "SCAN_CONFIGURATION_NOT_FOUND" | "INVALID_INPUT" | "RESOURCE_NOT_FOUND" | "QUOTA_EXCEEDED" | (string & {});
export type AssociationResultStatusMessage = string;
export interface FailedAssociationResult {
    scanConfigurationArn?: string | undefined;
    resource?: CodeSecurityResource | undefined;
    statusCode?: AssociationResultStatusCode | undefined;
    statusMessage?: string | undefined;
}
export type FailedAssociationResultList = FailedAssociationResult[];
export interface SuccessfulAssociationResult {
    scanConfigurationArn?: string | undefined;
    resource?: CodeSecurityResource | undefined;
}
export type SuccessfulAssociationResultList = SuccessfulAssociationResult[];
export interface BatchAssociateCodeSecurityScanConfigurationResponse {
    failedAssociations?: FailedAssociationResult[] | undefined;
    successfulAssociations?: SuccessfulAssociationResult[] | undefined;
}
export interface DisassociateConfigurationRequest {
    scanConfigurationArn: string;
    resource: CodeSecurityResource;
}
export type DisassociateConfigurationRequestList = DisassociateConfigurationRequest[];
export interface BatchDisassociateCodeSecurityScanConfigurationRequest {
    disassociateConfigurationRequests: DisassociateConfigurationRequest[];
}
export interface BatchDisassociateCodeSecurityScanConfigurationResponse {
    failedAssociations?: FailedAssociationResult[] | undefined;
    successfulAssociations?: SuccessfulAssociationResult[] | undefined;
}
export type AccountIdSet = string[];
export interface BatchGetAccountStatusRequest {
    accountIds?: string[] | undefined;
}
export type Status = string;
export type ErrorCode = string;
export type NonEmptyString = string;
export interface State {
    status: string;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
}
export interface ResourceState {
    ec2: State;
    ecr: State;
    lambda?: State | undefined;
    lambdaCode?: State | undefined;
    codeRepository?: State | undefined;
    ami?: State | undefined;
}
export interface AccountState {
    accountId: string;
    state: State;
    resourceState: ResourceState;
}
export type AccountStateList = AccountState[];
export interface ResourceStatus {
    ec2?: string | undefined;
    ecr?: string | undefined;
    lambda?: string | undefined;
    lambdaCode?: string | undefined;
    codeRepository?: string | undefined;
    ami?: string | undefined;
}
export interface FailedAccount {
    accountId: string;
    status?: string | undefined;
    resourceStatus?: ResourceStatus | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
}
export type FailedAccountList = FailedAccount[];
export interface BatchGetAccountStatusResponse {
    accounts: AccountState[];
    failedAccounts?: FailedAccount[] | undefined;
}
export type FindingArn = string;
export type FindingArns = string[];
export interface BatchGetCodeSnippetRequest {
    findingArns: string[];
}
export interface CodeLine {
    content: string;
    lineNumber: number;
}
export type CodeLineList = CodeLine[];
export interface SuggestedFix {
    description?: string | undefined;
    code?: string | undefined;
}
export type SuggestedFixes = SuggestedFix[];
export interface CodeSnippetResult {
    findingArn?: string | undefined;
    startLine?: number | undefined;
    endLine?: number | undefined;
    codeSnippet?: CodeLine[] | undefined;
    suggestedFixes?: SuggestedFix[] | undefined;
}
export type CodeSnippetResultList = CodeSnippetResult[];
export type CodeSnippetErrorCode = string;
export interface CodeSnippetError {
    findingArn: string;
    errorCode: string;
    errorMessage: string;
}
export type CodeSnippetErrorList = CodeSnippetError[];
export interface BatchGetCodeSnippetResponse {
    codeSnippetResults?: CodeSnippetResult[] | undefined;
    errors?: CodeSnippetError[] | undefined;
}
export type FindingArnList = string[];
export interface BatchGetFindingDetailsRequest {
    findingArns: string[];
}
export type CisaDateAdded = Date;
export type CisaDateDue = Date;
export type CisaAction = string;
export interface CisaData {
    dateAdded?: Date | undefined;
    dateDue?: Date | undefined;
    action?: string | undefined;
}
export type RiskScore = number;
export type EvidenceRule = string;
export type EvidenceDetail = string;
export type EvidenceSeverity = string;
export interface Evidence {
    evidenceRule?: string | undefined;
    evidenceDetail?: string | undefined;
    severity?: string | undefined;
}
export type EvidenceList = Evidence[];
export type Ttp = string;
export type Ttps = string[];
export type Tool = string;
export type Tools = string[];
export type LastSeen = Date;
export type FirstSeen = Date;
export interface ExploitObserved {
    lastSeen?: Date | undefined;
    firstSeen?: Date | undefined;
}
export type VulnerabilityReferenceUrl = string;
export type VulnerabilityReferenceUrls = string[];
export type Cwe = string;
export type Cwes = string[];
export interface FindingDetail {
    findingArn?: string | undefined;
    cisaData?: CisaData | undefined;
    riskScore?: number | undefined;
    evidences?: Evidence[] | undefined;
    ttps?: string[] | undefined;
    tools?: string[] | undefined;
    exploitObserved?: ExploitObserved | undefined;
    referenceUrls?: string[] | undefined;
    cwes?: string[] | undefined;
    epssScore?: number | undefined;
}
export type FindingDetails = FindingDetail[];
export type FindingDetailsErrorCode = string;
export interface FindingDetailsError {
    findingArn: string;
    errorCode: string;
    errorMessage: string;
}
export type FindingDetailsErrorList = FindingDetailsError[];
export interface BatchGetFindingDetailsResponse {
    findingDetails?: FindingDetail[] | undefined;
    errors?: FindingDetailsError[] | undefined;
}
export type MeteringAccountId = string;
export type MeteringAccountIdList = string[];
export interface BatchGetFreeTrialInfoRequest {
    accountIds: string[];
}
export type FreeTrialType = string;
export type FreeTrialStatus = string;
export type CloudProvider = string;
export interface FreeTrialInfo {
    type: string;
    start: Date;
    end: Date;
    status: string;
    cloudProvider?: string | undefined;
}
export type FreeTrialInfoList = FreeTrialInfo[];
export interface FreeTrialAccountInfo {
    accountId: string;
    freeTrialInfo: FreeTrialInfo[];
}
export type FreeTrialAccountInfoList = FreeTrialAccountInfo[];
export type FreeTrialInfoErrorCode = string;
export interface FreeTrialInfoError {
    accountId: string;
    code: string;
    message: string;
}
export type FreeTrialInfoErrorList = FreeTrialInfoError[];
export interface BatchGetFreeTrialInfoResponse {
    accounts: FreeTrialAccountInfo[];
    failedAccounts: FreeTrialInfoError[];
}
export interface BatchGetMemberEc2DeepInspectionStatusRequest {
    accountIds?: string[] | undefined;
}
export type Ec2DeepInspectionStatus = string;
export interface MemberAccountEc2DeepInspectionStatusState {
    accountId: string;
    status?: string | undefined;
    errorMessage?: string | undefined;
}
export type MemberAccountEc2DeepInspectionStatusStateList = MemberAccountEc2DeepInspectionStatusState[];
export interface FailedMemberAccountEc2DeepInspectionStatusState {
    accountId: string;
    ec2ScanStatus?: string | undefined;
    errorMessage?: string | undefined;
}
export type FailedMemberAccountEc2DeepInspectionStatusStateList = FailedMemberAccountEc2DeepInspectionStatusState[];
export interface BatchGetMemberEc2DeepInspectionStatusResponse {
    accountIds?: MemberAccountEc2DeepInspectionStatusState[] | undefined;
    failedAccountIds?: FailedMemberAccountEc2DeepInspectionStatusState[] | undefined;
}
export interface MemberAccountEc2DeepInspectionStatus {
    accountId: string;
    activateDeepInspection: boolean;
}
export type MemberAccountEc2DeepInspectionStatusList = MemberAccountEc2DeepInspectionStatus[];
export interface BatchUpdateMemberEc2DeepInspectionStatusRequest {
    accountIds: MemberAccountEc2DeepInspectionStatus[];
}
export interface BatchUpdateMemberEc2DeepInspectionStatusResponse {
    accountIds?: MemberAccountEc2DeepInspectionStatusState[] | undefined;
    failedAccountIds?: FailedMemberAccountEc2DeepInspectionStatusState[] | undefined;
}
export type ReportId = string;
export interface CancelFindingsReportRequest {
    reportId: string;
}
export interface CancelFindingsReportResponse {
    reportId: string;
}
export interface CancelSbomExportRequest {
    reportId: string;
}
export interface CancelSbomExportResponse {
    reportId?: string | undefined;
}
export type CisScanName = string;
export type CisSecurityLevel = "LEVEL_1" | "LEVEL_2" | (string & {});
export interface OneTimeSchedule {
}
export type TimeOfDay = string;
export type Timezone = string;
export interface Time {
    timeOfDay: string;
    timezone: string;
}
export interface DailySchedule {
    startTime: Time;
}
export type Day = "SUN" | "MON" | "TUE" | "WED" | "THU" | "FRI" | "SAT" | (string & {});
export type DaysList = Day[];
export interface WeeklySchedule {
    startTime: Time;
    days: Day[];
}
export interface MonthlySchedule {
    startTime: Time;
    day: Day;
}
export type Schedule = {
    oneTime: OneTimeSchedule;
    daily?: undefined;
    weekly?: undefined;
    monthly?: undefined;
} | {
    oneTime?: undefined;
    daily: DailySchedule;
    weekly?: undefined;
    monthly?: undefined;
} | {
    oneTime?: undefined;
    daily?: undefined;
    weekly: WeeklySchedule;
    monthly?: undefined;
} | {
    oneTime?: undefined;
    daily?: undefined;
    weekly?: undefined;
    monthly: MonthlySchedule;
};
export type TargetAccount = string;
export type TargetAccountList = string[];
export type TargetResourceTagsKey = string;
export type TargetResourceTagsValue = string;
export type TagValueList = string[];
export type TargetResourceTags = {
    [key: string]: string[] | undefined;
};
export interface CreateCisTargets {
    accountIds: string[];
    targetResourceTags: {
        [key: string]: string[] | undefined;
    };
}
export type MapKey = string;
export type MapValue = string;
export type CisTagMap = {
    [key: string]: string | undefined;
};
export interface CreateCisScanConfigurationRequest {
    scanName: string;
    securityLevel: CisSecurityLevel;
    schedule: Schedule;
    targets: CreateCisTargets;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CisScanConfigurationArn = string;
export interface CreateCisScanConfigurationResponse {
    scanConfigurationArn?: string | undefined;
}
export type IntegrationName = string;
export type IntegrationType = "GITLAB_SELF_MANAGED" | "GITHUB" | (string & {});
export type InstanceUrl = string | redacted.Redacted<string>;
export type GitLabAccessToken = string | redacted.Redacted<string>;
export interface CreateGitLabSelfManagedIntegrationDetail {
    instanceUrl: string | redacted.Redacted<string>;
    accessToken: string | redacted.Redacted<string>;
}
export type CreateIntegrationDetail = {
    gitlabSelfManaged: CreateGitLabSelfManagedIntegrationDetail;
};
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCodeSecurityIntegrationRequest {
    name: string;
    type: IntegrationType;
    details?: CreateIntegrationDetail | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CodeSecurityIntegrationArn = string;
export type IntegrationStatus = "PENDING" | "IN_PROGRESS" | "ACTIVE" | "INACTIVE" | "DISABLING" | (string & {});
export type AuthorizationUrl = string | redacted.Redacted<string>;
export interface CreateCodeSecurityIntegrationResponse {
    integrationArn: string;
    status: IntegrationStatus;
    authorizationUrl?: string | redacted.Redacted<string> | undefined;
}
export type ScanConfigurationName = string;
export type ConfigurationLevel = "ORGANIZATION" | "ACCOUNT" | (string & {});
export type PeriodicScanFrequency = "WEEKLY" | "MONTHLY" | "NEVER" | (string & {});
export type FrequencyExpression = string;
export interface PeriodicScanConfiguration {
    frequency?: PeriodicScanFrequency | undefined;
    frequencyExpression?: string | undefined;
}
export type ContinuousIntegrationScanEvent = "PULL_REQUEST" | "PUSH" | (string & {});
export type ContinuousIntegrationScanSupportedEvents = ContinuousIntegrationScanEvent[];
export interface ContinuousIntegrationScanConfiguration {
    supportedEvents: ContinuousIntegrationScanEvent[];
}
export type RuleSetCategory = "SAST" | "IAC" | "SCA" | (string & {});
export type RuleSetCategories = RuleSetCategory[];
export interface CodeSecurityScanConfiguration {
    periodicScanConfiguration?: PeriodicScanConfiguration | undefined;
    continuousIntegrationScanConfiguration?: ContinuousIntegrationScanConfiguration | undefined;
    ruleSetCategories: RuleSetCategory[];
}
export type ProjectSelectionScope = "ALL" | (string & {});
export interface ScopeSettings {
    projectSelectionScope?: ProjectSelectionScope | undefined;
}
export interface CreateCodeSecurityScanConfigurationRequest {
    name: string;
    level: ConfigurationLevel;
    configuration: CodeSecurityScanConfiguration;
    scopeSettings?: ScopeSettings | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateCodeSecurityScanConfigurationResponse {
    scanConfigurationArn: string;
}
export type ConnectorName = string;
export type ConnectorCloudProvider = "AZURE" | (string & {});
export type ConnectorDescription = string;
export type AwsConfigConnectorArn = string;
export type ScopeType = "TENANT" | "SUBSCRIPTION" | (string & {});
export type ScopeValue = string;
export type ScopeValueList = string[];
export interface ScopeConfigurationInput {
    scopeType: ScopeType;
    scopeValues?: string[] | undefined;
}
export interface AzureScopeConfigurationInput {
    vmScanning?: ScopeConfigurationInput | undefined;
    containerImageScanning?: ScopeConfigurationInput | undefined;
    serverlessScanning?: ScopeConfigurationInput | undefined;
}
export type AzureRegion = string;
export type AzureRegionList = string[];
export interface AzureProviderDetailCreate {
    awsConfigConnectorArn: string;
    scopeConfiguration: AzureScopeConfigurationInput;
    azureRegions: string[];
    autoInstallVMScanner?: boolean | undefined;
}
export type ProviderDetailCreate = {
    azure: AzureProviderDetailCreate;
};
export type ConnectorTagKey = string;
export type ConnectorTagValue = string;
export type ConnectorTagMap = {
    [key: string]: string | undefined;
};
export interface CreateConnectorRequest {
    clientToken?: string | undefined;
    name: string;
    provider: ConnectorCloudProvider;
    description?: string | undefined;
    providerDetail: ProviderDetailCreate;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConnectorArn = string;
export interface CreateConnectorResponse {
    connectorArn: string;
}
export type FilterAction = string;
export type FilterDescription = string;
export type StringComparison = string;
export type StringInput = string;
export interface StringFilter {
    comparison: string;
    value: string;
}
export type StringFilterList = StringFilter[];
export interface DateFilter {
    startInclusive?: Date | undefined;
    endInclusive?: Date | undefined;
}
export type DateFilterList = DateFilter[];
export interface NumberFilter {
    upperInclusive?: number | undefined;
    lowerInclusive?: number | undefined;
}
export type NumberFilterList = NumberFilter[];
export type MapComparison = string;
export interface MapFilter {
    comparison: string;
    key: string;
    value?: string | undefined;
}
export type MapFilterList = MapFilter[];
export type Port = number;
export interface PortRangeFilter {
    beginInclusive?: number | undefined;
    endInclusive?: number | undefined;
}
export type PortRangeFilterList = PortRangeFilter[];
export interface PackageFilter {
    name?: StringFilter | undefined;
    version?: StringFilter | undefined;
    epoch?: NumberFilter | undefined;
    release?: StringFilter | undefined;
    architecture?: StringFilter | undefined;
    sourceLayerHash?: StringFilter | undefined;
    sourceLambdaLayerArn?: StringFilter | undefined;
    filePath?: StringFilter | undefined;
}
export type PackageFilterList = PackageFilter[];
export interface FilterCriteria {
    findingArn?: StringFilter[] | undefined;
    awsAccountId?: StringFilter[] | undefined;
    findingType?: StringFilter[] | undefined;
    severity?: StringFilter[] | undefined;
    firstObservedAt?: DateFilter[] | undefined;
    lastObservedAt?: DateFilter[] | undefined;
    updatedAt?: DateFilter[] | undefined;
    findingStatus?: StringFilter[] | undefined;
    title?: StringFilter[] | undefined;
    inspectorScore?: NumberFilter[] | undefined;
    resourceType?: StringFilter[] | undefined;
    resourceId?: StringFilter[] | undefined;
    resourceTags?: MapFilter[] | undefined;
    ec2InstanceImageId?: StringFilter[] | undefined;
    ec2InstanceVpcId?: StringFilter[] | undefined;
    ec2InstanceSubnetId?: StringFilter[] | undefined;
    ecrImagePushedAt?: DateFilter[] | undefined;
    ecrImageArchitecture?: StringFilter[] | undefined;
    ecrImageRegistry?: StringFilter[] | undefined;
    ecrImageRepositoryName?: StringFilter[] | undefined;
    ecrImageTags?: StringFilter[] | undefined;
    ecrImageHash?: StringFilter[] | undefined;
    ecrImageLastInUseAt?: DateFilter[] | undefined;
    ecrImageInUseCount?: NumberFilter[] | undefined;
    portRange?: PortRangeFilter[] | undefined;
    networkProtocol?: StringFilter[] | undefined;
    componentId?: StringFilter[] | undefined;
    componentType?: StringFilter[] | undefined;
    vulnerabilityId?: StringFilter[] | undefined;
    vulnerabilitySource?: StringFilter[] | undefined;
    vendorSeverity?: StringFilter[] | undefined;
    vulnerablePackages?: PackageFilter[] | undefined;
    relatedVulnerabilities?: StringFilter[] | undefined;
    fixAvailable?: StringFilter[] | undefined;
    lambdaFunctionName?: StringFilter[] | undefined;
    lambdaFunctionLayers?: StringFilter[] | undefined;
    lambdaFunctionRuntime?: StringFilter[] | undefined;
    lambdaFunctionLastModifiedAt?: DateFilter[] | undefined;
    lambdaFunctionExecutionRoleArn?: StringFilter[] | undefined;
    exploitAvailable?: StringFilter[] | undefined;
    codeVulnerabilityDetectorName?: StringFilter[] | undefined;
    codeVulnerabilityDetectorTags?: StringFilter[] | undefined;
    codeVulnerabilityFilePath?: StringFilter[] | undefined;
    epssScore?: NumberFilter[] | undefined;
    codeRepositoryProjectName?: StringFilter[] | undefined;
    codeRepositoryProviderType?: StringFilter[] | undefined;
    machineImageId?: StringFilter[] | undefined;
    machineImageName?: StringFilter[] | undefined;
    machineImageOwnerAccountId?: StringFilter[] | undefined;
    machineImagePlatform?: StringFilter[] | undefined;
    cloudProvider?: StringFilter[] | undefined;
    cloudProviderRegion?: StringFilter[] | undefined;
    cloudProviderAccountId?: StringFilter[] | undefined;
    cloudProviderOrgId?: StringFilter[] | undefined;
    cloudVmImageReference?: StringFilter[] | undefined;
    cloudVmNetworkId?: StringFilter[] | undefined;
    cloudVmSubnetIds?: StringFilter[] | undefined;
    cloudImageRepositoryName?: StringFilter[] | undefined;
    cloudImageRegistry?: StringFilter[] | undefined;
    cloudImageDigest?: StringFilter[] | undefined;
    cloudImageTags?: StringFilter[] | undefined;
    cloudImagePushedAt?: DateFilter[] | undefined;
    cloudImageArchitecture?: StringFilter[] | undefined;
    cloudImageLastInUseAt?: DateFilter[] | undefined;
    cloudImageInUseCount?: NumberFilter[] | undefined;
    cloudServerlessFunctionName?: StringFilter[] | undefined;
    cloudServerlessFunctionRuntime?: StringFilter[] | undefined;
    cloudServerlessFunctionLastModifiedAt?: DateFilter[] | undefined;
    cloudServerlessFunctionExecutionRole?: StringFilter[] | undefined;
}
export type FilterName = string;
export type FilterReason = string;
export interface CreateFilterRequest {
    action: string;
    description?: string | undefined;
    filterCriteria: FilterCriteria;
    name: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    reason?: string | undefined;
}
export type FilterArn = string;
export interface CreateFilterResponse {
    arn: string;
}
export type ReportFormat = string;
export interface Destination {
    bucketName: string;
    keyPrefix?: string | undefined;
    kmsKeyArn: string;
    expectedBucketOwner?: string | undefined;
}
export interface CreateFindingsReportRequest {
    filterCriteria?: FilterCriteria | undefined;
    reportFormat: string;
    s3Destination: Destination;
}
export interface CreateFindingsReportResponse {
    reportId?: string | undefined;
}
export type ResourceStringComparison = string;
export type ResourceStringInput = string;
export interface ResourceStringFilter {
    comparison: string;
    value: string;
}
export type ResourceStringFilterList = ResourceStringFilter[];
export type ResourceMapComparison = string;
export interface ResourceMapFilter {
    comparison: string;
    key: string;
    value?: string | undefined;
}
export type ResourceMapFilterList = ResourceMapFilter[];
export interface ResourceFilterCriteria {
    accountId?: ResourceStringFilter[] | undefined;
    resourceId?: ResourceStringFilter[] | undefined;
    resourceType?: ResourceStringFilter[] | undefined;
    ecrRepositoryName?: ResourceStringFilter[] | undefined;
    lambdaFunctionName?: ResourceStringFilter[] | undefined;
    ecrImageTags?: ResourceStringFilter[] | undefined;
    ec2InstanceTags?: ResourceMapFilter[] | undefined;
    lambdaFunctionTags?: ResourceMapFilter[] | undefined;
    cloudProvider?: ResourceStringFilter[] | undefined;
    cloudProviderAccountId?: ResourceStringFilter[] | undefined;
    cloudProviderOrgId?: ResourceStringFilter[] | undefined;
    cloudProviderRegion?: ResourceStringFilter[] | undefined;
    cloudVmInstanceTags?: ResourceMapFilter[] | undefined;
    cloudContainerImageTags?: ResourceStringFilter[] | undefined;
    cloudContainerRepositoryName?: ResourceStringFilter[] | undefined;
    cloudContainerRegistryName?: ResourceStringFilter[] | undefined;
    cloudServerlessFunctionName?: ResourceStringFilter[] | undefined;
    cloudServerlessFunctionRuntime?: ResourceStringFilter[] | undefined;
    cloudServerlessFunctionTags?: ResourceMapFilter[] | undefined;
}
export type SbomReportFormat = string;
export interface CreateSbomExportRequest {
    resourceFilterCriteria?: ResourceFilterCriteria | undefined;
    reportFormat: string;
    s3Destination: Destination;
}
export interface CreateSbomExportResponse {
    reportId?: string | undefined;
}
export interface DeleteCisScanConfigurationRequest {
    scanConfigurationArn: string;
}
export interface DeleteCisScanConfigurationResponse {
    scanConfigurationArn: string;
}
export interface DeleteCodeSecurityIntegrationRequest {
    integrationArn: string;
}
export interface DeleteCodeSecurityIntegrationResponse {
    integrationArn?: string | undefined;
}
export interface DeleteCodeSecurityScanConfigurationRequest {
    scanConfigurationArn: string;
}
export interface DeleteCodeSecurityScanConfigurationResponse {
    scanConfigurationArn?: string | undefined;
}
export interface DeleteConnectorRequest {
    connectorArn: string;
}
export interface DeleteConnectorResponse {
}
export interface DeleteFilterRequest {
    arn: string;
}
export interface DeleteFilterResponse {
    arn: string;
}
export interface DescribeOrganizationConfigurationRequest {
}
export interface AutoEnable {
    ec2: boolean;
    ecr: boolean;
    lambda?: boolean | undefined;
    lambdaCode?: boolean | undefined;
    codeRepository?: boolean | undefined;
    ami?: boolean | undefined;
}
export interface DescribeOrganizationConfigurationResponse {
    autoEnable?: AutoEnable | undefined;
    maxAccountLimitReached?: boolean | undefined;
}
export type ResourceScanType = string;
export type DisableResourceTypeList = string[];
export interface DisableRequest {
    accountIds?: string[] | undefined;
    resourceTypes?: string[] | undefined;
}
export interface Account {
    accountId: string;
    status: string;
    resourceStatus: ResourceStatus;
}
export type AccountList = Account[];
export interface DisableResponse {
    accounts: Account[];
    failedAccounts?: FailedAccount[] | undefined;
}
export interface DisableDelegatedAdminAccountRequest {
    delegatedAdminAccountId: string;
}
export interface DisableDelegatedAdminAccountResponse {
    delegatedAdminAccountId: string;
}
export interface DisassociateMemberRequest {
    accountId: string;
}
export interface DisassociateMemberResponse {
    accountId: string;
}
export type EnableResourceTypeList = string[];
export type ClientToken = string;
export interface EnableRequest {
    accountIds?: string[] | undefined;
    resourceTypes: string[];
    clientToken?: string | undefined;
}
export interface EnableResponse {
    accounts: Account[];
    failedAccounts?: FailedAccount[] | undefined;
}
export interface EnableDelegatedAdminAccountRequest {
    delegatedAdminAccountId: string;
    clientToken?: string | undefined;
}
export interface EnableDelegatedAdminAccountResponse {
    delegatedAdminAccountId: string;
}
export type CisScanArn = string;
export type ReportTargetAccounts = string[];
export type CisReportFormat = "PDF" | "CSV" | (string & {});
export interface GetCisScanReportRequest {
    scanArn: string;
    targetAccounts?: string[] | undefined;
    reportFormat?: CisReportFormat | undefined;
}
export type CisReportStatus = "SUCCEEDED" | "FAILED" | "IN_PROGRESS" | (string & {});
export interface GetCisScanReportResponse {
    url?: string | undefined;
    status?: CisReportStatus | undefined;
}
export type ResourceId = string;
export type CisFindingStatusComparison = "EQUALS" | (string & {});
export type CisFindingStatus = "PASSED" | "FAILED" | "SKIPPED" | (string & {});
export interface CisFindingStatusFilter {
    comparison: CisFindingStatusComparison;
    value: CisFindingStatus;
}
export type CisFindingStatusFilterList = CisFindingStatusFilter[];
export type CisStringComparison = "EQUALS" | "PREFIX" | "NOT_EQUALS" | (string & {});
export interface CisStringFilter {
    comparison: CisStringComparison;
    value: string;
}
export type CheckIdFilterList = CisStringFilter[];
export type TitleFilterList = CisStringFilter[];
export type CisSecurityLevelComparison = "EQUALS" | (string & {});
export interface CisSecurityLevelFilter {
    comparison: CisSecurityLevelComparison;
    value: CisSecurityLevel;
}
export type CisSecurityLevelFilterList = CisSecurityLevelFilter[];
export type CisFindingArnFilterList = CisStringFilter[];
export interface CisScanResultDetailsFilterCriteria {
    findingStatusFilters?: CisFindingStatusFilter[] | undefined;
    checkIdFilters?: CisStringFilter[] | undefined;
    titleFilters?: CisStringFilter[] | undefined;
    securityLevelFilters?: CisSecurityLevelFilter[] | undefined;
    findingArnFilters?: CisStringFilter[] | undefined;
}
export type CisScanResultDetailsSortBy = "CHECK_ID" | "STATUS" | (string & {});
export type CisSortOrder = "ASC" | "DESC" | (string & {});
export type NextToken = string;
export type GetCisScanResultDetailsMaxResults = number;
export interface GetCisScanResultDetailsRequest {
    scanArn: string;
    targetResourceId: string;
    accountId: string;
    filterCriteria?: CisScanResultDetailsFilterCriteria | undefined;
    sortBy?: CisScanResultDetailsSortBy | undefined;
    sortOrder?: CisSortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type CisFindingArn = string;
export interface CisScanResultDetails {
    scanArn: string;
    accountId?: string | undefined;
    targetResourceId?: string | undefined;
    platform?: string | undefined;
    status?: CisFindingStatus | undefined;
    statusReason?: string | undefined;
    checkId?: string | undefined;
    title?: string | undefined;
    checkDescription?: string | undefined;
    remediation?: string | undefined;
    level?: CisSecurityLevel | undefined;
    findingArn?: string | undefined;
}
export type CisScanResultDetailsList = CisScanResultDetails[];
export interface GetCisScanResultDetailsResponse {
    scanResultDetails?: CisScanResultDetails[] | undefined;
    nextToken?: string | undefined;
}
export interface ClusterForImageFilterCriteria {
    resourceId: string;
}
export type GetClustersForImageNextToken = string;
export interface GetClustersForImageRequest {
    filter: ClusterForImageFilterCriteria;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AwsEcsMetadataDetails {
    detailsGroup: string;
    taskDefinitionArn: string;
}
export interface AwsEksWorkloadInfo {
    name: string;
    type: string;
}
export type AwsEksWorkloadInfoList = AwsEksWorkloadInfo[];
export interface AwsEksMetadataDetails {
    namespace?: string | undefined;
    workloadInfoList?: AwsEksWorkloadInfo[] | undefined;
}
export type ClusterMetadata = {
    awsEcsMetadataDetails: AwsEcsMetadataDetails;
    awsEksMetadataDetails?: undefined;
} | {
    awsEcsMetadataDetails?: undefined;
    awsEksMetadataDetails: AwsEksMetadataDetails;
};
export interface ClusterDetails {
    lastInUse: Date;
    runningUnitCount?: number | undefined;
    stoppedUnitCount?: number | undefined;
    clusterMetadata: ClusterMetadata;
}
export type ClusterDetailsList = ClusterDetails[];
export interface ClusterInformation {
    clusterArn: string;
    clusterDetails?: ClusterDetails[] | undefined;
}
export type ClusterInformationList = ClusterInformation[];
export interface GetClustersForImageResponse {
    cluster: ClusterInformation[];
    nextToken?: string | undefined;
}
export interface GetCodeSecurityIntegrationRequest {
    integrationArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetCodeSecurityIntegrationResponse {
    integrationArn: string;
    name: string;
    type: IntegrationType;
    status: IntegrationStatus;
    statusReason: string;
    createdOn: Date;
    lastUpdateOn: Date;
    authorizationUrl?: string | redacted.Redacted<string> | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CodeSecurityUuid = string;
export interface GetCodeSecurityScanRequest {
    resource: CodeSecurityResource;
    scanId: string;
}
export type CodeScanStatus = "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | "SKIPPED" | (string & {});
export interface GetCodeSecurityScanResponse {
    scanId?: string | undefined;
    resource?: CodeSecurityResource | undefined;
    accountId?: string | undefined;
    status?: CodeScanStatus | undefined;
    statusReason?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    lastCommitId?: string | undefined;
}
export interface GetCodeSecurityScanConfigurationRequest {
    scanConfigurationArn: string;
}
export interface GetCodeSecurityScanConfigurationResponse {
    scanConfigurationArn?: string | undefined;
    name?: string | undefined;
    configuration?: CodeSecurityScanConfiguration | undefined;
    level?: ConfigurationLevel | undefined;
    scopeSettings?: ScopeSettings | undefined;
    createdAt?: Date | undefined;
    lastUpdatedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetConfigurationRequest {
    accountId?: string | undefined;
}
export type EcrRescanDuration = string;
export type EcrRescanDurationStatus = string;
export type DateTimeTimestamp = Date;
export type EcrPullDateRescanDuration = string;
export type EcrPullDateRescanMode = string;
export interface EcrRescanDurationState {
    rescanDuration?: string | undefined;
    status?: string | undefined;
    updatedAt?: Date | undefined;
    pullDateRescanDuration?: string | undefined;
    pullDateRescanMode?: string | undefined;
}
export interface EcrConfigurationState {
    rescanDurationState?: EcrRescanDurationState | undefined;
}
export type Ec2ScanMode = string;
export type Ec2ScanModeStatus = string;
export interface Ec2ScanModeState {
    scanMode?: string | undefined;
    scanModeStatus?: string | undefined;
}
export type VMScannerStatus = string;
export interface VMScannerState {
    activated?: boolean | undefined;
    activatedAt?: Date | undefined;
    status?: string | undefined;
}
export interface Ec2ConfigurationState {
    scanModeState?: Ec2ScanModeState | undefined;
    vmScannerState?: VMScannerState | undefined;
}
export type AmiScanDuration = string;
export type AmiScanMode = string;
export type AmiTagKey = string;
export type AmiTagValue = string;
export interface AmiTagFilter {
    key: string;
    value?: string | undefined;
}
export type AmiTagFilterList = AmiTagFilter[];
export interface AmiScanModeConfiguration {
    scanMode: string;
    tags?: AmiTagFilter[] | undefined;
    excludeCopiedAmis?: boolean | undefined;
    excludeBackupDlmAmis?: boolean | undefined;
}
export type AmiConfigurationStatus = string;
export interface AmiConfigurationState {
    lastLaunchedWithin?: string | undefined;
    createdWithin?: string | undefined;
    scanModeConfiguration?: AmiScanModeConfiguration | undefined;
    status?: string | undefined;
    updatedAt?: Date | undefined;
}
export interface GetConfigurationResponse {
    ecrConfiguration?: EcrConfigurationState | undefined;
    ec2Configuration?: Ec2ConfigurationState | undefined;
    amiConfiguration?: AmiConfigurationState | undefined;
}
export interface GetDelegatedAdminAccountRequest {
}
export type RelationshipStatus = string;
export interface DelegatedAdmin {
    accountId?: string | undefined;
    relationshipStatus?: string | undefined;
}
export interface GetDelegatedAdminAccountResponse {
    delegatedAdmin?: DelegatedAdmin | undefined;
}
export interface GetEc2DeepInspectionConfigurationRequest {
}
export type Path = string;
export type PathList = string[];
export interface GetEc2DeepInspectionConfigurationResponse {
    packagePaths?: string[] | undefined;
    orgPackagePaths?: string[] | undefined;
    status?: string | undefined;
    errorMessage?: string | undefined;
}
export type ScanType = string;
export type ResourceType = string;
export interface GetEncryptionKeyRequest {
    scanType: string;
    resourceType: string;
}
export type KmsKeyArn = string;
export interface GetEncryptionKeyResponse {
    kmsKeyId: string;
}
export interface GetFindingsReportStatusRequest {
    reportId?: string | undefined;
}
export type ExternalReportStatus = string;
export type ReportingErrorCode = string;
export type ErrorMessage = string;
export interface GetFindingsReportStatusResponse {
    reportId?: string | undefined;
    status?: string | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    destination?: Destination | undefined;
    filterCriteria?: FilterCriteria | undefined;
}
export interface GetMemberRequest {
    accountId: string;
}
export interface Member {
    accountId?: string | undefined;
    relationshipStatus?: string | undefined;
    delegatedAdminAccountId?: string | undefined;
    updatedAt?: Date | undefined;
}
export interface GetMemberResponse {
    member?: Member | undefined;
}
export type ScanId = string;
export type OnDemandResourceType = "AMI" | (string & {});
export interface GetOnDemandScanStatusRequest {
    resourceId: string;
    scanId: string;
    resourceType: OnDemandResourceType;
}
export type OnDemandScanStatus = "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | (string & {});
export type OnDemandScanStatusReason = "ACCESS_DENIED" | "INTERNAL_ERROR" | "STORAGE_LIMIT_EXCEEDED" | "EXTRACTION_COLLECTION_TIME_LIMIT_EXCEEDED" | "UNSUPPORTED_OS" | "RESOURCE_TERMINATED" | (string & {});
export interface GetOnDemandScanStatusResponse {
    scanId: string;
    resourceId: string;
    resourceType: OnDemandResourceType;
    scanStatus: OnDemandScanStatus;
    scanStatusReason?: OnDemandScanStatusReason | undefined;
    startedAt: Date;
    completedAt?: Date | undefined;
}
export interface GetSbomExportRequest {
    reportId: string;
}
export interface GetSbomExportResponse {
    reportId?: string | undefined;
    format?: string | undefined;
    status?: string | undefined;
    errorCode?: string | undefined;
    errorMessage?: string | undefined;
    s3Destination?: Destination | undefined;
    filterCriteria?: ResourceFilterCriteria | undefined;
}
export type Service = string;
export type ListAccountPermissionsMaxResults = number;
export interface ListAccountPermissionsRequest {
    service?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type Operation = string;
export interface Permission {
    service: string;
    operation: string;
}
export type Permissions = Permission[];
export interface ListAccountPermissionsResponse {
    permissions: Permission[];
    nextToken?: string | undefined;
}
export type CisScanNameFilterList = CisStringFilter[];
export type TagComparison = "EQUALS" | (string & {});
export interface TagFilter {
    comparison: TagComparison;
    key: string;
    value: string;
}
export type ResourceTagFilterList = TagFilter[];
export type CisScanConfigurationArnFilterList = CisStringFilter[];
export interface ListCisScanConfigurationsFilterCriteria {
    scanNameFilters?: CisStringFilter[] | undefined;
    targetResourceTagFilters?: TagFilter[] | undefined;
    scanConfigurationArnFilters?: CisStringFilter[] | undefined;
}
export type CisScanConfigurationsSortBy = "SCAN_NAME" | "SCAN_CONFIGURATION_ARN" | (string & {});
export type ListCisScanConfigurationsMaxResults = number;
export interface ListCisScanConfigurationsRequest {
    filterCriteria?: ListCisScanConfigurationsFilterCriteria | undefined;
    sortBy?: CisScanConfigurationsSortBy | undefined;
    sortOrder?: CisSortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type CisOwnerId = string;
export type CisAccountIdList = string[];
export interface CisTargets {
    accountIds?: string[] | undefined;
    targetResourceTags?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface CisScanConfiguration {
    scanConfigurationArn: string;
    ownerId?: string | undefined;
    scanName?: string | undefined;
    securityLevel?: CisSecurityLevel | undefined;
    schedule?: Schedule | undefined;
    targets?: CisTargets | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CisScanConfigurationList = CisScanConfiguration[];
export interface ListCisScanConfigurationsResponse {
    scanConfigurations?: CisScanConfiguration[] | undefined;
    nextToken?: string | undefined;
}
export type OneAccountIdFilterList = CisStringFilter[];
export type PlatformFilterList = CisStringFilter[];
export interface CisNumberFilter {
    upperInclusive?: number | undefined;
    lowerInclusive?: number | undefined;
}
export type CisNumberFilterList = CisNumberFilter[];
export interface CisScanResultsAggregatedByChecksFilterCriteria {
    accountIdFilters?: CisStringFilter[] | undefined;
    checkIdFilters?: CisStringFilter[] | undefined;
    titleFilters?: CisStringFilter[] | undefined;
    platformFilters?: CisStringFilter[] | undefined;
    failedResourcesFilters?: CisNumberFilter[] | undefined;
    securityLevelFilters?: CisSecurityLevelFilter[] | undefined;
}
export type CisScanResultsAggregatedByChecksSortBy = "CHECK_ID" | "TITLE" | "PLATFORM" | "FAILED_COUNTS" | "SECURITY_LEVEL" | (string & {});
export type CisScanResultsMaxResults = number;
export interface ListCisScanResultsAggregatedByChecksRequest {
    scanArn: string;
    filterCriteria?: CisScanResultsAggregatedByChecksFilterCriteria | undefined;
    sortBy?: CisScanResultsAggregatedByChecksSortBy | undefined;
    sortOrder?: CisSortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface StatusCounts {
    failed?: number | undefined;
    skipped?: number | undefined;
    passed?: number | undefined;
}
export interface CisCheckAggregation {
    scanArn: string;
    checkId?: string | undefined;
    title?: string | undefined;
    checkDescription?: string | undefined;
    level?: CisSecurityLevel | undefined;
    accountId?: string | undefined;
    statusCounts?: StatusCounts | undefined;
    platform?: string | undefined;
}
export type CisCheckAggregationList = CisCheckAggregation[];
export interface ListCisScanResultsAggregatedByChecksResponse {
    checkAggregations?: CisCheckAggregation[] | undefined;
    nextToken?: string | undefined;
}
export type AccountIdFilterList = CisStringFilter[];
export type CisResultStatusComparison = "EQUALS" | (string & {});
export type CisResultStatus = "PASSED" | "FAILED" | "SKIPPED" | (string & {});
export interface CisResultStatusFilter {
    comparison: CisResultStatusComparison;
    value: CisResultStatus;
}
export type CisResultStatusFilterList = CisResultStatusFilter[];
export type ResourceIdFilterList = CisStringFilter[];
export type CisTargetStatusComparison = "EQUALS" | (string & {});
export type CisTargetStatus = "TIMED_OUT" | "CANCELLED" | "COMPLETED" | (string & {});
export interface CisTargetStatusFilter {
    comparison: CisTargetStatusComparison;
    value: CisTargetStatus;
}
export type TargetStatusFilterList = CisTargetStatusFilter[];
export type CisTargetStatusReason = "SCAN_IN_PROGRESS" | "UNSUPPORTED_OS" | "SSM_UNMANAGED" | (string & {});
export interface CisTargetStatusReasonFilter {
    comparison: CisTargetStatusComparison;
    value: CisTargetStatusReason;
}
export type TargetStatusReasonFilterList = CisTargetStatusReasonFilter[];
export interface CisScanResultsAggregatedByTargetResourceFilterCriteria {
    accountIdFilters?: CisStringFilter[] | undefined;
    statusFilters?: CisResultStatusFilter[] | undefined;
    checkIdFilters?: CisStringFilter[] | undefined;
    targetResourceIdFilters?: CisStringFilter[] | undefined;
    targetResourceTagFilters?: TagFilter[] | undefined;
    platformFilters?: CisStringFilter[] | undefined;
    targetStatusFilters?: CisTargetStatusFilter[] | undefined;
    targetStatusReasonFilters?: CisTargetStatusReasonFilter[] | undefined;
    failedChecksFilters?: CisNumberFilter[] | undefined;
}
export type CisScanResultsAggregatedByTargetResourceSortBy = "RESOURCE_ID" | "FAILED_COUNTS" | "ACCOUNT_ID" | "PLATFORM" | "TARGET_STATUS" | "TARGET_STATUS_REASON" | (string & {});
export interface ListCisScanResultsAggregatedByTargetResourceRequest {
    scanArn: string;
    filterCriteria?: CisScanResultsAggregatedByTargetResourceFilterCriteria | undefined;
    sortBy?: CisScanResultsAggregatedByTargetResourceSortBy | undefined;
    sortOrder?: CisSortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CisTargetResourceAggregation {
    scanArn: string;
    targetResourceId?: string | undefined;
    accountId?: string | undefined;
    targetResourceTags?: {
        [key: string]: string[] | undefined;
    } | undefined;
    statusCounts?: StatusCounts | undefined;
    platform?: string | undefined;
    targetStatus?: CisTargetStatus | undefined;
    targetStatusReason?: CisTargetStatusReason | undefined;
}
export type CisTargetResourceAggregationList = CisTargetResourceAggregation[];
export interface ListCisScanResultsAggregatedByTargetResourceResponse {
    targetResourceAggregations?: CisTargetResourceAggregation[] | undefined;
    nextToken?: string | undefined;
}
export type CisScanStatusComparison = "EQUALS" | (string & {});
export type CisScanStatus = "FAILED" | "COMPLETED" | "CANCELLED" | "IN_PROGRESS" | (string & {});
export interface CisScanStatusFilter {
    comparison: CisScanStatusComparison;
    value: CisScanStatus;
}
export type CisScanStatusFilterList = CisScanStatusFilter[];
export interface CisDateFilter {
    earliestScanStartTime?: Date | undefined;
    latestScanStartTime?: Date | undefined;
}
export type CisScanDateFilterList = CisDateFilter[];
export type CisScanArnFilterList = CisStringFilter[];
export type CisScheduledByFilterList = CisStringFilter[];
export interface ListCisScansFilterCriteria {
    scanNameFilters?: CisStringFilter[] | undefined;
    targetResourceTagFilters?: TagFilter[] | undefined;
    targetResourceIdFilters?: CisStringFilter[] | undefined;
    scanStatusFilters?: CisScanStatusFilter[] | undefined;
    scanAtFilters?: CisDateFilter[] | undefined;
    scanConfigurationArnFilters?: CisStringFilter[] | undefined;
    scanArnFilters?: CisStringFilter[] | undefined;
    scheduledByFilters?: CisStringFilter[] | undefined;
    failedChecksFilters?: CisNumberFilter[] | undefined;
    targetAccountIdFilters?: CisStringFilter[] | undefined;
}
export type ListCisScansDetailLevel = "ORGANIZATION" | "MEMBER" | (string & {});
export type ListCisScansSortBy = "STATUS" | "SCHEDULED_BY" | "SCAN_START_DATE" | "FAILED_CHECKS" | (string & {});
export type ListCisScansMaxResults = number;
export interface ListCisScansRequest {
    filterCriteria?: ListCisScansFilterCriteria | undefined;
    detailLevel?: ListCisScansDetailLevel | undefined;
    sortBy?: ListCisScansSortBy | undefined;
    sortOrder?: CisSortOrder | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CisScan {
    scanArn: string;
    scanConfigurationArn: string;
    status?: CisScanStatus | undefined;
    scanName?: string | undefined;
    scanDate?: Date | undefined;
    failedChecks?: number | undefined;
    totalChecks?: number | undefined;
    targets?: CisTargets | undefined;
    scheduledBy?: string | undefined;
    securityLevel?: CisSecurityLevel | undefined;
}
export type CisScanList = CisScan[];
export interface ListCisScansResponse {
    scans?: CisScan[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCodeSecurityIntegrationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CodeSecurityIntegrationSummary {
    integrationArn: string;
    name: string;
    type: IntegrationType;
    status: IntegrationStatus;
    statusReason: string;
    createdOn: Date;
    lastUpdateOn: Date;
}
export type IntegrationSummaries = CodeSecurityIntegrationSummary[];
export interface ListCodeSecurityIntegrationsResponse {
    integrations?: CodeSecurityIntegrationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCodeSecurityScanConfigurationAssociationsRequest {
    scanConfigurationArn: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CodeSecurityScanConfigurationAssociationSummary {
    resource?: CodeSecurityResource | undefined;
}
export type CodeSecurityScanConfigurationAssociationSummaries = CodeSecurityScanConfigurationAssociationSummary[];
export interface ListCodeSecurityScanConfigurationAssociationsResponse {
    associations?: CodeSecurityScanConfigurationAssociationSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCodeSecurityScanConfigurationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type OwnerId = string;
export interface CodeSecurityScanConfigurationSummary {
    scanConfigurationArn: string;
    name: string;
    ownerAccountId: string;
    periodicScanFrequency?: PeriodicScanFrequency | undefined;
    frequencyExpression?: string | undefined;
    continuousIntegrationScanSupportedEvents?: ContinuousIntegrationScanEvent[] | undefined;
    ruleSetCategories: RuleSetCategory[];
    scopeSettings?: ScopeSettings | undefined;
}
export type CodeSecurityScanConfigurationSummaries = CodeSecurityScanConfigurationSummary[];
export interface ListCodeSecurityScanConfigurationsResponse {
    configurations?: CodeSecurityScanConfigurationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ConnectorNextToken = string | redacted.Redacted<string>;
export type ConnectorArnComparison = "EQUALS" | (string & {});
export interface ConnectorArnFilter {
    comparison: ConnectorArnComparison;
    value: string;
}
export type ConnectorArnFilterList = ConnectorArnFilter[];
export type AwsConfigConnectorArnComparison = "EQUALS" | (string & {});
export interface AwsConfigConnectorArnFilter {
    comparison: AwsConfigConnectorArnComparison;
    value: string;
}
export type AwsConfigConnectorArnFilterList = AwsConfigConnectorArnFilter[];
export type ConnectorTypeComparison = "EQUALS" | (string & {});
export type ConnectorType = "CUSTOMER_MANAGED" | "SERVICE_LINKED" | (string & {});
export interface ConnectorTypeFilter {
    comparison: ConnectorTypeComparison;
    value: ConnectorType;
}
export type ConnectorTypeFilterList = ConnectorTypeFilter[];
export type ProviderComparison = "EQUALS" | (string & {});
export interface ProviderFilter {
    comparison: ProviderComparison;
    value: ConnectorCloudProvider;
}
export type ProviderFilterList = ProviderFilter[];
export interface ConnectorFilterCriteria {
    connectorArns?: ConnectorArnFilter[] | undefined;
    accounts?: StringFilter[] | undefined;
    awsConfigConnectorArns?: AwsConfigConnectorArnFilter[] | undefined;
    connectorType?: ConnectorTypeFilter[] | undefined;
    provider?: ProviderFilter[] | undefined;
}
export interface ListConnectorsRequest {
    maxResults?: number | undefined;
    nextToken?: string | redacted.Redacted<string> | undefined;
    filterCriteria?: ConnectorFilterCriteria | undefined;
}
export type EnablementStatus = "ENABLED" | "PENDING_ENABLEMENT" | "FAILED_TO_ENABLE" | "PENDING_UPDATE" | "FAILED_TO_UPDATE" | "PENDING_DELETION" | "DELETED" | "FAILED_TO_DELETE" | (string & {});
export type ConnectorHealthStatus = "CONNECTED" | "DEGRADED" | "FAILED_TO_CONNECT" | "PENDING_AUTHORIZATION" | "PENDING_CONFIGURATION" | "UNKNOWN" | (string & {});
export interface ConnectorHealth {
    connectorStatus: ConnectorHealthStatus;
    lastCheckedAt: Date;
    message?: string | undefined;
}
export type ScopeState = "ACTIVE" | "PENDING" | "ERROR" | "DISABLED" | (string & {});
export interface ScopeConfiguration {
    scopeType: ScopeType;
    scopeValues?: string[] | undefined;
    state?: ScopeState | undefined;
    stateReason?: string | undefined;
}
export interface AzureScopeConfiguration {
    vmScanning?: ScopeConfiguration | undefined;
    containerImageScanning?: ScopeConfiguration | undefined;
    serverlessScanning?: ScopeConfiguration | undefined;
}
export interface Connector {
    connectorArn: string;
    name?: string | undefined;
    description?: string | undefined;
    provider: ConnectorCloudProvider;
    enablementStatus?: EnablementStatus | undefined;
    enablementStatusReason?: string | undefined;
    health?: ConnectorHealth | undefined;
    createdAt: Date;
    updatedAt: Date;
    azureRegions?: string[] | undefined;
    awsConfigConnectorArn?: string | undefined;
    scopeConfiguration?: AzureScopeConfiguration | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    autoInstallVMScanner?: boolean | undefined;
}
export type ConnectorList = Connector[];
export interface ListConnectorsResponse {
    items: Connector[];
    nextToken?: string | redacted.Redacted<string> | undefined;
}
export type AwsConfigConnectorArnList = string[];
export type ListConnectorScanConfigurationsMaxResults = number;
export interface ListConnectorScanConfigurationsRequest {
    awsConfigConnectorArns?: string[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | redacted.Redacted<string> | undefined;
}
export type ConnectorArnList = string[];
export type ContainerImageRescanDuration = string;
export type ContainerImagePullDateRescanDuration = string;
export interface ConnectorContainerImageScanConfiguration {
    pushDuration?: string | undefined;
    pullDuration?: string | undefined;
}
export interface ConnectorScanConfiguration {
    containerImageScanning?: ConnectorContainerImageScanConfiguration | undefined;
}
export interface ConnectorScanConfigurationItem {
    awsConfigConnectorArn: string;
    connectorArns: string[];
    scanConfiguration: ConnectorScanConfiguration;
}
export type ConnectorScanConfigurationItemList = ConnectorScanConfigurationItem[];
export interface ListConnectorScanConfigurationsResponse {
    scanConfigurations: ConnectorScanConfigurationItem[];
    nextToken?: string | redacted.Redacted<string> | undefined;
}
export type ListCoverageMaxResults = number;
export type CoverageStringComparison = string;
export type CoverageStringInput = string;
export interface CoverageStringFilter {
    comparison: string;
    value: string;
}
export type CoverageStringFilterList = CoverageStringFilter[];
export type CoverageMapComparison = string;
export interface CoverageMapFilter {
    comparison: string;
    key: string;
    value?: string | undefined;
}
export type CoverageMapFilterList = CoverageMapFilter[];
export interface CoverageDateFilter {
    startInclusive?: Date | undefined;
    endInclusive?: Date | undefined;
}
export type CoverageDateFilterList = CoverageDateFilter[];
export interface CoverageNumberFilter {
    upperInclusive?: number | undefined;
    lowerInclusive?: number | undefined;
}
export type CoverageNumberFilterList = CoverageNumberFilter[];
export interface CoverageFilterCriteria {
    scanStatusCode?: CoverageStringFilter[] | undefined;
    scanStatusReason?: CoverageStringFilter[] | undefined;
    accountId?: CoverageStringFilter[] | undefined;
    resourceId?: CoverageStringFilter[] | undefined;
    resourceType?: CoverageStringFilter[] | undefined;
    scanType?: CoverageStringFilter[] | undefined;
    ecrRepositoryName?: CoverageStringFilter[] | undefined;
    ecrImageTags?: CoverageStringFilter[] | undefined;
    ec2InstanceTags?: CoverageMapFilter[] | undefined;
    lambdaFunctionName?: CoverageStringFilter[] | undefined;
    lambdaFunctionTags?: CoverageMapFilter[] | undefined;
    lambdaFunctionRuntime?: CoverageStringFilter[] | undefined;
    machineImageTags?: CoverageMapFilter[] | undefined;
    lastScannedAt?: CoverageDateFilter[] | undefined;
    scanMode?: CoverageStringFilter[] | undefined;
    imagePulledAt?: CoverageDateFilter[] | undefined;
    ecrImageLastInUseAt?: CoverageDateFilter[] | undefined;
    ecrImageInUseCount?: CoverageNumberFilter[] | undefined;
    codeRepositoryProjectName?: CoverageStringFilter[] | undefined;
    codeRepositoryProviderType?: CoverageStringFilter[] | undefined;
    codeRepositoryProviderTypeVisibility?: CoverageStringFilter[] | undefined;
    lastScannedCommitId?: CoverageStringFilter[] | undefined;
    cloudProvider?: CoverageStringFilter[] | undefined;
    cloudProviderAccountId?: CoverageStringFilter[] | undefined;
    cloudProviderRegion?: CoverageStringFilter[] | undefined;
    cloudVmInstanceTags?: CoverageMapFilter[] | undefined;
    cloudContainerImageTags?: CoverageStringFilter[] | undefined;
    cloudContainerRepositoryName?: CoverageStringFilter[] | undefined;
    cloudContainerRegistryName?: CoverageStringFilter[] | undefined;
    cloudServerlessFunctionName?: CoverageStringFilter[] | undefined;
    cloudServerlessFunctionRuntime?: CoverageStringFilter[] | undefined;
    cloudServerlessFunctionTags?: CoverageMapFilter[] | undefined;
    cloudProviderOrgId?: CoverageStringFilter[] | undefined;
}
export interface ListCoverageRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filterCriteria?: CoverageFilterCriteria | undefined;
}
export type CoverageResourceType = string;
export type ScanStatusCode = string;
export type ScanStatusReason = string;
export interface ScanStatus {
    statusCode: string;
    reason: string;
}
export type EcrScanFrequency = string;
export interface EcrRepositoryMetadata {
    name?: string | undefined;
    scanFrequency?: string | undefined;
}
export type TagList = string[];
export interface EcrContainerImageMetadata {
    tags?: string[] | undefined;
    imagePulledAt?: Date | undefined;
    lastInUseAt?: Date | undefined;
    inUseCount?: number | undefined;
}
export type AmiId = string;
export type Ec2Platform = string;
export interface Ec2Metadata {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    amiId?: string | undefined;
    platform?: string | undefined;
}
export type LambdaLayerList = string[];
export type Runtime = string;
export interface LambdaFunctionMetadata {
    functionTags?: {
        [key: string]: string | undefined;
    } | undefined;
    layers?: string[] | undefined;
    functionName?: string | undefined;
    runtime?: string | undefined;
}
export type CodeRepositoryIntegrationArn = string;
export type CommitId = string;
export interface ProjectPeriodicScanConfiguration {
    frequencyExpression?: string | undefined;
    ruleSetCategories?: RuleSetCategory[] | undefined;
}
export type ProjectPeriodicScanConfigurationList = ProjectPeriodicScanConfiguration[];
export interface ProjectContinuousIntegrationScanConfiguration {
    supportedEvent?: ContinuousIntegrationScanEvent | undefined;
    ruleSetCategories?: RuleSetCategory[] | undefined;
}
export type ProjectContinuousIntegrationScanConfigurationList = ProjectContinuousIntegrationScanConfiguration[];
export interface ProjectCodeSecurityScanConfiguration {
    periodicScanConfigurations?: ProjectPeriodicScanConfiguration[] | undefined;
    continuousIntegrationScanConfigurations?: ProjectContinuousIntegrationScanConfiguration[] | undefined;
}
export interface CodeRepositoryOnDemandScan {
    lastScannedCommitId?: string | undefined;
    lastScanAt?: Date | undefined;
    scanStatus?: ScanStatus | undefined;
}
export interface CodeRepositoryMetadata {
    projectName: string;
    integrationArn?: string | undefined;
    providerType: string;
    providerTypeVisibility: string;
    lastScannedCommitId?: string | undefined;
    scanConfiguration?: ProjectCodeSecurityScanConfiguration | undefined;
    onDemandScan?: CodeRepositoryOnDemandScan | undefined;
}
export type VmPlatform = string;
export interface VmInstanceMetadata {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    platform?: string | undefined;
    inventoryHash?: string | undefined;
    vmImageReference?: string | undefined;
}
export interface ContainerImageMetadata {
    imageTags?: string[] | undefined;
    imagePulledAt?: Date | undefined;
    lastInUseAt?: Date | undefined;
    inUseCount?: number | undefined;
}
export interface ContainerRepositoryMetadata {
    name?: string | undefined;
    scanFrequency?: string | undefined;
}
export interface ContainerRegistryMetadata {
    name?: string | undefined;
}
export interface ServerlessFunctionMetadata {
    serverlessFunctionName?: string | undefined;
    runtime?: string | undefined;
    functionTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MachineImagePlatform = string;
export interface MachineImageMetadata {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    platform?: string | undefined;
}
export interface ResourceScanMetadata {
    ecrRepository?: EcrRepositoryMetadata | undefined;
    ecrImage?: EcrContainerImageMetadata | undefined;
    ec2?: Ec2Metadata | undefined;
    lambdaFunction?: LambdaFunctionMetadata | undefined;
    codeRepository?: CodeRepositoryMetadata | undefined;
    vmInstance?: VmInstanceMetadata | undefined;
    containerImage?: ContainerImageMetadata | undefined;
    containerRepository?: ContainerRepositoryMetadata | undefined;
    containerRegistry?: ContainerRegistryMetadata | undefined;
    serverlessFunction?: ServerlessFunctionMetadata | undefined;
    machineImage?: MachineImageMetadata | undefined;
}
export type ScanMode = string;
export type Provider = string;
export type ProviderAccountId = string;
export type ProviderOrgId = string;
export type ProviderRegion = string;
export type ProviderPartition = string;
export interface CoveredResource {
    resourceType: string;
    resourceId: string;
    accountId: string;
    scanType: string;
    scanStatus?: ScanStatus | undefined;
    resourceMetadata?: ResourceScanMetadata | undefined;
    lastScannedAt?: Date | undefined;
    scanMode?: string | undefined;
    provider?: string | undefined;
    providerAccountId?: string | undefined;
    providerOrgId?: string | undefined;
    providerRegion?: string | undefined;
    providerPartition?: string | undefined;
}
export type CoveredResources = CoveredResource[];
export interface ListCoverageResponse {
    nextToken?: string | undefined;
    coveredResources?: CoveredResource[] | undefined;
}
export type GroupKey = string;
export interface ListCoverageStatisticsRequest {
    filterCriteria?: CoverageFilterCriteria | undefined;
    groupBy?: string | undefined;
    nextToken?: string | undefined;
}
export type AggCounts = number;
export interface Counts {
    count?: number | undefined;
    groupKey?: string | undefined;
}
export type CountsList = Counts[];
export interface ListCoverageStatisticsResponse {
    countsByGroup?: Counts[] | undefined;
    totalCounts: number;
    nextToken?: string | undefined;
}
export type ListDelegatedAdminMaxResults = number;
export interface ListDelegatedAdminAccountsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type DelegatedAdminStatus = string;
export interface DelegatedAdminAccount {
    accountId?: string | undefined;
    status?: string | undefined;
}
export type DelegatedAdminAccountList = DelegatedAdminAccount[];
export interface ListDelegatedAdminAccountsResponse {
    delegatedAdminAccounts?: DelegatedAdminAccount[] | undefined;
    nextToken?: string | undefined;
}
export type FilterArnList = string[];
export type ListFilterMaxResults = number;
export interface ListFiltersRequest {
    arns?: string[] | undefined;
    action?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Filter {
    arn: string;
    ownerId: string;
    name: string;
    criteria: FilterCriteria;
    action: string;
    createdAt: Date;
    updatedAt: Date;
    description?: string | undefined;
    reason?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type FilterList = Filter[];
export interface ListFiltersResponse {
    filters: Filter[];
    nextToken?: string | undefined;
}
export type AggregationType = string;
export type ListFindingAggregationsMaxResults = number;
export type AggregationFindingType = string;
export type AggregationResourceType = string;
export type SortOrder = string;
export type AccountSortBy = string;
export interface AccountAggregation {
    findingType?: string | undefined;
    resourceType?: string | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type AmiSortBy = string;
export type ScanSource = string;
export type ScanSourceList = string[];
export interface AmiAggregation {
    amis?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
    scanSources?: string[] | undefined;
}
export type AwsEcrContainerSortBy = string;
export interface AwsEcrContainerAggregation {
    resourceIds?: StringFilter[] | undefined;
    imageShas?: StringFilter[] | undefined;
    repositories?: StringFilter[] | undefined;
    architectures?: StringFilter[] | undefined;
    imageTags?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
    lastInUseAt?: DateFilter[] | undefined;
    inUseCount?: NumberFilter[] | undefined;
}
export type Ec2InstanceSortBy = string;
export interface Ec2InstanceAggregation {
    amis?: StringFilter[] | undefined;
    operatingSystems?: StringFilter[] | undefined;
    instanceIds?: StringFilter[] | undefined;
    instanceTags?: MapFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type FindingTypeSortBy = string;
export interface FindingTypeAggregation {
    findingType?: string | undefined;
    resourceType?: string | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type ImageLayerSortBy = string;
export interface ImageLayerAggregation {
    repositories?: StringFilter[] | undefined;
    resourceIds?: StringFilter[] | undefined;
    layerHashes?: StringFilter[] | undefined;
    cloudProviders?: StringFilter[] | undefined;
    cloudAccountIds?: StringFilter[] | undefined;
    cloudOrgIds?: StringFilter[] | undefined;
    cloudRegions?: StringFilter[] | undefined;
    cloudPartitions?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type PackageSortBy = string;
export interface PackageAggregation {
    packageNames?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type RepositorySortBy = string;
export interface RepositoryAggregation {
    repositories?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type TitleSortBy = string;
export interface TitleAggregation {
    titles?: StringFilter[] | undefined;
    vulnerabilityIds?: StringFilter[] | undefined;
    resourceType?: string | undefined;
    findingType?: string | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type LambdaLayerSortBy = string;
export interface LambdaLayerAggregation {
    functionNames?: StringFilter[] | undefined;
    resourceIds?: StringFilter[] | undefined;
    layerArns?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type LambdaFunctionSortBy = string;
export interface LambdaFunctionAggregation {
    resourceIds?: StringFilter[] | undefined;
    functionNames?: StringFilter[] | undefined;
    runtimes?: StringFilter[] | undefined;
    functionTags?: MapFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type CodeRepositorySortBy = string;
export interface CodeRepositoryAggregation {
    projectNames?: StringFilter[] | undefined;
    providerTypes?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
    resourceIds?: StringFilter[] | undefined;
}
export type VmInstanceSortBy = string;
export interface VmInstanceAggregation {
    resourceIds?: StringFilter[] | undefined;
    operatingSystems?: StringFilter[] | undefined;
    instanceTags?: MapFilter[] | undefined;
    vmImageReferences?: StringFilter[] | undefined;
    cloudProviders?: StringFilter[] | undefined;
    cloudPartitions?: StringFilter[] | undefined;
    cloudRegions?: StringFilter[] | undefined;
    cloudOrgIds?: StringFilter[] | undefined;
    cloudAccountIds?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type ContainerImageSortBy = string;
export interface ContainerImageAggregation {
    resourceIds?: StringFilter[] | undefined;
    imageDigests?: StringFilter[] | undefined;
    repositories?: StringFilter[] | undefined;
    registries?: StringFilter[] | undefined;
    architectures?: StringFilter[] | undefined;
    imageTags?: StringFilter[] | undefined;
    cloudProviders?: StringFilter[] | undefined;
    cloudPartitions?: StringFilter[] | undefined;
    cloudRegions?: StringFilter[] | undefined;
    cloudOrgIds?: StringFilter[] | undefined;
    cloudAccountIds?: StringFilter[] | undefined;
    lastInUseAt?: DateFilter[] | undefined;
    inUseCount?: NumberFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type ServerlessFunctionSortBy = string;
export interface ServerlessFunctionAggregation {
    resourceIds?: StringFilter[] | undefined;
    functionNames?: StringFilter[] | undefined;
    runtimes?: StringFilter[] | undefined;
    functionTags?: MapFilter[] | undefined;
    cloudProviders?: StringFilter[] | undefined;
    cloudPartitions?: StringFilter[] | undefined;
    cloudRegions?: StringFilter[] | undefined;
    cloudOrgIds?: StringFilter[] | undefined;
    cloudAccountIds?: StringFilter[] | undefined;
    sortOrder?: string | undefined;
    sortBy?: string | undefined;
}
export type AggregationRequest = {
    accountAggregation: AccountAggregation;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation: AmiAggregation;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation: AwsEcrContainerAggregation;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation: Ec2InstanceAggregation;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation: FindingTypeAggregation;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation: ImageLayerAggregation;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation: PackageAggregation;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation: RepositoryAggregation;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation: TitleAggregation;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation: LambdaLayerAggregation;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation: LambdaFunctionAggregation;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation: CodeRepositoryAggregation;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation: VmInstanceAggregation;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation: ContainerImageAggregation;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation: ServerlessFunctionAggregation;
};
export interface ListFindingAggregationsRequest {
    aggregationType: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    accountIds?: StringFilter[] | undefined;
    aggregationRequest?: AggregationRequest | undefined;
}
export interface SeverityCounts {
    all?: number | undefined;
    medium?: number | undefined;
    high?: number | undefined;
    critical?: number | undefined;
    low?: number | undefined;
    informational?: number | undefined;
    untriaged?: number | undefined;
}
export interface AccountAggregationResponse {
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    exploitAvailableCount?: number | undefined;
    fixAvailableCount?: number | undefined;
}
export interface AmiAggregationResponse {
    ami: string;
    accountId?: string | undefined;
    cloudProvider?: string | undefined;
    cloudPartition?: string | undefined;
    cloudRegion?: string | undefined;
    cloudOrgId?: string | undefined;
    cloudAccountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    affectedInstances?: number | undefined;
    scanSource?: string | undefined;
}
export type StringList = string[];
export interface AwsEcrContainerAggregationResponse {
    resourceId: string;
    imageSha?: string | undefined;
    repository?: string | undefined;
    architecture?: string | undefined;
    imageTags?: string[] | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    lastInUseAt?: Date | undefined;
    inUseCount?: number | undefined;
}
export interface Ec2InstanceAggregationResponse {
    instanceId: string;
    ami?: string | undefined;
    operatingSystem?: string | undefined;
    instanceTags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    networkFindings?: number | undefined;
}
export interface FindingTypeAggregationResponse {
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    exploitAvailableCount?: number | undefined;
    fixAvailableCount?: number | undefined;
    cloudProvider?: string | undefined;
    cloudAccountId?: string | undefined;
    cloudOrgId?: string | undefined;
    cloudRegion?: string | undefined;
    cloudPartition?: string | undefined;
}
export interface ImageLayerAggregationResponse {
    repository: string;
    resourceId: string;
    layerHash: string;
    accountId: string;
    cloudProvider?: string | undefined;
    cloudAccountId?: string | undefined;
    cloudOrgId?: string | undefined;
    cloudRegion?: string | undefined;
    cloudPartition?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface PackageAggregationResponse {
    packageName: string;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface RepositoryAggregationResponse {
    repository: string;
    accountId?: string | undefined;
    cloudProvider?: string | undefined;
    cloudPartition?: string | undefined;
    cloudRegion?: string | undefined;
    cloudOrgId?: string | undefined;
    cloudAccountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    affectedImages?: number | undefined;
}
export interface TitleAggregationResponse {
    title: string;
    vulnerabilityId?: string | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
}
export interface LambdaLayerAggregationResponse {
    functionName: string;
    resourceId: string;
    layerArn: string;
    accountId: string;
    severityCounts?: SeverityCounts | undefined;
}
export interface LambdaFunctionAggregationResponse {
    resourceId: string;
    functionName?: string | undefined;
    runtime?: string | undefined;
    lambdaTags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    lastModifiedAt?: Date | undefined;
}
export interface CodeRepositoryAggregationResponse {
    projectNames: string;
    providerType?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    exploitAvailableActiveFindingsCount?: number | undefined;
    fixAvailableActiveFindingsCount?: number | undefined;
    accountId?: string | undefined;
    resourceId?: string | undefined;
}
export interface VmInstanceAggregationResponse {
    resourceId: string;
    cloudProvider?: string | undefined;
    cloudAccountId?: string | undefined;
    cloudPartition?: string | undefined;
    cloudRegion?: string | undefined;
    cloudOrgId?: string | undefined;
    vmImageReference?: string | undefined;
    operatingSystem?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    networkFindings?: number | undefined;
    exploitAvailableActiveFindingsCount?: number | undefined;
    fixAvailableActiveFindingsCount?: number | undefined;
}
export interface ContainerImageAggregationResponse {
    resourceId: string;
    cloudProvider?: string | undefined;
    cloudAccountId?: string | undefined;
    cloudPartition?: string | undefined;
    cloudRegion?: string | undefined;
    cloudOrgId?: string | undefined;
    imageDigest?: string | undefined;
    repository?: string | undefined;
    registry?: string | undefined;
    architecture?: string | undefined;
    imageTags?: string[] | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    lastInUseAt?: Date | undefined;
    inUseCount?: number | undefined;
    exploitAvailableActiveFindingsCount?: number | undefined;
    fixAvailableActiveFindingsCount?: number | undefined;
}
export interface ServerlessFunctionAggregationResponse {
    resourceId: string;
    cloudProvider?: string | undefined;
    cloudAccountId?: string | undefined;
    cloudPartition?: string | undefined;
    cloudRegion?: string | undefined;
    cloudOrgId?: string | undefined;
    functionName?: string | undefined;
    runtime?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    accountId?: string | undefined;
    severityCounts?: SeverityCounts | undefined;
    lastModifiedAt?: Date | undefined;
    exploitAvailableActiveFindingsCount?: number | undefined;
    fixAvailableActiveFindingsCount?: number | undefined;
}
export type AggregationResponse = {
    accountAggregation: AccountAggregationResponse;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation: AmiAggregationResponse;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation: AwsEcrContainerAggregationResponse;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation: Ec2InstanceAggregationResponse;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation: FindingTypeAggregationResponse;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation: ImageLayerAggregationResponse;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation: PackageAggregationResponse;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation: RepositoryAggregationResponse;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation: TitleAggregationResponse;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation: LambdaLayerAggregationResponse;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation: LambdaFunctionAggregationResponse;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation: CodeRepositoryAggregationResponse;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation: VmInstanceAggregationResponse;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation: ContainerImageAggregationResponse;
    serverlessFunctionAggregation?: undefined;
} | {
    accountAggregation?: undefined;
    amiAggregation?: undefined;
    awsEcrContainerAggregation?: undefined;
    ec2InstanceAggregation?: undefined;
    findingTypeAggregation?: undefined;
    imageLayerAggregation?: undefined;
    packageAggregation?: undefined;
    repositoryAggregation?: undefined;
    titleAggregation?: undefined;
    lambdaLayerAggregation?: undefined;
    lambdaFunctionAggregation?: undefined;
    codeRepositoryAggregation?: undefined;
    vmInstanceAggregation?: undefined;
    containerImageAggregation?: undefined;
    serverlessFunctionAggregation: ServerlessFunctionAggregationResponse;
};
export type AggregationResponseList = AggregationResponse[];
export interface ListFindingAggregationsResponse {
    aggregationType: string;
    responses?: AggregationResponse[] | undefined;
    nextToken?: string | undefined;
}
export type ListFindingsMaxResults = number;
export type SortField = string;
export interface SortCriteria {
    field: string;
    sortOrder: string;
}
export interface ListFindingsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filterCriteria?: FilterCriteria | undefined;
    sortCriteria?: SortCriteria | undefined;
}
export type FindingType = string;
export type FindingDescription = string;
export type FindingTitle = string;
export interface Recommendation {
    text?: string | undefined;
    Url?: string | undefined;
}
export interface Remediation {
    recommendation?: Recommendation | undefined;
}
export type Severity = string;
export type FindingStatus = string;
export type IpV4Address = string;
export type IpV4AddressList = string[];
export type IpV6Address = string;
export type IpV6AddressList = string[];
export type Platform = string;
export interface AwsEc2InstanceDetails {
    type?: string | undefined;
    imageId?: string | undefined;
    ipV4Addresses?: string[] | undefined;
    ipV6Addresses?: string[] | undefined;
    keyName?: string | undefined;
    iamInstanceProfileArn?: string | undefined;
    vpcId?: string | undefined;
    subnetId?: string | undefined;
    launchedAt?: Date | undefined;
    platform?: string | undefined;
}
export type ImageTagList = string[];
export type ImageHash = string;
export interface AwsEcrContainerImageDetails {
    repositoryName: string;
    imageTags?: string[] | undefined;
    pushedAt?: Date | undefined;
    author?: string | undefined;
    architecture?: string | undefined;
    imageHash: string;
    registry: string;
    platform?: string | undefined;
    lastInUseAt?: Date | undefined;
    inUseCount?: number | undefined;
}
export type FunctionName = string;
export type Version = string;
export type ExecutionRoleArn = string;
export type LambdaLayerArn = string;
export type LayerList = string[];
export type SubnetId = string;
export type SubnetIdList = string[];
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export type VpcId = string;
export interface LambdaVpcConfig {
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    vpcId?: string | undefined;
}
export type PackageType = string;
export type Architecture = string;
export type ArchitectureList = string[];
export interface AwsLambdaFunctionDetails {
    functionName: string;
    runtime: string;
    codeSha256: string;
    version: string;
    executionRoleArn: string;
    layers?: string[] | undefined;
    vpcConfig?: LambdaVpcConfig | undefined;
    packageType?: string | undefined;
    architectures?: string[] | undefined;
    lastModifiedAt?: Date | undefined;
}
export type CodeRepositoryProjectName = string;
export type CodeRepositoryProviderType = string;
export interface CodeRepositoryDetails {
    projectName?: string | undefined;
    integrationArn?: string | undefined;
    providerType?: string | undefined;
}
export interface MachineImageDetails {
    machineImageId: string;
    name?: string | undefined;
    ownerAccountId?: string | undefined;
    platform?: string | undefined;
    architecture?: string | undefined;
    creationDate?: Date | undefined;
    state?: string | undefined;
    isPublic?: boolean | undefined;
    rootDeviceType?: string | undefined;
    virtualizationType?: string | undefined;
    sourceResourceId?: string | undefined;
}
export type CloudSubnetIdList = string[];
export type CloudSecurityGroupIdList = string[];
export interface Vm {
    type?: string | undefined;
    vmName?: string | undefined;
    vmImageReference?: string | undefined;
    ipV4Addresses?: string[] | undefined;
    ipV6Addresses?: string[] | undefined;
    networkId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    launchedAt?: Date | undefined;
    platform?: string | undefined;
    executionRole?: string | undefined;
    keyName?: string | undefined;
}
export interface Image {
    repositoryName?: string | undefined;
    registry?: string | undefined;
    imageTags?: string[] | undefined;
    imageDigest?: string | undefined;
    pushedAt?: Date | undefined;
    architecture?: string | undefined;
    author?: string | undefined;
    inUseCount?: number | undefined;
    lastInUseAt?: Date | undefined;
    platform?: string | undefined;
}
export type ServerlessFunctionLayerUrn = string;
export type ServerlessFunctionLayerList = string[];
export interface ServerlessFunction {
    serverlessFunctionName?: string | undefined;
    runtime?: string | undefined;
    version?: string | undefined;
    codeDigest?: string | undefined;
    lastModifiedAt?: Date | undefined;
    networkId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    executionRole?: string | undefined;
    packageType?: string | undefined;
    architectures?: string[] | undefined;
    layers?: string[] | undefined;
}
export interface ResourceDetails {
    awsEc2Instance?: AwsEc2InstanceDetails | undefined;
    awsEcrContainerImage?: AwsEcrContainerImageDetails | undefined;
    awsLambdaFunction?: AwsLambdaFunctionDetails | undefined;
    codeRepository?: CodeRepositoryDetails | undefined;
    machineImage?: MachineImageDetails | undefined;
    vm?: Vm | undefined;
    image?: Image | undefined;
    serverlessFunction?: ServerlessFunction | undefined;
}
export interface Resource {
    type: string;
    id: string;
    partition?: string | undefined;
    region?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    details?: ResourceDetails | undefined;
    provider?: string | undefined;
    providerAccountId?: string | undefined;
    providerOrgId?: string | undefined;
}
export type ResourceList = Resource[];
export interface CvssScoreAdjustment {
    metric: string;
    reason: string;
}
export type CvssScoreAdjustmentList = CvssScoreAdjustment[];
export interface CvssScoreDetails {
    scoreSource: string;
    cvssSource?: string | undefined;
    version: string;
    score: number;
    scoringVector: string;
    adjustments?: CvssScoreAdjustment[] | undefined;
}
export interface InspectorScoreDetails {
    adjustedCvss?: CvssScoreDetails | undefined;
}
export interface PortRange {
    begin: number;
    end: number;
}
export type NetworkProtocol = string;
export type Component = string;
export type ComponentType = string;
export type ComponentArn = string;
export interface Step {
    componentId: string;
    componentType: string;
    componentArn?: string | undefined;
}
export type StepList = Step[];
export interface NetworkPath {
    steps?: Step[] | undefined;
}
export interface NetworkReachabilityDetails {
    openPortRange: PortRange;
    protocol: string;
    networkPath: NetworkPath;
}
export type VulnerabilityId = string;
export type PackageName = string;
export type PackageVersion = string;
export type SourceLayerHash = string;
export type PackageEpoch = number;
export type PackageRelease = string;
export type PackageArchitecture = string;
export type PackageManager = string;
export type FilePath = string;
export type VulnerablePackageRemediation = string;
export interface VulnerablePackage {
    name: string;
    version: string;
    sourceLayerHash?: string | undefined;
    epoch?: number | undefined;
    release?: string | undefined;
    arch?: string | undefined;
    packageManager?: string | undefined;
    filePath?: string | undefined;
    fixedInVersion?: string | undefined;
    remediation?: string | undefined;
    sourceLambdaLayerArn?: string | undefined;
}
export type VulnerablePackageList = VulnerablePackage[];
export interface CvssScore {
    baseScore: number;
    scoringVector: string;
    version: string;
    source: string;
}
export type CvssScoreList = CvssScore[];
export type VulnerabilityIdList = string[];
export type NonEmptyStringList = string[];
export interface PackageVulnerabilityDetails {
    vulnerabilityId: string;
    vulnerablePackages?: VulnerablePackage[] | undefined;
    source: string;
    cvss?: CvssScore[] | undefined;
    relatedVulnerabilities?: string[] | undefined;
    sourceUrl?: string | undefined;
    vendorSeverity?: string | undefined;
    vendorCreatedAt?: Date | undefined;
    vendorUpdatedAt?: Date | undefined;
    referenceUrls?: string[] | undefined;
}
export type FixAvailable = string;
export type ExploitAvailable = string;
export interface ExploitabilityDetails {
    lastKnownExploitAt?: Date | undefined;
}
export interface CodeFilePath {
    fileName: string;
    filePath: string;
    startLine: number;
    endLine: number;
}
export type DetectorTagList = string[];
export type ReferenceUrls = string[];
export type CweList = string[];
export interface CodeVulnerabilityDetails {
    filePath: CodeFilePath;
    detectorTags?: string[] | undefined;
    referenceUrls?: string[] | undefined;
    ruleId?: string | undefined;
    sourceLambdaLayerArn?: string | undefined;
    detectorId: string;
    detectorName: string;
    cwes: string[];
}
export type EpssScoreValue = number;
export interface EpssDetails {
    score?: number | undefined;
}
export interface Finding {
    findingArn: string;
    awsAccountId: string;
    type: string;
    description: string;
    title?: string | undefined;
    remediation: Remediation;
    severity: string;
    firstObservedAt: Date;
    lastObservedAt: Date;
    updatedAt?: Date | undefined;
    status: string;
    resources: Resource[];
    inspectorScore?: number | undefined;
    inspectorScoreDetails?: InspectorScoreDetails | undefined;
    networkReachabilityDetails?: NetworkReachabilityDetails | undefined;
    packageVulnerabilityDetails?: PackageVulnerabilityDetails | undefined;
    fixAvailable?: string | undefined;
    exploitAvailable?: string | undefined;
    exploitabilityDetails?: ExploitabilityDetails | undefined;
    codeVulnerabilityDetails?: CodeVulnerabilityDetails | undefined;
    epss?: EpssDetails | undefined;
}
export type FindingList = Finding[];
export interface ListFindingsResponse {
    nextToken?: string | undefined;
    findings?: Finding[] | undefined;
}
export type ListMembersMaxResults = number;
export interface ListMembersRequest {
    onlyAssociated?: boolean | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type MemberList = Member[];
export interface ListMembersResponse {
    members?: Member[] | undefined;
    nextToken?: string | undefined;
}
export type OnDemandScanNextToken = string;
export interface ListOnDemandScansRequest {
    resourceId: string;
    resourceType: OnDemandResourceType;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface OnDemandScan {
    scanId: string;
    resourceId: string;
    resourceType: OnDemandResourceType;
    scanStatus: OnDemandScanStatus;
    scanStatusReason?: OnDemandScanStatusReason | undefined;
    startedAt: Date;
    completedAt?: Date | undefined;
}
export type OnDemandScanList = OnDemandScan[];
export interface ListOnDemandScansResponse {
    items: OnDemandScan[];
    nextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ListUsageTotalsMaxResults = number;
export type ListUsageTotalsNextToken = string;
export type UsageAccountId = string;
export type UsageAccountIdList = string[];
export interface ListUsageTotalsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    accountIds?: string[] | undefined;
}
export type UsageType = string;
export type UsageValue = number;
export type MonthlyCostEstimate = number;
export type Currency = string;
export interface Usage {
    type?: string | undefined;
    total?: number | undefined;
    estimatedMonthlyCost?: number | undefined;
    currency?: string | undefined;
    cloudProvider?: string | undefined;
}
export type UsageList = Usage[];
export interface UsageTotal {
    accountId?: string | undefined;
    usage?: Usage[] | undefined;
}
export type UsageTotalList = UsageTotal[];
export interface ListUsageTotalsResponse {
    nextToken?: string | undefined;
    totals?: UsageTotal[] | undefined;
}
export interface ResetEncryptionKeyRequest {
    scanType: string;
    resourceType: string;
}
export interface ResetEncryptionKeyResponse {
}
export type VulnId = string;
export type VulnIdList = string[];
export interface SearchVulnerabilitiesFilterCriteria {
    vulnerabilityIds: string[];
}
export interface SearchVulnerabilitiesRequest {
    filterCriteria: SearchVulnerabilitiesFilterCriteria;
    nextToken?: string | undefined;
}
export type VulnerabilitySource = string;
export type VulnerabilityDescription = string;
export type Target = string;
export type Targets = string[];
export interface AtigData {
    firstSeen?: Date | undefined;
    lastSeen?: Date | undefined;
    targets?: string[] | undefined;
    ttps?: string[] | undefined;
}
export type VendorSeverity = string;
export type CvssBaseScore = number;
export type CvssScoringVector = string;
export interface Cvss4 {
    baseScore?: number | undefined;
    scoringVector?: string | undefined;
}
export interface Cvss3 {
    baseScore?: number | undefined;
    scoringVector?: string | undefined;
}
export type RelatedVulnerability = string;
export type RelatedVulnerabilities = string[];
export interface Cvss2 {
    baseScore?: number | undefined;
    scoringVector?: string | undefined;
}
export type VendorCreatedAt = Date;
export type VendorUpdatedAt = Date;
export type VulnerabilitySourceUrl = string;
export type DetectionPlatforms = string[];
export type EpssScore = number;
export interface Epss {
    score?: number | undefined;
}
export interface Vulnerability {
    id: string;
    cwes?: string[] | undefined;
    cisaData?: CisaData | undefined;
    source?: string | undefined;
    description?: string | undefined;
    atigData?: AtigData | undefined;
    vendorSeverity?: string | undefined;
    cvss4?: Cvss4 | undefined;
    cvss3?: Cvss3 | undefined;
    relatedVulnerabilities?: string[] | undefined;
    cvss2?: Cvss2 | undefined;
    vendorCreatedAt?: Date | undefined;
    vendorUpdatedAt?: Date | undefined;
    sourceUrl?: string | undefined;
    referenceUrls?: string[] | undefined;
    exploitObserved?: ExploitObserved | undefined;
    detectionPlatforms?: string[] | undefined;
    epss?: Epss | undefined;
}
export type Vulnerabilities = Vulnerability[];
export interface SearchVulnerabilitiesResponse {
    vulnerabilities: Vulnerability[];
    nextToken?: string | undefined;
}
export type UUID = string;
export interface SendCisSessionHealthRequest {
    scanJobId: string;
    sessionToken: string;
}
export interface SendCisSessionHealthResponse {
}
export type RuleId = string;
export type CisRuleStatus = "FAILED" | "PASSED" | "NOT_EVALUATED" | "INFORMATIONAL" | "UNKNOWN" | "NOT_APPLICABLE" | "ERROR" | (string & {});
export type CisRuleDetails = Uint8Array;
export interface CisSessionMessage {
    ruleId: string;
    status: CisRuleStatus;
    cisRuleDetails: Uint8Array;
}
export type CisSessionMessages = CisSessionMessage[];
export interface SendCisSessionTelemetryRequest {
    scanJobId: string;
    sessionToken: string;
    messages: CisSessionMessage[];
}
export interface SendCisSessionTelemetryResponse {
}
export interface StartCisSessionMessage {
    sessionToken: string;
}
export interface StartCisSessionRequest {
    scanJobId: string;
    message: StartCisSessionMessage;
}
export interface StartCisSessionResponse {
}
export type CodeSecurityClientToken = string;
export interface StartCodeSecurityScanRequest {
    clientToken?: string | undefined;
    resource: CodeSecurityResource;
}
export interface StartCodeSecurityScanResponse {
    scanId?: string | undefined;
    status?: CodeScanStatus | undefined;
}
export interface StartOnDemandScanRequest {
    resourceId: string;
    resourceType: OnDemandResourceType;
    clientToken?: string | undefined;
}
export interface StartOnDemandScanResponse {
    scanId: string;
}
export type StopCisSessionStatus = "SUCCESS" | "FAILED" | "INTERRUPTED" | "UNSUPPORTED_OS" | (string & {});
export type Reason = string;
export type CheckCount = number;
export interface StopCisMessageProgress {
    totalChecks?: number | undefined;
    successfulChecks?: number | undefined;
    failedChecks?: number | undefined;
    notEvaluatedChecks?: number | undefined;
    unknownChecks?: number | undefined;
    notApplicableChecks?: number | undefined;
    informationalChecks?: number | undefined;
    errorChecks?: number | undefined;
}
export type Vendor = string;
export type Product = string;
export type PlatformVersion = string;
export interface ComputePlatform {
    vendor?: string | undefined;
    product?: string | undefined;
    version?: string | undefined;
}
export type BenchmarkVersion = string;
export type BenchmarkProfile = string;
export interface StopCisSessionMessage {
    status: StopCisSessionStatus;
    reason?: string | undefined;
    progress: StopCisMessageProgress;
    computePlatform?: ComputePlatform | undefined;
    benchmarkVersion?: string | undefined;
    benchmarkProfile?: string | undefined;
}
export interface StopCisSessionRequest {
    scanJobId: string;
    sessionToken: string;
    message: StopCisSessionMessage;
}
export interface StopCisSessionResponse {
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKey = string;
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCisTargets {
    accountIds?: string[] | undefined;
    targetResourceTags?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface UpdateCisScanConfigurationRequest {
    scanConfigurationArn: string;
    scanName?: string | undefined;
    securityLevel?: CisSecurityLevel | undefined;
    schedule?: Schedule | undefined;
    targets?: UpdateCisTargets | undefined;
}
export interface UpdateCisScanConfigurationResponse {
    scanConfigurationArn: string;
}
export type GitLabAuthCode = string | redacted.Redacted<string>;
export interface UpdateGitLabSelfManagedIntegrationDetail {
    authCode: string | redacted.Redacted<string>;
}
export type GitHubAuthCode = string | redacted.Redacted<string>;
export type GitHubInstallationId = string;
export interface UpdateGitHubIntegrationDetail {
    code: string | redacted.Redacted<string>;
    installationId: string;
}
export type UpdateIntegrationDetails = {
    gitlabSelfManaged: UpdateGitLabSelfManagedIntegrationDetail;
    github?: undefined;
} | {
    gitlabSelfManaged?: undefined;
    github: UpdateGitHubIntegrationDetail;
};
export interface UpdateCodeSecurityIntegrationRequest {
    integrationArn: string;
    details: UpdateIntegrationDetails;
}
export interface UpdateCodeSecurityIntegrationResponse {
    integrationArn: string;
    status: IntegrationStatus;
}
export interface UpdateCodeSecurityScanConfigurationRequest {
    scanConfigurationArn: string;
    configuration: CodeSecurityScanConfiguration;
}
export interface UpdateCodeSecurityScanConfigurationResponse {
    scanConfigurationArn?: string | undefined;
}
export interface EcrConfiguration {
    rescanDuration: string;
    pullDateRescanDuration?: string | undefined;
    pullDateRescanMode?: string | undefined;
}
export interface Ec2Configuration {
    scanMode: string;
    activateVMScanner?: boolean | undefined;
}
export interface AmiConfiguration {
    lastLaunchedWithin?: string | undefined;
    createdWithin?: string | undefined;
    scanModeConfiguration: AmiScanModeConfiguration;
}
export type InheritanceMode = string;
export interface UpdateConfigurationInheritance {
    ec2Configuration?: string | undefined;
    ecrConfiguration?: string | undefined;
    amiConfiguration?: string | undefined;
}
export interface UpdateConfigurationRequest {
    accountId?: string | undefined;
    ecrConfiguration?: EcrConfiguration | undefined;
    ec2Configuration?: Ec2Configuration | undefined;
    amiConfiguration?: AmiConfiguration | undefined;
    updateConfigurationInheritance?: UpdateConfigurationInheritance | undefined;
}
export interface UpdateConfigurationResponse {
}
export interface AzureProviderDetailUpdate {
    azureRegions?: string[] | undefined;
    scopeConfiguration?: AzureScopeConfigurationInput | undefined;
    autoInstallVMScanner?: boolean | undefined;
}
export type ProviderDetailUpdate = {
    azure: AzureProviderDetailUpdate;
};
export interface UpdateConnectorRequest {
    connectorArn: string;
    description?: string | undefined;
    providerDetail?: ProviderDetailUpdate | undefined;
}
export interface UpdateConnectorResponse {
    connectorArn?: string | undefined;
}
export interface UpdateConnectorScanConfigurationRequest {
    awsConfigConnectorArn: string;
    scanConfiguration: ConnectorScanConfiguration;
}
export interface UpdateConnectorScanConfigurationResponse {
}
export interface UpdateEc2DeepInspectionConfigurationRequest {
    activateDeepInspection?: boolean | undefined;
    packagePaths?: string[] | undefined;
}
export interface UpdateEc2DeepInspectionConfigurationResponse {
    packagePaths?: string[] | undefined;
    orgPackagePaths?: string[] | undefined;
    status?: string | undefined;
    errorMessage?: string | undefined;
}
export interface UpdateEncryptionKeyRequest {
    kmsKeyId: string;
    scanType: string;
    resourceType: string;
}
export interface UpdateEncryptionKeyResponse {
}
export interface UpdateFilterRequest {
    action?: string | undefined;
    description?: string | undefined;
    filterCriteria?: FilterCriteria | undefined;
    name?: string | undefined;
    filterArn: string;
    reason?: string | undefined;
}
export interface UpdateFilterResponse {
    arn: string;
}
export interface UpdateOrganizationConfigurationRequest {
    autoEnable: AutoEnable;
}
export interface UpdateOrganizationConfigurationResponse {
    autoEnable: AutoEnable;
}
export interface UpdateOrgEc2DeepInspectionConfigurationRequest {
    orgPackagePaths: string[];
}
export interface UpdateOrgEc2DeepInspectionConfigurationResponse {
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFields = ValidationExceptionField[];
export type AssociateMemberError = AccessDeniedException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an Amazon Web Services account with an Amazon Inspector delegated administrator. An HTTP 200 response indicates the association was successfully started, but doesn't indicate whether it was completed. You can check if the association completed by using ListMembers for multiple accounts or GetMembers for a single account.
 */
export declare const associateMember: API.OperationMethod<AssociateMemberRequest & RegionInput, AssociateMemberResponse, AssociateMemberError, Credentials | HttpClient.HttpClient>;
export type BatchAssociateCodeSecurityScanConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates multiple code repositories with an Amazon Inspector code security scan configuration.
 */
export declare const batchAssociateCodeSecurityScanConfiguration: API.OperationMethod<BatchAssociateCodeSecurityScanConfigurationRequest & RegionInput, BatchAssociateCodeSecurityScanConfigurationResponse, BatchAssociateCodeSecurityScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type BatchDisassociateCodeSecurityScanConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates multiple code repositories from an Amazon Inspector code security scan configuration.
 */
export declare const batchDisassociateCodeSecurityScanConfiguration: API.OperationMethod<BatchDisassociateCodeSecurityScanConfigurationRequest & RegionInput, BatchDisassociateCodeSecurityScanConfigurationResponse, BatchDisassociateCodeSecurityScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type BatchGetAccountStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the Amazon Inspector status of multiple Amazon Web Services accounts within your environment.
 */
export declare const batchGetAccountStatus: API.OperationMethod<BatchGetAccountStatusRequest & RegionInput, BatchGetAccountStatusResponse, BatchGetAccountStatusError, Credentials | HttpClient.HttpClient>;
export type BatchGetCodeSnippetError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves code snippets from findings that Amazon Inspector detected code vulnerabilities in.
 */
export declare const batchGetCodeSnippet: API.OperationMethod<BatchGetCodeSnippetRequest & RegionInput, BatchGetCodeSnippetResponse, BatchGetCodeSnippetError, Credentials | HttpClient.HttpClient>;
export type BatchGetFindingDetailsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets vulnerability details for findings.
 */
export declare const batchGetFindingDetails: API.OperationMethod<BatchGetFindingDetailsRequest & RegionInput, BatchGetFindingDetailsResponse, BatchGetFindingDetailsError, Credentials | HttpClient.HttpClient>;
export type BatchGetFreeTrialInfoError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets free trial status for multiple Amazon Web Services accounts.
 */
export declare const batchGetFreeTrialInfo: API.OperationMethod<BatchGetFreeTrialInfoRequest & RegionInput, BatchGetFreeTrialInfoResponse, BatchGetFreeTrialInfoError, Credentials | HttpClient.HttpClient>;
export type BatchGetMemberEc2DeepInspectionStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves Amazon Inspector deep inspection activation status of multiple member accounts within your organization. You must be the delegated administrator of an organization in Amazon Inspector to use this API.
 */
export declare const batchGetMemberEc2DeepInspectionStatus: API.OperationMethod<BatchGetMemberEc2DeepInspectionStatusRequest & RegionInput, BatchGetMemberEc2DeepInspectionStatusResponse, BatchGetMemberEc2DeepInspectionStatusError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateMemberEc2DeepInspectionStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Activates or deactivates Amazon Inspector deep inspection for the provided member accounts in your organization. You must be the delegated administrator of an organization in Amazon Inspector to use this API.
 */
export declare const batchUpdateMemberEc2DeepInspectionStatus: API.OperationMethod<BatchUpdateMemberEc2DeepInspectionStatusRequest & RegionInput, BatchUpdateMemberEc2DeepInspectionStatusResponse, BatchUpdateMemberEc2DeepInspectionStatusError, Credentials | HttpClient.HttpClient>;
export type CancelFindingsReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels the given findings report.
 */
export declare const cancelFindingsReport: API.OperationMethod<CancelFindingsReportRequest & RegionInput, CancelFindingsReportResponse, CancelFindingsReportError, Credentials | HttpClient.HttpClient>;
export type CancelSbomExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a software bill of materials (SBOM) report.
 */
export declare const cancelSbomExport: API.OperationMethod<CancelSbomExportRequest & RegionInput, CancelSbomExportResponse, CancelSbomExportError, Credentials | HttpClient.HttpClient>;
export type CreateCisScanConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a CIS scan configuration.
 */
export declare const createCisScanConfiguration: API.OperationMethod<CreateCisScanConfigurationRequest & RegionInput, CreateCisScanConfigurationResponse, CreateCisScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateCodeSecurityIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a code security integration with a source code repository provider.
 *
 * After calling the `CreateCodeSecurityIntegration` operation, you complete authentication and authorization with your provider. Next you call the `UpdateCodeSecurityIntegration` operation to provide the `details` to complete the integration setup
 */
export declare const createCodeSecurityIntegration: API.OperationMethod<CreateCodeSecurityIntegrationRequest & RegionInput, CreateCodeSecurityIntegrationResponse, CreateCodeSecurityIntegrationError, Credentials | HttpClient.HttpClient>;
export type CreateCodeSecurityScanConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scan configuration for code security scanning.
 */
export declare const createCodeSecurityScanConfiguration: API.OperationMethod<CreateCodeSecurityScanConfigurationRequest & RegionInput, CreateCodeSecurityScanConfigurationResponse, CreateCodeSecurityScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connector that links an external cloud provider to Amazon Inspector for vulnerability scanning.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest & RegionInput, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateFilterError = AccessDeniedException | BadRequestException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a filter resource using specified filter criteria. When the filter action is set to `SUPPRESS` this action creates a suppression rule.
 */
export declare const createFilter: API.OperationMethod<CreateFilterRequest & RegionInput, CreateFilterResponse, CreateFilterError, Credentials | HttpClient.HttpClient>;
export type CreateFindingsReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a finding report. By default only `ACTIVE` findings are returned in the report. To see `SUPRESSED` or `CLOSED` findings you must specify a value for the `findingStatus` filter criteria.
 */
export declare const createFindingsReport: API.OperationMethod<CreateFindingsReportRequest & RegionInput, CreateFindingsReportResponse, CreateFindingsReportError, Credentials | HttpClient.HttpClient>;
export type CreateSbomExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a software bill of materials (SBOM) report.
 */
export declare const createSbomExport: API.OperationMethod<CreateSbomExportRequest & RegionInput, CreateSbomExportResponse, CreateSbomExportError, Credentials | HttpClient.HttpClient>;
export type DeleteCisScanConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a CIS scan configuration.
 */
export declare const deleteCisScanConfiguration: API.OperationMethod<DeleteCisScanConfigurationRequest & RegionInput, DeleteCisScanConfigurationResponse, DeleteCisScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteCodeSecurityIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a code security integration.
 */
export declare const deleteCodeSecurityIntegration: API.OperationMethod<DeleteCodeSecurityIntegrationRequest & RegionInput, DeleteCodeSecurityIntegrationResponse, DeleteCodeSecurityIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteCodeSecurityScanConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a code security scan configuration.
 */
export declare const deleteCodeSecurityScanConfiguration: API.OperationMethod<DeleteCodeSecurityScanConfigurationRequest & RegionInput, DeleteCodeSecurityScanConfigurationResponse, DeleteCodeSecurityScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connector from your account.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest & RegionInput, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteFilterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a filter resource.
 */
export declare const deleteFilter: API.OperationMethod<DeleteFilterRequest & RegionInput, DeleteFilterResponse, DeleteFilterError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describe Amazon Inspector configuration settings for an Amazon Web Services organization.
 */
export declare const describeOrganizationConfiguration: API.OperationMethod<DescribeOrganizationConfigurationRequest & RegionInput, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DisableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables Amazon Inspector scans for one or more Amazon Web Services accounts. Disabling all scan types in an account disables the Amazon Inspector service.
 */
export declare const disable: API.OperationMethod<DisableRequest & RegionInput, DisableResponse, DisableError, Credentials | HttpClient.HttpClient>;
export type DisableDelegatedAdminAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables the Amazon Inspector delegated administrator for your organization.
 */
export declare const disableDelegatedAdminAccount: API.OperationMethod<DisableDelegatedAdminAccountRequest & RegionInput, DisableDelegatedAdminAccountResponse, DisableDelegatedAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMemberError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates a member account from an Amazon Inspector delegated administrator.
 */
export declare const disassociateMember: API.OperationMethod<DisassociateMemberRequest & RegionInput, DisassociateMemberResponse, DisassociateMemberError, Credentials | HttpClient.HttpClient>;
export type EnableError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables Amazon Inspector scans for one or more Amazon Web Services accounts.
 */
export declare const enable: API.OperationMethod<EnableRequest & RegionInput, EnableResponse, EnableError, Credentials | HttpClient.HttpClient>;
export type EnableDelegatedAdminAccountError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables the Amazon Inspector delegated administrator for your Organizations organization.
 */
export declare const enableDelegatedAdminAccount: API.OperationMethod<EnableDelegatedAdminAccountRequest & RegionInput, EnableDelegatedAdminAccountResponse, EnableDelegatedAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetCisScanReportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a CIS scan report.
 */
export declare const getCisScanReport: API.OperationMethod<GetCisScanReportRequest & RegionInput, GetCisScanReportResponse, GetCisScanReportError, Credentials | HttpClient.HttpClient>;
export type GetCisScanResultDetailsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves CIS scan result details.
 */
export declare const getCisScanResultDetails: API.PaginatedOperationMethod<GetCisScanResultDetailsRequest & RegionInput, GetCisScanResultDetailsResponse, GetCisScanResultDetailsError, Credentials | HttpClient.HttpClient, CisScanResultDetails>;
export type GetClustersForImageError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of clusters and metadata associated with an image.
 */
export declare const getClustersForImage: API.PaginatedOperationMethod<GetClustersForImageRequest & RegionInput, GetClustersForImageResponse, GetClustersForImageError, Credentials | HttpClient.HttpClient, ClusterInformation>;
export type GetCodeSecurityIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a code security integration.
 */
export declare const getCodeSecurityIntegration: API.OperationMethod<GetCodeSecurityIntegrationRequest & RegionInput, GetCodeSecurityIntegrationResponse, GetCodeSecurityIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetCodeSecurityScanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specific code security scan.
 */
export declare const getCodeSecurityScan: API.OperationMethod<GetCodeSecurityScanRequest & RegionInput, GetCodeSecurityScanResponse, GetCodeSecurityScanError, Credentials | HttpClient.HttpClient>;
export type GetCodeSecurityScanConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a code security scan configuration.
 */
export declare const getCodeSecurityScanConfiguration: API.OperationMethod<GetCodeSecurityScanConfigurationRequest & RegionInput, GetCodeSecurityScanConfigurationResponse, GetCodeSecurityScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves setting configurations for Amazon Inspector scans. If you specify an `accountId`, this operation returns the scan configuration for that member account. You must be the delegated administrator for the specified member account. If you do not specify an `accountId`, this operation returns your own scan configuration.
 */
export declare const getConfiguration: API.OperationMethod<GetConfigurationRequest & RegionInput, GetConfigurationResponse, GetConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDelegatedAdminAccountError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the Amazon Inspector delegated administrator for your organization.
 */
export declare const getDelegatedAdminAccount: API.OperationMethod<GetDelegatedAdminAccountRequest & RegionInput, GetDelegatedAdminAccountResponse, GetDelegatedAdminAccountError, Credentials | HttpClient.HttpClient>;
export type GetEc2DeepInspectionConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the activation status of Amazon Inspector deep inspection and custom paths associated with your account.
 */
export declare const getEc2DeepInspectionConfiguration: API.OperationMethod<GetEc2DeepInspectionConfigurationRequest & RegionInput, GetEc2DeepInspectionConfigurationResponse, GetEc2DeepInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetEncryptionKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets an encryption key.
 */
export declare const getEncryptionKey: API.OperationMethod<GetEncryptionKeyRequest & RegionInput, GetEncryptionKeyResponse, GetEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type GetFindingsReportStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the status of a findings report.
 */
export declare const getFindingsReportStatus: API.OperationMethod<GetFindingsReportStatusRequest & RegionInput, GetFindingsReportStatusResponse, GetFindingsReportStatusError, Credentials | HttpClient.HttpClient>;
export type GetMemberError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets member information for your organization.
 */
export declare const getMember: API.OperationMethod<GetMemberRequest & RegionInput, GetMemberResponse, GetMemberError, Credentials | HttpClient.HttpClient>;
export type GetOnDemandScanStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the status of a specific on-demand scan for a resource.
 */
export declare const getOnDemandScanStatus: API.OperationMethod<GetOnDemandScanStatusRequest & RegionInput, GetOnDemandScanStatusResponse, GetOnDemandScanStatusError, Credentials | HttpClient.HttpClient>;
export type GetSbomExportError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets details of a software bill of materials (SBOM) report.
 */
export declare const getSbomExport: API.OperationMethod<GetSbomExportRequest & RegionInput, GetSbomExportResponse, GetSbomExportError, Credentials | HttpClient.HttpClient>;
export type ListAccountPermissionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the permissions an account has to configure Amazon Inspector. If the account is a member account or standalone account with resources managed by an Organizations policy, the operation returns fewer permissions.
 */
export declare const listAccountPermissions: API.PaginatedOperationMethod<ListAccountPermissionsRequest & RegionInput, ListAccountPermissionsResponse, ListAccountPermissionsError, Credentials | HttpClient.HttpClient, Permission>;
export type ListCisScanConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists CIS scan configurations.
 */
export declare const listCisScanConfigurations: API.PaginatedOperationMethod<ListCisScanConfigurationsRequest & RegionInput, ListCisScanConfigurationsResponse, ListCisScanConfigurationsError, Credentials | HttpClient.HttpClient, CisScanConfiguration>;
export type ListCisScanResultsAggregatedByChecksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists scan results aggregated by checks.
 */
export declare const listCisScanResultsAggregatedByChecks: API.PaginatedOperationMethod<ListCisScanResultsAggregatedByChecksRequest & RegionInput, ListCisScanResultsAggregatedByChecksResponse, ListCisScanResultsAggregatedByChecksError, Credentials | HttpClient.HttpClient, CisCheckAggregation>;
export type ListCisScanResultsAggregatedByTargetResourceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists scan results aggregated by a target resource.
 */
export declare const listCisScanResultsAggregatedByTargetResource: API.PaginatedOperationMethod<ListCisScanResultsAggregatedByTargetResourceRequest & RegionInput, ListCisScanResultsAggregatedByTargetResourceResponse, ListCisScanResultsAggregatedByTargetResourceError, Credentials | HttpClient.HttpClient, CisTargetResourceAggregation>;
export type ListCisScansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a CIS scan list.
 */
export declare const listCisScans: API.PaginatedOperationMethod<ListCisScansRequest & RegionInput, ListCisScansResponse, ListCisScansError, Credentials | HttpClient.HttpClient, CisScan>;
export type ListCodeSecurityIntegrationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all code security integrations in your account.
 */
export declare const listCodeSecurityIntegrations: API.OperationMethod<ListCodeSecurityIntegrationsRequest & RegionInput, ListCodeSecurityIntegrationsResponse, ListCodeSecurityIntegrationsError, Credentials | HttpClient.HttpClient>;
export type ListCodeSecurityScanConfigurationAssociationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the associations between code repositories and Amazon Inspector code security scan configurations.
 */
export declare const listCodeSecurityScanConfigurationAssociations: API.OperationMethod<ListCodeSecurityScanConfigurationAssociationsRequest & RegionInput, ListCodeSecurityScanConfigurationAssociationsResponse, ListCodeSecurityScanConfigurationAssociationsError, Credentials | HttpClient.HttpClient>;
export type ListCodeSecurityScanConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all code security scan configurations in your account.
 */
export declare const listCodeSecurityScanConfigurations: API.OperationMethod<ListCodeSecurityScanConfigurationsRequest & RegionInput, ListCodeSecurityScanConfigurationsResponse, ListCodeSecurityScanConfigurationsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists connectors in your account. Results are paginated. Use the `nextToken` parameter to retrieve the next page of results.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest & RegionInput, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, Connector>;
export type ListConnectorScanConfigurationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists scan configurations for Amazon Web Services Config connectors. Results are paginated. Use the `nextToken` parameter to retrieve the next page of results.
 */
export declare const listConnectorScanConfigurations: API.PaginatedOperationMethod<ListConnectorScanConfigurationsRequest & RegionInput, ListConnectorScanConfigurationsResponse, ListConnectorScanConfigurationsError, Credentials | HttpClient.HttpClient, ConnectorScanConfigurationItem>;
export type ListCoverageError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists coverage details for your environment.
 */
export declare const listCoverage: API.PaginatedOperationMethod<ListCoverageRequest & RegionInput, ListCoverageResponse, ListCoverageError, Credentials | HttpClient.HttpClient, CoveredResource>;
export type ListCoverageStatisticsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Inspector coverage statistics for your environment.
 */
export declare const listCoverageStatistics: API.PaginatedOperationMethod<ListCoverageStatisticsRequest & RegionInput, ListCoverageStatisticsResponse, ListCoverageStatisticsError, Credentials | HttpClient.HttpClient, Counts>;
export type ListDelegatedAdminAccountsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists information about the Amazon Inspector delegated administrator of your organization.
 */
export declare const listDelegatedAdminAccounts: API.PaginatedOperationMethod<ListDelegatedAdminAccountsRequest & RegionInput, ListDelegatedAdminAccountsResponse, ListDelegatedAdminAccountsError, Credentials | HttpClient.HttpClient, DelegatedAdminAccount>;
export type ListFiltersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the filters associated with your account.
 */
export declare const listFilters: API.PaginatedOperationMethod<ListFiltersRequest & RegionInput, ListFiltersResponse, ListFiltersError, Credentials | HttpClient.HttpClient, Filter>;
export type ListFindingAggregationsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists aggregated finding data for your environment based on specific criteria.
 */
export declare const listFindingAggregations: API.PaginatedOperationMethod<ListFindingAggregationsRequest & RegionInput, ListFindingAggregationsResponse, ListFindingAggregationsError, Credentials | HttpClient.HttpClient, AggregationResponse>;
export type ListFindingsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists findings for your environment.
 */
export declare const listFindings: API.PaginatedOperationMethod<ListFindingsRequest & RegionInput, ListFindingsResponse, ListFindingsError, Credentials | HttpClient.HttpClient, Finding>;
export type ListMembersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List members associated with the Amazon Inspector delegated administrator for your organization.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest & RegionInput, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListOnDemandScansError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the on-demand scans for a resource.
 */
export declare const listOnDemandScans: API.PaginatedOperationMethod<ListOnDemandScansRequest & RegionInput, ListOnDemandScansResponse, ListOnDemandScansError, Credentials | HttpClient.HttpClient, OnDemandScan>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags attached to a given resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListUsageTotalsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Inspector usage totals over the last 30 days.
 */
export declare const listUsageTotals: API.PaginatedOperationMethod<ListUsageTotalsRequest & RegionInput, ListUsageTotalsResponse, ListUsageTotalsError, Credentials | HttpClient.HttpClient, UsageTotal>;
export type ResetEncryptionKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Resets an encryption key. After the key is reset your resources will be encrypted by an Amazon Web Services owned key.
 */
export declare const resetEncryptionKey: API.OperationMethod<ResetEncryptionKeyRequest & RegionInput, ResetEncryptionKeyResponse, ResetEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type SearchVulnerabilitiesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Inspector coverage details for a specific vulnerability.
 */
export declare const searchVulnerabilities: API.PaginatedOperationMethod<SearchVulnerabilitiesRequest & RegionInput, SearchVulnerabilitiesResponse, SearchVulnerabilitiesError, Credentials | HttpClient.HttpClient, Vulnerability>;
export type SendCisSessionHealthError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a CIS session health. This API is used by the Amazon Inspector SSM plugin to communicate with the Amazon Inspector service. The Amazon Inspector SSM plugin calls this API to start a CIS scan session for the scan ID supplied by the service.
 */
export declare const sendCisSessionHealth: API.OperationMethod<SendCisSessionHealthRequest & RegionInput, SendCisSessionHealthResponse, SendCisSessionHealthError, Credentials | HttpClient.HttpClient>;
export type SendCisSessionTelemetryError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sends a CIS session telemetry. This API is used by the Amazon Inspector SSM plugin to communicate with the Amazon Inspector service. The Amazon Inspector SSM plugin calls this API to start a CIS scan session for the scan ID supplied by the service.
 */
export declare const sendCisSessionTelemetry: API.OperationMethod<SendCisSessionTelemetryRequest & RegionInput, SendCisSessionTelemetryResponse, SendCisSessionTelemetryError, Credentials | HttpClient.HttpClient>;
export type StartCisSessionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a CIS session. This API is used by the Amazon Inspector SSM plugin to communicate with the Amazon Inspector service. The Amazon Inspector SSM plugin calls this API to start a CIS scan session for the scan ID supplied by the service.
 */
export declare const startCisSession: API.OperationMethod<StartCisSessionRequest & RegionInput, StartCisSessionResponse, StartCisSessionError, Credentials | HttpClient.HttpClient>;
export type StartCodeSecurityScanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a code security scan on a specified repository.
 */
export declare const startCodeSecurityScan: API.OperationMethod<StartCodeSecurityScanRequest & RegionInput, StartCodeSecurityScanResponse, StartCodeSecurityScanError, Credentials | HttpClient.HttpClient>;
export type StartOnDemandScanError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an on-demand scan of the specified resource, such as an Amazon Machine Image (AMI).
 */
export declare const startOnDemandScan: API.OperationMethod<StartOnDemandScanRequest & RegionInput, StartOnDemandScanResponse, StartOnDemandScanError, Credentials | HttpClient.HttpClient>;
export type StopCisSessionError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a CIS session. This API is used by the Amazon Inspector SSM plugin to communicate with the Amazon Inspector service. The Amazon Inspector SSM plugin calls this API to stop a CIS scan session for the scan ID supplied by the service.
 */
export declare const stopCisSession: API.OperationMethod<StopCisSessionRequest & RegionInput, StopCisSessionResponse, StopCisSessionError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCisScanConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a CIS scan configuration.
 */
export declare const updateCisScanConfiguration: API.OperationMethod<UpdateCisScanConfigurationRequest & RegionInput, UpdateCisScanConfigurationResponse, UpdateCisScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateCodeSecurityIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing code security integration.
 *
 * After calling the `CreateCodeSecurityIntegration` operation, you complete authentication and authorization with your provider. Next you call the `UpdateCodeSecurityIntegration` operation to provide the `details` to complete the integration setup
 */
export declare const updateCodeSecurityIntegration: API.OperationMethod<UpdateCodeSecurityIntegrationRequest & RegionInput, UpdateCodeSecurityIntegrationResponse, UpdateCodeSecurityIntegrationError, Credentials | HttpClient.HttpClient>;
export type UpdateCodeSecurityScanConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing code security scan configuration.
 */
export declare const updateCodeSecurityScanConfiguration: API.OperationMethod<UpdateCodeSecurityScanConfigurationRequest & RegionInput, UpdateCodeSecurityScanConfigurationResponse, UpdateCodeSecurityScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the scan configuration for your Amazon Inspector account. If you don't specify an `accountId`, this operation updates the delegated administrator's configuration and propagates it to member accounts that have not been individually configured. If you specify an `accountId`, this operation updates that member account's configuration. Only the delegated administrator can specify an `accountId`; member accounts cannot call this operation.
 */
export declare const updateConfiguration: API.OperationMethod<UpdateConfigurationRequest & RegionInput, UpdateConfigurationResponse, UpdateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the description or provider-specific configuration details of an existing connector.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest & RegionInput, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorScanConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates scan configuration settings for resources associated with an Amazon Web Services Config connector.
 */
export declare const updateConnectorScanConfiguration: API.OperationMethod<UpdateConnectorScanConfigurationRequest & RegionInput, UpdateConnectorScanConfigurationResponse, UpdateConnectorScanConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateEc2DeepInspectionConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Activates, deactivates Amazon Inspector deep inspection, or updates custom paths for your account.
 */
export declare const updateEc2DeepInspectionConfiguration: API.OperationMethod<UpdateEc2DeepInspectionConfigurationRequest & RegionInput, UpdateEc2DeepInspectionConfigurationResponse, UpdateEc2DeepInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateEncryptionKeyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an encryption key. A `ResourceNotFoundException` means that an Amazon Web Services owned key is being used for encryption.
 */
export declare const updateEncryptionKey: API.OperationMethod<UpdateEncryptionKeyRequest & RegionInput, UpdateEncryptionKeyResponse, UpdateEncryptionKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateFilterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Specifies the action that is to be applied to the findings that match the filter.
 */
export declare const updateFilter: API.OperationMethod<UpdateFilterRequest & RegionInput, UpdateFilterResponse, UpdateFilterError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the configurations for your Amazon Inspector organization.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest & RegionInput, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateOrgEc2DeepInspectionConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the Amazon Inspector deep inspection custom paths for your organization. You must be an Amazon Inspector delegated administrator to use this API.
 */
export declare const updateOrgEc2DeepInspectionConfiguration: API.OperationMethod<UpdateOrgEc2DeepInspectionConfigurationRequest & RegionInput, UpdateOrgEc2DeepInspectionConfigurationResponse, UpdateOrgEc2DeepInspectionConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=inspector2.d.ts.map