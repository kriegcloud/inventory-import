import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BatchWriteException_base: S.TaggedErrorClass<"BatchWriteException", {
    readonly Index: any;
    readonly Type: any;
    readonly message: any;
}>;
export declare class BatchWriteException extends /*@__PURE__*/ BatchWriteException_base {
}
declare const CannotListParentOfRootException_base: S.TaggedErrorClass<"CannotListParentOfRootException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CannotListParentOfRootException extends /*@__PURE__*/ CannotListParentOfRootException_base {
}
declare const DirectoryAlreadyExistsException_base: S.TaggedErrorClass<"DirectoryAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DirectoryAlreadyExistsException extends /*@__PURE__*/ DirectoryAlreadyExistsException_base {
}
declare const DirectoryDeletedException_base: S.TaggedErrorClass<"DirectoryDeletedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DirectoryDeletedException extends /*@__PURE__*/ DirectoryDeletedException_base {
}
declare const DirectoryNotDisabledException_base: S.TaggedErrorClass<"DirectoryNotDisabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DirectoryNotDisabledException extends /*@__PURE__*/ DirectoryNotDisabledException_base {
}
declare const DirectoryNotEnabledException_base: S.TaggedErrorClass<"DirectoryNotEnabledException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DirectoryNotEnabledException extends /*@__PURE__*/ DirectoryNotEnabledException_base {
}
declare const FacetAlreadyExistsException_base: S.TaggedErrorClass<"FacetAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class FacetAlreadyExistsException extends /*@__PURE__*/ FacetAlreadyExistsException_base {
}
declare const FacetInUseException_base: S.TaggedErrorClass<"FacetInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FacetInUseException extends /*@__PURE__*/ FacetInUseException_base {
}
declare const FacetNotFoundException_base: S.TaggedErrorClass<"FacetNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FacetNotFoundException extends /*@__PURE__*/ FacetNotFoundException_base {
}
declare const FacetValidationException_base: S.TaggedErrorClass<"FacetValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class FacetValidationException extends /*@__PURE__*/ FacetValidationException_base {
}
declare const IncompatibleSchemaException_base: S.TaggedErrorClass<"IncompatibleSchemaException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IncompatibleSchemaException extends /*@__PURE__*/ IncompatibleSchemaException_base {
}
declare const IndexedAttributeMissingException_base: S.TaggedErrorClass<"IndexedAttributeMissingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class IndexedAttributeMissingException extends /*@__PURE__*/ IndexedAttributeMissingException_base {
}
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
declare const InvalidArnException_base: S.TaggedErrorClass<"InvalidArnException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidArnException extends /*@__PURE__*/ InvalidArnException_base {
}
declare const InvalidAttachmentException_base: S.TaggedErrorClass<"InvalidAttachmentException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidAttachmentException extends /*@__PURE__*/ InvalidAttachmentException_base {
}
declare const InvalidFacetUpdateException_base: S.TaggedErrorClass<"InvalidFacetUpdateException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidFacetUpdateException extends /*@__PURE__*/ InvalidFacetUpdateException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidRuleException_base: S.TaggedErrorClass<"InvalidRuleException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRuleException extends /*@__PURE__*/ InvalidRuleException_base {
}
declare const InvalidSchemaDocException_base: S.TaggedErrorClass<"InvalidSchemaDocException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSchemaDocException extends /*@__PURE__*/ InvalidSchemaDocException_base {
}
declare const InvalidTaggingRequestException_base: S.TaggedErrorClass<"InvalidTaggingRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidTaggingRequestException extends /*@__PURE__*/ InvalidTaggingRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const LinkNameAlreadyInUseException_base: S.TaggedErrorClass<"LinkNameAlreadyInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LinkNameAlreadyInUseException extends /*@__PURE__*/ LinkNameAlreadyInUseException_base {
}
declare const NotIndexException_base: S.TaggedErrorClass<"NotIndexException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotIndexException extends /*@__PURE__*/ NotIndexException_base {
}
declare const NotNodeException_base: S.TaggedErrorClass<"NotNodeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotNodeException extends /*@__PURE__*/ NotNodeException_base {
}
declare const NotPolicyException_base: S.TaggedErrorClass<"NotPolicyException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotPolicyException extends /*@__PURE__*/ NotPolicyException_base {
}
declare const ObjectAlreadyDetachedException_base: S.TaggedErrorClass<"ObjectAlreadyDetachedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectAlreadyDetachedException extends /*@__PURE__*/ ObjectAlreadyDetachedException_base {
}
declare const ObjectNotDetachedException_base: S.TaggedErrorClass<"ObjectNotDetachedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ObjectNotDetachedException extends /*@__PURE__*/ ObjectNotDetachedException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const RetryableConflictException_base: S.TaggedErrorClass<"RetryableConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class RetryableConflictException extends /*@__PURE__*/ RetryableConflictException_base {
}
declare const SchemaAlreadyExistsException_base: S.TaggedErrorClass<"SchemaAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class SchemaAlreadyExistsException extends /*@__PURE__*/ SchemaAlreadyExistsException_base {
}
declare const SchemaAlreadyPublishedException_base: S.TaggedErrorClass<"SchemaAlreadyPublishedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SchemaAlreadyPublishedException extends /*@__PURE__*/ SchemaAlreadyPublishedException_base {
}
declare const StillContainsLinksException_base: S.TaggedErrorClass<"StillContainsLinksException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StillContainsLinksException extends /*@__PURE__*/ StillContainsLinksException_base {
}
declare const UnsupportedIndexTypeException_base: S.TaggedErrorClass<"UnsupportedIndexTypeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class UnsupportedIndexTypeException extends /*@__PURE__*/ UnsupportedIndexTypeException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Arn = string;
export type FacetName = string;
export interface SchemaFacet {
    SchemaArn?: string | undefined;
    FacetName?: string | undefined;
}
export type AttributeName = string;
export interface AttributeKey {
    SchemaArn: string;
    FacetName: string;
    Name: string;
}
export type StringAttributeValue = string;
export type BinaryAttributeValue = Uint8Array;
export type BooleanAttributeValue = boolean;
export type NumberAttributeValue = string;
export type DatetimeAttributeValue = Date;
export type TypedAttributeValue = {
    StringValue: string;
    BinaryValue?: undefined;
    BooleanValue?: undefined;
    NumberValue?: undefined;
    DatetimeValue?: undefined;
} | {
    StringValue?: undefined;
    BinaryValue: Uint8Array;
    BooleanValue?: undefined;
    NumberValue?: undefined;
    DatetimeValue?: undefined;
} | {
    StringValue?: undefined;
    BinaryValue?: undefined;
    BooleanValue: boolean;
    NumberValue?: undefined;
    DatetimeValue?: undefined;
} | {
    StringValue?: undefined;
    BinaryValue?: undefined;
    BooleanValue?: undefined;
    NumberValue: string;
    DatetimeValue?: undefined;
} | {
    StringValue?: undefined;
    BinaryValue?: undefined;
    BooleanValue?: undefined;
    NumberValue?: undefined;
    DatetimeValue: Date;
};
export interface AttributeKeyAndValue {
    Key: AttributeKey;
    Value: TypedAttributeValue;
}
export type AttributeKeyAndValueList = AttributeKeyAndValue[];
export type SelectorObjectReference = string;
export interface ObjectReference {
    Selector?: string | undefined;
}
export interface AddFacetToObjectRequest {
    DirectoryArn: string;
    SchemaFacet: SchemaFacet;
    ObjectAttributeList?: AttributeKeyAndValue[] | undefined;
    ObjectReference: ObjectReference;
}
export interface AddFacetToObjectResponse {
}
export interface ApplySchemaRequest {
    PublishedSchemaArn: string;
    DirectoryArn: string;
}
export interface ApplySchemaResponse {
    AppliedSchemaArn?: string | undefined;
    DirectoryArn?: string | undefined;
}
export type LinkName = string;
export interface AttachObjectRequest {
    DirectoryArn: string;
    ParentReference: ObjectReference;
    ChildReference: ObjectReference;
    LinkName: string;
}
export type ObjectIdentifier = string;
export interface AttachObjectResponse {
    AttachedObjectIdentifier?: string | undefined;
}
export interface AttachPolicyRequest {
    DirectoryArn: string;
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export interface AttachPolicyResponse {
}
export interface AttachToIndexRequest {
    DirectoryArn: string;
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export interface AttachToIndexResponse {
    AttachedObjectIdentifier?: string | undefined;
}
export type TypedLinkName = string;
export interface TypedLinkSchemaAndFacetName {
    SchemaArn: string;
    TypedLinkName: string;
}
export interface AttributeNameAndValue {
    AttributeName: string;
    Value: TypedAttributeValue;
}
export type AttributeNameAndValueList = AttributeNameAndValue[];
export interface AttachTypedLinkRequest {
    DirectoryArn: string;
    SourceObjectReference: ObjectReference;
    TargetObjectReference: ObjectReference;
    TypedLinkFacet: TypedLinkSchemaAndFacetName;
    Attributes: AttributeNameAndValue[];
}
export interface TypedLinkSpecifier {
    TypedLinkFacet: TypedLinkSchemaAndFacetName;
    SourceObjectReference: ObjectReference;
    TargetObjectReference: ObjectReference;
    IdentityAttributeValues: AttributeNameAndValue[];
}
export interface AttachTypedLinkResponse {
    TypedLinkSpecifier?: TypedLinkSpecifier | undefined;
}
export type NextToken = string;
export type NumberResults = number;
export interface BatchListObjectAttributes {
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    FacetFilter?: SchemaFacet | undefined;
}
export interface BatchListObjectChildren {
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchListAttachedIndices {
    TargetReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchListObjectParentPaths {
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchGetObjectInformation {
    ObjectReference: ObjectReference;
}
export type AttributeNameList = string[];
export interface BatchGetObjectAttributes {
    ObjectReference: ObjectReference;
    SchemaFacet: SchemaFacet;
    AttributeNames: string[];
}
export interface BatchListObjectParents {
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchListObjectPolicies {
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchListPolicyAttachments {
    PolicyReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchLookupPolicy {
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type RangeMode = "FIRST" | "LAST" | "LAST_BEFORE_MISSING_VALUES" | "INCLUSIVE" | "EXCLUSIVE" | (string & {});
export interface TypedAttributeValueRange {
    StartMode: RangeMode;
    StartValue?: TypedAttributeValue | undefined;
    EndMode: RangeMode;
    EndValue?: TypedAttributeValue | undefined;
}
export interface ObjectAttributeRange {
    AttributeKey?: AttributeKey | undefined;
    Range?: TypedAttributeValueRange | undefined;
}
export type ObjectAttributeRangeList = ObjectAttributeRange[];
export interface BatchListIndex {
    RangesOnIndexedValues?: ObjectAttributeRange[] | undefined;
    IndexReference: ObjectReference;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface TypedLinkAttributeRange {
    AttributeName?: string | undefined;
    Range: TypedAttributeValueRange;
}
export type TypedLinkAttributeRangeList = TypedLinkAttributeRange[];
export interface BatchListOutgoingTypedLinks {
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[] | undefined;
    FilterTypedLink?: TypedLinkSchemaAndFacetName | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchListIncomingTypedLinks {
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[] | undefined;
    FilterTypedLink?: TypedLinkSchemaAndFacetName | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface BatchGetLinkAttributes {
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeNames: string[];
}
export interface BatchReadOperation {
    ListObjectAttributes?: BatchListObjectAttributes | undefined;
    ListObjectChildren?: BatchListObjectChildren | undefined;
    ListAttachedIndices?: BatchListAttachedIndices | undefined;
    ListObjectParentPaths?: BatchListObjectParentPaths | undefined;
    GetObjectInformation?: BatchGetObjectInformation | undefined;
    GetObjectAttributes?: BatchGetObjectAttributes | undefined;
    ListObjectParents?: BatchListObjectParents | undefined;
    ListObjectPolicies?: BatchListObjectPolicies | undefined;
    ListPolicyAttachments?: BatchListPolicyAttachments | undefined;
    LookupPolicy?: BatchLookupPolicy | undefined;
    ListIndex?: BatchListIndex | undefined;
    ListOutgoingTypedLinks?: BatchListOutgoingTypedLinks | undefined;
    ListIncomingTypedLinks?: BatchListIncomingTypedLinks | undefined;
    GetLinkAttributes?: BatchGetLinkAttributes | undefined;
}
export type BatchReadOperationList = BatchReadOperation[];
export type ConsistencyLevel = "SERIALIZABLE" | "EVENTUAL" | (string & {});
export interface BatchReadRequest {
    DirectoryArn: string;
    Operations: BatchReadOperation[];
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface BatchListObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[] | undefined;
    NextToken?: string | undefined;
}
export type LinkNameToObjectIdentifierMap = {
    [key: string]: string | undefined;
};
export interface BatchListObjectChildrenResponse {
    Children?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
}
export type SchemaFacetList = SchemaFacet[];
export interface BatchGetObjectInformationResponse {
    SchemaFacets?: SchemaFacet[] | undefined;
    ObjectIdentifier?: string | undefined;
}
export interface BatchGetObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[] | undefined;
}
export interface IndexAttachment {
    IndexedAttributes?: AttributeKeyAndValue[] | undefined;
    ObjectIdentifier?: string | undefined;
}
export type IndexAttachmentList = IndexAttachment[];
export interface BatchListAttachedIndicesResponse {
    IndexAttachments?: IndexAttachment[] | undefined;
    NextToken?: string | undefined;
}
export type PathString = string;
export type ObjectIdentifierList = string[];
export interface PathToObjectIdentifiers {
    Path?: string | undefined;
    ObjectIdentifiers?: string[] | undefined;
}
export type PathToObjectIdentifiersList = PathToObjectIdentifiers[];
export interface BatchListObjectParentPathsResponse {
    PathToObjectIdentifiersList?: PathToObjectIdentifiers[] | undefined;
    NextToken?: string | undefined;
}
export interface BatchListObjectPoliciesResponse {
    AttachedPolicyIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface BatchListPolicyAttachmentsResponse {
    ObjectIdentifiers?: string[] | undefined;
    NextToken?: string | undefined;
}
export type PolicyType = string;
export interface PolicyAttachment {
    PolicyId?: string | undefined;
    ObjectIdentifier?: string | undefined;
    PolicyType?: string | undefined;
}
export type PolicyAttachmentList = PolicyAttachment[];
export interface PolicyToPath {
    Path?: string | undefined;
    Policies?: PolicyAttachment[] | undefined;
}
export type PolicyToPathList = PolicyToPath[];
export interface BatchLookupPolicyResponse {
    PolicyToPathList?: PolicyToPath[] | undefined;
    NextToken?: string | undefined;
}
export interface BatchListIndexResponse {
    IndexAttachments?: IndexAttachment[] | undefined;
    NextToken?: string | undefined;
}
export type TypedLinkSpecifierList = TypedLinkSpecifier[];
export interface BatchListOutgoingTypedLinksResponse {
    TypedLinkSpecifiers?: TypedLinkSpecifier[] | undefined;
    NextToken?: string | undefined;
}
export interface BatchListIncomingTypedLinksResponse {
    LinkSpecifiers?: TypedLinkSpecifier[] | undefined;
    NextToken?: string | undefined;
}
export interface BatchGetLinkAttributesResponse {
    Attributes?: AttributeKeyAndValue[] | undefined;
}
export interface ObjectIdentifierAndLinkNameTuple {
    ObjectIdentifier?: string | undefined;
    LinkName?: string | undefined;
}
export type ObjectIdentifierAndLinkNameList = ObjectIdentifierAndLinkNameTuple[];
export interface BatchListObjectParentsResponse {
    ParentLinks?: ObjectIdentifierAndLinkNameTuple[] | undefined;
    NextToken?: string | undefined;
}
export interface BatchReadSuccessfulResponse {
    ListObjectAttributes?: BatchListObjectAttributesResponse | undefined;
    ListObjectChildren?: BatchListObjectChildrenResponse | undefined;
    GetObjectInformation?: BatchGetObjectInformationResponse | undefined;
    GetObjectAttributes?: BatchGetObjectAttributesResponse | undefined;
    ListAttachedIndices?: BatchListAttachedIndicesResponse | undefined;
    ListObjectParentPaths?: BatchListObjectParentPathsResponse | undefined;
    ListObjectPolicies?: BatchListObjectPoliciesResponse | undefined;
    ListPolicyAttachments?: BatchListPolicyAttachmentsResponse | undefined;
    LookupPolicy?: BatchLookupPolicyResponse | undefined;
    ListIndex?: BatchListIndexResponse | undefined;
    ListOutgoingTypedLinks?: BatchListOutgoingTypedLinksResponse | undefined;
    ListIncomingTypedLinks?: BatchListIncomingTypedLinksResponse | undefined;
    GetLinkAttributes?: BatchGetLinkAttributesResponse | undefined;
    ListObjectParents?: BatchListObjectParentsResponse | undefined;
}
export type BatchReadExceptionType = "ValidationException" | "InvalidArnException" | "ResourceNotFoundException" | "InvalidNextTokenException" | "AccessDeniedException" | "NotNodeException" | "FacetValidationException" | "CannotListParentOfRootException" | "NotIndexException" | "NotPolicyException" | "DirectoryNotEnabledException" | "LimitExceededException" | "InternalServiceException" | (string & {});
export type ExceptionMessage = string;
export interface BatchReadException {
    Type?: BatchReadExceptionType | undefined;
    Message?: string | undefined;
}
export interface BatchReadOperationResponse {
    SuccessfulResponse?: BatchReadSuccessfulResponse | undefined;
    ExceptionResponse?: BatchReadException | undefined;
}
export type BatchReadOperationResponseList = BatchReadOperationResponse[];
export interface BatchReadResponse {
    Responses?: BatchReadOperationResponse[] | undefined;
}
export type BatchReferenceName = string;
export interface BatchCreateObject {
    SchemaFacet: SchemaFacet[];
    ObjectAttributeList: AttributeKeyAndValue[];
    ParentReference?: ObjectReference | undefined;
    LinkName?: string | undefined;
    BatchReferenceName?: string | undefined;
}
export interface BatchAttachObject {
    ParentReference: ObjectReference;
    ChildReference: ObjectReference;
    LinkName: string;
}
export interface BatchDetachObject {
    ParentReference: ObjectReference;
    LinkName: string;
    BatchReferenceName?: string | undefined;
}
export type UpdateActionType = "CREATE_OR_UPDATE" | "DELETE" | (string & {});
export interface ObjectAttributeAction {
    ObjectAttributeActionType?: UpdateActionType | undefined;
    ObjectAttributeUpdateValue?: TypedAttributeValue | undefined;
}
export interface ObjectAttributeUpdate {
    ObjectAttributeKey?: AttributeKey | undefined;
    ObjectAttributeAction?: ObjectAttributeAction | undefined;
}
export type ObjectAttributeUpdateList = ObjectAttributeUpdate[];
export interface BatchUpdateObjectAttributes {
    ObjectReference: ObjectReference;
    AttributeUpdates: ObjectAttributeUpdate[];
}
export interface BatchDeleteObject {
    ObjectReference: ObjectReference;
}
export interface BatchAddFacetToObject {
    SchemaFacet: SchemaFacet;
    ObjectAttributeList: AttributeKeyAndValue[];
    ObjectReference: ObjectReference;
}
export interface BatchRemoveFacetFromObject {
    SchemaFacet: SchemaFacet;
    ObjectReference: ObjectReference;
}
export interface BatchAttachPolicy {
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export interface BatchDetachPolicy {
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export type AttributeKeyList = AttributeKey[];
export interface BatchCreateIndex {
    OrderedIndexedAttributeList: AttributeKey[];
    IsUnique: boolean;
    ParentReference?: ObjectReference | undefined;
    LinkName?: string | undefined;
    BatchReferenceName?: string | undefined;
}
export interface BatchAttachToIndex {
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export interface BatchDetachFromIndex {
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export interface BatchAttachTypedLink {
    SourceObjectReference: ObjectReference;
    TargetObjectReference: ObjectReference;
    TypedLinkFacet: TypedLinkSchemaAndFacetName;
    Attributes: AttributeNameAndValue[];
}
export interface BatchDetachTypedLink {
    TypedLinkSpecifier: TypedLinkSpecifier;
}
export interface LinkAttributeAction {
    AttributeActionType?: UpdateActionType | undefined;
    AttributeUpdateValue?: TypedAttributeValue | undefined;
}
export interface LinkAttributeUpdate {
    AttributeKey?: AttributeKey | undefined;
    AttributeAction?: LinkAttributeAction | undefined;
}
export type LinkAttributeUpdateList = LinkAttributeUpdate[];
export interface BatchUpdateLinkAttributes {
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeUpdates: LinkAttributeUpdate[];
}
export interface BatchWriteOperation {
    CreateObject?: BatchCreateObject | undefined;
    AttachObject?: BatchAttachObject | undefined;
    DetachObject?: BatchDetachObject | undefined;
    UpdateObjectAttributes?: BatchUpdateObjectAttributes | undefined;
    DeleteObject?: BatchDeleteObject | undefined;
    AddFacetToObject?: BatchAddFacetToObject | undefined;
    RemoveFacetFromObject?: BatchRemoveFacetFromObject | undefined;
    AttachPolicy?: BatchAttachPolicy | undefined;
    DetachPolicy?: BatchDetachPolicy | undefined;
    CreateIndex?: BatchCreateIndex | undefined;
    AttachToIndex?: BatchAttachToIndex | undefined;
    DetachFromIndex?: BatchDetachFromIndex | undefined;
    AttachTypedLink?: BatchAttachTypedLink | undefined;
    DetachTypedLink?: BatchDetachTypedLink | undefined;
    UpdateLinkAttributes?: BatchUpdateLinkAttributes | undefined;
}
export type BatchWriteOperationList = BatchWriteOperation[];
export interface BatchWriteRequest {
    DirectoryArn: string;
    Operations: BatchWriteOperation[];
}
export interface BatchCreateObjectResponse {
    ObjectIdentifier?: string | undefined;
}
export interface BatchAttachObjectResponse {
    attachedObjectIdentifier?: string | undefined;
}
export interface BatchDetachObjectResponse {
    detachedObjectIdentifier?: string | undefined;
}
export interface BatchUpdateObjectAttributesResponse {
    ObjectIdentifier?: string | undefined;
}
export interface BatchDeleteObjectResponse {
}
export interface BatchAddFacetToObjectResponse {
}
export interface BatchRemoveFacetFromObjectResponse {
}
export interface BatchAttachPolicyResponse {
}
export interface BatchDetachPolicyResponse {
}
export interface BatchCreateIndexResponse {
    ObjectIdentifier?: string | undefined;
}
export interface BatchAttachToIndexResponse {
    AttachedObjectIdentifier?: string | undefined;
}
export interface BatchDetachFromIndexResponse {
    DetachedObjectIdentifier?: string | undefined;
}
export interface BatchAttachTypedLinkResponse {
    TypedLinkSpecifier?: TypedLinkSpecifier | undefined;
}
export interface BatchDetachTypedLinkResponse {
}
export interface BatchUpdateLinkAttributesResponse {
}
export interface BatchWriteOperationResponse {
    CreateObject?: BatchCreateObjectResponse | undefined;
    AttachObject?: BatchAttachObjectResponse | undefined;
    DetachObject?: BatchDetachObjectResponse | undefined;
    UpdateObjectAttributes?: BatchUpdateObjectAttributesResponse | undefined;
    DeleteObject?: BatchDeleteObjectResponse | undefined;
    AddFacetToObject?: BatchAddFacetToObjectResponse | undefined;
    RemoveFacetFromObject?: BatchRemoveFacetFromObjectResponse | undefined;
    AttachPolicy?: BatchAttachPolicyResponse | undefined;
    DetachPolicy?: BatchDetachPolicyResponse | undefined;
    CreateIndex?: BatchCreateIndexResponse | undefined;
    AttachToIndex?: BatchAttachToIndexResponse | undefined;
    DetachFromIndex?: BatchDetachFromIndexResponse | undefined;
    AttachTypedLink?: BatchAttachTypedLinkResponse | undefined;
    DetachTypedLink?: BatchDetachTypedLinkResponse | undefined;
    UpdateLinkAttributes?: BatchUpdateLinkAttributesResponse | undefined;
}
export type BatchWriteOperationResponseList = BatchWriteOperationResponse[];
export interface BatchWriteResponse {
    Responses?: BatchWriteOperationResponse[] | undefined;
}
export type DirectoryName = string;
export interface CreateDirectoryRequest {
    Name: string;
    SchemaArn: string;
}
export type DirectoryArn = string;
export interface CreateDirectoryResponse {
    DirectoryArn: string;
    Name: string;
    ObjectIdentifier: string;
    AppliedSchemaArn: string;
}
export type FacetAttributeType = "STRING" | "BINARY" | "BOOLEAN" | "NUMBER" | "DATETIME" | "VARIANT" | (string & {});
export type RuleKey = string;
export type RuleType = "BINARY_LENGTH" | "NUMBER_COMPARISON" | "STRING_FROM_SET" | "STRING_LENGTH" | (string & {});
export type RuleParameterKey = string;
export type RuleParameterValue = string;
export type RuleParameterMap = {
    [key: string]: string | undefined;
};
export interface Rule {
    Type?: RuleType | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RuleMap = {
    [key: string]: Rule | undefined;
};
export interface FacetAttributeDefinition {
    Type: FacetAttributeType;
    DefaultValue?: TypedAttributeValue | undefined;
    IsImmutable?: boolean | undefined;
    Rules?: {
        [key: string]: Rule | undefined;
    } | undefined;
}
export interface FacetAttributeReference {
    TargetFacetName: string;
    TargetAttributeName: string;
}
export type RequiredAttributeBehavior = "REQUIRED_ALWAYS" | "NOT_REQUIRED" | (string & {});
export interface FacetAttribute {
    Name: string;
    AttributeDefinition?: FacetAttributeDefinition | undefined;
    AttributeReference?: FacetAttributeReference | undefined;
    RequiredBehavior?: RequiredAttributeBehavior | undefined;
}
export type FacetAttributeList = FacetAttribute[];
export type ObjectType = "NODE" | "LEAF_NODE" | "POLICY" | "INDEX" | (string & {});
export type FacetStyle = "STATIC" | "DYNAMIC" | (string & {});
export interface CreateFacetRequest {
    SchemaArn: string;
    Name: string;
    Attributes?: FacetAttribute[] | undefined;
    ObjectType?: ObjectType | undefined;
    FacetStyle?: FacetStyle | undefined;
}
export interface CreateFacetResponse {
}
export interface CreateIndexRequest {
    DirectoryArn: string;
    OrderedIndexedAttributeList: AttributeKey[];
    IsUnique: boolean;
    ParentReference?: ObjectReference | undefined;
    LinkName?: string | undefined;
}
export interface CreateIndexResponse {
    ObjectIdentifier?: string | undefined;
}
export interface CreateObjectRequest {
    DirectoryArn: string;
    SchemaFacets: SchemaFacet[];
    ObjectAttributeList?: AttributeKeyAndValue[] | undefined;
    ParentReference?: ObjectReference | undefined;
    LinkName?: string | undefined;
}
export interface CreateObjectResponse {
    ObjectIdentifier?: string | undefined;
}
export type SchemaName = string;
export interface CreateSchemaRequest {
    Name: string;
}
export interface CreateSchemaResponse {
    SchemaArn?: string | undefined;
}
export interface TypedLinkAttributeDefinition {
    Name: string;
    Type: FacetAttributeType;
    DefaultValue?: TypedAttributeValue | undefined;
    IsImmutable?: boolean | undefined;
    Rules?: {
        [key: string]: Rule | undefined;
    } | undefined;
    RequiredBehavior: RequiredAttributeBehavior;
}
export type TypedLinkAttributeDefinitionList = TypedLinkAttributeDefinition[];
export interface TypedLinkFacet {
    Name: string;
    Attributes: TypedLinkAttributeDefinition[];
    IdentityAttributeOrder: string[];
}
export interface CreateTypedLinkFacetRequest {
    SchemaArn: string;
    Facet: TypedLinkFacet;
}
export interface CreateTypedLinkFacetResponse {
}
export interface DeleteDirectoryRequest {
    DirectoryArn: string;
}
export interface DeleteDirectoryResponse {
    DirectoryArn: string;
}
export interface DeleteFacetRequest {
    SchemaArn: string;
    Name: string;
}
export interface DeleteFacetResponse {
}
export interface DeleteObjectRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
}
export interface DeleteObjectResponse {
}
export interface DeleteSchemaRequest {
    SchemaArn: string;
}
export interface DeleteSchemaResponse {
    SchemaArn?: string | undefined;
}
export interface DeleteTypedLinkFacetRequest {
    SchemaArn: string;
    Name: string;
}
export interface DeleteTypedLinkFacetResponse {
}
export interface DetachFromIndexRequest {
    DirectoryArn: string;
    IndexReference: ObjectReference;
    TargetReference: ObjectReference;
}
export interface DetachFromIndexResponse {
    DetachedObjectIdentifier?: string | undefined;
}
export interface DetachObjectRequest {
    DirectoryArn: string;
    ParentReference: ObjectReference;
    LinkName: string;
}
export interface DetachObjectResponse {
    DetachedObjectIdentifier?: string | undefined;
}
export interface DetachPolicyRequest {
    DirectoryArn: string;
    PolicyReference: ObjectReference;
    ObjectReference: ObjectReference;
}
export interface DetachPolicyResponse {
}
export interface DetachTypedLinkRequest {
    DirectoryArn: string;
    TypedLinkSpecifier: TypedLinkSpecifier;
}
export interface DetachTypedLinkResponse {
}
export interface DisableDirectoryRequest {
    DirectoryArn: string;
}
export interface DisableDirectoryResponse {
    DirectoryArn: string;
}
export interface EnableDirectoryRequest {
    DirectoryArn: string;
}
export interface EnableDirectoryResponse {
    DirectoryArn: string;
}
export interface GetAppliedSchemaVersionRequest {
    SchemaArn: string;
}
export interface GetAppliedSchemaVersionResponse {
    AppliedSchemaArn?: string | undefined;
}
export interface GetDirectoryRequest {
    DirectoryArn: string;
}
export type DirectoryState = "ENABLED" | "DISABLED" | "DELETED" | (string & {});
export interface Directory {
    Name?: string | undefined;
    DirectoryArn?: string | undefined;
    State?: DirectoryState | undefined;
    CreationDateTime?: Date | undefined;
}
export interface GetDirectoryResponse {
    Directory: Directory;
}
export interface GetFacetRequest {
    SchemaArn: string;
    Name: string;
}
export interface Facet {
    Name?: string | undefined;
    ObjectType?: ObjectType | undefined;
    FacetStyle?: FacetStyle | undefined;
}
export interface GetFacetResponse {
    Facet?: Facet | undefined;
}
export interface GetLinkAttributesRequest {
    DirectoryArn: string;
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeNames: string[];
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface GetLinkAttributesResponse {
    Attributes?: AttributeKeyAndValue[] | undefined;
}
export interface GetObjectAttributesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    ConsistencyLevel?: ConsistencyLevel | undefined;
    SchemaFacet: SchemaFacet;
    AttributeNames: string[];
}
export interface GetObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[] | undefined;
}
export interface GetObjectInformationRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface GetObjectInformationResponse {
    SchemaFacets?: SchemaFacet[] | undefined;
    ObjectIdentifier?: string | undefined;
}
export interface GetSchemaAsJsonRequest {
    SchemaArn: string;
}
export type SchemaJsonDocument = string;
export interface GetSchemaAsJsonResponse {
    Name?: string | undefined;
    Document?: string | undefined;
}
export interface GetTypedLinkFacetInformationRequest {
    SchemaArn: string;
    Name: string;
}
export interface GetTypedLinkFacetInformationResponse {
    IdentityAttributeOrder?: string[] | undefined;
}
export interface ListAppliedSchemaArnsRequest {
    DirectoryArn: string;
    SchemaArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Arns = string[];
export interface ListAppliedSchemaArnsResponse {
    SchemaArns?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAttachedIndicesRequest {
    DirectoryArn: string;
    TargetReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListAttachedIndicesResponse {
    IndexAttachments?: IndexAttachment[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDevelopmentSchemaArnsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListDevelopmentSchemaArnsResponse {
    SchemaArns?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDirectoriesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    state?: DirectoryState | undefined;
}
export type DirectoryList = Directory[];
export interface ListDirectoriesResponse {
    Directories: Directory[];
    NextToken?: string | undefined;
}
export interface ListFacetAttributesRequest {
    SchemaArn: string;
    Name: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListFacetAttributesResponse {
    Attributes?: FacetAttribute[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFacetNamesRequest {
    SchemaArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type FacetNameList = string[];
export interface ListFacetNamesResponse {
    FacetNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListIncomingTypedLinksRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[] | undefined;
    FilterTypedLink?: TypedLinkSchemaAndFacetName | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListIncomingTypedLinksResponse {
    LinkSpecifiers?: TypedLinkSpecifier[] | undefined;
    NextToken?: string | undefined;
}
export interface ListIndexRequest {
    DirectoryArn: string;
    RangesOnIndexedValues?: ObjectAttributeRange[] | undefined;
    IndexReference: ObjectReference;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListIndexResponse {
    IndexAttachments?: IndexAttachment[] | undefined;
    NextToken?: string | undefined;
}
export interface ListManagedSchemaArnsRequest {
    SchemaArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListManagedSchemaArnsResponse {
    SchemaArns?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListObjectAttributesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
    FacetFilter?: SchemaFacet | undefined;
}
export interface ListObjectAttributesResponse {
    Attributes?: AttributeKeyAndValue[] | undefined;
    NextToken?: string | undefined;
}
export interface ListObjectChildrenRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListObjectChildrenResponse {
    Children?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
}
export interface ListObjectParentPathsRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListObjectParentPathsResponse {
    PathToObjectIdentifiersList?: PathToObjectIdentifiers[] | undefined;
    NextToken?: string | undefined;
}
export interface ListObjectParentsRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
    IncludeAllLinksToEachParent?: boolean | undefined;
}
export type ObjectIdentifierToLinkNameMap = {
    [key: string]: string | undefined;
};
export interface ListObjectParentsResponse {
    Parents?: {
        [key: string]: string | undefined;
    } | undefined;
    NextToken?: string | undefined;
    ParentLinks?: ObjectIdentifierAndLinkNameTuple[] | undefined;
}
export interface ListObjectPoliciesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListObjectPoliciesResponse {
    AttachedPolicyIds?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListOutgoingTypedLinksRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    FilterAttributeRanges?: TypedLinkAttributeRange[] | undefined;
    FilterTypedLink?: TypedLinkSchemaAndFacetName | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListOutgoingTypedLinksResponse {
    TypedLinkSpecifiers?: TypedLinkSpecifier[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPolicyAttachmentsRequest {
    DirectoryArn: string;
    PolicyReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ConsistencyLevel?: ConsistencyLevel | undefined;
}
export interface ListPolicyAttachmentsResponse {
    ObjectIdentifiers?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPublishedSchemaArnsRequest {
    SchemaArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListPublishedSchemaArnsResponse {
    SchemaArns?: string[] | undefined;
    NextToken?: string | undefined;
}
export type TagsNumberResults = number;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTypedLinkFacetAttributesRequest {
    SchemaArn: string;
    Name: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListTypedLinkFacetAttributesResponse {
    Attributes?: TypedLinkAttributeDefinition[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTypedLinkFacetNamesRequest {
    SchemaArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TypedLinkNameList = string[];
export interface ListTypedLinkFacetNamesResponse {
    FacetNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface LookupPolicyRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface LookupPolicyResponse {
    PolicyToPathList?: PolicyToPath[] | undefined;
    NextToken?: string | undefined;
}
export type Version = string;
export interface PublishSchemaRequest {
    DevelopmentSchemaArn: string;
    Version: string;
    MinorVersion?: string | undefined;
    Name?: string | undefined;
}
export interface PublishSchemaResponse {
    PublishedSchemaArn?: string | undefined;
}
export interface PutSchemaFromJsonRequest {
    SchemaArn: string;
    Document: string;
}
export interface PutSchemaFromJsonResponse {
    Arn?: string | undefined;
}
export interface RemoveFacetFromObjectRequest {
    DirectoryArn: string;
    SchemaFacet: SchemaFacet;
    ObjectReference: ObjectReference;
}
export interface RemoveFacetFromObjectResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface FacetAttributeUpdate {
    Attribute?: FacetAttribute | undefined;
    Action?: UpdateActionType | undefined;
}
export type FacetAttributeUpdateList = FacetAttributeUpdate[];
export interface UpdateFacetRequest {
    SchemaArn: string;
    Name: string;
    AttributeUpdates?: FacetAttributeUpdate[] | undefined;
    ObjectType?: ObjectType | undefined;
}
export interface UpdateFacetResponse {
}
export interface UpdateLinkAttributesRequest {
    DirectoryArn: string;
    TypedLinkSpecifier: TypedLinkSpecifier;
    AttributeUpdates: LinkAttributeUpdate[];
}
export interface UpdateLinkAttributesResponse {
}
export interface UpdateObjectAttributesRequest {
    DirectoryArn: string;
    ObjectReference: ObjectReference;
    AttributeUpdates: ObjectAttributeUpdate[];
}
export interface UpdateObjectAttributesResponse {
    ObjectIdentifier?: string | undefined;
}
export interface UpdateSchemaRequest {
    SchemaArn: string;
    Name: string;
}
export interface UpdateSchemaResponse {
    SchemaArn?: string | undefined;
}
export interface TypedLinkFacetAttributeUpdate {
    Attribute: TypedLinkAttributeDefinition;
    Action: UpdateActionType;
}
export type TypedLinkFacetAttributeUpdateList = TypedLinkFacetAttributeUpdate[];
export interface UpdateTypedLinkFacetRequest {
    SchemaArn: string;
    Name: string;
    AttributeUpdates: TypedLinkFacetAttributeUpdate[];
    IdentityAttributeOrder: string[];
}
export interface UpdateTypedLinkFacetResponse {
}
export interface UpgradeAppliedSchemaRequest {
    PublishedSchemaArn: string;
    DirectoryArn: string;
    DryRun?: boolean | undefined;
}
export interface UpgradeAppliedSchemaResponse {
    UpgradedSchemaArn?: string | undefined;
    DirectoryArn?: string | undefined;
}
export interface UpgradePublishedSchemaRequest {
    DevelopmentSchemaArn: string;
    PublishedSchemaArn: string;
    MinorVersion: string;
    DryRun?: boolean | undefined;
}
export interface UpgradePublishedSchemaResponse {
    UpgradedSchemaArn?: string | undefined;
}
export type BatchOperationIndex = number;
export type BatchWriteExceptionType = "InternalServiceException" | "ValidationException" | "InvalidArnException" | "LinkNameAlreadyInUseException" | "StillContainsLinksException" | "FacetValidationException" | "ObjectNotDetachedException" | "ResourceNotFoundException" | "AccessDeniedException" | "InvalidAttachmentException" | "NotIndexException" | "NotNodeException" | "IndexedAttributeMissingException" | "ObjectAlreadyDetachedException" | "NotPolicyException" | "DirectoryNotEnabledException" | "LimitExceededException" | "UnsupportedIndexTypeException" | (string & {});
export type AddFacetToObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Adds a new Facet to an object. An object can have more than one facet applied on it.
 */
export declare const addFacetToObject: API.OperationMethod<AddFacetToObjectRequest & RegionInput, AddFacetToObjectResponse, AddFacetToObjectError, Credentials | HttpClient.HttpClient>;
export type ApplySchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | SchemaAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Copies the input published schema, at the specified version, into the Directory with the same
 * name and version as that of the published schema.
 */
export declare const applySchema: API.OperationMethod<ApplySchemaRequest & RegionInput, ApplySchemaResponse, ApplySchemaError, Credentials | HttpClient.HttpClient>;
export type AttachObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches an existing object to another object. An object can be accessed in two
 * ways:
 *
 * - Using the path
 *
 * - Using `ObjectIdentifier`
 */
export declare const attachObject: API.OperationMethod<AttachObjectRequest & RegionInput, AttachObjectResponse, AttachObjectError, Credentials | HttpClient.HttpClient>;
export type AttachPolicyError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotPolicyException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches a policy object to a regular object. An object can have a limited number of attached
 * policies.
 */
export declare const attachPolicy: API.OperationMethod<AttachPolicyRequest & RegionInput, AttachPolicyResponse, AttachPolicyError, Credentials | HttpClient.HttpClient>;
export type AttachToIndexError = AccessDeniedException | DirectoryNotEnabledException | IndexedAttributeMissingException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | LinkNameAlreadyInUseException | NotIndexException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches the specified object to the specified index.
 */
export declare const attachToIndex: API.OperationMethod<AttachToIndexRequest & RegionInput, AttachToIndexResponse, AttachToIndexError, Credentials | HttpClient.HttpClient>;
export type AttachTypedLinkError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Attaches a typed link to a specified source and target object. For more information, see Typed Links.
 */
export declare const attachTypedLink: API.OperationMethod<AttachTypedLinkRequest & RegionInput, AttachTypedLinkResponse, AttachTypedLinkError, Credentials | HttpClient.HttpClient>;
export type BatchReadError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Performs all the read operations in a batch.
 */
export declare const batchRead: API.OperationMethod<BatchReadRequest & RegionInput, BatchReadResponse, BatchReadError, Credentials | HttpClient.HttpClient>;
export type BatchWriteError = AccessDeniedException | BatchWriteException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Performs all the write operations in a batch. Either all the operations succeed or
 * none.
 */
export declare const batchWrite: API.OperationMethod<BatchWriteRequest & RegionInput, BatchWriteResponse, BatchWriteError, Credentials | HttpClient.HttpClient>;
export type CreateDirectoryError = AccessDeniedException | DirectoryAlreadyExistsException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Creates a Directory by copying the published schema into the
 * directory. A directory cannot be created without a schema.
 *
 * You can also quickly create a directory using a managed schema, called the
 * `QuickStartSchema`. For more information, see Managed Schema in the *Amazon Cloud Directory Developer Guide*.
 */
export declare const createDirectory: API.OperationMethod<CreateDirectoryRequest & RegionInput, CreateDirectoryResponse, CreateDirectoryError, Credentials | HttpClient.HttpClient>;
export type CreateFacetError = AccessDeniedException | FacetAlreadyExistsException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Creates a new Facet in a schema. Facet creation is allowed only
 * in development or applied schemas.
 */
export declare const createFacet: API.OperationMethod<CreateFacetRequest & RegionInput, CreateFacetResponse, CreateFacetError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | UnsupportedIndexTypeException | ValidationException | CommonErrors;
/**
 * Creates an index object. See Indexing and search for more information.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest & RegionInput, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | UnsupportedIndexTypeException | ValidationException | CommonErrors;
/**
 * Creates an object in a Directory. Additionally attaches the object to
 * a parent, if a parent reference and `LinkName` is specified. An object is simply a
 * collection of Facet attributes. You can also use this API call to create a
 * policy object, if the facet from which you create the object is a policy facet.
 */
export declare const createObject: API.OperationMethod<CreateObjectRequest & RegionInput, CreateObjectResponse, CreateObjectError, Credentials | HttpClient.HttpClient>;
export type CreateSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | SchemaAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Creates a new schema in a development state. A schema can exist in three
 * phases:
 *
 * - *Development:* This is a mutable phase of the schema. All new
 * schemas are in the development phase. Once the schema is finalized, it can be
 * published.
 *
 * - *Published:* Published schemas are immutable and have a version
 * associated with them.
 *
 * - *Applied:* Applied schemas are mutable in a way that allows you
 * to add new schema facets. You can also add new, nonrequired attributes to existing schema
 * facets. You can apply only published schemas to directories.
 */
export declare const createSchema: API.OperationMethod<CreateSchemaRequest & RegionInput, CreateSchemaResponse, CreateSchemaError, Credentials | HttpClient.HttpClient>;
export type CreateTypedLinkFacetError = AccessDeniedException | FacetAlreadyExistsException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Creates a TypedLinkFacet. For more information, see Typed Links.
 */
export declare const createTypedLinkFacet: API.OperationMethod<CreateTypedLinkFacetRequest & RegionInput, CreateTypedLinkFacetResponse, CreateTypedLinkFacetError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectoryError = AccessDeniedException | DirectoryDeletedException | DirectoryNotDisabledException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes a directory. Only disabled directories can be deleted. A deleted directory cannot be undone. Exercise extreme
 * caution
 * when deleting directories.
 */
export declare const deleteDirectory: API.OperationMethod<DeleteDirectoryRequest & RegionInput, DeleteDirectoryResponse, DeleteDirectoryError, Credentials | HttpClient.HttpClient>;
export type DeleteFacetError = AccessDeniedException | FacetInUseException | FacetNotFoundException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes a given Facet. All attributes and Rules
 * that are associated with the facet will be deleted. Only development schema facets are allowed
 * deletion.
 */
export declare const deleteFacet: API.OperationMethod<DeleteFacetRequest & RegionInput, DeleteFacetResponse, DeleteFacetError, Credentials | HttpClient.HttpClient>;
export type DeleteObjectError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | ObjectNotDetachedException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes an object and its associated attributes. Only objects with no children and no
 * parents can be deleted. The maximum number of attributes that can be deleted during an object deletion is 30. For more information, see Amazon Cloud Directory Limits.
 */
export declare const deleteObject: API.OperationMethod<DeleteObjectRequest & RegionInput, DeleteObjectResponse, DeleteObjectError, Credentials | HttpClient.HttpClient>;
export type DeleteSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | StillContainsLinksException | ValidationException | CommonErrors;
/**
 * Deletes a given schema. Schemas in a development and published state can only be deleted.
 */
export declare const deleteSchema: API.OperationMethod<DeleteSchemaRequest & RegionInput, DeleteSchemaResponse, DeleteSchemaError, Credentials | HttpClient.HttpClient>;
export type DeleteTypedLinkFacetError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Deletes a TypedLinkFacet. For more information, see Typed Links.
 */
export declare const deleteTypedLinkFacet: API.OperationMethod<DeleteTypedLinkFacetRequest & RegionInput, DeleteTypedLinkFacetResponse, DeleteTypedLinkFacetError, Credentials | HttpClient.HttpClient>;
export type DetachFromIndexError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotIndexException | ObjectAlreadyDetachedException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches the specified object from the specified index.
 */
export declare const detachFromIndex: API.OperationMethod<DetachFromIndexRequest & RegionInput, DetachFromIndexResponse, DetachFromIndexError, Credentials | HttpClient.HttpClient>;
export type DetachObjectError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotNodeException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches a given object from the parent object. The object that is to be detached from the
 * parent is specified by the link name.
 */
export declare const detachObject: API.OperationMethod<DetachObjectRequest & RegionInput, DetachObjectResponse, DetachObjectError, Credentials | HttpClient.HttpClient>;
export type DetachPolicyError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | NotPolicyException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches a policy from an object.
 */
export declare const detachPolicy: API.OperationMethod<DetachPolicyRequest & RegionInput, DetachPolicyResponse, DetachPolicyError, Credentials | HttpClient.HttpClient>;
export type DetachTypedLinkError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Detaches a typed link from a specified source and target object. For more information, see Typed Links.
 */
export declare const detachTypedLink: API.OperationMethod<DetachTypedLinkRequest & RegionInput, DetachTypedLinkResponse, DetachTypedLinkError, Credentials | HttpClient.HttpClient>;
export type DisableDirectoryError = AccessDeniedException | DirectoryDeletedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Disables the specified directory. Disabled directories cannot be read or written to.
 * Only enabled directories can be disabled. Disabled directories may be reenabled.
 */
export declare const disableDirectory: API.OperationMethod<DisableDirectoryRequest & RegionInput, DisableDirectoryResponse, DisableDirectoryError, Credentials | HttpClient.HttpClient>;
export type EnableDirectoryError = AccessDeniedException | DirectoryDeletedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Enables the specified directory. Only disabled directories can be enabled. Once
 * enabled, the directory can then be read and written to.
 */
export declare const enableDirectory: API.OperationMethod<EnableDirectoryRequest & RegionInput, EnableDirectoryResponse, EnableDirectoryError, Credentials | HttpClient.HttpClient>;
export type GetAppliedSchemaVersionError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns current applied schema version ARN, including the minor version in use.
 */
export declare const getAppliedSchemaVersion: API.OperationMethod<GetAppliedSchemaVersionRequest & RegionInput, GetAppliedSchemaVersionResponse, GetAppliedSchemaVersionError, Credentials | HttpClient.HttpClient>;
export type GetDirectoryError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves metadata about a directory.
 */
export declare const getDirectory: API.OperationMethod<GetDirectoryRequest & RegionInput, GetDirectoryResponse, GetDirectoryError, Credentials | HttpClient.HttpClient>;
export type GetFacetError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Gets details of the Facet, such as facet name, attributes, Rules, or `ObjectType`. You can call this on all kinds of schema
 * facets -- published, development, or applied.
 */
export declare const getFacet: API.OperationMethod<GetFacetRequest & RegionInput, GetFacetResponse, GetFacetError, Credentials | HttpClient.HttpClient>;
export type GetLinkAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves attributes that are associated with a typed link.
 */
export declare const getLinkAttributes: API.OperationMethod<GetLinkAttributesRequest & RegionInput, GetLinkAttributesResponse, GetLinkAttributesError, Credentials | HttpClient.HttpClient>;
export type GetObjectAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves attributes within a facet that are associated with an object.
 */
export declare const getObjectAttributes: API.OperationMethod<GetObjectAttributesRequest & RegionInput, GetObjectAttributesResponse, GetObjectAttributesError, Credentials | HttpClient.HttpClient>;
export type GetObjectInformationError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves metadata about an object.
 */
export declare const getObjectInformation: API.OperationMethod<GetObjectInformationRequest & RegionInput, GetObjectInformationResponse, GetObjectInformationError, Credentials | HttpClient.HttpClient>;
export type GetSchemaAsJsonError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves a JSON representation of the schema. See JSON Schema Format for more information.
 */
export declare const getSchemaAsJson: API.OperationMethod<GetSchemaAsJsonRequest & RegionInput, GetSchemaAsJsonResponse, GetSchemaAsJsonError, Credentials | HttpClient.HttpClient>;
export type GetTypedLinkFacetInformationError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns the identity attribute order for a specific TypedLinkFacet. For more information, see Typed Links.
 */
export declare const getTypedLinkFacetInformation: API.OperationMethod<GetTypedLinkFacetInformationRequest & RegionInput, GetTypedLinkFacetInformationResponse, GetTypedLinkFacetInformationError, Credentials | HttpClient.HttpClient>;
export type ListAppliedSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists schema major versions applied to a directory. If `SchemaArn` is provided, lists the minor version.
 */
export declare const listAppliedSchemaArns: API.PaginatedOperationMethod<ListAppliedSchemaArnsRequest & RegionInput, ListAppliedSchemaArnsResponse, ListAppliedSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAttachedIndicesError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists indices attached to the specified object.
 */
export declare const listAttachedIndices: API.PaginatedOperationMethod<ListAttachedIndicesRequest & RegionInput, ListAttachedIndicesResponse, ListAttachedIndicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDevelopmentSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves each Amazon Resource Name (ARN) of schemas in the development
 * state.
 */
export declare const listDevelopmentSchemaArns: API.PaginatedOperationMethod<ListDevelopmentSchemaArnsRequest & RegionInput, ListDevelopmentSchemaArnsResponse, ListDevelopmentSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListDirectoriesError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists directories created within an account.
 */
export declare const listDirectories: API.PaginatedOperationMethod<ListDirectoriesRequest & RegionInput, ListDirectoriesResponse, ListDirectoriesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFacetAttributesError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves attributes attached to the facet.
 */
export declare const listFacetAttributes: API.PaginatedOperationMethod<ListFacetAttributesRequest & RegionInput, ListFacetAttributesResponse, ListFacetAttributesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListFacetNamesError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves the names of facets that exist in a schema.
 */
export declare const listFacetNames: API.PaginatedOperationMethod<ListFacetNamesRequest & RegionInput, ListFacetNamesResponse, ListFacetNamesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIncomingTypedLinksError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all the incoming TypedLinkSpecifier
 * information for an object. It also supports filtering by typed link facet and identity
 * attributes. For more information, see Typed Links.
 */
export declare const listIncomingTypedLinks: API.OperationMethod<ListIncomingTypedLinksRequest & RegionInput, ListIncomingTypedLinksResponse, ListIncomingTypedLinksError, Credentials | HttpClient.HttpClient>;
export type ListIndexError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | NotIndexException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists objects attached to the specified index.
 */
export declare const listIndex: API.PaginatedOperationMethod<ListIndexRequest & RegionInput, ListIndexResponse, ListIndexError, Credentials | HttpClient.HttpClient, unknown>;
export type ListManagedSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the major version families of each managed schema. If a major version ARN is provided as SchemaArn, the minor version revisions in that family are listed instead.
 */
export declare const listManagedSchemaArns: API.PaginatedOperationMethod<ListManagedSchemaArnsRequest & RegionInput, ListManagedSchemaArnsResponse, ListManagedSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists all attributes that are associated with an object.
 */
export declare const listObjectAttributes: API.PaginatedOperationMethod<ListObjectAttributesRequest & RegionInput, ListObjectAttributesResponse, ListObjectAttributesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectChildrenError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | NotNodeException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of child objects that are associated with a given
 * object.
 */
export declare const listObjectChildren: API.PaginatedOperationMethod<ListObjectChildrenRequest & RegionInput, ListObjectChildrenResponse, ListObjectChildrenError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectParentPathsError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Retrieves all available parent paths for any object type such as node, leaf node,
 * policy node, and index node objects. For more information about objects, see Directory Structure.
 *
 * Use this API to evaluate all parents for an object. The call returns all objects from
 * the root of the directory up to the requested object. The API returns the number of paths
 * based on user-defined `MaxResults`, in case there are multiple paths to the parent.
 * The order of the paths and nodes returned is consistent among multiple API calls unless the
 * objects are deleted or moved. Paths not leading to the directory root are ignored from the
 * target object.
 */
export declare const listObjectParentPaths: API.PaginatedOperationMethod<ListObjectParentPathsRequest & RegionInput, ListObjectParentPathsResponse, ListObjectParentPathsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectParentsError = AccessDeniedException | CannotListParentOfRootException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists parent objects that are associated with a given object in pagination
 * fashion.
 */
export declare const listObjectParents: API.PaginatedOperationMethod<ListObjectParentsRequest & RegionInput, ListObjectParentsResponse, ListObjectParentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListObjectPoliciesError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns policies attached to an object in pagination fashion.
 */
export declare const listObjectPolicies: API.PaginatedOperationMethod<ListObjectPoliciesRequest & RegionInput, ListObjectPoliciesResponse, ListObjectPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOutgoingTypedLinksError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all the outgoing TypedLinkSpecifier
 * information for an object. It also supports filtering by typed link facet and identity
 * attributes. For more information, see Typed Links.
 */
export declare const listOutgoingTypedLinks: API.OperationMethod<ListOutgoingTypedLinksRequest & RegionInput, ListOutgoingTypedLinksResponse, ListOutgoingTypedLinksError, Credentials | HttpClient.HttpClient>;
export type ListPolicyAttachmentsError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | NotPolicyException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns all of the `ObjectIdentifiers` to which a given policy is attached.
 */
export declare const listPolicyAttachments: API.PaginatedOperationMethod<ListPolicyAttachmentsRequest & RegionInput, ListPolicyAttachmentsResponse, ListPolicyAttachmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPublishedSchemaArnsError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists the major version families of each published schema. If a major version ARN is provided as `SchemaArn`, the minor version revisions in that family are listed instead.
 */
export declare const listPublishedSchemaArns: API.PaginatedOperationMethod<ListPublishedSchemaArnsRequest & RegionInput, ListPublishedSchemaArnsResponse, ListPublishedSchemaArnsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidTaggingRequestException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns tags for a resource. Tagging is currently supported only for directories with a
 * limit of 50 tags per directory. All 50 tags are returned for a given directory with this API
 * call.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTypedLinkFacetAttributesError = AccessDeniedException | FacetNotFoundException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of all attribute definitions for a particular TypedLinkFacet. For more information, see Typed Links.
 */
export declare const listTypedLinkFacetAttributes: API.PaginatedOperationMethod<ListTypedLinkFacetAttributesRequest & RegionInput, ListTypedLinkFacetAttributesResponse, ListTypedLinkFacetAttributesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTypedLinkFacetNamesError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of `TypedLink` facet names for a particular schema.
 * For more information, see Typed Links.
 */
export declare const listTypedLinkFacetNames: API.PaginatedOperationMethod<ListTypedLinkFacetNamesRequest & RegionInput, ListTypedLinkFacetNamesResponse, ListTypedLinkFacetNamesError, Credentials | HttpClient.HttpClient, unknown>;
export type LookupPolicyError = AccessDeniedException | DirectoryNotEnabledException | InternalServiceException | InvalidArnException | InvalidNextTokenException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Lists all policies from the root of the Directory to the object
 * specified. If there are no policies present, an empty list is returned. If policies are
 * present, and if some objects don't have the policies attached, it returns the `ObjectIdentifier`
 * for such objects. If policies are present, it returns `ObjectIdentifier`, `policyId`, and
 * `policyType`. Paths that don't lead to the root from the target object are ignored. For more
 * information, see Policies.
 */
export declare const lookupPolicy: API.PaginatedOperationMethod<LookupPolicyRequest & RegionInput, LookupPolicyResponse, LookupPolicyError, Credentials | HttpClient.HttpClient, unknown>;
export type PublishSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | SchemaAlreadyPublishedException | ValidationException | CommonErrors;
/**
 * Publishes a development schema with a major version and a recommended minor version.
 */
export declare const publishSchema: API.OperationMethod<PublishSchemaRequest & RegionInput, PublishSchemaResponse, PublishSchemaError, Credentials | HttpClient.HttpClient>;
export type PutSchemaFromJsonError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidRuleException | InvalidSchemaDocException | LimitExceededException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Allows a schema to be updated using JSON upload. Only available for development schemas. See JSON Schema Format for more information.
 */
export declare const putSchemaFromJson: API.OperationMethod<PutSchemaFromJsonRequest & RegionInput, PutSchemaFromJsonResponse, PutSchemaFromJsonError, Credentials | HttpClient.HttpClient>;
export type RemoveFacetFromObjectError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Removes the specified facet from the specified object.
 */
export declare const removeFacetFromObject: API.OperationMethod<RemoveFacetFromObjectRequest & RegionInput, RemoveFacetFromObjectResponse, RemoveFacetFromObjectError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidTaggingRequestException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * An API operation for adding tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServiceException | InvalidArnException | InvalidTaggingRequestException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * An API operation for removing tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateFacetError = AccessDeniedException | FacetNotFoundException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidFacetUpdateException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Does the following:
 *
 * - Adds new `Attributes`, `Rules`, or `ObjectTypes`.
 *
 * - Updates existing `Attributes`, `Rules`, or `ObjectTypes`.
 *
 * - Deletes existing `Attributes`, `Rules`, or `ObjectTypes`.
 */
export declare const updateFacet: API.OperationMethod<UpdateFacetRequest & RegionInput, UpdateFacetResponse, UpdateFacetError, Credentials | HttpClient.HttpClient>;
export type UpdateLinkAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates a given typed link's attributes. Attributes to be updated must not contribute to the typed link's identity, as defined by its `IdentityAttributeOrder`.
 */
export declare const updateLinkAttributes: API.OperationMethod<UpdateLinkAttributesRequest & RegionInput, UpdateLinkAttributesResponse, UpdateLinkAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateObjectAttributesError = AccessDeniedException | DirectoryNotEnabledException | FacetValidationException | InternalServiceException | InvalidArnException | LimitExceededException | LinkNameAlreadyInUseException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates a given object's attributes.
 */
export declare const updateObjectAttributes: API.OperationMethod<UpdateObjectAttributesRequest & RegionInput, UpdateObjectAttributesResponse, UpdateObjectAttributesError, Credentials | HttpClient.HttpClient>;
export type UpdateSchemaError = AccessDeniedException | InternalServiceException | InvalidArnException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates the schema name with a new name. Only development schema names can be
 * updated.
 */
export declare const updateSchema: API.OperationMethod<UpdateSchemaRequest & RegionInput, UpdateSchemaResponse, UpdateSchemaError, Credentials | HttpClient.HttpClient>;
export type UpdateTypedLinkFacetError = AccessDeniedException | FacetNotFoundException | FacetValidationException | InternalServiceException | InvalidArnException | InvalidFacetUpdateException | InvalidRuleException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Updates a TypedLinkFacet. For more information, see Typed Links.
 */
export declare const updateTypedLinkFacet: API.OperationMethod<UpdateTypedLinkFacetRequest & RegionInput, UpdateTypedLinkFacetResponse, UpdateTypedLinkFacetError, Credentials | HttpClient.HttpClient>;
export type UpgradeAppliedSchemaError = AccessDeniedException | IncompatibleSchemaException | InternalServiceException | InvalidArnException | InvalidAttachmentException | ResourceNotFoundException | RetryableConflictException | SchemaAlreadyExistsException | ValidationException | CommonErrors;
/**
 * Upgrades a single directory in-place using the `PublishedSchemaArn` with schema updates found in `MinorVersion`. Backwards-compatible minor version upgrades are instantaneously available for readers on all objects in the directory. Note: This is a synchronous API call and upgrades only one schema on a given directory per call. To upgrade multiple directories from one schema, you would need to call this API on each directory.
 */
export declare const upgradeAppliedSchema: API.OperationMethod<UpgradeAppliedSchemaRequest & RegionInput, UpgradeAppliedSchemaResponse, UpgradeAppliedSchemaError, Credentials | HttpClient.HttpClient>;
export type UpgradePublishedSchemaError = AccessDeniedException | IncompatibleSchemaException | InternalServiceException | InvalidArnException | InvalidAttachmentException | LimitExceededException | ResourceNotFoundException | RetryableConflictException | ValidationException | CommonErrors;
/**
 * Upgrades a published schema under a new minor version revision using the current contents of `DevelopmentSchemaArn`.
 */
export declare const upgradePublishedSchema: API.OperationMethod<UpgradePublishedSchemaRequest & RegionInput, UpgradePublishedSchemaResponse, UpgradePublishedSchemaError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=clouddirectory.d.ts.map