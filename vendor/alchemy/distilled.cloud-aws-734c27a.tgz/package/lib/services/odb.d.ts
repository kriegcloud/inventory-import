import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export interface AcceptMarketplaceRegistrationInput {
    marketplaceRegistrationToken: string;
}
export interface AcceptMarketplaceRegistrationOutput {
}
export type RoleArn = string;
export type SupportedAwsIntegration = "KmsTde" | (string & {});
export type Arn = string;
export interface AssociateIamRoleToResourceInput {
    iamRoleArn: string;
    awsIntegration: SupportedAwsIntegration;
    resourceArn: string;
}
export interface AssociateIamRoleToResourceOutput {
}
export type ResourceId = string;
export type StringList = string[];
export interface AssociateVirtualMachinesToCloudVmClusterInput {
    cloudVmClusterId: string;
    dbServers: string[];
}
export type ResourceStatus = "AVAILABLE" | "FAILED" | "PROVISIONING" | "TERMINATED" | "TERMINATING" | "UPDATING" | "MAINTENANCE_IN_PROGRESS" | (string & {});
export interface AssociateVirtualMachinesToCloudVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudVmClusterId: string;
}
export type ResourceIdOrArn = string;
export interface AssociateVirtualMachinesToExadbVmClusterInput {
    exadbVmClusterId: string;
    desiredNodeCount: number;
}
export interface AssociateVirtualMachinesToExadbVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    exadbVmClusterId: string;
}
export type ResourceDisplayName = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type DbWorkload = "OLTP" | "AJD" | "APEX" | "LH" | (string & {});
export type LicenseModel = "BRING_YOUR_OWN_LICENSE" | "LICENSE_INCLUDED" | (string & {});
export type DatabaseEdition = "STANDARD_EDITION" | "ENTERPRISE_EDITION" | (string & {});
export type StandbyAllowlistedIpsSource = "PRIMARY" | "SEPARATE" | "NOT_APPLICABLE" | (string & {});
export type AutonomousMaintenanceScheduleType = "EARLY" | "REGULAR" | (string & {});
export interface CustomerContact {
    email?: string | redacted.Redacted<string> | undefined;
}
export type CustomerContacts = CustomerContact[];
export interface ResourcePoolSummary {
    isDisabled?: boolean | undefined;
    poolSize?: number | undefined;
    poolStorageSizeInTBs?: number | undefined;
    availableStorageCapacityInTBs?: number | undefined;
    totalComputeCapacity?: number | undefined;
    availableComputeCapacity?: number | undefined;
}
export type DayOfWeekName = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export interface DayOfWeek {
    name?: DayOfWeekName | undefined;
}
export interface ScheduledOperationDetails {
    dayOfWeek: DayOfWeek;
    scheduledStartTime?: string | undefined;
    scheduledStopTime?: string | undefined;
}
export type ScheduledOperationDetailsList = ScheduledOperationDetails[];
export interface TransportableTablespace {
    ttsBundleUrl?: string | undefined;
}
export interface DatabaseTool {
    isEnabled?: boolean | undefined;
    name?: string | undefined;
    computeCount?: number | undefined;
    maxIdleTimeInMinutes?: number | undefined;
}
export type DatabaseToolList = DatabaseTool[];
export type SourceType = "NONE" | "DATABASE" | "BACKUP_FROM_ID" | "BACKUP_FROM_TIMESTAMP" | "CROSS_REGION_DATAGUARD" | "CROSS_REGION_DISASTER_RECOVERY" | "CLONE_TO_REFRESHABLE" | (string & {});
export type CloneType = "FULL" | "METADATA" | "PARTIAL" | (string & {});
export interface DatabaseCloneConfiguration {
    sourceAutonomousDatabaseId: string;
    cloneType: CloneType;
}
export type IntegerList = number[];
export interface RestoreFromBackupConfiguration {
    autonomousDatabaseBackupId: string;
    cloneType: CloneType;
    cloneTableSpaceList?: number[] | undefined;
}
export interface PointInTimeRestoreConfiguration {
    sourceAutonomousDatabaseId: string;
    cloneType: CloneType;
    timestamp?: Date | undefined;
    useLatestAvailableBackupTimestamp?: boolean | undefined;
    cloneTableSpaceList?: number[] | undefined;
}
export interface CrossRegionDataGuardConfiguration {
    sourceAutonomousDatabaseArn: string;
}
export type DisasterRecoveryType = "ADG" | "BACKUP_BASED" | (string & {});
export interface CrossRegionDisasterRecoveryConfiguration {
    sourceAutonomousDatabaseArn: string;
    remoteDisasterRecoveryType: DisasterRecoveryType;
    isReplicateAutomaticBackups?: boolean | undefined;
}
export type RefreshableMode = "AUTOMATIC" | "MANUAL" | (string & {});
export type OpenMode = "READ_ONLY" | "READ_WRITE" | (string & {});
export interface CloneToRefreshableConfiguration {
    sourceAutonomousDatabaseId: string;
    refreshableMode?: RefreshableMode | undefined;
    autoRefreshFrequencyInSeconds?: number | undefined;
    autoRefreshPointLagInSeconds?: number | undefined;
    timeOfAutoRefreshStart?: Date | undefined;
    openMode?: OpenMode | undefined;
    cloneType?: CloneType | undefined;
}
export type SourceConfiguration = {
    databaseClone: DatabaseCloneConfiguration;
    restoreFromBackup?: undefined;
    pointInTimeRestore?: undefined;
    crossRegionDataGuard?: undefined;
    crossRegionDisasterRecovery?: undefined;
    cloneToRefreshable?: undefined;
} | {
    databaseClone?: undefined;
    restoreFromBackup: RestoreFromBackupConfiguration;
    pointInTimeRestore?: undefined;
    crossRegionDataGuard?: undefined;
    crossRegionDisasterRecovery?: undefined;
    cloneToRefreshable?: undefined;
} | {
    databaseClone?: undefined;
    restoreFromBackup?: undefined;
    pointInTimeRestore: PointInTimeRestoreConfiguration;
    crossRegionDataGuard?: undefined;
    crossRegionDisasterRecovery?: undefined;
    cloneToRefreshable?: undefined;
} | {
    databaseClone?: undefined;
    restoreFromBackup?: undefined;
    pointInTimeRestore?: undefined;
    crossRegionDataGuard: CrossRegionDataGuardConfiguration;
    crossRegionDisasterRecovery?: undefined;
    cloneToRefreshable?: undefined;
} | {
    databaseClone?: undefined;
    restoreFromBackup?: undefined;
    pointInTimeRestore?: undefined;
    crossRegionDataGuard?: undefined;
    crossRegionDisasterRecovery: CrossRegionDisasterRecoveryConfiguration;
    cloneToRefreshable?: undefined;
} | {
    databaseClone?: undefined;
    restoreFromBackup?: undefined;
    pointInTimeRestore?: undefined;
    crossRegionDataGuard?: undefined;
    crossRegionDisasterRecovery?: undefined;
    cloneToRefreshable: CloneToRefreshableConfiguration;
};
export type EncryptionKeyProviderInput = "ORACLE_MANAGED" | "AWS_KMS" | (string & {});
export type ExternalIdType = "database_ocid" | "compartment_ocid" | "tenant_ocid" | (string & {});
export type KmsKeyIdOrArn = string;
export interface AwsEncryptionKeyConfigurationInput {
    iamRoleArn?: string | undefined;
    externalIdType?: ExternalIdType | undefined;
    kmsKeyId?: string | undefined;
}
export type EncryptionKeyConfigurationInput = {
    awsEncryptionKey: AwsEncryptionKeyConfigurationInput;
};
export type AdminPasswordSource = "CUSTOMER_MANAGED_AWS_SECRET" | "API_REQUEST_PARAMETER" | (string & {});
export type SecretIdOrArn = string;
export interface CustomerManagedAwsSecretConfigurationInput {
    secretId?: string | undefined;
    iamRoleArn?: string | undefined;
    externalIdType?: ExternalIdType | undefined;
}
export type AdminPasswordSourceConfigurationInput = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfigurationInput;
};
export type GeneralInputString = string;
export type TagKey = string;
export type TagValue = string;
export type RequestTagMap = {
    [key: string]: string | undefined;
};
export interface CreateAutonomousDatabaseInput {
    odbNetworkId?: string | undefined;
    displayName?: string | undefined;
    dbName?: string | undefined;
    adminPassword?: string | redacted.Redacted<string> | undefined;
    computeCount?: number | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dataStorageSizeInGBs?: number | undefined;
    dbWorkload?: DbWorkload | undefined;
    isAutoScalingEnabled?: boolean | undefined;
    isAutoScalingForStorageEnabled?: boolean | undefined;
    licenseModel?: LicenseModel | undefined;
    characterSet?: string | undefined;
    ncharacterSet?: string | undefined;
    dbVersion?: string | undefined;
    databaseEdition?: DatabaseEdition | undefined;
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource | undefined;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType | undefined;
    backupRetentionPeriodInDays?: number | undefined;
    byolComputeCountLimit?: number | undefined;
    cpuCoreCount?: number | undefined;
    customerContactsToSendToOCI?: CustomerContact[] | undefined;
    privateEndpointIp?: string | undefined;
    privateEndpointLabel?: string | undefined;
    resourcePoolLeaderId?: string | undefined;
    resourcePoolSummary?: ResourcePoolSummary | undefined;
    scheduledOperations?: ScheduledOperationDetails[] | undefined;
    standbyAllowlistedIps?: string[] | undefined;
    allowlistedIps?: string[] | undefined;
    transportableTablespace?: TransportableTablespace | undefined;
    isBackupRetentionLocked?: boolean | undefined;
    isLocalDataGuardEnabled?: boolean | undefined;
    isMtlsConnectionRequired?: boolean | undefined;
    dbToolsDetails?: DatabaseTool[] | undefined;
    source?: SourceType | undefined;
    sourceConfiguration?: SourceConfiguration | undefined;
    encryptionKeyProvider?: EncryptionKeyProviderInput | undefined;
    encryptionKeyConfiguration?: EncryptionKeyConfigurationInput | undefined;
    adminPasswordSource?: AdminPasswordSource | undefined;
    adminPasswordSourceConfiguration?: AdminPasswordSourceConfigurationInput | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AutonomousDatabaseResourceStatus = "AVAILABLE" | "FAILED" | "PROVISIONING" | "TERMINATED" | "TERMINATING" | "UPDATING" | "MAINTENANCE_IN_PROGRESS" | "STOPPING" | "STOPPED" | "STARTING" | "UNAVAILABLE" | "RESTORE_IN_PROGRESS" | "RESTORE_FAILED" | "BACKUP_IN_PROGRESS" | "SCALE_IN_PROGRESS" | "AVAILABLE_NEEDS_ATTENTION" | "RESTARTING" | "RECREATING" | "ROLE_CHANGE_IN_PROGRESS" | "UPGRADING" | "INACCESSIBLE" | "STANDBY" | (string & {});
export interface CreateAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface CreateAutonomousDatabaseBackupInput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    retentionPeriodInDays?: number | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateAutonomousDatabaseBackupOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    autonomousDatabaseBackupId: string;
}
export type WalletType = "REGIONAL" | "INSTANCE" | (string & {});
export type WalletPasswordSource = "CUSTOMER_MANAGED_AWS_SECRET" | "API_REQUEST_PARAMETER" | (string & {});
export type WalletPasswordSourceConfigurationInput = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfigurationInput;
};
export interface CreateAutonomousDatabaseWalletInput {
    autonomousDatabaseId: string;
    walletType?: WalletType | undefined;
    password?: string | redacted.Redacted<string> | undefined;
    passwordSource?: WalletPasswordSource | undefined;
    passwordSourceConfiguration?: WalletPasswordSourceConfigurationInput | undefined;
    clientToken?: string | undefined;
}
export type AutonomousDatabaseWalletFile = Uint8Array | redacted.Redacted<Uint8Array>;
export interface CreateAutonomousDatabaseWalletOutput {
    autonomousDatabaseWalletFile: Uint8Array | redacted.Redacted<Uint8Array>;
}
export type DaysOfWeek = DayOfWeek[];
export type HoursOfDay = number[];
export type MonthName = "JANUARY" | "FEBRUARY" | "MARCH" | "APRIL" | "MAY" | "JUNE" | "JULY" | "AUGUST" | "SEPTEMBER" | "OCTOBER" | "NOVEMBER" | "DECEMBER" | (string & {});
export interface Month {
    name?: MonthName | undefined;
}
export type Months = Month[];
export type PatchingModeType = "ROLLING" | "NONROLLING" | (string & {});
export type PreferenceType = "NO_PREFERENCE" | "CUSTOM_PREFERENCE" | (string & {});
export type WeeksOfMonth = number[];
export interface MaintenanceWindow {
    customActionTimeoutInMins?: number | undefined;
    daysOfWeek?: DayOfWeek[] | undefined;
    hoursOfDay?: number[] | undefined;
    isCustomActionTimeoutEnabled?: boolean | undefined;
    leadTimeInWeeks?: number | undefined;
    months?: Month[] | undefined;
    patchingMode?: PatchingModeType | undefined;
    preference?: PreferenceType | undefined;
    skipRu?: boolean | undefined;
    weeksOfMonth?: number[] | undefined;
}
export interface CreateCloudAutonomousVmClusterInput {
    cloudExadataInfrastructureId: string;
    odbNetworkId: string;
    displayName: string;
    clientToken?: string | undefined;
    autonomousDataStorageSizeInTBs: number;
    cpuCoreCountPerNode: number;
    dbServers?: string[] | undefined;
    description?: string | undefined;
    isMtlsEnabledVmCluster?: boolean | undefined;
    licenseModel?: LicenseModel | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    memoryPerOracleComputeUnitInGBs: number;
    scanListenerPortNonTls?: number | undefined;
    scanListenerPortTls?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    timeZone?: string | undefined;
    totalContainerDatabases: number;
}
export interface CreateCloudAutonomousVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudAutonomousVmClusterId: string;
}
export interface CreateCloudExadataInfrastructureInput {
    displayName: string;
    shape: string;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    computeCount: number;
    customerContactsToSendToOCI?: CustomerContact[] | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    storageCount: number;
    clientToken?: string | undefined;
    databaseServerType?: string | undefined;
    storageServerType?: string | undefined;
}
export interface CreateCloudExadataInfrastructureOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureId: string;
}
export type VmStorageType = "LOCAL" | "EXASCALE" | (string & {});
export interface FileSystemConfigurationDetails {
    mountPoint?: string | undefined;
    fileSystemSizeInGBs?: number | undefined;
}
export type FileSystemConfigurationDetailsList = FileSystemConfigurationDetails[];
export type Hostname = string;
export type ClusterName = string;
export interface DataCollectionOptions {
    isDiagnosticsEventsEnabled?: boolean | undefined;
    isHealthMonitoringEnabled?: boolean | undefined;
    isIncidentLogsEnabled?: boolean | undefined;
}
export interface CreateCloudVmClusterInput {
    cloudExadataInfrastructureId: string;
    exascaleDbStorageVaultId?: string | undefined;
    vmFileSystemStorageType?: VmStorageType | undefined;
    vmBackupStorageType?: VmStorageType | undefined;
    fileSystemConfigurationDetails?: FileSystemConfigurationDetails[] | undefined;
    cpuCoreCount: number;
    displayName: string;
    giVersion: string;
    hostname: string;
    sshPublicKeys: string[];
    odbNetworkId: string;
    clusterName?: string | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServers?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    isLocalBackupEnabled?: boolean | undefined;
    isSparseDiskgroupEnabled?: boolean | undefined;
    licenseModel?: LicenseModel | undefined;
    memorySizeInGBs?: number | undefined;
    systemVersion?: string | undefined;
    timeZone?: string | undefined;
    clientToken?: string | undefined;
    scanListenerPortTcp?: number | undefined;
}
export interface CreateCloudVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudVmClusterId: string;
}
export type ShapeAttribute = "SMART_STORAGE" | "BLOCK_STORAGE" | (string & {});
export interface CreateExadbVmClusterInput {
    displayName: string;
    enabledEcpuCount: number;
    exascaleDbStorageVaultId: string;
    gridImageId: string;
    hostname: string;
    nodeCount: number;
    odbNetworkId: string;
    shape: string;
    sshPublicKeys: string[];
    totalEcpuCount: number;
    vmFileSystemStorageTotalSizeInGBs: number;
    clusterName?: string | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    licenseModel?: LicenseModel | undefined;
    scanListenerPortTcp?: number | undefined;
    scanListenerPortTcpSsl?: number | undefined;
    shapeAttribute?: ShapeAttribute | undefined;
    systemVersion?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    timeZone?: string | undefined;
    clientToken?: string | undefined;
}
export interface CreateExadbVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    exadbVmClusterId: string;
}
export interface CreateExascaleDbStorageVaultInput {
    displayName: string;
    highCapacityDatabaseStorageTotalSizeInGBs: number;
    additionalFlashCacheInPercent?: number | undefined;
    autoscaleLimitInGBs?: number | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    availabilityZoneId?: string | undefined;
    availabilityZone?: string | undefined;
    description?: string | undefined;
    isAutoscaleEnabled?: boolean | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    timeZone?: string | undefined;
    clientToken?: string | undefined;
}
export interface CreateExascaleDbStorageVaultOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    exascaleDbStorageVaultId: string;
}
export type Access = "ENABLED" | "DISABLED" | (string & {});
export type PolicyDocument = string;
export interface CreateOdbNetworkInput {
    displayName: string;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    clientSubnetCidr: string;
    backupSubnetCidr?: string | undefined;
    customDomainName?: string | undefined;
    defaultDnsPrefix?: string | undefined;
    clientToken?: string | undefined;
    s3Access?: Access | undefined;
    zeroEtlAccess?: Access | undefined;
    stsAccess?: Access | undefined;
    kmsAccess?: Access | undefined;
    s3PolicyDocument?: string | undefined;
    stsPolicyDocument?: string | undefined;
    kmsPolicyDocument?: string | undefined;
    crossRegionS3RestoreSourcesToEnable?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateOdbNetworkOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbNetworkId: string;
}
export type PeeredCidr = string;
export type PeeredCidrList = string[];
export type PeerNetworkRouteTableId = string;
export type PeerNetworkRouteTableIdList = string[];
export interface CreateOdbPeeringConnectionInput {
    odbNetworkId: string;
    peerNetworkId: string;
    displayName?: string | undefined;
    peerNetworkCidrsToBeAdded?: string[] | undefined;
    peerNetworkRouteTableIds?: string[] | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateOdbPeeringConnectionOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbPeeringConnectionId: string;
}
export interface DeleteAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface DeleteAutonomousDatabaseOutput {
}
export interface DeleteAutonomousDatabaseBackupInput {
    autonomousDatabaseBackupId: string;
}
export interface DeleteAutonomousDatabaseBackupOutput {
}
export interface DeleteCloudAutonomousVmClusterInput {
    cloudAutonomousVmClusterId: string;
}
export interface DeleteCloudAutonomousVmClusterOutput {
}
export interface DeleteCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
}
export interface DeleteCloudExadataInfrastructureOutput {
}
export interface DeleteCloudVmClusterInput {
    cloudVmClusterId: string;
}
export interface DeleteCloudVmClusterOutput {
}
export interface DeleteExadbVmClusterInput {
    exadbVmClusterId: string;
}
export interface DeleteExadbVmClusterOutput {
}
export interface DeleteExascaleDbStorageVaultInput {
    exascaleDbStorageVaultId: string;
}
export interface DeleteExascaleDbStorageVaultOutput {
}
export interface DeleteOdbNetworkInput {
    odbNetworkId: string;
    deleteAssociatedResources: boolean;
}
export interface DeleteOdbNetworkOutput {
}
export interface DeleteOdbPeeringConnectionInput {
    odbPeeringConnectionId: string;
}
export interface DeleteOdbPeeringConnectionOutput {
}
export interface DisassociateIamRoleFromResourceInput {
    iamRoleArn: string;
    awsIntegration: SupportedAwsIntegration;
    resourceArn: string;
}
export interface DisassociateIamRoleFromResourceOutput {
}
export interface DisassociateVirtualMachinesFromCloudVmClusterInput {
    cloudVmClusterId: string;
    dbServers: string[];
}
export interface DisassociateVirtualMachinesFromCloudVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudVmClusterId: string;
}
export type ResourceIdList = string[];
export interface DisassociateVirtualMachinesFromExadbVmClusterInput {
    exadbVmClusterId: string;
    dbNodeIds: string[];
}
export interface DisassociateVirtualMachinesFromExadbVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    exadbVmClusterId: string;
}
export type ResourceArn = string;
export interface FailoverAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    peerDbArn?: string | undefined;
}
export interface FailoverAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface GetAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export type DatabaseType = "REGULAR" | "CLONE" | (string & {});
export type PermissionLevel = "RESTRICTED" | "UNRESTRICTED" | (string & {});
export type NetServicesArchitecture = "DEDICATED" | "SHARED" | (string & {});
export type DatabaseConnectionStringMap = {
    [key: string]: string | undefined;
};
export interface DatabaseConnectionStringProfile {
    consumerGroup?: string | undefined;
    displayName?: string | undefined;
    hostFormat?: string | undefined;
    isRegional?: boolean | undefined;
    protocol?: string | undefined;
    sessionMode?: string | undefined;
    syntaxFormat?: string | undefined;
    tlsAuthentication?: string | undefined;
    value?: string | undefined;
}
export type DatabaseConnectionStringProfileList = DatabaseConnectionStringProfile[];
export interface AutonomousDatabaseConnectionStrings {
    allConnectionStrings?: {
        [key: string]: string | undefined;
    } | undefined;
    dedicated?: string | undefined;
    high?: string | undefined;
    medium?: string | undefined;
    low?: string | undefined;
    profiles?: DatabaseConnectionStringProfile[] | undefined;
}
export interface AutonomousDatabaseApex {
    apexVersion?: string | undefined;
    ordsVersion?: string | undefined;
}
export interface DatabaseStandbySummary {
    availabilityDomain?: string | undefined;
    lagTimeInSeconds?: number | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
    maintenanceTargetComponent?: string | undefined;
    timeDataGuardRoleChanged?: Date | undefined;
    timeDisasterRecoveryRoleChanged?: Date | undefined;
    timeMaintenanceBegin?: Date | undefined;
    timeMaintenanceEnd?: Date | undefined;
}
export type DataSafeStatus = "REGISTERING" | "REGISTERED" | "DEREGISTERING" | "NOT_REGISTERED" | "FAILED" | (string & {});
export type DatabaseManagementStatus = "ENABLING" | "ENABLED" | "DISABLING" | "NOT_ENABLED" | "FAILED_ENABLING" | "FAILED_DISABLING" | (string & {});
export type OperationsInsightsStatus = "ENABLING" | "ENABLED" | "DISABLING" | "NOT_ENABLED" | "FAILED_ENABLING" | "FAILED_DISABLING" | (string & {});
export interface AutonomousDatabaseConnectionUrls {
    apexUrl?: string | undefined;
    databaseTransformsUrl?: string | undefined;
    graphStudioUrl?: string | undefined;
    machineLearningNotebookUrl?: string | undefined;
    machineLearningUserManagementUrl?: string | undefined;
    mongoDbUrl?: string | undefined;
    ordsUrl?: string | undefined;
    spatialStudioUrl?: string | undefined;
    sqlDevWebUrl?: string | undefined;
}
export type ComputeModel = "ECPU" | "OCPU" | (string & {});
export type DataGuardRole = "PRIMARY" | "STANDBY" | "DISABLED_STANDBY" | "BACKUP_COPY" | "SNAPSHOT_STANDBY" | (string & {});
export interface DisasterRecoveryConfiguration {
    disasterRecoveryType?: DisasterRecoveryType | undefined;
    isReplicateAutomaticBackups?: boolean | undefined;
    isSnapshotStandby?: boolean | undefined;
    timeSnapshotStandbyEnabledTill?: Date | undefined;
}
export type RefreshableStatus = "REFRESHING" | "NOT_REFRESHING" | (string & {});
export type RepeatCadence = "ONE_TIME" | "WEEKLY" | "MONTHLY" | "YEARLY" | (string & {});
export interface LongTermBackupSchedule {
    isDisabled?: boolean | undefined;
    repeatCadence?: RepeatCadence | undefined;
    retentionPeriodInDays?: number | undefined;
    timeOfBackup?: Date | undefined;
}
export type EncryptionKeyProvider = "ORACLE_MANAGED" | "AWS_KMS" | "OKV" | "OCI" | (string & {});
export interface AwsEncryptionKeyConfiguration {
    iamRoleArn?: string | undefined;
    externalIdType?: ExternalIdType | undefined;
    kmsKeyId?: string | undefined;
}
export interface OciEncryptionKeyConfiguration {
    kmsKeyId: string;
    vaultId: string;
}
export interface OkvEncryptionKeyConfiguration {
    certificateDirectoryName: string;
    certificateId?: string | undefined;
    directoryName: string;
    okvKmsKey: string;
    okvUri: string;
}
export type EncryptionKeyConfiguration = {
    awsEncryptionKey: AwsEncryptionKeyConfiguration;
    ociEncryptionKey?: undefined;
    okvEncryptionKey?: undefined;
} | {
    awsEncryptionKey?: undefined;
    ociEncryptionKey: OciEncryptionKeyConfiguration;
    okvEncryptionKey?: undefined;
} | {
    awsEncryptionKey?: undefined;
    ociEncryptionKey?: undefined;
    okvEncryptionKey: OkvEncryptionKeyConfiguration;
};
export interface EncryptionSummary {
    encryptionKeyProvider?: EncryptionKeyProvider | undefined;
    encryptionKeyConfiguration?: EncryptionKeyConfiguration | undefined;
}
export interface CustomerManagedAwsSecretConfiguration {
    iamRoleArn?: string | undefined;
    secretId?: string | undefined;
    externalIdType?: ExternalIdType | undefined;
}
export type AdminPasswordSourceConfiguration = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfiguration;
};
export interface AdminPasswordSourceSummary {
    adminPasswordSource?: AdminPasswordSource | undefined;
    adminPasswordSourceConfiguration?: AdminPasswordSourceConfiguration | undefined;
}
export interface AutonomousDatabase {
    autonomousDatabaseId?: string | undefined;
    autonomousDatabaseArn?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    percentProgress?: number | undefined;
    ocid?: string | undefined;
    ociUrl?: string | undefined;
    displayName?: string | undefined;
    dbName?: string | undefined;
    sourceId?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
    databaseType?: DatabaseType | undefined;
    dbVersion?: string | undefined;
    dbWorkload?: DbWorkload | undefined;
    characterSet?: string | undefined;
    ncharacterSet?: string | undefined;
    databaseEdition?: DatabaseEdition | undefined;
    licenseModel?: LicenseModel | undefined;
    openMode?: OpenMode | undefined;
    permissionLevel?: PermissionLevel | undefined;
    isMtlsConnectionRequired?: boolean | undefined;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType | undefined;
    netServicesArchitecture?: NetServicesArchitecture | undefined;
    availableUpgradeVersions?: string[] | undefined;
    byolComputeCountLimit?: number | undefined;
    connectionStringDetails?: AutonomousDatabaseConnectionStrings | undefined;
    serviceConsoleUrl?: string | undefined;
    sqlWebDeveloperUrl?: string | undefined;
    customerContacts?: CustomerContact[] | undefined;
    apexDetails?: AutonomousDatabaseApex | undefined;
    standbyDb?: DatabaseStandbySummary | undefined;
    localStandbyDb?: DatabaseStandbySummary | undefined;
    dataSafeStatus?: DataSafeStatus | undefined;
    databaseManagementStatus?: DatabaseManagementStatus | undefined;
    operationsInsightsStatus?: OperationsInsightsStatus | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    maintenanceTargetComponent?: string | undefined;
    connectionUrls?: AutonomousDatabaseConnectionUrls | undefined;
    dbToolsDetails?: DatabaseTool[] | undefined;
    scheduledOperations?: ScheduledOperationDetails[] | undefined;
    resourcePoolLeaderId?: string | undefined;
    computeCount?: number | undefined;
    computeModel?: ComputeModel | undefined;
    cpuCoreCount?: number | undefined;
    memoryPerOracleComputeUnitInGBs?: number | undefined;
    provisionableCpus?: number[] | undefined;
    isAutoScalingEnabled?: boolean | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dataStorageSizeInGBs?: number | undefined;
    usedDataStorageSizeInTBs?: number | undefined;
    usedDataStorageSizeInGBs?: number | undefined;
    actualUsedDataStorageSizeInTBs?: number | undefined;
    allocatedStorageSizeInTBs?: number | undefined;
    inMemoryAreaInGBs?: number | undefined;
    isAutoScalingForStorageEnabled?: boolean | undefined;
    odbNetworkId?: string | undefined;
    odbNetworkArn?: string | undefined;
    privateEndpoint?: string | undefined;
    privateEndpointIp?: string | undefined;
    privateEndpointLabel?: string | undefined;
    allowlistedIps?: string[] | undefined;
    standbyAllowlistedIps?: string[] | undefined;
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource | undefined;
    isLocalDataGuardEnabled?: boolean | undefined;
    isRemoteDataGuardEnabled?: boolean | undefined;
    localDisasterRecoveryType?: DisasterRecoveryType | undefined;
    role?: DataGuardRole | undefined;
    peerDbIds?: string[] | undefined;
    failedDataRecoveryInSeconds?: number | undefined;
    localAdgAutoFailoverMaxDataLossLimit?: number | undefined;
    remoteDisasterRecoveryConfiguration?: DisasterRecoveryConfiguration | undefined;
    isRefreshableClone?: boolean | undefined;
    refreshableMode?: RefreshableMode | undefined;
    refreshableStatus?: RefreshableStatus | undefined;
    autoRefreshFrequencyInSeconds?: number | undefined;
    autoRefreshPointLagInSeconds?: number | undefined;
    isReconnectCloneEnabled?: boolean | undefined;
    cloneTableSpaceList?: number[] | undefined;
    backupRetentionPeriodInDays?: number | undefined;
    longTermBackupSchedule?: LongTermBackupSchedule | undefined;
    isBackupRetentionLocked?: boolean | undefined;
    totalBackupStorageSizeInGBs?: number | undefined;
    resourcePoolSummary?: ResourcePoolSummary | undefined;
    encryptionSummary?: EncryptionSummary | undefined;
    createdAt?: Date | undefined;
    timeOfLastBackup?: Date | undefined;
    timeMaintenanceBegin?: Date | undefined;
    timeMaintenanceEnd?: Date | undefined;
    timeLocalDataGuardEnabled?: Date | undefined;
    timeDataGuardRoleChanged?: Date | undefined;
    timeOfLastSwitchover?: Date | undefined;
    timeOfLastFailover?: Date | undefined;
    timeOfLastRefresh?: Date | undefined;
    timeOfLastRefreshPoint?: Date | undefined;
    timeOfNextRefresh?: Date | undefined;
    timeOfAutoRefreshStart?: Date | undefined;
    timeDeletionOfFreeAutonomousDatabase?: Date | undefined;
    timeReclamationOfFreeAutonomousDatabase?: Date | undefined;
    timeDisasterRecoveryRoleChanged?: Date | undefined;
    timeUntilReconnectCloneEnabled?: Date | undefined;
    nextLongTermBackupTimeStamp?: Date | undefined;
    timeUndeleted?: Date | undefined;
    adminPasswordSourceSummary?: AdminPasswordSourceSummary | undefined;
}
export interface GetAutonomousDatabaseOutput {
    autonomousDatabase: AutonomousDatabase;
}
export interface GetAutonomousDatabaseBackupInput {
    autonomousDatabaseBackupId: string;
}
export type AutonomousDatabaseBackupStatus = "ACTIVE" | "CREATING" | "UPDATING" | "DELETING" | "FAILED" | (string & {});
export type AutonomousDatabaseBackupType = "INCREMENTAL" | "FULL" | "LONGTERM" | "VIRTUAL_FULL" | "CUMULATIVE_INCREMENTAL" | "ROLL_FORWARD_IMAGE_COPY" | (string & {});
export interface AutonomousDatabaseBackup {
    autonomousDatabaseBackupId?: string | undefined;
    autonomousDatabaseBackupArn?: string | undefined;
    autonomousDatabaseId?: string | undefined;
    ocid?: string | undefined;
    displayName?: string | undefined;
    dbVersion?: string | undefined;
    status?: AutonomousDatabaseBackupStatus | undefined;
    statusReason?: string | undefined;
    isAutomatic?: boolean | undefined;
    retentionPeriodInDays?: number | undefined;
    sizeInTBs?: number | undefined;
    timeAvailableTill?: Date | undefined;
    timeStarted?: Date | undefined;
    timeEnded?: Date | undefined;
    type?: AutonomousDatabaseBackupType | undefined;
}
export interface GetAutonomousDatabaseBackupOutput {
    autonomousDatabaseBackup?: AutonomousDatabaseBackup | undefined;
}
export interface GetAutonomousDatabaseWalletDetailsInput {
    autonomousDatabaseId: string;
}
export type AutonomousDatabaseWalletStatus = "ACTIVE" | "UPDATING" | (string & {});
export type WalletPasswordSourceConfiguration = {
    customerManagedAwsSecret: CustomerManagedAwsSecretConfiguration;
};
export interface WalletPasswordSourceSummary {
    passwordSource?: WalletPasswordSource | undefined;
    passwordSourceConfiguration?: WalletPasswordSourceConfiguration | undefined;
}
export interface AutonomousDatabaseWalletDetails {
    status?: AutonomousDatabaseWalletStatus | undefined;
    timeRotated?: Date | undefined;
    passwordSourceSummary?: WalletPasswordSourceSummary | undefined;
}
export interface GetAutonomousDatabaseWalletDetailsOutput {
    autonomousDatabaseWalletDetails: AutonomousDatabaseWalletDetails;
}
export interface GetCloudAutonomousVmClusterInput {
    cloudAutonomousVmClusterId: string;
}
export type IamRoleStatus = "ASSOCIATING" | "DISASSOCIATING" | "FAILED" | "CONNECTED" | "DISCONNECTED" | "PARTIALLY_CONNECTED" | "UNKNOWN" | (string & {});
export interface IamRole {
    iamRoleArn?: string | undefined;
    status?: IamRoleStatus | undefined;
    statusReason?: string | undefined;
    awsIntegration?: SupportedAwsIntegration | undefined;
}
export type IamRoleList = IamRole[];
export interface CloudAutonomousVmCluster {
    cloudAutonomousVmClusterId: string;
    cloudAutonomousVmClusterArn?: string | undefined;
    odbNetworkId?: string | undefined;
    odbNetworkArn?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    percentProgress?: number | undefined;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    autonomousDataStoragePercentage?: number | undefined;
    autonomousDataStorageSizeInTBs?: number | undefined;
    availableAutonomousDataStorageSizeInTBs?: number | undefined;
    availableContainerDatabases?: number | undefined;
    availableCpus?: number | undefined;
    computeModel?: ComputeModel | undefined;
    cpuCoreCount?: number | undefined;
    cpuCoreCountPerNode?: number | undefined;
    cpuPercentage?: number | undefined;
    dataStorageSizeInGBs?: number | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServers?: string[] | undefined;
    description?: string | undefined;
    domain?: string | undefined;
    exadataStorageInTBsLowestScaledValue?: number | undefined;
    hostname?: string | undefined;
    ocid?: string | undefined;
    ociUrl?: string | undefined;
    isMtlsEnabledVmCluster?: boolean | undefined;
    licenseModel?: LicenseModel | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    maxAcdsLowestScaledValue?: number | undefined;
    memoryPerOracleComputeUnitInGBs?: number | undefined;
    memorySizeInGBs?: number | undefined;
    nodeCount?: number | undefined;
    nonProvisionableAutonomousContainerDatabases?: number | undefined;
    ocpusLowestScaledValue?: number | undefined;
    provisionableAutonomousContainerDatabases?: number | undefined;
    provisionedAutonomousContainerDatabases?: number | undefined;
    provisionedCpus?: number | undefined;
    reclaimableCpus?: number | undefined;
    reservedCpus?: number | undefined;
    scanListenerPortNonTls?: number | undefined;
    scanListenerPortTls?: number | undefined;
    shape?: string | undefined;
    createdAt?: Date | undefined;
    timeDatabaseSslCertificateExpires?: Date | undefined;
    timeOrdsCertificateExpires?: Date | undefined;
    timeZone?: string | undefined;
    totalContainerDatabases?: number | undefined;
    iamRoles?: IamRole[] | undefined;
}
export interface GetCloudAutonomousVmClusterOutput {
    cloudAutonomousVmCluster?: CloudAutonomousVmCluster | undefined;
}
export interface GetCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
}
export interface ExascaleConfiguration {
    totalStorageSizeInGBs?: number | undefined;
    availableStorageSizeInGBs?: number | undefined;
    totalVmStorageSizeInGBs?: number | undefined;
    availableVmStorageSizeInGBs?: number | undefined;
}
export interface CloudExadataInfrastructure {
    cloudExadataInfrastructureId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    activatedStorageCount?: number | undefined;
    additionalStorageCount?: number | undefined;
    availableStorageSizeInGBs?: number | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    computeCount?: number | undefined;
    cpuCount?: number | undefined;
    customerContactsToSendToOCI?: CustomerContact[] | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServerVersion?: string | undefined;
    lastMaintenanceRunId?: string | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    maxCpuCount?: number | undefined;
    maxDataStorageInTBs?: number | undefined;
    maxDbNodeStorageSizeInGBs?: number | undefined;
    maxMemoryInGBs?: number | undefined;
    memorySizeInGBs?: number | undefined;
    monthlyDbServerVersion?: string | undefined;
    monthlyStorageServerVersion?: string | undefined;
    nextMaintenanceRunId?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    ocid?: string | undefined;
    shape?: string | undefined;
    storageCount?: number | undefined;
    storageServerVersion?: string | undefined;
    createdAt?: Date | undefined;
    totalStorageSizeInGBs?: number | undefined;
    percentProgress?: number | undefined;
    databaseServerType?: string | undefined;
    storageServerType?: string | undefined;
    computeModel?: ComputeModel | undefined;
    exascaleConfiguration?: ExascaleConfiguration | undefined;
}
export interface GetCloudExadataInfrastructureOutput {
    cloudExadataInfrastructure?: CloudExadataInfrastructure | undefined;
}
export interface GetCloudExadataInfrastructureUnallocatedResourcesInput {
    cloudExadataInfrastructureId: string;
    dbServers?: string[] | undefined;
}
export interface CloudAutonomousVmClusterResourceDetails {
    cloudAutonomousVmClusterId?: string | undefined;
    unallocatedAdbStorageInTBs?: number | undefined;
}
export type CloudAutonomousVmClusterResourceDetailsList = CloudAutonomousVmClusterResourceDetails[];
export interface CloudExadataInfrastructureUnallocatedResources {
    cloudAutonomousVmClusters?: CloudAutonomousVmClusterResourceDetails[] | undefined;
    cloudExadataInfrastructureDisplayName?: string | undefined;
    exadataStorageInTBs?: number | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    localStorageInGBs?: number | undefined;
    memoryInGBs?: number | undefined;
    ocpus?: number | undefined;
}
export interface GetCloudExadataInfrastructureUnallocatedResourcesOutput {
    cloudExadataInfrastructureUnallocatedResources?: CloudExadataInfrastructureUnallocatedResources | undefined;
}
export interface GetCloudVmClusterInput {
    cloudVmClusterId: string;
}
export type StorageManagementType = "ASM" | "EXASCALE" | (string & {});
export type DiskRedundancy = "HIGH" | "NORMAL" | (string & {});
export interface DbIormConfig {
    dbName?: string | undefined;
    flashCacheLimit?: string | undefined;
    share?: number | undefined;
}
export type DbIormConfigList = DbIormConfig[];
export type IormLifecycleState = "BOOTSTRAPPING" | "DISABLED" | "ENABLED" | "FAILED" | "UPDATING" | (string & {});
export type Objective = "AUTO" | "BALANCED" | "BASIC" | "HIGH_THROUGHPUT" | "LOW_LATENCY" | (string & {});
export interface ExadataIormConfig {
    dbPlans?: DbIormConfig[] | undefined;
    lifecycleDetails?: string | undefined;
    lifecycleState?: IormLifecycleState | undefined;
    objective?: Objective | undefined;
}
export type SensitiveStringList = (string | redacted.Redacted<string>)[];
export interface CloudVmCluster {
    cloudVmClusterId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudVmClusterArn?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    exascaleDbStorageVaultId?: string | undefined;
    exascaleDbStorageVaultArn?: string | undefined;
    storageManagementType?: StorageManagementType | undefined;
    vmFileSystemStorageType?: VmStorageType | undefined;
    vmBackupStorageType?: VmStorageType | undefined;
    fileSystemConfigurationDetails?: FileSystemConfigurationDetails[] | undefined;
    clusterName?: string | undefined;
    cpuCoreCount?: number | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServers?: string[] | undefined;
    diskRedundancy?: DiskRedundancy | undefined;
    giVersion?: string | undefined;
    hostname?: string | undefined;
    iormConfigCache?: ExadataIormConfig | undefined;
    isLocalBackupEnabled?: boolean | undefined;
    isSparseDiskgroupEnabled?: boolean | undefined;
    lastUpdateHistoryEntryId?: string | undefined;
    licenseModel?: LicenseModel | undefined;
    listenerPort?: number | undefined;
    memorySizeInGBs?: number | undefined;
    nodeCount?: number | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    domain?: string | undefined;
    scanDnsName?: string | undefined;
    scanDnsRecordId?: string | undefined;
    scanIpIds?: string[] | undefined;
    shape?: string | undefined;
    sshPublicKeys?: (string | redacted.Redacted<string>)[] | undefined;
    storageSizeInGBs?: number | undefined;
    systemVersion?: string | undefined;
    createdAt?: Date | undefined;
    timeZone?: string | undefined;
    vipIds?: string[] | undefined;
    odbNetworkId?: string | undefined;
    odbNetworkArn?: string | undefined;
    percentProgress?: number | undefined;
    computeModel?: ComputeModel | undefined;
    iamRoles?: IamRole[] | undefined;
}
export interface GetCloudVmClusterOutput {
    cloudVmCluster?: CloudVmCluster | undefined;
}
export interface GetDbNodeInput {
    cloudVmClusterId?: string | undefined;
    exadbVmClusterId?: string | undefined;
    dbNodeId: string;
}
export type DbNodeResourceStatus = "AVAILABLE" | "FAILED" | "PROVISIONING" | "TERMINATED" | "TERMINATING" | "UPDATING" | "STOPPING" | "STOPPED" | "STARTING" | (string & {});
export type DbNodeMaintenanceType = "VMDB_REBOOT_MIGRATION" | (string & {});
export interface DbNode {
    dbNodeId?: string | undefined;
    dbNodeArn?: string | undefined;
    status?: DbNodeResourceStatus | undefined;
    statusReason?: string | undefined;
    additionalDetails?: string | undefined;
    backupIpId?: string | undefined;
    backupVnic2Id?: string | undefined;
    backupVnicId?: string | undefined;
    cpuCoreCount?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServerId?: string | undefined;
    dbSystemId?: string | undefined;
    faultDomain?: string | undefined;
    hostIpId?: string | undefined;
    hostname?: string | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    maintenanceType?: DbNodeMaintenanceType | undefined;
    memorySizeInGBs?: number | undefined;
    softwareStorageSizeInGB?: number | undefined;
    createdAt?: Date | undefined;
    timeMaintenanceWindowEnd?: string | undefined;
    timeMaintenanceWindowStart?: string | undefined;
    totalCpuCoreCount?: number | undefined;
    vnic2Id?: string | undefined;
    vnicId?: string | undefined;
    privateIpAddress?: string | undefined;
    floatingIpAddress?: string | undefined;
}
export interface GetDbNodeOutput {
    dbNode?: DbNode | undefined;
}
export interface GetDbServerInput {
    cloudExadataInfrastructureId: string;
    dbServerId: string;
}
export type DbServerPatchingStatus = "COMPLETE" | "FAILED" | "MAINTENANCE_IN_PROGRESS" | "SCHEDULED" | (string & {});
export interface DbServerPatchingDetails {
    estimatedPatchDuration?: number | undefined;
    patchingStatus?: DbServerPatchingStatus | undefined;
    timePatchingEnded?: string | undefined;
    timePatchingStarted?: string | undefined;
}
export interface DbServer {
    dbServerId?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cpuCoreCount?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServerPatchingDetails?: DbServerPatchingDetails | undefined;
    displayName?: string | undefined;
    exadataInfrastructureId?: string | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    maxCpuCount?: number | undefined;
    maxDbNodeStorageInGBs?: number | undefined;
    maxMemoryInGBs?: number | undefined;
    memorySizeInGBs?: number | undefined;
    shape?: string | undefined;
    createdAt?: Date | undefined;
    vmClusterIds?: string[] | undefined;
    computeModel?: ComputeModel | undefined;
    autonomousVmClusterIds?: string[] | undefined;
    autonomousVirtualMachineIds?: string[] | undefined;
}
export interface GetDbServerOutput {
    dbServer?: DbServer | undefined;
}
export interface GetExadbVmClusterInput {
    exadbVmClusterId: string;
}
export type GridImageType = "RELEASE_UPDATE" | "CUSTOM_IMAGE" | (string & {});
export interface ExadbVmClusterStorageDetails {
    totalSizeInGBs?: number | undefined;
}
export interface ExadbVmCluster {
    exadbVmClusterId: string;
    clusterName?: string | undefined;
    createdAt?: Date | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    displayName?: string | undefined;
    domain?: string | undefined;
    enabledEcpuCount?: number | undefined;
    exadbVmClusterArn?: string | undefined;
    exascaleDbStorageVaultArn?: string | undefined;
    exascaleDbStorageVaultId?: string | undefined;
    giVersion?: string | undefined;
    gridImageId?: string | undefined;
    gridImageType?: GridImageType | undefined;
    hostname?: string | undefined;
    iamRoles?: IamRole[] | undefined;
    iormConfigCache?: ExadataIormConfig | undefined;
    lastUpdateHistoryEntryId?: string | undefined;
    licenseModel?: LicenseModel | undefined;
    listenerPort?: number | undefined;
    memorySizeInGBs?: number | undefined;
    nodeCount?: number | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    odbNetworkArn?: string | undefined;
    odbNetworkId?: string | undefined;
    percentProgress?: number | undefined;
    scanDnsName?: string | undefined;
    scanDnsRecordId?: string | undefined;
    scanIpIds?: string[] | undefined;
    scanListenerPortTcp?: number | undefined;
    scanListenerPortTcpSsl?: number | undefined;
    shape?: string | undefined;
    shapeAttribute?: ShapeAttribute | undefined;
    snapshotFileSystemStorage?: ExadbVmClusterStorageDetails | undefined;
    sshPublicKeys?: string[] | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    systemVersion?: string | undefined;
    timeZone?: string | undefined;
    totalEcpuCount?: number | undefined;
    totalFileSystemStorage?: ExadbVmClusterStorageDetails | undefined;
    vipIds?: string[] | undefined;
    vmFileSystemStorage?: ExadbVmClusterStorageDetails | undefined;
}
export interface GetExadbVmClusterOutput {
    exadbVmCluster: ExadbVmCluster;
}
export interface GetExascaleDbStorageVaultInput {
    exascaleDbStorageVaultId: string;
}
export type ShapeAttributeList = ShapeAttribute[];
export type ResourceArnList = string[];
export interface ExascaleDbStorageDetails {
    availableSizeInGBs?: number | undefined;
    totalSizeInGBs?: number | undefined;
}
export type ExascaleDbStorageVaultType = "EXASCALE_INFRASTRUCTURE" | "DEDICATED_INFRASTRUCTURE" | (string & {});
export interface ExascaleDbStorageVault {
    exascaleDbStorageVaultId: string;
    additionalFlashCacheInPercent?: number | undefined;
    attachedShapeAttributes?: ShapeAttribute[] | undefined;
    autoscaleLimitInGBs?: number | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    displayName?: string | undefined;
    vmClusterArns?: string[] | undefined;
    vmClusterCount?: number | undefined;
    vmClusterIds?: string[] | undefined;
    exascaleDbStorageVaultArn?: string | undefined;
    highCapacityDatabaseStorage?: ExascaleDbStorageDetails | undefined;
    isAutoscaleEnabled?: boolean | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    percentProgress?: number | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    timeZone?: string | undefined;
    vaultType?: ExascaleDbStorageVaultType | undefined;
}
export interface GetExascaleDbStorageVaultOutput {
    exascaleDbStorageVault: ExascaleDbStorageVault;
}
export interface GetOciOnboardingStatusInput {
}
export type OciOnboardingStatus = "NOT_STARTED" | "PENDING_LINK_GENERATION" | "PENDING_CUSTOMER_ACTION" | "PENDING_INITIALIZATION" | "ACTIVATING" | "ACTIVE_IN_HOME_REGION" | "ACTIVE" | "ACTIVE_LIMITED" | "FAILED" | "PUBLIC_OFFER_UNSUPPORTED" | "SUSPENDED" | "CANCELED" | (string & {});
export interface OciIdentityDomain {
    ociIdentityDomainId?: string | undefined;
    ociIdentityDomainResourceUrl?: string | undefined;
    ociIdentityDomainUrl?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    accountSetupCloudFormationUrl?: string | undefined;
}
export type OciAwsIntegration = "KmsTde" | "SecretsManager" | (string & {});
export type OciIamRoleStatus = "PROVISIONING" | "AVAILABLE" | "PROVISION_FAILED" | "TERMINATING" | "TERMINATE_FAILED" | (string & {});
export interface OciIamRole {
    iamRoleArn?: string | undefined;
    awsIntegration?: OciAwsIntegration | undefined;
    status?: OciIamRoleStatus | undefined;
    statusReason?: string | undefined;
}
export type OciIamRoleList = OciIamRole[];
export interface SubscriptionError {
    errorMessage?: string | undefined;
}
export type SubscriptionErrors = SubscriptionError[];
export interface GetOciOnboardingStatusOutput {
    status?: OciOnboardingStatus | undefined;
    existingTenancyActivationLink?: string | undefined;
    newTenancyActivationLink?: string | undefined;
    ociIdentityDomain?: OciIdentityDomain | undefined;
    autonomousDatabaseOciIntegrationIamRoles?: OciIamRole[] | undefined;
    linkedOciTenancyId?: string | undefined;
    linkedOciCompartmentId?: string | undefined;
    subscriptionErrors?: SubscriptionError[] | undefined;
}
export interface GetOdbNetworkInput {
    odbNetworkId: string;
}
export interface OciDnsForwardingConfig {
    domainName?: string | undefined;
    ociDnsListenerIp?: string | undefined;
}
export type OciDnsForwardingConfigList = OciDnsForwardingConfig[];
export type VpcEndpointType = "SERVICENETWORK" | (string & {});
export interface ServiceNetworkEndpoint {
    vpcEndpointId?: string | undefined;
    vpcEndpointType?: VpcEndpointType | undefined;
}
export type ManagedResourceStatus = "ENABLED" | "ENABLING" | "DISABLED" | "DISABLING" | (string & {});
export interface ManagedS3BackupAccess {
    status?: ManagedResourceStatus | undefined;
    ipv4Addresses?: string[] | undefined;
}
export interface ZeroEtlAccess {
    status?: ManagedResourceStatus | undefined;
    cidr?: string | undefined;
}
export interface S3Access {
    status?: ManagedResourceStatus | undefined;
    ipv4Addresses?: string[] | undefined;
    domainName?: string | undefined;
    s3PolicyDocument?: string | undefined;
}
export interface StsAccess {
    status?: ManagedResourceStatus | undefined;
    ipv4Addresses?: string[] | undefined;
    domainName?: string | undefined;
    stsPolicyDocument?: string | undefined;
}
export interface KmsAccess {
    status?: ManagedResourceStatus | undefined;
    ipv4Addresses?: string[] | undefined;
    domainName?: string | undefined;
    kmsPolicyDocument?: string | undefined;
}
export interface CrossRegionS3RestoreSourcesAccess {
    region?: string | undefined;
    ipv4Addresses?: string[] | undefined;
    status?: ManagedResourceStatus | undefined;
}
export type CrossRegionS3RestoreSourcesAccessList = CrossRegionS3RestoreSourcesAccess[];
export interface ManagedServices {
    serviceNetworkArn?: string | undefined;
    resourceGatewayArn?: string | undefined;
    managedServicesIpv4Cidrs?: string[] | undefined;
    serviceNetworkEndpoint?: ServiceNetworkEndpoint | undefined;
    managedS3BackupAccess?: ManagedS3BackupAccess | undefined;
    zeroEtlAccess?: ZeroEtlAccess | undefined;
    s3Access?: S3Access | undefined;
    stsAccess?: StsAccess | undefined;
    kmsAccess?: KmsAccess | undefined;
    crossRegionS3RestoreSourcesAccess?: CrossRegionS3RestoreSourcesAccess[] | undefined;
}
export interface OdbNetwork {
    odbNetworkId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbNetworkArn?: string | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    clientSubnetCidr?: string | undefined;
    backupSubnetCidr?: string | undefined;
    customDomainName?: string | undefined;
    defaultDnsPrefix?: string | undefined;
    peeredCidrs?: string[] | undefined;
    ociNetworkAnchorId?: string | undefined;
    ociNetworkAnchorUrl?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociVcnId?: string | undefined;
    ociVcnUrl?: string | undefined;
    ociDnsForwardingConfigs?: OciDnsForwardingConfig[] | undefined;
    createdAt?: Date | undefined;
    percentProgress?: number | undefined;
    managedServices?: ManagedServices | undefined;
    ec2PlacementGroupIds?: string[] | undefined;
}
export interface GetOdbNetworkOutput {
    odbNetwork?: OdbNetwork | undefined;
}
export interface GetOdbPeeringConnectionInput {
    odbPeeringConnectionId: string;
}
export interface OdbPeeringConnection {
    odbPeeringConnectionId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbPeeringConnectionArn?: string | undefined;
    odbNetworkArn?: string | undefined;
    peerNetworkArn?: string | undefined;
    odbPeeringConnectionType?: string | undefined;
    peerNetworkCidrs?: string[] | undefined;
    createdAt?: Date | undefined;
    percentProgress?: number | undefined;
}
export interface GetOdbPeeringConnectionOutput {
    odbPeeringConnection?: OdbPeeringConnection | undefined;
}
export interface InitializeServiceInput {
    ociIdentityDomain?: boolean | undefined;
    autonomousDatabaseOciAwsSecretsManagerIntegration?: Access | undefined;
}
export interface InitializeServiceOutput {
}
export interface ListAutonomousDatabaseBackupsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    autonomousDatabaseId: string;
    status?: AutonomousDatabaseBackupStatus | undefined;
    type?: AutonomousDatabaseBackupType | undefined;
}
export interface AutonomousDatabaseBackupSummary {
    autonomousDatabaseBackupId?: string | undefined;
    autonomousDatabaseBackupArn?: string | undefined;
    autonomousDatabaseId?: string | undefined;
    ocid?: string | undefined;
    displayName?: string | undefined;
    dbVersion?: string | undefined;
    status?: AutonomousDatabaseBackupStatus | undefined;
    statusReason?: string | undefined;
    isAutomatic?: boolean | undefined;
    retentionPeriodInDays?: number | undefined;
    sizeInTBs?: number | undefined;
    timeAvailableTill?: Date | undefined;
    timeStarted?: Date | undefined;
    timeEnded?: Date | undefined;
    type?: AutonomousDatabaseBackupType | undefined;
}
export type AutonomousDatabaseBackupList = AutonomousDatabaseBackupSummary[];
export interface ListAutonomousDatabaseBackupsOutput {
    nextToken?: string | undefined;
    autonomousDatabaseBackups: AutonomousDatabaseBackupSummary[];
}
export type CharacterSetType = "DATABASE" | "NATIONAL" | (string & {});
export interface ListAutonomousDatabaseCharacterSetsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    characterSetType?: CharacterSetType | undefined;
}
export interface AutonomousDatabaseCharacterSetSummary {
    characterSet?: string | undefined;
}
export type AutonomousDatabaseCharacterSetList = AutonomousDatabaseCharacterSetSummary[];
export interface ListAutonomousDatabaseCharacterSetsOutput {
    nextToken?: string | undefined;
    autonomousDatabaseCharacterSets: AutonomousDatabaseCharacterSetSummary[];
}
export interface ListAutonomousDatabaseClonesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    autonomousDatabaseId: string;
}
export interface AutonomousDatabaseSummary {
    autonomousDatabaseId?: string | undefined;
    autonomousDatabaseArn?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    percentProgress?: number | undefined;
    ocid?: string | undefined;
    ociUrl?: string | undefined;
    displayName?: string | undefined;
    dbName?: string | undefined;
    sourceId?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
    databaseType?: DatabaseType | undefined;
    dbVersion?: string | undefined;
    dbWorkload?: DbWorkload | undefined;
    characterSet?: string | undefined;
    ncharacterSet?: string | undefined;
    databaseEdition?: DatabaseEdition | undefined;
    licenseModel?: LicenseModel | undefined;
    openMode?: OpenMode | undefined;
    permissionLevel?: PermissionLevel | undefined;
    isMtlsConnectionRequired?: boolean | undefined;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType | undefined;
    netServicesArchitecture?: NetServicesArchitecture | undefined;
    availableUpgradeVersions?: string[] | undefined;
    byolComputeCountLimit?: number | undefined;
    connectionStringDetails?: AutonomousDatabaseConnectionStrings | undefined;
    serviceConsoleUrl?: string | undefined;
    sqlWebDeveloperUrl?: string | undefined;
    customerContacts?: CustomerContact[] | undefined;
    apexDetails?: AutonomousDatabaseApex | undefined;
    standbyDb?: DatabaseStandbySummary | undefined;
    localStandbyDb?: DatabaseStandbySummary | undefined;
    dataSafeStatus?: DataSafeStatus | undefined;
    databaseManagementStatus?: DatabaseManagementStatus | undefined;
    operationsInsightsStatus?: OperationsInsightsStatus | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    maintenanceTargetComponent?: string | undefined;
    connectionUrls?: AutonomousDatabaseConnectionUrls | undefined;
    dbToolsDetails?: DatabaseTool[] | undefined;
    scheduledOperations?: ScheduledOperationDetails[] | undefined;
    resourcePoolLeaderId?: string | undefined;
    computeCount?: number | undefined;
    computeModel?: ComputeModel | undefined;
    cpuCoreCount?: number | undefined;
    memoryPerOracleComputeUnitInGBs?: number | undefined;
    provisionableCpus?: number[] | undefined;
    isAutoScalingEnabled?: boolean | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dataStorageSizeInGBs?: number | undefined;
    usedDataStorageSizeInTBs?: number | undefined;
    usedDataStorageSizeInGBs?: number | undefined;
    actualUsedDataStorageSizeInTBs?: number | undefined;
    allocatedStorageSizeInTBs?: number | undefined;
    inMemoryAreaInGBs?: number | undefined;
    isAutoScalingForStorageEnabled?: boolean | undefined;
    odbNetworkId?: string | undefined;
    odbNetworkArn?: string | undefined;
    privateEndpoint?: string | undefined;
    privateEndpointIp?: string | undefined;
    privateEndpointLabel?: string | undefined;
    allowlistedIps?: string[] | undefined;
    standbyAllowlistedIps?: string[] | undefined;
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource | undefined;
    isLocalDataGuardEnabled?: boolean | undefined;
    isRemoteDataGuardEnabled?: boolean | undefined;
    localDisasterRecoveryType?: DisasterRecoveryType | undefined;
    role?: DataGuardRole | undefined;
    peerDbIds?: string[] | undefined;
    failedDataRecoveryInSeconds?: number | undefined;
    localAdgAutoFailoverMaxDataLossLimit?: number | undefined;
    remoteDisasterRecoveryConfiguration?: DisasterRecoveryConfiguration | undefined;
    isRefreshableClone?: boolean | undefined;
    refreshableMode?: RefreshableMode | undefined;
    refreshableStatus?: RefreshableStatus | undefined;
    autoRefreshFrequencyInSeconds?: number | undefined;
    autoRefreshPointLagInSeconds?: number | undefined;
    isReconnectCloneEnabled?: boolean | undefined;
    cloneTableSpaceList?: number[] | undefined;
    backupRetentionPeriodInDays?: number | undefined;
    longTermBackupSchedule?: LongTermBackupSchedule | undefined;
    isBackupRetentionLocked?: boolean | undefined;
    totalBackupStorageSizeInGBs?: number | undefined;
    resourcePoolSummary?: ResourcePoolSummary | undefined;
    encryptionSummary?: EncryptionSummary | undefined;
    createdAt?: Date | undefined;
    timeOfLastBackup?: Date | undefined;
    timeMaintenanceBegin?: Date | undefined;
    timeMaintenanceEnd?: Date | undefined;
    timeLocalDataGuardEnabled?: Date | undefined;
    timeDataGuardRoleChanged?: Date | undefined;
    timeOfLastSwitchover?: Date | undefined;
    timeOfLastFailover?: Date | undefined;
    timeOfLastRefresh?: Date | undefined;
    timeOfLastRefreshPoint?: Date | undefined;
    timeOfNextRefresh?: Date | undefined;
    timeOfAutoRefreshStart?: Date | undefined;
    timeDeletionOfFreeAutonomousDatabase?: Date | undefined;
    timeReclamationOfFreeAutonomousDatabase?: Date | undefined;
    timeDisasterRecoveryRoleChanged?: Date | undefined;
    timeUntilReconnectCloneEnabled?: Date | undefined;
    nextLongTermBackupTimeStamp?: Date | undefined;
    timeUndeleted?: Date | undefined;
    adminPasswordSourceSummary?: AdminPasswordSourceSummary | undefined;
}
export type AutonomousDatabaseList = AutonomousDatabaseSummary[];
export interface ListAutonomousDatabaseClonesOutput {
    nextToken?: string | undefined;
    autonomousDatabaseClones: AutonomousDatabaseSummary[];
}
export interface ListAutonomousDatabasePeersInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    autonomousDatabaseId: string;
}
export interface AutonomousDatabasePeerSummary {
    autonomousDatabaseId?: string | undefined;
    autonomousDatabaseArn?: string | undefined;
    ocid?: string | undefined;
    region?: string | undefined;
}
export type AutonomousDatabasePeerList = AutonomousDatabasePeerSummary[];
export interface ListAutonomousDatabasePeersOutput {
    nextToken?: string | undefined;
    autonomousDatabasePeers: AutonomousDatabasePeerSummary[];
}
export interface ListAutonomousDatabasesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListAutonomousDatabasesOutput {
    nextToken?: string | undefined;
    autonomousDatabases: AutonomousDatabaseSummary[];
}
export interface ListAutonomousDatabaseVersionsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    dbWorkload?: DbWorkload | undefined;
}
export interface AutonomousDatabaseVersionSummary {
    dbWorkload?: DbWorkload | undefined;
    details?: string | undefined;
    version?: string | undefined;
}
export type AutonomousDatabaseVersionList = AutonomousDatabaseVersionSummary[];
export interface ListAutonomousDatabaseVersionsOutput {
    nextToken?: string | undefined;
    autonomousDatabaseVersions: AutonomousDatabaseVersionSummary[];
}
export interface ListAutonomousVirtualMachinesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    cloudAutonomousVmClusterId: string;
}
export interface AutonomousVirtualMachineSummary {
    autonomousVirtualMachineId?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    vmName?: string | undefined;
    dbServerId?: string | undefined;
    dbServerDisplayName?: string | undefined;
    cpuCoreCount?: number | undefined;
    memorySizeInGBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    clientIpAddress?: string | undefined;
    cloudAutonomousVmClusterId?: string | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
}
export type AutonomousVirtualMachineList = AutonomousVirtualMachineSummary[];
export interface ListAutonomousVirtualMachinesOutput {
    nextToken?: string | undefined;
    autonomousVirtualMachines: AutonomousVirtualMachineSummary[];
}
export interface ListCloudAutonomousVmClustersInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
}
export interface CloudAutonomousVmClusterSummary {
    cloudAutonomousVmClusterId: string;
    cloudAutonomousVmClusterArn?: string | undefined;
    odbNetworkId?: string | undefined;
    odbNetworkArn?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    percentProgress?: number | undefined;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    autonomousDataStoragePercentage?: number | undefined;
    autonomousDataStorageSizeInTBs?: number | undefined;
    availableAutonomousDataStorageSizeInTBs?: number | undefined;
    availableContainerDatabases?: number | undefined;
    availableCpus?: number | undefined;
    computeModel?: ComputeModel | undefined;
    cpuCoreCount?: number | undefined;
    cpuCoreCountPerNode?: number | undefined;
    cpuPercentage?: number | undefined;
    dataStorageSizeInGBs?: number | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServers?: string[] | undefined;
    description?: string | undefined;
    domain?: string | undefined;
    exadataStorageInTBsLowestScaledValue?: number | undefined;
    hostname?: string | undefined;
    ocid?: string | undefined;
    ociUrl?: string | undefined;
    isMtlsEnabledVmCluster?: boolean | undefined;
    licenseModel?: LicenseModel | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    maxAcdsLowestScaledValue?: number | undefined;
    memoryPerOracleComputeUnitInGBs?: number | undefined;
    memorySizeInGBs?: number | undefined;
    nodeCount?: number | undefined;
    nonProvisionableAutonomousContainerDatabases?: number | undefined;
    ocpusLowestScaledValue?: number | undefined;
    provisionableAutonomousContainerDatabases?: number | undefined;
    provisionedAutonomousContainerDatabases?: number | undefined;
    provisionedCpus?: number | undefined;
    reclaimableCpus?: number | undefined;
    reservedCpus?: number | undefined;
    scanListenerPortNonTls?: number | undefined;
    scanListenerPortTls?: number | undefined;
    shape?: string | undefined;
    createdAt?: Date | undefined;
    timeDatabaseSslCertificateExpires?: Date | undefined;
    timeOrdsCertificateExpires?: Date | undefined;
    timeZone?: string | undefined;
    totalContainerDatabases?: number | undefined;
    iamRoles?: IamRole[] | undefined;
}
export type CloudAutonomousVmClusterList = CloudAutonomousVmClusterSummary[];
export interface ListCloudAutonomousVmClustersOutput {
    nextToken?: string | undefined;
    cloudAutonomousVmClusters: CloudAutonomousVmClusterSummary[];
}
export interface ListCloudExadataInfrastructuresInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface CloudExadataInfrastructureSummary {
    cloudExadataInfrastructureId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    activatedStorageCount?: number | undefined;
    additionalStorageCount?: number | undefined;
    availableStorageSizeInGBs?: number | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    computeCount?: number | undefined;
    cpuCount?: number | undefined;
    customerContactsToSendToOCI?: CustomerContact[] | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServerVersion?: string | undefined;
    lastMaintenanceRunId?: string | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    maxCpuCount?: number | undefined;
    maxDataStorageInTBs?: number | undefined;
    maxDbNodeStorageSizeInGBs?: number | undefined;
    maxMemoryInGBs?: number | undefined;
    memorySizeInGBs?: number | undefined;
    monthlyDbServerVersion?: string | undefined;
    monthlyStorageServerVersion?: string | undefined;
    nextMaintenanceRunId?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    ocid?: string | undefined;
    shape?: string | undefined;
    storageCount?: number | undefined;
    storageServerVersion?: string | undefined;
    createdAt?: Date | undefined;
    totalStorageSizeInGBs?: number | undefined;
    percentProgress?: number | undefined;
    databaseServerType?: string | undefined;
    storageServerType?: string | undefined;
    computeModel?: ComputeModel | undefined;
    exascaleConfiguration?: ExascaleConfiguration | undefined;
}
export type CloudExadataInfrastructureList = CloudExadataInfrastructureSummary[];
export interface ListCloudExadataInfrastructuresOutput {
    nextToken?: string | undefined;
    cloudExadataInfrastructures: CloudExadataInfrastructureSummary[];
}
export interface ListCloudVmClustersInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
}
export interface CloudVmClusterSummary {
    cloudVmClusterId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudVmClusterArn?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    exascaleDbStorageVaultId?: string | undefined;
    exascaleDbStorageVaultArn?: string | undefined;
    storageManagementType?: StorageManagementType | undefined;
    vmFileSystemStorageType?: VmStorageType | undefined;
    vmBackupStorageType?: VmStorageType | undefined;
    fileSystemConfigurationDetails?: FileSystemConfigurationDetails[] | undefined;
    clusterName?: string | undefined;
    cpuCoreCount?: number | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServers?: string[] | undefined;
    diskRedundancy?: DiskRedundancy | undefined;
    giVersion?: string | undefined;
    hostname?: string | undefined;
    iormConfigCache?: ExadataIormConfig | undefined;
    isLocalBackupEnabled?: boolean | undefined;
    isSparseDiskgroupEnabled?: boolean | undefined;
    lastUpdateHistoryEntryId?: string | undefined;
    licenseModel?: LicenseModel | undefined;
    listenerPort?: number | undefined;
    memorySizeInGBs?: number | undefined;
    nodeCount?: number | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    domain?: string | undefined;
    scanDnsName?: string | undefined;
    scanDnsRecordId?: string | undefined;
    scanIpIds?: string[] | undefined;
    shape?: string | undefined;
    sshPublicKeys?: (string | redacted.Redacted<string>)[] | undefined;
    storageSizeInGBs?: number | undefined;
    systemVersion?: string | undefined;
    createdAt?: Date | undefined;
    timeZone?: string | undefined;
    vipIds?: string[] | undefined;
    odbNetworkId?: string | undefined;
    odbNetworkArn?: string | undefined;
    percentProgress?: number | undefined;
    computeModel?: ComputeModel | undefined;
    iamRoles?: IamRole[] | undefined;
}
export type CloudVmClusterList = CloudVmClusterSummary[];
export interface ListCloudVmClustersOutput {
    nextToken?: string | undefined;
    cloudVmClusters: CloudVmClusterSummary[];
}
export interface ListDbNodesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    cloudVmClusterId?: string | undefined;
    exadbVmClusterId?: string | undefined;
}
export interface DbNodeSummary {
    dbNodeId?: string | undefined;
    dbNodeArn?: string | undefined;
    status?: DbNodeResourceStatus | undefined;
    statusReason?: string | undefined;
    additionalDetails?: string | undefined;
    backupIpId?: string | undefined;
    backupVnic2Id?: string | undefined;
    backupVnicId?: string | undefined;
    cpuCoreCount?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServerId?: string | undefined;
    dbSystemId?: string | undefined;
    faultDomain?: string | undefined;
    hostIpId?: string | undefined;
    hostname?: string | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    maintenanceType?: DbNodeMaintenanceType | undefined;
    memorySizeInGBs?: number | undefined;
    softwareStorageSizeInGB?: number | undefined;
    createdAt?: Date | undefined;
    timeMaintenanceWindowEnd?: string | undefined;
    timeMaintenanceWindowStart?: string | undefined;
    totalCpuCoreCount?: number | undefined;
    vnic2Id?: string | undefined;
    vnicId?: string | undefined;
}
export type DbNodeList = DbNodeSummary[];
export interface ListDbNodesOutput {
    nextToken?: string | undefined;
    dbNodes: DbNodeSummary[];
}
export interface ListDbServersInput {
    cloudExadataInfrastructureId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DbServerSummary {
    dbServerId?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cpuCoreCount?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    dbServerPatchingDetails?: DbServerPatchingDetails | undefined;
    displayName?: string | undefined;
    exadataInfrastructureId?: string | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    maxCpuCount?: number | undefined;
    maxDbNodeStorageInGBs?: number | undefined;
    maxMemoryInGBs?: number | undefined;
    memorySizeInGBs?: number | undefined;
    shape?: string | undefined;
    createdAt?: Date | undefined;
    vmClusterIds?: string[] | undefined;
    computeModel?: ComputeModel | undefined;
    autonomousVmClusterIds?: string[] | undefined;
    autonomousVirtualMachineIds?: string[] | undefined;
}
export type DbServerList = DbServerSummary[];
export interface ListDbServersOutput {
    nextToken?: string | undefined;
    dbServers: DbServerSummary[];
}
export interface ListDbSystemShapesInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    shapeFamily?: string | undefined;
}
export type ShapeType = "AMD" | "INTEL" | "INTEL_FLEX_X9" | "AMPERE_FLEX_A1" | (string & {});
export interface DbSystemShapeSummary {
    availableCoreCount?: number | undefined;
    availableCoreCountPerNode?: number | undefined;
    availableDataStorageInTBs?: number | undefined;
    availableDataStoragePerServerInTBs?: number | undefined;
    availableDbNodePerNodeInGBs?: number | undefined;
    availableDbNodeStorageInGBs?: number | undefined;
    availableMemoryInGBs?: number | undefined;
    availableMemoryPerNodeInGBs?: number | undefined;
    coreCountIncrement?: number | undefined;
    maxStorageCount?: number | undefined;
    maximumNodeCount?: number | undefined;
    minCoreCountPerNode?: number | undefined;
    minDataStorageInTBs?: number | undefined;
    minDbNodeStoragePerNodeInGBs?: number | undefined;
    minMemoryPerNodeInGBs?: number | undefined;
    minStorageCount?: number | undefined;
    minimumCoreCount?: number | undefined;
    minimumNodeCount?: number | undefined;
    runtimeMinimumCoreCount?: number | undefined;
    shapeFamily?: string | undefined;
    shapeType?: ShapeType | undefined;
    shapeAttributes?: ShapeAttribute[] | undefined;
    name?: string | undefined;
    computeModel?: ComputeModel | undefined;
    areServerTypesSupported?: boolean | undefined;
}
export type DbSystemShapeList = DbSystemShapeSummary[];
export interface ListDbSystemShapesOutput {
    nextToken?: string | undefined;
    dbSystemShapes: DbSystemShapeSummary[];
}
export interface ListExadbVmClustersInput {
    exascaleDbStorageVaultId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ExadbVmClusterSummary {
    exadbVmClusterId: string;
    clusterName?: string | undefined;
    createdAt?: Date | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    displayName?: string | undefined;
    domain?: string | undefined;
    enabledEcpuCount?: number | undefined;
    exadbVmClusterArn?: string | undefined;
    exascaleDbStorageVaultArn?: string | undefined;
    exascaleDbStorageVaultId?: string | undefined;
    giVersion?: string | undefined;
    gridImageId?: string | undefined;
    gridImageType?: GridImageType | undefined;
    hostname?: string | undefined;
    iamRoles?: IamRole[] | undefined;
    iormConfigCache?: ExadataIormConfig | undefined;
    lastUpdateHistoryEntryId?: string | undefined;
    licenseModel?: LicenseModel | undefined;
    listenerPort?: number | undefined;
    memorySizeInGBs?: number | undefined;
    nodeCount?: number | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    odbNetworkArn?: string | undefined;
    odbNetworkId?: string | undefined;
    percentProgress?: number | undefined;
    scanDnsName?: string | undefined;
    scanDnsRecordId?: string | undefined;
    scanIpIds?: string[] | undefined;
    scanListenerPortTcp?: number | undefined;
    scanListenerPortTcpSsl?: number | undefined;
    shape?: string | undefined;
    shapeAttribute?: ShapeAttribute | undefined;
    snapshotFileSystemStorage?: ExadbVmClusterStorageDetails | undefined;
    sshPublicKeys?: string[] | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    systemVersion?: string | undefined;
    timeZone?: string | undefined;
    totalEcpuCount?: number | undefined;
    totalFileSystemStorage?: ExadbVmClusterStorageDetails | undefined;
    vipIds?: string[] | undefined;
    vmFileSystemStorage?: ExadbVmClusterStorageDetails | undefined;
}
export type ExadbVmClusterList = ExadbVmClusterSummary[];
export interface ListExadbVmClustersOutput {
    nextToken?: string | undefined;
    exadbVmClusters: ExadbVmClusterSummary[];
}
export interface ListExascaleDbStorageVaultsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    vaultType?: ExascaleDbStorageVaultType | undefined;
}
export interface ExascaleDbStorageVaultSummary {
    exascaleDbStorageVaultId: string;
    additionalFlashCacheInPercent?: number | undefined;
    attachedShapeAttributes?: ShapeAttribute[] | undefined;
    autoscaleLimitInGBs?: number | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    cloudExadataInfrastructureArn?: string | undefined;
    cloudExadataInfrastructureId?: string | undefined;
    createdAt?: Date | undefined;
    description?: string | undefined;
    displayName?: string | undefined;
    vmClusterArns?: string[] | undefined;
    vmClusterCount?: number | undefined;
    vmClusterIds?: string[] | undefined;
    exascaleDbStorageVaultArn?: string | undefined;
    highCapacityDatabaseStorage?: ExascaleDbStorageDetails | undefined;
    isAutoscaleEnabled?: boolean | undefined;
    ocid?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociUrl?: string | undefined;
    percentProgress?: number | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    timeZone?: string | undefined;
    vaultType?: ExascaleDbStorageVaultType | undefined;
}
export type ExascaleDbStorageVaultList = ExascaleDbStorageVaultSummary[];
export interface ListExascaleDbStorageVaultsOutput {
    nextToken?: string | undefined;
    exascaleDbStorageVaults: ExascaleDbStorageVaultSummary[];
}
export interface ListFlexComponentsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    shape?: string | undefined;
}
export type HardwareType = "COMPUTE" | "CELL" | (string & {});
export interface FlexComponentSummary {
    availableCoreCount?: number | undefined;
    availableDbStorageInGBs?: number | undefined;
    availableLocalStorageInGBs?: number | undefined;
    availableMemoryInGBs?: number | undefined;
    computeModel?: ComputeModel | undefined;
    descriptionSummary?: string | undefined;
    hardwareType?: HardwareType | undefined;
    minimumCoreCount?: number | undefined;
    name?: string | undefined;
    runtimeMinimumCoreCount?: number | undefined;
    shape?: string | undefined;
}
export type FlexComponentList = FlexComponentSummary[];
export interface ListFlexComponentsOutput {
    nextToken?: string | undefined;
    flexComponents: FlexComponentSummary[];
}
export interface ListGiMinorVersionsInput {
    giVersion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    shapeFamily?: string | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
}
export interface GiMinorVersionSummary {
    version: string;
    gridImageId?: string | undefined;
}
export type GiMinorVersionList = GiMinorVersionSummary[];
export interface ListGiMinorVersionsOutput {
    nextToken?: string | undefined;
    giMinorVersions: GiMinorVersionSummary[];
}
export interface ListGiVersionsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    shape?: string | undefined;
}
export interface GiVersionSummary {
    version?: string | undefined;
}
export type GiVersionList = GiVersionSummary[];
export interface ListGiVersionsOutput {
    nextToken?: string | undefined;
    giVersions: GiVersionSummary[];
}
export interface ListOdbNetworksInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface OdbNetworkSummary {
    odbNetworkId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbNetworkArn?: string | undefined;
    availabilityZone?: string | undefined;
    availabilityZoneId?: string | undefined;
    clientSubnetCidr?: string | undefined;
    backupSubnetCidr?: string | undefined;
    customDomainName?: string | undefined;
    defaultDnsPrefix?: string | undefined;
    peeredCidrs?: string[] | undefined;
    ociNetworkAnchorId?: string | undefined;
    ociNetworkAnchorUrl?: string | undefined;
    ociResourceAnchorName?: string | undefined;
    ociVcnId?: string | undefined;
    ociVcnUrl?: string | undefined;
    ociDnsForwardingConfigs?: OciDnsForwardingConfig[] | undefined;
    createdAt?: Date | undefined;
    percentProgress?: number | undefined;
    managedServices?: ManagedServices | undefined;
    ec2PlacementGroupIds?: string[] | undefined;
}
export type OdbNetworkList = OdbNetworkSummary[];
export interface ListOdbNetworksOutput {
    nextToken?: string | undefined;
    odbNetworks: OdbNetworkSummary[];
}
export interface ListOdbPeeringConnectionsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    odbNetworkId?: string | undefined;
}
export interface OdbPeeringConnectionSummary {
    odbPeeringConnectionId: string;
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbPeeringConnectionArn?: string | undefined;
    odbNetworkArn?: string | undefined;
    peerNetworkArn?: string | undefined;
    odbPeeringConnectionType?: string | undefined;
    peerNetworkCidrs?: string[] | undefined;
    createdAt?: Date | undefined;
    percentProgress?: number | undefined;
}
export type OdbPeeringConnectionList = OdbPeeringConnectionSummary[];
export interface ListOdbPeeringConnectionsOutput {
    nextToken?: string | undefined;
    odbPeeringConnections: OdbPeeringConnectionSummary[];
}
export interface ListSystemVersionsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    giVersion: string;
    shape: string;
}
export interface SystemVersionSummary {
    giVersion?: string | undefined;
    shape?: string | undefined;
    systemVersions?: string[] | undefined;
}
export type SystemVersionList = SystemVersionSummary[];
export interface ListSystemVersionsOutput {
    nextToken?: string | undefined;
    systemVersions: SystemVersionSummary[];
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type ResponseTagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RebootAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    isOnlineReboot?: boolean | undefined;
}
export interface RebootAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface RebootDbNodeInput {
    cloudVmClusterId?: string | undefined;
    exadbVmClusterId?: string | undefined;
    dbNodeId: string;
}
export interface RebootDbNodeOutput {
    dbNodeId: string;
    status?: DbNodeResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface RestoreAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    timestamp: Date;
}
export interface RestoreAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface ShrinkAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface ShrinkAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface StartAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface StartAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface StartDbNodeInput {
    cloudVmClusterId?: string | undefined;
    exadbVmClusterId?: string | undefined;
    dbNodeId: string;
}
export interface StartDbNodeOutput {
    dbNodeId: string;
    status?: DbNodeResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface StopAutonomousDatabaseInput {
    autonomousDatabaseId: string;
}
export interface StopAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface StopDbNodeInput {
    cloudVmClusterId?: string | undefined;
    exadbVmClusterId?: string | undefined;
    dbNodeId: string;
}
export interface StopDbNodeOutput {
    dbNodeId: string;
    status?: DbNodeResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface SwitchoverAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    peerDbArn?: string | undefined;
}
export interface SwitchoverAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAutonomousDatabaseInput {
    autonomousDatabaseId: string;
    adminPassword?: string | redacted.Redacted<string> | undefined;
    computeCount?: number | undefined;
    cpuCoreCount?: number | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dataStorageSizeInGBs?: number | undefined;
    displayName?: string | undefined;
    dbName?: string | undefined;
    dbVersion?: string | undefined;
    dbWorkload?: DbWorkload | undefined;
    dbToolsDetails?: DatabaseTool[] | undefined;
    databaseEdition?: DatabaseEdition | undefined;
    licenseModel?: LicenseModel | undefined;
    isAutoScalingEnabled?: boolean | undefined;
    isAutoScalingForStorageEnabled?: boolean | undefined;
    isBackupRetentionLocked?: boolean | undefined;
    isLocalDataGuardEnabled?: boolean | undefined;
    isMtlsConnectionRequired?: boolean | undefined;
    isRefreshableClone?: boolean | undefined;
    isDisconnectPeer?: boolean | undefined;
    backupRetentionPeriodInDays?: number | undefined;
    byolComputeCountLimit?: number | undefined;
    localAdgAutoFailoverMaxDataLossLimit?: number | undefined;
    autonomousMaintenanceScheduleType?: AutonomousMaintenanceScheduleType | undefined;
    customerContactsToSendToOCI?: CustomerContact[] | undefined;
    scheduledOperations?: ScheduledOperationDetails[] | undefined;
    longTermBackupSchedule?: LongTermBackupSchedule | undefined;
    openMode?: OpenMode | undefined;
    permissionLevel?: PermissionLevel | undefined;
    refreshableMode?: RefreshableMode | undefined;
    privateEndpointIp?: string | undefined;
    privateEndpointLabel?: string | undefined;
    peerDbId?: string | undefined;
    resourcePoolLeaderId?: string | undefined;
    resourcePoolSummary?: ResourcePoolSummary | undefined;
    standbyAllowlistedIpsSource?: StandbyAllowlistedIpsSource | undefined;
    standbyAllowlistedIps?: string[] | undefined;
    allowlistedIps?: string[] | undefined;
    autoRefreshFrequencyInSeconds?: number | undefined;
    autoRefreshPointLagInSeconds?: number | undefined;
    timeOfAutoRefreshStart?: Date | undefined;
    encryptionKeyProvider?: EncryptionKeyProviderInput | undefined;
    encryptionKeyConfiguration?: EncryptionKeyConfigurationInput | undefined;
    adminPasswordSource?: AdminPasswordSource | undefined;
    adminPasswordSourceConfiguration?: AdminPasswordSourceConfigurationInput | undefined;
}
export interface UpdateAutonomousDatabaseOutput {
    autonomousDatabaseId: string;
    displayName?: string | undefined;
    status?: AutonomousDatabaseResourceStatus | undefined;
    statusReason?: string | undefined;
}
export interface UpdateAutonomousDatabaseBackupInput {
    autonomousDatabaseBackupId: string;
    retentionPeriodInDays?: number | undefined;
}
export interface UpdateAutonomousDatabaseBackupOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    autonomousDatabaseBackupId: string;
}
export interface UpdateCloudAutonomousVmClusterInput {
    cloudAutonomousVmClusterId: string;
    autonomousDataStorageSizeInTBs?: number | undefined;
    cpuCoreCountPerNode?: number | undefined;
    description?: string | undefined;
    displayName?: string | undefined;
    licenseModel?: LicenseModel | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    totalContainerDatabases?: number | undefined;
}
export interface UpdateCloudAutonomousVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudAutonomousVmClusterId: string;
}
export interface UpdateCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
    displayName?: string | undefined;
    computeCount?: number | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    storageCount?: number | undefined;
}
export interface UpdateCloudExadataInfrastructureOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureId: string;
}
export interface UpdateCloudExadataInfrastructureStorageCapacityInput {
    cloudExadataInfrastructureId: string;
}
export interface UpdateCloudExadataInfrastructureStorageCapacityOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureId: string;
}
export interface UpdateCloudVmClusterInput {
    cloudVmClusterId: string;
    cpuCoreCount?: number | undefined;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    dataStorageSizeInTBs?: number | undefined;
    dbNodeStorageSizeInGBs?: number | undefined;
    displayName?: string | undefined;
    sshPublicKeys?: string[] | undefined;
    licenseModel?: LicenseModel | undefined;
    memorySizeInGBs?: number | undefined;
    storageSizeInGBs?: number | undefined;
}
export interface UpdateCloudVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudVmClusterId: string;
}
export type UpdateAction = "ROLLING_APPLY" | "NON_ROLLING_APPLY" | "PRECHECK" | "ROLLBACK" | (string & {});
export interface UpdateExadbVmClusterInput {
    exadbVmClusterId: string;
    dataCollectionOptions?: DataCollectionOptions | undefined;
    displayName?: string | undefined;
    enabledEcpuCount?: number | undefined;
    gridImageId?: string | undefined;
    licenseModel?: LicenseModel | undefined;
    sshPublicKeys?: string[] | undefined;
    systemVersion?: string | undefined;
    totalEcpuCount?: number | undefined;
    updateAction?: UpdateAction | undefined;
    vmFileSystemStorageTotalSizeInGBs?: number | undefined;
}
export interface UpdateExadbVmClusterOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    exadbVmClusterId: string;
}
export interface UpdateExascaleCloudExadataInfrastructureInput {
    cloudExadataInfrastructureId: string;
    totalStorageSizeInGBs: number;
    totalVmStorageSizeInGBs?: number | undefined;
}
export interface UpdateExascaleCloudExadataInfrastructureOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    cloudExadataInfrastructureId: string;
}
export interface UpdateExascaleDbStorageVaultInput {
    exascaleDbStorageVaultId: string;
    additionalFlashCacheInPercent?: number | undefined;
    autoscaleLimitInGBs?: number | undefined;
    description?: string | undefined;
    displayName?: string | undefined;
    highCapacityDatabaseStorageTotalSizeInGBs?: number | undefined;
    isAutoscaleEnabled?: boolean | undefined;
}
export interface UpdateExascaleDbStorageVaultOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    exascaleDbStorageVaultId: string;
}
export interface UpdateOdbNetworkInput {
    odbNetworkId: string;
    displayName?: string | undefined;
    peeredCidrsToBeAdded?: string[] | undefined;
    peeredCidrsToBeRemoved?: string[] | undefined;
    s3Access?: Access | undefined;
    zeroEtlAccess?: Access | undefined;
    stsAccess?: Access | undefined;
    kmsAccess?: Access | undefined;
    s3PolicyDocument?: string | undefined;
    stsPolicyDocument?: string | undefined;
    kmsPolicyDocument?: string | undefined;
    crossRegionS3RestoreSourcesToEnable?: string[] | undefined;
    crossRegionS3RestoreSourcesToDisable?: string[] | undefined;
}
export interface UpdateOdbNetworkOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbNetworkId: string;
}
export interface UpdateOdbPeeringConnectionInput {
    odbPeeringConnectionId: string;
    displayName?: string | undefined;
    peerNetworkCidrsToBeAdded?: string[] | undefined;
    peerNetworkCidrsToBeRemoved?: string[] | undefined;
}
export interface UpdateOdbPeeringConnectionOutput {
    displayName?: string | undefined;
    status?: ResourceStatus | undefined;
    statusReason?: string | undefined;
    odbPeeringConnectionId: string;
}
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AcceptMarketplaceRegistrationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Registers the Amazon Web Services Marketplace token for your Amazon Web Services account to activate your Oracle Database@Amazon Web Services subscription.
 */
export declare const acceptMarketplaceRegistration: API.OperationMethod<AcceptMarketplaceRegistrationInput & RegionInput, AcceptMarketplaceRegistrationOutput, AcceptMarketplaceRegistrationError, Credentials | HttpClient.HttpClient>;
export type AssociateIamRoleToResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates an Amazon Web Services Identity and Access Management (IAM) service role with a specified resource to enable Amazon Web Services service integration.
 */
export declare const associateIamRoleToResource: API.OperationMethod<AssociateIamRoleToResourceInput & RegionInput, AssociateIamRoleToResourceOutput, AssociateIamRoleToResourceError, Credentials | HttpClient.HttpClient>;
export type AssociateVirtualMachinesToCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds virtual machines to the specified VM cluster.
 */
export declare const associateVirtualMachinesToCloudVmCluster: API.OperationMethod<AssociateVirtualMachinesToCloudVmClusterInput & RegionInput, AssociateVirtualMachinesToCloudVmClusterOutput, AssociateVirtualMachinesToCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type AssociateVirtualMachinesToExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds virtual machines to the specified Exascale VM cluster.
 */
export declare const associateVirtualMachinesToExadbVmCluster: API.OperationMethod<AssociateVirtualMachinesToExadbVmClusterInput & RegionInput, AssociateVirtualMachinesToExadbVmClusterOutput, AssociateVirtualMachinesToExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Autonomous Database.
 */
export declare const createAutonomousDatabase: API.OperationMethod<CreateAutonomousDatabaseInput & RegionInput, CreateAutonomousDatabaseOutput, CreateAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateAutonomousDatabaseBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new backup of the specified Autonomous Database.
 */
export declare const createAutonomousDatabaseBackup: API.OperationMethod<CreateAutonomousDatabaseBackupInput & RegionInput, CreateAutonomousDatabaseBackupOutput, CreateAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type CreateAutonomousDatabaseWalletError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new wallet for the specified Autonomous Database.
 */
export declare const createAutonomousDatabaseWallet: API.OperationMethod<CreateAutonomousDatabaseWalletInput & RegionInput, CreateAutonomousDatabaseWalletOutput, CreateAutonomousDatabaseWalletError, Credentials | HttpClient.HttpClient>;
export type CreateCloudAutonomousVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Autonomous VM cluster in the specified Exadata infrastructure.
 */
export declare const createCloudAutonomousVmCluster: API.OperationMethod<CreateCloudAutonomousVmClusterInput & RegionInput, CreateCloudAutonomousVmClusterOutput, CreateCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Exadata infrastructure.
 */
export declare const createCloudExadataInfrastructure: API.OperationMethod<CreateCloudExadataInfrastructureInput & RegionInput, CreateCloudExadataInfrastructureOutput, CreateCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type CreateCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a VM cluster on the specified Exadata infrastructure.
 */
export declare const createCloudVmCluster: API.OperationMethod<CreateCloudVmClusterInput & RegionInput, CreateCloudVmClusterOutput, CreateCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Exascale VM cluster.
 */
export declare const createExadbVmCluster: API.OperationMethod<CreateExadbVmClusterInput & RegionInput, CreateExadbVmClusterOutput, CreateExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type CreateExascaleDbStorageVaultError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Exascale storage vault.
 *
 * To create the Exascale storage vault on dedicated Exadata infrastructure, specify `cloudExadataInfrastructureId`.
 */
export declare const createExascaleDbStorageVault: API.OperationMethod<CreateExascaleDbStorageVaultInput & RegionInput, CreateExascaleDbStorageVaultOutput, CreateExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type CreateOdbNetworkError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an ODB network.
 */
export declare const createOdbNetwork: API.OperationMethod<CreateOdbNetworkInput & RegionInput, CreateOdbNetworkOutput, CreateOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type CreateOdbPeeringConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a peering connection between an ODB network and a VPC.
 *
 * A peering connection enables private connectivity between the networks for application-tier communication.
 */
export declare const createOdbPeeringConnection: API.OperationMethod<CreateOdbPeeringConnectionInput & RegionInput, CreateOdbPeeringConnectionOutput, CreateOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Autonomous Database.
 */
export declare const deleteAutonomousDatabase: API.OperationMethod<DeleteAutonomousDatabaseInput & RegionInput, DeleteAutonomousDatabaseOutput, DeleteAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteAutonomousDatabaseBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Autonomous Database backup.
 */
export declare const deleteAutonomousDatabaseBackup: API.OperationMethod<DeleteAutonomousDatabaseBackupInput & RegionInput, DeleteAutonomousDatabaseBackupOutput, DeleteAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudAutonomousVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an Autonomous VM cluster.
 */
export declare const deleteCloudAutonomousVmCluster: API.OperationMethod<DeleteCloudAutonomousVmClusterInput & RegionInput, DeleteCloudAutonomousVmClusterOutput, DeleteCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Exadata infrastructure. Before you use this operation, make sure to delete all of the VM clusters that are hosted on this Exadata infrastructure.
 */
export declare const deleteCloudExadataInfrastructure: API.OperationMethod<DeleteCloudExadataInfrastructureInput & RegionInput, DeleteCloudExadataInfrastructureOutput, DeleteCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type DeleteCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the specified VM cluster.
 */
export declare const deleteCloudVmCluster: API.OperationMethod<DeleteCloudVmClusterInput & RegionInput, DeleteCloudVmClusterOutput, DeleteCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Exascale VM cluster.
 */
export declare const deleteExadbVmCluster: API.OperationMethod<DeleteExadbVmClusterInput & RegionInput, DeleteExadbVmClusterOutput, DeleteExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteExascaleDbStorageVaultError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified Exascale storage vault.
 */
export declare const deleteExascaleDbStorageVault: API.OperationMethod<DeleteExascaleDbStorageVaultInput & RegionInput, DeleteExascaleDbStorageVaultOutput, DeleteExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type DeleteOdbNetworkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified ODB network.
 */
export declare const deleteOdbNetwork: API.OperationMethod<DeleteOdbNetworkInput & RegionInput, DeleteOdbNetworkOutput, DeleteOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type DeleteOdbPeeringConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an ODB peering connection.
 *
 * When you delete an ODB peering connection, the underlying VPC peering connection is also deleted.
 */
export declare const deleteOdbPeeringConnection: API.OperationMethod<DeleteOdbPeeringConnectionInput & RegionInput, DeleteOdbPeeringConnectionOutput, DeleteOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export type DisassociateIamRoleFromResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates an Amazon Web Services Identity and Access Management (IAM) service role from a specified resource to disable Amazon Web Services service integration.
 */
export declare const disassociateIamRoleFromResource: API.OperationMethod<DisassociateIamRoleFromResourceInput & RegionInput, DisassociateIamRoleFromResourceOutput, DisassociateIamRoleFromResourceError, Credentials | HttpClient.HttpClient>;
export type DisassociateVirtualMachinesFromCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes virtual machines from the specified VM cluster.
 */
export declare const disassociateVirtualMachinesFromCloudVmCluster: API.OperationMethod<DisassociateVirtualMachinesFromCloudVmClusterInput & RegionInput, DisassociateVirtualMachinesFromCloudVmClusterOutput, DisassociateVirtualMachinesFromCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type DisassociateVirtualMachinesFromExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes virtual machines from the specified Exascale VM cluster.
 */
export declare const disassociateVirtualMachinesFromExadbVmCluster: API.OperationMethod<DisassociateVirtualMachinesFromExadbVmClusterInput & RegionInput, DisassociateVirtualMachinesFromExadbVmClusterOutput, DisassociateVirtualMachinesFromExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type FailoverAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initiates a failover of the specified Autonomous Database to a standby peer database.
 */
export declare const failoverAutonomousDatabase: API.OperationMethod<FailoverAutonomousDatabaseInput & RegionInput, FailoverAutonomousDatabaseOutput, FailoverAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetAutonomousDatabaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific Autonomous Database.
 */
export declare const getAutonomousDatabase: API.OperationMethod<GetAutonomousDatabaseInput & RegionInput, GetAutonomousDatabaseOutput, GetAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetAutonomousDatabaseBackupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific Autonomous Database backup.
 */
export declare const getAutonomousDatabaseBackup: API.OperationMethod<GetAutonomousDatabaseBackupInput & RegionInput, GetAutonomousDatabaseBackupOutput, GetAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type GetAutonomousDatabaseWalletDetailsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the wallet details for the specified Autonomous Database.
 */
export declare const getAutonomousDatabaseWalletDetails: API.OperationMethod<GetAutonomousDatabaseWalletDetailsInput & RegionInput, GetAutonomousDatabaseWalletDetailsOutput, GetAutonomousDatabaseWalletDetailsError, Credentials | HttpClient.HttpClient>;
export type GetCloudAutonomousVmClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about a specific Autonomous VM cluster.
 */
export declare const getCloudAutonomousVmCluster: API.OperationMethod<GetCloudAutonomousVmClusterInput & RegionInput, GetCloudAutonomousVmClusterOutput, GetCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type GetCloudExadataInfrastructureError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified Exadata infrastructure.
 */
export declare const getCloudExadataInfrastructure: API.OperationMethod<GetCloudExadataInfrastructureInput & RegionInput, GetCloudExadataInfrastructureOutput, GetCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type GetCloudExadataInfrastructureUnallocatedResourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about unallocated resources in a specified Cloud Exadata Infrastructure.
 */
export declare const getCloudExadataInfrastructureUnallocatedResources: API.OperationMethod<GetCloudExadataInfrastructureUnallocatedResourcesInput & RegionInput, GetCloudExadataInfrastructureUnallocatedResourcesOutput, GetCloudExadataInfrastructureUnallocatedResourcesError, Credentials | HttpClient.HttpClient>;
export type GetCloudVmClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified VM cluster.
 */
export declare const getCloudVmCluster: API.OperationMethod<GetCloudVmClusterInput & RegionInput, GetCloudVmClusterOutput, GetCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type GetDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified DB node.
 */
export declare const getDbNode: API.OperationMethod<GetDbNodeInput & RegionInput, GetDbNodeOutput, GetDbNodeError, Credentials | HttpClient.HttpClient>;
export type GetDbServerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified database server.
 */
export declare const getDbServer: API.OperationMethod<GetDbServerInput & RegionInput, GetDbServerOutput, GetDbServerError, Credentials | HttpClient.HttpClient>;
export type GetExadbVmClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified Exascale VM cluster.
 */
export declare const getExadbVmCluster: API.OperationMethod<GetExadbVmClusterInput & RegionInput, GetExadbVmClusterOutput, GetExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type GetExascaleDbStorageVaultError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified Exascale storage vault.
 */
export declare const getExascaleDbStorageVault: API.OperationMethod<GetExascaleDbStorageVaultInput & RegionInput, GetExascaleDbStorageVaultOutput, GetExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type GetOciOnboardingStatusError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the tenancy activation link and onboarding status for your Amazon Web Services account.
 */
export declare const getOciOnboardingStatus: API.OperationMethod<GetOciOnboardingStatusInput & RegionInput, GetOciOnboardingStatusOutput, GetOciOnboardingStatusError, Credentials | HttpClient.HttpClient>;
export type GetOdbNetworkError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the specified ODB network.
 */
export declare const getOdbNetwork: API.OperationMethod<GetOdbNetworkInput & RegionInput, GetOdbNetworkOutput, GetOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type GetOdbPeeringConnectionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an ODB peering connection.
 */
export declare const getOdbPeeringConnection: API.OperationMethod<GetOdbPeeringConnectionInput & RegionInput, GetOdbPeeringConnectionOutput, GetOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export type InitializeServiceError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Initializes the ODB service for the first time in an account.
 */
export declare const initializeService: API.OperationMethod<InitializeServiceInput & RegionInput, InitializeServiceOutput, InitializeServiceError, Credentials | HttpClient.HttpClient>;
export type ListAutonomousDatabaseBackupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the backups of the specified Autonomous Database.
 */
export declare const listAutonomousDatabaseBackups: API.PaginatedOperationMethod<ListAutonomousDatabaseBackupsInput & RegionInput, ListAutonomousDatabaseBackupsOutput, ListAutonomousDatabaseBackupsError, Credentials | HttpClient.HttpClient, AutonomousDatabaseBackupSummary>;
export type ListAutonomousDatabaseCharacterSetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available character sets for Autonomous Databases.
 */
export declare const listAutonomousDatabaseCharacterSets: API.PaginatedOperationMethod<ListAutonomousDatabaseCharacterSetsInput & RegionInput, ListAutonomousDatabaseCharacterSetsOutput, ListAutonomousDatabaseCharacterSetsError, Credentials | HttpClient.HttpClient, AutonomousDatabaseCharacterSetSummary>;
export type ListAutonomousDatabaseClonesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the clones of the specified Autonomous Database.
 */
export declare const listAutonomousDatabaseClones: API.PaginatedOperationMethod<ListAutonomousDatabaseClonesInput & RegionInput, ListAutonomousDatabaseClonesOutput, ListAutonomousDatabaseClonesError, Credentials | HttpClient.HttpClient, AutonomousDatabaseSummary>;
export type ListAutonomousDatabasePeersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the peer databases of the specified Autonomous Database.
 */
export declare const listAutonomousDatabasePeers: API.PaginatedOperationMethod<ListAutonomousDatabasePeersInput & RegionInput, ListAutonomousDatabasePeersOutput, ListAutonomousDatabasePeersError, Credentials | HttpClient.HttpClient, AutonomousDatabasePeerSummary>;
export type ListAutonomousDatabasesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Autonomous Databases owned by your Amazon Web Services account in the current Amazon Web Services Region.
 */
export declare const listAutonomousDatabases: API.PaginatedOperationMethod<ListAutonomousDatabasesInput & RegionInput, ListAutonomousDatabasesOutput, ListAutonomousDatabasesError, Credentials | HttpClient.HttpClient, AutonomousDatabaseSummary>;
export type ListAutonomousDatabaseVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the available Oracle Database software versions for Autonomous Databases.
 */
export declare const listAutonomousDatabaseVersions: API.PaginatedOperationMethod<ListAutonomousDatabaseVersionsInput & RegionInput, ListAutonomousDatabaseVersionsOutput, ListAutonomousDatabaseVersionsError, Credentials | HttpClient.HttpClient, AutonomousDatabaseVersionSummary>;
export type ListAutonomousVirtualMachinesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Autonomous VMs in an Autonomous VM cluster.
 */
export declare const listAutonomousVirtualMachines: API.PaginatedOperationMethod<ListAutonomousVirtualMachinesInput & RegionInput, ListAutonomousVirtualMachinesOutput, ListAutonomousVirtualMachinesError, Credentials | HttpClient.HttpClient, AutonomousVirtualMachineSummary>;
export type ListCloudAutonomousVmClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all Autonomous VM clusters in a specified Cloud Exadata infrastructure.
 */
export declare const listCloudAutonomousVmClusters: API.PaginatedOperationMethod<ListCloudAutonomousVmClustersInput & RegionInput, ListCloudAutonomousVmClustersOutput, ListCloudAutonomousVmClustersError, Credentials | HttpClient.HttpClient, CloudAutonomousVmClusterSummary>;
export type ListCloudExadataInfrastructuresError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Exadata infrastructures owned by your Amazon Web Services account.
 */
export declare const listCloudExadataInfrastructures: API.PaginatedOperationMethod<ListCloudExadataInfrastructuresInput & RegionInput, ListCloudExadataInfrastructuresOutput, ListCloudExadataInfrastructuresError, Credentials | HttpClient.HttpClient, CloudExadataInfrastructureSummary>;
export type ListCloudVmClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the VM clusters owned by your Amazon Web Services account or only the ones on the specified Exadata infrastructure.
 */
export declare const listCloudVmClusters: API.PaginatedOperationMethod<ListCloudVmClustersInput & RegionInput, ListCloudVmClustersOutput, ListCloudVmClustersError, Credentials | HttpClient.HttpClient, CloudVmClusterSummary>;
export type ListDbNodesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the DB nodes for the specified VM cluster.
 */
export declare const listDbNodes: API.PaginatedOperationMethod<ListDbNodesInput & RegionInput, ListDbNodesOutput, ListDbNodesError, Credentials | HttpClient.HttpClient, DbNodeSummary>;
export type ListDbServersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the database servers that belong to the specified Exadata infrastructure.
 */
export declare const listDbServers: API.PaginatedOperationMethod<ListDbServersInput & RegionInput, ListDbServersOutput, ListDbServersError, Credentials | HttpClient.HttpClient, DbServerSummary>;
export type ListDbSystemShapesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the shapes that are available for an Exadata infrastructure.
 */
export declare const listDbSystemShapes: API.PaginatedOperationMethod<ListDbSystemShapesInput & RegionInput, ListDbSystemShapesOutput, ListDbSystemShapesError, Credentials | HttpClient.HttpClient, DbSystemShapeSummary>;
export type ListExadbVmClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Exascale VM clusters owned by your Amazon Web Services account.
 */
export declare const listExadbVmClusters: API.PaginatedOperationMethod<ListExadbVmClustersInput & RegionInput, ListExadbVmClustersOutput, ListExadbVmClustersError, Credentials | HttpClient.HttpClient, ExadbVmClusterSummary>;
export type ListExascaleDbStorageVaultsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Exascale storage vaults owned by your Amazon Web Services account.
 */
export declare const listExascaleDbStorageVaults: API.PaginatedOperationMethod<ListExascaleDbStorageVaultsInput & RegionInput, ListExascaleDbStorageVaultsOutput, ListExascaleDbStorageVaultsError, Credentials | HttpClient.HttpClient, ExascaleDbStorageVaultSummary>;
export type ListFlexComponentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the flex components that are available for an Exadata infrastructure.
 */
export declare const listFlexComponents: API.PaginatedOperationMethod<ListFlexComponentsInput & RegionInput, ListFlexComponentsOutput, ListFlexComponentsError, Credentials | HttpClient.HttpClient, FlexComponentSummary>;
export type ListGiMinorVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of the Oracle Grid Infrastructure (GI) minor versions for the specified major version.
 */
export declare const listGiMinorVersions: API.PaginatedOperationMethod<ListGiMinorVersionsInput & RegionInput, ListGiMinorVersionsOutput, ListGiMinorVersionsError, Credentials | HttpClient.HttpClient, GiMinorVersionSummary>;
export type ListGiVersionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about Oracle Grid Infrastructure (GI) software versions that are available for a VM cluster for the specified shape.
 */
export declare const listGiVersions: API.PaginatedOperationMethod<ListGiVersionsInput & RegionInput, ListGiVersionsOutput, ListGiVersionsError, Credentials | HttpClient.HttpClient, GiVersionSummary>;
export type ListOdbNetworksError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the ODB networks owned by your Amazon Web Services account.
 */
export declare const listOdbNetworks: API.PaginatedOperationMethod<ListOdbNetworksInput & RegionInput, ListOdbNetworksOutput, ListOdbNetworksError, Credentials | HttpClient.HttpClient, OdbNetworkSummary>;
export type ListOdbPeeringConnectionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all ODB peering connections or those associated with a specific ODB network.
 */
export declare const listOdbPeeringConnections: API.PaginatedOperationMethod<ListOdbPeeringConnectionsInput & RegionInput, ListOdbPeeringConnectionsOutput, ListOdbPeeringConnectionsError, Credentials | HttpClient.HttpClient, OdbPeeringConnectionSummary>;
export type ListSystemVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the system versions that are available for a VM cluster for the specified `giVersion` and `shape`.
 */
export declare const listSystemVersions: API.PaginatedOperationMethod<ListSystemVersionsInput & RegionInput, ListSystemVersionsOutput, ListSystemVersionsError, Credentials | HttpClient.HttpClient, SystemVersionSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Returns information about the tags applied to this resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RebootAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots the specified Autonomous Database.
 */
export declare const rebootAutonomousDatabase: API.OperationMethod<RebootAutonomousDatabaseInput & RegionInput, RebootAutonomousDatabaseOutput, RebootAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type RebootDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots the specified DB node in a VM cluster.
 */
export declare const rebootDbNode: API.OperationMethod<RebootDbNodeInput & RegionInput, RebootDbNodeOutput, RebootDbNodeError, Credentials | HttpClient.HttpClient>;
export type RestoreAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores the specified Autonomous Database to a point in time.
 */
export declare const restoreAutonomousDatabase: API.OperationMethod<RestoreAutonomousDatabaseInput & RegionInput, RestoreAutonomousDatabaseOutput, RestoreAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type ShrinkAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Shrinks the storage of the specified Autonomous Database to reclaim unused space.
 */
export declare const shrinkAutonomousDatabase: API.OperationMethod<ShrinkAutonomousDatabaseInput & RegionInput, ShrinkAutonomousDatabaseOutput, ShrinkAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type StartAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the specified Autonomous Database.
 */
export declare const startAutonomousDatabase: API.OperationMethod<StartAutonomousDatabaseInput & RegionInput, StartAutonomousDatabaseOutput, StartAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type StartDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts the specified DB node in a VM cluster.
 */
export declare const startDbNode: API.OperationMethod<StartDbNodeInput & RegionInput, StartDbNodeOutput, StartDbNodeError, Credentials | HttpClient.HttpClient>;
export type StopAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specified Autonomous Database.
 */
export declare const stopAutonomousDatabase: API.OperationMethod<StopAutonomousDatabaseInput & RegionInput, StopAutonomousDatabaseOutput, StopAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type StopDbNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops the specified DB node in a VM cluster.
 */
export declare const stopDbNode: API.OperationMethod<StopDbNodeInput & RegionInput, StopDbNodeOutput, StopDbNodeError, Credentials | HttpClient.HttpClient>;
export type SwitchoverAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Performs a switchover of the specified Autonomous Database to a standby peer database.
 */
export declare const switchoverAutonomousDatabase: API.OperationMethod<SwitchoverAutonomousDatabaseInput & RegionInput, SwitchoverAutonomousDatabaseOutput, SwitchoverAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Applies tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutonomousDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an Autonomous Database.
 */
export declare const updateAutonomousDatabase: API.OperationMethod<UpdateAutonomousDatabaseInput & RegionInput, UpdateAutonomousDatabaseOutput, UpdateAutonomousDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateAutonomousDatabaseBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an Autonomous Database backup.
 */
export declare const updateAutonomousDatabaseBackup: API.OperationMethod<UpdateAutonomousDatabaseBackupInput & RegionInput, UpdateAutonomousDatabaseBackupOutput, UpdateAutonomousDatabaseBackupError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudAutonomousVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of the specified Autonomous VM cluster.
 */
export declare const updateCloudAutonomousVmCluster: API.OperationMethod<UpdateCloudAutonomousVmClusterInput & RegionInput, UpdateCloudAutonomousVmClusterOutput, UpdateCloudAutonomousVmClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of an Exadata infrastructure resource.
 */
export declare const updateCloudExadataInfrastructure: API.OperationMethod<UpdateCloudExadataInfrastructureInput & RegionInput, UpdateCloudExadataInfrastructureOutput, UpdateCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudExadataInfrastructureStorageCapacityError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds storage capacity to the specified Exadata infrastructure.
 */
export declare const updateCloudExadataInfrastructureStorageCapacity: API.OperationMethod<UpdateCloudExadataInfrastructureStorageCapacityInput & RegionInput, UpdateCloudExadataInfrastructureStorageCapacityOutput, UpdateCloudExadataInfrastructureStorageCapacityError, Credentials | HttpClient.HttpClient>;
export type UpdateCloudVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the properties of the specified VM cluster.
 */
export declare const updateCloudVmCluster: API.OperationMethod<UpdateCloudVmClusterInput & RegionInput, UpdateCloudVmClusterOutput, UpdateCloudVmClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateExadbVmClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified Exascale VM cluster.
 */
export declare const updateExadbVmCluster: API.OperationMethod<UpdateExadbVmClusterInput & RegionInput, UpdateExadbVmClusterOutput, UpdateExadbVmClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateExascaleCloudExadataInfrastructureError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Configures or updates the Exascale storage on an Exadata infrastructure. After you configure Exascale storage, you can create Exascale storage vaults on the infrastructure and VM clusters that use Exascale storage.
 */
export declare const updateExascaleCloudExadataInfrastructure: API.OperationMethod<UpdateExascaleCloudExadataInfrastructureInput & RegionInput, UpdateExascaleCloudExadataInfrastructureOutput, UpdateExascaleCloudExadataInfrastructureError, Credentials | HttpClient.HttpClient>;
export type UpdateExascaleDbStorageVaultError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified Exascale storage vault.
 */
export declare const updateExascaleDbStorageVault: API.OperationMethod<UpdateExascaleDbStorageVaultInput & RegionInput, UpdateExascaleDbStorageVaultOutput, UpdateExascaleDbStorageVaultError, Credentials | HttpClient.HttpClient>;
export type UpdateOdbNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates properties of a specified ODB network.
 */
export declare const updateOdbNetwork: API.OperationMethod<UpdateOdbNetworkInput & RegionInput, UpdateOdbNetworkOutput, UpdateOdbNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateOdbPeeringConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Modifies the settings of an Oracle Database@Amazon Web Services peering connection. You can update the display name and add or remove CIDR blocks from the peering connection.
 */
export declare const updateOdbPeeringConnection: API.OperationMethod<UpdateOdbPeeringConnectionInput & RegionInput, UpdateOdbPeeringConnectionOutput, UpdateOdbPeeringConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=odb.d.ts.map