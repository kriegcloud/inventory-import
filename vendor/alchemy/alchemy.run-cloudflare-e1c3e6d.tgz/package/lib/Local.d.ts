/**
 * The Cloudflare provider group served by the dev sidecar (see
 * `Local/Sidecar.ts`): the workerd-backed local providers, built per
 * session the first time a stack asks for one of their types.
 */
import * as Layer from "effect/Layer";
declare const _default: Layer.Layer<import("alchemy").Provider<import("./index.ts").ContainerApplication<unknown>> | import("alchemy").Provider<import("./Queues/Consumer.ts").Consumer> | import("alchemy").Provider<import("./D1/Database.ts").Database> | import("alchemy").Provider<import("./Queues/Queue.ts").Queue> | import("alchemy").Provider<import("./SecretsStore/Secret.ts").Secret> | import("alchemy").Provider<import("./index.ts").Worker<any>> | import("alchemy").Provider<import("./index.ts").WorkerRoute>, import("effect/Config").ConfigError | import("@alchemy.run/cloudflare-runtime/core").ConfigError | import("effect/PlatformError").PlatformError | import("@alchemy.run/cloudflare-runtime/core").SystemError, import("alchemy").AlchemyContext | import("alchemy/Artifacts").ArtifactStore | import("alchemy").AuthProviders | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("alchemy/Auth/Credentials").CredentialsStore | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom | import("alchemy").Stack | import("alchemy").Stage>;
export default _default;
//# sourceMappingURL=Local.d.ts.map