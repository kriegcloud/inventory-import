import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ConflictType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainId = string;
export type WatchlistId = string;
export type FraudsterId = string | redacted.Redacted<string>;
export interface AssociateFraudsterRequest {
    DomainId: string;
    WatchlistId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export type GeneratedFraudsterId = string;
export type ResponseWatchlistIds = string[];
export interface Fraudster {
    DomainId?: string | undefined;
    GeneratedFraudsterId?: string | undefined;
    CreatedAt?: Date | undefined;
    WatchlistIds?: string[] | undefined;
}
export interface AssociateFraudsterResponse {
    Fraudster?: Fraudster | undefined;
}
export type DomainName = string | redacted.Redacted<string>;
export type Description = string | redacted.Redacted<string>;
export type KmsKeyId = string;
export interface ServerSideEncryptionConfiguration {
    KmsKeyId: string;
}
export type ClientTokenString = string;
export type TagKey = string | redacted.Redacted<string>;
export type TagValue = string | redacted.Redacted<string>;
export interface Tag {
    Key: string | redacted.Redacted<string>;
    Value: string | redacted.Redacted<string>;
}
export type TagList = Tag[];
export interface CreateDomainRequest {
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string> | undefined;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
    ClientToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type Arn = string;
export type DomainStatus = string;
export type ServerSideEncryptionUpdateStatus = string;
export interface ServerSideEncryptionUpdateDetails {
    OldKmsKeyId?: string | undefined;
    UpdateStatus?: string | undefined;
    Message?: string | undefined;
}
export interface WatchlistDetails {
    DefaultWatchlistId: string;
}
export interface Domain {
    DomainId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    DomainStatus?: string | undefined;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    ServerSideEncryptionUpdateDetails?: ServerSideEncryptionUpdateDetails | undefined;
    WatchlistDetails?: WatchlistDetails | undefined;
}
export interface CreateDomainResponse {
    Domain?: Domain | undefined;
}
export type WatchlistName = string | redacted.Redacted<string>;
export type WatchlistDescription = string | redacted.Redacted<string>;
export interface CreateWatchlistRequest {
    DomainId: string;
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string> | undefined;
    ClientToken?: string | undefined;
}
export interface Watchlist {
    DomainId?: string | undefined;
    WatchlistId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    DefaultWatchlist?: boolean | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface CreateWatchlistResponse {
    Watchlist?: Watchlist | undefined;
}
export interface DeleteDomainRequest {
    DomainId: string;
}
export interface DeleteDomainResponse {
}
export interface DeleteFraudsterRequest {
    DomainId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export interface DeleteFraudsterResponse {
}
export type SpeakerId = string | redacted.Redacted<string>;
export interface DeleteSpeakerRequest {
    DomainId: string;
    SpeakerId: string | redacted.Redacted<string>;
}
export interface DeleteSpeakerResponse {
}
export interface DeleteWatchlistRequest {
    DomainId: string;
    WatchlistId: string;
}
export interface DeleteWatchlistResponse {
}
export interface DescribeDomainRequest {
    DomainId: string;
}
export interface DescribeDomainResponse {
    Domain?: Domain | undefined;
}
export interface DescribeFraudsterRequest {
    DomainId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export interface DescribeFraudsterResponse {
    Fraudster?: Fraudster | undefined;
}
export type JobId = string;
export interface DescribeFraudsterRegistrationJobRequest {
    DomainId: string;
    JobId: string;
}
export type JobName = string | redacted.Redacted<string>;
export type FraudsterRegistrationJobStatus = string;
export type IamRoleArn = string;
export type DuplicateRegistrationAction = string;
export type Score = number;
export type RegistrationConfigWatchlistIds = string[];
export interface RegistrationConfig {
    DuplicateRegistrationAction?: string | undefined;
    FraudsterSimilarityThreshold?: number | undefined;
    WatchlistIds?: string[] | undefined;
}
export type S3Uri = string;
export interface InputDataConfig {
    S3Uri: string;
}
export interface OutputDataConfig {
    S3Uri: string;
    KmsKeyId?: string | undefined;
}
export interface FailureDetails {
    StatusCode?: number | undefined;
    Message?: string | undefined;
}
export interface JobProgress {
    PercentComplete?: number | undefined;
}
export interface FraudsterRegistrationJob {
    JobName?: string | redacted.Redacted<string> | undefined;
    JobId?: string | undefined;
    JobStatus?: string | undefined;
    DomainId?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    RegistrationConfig?: RegistrationConfig | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    CreatedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    FailureDetails?: FailureDetails | undefined;
    JobProgress?: JobProgress | undefined;
}
export interface DescribeFraudsterRegistrationJobResponse {
    Job?: FraudsterRegistrationJob | undefined;
}
export interface DescribeSpeakerRequest {
    DomainId: string;
    SpeakerId: string | redacted.Redacted<string>;
}
export type CustomerSpeakerId = string | redacted.Redacted<string>;
export type GeneratedSpeakerId = string;
export type SpeakerStatus = string;
export interface Speaker {
    DomainId?: string | undefined;
    CustomerSpeakerId?: string | redacted.Redacted<string> | undefined;
    GeneratedSpeakerId?: string | undefined;
    Status?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    LastAccessedAt?: Date | undefined;
}
export interface DescribeSpeakerResponse {
    Speaker?: Speaker | undefined;
}
export interface DescribeSpeakerEnrollmentJobRequest {
    DomainId: string;
    JobId: string;
}
export type SpeakerEnrollmentJobStatus = string;
export type ExistingEnrollmentAction = string;
export type FraudDetectionAction = string;
export type EnrollmentJobFraudDetectionConfigWatchlistIds = string[];
export interface EnrollmentJobFraudDetectionConfig {
    FraudDetectionAction?: string | undefined;
    RiskThreshold?: number | undefined;
    WatchlistIds?: string[] | undefined;
}
export interface EnrollmentConfig {
    ExistingEnrollmentAction?: string | undefined;
    FraudDetectionConfig?: EnrollmentJobFraudDetectionConfig | undefined;
}
export interface SpeakerEnrollmentJob {
    JobName?: string | redacted.Redacted<string> | undefined;
    JobId?: string | undefined;
    JobStatus?: string | undefined;
    DomainId?: string | undefined;
    DataAccessRoleArn?: string | undefined;
    EnrollmentConfig?: EnrollmentConfig | undefined;
    InputDataConfig?: InputDataConfig | undefined;
    OutputDataConfig?: OutputDataConfig | undefined;
    CreatedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    FailureDetails?: FailureDetails | undefined;
    JobProgress?: JobProgress | undefined;
}
export interface DescribeSpeakerEnrollmentJobResponse {
    Job?: SpeakerEnrollmentJob | undefined;
}
export interface DescribeWatchlistRequest {
    DomainId: string;
    WatchlistId: string;
}
export interface DescribeWatchlistResponse {
    Watchlist?: Watchlist | undefined;
}
export interface DisassociateFraudsterRequest {
    DomainId: string;
    WatchlistId: string;
    FraudsterId: string | redacted.Redacted<string>;
}
export interface DisassociateFraudsterResponse {
    Fraudster?: Fraudster | undefined;
}
export type SessionNameOrId = string;
export interface EvaluateSessionRequest {
    DomainId: string;
    SessionNameOrId: string;
}
export type SessionId = string;
export type SessionName = string;
export type StreamingStatus = string;
export type UniqueIdLarge = string;
export type AuthenticationDecision = string;
export interface AuthenticationConfiguration {
    AcceptanceThreshold: number;
}
export interface AuthenticationResult {
    AuthenticationResultId?: string | undefined;
    AudioAggregationStartedAt?: Date | undefined;
    AudioAggregationEndedAt?: Date | undefined;
    CustomerSpeakerId?: string | redacted.Redacted<string> | undefined;
    GeneratedSpeakerId?: string | undefined;
    Decision?: string | undefined;
    Score?: number | undefined;
    Configuration?: AuthenticationConfiguration | undefined;
}
export interface FraudDetectionConfiguration {
    RiskThreshold?: number | undefined;
    WatchlistId?: string | undefined;
}
export type FraudDetectionDecision = string;
export type FraudDetectionReason = string;
export type FraudDetectionReasons = string[];
export interface KnownFraudsterRisk {
    RiskScore: number;
    GeneratedFraudsterId?: string | undefined;
}
export interface VoiceSpoofingRisk {
    RiskScore: number;
}
export interface FraudRiskDetails {
    KnownFraudsterRisk: KnownFraudsterRisk;
    VoiceSpoofingRisk: VoiceSpoofingRisk;
}
export interface FraudDetectionResult {
    FraudDetectionResultId?: string | undefined;
    AudioAggregationStartedAt?: Date | undefined;
    AudioAggregationEndedAt?: Date | undefined;
    Configuration?: FraudDetectionConfiguration | undefined;
    Decision?: string | undefined;
    Reasons?: string[] | undefined;
    RiskDetails?: FraudRiskDetails | undefined;
}
export interface EvaluateSessionResponse {
    DomainId?: string | undefined;
    SessionId?: string | undefined;
    SessionName?: string | undefined;
    StreamingStatus?: string | undefined;
    AuthenticationResult?: AuthenticationResult | undefined;
    FraudDetectionResult?: FraudDetectionResult | undefined;
}
export type MaxResultsForListDomainFe = number;
export type NextToken = string;
export interface ListDomainsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DomainSummary {
    DomainId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    DomainStatus?: string | undefined;
    ServerSideEncryptionConfiguration?: ServerSideEncryptionConfiguration | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    ServerSideEncryptionUpdateDetails?: ServerSideEncryptionUpdateDetails | undefined;
    WatchlistDetails?: WatchlistDetails | undefined;
}
export type DomainSummaries = DomainSummary[];
export interface ListDomainsResponse {
    DomainSummaries?: DomainSummary[] | undefined;
    NextToken?: string | undefined;
}
export type MaxResultsForList = number;
export interface ListFraudsterRegistrationJobsRequest {
    DomainId: string;
    JobStatus?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FraudsterRegistrationJobSummary {
    JobName?: string | redacted.Redacted<string> | undefined;
    JobId?: string | undefined;
    JobStatus?: string | undefined;
    DomainId?: string | undefined;
    CreatedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    FailureDetails?: FailureDetails | undefined;
    JobProgress?: JobProgress | undefined;
}
export type FraudsterRegistrationJobSummaries = FraudsterRegistrationJobSummary[];
export interface ListFraudsterRegistrationJobsResponse {
    JobSummaries?: FraudsterRegistrationJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFraudstersRequest {
    DomainId: string;
    WatchlistId?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FraudsterSummary {
    DomainId?: string | undefined;
    GeneratedFraudsterId?: string | undefined;
    CreatedAt?: Date | undefined;
    WatchlistIds?: string[] | undefined;
}
export type FraudsterSummaries = FraudsterSummary[];
export interface ListFraudstersResponse {
    FraudsterSummaries?: FraudsterSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSpeakerEnrollmentJobsRequest {
    DomainId: string;
    JobStatus?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SpeakerEnrollmentJobSummary {
    JobName?: string | redacted.Redacted<string> | undefined;
    JobId?: string | undefined;
    JobStatus?: string | undefined;
    DomainId?: string | undefined;
    CreatedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    FailureDetails?: FailureDetails | undefined;
    JobProgress?: JobProgress | undefined;
}
export type SpeakerEnrollmentJobSummaries = SpeakerEnrollmentJobSummary[];
export interface ListSpeakerEnrollmentJobsResponse {
    JobSummaries?: SpeakerEnrollmentJobSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSpeakersRequest {
    DomainId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SpeakerSummary {
    DomainId?: string | undefined;
    CustomerSpeakerId?: string | redacted.Redacted<string> | undefined;
    GeneratedSpeakerId?: string | undefined;
    Status?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    LastAccessedAt?: Date | undefined;
}
export type SpeakerSummaries = SpeakerSummary[];
export interface ListSpeakersResponse {
    SpeakerSummaries?: SpeakerSummary[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListWatchlistsRequest {
    DomainId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface WatchlistSummary {
    DomainId?: string | undefined;
    WatchlistId?: string | undefined;
    Name?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    DefaultWatchlist?: boolean | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type WatchlistSummaries = WatchlistSummary[];
export interface ListWatchlistsResponse {
    WatchlistSummaries?: WatchlistSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface OptOutSpeakerRequest {
    DomainId: string;
    SpeakerId: string | redacted.Redacted<string>;
}
export interface OptOutSpeakerResponse {
    Speaker?: Speaker | undefined;
}
export interface StartFraudsterRegistrationJobRequest {
    ClientToken?: string | undefined;
    JobName?: string | redacted.Redacted<string> | undefined;
    DomainId: string;
    DataAccessRoleArn: string;
    RegistrationConfig?: RegistrationConfig | undefined;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
}
export interface StartFraudsterRegistrationJobResponse {
    Job?: FraudsterRegistrationJob | undefined;
}
export interface StartSpeakerEnrollmentJobRequest {
    ClientToken?: string | undefined;
    JobName?: string | redacted.Redacted<string> | undefined;
    DomainId: string;
    DataAccessRoleArn: string;
    EnrollmentConfig?: EnrollmentConfig | undefined;
    InputDataConfig: InputDataConfig;
    OutputDataConfig: OutputDataConfig;
}
export interface StartSpeakerEnrollmentJobResponse {
    Job?: SpeakerEnrollmentJob | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = (string | redacted.Redacted<string>)[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: (string | redacted.Redacted<string>)[];
}
export interface UntagResourceResponse {
}
export interface UpdateDomainRequest {
    DomainId: string;
    Name: string | redacted.Redacted<string>;
    Description?: string | redacted.Redacted<string> | undefined;
    ServerSideEncryptionConfiguration: ServerSideEncryptionConfiguration;
}
export interface UpdateDomainResponse {
    Domain?: Domain | undefined;
}
export interface UpdateWatchlistRequest {
    DomainId: string;
    WatchlistId: string;
    Name?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateWatchlistResponse {
    Watchlist?: Watchlist | undefined;
}
export type ConflictType = string;
export type ResourceType = string;
export type AssociateFraudsterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates the fraudsters with the watchlist specified in the same domain.
 */
export declare const associateFraudster: API.OperationMethod<AssociateFraudsterRequest & RegionInput, AssociateFraudsterResponse, AssociateFraudsterError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain that contains all Amazon Connect Voice ID data, such as speakers, fraudsters,
 * customer audio, and voiceprints. Every domain is created with a default watchlist that fraudsters can be a part of.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResponse, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreateWatchlistError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a watchlist that fraudsters can be a part of.
 */
export declare const createWatchlist: API.OperationMethod<CreateWatchlistRequest & RegionInput, CreateWatchlistResponse, CreateWatchlistError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified domain from Voice ID.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResponse, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteFraudsterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified fraudster from Voice ID. This action disassociates the fraudster from any watchlists it is a part of.
 */
export declare const deleteFraudster: API.OperationMethod<DeleteFraudsterRequest & RegionInput, DeleteFraudsterResponse, DeleteFraudsterError, Credentials | HttpClient.HttpClient>;
export type DeleteSpeakerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified speaker from Voice ID.
 */
export declare const deleteSpeaker: API.OperationMethod<DeleteSpeakerRequest & RegionInput, DeleteSpeakerResponse, DeleteSpeakerError, Credentials | HttpClient.HttpClient>;
export type DeleteWatchlistError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified watchlist from Voice ID. This API throws an exception when
 * there are fraudsters in the watchlist that you are trying to delete. You must delete the
 * fraudsters, and then delete the watchlist. Every domain has a default watchlist which cannot be deleted.
 */
export declare const deleteWatchlist: API.OperationMethod<DeleteWatchlistRequest & RegionInput, DeleteWatchlistResponse, DeleteWatchlistError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified domain.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest & RegionInput, DescribeDomainResponse, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeFraudsterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified fraudster.
 */
export declare const describeFraudster: API.OperationMethod<DescribeFraudsterRequest & RegionInput, DescribeFraudsterResponse, DescribeFraudsterError, Credentials | HttpClient.HttpClient>;
export type DescribeFraudsterRegistrationJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified fraudster registration job.
 */
export declare const describeFraudsterRegistrationJob: API.OperationMethod<DescribeFraudsterRegistrationJobRequest & RegionInput, DescribeFraudsterRegistrationJobResponse, DescribeFraudsterRegistrationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeSpeakerError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified speaker.
 */
export declare const describeSpeaker: API.OperationMethod<DescribeSpeakerRequest & RegionInput, DescribeSpeakerResponse, DescribeSpeakerError, Credentials | HttpClient.HttpClient>;
export type DescribeSpeakerEnrollmentJobError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified speaker enrollment job.
 */
export declare const describeSpeakerEnrollmentJob: API.OperationMethod<DescribeSpeakerEnrollmentJobRequest & RegionInput, DescribeSpeakerEnrollmentJobResponse, DescribeSpeakerEnrollmentJobError, Credentials | HttpClient.HttpClient>;
export type DescribeWatchlistError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the specified watchlist.
 */
export declare const describeWatchlist: API.OperationMethod<DescribeWatchlistRequest & RegionInput, DescribeWatchlistResponse, DescribeWatchlistError, Credentials | HttpClient.HttpClient>;
export type DisassociateFraudsterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disassociates the fraudsters from the watchlist specified. Voice ID always expects a
 * fraudster to be a part of at least one watchlist. If
 * you try to disassociate a fraudster from its only watchlist, a `ValidationException` is thrown.
 */
export declare const disassociateFraudster: API.OperationMethod<DisassociateFraudsterRequest & RegionInput, DisassociateFraudsterResponse, DisassociateFraudsterError, Credentials | HttpClient.HttpClient>;
export type EvaluateSessionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Evaluates a specified session based on audio data accumulated during a streaming
 * Amazon Connect Voice ID call.
 */
export declare const evaluateSession: API.OperationMethod<EvaluateSessionRequest & RegionInput, EvaluateSessionResponse, EvaluateSessionError, Credentials | HttpClient.HttpClient>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the domains in the Amazon Web Services account.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest & RegionInput, ListDomainsResponse, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListFraudsterRegistrationJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the fraudster registration jobs in the domain with the given
 * `JobStatus`. If `JobStatus` is not provided, this lists all
 * fraudster registration jobs in the given domain.
 */
export declare const listFraudsterRegistrationJobs: API.PaginatedOperationMethod<ListFraudsterRegistrationJobsRequest & RegionInput, ListFraudsterRegistrationJobsResponse, ListFraudsterRegistrationJobsError, Credentials | HttpClient.HttpClient, FraudsterRegistrationJobSummary>;
export type ListFraudstersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all fraudsters in a specified watchlist or domain.
 */
export declare const listFraudsters: API.PaginatedOperationMethod<ListFraudstersRequest & RegionInput, ListFraudstersResponse, ListFraudstersError, Credentials | HttpClient.HttpClient, FraudsterSummary>;
export type ListSpeakerEnrollmentJobsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the speaker enrollment jobs in the domain with the specified
 * `JobStatus`. If `JobStatus` is not provided, this lists all
 * jobs with all possible speaker enrollment job statuses.
 */
export declare const listSpeakerEnrollmentJobs: API.PaginatedOperationMethod<ListSpeakerEnrollmentJobsRequest & RegionInput, ListSpeakerEnrollmentJobsResponse, ListSpeakerEnrollmentJobsError, Credentials | HttpClient.HttpClient, SpeakerEnrollmentJobSummary>;
export type ListSpeakersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all speakers in a specified domain.
 */
export declare const listSpeakers: API.PaginatedOperationMethod<ListSpeakersRequest & RegionInput, ListSpeakersResponse, ListSpeakersError, Credentials | HttpClient.HttpClient, SpeakerSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all tags associated with a specified Voice ID resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWatchlistsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all watchlists in a specified domain.
 */
export declare const listWatchlists: API.PaginatedOperationMethod<ListWatchlistsRequest & RegionInput, ListWatchlistsResponse, ListWatchlistsError, Credentials | HttpClient.HttpClient, WatchlistSummary>;
export type OptOutSpeakerError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Opts out a speaker from Voice ID. A speaker can be opted out regardless of whether or
 * not they already exist in Voice ID. If they don't yet exist, a new speaker is created
 * in an opted out state. If they already exist, their existing status is overridden and
 * they are opted out. Enrollment and evaluation authentication requests are rejected for
 * opted out speakers, and opted out speakers have no voice embeddings stored in
 * Voice ID.
 */
export declare const optOutSpeaker: API.OperationMethod<OptOutSpeakerRequest & RegionInput, OptOutSpeakerResponse, OptOutSpeakerError, Credentials | HttpClient.HttpClient>;
export type StartFraudsterRegistrationJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new batch fraudster registration job using provided details.
 */
export declare const startFraudsterRegistrationJob: API.OperationMethod<StartFraudsterRegistrationJobRequest & RegionInput, StartFraudsterRegistrationJobResponse, StartFraudsterRegistrationJobError, Credentials | HttpClient.HttpClient>;
export type StartSpeakerEnrollmentJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a new batch speaker enrollment job using specified details.
 */
export declare const startSpeakerEnrollmentJob: API.OperationMethod<StartSpeakerEnrollmentJobRequest & RegionInput, StartSpeakerEnrollmentJobResponse, StartSpeakerEnrollmentJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tags a Voice ID resource with the provided list of tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes specified tags from a specified Amazon Connect Voice ID resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified domain. This API has clobber behavior, and clears and replaces
 * all attributes. If an optional field, such as 'Description' is not provided, it is
 * removed from the domain.
 */
export declare const updateDomain: API.OperationMethod<UpdateDomainRequest & RegionInput, UpdateDomainResponse, UpdateDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateWatchlistError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified watchlist. Every domain has a default watchlist which cannot be updated.
 */
export declare const updateWatchlist: API.OperationMethod<UpdateWatchlistRequest & RegionInput, UpdateWatchlistResponse, UpdateWatchlistError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=voice-id.d.ts.map