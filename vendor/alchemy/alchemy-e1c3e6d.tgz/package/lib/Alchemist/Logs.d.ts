import * as Effect from "effect/Effect";
import * as Stream from "effect/Stream";
import type { ConfiguredStack } from "../Stack.ts";
import * as State from "../State/index.ts";
import { AlchemistInvalidInput } from "./Errors.ts";
import { type BuildOptions } from "./Operations.ts";
export interface ResourceIdentity {
    readonly fqn: string;
    readonly logicalId: string;
    readonly resourceType: string;
}
export interface LogResource extends ResourceIdentity {
    readonly supportsQuery: boolean;
    readonly supportsTail: boolean;
}
export interface LogEntry {
    readonly resource: ResourceIdentity;
    readonly timestamp: Date;
    readonly message: string;
}
export interface LogOptions extends BuildOptions {
    readonly stack: ConfiguredStack<unknown, unknown>;
    /** Logical IDs to include. Empty or omitted means every resource. */
    readonly resources?: ReadonlyArray<string>;
}
export interface QueryOptions extends LogOptions {
    readonly limit?: number;
    readonly since?: Date;
}
/** Every deployed resource, with the log capabilities its provider offers. */
export declare const resources: (options: BuildOptions & {
    readonly stack: ConfiguredStack<unknown, unknown>;
}) => Effect.Effect<LogResource[], AlchemistInvalidInput | import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError | State.StateStoreError, import("../AlchemyContext.ts").AlchemyContext | import("effect/FileSystem").FileSystem>;
/** Query past log entries across the selected resources, oldest first. */
export declare const entries: (input: QueryOptions) => Effect.Effect<{
    resource: {
        fqn: string;
        logicalId: string;
        resourceType: string;
    };
    timestamp: Date;
    message: string;
}[], import("../Provider.ts").ProviderError, import("../AlchemyContext.ts").AlchemyContext | import("effect/FileSystem").FileSystem>;
/** Live-stream log entries from every selected resource that supports it. */
export declare const tail: (input: LogOptions) => Stream.Stream<LogEntry, AlchemistInvalidInput | import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError | import("../Provider.ts").ProviderError | State.StateStoreError, import("../AlchemyContext.ts").AlchemyContext | import("effect/FileSystem").FileSystem>;
//# sourceMappingURL=Logs.d.ts.map