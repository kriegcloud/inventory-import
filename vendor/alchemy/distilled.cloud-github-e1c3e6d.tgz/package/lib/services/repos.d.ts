import * as API from "@distilled.cloud/core/api";
import type * as Redacted from "effect/Redacted";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface AcceptInvitationForAuthenticatedUserRequest {
    /** The unique identifier of the invitation. */
    invitation_id: number;
}
export interface AcceptInvitationForAuthenticatedUserResponse {
}
/** The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items. */
export type AddAppAccessRestrictionsRequestAppsList = Array<string>;
export interface AddAppAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items. */
    apps: AddAppAccessRestrictionsRequestAppsList;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type IntegrationOwner = SimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface IntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type IntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface Integration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: IntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: IntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: IntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
export type AddAppAccessRestrictionsResponseBodyList = Array<Integration | null>;
export type AddAppAccessRestrictionsResponse = AddAppAccessRestrictionsResponseBodyList;
export interface AddCollaboratorRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The handle for the GitHub user account. */
    username: string;
    /** The permission to grant the collaborator. **Only valid on organization-owned repositories.** We accept the following permissions to be set: `pull`, `triage`, `moderate`, `push`, `maintain`, `admin` and you can also specify a custom repository role name, if the owning organization has defined any. */
    permission?: string | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
/** The permission associated with the invitation. */
export type RepositoryInvitationPermissions = "read" | "write" | "admin" | "triage" | "moderate" | "maintain";
/** Repository invitations let you manage who you collaborate with. */
export interface RepositoryInvitation {
    /** Unique identifier of the repository invitation. */
    id: number;
    repository: MinimalRepository;
    invitee: SimpleUser | null;
    inviter: SimpleUser | null;
    /** The permission associated with the invitation. */
    permissions: RepositoryInvitationPermissions;
    created_at: string;
    /** Whether or not the invitation has expired */
    expired?: boolean | undefined;
    /** URL for the repository invitation */
    url: string;
    html_url: string;
    node_id: string;
}
/** The name of the status checks */
export type AddStatusCheckContextsRequestBodyCase0ContextsList = Array<string>;
export interface AddStatusCheckContextsRequestBodyCase0 {
    /** The name of the status checks */
    contexts: AddStatusCheckContextsRequestBodyCase0ContextsList;
}
/** The name of the status checks */
export type AddStatusCheckContextsRequestBodyCase1List = Array<string>;
export type AddStatusCheckContextsRequestBody = AddStatusCheckContextsRequestBodyCase0 | AddStatusCheckContextsRequestBodyCase1List;
export interface AddStatusCheckContextsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    body?: AddStatusCheckContextsRequestBody | undefined;
}
export type AddStatusCheckContextsResponseBodyList = Array<string>;
export type AddStatusCheckContextsResponse = AddStatusCheckContextsResponseBodyList;
/** The slug values for teams */
export type AddTeamAccessRestrictionsRequestBodyCase0TeamsList = Array<string>;
export interface AddTeamAccessRestrictionsRequestBodyCase0 {
    /** The slug values for teams */
    teams: AddTeamAccessRestrictionsRequestBodyCase0TeamsList;
}
/** The slug values for teams */
export type AddTeamAccessRestrictionsRequestBodyCase1List = Array<string>;
export type AddTeamAccessRestrictionsRequestBody = AddTeamAccessRestrictionsRequestBodyCase0 | AddTeamAccessRestrictionsRequestBodyCase1List;
export interface AddTeamAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    body?: AddTeamAccessRestrictionsRequestBody | undefined;
}
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type AddTeamAccessRestrictionsResponseBodyList = Array<Team>;
export type AddTeamAccessRestrictionsResponse = AddTeamAccessRestrictionsResponseBodyList;
/** The username for users */
export type AddUserAccessRestrictionsRequestUsersList = Array<string>;
export interface AddUserAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The username for users */
    users: AddUserAccessRestrictionsRequestUsersList;
}
export type AddUserAccessRestrictionsResponseBodyList = Array<SimpleUser>;
export type AddUserAccessRestrictionsResponse = AddUserAccessRestrictionsResponseBodyList;
export interface CancelPagesDeploymentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the Pages deployment. You can also give the commit SHA of the deployment. */
    pages_deployment_id: string;
}
export interface CancelPagesDeploymentResponse {
}
export interface CheckAutomatedSecurityFixesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Check Dependabot security updates */
export interface CheckAutomatedSecurityFixes {
    /** Whether Dependabot security updates are enabled for the repository. */
    enabled: boolean;
    /** Whether Dependabot security updates are paused for the repository. */
    paused: boolean;
}
export interface CheckCollaboratorRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface CheckCollaboratorResponse {
}
export interface CheckImmutableReleasesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Check immutable releases */
export interface CheckImmutableReleases {
    /** Whether immutable releases are enabled for the repository. */
    enabled: boolean;
    /** Whether immutable releases are enforced by the repository owner. */
    enforced_by_owner: boolean;
}
export interface CheckPrivateVulnerabilityReportingRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface CheckPrivateVulnerabilityReportingResponse {
    /** Whether or not private vulnerability reporting is enabled for the repository. */
    enabled: boolean;
}
export interface CheckVulnerabilityAlertsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface CheckVulnerabilityAlertsResponse {
}
export interface CodeownersErrorsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A branch, tag or commit name used to determine which version of the CODEOWNERS file to use. Default: the repository's default branch (e.g. `main`) */
    ref?: string | undefined;
}
export interface CodeownersErrorsErrorsItem {
    /** The line number where this errors occurs. */
    line: number;
    /** The column number where this errors occurs. */
    column: number;
    /** The contents of the line where the error occurs. */
    source?: string | undefined;
    /** The type of error. */
    kind: string;
    /** Suggested action to fix the error. This will usually be `null`, but is provided for some common errors. */
    suggestion?: string | null | undefined;
    /** A human-readable description of the error, combining information from multiple fields, laid out for display in a monospaced typeface (for example, a command-line setting). */
    message: string;
    /** The path of the file where the error occured. */
    path: string;
}
export type CodeownersErrorsErrorsList = Array<CodeownersErrorsErrorsItem>;
/** A list of errors found in a repo's CODEOWNERS file */
export interface CodeownersErrors {
    errors: CodeownersErrorsErrorsList;
}
export type CompareCommitsRequestAccept = "application/vnd.github+json" | "application/vnd.github.diff" | "application/vnd.github.patch";
export interface CompareCommitsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The base branch and head branch to compare. This parameter expects the format `BASE...HEAD`. Both must be branch names in `repo`. To compare with a branch that exists in a different repository in the same network as `repo`, the `basehead` parameter expects the format `USERNAME:BASE...USERNAME:HEAD`. */
    basehead: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A media type that returns text instead of JSON: `application/vnd.github.diff`, `application/vnd.github.patch`. */
    accept?: CompareCommitsRequestAccept | (string & {}) | undefined;
}
/** Metaproperties for Git author/committer information. */
export interface NullableGitUser {
    name?: string | undefined;
    email?: string | undefined;
    date?: string | undefined;
}
export interface CommitCommitTree {
    sha: string;
    url: string;
}
export interface Verification {
    verified: boolean;
    reason: string;
    payload: string | null;
    signature: string | null;
    verified_at: string | null;
}
export interface CommitCommit {
    url: string;
    author: NullableGitUser | null;
    committer: NullableGitUser | null;
    message: string;
    comment_count: number;
    tree: CommitCommitTree;
    verification?: Verification | undefined;
}
export type CommitAuthor = SimpleUser | unknown;
export type CommitCommitter = SimpleUser | unknown;
export interface CommitParentsItem {
    sha: string;
    url: string;
    html_url?: string | undefined;
}
export type CommitParentsList = Array<CommitParentsItem>;
export interface CommitStats {
    additions?: number | undefined;
    deletions?: number | undefined;
    total?: number | undefined;
}
export type DiffEntryStatus = "added" | "removed" | "modified" | "renamed" | "copied" | "changed" | "unchanged";
/** Diff Entry */
export interface DiffEntry {
    sha: string | null;
    filename: string;
    status: DiffEntryStatus;
    additions: number;
    deletions: number;
    changes: number;
    blob_url: string;
    raw_url: string;
    contents_url: string;
    patch?: string | undefined;
    previous_filename?: string | undefined;
}
export type CommitFilesList = Array<DiffEntry>;
/** Commit */
export interface Commit {
    url: string;
    sha: string;
    node_id: string;
    html_url: string;
    comments_url: string;
    commit: CommitCommit;
    author: CommitAuthor | null;
    committer: CommitCommitter | null;
    parents: CommitParentsList;
    stats?: CommitStats | undefined;
    files?: CommitFilesList | undefined;
}
export type CommitComparisonStatus = "diverged" | "ahead" | "behind" | "identical";
export type CommitComparisonCommitsList = Array<Commit>;
export type CommitComparisonFilesList = Array<DiffEntry>;
/** Commit Comparison */
export interface CommitComparison {
    url: string;
    html_url: string;
    permalink_url: string;
    diff_url: string;
    patch_url: string;
    base_commit: Commit;
    merge_base_commit: Commit;
    status: CommitComparisonStatus;
    ahead_by: number;
    behind_by: number;
    total_commits: number;
    commits: CommitComparisonCommitsList;
    files?: CommitComparisonFilesList | undefined;
}
export type CompareCommitsResponseBody = CommitComparison | string;
export type CompareCommitsResponse = CompareCommitsResponseBody;
export type CreateAttestationRequestBundleVerificationMaterialMap = {
    [key: string]: unknown | undefined;
};
export type CreateAttestationRequestBundleDsseEnvelopeMap = {
    [key: string]: unknown | undefined;
};
/** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
export interface CreateAttestationRequestBundle {
    mediaType?: string | undefined;
    verificationMaterial?: CreateAttestationRequestBundleVerificationMaterialMap | undefined;
    dsseEnvelope?: CreateAttestationRequestBundleDsseEnvelopeMap | undefined;
}
export interface CreateAttestationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
    bundle: CreateAttestationRequestBundle;
}
export interface CreateAttestationResponse {
    /** The ID of the attestation. */
    id?: number | undefined;
}
export interface CreateAutolinkRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** This prefix appended by certain characters will generate a link any time it is found in an issue, pull request, or commit. */
    key_prefix: string;
    /** The URL must contain `<num>` for the reference number. `<num>` matches different characters depending on the value of `is_alphanumeric`. */
    url_template: string;
    /** Whether this autolink reference matches alphanumeric characters. If true, the `<num>` parameter of the `url_template` matches alphanumeric characters `A-Z` (case insensitive), `0-9`, and `-`. If false, this autolink reference only matches numeric characters. */
    is_alphanumeric?: boolean | undefined;
}
/** An autolink reference. */
export interface Autolink {
    id: number;
    /** The prefix of a key that is linkified. */
    key_prefix: string;
    /** A template for the target URL that is generated if a key was found. */
    url_template: string;
    /** Whether this autolink reference matches alphanumeric characters. If false, this autolink reference only matches numeric characters. */
    is_alphanumeric: boolean;
    updated_at?: string | null | undefined;
}
export interface CreateCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA of the commit. */
    commit_sha: string;
    /** The contents of the comment. */
    body: string;
    /** Relative path of the file to comment on. */
    path?: string | undefined;
    /** Line index in the diff to comment on. */
    position?: number | undefined;
    /** **Closing down notice**. Use **position** parameter instead. Line number in the file to comment on. */
    line?: number | undefined;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
export interface ReactionRollup {
    url: string;
    total_count: number;
    _1: number;
    _1_2: number;
    laugh: number;
    confused: number;
    heart: number;
    hooray: number;
    eyes: number;
    rocket: number;
}
/** Commit Comment */
export interface CommitComment {
    html_url: string;
    url: string;
    id: number;
    node_id: string;
    body: string;
    path: string | null;
    position: number | null;
    line: number | null;
    commit_id: string;
    user: SimpleUser | null;
    created_at: string;
    updated_at: string;
    author_association: AuthorAssociation;
    reactions?: ReactionRollup | undefined;
}
export interface CreateCommitSignatureProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
/** Protected Branch Admin Enforced */
export interface ProtectedBranchAdminEnforced {
    url: string;
    enabled: boolean;
}
/** The state of the status. */
export type CreateCommitStatusRequestState = "error" | "failure" | "pending" | "success";
export interface CreateCommitStatusRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    sha: string;
    /** The state of the status. */
    state: CreateCommitStatusRequestState | (string & {});
    /** The target URL to associate with this status. This URL will be linked from the GitHub UI to allow users to easily see the source of the status. For example, if your continuous integration system is posting build status, you would want to provide the deep link for the build output for this specific SHA: `http://ci.example.com/user/repo/build/sha` */
    target_url?: string | null | undefined;
    /** A short description of the status. */
    description?: string | null | undefined;
    /** A string label to differentiate this status from the status of other systems. This field is case-insensitive. */
    context?: string | undefined;
}
/** The status of a commit. */
export interface Status {
    url: string;
    avatar_url: string | null;
    id: number;
    node_id: string;
    state: string;
    description: string | null;
    target_url: string | null;
    context: string;
    created_at: string;
    updated_at: string;
    creator: SimpleUser | null;
}
export interface CreateDeployKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A name for the key. */
    title?: string | undefined;
    /** The contents of the key. */
    key: string;
    /** If `true`, the key will only be able to read repository contents. Otherwise, the key will be able to read and write. Deploy keys with write access can perform the same actions as an organization member with admin access, or a collaborator on a personal repository. For more information, see "[Repository permission levels for an organization](https://docs.github.com/articles/repository-permission-levels-for-an-organization/)" and "[Permission levels for a user account repository](https://docs.github.com/articles/permission-levels-for-a-user-account-repository/)." */
    read_only?: boolean | undefined;
}
/** An SSH key granting access to a single repository. */
export interface DeployKey {
    id: number;
    key: string;
    url: string;
    title: string;
    verified: boolean;
    created_at: string;
    read_only: boolean;
    added_by?: string | null | undefined;
    last_used?: string | null | undefined;
    enabled?: boolean | undefined;
}
/** The [status](https://docs.github.com/rest/commits/statuses) contexts to verify against commit status checks. If you omit this parameter, GitHub verifies all unique contexts before creating a deployment. To bypass checking entirely, pass an empty array. Defaults to all unique contexts. */
export type CreateDeploymentRequestRequiredContextsList = Array<string>;
export type CreateDeploymentRequestPayloadCase0Map = {
    [key: string]: unknown | undefined;
};
export type CreateDeploymentRequestPayload = CreateDeploymentRequestPayloadCase0Map | string;
export interface CreateDeploymentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ref to deploy. This can be a branch, tag, or SHA. */
    ref: string;
    /** Specifies a task to execute (e.g., `deploy` or `deploy:migrations`). */
    task?: string | undefined;
    /** Attempts to automatically merge the default branch into the requested ref, if it's behind the default branch. */
    auto_merge?: boolean | undefined;
    /** The [status](https://docs.github.com/rest/commits/statuses) contexts to verify against commit status checks. If you omit this parameter, GitHub verifies all unique contexts before creating a deployment. To bypass checking entirely, pass an empty array. Defaults to all unique contexts. */
    required_contexts?: CreateDeploymentRequestRequiredContextsList | undefined;
    payload?: CreateDeploymentRequestPayload | undefined;
    /** Name for the target deployment environment (e.g., `production`, `staging`, `qa`). */
    environment?: string | undefined;
    /** Short description of the deployment. */
    description?: string | null | undefined;
    /** Specifies if the given environment is specific to the deployment and will no longer exist at some point in the future. Default: `false` */
    transient_environment?: boolean | undefined;
    /** Specifies if the given environment is one that end-users directly interact with. Default: `true` when `environment` is `production` and `false` otherwise. */
    production_environment?: boolean | undefined;
}
export type DeploymentPayloadCase0Map = {
    [key: string]: unknown | undefined;
};
export type DeploymentPayload = DeploymentPayloadCase0Map | string;
export type NullableIntegrationOwner = SimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export type NullableIntegrationPermissions = IntegrationPermissions;
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: IntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
/** A request for a specific ref(branch,sha,tag) to be deployed */
export interface Deployment {
    url: string;
    /** Unique identifier of the deployment */
    id: number;
    node_id: string;
    sha: string;
    /** The ref to deploy. This can be a branch, tag, or sha. */
    ref: string;
    /** Parameter to specify a task to execute */
    task: string;
    payload: DeploymentPayload;
    original_environment?: string | undefined;
    /** Name for the target deployment environment. */
    environment: string;
    description: string | null;
    creator: SimpleUser | null;
    created_at: string;
    updated_at: string;
    statuses_url: string;
    repository_url: string;
    /** Specifies if the given environment is will no longer exist at some point in the future. Default: false. */
    transient_environment?: boolean | undefined;
    /** Specifies if the given environment is one that end-users directly interact with. Default: false. */
    production_environment?: boolean | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
}
/** Whether this rule targets a branch or tag */
export type CreateDeploymentBranchPolicyRequestType = "branch" | "tag";
export interface CreateDeploymentBranchPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The name pattern that branches or tags must match in order to deploy to the environment. Wildcard characters will not match `/`. For example, to match branches that begin with `release/` and contain an additional single slash, use `release/*\/*`. For more information about pattern matching syntax, see the [Ruby File.fnmatch documentation](https://ruby-doc.org/core-2.5.1/File.html#method-c-fnmatch). */
    name: string;
    /** Whether this rule targets a branch or tag */
    type?: CreateDeploymentBranchPolicyRequestType | (string & {}) | undefined;
}
/** Whether this rule targets a branch or tag. */
export type DeploymentBranchPolicyType = "branch" | "tag";
/** Details of a deployment branch or tag policy. */
export interface DeploymentBranchPolicy {
    /** The unique identifier of the branch or tag policy. */
    id?: number | undefined;
    node_id?: string | undefined;
    /** The name pattern that branches or tags must match in order to deploy to the environment. */
    name?: string | undefined;
    /** Whether this rule targets a branch or tag. */
    type?: DeploymentBranchPolicyType | undefined;
}
export interface CreateDeploymentProtectionRuleRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The ID of the custom app that will be enabled on the environment. */
    integration_id?: number | undefined;
}
/** A GitHub App that is providing a custom deployment protection rule. */
export interface CustomDeploymentRuleApp {
    /** The unique identifier of the deployment protection rule integration. */
    id: number;
    /** The slugified name of the deployment protection rule integration. */
    slug: string;
    /** The URL for the endpoint to get details about the app. */
    integration_url: string;
    /** The node ID for the deployment protection rule integration. */
    node_id: string;
}
/** Deployment protection rule */
export interface DeploymentProtectionRule {
    /** The unique identifier for the deployment protection rule. */
    id: number;
    /** The node ID for the deployment protection rule. */
    node_id: string;
    /** Whether the deployment protection rule is enabled for the environment. */
    enabled: boolean;
    app: CustomDeploymentRuleApp;
}
/** The state of the status. When you set a transient deployment to `inactive`, the deployment will be shown as `destroyed` in GitHub. */
export type CreateDeploymentStatusRequestState = "error" | "failure" | "inactive" | "in_progress" | "queued" | "pending" | "success";
export interface CreateDeploymentStatusRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** deployment_id parameter */
    deployment_id: number;
    /** The state of the status. When you set a transient deployment to `inactive`, the deployment will be shown as `destroyed` in GitHub. */
    state: CreateDeploymentStatusRequestState | (string & {});
    /** The target URL to associate with this status. This URL should contain output to keep the user updated while the task is running or serve as historical information for what happened in the deployment. > [!NOTE] > It's recommended to use the `log_url` parameter, which replaces `target_url`. */
    target_url?: string | undefined;
    /** The full URL of the deployment's output. This parameter replaces `target_url`. We will continue to accept `target_url` to support legacy uses, but we recommend replacing `target_url` with `log_url`. Setting `log_url` will automatically set `target_url` to the same value. Default: `""` */
    log_url?: string | undefined;
    /** A short description of the status. The maximum description length is 140 characters. */
    description?: string | undefined;
    /** Name for the target deployment environment, which can be changed when setting a deploy status. For example, `production`, `staging`, or `qa`. If not defined, the environment of the previous status on the deployment will be used, if it exists. Otherwise, the environment of the deployment will be used. */
    environment?: string | undefined;
    /** Sets the URL for accessing your environment. Default: `""` */
    environment_url?: string | undefined;
    /** Adds a new `inactive` status to all prior non-transient, non-production environment deployments with the same repository and `environment` name as the created status's deployment. An `inactive` status is only added to deployments that had a `success` state. Default: `true` */
    auto_inactive?: boolean | undefined;
}
/** The state of the status. */
export type DeploymentStatusState = "error" | "failure" | "inactive" | "pending" | "success" | "queued" | "in_progress";
/** The status of a deployment. */
export interface DeploymentStatus {
    url: string;
    id: number;
    node_id: string;
    /** The state of the status. */
    state: DeploymentStatusState;
    creator: SimpleUser | null;
    /** A short description of the status. */
    description: string;
    /** The environment of the deployment that the status is for. */
    environment?: string | undefined;
    /** Closing down notice: the URL to associate with this status. */
    target_url: string;
    created_at: string;
    updated_at: string;
    deployment_url: string;
    repository_url: string;
    /** The URL for accessing your environment. */
    environment_url?: string | undefined;
    /** The URL to associate with this status. */
    log_url?: string | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
}
/** JSON payload with extra information about the webhook event that your action or workflow may use. The maximum number of top-level properties is 10. The total size of the JSON payload must be less than 64KB. */
export type CreateDispatchEventRequestClientPayloadMap = {
    [key: string]: unknown | undefined;
};
export interface CreateDispatchEventRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A custom webhook event name. Must be 100 characters or fewer. */
    event_type: string;
    /** JSON payload with extra information about the webhook event that your action or workflow may use. The maximum number of top-level properties is 10. The total size of the JSON payload must be less than 64KB. */
    client_payload?: CreateDispatchEventRequestClientPayloadMap | undefined;
}
export interface CreateDispatchEventResponse {
}
/** Required when using `squash_merge_commit_message`. The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type CreateForAuthenticatedUserRequestSquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type CreateForAuthenticatedUserRequestSquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** Required when using `merge_commit_message`. The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type CreateForAuthenticatedUserRequestMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type CreateForAuthenticatedUserRequestMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
export interface CreateForAuthenticatedUserRequest {
    /** The name of the repository. */
    name: string;
    /** A short description of the repository. */
    description?: string | undefined;
    /** A URL with more information about the repository. */
    homepage?: string | undefined;
    /** Whether the repository is private. */
    private?: boolean | undefined;
    /** Whether issues are enabled. */
    has_issues?: boolean | undefined;
    /** Whether projects are enabled. */
    has_projects?: boolean | undefined;
    /** Whether the wiki is enabled. */
    has_wiki?: boolean | undefined;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization. */
    team_id?: number | undefined;
    /** Whether the repository is initialized with a minimal README. */
    auto_init?: boolean | undefined;
    /** The desired language or platform to apply to the .gitignore. */
    gitignore_template?: string | undefined;
    /** The license keyword of the open source license for this repository. */
    license_template?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Required when using `squash_merge_commit_message`. The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: CreateForAuthenticatedUserRequestSquashMergeCommitTitle | (string & {}) | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: CreateForAuthenticatedUserRequestSquashMergeCommitMessage | (string & {}) | undefined;
    /** Required when using `merge_commit_message`. The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: CreateForAuthenticatedUserRequestMergeCommitTitle | (string & {}) | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: CreateForAuthenticatedUserRequestMergeCommitMessage | (string & {}) | undefined;
    /** Whether downloads are enabled. */
    has_downloads?: boolean | undefined;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
}
export type FullRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type FullRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface FullRepositoryPermissions {
    admin: boolean;
    maintain?: boolean | undefined;
    push: boolean;
    triage?: boolean | undefined;
    pull: boolean;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface NullableRepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type NullableRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type NullableRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type NullableRepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type NullableRepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type NullableRepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type NullableRepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface NullableRepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface NullableRepository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: NullableRepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: NullableRepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: NullableRepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: NullableRepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: NullableRepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: NullableRepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: NullableRepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: NullableRepositoryCodeSearchIndexStatus | undefined;
}
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type FullRepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type FullRepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type FullRepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type FullRepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
export type RepositoryPermissions = NullableRepositoryPermissions;
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export type RepositoryCodeSearchIndexStatus = NullableRepositoryCodeSearchIndexStatus;
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: NullableRepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: NullableRepositoryCodeSearchIndexStatus | undefined;
}
/** Code of Conduct Simple */
export interface CodeOfConductSimple {
    url: string;
    key: string;
    name: string;
    html_url: string | null;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type FullRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Full Repository */
export interface FullRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    default_branch: string;
    open_issues_count: number;
    is_template?: boolean | undefined;
    topics?: FullRepositoryTopicsList | undefined;
    has_issues: boolean;
    has_projects: boolean;
    has_wiki: boolean;
    has_pages: boolean;
    has_downloads?: boolean | undefined;
    has_discussions: boolean;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: FullRepositoryPullRequestCreationPolicy | undefined;
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string;
    created_at: string;
    updated_at: string;
    permissions?: FullRepositoryPermissions | undefined;
    allow_rebase_merge?: boolean | undefined;
    template_repository?: NullableRepository | null | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | null | undefined;
    allow_squash_merge?: boolean | undefined;
    allow_auto_merge?: boolean | undefined;
    delete_branch_on_merge?: boolean | undefined;
    allow_merge_commit?: boolean | undefined;
    allow_update_branch?: boolean | undefined;
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: FullRepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: FullRepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: FullRepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: FullRepositoryMergeCommitMessage | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    subscribers_count: number;
    network_count: number;
    license: NullableLicenseSimple | null;
    organization?: SimpleUser | null | undefined;
    parent?: Repository | undefined;
    source?: Repository | undefined;
    forks: number;
    master_branch?: string | undefined;
    open_issues: number;
    watchers: number;
    /** Whether anonymous git access is allowed. */
    anonymous_access_enabled?: boolean | undefined;
    code_of_conduct?: CodeOfConductSimple | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: FullRepositoryCustomPropertiesMap | undefined;
}
export interface CreateForkRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Optional parameter to specify the organization name if forking into an organization. */
    organization?: string | undefined;
    /** When forking from an existing repository, a new name for the fork. */
    name?: string | undefined;
    /** When forking from an existing repository, fork with only the default branch. */
    default_branch_only?: boolean | undefined;
}
export interface CreateForkResponse {
}
/** The visibility of the repository. */
export type CreateInOrgRequestVisibility = "public" | "private";
/** Required when using `squash_merge_commit_message`. The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type CreateInOrgRequestSquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type CreateInOrgRequestSquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** Required when using `merge_commit_message`. The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type CreateInOrgRequestMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type CreateInOrgRequestMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The custom properties for the new repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type CreateInOrgRequestCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
export interface CreateInOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the repository. */
    name: string;
    /** A short description of the repository. */
    description?: string | undefined;
    /** A URL with more information about the repository. */
    homepage?: string | undefined;
    /** Whether the repository is private. */
    private?: boolean | undefined;
    /** The visibility of the repository. */
    visibility?: CreateInOrgRequestVisibility | (string & {}) | undefined;
    /** Either `true` to enable issues for this repository or `false` to disable them. */
    has_issues?: boolean | undefined;
    /** Either `true` to enable projects for this repository or `false` to disable them. **Note:** If you're creating a repository in an organization that has disabled repository projects, the default is `false`, and if you pass `true`, the API returns an error. */
    has_projects?: boolean | undefined;
    /** Either `true` to enable the wiki for this repository or `false` to disable it. */
    has_wiki?: boolean | undefined;
    /** Whether downloads are enabled. */
    has_downloads?: boolean | undefined;
    /** Either `true` to make this repo available as a template repository or `false` to prevent it. */
    is_template?: boolean | undefined;
    /** The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization. */
    team_id?: number | undefined;
    /** Pass `true` to create an initial commit with empty README. */
    auto_init?: boolean | undefined;
    /** Desired language or platform [.gitignore template](https://github.com/github/gitignore) to apply. Use the name of the template without the extension. For example, "Haskell". */
    gitignore_template?: string | undefined;
    /** Choose an [open source license template](https://choosealicense.com/) that best suits your needs, and then use the [license keyword](https://docs.github.com/articles/licensing-a-repository/#searching-github-by-license-type) as the `license_template` string. For example, "mit" or "mpl-2.0". */
    license_template?: string | undefined;
    /** Either `true` to allow squash-merging pull requests, or `false` to prevent squash-merging. */
    allow_squash_merge?: boolean | undefined;
    /** Either `true` to allow merging pull requests with a merge commit, or `false` to prevent merging pull requests with merge commits. */
    allow_merge_commit?: boolean | undefined;
    /** Either `true` to allow rebase-merging pull requests, or `false` to prevent rebase-merging. */
    allow_rebase_merge?: boolean | undefined;
    /** Either `true` to allow auto-merge on pull requests, or `false` to disallow auto-merge. */
    allow_auto_merge?: boolean | undefined;
    /** Either `true` to allow automatically deleting head branches when pull requests are merged, or `false` to prevent automatic deletion. **The authenticated user must be an organization owner to set this property to `true`.** */
    delete_branch_on_merge?: boolean | undefined;
    /** Either `true` to allow squash-merge commits to use pull request title, or `false` to use commit message. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** Required when using `squash_merge_commit_message`. The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: CreateInOrgRequestSquashMergeCommitTitle | (string & {}) | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: CreateInOrgRequestSquashMergeCommitMessage | (string & {}) | undefined;
    /** Required when using `merge_commit_message`. The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: CreateInOrgRequestMergeCommitTitle | (string & {}) | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: CreateInOrgRequestMergeCommitMessage | (string & {}) | undefined;
    /** The custom properties for the new repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: CreateInOrgRequestCustomPropertiesMap | undefined;
}
/** The target of the ruleset */
export type CreateOrgRulesetRequestTarget = "branch" | "tag" | "push" | "repository";
/** The enforcement level of the ruleset. `evaluate` allows admins to test rules before enforcing them. Admins can view insights on the Rule Insights page (`evaluate` is only available with GitHub Enterprise). */
export type RepositoryRuleEnforcement = "disabled" | "active" | "evaluate";
/** The type of actor that can bypass a ruleset. */
export type RepositoryRulesetBypassActorActorType = "Integration" | "OrganizationAdmin" | "RepositoryRole" | "Team" | "DeployKey" | "User";
/** When the specified actor can bypass the ruleset. `pull_request` means that an actor can only bypass rules on pull requests. `pull_request` is not applicable for the `DeployKey` actor type. Also, `pull_request` is only applicable to branch rulesets. When `bypass_mode` is `exempt`, rules will not be run for that actor and a bypass audit entry will not be created. */
export type RepositoryRulesetBypassActorBypassMode = "always" | "pull_request" | "exempt";
/** An actor that can bypass rules in a ruleset */
export interface RepositoryRulesetBypassActor {
    /** The ID of the actor that can bypass a ruleset. Required for `Integration`, `RepositoryRole`, `Team`, and `User` actor types. If `actor_type` is `OrganizationAdmin`, `actor_id` is ignored. If `actor_type` is `DeployKey`, this should be null. `OrganizationAdmin` is not applicable for personal repositories. */
    actor_id?: number | null | undefined;
    /** The type of actor that can bypass a ruleset. */
    actor_type: RepositoryRulesetBypassActorActorType | (string & {});
    /** When the specified actor can bypass the ruleset. `pull_request` means that an actor can only bypass rules on pull requests. `pull_request` is not applicable for the `DeployKey` actor type. Also, `pull_request` is only applicable to branch rulesets. When `bypass_mode` is `exempt`, rules will not be run for that actor and a bypass audit entry will not be created. */
    bypass_mode?: RepositoryRulesetBypassActorBypassMode | (string & {}) | undefined;
}
/** The actors that can bypass the rules in this ruleset */
export type CreateOrgRulesetRequestBypassActorsList = Array<RepositoryRulesetBypassActor>;
/** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
export type OrgRulesetConditionsCase0RefNameIncludeList = Array<string>;
/** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type OrgRulesetConditionsCase0RefNameExcludeList = Array<string>;
export interface OrgRulesetConditionsCase0RefName {
    /** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
    include?: OrgRulesetConditionsCase0RefNameIncludeList | undefined;
    /** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: OrgRulesetConditionsCase0RefNameExcludeList | undefined;
}
/** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
export type OrgRulesetConditionsCase0RepositoryNameIncludeList = Array<string>;
/** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type OrgRulesetConditionsCase0RepositoryNameExcludeList = Array<string>;
export interface OrgRulesetConditionsCase0RepositoryName {
    /** Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories. */
    include?: OrgRulesetConditionsCase0RepositoryNameIncludeList | undefined;
    /** Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: OrgRulesetConditionsCase0RepositoryNameExcludeList | undefined;
    /** Whether renaming of target repositories is prevented. */
    protected?: boolean | undefined;
}
/** Conditions to target repositories by name and refs by name */
export interface OrgRulesetConditionsCase0 {
    ref_name?: OrgRulesetConditionsCase0RefName | undefined;
    repository_name: OrgRulesetConditionsCase0RepositoryName;
}
/** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
export type OrgRulesetConditionsCase1RefNameIncludeList = Array<string>;
/** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type OrgRulesetConditionsCase1RefNameExcludeList = Array<string>;
export interface OrgRulesetConditionsCase1RefName {
    /** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
    include?: OrgRulesetConditionsCase1RefNameIncludeList | undefined;
    /** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: OrgRulesetConditionsCase1RefNameExcludeList | undefined;
}
/** The repository IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
export type OrgRulesetConditionsCase1RepositoryIdRepositoryIdsList = Array<number>;
export interface OrgRulesetConditionsCase1RepositoryId {
    /** The repository IDs that the ruleset applies to. One of these IDs must match for the condition to pass. */
    repository_ids?: OrgRulesetConditionsCase1RepositoryIdRepositoryIdsList | undefined;
}
/** Conditions to target repositories by id and refs by name */
export interface OrgRulesetConditionsCase1 {
    ref_name?: OrgRulesetConditionsCase1RefName | undefined;
    repository_id: OrgRulesetConditionsCase1RepositoryId;
}
/** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
export type OrgRulesetConditionsCase2RefNameIncludeList = Array<string>;
/** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type OrgRulesetConditionsCase2RefNameExcludeList = Array<string>;
export interface OrgRulesetConditionsCase2RefName {
    /** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
    include?: OrgRulesetConditionsCase2RefNameIncludeList | undefined;
    /** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: OrgRulesetConditionsCase2RefNameExcludeList | undefined;
}
/** The values to match for the repository property */
export type RepositoryRulesetConditionsRepositoryPropertySpecPropertyValuesList = Array<string>;
/** The source of the repository property. Defaults to 'custom' if not specified. */
export type RepositoryRulesetConditionsRepositoryPropertySpecSource = "custom" | "system";
/** Parameters for a targeting a repository property */
export interface RepositoryRulesetConditionsRepositoryPropertySpec {
    /** The name of the repository property to target */
    name: string;
    /** The values to match for the repository property */
    property_values: RepositoryRulesetConditionsRepositoryPropertySpecPropertyValuesList;
    /** The source of the repository property. Defaults to 'custom' if not specified. */
    source?: RepositoryRulesetConditionsRepositoryPropertySpecSource | (string & {}) | undefined;
}
/** The repository properties and values to include. All of these properties must match for the condition to pass. */
export type OrgRulesetConditionsCase2RepositoryPropertyIncludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
/** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
export type OrgRulesetConditionsCase2RepositoryPropertyExcludeList = Array<RepositoryRulesetConditionsRepositoryPropertySpec>;
export interface OrgRulesetConditionsCase2RepositoryProperty {
    /** The repository properties and values to include. All of these properties must match for the condition to pass. */
    include?: OrgRulesetConditionsCase2RepositoryPropertyIncludeList | undefined;
    /** The repository properties and values to exclude. The condition will not pass if any of these properties match. */
    exclude?: OrgRulesetConditionsCase2RepositoryPropertyExcludeList | undefined;
}
/** Conditions to target repositories by property and refs by name */
export interface OrgRulesetConditionsCase2 {
    ref_name?: OrgRulesetConditionsCase2RefName | undefined;
    repository_property: OrgRulesetConditionsCase2RepositoryProperty;
}
/** Conditions for an organization ruleset. The branch and tag rulesets conditions object should contain both `repository_name` and `ref_name` properties, or both `repository_id` and `ref_name` properties, or both `repository_property` and `ref_name` properties. The push rulesets conditions object does not require the `ref_name` property. For repository policy rulesets, the conditions object should only contain the `repository_name`, the `repository_id`, or the `repository_property`. */
export type OrgRulesetConditions = OrgRulesetConditionsCase0 | OrgRulesetConditionsCase1 | OrgRulesetConditionsCase2;
export type RepositoryRuleCreationType = "creation";
/** Only allow users with bypass permission to create matching refs. */
export interface RepositoryRuleCreation {
    type: RepositoryRuleCreationType;
}
export type RepositoryRuleUpdateType = "update";
export interface RepositoryRuleUpdateParameters {
    /** Branch can pull changes from its upstream repository */
    update_allows_fetch_and_merge: boolean;
}
/** Only allow users with bypass permission to update matching refs. */
export interface RepositoryRuleUpdate {
    type: RepositoryRuleUpdateType;
    parameters?: RepositoryRuleUpdateParameters | undefined;
}
export type RepositoryRuleDeletionType = "deletion";
/** Only allow users with bypass permissions to delete matching refs. */
export interface RepositoryRuleDeletion {
    type: RepositoryRuleDeletionType;
}
export type RepositoryRuleRequiredLinearHistoryType = "required_linear_history";
/** Prevent merge commits from being pushed to matching refs. */
export interface RepositoryRuleRequiredLinearHistory {
    type: RepositoryRuleRequiredLinearHistoryType;
}
export type RepositoryRuleRequiredDeploymentsType = "required_deployments";
/** The environments that must be successfully deployed to before branches can be merged. */
export type RepositoryRuleRequiredDeploymentsParametersRequiredDeploymentEnvironmentsList = Array<string>;
export interface RepositoryRuleRequiredDeploymentsParameters {
    /** The environments that must be successfully deployed to before branches can be merged. */
    required_deployment_environments: RepositoryRuleRequiredDeploymentsParametersRequiredDeploymentEnvironmentsList;
}
/** Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule. */
export interface RepositoryRuleRequiredDeployments {
    type: RepositoryRuleRequiredDeploymentsType;
    parameters?: RepositoryRuleRequiredDeploymentsParameters | undefined;
}
export type RepositoryRuleRequiredSignaturesType = "required_signatures";
/** Commits pushed to matching refs must have verified signatures. */
export interface RepositoryRuleRequiredSignatures {
    type: RepositoryRuleRequiredSignaturesType;
}
export type RepositoryRulePullRequestType = "pull_request";
export type RepositoryRulePullRequestParametersAllowedMergeMethodsItem = "merge" | "squash" | "rebase";
/** Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. */
export type RepositoryRulePullRequestParametersAllowedMergeMethodsList = Array<RepositoryRulePullRequestParametersAllowedMergeMethodsItem | (string & {})>;
/** The type of the actor */
export type RepositoryRuleParamsActorType = "User" | "Team" | "IntegrationInstallation" | "RepositoryRole";
/** An actor allowed to dismiss pull request reviews */
export interface RepositoryRuleParamsActor {
    /** ID of the actor that can dismiss reviews. */
    id: number;
    /** The type of the actor */
    type: RepositoryRuleParamsActorType | (string & {});
}
/** Specify people, teams, or apps allowed to dismiss pull request reviews. */
export type RepositoryRuleParamsDismissalRestrictionAllowedActorsList = Array<RepositoryRuleParamsActor>;
/** Specify people, teams, or apps allowed to dismiss pull request reviews. */
export interface RepositoryRuleParamsDismissalRestriction {
    /** Specify people, teams, or apps allowed to dismiss pull request reviews. */
    allowed_actors?: RepositoryRuleParamsDismissalRestrictionAllowedActorsList | undefined;
    /** Whether to restrict review dismissal to specific actors. */
    enabled: boolean;
}
/** Array of file patterns. Pull requests which change matching files must be approved by the specified team. File patterns use fnmatch syntax. */
export type RepositoryRuleParamsRequiredReviewerConfigurationFilePatternsList = Array<string>;
/** The type of the reviewer */
export type RepositoryRuleParamsReviewerType = "Team";
/** A required reviewing team */
export interface RepositoryRuleParamsReviewer {
    /** ID of the reviewer which must review changes to matching files. */
    id: number;
    /** The type of the reviewer */
    type: RepositoryRuleParamsReviewerType | (string & {});
}
/** A reviewing team, and file patterns describing which files they must approve changes to. */
export interface RepositoryRuleParamsRequiredReviewerConfiguration {
    /** Array of file patterns. Pull requests which change matching files must be approved by the specified team. File patterns use fnmatch syntax. */
    file_patterns: RepositoryRuleParamsRequiredReviewerConfigurationFilePatternsList;
    /** Minimum number of approvals required from the specified team. If set to zero, the team will be added to the pull request but approval is optional. */
    minimum_approvals: number;
    reviewer: RepositoryRuleParamsReviewer;
}
/** A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review. */
export type RepositoryRulePullRequestParametersRequiredReviewersList = Array<RepositoryRuleParamsRequiredReviewerConfiguration>;
export interface RepositoryRulePullRequestParameters {
    /** Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. */
    allowed_merge_methods?: RepositoryRulePullRequestParametersAllowedMergeMethodsList | undefined;
    /** New, reviewable commits pushed will dismiss previous pull request review approvals. */
    dismiss_stale_reviews_on_push: boolean;
    dismissal_restriction?: RepositoryRuleParamsDismissalRestriction | undefined;
    /** Require an approving review in pull requests that modify files that have a designated code owner. */
    require_code_owner_review: boolean;
    /** When Copilot opens a pull request without a human collaborator, require one more approving review if a non-zero approval count is required. */
    require_extra_approval_for_unattributed_changes?: boolean | undefined;
    /** Whether the most recent reviewable push must be approved by someone other than the person who pushed it. */
    require_last_push_approval: boolean;
    /** The number of approving reviews that are required before a pull request can be merged. */
    required_approving_review_count: number;
    /** All conversations on code must be resolved before a pull request can be merged. */
    required_review_thread_resolution: boolean;
    /** A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review. */
    required_reviewers?: RepositoryRulePullRequestParametersRequiredReviewersList | undefined;
}
/** Require all commits be made to a non-target branch and submitted via a pull request before they can be merged. */
export interface RepositoryRulePullRequest {
    type: RepositoryRulePullRequestType;
    parameters?: RepositoryRulePullRequestParameters | undefined;
}
export type RepositoryRuleRequiredStatusChecksType = "required_status_checks";
/** Required status check */
export interface RepositoryRuleParamsStatusCheckConfiguration {
    /** The status check context name that must be present on the commit. */
    context: string;
    /** The optional integration ID that this status check must originate from. */
    integration_id?: number | undefined;
}
/** Status checks that are required. */
export type RepositoryRuleRequiredStatusChecksParametersRequiredStatusChecksList = Array<RepositoryRuleParamsStatusCheckConfiguration>;
export interface RepositoryRuleRequiredStatusChecksParameters {
    /** Allow repositories and branches to be created if a check would otherwise prohibit it. */
    do_not_enforce_on_create?: boolean | undefined;
    /** Status checks that are required. */
    required_status_checks: RepositoryRuleRequiredStatusChecksParametersRequiredStatusChecksList;
    /** Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled. */
    strict_required_status_checks_policy: boolean;
}
/** Choose which status checks must pass before the ref is updated. When enabled, commits must first be pushed to another ref where the checks pass. */
export interface RepositoryRuleRequiredStatusChecks {
    type: RepositoryRuleRequiredStatusChecksType;
    parameters?: RepositoryRuleRequiredStatusChecksParameters | undefined;
}
export type RepositoryRuleNonFastForwardType = "non_fast_forward";
/** Prevent users with push access from force pushing to refs. */
export interface RepositoryRuleNonFastForward {
    type: RepositoryRuleNonFastForwardType;
}
export type RepositoryRuleCommitMessagePatternType = "commit_message_pattern";
/** The operator to use for matching. */
export type RepositoryRuleCommitMessagePatternParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleCommitMessagePatternParameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleCommitMessagePatternParametersOperator | (string & {});
    /** The pattern to match with. */
    pattern: string;
}
/** Parameters to be used for the commit_message_pattern rule */
export interface RepositoryRuleCommitMessagePattern {
    type: RepositoryRuleCommitMessagePatternType;
    parameters?: RepositoryRuleCommitMessagePatternParameters | undefined;
}
export type RepositoryRuleCommitAuthorEmailPatternType = "commit_author_email_pattern";
/** The operator to use for matching. */
export type RepositoryRuleCommitAuthorEmailPatternParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleCommitAuthorEmailPatternParameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleCommitAuthorEmailPatternParametersOperator | (string & {});
    /** The pattern to match with. */
    pattern: string;
}
/** Parameters to be used for the commit_author_email_pattern rule */
export interface RepositoryRuleCommitAuthorEmailPattern {
    type: RepositoryRuleCommitAuthorEmailPatternType;
    parameters?: RepositoryRuleCommitAuthorEmailPatternParameters | undefined;
}
export type RepositoryRuleCommitterEmailPatternType = "committer_email_pattern";
/** The operator to use for matching. */
export type RepositoryRuleCommitterEmailPatternParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleCommitterEmailPatternParameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleCommitterEmailPatternParametersOperator | (string & {});
    /** The pattern to match with. */
    pattern: string;
}
/** Parameters to be used for the committer_email_pattern rule */
export interface RepositoryRuleCommitterEmailPattern {
    type: RepositoryRuleCommitterEmailPatternType;
    parameters?: RepositoryRuleCommitterEmailPatternParameters | undefined;
}
export type RepositoryRuleBranchNamePatternType = "branch_name_pattern";
/** The operator to use for matching. */
export type RepositoryRuleBranchNamePatternParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleBranchNamePatternParameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleBranchNamePatternParametersOperator | (string & {});
    /** The pattern to match with. */
    pattern: string;
}
/** Parameters to be used for the branch_name_pattern rule */
export interface RepositoryRuleBranchNamePattern {
    type: RepositoryRuleBranchNamePatternType;
    parameters?: RepositoryRuleBranchNamePatternParameters | undefined;
}
export type RepositoryRuleTagNamePatternType = "tag_name_pattern";
/** The operator to use for matching. */
export type RepositoryRuleTagNamePatternParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleTagNamePatternParameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleTagNamePatternParametersOperator | (string & {});
    /** The pattern to match with. */
    pattern: string;
}
/** Parameters to be used for the tag_name_pattern rule */
export interface RepositoryRuleTagNamePattern {
    type: RepositoryRuleTagNamePatternType;
    parameters?: RepositoryRuleTagNamePatternParameters | undefined;
}
export type RepositoryRuleFilePathRestrictionType = "file_path_restriction";
/** Files matching these patterns are allowed even when they also match a restricted path. */
export type RepositoryRuleFilePathRestrictionParametersIgnoredFilePathsList = Array<string>;
/** The file paths that are restricted from being pushed to the commit graph. */
export type RepositoryRuleFilePathRestrictionParametersRestrictedFilePathsList = Array<string>;
export interface RepositoryRuleFilePathRestrictionParameters {
    /** Files matching these patterns are allowed even when they also match a restricted path. */
    ignored_file_paths?: RepositoryRuleFilePathRestrictionParametersIgnoredFilePathsList | undefined;
    /** The file paths that are restricted from being pushed to the commit graph. */
    restricted_file_paths: RepositoryRuleFilePathRestrictionParametersRestrictedFilePathsList;
}
/** Prevent commits that include changes in specified file and folder paths from being pushed to the commit graph. This includes absolute paths that contain file names. */
export interface RepositoryRuleFilePathRestriction {
    type: RepositoryRuleFilePathRestrictionType;
    parameters?: RepositoryRuleFilePathRestrictionParameters | undefined;
}
export type RepositoryRuleMaxFilePathLengthType = "max_file_path_length";
export interface RepositoryRuleMaxFilePathLengthParameters {
    /** The maximum amount of characters allowed in file paths. */
    max_file_path_length: number;
}
/** Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph. */
export interface RepositoryRuleMaxFilePathLength {
    type: RepositoryRuleMaxFilePathLengthType;
    parameters?: RepositoryRuleMaxFilePathLengthParameters | undefined;
}
export type RepositoryRuleFileExtensionRestrictionType = "file_extension_restriction";
/** The file extensions that are restricted from being pushed to the commit graph. */
export type RepositoryRuleFileExtensionRestrictionParametersRestrictedFileExtensionsList = Array<string>;
export interface RepositoryRuleFileExtensionRestrictionParameters {
    /** The file extensions that are restricted from being pushed to the commit graph. */
    restricted_file_extensions: RepositoryRuleFileExtensionRestrictionParametersRestrictedFileExtensionsList;
}
/** Prevent commits that include files with specified file extensions from being pushed to the commit graph. */
export interface RepositoryRuleFileExtensionRestriction {
    type: RepositoryRuleFileExtensionRestrictionType;
    parameters?: RepositoryRuleFileExtensionRestrictionParameters | undefined;
}
export type RepositoryRuleMaxFileSizeType = "max_file_size";
/** Files matching these patterns may exceed the maximum size. */
export type RepositoryRuleMaxFileSizeParametersIgnoredFilePathsList = Array<string>;
export interface RepositoryRuleMaxFileSizeParameters {
    /** Files matching these patterns may exceed the maximum size. */
    ignored_file_paths?: RepositoryRuleMaxFileSizeParametersIgnoredFilePathsList | undefined;
    /** The maximum file size allowed in megabytes. This limit does not apply to Git Large File Storage (Git LFS). */
    max_file_size: number;
}
/** Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph. */
export interface RepositoryRuleMaxFileSize {
    type: RepositoryRuleMaxFileSizeType;
    parameters?: RepositoryRuleMaxFileSizeParameters | undefined;
}
export type RepositoryRuleWorkflowsType = "workflows";
/** A workflow that must run for this rule to pass */
export interface RepositoryRuleParamsWorkflowFileReference {
    /** The path to the workflow file */
    path: string;
    /** The ref (branch or tag) of the workflow file to use */
    ref?: string | undefined;
    /** The ID of the repository where the workflow is defined */
    repository_id: number;
    /** The commit SHA of the workflow file to use */
    sha?: string | undefined;
}
/** Workflows that must pass for this rule to pass. */
export type RepositoryRuleWorkflowsParametersWorkflowsList = Array<RepositoryRuleParamsWorkflowFileReference>;
export interface RepositoryRuleWorkflowsParameters {
    /** Allow repositories and branches to be created if a check would otherwise prohibit it. */
    do_not_enforce_on_create?: boolean | undefined;
    /** Workflows that must pass for this rule to pass. */
    workflows: RepositoryRuleWorkflowsParametersWorkflowsList;
}
/** Require all changes made to a targeted branch to pass the specified workflows before they can be merged. */
export interface RepositoryRuleWorkflows {
    type: RepositoryRuleWorkflowsType;
    parameters?: RepositoryRuleWorkflowsParameters | undefined;
}
export type RepositoryRuleCodeScanningType = "code_scanning";
/** The severity level at which code scanning results that raise alerts block a reference update. For more information on alert severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." */
export type RepositoryRuleParamsCodeScanningToolAlertsThreshold = "none" | "errors" | "errors_and_warnings" | "all";
/** The severity level at which code scanning results that raise security alerts block a reference update. For more information on security severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." */
export type RepositoryRuleParamsCodeScanningToolSecurityAlertsThreshold = "none" | "critical" | "high_or_higher" | "medium_or_higher" | "all";
/** A tool that must provide code scanning results for this rule to pass. */
export interface RepositoryRuleParamsCodeScanningTool {
    /** The severity level at which code scanning results that raise alerts block a reference update. For more information on alert severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." */
    alerts_threshold: RepositoryRuleParamsCodeScanningToolAlertsThreshold | (string & {});
    /** The severity level at which code scanning results that raise security alerts block a reference update. For more information on security severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." */
    security_alerts_threshold: RepositoryRuleParamsCodeScanningToolSecurityAlertsThreshold | (string & {});
    /** The name of a code scanning tool */
    tool: string;
}
/** Tools that must provide code scanning results for this rule to pass. */
export type RepositoryRuleCodeScanningParametersCodeScanningToolsList = Array<RepositoryRuleParamsCodeScanningTool>;
export interface RepositoryRuleCodeScanningParameters {
    /** Tools that must provide code scanning results for this rule to pass. */
    code_scanning_tools: RepositoryRuleCodeScanningParametersCodeScanningToolsList;
}
/** Choose which tools must provide code scanning results before the reference is updated. When configured, code scanning must be enabled and have results for both the commit and the reference being updated. */
export interface RepositoryRuleCodeScanning {
    type: RepositoryRuleCodeScanningType;
    parameters?: RepositoryRuleCodeScanningParameters | undefined;
}
export type RepositoryRuleCopilotCodeReviewType = "copilot_code_review";
export interface RepositoryRuleCopilotCodeReviewParameters {
    /** Copilot automatically reviews draft pull requests before they are marked as ready for review. */
    review_draft_pull_requests?: boolean | undefined;
    /** Copilot automatically reviews each new push to the pull request. */
    review_on_push?: boolean | undefined;
}
/** Request Copilot code review for new pull requests automatically if the author has access to Copilot code review and AI credits. */
export interface RepositoryRuleCopilotCodeReview {
    type: RepositoryRuleCopilotCodeReviewType;
    parameters?: RepositoryRuleCopilotCodeReviewParameters | undefined;
}
/** A repository rule. */
export type OrgRules = RepositoryRuleCreation | RepositoryRuleUpdate | RepositoryRuleDeletion | RepositoryRuleRequiredLinearHistory | RepositoryRuleRequiredDeployments | RepositoryRuleRequiredSignatures | RepositoryRulePullRequest | RepositoryRuleRequiredStatusChecks | RepositoryRuleNonFastForward | RepositoryRuleCommitMessagePattern | RepositoryRuleCommitAuthorEmailPattern | RepositoryRuleCommitterEmailPattern | RepositoryRuleBranchNamePattern | RepositoryRuleTagNamePattern | RepositoryRuleFilePathRestriction | RepositoryRuleMaxFilePathLength | RepositoryRuleFileExtensionRestriction | RepositoryRuleMaxFileSize | RepositoryRuleWorkflows | RepositoryRuleCodeScanning | RepositoryRuleCopilotCodeReview;
/** An array of rules within the ruleset. */
export type CreateOrgRulesetRequestRulesList = Array<OrgRules>;
export interface CreateOrgRulesetRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the ruleset. */
    name: string;
    /** The target of the ruleset */
    target?: CreateOrgRulesetRequestTarget | (string & {}) | undefined;
    enforcement: RepositoryRuleEnforcement | (string & {});
    /** The actors that can bypass the rules in this ruleset */
    bypass_actors?: CreateOrgRulesetRequestBypassActorsList | undefined;
    conditions?: OrgRulesetConditions | undefined;
    /** An array of rules within the ruleset. */
    rules?: CreateOrgRulesetRequestRulesList | undefined;
}
/** The target of the ruleset */
export type RepositoryRulesetTarget = "branch" | "tag" | "push" | "repository";
/** The type of the source of the ruleset */
export type RepositoryRulesetSourceType = "Repository" | "Organization" | "Enterprise";
/** The actors that can bypass the rules in this ruleset */
export type RepositoryRulesetBypassActorsList = Array<RepositoryRulesetBypassActor>;
/** The bypass type of the user making the API request for this ruleset. This field is only returned when querying the repository-level endpoint. */
export type RepositoryRulesetCurrentUserCanBypass = "always" | "pull_requests_only" | "never" | "exempt";
export interface RepositoryRulesetLinksSelf {
    /** The URL of the ruleset */
    href?: string | undefined;
}
export interface RepositoryRulesetLinksHtml {
    /** The html URL of the ruleset */
    href?: string | undefined;
}
export interface RepositoryRulesetLinks {
    self?: RepositoryRulesetLinksSelf | undefined;
    html?: RepositoryRulesetLinksHtml | null | undefined;
}
/** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
export type RepositoryRulesetConditionsRefNameIncludeList = Array<string>;
/** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
export type RepositoryRulesetConditionsRefNameExcludeList = Array<string>;
export interface RepositoryRulesetConditionsRefName {
    /** Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches. */
    include?: RepositoryRulesetConditionsRefNameIncludeList | undefined;
    /** Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match. */
    exclude?: RepositoryRulesetConditionsRefNameExcludeList | undefined;
}
/** Parameters for a repository ruleset ref name condition */
export interface RepositoryRulesetConditions {
    ref_name?: RepositoryRulesetConditionsRefName | undefined;
}
export type RepositoryRulesetConditions2 = RepositoryRulesetConditions | OrgRulesetConditions;
export type RepositoryRuleMergeQueueType = "merge_queue";
/** When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. */
export type RepositoryRuleMergeQueueParametersGroupingStrategy = "ALLGREEN" | "HEADGREEN";
/** Method to use when merging changes from queued pull requests. */
export type RepositoryRuleMergeQueueParametersMergeMethod = "MERGE" | "SQUASH" | "REBASE";
export interface RepositoryRuleMergeQueueParameters {
    /** Maximum time for a required status check to report a conclusion. After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed */
    check_response_timeout_minutes: number;
    /** When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. */
    grouping_strategy: RepositoryRuleMergeQueueParametersGroupingStrategy | (string & {});
    /** Limit the number of queued pull requests requesting checks and workflow runs at the same time. */
    max_entries_to_build: number;
    /** The maximum number of PRs that will be merged together in a group. */
    max_entries_to_merge: number;
    /** Method to use when merging changes from queued pull requests. */
    merge_method: RepositoryRuleMergeQueueParametersMergeMethod | (string & {});
    /** The minimum number of PRs that will be merged together in a group. */
    min_entries_to_merge: number;
    /** The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met. After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged. */
    min_entries_to_merge_wait_minutes: number;
}
/** Merges must be performed via a merge queue. */
export interface RepositoryRuleMergeQueue {
    type: RepositoryRuleMergeQueueType;
    parameters?: RepositoryRuleMergeQueueParameters | undefined;
}
export type RepositoryRuleCodeQualityType = "code_quality";
/** The lowest severity level at which code quality reviews need to be resolved before commits can be merged. */
export type RepositoryRuleCodeQualityParametersSeverity = "errors" | "warnings" | "notes" | "all";
export interface RepositoryRuleCodeQualityParameters {
    /** The lowest severity level at which code quality reviews need to be resolved before commits can be merged. */
    severity: RepositoryRuleCodeQualityParametersSeverity | (string & {});
}
/** Choose which severity levels of code quality results should block pull request merges. When configured, a code quality analysis must be done on the pull request before the changes can be merged. */
export interface RepositoryRuleCodeQuality {
    type: RepositoryRuleCodeQualityType;
    parameters?: RepositoryRuleCodeQualityParameters | undefined;
}
export type RepositoryRuleCodeCoverageType = "code_coverage";
export interface RepositoryRuleCodeCoverageParameters {
    /** The maximum percentage points that line coverage may drop relative to the default branch. Pull requests that reduce line coverage by more than this amount will be blocked. */
    max_coverage_drop?: number | undefined;
    /** The absolute minimum line coverage percentage required. Pull requests with line coverage below this threshold will be blocked. */
    minimum_coverage?: number | undefined;
}
/** Enforce minimum line coverage thresholds on pull requests. This rule evaluates uploaded coverage data but does not wait for coverage uploads. To ensure coverage is evaluated before merging, make each status check associated with a coverage upload a required status check. */
export interface RepositoryRuleCodeCoverage {
    type: RepositoryRuleCodeCoverageType;
    parameters?: RepositoryRuleCodeCoverageParameters | undefined;
}
export type RepositoryRuleLicenseComplianceScanningType = "license_compliance_scanning";
/** Enforce any added or changed dependencies to comply with the organization's license policy. */
export interface RepositoryRuleLicenseComplianceScanning {
    type: RepositoryRuleLicenseComplianceScanningType;
}
/** A repository rule. */
export type RepositoryRule = RepositoryRuleCreation | RepositoryRuleUpdate | RepositoryRuleDeletion | RepositoryRuleRequiredLinearHistory | RepositoryRuleMergeQueue | RepositoryRuleRequiredDeployments | RepositoryRuleRequiredSignatures | RepositoryRulePullRequest | RepositoryRuleRequiredStatusChecks | RepositoryRuleNonFastForward | RepositoryRuleCommitMessagePattern | RepositoryRuleCommitAuthorEmailPattern | RepositoryRuleCommitterEmailPattern | RepositoryRuleBranchNamePattern | RepositoryRuleTagNamePattern | RepositoryRuleWorkflows | RepositoryRuleCodeScanning | RepositoryRuleCodeQuality | RepositoryRuleCodeCoverage | RepositoryRuleCopilotCodeReview | RepositoryRuleLicenseComplianceScanning | RepositoryRuleFilePathRestriction | RepositoryRuleMaxFilePathLength | RepositoryRuleFileExtensionRestriction | RepositoryRuleMaxFileSize;
export type RepositoryRulesetRulesList = Array<RepositoryRule>;
/** A set of rules to apply when specified conditions are met. */
export interface RepositoryRuleset {
    /** The ID of the ruleset */
    id: number;
    /** The name of the ruleset */
    name: string;
    /** The target of the ruleset */
    target?: RepositoryRulesetTarget | undefined;
    /** The type of the source of the ruleset */
    source_type?: RepositoryRulesetSourceType | undefined;
    /** The name of the source */
    source: string;
    enforcement: RepositoryRuleEnforcement;
    /** The actors that can bypass the rules in this ruleset */
    bypass_actors?: RepositoryRulesetBypassActorsList | undefined;
    /** The bypass type of the user making the API request for this ruleset. This field is only returned when querying the repository-level endpoint. */
    current_user_can_bypass?: RepositoryRulesetCurrentUserCanBypass | undefined;
    node_id?: string | undefined;
    _links?: RepositoryRulesetLinks | undefined;
    conditions?: RepositoryRulesetConditions2 | null | undefined;
    rules?: RepositoryRulesetRulesList | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
}
/** The type of reviewer. */
export type DeploymentReviewerType = "User" | "Team";
export interface CreateOrUpdateEnvironmentRequestReviewersItem {
    type?: DeploymentReviewerType | (string & {}) | undefined;
    /** The id of the user or team who can review the deployment */
    id?: number | undefined;
}
/** The people or teams that may review jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed. */
export type CreateOrUpdateEnvironmentRequestReviewersList = Array<CreateOrUpdateEnvironmentRequestReviewersItem>;
/** The type of deployment branch policy for this environment. To allow all branches to deploy, set to `null`. */
export interface DeploymentBranchPolicySettings {
    /** Whether only branches with branch protection rules can deploy to this environment. If `protected_branches` is `true`, `custom_branch_policies` must be `false`; if `protected_branches` is `false`, `custom_branch_policies` must be `true`. */
    protected_branches: boolean;
    /** Whether only branches that match the specified name patterns can deploy to this environment. If `custom_branch_policies` is `true`, `protected_branches` must be `false`; if `custom_branch_policies` is `false`, `protected_branches` must be `true`. */
    custom_branch_policies: boolean;
}
export interface CreateOrUpdateEnvironmentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    wait_timer?: number | undefined;
    prevent_self_review?: boolean | undefined;
    /** The people or teams that may review jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed. */
    reviewers?: CreateOrUpdateEnvironmentRequestReviewersList | null | undefined;
    deployment_branch_policy?: DeploymentBranchPolicySettings | null | undefined;
}
export interface EnvironmentProtectionRulesItemCase0 {
    id: number;
    node_id: string;
    type: string;
    wait_timer?: number | undefined;
}
export type EnvironmentProtectionRulesItemCase1ReviewersItemReviewer = SimpleUser | Team;
export interface EnvironmentProtectionRulesItemCase1ReviewersItem {
    type?: DeploymentReviewerType | undefined;
    reviewer?: EnvironmentProtectionRulesItemCase1ReviewersItemReviewer | undefined;
}
/** The people or teams that may approve jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed. */
export type EnvironmentProtectionRulesItemCase1ReviewersList = Array<EnvironmentProtectionRulesItemCase1ReviewersItem>;
export interface EnvironmentProtectionRulesItemCase1 {
    id: number;
    node_id: string;
    /** Whether deployments to this environment can be approved by the user who created the deployment. */
    prevent_self_review?: boolean | undefined;
    type: string;
    /** The people or teams that may approve jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed. */
    reviewers?: EnvironmentProtectionRulesItemCase1ReviewersList | undefined;
}
export interface EnvironmentProtectionRulesItemCase2 {
    id: number;
    node_id: string;
    type: string;
}
export type EnvironmentProtectionRulesItem = EnvironmentProtectionRulesItemCase0 | EnvironmentProtectionRulesItemCase1 | EnvironmentProtectionRulesItemCase2;
/** Built-in deployment protection rules for the environment. */
export type EnvironmentProtectionRulesList = Array<EnvironmentProtectionRulesItem>;
/** Details of a deployment environment */
export interface Environment {
    /** The id of the environment. */
    id: number;
    node_id: string;
    /** The name of the environment. */
    name: string;
    url: string;
    html_url: string;
    /** The time that the environment was created, in ISO 8601 format. */
    created_at: string;
    /** The time that the environment was last updated, in ISO 8601 format. */
    updated_at: string;
    /** Built-in deployment protection rules for the environment. */
    protection_rules?: EnvironmentProtectionRulesList | undefined;
    deployment_branch_policy?: DeploymentBranchPolicySettings | null | undefined;
}
/** The person that committed the file. Default: the authenticated user. */
export interface CreateOrUpdateFileContentsRequestCommitter {
    /** The name of the author or committer of the commit. You'll receive a `422` status code if `name` is omitted. */
    name: string;
    /** The email of the author or committer of the commit. You'll receive a `422` status code if `email` is omitted. */
    email: string;
    date?: string | undefined;
}
/** The author of the file. Default: The `committer` or the authenticated user if you omit `committer`. */
export type CreateOrUpdateFileContentsRequestAuthor = CreateOrUpdateFileContentsRequestCommitter;
export interface CreateOrUpdateFileContentsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** path parameter */
    path: string;
    /** The commit message. */
    message: string;
    /** The new file content, using Base64 encoding. */
    content: string;
    /** **Required if you are updating a file**. The blob SHA of the file being replaced. */
    sha?: string | undefined;
    /** The branch name. Default: the repository's default branch. */
    branch?: string | undefined;
    /** The person that committed the file. Default: the authenticated user. */
    committer?: CreateOrUpdateFileContentsRequestCommitter | undefined;
    /** The author of the file. Default: The `committer` or the authenticated user if you omit `committer`. */
    author?: CreateOrUpdateFileContentsRequestCommitter | undefined;
}
export interface FileCommitContentLinks {
    self?: string | undefined;
    git?: string | undefined;
    html?: string | undefined;
}
export interface FileCommitContent {
    name?: string | undefined;
    path?: string | undefined;
    sha?: string | undefined;
    size?: number | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    git_url?: string | undefined;
    download_url?: string | undefined;
    type?: string | undefined;
    _links?: FileCommitContentLinks | undefined;
}
export interface FileCommitCommitAuthor {
    date?: string | undefined;
    name?: string | undefined;
    email?: string | undefined;
}
export type FileCommitCommitCommitter = FileCommitCommitAuthor;
export interface FileCommitCommitTree {
    url?: string | undefined;
    sha?: string | undefined;
}
export interface FileCommitCommitParentsItem {
    url?: string | undefined;
    html_url?: string | undefined;
    sha?: string | undefined;
}
export type FileCommitCommitParentsList = Array<FileCommitCommitParentsItem>;
export interface FileCommitCommitVerification {
    verified?: boolean | undefined;
    reason?: string | undefined;
    signature?: string | null | undefined;
    payload?: string | null | undefined;
    verified_at?: string | null | undefined;
}
export interface FileCommitCommit {
    sha?: string | undefined;
    node_id?: string | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    author?: FileCommitCommitAuthor | undefined;
    committer?: FileCommitCommitAuthor | undefined;
    message?: string | undefined;
    tree?: FileCommitCommitTree | undefined;
    parents?: FileCommitCommitParentsList | undefined;
    verification?: FileCommitCommitVerification | undefined;
}
/** File Commit */
export interface FileCommit {
    content: FileCommitContent | null;
    commit: FileCommitCommit;
}
export interface CreatePagesDeploymentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of an artifact that contains the .zip or .tar of static assets to deploy. The artifact belongs to the repository. Either `artifact_id` or `artifact_url` are required. */
    artifact_id?: number | undefined;
    /** The URL of an artifact that contains the .zip or .tar of static assets to deploy. The artifact belongs to the repository. Either `artifact_id` or `artifact_url` are required. */
    artifact_url?: string | undefined;
    /** The target environment for this GitHub Pages deployment. */
    environment?: string | undefined;
    /** A unique string that represents the version of the build for this deployment. */
    pages_build_version: string;
    /** The OIDC token issued by GitHub Actions certifying the origin of the deployment. */
    oidc_token: string;
}
/** The ID of the GitHub Pages deployment. This is the Git SHA of the deployed commit. */
export type PageDeploymentId = number | string;
/** The GitHub Pages deployment status. */
export interface PageDeployment {
    /** The ID of the GitHub Pages deployment. This is the Git SHA of the deployed commit. */
    id: PageDeploymentId;
    /** The URI to monitor GitHub Pages deployment status. */
    status_url: string;
    /** The URI to the deployed GitHub Pages. */
    page_url: string;
    /** The URI to the deployed GitHub Pages preview. */
    preview_url?: string | undefined;
}
/** The process in which the Page will be built. Possible values are `"legacy"` and `"workflow"`. */
export type CreatePagesSiteRequestBuildType = "legacy" | "workflow";
/** The repository directory that includes the source files for the Pages site. Allowed paths are `/` or `/docs`. Default: `/` */
export type CreatePagesSiteRequestSourcePath = "/" | "/docs";
/** The source branch and directory used to publish your Pages site. */
export interface CreatePagesSiteRequestSource {
    /** The repository branch used to publish your site's source files. */
    branch: string;
    /** The repository directory that includes the source files for the Pages site. Allowed paths are `/` or `/docs`. Default: `/` */
    path?: CreatePagesSiteRequestSourcePath | (string & {}) | undefined;
}
export interface CreatePagesSiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The process in which the Page will be built. Possible values are `"legacy"` and `"workflow"`. */
    build_type?: CreatePagesSiteRequestBuildType | (string & {}) | undefined;
    /** The source branch and directory used to publish your Pages site. */
    source?: CreatePagesSiteRequestSource | undefined;
}
/** The status of the most recent build of the Page. */
export type PageStatus = "built" | "building" | "errored";
/** The state if the domain is verified */
export type PageProtectedDomainState = "pending" | "verified" | "unverified";
/** The process in which the Page will be built. */
export type PageBuildType = "legacy" | "workflow";
export interface PagesSourceHash {
    branch: string;
    path: string;
}
export type PagesHttpsCertificateState = "new" | "authorization_created" | "authorization_pending" | "authorized" | "authorization_revoked" | "issued" | "uploaded" | "approved" | "errored" | "bad_authz" | "destroy_pending" | "dns_changed";
/** Array of the domain set and its alternate name (if it is configured) */
export type PagesHttpsCertificateDomainsList = Array<string>;
export interface PagesHttpsCertificate {
    state: PagesHttpsCertificateState;
    description: string;
    /** Array of the domain set and its alternate name (if it is configured) */
    domains: PagesHttpsCertificateDomainsList;
    expires_at?: string | undefined;
}
/** The configuration for GitHub Pages for a repository. */
export interface Page {
    /** The API address for accessing this Page resource. */
    url: string;
    /** The status of the most recent build of the Page. */
    status: PageStatus | null;
    /** The Pages site's custom domain */
    cname: string | null;
    /** The state if the domain is verified */
    protected_domain_state?: PageProtectedDomainState | null | undefined;
    /** The timestamp when a pending domain becomes unverified. */
    pending_domain_unverified_at?: string | null | undefined;
    /** Whether the Page has a custom 404 page. */
    custom_404: boolean;
    /** The web address the Page can be accessed from. */
    html_url?: string | undefined;
    /** The process in which the Page will be built. */
    build_type?: PageBuildType | null | undefined;
    source?: PagesSourceHash | undefined;
    /** Whether the GitHub Pages site is publicly visible. If set to `true`, the site is accessible to anyone on the internet. If set to `false`, the site will only be accessible to users who have at least `read` access to the repository that published the site. */
    public: boolean;
    https_certificate?: PagesHttpsCertificate | undefined;
    /** Whether https is enabled on the domain */
    https_enforced?: boolean | undefined;
}
/** Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. */
export type CreateReleaseRequestMakeLatest = "true" | "false" | "legacy";
export interface CreateReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the tag. */
    tag_name: string;
    /** Specifies the commitish value that determines where the Git tag is created from. Can be any branch or commit SHA. Unused if the Git tag already exists. Default: the repository's default branch. */
    target_commitish?: string | undefined;
    /** The name of the release. */
    name?: string | undefined;
    /** Text describing the contents of the tag. */
    body?: string | undefined;
    /** `true` to create a draft (unpublished) release, `false` to create a published one. */
    draft?: boolean | undefined;
    /** `true` to identify the release as a prerelease. `false` to identify the release as a full release. */
    prerelease?: boolean | undefined;
    /** If specified, a discussion of the specified category is created and linked to the release. The value must be a category that already exists in the repository. For more information, see "[Managing categories for discussions in your repository](https://docs.github.com/discussions/managing-discussions-for-your-community/managing-categories-for-discussions-in-your-repository)." */
    discussion_category_name?: string | undefined;
    /** Whether to automatically generate the name and body for this release. If `name` is specified, the specified name will be used; otherwise, a name will be automatically generated. If `body` is specified, the body will be pre-pended to the automatically generated notes. */
    generate_release_notes?: boolean | undefined;
    /** Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. */
    make_latest?: CreateReleaseRequestMakeLatest | (string & {}) | undefined;
}
/** State of the release asset. */
export type ReleaseAssetState = "uploaded" | "open";
/** Data related to a release. */
export interface ReleaseAsset {
    url: string;
    browser_download_url: string;
    id: number;
    node_id: string;
    /** The file name of the asset. */
    name: string;
    label: string | null;
    /** State of the release asset. */
    state: ReleaseAssetState;
    content_type: string;
    size: number;
    digest: string | null;
    download_count: number;
    created_at: string;
    updated_at: string;
    uploader: SimpleUser | null;
}
export type ReleaseAssetsList = Array<ReleaseAsset>;
/** A release. */
export interface Release {
    url: string;
    html_url: string;
    assets_url: string;
    upload_url: string;
    tarball_url: string | null;
    zipball_url: string | null;
    id: number;
    node_id: string;
    /** The name of the tag. */
    tag_name: string;
    /** Specifies the commitish value that determines where the Git tag is created from. */
    target_commitish: string;
    name: string | null;
    body?: string | null | undefined;
    /** true to create a draft (unpublished) release, false to create a published one. */
    draft: boolean;
    /** Whether to identify the release as a prerelease or a full release. */
    prerelease: boolean;
    /** Whether or not the release is immutable. */
    immutable?: boolean | undefined;
    created_at: string;
    published_at: string | null;
    updated_at?: string | null | undefined;
    author: SimpleUser;
    assets: ReleaseAssetsList;
    body_html?: string | undefined;
    body_text?: string | undefined;
    mentions_count?: number | undefined;
    /** The URL of the release discussion. */
    discussion_url?: string | undefined;
    reactions?: ReactionRollup | undefined;
}
/** The target of the ruleset */
export type CreateRepoRulesetRequestTarget = "branch" | "tag" | "push";
/** The actors that can bypass the rules in this ruleset */
export type CreateRepoRulesetRequestBypassActorsList = Array<RepositoryRulesetBypassActor>;
/** An array of rules within the ruleset. */
export type CreateRepoRulesetRequestRulesList = Array<RepositoryRule>;
export interface CreateRepoRulesetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the ruleset. */
    name: string;
    /** The target of the ruleset */
    target?: CreateRepoRulesetRequestTarget | (string & {}) | undefined;
    enforcement: RepositoryRuleEnforcement | (string & {});
    /** The actors that can bypass the rules in this ruleset */
    bypass_actors?: CreateRepoRulesetRequestBypassActorsList | undefined;
    conditions?: RepositoryRulesetConditions | undefined;
    /** An array of rules within the ruleset. */
    rules?: CreateRepoRulesetRequestRulesList | undefined;
}
export interface CreateUsingTemplateRequest {
    /** The account owner of the template repository. The name is not case sensitive. */
    template_owner: string;
    /** The name of the template repository without the `.git` extension. The name is not case sensitive. */
    template_repo: string;
    /** The organization or person who will own the new repository. To create a new repository in an organization, the authenticated user must be a member of the specified organization. */
    owner?: string | undefined;
    /** The name of the new repository. */
    name: string;
    /** A short description of the new repository. */
    description?: string | undefined;
    /** Set to `true` to include the directory structure and files from all branches in the template repository, and not just the default branch. Default: `false`. */
    include_all_branches?: boolean | undefined;
    /** Either `true` to create a new private repository or `false` to create a new public one. */
    private?: boolean | undefined;
}
export type WebhookConfigInsecureSsl = string | number;
/** Key/value pairs to provide settings for this webhook. */
export interface CreateWebhookRequestConfig {
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
/** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. */
export type CreateWebhookRequestEventsList = Array<string>;
export interface CreateWebhookRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Use `web` to create a webhook. Default: `web`. This parameter only accepts the value `web`. */
    name?: string | undefined;
    /** Key/value pairs to provide settings for this webhook. */
    config?: CreateWebhookRequestConfig | undefined;
    /** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. */
    events?: CreateWebhookRequestEventsList | undefined;
    /** Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. */
    active?: boolean | undefined;
}
/** Determines what events the hook is triggered for. Default: ['push']. */
export type HookEventsList = Array<string>;
/** Configuration object of the webhook */
export interface WebhookConfig {
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
export interface HookResponse {
    code: number | null;
    status: string | null;
    message: string | null;
}
/** Webhooks for repositories. */
export interface Hook {
    type: string;
    /** Unique identifier of the webhook. */
    id: number;
    /** The name of a valid service, use 'web' for a webhook. */
    name: string;
    /** Determines whether the hook is actually triggered on pushes. */
    active: boolean;
    /** Determines what events the hook is triggered for. Default: ['push']. */
    events: HookEventsList;
    config: WebhookConfig;
    updated_at: string;
    created_at: string;
    url: string;
    test_url: string;
    ping_url: string;
    deliveries_url?: string | undefined;
    last_response: HookResponse;
}
export type CustomPropertyValueValueCase1List = Array<string>;
/** The value assigned to the property */
export type CustomPropertyValueValue = string | CustomPropertyValueValueCase1List;
/** Custom property name and associated value */
export interface CustomPropertyValue {
    /** The name of the property */
    property_name: string;
    /** The value assigned to the property */
    value: CustomPropertyValueValue | null;
}
/** A list of custom property names and associated values to apply to the repositories. */
export type CustomPropertiesForReposCreateOrUpdateRepositoryValuesRequestPropertiesList = Array<CustomPropertyValue>;
export interface CustomPropertiesForReposCreateOrUpdateRepositoryValuesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** A list of custom property names and associated values to apply to the repositories. */
    properties: CustomPropertiesForReposCreateOrUpdateRepositoryValuesRequestPropertiesList;
}
export interface CustomPropertiesForReposCreateOrUpdateRepositoryValuesResponse {
}
export interface CustomPropertiesForReposGetRepositoryValuesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type CustomPropertiesForReposGetRepositoryValuesResponseBodyList = Array<CustomPropertyValue>;
export type CustomPropertiesForReposGetRepositoryValuesResponse = CustomPropertiesForReposGetRepositoryValuesResponseBodyList;
export interface DeclineInvitationForAuthenticatedUserRequest {
    /** The unique identifier of the invitation. */
    invitation_id: number;
}
export interface DeclineInvitationForAuthenticatedUserResponse {
}
export interface DeleteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DeleteResponse {
}
export interface DeleteAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface DeleteAccessRestrictionsResponse {
}
export interface DeleteAdminBranchProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface DeleteAdminBranchProtectionResponse {
}
export interface DeleteAnEnvironmentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
}
export interface DeleteAnEnvironmentResponse {
}
export interface DeleteAutolinkRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the autolink. */
    autolink_id: number;
}
export interface DeleteAutolinkResponse {
}
export interface DeleteBranchProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface DeleteBranchProtectionResponse {
}
export interface DeleteCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface DeleteCommitCommentResponse {
}
export interface DeleteCommitSignatureProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface DeleteCommitSignatureProtectionResponse {
}
export interface DeleteDeployKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the key. */
    key_id: number;
}
export interface DeleteDeployKeyResponse {
}
export interface DeleteDeploymentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** deployment_id parameter */
    deployment_id: number;
}
export interface DeleteDeploymentResponse {
}
export interface DeleteDeploymentBranchPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The unique identifier of the branch policy. */
    branch_policy_id: number;
}
export interface DeleteDeploymentBranchPolicyResponse {
}
/** object containing information about the committer. */
export interface DeleteFileRequestCommitter {
    /** The name of the author (or committer) of the commit */
    name?: string | undefined;
    /** The email of the author (or committer) of the commit */
    email?: string | undefined;
}
/** object containing information about the author. */
export type DeleteFileRequestAuthor = DeleteFileRequestCommitter;
export interface DeleteFileRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** path parameter */
    path: string;
    /** The commit message. */
    message: string;
    /** The blob SHA of the file being deleted. */
    sha: string;
    /** The branch name. Default: the repository's default branch */
    branch?: string | undefined;
    /** object containing information about the committer. */
    committer?: DeleteFileRequestCommitter | undefined;
    /** object containing information about the author. */
    author?: DeleteFileRequestCommitter | undefined;
}
export interface DeleteInvitationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the invitation. */
    invitation_id: number;
}
export interface DeleteInvitationResponse {
}
export interface DeleteOrgRulesetRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
}
export interface DeleteOrgRulesetResponse {
}
export interface DeletePagesSiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DeletePagesSiteResponse {
}
export interface DeletePullRequestReviewProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface DeletePullRequestReviewProtectionResponse {
}
export interface DeleteReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
}
export interface DeleteReleaseResponse {
}
export interface DeleteReleaseAssetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the asset. */
    asset_id: number;
}
export interface DeleteReleaseAssetResponse {
}
export interface DeleteRepoRulesetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
}
export interface DeleteRepoRulesetResponse {
}
export interface DeleteWebhookRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface DeleteWebhookResponse {
}
export interface DisableAutomatedSecurityFixesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DisableAutomatedSecurityFixesResponse {
}
export interface DisableDeploymentProtectionRuleRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The unique identifier of the protection rule. */
    protection_rule_id: number;
}
export interface DisableDeploymentProtectionRuleResponse {
}
export interface DisableImmutableReleasesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DisableImmutableReleasesResponse {
}
export interface DisablePrivateVulnerabilityReportingRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DisablePrivateVulnerabilityReportingResponse {
}
export interface DisableVulnerabilityAlertsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DisableVulnerabilityAlertsResponse {
}
export interface DownloadTarballArchiveRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    ref: string;
}
export interface DownloadTarballArchiveResponse {
}
export interface DownloadZipballArchiveRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    ref: string;
}
export interface DownloadZipballArchiveResponse {
}
export interface EnableAutomatedSecurityFixesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface EnableAutomatedSecurityFixesResponse {
}
export interface EnableImmutableReleasesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface EnableImmutableReleasesResponse {
}
export interface EnablePrivateVulnerabilityReportingRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface EnablePrivateVulnerabilityReportingResponse {
}
export interface EnableVulnerabilityAlertsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface EnableVulnerabilityAlertsResponse {
}
export interface GenerateReleaseNotesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The tag name for the release. This can be an existing tag or a new one. */
    tag_name: string;
    /** Specifies the commitish value that will be the target for the release's tag. Required if the supplied tag_name does not reference an existing tag. Ignored if the tag_name already exists. */
    target_commitish?: string | undefined;
    /** The name of the previous tag to use as the starting point for the release notes. Use to manually specify the range for the set of changes considered as part this release. */
    previous_tag_name?: string | undefined;
    /** Specifies a path to a file in the repository containing configuration settings used for generating the release notes. If unspecified, the configuration file located in the repository at '.github/release.yml' or '.github/release.yaml' will be used. If that is not present, the default configuration will be used. */
    configuration_file_path?: string | undefined;
}
/** Generated name and body describing a release */
export interface ReleaseNotesContent {
    /** The generated name of the release */
    name: string;
    /** The generated body describing the contents of the release supporting markdown formatting */
    body: string;
}
export interface GetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface BranchRestrictionPolicyUsersItem {
    login?: string | undefined;
    id?: number | undefined;
    node_id?: string | undefined;
    avatar_url?: string | undefined;
    gravatar_id?: string | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    followers_url?: string | undefined;
    following_url?: string | undefined;
    gists_url?: string | undefined;
    starred_url?: string | undefined;
    subscriptions_url?: string | undefined;
    organizations_url?: string | undefined;
    repos_url?: string | undefined;
    events_url?: string | undefined;
    received_events_url?: string | undefined;
    type?: string | undefined;
    site_admin?: boolean | undefined;
    user_view_type?: string | undefined;
}
export type BranchRestrictionPolicyUsersList = Array<BranchRestrictionPolicyUsersItem>;
export type BranchRestrictionPolicyTeamsList = Array<Team>;
export interface BranchRestrictionPolicyAppsItemOwner {
    login?: string | undefined;
    id?: number | undefined;
    node_id?: string | undefined;
    url?: string | undefined;
    repos_url?: string | undefined;
    events_url?: string | undefined;
    hooks_url?: string | undefined;
    issues_url?: string | undefined;
    members_url?: string | undefined;
    public_members_url?: string | undefined;
    avatar_url?: string | undefined;
    description?: string | undefined;
    gravatar_id?: string | undefined;
    html_url?: string | undefined;
    followers_url?: string | undefined;
    following_url?: string | undefined;
    gists_url?: string | undefined;
    starred_url?: string | undefined;
    subscriptions_url?: string | undefined;
    organizations_url?: string | undefined;
    received_events_url?: string | undefined;
    type?: string | undefined;
    site_admin?: boolean | undefined;
    user_view_type?: string | undefined;
}
export interface BranchRestrictionPolicyAppsItemPermissions {
    metadata?: string | undefined;
    contents?: string | undefined;
    issues?: string | undefined;
    single_file?: string | undefined;
}
export type BranchRestrictionPolicyAppsItemEventsList = Array<string>;
export interface BranchRestrictionPolicyAppsItem {
    id?: number | undefined;
    slug?: string | undefined;
    node_id?: string | undefined;
    owner?: BranchRestrictionPolicyAppsItemOwner | undefined;
    name?: string | undefined;
    client_id?: string | undefined;
    description?: string | undefined;
    external_url?: string | undefined;
    html_url?: string | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
    permissions?: BranchRestrictionPolicyAppsItemPermissions | undefined;
    events?: BranchRestrictionPolicyAppsItemEventsList | undefined;
}
export type BranchRestrictionPolicyAppsList = Array<BranchRestrictionPolicyAppsItem>;
/** Branch Restriction Policy */
export interface BranchRestrictionPolicy {
    url: string;
    users_url: string;
    teams_url: string;
    apps_url: string;
    users: BranchRestrictionPolicyUsersList;
    teams: BranchRestrictionPolicyTeamsList;
    apps: BranchRestrictionPolicyAppsList;
}
export interface GetAdminBranchProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface GetAllDeploymentProtectionRulesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
}
export type GetAllDeploymentProtectionRulesResponseCustomDeploymentProtectionRulesList = Array<DeploymentProtectionRule>;
export interface GetAllDeploymentProtectionRulesResponse {
    /** The number of enabled custom deployment protection rules for this environment */
    total_count?: number | undefined;
    custom_deployment_protection_rules?: GetAllDeploymentProtectionRulesResponseCustomDeploymentProtectionRulesList | undefined;
}
export interface GetAllEnvironmentsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type GetAllEnvironmentsResponseEnvironmentsList = Array<Environment>;
export interface GetAllEnvironmentsResponse {
    /** The number of environments in this repository */
    total_count?: number | undefined;
    environments: GetAllEnvironmentsResponseEnvironmentsList;
}
export interface GetAllStatusCheckContextsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export type GetAllStatusCheckContextsResponseBodyList = Array<string>;
export type GetAllStatusCheckContextsResponse = GetAllStatusCheckContextsResponseBodyList;
export interface GetAllTopicsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type TopicNamesList = Array<string>;
/** A topic aggregates entities that are related to a subject. */
export interface Topic {
    names: TopicNamesList;
}
export interface GetAppsWithAccessToProtectedBranchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export type GetAppsWithAccessToProtectedBranchResponseBodyList = Array<Integration | null>;
export type GetAppsWithAccessToProtectedBranchResponse = GetAppsWithAccessToProtectedBranchResponseBodyList;
export interface GetAutolinkRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the autolink. */
    autolink_id: number;
}
export interface GetBranchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface BranchWithProtectionLinks {
    html: string;
    self: string;
}
export type ProtectedBranchRequiredStatusCheckContextsList = Array<string>;
export interface ProtectedBranchRequiredStatusCheckChecksItem {
    context: string;
    app_id: number | null;
}
export type ProtectedBranchRequiredStatusCheckChecksList = Array<ProtectedBranchRequiredStatusCheckChecksItem>;
/** Protected Branch Required Status Check */
export interface ProtectedBranchRequiredStatusCheck {
    url?: string | undefined;
    enforcement_level?: string | undefined;
    contexts: ProtectedBranchRequiredStatusCheckContextsList;
    checks: ProtectedBranchRequiredStatusCheckChecksList;
    contexts_url?: string | undefined;
    strict?: boolean | undefined;
}
/** The list of users with review dismissal access. */
export type ProtectedBranchPullRequestReviewDismissalRestrictionsUsersList = Array<SimpleUser>;
/** The list of teams with review dismissal access. */
export type ProtectedBranchPullRequestReviewDismissalRestrictionsTeamsList = Array<Team>;
/** The list of apps with review dismissal access. */
export type ProtectedBranchPullRequestReviewDismissalRestrictionsAppsList = Array<Integration | null>;
export interface ProtectedBranchPullRequestReviewDismissalRestrictions {
    /** The list of users with review dismissal access. */
    users?: ProtectedBranchPullRequestReviewDismissalRestrictionsUsersList | undefined;
    /** The list of teams with review dismissal access. */
    teams?: ProtectedBranchPullRequestReviewDismissalRestrictionsTeamsList | undefined;
    /** The list of apps with review dismissal access. */
    apps?: ProtectedBranchPullRequestReviewDismissalRestrictionsAppsList | undefined;
    url?: string | undefined;
    users_url?: string | undefined;
    teams_url?: string | undefined;
}
/** The list of users allowed to bypass pull request requirements. */
export type ProtectedBranchPullRequestReviewBypassPullRequestAllowancesUsersList = Array<SimpleUser>;
/** The list of teams allowed to bypass pull request requirements. */
export type ProtectedBranchPullRequestReviewBypassPullRequestAllowancesTeamsList = Array<Team>;
/** The list of apps allowed to bypass pull request requirements. */
export type ProtectedBranchPullRequestReviewBypassPullRequestAllowancesAppsList = Array<Integration | null>;
/** Allow specific users, teams, or apps to bypass pull request requirements. */
export interface ProtectedBranchPullRequestReviewBypassPullRequestAllowances {
    /** The list of users allowed to bypass pull request requirements. */
    users?: ProtectedBranchPullRequestReviewBypassPullRequestAllowancesUsersList | undefined;
    /** The list of teams allowed to bypass pull request requirements. */
    teams?: ProtectedBranchPullRequestReviewBypassPullRequestAllowancesTeamsList | undefined;
    /** The list of apps allowed to bypass pull request requirements. */
    apps?: ProtectedBranchPullRequestReviewBypassPullRequestAllowancesAppsList | undefined;
}
/** Protected Branch Pull Request Review */
export interface ProtectedBranchPullRequestReview {
    url?: string | undefined;
    dismissal_restrictions?: ProtectedBranchPullRequestReviewDismissalRestrictions | undefined;
    /** Allow specific users, teams, or apps to bypass pull request requirements. */
    bypass_pull_request_allowances?: ProtectedBranchPullRequestReviewBypassPullRequestAllowances | undefined;
    dismiss_stale_reviews: boolean;
    require_code_owner_reviews: boolean;
    required_approving_review_count?: number | undefined;
    /** Whether the most recent push must be approved by someone other than the person who pushed it. */
    require_last_push_approval?: boolean | undefined;
}
export interface BranchProtectionRequiredLinearHistory {
    enabled?: boolean | undefined;
}
export type BranchProtectionAllowForcePushes = BranchProtectionRequiredLinearHistory;
export type BranchProtectionAllowDeletions = BranchProtectionRequiredLinearHistory;
export type BranchProtectionBlockCreations = BranchProtectionRequiredLinearHistory;
export type BranchProtectionRequiredConversationResolution = BranchProtectionRequiredLinearHistory;
export interface BranchProtectionRequiredSignatures {
    url: string;
    enabled: boolean;
}
/** Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. */
export type BranchProtectionLockBranch = BranchProtectionRequiredLinearHistory;
/** Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. */
export type BranchProtectionAllowForkSyncing = BranchProtectionRequiredLinearHistory;
/** Branch Protection */
export interface BranchProtection {
    url?: string | undefined;
    enabled?: boolean | undefined;
    required_status_checks?: ProtectedBranchRequiredStatusCheck | undefined;
    enforce_admins?: ProtectedBranchAdminEnforced | undefined;
    required_pull_request_reviews?: ProtectedBranchPullRequestReview | undefined;
    restrictions?: BranchRestrictionPolicy | undefined;
    required_linear_history?: BranchProtectionRequiredLinearHistory | undefined;
    allow_force_pushes?: BranchProtectionRequiredLinearHistory | undefined;
    allow_deletions?: BranchProtectionRequiredLinearHistory | undefined;
    block_creations?: BranchProtectionRequiredLinearHistory | undefined;
    required_conversation_resolution?: BranchProtectionRequiredLinearHistory | undefined;
    name?: string | undefined;
    protection_url?: string | undefined;
    required_signatures?: BranchProtectionRequiredSignatures | undefined;
    /** Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. */
    lock_branch?: BranchProtectionRequiredLinearHistory | undefined;
    /** Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. */
    allow_fork_syncing?: BranchProtectionRequiredLinearHistory | undefined;
}
/** Branch With Protection */
export interface BranchWithProtection {
    name: string;
    commit: Commit;
    _links: BranchWithProtectionLinks;
    protected: boolean;
    protection: BranchProtection;
    protection_url: string;
    pattern?: string | undefined;
    required_approving_review_count?: number | undefined;
}
export interface GetBranchProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface GetBranchRulesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type RepositoryRuleDetailedCase0Type = "creation";
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase0RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase0 {
    type: RepositoryRuleDetailedCase0Type;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase0RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase1Type = "update";
export type RepositoryRuleDetailedCase1Parameters = RepositoryRuleUpdateParameters;
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase1RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase1 {
    type: RepositoryRuleDetailedCase1Type;
    parameters?: RepositoryRuleUpdateParameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase1RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase2Type = "deletion";
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase2RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase2 {
    type: RepositoryRuleDetailedCase2Type;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase2RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase3Type = "required_linear_history";
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase3RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase3 {
    type: RepositoryRuleDetailedCase3Type;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase3RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase4Type = "merge_queue";
/** When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. */
export type RepositoryRuleDetailedCase4ParametersGroupingStrategy = "ALLGREEN" | "HEADGREEN";
/** Method to use when merging changes from queued pull requests. */
export type RepositoryRuleDetailedCase4ParametersMergeMethod = "MERGE" | "SQUASH" | "REBASE";
export interface RepositoryRuleDetailedCase4Parameters {
    /** Maximum time for a required status check to report a conclusion. After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed */
    check_response_timeout_minutes: number;
    /** When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. */
    grouping_strategy: RepositoryRuleDetailedCase4ParametersGroupingStrategy;
    /** Limit the number of queued pull requests requesting checks and workflow runs at the same time. */
    max_entries_to_build: number;
    /** The maximum number of PRs that will be merged together in a group. */
    max_entries_to_merge: number;
    /** Method to use when merging changes from queued pull requests. */
    merge_method: RepositoryRuleDetailedCase4ParametersMergeMethod;
    /** The minimum number of PRs that will be merged together in a group. */
    min_entries_to_merge: number;
    /** The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met. After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged. */
    min_entries_to_merge_wait_minutes: number;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase4RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase4 {
    type: RepositoryRuleDetailedCase4Type;
    parameters?: RepositoryRuleDetailedCase4Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase4RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase5Type = "required_deployments";
/** The environments that must be successfully deployed to before branches can be merged. */
export type RepositoryRuleDetailedCase5ParametersRequiredDeploymentEnvironmentsList = Array<string>;
export interface RepositoryRuleDetailedCase5Parameters {
    /** The environments that must be successfully deployed to before branches can be merged. */
    required_deployment_environments: RepositoryRuleDetailedCase5ParametersRequiredDeploymentEnvironmentsList;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase5RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase5 {
    type: RepositoryRuleDetailedCase5Type;
    parameters?: RepositoryRuleDetailedCase5Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase5RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase6Type = "required_signatures";
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase6RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase6 {
    type: RepositoryRuleDetailedCase6Type;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase6RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase7Type = "pull_request";
export type RepositoryRuleDetailedCase7ParametersAllowedMergeMethodsItem = "merge" | "squash" | "rebase";
/** Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. */
export type RepositoryRuleDetailedCase7ParametersAllowedMergeMethodsList = Array<RepositoryRuleDetailedCase7ParametersAllowedMergeMethodsItem>;
/** A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review. */
export type RepositoryRuleDetailedCase7ParametersRequiredReviewersList = Array<RepositoryRuleParamsRequiredReviewerConfiguration>;
export interface RepositoryRuleDetailedCase7Parameters {
    /** Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. */
    allowed_merge_methods?: RepositoryRuleDetailedCase7ParametersAllowedMergeMethodsList | undefined;
    /** New, reviewable commits pushed will dismiss previous pull request review approvals. */
    dismiss_stale_reviews_on_push: boolean;
    dismissal_restriction?: RepositoryRuleParamsDismissalRestriction | undefined;
    /** Require an approving review in pull requests that modify files that have a designated code owner. */
    require_code_owner_review: boolean;
    /** When Copilot opens a pull request without a human collaborator, require one more approving review if a non-zero approval count is required. */
    require_extra_approval_for_unattributed_changes?: boolean | undefined;
    /** Whether the most recent reviewable push must be approved by someone other than the person who pushed it. */
    require_last_push_approval: boolean;
    /** The number of approving reviews that are required before a pull request can be merged. */
    required_approving_review_count: number;
    /** All conversations on code must be resolved before a pull request can be merged. */
    required_review_thread_resolution: boolean;
    /** A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review. */
    required_reviewers?: RepositoryRuleDetailedCase7ParametersRequiredReviewersList | undefined;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase7RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase7 {
    type: RepositoryRuleDetailedCase7Type;
    parameters?: RepositoryRuleDetailedCase7Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase7RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase8Type = "required_status_checks";
/** Status checks that are required. */
export type RepositoryRuleDetailedCase8ParametersRequiredStatusChecksList = Array<RepositoryRuleParamsStatusCheckConfiguration>;
export interface RepositoryRuleDetailedCase8Parameters {
    /** Allow repositories and branches to be created if a check would otherwise prohibit it. */
    do_not_enforce_on_create?: boolean | undefined;
    /** Status checks that are required. */
    required_status_checks: RepositoryRuleDetailedCase8ParametersRequiredStatusChecksList;
    /** Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled. */
    strict_required_status_checks_policy: boolean;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase8RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase8 {
    type: RepositoryRuleDetailedCase8Type;
    parameters?: RepositoryRuleDetailedCase8Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase8RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase9Type = "non_fast_forward";
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase9RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase9 {
    type: RepositoryRuleDetailedCase9Type;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase9RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase10Type = "commit_message_pattern";
/** The operator to use for matching. */
export type RepositoryRuleDetailedCase10ParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleDetailedCase10Parameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleDetailedCase10ParametersOperator;
    /** The pattern to match with. */
    pattern: string;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase10RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase10 {
    type: RepositoryRuleDetailedCase10Type;
    parameters?: RepositoryRuleDetailedCase10Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase10RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase11Type = "commit_author_email_pattern";
/** The operator to use for matching. */
export type RepositoryRuleDetailedCase11ParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleDetailedCase11Parameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleDetailedCase11ParametersOperator;
    /** The pattern to match with. */
    pattern: string;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase11RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase11 {
    type: RepositoryRuleDetailedCase11Type;
    parameters?: RepositoryRuleDetailedCase11Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase11RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase12Type = "committer_email_pattern";
/** The operator to use for matching. */
export type RepositoryRuleDetailedCase12ParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleDetailedCase12Parameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleDetailedCase12ParametersOperator;
    /** The pattern to match with. */
    pattern: string;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase12RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase12 {
    type: RepositoryRuleDetailedCase12Type;
    parameters?: RepositoryRuleDetailedCase12Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase12RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase13Type = "branch_name_pattern";
/** The operator to use for matching. */
export type RepositoryRuleDetailedCase13ParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleDetailedCase13Parameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleDetailedCase13ParametersOperator;
    /** The pattern to match with. */
    pattern: string;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase13RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase13 {
    type: RepositoryRuleDetailedCase13Type;
    parameters?: RepositoryRuleDetailedCase13Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase13RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase14Type = "tag_name_pattern";
/** The operator to use for matching. */
export type RepositoryRuleDetailedCase14ParametersOperator = "starts_with" | "ends_with" | "contains" | "regex";
export interface RepositoryRuleDetailedCase14Parameters {
    /** How this rule appears when configuring it. */
    name?: string | undefined;
    /** If true, the rule will fail if the pattern matches. */
    negate?: boolean | undefined;
    /** The operator to use for matching. */
    operator: RepositoryRuleDetailedCase14ParametersOperator;
    /** The pattern to match with. */
    pattern: string;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase14RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase14 {
    type: RepositoryRuleDetailedCase14Type;
    parameters?: RepositoryRuleDetailedCase14Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase14RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase15Type = "workflows";
/** Workflows that must pass for this rule to pass. */
export type RepositoryRuleDetailedCase15ParametersWorkflowsList = Array<RepositoryRuleParamsWorkflowFileReference>;
export interface RepositoryRuleDetailedCase15Parameters {
    /** Allow repositories and branches to be created if a check would otherwise prohibit it. */
    do_not_enforce_on_create?: boolean | undefined;
    /** Workflows that must pass for this rule to pass. */
    workflows: RepositoryRuleDetailedCase15ParametersWorkflowsList;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase15RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase15 {
    type: RepositoryRuleDetailedCase15Type;
    parameters?: RepositoryRuleDetailedCase15Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase15RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase16Type = "code_scanning";
/** Tools that must provide code scanning results for this rule to pass. */
export type RepositoryRuleDetailedCase16ParametersCodeScanningToolsList = Array<RepositoryRuleParamsCodeScanningTool>;
export interface RepositoryRuleDetailedCase16Parameters {
    /** Tools that must provide code scanning results for this rule to pass. */
    code_scanning_tools: RepositoryRuleDetailedCase16ParametersCodeScanningToolsList;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase16RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase16 {
    type: RepositoryRuleDetailedCase16Type;
    parameters?: RepositoryRuleDetailedCase16Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase16RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase17Type = "code_quality";
/** The lowest severity level at which code quality reviews need to be resolved before commits can be merged. */
export type RepositoryRuleDetailedCase17ParametersSeverity = "errors" | "warnings" | "notes" | "all";
export interface RepositoryRuleDetailedCase17Parameters {
    /** The lowest severity level at which code quality reviews need to be resolved before commits can be merged. */
    severity: RepositoryRuleDetailedCase17ParametersSeverity;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase17RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase17 {
    type: RepositoryRuleDetailedCase17Type;
    parameters?: RepositoryRuleDetailedCase17Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase17RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase18Type = "code_coverage";
export type RepositoryRuleDetailedCase18Parameters = RepositoryRuleCodeCoverageParameters;
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase18RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase18 {
    type: RepositoryRuleDetailedCase18Type;
    parameters?: RepositoryRuleCodeCoverageParameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase18RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase19Type = "copilot_code_review";
export type RepositoryRuleDetailedCase19Parameters = RepositoryRuleCopilotCodeReviewParameters;
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase19RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase19 {
    type: RepositoryRuleDetailedCase19Type;
    parameters?: RepositoryRuleCopilotCodeReviewParameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase19RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase20Type = "license_compliance_scanning";
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase20RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase20 {
    type: RepositoryRuleDetailedCase20Type;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase20RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase21Type = "file_path_restriction";
/** Files matching these patterns are allowed even when they also match a restricted path. */
export type RepositoryRuleDetailedCase21ParametersIgnoredFilePathsList = Array<string>;
/** The file paths that are restricted from being pushed to the commit graph. */
export type RepositoryRuleDetailedCase21ParametersRestrictedFilePathsList = Array<string>;
export interface RepositoryRuleDetailedCase21Parameters {
    /** Files matching these patterns are allowed even when they also match a restricted path. */
    ignored_file_paths?: RepositoryRuleDetailedCase21ParametersIgnoredFilePathsList | undefined;
    /** The file paths that are restricted from being pushed to the commit graph. */
    restricted_file_paths: RepositoryRuleDetailedCase21ParametersRestrictedFilePathsList;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase21RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase21 {
    type: RepositoryRuleDetailedCase21Type;
    parameters?: RepositoryRuleDetailedCase21Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase21RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase22Type = "max_file_path_length";
export type RepositoryRuleDetailedCase22Parameters = RepositoryRuleMaxFilePathLengthParameters;
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase22RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase22 {
    type: RepositoryRuleDetailedCase22Type;
    parameters?: RepositoryRuleMaxFilePathLengthParameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase22RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase23Type = "file_extension_restriction";
/** The file extensions that are restricted from being pushed to the commit graph. */
export type RepositoryRuleDetailedCase23ParametersRestrictedFileExtensionsList = Array<string>;
export interface RepositoryRuleDetailedCase23Parameters {
    /** The file extensions that are restricted from being pushed to the commit graph. */
    restricted_file_extensions: RepositoryRuleDetailedCase23ParametersRestrictedFileExtensionsList;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase23RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase23 {
    type: RepositoryRuleDetailedCase23Type;
    parameters?: RepositoryRuleDetailedCase23Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase23RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
export type RepositoryRuleDetailedCase24Type = "max_file_size";
/** Files matching these patterns may exceed the maximum size. */
export type RepositoryRuleDetailedCase24ParametersIgnoredFilePathsList = Array<string>;
export interface RepositoryRuleDetailedCase24Parameters {
    /** Files matching these patterns may exceed the maximum size. */
    ignored_file_paths?: RepositoryRuleDetailedCase24ParametersIgnoredFilePathsList | undefined;
    /** The maximum file size allowed in megabytes. This limit does not apply to Git Large File Storage (Git LFS). */
    max_file_size: number;
}
/** The type of source for the ruleset that includes this rule. */
export type RepositoryRuleDetailedCase24RulesetSourceType = "Repository" | "Organization";
export interface RepositoryRuleDetailedCase24 {
    type: RepositoryRuleDetailedCase24Type;
    parameters?: RepositoryRuleDetailedCase24Parameters | undefined;
    /** The type of source for the ruleset that includes this rule. */
    ruleset_source_type?: RepositoryRuleDetailedCase24RulesetSourceType | undefined;
    /** The name of the source of the ruleset that includes this rule. */
    ruleset_source?: string | undefined;
    /** The ID of the ruleset that includes this rule. */
    ruleset_id?: number | undefined;
}
/** A repository rule with ruleset details. */
export type RepositoryRuleDetailed = RepositoryRuleDetailedCase0 | RepositoryRuleDetailedCase1 | RepositoryRuleDetailedCase2 | RepositoryRuleDetailedCase3 | RepositoryRuleDetailedCase4 | RepositoryRuleDetailedCase5 | RepositoryRuleDetailedCase6 | RepositoryRuleDetailedCase7 | RepositoryRuleDetailedCase8 | RepositoryRuleDetailedCase9 | RepositoryRuleDetailedCase10 | RepositoryRuleDetailedCase11 | RepositoryRuleDetailedCase12 | RepositoryRuleDetailedCase13 | RepositoryRuleDetailedCase14 | RepositoryRuleDetailedCase15 | RepositoryRuleDetailedCase16 | RepositoryRuleDetailedCase17 | RepositoryRuleDetailedCase18 | RepositoryRuleDetailedCase19 | RepositoryRuleDetailedCase20 | RepositoryRuleDetailedCase21 | RepositoryRuleDetailedCase22 | RepositoryRuleDetailedCase23 | RepositoryRuleDetailedCase24;
export type GetBranchRulesResponseBodyList = Array<RepositoryRuleDetailed>;
export type GetBranchRulesResponse = GetBranchRulesResponseBodyList;
export interface GetByIdRequest {
    /** The unique identifier of the repository. */
    id: number;
}
export type GetClonesRequestPer = "day" | "week";
export interface GetClonesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The time frame to display results for. */
    per?: GetClonesRequestPer | (string & {}) | undefined;
}
export interface Traffic {
    timestamp: string;
    uniques: number;
    count: number;
}
export type CloneTrafficClonesList = Array<Traffic>;
/** Clone Traffic */
export interface CloneTraffic {
    count: number;
    uniques: number;
    clones: CloneTrafficClonesList;
}
export interface GetCodeFrequencyStatsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Code Frequency Stat */
export type CodeFrequencyStat = Array<number>;
export type GetCodeFrequencyStatsResponseBodyList = Array<CodeFrequencyStat>;
export type GetCodeFrequencyStatsResponse = GetCodeFrequencyStatsResponseBodyList;
export interface GetCollaboratorPermissionLevelRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface NullableCollaboratorPermissions {
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
    admin: boolean;
}
/** Collaborator */
export interface NullableCollaborator {
    login: string;
    id: number;
    email?: string | null | undefined;
    name?: string | null | undefined;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    permissions?: NullableCollaboratorPermissions | undefined;
    role_name: string;
    user_view_type?: string | undefined;
}
/** Repository Collaborator Permission */
export interface RepositoryCollaboratorPermission {
    permission: string;
    role_name: string;
    user: NullableCollaborator | null;
}
export interface GetCombinedStatusForRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface SimpleCommitStatus {
    description: string | null;
    id: number;
    node_id: string;
    state: string;
    context: string;
    target_url: string | null;
    required?: boolean | null | undefined;
    avatar_url: string | null;
    url: string;
    created_at: string;
    updated_at: string;
}
export type CombinedCommitStatusStatusesList = Array<SimpleCommitStatus>;
/** Combined Commit Status */
export interface CombinedCommitStatus {
    state: string;
    statuses: CombinedCommitStatusStatusesList;
    sha: string;
    total_count: number;
    repository: MinimalRepository;
    commit_url: string;
    url: string;
}
export type GetCommitRequestAccept = "application/vnd.github+json" | "application/vnd.github.diff" | "application/vnd.github.patch" | "application/vnd.github.sha";
export interface GetCommitRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A media type that returns text instead of JSON: `application/vnd.github.diff`, `application/vnd.github.patch`, `application/vnd.github.sha`. */
    accept?: GetCommitRequestAccept | (string & {}) | undefined;
}
export type GetCommitResponseBody = Commit | string;
export type GetCommitResponse = GetCommitResponseBody;
export interface GetCommitActivityStatsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type CommitActivityDaysList = Array<number>;
/** Commit Activity */
export interface CommitActivity {
    days: CommitActivityDaysList;
    total: number;
    week: number;
}
export type GetCommitActivityStatsResponseBodyList = Array<CommitActivity>;
export type GetCommitActivityStatsResponse = GetCommitActivityStatsResponseBodyList;
export interface GetCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
}
export interface GetCommitSignatureProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface GetCommunityProfileMetricsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Code of Conduct Simple */
export type NullableCodeOfConductSimple = CodeOfConductSimple;
export interface NullableCommunityHealthFile {
    url: string;
    html_url: string;
}
export interface CommunityProfileFiles {
    code_of_conduct: CodeOfConductSimple | null;
    code_of_conduct_file: NullableCommunityHealthFile | null;
    license: NullableLicenseSimple | null;
    contributing: NullableCommunityHealthFile | null;
    readme: NullableCommunityHealthFile | null;
    issue_template: NullableCommunityHealthFile | null;
    pull_request_template: NullableCommunityHealthFile | null;
}
/** Community Profile */
export interface CommunityProfile {
    health_percentage: number;
    description: string | null;
    documentation: string | null;
    files: CommunityProfileFiles;
    updated_at: string | null;
    content_reports_enabled?: boolean | undefined;
}
export interface GetContentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** path parameter */
    path: string;
    /** The name of the commit/branch/tag. Default: the repository's default branch. */
    ref?: string | undefined;
}
export type ContentDirectoryItemType = "dir" | "file" | "submodule" | "symlink";
export interface ContentDirectoryItemLinks {
    git: string | null;
    html: string | null;
    self: string;
}
export interface ContentDirectoryItem {
    type: ContentDirectoryItemType;
    size: number;
    name: string;
    path: string;
    content?: string | undefined;
    sha: string;
    url: string;
    git_url: string | null;
    html_url: string | null;
    download_url: string | null;
    _links: ContentDirectoryItemLinks;
}
/** A list of directory items */
export type ContentDirectory = Array<ContentDirectoryItem>;
export type ContentFileType = "file";
export type ContentFileLinks = ContentDirectoryItemLinks;
/** Content File */
export interface ContentFile {
    type: ContentFileType;
    encoding: string;
    size: number;
    name: string;
    path: string;
    content: string;
    sha: string;
    url: string;
    git_url: string | null;
    html_url: string | null;
    download_url: string | null;
    _links: ContentDirectoryItemLinks;
    target?: string | undefined;
    submodule_git_url?: string | undefined;
}
export type ContentSymlinkType = "symlink";
export type ContentSymlinkLinks = ContentDirectoryItemLinks;
/** An object describing a symlink */
export interface ContentSymlink {
    type: ContentSymlinkType;
    target: string;
    size: number;
    name: string;
    path: string;
    sha: string;
    url: string;
    git_url: string | null;
    html_url: string | null;
    download_url: string | null;
    _links: ContentDirectoryItemLinks;
}
export type ContentSubmoduleType = "submodule";
export type ContentSubmoduleLinks = ContentDirectoryItemLinks;
/** An object describing a submodule */
export interface ContentSubmodule {
    type: ContentSubmoduleType;
    submodule_git_url: string;
    size: number;
    name: string;
    path: string;
    sha: string;
    url: string;
    git_url: string | null;
    html_url: string | null;
    download_url: string | null;
    _links: ContentDirectoryItemLinks;
}
export type GetContentResponseBody = ContentDirectory | ContentFile | ContentSymlink | ContentSubmodule;
export type GetContentResponse = GetContentResponseBody;
export interface GetContributorsStatsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface ContributorActivityWeeksItem {
    w?: number | undefined;
    a?: number | undefined;
    d?: number | undefined;
    c?: number | undefined;
}
export type ContributorActivityWeeksList = Array<ContributorActivityWeeksItem>;
/** Contributor Activity */
export interface ContributorActivity {
    author: SimpleUser | null;
    total: number;
    weeks: ContributorActivityWeeksList;
}
export type GetContributorsStatsResponseBodyList = Array<ContributorActivity>;
export type GetContributorsStatsResponse = GetContributorsStatsResponseBodyList;
export interface GetCustomDeploymentProtectionRuleRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The unique identifier of the protection rule. */
    protection_rule_id: number;
}
export interface GetDeployKeyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the key. */
    key_id: number;
}
export interface GetDeploymentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** deployment_id parameter */
    deployment_id: number;
}
export interface GetDeploymentBranchPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The unique identifier of the branch policy. */
    branch_policy_id: number;
}
export interface GetDeploymentStatusRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** deployment_id parameter */
    deployment_id: number;
    status_id: number;
}
export interface GetEnvironmentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
}
export interface GetHashAlgorithmRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** The Git hash algorithm used by this repository. */
export type RepositoryHashAlgorithmHashAlgorithm = "sha1" | "sha256";
/** Repository hash algorithm */
export interface RepositoryHashAlgorithm {
    /** The Git hash algorithm used by this repository. */
    hash_algorithm: RepositoryHashAlgorithmHashAlgorithm;
}
export interface GetLatestPagesBuildRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface PageBuildError {
    message: string | null;
}
/** Page Build */
export interface PageBuild {
    url: string;
    status: string;
    error: PageBuildError;
    pusher: SimpleUser | null;
    commit: string;
    duration: number;
    created_at: string;
    updated_at: string;
}
export interface GetLatestReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetOrgRulesetRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
}
export interface GetOrgRulesetsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** A comma-separated list of rule targets to filter by. If provided, only rulesets that apply to the specified targets will be returned. For example, `branch,tag,push`. */
    targets?: string | undefined;
}
export type GetOrgRulesetsResponseBodyList = Array<RepositoryRuleset>;
export type GetOrgRulesetsResponse = GetOrgRulesetsResponseBodyList;
export interface GetOrgRuleSuiteRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The unique identifier of the rule suite result. To get this ID, you can use [GET /repos/{owner}/{repo}/rulesets/rule-suites](https://docs.github.com/rest/repos/rule-suites#list-repository-rule-suites) for repositories and [GET /orgs/{org}/rulesets/rule-suites](https://docs.github.com/rest/orgs/rule-suites#list-organization-rule-suites) for organizations. */
    rule_suite_id: number;
    /** When set to `true`, the response will include additional metadata for pull request and required status check rule evaluation. Results are capped at 50 entries. */
    include_metadata?: boolean | undefined;
}
/** The result of the rule evaluations for rules with the `active` enforcement status. */
export type RuleSuiteResult = "pass" | "fail" | "bypass";
/** The result of the rule evaluations for rules with the `active` and `evaluate` enforcement statuses, demonstrating whether rules would pass or fail if all rules in the rule suite were `active`. Null if no rules with `evaluate` enforcement status were run. */
export type RuleSuiteEvaluationResult = "pass" | "fail" | "bypass";
export interface RuleSuiteRuleEvaluationsItemRuleSource {
    /** The type of rule source. */
    type?: string | undefined;
    /** The ID of the rule source. */
    id?: number | null | undefined;
    /** The name of the rule source. */
    name?: string | null | undefined;
}
/** The enforcement level of this rule source. */
export type RuleSuiteRuleEvaluationsItemEnforcement = "active" | "evaluate" | "deleted ruleset";
/** The result of the evaluation of the individual rule. */
export type RuleSuiteRuleEvaluationsItemResult = "pass" | "fail";
/** The user who created the pull request. */
export interface RuleSuitePullRequestPullRequestUser {
    /** The unique identifier of the user. */
    id?: number | undefined;
    /** The handle for the GitHub user account. */
    login?: string | undefined;
    /** The type of the user. */
    type?: string | undefined;
}
/** The user who submitted the review. */
export type RuleSuitePullRequestPullRequestReviewsItemUser = RuleSuitePullRequestPullRequestUser;
export interface RuleSuitePullRequestPullRequestReviewsItem {
    /** The unique identifier of the review. */
    id?: number | undefined;
    /** The user who submitted the review. */
    user?: RuleSuitePullRequestPullRequestUser | undefined;
    /** The state of the review. */
    state?: string | undefined;
}
/** The reviews associated with the pull request. */
export type RuleSuitePullRequestPullRequestReviewsList = Array<RuleSuitePullRequestPullRequestReviewsItem>;
/** The user who provided proof of presence. Null if no proof of presence was recorded. */
export type RuleSuitePullRequestPullRequestProofOfPresenceVerifier = RuleSuitePullRequestPullRequestUser;
/** The proof of presence evaluation for the pull request. Null if proof of presence was not evaluated. */
export interface RuleSuitePullRequestPullRequestProofOfPresence {
    /** The state of the proof of presence evaluation. */
    state?: string | undefined;
    /** A code describing the reason for the proof of presence state. */
    code?: string | undefined;
    /** The base commit SHA the proof of presence evaluation applies to. Empty if unavailable. */
    base_sha?: string | undefined;
    /** The head commit SHA the proof of presence evaluation applies to. Empty if unavailable. */
    head_sha?: string | undefined;
    /** The authentication level required by the rule. Empty if unavailable. */
    required_level?: string | undefined;
    /** The authentication level that was verified. Empty if proof of presence has not been completed. */
    verified_level?: string | undefined;
    /** The time proof of presence was verified, in ISO 8601 format. Empty if proof of presence has not been completed. */
    verified_at?: string | undefined;
    /** The user who provided proof of presence. Null if no proof of presence was recorded. */
    verifier?: RuleSuitePullRequestPullRequestUser | null | undefined;
}
/** The pull request associated with the rule evaluation. */
export interface RuleSuitePullRequestPullRequest {
    /** The unique identifier of the pull request. */
    id?: number | undefined;
    /** The number of the pull request. */
    number?: number | undefined;
    /** The user who created the pull request. */
    user?: RuleSuitePullRequestPullRequestUser | undefined;
    /** The reviews associated with the pull request. */
    reviews?: RuleSuitePullRequestPullRequestReviewsList | undefined;
    /** The proof of presence evaluation for the pull request. Null if proof of presence was not evaluated. */
    proof_of_presence?: RuleSuitePullRequestPullRequestProofOfPresence | null | undefined;
}
/** Metadata for a pull request rule evaluation result. */
export interface RuleSuitePullRequest {
    /** The pull request associated with the rule evaluation. */
    pull_request?: RuleSuitePullRequestPullRequest | undefined;
}
/** The GitHub App associated with the status check. */
export interface RuleSuiteRequiredStatusChecksChecksItemApp {
    /** The unique identifier of the GitHub App. */
    id?: number | undefined;
    /** The slug of the GitHub App. */
    slug?: string | undefined;
    /** The name of the GitHub App. */
    name?: string | undefined;
}
export interface RuleSuiteRequiredStatusChecksChecksItem {
    /** The unique identifier of the status check. */
    id?: number | undefined;
    /** The context name of the status check. */
    context?: string | undefined;
    /** The state of the status check. */
    state?: string | undefined;
    /** The type of the status check. */
    type?: string | undefined;
    /** The GitHub App associated with the status check. */
    app?: RuleSuiteRequiredStatusChecksChecksItemApp | null | undefined;
}
/** The status checks associated with the rule evaluation. */
export type RuleSuiteRequiredStatusChecksChecksList = Array<RuleSuiteRequiredStatusChecksChecksItem>;
/** Metadata for a required status checks rule evaluation result. */
export interface RuleSuiteRequiredStatusChecks {
    /** The status checks associated with the rule evaluation. */
    checks?: RuleSuiteRequiredStatusChecksChecksList | undefined;
}
/** Additional metadata about the rule evaluation. */
export type RuleSuiteRuleEvaluationsItemMetadata = RuleSuitePullRequest | RuleSuiteRequiredStatusChecks;
export interface RuleSuiteRuleEvaluationsItem {
    rule_source?: RuleSuiteRuleEvaluationsItemRuleSource | undefined;
    /** The enforcement level of this rule source. */
    enforcement?: RuleSuiteRuleEvaluationsItemEnforcement | undefined;
    /** The result of the evaluation of the individual rule. */
    result?: RuleSuiteRuleEvaluationsItemResult | undefined;
    /** The type of rule. */
    rule_type?: string | undefined;
    /** Additional metadata about the rule evaluation. */
    metadata?: RuleSuiteRuleEvaluationsItemMetadata | null | undefined;
    /** The detailed failure message for the rule. Null if the rule passed. */
    details?: string | null | undefined;
}
/** Details on the evaluated rules. */
export type RuleSuiteRuleEvaluationsList = Array<RuleSuiteRuleEvaluationsItem>;
/** Response */
export interface RuleSuite {
    /** The unique identifier of the rule insight. */
    id?: number | undefined;
    /** The number that identifies the user. */
    actor_id?: number | null | undefined;
    /** The handle for the GitHub user account. */
    actor_name?: string | null | undefined;
    /** The previous commit SHA of the ref. */
    before_sha?: string | undefined;
    /** The new commit SHA of the ref. */
    after_sha?: string | undefined;
    /** The ref name that the evaluation ran on. */
    ref?: string | undefined;
    /** The ID of the repository associated with the rule evaluation. */
    repository_id?: number | undefined;
    /** The name of the repository without the `.git` extension. */
    repository_name?: string | undefined;
    pushed_at?: string | undefined;
    /** The result of the rule evaluations for rules with the `active` enforcement status. */
    result?: RuleSuiteResult | undefined;
    /** The result of the rule evaluations for rules with the `active` and `evaluate` enforcement statuses, demonstrating whether rules would pass or fail if all rules in the rule suite were `active`. Null if no rules with `evaluate` enforcement status were run. */
    evaluation_result?: RuleSuiteEvaluationResult | null | undefined;
    /** Details on the evaluated rules. */
    rule_evaluations?: RuleSuiteRuleEvaluationsList | undefined;
}
export type GetOrgRuleSuitesRequestTimePeriod = "hour" | "day" | "week" | "month";
export type GetOrgRuleSuitesRequestRuleSuiteResult = "pass" | "fail" | "bypass" | "all";
export type GetOrgRuleSuitesRequestEvaluateStatus = "all" | "active" | "evaluate";
export interface GetOrgRuleSuitesRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the ref. Cannot contain wildcard characters. Optionally prefix with `refs/heads/` to limit to branches or `refs/tags/` to limit to tags. Omit the prefix to search across all refs. When specified, only rule evaluations triggered for this ref will be returned. */
    ref?: string | undefined;
    /** The name of the repository to filter on. */
    repository_name?: string | undefined;
    /** The time period to filter by. For example, `day` will filter for rule suites that occurred in the past 24 hours, and `week` will filter for rule suites that occurred in the past 7 days (168 hours). */
    time_period?: GetOrgRuleSuitesRequestTimePeriod | (string & {}) | undefined;
    /** The handle for the GitHub user account to filter on. When specified, only rule evaluations triggered by this actor will be returned. */
    actor_name?: string | undefined;
    /** The rule suite results to filter on. When specified, only suites with this result will be returned. */
    rule_suite_result?: GetOrgRuleSuitesRequestRuleSuiteResult | (string & {}) | undefined;
    /** The evaluate status to filter on. When specified, only rule suites resulting from rulesets with the specified evaluate status will be returned. - `all` - all rule suites will be returned. - `active` - only rule suites resulting from rulesets in active (non-evaluate) mode will be returned. - `evaluate` - only rule suites resulting from rulesets in evaluate mode will be returned. */
    evaluate_status?: GetOrgRuleSuitesRequestEvaluateStatus | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The result of the rule evaluations for rules with the `active` enforcement status. */
export type RuleSuitesItemResult = "pass" | "fail" | "bypass";
/** The result of the rule evaluations for rules with the `active` and `evaluate` enforcement statuses, demonstrating whether rules would pass or fail if all rules in the rule suite were `active`. */
export type RuleSuitesItemEvaluationResult = "pass" | "fail" | "bypass";
export interface RuleSuitesItem {
    /** The unique identifier of the rule insight. */
    id?: number | undefined;
    /** The number that identifies the user. */
    actor_id?: number | undefined;
    /** The handle for the GitHub user account. */
    actor_name?: string | undefined;
    /** The first commit sha before the push evaluation. */
    before_sha?: string | undefined;
    /** The last commit sha in the push evaluation. */
    after_sha?: string | undefined;
    /** The ref name that the evaluation ran on. */
    ref?: string | undefined;
    /** The ID of the repository associated with the rule evaluation. */
    repository_id?: number | undefined;
    /** The name of the repository without the `.git` extension. */
    repository_name?: string | undefined;
    pushed_at?: string | undefined;
    /** The result of the rule evaluations for rules with the `active` enforcement status. */
    result?: RuleSuitesItemResult | undefined;
    /** The result of the rule evaluations for rules with the `active` and `evaluate` enforcement statuses, demonstrating whether rules would pass or fail if all rules in the rule suite were `active`. */
    evaluation_result?: RuleSuitesItemEvaluationResult | undefined;
}
/** Response */
export type RuleSuites = Array<RuleSuitesItem>;
export type GetOrgRuleSuitesResponse = RuleSuites;
export interface GetPagesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetPagesBuildRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    build_id: number;
}
export interface GetPagesDeploymentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the Pages deployment. You can also give the commit SHA of the deployment. */
    pages_deployment_id: string;
}
/** The current status of the deployment. */
export type PagesDeploymentStatusStatus = "deployment_in_progress" | "syncing_files" | "finished_file_sync" | "updating_pages" | "purging_cdn" | "deployment_cancelled" | "deployment_failed" | "deployment_content_failed" | "deployment_attempt_error" | "deployment_lost" | "succeed";
export interface PagesDeploymentStatus {
    /** The current status of the deployment. */
    status?: PagesDeploymentStatusStatus | undefined;
}
export interface GetPagesHealthCheckRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface PagesHealthCheckDomain {
    host?: string | undefined;
    uri?: string | undefined;
    nameservers?: string | undefined;
    dns_resolves?: boolean | undefined;
    is_proxied?: boolean | null | undefined;
    is_cloudflare_ip?: boolean | null | undefined;
    is_fastly_ip?: boolean | null | undefined;
    is_old_ip_address?: boolean | null | undefined;
    is_a_record?: boolean | null | undefined;
    has_cname_record?: boolean | null | undefined;
    has_mx_records_present?: boolean | null | undefined;
    is_valid_domain?: boolean | undefined;
    is_apex_domain?: boolean | undefined;
    should_be_a_record?: boolean | null | undefined;
    is_cname_to_github_user_domain?: boolean | null | undefined;
    is_cname_to_pages_dot_github_dot_com?: boolean | null | undefined;
    is_cname_to_fastly?: boolean | null | undefined;
    is_pointed_to_github_pages_ip?: boolean | null | undefined;
    is_non_github_pages_ip_present?: boolean | null | undefined;
    is_pages_domain?: boolean | undefined;
    is_served_by_pages?: boolean | null | undefined;
    is_valid?: boolean | undefined;
    reason?: string | null | undefined;
    responds_to_https?: boolean | undefined;
    enforces_https?: boolean | undefined;
    https_error?: string | null | undefined;
    is_https_eligible?: boolean | null | undefined;
    caa_error?: string | null | undefined;
}
export type PagesHealthCheckAltDomain = PagesHealthCheckDomain;
/** Pages Health Check Status */
export interface PagesHealthCheck {
    domain?: PagesHealthCheckDomain | undefined;
    alt_domain?: PagesHealthCheckDomain | null | undefined;
}
export interface GetParticipationStatsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type ParticipationStatsAllList = Array<number>;
export type ParticipationStatsOwnerList = Array<number>;
export interface ParticipationStats {
    all: ParticipationStatsAllList;
    owner: ParticipationStatsOwnerList;
}
export interface GetPullRequestReviewProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface GetPunchCardStatsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type GetPunchCardStatsResponseBodyList = Array<CodeFrequencyStat>;
export type GetPunchCardStatsResponse = GetPunchCardStatsResponseBodyList;
export interface GetReadmeRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the commit/branch/tag. Default: the repository's default branch. */
    ref?: string | undefined;
}
export interface GetReadmeInDirectoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The alternate path to look for a README file */
    dir: string;
    /** The name of the commit/branch/tag. Default: the repository's default branch. */
    ref?: string | undefined;
}
export interface GetReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
}
export interface GetReleaseAssetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the asset. */
    asset_id: number;
}
export interface GetReleaseByTagRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** tag parameter */
    tag: string;
}
export interface GetRepoRulesetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** Include rulesets configured at higher levels that apply to this repository */
    includes_parents?: boolean | undefined;
}
export interface GetRepoRulesetHistoryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The actor who updated the ruleset */
export interface RulesetVersionActor {
    id?: number | undefined;
    type?: string | undefined;
}
/** The historical version of a ruleset */
export interface RulesetVersion {
    /** The ID of the previous version of the ruleset */
    version_id: number;
    /** The actor who updated the ruleset */
    actor: RulesetVersionActor;
    updated_at: string;
}
export type GetRepoRulesetHistoryResponseBodyList = Array<RulesetVersion>;
export type GetRepoRulesetHistoryResponse = GetRepoRulesetHistoryResponseBodyList;
export interface GetRepoRulesetsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Include rulesets configured at higher levels that apply to this repository */
    includes_parents?: boolean | undefined;
    /** A comma-separated list of rule targets to filter by. If provided, only rulesets that apply to the specified targets will be returned. For example, `branch,tag,push`. */
    targets?: string | undefined;
}
export type GetRepoRulesetsResponseBodyList = Array<RepositoryRuleset>;
export type GetRepoRulesetsResponse = GetRepoRulesetsResponseBodyList;
export interface GetRepoRulesetVersionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** The ID of the version */
    version_id: number;
}
/** The actor who updated the ruleset */
export type GetRepoRulesetVersionResponseActor = RulesetVersionActor;
export interface GetRepoRulesetVersionResponse {
    /** The ID of the previous version of the ruleset */
    version_id: number;
    /** The actor who updated the ruleset */
    actor: RulesetVersionActor;
    updated_at: string;
    /** The state of the ruleset version */
    state: unknown;
}
export interface GetRepoRuleSuiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the rule suite result. To get this ID, you can use [GET /repos/{owner}/{repo}/rulesets/rule-suites](https://docs.github.com/rest/repos/rule-suites#list-repository-rule-suites) for repositories and [GET /orgs/{org}/rulesets/rule-suites](https://docs.github.com/rest/orgs/rule-suites#list-organization-rule-suites) for organizations. */
    rule_suite_id: number;
    /** When set to `true`, the response will include additional metadata for pull request and required status check rule evaluation. Results are capped at 50 entries. */
    include_metadata?: boolean | undefined;
}
export type GetRepoRuleSuitesRequestTimePeriod = "hour" | "day" | "week" | "month";
export type GetRepoRuleSuitesRequestRuleSuiteResult = "pass" | "fail" | "bypass" | "all";
export type GetRepoRuleSuitesRequestEvaluateStatus = "all" | "active" | "evaluate";
export interface GetRepoRuleSuitesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the ref. Cannot contain wildcard characters. Optionally prefix with `refs/heads/` to limit to branches or `refs/tags/` to limit to tags. Omit the prefix to search across all refs. When specified, only rule evaluations triggered for this ref will be returned. */
    ref?: string | undefined;
    /** The time period to filter by. For example, `day` will filter for rule suites that occurred in the past 24 hours, and `week` will filter for rule suites that occurred in the past 7 days (168 hours). */
    time_period?: GetRepoRuleSuitesRequestTimePeriod | (string & {}) | undefined;
    /** The handle for the GitHub user account to filter on. When specified, only rule evaluations triggered by this actor will be returned. */
    actor_name?: string | undefined;
    /** The rule suite results to filter on. When specified, only suites with this result will be returned. */
    rule_suite_result?: GetRepoRuleSuitesRequestRuleSuiteResult | (string & {}) | undefined;
    /** The evaluate status to filter on. When specified, only rule suites resulting from rulesets with the specified evaluate status will be returned. - `all` - all rule suites will be returned. - `active` - only rule suites resulting from rulesets in active (non-evaluate) mode will be returned. - `evaluate` - only rule suites resulting from rulesets in evaluate mode will be returned. */
    evaluate_status?: GetRepoRuleSuitesRequestEvaluateStatus | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type GetRepoRuleSuitesResponse = RuleSuites;
export interface GetStatusChecksProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export type StatusCheckPolicyContextsList = Array<string>;
export type StatusCheckPolicyChecksItem = ProtectedBranchRequiredStatusCheckChecksItem;
export type StatusCheckPolicyChecksList = Array<ProtectedBranchRequiredStatusCheckChecksItem>;
/** Status Check Policy */
export interface StatusCheckPolicy {
    url: string;
    strict: boolean;
    contexts: StatusCheckPolicyContextsList;
    checks: StatusCheckPolicyChecksList;
    contexts_url: string;
}
export interface GetTeamsWithAccessToProtectedBranchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export type GetTeamsWithAccessToProtectedBranchResponseBodyList = Array<Team>;
export type GetTeamsWithAccessToProtectedBranchResponse = GetTeamsWithAccessToProtectedBranchResponseBodyList;
export interface GetTopPathsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Content Traffic */
export interface ContentTraffic {
    path: string;
    title: string;
    count: number;
    uniques: number;
}
export type GetTopPathsResponseBodyList = Array<ContentTraffic>;
export type GetTopPathsResponse = GetTopPathsResponseBodyList;
export interface GetTopReferrersRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Referrer Traffic */
export interface ReferrerTraffic {
    referrer: string;
    count: number;
    uniques: number;
}
export type GetTopReferrersResponseBodyList = Array<ReferrerTraffic>;
export type GetTopReferrersResponse = GetTopReferrersResponseBodyList;
export interface GetUsersWithAccessToProtectedBranchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export type GetUsersWithAccessToProtectedBranchResponseBodyList = Array<SimpleUser>;
export type GetUsersWithAccessToProtectedBranchResponse = GetUsersWithAccessToProtectedBranchResponseBodyList;
export type GetViewsRequestPer = "day" | "week";
export interface GetViewsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The time frame to display results for. */
    per?: GetViewsRequestPer | (string & {}) | undefined;
}
export type ViewTrafficViewsList = Array<Traffic>;
/** View Traffic */
export interface ViewTraffic {
    count: number;
    uniques: number;
    views: ViewTrafficViewsList;
}
export interface GetWebhookRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface GetWebhookConfigForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface GetWebhookDeliveryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    delivery_id: number;
}
/** The request headers sent with the webhook delivery. */
export type HookDeliveryRequestHeadersMap = {
    [key: string]: unknown | undefined;
};
/** The webhook payload. */
export type HookDeliveryRequestPayloadMap = {
    [key: string]: unknown | undefined;
};
export interface HookDeliveryRequest {
    /** The request headers sent with the webhook delivery. */
    headers: HookDeliveryRequestHeadersMap | null;
    /** The webhook payload. */
    payload: HookDeliveryRequestPayloadMap | null;
}
/** The response headers received when the delivery was made. */
export type HookDeliveryResponseHeadersMap = {
    [key: string]: unknown | undefined;
};
/** The response payload received. */
export type HookDeliveryResponsePayloadMap = {
    [key: string]: unknown | undefined;
};
export interface HookDeliveryResponse {
    /** The response headers received when the delivery was made. */
    headers: HookDeliveryResponseHeadersMap | null;
    /** The response payload received. */
    payload: HookDeliveryResponsePayloadMap | null;
}
/** Delivery made by a webhook. */
export interface HookDelivery {
    /** Unique identifier of the delivery. */
    id: number;
    /** Unique identifier for the event (shared with all deliveries for all webhooks that subscribe to this event). */
    guid: string;
    /** Time when the delivery was delivered. */
    delivered_at: string;
    /** Whether the delivery is a redelivery. */
    redelivery: boolean;
    /** Time spent delivering. */
    duration: number;
    /** Description of the status of the attempted delivery */
    status: string;
    /** Status code received when delivery was made. */
    status_code: number;
    /** The event that triggered the delivery. */
    event: string;
    /** The type of activity for the event that triggered the delivery. */
    action: string | null;
    /** The id of the GitHub App installation associated with this event. */
    installation_id: number | null;
    /** The id of the repository associated with this event. */
    repository_id: number | null;
    /** Time when the webhook delivery was throttled. */
    throttled_at?: string | null | undefined;
    /** The URL target of the delivery. */
    url?: string | undefined;
    request: HookDeliveryRequest;
    response: HookDeliveryResponse;
}
export type ListActivitiesRequestDirection = "asc" | "desc";
export type ListActivitiesRequestTimePeriod = "day" | "week" | "month" | "quarter" | "year";
export type ListActivitiesRequestActivityType = "push" | "force_push" | "branch_creation" | "branch_deletion" | "pr_merge" | "merge_queue_merge";
export interface ListActivitiesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The direction to sort the results by. */
    direction?: ListActivitiesRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The Git reference for the activities you want to list. The `ref` for a branch can be formatted either as `refs/heads/BRANCH_NAME` or `BRANCH_NAME`, where `BRANCH_NAME` is the name of your branch. */
    ref?: string | undefined;
    /** The GitHub username to use to filter by the actor who performed the activity. */
    actor?: string | undefined;
    /** The time period to filter by. For example, `day` will filter for activity that occurred in the past 24 hours, and `week` will filter for activity that occurred in the past 7 days (168 hours). */
    time_period?: ListActivitiesRequestTimePeriod | (string & {}) | undefined;
    /** The activity type to filter by. For example, you can choose to filter by "force_push", to see all force pushes to the repository. */
    activity_type?: ListActivitiesRequestActivityType | (string & {}) | undefined;
}
/** The type of the activity that was performed. */
export type ActivityActivityType = "push" | "force_push" | "branch_deletion" | "branch_creation" | "pr_merge" | "merge_queue_merge";
/** Activity */
export interface Activity {
    id: number;
    node_id: string;
    /** The SHA of the commit before the activity. */
    before: string;
    /** The SHA of the commit after the activity. */
    after: string;
    /** The full Git reference, formatted as `refs/heads/<branch name>`. */
    ref: string;
    /** The time when the activity occurred. */
    timestamp: string;
    /** The type of the activity that was performed. */
    activity_type: ActivityActivityType;
    actor: SimpleUser | null;
}
export type ListActivitiesResponseBodyList = Array<Activity>;
export type ListActivitiesResponse = ListActivitiesResponseBodyList;
export interface ListAttestationsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`. */
    subject_digest: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** Optional filter for fetching attestations with a given predicate type. This option accepts `provenance`, `sbom`, `release`, or freeform text for custom predicate types. */
    predicate_type?: string | undefined;
}
export type ListAttestationsResponseAttestationsItemBundleVerificationMaterialMap = {
    [key: string]: unknown | undefined;
};
export type ListAttestationsResponseAttestationsItemBundleDsseEnvelopeMap = {
    [key: string]: unknown | undefined;
};
/** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
export interface ListAttestationsResponseAttestationsItemBundle {
    mediaType?: string | undefined;
    verificationMaterial?: ListAttestationsResponseAttestationsItemBundleVerificationMaterialMap | undefined;
    dsseEnvelope?: ListAttestationsResponseAttestationsItemBundleDsseEnvelopeMap | undefined;
}
export interface ListAttestationsResponseAttestationsItem {
    /** The attestation's Sigstore Bundle. Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information. */
    bundle?: ListAttestationsResponseAttestationsItemBundle | undefined;
    repository_id?: number | undefined;
    bundle_url?: string | undefined;
    initiator?: string | undefined;
}
export type ListAttestationsResponseAttestationsList = Array<ListAttestationsResponseAttestationsItem>;
export interface ListAttestationsResponse {
    attestations?: ListAttestationsResponseAttestationsList | undefined;
}
export interface ListAutolinksRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type ListAutolinksResponseBodyList = Array<Autolink>;
export type ListAutolinksResponse = ListAutolinksResponseBodyList;
export interface ListBranchesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Setting to `true` returns only branches protected by branch protections or rulesets. When set to `false`, only unprotected branches are returned. Omitting this parameter returns all branches. */
    protected?: boolean | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ShortBranchCommit = CommitCommitTree;
/** Short Branch */
export interface ShortBranch {
    name: string;
    commit: CommitCommitTree;
    protected: boolean;
    protection?: BranchProtection | undefined;
    protection_url?: string | undefined;
}
export type ListBranchesResponseBodyList = Array<ShortBranch>;
export type ListBranchesResponse = ListBranchesResponseBodyList;
export interface ListBranchesForHeadCommitRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA of the commit. */
    commit_sha: string;
}
export type BranchShortCommit = CommitCommitTree;
/** Branch Short */
export interface BranchShort {
    name: string;
    commit: CommitCommitTree;
    protected: boolean;
}
export type ListBranchesForHeadCommitResponseBodyList = Array<BranchShort>;
export type ListBranchesForHeadCommitResponse = ListBranchesForHeadCommitResponseBodyList;
export type ListCollaboratorsRequestAffiliation = "outside" | "direct" | "all";
export type ListCollaboratorsRequestPermission = "pull" | "triage" | "moderate" | "push" | "maintain" | "admin";
export interface ListCollaboratorsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Filter collaborators returned by their affiliation. `outside` means all outside collaborators of an organization-owned repository. `direct` means all collaborators with permissions to an organization-owned repository, regardless of organization membership status. `all` means all collaborators the authenticated user can see. */
    affiliation?: ListCollaboratorsRequestAffiliation | (string & {}) | undefined;
    /** Filter collaborators by the permissions they have on the repository. If not specified, all collaborators will be returned. */
    permission?: ListCollaboratorsRequestPermission | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type CollaboratorPermissions = NullableCollaboratorPermissions;
/** Collaborator */
export type Collaborator = NullableCollaborator;
export type ListCollaboratorsResponseBodyList = Array<NullableCollaborator>;
export type ListCollaboratorsResponse = ListCollaboratorsResponseBodyList;
export interface ListCommentsForCommitRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA of the commit. */
    commit_sha: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommentsForCommitResponseBodyList = Array<CommitComment>;
export type ListCommentsForCommitResponse = ListCommentsForCommitResponseBodyList;
export interface ListCommitCommentsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommitCommentsForRepoResponseBodyList = Array<CommitComment>;
export type ListCommitCommentsForRepoResponse = ListCommitCommentsForRepoResponseBodyList;
export interface ListCommitsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** SHA or branch to start listing commits from. Default: the repository's default branch (usually `main`). */
    sha?: string | undefined;
    /** Only commits containing this file path will be returned. */
    path?: string | undefined;
    /** GitHub username or email address to use to filter by commit author. */
    author?: string | undefined;
    /** GitHub username or email address to use to filter by commit committer. */
    committer?: string | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned. */
    since?: string | undefined;
    /** Only commits before this date will be returned. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned. */
    until?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommitsResponseBodyList = Array<Commit>;
export type ListCommitsResponse = ListCommitsResponseBodyList;
export interface ListCommitStatusesForRefRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    ref: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListCommitStatusesForRefResponseBodyList = Array<Status>;
export type ListCommitStatusesForRefResponse = ListCommitStatusesForRefResponseBodyList;
export interface ListContributorsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Set to `1` or `true` to include anonymous contributors in results. */
    anon?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Contributor */
export interface Contributor {
    login?: string | undefined;
    id?: number | undefined;
    node_id?: string | undefined;
    avatar_url?: string | undefined;
    gravatar_id?: string | null | undefined;
    url?: string | undefined;
    html_url?: string | undefined;
    followers_url?: string | undefined;
    following_url?: string | undefined;
    gists_url?: string | undefined;
    starred_url?: string | undefined;
    subscriptions_url?: string | undefined;
    organizations_url?: string | undefined;
    repos_url?: string | undefined;
    events_url?: string | undefined;
    received_events_url?: string | undefined;
    type: string;
    site_admin?: boolean | undefined;
    contributions: number;
    email?: string | undefined;
    name?: string | undefined;
    user_view_type?: string | undefined;
}
export type ListContributorsResponseBodyList = Array<Contributor>;
export type ListContributorsResponse = ListContributorsResponseBodyList;
export interface ListCustomDeploymentRuleIntegrationsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListCustomDeploymentRuleIntegrationsResponseAvailableCustomDeploymentProtectionRuleIntegrationsList = Array<CustomDeploymentRuleApp>;
export interface ListCustomDeploymentRuleIntegrationsResponse {
    /** The total number of custom deployment protection rule integrations available for this environment. */
    total_count?: number | undefined;
    available_custom_deployment_protection_rule_integrations: ListCustomDeploymentRuleIntegrationsResponseAvailableCustomDeploymentProtectionRuleIntegrationsList;
}
export interface ListDeployKeysRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListDeployKeysResponseBodyList = Array<DeployKey>;
export type ListDeployKeysResponse = ListDeployKeysResponseBodyList;
export interface ListDeploymentBranchPoliciesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListDeploymentBranchPoliciesResponseBranchPoliciesList = Array<DeploymentBranchPolicy>;
export interface ListDeploymentBranchPoliciesResponse {
    /** The number of deployment branch policies for the environment. */
    total_count: number;
    branch_policies: ListDeploymentBranchPoliciesResponseBranchPoliciesList;
}
export interface ListDeploymentsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA recorded at creation time. */
    sha?: string | undefined;
    /** The name of the ref. This can be a branch, tag, or SHA. */
    ref?: string | undefined;
    /** The name of the task for the deployment (e.g., `deploy` or `deploy:migrations`). */
    task?: string | undefined;
    /** The name of the environment that was deployed to (e.g., `staging` or `production`). */
    environment?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListDeploymentsResponseBodyList = Array<Deployment>;
export type ListDeploymentsResponse = ListDeploymentsResponseBodyList;
export interface ListDeploymentStatusesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** deployment_id parameter */
    deployment_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListDeploymentStatusesResponseBodyList = Array<DeploymentStatus>;
export type ListDeploymentStatusesResponse = ListDeploymentStatusesResponseBodyList;
export type ListForAuthenticatedUserRequestVisibility = "all" | "public" | "private";
export type ListForAuthenticatedUserRequestType = "all" | "owner" | "public" | "private" | "member";
export type ListForAuthenticatedUserRequestSort = "created" | "updated" | "pushed" | "full_name";
export type ListForAuthenticatedUserRequestDirection = "asc" | "desc";
export interface ListForAuthenticatedUserRequest {
    /** Limit results to repositories with the specified visibility. */
    visibility?: ListForAuthenticatedUserRequestVisibility | (string & {}) | undefined;
    /** Comma-separated list of values. Can include: * `owner`: Repositories that are owned by the authenticated user. * `collaborator`: Repositories that the user has been added to as a collaborator. * `organization_member`: Repositories that the user has access to through being a member of an organization. This includes every repository on every team that the user is on. */
    affiliation?: string | undefined;
    /** Limit results to repositories of the specified type. Will cause a `422` error if used in the same request as **visibility** or **affiliation**. */
    type?: ListForAuthenticatedUserRequestType | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListForAuthenticatedUserRequestSort | (string & {}) | undefined;
    /** The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. */
    direction?: ListForAuthenticatedUserRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** Only show repositories updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** Only show repositories updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    before?: string | undefined;
}
export type ListForAuthenticatedUserResponseBodyList = Array<Repository>;
export type ListForAuthenticatedUserResponse = ListForAuthenticatedUserResponseBodyList;
export type ListForksRequestSort = "newest" | "oldest" | "stargazers" | "watchers";
export interface ListForksRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The sort order. `stargazers` will sort by star count. */
    sort?: ListForksRequestSort | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForksResponseBodyList = Array<MinimalRepository>;
export type ListForksResponse = ListForksResponseBodyList;
export type ListForOrgRequestType = "all" | "public" | "private" | "forks" | "sources" | "member";
export type ListForOrgRequestSort = "created" | "updated" | "pushed" | "full_name";
export type ListForOrgRequestDirection = "asc" | "desc";
export interface ListForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Specifies the types of repositories you want returned. */
    type?: ListForOrgRequestType | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListForOrgRequestSort | (string & {}) | undefined;
    /** The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. */
    direction?: ListForOrgRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForOrgResponseBodyList = Array<MinimalRepository>;
export type ListForOrgResponse = ListForOrgResponseBodyList;
export type ListForUserRequestType = "all" | "owner" | "member";
export type ListForUserRequestSort = "created" | "updated" | "pushed" | "full_name";
export type ListForUserRequestDirection = "asc" | "desc";
export interface ListForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** Limit results to repositories of the specified type. */
    type?: ListForUserRequestType | (string & {}) | undefined;
    /** The property to sort the results by. */
    sort?: ListForUserRequestSort | (string & {}) | undefined;
    /** The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. */
    direction?: ListForUserRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListForUserResponseBodyList = Array<MinimalRepository>;
export type ListForUserResponse = ListForUserResponseBodyList;
export interface ListInvitationsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListInvitationsResponseBodyList = Array<RepositoryInvitation>;
export type ListInvitationsResponse = ListInvitationsResponseBodyList;
export interface ListInvitationsForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListInvitationsForAuthenticatedUserResponseBodyList = Array<RepositoryInvitation>;
export type ListInvitationsForAuthenticatedUserResponse = ListInvitationsForAuthenticatedUserResponseBodyList;
export interface ListIssueTypesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** The color of the issue type. */
export type IssueTypeColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type assigned to the issue. This is only present for issues in repositories where issue types are supported. */
export interface IssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The description of the issue type. */
    description: string | null;
    /** The color of the issue type. */
    color?: IssueTypeColor | null | undefined;
    /** The time the issue type created. */
    created_at?: string | undefined;
    /** The time the issue type last updated. */
    updated_at?: string | undefined;
    /** The enabled state of the issue type. */
    is_enabled?: boolean | undefined;
}
export type ListIssueTypesResponseBodyList = Array<IssueType | null>;
export type ListIssueTypesResponse = ListIssueTypesResponseBodyList;
export interface ListLanguagesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Language */
export type Language = {
    [key: string]: number | undefined;
};
export type ListLanguagesResponse = Language;
export interface ListPagesBuildsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPagesBuildsResponseBodyList = Array<PageBuild>;
export type ListPagesBuildsResponse = ListPagesBuildsResponseBodyList;
export interface ListPublicRequest {
    /** A repository ID. Only return repositories with an ID greater than this ID. */
    since?: number | undefined;
}
export type ListPublicResponseBodyList = Array<MinimalRepository>;
export type ListPublicResponse = ListPublicResponseBodyList;
export interface ListPullRequestsAssociatedWithCommitRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SHA of the commit. */
    commit_sha: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export interface PullRequestSimpleLabelsItem {
    id: number;
    node_id: string;
    url: string;
    name: string;
    description: string;
    color: string;
    default: boolean;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: SimpleUser | null;
}
export type PullRequestSimpleLabelsList = Array<PullRequestSimpleLabelsItem>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: SimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export type PullRequestSimpleAssigneesList = Array<SimpleUser>;
export type PullRequestSimpleRequestedReviewersList = Array<SimpleUser>;
export type PullRequestSimpleRequestedTeamsList = Array<Team>;
export interface PullRequestSimpleHead {
    label: string;
    ref: string;
    repo: Repository;
    sha: string;
    user: SimpleUser | null;
}
export type PullRequestSimpleBase = PullRequestSimpleHead;
/** Hypermedia Link */
export interface Link {
    href: string;
}
export interface PullRequestSimpleLinks {
    comments: Link;
    commits: Link;
    statuses: Link;
    html: Link;
    issue: Link;
    review_comments: Link;
    review_comment: Link;
    self: Link;
}
/** The merge method to use. */
export type AutoMergeMergeMethod = "merge" | "squash" | "rebase";
/** The status of auto merging a pull request. */
export interface AutoMerge {
    enabled_by: SimpleUser;
    /** The merge method to use. */
    merge_method: AutoMergeMergeMethod;
    /** Title for the merge commit message. */
    commit_title: string;
    /** Commit message for the merge commit. */
    commit_message: string;
}
export interface PullRequestStackBase {
    /** The base ref of the stack this pull request belongs to. */
    ref: string;
    /** The base SHA of the stack this pull request belongs to. */
    sha: string;
}
/** The stack information associated with a pull request. */
export interface PullRequestStack {
    base: PullRequestStackBase;
    /** The total number of pull requests in the stack. */
    size?: number | undefined;
    /** The one-based position of this pull request within the stack, where 1 is the bottom of the stack. */
    position?: number | undefined;
    /** The ID of the stack that this pull request belongs to. */
    id?: number | undefined;
    /** The number of the stack that this pull request belongs to. */
    number?: number | undefined;
}
/** Pull Request Simple */
export interface PullRequestSimple {
    url: string;
    id: number;
    node_id: string;
    html_url: string;
    diff_url: string;
    patch_url: string;
    issue_url: string;
    commits_url: string;
    review_comments_url: string;
    review_comment_url: string;
    comments_url: string;
    statuses_url: string;
    number: number;
    state: string;
    locked: boolean;
    title: string;
    user: SimpleUser | null;
    body: string | null;
    labels: PullRequestSimpleLabelsList;
    milestone: NullableMilestone | null;
    active_lock_reason?: string | null | undefined;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    merged_at: string | null;
    merge_commit_sha: string | null;
    assignee: SimpleUser | null;
    assignees?: PullRequestSimpleAssigneesList | undefined;
    requested_reviewers?: PullRequestSimpleRequestedReviewersList | undefined;
    requested_teams?: PullRequestSimpleRequestedTeamsList | undefined;
    head: PullRequestSimpleHead;
    base: PullRequestSimpleHead;
    _links: PullRequestSimpleLinks;
    author_association: AuthorAssociation;
    auto_merge: AutoMerge | null;
    stack?: PullRequestStack | null | undefined;
    /** Indicates whether or not the pull request is a draft. */
    draft?: boolean | undefined;
}
export type ListPullRequestsAssociatedWithCommitResponseBodyList = Array<PullRequestSimple>;
export type ListPullRequestsAssociatedWithCommitResponse = ListPullRequestsAssociatedWithCommitResponseBodyList;
export interface ListReleaseAssetsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReleaseAssetsResponseBodyList = Array<ReleaseAsset>;
export type ListReleaseAssetsResponse = ListReleaseAssetsResponseBodyList;
export interface ListReleasesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReleasesResponseBodyList = Array<Release>;
export type ListReleasesResponse = ListReleasesResponseBodyList;
export interface ListTagsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type TagCommit = CommitCommitTree;
/** Tag */
export interface Tag {
    name: string;
    commit: CommitCommitTree;
    zipball_url: string;
    tarball_url: string;
    node_id: string;
}
export type ListTagsResponseBodyList = Array<Tag>;
export type ListTagsResponse = ListTagsResponseBodyList;
export interface ListTeamsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListTeamsResponseBodyList = Array<Team>;
export type ListTeamsResponse = ListTeamsResponseBodyList;
export type ListWebhookDeliveriesRequestStatus = "success" | "failure";
export interface ListWebhookDeliveriesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors. */
    cursor?: string | undefined;
    /** Returns webhook deliveries filtered by delivery outcome classification based on `status_code` range. A `status` of `success` returns deliveries with a `status_code` in the 200-399 range (inclusive). A `status` of `failure` returns deliveries with a `status_code` in the 400-599 range (inclusive). */
    status?: ListWebhookDeliveriesRequestStatus | (string & {}) | undefined;
}
/** Delivery made by a webhook, without request and response information. */
export interface HookDeliveryItem {
    /** Unique identifier of the webhook delivery. */
    id: number;
    /** Unique identifier for the event (shared with all deliveries for all webhooks that subscribe to this event). */
    guid: string;
    /** Time when the webhook delivery occurred. */
    delivered_at: string;
    /** Whether the webhook delivery is a redelivery. */
    redelivery: boolean;
    /** Time spent delivering. */
    duration: number;
    /** Describes the response returned after attempting the delivery. */
    status: string;
    /** Status code received when delivery was made. */
    status_code: number;
    /** The event that triggered the delivery. */
    event: string;
    /** The type of activity for the event that triggered the delivery. */
    action: string | null;
    /** The id of the GitHub App installation associated with this event. */
    installation_id: number | null;
    /** The id of the repository associated with this event. */
    repository_id: number | null;
    /** Time when the webhook delivery was throttled. */
    throttled_at?: string | null | undefined;
}
export type ListWebhookDeliveriesResponseBodyList = Array<HookDeliveryItem>;
export type ListWebhookDeliveriesResponse = ListWebhookDeliveriesResponseBodyList;
export interface ListWebhooksRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListWebhooksResponseBodyList = Array<Hook>;
export type ListWebhooksResponse = ListWebhooksResponseBodyList;
export interface MergeRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the base branch that the head will be merged into. */
    base: string;
    /** The head to merge. This can be a branch name or a commit SHA1. */
    head: string;
    /** Commit message to use for the merge commit. If omitted, a default message will be used. */
    commit_message?: string | undefined;
}
export interface MergeUpstreamRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch which should be updated to match upstream. */
    branch: string;
}
export type MergedUpstreamMergeType = "merge" | "fast-forward" | "none";
/** Results of a successful merge upstream request */
export interface MergedUpstream {
    message?: string | undefined;
    merge_type?: MergedUpstreamMergeType | undefined;
    base_branch?: string | undefined;
}
export interface PingWebhookRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface PingWebhookResponse {
}
export interface RedeliverWebhookDeliveryRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    delivery_id: number;
}
export interface RedeliverWebhookDeliveryResponse {
}
/** The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items. */
export type RemoveAppAccessRestrictionsRequestAppsList = Array<string>;
export interface RemoveAppAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items. */
    apps: RemoveAppAccessRestrictionsRequestAppsList;
}
export type RemoveAppAccessRestrictionsResponseBodyList = Array<Integration | null>;
export type RemoveAppAccessRestrictionsResponse = RemoveAppAccessRestrictionsResponseBodyList;
export interface RemoveCollaboratorRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The handle for the GitHub user account. */
    username: string;
}
export interface RemoveCollaboratorResponse {
}
/** The name of the status checks */
export type RemoveStatusCheckContextsRequestBodyCase0ContextsList = Array<string>;
export interface RemoveStatusCheckContextsRequestBodyCase0 {
    /** The name of the status checks */
    contexts: RemoveStatusCheckContextsRequestBodyCase0ContextsList;
}
/** The name of the status checks */
export type RemoveStatusCheckContextsRequestBodyCase1List = Array<string>;
export type RemoveStatusCheckContextsRequestBody = RemoveStatusCheckContextsRequestBodyCase0 | RemoveStatusCheckContextsRequestBodyCase1List;
export interface RemoveStatusCheckContextsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    body?: RemoveStatusCheckContextsRequestBody | undefined;
}
export type RemoveStatusCheckContextsResponseBodyList = Array<string>;
export type RemoveStatusCheckContextsResponse = RemoveStatusCheckContextsResponseBodyList;
export interface RemoveStatusCheckProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
export interface RemoveStatusCheckProtectionResponse {
}
/** The slug values for teams */
export type RemoveTeamAccessRestrictionsRequestBodyCase0TeamsList = Array<string>;
export interface RemoveTeamAccessRestrictionsRequestBodyCase0 {
    /** The slug values for teams */
    teams: RemoveTeamAccessRestrictionsRequestBodyCase0TeamsList;
}
/** The slug values for teams */
export type RemoveTeamAccessRestrictionsRequestBodyCase1List = Array<string>;
export type RemoveTeamAccessRestrictionsRequestBody = RemoveTeamAccessRestrictionsRequestBodyCase0 | RemoveTeamAccessRestrictionsRequestBodyCase1List;
export interface RemoveTeamAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    body?: RemoveTeamAccessRestrictionsRequestBody | undefined;
}
export type RemoveTeamAccessRestrictionsResponseBodyList = Array<Team>;
export type RemoveTeamAccessRestrictionsResponse = RemoveTeamAccessRestrictionsResponseBodyList;
/** The username for users */
export type RemoveUserAccessRestrictionsRequestUsersList = Array<string>;
export interface RemoveUserAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The username for users */
    users: RemoveUserAccessRestrictionsRequestUsersList;
}
export type RemoveUserAccessRestrictionsResponseBodyList = Array<SimpleUser>;
export type RemoveUserAccessRestrictionsResponse = RemoveUserAccessRestrictionsResponseBodyList;
export interface RenameBranchRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The new name of the branch. */
    new_name: string;
}
/** An array of topics to add to the repository. Pass one or more topics to _replace_ the set of existing topics. Send an empty array (`[]`) to clear all topics from the repository. **Note:** Topic `names` will be saved as lowercase. */
export type ReplaceAllTopicsRequestNamesList = Array<string>;
export interface ReplaceAllTopicsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** An array of topics to add to the repository. Pass one or more topics to _replace_ the set of existing topics. Send an empty array (`[]`) to clear all topics from the repository. **Note:** Topic `names` will be saved as lowercase. */
    names: ReplaceAllTopicsRequestNamesList;
}
export interface RequestPagesBuildRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Page Build Status */
export interface PageBuildStatus {
    url: string;
    status: string;
}
export interface SetAdminBranchProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
}
/** The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items. */
export type SetAppAccessRestrictionsRequestAppsList = Array<string>;
export interface SetAppAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items. */
    apps: SetAppAccessRestrictionsRequestAppsList;
}
export type SetAppAccessRestrictionsResponseBodyList = Array<Integration | null>;
export type SetAppAccessRestrictionsResponse = SetAppAccessRestrictionsResponseBodyList;
/** The name of the status checks */
export type SetStatusCheckContextsRequestBodyCase0ContextsList = Array<string>;
export interface SetStatusCheckContextsRequestBodyCase0 {
    /** The name of the status checks */
    contexts: SetStatusCheckContextsRequestBodyCase0ContextsList;
}
/** The name of the status checks */
export type SetStatusCheckContextsRequestBodyCase1List = Array<string>;
export type SetStatusCheckContextsRequestBody = SetStatusCheckContextsRequestBodyCase0 | SetStatusCheckContextsRequestBodyCase1List;
export interface SetStatusCheckContextsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    body?: SetStatusCheckContextsRequestBody | undefined;
}
export type SetStatusCheckContextsResponseBodyList = Array<string>;
export type SetStatusCheckContextsResponse = SetStatusCheckContextsResponseBodyList;
/** The slug values for teams */
export type SetTeamAccessRestrictionsRequestBodyCase0TeamsList = Array<string>;
export interface SetTeamAccessRestrictionsRequestBodyCase0 {
    /** The slug values for teams */
    teams: SetTeamAccessRestrictionsRequestBodyCase0TeamsList;
}
/** The slug values for teams */
export type SetTeamAccessRestrictionsRequestBodyCase1List = Array<string>;
export type SetTeamAccessRestrictionsRequestBody = SetTeamAccessRestrictionsRequestBodyCase0 | SetTeamAccessRestrictionsRequestBodyCase1List;
export interface SetTeamAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    body?: SetTeamAccessRestrictionsRequestBody | undefined;
}
export type SetTeamAccessRestrictionsResponseBodyList = Array<Team>;
export type SetTeamAccessRestrictionsResponse = SetTeamAccessRestrictionsResponseBodyList;
/** The username for users */
export type SetUserAccessRestrictionsRequestUsersList = Array<string>;
export interface SetUserAccessRestrictionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** The username for users */
    users: SetUserAccessRestrictionsRequestUsersList;
}
export type SetUserAccessRestrictionsResponseBodyList = Array<SimpleUser>;
export type SetUserAccessRestrictionsResponse = SetUserAccessRestrictionsResponseBodyList;
export interface TestPushWebhookRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
}
export interface TestPushWebhookResponse {
}
/** ID of the team or teams to add to the repository. Teams can only be added to organization-owned repositories. */
export type TransferRequestTeamIdsList = Array<number>;
export interface TransferRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The username or organization name the repository will be transferred to. */
    new_owner: string;
    /** The new name to be given to the repository. */
    new_name?: string | undefined;
    /** ID of the team or teams to add to the repository. Teams can only be added to organization-owned repositories. */
    team_ids?: TransferRequestTeamIdsList | undefined;
}
export interface TransferResponse {
}
/** The visibility of the repository. */
export type UpdateRequestVisibility = "public" | "private";
/** Use the `status` property to enable or disable GitHub Advanced Security for this repository. For more information, see "[About GitHub Advanced Security](/github/getting-started-with-github/learning-about-github/about-github-advanced-security)." For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface UpdateRequestSecurityAndAnalysisAdvancedSecurity {
    /** Can be `enabled` or `disabled`. */
    status?: string | undefined;
}
/** Use the `status` property to enable or disable GitHub Code Security for this repository. */
export type UpdateRequestSecurityAndAnalysisCodeSecurity = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** Use the `status` property to enable or disable secret scanning for this repository. For more information, see "[About secret scanning](/code-security/secret-security/about-secret-scanning)." */
export type UpdateRequestSecurityAndAnalysisSecretScanning = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** Use the `status` property to enable or disable secret scanning push protection for this repository. For more information, see "[Protecting pushes with secret scanning](/code-security/secret-scanning/protecting-pushes-with-secret-scanning)." */
export type UpdateRequestSecurityAndAnalysisSecretScanningPushProtection = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** Use the `status` property to enable or disable secret scanning AI detection for this repository. For more information, see "[Responsible detection of generic secrets with AI](https://docs.github.com/code-security/secret-scanning/using-advanced-secret-scanning-and-push-protection-features/generic-secret-detection/responsible-ai-generic-secrets)." */
export type UpdateRequestSecurityAndAnalysisSecretScanningAiDetection = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** Use the `status` property to enable or disable secret scanning non-provider patterns for this repository. For more information, see "[Supported secret scanning patterns](/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)." */
export type UpdateRequestSecurityAndAnalysisSecretScanningNonProviderPatterns = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** Use the `status` property to enable or disable secret scanning delegated alert dismissal for this repository. */
export type UpdateRequestSecurityAndAnalysisSecretScanningDelegatedAlertDismissal = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** Use the `status` property to enable or disable secret scanning delegated bypass for this repository. */
export type UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypass = UpdateRequestSecurityAndAnalysisAdvancedSecurity;
/** The type of the bypass reviewer */
export type UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType | (string & {});
    /** The bypass mode for the reviewer */
    mode?: UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | (string & {}) | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass. If you omit this field, the existing set of reviewers is unchanged. */
export type UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
/** Feature options for secret scanning delegated bypass. This object is only honored when `security_and_analysis.secret_scanning_delegated_bypass.status` is set to `enabled`. You can send this object in the same request as `secret_scanning_delegated_bypass`, or update just the options in a separate request. */
export interface UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass. If you omit this field, the existing set of reviewers is unchanged. */
    reviewers?: UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
/** Specify which security and analysis features to enable or disable for the repository. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." For example, to enable GitHub Advanced Security, use this data in the body of the `PATCH` request: `{ "security_and_analysis": {"advanced_security": { "status": "enabled" } } }`. You can check which security and analysis features are currently enabled by using a `GET /repos/{owner}/{repo}` request. */
export interface UpdateRequestSecurityAndAnalysis {
    /** Use the `status` property to enable or disable GitHub Advanced Security for this repository. For more information, see "[About GitHub Advanced Security](/github/getting-started-with-github/learning-about-github/about-github-advanced-security)." For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable GitHub Code Security for this repository. */
    code_security?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable secret scanning for this repository. For more information, see "[About secret scanning](/code-security/secret-security/about-secret-scanning)." */
    secret_scanning?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable secret scanning push protection for this repository. For more information, see "[Protecting pushes with secret scanning](/code-security/secret-scanning/protecting-pushes-with-secret-scanning)." */
    secret_scanning_push_protection?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable secret scanning AI detection for this repository. For more information, see "[Responsible detection of generic secrets with AI](https://docs.github.com/code-security/secret-scanning/using-advanced-secret-scanning-and-push-protection-features/generic-secret-detection/responsible-ai-generic-secrets)." */
    secret_scanning_ai_detection?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable secret scanning non-provider patterns for this repository. For more information, see "[Supported secret scanning patterns](/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)." */
    secret_scanning_non_provider_patterns?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable secret scanning delegated alert dismissal for this repository. */
    secret_scanning_delegated_alert_dismissal?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Use the `status` property to enable or disable secret scanning delegated bypass for this repository. */
    secret_scanning_delegated_bypass?: UpdateRequestSecurityAndAnalysisAdvancedSecurity | undefined;
    /** Feature options for secret scanning delegated bypass. This object is only honored when `security_and_analysis.secret_scanning_delegated_bypass.status` is set to `enabled`. You can send this object in the same request as `secret_scanning_delegated_bypass`, or update just the options in a separate request. */
    secret_scanning_delegated_bypass_options?: UpdateRequestSecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The policy that controls who can create pull requests for this repository: `all` or `collaborators_only`. */
export type UpdateRequestPullRequestCreationPolicy = "all" | "collaborators_only";
/** Required when using `squash_merge_commit_message`. The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type UpdateRequestSquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type UpdateRequestSquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** Required when using `merge_commit_message`. The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type UpdateRequestMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type UpdateRequestMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
export interface UpdateRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the repository. */
    name?: string | undefined;
    /** A short description of the repository. */
    description?: string | undefined;
    /** A URL with more information about the repository. */
    homepage?: string | undefined;
    /** Either `true` to make the repository private or `false` to make it public. Default: `false`. **Note**: You will get a `422` error if the organization restricts [changing repository visibility](https://docs.github.com/articles/repository-permission-levels-for-an-organization#changing-the-visibility-of-repositories) to organization owners and a non-owner tries to change the value of private. */
    private?: boolean | undefined;
    /** The visibility of the repository. */
    visibility?: UpdateRequestVisibility | (string & {}) | undefined;
    /** Specify which security and analysis features to enable or disable for the repository. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." For example, to enable GitHub Advanced Security, use this data in the body of the `PATCH` request: `{ "security_and_analysis": {"advanced_security": { "status": "enabled" } } }`. You can check which security and analysis features are currently enabled by using a `GET /repos/{owner}/{repo}` request. */
    security_and_analysis?: UpdateRequestSecurityAndAnalysis | null | undefined;
    /** Either `true` to enable issues for this repository or `false` to disable them. */
    has_issues?: boolean | undefined;
    /** Either `true` to enable projects for this repository or `false` to disable them. **Note:** If you're creating a repository in an organization that has disabled repository projects, the default is `false`, and if you pass `true`, the API returns an error. */
    has_projects?: boolean | undefined;
    /** Either `true` to enable the wiki for this repository or `false` to disable it. */
    has_wiki?: boolean | undefined;
    /** Either `true` to allow pull requests for this repository or `false` to prevent pull requests. */
    has_pull_requests?: boolean | undefined;
    /** The policy that controls who can create pull requests for this repository: `all` or `collaborators_only`. */
    pull_request_creation_policy?: UpdateRequestPullRequestCreationPolicy | (string & {}) | undefined;
    /** Either `true` to make this repo available as a template repository or `false` to prevent it. */
    is_template?: boolean | undefined;
    /** Updates the default branch for this repository. */
    default_branch?: string | undefined;
    /** Either `true` to allow squash-merging pull requests, or `false` to prevent squash-merging. */
    allow_squash_merge?: boolean | undefined;
    /** Either `true` to allow merging pull requests with a merge commit, or `false` to prevent merging pull requests with merge commits. */
    allow_merge_commit?: boolean | undefined;
    /** Either `true` to allow rebase-merging pull requests, or `false` to prevent rebase-merging. */
    allow_rebase_merge?: boolean | undefined;
    /** Either `true` to allow auto-merge on pull requests, or `false` to disallow auto-merge. */
    allow_auto_merge?: boolean | undefined;
    /** Either `true` to allow automatically deleting head branches when pull requests are merged, or `false` to prevent automatic deletion. */
    delete_branch_on_merge?: boolean | undefined;
    /** Either `true` to always allow a pull request head branch that is behind its base branch to be updated even if it is not required to be up to date before merging, or false otherwise. */
    allow_update_branch?: boolean | undefined;
    /** Either `true` to allow squash-merge commits to use pull request title, or `false` to use commit message. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** Required when using `squash_merge_commit_message`. The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: UpdateRequestSquashMergeCommitTitle | (string & {}) | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: UpdateRequestSquashMergeCommitMessage | (string & {}) | undefined;
    /** Required when using `merge_commit_message`. The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: UpdateRequestMergeCommitTitle | (string & {}) | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: UpdateRequestMergeCommitMessage | (string & {}) | undefined;
    /** Whether to archive this repository. `false` will unarchive a previously archived repository. */
    archived?: boolean | undefined;
    /** Either `true` to allow private forks, or `false` to prevent private forks. */
    allow_forking?: boolean | undefined;
    /** Either `true` to require contributors to sign off on web-based commits, or `false` to not require contributors to sign off on web-based commits. */
    web_commit_signoff_required?: boolean | undefined;
    /** Whether GitHub Discussions are enabled for the repository. */
    has_discussions?: boolean | undefined;
}
/** **Closing down notice**: The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control. */
export type UpdateBranchProtectionRequestRequiredStatusChecksContextsList = Array<string>;
export interface UpdateBranchProtectionRequestRequiredStatusChecksChecksItem {
    /** The name of the required check */
    context: string;
    /** The ID of the GitHub App that must provide this check. Omit this field to automatically select the GitHub App that has recently provided this check, or any app if it was not set by a GitHub App. Pass -1 to explicitly allow any app to set the status. */
    app_id?: number | undefined;
}
/** The list of status checks to require in order to merge into this branch. */
export type UpdateBranchProtectionRequestRequiredStatusChecksChecksList = Array<UpdateBranchProtectionRequestRequiredStatusChecksChecksItem>;
/** Require status checks to pass before merging. Set to `null` to disable. */
export interface UpdateBranchProtectionRequestRequiredStatusChecks {
    /** Require branches to be up to date before merging. */
    strict: boolean;
    /** **Closing down notice**: The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control. */
    contexts?: UpdateBranchProtectionRequestRequiredStatusChecksContextsList | undefined;
    /** The list of status checks to require in order to merge into this branch. */
    checks?: UpdateBranchProtectionRequestRequiredStatusChecksChecksList | undefined;
}
/** The list of user `login`s with dismissal access */
export type UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictionsUsersList = Array<string>;
/** The list of team `slug`s with dismissal access */
export type UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictionsTeamsList = Array<string>;
/** The list of app `slug`s with dismissal access */
export type UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictionsAppsList = Array<string>;
/** Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories. */
export interface UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictions {
    /** The list of user `login`s with dismissal access */
    users?: UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictionsUsersList | undefined;
    /** The list of team `slug`s with dismissal access */
    teams?: UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictionsTeamsList | undefined;
    /** The list of app `slug`s with dismissal access */
    apps?: UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictionsAppsList | undefined;
}
/** The list of user `login`s allowed to bypass pull request requirements. */
export type UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowancesUsersList = Array<string>;
/** The list of team `slug`s allowed to bypass pull request requirements. */
export type UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowancesTeamsList = Array<string>;
/** The list of app `slug`s allowed to bypass pull request requirements. */
export type UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowancesAppsList = Array<string>;
/** Allow specific users, teams, or apps to bypass pull request requirements. */
export interface UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowances {
    /** The list of user `login`s allowed to bypass pull request requirements. */
    users?: UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowancesUsersList | undefined;
    /** The list of team `slug`s allowed to bypass pull request requirements. */
    teams?: UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowancesTeamsList | undefined;
    /** The list of app `slug`s allowed to bypass pull request requirements. */
    apps?: UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowancesAppsList | undefined;
}
/** Require at least one approving review on a pull request, before merging. Set to `null` to disable. */
export interface UpdateBranchProtectionRequestRequiredPullRequestReviews {
    /** Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories. */
    dismissal_restrictions?: UpdateBranchProtectionRequestRequiredPullRequestReviewsDismissalRestrictions | undefined;
    /** Set to `true` if you want to automatically dismiss approving reviews when someone pushes a new commit. */
    dismiss_stale_reviews?: boolean | undefined;
    /** Blocks merging pull requests until [code owners](https://docs.github.com/articles/about-code-owners/) review them. */
    require_code_owner_reviews?: boolean | undefined;
    /** Specify the number of reviewers required to approve pull requests. Use a number between 1 and 6 or 0 to not require reviewers. */
    required_approving_review_count?: number | undefined;
    /** Whether the most recent push must be approved by someone other than the person who pushed it. Default: `false`. */
    require_last_push_approval?: boolean | undefined;
    /** Allow specific users, teams, or apps to bypass pull request requirements. */
    bypass_pull_request_allowances?: UpdateBranchProtectionRequestRequiredPullRequestReviewsBypassPullRequestAllowances | undefined;
}
/** The list of user `login`s with push access */
export type UpdateBranchProtectionRequestRestrictionsUsersList = Array<string>;
/** The list of team `slug`s with push access */
export type UpdateBranchProtectionRequestRestrictionsTeamsList = Array<string>;
/** The list of app `slug`s with push access */
export type UpdateBranchProtectionRequestRestrictionsAppsList = Array<string>;
/** Restrict who can push to the protected branch. User, app, and team `restrictions` are only available for organization-owned repositories. Set to `null` to disable. */
export interface UpdateBranchProtectionRequestRestrictions {
    /** The list of user `login`s with push access */
    users: UpdateBranchProtectionRequestRestrictionsUsersList;
    /** The list of team `slug`s with push access */
    teams: UpdateBranchProtectionRequestRestrictionsTeamsList;
    /** The list of app `slug`s with push access */
    apps?: UpdateBranchProtectionRequestRestrictionsAppsList | undefined;
}
export interface UpdateBranchProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** Require status checks to pass before merging. Set to `null` to disable. */
    required_status_checks: UpdateBranchProtectionRequestRequiredStatusChecks | null;
    /** Enforce all configured restrictions for administrators. Set to `true` to enforce required status checks for repository administrators. Set to `null` to disable. */
    enforce_admins: boolean | null;
    /** Require at least one approving review on a pull request, before merging. Set to `null` to disable. */
    required_pull_request_reviews: UpdateBranchProtectionRequestRequiredPullRequestReviews | null;
    /** Restrict who can push to the protected branch. User, app, and team `restrictions` are only available for organization-owned repositories. Set to `null` to disable. */
    restrictions: UpdateBranchProtectionRequestRestrictions | null;
    /** Enforces a linear commit Git history, which prevents anyone from pushing merge commits to a branch. Set to `true` to enforce a linear commit history. Set to `false` to disable a linear commit Git history. Your repository must allow squash merging or rebase merging before you can enable a linear commit history. Default: `false`. For more information, see "[Requiring a linear commit history](https://docs.github.com/github/administering-a-repository/requiring-a-linear-commit-history)" in the GitHub Help documentation. */
    required_linear_history?: boolean | undefined;
    /** Permits force pushes to the protected branch by anyone with write access to the repository. Set to `true` to allow force pushes. Set to `false` or `null` to block force pushes. Default: `false`. For more information, see "[Enabling force pushes to a protected branch](https://docs.github.com/github/administering-a-repository/enabling-force-pushes-to-a-protected-branch)" in the GitHub Help documentation." */
    allow_force_pushes?: boolean | null | undefined;
    /** Allows deletion of the protected branch by anyone with write access to the repository. Set to `false` to prevent deletion of the protected branch. Default: `false`. For more information, see "[Enabling force pushes to a protected branch](https://docs.github.com/github/administering-a-repository/enabling-force-pushes-to-a-protected-branch)" in the GitHub Help documentation. */
    allow_deletions?: boolean | undefined;
    /** If set to `true`, the `restrictions` branch protection settings which limits who can push will also block pushes which create new branches, unless the push is initiated by a user, team, or app which has the ability to push. Set to `true` to restrict new branch creation. Default: `false`. */
    block_creations?: boolean | undefined;
    /** Requires all conversations on code to be resolved before a pull request can be merged into a branch that matches this rule. Set to `false` to disable. Default: `false`. */
    required_conversation_resolution?: boolean | undefined;
    /** Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. Default: `false`. */
    lock_branch?: boolean | undefined;
    /** Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. Default: `false`. */
    allow_fork_syncing?: boolean | undefined;
}
export type ProtectedBranchRequiredPullRequestReviewsDismissalRestrictionsUsersList = Array<SimpleUser>;
export type ProtectedBranchRequiredPullRequestReviewsDismissalRestrictionsTeamsList = Array<Team>;
export type ProtectedBranchRequiredPullRequestReviewsDismissalRestrictionsAppsList = Array<Integration | null>;
export interface ProtectedBranchRequiredPullRequestReviewsDismissalRestrictions {
    url: string;
    users_url: string;
    teams_url: string;
    users: ProtectedBranchRequiredPullRequestReviewsDismissalRestrictionsUsersList;
    teams: ProtectedBranchRequiredPullRequestReviewsDismissalRestrictionsTeamsList;
    apps?: ProtectedBranchRequiredPullRequestReviewsDismissalRestrictionsAppsList | undefined;
}
export type ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowancesUsersList = Array<SimpleUser>;
export type ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowancesTeamsList = Array<Team>;
export type ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowancesAppsList = Array<Integration | null>;
export interface ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowances {
    users: ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowancesUsersList;
    teams: ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowancesTeamsList;
    apps?: ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowancesAppsList | undefined;
}
export interface ProtectedBranchRequiredPullRequestReviews {
    url: string;
    dismiss_stale_reviews?: boolean | undefined;
    require_code_owner_reviews?: boolean | undefined;
    required_approving_review_count?: number | undefined;
    /** Whether the most recent push must be approved by someone other than the person who pushed it. */
    require_last_push_approval?: boolean | undefined;
    dismissal_restrictions?: ProtectedBranchRequiredPullRequestReviewsDismissalRestrictions | undefined;
    bypass_pull_request_allowances?: ProtectedBranchRequiredPullRequestReviewsBypassPullRequestAllowances | undefined;
}
export type ProtectedBranchRequiredSignatures = BranchProtectionRequiredSignatures;
export type ProtectedBranchEnforceAdmins = BranchProtectionRequiredSignatures;
export interface ProtectedBranchRequiredLinearHistory {
    enabled: boolean;
}
export type ProtectedBranchAllowForcePushes = ProtectedBranchRequiredLinearHistory;
export type ProtectedBranchAllowDeletions = ProtectedBranchRequiredLinearHistory;
export type ProtectedBranchRequiredConversationResolution = BranchProtectionRequiredLinearHistory;
export type ProtectedBranchBlockCreations = ProtectedBranchRequiredLinearHistory;
/** Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. */
export type ProtectedBranchLockBranch = BranchProtectionRequiredLinearHistory;
/** Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. */
export type ProtectedBranchAllowForkSyncing = BranchProtectionRequiredLinearHistory;
/** Branch protections protect branches */
export interface ProtectedBranch {
    url: string;
    required_status_checks?: StatusCheckPolicy | undefined;
    required_pull_request_reviews?: ProtectedBranchRequiredPullRequestReviews | undefined;
    required_signatures?: BranchProtectionRequiredSignatures | undefined;
    enforce_admins?: BranchProtectionRequiredSignatures | undefined;
    required_linear_history?: ProtectedBranchRequiredLinearHistory | undefined;
    allow_force_pushes?: ProtectedBranchRequiredLinearHistory | undefined;
    allow_deletions?: ProtectedBranchRequiredLinearHistory | undefined;
    restrictions?: BranchRestrictionPolicy | undefined;
    required_conversation_resolution?: BranchProtectionRequiredLinearHistory | undefined;
    block_creations?: ProtectedBranchRequiredLinearHistory | undefined;
    /** Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. */
    lock_branch?: BranchProtectionRequiredLinearHistory | undefined;
    /** Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. */
    allow_fork_syncing?: BranchProtectionRequiredLinearHistory | undefined;
}
export interface UpdateCommitCommentRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the comment. */
    comment_id: number;
    /** The contents of the comment */
    body: string;
}
export interface UpdateDeploymentBranchPolicyRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`. */
    environment_name: string;
    /** The unique identifier of the branch policy. */
    branch_policy_id: number;
    /** The name pattern that branches must match in order to deploy to the environment. Wildcard characters will not match `/`. For example, to match branches that begin with `release/` and contain an additional single slash, use `release/*\/*`. For more information about pattern matching syntax, see the [Ruby File.fnmatch documentation](https://ruby-doc.org/core-2.5.1/File.html#method-c-fnmatch). */
    name: string;
}
/** The process by which the GitHub Pages site will be built. `workflow` means that the site is built by a custom GitHub Actions workflow. `legacy` means that the site is built by GitHub when changes are pushed to a specific branch. */
export type UpdateInformationAboutPagesSiteRequestBuildType = "legacy" | "workflow";
/** Update the source for the repository. Must include the branch name, and may optionally specify the subdirectory `/docs`. Possible values are `"gh-pages"`, `"master"`, and `"master /docs"`. */
export type UpdateInformationAboutPagesSiteRequestSourceCase0 = "gh-pages" | "master" | "master /docs";
/** The repository directory that includes the source files for the Pages site. Allowed paths are `/` or `/docs`. */
export type UpdateInformationAboutPagesSiteRequestSourceCase1Path = "/" | "/docs";
/** Update the source for the repository. Must include the branch name and path. */
export interface UpdateInformationAboutPagesSiteRequestSourceCase1 {
    /** The repository branch used to publish your site's source files. */
    branch: string;
    /** The repository directory that includes the source files for the Pages site. Allowed paths are `/` or `/docs`. */
    path: UpdateInformationAboutPagesSiteRequestSourceCase1Path | (string & {});
}
export type UpdateInformationAboutPagesSiteRequestSource = UpdateInformationAboutPagesSiteRequestSourceCase0 | UpdateInformationAboutPagesSiteRequestSourceCase1;
export interface UpdateInformationAboutPagesSiteRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Specify a custom domain for the repository. Sending a `null` value will remove the custom domain. For more about custom domains, see "[Using a custom domain with GitHub Pages](https://docs.github.com/pages/configuring-a-custom-domain-for-your-github-pages-site)." */
    cname?: string | null | undefined;
    /** Specify whether HTTPS should be enforced for the repository. */
    https_enforced?: boolean | undefined;
    /** The process by which the GitHub Pages site will be built. `workflow` means that the site is built by a custom GitHub Actions workflow. `legacy` means that the site is built by GitHub when changes are pushed to a specific branch. */
    build_type?: UpdateInformationAboutPagesSiteRequestBuildType | (string & {}) | undefined;
    source?: UpdateInformationAboutPagesSiteRequestSource | undefined;
}
export interface UpdateInformationAboutPagesSiteResponse {
}
/** The permissions that the associated user will have on the repository. Valid values are `read`, `write`, `maintain`, `triage`, `moderate`, and `admin`. */
export type UpdateInvitationRequestPermissions = "read" | "write" | "maintain" | "triage" | "moderate" | "admin";
export interface UpdateInvitationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the invitation. */
    invitation_id: number;
    /** The permissions that the associated user will have on the repository. Valid values are `read`, `write`, `maintain`, `triage`, `moderate`, and `admin`. */
    permissions?: UpdateInvitationRequestPermissions | (string & {}) | undefined;
}
/** The target of the ruleset */
export type UpdateOrgRulesetRequestTarget = "branch" | "tag" | "push" | "repository";
/** The actors that can bypass the rules in this ruleset */
export type UpdateOrgRulesetRequestBypassActorsList = Array<RepositoryRulesetBypassActor>;
/** An array of rules within the ruleset. */
export type UpdateOrgRulesetRequestRulesList = Array<OrgRules>;
export interface UpdateOrgRulesetRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** The name of the ruleset. */
    name?: string | undefined;
    /** The target of the ruleset */
    target?: UpdateOrgRulesetRequestTarget | (string & {}) | undefined;
    enforcement?: RepositoryRuleEnforcement | (string & {}) | undefined;
    /** The actors that can bypass the rules in this ruleset */
    bypass_actors?: UpdateOrgRulesetRequestBypassActorsList | undefined;
    conditions?: OrgRulesetConditions | undefined;
    /** An array of rules within the ruleset. */
    rules?: UpdateOrgRulesetRequestRulesList | undefined;
}
/** The list of user `login`s with dismissal access */
export type UpdatePullRequestReviewProtectionRequestDismissalRestrictionsUsersList = Array<string>;
/** The list of team `slug`s with dismissal access */
export type UpdatePullRequestReviewProtectionRequestDismissalRestrictionsTeamsList = Array<string>;
/** The list of app `slug`s with dismissal access */
export type UpdatePullRequestReviewProtectionRequestDismissalRestrictionsAppsList = Array<string>;
/** Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories. */
export interface UpdatePullRequestReviewProtectionRequestDismissalRestrictions {
    /** The list of user `login`s with dismissal access */
    users?: UpdatePullRequestReviewProtectionRequestDismissalRestrictionsUsersList | undefined;
    /** The list of team `slug`s with dismissal access */
    teams?: UpdatePullRequestReviewProtectionRequestDismissalRestrictionsTeamsList | undefined;
    /** The list of app `slug`s with dismissal access */
    apps?: UpdatePullRequestReviewProtectionRequestDismissalRestrictionsAppsList | undefined;
}
/** The list of user `login`s allowed to bypass pull request requirements. */
export type UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowancesUsersList = Array<string>;
/** The list of team `slug`s allowed to bypass pull request requirements. */
export type UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowancesTeamsList = Array<string>;
/** The list of app `slug`s allowed to bypass pull request requirements. */
export type UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowancesAppsList = Array<string>;
/** Allow specific users, teams, or apps to bypass pull request requirements. */
export interface UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowances {
    /** The list of user `login`s allowed to bypass pull request requirements. */
    users?: UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowancesUsersList | undefined;
    /** The list of team `slug`s allowed to bypass pull request requirements. */
    teams?: UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowancesTeamsList | undefined;
    /** The list of app `slug`s allowed to bypass pull request requirements. */
    apps?: UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowancesAppsList | undefined;
}
export interface UpdatePullRequestReviewProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories. */
    dismissal_restrictions?: UpdatePullRequestReviewProtectionRequestDismissalRestrictions | undefined;
    /** Set to `true` if you want to automatically dismiss approving reviews when someone pushes a new commit. */
    dismiss_stale_reviews?: boolean | undefined;
    /** Blocks merging pull requests until [code owners](https://docs.github.com/articles/about-code-owners/) have reviewed. */
    require_code_owner_reviews?: boolean | undefined;
    /** Specifies the number of reviewers required to approve pull requests. Use a number between 1 and 6 or 0 to not require reviewers. */
    required_approving_review_count?: number | undefined;
    /** Whether the most recent push must be approved by someone other than the person who pushed it. Default: `false` */
    require_last_push_approval?: boolean | undefined;
    /** Allow specific users, teams, or apps to bypass pull request requirements. */
    bypass_pull_request_allowances?: UpdatePullRequestReviewProtectionRequestBypassPullRequestAllowances | undefined;
}
/** Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. */
export type UpdateReleaseRequestMakeLatest = "true" | "false" | "legacy";
export interface UpdateReleaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
    /** The name of the tag. */
    tag_name?: string | undefined;
    /** Specifies the commitish value that determines where the Git tag is created from. Can be any branch or commit SHA. Unused if the Git tag already exists. Default: the repository's default branch. */
    target_commitish?: string | undefined;
    /** The name of the release. */
    name?: string | undefined;
    /** Text describing the contents of the tag. */
    body?: string | undefined;
    /** `true` makes the release a draft, and `false` publishes the release. */
    draft?: boolean | undefined;
    /** `true` to identify the release as a prerelease, `false` to identify the release as a full release. */
    prerelease?: boolean | undefined;
    /** Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. */
    make_latest?: UpdateReleaseRequestMakeLatest | (string & {}) | undefined;
    /** If specified, a discussion of the specified category is created and linked to the release. The value must be a category that already exists in the repository. If there is already a discussion linked to the release, this parameter is ignored. For more information, see "[Managing categories for discussions in your repository](https://docs.github.com/discussions/managing-discussions-for-your-community/managing-categories-for-discussions-in-your-repository)." */
    discussion_category_name?: string | undefined;
}
export interface UpdateReleaseAssetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the asset. */
    asset_id: number;
    /** The file name of the asset. */
    name?: string | undefined;
    /** An alternate short description of the asset. Used in place of the filename. */
    label?: string | undefined;
    state?: string | undefined;
}
/** The target of the ruleset */
export type UpdateRepoRulesetRequestTarget = "branch" | "tag" | "push";
/** The actors that can bypass the rules in this ruleset */
export type UpdateRepoRulesetRequestBypassActorsList = Array<RepositoryRulesetBypassActor>;
/** An array of rules within the ruleset. */
export type UpdateRepoRulesetRequestRulesList = Array<RepositoryRule>;
export interface UpdateRepoRulesetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the ruleset. */
    ruleset_id: number;
    /** The name of the ruleset. */
    name?: string | undefined;
    /** The target of the ruleset */
    target?: UpdateRepoRulesetRequestTarget | (string & {}) | undefined;
    enforcement?: RepositoryRuleEnforcement | (string & {}) | undefined;
    /** The actors that can bypass the rules in this ruleset */
    bypass_actors?: UpdateRepoRulesetRequestBypassActorsList | undefined;
    conditions?: RepositoryRulesetConditions | undefined;
    /** An array of rules within the ruleset. */
    rules?: UpdateRepoRulesetRequestRulesList | undefined;
}
/** **Closing down notice**: The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control. */
export type UpdateStatusCheckProtectionRequestContextsList = Array<string>;
export type UpdateStatusCheckProtectionRequestChecksItem = UpdateBranchProtectionRequestRequiredStatusChecksChecksItem;
/** The list of status checks to require in order to merge into this branch. */
export type UpdateStatusCheckProtectionRequestChecksList = Array<UpdateBranchProtectionRequestRequiredStatusChecksChecksItem>;
export interface UpdateStatusCheckProtectionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql). */
    branch: string;
    /** Require branches to be up to date before merging. */
    strict?: boolean | undefined;
    /** **Closing down notice**: The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control. */
    contexts?: UpdateStatusCheckProtectionRequestContextsList | undefined;
    /** The list of status checks to require in order to merge into this branch. */
    checks?: UpdateStatusCheckProtectionRequestChecksList | undefined;
}
/** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. This replaces the entire array of events. */
export type UpdateWebhookRequestEventsList = Array<string>;
/** Determines a list of events to be added to the list of events that the Hook triggers for. */
export type UpdateWebhookRequestAddEventsList = Array<string>;
/** Determines a list of events to be removed from the list of events that the Hook triggers for. */
export type UpdateWebhookRequestRemoveEventsList = Array<string>;
export interface UpdateWebhookRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    config?: WebhookConfig | undefined;
    /** Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. This replaces the entire array of events. */
    events?: UpdateWebhookRequestEventsList | undefined;
    /** Determines a list of events to be added to the list of events that the Hook triggers for. */
    add_events?: UpdateWebhookRequestAddEventsList | undefined;
    /** Determines a list of events to be removed from the list of events that the Hook triggers for. */
    remove_events?: UpdateWebhookRequestRemoveEventsList | undefined;
    /** Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. */
    active?: boolean | undefined;
}
export interface UpdateWebhookConfigForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery. */
    hook_id: number;
    url?: string | undefined;
    content_type?: string | undefined;
    secret?: string | Redacted.Redacted<string> | undefined;
    insecure_ssl?: WebhookConfigInsecureSsl | undefined;
}
export interface UploadReleaseAssetRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the release. */
    release_id: number;
    name: string;
    label?: string | undefined;
}
export type AcceptInvitationForAuthenticatedUserError = GithubOpError;
/** Accept a repository invitation */
export declare const acceptInvitationForAuthenticatedUser: API.OperationMethod<AcceptInvitationForAuthenticatedUserRequest, AcceptInvitationForAuthenticatedUserResponse, AcceptInvitationForAuthenticatedUserError, GithubOpContext>;
export type AddAppAccessRestrictionsError = GithubOpError;
/** Add app access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Grants the specified apps push access for this branch. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch. */
export declare const addAppAccessRestrictions: API.OperationMethod<AddAppAccessRestrictionsRequest, AddAppAccessRestrictionsResponse, AddAppAccessRestrictionsError, GithubOpContext>;
export type AddCollaboratorError = GithubOpError;
/** Add a repository collaborator Add a user to a repository with a specified level of access. If the repository is owned by an organization, this API does not add the user to the organization - a user that has repository access without being an organization member is called an "outside collaborator" (if they are not an Enterprise Managed User) or a "repository collaborator" if they are an Enterprise Managed User. These users are exempt from some organization policies - see "[Adding outside collaborators to repositories](https://docs.github.com/organizations/managing-user-access-to-your-organizations-repositories/managing-outside-collaborators/adding-outside-collaborators-to-repositories-in-your-organization)" to learn more about these collaborator types. This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Adding an outside collaborator may be restricted by enterprise and organization administrators. For more information, see "[Enforcing repository management policies in your enterprise](https://docs.github.com/admin/policies/enforcing-policies-for-your-enterprise/enforcing-repository-management-policies-in-your-enterprise#enforcing-a-policy-for-inviting-outside-collaborators-to-repositories)" and "[Setting permissions for adding outside collaborators](https://docs.github.com/organizations/managing-organization-settings/setting-permissions-for-adding-outside-collaborators)" for organization settings. For more information on permission levels, see "[Repository permission levels for an organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/repository-permission-levels-for-an-organization#permission-levels-for-repositories-owned-by-an-organization)". There are restrictions on which permissions can be granted to organization members when an organization base role is in place. In this case, the role being given must be equal to or higher than the org base permission. Otherwise, the request will fail with: ``` Cannot assign {member} permission of {role name} ``` Note that, if you choose not to pass any parameters, you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." The invitee will receive a notification that they have been invited to the repository, which they must accept or decline. They may do this via the notifications page, the email they receive, or by using the [API](https://docs.github.com/rest/collaborators/invitations). For Enterprise Managed Users, this endpoint does not send invitations - these users are automatically added to organizations and repositories. Enterprise Managed Users can only be added to organizations and repositories within their enterprise. **Updating an existing collaborator's permission level** The endpoint can also be used to change the permissions of an existing collaborator without first removing and re-adding the collaborator. To change the permissions, use the same endpoint and pass a different `permission` parameter. The response will be a `204`, with no other indication that the permission level changed. **Rate limits** You are limited to sending 50 invitations to a repository per 24 hour period. Note there is no limit if you are inviting organization members to an organization repository. */
export declare const addCollaborator: API.OperationMethod<AddCollaboratorRequest, RepositoryInvitation, AddCollaboratorError, GithubOpContext>;
export type AddStatusCheckContextsError = GithubOpError;
/** Add status check contexts Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const addStatusCheckContexts: API.OperationMethod<AddStatusCheckContextsRequest, AddStatusCheckContextsResponse, AddStatusCheckContextsError, GithubOpContext>;
export type AddTeamAccessRestrictionsError = GithubOpError;
/** Add team access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Grants the specified teams push access for this branch. You can also give push access to child teams. */
export declare const addTeamAccessRestrictions: API.OperationMethod<AddTeamAccessRestrictionsRequest, AddTeamAccessRestrictionsResponse, AddTeamAccessRestrictionsError, GithubOpContext>;
export type AddUserAccessRestrictionsError = GithubOpError;
/** Add user access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Grants the specified people push access for this branch. */
export declare const addUserAccessRestrictions: API.OperationMethod<AddUserAccessRestrictionsRequest, AddUserAccessRestrictionsResponse, AddUserAccessRestrictionsError, GithubOpContext>;
export type CancelPagesDeploymentError = GithubOpError;
/** Cancel a GitHub Pages deployment Cancels a GitHub Pages deployment. The authenticated user must have write permissions for the GitHub Pages site. */
export declare const cancelPagesDeployment: API.OperationMethod<CancelPagesDeploymentRequest, CancelPagesDeploymentResponse, CancelPagesDeploymentError, GithubOpContext>;
export type CheckAutomatedSecurityFixes2Error = GithubOpError;
/** Check if Dependabot security updates are enabled for a repository Shows whether Dependabot security updates are enabled, disabled or paused for a repository. The authenticated user must have admin read access to the repository. For more information, see "[Configuring Dependabot security updates](https://docs.github.com/articles/configuring-automated-security-fixes)". */
export declare const checkAutomatedSecurityFixes2: API.OperationMethod<CheckAutomatedSecurityFixesRequest, CheckAutomatedSecurityFixes, CheckAutomatedSecurityFixes2Error, GithubOpContext>;
export type CheckCollaboratorError = GithubOpError;
/** Check if a user is a repository collaborator For organization-owned repositories, the list of collaborators includes outside collaborators, organization members that are direct collaborators, organization members with access through team memberships, organization members with access through default organization permissions, and organization owners. Team members will include the members of child teams. The authenticated user must have push access to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `read:org` and `repo` scopes to use this endpoint. */
export declare const checkCollaborator: API.OperationMethod<CheckCollaboratorRequest, CheckCollaboratorResponse, CheckCollaboratorError, GithubOpContext>;
export type CheckImmutableReleases2Error = GithubOpError;
/** Check if immutable releases are enabled for a repository Shows whether immutable releases are enabled or disabled. Also identifies whether immutability is being enforced by the repository owner. The authenticated user must have admin read access to the repository. */
export declare const checkImmutableReleases2: API.OperationMethod<CheckImmutableReleasesRequest, CheckImmutableReleases, CheckImmutableReleases2Error, GithubOpContext>;
export type CheckPrivateVulnerabilityReportingError = GithubOpError;
/** Check if private vulnerability reporting is enabled for a repository Returns a boolean indicating whether or not private vulnerability reporting is enabled for the repository. For more information, see "[Evaluating the security settings of a repository](https://docs.github.com/code-security/security-advisories/working-with-repository-security-advisories/evaluating-the-security-settings-of-a-repository)". */
export declare const checkPrivateVulnerabilityReporting: API.OperationMethod<CheckPrivateVulnerabilityReportingRequest, CheckPrivateVulnerabilityReportingResponse, CheckPrivateVulnerabilityReportingError, GithubOpContext>;
export type CheckVulnerabilityAlertsError = GithubOpError;
/** Check if vulnerability alerts are enabled for a repository Shows whether dependency alerts are enabled or disabled for a repository. The authenticated user must have admin read access to the repository. For more information, see "[About security alerts for vulnerable dependencies](https://docs.github.com/articles/about-security-alerts-for-vulnerable-dependencies)". */
export declare const checkVulnerabilityAlerts: API.OperationMethod<CheckVulnerabilityAlertsRequest, CheckVulnerabilityAlertsResponse, CheckVulnerabilityAlertsError, GithubOpContext>;
export type CodeownersErrors2Error = GithubOpError;
/** List CODEOWNERS errors List any syntax errors that are detected in the CODEOWNERS file. For more information about the correct CODEOWNERS syntax, see "[About code owners](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners)." */
export declare const codeownersErrors2: API.OperationMethod<CodeownersErrorsRequest, CodeownersErrors, CodeownersErrors2Error, GithubOpContext>;
export type CompareCommitsError = GithubOpError;
/** Compare two commits Compares two commits against one another. You can compare refs (branches or tags) and commit SHAs in the same repository, or you can compare refs and commit SHAs that exist in different repositories within the same repository network, including fork branches. For more information about how to view a repository's network, see "[Understanding connections between repositories](https://docs.github.com/repositories/viewing-activity-and-data-for-your-repository/understanding-connections-between-repositories)." This endpoint is equivalent to running the `git log BASE..HEAD` command, but it returns commits in a different order. The `git log BASE..HEAD` command returns commits in reverse chronological order, whereas the API returns commits in chronological order. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.diff`**: Returns the diff of the commit. - **`application/vnd.github.patch`**: Returns the patch of the commit. Diffs with binary data will have no `patch` property. The API response includes details about the files that were changed between the two commits. This includes the status of the change (if a file was added, removed, modified, or renamed), and details of the change itself. For example, files with a `renamed` status have a `previous_filename` field showing the previous filename of the file, and files with a `modified` status have a `patch` field showing the changes made to the file. When calling this endpoint without any paging parameter (`per_page` or `page`), the returned list is limited to 250 commits, and the last commit in the list is the most recent of the entire comparison. **Working with large comparisons** To process a response with a large number of commits, use a query parameter (`per_page` or `page`) to paginate the results. When using pagination: - The list of changed files is only shown on the first page of results, and it includes up to 300 changed files for the entire comparison. - The results are returned in chronological order, but the last commit in the returned list may not be the most recent one in the entire set if there are more pages of results. For more information on working with pagination, see "[Using pagination in the REST API](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api)." **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The `verification` object includes the following fields: These are the possible values for `reason` in the `verification` object: */
export declare const compareCommits: API.OperationMethod<CompareCommitsRequest & {
    readonly accept?: "application/vnd.github+json" | undefined;
}, CommitComparison, CompareCommitsError, GithubOpContext> & API.OperationMethod<CompareCommitsRequest & {
    readonly accept: "application/vnd.github.diff" | "application/vnd.github.patch";
}, string, CompareCommitsError, GithubOpContext>;
export type CreateAttestationError = GithubOpError;
/** Create an attestation Store an artifact attestation and associate it with a repository. The authenticated user must have write permission to the repository and, if using a fine-grained access token, the `attestations:write` permission is required. Artifact attestations are meant to be created using the [attest action](https://github.com/actions/attest). For more information, see our guide on [using artifact attestations to establish a build's provenance](https://docs.github.com/actions/security-guides/using-artifact-attestations-to-establish-provenance-for-builds). */
export declare const createAttestation: API.OperationMethod<CreateAttestationRequest, CreateAttestationResponse, CreateAttestationError, GithubOpContext>;
export type CreateAutolinkError = GithubOpError;
/** Create an autolink reference for a repository Users with admin access to the repository can create an autolink. */
export declare const createAutolink: API.OperationMethod<CreateAutolinkRequest, Autolink, CreateAutolinkError, GithubOpContext>;
export type CreateCommitCommentError = GithubOpError;
/** Create a commit comment Create a comment for a commit using its `:commit_sha`. Access to commit comments can be controlled by organization owners. For more information, see "[Managing commit comments for your organization](https://docs.github.com/organizations/managing-organization-settings/managing-commit-comments-for-your-organization)". This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const createCommitComment: API.OperationMethod<CreateCommitCommentRequest, CommitComment, CreateCommitCommentError, GithubOpContext>;
export type CreateCommitSignatureProtectionError = GithubOpError;
/** Create commit signature protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. When authenticated with admin or owner permissions to the repository, you can use this endpoint to require signed commits on a branch. You must enable branch protection to require signed commits. */
export declare const createCommitSignatureProtection: API.OperationMethod<CreateCommitSignatureProtectionRequest, ProtectedBranchAdminEnforced, CreateCommitSignatureProtectionError, GithubOpContext>;
export type CreateCommitStatusError = GithubOpError;
/** Create a commit status Users with push access in a repository can create commit statuses for a given SHA. Note: there is a limit of 1000 statuses per `sha` and `context` within a repository. Attempts to create more than 1000 statuses will result in a validation error. */
export declare const createCommitStatus: API.OperationMethod<CreateCommitStatusRequest, Status, CreateCommitStatusError, GithubOpContext>;
export type CreateDeployKeyError = GithubOpError;
/** Create a deploy key You can create a read-only deploy key. */
export declare const createDeployKey: API.OperationMethod<CreateDeployKeyRequest, DeployKey, CreateDeployKeyError, GithubOpContext>;
export type CreateDeploymentError = GithubOpError;
/** Create a deployment Deployments offer a few configurable parameters with certain defaults. The `ref` parameter can be any named branch, tag, or SHA. At GitHub we often deploy branches and verify them before we merge a pull request. The `environment` parameter allows deployments to be issued to different runtime environments. Teams often have multiple environments for verifying their applications, such as `production`, `staging`, and `qa`. This parameter makes it easier to track which environments have requested deployments. The default environment is `production`. The `auto_merge` parameter is used to ensure that the requested ref is not behind the repository's default branch. If the ref _is_ behind the default branch for the repository, we will attempt to merge it for you. If the merge succeeds, the API will return a successful merge commit. If merge conflicts prevent the merge from succeeding, the API will return a failure response. By default, [commit statuses](https://docs.github.com/rest/commits/statuses) for every submitted context must be in a `success` state. The `required_contexts` parameter allows you to specify a subset of contexts that must be `success`, or to specify contexts that have not yet been submitted. You are not required to use commit statuses to deploy. If you do not require any contexts or create any commit statuses, the deployment will always succeed. The `payload` parameter is available for any extra information that a deployment system might need. It is a JSON text field that will be passed on when a deployment event is dispatched. The `task` parameter is used by the deployment system to allow different execution paths. In the web world this might be `deploy:migrations` to run schema changes on the system. In the compiled world this could be a flag to compile an application with debugging enabled. Merged branch response: You will see this response when GitHub automatically merges the base branch into the topic branch instead of creating a deployment. This auto-merge happens when: * Auto-merge option is enabled in the repository * Topic branch does not include the latest changes on the base branch, which is `master` in the response example * There are no merge conflicts If there are no new commits in the base branch, a new request to create a deployment should give a successful response. Merge conflict response: This error happens when the `auto_merge` option is enabled and when the default branch (in this case `master`), can't be merged into the branch that's being deployed (in this case `topic-branch`), due to merge conflicts. Failed commit status checks: This error happens when the `required_contexts` parameter indicates that one or more contexts need to have a `success` status for the commit to be deployed, but one or more of the required contexts do not have a state of `success`. OAuth app tokens and personal access tokens (classic) need the `repo` or `repo_deployment` scope to use this endpoint. */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest, Deployment, CreateDeploymentError, GithubOpContext>;
export type CreateDeploymentBranchPolicyError = GithubOpError;
/** Create a deployment branch policy Creates a deployment branch or tag policy for an environment. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createDeploymentBranchPolicy: API.OperationMethod<CreateDeploymentBranchPolicyRequest, DeploymentBranchPolicy, CreateDeploymentBranchPolicyError, GithubOpContext>;
export type CreateDeploymentProtectionRuleError = GithubOpError;
/** Create a custom deployment protection rule on an environment Enable a custom deployment protection rule for an environment. The authenticated user must have admin or owner permissions to the repository to use this endpoint. For more information about the app that is providing this custom deployment rule, see the [documentation for the `GET /apps/{app_slug}` endpoint](https://docs.github.com/rest/apps/apps#get-an-app), as well as the [guide to creating custom deployment protection rules](https://docs.github.com/actions/managing-workflow-runs-and-deployments/managing-deployments/creating-custom-deployment-protection-rules). OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createDeploymentProtectionRule: API.OperationMethod<CreateDeploymentProtectionRuleRequest, DeploymentProtectionRule, CreateDeploymentProtectionRuleError, GithubOpContext>;
export type CreateDeploymentStatusError = GithubOpError;
/** Create a deployment status Users with `push` access can create deployment statuses for a given deployment. OAuth app tokens and personal access tokens (classic) need the `repo_deployment` scope to use this endpoint. */
export declare const createDeploymentStatus: API.OperationMethod<CreateDeploymentStatusRequest, DeploymentStatus, CreateDeploymentStatusError, GithubOpContext>;
export type CreateDispatchEventError = GithubOpError;
/** Create a repository dispatch event You can use this endpoint to trigger a webhook event called `repository_dispatch` when you want activity that happens outside of GitHub to trigger a GitHub Actions workflow or GitHub App webhook. You must configure your GitHub Actions workflow or GitHub App to run when the `repository_dispatch` event occurs. For an example `repository_dispatch` webhook payload, see "[RepositoryDispatchEvent](https://docs.github.com/webhooks/event-payloads/#repository_dispatch)." The `client_payload` parameter is available for any extra information that your workflow might need. This parameter is a JSON payload that will be passed on when the webhook event is dispatched. For example, the `client_payload` can include a message that a user would like to send using a GitHub Actions workflow. Or the `client_payload` can be used as a test to debug your workflow. This input example shows how you can use the `client_payload` as a test to debug your workflow. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createDispatchEvent: API.OperationMethod<CreateDispatchEventRequest, CreateDispatchEventResponse, CreateDispatchEventError, GithubOpContext>;
export type CreateForAuthenticatedUserError = GithubOpError;
/** Create a repository for the authenticated user Creates a new repository for the authenticated user. OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to create a public repository, and `repo` scope to create a private repository. */
export declare const createForAuthenticatedUser: API.OperationMethod<CreateForAuthenticatedUserRequest, FullRepository, CreateForAuthenticatedUserError, GithubOpContext>;
export type CreateForkError = GithubOpError;
/** Create a fork Create a fork for the authenticated user. > [!NOTE] > Forking a Repository happens asynchronously. You may have to wait a short period of time before you can access the git objects. If this takes longer than 5 minutes, be sure to contact [GitHub Support](https://support.github.com/contact?tags=dotcom-rest-api). > [!NOTE] > Although this endpoint works with GitHub Apps, the GitHub App must be installed on the destination account with access to all repositories and on the source account with access to the source repository. */
export declare const createFork: API.OperationMethod<CreateForkRequest, CreateForkResponse, CreateForkError, GithubOpContext>;
export type CreateInOrgError = GithubOpError;
/** Create an organization repository Creates a new repository in the specified organization. The authenticated user must be a member of the organization. OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to create a public repository, and `repo` scope to create a private repository. */
export declare const createInOrg: API.OperationMethod<CreateInOrgRequest, FullRepository, CreateInOrgError, GithubOpContext>;
export type CreateOrgRulesetError = GithubOpError;
/** Create an organization repository ruleset Create a repository ruleset for an organization. */
export declare const createOrgRuleset: API.OperationMethod<CreateOrgRulesetRequest, RepositoryRuleset, CreateOrgRulesetError, GithubOpContext>;
export type CreateOrUpdateEnvironmentError = GithubOpError;
/** Create or update an environment Create or update an environment with protection rules, such as required reviewers. For more information about environment protection rules, see "[Environments](/actions/reference/environments#environment-protection-rules)." > [!NOTE] > To create or update name patterns that branches must match in order to deploy to this environment, see "[Deployment branch policies](/rest/deployments/branch-policies)." > [!NOTE] > To create or update secrets for an environment, see "[GitHub Actions secrets](/rest/actions/secrets)." OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createOrUpdateEnvironment: API.OperationMethod<CreateOrUpdateEnvironmentRequest, Environment, CreateOrUpdateEnvironmentError, GithubOpContext>;
export type CreateOrUpdateFileContentsError = GithubOpError;
/** Create or update file contents Creates a new file or replaces an existing file in a repository. > [!NOTE] > If you use this endpoint and the "[Delete a file](https://docs.github.com/rest/repos/contents/#delete-a-file)" endpoint in parallel, the concurrent requests will conflict and you will receive errors. You must use these endpoints serially instead. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. The `workflow` scope is also required in order to modify files in the `.github/workflows` directory. */
export declare const createOrUpdateFileContents: API.OperationMethod<CreateOrUpdateFileContentsRequest, FileCommit, CreateOrUpdateFileContentsError, GithubOpContext>;
export type CreatePagesDeploymentError = GithubOpError;
/** Create a GitHub Pages deployment Create a GitHub Pages deployment for a repository. The authenticated user must have write permission to the repository. */
export declare const createPagesDeployment: API.OperationMethod<CreatePagesDeploymentRequest, PageDeployment, CreatePagesDeploymentError, GithubOpContext>;
export type CreatePagesSiteError = GithubOpError;
/** Create a GitHub Pages site Configures a GitHub Pages site. For more information, see "[About GitHub Pages](/github/working-with-github-pages/about-github-pages)." The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createPagesSite: API.OperationMethod<CreatePagesSiteRequest, Page, CreatePagesSiteError, GithubOpContext>;
export type CreateReleaseError = GithubOpError;
/** Create a release Users with push access to the repository can create a release. > [!NOTE] > If the commit identified by `target_commitish` (or, when `target_commitish` is omitted, the latest commit on the default branch) adds or modifies any file under `.github/workflows/` relative to the repository's default branch, the authenticating token must be authorized to modify workflows. Otherwise, this endpoint returns `404 Not Found`; some authentication paths surface `403 Resource not accessible by integration` instead. OAuth app tokens and personal access tokens (classic) need the `workflow` scope when the resolved target commit modifies workflow files. Fine-grained access tokens and GitHub App installation tokens also need the "Workflows" repository permission (write). The `GITHUB_TOKEN` available to GitHub Actions cannot be authorized for this; for more information, see "[Automatic token authentication](https://docs.github.com/actions/security-guides/automatic-token-authentication#permissions-for-the-github_token)". This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)." */
export declare const createRelease: API.OperationMethod<CreateReleaseRequest, Release, CreateReleaseError, GithubOpContext>;
export type CreateRepoRulesetError = GithubOpError;
/** Create a repository ruleset Create a ruleset for a repository. */
export declare const createRepoRuleset: API.OperationMethod<CreateRepoRulesetRequest, RepositoryRuleset, CreateRepoRulesetError, GithubOpContext>;
export type CreateUsingTemplateError = GithubOpError;
/** Create a repository using a template Creates a new repository using a repository template. Use the `template_owner` and `template_repo` route parameters to specify the repository to use as the template. If the repository is not public, the authenticated user must own or be a member of an organization that owns the repository. To check if a repository is available to use as a template, get the repository's information using the [Get a repository](https://docs.github.com/rest/repos/repos#get-a-repository) endpoint and check that the `is_template` key is `true`. OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to create a public repository, and `repo` scope to create a private repository. */
export declare const createUsingTemplate: API.OperationMethod<CreateUsingTemplateRequest, FullRepository, CreateUsingTemplateError, GithubOpContext>;
export type CreateWebhookError = GithubOpError;
/** Create a repository webhook Repositories can have multiple webhooks installed. Each webhook should have a unique `config`. Multiple webhooks can share the same `config` as long as those webhooks do not have any `events` that overlap. */
export declare const createWebhook: API.OperationMethod<CreateWebhookRequest, Hook, CreateWebhookError, GithubOpContext>;
export type CustomPropertiesForReposCreateOrUpdateRepositoryValuesError = GithubOpError;
/** Create or update custom property values for a repository Create new or update existing custom property values for a repository. Using a value of `null` for a custom property will remove or 'unset' the property value from the repository. Repository admins and other users with the repository-level "edit custom property values" fine-grained permission can use this endpoint. */
export declare const customPropertiesForReposCreateOrUpdateRepositoryValues: API.OperationMethod<CustomPropertiesForReposCreateOrUpdateRepositoryValuesRequest, CustomPropertiesForReposCreateOrUpdateRepositoryValuesResponse, CustomPropertiesForReposCreateOrUpdateRepositoryValuesError, GithubOpContext>;
export type CustomPropertiesForReposGetRepositoryValuesError = GithubOpError;
/** Get all custom property values for a repository Gets all custom property values that are set for a repository. Users with read access to the repository can use this endpoint. */
export declare const customPropertiesForReposGetRepositoryValues: API.OperationMethod<CustomPropertiesForReposGetRepositoryValuesRequest, CustomPropertiesForReposGetRepositoryValuesResponse, CustomPropertiesForReposGetRepositoryValuesError, GithubOpContext>;
export type DeclineInvitationForAuthenticatedUserError = GithubOpError;
/** Decline a repository invitation */
export declare const declineInvitationForAuthenticatedUser: API.OperationMethod<DeclineInvitationForAuthenticatedUserRequest, DeclineInvitationForAuthenticatedUserResponse, DeclineInvitationForAuthenticatedUserError, GithubOpContext>;
export type DeleteError = GithubOpError;
/** Delete a repository Deleting a repository requires admin access. If an organization owner has configured the organization to prevent members from deleting organization-owned repositories, you will get a `403 Forbidden` response. OAuth app tokens and personal access tokens (classic) need the `delete_repo` scope to use this endpoint. */
export declare const Delete: API.OperationMethod<DeleteRequest, DeleteResponse, DeleteError, GithubOpContext>;
export type DeleteAccessRestrictionsError = GithubOpError;
/** Delete access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Disables the ability to restrict who can push to this branch. */
export declare const deleteAccessRestrictions: API.OperationMethod<DeleteAccessRestrictionsRequest, DeleteAccessRestrictionsResponse, DeleteAccessRestrictionsError, GithubOpContext>;
export type DeleteAdminBranchProtectionError = GithubOpError;
/** Delete admin branch protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Removing admin enforcement requires admin or owner permissions to the repository and branch protection to be enabled. */
export declare const deleteAdminBranchProtection: API.OperationMethod<DeleteAdminBranchProtectionRequest, DeleteAdminBranchProtectionResponse, DeleteAdminBranchProtectionError, GithubOpContext>;
export type DeleteAnEnvironmentError = GithubOpError;
/** Delete an environment OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteAnEnvironment: API.OperationMethod<DeleteAnEnvironmentRequest, DeleteAnEnvironmentResponse, DeleteAnEnvironmentError, GithubOpContext>;
export type DeleteAutolinkError = GithubOpError;
/** Delete an autolink reference from a repository This deletes a single autolink reference by ID that was configured for the given repository. Information about autolinks are only available to repository administrators. */
export declare const deleteAutolink: API.OperationMethod<DeleteAutolinkRequest, DeleteAutolinkResponse, DeleteAutolinkError, GithubOpContext>;
export type DeleteBranchProtectionError = GithubOpError;
/** Delete branch protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const deleteBranchProtection: API.OperationMethod<DeleteBranchProtectionRequest, DeleteBranchProtectionResponse, DeleteBranchProtectionError, GithubOpContext>;
export type DeleteCommitCommentError = GithubOpError;
/** Delete a commit comment */
export declare const deleteCommitComment: API.OperationMethod<DeleteCommitCommentRequest, DeleteCommitCommentResponse, DeleteCommitCommentError, GithubOpContext>;
export type DeleteCommitSignatureProtectionError = GithubOpError;
/** Delete commit signature protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. When authenticated with admin or owner permissions to the repository, you can use this endpoint to disable required signed commits on a branch. You must enable branch protection to require signed commits. */
export declare const deleteCommitSignatureProtection: API.OperationMethod<DeleteCommitSignatureProtectionRequest, DeleteCommitSignatureProtectionResponse, DeleteCommitSignatureProtectionError, GithubOpContext>;
export type DeleteDeployKeyError = GithubOpError;
/** Delete a deploy key Deploy keys are immutable. If you need to update a key, remove the key and create a new one instead. */
export declare const deleteDeployKey: API.OperationMethod<DeleteDeployKeyRequest, DeleteDeployKeyResponse, DeleteDeployKeyError, GithubOpContext>;
export type DeleteDeploymentError = GithubOpError;
/** Delete a deployment If the repository only has one deployment, you can delete the deployment regardless of its status. If the repository has more than one deployment, you can only delete inactive deployments. This ensures that repositories with multiple deployments will always have an active deployment. To set a deployment as inactive, you must: * Create a new deployment that is active so that the system has a record of the current state, then delete the previously active deployment. * Mark the active deployment as inactive by adding any non-successful deployment status. For more information, see "[Create a deployment](https://docs.github.com/rest/deployments/deployments/#create-a-deployment)" and "[Create a deployment status](https://docs.github.com/rest/deployments/statuses#create-a-deployment-status)." OAuth app tokens and personal access tokens (classic) need the `repo` or `repo_deployment` scope to use this endpoint. */
export declare const deleteDeployment: API.OperationMethod<DeleteDeploymentRequest, DeleteDeploymentResponse, DeleteDeploymentError, GithubOpContext>;
export type DeleteDeploymentBranchPolicyError = GithubOpError;
/** Delete a deployment branch policy Deletes a deployment branch or tag policy for an environment. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deleteDeploymentBranchPolicy: API.OperationMethod<DeleteDeploymentBranchPolicyRequest, DeleteDeploymentBranchPolicyResponse, DeleteDeploymentBranchPolicyError, GithubOpContext>;
export type DeleteFileError = GithubOpError;
/** Delete a file Deletes a file in a repository. You can provide an additional `committer` parameter, which is an object containing information about the committer. Or, you can provide an `author` parameter, which is an object containing information about the author. The `author` section is optional and is filled in with the `committer` information if omitted. If the `committer` information is omitted, the authenticated user's information is used. You must provide values for both `name` and `email`, whether you choose to use `author` or `committer`. Otherwise, you'll receive a `422` status code. > [!NOTE] > If you use this endpoint and the "[Create or update file contents](https://docs.github.com/rest/repos/contents/#create-or-update-file-contents)" endpoint in parallel, the concurrent requests will conflict and you will receive errors. You must use these endpoints serially instead. */
export declare const deleteFile: API.OperationMethod<DeleteFileRequest, FileCommit, DeleteFileError, GithubOpContext>;
export type DeleteInvitationError = GithubOpError;
/** Delete a repository invitation */
export declare const deleteInvitation: API.OperationMethod<DeleteInvitationRequest, DeleteInvitationResponse, DeleteInvitationError, GithubOpContext>;
export type DeleteOrgRulesetError = GithubOpError;
/** Delete an organization repository ruleset Delete a ruleset for an organization. */
export declare const deleteOrgRuleset: API.OperationMethod<DeleteOrgRulesetRequest, DeleteOrgRulesetResponse, DeleteOrgRulesetError, GithubOpContext>;
export type DeletePagesSiteError = GithubOpError;
/** Delete a GitHub Pages site Deletes a GitHub Pages site. For more information, see "[About GitHub Pages](/github/working-with-github-pages/about-github-pages). The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const deletePagesSite: API.OperationMethod<DeletePagesSiteRequest, DeletePagesSiteResponse, DeletePagesSiteError, GithubOpContext>;
export type DeletePullRequestReviewProtectionError = GithubOpError;
/** Delete pull request review protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const deletePullRequestReviewProtection: API.OperationMethod<DeletePullRequestReviewProtectionRequest, DeletePullRequestReviewProtectionResponse, DeletePullRequestReviewProtectionError, GithubOpContext>;
export type DeleteReleaseError = GithubOpError;
/** Delete a release Users with push access to the repository can delete a release. */
export declare const deleteRelease: API.OperationMethod<DeleteReleaseRequest, DeleteReleaseResponse, DeleteReleaseError, GithubOpContext>;
export type DeleteReleaseAssetError = GithubOpError;
/** Delete a release asset */
export declare const deleteReleaseAsset: API.OperationMethod<DeleteReleaseAssetRequest, DeleteReleaseAssetResponse, DeleteReleaseAssetError, GithubOpContext>;
export type DeleteRepoRulesetError = GithubOpError;
/** Delete a repository ruleset Delete a ruleset for a repository. */
export declare const deleteRepoRuleset: API.OperationMethod<DeleteRepoRulesetRequest, DeleteRepoRulesetResponse, DeleteRepoRulesetError, GithubOpContext>;
export type DeleteWebhookError = GithubOpError;
/** Delete a repository webhook Delete a webhook for an organization. The authenticated user must be a repository owner, or have admin access in the repository, to delete the webhook. */
export declare const deleteWebhook: API.OperationMethod<DeleteWebhookRequest, DeleteWebhookResponse, DeleteWebhookError, GithubOpContext>;
export type DisableAutomatedSecurityFixesError = GithubOpError;
/** Disable Dependabot security updates Disables Dependabot security updates for a repository. The authenticated user must have admin access to the repository. For more information, see "[Configuring Dependabot security updates](https://docs.github.com/articles/configuring-automated-security-fixes)". */
export declare const disableAutomatedSecurityFixes: API.OperationMethod<DisableAutomatedSecurityFixesRequest, DisableAutomatedSecurityFixesResponse, DisableAutomatedSecurityFixesError, GithubOpContext>;
export type DisableDeploymentProtectionRuleError = GithubOpError;
/** Disable a custom protection rule for an environment Disables a custom deployment protection rule for an environment. The authenticated user must have admin or owner permissions to the repository to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const disableDeploymentProtectionRule: API.OperationMethod<DisableDeploymentProtectionRuleRequest, DisableDeploymentProtectionRuleResponse, DisableDeploymentProtectionRuleError, GithubOpContext>;
export type DisableImmutableReleasesError = GithubOpError;
/** Disable immutable releases Disables immutable releases for a repository. The authenticated user must have admin access to the repository. */
export declare const disableImmutableReleases: API.OperationMethod<DisableImmutableReleasesRequest, DisableImmutableReleasesResponse, DisableImmutableReleasesError, GithubOpContext>;
export type DisablePrivateVulnerabilityReportingError = GithubOpError;
/** Disable private vulnerability reporting for a repository Disables private vulnerability reporting for a repository. The authenticated user must have admin access to the repository. For more information, see "[Privately reporting a security vulnerability](https://docs.github.com/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability)". */
export declare const disablePrivateVulnerabilityReporting: API.OperationMethod<DisablePrivateVulnerabilityReportingRequest, DisablePrivateVulnerabilityReportingResponse, DisablePrivateVulnerabilityReportingError, GithubOpContext>;
export type DisableVulnerabilityAlertsError = GithubOpError;
/** Disable vulnerability alerts Disables dependency alerts and the dependency graph for a repository. The authenticated user must have admin access to the repository. For more information, see "[About security alerts for vulnerable dependencies](https://docs.github.com/articles/about-security-alerts-for-vulnerable-dependencies)". */
export declare const disableVulnerabilityAlerts: API.OperationMethod<DisableVulnerabilityAlertsRequest, DisableVulnerabilityAlertsResponse, DisableVulnerabilityAlertsError, GithubOpContext>;
export type DownloadTarballArchiveError = GithubOpError;
/** Download a repository archive (tar) Gets a redirect URL to download a tar archive for a repository. If you omit `:ref`, the repository's default branch (usually `main`) will be used. Please make sure your HTTP framework is configured to follow redirects or you will need to use the `Location` header to make a second `GET` request. > [!NOTE] > For private repositories, these links are temporary and expire after five minutes. */
export declare const downloadTarballArchive: API.OperationMethod<DownloadTarballArchiveRequest, DownloadTarballArchiveResponse, DownloadTarballArchiveError, GithubOpContext>;
export type DownloadZipballArchiveError = GithubOpError;
/** Download a repository archive (zip) Gets a redirect URL to download a zip archive for a repository. If you omit `:ref`, the repository's default branch (usually `main`) will be used. Please make sure your HTTP framework is configured to follow redirects or you will need to use the `Location` header to make a second `GET` request. > [!NOTE] > For private repositories, these links are temporary and expire after five minutes. If the repository is empty, you will receive a 404 when you follow the redirect. */
export declare const downloadZipballArchive: API.OperationMethod<DownloadZipballArchiveRequest, DownloadZipballArchiveResponse, DownloadZipballArchiveError, GithubOpContext>;
export type EnableAutomatedSecurityFixesError = GithubOpError;
/** Enable Dependabot security updates Enables Dependabot security updates for a repository. The authenticated user must have admin access to the repository. For more information, see "[Configuring Dependabot security updates](https://docs.github.com/articles/configuring-automated-security-fixes)". */
export declare const enableAutomatedSecurityFixes: API.OperationMethod<EnableAutomatedSecurityFixesRequest, EnableAutomatedSecurityFixesResponse, EnableAutomatedSecurityFixesError, GithubOpContext>;
export type EnableImmutableReleasesError = GithubOpError;
/** Enable immutable releases Enables immutable releases for a repository. The authenticated user must have admin access to the repository. */
export declare const enableImmutableReleases: API.OperationMethod<EnableImmutableReleasesRequest, EnableImmutableReleasesResponse, EnableImmutableReleasesError, GithubOpContext>;
export type EnablePrivateVulnerabilityReportingError = GithubOpError;
/** Enable private vulnerability reporting for a repository Enables private vulnerability reporting for a repository. The authenticated user must have admin access to the repository. For more information, see "[Privately reporting a security vulnerability](https://docs.github.com/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability)." */
export declare const enablePrivateVulnerabilityReporting: API.OperationMethod<EnablePrivateVulnerabilityReportingRequest, EnablePrivateVulnerabilityReportingResponse, EnablePrivateVulnerabilityReportingError, GithubOpContext>;
export type EnableVulnerabilityAlertsError = GithubOpError;
/** Enable vulnerability alerts Enables dependency alerts and the dependency graph for a repository. The authenticated user must have admin access to the repository. For more information, see "[About security alerts for vulnerable dependencies](https://docs.github.com/articles/about-security-alerts-for-vulnerable-dependencies)". */
export declare const enableVulnerabilityAlerts: API.OperationMethod<EnableVulnerabilityAlertsRequest, EnableVulnerabilityAlertsResponse, EnableVulnerabilityAlertsError, GithubOpContext>;
export type GenerateReleaseNotesError = GithubOpError;
/** Generate release notes content for a release Generate a name and body describing a [release](https://docs.github.com/rest/releases/releases#get-a-release). The body content will be markdown formatted and contain information like the changes since last release and users who contributed. The generated release notes are not saved anywhere. They are intended to be generated and used when creating a new release. */
export declare const generateReleaseNotes: API.OperationMethod<GenerateReleaseNotesRequest, ReleaseNotesContent, GenerateReleaseNotesError, GithubOpContext>;
export type GetError = GithubOpError;
/** Get a repository The `parent` and `source` objects are present when the repository is a fork. `parent` is the repository this repository was forked from, `source` is the ultimate source for the network. When present and non-empty, `temp_clone_token` is a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. > [!NOTE] > - In order to see the `security_and_analysis` block for a repository you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." > - To view merge-related settings, you must have the `contents:read` and `contents:write` permissions. */
export declare const get: API.OperationMethod<GetRequest, FullRepository, GetError, GithubOpContext>;
export type GetAccessRestrictionsError = GithubOpError;
/** Get access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Lists who has access to this protected branch. > [!NOTE] > Users, apps, and teams `restrictions` are only available for organization-owned repositories. */
export declare const getAccessRestrictions: API.OperationMethod<GetAccessRestrictionsRequest, BranchRestrictionPolicy, GetAccessRestrictionsError, GithubOpContext>;
export type GetAdminBranchProtectionError = GithubOpError;
/** Get admin branch protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const getAdminBranchProtection: API.OperationMethod<GetAdminBranchProtectionRequest, ProtectedBranchAdminEnforced, GetAdminBranchProtectionError, GithubOpContext>;
export type GetAllDeploymentProtectionRulesError = GithubOpError;
/** Get all deployment protection rules for an environment Gets all custom deployment protection rules that are enabled for an environment. Anyone with read access to the repository can use this endpoint. For more information about environments, see "[Using environments for deployment](https://docs.github.com/actions/deployment/targeting-different-environments/using-environments-for-deployment)." For more information about the app that is providing this custom deployment rule, see the [documentation for the `GET /apps/{app_slug}` endpoint](https://docs.github.com/rest/apps/apps#get-an-app). OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getAllDeploymentProtectionRules: API.OperationMethod<GetAllDeploymentProtectionRulesRequest, GetAllDeploymentProtectionRulesResponse, GetAllDeploymentProtectionRulesError, GithubOpContext>;
export type GetAllEnvironmentsError = GithubOpError;
/** List environments Lists the environments for a repository. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getAllEnvironments: API.PaginatedOperationMethod<GetAllEnvironmentsRequest, GetAllEnvironmentsResponse, GetAllEnvironmentsError, GithubOpContext, Environment>;
export type GetAllStatusCheckContextsError = GithubOpError;
/** Get all status check contexts Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const getAllStatusCheckContexts: API.OperationMethod<GetAllStatusCheckContextsRequest, GetAllStatusCheckContextsResponse, GetAllStatusCheckContextsError, GithubOpContext>;
export type GetAllTopicsError = GithubOpError;
/** Get all repository topics */
export declare const getAllTopics: API.PaginatedOperationMethod<GetAllTopicsRequest, Topic, GetAllTopicsError, GithubOpContext, string>;
export type GetAppsWithAccessToProtectedBranchError = GithubOpError;
/** Get apps with access to the protected branch Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Lists the GitHub Apps that have push access to this branch. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch. */
export declare const getAppsWithAccessToProtectedBranch: API.OperationMethod<GetAppsWithAccessToProtectedBranchRequest, GetAppsWithAccessToProtectedBranchResponse, GetAppsWithAccessToProtectedBranchError, GithubOpContext>;
export type GetAutolinkError = GithubOpError;
/** Get an autolink reference of a repository This returns a single autolink reference by ID that was configured for the given repository. Information about autolinks are only available to repository administrators. */
export declare const getAutolink: API.OperationMethod<GetAutolinkRequest, Autolink, GetAutolinkError, GithubOpContext>;
export type GetBranchError = GithubOpError;
/** Get a branch */
export declare const getBranch: API.OperationMethod<GetBranchRequest, BranchWithProtection, GetBranchError, GithubOpContext>;
export type GetBranchProtectionError = GithubOpError;
/** Get branch protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const getBranchProtection: API.OperationMethod<GetBranchProtectionRequest, BranchProtection, GetBranchProtectionError, GithubOpContext>;
export type GetBranchRulesError = GithubOpError;
/** Get rules for a branch Returns all active rules that apply to the specified branch. The branch does not need to exist; rules that would apply to a branch with that name will be returned. All active rules that apply will be returned, regardless of the level at which they are configured (e.g. repository or organization). Rules in rulesets with "evaluate" or "disabled" enforcement statuses are not returned. */
export declare const getBranchRules: API.PaginatedOperationMethod<GetBranchRulesRequest, GetBranchRulesResponse, GetBranchRulesError, GithubOpContext, RepositoryRuleDetailed>;
export type GetByIdError = GithubOpError;
/** Get a repository by id The repository's numeric id is stable across renames and transfers, so this finds a repository whose name changed. Undocumented in GitHub's REST reference, but served by the API. */
export declare const getById: API.OperationMethod<GetByIdRequest, FullRepository, GetByIdError, GithubOpContext>;
export type GetClonesError = GithubOpError;
/** Get repository clones Get the total number of clones and breakdown per day or week for the last 14 days. Timestamps are aligned to UTC midnight of the beginning of the day or week. Week begins on Monday. */
export declare const getClones: API.OperationMethod<GetClonesRequest, CloneTraffic, GetClonesError, GithubOpContext>;
export type GetCodeFrequencyStatsError = GithubOpError;
/** Get the weekly commit activity Returns a weekly aggregate of the number of additions and deletions pushed to a repository. > [!NOTE] > This endpoint can only be used for repositories with fewer than 10,000 commits. If the repository contains 10,000 or more commits, a 422 status code will be returned. */
export declare const getCodeFrequencyStats: API.OperationMethod<GetCodeFrequencyStatsRequest, GetCodeFrequencyStatsResponse, GetCodeFrequencyStatsError, GithubOpContext>;
export type GetCollaboratorPermissionLevelError = GithubOpError;
/** Get repository permissions for a user Checks the repository permission and role of a collaborator. The `permission` attribute provides the legacy base roles of `admin`, `write`, `read`, and `none`, where the `maintain` role is mapped to `write` and the `triage` role is mapped to `read`. The `role_name` attribute provides the name of the assigned role, including custom roles. The `permission` can also be used to determine which base level of access the collaborator has to the repository. The calculated permissions are the highest role assigned to the collaborator after considering all sources of grants, including: repo, teams, organization, and enterprise. There is presently not a way to differentiate between an organization level grant and a repository level grant from this endpoint response. */
export declare const getCollaboratorPermissionLevel: API.OperationMethod<GetCollaboratorPermissionLevelRequest, RepositoryCollaboratorPermission, GetCollaboratorPermissionLevelError, GithubOpContext>;
export type GetCombinedStatusForRefError = GithubOpError;
/** Get the combined status for a specific reference Users with pull access in a repository can access a combined view of commit statuses for a given ref. The ref can be a SHA, a branch name, or a tag name. Additionally, a combined `state` is returned. The `state` is one of: * **failure** if any of the contexts report as `error` or `failure` * **pending** if there are no statuses or a context is `pending` * **success** if the latest status for all contexts is `success` */
export declare const getCombinedStatusForRef: API.PaginatedOperationMethod<GetCombinedStatusForRefRequest, CombinedCommitStatus, GetCombinedStatusForRefError, GithubOpContext, SimpleCommitStatus>;
export type GetCommitError = GithubOpError;
/** Get a commit Returns the contents of a single commit reference. You must have `read` access for the repository to use this endpoint. > [!NOTE] > If there are more than 300 files in the commit diff and the default JSON media type is requested, the response will include pagination link headers for the remaining files, up to a limit of 3000 files. Each page contains the static commit information, and the only changes are to the file listing. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." Pagination query parameters are not supported for these media types. - **`application/vnd.github.diff`**: Returns the diff of the commit. Larger diffs may time out and return a 5xx status code. - **`application/vnd.github.patch`**: Returns the patch of the commit. Diffs with binary data will have no `patch` property. Larger diffs may time out and return a 5xx status code. - **`application/vnd.github.sha`**: Returns the commit's SHA-1 hash. You can use this endpoint to check if a remote reference's SHA-1 hash is the same as your local reference's SHA-1 hash by providing the local SHA-1 reference as the ETag. **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object: These are the possible values for `reason` in the `verification` object: */
export declare const getCommit: API.OperationMethod<GetCommitRequest & {
    readonly accept?: "application/vnd.github+json" | undefined;
}, Commit, GetCommitError, GithubOpContext> & API.OperationMethod<GetCommitRequest & {
    readonly accept: "application/vnd.github.diff" | "application/vnd.github.patch" | "application/vnd.github.sha";
}, string, GetCommitError, GithubOpContext>;
export type GetCommitActivityStatsError = GithubOpError;
/** Get the last year of commit activity Returns the last year of commit activity grouped by week. The `days` array is a group of commits per day, starting on `Sunday`. */
export declare const getCommitActivityStats: API.OperationMethod<GetCommitActivityStatsRequest, GetCommitActivityStatsResponse, GetCommitActivityStatsError, GithubOpContext>;
export type GetCommitCommentError = GithubOpError;
/** Get a commit comment Gets a specified commit comment. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const getCommitComment: API.OperationMethod<GetCommitCommentRequest, CommitComment, GetCommitCommentError, GithubOpContext>;
export type GetCommitSignatureProtectionError = GithubOpError;
/** Get commit signature protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. When authenticated with admin or owner permissions to the repository, you can use this endpoint to check whether a branch requires signed commits. An enabled status of `true` indicates you must sign commits on this branch. For more information, see [Signing commits with GPG](https://docs.github.com/articles/signing-commits-with-gpg) in GitHub Help. > [!NOTE] > You must enable branch protection to require signed commits. */
export declare const getCommitSignatureProtection: API.OperationMethod<GetCommitSignatureProtectionRequest, ProtectedBranchAdminEnforced, GetCommitSignatureProtectionError, GithubOpContext>;
export type GetCommunityProfileMetricsError = GithubOpError;
/** Get community profile metrics Returns all community profile metrics for a repository. The repository cannot be a fork. The returned metrics include an overall health score, the repository description, the presence of documentation, the detected code of conduct, the detected license, and the presence of ISSUE\_TEMPLATE, PULL\_REQUEST\_TEMPLATE, README, and CONTRIBUTING files. The `health_percentage` score is defined as a percentage of how many of the recommended community health files are present. For more information, see "[About community profiles for public repositories](https://docs.github.com/communities/setting-up-your-project-for-healthy-contributions/about-community-profiles-for-public-repositories)." `content_reports_enabled` is only returned for organization-owned repositories. */
export declare const getCommunityProfileMetrics: API.OperationMethod<GetCommunityProfileMetricsRequest, CommunityProfile, GetCommunityProfileMetricsError, GithubOpContext>;
export type GetContentError = GithubOpError;
/** Get repository content Gets the contents of a file or directory in a repository. Specify the file path or directory with the `path` parameter. If you omit the `path` parameter, you will receive the contents of the repository's root directory. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw file contents for files and symlinks. - **`application/vnd.github.html+json`**: Returns the file contents in HTML. Markup languages are rendered to HTML using GitHub's open-source [Markup library](https://github.com/github/markup). - **`application/vnd.github.object+json`**: Returns the contents in a consistent object format regardless of the content type. For example, instead of an array of objects for a directory, the response will be an object with an `entries` attribute containing the array of objects. If the content is a directory, the response will be an array of objects, one object for each item in the directory. When listing the contents of a directory, submodules have their "type" specified as "file". Logically, the value _should_ be "submodule". This behavior exists [for backwards compatibility purposes](https://git.io/v1YCW). In the next major version of the API, the type will be returned as "submodule". If the content is a symlink and the symlink's target is a normal file in the repository, then the API responds with the content of the file. Otherwise, the API responds with an object describing the symlink itself. If the content is a submodule, the `submodule_git_url` field identifies the location of the submodule repository, and the `sha` identifies a specific commit within the submodule repository. Git uses the given URL when cloning the submodule repository, and checks out the submodule at that specific commit. If the submodule repository is not hosted on github.com, the Git URLs (`git_url` and `_links["git"]`) and the github.com URLs (`html_url` and `_links["html"]`) will have null values. **Notes**: - To get a repository's contents recursively, you can [recursively get the tree](https://docs.github.com/rest/git/trees#get-a-tree). - This API has an upper limit of 1,000 files for a directory. If you need to retrieve more files, use the [Git Trees API](https://docs.github.com/rest/git/trees#get-a-tree). - Download URLs expire and are meant to be used just once. To ensure the download URL does not expire, please use the contents API to obtain a fresh download URL for each download. - If the requested file's size is: - 1 MB or smaller: All features of this endpoint are supported. - Between 1-100 MB: Only the `raw` or `object` custom media types are supported. Both will work as normal, except that when using the `object` media type, the `content` field will be an empty string and the `encoding` field will be `"none"`. To get the contents of these larger files, use the `raw` media type. - Greater than 100 MB: This endpoint is not supported. */
export declare const getContent: API.OperationMethod<GetContentRequest, GetContentResponse, GetContentError, GithubOpContext>;
export type GetContributorsStatsError = GithubOpError;
/** Get all contributor commit activity Returns the `total` number of commits authored by the contributor. In addition, the response includes a Weekly Hash (`weeks` array) with the following information: * `w` - Start of the week, given as a [Unix timestamp](https://en.wikipedia.org/wiki/Unix_time). * `a` - Number of additions * `d` - Number of deletions * `c` - Number of commits > [!NOTE] > This endpoint will return `0` values for all addition and deletion counts in repositories with 10,000 or more commits. */
export declare const getContributorsStats: API.OperationMethod<GetContributorsStatsRequest, GetContributorsStatsResponse, GetContributorsStatsError, GithubOpContext>;
export type GetCustomDeploymentProtectionRuleError = GithubOpError;
/** Get a custom deployment protection rule Gets an enabled custom deployment protection rule for an environment. Anyone with read access to the repository can use this endpoint. For more information about environments, see "[Using environments for deployment](https://docs.github.com/actions/deployment/targeting-different-environments/using-environments-for-deployment)." For more information about the app that is providing this custom deployment rule, see [`GET /apps/{app_slug}`](https://docs.github.com/rest/apps/apps#get-an-app). OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getCustomDeploymentProtectionRule: API.OperationMethod<GetCustomDeploymentProtectionRuleRequest, DeploymentProtectionRule, GetCustomDeploymentProtectionRuleError, GithubOpContext>;
export type GetDeployKeyError = GithubOpError;
/** Get a deploy key */
export declare const getDeployKey: API.OperationMethod<GetDeployKeyRequest, DeployKey, GetDeployKeyError, GithubOpContext>;
export type GetDeploymentError = GithubOpError;
/** Get a deployment */
export declare const getDeployment: API.OperationMethod<GetDeploymentRequest, Deployment, GetDeploymentError, GithubOpContext>;
export type GetDeploymentBranchPolicyError = GithubOpError;
/** Get a deployment branch policy Gets a deployment branch or tag policy for an environment. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getDeploymentBranchPolicy: API.OperationMethod<GetDeploymentBranchPolicyRequest, DeploymentBranchPolicy, GetDeploymentBranchPolicyError, GithubOpContext>;
export type GetDeploymentStatusError = GithubOpError;
/** Get a deployment status Users with pull access can view a deployment status for a deployment: */
export declare const getDeploymentStatus: API.OperationMethod<GetDeploymentStatusRequest, DeploymentStatus, GetDeploymentStatusError, GithubOpContext>;
export type GetEnvironmentError = GithubOpError;
/** Get an environment > [!NOTE] > To get information about name patterns that branches must match in order to deploy to this environment, see "[Get a deployment branch policy](/rest/deployments/branch-policies#get-a-deployment-branch-policy)." Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest, Environment, GetEnvironmentError, GithubOpContext>;
export type GetHashAlgorithmError = GithubOpError;
/** Get the hash algorithm for a repository Returns the hash algorithm used to store repository objects. */
export declare const getHashAlgorithm: API.OperationMethod<GetHashAlgorithmRequest, RepositoryHashAlgorithm, GetHashAlgorithmError, GithubOpContext>;
export type GetLatestPagesBuildError = GithubOpError;
/** Get latest Pages build Gets information about the single most recent build of a GitHub Pages site. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getLatestPagesBuild: API.OperationMethod<GetLatestPagesBuildRequest, PageBuild, GetLatestPagesBuildError, GithubOpContext>;
export type GetLatestReleaseError = GithubOpError;
/** Get the latest release View the latest published full release for the repository. The latest release is the most recent non-prerelease, non-draft release, sorted by the `created_at` attribute. The `created_at` attribute is the date of the commit used for the release, and not the date when the release was drafted or published. */
export declare const getLatestRelease: API.OperationMethod<GetLatestReleaseRequest, Release, GetLatestReleaseError, GithubOpContext>;
export type GetOrgRulesetError = GithubOpError;
/** Get an organization repository ruleset Get a repository ruleset for an organization. **Note:** To prevent leaking sensitive information, the `bypass_actors` property is only returned if the user making the API request has write access to the ruleset. */
export declare const getOrgRuleset: API.OperationMethod<GetOrgRulesetRequest, RepositoryRuleset, GetOrgRulesetError, GithubOpContext>;
export type GetOrgRulesetsError = GithubOpError;
/** Get all organization repository rulesets Get all the repository rulesets for an organization. */
export declare const getOrgRulesets: API.PaginatedOperationMethod<GetOrgRulesetsRequest, GetOrgRulesetsResponse, GetOrgRulesetsError, GithubOpContext, RepositoryRuleset>;
export type GetOrgRuleSuiteError = GithubOpError;
/** Get an organization rule suite Gets information about a suite of rule evaluations from within an organization. For more information, see "[Managing rulesets for repositories in your organization](https://docs.github.com/organizations/managing-organization-settings/managing-rulesets-for-repositories-in-your-organization#viewing-insights-for-rulesets)." */
export declare const getOrgRuleSuite: API.OperationMethod<GetOrgRuleSuiteRequest, RuleSuite, GetOrgRuleSuiteError, GithubOpContext>;
export type GetOrgRuleSuitesError = GithubOpError;
/** List organization rule suites Lists suites of rule evaluations at the organization level. For more information, see "[Managing rulesets for repositories in your organization](https://docs.github.com/organizations/managing-organization-settings/managing-rulesets-for-repositories-in-your-organization#viewing-insights-for-rulesets)." */
export declare const getOrgRuleSuites: API.PaginatedOperationMethod<GetOrgRuleSuitesRequest, GetOrgRuleSuitesResponse, GetOrgRuleSuitesError, GithubOpContext, RuleSuitesItem>;
export type GetPagesError = GithubOpError;
/** Get a GitHub Pages site Gets information about a GitHub Pages site. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getPages: API.OperationMethod<GetPagesRequest, Page, GetPagesError, GithubOpContext>;
export type GetPagesBuildError = GithubOpError;
/** Get GitHub Pages build Gets information about a GitHub Pages build. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getPagesBuild: API.OperationMethod<GetPagesBuildRequest, PageBuild, GetPagesBuildError, GithubOpContext>;
export type GetPagesDeploymentError = GithubOpError;
/** Get the status of a GitHub Pages deployment Gets the current status of a GitHub Pages deployment. The authenticated user must have read permission for the GitHub Pages site. */
export declare const getPagesDeployment: API.OperationMethod<GetPagesDeploymentRequest, PagesDeploymentStatus, GetPagesDeploymentError, GithubOpContext>;
export type GetPagesHealthCheckError = GithubOpError;
/** Get a DNS health check for GitHub Pages Gets a health check of the DNS settings for the `CNAME` record configured for a repository's GitHub Pages. The first request to this endpoint returns a `202 Accepted` status and starts an asynchronous background task to get the results for the domain. After the background task completes, subsequent requests to this endpoint return a `200 OK` status with the health check results in the response. The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const getPagesHealthCheck: API.OperationMethod<GetPagesHealthCheckRequest, PagesHealthCheck, GetPagesHealthCheckError, GithubOpContext>;
export type GetParticipationStatsError = GithubOpError;
/** Get the weekly commit count Returns the total commit counts for the `owner` and total commit counts in `all`. `all` is everyone combined, including the `owner` in the last 52 weeks. If you'd like to get the commit counts for non-owners, you can subtract `owner` from `all`. The array order is oldest week (index 0) to most recent week. The most recent week is seven days ago at UTC midnight to today at UTC midnight. */
export declare const getParticipationStats: API.OperationMethod<GetParticipationStatsRequest, ParticipationStats, GetParticipationStatsError, GithubOpContext>;
export type GetPullRequestReviewProtectionError = GithubOpError;
/** Get pull request review protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const getPullRequestReviewProtection: API.OperationMethod<GetPullRequestReviewProtectionRequest, ProtectedBranchPullRequestReview, GetPullRequestReviewProtectionError, GithubOpContext>;
export type GetPunchCardStatsError = GithubOpError;
/** Get the hourly commit count for each day Each array contains the day number, hour number, and number of commits: * `0-6`: Sunday - Saturday * `0-23`: Hour of day * Number of commits For example, `[2, 14, 25]` indicates that there were 25 total commits, during the 2:00pm hour on Tuesdays. All times are based on the time zone of individual commits. */
export declare const getPunchCardStats: API.OperationMethod<GetPunchCardStatsRequest, GetPunchCardStatsResponse, GetPunchCardStatsError, GithubOpContext>;
export type GetReadmeError = GithubOpError;
/** Get a repository README Gets the preferred README for a repository. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw file contents. This is the default if you do not specify a media type. - **`application/vnd.github.html+json`**: Returns the README in HTML. Markup languages are rendered to HTML using GitHub's open-source [Markup library](https://github.com/github/markup). */
export declare const getReadme: API.OperationMethod<GetReadmeRequest, ContentFile, GetReadmeError, GithubOpContext>;
export type GetReadmeInDirectoryError = GithubOpError;
/** Get a repository README for a directory Gets the README from a repository directory. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.raw+json`**: Returns the raw file contents. This is the default if you do not specify a media type. - **`application/vnd.github.html+json`**: Returns the README in HTML. Markup languages are rendered to HTML using GitHub's open-source [Markup library](https://github.com/github/markup). */
export declare const getReadmeInDirectory: API.OperationMethod<GetReadmeInDirectoryRequest, ContentFile, GetReadmeInDirectoryError, GithubOpContext>;
export type GetReleaseError = GithubOpError;
/** Get a release Gets a public release with the specified release ID. > [!NOTE] > This returns an `upload_url` key corresponding to the endpoint for uploading release assets. This key is a hypermedia resource. For more information, see "[Getting started with the REST API](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#hypermedia)." */
export declare const getRelease: API.OperationMethod<GetReleaseRequest, Release, GetReleaseError, GithubOpContext>;
export type GetReleaseAssetError = GithubOpError;
/** Get a release asset To download the asset's binary content: - If within a browser, fetch the location specified in the `browser_download_url` key provided in the response. - Alternatively, set the `Accept` header of the request to [`application/octet-stream`](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types). The API will either redirect the client to the location, or stream it directly if possible. API clients should handle both a `200` or `302` response. */
export declare const getReleaseAsset: API.OperationMethod<GetReleaseAssetRequest, ReleaseAsset, GetReleaseAssetError, GithubOpContext>;
export type GetReleaseByTagError = GithubOpError;
/** Get a release by tag name Get a published release with the specified tag. */
export declare const getReleaseByTag: API.OperationMethod<GetReleaseByTagRequest, Release, GetReleaseByTagError, GithubOpContext>;
export type GetRepoRulesetError = GithubOpError;
/** Get a repository ruleset Get a ruleset for a repository. **Note:** To prevent leaking sensitive information, the `bypass_actors` property is only returned if the user making the API request has write access to the ruleset. */
export declare const getRepoRuleset: API.OperationMethod<GetRepoRulesetRequest, RepositoryRuleset, GetRepoRulesetError, GithubOpContext>;
export type GetRepoRulesetHistoryError = GithubOpError;
/** Get repository ruleset history Get the history of a repository ruleset. */
export declare const getRepoRulesetHistory: API.PaginatedOperationMethod<GetRepoRulesetHistoryRequest, GetRepoRulesetHistoryResponse, GetRepoRulesetHistoryError, GithubOpContext, RulesetVersion>;
export type GetRepoRulesetsError = GithubOpError;
/** Get all repository rulesets Get all the rulesets for a repository. */
export declare const getRepoRulesets: API.PaginatedOperationMethod<GetRepoRulesetsRequest, GetRepoRulesetsResponse, GetRepoRulesetsError, GithubOpContext, RepositoryRuleset>;
export type GetRepoRulesetVersionError = GithubOpError;
/** Get repository ruleset version Get a version of a repository ruleset. */
export declare const getRepoRulesetVersion: API.OperationMethod<GetRepoRulesetVersionRequest, GetRepoRulesetVersionResponse, GetRepoRulesetVersionError, GithubOpContext>;
export type GetRepoRuleSuiteError = GithubOpError;
/** Get a repository rule suite Gets information about a suite of rule evaluations from within a repository. For more information, see "[Managing rulesets for a repository](https://docs.github.com/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository#viewing-insights-for-rulesets)." */
export declare const getRepoRuleSuite: API.OperationMethod<GetRepoRuleSuiteRequest, RuleSuite, GetRepoRuleSuiteError, GithubOpContext>;
export type GetRepoRuleSuitesError = GithubOpError;
/** List repository rule suites Lists suites of rule evaluations at the repository level. For more information, see "[Managing rulesets for a repository](https://docs.github.com/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/managing-rulesets-for-a-repository#viewing-insights-for-rulesets)." */
export declare const getRepoRuleSuites: API.PaginatedOperationMethod<GetRepoRuleSuitesRequest, GetRepoRuleSuitesResponse, GetRepoRuleSuitesError, GithubOpContext, RuleSuitesItem>;
export type GetStatusChecksProtectionError = GithubOpError;
/** Get status checks protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const getStatusChecksProtection: API.OperationMethod<GetStatusChecksProtectionRequest, StatusCheckPolicy, GetStatusChecksProtectionError, GithubOpContext>;
export type GetTeamsWithAccessToProtectedBranchError = GithubOpError;
/** Get teams with access to the protected branch Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Lists the teams who have push access to this branch. The list includes child teams. */
export declare const getTeamsWithAccessToProtectedBranch: API.OperationMethod<GetTeamsWithAccessToProtectedBranchRequest, GetTeamsWithAccessToProtectedBranchResponse, GetTeamsWithAccessToProtectedBranchError, GithubOpContext>;
export type GetTopPathsError = GithubOpError;
/** Get top referral paths Get the top 10 popular contents over the last 14 days. */
export declare const getTopPaths: API.OperationMethod<GetTopPathsRequest, GetTopPathsResponse, GetTopPathsError, GithubOpContext>;
export type GetTopReferrersError = GithubOpError;
/** Get top referral sources Get the top 10 referrers over the last 14 days. */
export declare const getTopReferrers: API.OperationMethod<GetTopReferrersRequest, GetTopReferrersResponse, GetTopReferrersError, GithubOpContext>;
export type GetUsersWithAccessToProtectedBranchError = GithubOpError;
/** Get users with access to the protected branch Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Lists the people who have push access to this branch. */
export declare const getUsersWithAccessToProtectedBranch: API.OperationMethod<GetUsersWithAccessToProtectedBranchRequest, GetUsersWithAccessToProtectedBranchResponse, GetUsersWithAccessToProtectedBranchError, GithubOpContext>;
export type GetViewsError = GithubOpError;
/** Get page views Get the total number of views and breakdown per day or week for the last 14 days. Timestamps are aligned to UTC midnight of the beginning of the day or week. Week begins on Monday. */
export declare const getViews: API.OperationMethod<GetViewsRequest, ViewTraffic, GetViewsError, GithubOpContext>;
export type GetWebhookError = GithubOpError;
/** Get a repository webhook Returns a webhook configured in a repository. To get only the webhook `config` properties, see "[Get a webhook configuration for a repository](/rest/webhooks/repo-config#get-a-webhook-configuration-for-a-repository)." */
export declare const getWebhook: API.OperationMethod<GetWebhookRequest, Hook, GetWebhookError, GithubOpContext>;
export type GetWebhookConfigForRepoError = GithubOpError;
/** Get a webhook configuration for a repository Returns the webhook configuration for a repository. To get more information about the webhook, including the `active` state and `events`, use "[Get a repository webhook](/rest/webhooks/repos#get-a-repository-webhook)." OAuth app tokens and personal access tokens (classic) need the `read:repo_hook` or `repo` scope to use this endpoint. */
export declare const getWebhookConfigForRepo: API.OperationMethod<GetWebhookConfigForRepoRequest, WebhookConfig, GetWebhookConfigForRepoError, GithubOpContext>;
export type GetWebhookDeliveryError = GithubOpError;
/** Get a delivery for a repository webhook Returns a delivery for a webhook configured in a repository. */
export declare const getWebhookDelivery: API.OperationMethod<GetWebhookDeliveryRequest, HookDelivery, GetWebhookDeliveryError, GithubOpContext>;
export type ListActivitiesError = GithubOpError;
/** List repository activities Lists a detailed history of changes to a repository, such as pushes, merges, force pushes, and branch changes, and associates these changes with commits and users. For more information about viewing repository activity, see "[Viewing activity and data for your repository](https://docs.github.com/repositories/viewing-activity-and-data-for-your-repository)." */
export declare const listActivities: API.OperationMethod<ListActivitiesRequest, ListActivitiesResponse, ListActivitiesError, GithubOpContext>;
export type ListAttestationsError = GithubOpError;
/** List attestations List a collection of artifact attestations with a given subject digest that are associated with a repository. The authenticated user making the request must have read access to the repository. In addition, when using a fine-grained access token the `attestations:read` permission is required. **Please note:** in order to offer meaningful security benefits, an attestation's signature and timestamps **must** be cryptographically verified, and the identity of the attestation signer **must** be validated. Attestations can be verified using the [GitHub CLI `attestation verify` command](https://cli.github.com/manual/gh_attestation_verify). For more information, see [our guide on how to use artifact attestations to establish a build's provenance](https://docs.github.com/actions/security-guides/using-artifact-attestations-to-establish-provenance-for-builds). */
export declare const listAttestations: API.OperationMethod<ListAttestationsRequest, ListAttestationsResponse, ListAttestationsError, GithubOpContext>;
export type ListAutolinksError = GithubOpError;
/** Get all autolinks of a repository Gets all autolinks that are configured for a repository. Information about autolinks are only available to repository administrators. */
export declare const listAutolinks: API.OperationMethod<ListAutolinksRequest, ListAutolinksResponse, ListAutolinksError, GithubOpContext>;
export type ListBranchesError = GithubOpError;
/** List branches */
export declare const listBranches: API.PaginatedOperationMethod<ListBranchesRequest, ListBranchesResponse, ListBranchesError, GithubOpContext, ShortBranch>;
export type ListBranchesForHeadCommitError = GithubOpError;
/** List branches for HEAD commit Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Returns all branches where the given commit SHA is the HEAD, or latest commit for the branch. */
export declare const listBranchesForHeadCommit: API.OperationMethod<ListBranchesForHeadCommitRequest, ListBranchesForHeadCommitResponse, ListBranchesForHeadCommitError, GithubOpContext>;
export type ListCollaboratorsError = GithubOpError;
/** List repository collaborators For organization-owned repositories, the list of collaborators includes outside collaborators, organization members that are direct collaborators, organization members with access through team memberships, organization members with access through default organization permissions, and organization owners. The `permissions` hash returned in the response contains the base role permissions of the collaborator. The `role_name` is the highest role assigned to the collaborator after considering all sources of grants, including: repo, teams, organization, and enterprise. There is presently not a way to differentiate between an organization level grant and a repository level grant from this endpoint response. Team members will include the members of child teams. The authenticated user must have write, maintain, or admin privileges on the repository to use this endpoint. For organization-owned repositories, the authenticated user needs to be a member of the organization. OAuth app tokens and personal access tokens (classic) need the `read:org` and `repo` scopes to use this endpoint. */
export declare const listCollaborators: API.PaginatedOperationMethod<ListCollaboratorsRequest, ListCollaboratorsResponse, ListCollaboratorsError, GithubOpContext, NullableCollaborator>;
export type ListCommentsForCommitError = GithubOpError;
/** List commit comments Lists the comments for a specified commit. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listCommentsForCommit: API.PaginatedOperationMethod<ListCommentsForCommitRequest, ListCommentsForCommitResponse, ListCommentsForCommitError, GithubOpContext, CommitComment>;
export type ListCommitCommentsForRepoError = GithubOpError;
/** List commit comments for a repository Lists the commit comments for a specified repository. Comments are ordered by ascending ID. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const listCommitCommentsForRepo: API.PaginatedOperationMethod<ListCommitCommentsForRepoRequest, ListCommitCommentsForRepoResponse, ListCommitCommentsForRepoError, GithubOpContext, CommitComment>;
export type ListCommitsError = GithubOpError;
/** List commits **Signature verification object** The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object: These are the possible values for `reason` in the `verification` object: */
export declare const listCommits: API.PaginatedOperationMethod<ListCommitsRequest, ListCommitsResponse, ListCommitsError, GithubOpContext, Commit>;
export type ListCommitStatusesForRefError = GithubOpError;
/** List commit statuses for a reference Users with pull access in a repository can view commit statuses for a given ref. The ref can be a SHA, a branch name, or a tag name. Statuses are returned in reverse chronological order. The first status in the list will be the latest one. This resource is also available via a legacy route: `GET /repos/:owner/:repo/statuses/:ref`. */
export declare const listCommitStatusesForRef: API.PaginatedOperationMethod<ListCommitStatusesForRefRequest, ListCommitStatusesForRefResponse, ListCommitStatusesForRefError, GithubOpContext, Status>;
export type ListContributorsError = GithubOpError;
/** List repository contributors Lists contributors to the specified repository and sorts them by the number of commits per contributor in descending order. This endpoint may return information that is a few hours old because the GitHub REST API caches contributor data to improve performance. GitHub identifies contributors by author email address. This endpoint groups contribution counts by GitHub user, which includes all associated email addresses. To improve performance, only the first 500 author email addresses in the repository link to GitHub users. The rest will appear as anonymous contributors without associated GitHub user information. */
export declare const listContributors: API.PaginatedOperationMethod<ListContributorsRequest, ListContributorsResponse, ListContributorsError, GithubOpContext, Contributor>;
export type ListCustomDeploymentRuleIntegrationsError = GithubOpError;
/** List custom deployment rule integrations available for an environment Gets all custom deployment protection rule integrations that are available for an environment. The authenticated user must have admin or owner permissions to the repository to use this endpoint. For more information about environments, see "[Using environments for deployment](https://docs.github.com/actions/deployment/targeting-different-environments/using-environments-for-deployment)." For more information about the app that is providing this custom deployment rule, see "[GET an app](https://docs.github.com/rest/apps/apps#get-an-app)". OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listCustomDeploymentRuleIntegrations: API.PaginatedOperationMethod<ListCustomDeploymentRuleIntegrationsRequest, ListCustomDeploymentRuleIntegrationsResponse, ListCustomDeploymentRuleIntegrationsError, GithubOpContext, CustomDeploymentRuleApp>;
export type ListDeployKeysError = GithubOpError;
/** List deploy keys */
export declare const listDeployKeys: API.PaginatedOperationMethod<ListDeployKeysRequest, ListDeployKeysResponse, ListDeployKeysError, GithubOpContext, DeployKey>;
export type ListDeploymentBranchPoliciesError = GithubOpError;
/** List deployment branch policies Lists the deployment branch policies for an environment. Anyone with read access to the repository can use this endpoint. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with a private repository. */
export declare const listDeploymentBranchPolicies: API.PaginatedOperationMethod<ListDeploymentBranchPoliciesRequest, ListDeploymentBranchPoliciesResponse, ListDeploymentBranchPoliciesError, GithubOpContext, DeploymentBranchPolicy>;
export type ListDeploymentsError = GithubOpError;
/** List deployments Simple filtering of deployments is available via query parameters: */
export declare const listDeployments: API.PaginatedOperationMethod<ListDeploymentsRequest, ListDeploymentsResponse, ListDeploymentsError, GithubOpContext, Deployment>;
export type ListDeploymentStatusesError = GithubOpError;
/** List deployment statuses Users with pull access can view deployment statuses for a deployment: */
export declare const listDeploymentStatuses: API.PaginatedOperationMethod<ListDeploymentStatusesRequest, ListDeploymentStatusesResponse, ListDeploymentStatusesError, GithubOpContext, DeploymentStatus>;
export type ListForAuthenticatedUserError = GithubOpError;
/** List repositories for the authenticated user Lists repositories that the authenticated user has explicit permission (`:read`, `:write`, or `:admin`) to access. The authenticated user has explicit permission to access repositories they own, repositories where they are a collaborator, and repositories that they can access through an organization membership. */
export declare const listForAuthenticatedUser: API.PaginatedOperationMethod<ListForAuthenticatedUserRequest, ListForAuthenticatedUserResponse, ListForAuthenticatedUserError, GithubOpContext, Repository>;
export type ListForksError = GithubOpError;
/** List forks */
export declare const listForks: API.PaginatedOperationMethod<ListForksRequest, ListForksResponse, ListForksError, GithubOpContext, MinimalRepository>;
export type ListForOrgError = GithubOpError;
/** List organization repositories Lists repositories for the specified organization. > [!NOTE] > In order to see the `security_and_analysis` block for a repository you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." */
export declare const listForOrg: API.PaginatedOperationMethod<ListForOrgRequest, ListForOrgResponse, ListForOrgError, GithubOpContext, MinimalRepository>;
export type ListForUserError = GithubOpError;
/** List repositories for a user Lists public repositories for the specified user. */
export declare const listForUser: API.PaginatedOperationMethod<ListForUserRequest, ListForUserResponse, ListForUserError, GithubOpContext, MinimalRepository>;
export type ListInvitationsError = GithubOpError;
/** List repository invitations When authenticating as a user with admin rights to a repository, this endpoint will list all currently open repository invitations. */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest, ListInvitationsResponse, ListInvitationsError, GithubOpContext, RepositoryInvitation>;
export type ListInvitationsForAuthenticatedUserError = GithubOpError;
/** List repository invitations for the authenticated user When authenticating as a user, this endpoint will list all currently open repository invitations for that user. */
export declare const listInvitationsForAuthenticatedUser: API.PaginatedOperationMethod<ListInvitationsForAuthenticatedUserRequest, ListInvitationsForAuthenticatedUserResponse, ListInvitationsForAuthenticatedUserError, GithubOpContext, RepositoryInvitation>;
export type ListIssueTypesError = GithubOpError;
/** List issue types for a repository Lists enabled issue types inherited from the repository owner. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. Fine-grained access tokens require the "Metadata" repository permission (read). */
export declare const listIssueTypes: API.OperationMethod<ListIssueTypesRequest, ListIssueTypesResponse, ListIssueTypesError, GithubOpContext>;
export type ListLanguagesError = GithubOpError;
/** List repository languages Lists languages for the specified repository. The value shown for each language is the number of bytes of code written in that language. */
export declare const listLanguages: API.OperationMethod<ListLanguagesRequest, ListLanguagesResponse, ListLanguagesError, GithubOpContext>;
export type ListPagesBuildsError = GithubOpError;
/** List GitHub Pages builds Lists builts of a GitHub Pages site. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const listPagesBuilds: API.PaginatedOperationMethod<ListPagesBuildsRequest, ListPagesBuildsResponse, ListPagesBuildsError, GithubOpContext, PageBuild>;
export type ListPublicError = GithubOpError;
/** List public repositories Lists all public repositories in the order that they were created. Note: - For GitHub Enterprise Server, this endpoint will only list repositories available to all users on the enterprise. - Pagination is powered exclusively by the `since` parameter. Use the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers) to get the URL for the next page of repositories. */
export declare const listPublic: API.OperationMethod<ListPublicRequest, ListPublicResponse, ListPublicError, GithubOpContext>;
export type ListPullRequestsAssociatedWithCommitError = GithubOpError;
/** List pull requests associated with a commit Lists the merged pull request that introduced the commit to the repository. If the commit is not present in the default branch, it will return merged and open pull requests associated with the commit. To list the open or merged pull requests associated with a branch, you can set the `commit_sha` parameter to the branch name. */
export declare const listPullRequestsAssociatedWithCommit: API.PaginatedOperationMethod<ListPullRequestsAssociatedWithCommitRequest, ListPullRequestsAssociatedWithCommitResponse, ListPullRequestsAssociatedWithCommitError, GithubOpContext, PullRequestSimple>;
export type ListReleaseAssetsError = GithubOpError;
/** List release assets */
export declare const listReleaseAssets: API.PaginatedOperationMethod<ListReleaseAssetsRequest, ListReleaseAssetsResponse, ListReleaseAssetsError, GithubOpContext, ReleaseAsset>;
export type ListReleasesError = GithubOpError;
/** List releases This returns a list of releases, which does not include regular Git tags that have not been associated with a release. To get a list of Git tags, use the [Repository Tags API](https://docs.github.com/rest/repos/repos#list-repository-tags). Information about published releases are available to everyone. Only users with push access will receive listings for draft releases. */
export declare const listReleases: API.PaginatedOperationMethod<ListReleasesRequest, ListReleasesResponse, ListReleasesError, GithubOpContext, Release>;
export type ListTagsError = GithubOpError;
/** List repository tags */
export declare const listTags: API.PaginatedOperationMethod<ListTagsRequest, ListTagsResponse, ListTagsError, GithubOpContext, Tag>;
export type ListTeamsError = GithubOpError;
/** List repository teams Lists the teams that have access to the specified repository and that are also visible to the authenticated user. For a public repository, a team is listed only if that team added the public repository explicitly. OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to use this endpoint with a public repository, and `repo` scope to use this endpoint with a private repository. */
export declare const listTeams: API.PaginatedOperationMethod<ListTeamsRequest, ListTeamsResponse, ListTeamsError, GithubOpContext, Team>;
export type ListWebhookDeliveriesError = GithubOpError;
/** List deliveries for a repository webhook Returns a list of webhook deliveries for a webhook configured in a repository. */
export declare const listWebhookDeliveries: API.OperationMethod<ListWebhookDeliveriesRequest, ListWebhookDeliveriesResponse, ListWebhookDeliveriesError, GithubOpContext>;
export type ListWebhooksError = GithubOpError;
/** List repository webhooks Lists webhooks for a repository. `last response` may return null if there have not been any deliveries within 30 days. */
export declare const listWebhooks: API.PaginatedOperationMethod<ListWebhooksRequest, ListWebhooksResponse, ListWebhooksError, GithubOpContext, Hook>;
export type MergeError = GithubOpError;
/** Merge a branch */
export declare const merge: API.OperationMethod<MergeRequest, Commit, MergeError, GithubOpContext>;
export type MergeUpstreamError = GithubOpError;
/** Sync a fork branch with the upstream repository Sync a branch of a forked repository to keep it up-to-date with the upstream repository. */
export declare const mergeUpstream: API.OperationMethod<MergeUpstreamRequest, MergedUpstream, MergeUpstreamError, GithubOpContext>;
export type PingWebhookError = GithubOpError;
/** Ping a repository webhook This will trigger a [ping event](https://docs.github.com/webhooks/#ping-event) to be sent to the hook. */
export declare const pingWebhook: API.OperationMethod<PingWebhookRequest, PingWebhookResponse, PingWebhookError, GithubOpContext>;
export type RedeliverWebhookDeliveryError = GithubOpError;
/** Redeliver a delivery for a repository webhook Redeliver a webhook delivery for a webhook configured in a repository. */
export declare const redeliverWebhookDelivery: API.OperationMethod<RedeliverWebhookDeliveryRequest, RedeliverWebhookDeliveryResponse, RedeliverWebhookDeliveryError, GithubOpContext>;
export type RemoveAppAccessRestrictionsError = GithubOpError;
/** Remove app access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Removes the ability of an app to push to this branch. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch. */
export declare const removeAppAccessRestrictions: API.OperationMethod<RemoveAppAccessRestrictionsRequest, RemoveAppAccessRestrictionsResponse, RemoveAppAccessRestrictionsError, GithubOpContext>;
export type RemoveCollaboratorError = GithubOpError;
/** Remove a repository collaborator Removes a collaborator from a repository. To use this endpoint, the authenticated user must either be an administrator of the repository or target themselves for removal. This endpoint also: - Cancels any outstanding invitations sent by the collaborator - Unassigns the user from any issues - Removes access to organization projects if the user is not an organization member and is not a collaborator on any other organization repositories. - Unstars the repository - Updates access permissions to packages Removing a user as a collaborator has the following effects on forks: - If the user had access to a fork through their membership to this repository, the user will also be removed from the fork. - If the user had their own fork of the repository, the fork will be deleted. - If the user still has read access to the repository, open pull requests by this user from a fork will be denied. > [!NOTE] > A user can still have access to the repository through organization permissions like base repository permissions. Although the API responds immediately, the additional permission updates might take some extra time to complete in the background. For more information on fork permissions, see "[About permissions and visibility of forks](https://docs.github.com/pull-requests/collaborating-with-pull-requests/working-with-forks/about-permissions-and-visibility-of-forks)". */
export declare const removeCollaborator: API.OperationMethod<RemoveCollaboratorRequest, RemoveCollaboratorResponse, RemoveCollaboratorError, GithubOpContext>;
export type RemoveStatusCheckContextsError = GithubOpError;
/** Remove status check contexts Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const removeStatusCheckContexts: API.OperationMethod<RemoveStatusCheckContextsRequest, RemoveStatusCheckContextsResponse, RemoveStatusCheckContextsError, GithubOpContext>;
export type RemoveStatusCheckProtectionError = GithubOpError;
/** Remove status check protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const removeStatusCheckProtection: API.OperationMethod<RemoveStatusCheckProtectionRequest, RemoveStatusCheckProtectionResponse, RemoveStatusCheckProtectionError, GithubOpContext>;
export type RemoveTeamAccessRestrictionsError = GithubOpError;
/** Remove team access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Removes the ability of a team to push to this branch. You can also remove push access for child teams. */
export declare const removeTeamAccessRestrictions: API.OperationMethod<RemoveTeamAccessRestrictionsRequest, RemoveTeamAccessRestrictionsResponse, RemoveTeamAccessRestrictionsError, GithubOpContext>;
export type RemoveUserAccessRestrictionsError = GithubOpError;
/** Remove user access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Removes the ability of a user to push to this branch. */
export declare const removeUserAccessRestrictions: API.OperationMethod<RemoveUserAccessRestrictionsRequest, RemoveUserAccessRestrictionsResponse, RemoveUserAccessRestrictionsError, GithubOpContext>;
export type RenameBranchError = GithubOpError;
/** Rename a branch Renames a branch in a repository. > [!NOTE] > Although the API responds immediately, the branch rename process might take some extra time to complete in the background. You won't be able to push to the old branch name while the rename process is in progress. For more information, see "[Renaming a branch](https://docs.github.com/github/administering-a-repository/renaming-a-branch)". The authenticated user must have push access to the branch. If the branch is the default branch, the authenticated user must also have admin or owner permissions. In order to rename the default branch, fine-grained access tokens also need the `administration:write` repository permission. */
export declare const renameBranch: API.OperationMethod<RenameBranchRequest, BranchWithProtection, RenameBranchError, GithubOpContext>;
export type ReplaceAllTopicsError = GithubOpError;
/** Replace all repository topics */
export declare const replaceAllTopics: API.OperationMethod<ReplaceAllTopicsRequest, Topic, ReplaceAllTopicsError, GithubOpContext>;
export type RequestPagesBuildError = GithubOpError;
/** Request a GitHub Pages build You can request that your site be built from the latest revision on the default branch. This has the same effect as pushing a commit to your default branch, but does not require an additional commit. Manually triggering page builds can be helpful when diagnosing build warnings and failures. Build requests are limited to one concurrent build per repository and one concurrent build per requester. If you request a build while another is still in progress, the second request will be queued until the first completes. */
export declare const requestPagesBuild: API.OperationMethod<RequestPagesBuildRequest, PageBuildStatus, RequestPagesBuildError, GithubOpContext>;
export type SetAdminBranchProtectionError = GithubOpError;
/** Set admin branch protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Adding admin enforcement requires admin or owner permissions to the repository and branch protection to be enabled. */
export declare const setAdminBranchProtection: API.OperationMethod<SetAdminBranchProtectionRequest, ProtectedBranchAdminEnforced, SetAdminBranchProtectionError, GithubOpContext>;
export type SetAppAccessRestrictionsError = GithubOpError;
/** Set app access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Replaces the list of apps that have push access to this branch. This removes all apps that previously had push access and grants push access to the new list of apps. Only GitHub Apps that are installed on the repository and that have been granted write access to the repository contents can be added as authorized actors on a protected branch. */
export declare const setAppAccessRestrictions: API.OperationMethod<SetAppAccessRestrictionsRequest, SetAppAccessRestrictionsResponse, SetAppAccessRestrictionsError, GithubOpContext>;
export type SetStatusCheckContextsError = GithubOpError;
/** Set status check contexts Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. */
export declare const setStatusCheckContexts: API.OperationMethod<SetStatusCheckContextsRequest, SetStatusCheckContextsResponse, SetStatusCheckContextsError, GithubOpContext>;
export type SetTeamAccessRestrictionsError = GithubOpError;
/** Set team access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Replaces the list of teams that have push access to this branch. This removes all teams that previously had push access and grants push access to the new list of teams. Team restrictions include child teams. */
export declare const setTeamAccessRestrictions: API.OperationMethod<SetTeamAccessRestrictionsRequest, SetTeamAccessRestrictionsResponse, SetTeamAccessRestrictionsError, GithubOpContext>;
export type SetUserAccessRestrictionsError = GithubOpError;
/** Set user access restrictions Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Replaces the list of people that have push access to this branch. This removes all people that previously had push access and grants push access to the new list of people. */
export declare const setUserAccessRestrictions: API.OperationMethod<SetUserAccessRestrictionsRequest, SetUserAccessRestrictionsResponse, SetUserAccessRestrictionsError, GithubOpContext>;
export type TestPushWebhookError = GithubOpError;
/** Test the push repository webhook This will trigger the hook with the latest push to the current repository if the hook is subscribed to `push` events. If the hook is not subscribed to `push` events, the server will respond with 204 but no test POST will be generated. > [!NOTE] > Previously `/repos/:owner/:repo/hooks/:hook_id/test` */
export declare const testPushWebhook: API.OperationMethod<TestPushWebhookRequest, TestPushWebhookResponse, TestPushWebhookError, GithubOpContext>;
export type TransferError = GithubOpError;
/** Transfer a repository A transfer request will need to be accepted by the new owner when transferring a personal repository to another user. The response will contain the original `owner`, and the transfer will continue asynchronously. For more details on the requirements to transfer personal and organization-owned repositories, see [about repository transfers](https://docs.github.com/articles/about-repository-transfers/). */
export declare const transfer: API.OperationMethod<TransferRequest, TransferResponse, TransferError, GithubOpContext>;
export type UpdateError = GithubOpError;
/** Update a repository **Note**: To edit a repository's topics, use the [Replace all repository topics](https://docs.github.com/rest/repos/repos#replace-all-repository-topics) endpoint. */
export declare const update: API.OperationMethod<UpdateRequest, FullRepository, UpdateError, GithubOpContext>;
export type UpdateBranchProtectionError = GithubOpError;
/** Update branch protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Protecting a branch requires admin or owner permissions to the repository. > [!NOTE] > Passing new arrays of `users` and `teams` replaces their previous values. > [!NOTE] > The list of users, apps, and teams in total is limited to 100 items. */
export declare const updateBranchProtection: API.OperationMethod<UpdateBranchProtectionRequest, ProtectedBranch, UpdateBranchProtectionError, GithubOpContext>;
export type UpdateCommitCommentError = GithubOpError;
/** Update a commit comment Updates the contents of a specified commit comment. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github-commitcomment.raw+json`**: Returns the raw markdown body. Response will include `body`. This is the default if you do not pass any specific media type. - **`application/vnd.github-commitcomment.text+json`**: Returns a text only representation of the markdown body. Response will include `body_text`. - **`application/vnd.github-commitcomment.html+json`**: Returns HTML rendered from the body's markdown. Response will include `body_html`. - **`application/vnd.github-commitcomment.full+json`**: Returns raw, text, and HTML representations. Response will include `body`, `body_text`, and `body_html`. */
export declare const updateCommitComment: API.OperationMethod<UpdateCommitCommentRequest, CommitComment, UpdateCommitCommentError, GithubOpContext>;
export type UpdateDeploymentBranchPolicyError = GithubOpError;
/** Update a deployment branch policy Updates a deployment branch or tag policy for an environment. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const updateDeploymentBranchPolicy: API.OperationMethod<UpdateDeploymentBranchPolicyRequest, DeploymentBranchPolicy, UpdateDeploymentBranchPolicyError, GithubOpContext>;
export type UpdateInformationAboutPagesSiteError = GithubOpError;
/** Update information about a GitHub Pages site Updates information for a GitHub Pages site. For more information, see "[About GitHub Pages](/github/working-with-github-pages/about-github-pages). The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const updateInformationAboutPagesSite: API.OperationMethod<UpdateInformationAboutPagesSiteRequest, UpdateInformationAboutPagesSiteResponse, UpdateInformationAboutPagesSiteError, GithubOpContext>;
export type UpdateInvitationError = GithubOpError;
/** Update a repository invitation */
export declare const updateInvitation: API.OperationMethod<UpdateInvitationRequest, RepositoryInvitation, UpdateInvitationError, GithubOpContext>;
export type UpdateOrgRulesetError = GithubOpError;
/** Update an organization repository ruleset Update a ruleset for an organization. */
export declare const updateOrgRuleset: API.OperationMethod<UpdateOrgRulesetRequest, RepositoryRuleset, UpdateOrgRulesetError, GithubOpContext>;
export type UpdatePullRequestReviewProtectionError = GithubOpError;
/** Update pull request review protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Updating pull request review enforcement requires admin or owner permissions to the repository and branch protection to be enabled. > [!NOTE] > Passing new arrays of `users` and `teams` replaces their previous values. */
export declare const updatePullRequestReviewProtection: API.OperationMethod<UpdatePullRequestReviewProtectionRequest, ProtectedBranchPullRequestReview, UpdatePullRequestReviewProtectionError, GithubOpContext>;
export type UpdateReleaseError = GithubOpError;
/** Update a release Users with push access to the repository can edit a release. > [!NOTE] > If the resolved target commit (the new value of `target_commitish` if you are changing it, otherwise the existing target) adds or modifies any file under `.github/workflows/` relative to the repository's default branch, the authenticating token must be authorized to modify workflows. Otherwise, this endpoint returns `404 Not Found`; some authentication paths surface `403 Resource not accessible by integration` instead. OAuth app tokens and personal access tokens (classic) need the `workflow` scope when the resolved target commit modifies workflow files. Fine-grained access tokens and GitHub App installation tokens also need the "Workflows" repository permission (write). The `GITHUB_TOKEN` available to GitHub Actions cannot be authorized for this; for more information, see "[Automatic token authentication](https://docs.github.com/actions/security-guides/automatic-token-authentication#permissions-for-the-github_token)". */
export declare const updateRelease: API.OperationMethod<UpdateReleaseRequest, Release, UpdateReleaseError, GithubOpContext>;
export type UpdateReleaseAssetError = GithubOpError;
/** Update a release asset Users with push access to the repository can edit a release asset. */
export declare const updateReleaseAsset: API.OperationMethod<UpdateReleaseAssetRequest, ReleaseAsset, UpdateReleaseAssetError, GithubOpContext>;
export type UpdateRepoRulesetError = GithubOpError;
/** Update a repository ruleset Update a ruleset for a repository. */
export declare const updateRepoRuleset: API.OperationMethod<UpdateRepoRulesetRequest, RepositoryRuleset, UpdateRepoRulesetError, GithubOpContext>;
export type UpdateStatusCheckProtectionError = GithubOpError;
/** Update status check protection Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation. Updating required status checks requires admin or owner permissions to the repository and branch protection to be enabled. */
export declare const updateStatusCheckProtection: API.OperationMethod<UpdateStatusCheckProtectionRequest, StatusCheckPolicy, UpdateStatusCheckProtectionError, GithubOpContext>;
export type UpdateWebhookError = GithubOpError;
/** Update a repository webhook Updates a webhook configured in a repository. If you previously had a `secret` set, you must provide the same `secret` or set a new `secret` or the secret will be removed. If you are only updating individual webhook `config` properties, use "[Update a webhook configuration for a repository](/rest/webhooks/repo-config#update-a-webhook-configuration-for-a-repository)." */
export declare const updateWebhook: API.OperationMethod<UpdateWebhookRequest, Hook, UpdateWebhookError, GithubOpContext>;
export type UpdateWebhookConfigForRepoError = GithubOpError;
/** Update a webhook configuration for a repository Updates the webhook configuration for a repository. To update more information about the webhook, including the `active` state and `events`, use "[Update a repository webhook](/rest/webhooks/repos#update-a-repository-webhook)." OAuth app tokens and personal access tokens (classic) need the `write:repo_hook` or `repo` scope to use this endpoint. */
export declare const updateWebhookConfigForRepo: API.OperationMethod<UpdateWebhookConfigForRepoRequest, WebhookConfig, UpdateWebhookConfigForRepoError, GithubOpContext>;
export type UploadReleaseAssetError = GithubOpError;
/** Upload a release asset This endpoint makes use of a [Hypermedia relation](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#hypermedia) to determine which URL to access. The endpoint you call to upload release assets is specific to your release. Use the `upload_url` returned in the response of the [Create a release endpoint](https://docs.github.com/rest/releases/releases#create-a-release) to upload a release asset. You need to use an HTTP client which supports [SNI](http://en.wikipedia.org/wiki/Server_Name_Indication) to make calls to this endpoint. Most libraries will set the required `Content-Length` header automatically. Use the required `Content-Type` header to provide the media type of the asset. For a list of media types, see [Media Types](https://www.iana.org/assignments/media-types/media-types.xhtml). For example: `application/zip` GitHub expects the asset data in its raw binary form, rather than JSON. You will send the raw binary content of the asset as the request body. Everything else about the endpoint is the same as the rest of the API. For example, you'll still need to pass your authentication to be able to upload an asset. When an upstream failure occurs, you will receive a `502 Bad Gateway` status. This may leave an empty asset with a state of `starter`. It can be safely deleted. **Notes:** * GitHub renames asset filenames that have special characters, non-alphanumeric characters, and leading or trailing periods. The "[List release assets](https://docs.github.com/rest/releases/assets#list-release-assets)" endpoint lists the renamed filenames. For more information and help, contact [GitHub Support](https://support.github.com/contact?tags=dotcom-rest-api). * To find the `release_id` query the [`GET /repos/{owner}/{repo}/releases/latest` endpoint](https://docs.github.com/rest/releases/releases#get-the-latest-release). * If you upload an asset with the same filename as another uploaded asset, you'll receive an error and must delete the old file before you can re-upload the new asset. */
export declare const uploadReleaseAsset: API.OperationMethod<UploadReleaseAssetRequest, ReleaseAsset, UploadReleaseAssetError, GithubOpContext>;
//# sourceMappingURL=repos.d.ts.map