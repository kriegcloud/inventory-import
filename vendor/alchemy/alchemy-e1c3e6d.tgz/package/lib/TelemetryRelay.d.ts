import * as Effect from "effect/Effect";
import { HttpServerRequest } from "effect/http/HttpServerRequest";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
/** An OpenTelemetry signal the relay forwards. */
export type Signal = "traces" | "logs" | "metrics";
/** Where the relay forwards one batch: an OTLP/HTTP endpoint and the headers to send it. */
export interface Destination {
    readonly url: string;
    readonly headers?: Readonly<Record<string, string>>;
}
/** Options for {@link relay}. */
export interface RelayOptions<R = never> {
    /**
     * The signals the relay accepts. A post for any other gets a 404.
     * @default ["traces", "logs", "metrics"]
     */
    readonly signals?: ReadonlyArray<Signal>;
    /**
     * The largest body accepted, in bytes. Larger posts get a 413.
     * @default 1048576
     */
    readonly maxBytes?: number;
    /**
     * Decide whether to accept a post, e.g. only from signed-in users. A post
     * it refuses gets a 403. The relay is a public endpoint, so gate it when
     * you can.
     * @default every post is accepted
     */
    readonly authorize?: Effect.Effect<boolean, never, R | HttpServerRequest>;
    /**
     * Choose where a batch goes. It receives the destinations this runtime
     * exports its own telemetry to, and returns the ones to forward to: all
     * of them, some, or others entirely.
     * @default the runtime's own destinations for that signal
     */
    readonly route?: (signal: Signal, configured: ReadonlyArray<Destination>) => Effect.Effect<ReadonlyArray<Destination>, never, R | HttpServerRequest>;
}
/**
 * Collect OpenTelemetry from browsers and other clients through your own
 * Worker or Function, and forward it to where your backend's telemetry
 * goes, with the backend's own credentials. Clients post OTLP/HTTP to a
 * path ending in `/v1/traces`, `/v1/logs` or `/v1/metrics`; each body is
 * forwarded unchanged, JSON or protobuf.
 *
 * No ingest token ever reaches the client, the client posts to its own
 * origin, and `route` decides where each batch goes.
 *
 * ### Collecting browser traces
 * **Example:** Relay the app's spans through the backend Worker
 * ```typescript
 * import * as Telemetry from "alchemy/Telemetry";
 *
 * const telemetry = Telemetry.relay({ signals: ["traces"] });
 *
 * // in the Worker's fetch handler
 * if (path.startsWith("/api/telemetry/")) return yield* telemetry;
 * ```
 *
 * **Example:** The browser exports to it
 * ```typescript
 * import * as OtlpTracer from "effect/observability/OtlpTracer";
 *
 * OtlpTracer.layer({
 *   url: `${location.origin}/api/telemetry/v1/traces`,
 *   resource: { serviceName: "bank-web" },
 * });
 * ```
 *
 * ### Routing batches
 * **Example:** Send browser traces to their own dataset
 * ```typescript
 * Telemetry.relay({
 *   route: (signal, configured) =>
 *     Effect.succeed(
 *       signal === "traces"
 *         ? configured.map((d) => ({ ...d, headers: { ...d.headers, "x-axiom-dataset": "browser" } }))
 *         : configured,
 *     ),
 * });
 * ```
 *
 * @primitive
 */
export declare const relay: <R = never>(options?: RelayOptions<R>) => Effect.Effect<HttpServerResponse.HttpServerResponse, never, R | HttpServerRequest>;
//# sourceMappingURL=TelemetryRelay.d.ts.map