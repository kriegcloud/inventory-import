import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface GetFindingRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies a finding. */
    finding_number: number;
}
/** State of the code quality finding. */
export type CodeQualityFindingState = "open" | "dismissed";
/** The severity of the rule used to detect the finding. */
export type CodeQualityFindingRuleSeverity = "error" | "warning" | "note" | "none";
/** The category of the rule used to detect the finding. */
export type CodeQualityFindingRuleCategory = "none" | "maintainability" | "reliability";
/** Code quality rule */
export interface CodeQualityFindingRule {
    /** A unique identifier for the rule used to detect the finding. */
    id: string;
    /** The name of the rule used to detect the finding. */
    title: string;
    /** A short description of the rule used to detect the finding. */
    description: string;
    /** A detailed description of the rule used to detect the finding. */
    help?: string | undefined;
    /** The severity of the rule used to detect the finding. */
    severity: CodeQualityFindingRuleSeverity;
    /** The category of the rule used to detect the finding. */
    category: CodeQualityFindingRuleCategory;
}
/** Code quality file location */
export interface CodeQualityFindingLocation {
    /** The file path where the finding was detected. */
    path: string;
    /** The line number where the finding starts. */
    start_line?: number | undefined;
    /** The column number where the finding starts. */
    start_column?: number | undefined;
    /** The line number where the finding ends. */
    end_line?: number | undefined;
    /** The column number where the finding ends. */
    end_column?: number | undefined;
}
/** Code quality finding message */
export interface CodeQualityFindingMessage {
    /** The message text of the code quality finding. */
    text: string;
    /** The message text of the code quality finding in markdown format. */
    markdown: string;
}
/** Code quality finding */
export interface CodeQualityFinding {
    /** The finding number. */
    number: number;
    /** State of the code quality finding. */
    state: CodeQualityFindingState;
    /** The REST API URL of the code quality finding resource. */
    url: string;
    rule: CodeQualityFindingRule;
    location: CodeQualityFindingLocation;
    message: CodeQualityFindingMessage;
    /** The time the code quality finding was created. */
    created_at?: string | undefined;
}
export interface GetSetupRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Code quality setup has been configured or not. */
export type CodeQualitySetupState = "configured" | "not-configured";
export type CodeQualitySetupLanguagesItem = "csharp" | "go" | "java-kotlin" | "javascript-typescript" | "python" | "ruby" | "rust";
/** Languages to be analyzed. */
export type CodeQualitySetupLanguagesList = Array<CodeQualitySetupLanguagesItem>;
/** Runner type to be used. */
export type CodeQualitySetupRunnerType = "standard" | "labeled";
/** The frequency of the periodic analysis. */
export type CodeQualitySetupSchedule = "weekly";
/** The AI findings configuration for the repository. */
export type CodeQualitySetupAiFindingsOption = "disabled" | "on_push";
/** Configuration for code quality setup. */
export interface CodeQualitySetup {
    /** Code quality setup has been configured or not. */
    state?: CodeQualitySetupState | undefined;
    /** Languages to be analyzed. */
    languages?: CodeQualitySetupLanguagesList | undefined;
    /** Runner type to be used. */
    runner_type?: CodeQualitySetupRunnerType | null | undefined;
    /** Runner label to be used if the runner type is labeled. */
    runner_label?: string | null | undefined;
    /** Timestamp of latest configuration update. */
    updated_at?: string | null | undefined;
    /** The frequency of the periodic analysis. */
    schedule?: CodeQualitySetupSchedule | null | undefined;
    /** The AI findings configuration for the repository. */
    ai_findings_option?: CodeQualitySetupAiFindingsOption | null | undefined;
}
export type ListFindingsForRepoRequestDirection = "asc" | "desc";
export type ListFindingsForRepoRequestState = "open" | "dismissed";
export interface ListFindingsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The direction to sort the results by. */
    direction?: ListFindingsForRepoRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** If specified, only code quality findings with this state will be returned. */
    state?: ListFindingsForRepoRequestState | (string & {}) | undefined;
}
export type ListFindingsForRepoResponseBodyList = Array<CodeQualityFinding>;
export type ListFindingsForRepoResponse = ListFindingsForRepoResponseBodyList;
/** The desired state of code quality setup. */
export type UpdateSetupRequestState = "configured" | "not-configured";
/** Runner type to be used. */
export type UpdateSetupRequestRunnerType = "standard" | "labeled";
export type UpdateSetupRequestLanguagesItem = "csharp" | "go" | "java-kotlin" | "javascript-typescript" | "python" | "ruby";
/** Languages to be analyzed. */
export type UpdateSetupRequestLanguagesList = Array<UpdateSetupRequestLanguagesItem | (string & {})>;
/** Whether AI findings run for Code Quality on this repository. */
export type UpdateSetupRequestAiFindingsOption = "disabled" | "on_push";
export interface UpdateSetupRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The desired state of code quality setup. */
    state?: UpdateSetupRequestState | (string & {}) | undefined;
    /** Runner type to be used. */
    runner_type?: UpdateSetupRequestRunnerType | (string & {}) | undefined;
    /** Runner label to be used if the runner type is labeled. */
    runner_label?: string | null | undefined;
    /** Languages to be analyzed. */
    languages?: UpdateSetupRequestLanguagesList | undefined;
    /** Whether AI findings run for Code Quality on this repository. */
    ai_findings_option?: UpdateSetupRequestAiFindingsOption | (string & {}) | undefined;
}
export type UpdateSetupResponse = unknown;
export type GetFindingError = GithubOpError;
/** Get a code quality finding Gets a single code quality finding. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getFinding: API.OperationMethod<GetFindingRequest, CodeQualityFinding, GetFindingError, GithubOpContext>;
export type GetSetupError = GithubOpError;
/** Get a code quality setup configuration Gets a code quality setup configuration. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getSetup: API.OperationMethod<GetSetupRequest, CodeQualitySetup, GetSetupError, GithubOpContext>;
export type ListFindingsForRepoError = GithubOpError;
/** List code quality findings for a repository Lists code quality findings for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const listFindingsForRepo: API.OperationMethod<ListFindingsForRepoRequest, ListFindingsForRepoResponse, ListFindingsForRepoError, GithubOpContext>;
export type UpdateSetupError = GithubOpError;
/** Update a code quality setup configuration Updates a code quality setup configuration. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const updateSetup: API.OperationMethod<UpdateSetupRequest, UpdateSetupResponse, UpdateSetupError, GithubOpContext>;
//# sourceMappingURL=code_quality.d.ts.map