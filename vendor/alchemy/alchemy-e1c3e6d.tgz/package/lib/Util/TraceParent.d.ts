import * as Effect from "effect/Effect";
import * as Stream from "effect/Stream";
/**
 * The span a child process or RPC call runs under, so its records and spans
 * join the caller's trace instead of starting their own.
 */
export interface TraceParent {
    readonly traceId: string;
    readonly spanId: string;
}
/** Set on alchemy child processes to the trace they report under. */
export declare const TRACE_PARENT_ENV = "ALCHEMY_TRACE_PARENT";
/**
 * This process's trace, for records logged outside any span (startup,
 * shutdown, finalizers): the parent's when it passed one in
 * {@link TRACE_PARENT_ENV}, otherwise a new one. It ties a process's
 * untraced records together and to its parent's, without a span that would
 * stay open for the life of the process.
 */
export declare const processTrace: TraceParent;
/** The caller's current span, if it is in one. */
export declare const currentTraceParent: Effect.Effect<TraceParent | undefined>;
/**
 * {@link TRACE_PARENT_ENV} for a child process: the current span, or this
 * process's trace outside one.
 */
export declare const traceParentEnv: Effect.Effect<Record<string, string>>;
/** Run `effect` as a child of `parent`, when there is one. */
export declare const withTraceParent: (parent: TraceParent | undefined) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
/** Run `stream` (its whole execution, not just its construction) as a child of `parent`. */
export declare const withStreamTraceParent: (parent: TraceParent | undefined) => <A, E, R>(stream: Stream.Stream<A, E, R>) => Stream.Stream<A, E, R>;
//# sourceMappingURL=TraceParent.d.ts.map