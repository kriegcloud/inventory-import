import * as Context from "effect/Context";
declare const Request_base: Context.ServiceClass<Request, "Request", globalThis.Request>;
export declare class Request extends Request_base {
}
export {};
//# sourceMappingURL=Request.d.ts.map