import * as Effect from "effect/Effect";
export type OutputChannel = "stdout" | "stderr";
/**
 * Sigil-themed resource attribution shared by every append-only log path.
 * Without `colors`, the color level is detected for stdout.
 */
export declare const formatResourceTag: (id: string, colors?: boolean) => string;
/** Remove a pretty Effect prefix already rendered by a child process. */
export declare const stripChildEffectPrefix: (line: string) => string;
/**
 * Log one line a resource-owned process wrote, as a structured record: the
 * child's text (with any pretty Effect prefix removed) plus the resource and
 * stream it came from. The record keeps the text as written; the renderer
 * draws the resource tag and strips styling when colors are off. A JSON line from an alchemy child is replayed as-is.
 *
 * stderr is a process transport, not a semantic failure: Vite and many other
 * tools write warnings, progress, and ordinary diagnostics there, so both
 * streams log at Info and carry the stream as data.
 */
export declare const logResourceLine: (id: string, channel: OutputChannel, line: string) => Effect.Effect<void, never, never>;
/**
 * Line-buffered output for resource-owned child processes whose streams
 * arrive as chunks outside an Effect (workerd output pumps, stream mirrors).
 * Captures the caller's services so each line goes through its loggers.
 */
export declare const makeResourceOutput: (id: string) => Effect.Effect<{
    stdout: {
        push(chunk: string): void;
        flush(): void;
    };
    stderr: {
        push(chunk: string): void;
        flush(): void;
    };
}, never, never>;
/**
 * Effect-native output for resource-owned child processes whose streams are
 * already consumed inside an Effect.
 */
export declare const makeResourceLogger: (id: string) => (channel: OutputChannel, line: string) => Effect.Effect<void, never, never>;
//# sourceMappingURL=ResourceOutput.d.ts.map