import * as Effect from "effect/Effect";
import type * as ModelSearch from "../../Explore/internal/ModelSearch.ts";
import * as Script from "../../Explore/internal/Script.ts";
import type * as Model from "../../Model.ts";
/** A rule about a rewrite or a compaction, as far as the runs on the real model say. */
export interface Checked {
    readonly name: string;
    readonly kind: "compaction" | "roll-up" | "rewrite";
    /** What the rule says, for a report. */
    readonly says: string;
    /** How many runs looked at it. */
    runs: number;
    /** A view said to hold less after the compaction, on purpose: what broke it is let go. */
    readonly allowed?: true;
    /** The first run that broke it: the sequence, as a story, and what it showed. */
    broken: {
        readonly story: ModelSearch.Story;
        readonly script: string;
        readonly shown: string;
    } | undefined;
}
export interface Report {
    readonly rules: ReadonlyArray<Checked>;
    /** How many sequences were run with a rewrite or a compaction put in. */
    readonly runs: number;
    /** Whether the runs stopped at the budget before every place was tried. */
    readonly truncated: boolean;
    /** The rewrites no run gave an input: no value in a sequence fits one of their fields. */
    readonly uninstantiated: ReadonlyArray<string>;
}
export interface Options {
    /** The most sequences run with a rewrite or a compaction put in. */
    readonly budget: number;
    /** The views that may read a roll-up as something else than the events it replaces, as `View.Compaction`. */
    readonly lossy: ReadonlyArray<string>;
    /** The rewrites proved to keep every invariant: one is run only where a compaction could change what it does. */
    readonly proved: ReadonlySet<string>;
}
/**
 * Run each sequence again on the real model with a compaction, then a
 * rewrite, put in at each place a caller could have run one, and say what
 * each leaves:
 *
 * - a compaction is refused nowhere, and the sequence goes on as it did;
 * - a view built after a compaction holds what one built from the events did;
 * - a rewrite is refused nowhere, and leaves every instance in its rules;
 * - a rewrite leaves a compacted instance as it leaves one that kept its events.
 */
export declare const check: (model: Model.Any, found: readonly {
    readonly story: ModelSearch.Story;
}[], run: (...steps: ReadonlyArray<unknown>) => Effect.Effect<void, unknown>, stepOf: (op: Script.Op) => ReadonlyArray<unknown>, options: Options) => Effect.Effect<Report, never, never>;
//# sourceMappingURL=Histories.d.ts.map