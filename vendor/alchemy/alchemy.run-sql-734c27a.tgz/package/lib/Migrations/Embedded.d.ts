/**
 * SQL migrations embedded into a Workers-style runtime bundle: captured
 * from a migrations directory during construction, carried into the
 * bundle as records, and applied to an object's native SQLite storage at
 * activation. Shared by every Durable Object host (Cloudflare today).
 * Runtime-safe: construction-time capture lives in `EmbeddedCapture.ts`.
 *
 * @internal
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { MigrationError, type MigrationRecord, type SqlExecutor } from "./Format.ts";
/** SQL files captured during construction and embedded in the runtime bundle. */
export interface SqlMigrationSnapshot {
    /** Retained for compatibility with existing migration snapshots. */
    readonly _tag: "Cloudflare.SqlMigrations";
    /** The per-instance applied-migrations table. */
    readonly table: string;
    /** Ordered SQL records, including their content hashes. */
    readonly records: ReadonlyArray<MigrationRecord>;
}
/** @internal */
export interface SqlMigrationsExport {
    readonly kind: "sqlMigrations";
    readonly snapshot: SqlMigrationSnapshot;
}
/** @internal */
export declare const isSqlMigrationsExport: (value: unknown) => value is SqlMigrationsExport;
declare const SqlMigrationsRuntime_base: Context.ServiceClass<SqlMigrationsRuntime, "Cloudflare.SqlMigrationsRuntime", Readonly<Record<string, SqlMigrationSnapshot>>>;
export declare class SqlMigrationsRuntime extends SqlMigrationsRuntime_base {
}
/** Native synchronous SQLite storage (workerd's `ctx.storage`). */
export interface NativeSyncSqlStorage {
    readonly sql: {
        readonly exec: (sql: string) => {
            toArray(): Array<Record<string, unknown>>;
        };
    };
    readonly transactionSync: <A>(run: () => A) => A;
}
/** A migration executor over native synchronous SQLite storage. */
export declare const makeSyncSqlExecutor: (storage: NativeSyncSqlStorage) => SqlExecutor;
/** Apply pending files, each with its history row in one native transaction. */
export declare const applySqlMigrationSnapshot: (migrations: SqlMigrationSnapshot, executor: SqlExecutor) => Effect.Effect<void, MigrationError | import("./Format.ts").MigrationHistoryConflictError, never>;
export {};
//# sourceMappingURL=Embedded.d.ts.map