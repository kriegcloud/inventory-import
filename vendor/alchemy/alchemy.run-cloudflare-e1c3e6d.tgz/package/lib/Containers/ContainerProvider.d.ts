import { Docker } from "@alchemy.run/docker/Docker";
import * as Containers from "@distilled.cloud/cloudflare/containers";
import { AlchemyContext } from "alchemy/AlchemyContext";
import * as Provider from "alchemy/Provider";
import * as Effect from "effect/Effect";
import * as Path from "effect/Path";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { ContainerApplication } from "./ContainerApplication.ts";
declare const ContainerProviderConflict_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContainerProviderConflict";
} & Readonly<A>;
export declare class ContainerProviderConflict extends ContainerProviderConflict_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
declare const ContainerProviderOperationFailed_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContainerProviderOperationFailed";
} & Readonly<A>;
export declare class ContainerProviderOperationFailed extends ContainerProviderOperationFailed_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
declare const ContainerProviderUnexpectedResponse_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ContainerProviderUnexpectedResponse";
} & Readonly<A>;
export declare class ContainerProviderUnexpectedResponse extends ContainerProviderUnexpectedResponse_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export declare const LiveContainerProvider: () => import("effect/Layer").Layer<Provider.Provider<ContainerApplication<unknown>>, never, AlchemyContext | CloudflareEnvironment | Docker | import("effect/FileSystem").FileSystem | Path.Path | import("alchemy").Stack | import("alchemy").Stage | Containers.CloudflareOpContext>;
export declare const retryForContainerApplicationReadiness: <A, E, R>(operation: string, applicationId: string, effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
export {};
//# sourceMappingURL=ContainerProvider.d.ts.map