import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AuthorizationNotFoundFault_base: S.TaggedErrorClass<"AuthorizationNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class AuthorizationNotFoundFault extends /*@__PURE__*/ AuthorizationNotFoundFault_base {
}
declare const CertificateNotFoundFault_base: S.TaggedErrorClass<"CertificateNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CertificateNotFoundFault extends /*@__PURE__*/ CertificateNotFoundFault_base {
}
declare const DBClusterAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterAlreadyExistsFault extends /*@__PURE__*/ DBClusterAlreadyExistsFault_base {
}
declare const DBClusterDeletionProtected_base: S.TaggedErrorClass<"DBClusterDeletionProtected", {
    readonly message: any;
}>;
export declare class DBClusterDeletionProtected extends /*@__PURE__*/ DBClusterDeletionProtected_base {
}
declare const DBClusterNotFoundFault_base: S.TaggedErrorClass<"DBClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterNotFoundFault extends /*@__PURE__*/ DBClusterNotFoundFault_base {
}
declare const DBClusterParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBClusterParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterParameterGroupNotFoundFault extends /*@__PURE__*/ DBClusterParameterGroupNotFoundFault_base {
}
declare const DBClusterQuotaExceededFault_base: S.TaggedErrorClass<"DBClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DBClusterQuotaExceededFault extends /*@__PURE__*/ DBClusterQuotaExceededFault_base {
}
declare const DBClusterSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBClusterSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBClusterSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBClusterSnapshotAlreadyExistsFault_base {
}
declare const DBClusterSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBClusterSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBClusterSnapshotNotFoundFault extends /*@__PURE__*/ DBClusterSnapshotNotFoundFault_base {
}
declare const DBInstanceAlreadyExistsFault_base: S.TaggedErrorClass<"DBInstanceAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBInstanceAlreadyExistsFault extends /*@__PURE__*/ DBInstanceAlreadyExistsFault_base {
}
declare const DBInstanceNotFoundFault_base: S.TaggedErrorClass<"DBInstanceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBInstanceNotFoundFault extends /*@__PURE__*/ DBInstanceNotFoundFault_base {
}
declare const DBParameterGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBParameterGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBParameterGroupAlreadyExistsFault extends /*@__PURE__*/ DBParameterGroupAlreadyExistsFault_base {
}
declare const DBParameterGroupNotFoundFault_base: S.TaggedErrorClass<"DBParameterGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBParameterGroupNotFoundFault extends /*@__PURE__*/ DBParameterGroupNotFoundFault_base {
}
declare const DBParameterGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBParameterGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBParameterGroupQuotaExceededFault extends /*@__PURE__*/ DBParameterGroupQuotaExceededFault_base {
}
declare const DBSecurityGroupNotFoundFault_base: S.TaggedErrorClass<"DBSecurityGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSecurityGroupNotFoundFault extends /*@__PURE__*/ DBSecurityGroupNotFoundFault_base {
}
declare const DBSnapshotAlreadyExistsFault_base: S.TaggedErrorClass<"DBSnapshotAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSnapshotAlreadyExistsFault extends /*@__PURE__*/ DBSnapshotAlreadyExistsFault_base {
}
declare const DBSnapshotNotFoundFault_base: S.TaggedErrorClass<"DBSnapshotNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSnapshotNotFoundFault extends /*@__PURE__*/ DBSnapshotNotFoundFault_base {
}
declare const DBSubnetGroupAlreadyExistsFault_base: S.TaggedErrorClass<"DBSubnetGroupAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class DBSubnetGroupAlreadyExistsFault extends /*@__PURE__*/ DBSubnetGroupAlreadyExistsFault_base {
}
declare const DBSubnetGroupDoesNotCoverEnoughAZs_base: S.TaggedErrorClass<"DBSubnetGroupDoesNotCoverEnoughAZs", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupDoesNotCoverEnoughAZs extends /*@__PURE__*/ DBSubnetGroupDoesNotCoverEnoughAZs_base {
}
declare const DBSubnetGroupNotFoundFault_base: S.TaggedErrorClass<"DBSubnetGroupNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupNotFoundFault extends /*@__PURE__*/ DBSubnetGroupNotFoundFault_base {
}
declare const DBSubnetGroupQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetGroupQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetGroupQuotaExceededFault extends /*@__PURE__*/ DBSubnetGroupQuotaExceededFault_base {
}
declare const DBSubnetQuotaExceededFault_base: S.TaggedErrorClass<"DBSubnetQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBSubnetQuotaExceededFault extends /*@__PURE__*/ DBSubnetQuotaExceededFault_base {
}
declare const DBUpgradeDependencyFailureFault_base: S.TaggedErrorClass<"DBUpgradeDependencyFailureFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class DBUpgradeDependencyFailureFault extends /*@__PURE__*/ DBUpgradeDependencyFailureFault_base {
}
declare const EventSubscriptionQuotaExceededFault_base: S.TaggedErrorClass<"EventSubscriptionQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class EventSubscriptionQuotaExceededFault extends /*@__PURE__*/ EventSubscriptionQuotaExceededFault_base {
}
declare const GlobalClusterAlreadyExistsFault_base: S.TaggedErrorClass<"GlobalClusterAlreadyExistsFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class GlobalClusterAlreadyExistsFault extends /*@__PURE__*/ GlobalClusterAlreadyExistsFault_base {
}
declare const GlobalClusterNotFoundFault_base: S.TaggedErrorClass<"GlobalClusterNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterNotFoundFault extends /*@__PURE__*/ GlobalClusterNotFoundFault_base {
}
declare const GlobalClusterQuotaExceededFault_base: S.TaggedErrorClass<"GlobalClusterQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GlobalClusterQuotaExceededFault extends /*@__PURE__*/ GlobalClusterQuotaExceededFault_base {
}
declare const InstanceQuotaExceededFault_base: S.TaggedErrorClass<"InstanceQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceQuotaExceededFault extends /*@__PURE__*/ InstanceQuotaExceededFault_base {
}
declare const InsufficientDBClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientDBClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InsufficientDBClusterCapacityFault extends /*@__PURE__*/ InsufficientDBClusterCapacityFault_base {
}
declare const InsufficientDBInstanceCapacityFault_base: S.TaggedErrorClass<"InsufficientDBInstanceCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientDBInstanceCapacityFault extends /*@__PURE__*/ InsufficientDBInstanceCapacityFault_base {
}
declare const InsufficientStorageClusterCapacityFault_base: S.TaggedErrorClass<"InsufficientStorageClusterCapacityFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InsufficientStorageClusterCapacityFault extends /*@__PURE__*/ InsufficientStorageClusterCapacityFault_base {
}
declare const InvalidDBClusterSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBClusterSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterSnapshotStateFault extends /*@__PURE__*/ InvalidDBClusterSnapshotStateFault_base {
}
declare const InvalidDBClusterStateFault_base: S.TaggedErrorClass<"InvalidDBClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBClusterStateFault extends /*@__PURE__*/ InvalidDBClusterStateFault_base {
}
declare const InvalidDBInstanceStateFault_base: S.TaggedErrorClass<"InvalidDBInstanceStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBInstanceStateFault extends /*@__PURE__*/ InvalidDBInstanceStateFault_base {
}
declare const InvalidDBParameterGroupStateFault_base: S.TaggedErrorClass<"InvalidDBParameterGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBParameterGroupStateFault extends /*@__PURE__*/ InvalidDBParameterGroupStateFault_base {
}
declare const InvalidDBSecurityGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSecurityGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSecurityGroupStateFault extends /*@__PURE__*/ InvalidDBSecurityGroupStateFault_base {
}
declare const InvalidDBSnapshotStateFault_base: S.TaggedErrorClass<"InvalidDBSnapshotStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSnapshotStateFault extends /*@__PURE__*/ InvalidDBSnapshotStateFault_base {
}
declare const InvalidDBSubnetGroupStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetGroupStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetGroupStateFault extends /*@__PURE__*/ InvalidDBSubnetGroupStateFault_base {
}
declare const InvalidDBSubnetStateFault_base: S.TaggedErrorClass<"InvalidDBSubnetStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDBSubnetStateFault extends /*@__PURE__*/ InvalidDBSubnetStateFault_base {
}
declare const InvalidEventSubscriptionStateFault_base: S.TaggedErrorClass<"InvalidEventSubscriptionStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidEventSubscriptionStateFault extends /*@__PURE__*/ InvalidEventSubscriptionStateFault_base {
}
declare const InvalidGlobalClusterStateFault_base: S.TaggedErrorClass<"InvalidGlobalClusterStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidGlobalClusterStateFault extends /*@__PURE__*/ InvalidGlobalClusterStateFault_base {
}
declare const InvalidRestoreFault_base: S.TaggedErrorClass<"InvalidRestoreFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRestoreFault extends /*@__PURE__*/ InvalidRestoreFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const InvalidVPCNetworkStateFault_base: S.TaggedErrorClass<"InvalidVPCNetworkStateFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidVPCNetworkStateFault extends /*@__PURE__*/ InvalidVPCNetworkStateFault_base {
}
declare const KMSKeyNotAccessibleFault_base: S.TaggedErrorClass<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const NetworkTypeNotSupported_base: S.TaggedErrorClass<"NetworkTypeNotSupported", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NetworkTypeNotSupported extends /*@__PURE__*/ NetworkTypeNotSupported_base {
}
declare const ResourceNotFoundFault_base: S.TaggedErrorClass<"ResourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const SharedSnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SharedSnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SharedSnapshotQuotaExceededFault extends /*@__PURE__*/ SharedSnapshotQuotaExceededFault_base {
}
declare const SnapshotQuotaExceededFault_base: S.TaggedErrorClass<"SnapshotQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SnapshotQuotaExceededFault extends /*@__PURE__*/ SnapshotQuotaExceededFault_base {
}
declare const SNSInvalidTopicFault_base: S.TaggedErrorClass<"SNSInvalidTopicFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.TaggedErrorClass<"SNSNoAuthorizationFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const SNSTopicArnNotFoundFault_base: S.TaggedErrorClass<"SNSTopicArnNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SNSTopicArnNotFoundFault extends /*@__PURE__*/ SNSTopicArnNotFoundFault_base {
}
declare const SourceNotFoundFault_base: S.TaggedErrorClass<"SourceNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SourceNotFoundFault extends /*@__PURE__*/ SourceNotFoundFault_base {
}
declare const StorageQuotaExceededFault_base: S.TaggedErrorClass<"StorageQuotaExceededFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageQuotaExceededFault extends /*@__PURE__*/ StorageQuotaExceededFault_base {
}
declare const StorageTypeNotSupportedFault_base: S.TaggedErrorClass<"StorageTypeNotSupportedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class StorageTypeNotSupportedFault extends /*@__PURE__*/ StorageTypeNotSupportedFault_base {
}
declare const SubnetAlreadyInUse_base: S.TaggedErrorClass<"SubnetAlreadyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const SubscriptionAlreadyExistFault_base: S.TaggedErrorClass<"SubscriptionAlreadyExistFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionAlreadyExistFault extends /*@__PURE__*/ SubscriptionAlreadyExistFault_base {
}
declare const SubscriptionCategoryNotFoundFault_base: S.TaggedErrorClass<"SubscriptionCategoryNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionCategoryNotFoundFault extends /*@__PURE__*/ SubscriptionCategoryNotFoundFault_base {
}
declare const SubscriptionNotFoundFault_base: S.TaggedErrorClass<"SubscriptionNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SubscriptionNotFoundFault extends /*@__PURE__*/ SubscriptionNotFoundFault_base {
}
export interface AddSourceIdentifierToSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SourceIdentifier?: string | undefined;
}
export type SourceIdsList = string[];
export type EventCategoriesList = string[];
export interface EventSubscription {
    CustomerAwsId?: string | undefined;
    CustSubscriptionId?: string | undefined;
    SnsTopicArn?: string | undefined;
    Status?: string | undefined;
    SubscriptionCreationTime?: string | undefined;
    SourceType?: string | undefined;
    SourceIdsList?: string[] | undefined;
    EventCategoriesList?: string[] | undefined;
    Enabled?: boolean | undefined;
    EventSubscriptionArn?: string | undefined;
}
export interface AddSourceIdentifierToSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceName?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface AddTagsToResourceResponse {
}
export interface ApplyPendingMaintenanceActionMessage {
    ResourceIdentifier?: string | undefined;
    ApplyAction?: string | undefined;
    OptInType?: string | undefined;
}
export interface PendingMaintenanceAction {
    Action?: string | undefined;
    AutoAppliedAfterDate?: Date | undefined;
    ForcedApplyDate?: Date | undefined;
    OptInStatus?: string | undefined;
    CurrentApplyDate?: Date | undefined;
    Description?: string | undefined;
}
export type PendingMaintenanceActionDetails = PendingMaintenanceAction[];
export interface ResourcePendingMaintenanceActions {
    ResourceIdentifier?: string | undefined;
    PendingMaintenanceActionDetails?: PendingMaintenanceAction[] | undefined;
}
export interface ApplyPendingMaintenanceActionResult {
    ResourcePendingMaintenanceActions?: ResourcePendingMaintenanceActions | undefined;
}
export interface CopyDBClusterParameterGroupMessage {
    SourceDBClusterParameterGroupIdentifier?: string | undefined;
    TargetDBClusterParameterGroupIdentifier?: string | undefined;
    TargetDBClusterParameterGroupDescription?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DBClusterParameterGroup {
    DBClusterParameterGroupName?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    DBClusterParameterGroupArn?: string | undefined;
}
export interface CopyDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup | undefined;
}
export interface CopyDBClusterSnapshotMessage {
    SourceDBClusterSnapshotIdentifier?: string | undefined;
    TargetDBClusterSnapshotIdentifier?: string | undefined;
    KmsKeyId?: string | undefined;
    PreSignedUrl?: string | undefined;
    CopyTags?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export type AvailabilityZones = string[];
export interface DBClusterSnapshot {
    AvailabilityZones?: string[] | undefined;
    DBClusterSnapshotIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    SnapshotCreateTime?: Date | undefined;
    Engine?: string | undefined;
    Status?: string | undefined;
    Port?: number | undefined;
    VpcId?: string | undefined;
    ClusterCreateTime?: Date | undefined;
    MasterUsername?: string | undefined;
    EngineVersion?: string | undefined;
    SnapshotType?: string | undefined;
    PercentProgress?: number | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    DBClusterSnapshotArn?: string | undefined;
    SourceDBClusterSnapshotArn?: string | undefined;
    StorageType?: string | undefined;
}
export interface CopyDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot | undefined;
}
export type VpcSecurityGroupIdList = string[];
export type LogTypeList = string[];
export type GlobalClusterIdentifier = string;
export interface ServerlessV2ScalingConfiguration {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
}
export interface CreateDBClusterMessage {
    AvailabilityZones?: string[] | undefined;
    BackupRetentionPeriod?: number | undefined;
    DBClusterIdentifier?: string | undefined;
    DBClusterParameterGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    DBSubnetGroupName?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Port?: number | undefined;
    MasterUsername?: string | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    Tags?: Tag[] | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    PreSignedUrl?: string | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    DeletionProtection?: boolean | undefined;
    GlobalClusterIdentifier?: string | undefined;
    StorageType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    NetworkType?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
}
export type ReadReplicaIdentifierList = string[];
export interface DBClusterMember {
    DBInstanceIdentifier?: string | undefined;
    IsClusterWriter?: boolean | undefined;
    DBClusterParameterGroupStatus?: string | undefined;
    PromotionTier?: number | undefined;
}
export type DBClusterMemberList = DBClusterMember[];
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string | undefined;
    Status?: string | undefined;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface DBClusterRole {
    RoleArn?: string | undefined;
    Status?: string | undefined;
}
export type DBClusterRoles = DBClusterRole[];
export interface ServerlessV2ScalingConfigurationInfo {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
}
export interface ClusterMasterUserSecret {
    SecretArn?: string | undefined;
    SecretStatus?: string | undefined;
    KmsKeyId?: string | undefined;
}
export interface DBCluster {
    AvailabilityZones?: string[] | undefined;
    BackupRetentionPeriod?: number | undefined;
    DBClusterIdentifier?: string | undefined;
    DBClusterParameterGroup?: string | undefined;
    DBSubnetGroup?: string | undefined;
    Status?: string | undefined;
    PercentProgress?: string | undefined;
    EarliestRestorableTime?: Date | undefined;
    Endpoint?: string | undefined;
    ReaderEndpoint?: string | undefined;
    MultiAZ?: boolean | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    LatestRestorableTime?: Date | undefined;
    Port?: number | undefined;
    MasterUsername?: string | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    ReplicationSourceIdentifier?: string | undefined;
    ReadReplicaIdentifiers?: string[] | undefined;
    DBClusterMembers?: DBClusterMember[] | undefined;
    VpcSecurityGroups?: VpcSecurityGroupMembership[] | undefined;
    HostedZoneId?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    DbClusterResourceId?: string | undefined;
    DBClusterArn?: string | undefined;
    AssociatedRoles?: DBClusterRole[] | undefined;
    CloneGroupId?: string | undefined;
    ClusterCreateTime?: Date | undefined;
    EnabledCloudwatchLogsExports?: string[] | undefined;
    DeletionProtection?: boolean | undefined;
    IOOptimizedNextAllowedModificationTime?: Date | undefined;
    StorageType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfigurationInfo | undefined;
    ServerlessV2PlatformVersion?: string | undefined;
    MasterUserSecret?: ClusterMasterUserSecret | undefined;
    NetworkType?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
}
export interface CreateDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface CreateDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBClusterParameterGroupResult {
    DBClusterParameterGroup?: DBClusterParameterGroup | undefined;
}
export interface CreateDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot | undefined;
}
export interface CreateDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    AvailabilityZone?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    Tags?: Tag[] | undefined;
    DBClusterIdentifier?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    PromotionTier?: number | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    CACertificateIdentifier?: string | undefined;
}
export interface Endpoint {
    Address?: string | undefined;
    Port?: number | undefined;
    HostedZoneId?: string | undefined;
}
export interface AvailabilityZone {
    Name?: string | undefined;
}
export interface Subnet {
    SubnetIdentifier?: string | undefined;
    SubnetAvailabilityZone?: AvailabilityZone | undefined;
    SubnetStatus?: string | undefined;
}
export type SubnetList = Subnet[];
export type NetworkTypeList = string[];
export interface DBSubnetGroup {
    DBSubnetGroupName?: string | undefined;
    DBSubnetGroupDescription?: string | undefined;
    VpcId?: string | undefined;
    SubnetGroupStatus?: string | undefined;
    Subnets?: Subnet[] | undefined;
    DBSubnetGroupArn?: string | undefined;
    SupportedNetworkTypes?: string[] | undefined;
}
export interface PendingCloudwatchLogsExports {
    LogTypesToEnable?: string[] | undefined;
    LogTypesToDisable?: string[] | undefined;
}
export interface PendingModifiedValues {
    DBInstanceClass?: string | undefined;
    AllocatedStorage?: number | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    BackupRetentionPeriod?: number | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    DBInstanceIdentifier?: string | undefined;
    StorageType?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    DBSubnetGroupName?: string | undefined;
    PendingCloudwatchLogsExports?: PendingCloudwatchLogsExports | undefined;
}
export interface DBInstanceStatusInfo {
    StatusType?: string | undefined;
    Normal?: boolean | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
}
export type DBInstanceStatusInfoList = DBInstanceStatusInfo[];
export interface CertificateDetails {
    CAIdentifier?: string | undefined;
    ValidTill?: Date | undefined;
}
export interface DBInstance {
    DBInstanceIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    Engine?: string | undefined;
    DBInstanceStatus?: string | undefined;
    Endpoint?: Endpoint | undefined;
    InstanceCreateTime?: Date | undefined;
    PreferredBackupWindow?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    VpcSecurityGroups?: VpcSecurityGroupMembership[] | undefined;
    AvailabilityZone?: string | undefined;
    DBSubnetGroup?: DBSubnetGroup | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    PendingModifiedValues?: PendingModifiedValues | undefined;
    LatestRestorableTime?: Date | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    PubliclyAccessible?: boolean | undefined;
    StatusInfos?: DBInstanceStatusInfo[] | undefined;
    DBClusterIdentifier?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    DbiResourceId?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    PromotionTier?: number | undefined;
    DBInstanceArn?: string | undefined;
    EnabledCloudwatchLogsExports?: string[] | undefined;
    CertificateDetails?: CertificateDetails | undefined;
    PerformanceInsightsEnabled?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
}
export interface CreateDBInstanceResult {
    DBInstance?: DBInstance | undefined;
}
export type SubnetIdentifierList = string[];
export interface CreateDBSubnetGroupMessage {
    DBSubnetGroupName?: string | undefined;
    DBSubnetGroupDescription?: string | undefined;
    SubnetIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup | undefined;
}
export interface CreateEventSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SnsTopicArn?: string | undefined;
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
    SourceIds?: string[] | undefined;
    Enabled?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateEventSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface CreateGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    SourceDBClusterIdentifier?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DeletionProtection?: boolean | undefined;
    DatabaseName?: string | undefined;
    StorageEncrypted?: boolean | undefined;
}
export type ReadersArnList = string[];
export type GlobalClusterMemberSynchronizationStatus = "connected" | "pending-resync" | (string & {});
export interface GlobalClusterMember {
    DBClusterArn?: string | undefined;
    Readers?: string[] | undefined;
    IsWriter?: boolean | undefined;
    SynchronizationStatus?: GlobalClusterMemberSynchronizationStatus | undefined;
}
export type GlobalClusterMemberList = GlobalClusterMember[];
export type FailoverStatus = "pending" | "failing-over" | "cancelling" | (string & {});
export interface FailoverState {
    Status?: FailoverStatus | undefined;
    FromDbClusterArn?: string | undefined;
    ToDbClusterArn?: string | undefined;
    IsDataLossAllowed?: boolean | undefined;
}
export interface GlobalCluster {
    GlobalClusterIdentifier?: string | undefined;
    GlobalClusterResourceId?: string | undefined;
    GlobalClusterArn?: string | undefined;
    Status?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DatabaseName?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    GlobalClusterMembers?: GlobalClusterMember[] | undefined;
    FailoverState?: FailoverState | undefined;
    TagList?: Tag[] | undefined;
}
export interface CreateGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface DeleteDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    SkipFinalSnapshot?: boolean | undefined;
    FinalDBSnapshotIdentifier?: string | undefined;
}
export interface DeleteDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface DeleteDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
}
export interface DeleteDBClusterParameterGroupResponse {
}
export interface DeleteDBClusterSnapshotMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
}
export interface DeleteDBClusterSnapshotResult {
    DBClusterSnapshot?: DBClusterSnapshot | undefined;
}
export interface DeleteDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
}
export interface DeleteDBInstanceResult {
    DBInstance?: DBInstance | undefined;
}
export interface DeleteDBSubnetGroupMessage {
    DBSubnetGroupName?: string | undefined;
}
export interface DeleteDBSubnetGroupResponse {
}
export interface DeleteEventSubscriptionMessage {
    SubscriptionName?: string | undefined;
}
export interface DeleteEventSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface DeleteGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
}
export interface DeleteGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export type FilterValueList = string[];
export interface Filter {
    Name?: string | undefined;
    Values?: string[] | undefined;
}
export type FilterList = Filter[];
export interface DescribeCertificatesMessage {
    CertificateIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface Certificate {
    CertificateIdentifier?: string | undefined;
    CertificateType?: string | undefined;
    Thumbprint?: string | undefined;
    ValidFrom?: Date | undefined;
    ValidTill?: Date | undefined;
    CertificateArn?: string | undefined;
}
export type CertificateList = Certificate[];
export interface CertificateMessage {
    Certificates?: Certificate[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBClusterParameterGroupsMessage {
    DBClusterParameterGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBClusterParameterGroupList = DBClusterParameterGroup[];
export interface DBClusterParameterGroupsMessage {
    Marker?: string | undefined;
    DBClusterParameterGroups?: DBClusterParameterGroup[] | undefined;
}
export interface DescribeDBClusterParametersMessage {
    DBClusterParameterGroupName?: string | undefined;
    Source?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ApplyMethod = "immediate" | "pending-reboot" | (string & {});
export interface Parameter {
    ParameterName?: string | undefined;
    ParameterValue?: string | undefined;
    Description?: string | undefined;
    Source?: string | undefined;
    ApplyType?: string | undefined;
    DataType?: string | undefined;
    AllowedValues?: string | undefined;
    IsModifiable?: boolean | undefined;
    MinimumEngineVersion?: string | undefined;
    ApplyMethod?: ApplyMethod | undefined;
}
export type ParametersList = Parameter[];
export interface DBClusterParameterGroupDetails {
    Parameters?: Parameter[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDBClustersMessage {
    DBClusterIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBClusterList = DBCluster[];
export interface DBClusterMessage {
    Marker?: string | undefined;
    DBClusters?: DBCluster[] | undefined;
}
export interface DescribeDBClusterSnapshotAttributesMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
}
export type AttributeValueList = string[];
export interface DBClusterSnapshotAttribute {
    AttributeName?: string | undefined;
    AttributeValues?: string[] | undefined;
}
export type DBClusterSnapshotAttributeList = DBClusterSnapshotAttribute[];
export interface DBClusterSnapshotAttributesResult {
    DBClusterSnapshotIdentifier?: string | undefined;
    DBClusterSnapshotAttributes?: DBClusterSnapshotAttribute[] | undefined;
}
export interface DescribeDBClusterSnapshotAttributesResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult | undefined;
}
export interface DescribeDBClusterSnapshotsMessage {
    DBClusterIdentifier?: string | undefined;
    DBClusterSnapshotIdentifier?: string | undefined;
    SnapshotType?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    IncludeShared?: boolean | undefined;
    IncludePublic?: boolean | undefined;
}
export type DBClusterSnapshotList = DBClusterSnapshot[];
export interface DBClusterSnapshotMessage {
    Marker?: string | undefined;
    DBClusterSnapshots?: DBClusterSnapshot[] | undefined;
}
export interface DescribeDBEngineVersionsMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    DefaultOnly?: boolean | undefined;
    ListSupportedCharacterSets?: boolean | undefined;
    ListSupportedTimezones?: boolean | undefined;
}
export interface UpgradeTarget {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Description?: string | undefined;
    AutoUpgrade?: boolean | undefined;
    IsMajorVersionUpgrade?: boolean | undefined;
}
export type ValidUpgradeTargetList = UpgradeTarget[];
export type CACertificateIdentifiersList = string[];
export interface ServerlessV2FeaturesSupport {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
}
export interface DBEngineVersion {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBParameterGroupFamily?: string | undefined;
    DBEngineDescription?: string | undefined;
    DBEngineVersionDescription?: string | undefined;
    ValidUpgradeTarget?: UpgradeTarget[] | undefined;
    ExportableLogTypes?: string[] | undefined;
    SupportsLogExportsToCloudwatchLogs?: boolean | undefined;
    SupportedCACertificateIdentifiers?: string[] | undefined;
    SupportsCertificateRotationWithoutRestart?: boolean | undefined;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport | undefined;
}
export type DBEngineVersionList = DBEngineVersion[];
export interface DBEngineVersionMessage {
    Marker?: string | undefined;
    DBEngineVersions?: DBEngineVersion[] | undefined;
}
export interface DescribeDBInstancesMessage {
    DBInstanceIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBInstanceList = DBInstance[];
export interface DBInstanceMessage {
    Marker?: string | undefined;
    DBInstances?: DBInstance[] | undefined;
}
export interface DescribeDBSubnetGroupsMessage {
    DBSubnetGroupName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DBSubnetGroups = DBSubnetGroup[];
export interface DBSubnetGroupMessage {
    Marker?: string | undefined;
    DBSubnetGroups?: DBSubnetGroup[] | undefined;
}
export interface DescribeEngineDefaultClusterParametersMessage {
    DBParameterGroupFamily?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface EngineDefaults {
    DBParameterGroupFamily?: string | undefined;
    Marker?: string | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface DescribeEngineDefaultClusterParametersResult {
    EngineDefaults?: EngineDefaults | undefined;
}
export interface DescribeEventCategoriesMessage {
    SourceType?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface EventCategoriesMap {
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
}
export type EventCategoriesMapList = EventCategoriesMap[];
export interface EventCategoriesMessage {
    EventCategoriesMapList?: EventCategoriesMap[] | undefined;
}
export type SourceType = "db-instance" | "db-parameter-group" | "db-security-group" | "db-snapshot" | "db-cluster" | "db-cluster-snapshot" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Duration?: number | undefined;
    EventCategories?: string[] | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface Event {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    Message?: string | undefined;
    EventCategories?: string[] | undefined;
    Date?: Date | undefined;
    SourceArn?: string | undefined;
}
export type EventList = Event[];
export interface EventsMessage {
    Marker?: string | undefined;
    Events?: Event[] | undefined;
}
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type EventSubscriptionsList = EventSubscription[];
export interface EventSubscriptionsMessage {
    Marker?: string | undefined;
    EventSubscriptionsList?: EventSubscription[] | undefined;
}
export interface DescribeGlobalClustersMessage {
    GlobalClusterIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type GlobalClusterList = GlobalCluster[];
export interface GlobalClustersMessage {
    Marker?: string | undefined;
    GlobalClusters?: GlobalCluster[] | undefined;
}
export interface DescribeOrderableDBInstanceOptionsMessage {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBInstanceClass?: string | undefined;
    LicenseModel?: string | undefined;
    Vpc?: boolean | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type AvailabilityZoneList = AvailabilityZone[];
export interface OrderableDBInstanceOption {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    DBInstanceClass?: string | undefined;
    LicenseModel?: string | undefined;
    AvailabilityZones?: AvailabilityZone[] | undefined;
    Vpc?: boolean | undefined;
    StorageType?: string | undefined;
}
export type OrderableDBInstanceOptionsList = OrderableDBInstanceOption[];
export interface OrderableDBInstanceOptionsMessage {
    OrderableDBInstanceOptions?: OrderableDBInstanceOption[] | undefined;
    Marker?: string | undefined;
}
export interface DescribePendingMaintenanceActionsMessage {
    ResourceIdentifier?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type PendingMaintenanceActions = ResourcePendingMaintenanceActions[];
export interface PendingMaintenanceActionsMessage {
    PendingMaintenanceActions?: ResourcePendingMaintenanceActions[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeServerlessV2PlatformVersionsMessage {
    ServerlessV2PlatformVersion?: string | undefined;
    Engine?: string | undefined;
    Filters?: Filter[] | undefined;
    DefaultOnly?: boolean | undefined;
    IncludeAll?: boolean | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ServerlessV2PlatformVersionInfo {
    ServerlessV2PlatformVersion?: string | undefined;
    ServerlessV2PlatformVersionDescription?: string | undefined;
    Engine?: string | undefined;
    ServerlessV2FeaturesSupport?: ServerlessV2FeaturesSupport | undefined;
    Status?: string | undefined;
    IsDefault?: boolean | undefined;
}
export type ServerlessV2PlatformVersionList = ServerlessV2PlatformVersionInfo[];
export interface ServerlessV2PlatformVersionsMessage {
    Marker?: string | undefined;
    ServerlessV2PlatformVersions?: ServerlessV2PlatformVersionInfo[] | undefined;
}
export interface FailoverDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    TargetDBInstanceIdentifier?: string | undefined;
}
export interface FailoverDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export type DBClusterIdentifier = string;
export interface FailoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    TargetDbClusterIdentifier?: string | undefined;
    AllowDataLoss?: boolean | undefined;
    Switchover?: boolean | undefined;
}
export interface FailoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface ListTagsForResourceMessage {
    ResourceName?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface TagListMessage {
    TagList?: Tag[] | undefined;
}
export interface CloudwatchLogsExportConfiguration {
    EnableLogTypes?: string[] | undefined;
    DisableLogTypes?: string[] | undefined;
}
export interface ModifyDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
    NewDBClusterIdentifier?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    BackupRetentionPeriod?: number | undefined;
    DBClusterParameterGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Port?: number | undefined;
    MasterUserPassword?: string | redacted.Redacted<string> | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    CloudwatchLogsExportConfiguration?: CloudwatchLogsExportConfiguration | undefined;
    EngineVersion?: string | undefined;
    AllowMajorVersionUpgrade?: boolean | undefined;
    DeletionProtection?: boolean | undefined;
    StorageType?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    ManageMasterUserPassword?: boolean | undefined;
    MasterUserSecretKmsKeyId?: string | undefined;
    RotateMasterUserPassword?: boolean | undefined;
    NetworkType?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
}
export interface ModifyDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface ModifyDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface DBClusterParameterGroupNameMessage {
    DBClusterParameterGroupName?: string | undefined;
}
export interface ModifyDBClusterSnapshotAttributeMessage {
    DBClusterSnapshotIdentifier?: string | undefined;
    AttributeName?: string | undefined;
    ValuesToAdd?: string[] | undefined;
    ValuesToRemove?: string[] | undefined;
}
export interface ModifyDBClusterSnapshotAttributeResult {
    DBClusterSnapshotAttributesResult?: DBClusterSnapshotAttributesResult | undefined;
}
export interface ModifyDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    ApplyImmediately?: boolean | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    NewDBInstanceIdentifier?: string | undefined;
    CACertificateIdentifier?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    PromotionTier?: number | undefined;
    EnablePerformanceInsights?: boolean | undefined;
    PerformanceInsightsKMSKeyId?: string | undefined;
    CertificateRotationRestart?: boolean | undefined;
}
export interface ModifyDBInstanceResult {
    DBInstance?: DBInstance | undefined;
}
export interface ModifyDBSubnetGroupMessage {
    DBSubnetGroupName?: string | undefined;
    DBSubnetGroupDescription?: string | undefined;
    SubnetIds?: string[] | undefined;
}
export interface ModifyDBSubnetGroupResult {
    DBSubnetGroup?: DBSubnetGroup | undefined;
}
export interface ModifyEventSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SnsTopicArn?: string | undefined;
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
    Enabled?: boolean | undefined;
}
export interface ModifyEventSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export interface ModifyGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    NewGlobalClusterIdentifier?: string | undefined;
    DeletionProtection?: boolean | undefined;
}
export interface ModifyGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface RebootDBInstanceMessage {
    DBInstanceIdentifier?: string | undefined;
    ForceFailover?: boolean | undefined;
}
export interface RebootDBInstanceResult {
    DBInstance?: DBInstance | undefined;
}
export interface RemoveFromGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    DbClusterIdentifier?: string | undefined;
}
export interface RemoveFromGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export interface RemoveSourceIdentifierFromSubscriptionMessage {
    SubscriptionName?: string | undefined;
    SourceIdentifier?: string | undefined;
}
export interface RemoveSourceIdentifierFromSubscriptionResult {
    EventSubscription?: EventSubscription | undefined;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceName?: string | undefined;
    TagKeys?: string[] | undefined;
}
export interface RemoveTagsFromResourceResponse {
}
export interface ResetDBClusterParameterGroupMessage {
    DBClusterParameterGroupName?: string | undefined;
    ResetAllParameters?: boolean | undefined;
    Parameters?: Parameter[] | undefined;
}
export interface RestoreDBClusterFromSnapshotMessage {
    AvailabilityZones?: string[] | undefined;
    DBClusterIdentifier?: string | undefined;
    SnapshotIdentifier?: string | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Port?: number | undefined;
    DBSubnetGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    DeletionProtection?: boolean | undefined;
    DBClusterParameterGroupName?: string | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    StorageType?: string | undefined;
    NetworkType?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
}
export interface RestoreDBClusterFromSnapshotResult {
    DBCluster?: DBCluster | undefined;
}
export interface RestoreDBClusterToPointInTimeMessage {
    DBClusterIdentifier?: string | undefined;
    RestoreType?: string | undefined;
    SourceDBClusterIdentifier?: string | undefined;
    RestoreToTime?: Date | undefined;
    UseLatestRestorableTime?: boolean | undefined;
    Port?: number | undefined;
    DBSubnetGroupName?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    EnableCloudwatchLogsExports?: string[] | undefined;
    DeletionProtection?: boolean | undefined;
    ServerlessV2ScalingConfiguration?: ServerlessV2ScalingConfiguration | undefined;
    StorageType?: string | undefined;
    NetworkType?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
}
export interface RestoreDBClusterToPointInTimeResult {
    DBCluster?: DBCluster | undefined;
}
export interface StartDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
}
export interface StartDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface StopDBClusterMessage {
    DBClusterIdentifier?: string | undefined;
}
export interface StopDBClusterResult {
    DBCluster?: DBCluster | undefined;
}
export interface SwitchoverGlobalClusterMessage {
    GlobalClusterIdentifier?: string | undefined;
    TargetDbClusterIdentifier?: string | undefined;
}
export interface SwitchoverGlobalClusterResult {
    GlobalCluster?: GlobalCluster | undefined;
}
export type ExceptionMessage = string;
export type AddSourceIdentifierToSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Adds a source identifier to an existing event notification
 * subscription.
 */
export declare const addSourceIdentifierToSubscription: API.OperationMethod<AddSourceIdentifierToSubscriptionMessage & RegionInput, AddSourceIdentifierToSubscriptionResult, AddSourceIdentifierToSubscriptionError, Credentials | HttpClient.HttpClient>;
export type AddTagsToResourceError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSnapshotNotFoundFault | CommonErrors;
/**
 * Adds metadata tags to an Amazon DocumentDB resource. You can use these tags
 * with cost allocation reporting to track costs that are associated
 * with Amazon DocumentDB resources or in a `Condition` statement in
 * an Identity and Access Management (IAM) policy for Amazon DocumentDB.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage & RegionInput, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type ApplyPendingMaintenanceActionError = InvalidDBClusterStateFault | InvalidDBInstanceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Applies a pending maintenance action to a resource (for example,
 * to an Amazon DocumentDB instance).
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionMessage & RegionInput, ApplyPendingMaintenanceActionResult, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupNotFoundFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Copies the specified cluster parameter group.
 */
export declare const copyDBClusterParameterGroup: API.OperationMethod<CopyDBClusterParameterGroupMessage & RegionInput, CopyDBClusterParameterGroupResult, CopyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CopyDBClusterSnapshotError = DBClusterSnapshotAlreadyExistsFault | DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | KMSKeyNotAccessibleFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Copies a snapshot of a cluster.
 *
 * To copy a cluster snapshot from a shared manual cluster snapshot,
 * `SourceDBClusterSnapshotIdentifier` must be the Amazon
 * Resource Name (ARN) of the shared cluster snapshot. You can only
 * copy a shared DB cluster snapshot, whether encrypted or not, in the
 * same Amazon Web Services Region.
 *
 * To cancel the copy operation after it is in progress, delete the
 * target cluster snapshot identified by
 * `TargetDBClusterSnapshotIdentifier` while that cluster
 * snapshot is in the *copying* status.
 */
export declare const copyDBClusterSnapshot: API.OperationMethod<CopyDBClusterSnapshotMessage & RegionInput, CopyDBClusterSnapshotResult, CopyDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBClusterQuotaExceededFault | DBInstanceNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | GlobalClusterNotFoundFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSubnetGroupStateFault | InvalidGlobalClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates a new Amazon DocumentDB cluster.
 */
export declare const createDBCluster: API.OperationMethod<CreateDBClusterMessage & RegionInput, CreateDBClusterResult, CreateDBClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterParameterGroupError = DBParameterGroupAlreadyExistsFault | DBParameterGroupQuotaExceededFault | CommonErrors;
/**
 * Creates a new cluster parameter group.
 *
 * Parameters in a cluster parameter group apply to all of the
 * instances in a cluster.
 *
 * A cluster parameter group is initially created with the default
 * parameters for the database engine used by instances in the cluster.
 * In Amazon DocumentDB, you cannot make modifications directly to the
 * `default.docdb3.6` cluster parameter group. If your
 * Amazon DocumentDB cluster is using the default cluster parameter group and you
 * want to modify a value in it, you must first
 * create a new parameter group
 * or
 * copy an existing parameter group,
 * modify it, and then apply the modified parameter group to your
 * cluster. For the new cluster parameter group and associated settings
 * to take effect, you must then reboot the instances in the cluster
 * without failover. For more information,
 * see
 * Modifying Amazon DocumentDB Cluster Parameter Groups.
 */
export declare const createDBClusterParameterGroup: API.OperationMethod<CreateDBClusterParameterGroupMessage & RegionInput, CreateDBClusterParameterGroupResult, CreateDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type CreateDBClusterSnapshotError = DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Creates a snapshot of a cluster.
 */
export declare const createDBClusterSnapshot: API.OperationMethod<CreateDBClusterSnapshotMessage & RegionInput, CreateDBClusterSnapshotResult, CreateDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type CreateDBInstanceError = AuthorizationNotFoundFault | DBClusterNotFoundFault | DBInstanceAlreadyExistsFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | InstanceQuotaExceededFault | InsufficientDBInstanceCapacityFault | InvalidDBClusterStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Creates a new instance.
 */
export declare const createDBInstance: API.OperationMethod<CreateDBInstanceMessage & RegionInput, CreateDBInstanceResult, CreateDBInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateDBSubnetGroupError = DBSubnetGroupAlreadyExistsFault | DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupQuotaExceededFault | DBSubnetQuotaExceededFault | InvalidSubnet | CommonErrors;
/**
 * Creates a new subnet group. subnet groups must contain at least one subnet in at
 * least two Availability Zones in the Amazon Web Services Region.
 */
export declare const createDBSubnetGroup: API.OperationMethod<CreateDBSubnetGroupMessage & RegionInput, CreateDBSubnetGroupResult, CreateDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SourceNotFoundFault | SubscriptionAlreadyExistFault | SubscriptionCategoryNotFoundFault | CommonErrors;
/**
 * Creates an Amazon DocumentDB event notification subscription. This action requires a topic Amazon Resource Name (ARN) created by using the Amazon DocumentDB console, the Amazon SNS console, or the Amazon SNS API. To obtain an ARN with Amazon SNS, you must create a topic in Amazon SNS and subscribe to the topic. The ARN is displayed in the Amazon SNS console.
 *
 * You can specify the type of source (`SourceType`) that you want to be notified of. You can also provide a list of Amazon DocumentDB sources (`SourceIds`) that trigger the events, and you can provide a list of event categories (`EventCategories`) for events that you want to be notified of. For example, you can specify `SourceType = db-instance`, `SourceIds = mydbinstance1, mydbinstance2` and `EventCategories = Availability, Backup`.
 *
 * If you specify both the `SourceType` and `SourceIds` (such as `SourceType = db-instance` and `SourceIdentifier = myDBInstance1`), you are notified of all the `db-instance` events for the specified source. If you specify a `SourceType` but do not specify a `SourceIdentifier`, you receive notice of the events for that source type for all your Amazon DocumentDB sources. If you do not specify either the `SourceType` or the `SourceIdentifier`, you are notified of events generated from all Amazon DocumentDB sources belonging to your customer account.
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage & RegionInput, CreateEventSubscriptionResult, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateGlobalClusterError = DBClusterNotFoundFault | GlobalClusterAlreadyExistsFault | GlobalClusterQuotaExceededFault | InvalidDBClusterStateFault | CommonErrors;
/**
 * Creates an Amazon DocumentDB global cluster that can span multiple multiple Amazon Web Services Regions.
 * The global cluster contains one primary cluster with read-write capability, and up-to 10 read-only secondary clusters. Global clusters uses storage-based fast replication across regions with latencies less than one second, using dedicated infrastructure with no impact to your workload's performance.
 *
 * You can create a global cluster that is initially empty, and then add a primary and a secondary to it.
 * Or you can specify an existing cluster during the create operation, and this cluster becomes the primary of the global cluster.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const createGlobalCluster: API.OperationMethod<CreateGlobalClusterMessage & RegionInput, CreateGlobalClusterResult, CreateGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterError = DBClusterNotFoundFault | DBClusterSnapshotAlreadyExistsFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | SnapshotQuotaExceededFault | DBClusterDeletionProtected | CommonErrors;
/**
 * Deletes a previously provisioned cluster. When you delete a cluster, all automated backups for that cluster are deleted and can't be recovered. Manual DB cluster snapshots of the specified cluster are not deleted.
 */
export declare const deleteDBCluster: API.OperationMethod<DeleteDBClusterMessage & RegionInput, DeleteDBClusterResult, DeleteDBClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Deletes a specified cluster parameter group. The cluster parameter group to be deleted can't be associated with any clusters.
 */
export declare const deleteDBClusterParameterGroup: API.OperationMethod<DeleteDBClusterParameterGroupMessage & RegionInput, DeleteDBClusterParameterGroupResponse, DeleteDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDBClusterSnapshotError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | CommonErrors;
/**
 * Deletes a cluster snapshot. If the snapshot is being copied, the copy operation is terminated.
 *
 * The cluster snapshot must be in the `available` state to be deleted.
 */
export declare const deleteDBClusterSnapshot: API.OperationMethod<DeleteDBClusterSnapshotMessage & RegionInput, DeleteDBClusterSnapshotResult, DeleteDBClusterSnapshotError, Credentials | HttpClient.HttpClient>;
export type DeleteDBInstanceError = DBInstanceNotFoundFault | DBSnapshotAlreadyExistsFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | SnapshotQuotaExceededFault | CommonErrors;
/**
 * Deletes a previously provisioned instance.
 */
export declare const deleteDBInstance: API.OperationMethod<DeleteDBInstanceMessage & RegionInput, DeleteDBInstanceResult, DeleteDBInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteDBSubnetGroupError = DBSubnetGroupNotFoundFault | InvalidDBSubnetGroupStateFault | InvalidDBSubnetStateFault | CommonErrors;
/**
 * Deletes a subnet group.
 *
 * The specified database subnet group must not be associated with any DB
 * instances.
 */
export declare const deleteDBSubnetGroup: API.OperationMethod<DeleteDBSubnetGroupMessage & RegionInput, DeleteDBSubnetGroupResponse, DeleteDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = InvalidEventSubscriptionStateFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Deletes an Amazon DocumentDB event notification subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage & RegionInput, DeleteEventSubscriptionResult, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteGlobalClusterError = GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Deletes a global cluster. The primary and secondary clusters must already be detached or deleted before attempting to delete a global cluster.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const deleteGlobalCluster: API.OperationMethod<DeleteGlobalClusterMessage & RegionInput, DeleteGlobalClusterResult, DeleteGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificatesError = CertificateNotFoundFault | CommonErrors;
/**
 * Returns a list of certificate authority (CA) certificates provided by Amazon DocumentDB for this Amazon Web Services account.
 */
export declare const describeCertificates: API.PaginatedOperationMethod<DescribeCertificatesMessage & RegionInput, CertificateMessage, DescribeCertificatesError, Credentials | HttpClient.HttpClient, Certificate>;
export type DescribeDBClusterParameterGroupsError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBClusterParameterGroup` descriptions. If a `DBClusterParameterGroupName` parameter is specified, the list contains only the description of the specified cluster parameter group.
 */
export declare const describeDBClusterParameterGroups: API.PaginatedOperationMethod<DescribeDBClusterParameterGroupsMessage & RegionInput, DBClusterParameterGroupsMessage, DescribeDBClusterParameterGroupsError, Credentials | HttpClient.HttpClient, DBClusterParameterGroup>;
export type DescribeDBClusterParametersError = DBParameterGroupNotFoundFault | CommonErrors;
/**
 * Returns the detailed parameter list for a particular cluster parameter
 * group.
 */
export declare const describeDBClusterParameters: API.PaginatedOperationMethod<DescribeDBClusterParametersMessage & RegionInput, DBClusterParameterGroupDetails, DescribeDBClusterParametersError, Credentials | HttpClient.HttpClient, Parameter>;
export type DescribeDBClustersError = DBClusterNotFoundFault | CommonErrors;
/**
 * Returns information about provisioned Amazon DocumentDB clusters. This API
 * operation supports pagination. For certain management features
 * such as cluster and instance lifecycle management, Amazon DocumentDB leverages
 * operational technology that is shared with Amazon RDS and Amazon
 * Neptune. Use the `filterName=engine,Values=docdb` filter
 * parameter to return only Amazon DocumentDB clusters.
 */
export declare const describeDBClusters: API.PaginatedOperationMethod<DescribeDBClustersMessage & RegionInput, DBClusterMessage, DescribeDBClustersError, Credentials | HttpClient.HttpClient, DBCluster>;
export type DescribeDBClusterSnapshotAttributesError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns a list of cluster snapshot attribute names and values for a manual DB
 * cluster snapshot.
 *
 * When you share snapshots with other Amazon Web Services accounts,
 * `DescribeDBClusterSnapshotAttributes` returns the `restore` attribute and a list of IDs for the Amazon Web Services accounts that are authorized to copy or restore the manual cluster snapshot. If `all` is included in the list of values for the `restore` attribute, then the manual cluster snapshot is public and can be copied or restored by all Amazon Web Services accounts.
 */
export declare const describeDBClusterSnapshotAttributes: API.OperationMethod<DescribeDBClusterSnapshotAttributesMessage & RegionInput, DescribeDBClusterSnapshotAttributesResult, DescribeDBClusterSnapshotAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeDBClusterSnapshotsError = DBClusterSnapshotNotFoundFault | CommonErrors;
/**
 * Returns information about cluster snapshots. This API operation supports pagination.
 */
export declare const describeDBClusterSnapshots: API.PaginatedOperationMethod<DescribeDBClusterSnapshotsMessage & RegionInput, DBClusterSnapshotMessage, DescribeDBClusterSnapshotsError, Credentials | HttpClient.HttpClient, DBClusterSnapshot>;
export type DescribeDBEngineVersionsError = CommonErrors;
/**
 * Returns a list of the available engines.
 */
export declare const describeDBEngineVersions: API.PaginatedOperationMethod<DescribeDBEngineVersionsMessage & RegionInput, DBEngineVersionMessage, DescribeDBEngineVersionsError, Credentials | HttpClient.HttpClient, DBEngineVersion>;
export type DescribeDBInstancesError = DBInstanceNotFoundFault | CommonErrors;
/**
 * Returns information about provisioned Amazon DocumentDB instances. This API supports pagination.
 */
export declare const describeDBInstances: API.PaginatedOperationMethod<DescribeDBInstancesMessage & RegionInput, DBInstanceMessage, DescribeDBInstancesError, Credentials | HttpClient.HttpClient, DBInstance>;
export type DescribeDBSubnetGroupsError = DBSubnetGroupNotFoundFault | CommonErrors;
/**
 * Returns a list of `DBSubnetGroup` descriptions. If a
 * `DBSubnetGroupName` is specified, the list will contain only the descriptions of the specified `DBSubnetGroup`.
 */
export declare const describeDBSubnetGroups: API.PaginatedOperationMethod<DescribeDBSubnetGroupsMessage & RegionInput, DBSubnetGroupMessage, DescribeDBSubnetGroupsError, Credentials | HttpClient.HttpClient, DBSubnetGroup>;
export type DescribeEngineDefaultClusterParametersError = CommonErrors;
/**
 * Returns the default engine and system parameter information for the cluster database
 * engine.
 */
export declare const describeEngineDefaultClusterParameters: API.OperationMethod<DescribeEngineDefaultClusterParametersMessage & RegionInput, DescribeEngineDefaultClusterParametersResult, DescribeEngineDefaultClusterParametersError, Credentials | HttpClient.HttpClient>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Displays a list of categories for all event source types, or, if specified, for a
 * specified source type.
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage & RegionInput, EventCategoriesMessage, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Returns events related to instances, security groups, snapshots, and DB parameter groups for the past 14 days. You can obtain events specific to a particular DB instance, security group, snapshot, or parameter group by providing the name as a parameter. By default, the events of the past hour are returned.
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage & RegionInput, EventsMessage, DescribeEventsError, Credentials | HttpClient.HttpClient, Event>;
export type DescribeEventSubscriptionsError = SubscriptionNotFoundFault | CommonErrors;
/**
 * Lists all the subscription descriptions for a customer account. The description for a subscription includes `SubscriptionName`, `SNSTopicARN`, `CustomerID`, `SourceType`, `SourceID`, `CreationTime`, and `Status`.
 *
 * If you specify a `SubscriptionName`, lists the description for that subscription.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage & RegionInput, EventSubscriptionsMessage, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, EventSubscription>;
export type DescribeGlobalClustersError = GlobalClusterNotFoundFault | CommonErrors;
/**
 * Returns information about Amazon DocumentDB global clusters. This API supports pagination.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const describeGlobalClusters: API.PaginatedOperationMethod<DescribeGlobalClustersMessage & RegionInput, GlobalClustersMessage, DescribeGlobalClustersError, Credentials | HttpClient.HttpClient, GlobalCluster>;
export type DescribeOrderableDBInstanceOptionsError = CommonErrors;
/**
 * Returns a list of orderable instance options for the specified engine.
 */
export declare const describeOrderableDBInstanceOptions: API.PaginatedOperationMethod<DescribeOrderableDBInstanceOptionsMessage & RegionInput, OrderableDBInstanceOptionsMessage, DescribeOrderableDBInstanceOptionsError, Credentials | HttpClient.HttpClient, OrderableDBInstanceOption>;
export type DescribePendingMaintenanceActionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of resources (for example, instances) that have at least one pending
 * maintenance action.
 */
export declare const describePendingMaintenanceActions: API.PaginatedOperationMethod<DescribePendingMaintenanceActionsMessage & RegionInput, PendingMaintenanceActionsMessage, DescribePendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, ResourcePendingMaintenanceActions>;
export type DescribeServerlessV2PlatformVersionsError = CommonErrors;
/**
 * Describes the properties of specific platform versions for Amazon DocumentDB Serverless v2.
 */
export declare const describeServerlessV2PlatformVersions: API.PaginatedOperationMethod<DescribeServerlessV2PlatformVersionsMessage & RegionInput, ServerlessV2PlatformVersionsMessage, DescribeServerlessV2PlatformVersionsError, Credentials | HttpClient.HttpClient, ServerlessV2PlatformVersionInfo>;
export type FailoverDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Forces a failover for a cluster.
 *
 * A failover for a cluster promotes one of the Amazon DocumentDB replicas (read-only instances) in the cluster to be the primary instance (the cluster writer).
 *
 * If the primary instance fails, Amazon DocumentDB automatically fails over to an Amazon DocumentDB replica, if one exists. You can force a failover when you want to simulate a failure of a primary instance for testing.
 */
export declare const failoverDBCluster: API.OperationMethod<FailoverDBClusterMessage & RegionInput, FailoverDBClusterResult, FailoverDBClusterError, Credentials | HttpClient.HttpClient>;
export type FailoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Promotes the specified secondary DB cluster to be the primary DB cluster in the global cluster when failing over a global cluster occurs.
 *
 * Use this operation to respond to an unplanned event, such as a regional disaster in the primary region.
 * Failing over can result in a loss of write transaction data that wasn't replicated to the chosen secondary before the failover event occurred.
 * However, the recovery process that promotes a DB instance on the chosen seconday DB cluster to be the primary writer DB instance guarantees that the data is in a transactionally consistent state.
 */
export declare const failoverGlobalCluster: API.OperationMethod<FailoverGlobalClusterMessage & RegionInput, FailoverGlobalClusterResult, FailoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSnapshotNotFoundFault | CommonErrors;
/**
 * Lists all tags on an Amazon DocumentDB resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage & RegionInput, TagListMessage, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterParameterGroupNotFoundFault | DBSubnetGroupNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidDBSubnetGroupStateFault | InvalidSubnet | InvalidVPCNetworkStateFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Modifies a setting for an Amazon DocumentDB cluster. You can change one or more database
 * configuration parameters by specifying these parameters and the new values in the
 * request.
 */
export declare const modifyDBCluster: API.OperationMethod<ModifyDBClusterMessage & RegionInput, ModifyDBClusterResult, ModifyDBClusterError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a cluster parameter group. To modify more than one
 * parameter, submit a list of the following: `ParameterName`,
 * `ParameterValue`, and `ApplyMethod`. A maximum of 20
 * parameters can be modified in a single request.
 *
 * Changes to dynamic parameters are applied immediately. Changes to static
 * parameters require a reboot or maintenance window
 *
 * before the change can take effect.
 *
 * After you create a cluster parameter group, you should wait at least 5 minutes
 * before creating your first cluster that uses that cluster parameter group as
 * the default parameter group. This allows Amazon DocumentDB to fully complete the create action
 * before the parameter group is used as the default for a new cluster. This step is
 * especially important for parameters that are critical when creating the default
 * database for a cluster, such as the character set for the default database
 * defined by the `character_set_database` parameter.
 */
export declare const modifyDBClusterParameterGroup: API.OperationMethod<ModifyDBClusterParameterGroupMessage & RegionInput, DBClusterParameterGroupNameMessage, ModifyDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyDBClusterSnapshotAttributeError = DBClusterSnapshotNotFoundFault | InvalidDBClusterSnapshotStateFault | SharedSnapshotQuotaExceededFault | CommonErrors;
/**
 * Adds an attribute and values to, or removes an attribute and values from, a manual cluster snapshot.
 *
 * To share a manual cluster snapshot with other Amazon Web Services accounts, specify `restore` as the `AttributeName`, and use the `ValuesToAdd` parameter to add a list of IDs of the Amazon Web Services accounts that are authorized to restore the manual cluster snapshot. Use the value `all` to make the manual cluster snapshot public, which means that it can be copied or restored by all Amazon Web Services accounts. Do not add the `all` value for any manual cluster snapshots that contain private information that you don't want available to all Amazon Web Services accounts. If a manual cluster snapshot is encrypted, it can be shared, but only by specifying a list of authorized Amazon Web Services account IDs for the `ValuesToAdd` parameter. You can't use `all` as a value for that parameter in this case.
 */
export declare const modifyDBClusterSnapshotAttribute: API.OperationMethod<ModifyDBClusterSnapshotAttributeMessage & RegionInput, ModifyDBClusterSnapshotAttributeResult, ModifyDBClusterSnapshotAttributeError, Credentials | HttpClient.HttpClient>;
export type ModifyDBInstanceError = AuthorizationNotFoundFault | CertificateNotFoundFault | DBInstanceAlreadyExistsFault | DBInstanceNotFoundFault | DBParameterGroupNotFoundFault | DBSecurityGroupNotFoundFault | DBUpgradeDependencyFailureFault | InsufficientDBInstanceCapacityFault | InvalidDBInstanceStateFault | InvalidDBSecurityGroupStateFault | InvalidVPCNetworkStateFault | StorageQuotaExceededFault | StorageTypeNotSupportedFault | CommonErrors;
/**
 * Modifies settings for an instance. You can change one or more database configuration parameters by specifying these parameters and the new values in the request.
 */
export declare const modifyDBInstance: API.OperationMethod<ModifyDBInstanceMessage & RegionInput, ModifyDBInstanceResult, ModifyDBInstanceError, Credentials | HttpClient.HttpClient>;
export type ModifyDBSubnetGroupError = DBSubnetGroupDoesNotCoverEnoughAZs | DBSubnetGroupNotFoundFault | DBSubnetQuotaExceededFault | InvalidSubnet | SubnetAlreadyInUse | CommonErrors;
/**
 * Modifies an existing subnet group. subnet groups must contain at least one subnet in at least two Availability Zones in the Amazon Web Services Region.
 */
export declare const modifyDBSubnetGroup: API.OperationMethod<ModifyDBSubnetGroupMessage & RegionInput, ModifyDBSubnetGroupResult, ModifyDBSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = EventSubscriptionQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | SNSTopicArnNotFoundFault | SubscriptionCategoryNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Modifies an existing Amazon DocumentDB event notification subscription.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage & RegionInput, ModifyEventSubscriptionResult, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyGlobalClusterError = GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Modify a setting for an Amazon DocumentDB global cluster. You can change one or more configuration parameters (for example: deletion protection), or the global cluster identifier by specifying these parameters and the new values in the request.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const modifyGlobalCluster: API.OperationMethod<ModifyGlobalClusterMessage & RegionInput, ModifyGlobalClusterResult, ModifyGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type RebootDBInstanceError = DBInstanceNotFoundFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * You might need to reboot your instance, usually for maintenance reasons. For
 * example, if you make certain changes, or if you change the cluster parameter group
 * that is associated with the instance, you must reboot the instance for the changes to
 * take effect.
 *
 * Rebooting an instance restarts the database engine service. Rebooting an instance
 * results in a momentary outage, during which the instance status is set to
 * *rebooting*.
 */
export declare const rebootDBInstance: API.OperationMethod<RebootDBInstanceMessage & RegionInput, RebootDBInstanceResult, RebootDBInstanceError, Credentials | HttpClient.HttpClient>;
export type RemoveFromGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Detaches an Amazon DocumentDB secondary cluster from a global cluster. The cluster becomes a standalone cluster with read-write capability instead of being read-only and receiving data from a primary in a different region.
 *
 * This action only applies to Amazon DocumentDB clusters.
 */
export declare const removeFromGlobalCluster: API.OperationMethod<RemoveFromGlobalClusterMessage & RegionInput, RemoveFromGlobalClusterResult, RemoveFromGlobalClusterError, Credentials | HttpClient.HttpClient>;
export type RemoveSourceIdentifierFromSubscriptionError = SourceNotFoundFault | SubscriptionNotFoundFault | CommonErrors;
/**
 * Removes a source identifier from an existing Amazon DocumentDB event notification
 * subscription.
 */
export declare const removeSourceIdentifierFromSubscription: API.OperationMethod<RemoveSourceIdentifierFromSubscriptionMessage & RegionInput, RemoveSourceIdentifierFromSubscriptionResult, RemoveSourceIdentifierFromSubscriptionError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = DBClusterNotFoundFault | DBInstanceNotFoundFault | DBSnapshotNotFoundFault | CommonErrors;
/**
 * Removes metadata tags from an Amazon DocumentDB resource.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage & RegionInput, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type ResetDBClusterParameterGroupError = DBParameterGroupNotFoundFault | InvalidDBParameterGroupStateFault | CommonErrors;
/**
 * Modifies the parameters of a cluster parameter group to the default value. To
 * reset specific parameters, submit a list of the following: `ParameterName`
 * and `ApplyMethod`. To reset the entire cluster parameter group, specify
 * the `DBClusterParameterGroupName` and `ResetAllParameters`
 * parameters.
 *
 * When you reset the entire group, dynamic parameters are updated immediately and
 * static parameters are set to `pending-reboot` to take effect on the next DB
 * instance reboot.
 */
export declare const resetDBClusterParameterGroup: API.OperationMethod<ResetDBClusterParameterGroupMessage & RegionInput, DBClusterParameterGroupNameMessage, ResetDBClusterParameterGroupError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterFromSnapshotError = DBClusterAlreadyExistsFault | DBClusterQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSnapshotNotFoundFault | DBSubnetGroupNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Creates a new cluster from a snapshot or cluster snapshot.
 *
 * If a snapshot is specified, the target cluster is created from the source DB snapshot with a default configuration and default security group.
 *
 * If a cluster snapshot is specified, the target cluster is created from the source cluster restore point with the same configuration as the original source DB cluster, except that the new cluster is created with the default security group.
 */
export declare const restoreDBClusterFromSnapshot: API.OperationMethod<RestoreDBClusterFromSnapshotMessage & RegionInput, RestoreDBClusterFromSnapshotResult, RestoreDBClusterFromSnapshotError, Credentials | HttpClient.HttpClient>;
export type RestoreDBClusterToPointInTimeError = DBClusterAlreadyExistsFault | DBClusterNotFoundFault | DBClusterQuotaExceededFault | DBClusterSnapshotNotFoundFault | DBSubnetGroupNotFoundFault | InsufficientDBClusterCapacityFault | InsufficientStorageClusterCapacityFault | InvalidDBClusterSnapshotStateFault | InvalidDBClusterStateFault | InvalidDBSnapshotStateFault | InvalidRestoreFault | InvalidSubnet | InvalidVPCNetworkStateFault | KMSKeyNotAccessibleFault | NetworkTypeNotSupported | StorageQuotaExceededFault | CommonErrors;
/**
 * Restores a cluster to an arbitrary point in time. Users can restore to any point in
 * time before `LatestRestorableTime` for up to
 * `BackupRetentionPeriod` days. The target cluster is created from the
 * source cluster with the same configuration as the original cluster, except that
 * the new cluster is created with the default security group.
 */
export declare const restoreDBClusterToPointInTime: API.OperationMethod<RestoreDBClusterToPointInTimeMessage & RegionInput, RestoreDBClusterToPointInTimeResult, RestoreDBClusterToPointInTimeError, Credentials | HttpClient.HttpClient>;
export type StartDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Restarts the stopped cluster that is specified by `DBClusterIdentifier`.
 * For more information, see Stopping and
 * Starting an Amazon DocumentDB Cluster.
 */
export declare const startDBCluster: API.OperationMethod<StartDBClusterMessage & RegionInput, StartDBClusterResult, StartDBClusterError, Credentials | HttpClient.HttpClient>;
export type StopDBClusterError = DBClusterNotFoundFault | InvalidDBClusterStateFault | InvalidDBInstanceStateFault | CommonErrors;
/**
 * Stops the running cluster that is specified by `DBClusterIdentifier`. The
 * cluster must be in the *available* state. For more information, see
 * Stopping and
 * Starting an Amazon DocumentDB Cluster.
 */
export declare const stopDBCluster: API.OperationMethod<StopDBClusterMessage & RegionInput, StopDBClusterResult, StopDBClusterError, Credentials | HttpClient.HttpClient>;
export type SwitchoverGlobalClusterError = DBClusterNotFoundFault | GlobalClusterNotFoundFault | InvalidDBClusterStateFault | InvalidGlobalClusterStateFault | CommonErrors;
/**
 * Switches over the specified secondary Amazon DocumentDB cluster to be the new primary Amazon DocumentDB cluster in the global database cluster.
 */
export declare const switchoverGlobalCluster: API.OperationMethod<SwitchoverGlobalClusterMessage & RegionInput, SwitchoverGlobalClusterResult, SwitchoverGlobalClusterError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=docdb.d.ts.map