import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CheckRepoIsStarredByAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface CheckRepoIsStarredByAuthenticatedUserResponse {
}
export interface DeleteRepoSubscriptionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface DeleteRepoSubscriptionResponse {
}
export interface DeleteThreadSubscriptionRequest {
    /** The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)). */
    thread_id: number;
}
export interface DeleteThreadSubscriptionResponse {
}
export interface GetFeedsRequest {
}
export type FeedCurrentUserOrganizationUrlsList = Array<string>;
/** Hypermedia Link with Type */
export interface LinkWithType {
    href: string;
    type: string;
}
export type FeedLinksCurrentUserOrganizationsList = Array<LinkWithType>;
export interface FeedLinks {
    timeline: LinkWithType;
    user: LinkWithType;
    security_advisories?: LinkWithType | undefined;
    current_user?: LinkWithType | undefined;
    current_user_public?: LinkWithType | undefined;
    current_user_actor?: LinkWithType | undefined;
    current_user_organization?: LinkWithType | undefined;
    current_user_organizations?: FeedLinksCurrentUserOrganizationsList | undefined;
    repository_discussions?: LinkWithType | undefined;
    repository_discussions_category?: LinkWithType | undefined;
}
/** Feed */
export interface Feed {
    timeline_url: string;
    user_url: string;
    current_user_public_url?: string | undefined;
    current_user_url?: string | undefined;
    current_user_actor_url?: string | undefined;
    current_user_organization_url?: string | undefined;
    current_user_organization_urls?: FeedCurrentUserOrganizationUrlsList | undefined;
    security_advisories_url?: string | undefined;
    /** A feed of discussions for a given repository. */
    repository_discussions_url?: string | undefined;
    /** A feed of discussions for a given repository and category. */
    repository_discussions_category_url?: string | undefined;
    _links: FeedLinks;
}
export interface GetRepoSubscriptionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Repository invitations let you manage who you collaborate with. */
export interface RepositorySubscription {
    /** Determines if notifications should be received from this repository. */
    subscribed: boolean;
    /** Determines if all notifications should be blocked from this repository. */
    ignored: boolean;
    reason: string | null;
    created_at: string;
    url: string;
    repository_url: string;
}
export interface GetStargazerCountForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface GetStargazerCountForRepoResponse {
    count: number;
}
export interface GetStargazerHistoryForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** The number of stars created on each day of the week, starting on Sunday. */
export type StargazerHistoryDaysList = Array<number>;
/** Stargazer History */
export interface StargazerHistory {
    /** The number of stars created on each day of the week, starting on Sunday. */
    days: StargazerHistoryDaysList;
    /** The number of stars created during the week. */
    total: number;
    /** The start of the week, given as a Unix timestamp. */
    week: number;
}
export type GetStargazerHistoryForRepoResponseBodyList = Array<StargazerHistory>;
export type GetStargazerHistoryForRepoResponse = GetStargazerHistoryForRepoResponseBodyList;
export interface GetThreadRequest {
    /** The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)). */
    thread_id: number;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
export type MinimalRepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type MinimalRepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
export interface MinimalRepositoryPermissions {
    admin?: boolean | undefined;
    maintain?: boolean | undefined;
    push?: boolean | undefined;
    triage?: boolean | undefined;
    pull?: boolean | undefined;
}
/** Code Of Conduct */
export interface CodeOfConduct {
    key: string;
    name: string;
    url: string;
    body?: string | undefined;
    html_url: string | null;
}
export interface MinimalRepositoryLicense {
    key?: string | undefined;
    name?: string | undefined;
    spdx_id?: string | undefined;
    url?: string | null | undefined;
    node_id?: string | undefined;
}
export type SecurityAndAnalysisAdvancedSecurityStatus = "enabled" | "disabled";
/** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
export interface SecurityAndAnalysisAdvancedSecurity {
    status?: SecurityAndAnalysisAdvancedSecurityStatus | undefined;
}
export type SecurityAndAnalysisCodeSecurityStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisCodeSecurity {
    status?: SecurityAndAnalysisCodeSecurityStatus | undefined;
}
/** The enablement status of Dependabot security updates for the repository. */
export type SecurityAndAnalysisDependabotSecurityUpdatesStatus = "enabled" | "disabled";
/** Enable or disable Dependabot security updates for the repository. */
export interface SecurityAndAnalysisDependabotSecurityUpdates {
    /** The enablement status of Dependabot security updates for the repository. */
    status?: SecurityAndAnalysisDependabotSecurityUpdatesStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanning {
    status?: SecurityAndAnalysisSecretScanningStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningPushProtectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningPushProtection {
    status?: SecurityAndAnalysisSecretScanningPushProtectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningNonProviderPatternsStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningNonProviderPatterns {
    status?: SecurityAndAnalysisSecretScanningNonProviderPatternsStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningAiDetectionStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningAiDetection {
    status?: SecurityAndAnalysisSecretScanningAiDetectionStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedAlertDismissal {
    status?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissalStatus | undefined;
}
export type SecurityAndAnalysisSecretScanningDelegatedBypassStatus = "enabled" | "disabled";
export interface SecurityAndAnalysisSecretScanningDelegatedBypass {
    status?: SecurityAndAnalysisSecretScanningDelegatedBypassStatus | undefined;
}
/** The type of the bypass reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType = "TEAM" | "ROLE";
/** The bypass mode for the reviewer */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode = "ALWAYS" | "EXEMPT";
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem {
    /** The ID of the team or role selected as a bypass reviewer */
    reviewer_id: number;
    /** The type of the bypass reviewer */
    reviewer_type: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemReviewerType;
    /** The bypass mode for the reviewer */
    mode?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItemMode | undefined;
}
/** The bypass reviewers for secret scanning delegated bypass */
export type SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList = Array<SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersItem>;
export interface SecurityAndAnalysisSecretScanningDelegatedBypassOptions {
    /** The bypass reviewers for secret scanning delegated bypass */
    reviewers?: SecurityAndAnalysisSecretScanningDelegatedBypassOptionsReviewersList | undefined;
}
export interface SecurityAndAnalysis {
    /** Enable or disable GitHub Advanced Security for the repository. For standalone Code Scanning or Secret Protection products, this parameter cannot be used. */
    advanced_security?: SecurityAndAnalysisAdvancedSecurity | undefined;
    code_security?: SecurityAndAnalysisCodeSecurity | undefined;
    /** Enable or disable Dependabot security updates for the repository. */
    dependabot_security_updates?: SecurityAndAnalysisDependabotSecurityUpdates | undefined;
    secret_scanning?: SecurityAndAnalysisSecretScanning | undefined;
    secret_scanning_push_protection?: SecurityAndAnalysisSecretScanningPushProtection | undefined;
    secret_scanning_non_provider_patterns?: SecurityAndAnalysisSecretScanningNonProviderPatterns | undefined;
    secret_scanning_ai_detection?: SecurityAndAnalysisSecretScanningAiDetection | undefined;
    secret_scanning_delegated_alert_dismissal?: SecurityAndAnalysisSecretScanningDelegatedAlertDismissal | undefined;
    secret_scanning_delegated_bypass?: SecurityAndAnalysisSecretScanningDelegatedBypass | undefined;
    secret_scanning_delegated_bypass_options?: SecurityAndAnalysisSecretScanningDelegatedBypassOptions | undefined;
}
/** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
export type MinimalRepositoryCustomPropertiesMap = {
    [key: string]: unknown | undefined;
};
/** Minimal Repository */
export interface MinimalRepository {
    id: number;
    node_id: string;
    name: string;
    full_name: string;
    owner: SimpleUser;
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url?: string | undefined;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url?: string | undefined;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url?: string | undefined;
    mirror_url?: string | null | undefined;
    hooks_url: string;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    language?: string | null | undefined;
    forks_count?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size?: number | undefined;
    default_branch?: string | undefined;
    open_issues_count?: number | undefined;
    is_template?: boolean | undefined;
    topics?: MinimalRepositoryTopicsList | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: MinimalRepositoryPullRequestCreationPolicy | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    visibility?: string | undefined;
    pushed_at?: string | null | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    permissions?: MinimalRepositoryPermissions | undefined;
    role_name?: string | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    delete_branch_on_merge?: boolean | undefined;
    subscribers_count?: number | undefined;
    network_count?: number | undefined;
    code_of_conduct?: CodeOfConduct | undefined;
    license?: MinimalRepositoryLicense | null | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    allow_forking?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    security_and_analysis?: SecurityAndAnalysis | null | undefined;
    /** The custom properties that were defined for the repository. The keys are the custom property names, and the values are the corresponding custom property values. */
    custom_properties?: MinimalRepositoryCustomPropertiesMap | undefined;
}
export interface ThreadSubject {
    title: string;
    url: string;
    latest_comment_url: string;
    type: string;
}
/** Thread */
export interface Thread {
    id: string;
    repository: MinimalRepository;
    subject: ThreadSubject;
    reason: string;
    unread: boolean;
    updated_at: string;
    last_read_at: string | null;
    url: string;
    subscription_url: string;
}
export interface GetThreadSubscriptionForAuthenticatedUserRequest {
    /** The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)). */
    thread_id: number;
}
/** Thread Subscription */
export interface ThreadSubscription {
    subscribed: boolean;
    ignored: boolean;
    reason: string | null;
    created_at: string | null;
    url: string;
    thread_url?: string | undefined;
    repository_url?: string | undefined;
}
export interface ListEventsForAuthenticatedUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Actor */
export interface Actor {
    id: number;
    login: string;
    display_login?: string | undefined;
    gravatar_id: string | null;
    url: string;
    avatar_url: string;
}
export interface EventRepo {
    id: number;
    name: string;
    url: string;
}
export interface CreateEvent {
    ref: string;
    ref_type: string;
    full_ref: string;
    master_branch: string;
    description?: string | null | undefined;
    pusher_type: string;
}
export interface DeleteEvent {
    ref: string;
    ref_type: string;
    full_ref: string;
    pusher_type: string;
}
export type DiscussionAnswerChosenByType = "Bot" | "User" | "Organization";
export interface DiscussionAnswerChosenBy {
    avatar_url?: string | undefined;
    deleted?: boolean | undefined;
    email?: string | null | undefined;
    events_url?: string | undefined;
    followers_url?: string | undefined;
    following_url?: string | undefined;
    gists_url?: string | undefined;
    gravatar_id?: string | undefined;
    html_url?: string | undefined;
    id: number;
    login: string;
    name?: string | undefined;
    node_id?: string | undefined;
    organizations_url?: string | undefined;
    received_events_url?: string | undefined;
    repos_url?: string | undefined;
    site_admin?: boolean | undefined;
    starred_url?: string | undefined;
    subscriptions_url?: string | undefined;
    type?: DiscussionAnswerChosenByType | undefined;
    url?: string | undefined;
    user_view_type?: string | undefined;
}
/** How the author is associated with the repository. */
export type DiscussionAuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
export interface DiscussionCategory {
    created_at: string;
    description: string;
    emoji: string;
    id: number;
    is_answerable: boolean;
    name: string;
    node_id?: string | undefined;
    repository_id: number;
    slug: string;
    updated_at: string;
}
export interface DiscussionReactions {
    _1: number;
    _1_2: number;
    confused: number;
    eyes: number;
    heart: number;
    hooray: number;
    laugh: number;
    rocket: number;
    total_count: number;
    url: string;
}
/** The current state of the discussion. `converting` means that the discussion is being converted from an issue. `transferring` means that the discussion is being transferred from another repository. */
export type DiscussionState = "open" | "closed" | "locked" | "converting" | "transferring";
/** The reason for the current state */
export type DiscussionStateReason = "resolved" | "outdated" | "duplicate" | "reopened";
export type DiscussionUserType = "Bot" | "User" | "Organization";
export interface DiscussionUser {
    avatar_url?: string | undefined;
    deleted?: boolean | undefined;
    email?: string | null | undefined;
    events_url?: string | undefined;
    followers_url?: string | undefined;
    following_url?: string | undefined;
    gists_url?: string | undefined;
    gravatar_id?: string | undefined;
    html_url?: string | undefined;
    id: number;
    login: string;
    name?: string | undefined;
    node_id?: string | undefined;
    organizations_url?: string | undefined;
    received_events_url?: string | undefined;
    repos_url?: string | undefined;
    site_admin?: boolean | undefined;
    starred_url?: string | undefined;
    subscriptions_url?: string | undefined;
    type?: DiscussionUserType | undefined;
    url?: string | undefined;
    user_view_type?: string | undefined;
}
/** Color-coded labels help you categorize and filter your issues (just like labels in Gmail). */
export interface Label {
    /** Unique identifier for the label. */
    id: number;
    node_id: string;
    /** URL for the label */
    url: string;
    /** The name of the label. */
    name: string;
    /** Optional description of the label, such as its purpose. */
    description: string | null;
    /** 6-character hex code, without the leading #, identifying the color */
    color: string;
    /** Whether this label comes by default in a new repository. */
    default: boolean;
    /** Timestamp indicating when the label was archived, or `null` if it has not been archived. */
    archived_at: string | null;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: SimpleUser | null;
}
export type DiscussionLabelsList = Array<Label>;
/** A Discussion in a repository. */
export interface Discussion {
    active_lock_reason: string | null;
    answer_chosen_at: string | null;
    answer_chosen_by: DiscussionAnswerChosenBy | null;
    answer_html_url: string | null;
    /** How the author is associated with the repository. */
    author_association?: DiscussionAuthorAssociation | undefined;
    body: string;
    category: DiscussionCategory;
    comments: number;
    created_at: string;
    html_url: string;
    id: number;
    locked: boolean;
    node_id: string;
    number: number;
    reactions?: DiscussionReactions | undefined;
    repository_url: string;
    /** The current state of the discussion. `converting` means that the discussion is being converted from an issue. `transferring` means that the discussion is being transferred from another repository. */
    state: DiscussionState;
    /** The reason for the current state */
    state_reason: DiscussionStateReason | null;
    timeline_url?: string | undefined;
    title: string;
    updated_at: string;
    user: DiscussionUser | null;
    labels?: DiscussionLabelsList | undefined;
}
export interface DiscussionEvent {
    action: string;
    discussion: Discussion;
}
/** The reason for the current state */
export type IssueStateReason = "completed" | "reopened" | "not_planned" | "duplicate";
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
export interface IssueLabelsItemCase1 {
    id?: number | undefined;
    node_id?: string | undefined;
    url?: string | undefined;
    name?: string | undefined;
    description?: string | null | undefined;
    color?: string | null | undefined;
    default?: boolean | undefined;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by?: SimpleUser | null | undefined;
}
export type IssueLabelsItem = string | IssueLabelsItemCase1;
/** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
export type IssueLabelsList = Array<IssueLabelsItem>;
export type IssueAssigneesList = Array<SimpleUser>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: SimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export interface IssuePullRequest {
    merged_at?: string | null | undefined;
    diff_url: string | null;
    html_url: string | null;
    patch_url: string | null;
    url: string | null;
}
/** The color of the issue type. */
export type IssueTypeColor = "gray" | "blue" | "green" | "yellow" | "orange" | "red" | "pink" | "purple";
/** The type assigned to the issue. This is only present for issues in repositories where issue types are supported. */
export interface IssueType {
    /** The unique identifier of the issue type. */
    id: number;
    /** The node identifier of the issue type. */
    node_id: string;
    /** The name of the issue type. */
    name: string;
    /** The description of the issue type. */
    description: string | null;
    /** The color of the issue type. */
    color?: IssueTypeColor | null | undefined;
    /** The time the issue type created. */
    created_at?: string | undefined;
    /** The time the issue type last updated. */
    updated_at?: string | undefined;
    /** The enabled state of the issue type. */
    is_enabled?: boolean | undefined;
}
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
/** An enterprise on GitHub. */
export interface Enterprise {
    /** A short description of the enterprise. */
    description?: string | null | undefined;
    html_url: string;
    /** The enterprise's website URL. */
    website_url?: string | null | undefined;
    /** Unique identifier of the enterprise */
    id: number;
    node_id: string;
    /** The name of the enterprise. */
    name: string;
    /** The slug url identifier for the enterprise. */
    slug: string;
    created_at: string | null;
    updated_at: string | null;
    avatar_url: string;
}
export type NullableIntegrationOwner = SimpleUser | Enterprise;
/** The set of permissions for the GitHub app */
export interface NullableIntegrationPermissions {
    issues?: string | undefined;
    checks?: string | undefined;
    metadata?: string | undefined;
    contents?: string | undefined;
    deployments?: string | undefined;
    [key: string]: unknown;
}
/** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
export type NullableIntegrationEventsList = Array<string>;
/** GitHub apps are a new way to extend GitHub. They can be installed directly on organizations and user accounts and granted access to specific repositories. They come with granular permissions and built-in webhooks. GitHub apps are first class actors within GitHub. */
export interface NullableIntegration {
    /** Unique identifier of the GitHub app */
    id: number;
    /** The slug name of the GitHub app */
    slug?: string | undefined;
    node_id: string;
    client_id?: string | undefined;
    owner: NullableIntegrationOwner;
    /** The name of the GitHub app */
    name: string;
    description: string | null;
    external_url: string;
    html_url: string;
    created_at: string;
    updated_at: string;
    /** The set of permissions for the GitHub app */
    permissions: NullableIntegrationPermissions;
    /** The list of events for the GitHub app. Note that the `installation_target`, `security_advisory`, and `meta` events are not included because they are global events and not specific to an installation. */
    events: NullableIntegrationEventsList;
    /** The number of installations associated with the GitHub app. Only returned when the integration is requesting details about itself. */
    installations_count?: number | undefined;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
export interface ReactionRollup {
    url: string;
    total_count: number;
    _1: number;
    _1_2: number;
    laugh: number;
    confused: number;
    heart: number;
    hooray: number;
    eyes: number;
    rocket: number;
}
export interface SubIssuesSummary {
    total: number;
    completed: number;
    percent_completed: number;
}
/** Context around who pinned an issue comment and when it was pinned. */
export interface NullablePinnedIssueComment {
    pinned_at: string;
    pinned_by: SimpleUser | null;
}
/** Details about why an issue comment was minimized. */
export interface NullableIssueCommentMinimized {
    /** The reason the comment was minimized. */
    reason: string | null;
}
/** Comments provide a way for people to collaborate on an issue. */
export interface NullableIssueComment {
    /** Unique identifier of the issue comment */
    id: number;
    node_id: string;
    /** URL for the issue comment */
    url: string;
    /** Contents of the issue comment */
    body?: string | undefined;
    body_text?: string | undefined;
    body_html?: string | undefined;
    html_url: string;
    user: SimpleUser | null;
    created_at: string;
    updated_at: string;
    issue_url: string;
    author_association?: AuthorAssociation | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    reactions?: ReactionRollup | undefined;
    pin?: NullablePinnedIssueComment | null | undefined;
    minimized?: NullableIssueCommentMinimized | null | undefined;
}
export interface IssueDependenciesSummary {
    blocked_by: number;
    blocking: number;
    total_blocked_by: number;
    total_blocking: number;
}
/** The data type of the issue field */
export type IssueFieldValueDataType = "text" | "single_select" | "multi_select" | "number" | "date";
/** The value of the issue field */
export type IssueFieldValueValue = string | number | number;
/** Details about the selected option (only present for single_select fields) */
export interface IssueFieldValueSingleSelectOption {
    /** Unique identifier for the option. */
    id: number;
    /** The name of the option */
    name: string;
    /** The color of the option */
    color: string;
}
export type IssueFieldValueMultiSelectOptionsItem = IssueFieldValueSingleSelectOption;
/** Details about the selected options */
export type IssueFieldValueMultiSelectOptionsList = Array<IssueFieldValueSingleSelectOption>;
/** A value assigned to an issue field */
export interface IssueFieldValue {
    /** Unique identifier for the issue field. */
    issue_field_id: number;
    /** The human-readable name of the issue field. */
    issue_field_name?: string | undefined;
    node_id: string;
    /** The data type of the issue field */
    data_type: IssueFieldValueDataType;
    /** The value of the issue field */
    value: IssueFieldValueValue | null;
    /** Details about the selected option (only present for single_select fields) */
    single_select_option?: IssueFieldValueSingleSelectOption | null | undefined;
    /** Details about the selected options */
    multi_select_options?: IssueFieldValueMultiSelectOptionsList | null | undefined;
}
export type IssueIssueFieldValuesList = Array<IssueFieldValue>;
/** Issues are a great way to keep track of tasks, enhancements, and bugs for your projects. */
export interface Issue {
    id: number;
    node_id: string;
    /** URL for the issue */
    url: string;
    repository_url: string;
    labels_url: string;
    comments_url: string;
    events_url: string;
    html_url: string;
    /** Number uniquely identifying the issue within its repository */
    number: number;
    /** State of the issue; either 'open' or 'closed' */
    state: string;
    /** The reason for the current state */
    state_reason?: IssueStateReason | null | undefined;
    /** Title of the issue */
    title: string;
    /** Contents of the issue */
    body?: string | null | undefined;
    user: SimpleUser | null;
    /** Labels to associate with this issue; pass one or more label names to replace the set of labels on this issue; send an empty array to clear all labels from the issue; note that the labels are silently dropped for users without push access to the repository */
    labels: IssueLabelsList;
    assignee: SimpleUser | null;
    assignees?: IssueAssigneesList | undefined;
    milestone: NullableMilestone | null;
    locked: boolean;
    active_lock_reason?: string | null | undefined;
    comments: number;
    pull_request?: IssuePullRequest | undefined;
    closed_at: string | null;
    created_at: string;
    updated_at: string;
    draft?: boolean | undefined;
    closed_by?: SimpleUser | null | undefined;
    body_html?: string | undefined;
    body_text?: string | undefined;
    timeline_url?: string | undefined;
    type?: IssueType | null | undefined;
    repository?: Repository | undefined;
    performed_via_github_app?: NullableIntegration | null | undefined;
    author_association?: AuthorAssociation | undefined;
    reactions?: ReactionRollup | undefined;
    sub_issues_summary?: SubIssuesSummary | undefined;
    /** URL to get the parent issue of this issue, if it is a sub-issue */
    parent_issue_url?: string | null | undefined;
    pinned_comment?: NullableIssueComment | null | undefined;
    issue_dependencies_summary?: IssueDependenciesSummary | undefined;
    issue_field_values?: IssueIssueFieldValuesList | undefined;
}
export type IssuesEventAssigneesList = Array<SimpleUser>;
export type IssuesEventLabelsList = Array<Label>;
export interface IssuesEvent {
    action: string;
    issue: Issue;
    assignee?: SimpleUser | undefined;
    assignees?: IssuesEventAssigneesList | undefined;
    label?: Label | undefined;
    labels?: IssuesEventLabelsList | undefined;
}
/** Comments provide a way for people to collaborate on an issue. */
export type IssueComment = NullableIssueComment;
export interface IssueCommentEvent {
    action: string;
    issue: Issue;
    comment: NullableIssueComment;
}
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type ForkEventForkeePullRequestCreationPolicy = "all" | "collaborators_only";
export type ForkEventForkeeTopicsList = Array<string>;
export interface ForkEventForkee {
    id?: number | undefined;
    node_id?: string | undefined;
    name?: string | undefined;
    full_name?: string | undefined;
    private?: boolean | undefined;
    owner?: SimpleUser | undefined;
    html_url?: string | undefined;
    description?: string | null | undefined;
    fork?: boolean | undefined;
    url?: string | undefined;
    forks_url?: string | undefined;
    keys_url?: string | undefined;
    collaborators_url?: string | undefined;
    teams_url?: string | undefined;
    hooks_url?: string | undefined;
    issue_events_url?: string | undefined;
    events_url?: string | undefined;
    assignees_url?: string | undefined;
    branches_url?: string | undefined;
    tags_url?: string | undefined;
    blobs_url?: string | undefined;
    git_tags_url?: string | undefined;
    git_refs_url?: string | undefined;
    trees_url?: string | undefined;
    statuses_url?: string | undefined;
    languages_url?: string | undefined;
    stargazers_url?: string | undefined;
    contributors_url?: string | undefined;
    subscribers_url?: string | undefined;
    subscription_url?: string | undefined;
    commits_url?: string | undefined;
    git_commits_url?: string | undefined;
    comments_url?: string | undefined;
    issue_comment_url?: string | undefined;
    contents_url?: string | undefined;
    compare_url?: string | undefined;
    merges_url?: string | undefined;
    archive_url?: string | undefined;
    downloads_url?: string | undefined;
    issues_url?: string | undefined;
    pulls_url?: string | undefined;
    milestones_url?: string | undefined;
    notifications_url?: string | undefined;
    labels_url?: string | undefined;
    releases_url?: string | undefined;
    deployments_url?: string | undefined;
    created_at?: string | null | undefined;
    updated_at?: string | null | undefined;
    pushed_at?: string | null | undefined;
    git_url?: string | undefined;
    ssh_url?: string | undefined;
    clone_url?: string | undefined;
    svn_url?: string | undefined;
    homepage?: string | null | undefined;
    size?: number | undefined;
    stargazers_count?: number | undefined;
    watchers_count?: number | undefined;
    language?: string | null | undefined;
    has_issues?: boolean | undefined;
    has_projects?: boolean | undefined;
    has_downloads?: boolean | undefined;
    has_wiki?: boolean | undefined;
    has_pages?: boolean | undefined;
    has_discussions?: boolean | undefined;
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: ForkEventForkeePullRequestCreationPolicy | undefined;
    forks_count?: number | undefined;
    mirror_url?: string | null | undefined;
    archived?: boolean | undefined;
    disabled?: boolean | undefined;
    open_issues_count?: number | undefined;
    license?: NullableLicenseSimple | null | undefined;
    allow_forking?: boolean | undefined;
    is_template?: boolean | undefined;
    web_commit_signoff_required?: boolean | undefined;
    topics?: ForkEventForkeeTopicsList | undefined;
    visibility?: string | undefined;
    forks?: number | undefined;
    open_issues?: number | undefined;
    watchers?: number | undefined;
    default_branch?: string | undefined;
    public?: boolean | undefined;
}
export interface ForkEvent {
    action: string;
    forkee: ForkEventForkee;
}
export interface GollumEventPagesItem {
    page_name?: string | null | undefined;
    title?: string | null | undefined;
    summary?: string | null | undefined;
    action?: string | undefined;
    sha?: string | undefined;
    html_url?: string | undefined;
}
export type GollumEventPagesList = Array<GollumEventPagesItem>;
export interface GollumEvent {
    pages: GollumEventPagesList;
}
export interface MemberEvent {
    action: string;
    member: SimpleUser;
}
export interface PushEvent {
    repository_id: number;
    push_id: number;
    ref: string;
    head: string;
    before: string;
}
export interface PullRequestMinimalHeadRepo {
    id: number;
    url: string;
    name: string;
}
export interface PullRequestMinimalHead {
    ref: string;
    sha: string;
    repo: PullRequestMinimalHeadRepo;
}
export type PullRequestMinimalBaseRepo = PullRequestMinimalHeadRepo;
export type PullRequestMinimalBase = PullRequestMinimalHead;
export interface PullRequestMinimal {
    id: number;
    number: number;
    url: string;
    head: PullRequestMinimalHead;
    base: PullRequestMinimalHead;
}
export type PullRequestEventAssigneesList = Array<SimpleUser>;
export type PullRequestEventLabelsList = Array<Label>;
export interface PullRequestEvent {
    action: string;
    number: number;
    pull_request: PullRequestMinimal;
    assignee?: SimpleUser | undefined;
    assignees?: PullRequestEventAssigneesList | undefined;
    label?: Label | undefined;
    labels?: PullRequestEventLabelsList | undefined;
}
export type PullRequestReviewCommentEventCommentUserType = "Bot" | "User" | "Organization";
export interface PullRequestReviewCommentEventCommentUser {
    avatar_url?: string | undefined;
    deleted?: boolean | undefined;
    email?: string | null | undefined;
    events_url?: string | undefined;
    followers_url?: string | undefined;
    following_url?: string | undefined;
    gists_url?: string | undefined;
    gravatar_id?: string | undefined;
    html_url?: string | undefined;
    id?: number | undefined;
    login?: string | undefined;
    name?: string | undefined;
    node_id?: string | undefined;
    organizations_url?: string | undefined;
    received_events_url?: string | undefined;
    repos_url?: string | undefined;
    site_admin?: boolean | undefined;
    starred_url?: string | undefined;
    subscriptions_url?: string | undefined;
    type?: PullRequestReviewCommentEventCommentUserType | undefined;
    url?: string | undefined;
    user_view_type?: string | undefined;
}
export interface PullRequestReviewCommentEventCommentLinksHtml {
    href: string;
}
export type PullRequestReviewCommentEventCommentLinksPullRequest = PullRequestReviewCommentEventCommentLinksHtml;
export type PullRequestReviewCommentEventCommentLinksSelf = PullRequestReviewCommentEventCommentLinksHtml;
export interface PullRequestReviewCommentEventCommentLinks {
    html: PullRequestReviewCommentEventCommentLinksHtml;
    pull_request: PullRequestReviewCommentEventCommentLinksHtml;
    self: PullRequestReviewCommentEventCommentLinksHtml;
}
export interface PullRequestReviewCommentEventCommentReactions {
    _1?: number | undefined;
    _1_2?: number | undefined;
    confused?: number | undefined;
    eyes?: number | undefined;
    heart?: number | undefined;
    hooray?: number | undefined;
    laugh?: number | undefined;
    rocket?: number | undefined;
    total_count?: number | undefined;
    url?: string | undefined;
}
export interface PullRequestReviewCommentEventComment {
    id: number;
    node_id: string;
    url: string;
    pull_request_review_id: number | null;
    diff_hunk: string;
    path: string;
    position: number | null;
    original_position: number;
    subject_type?: string | null | undefined;
    commit_id: string;
    user: PullRequestReviewCommentEventCommentUser | null;
    body: string;
    created_at: string;
    updated_at: string;
    html_url: string;
    pull_request_url: string;
    _links: PullRequestReviewCommentEventCommentLinks;
    original_commit_id: string;
    reactions: PullRequestReviewCommentEventCommentReactions;
    in_reply_to_id?: number | undefined;
}
export interface PullRequestReviewCommentEvent {
    action: string;
    pull_request: PullRequestMinimal;
    comment: PullRequestReviewCommentEventComment;
}
export type PullRequestReviewEventReviewLinksHtml = PullRequestReviewCommentEventCommentLinksHtml;
export type PullRequestReviewEventReviewLinksPullRequest = PullRequestReviewCommentEventCommentLinksHtml;
export interface PullRequestReviewEventReviewLinks {
    html: PullRequestReviewCommentEventCommentLinksHtml;
    pull_request: PullRequestReviewCommentEventCommentLinksHtml;
}
export interface PullRequestReviewEventReview {
    id?: number | undefined;
    node_id?: string | undefined;
    user?: SimpleUser | null | undefined;
    body?: string | undefined;
    commit_id?: string | undefined;
    submitted_at?: string | null | undefined;
    state?: string | undefined;
    html_url?: string | undefined;
    pull_request_url?: string | undefined;
    _links?: PullRequestReviewEventReviewLinks | undefined;
    updated_at?: string | undefined;
}
export interface PullRequestReviewEvent {
    action: string;
    review: PullRequestReviewEventReview;
    pull_request: PullRequestMinimal;
}
export interface CommitCommentEventComment {
    html_url?: string | undefined;
    url?: string | undefined;
    id?: number | undefined;
    node_id?: string | undefined;
    body?: string | undefined;
    path?: string | null | undefined;
    position?: number | null | undefined;
    line?: number | null | undefined;
    commit_id?: string | undefined;
    user?: SimpleUser | null | undefined;
    created_at?: string | undefined;
    updated_at?: string | undefined;
    reactions?: ReactionRollup | undefined;
}
export interface CommitCommentEvent {
    action: string;
    comment: CommitCommentEventComment;
}
/** State of the release asset. */
export type ReleaseAssetState = "uploaded" | "open";
/** Data related to a release. */
export interface ReleaseAsset {
    url: string;
    browser_download_url: string;
    id: number;
    node_id: string;
    /** The file name of the asset. */
    name: string;
    label: string | null;
    /** State of the release asset. */
    state: ReleaseAssetState;
    content_type: string;
    size: number;
    digest: string | null;
    download_count: number;
    created_at: string;
    updated_at: string;
    uploader: SimpleUser | null;
}
export type ReleaseEventReleaseAssetsList = Array<ReleaseAsset>;
export interface ReleaseEventRelease {
    url: string;
    html_url: string;
    assets_url: string;
    upload_url: string;
    tarball_url: string | null;
    zipball_url: string | null;
    id: number;
    node_id: string;
    /** The name of the tag. */
    tag_name: string;
    /** Specifies the commitish value that determines where the Git tag is created from. */
    target_commitish: string;
    name: string | null;
    body?: string | null | undefined;
    /** true to create a draft (unpublished) release, false to create a published one. */
    draft: boolean;
    /** Whether to identify the release as a prerelease or a full release. */
    prerelease: boolean;
    /** Whether or not the release is immutable. */
    immutable?: boolean | undefined;
    created_at: string;
    published_at: string | null;
    updated_at?: string | null | undefined;
    author: SimpleUser;
    assets: ReleaseEventReleaseAssetsList;
    body_html?: string | undefined;
    body_text?: string | undefined;
    mentions_count?: number | undefined;
    /** The URL of the release discussion. */
    discussion_url?: string | undefined;
    reactions?: ReactionRollup | undefined;
    is_short_description_html_truncated?: boolean | undefined;
    short_description_html?: string | undefined;
}
export interface ReleaseEvent {
    action: string;
    release: ReleaseEventRelease;
}
export interface WatchEvent {
    action: string;
}
export type EventPayload = CreateEvent | DeleteEvent | DiscussionEvent | IssuesEvent | IssueCommentEvent | ForkEvent | GollumEvent | MemberEvent | unknown | PushEvent | PullRequestEvent | PullRequestReviewCommentEvent | PullRequestReviewEvent | CommitCommentEvent | ReleaseEvent | WatchEvent;
/** Event */
export interface Event {
    id: string;
    type: string | null;
    actor: Actor;
    repo: EventRepo;
    org?: Actor | undefined;
    payload: EventPayload;
    public: boolean;
    created_at: string | null;
}
export type ListEventsForAuthenticatedUserResponseBodyList = Array<Event>;
export type ListEventsForAuthenticatedUserResponse = ListEventsForAuthenticatedUserResponseBodyList;
export interface ListNotificationsForAuthenticatedUserRequest {
    /** If `true`, show notifications marked as read. */
    all?: boolean | undefined;
    /** Whether to return only done notifications (`true`) or exclude them (`false`). When omitted, notifications are not filtered by done status. Use `all=true&is_done=true` for done notifications or `all=true&is_done=false` for both read and unread inbox notifications. If `all` is omitted or `false`, `is_done=true` returns no notifications. */
    is_done?: boolean | undefined;
    /** If `true`, only shows notifications in which the user is directly participating or mentioned. */
    participating?: boolean | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** Only show notifications updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    before?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 50). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
}
export type ListNotificationsForAuthenticatedUserResponseBodyList = Array<Thread>;
export type ListNotificationsForAuthenticatedUserResponse = ListNotificationsForAuthenticatedUserResponseBodyList;
export interface ListOrgEventsForAuthenticatedUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListOrgEventsForAuthenticatedUserResponseBodyList = Array<Event>;
export type ListOrgEventsForAuthenticatedUserResponse = ListOrgEventsForAuthenticatedUserResponseBodyList;
export interface ListPublicEventsRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicEventsResponseBodyList = Array<Event>;
export type ListPublicEventsResponse = ListPublicEventsResponseBodyList;
export interface ListPublicEventsForRepoNetworkRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicEventsForRepoNetworkResponseBodyList = Array<Event>;
export type ListPublicEventsForRepoNetworkResponse = ListPublicEventsForRepoNetworkResponseBodyList;
export interface ListPublicEventsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicEventsForUserResponseBodyList = Array<Event>;
export type ListPublicEventsForUserResponse = ListPublicEventsForUserResponseBodyList;
export interface ListPublicOrgEventsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListPublicOrgEventsResponseBodyList = Array<Event>;
export type ListPublicOrgEventsResponse = ListPublicOrgEventsResponseBodyList;
export interface ListReceivedEventsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReceivedEventsForUserResponseBodyList = Array<Event>;
export type ListReceivedEventsForUserResponse = ListReceivedEventsForUserResponseBodyList;
export interface ListReceivedPublicEventsForUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReceivedPublicEventsForUserResponseBodyList = Array<Event>;
export type ListReceivedPublicEventsForUserResponse = ListReceivedPublicEventsForUserResponseBodyList;
export interface ListRepoEventsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoEventsResponseBodyList = Array<Event>;
export type ListRepoEventsResponse = ListRepoEventsResponseBodyList;
export interface ListRepoNotificationsForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** If `true`, show notifications marked as read. */
    all?: boolean | undefined;
    /** Whether to return only done notifications (`true`) or exclude them (`false`). When omitted, notifications are not filtered by done status. Use `all=true&is_done=true` for done notifications or `all=true&is_done=false` for both read and unread inbox notifications. If `all` is omitted or `false`, `is_done=true` returns no notifications. */
    is_done?: boolean | undefined;
    /** If `true`, only shows notifications in which the user is directly participating or mentioned. */
    participating?: boolean | undefined;
    /** Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    since?: string | undefined;
    /** Only show notifications updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    before?: string | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListRepoNotificationsForAuthenticatedUserResponseBodyList = Array<Thread>;
export type ListRepoNotificationsForAuthenticatedUserResponse = ListRepoNotificationsForAuthenticatedUserResponseBodyList;
export type ListReposStarredByAuthenticatedUserRequestSort = "created" | "updated";
export type ListReposStarredByAuthenticatedUserRequestDirection = "asc" | "desc";
export interface ListReposStarredByAuthenticatedUserRequest {
    /** The property to sort the results by. `created` means when the repository was starred. `updated` means when the repository was last pushed to. */
    sort?: ListReposStarredByAuthenticatedUserRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListReposStarredByAuthenticatedUserRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReposStarredByAuthenticatedUserResponseBodyList = Array<Repository>;
export type ListReposStarredByAuthenticatedUserResponse = ListReposStarredByAuthenticatedUserResponseBodyList;
export type ListReposStarredByUserRequestSort = "created" | "updated";
export type ListReposStarredByUserRequestDirection = "asc" | "desc";
export interface ListReposStarredByUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The property to sort the results by. `created` means when the repository was starred. `updated` means when the repository was last pushed to. */
    sort?: ListReposStarredByUserRequestSort | (string & {}) | undefined;
    /** The direction to sort the results by. */
    direction?: ListReposStarredByUserRequestDirection | (string & {}) | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
/** Starred Repository */
export interface StarredRepository {
    starred_at: string;
    repo: Repository;
}
export type ListReposStarredByUserResponseBodyCase0List = Array<StarredRepository>;
export type ListReposStarredByUserResponseBodyCase1List = Array<Repository>;
export type ListReposStarredByUserResponseBody = ListReposStarredByUserResponseBodyCase0List | ListReposStarredByUserResponseBodyCase1List;
export type ListReposStarredByUserResponse = ListReposStarredByUserResponseBody;
export interface ListReposWatchedByUserRequest {
    /** The handle for the GitHub user account. */
    username: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListReposWatchedByUserResponseBodyList = Array<MinimalRepository>;
export type ListReposWatchedByUserResponse = ListReposWatchedByUserResponseBodyList;
export interface ListStargazersForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListStargazersForRepoResponseBodyCase0List = Array<SimpleUser>;
/** Stargazer */
export interface Stargazer {
    starred_at: string;
    user: SimpleUser | null;
}
export type ListStargazersForRepoResponseBodyCase1List = Array<Stargazer>;
export type ListStargazersForRepoResponseBody = ListStargazersForRepoResponseBodyCase0List | ListStargazersForRepoResponseBodyCase1List;
export type ListStargazersForRepoResponse = ListStargazersForRepoResponseBody;
export interface ListWatchedReposForAuthenticatedUserRequest {
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListWatchedReposForAuthenticatedUserResponseBodyList = Array<MinimalRepository>;
export type ListWatchedReposForAuthenticatedUserResponse = ListWatchedReposForAuthenticatedUserResponseBodyList;
export interface ListWatchersForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
}
export type ListWatchersForRepoResponseBodyList = Array<SimpleUser>;
export type ListWatchersForRepoResponse = ListWatchersForRepoResponseBodyList;
export interface MarkThreadAsDoneRequest {
    /** The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)). */
    thread_id: number;
}
export interface MarkThreadAsDoneResponse {
}
export interface ReadMarkNotificationsAsRequest {
    /** Describes the last point that notifications were checked. Anything updated since this time will not be marked as read. If you omit this parameter, all notifications are marked as read. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Default: The current timestamp. */
    last_read_at?: string | undefined;
    /** Whether the notification has been read. */
    read?: boolean | undefined;
}
export interface ReadMarkNotificationsAsResponse {
}
export interface ReadMarkRepoNotificationsAsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Describes the last point that notifications were checked. Anything updated since this time will not be marked as read. If you omit this parameter, all notifications are marked as read. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Default: The current timestamp. */
    last_read_at?: string | undefined;
}
export interface ReadMarkRepoNotificationsAsResponse {
}
export interface ReadMarkThreadAsRequest {
    /** The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)). */
    thread_id: number;
}
export interface ReadMarkThreadAsResponse {
}
export interface SetRepoSubscriptionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Determines if notifications should be received from this repository. */
    subscribed?: boolean | undefined;
    /** Determines if all notifications should be blocked from this repository. */
    ignored?: boolean | undefined;
}
export interface SetThreadSubscriptionRequest {
    /** The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)). */
    thread_id: number;
    /** Whether to block all notifications from a thread. */
    ignored?: boolean | undefined;
}
export interface StarRepoForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface StarRepoForAuthenticatedUserResponse {
}
export interface UnstarRepoForAuthenticatedUserRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export interface UnstarRepoForAuthenticatedUserResponse {
}
export type CheckRepoIsStarredByAuthenticatedUserError = GithubOpError;
/** Check if a repository is starred by the authenticated user Whether the authenticated user has starred the repository. */
export declare const checkRepoIsStarredByAuthenticatedUser: API.OperationMethod<CheckRepoIsStarredByAuthenticatedUserRequest, CheckRepoIsStarredByAuthenticatedUserResponse, CheckRepoIsStarredByAuthenticatedUserError, GithubOpContext>;
export type DeleteRepoSubscriptionError = GithubOpError;
/** Delete a repository subscription This endpoint should only be used to stop watching a repository. To control whether or not you wish to receive notifications from a repository, [set the repository's subscription manually](https://docs.github.com/rest/activity/watching#set-a-repository-subscription). */
export declare const deleteRepoSubscription: API.OperationMethod<DeleteRepoSubscriptionRequest, DeleteRepoSubscriptionResponse, DeleteRepoSubscriptionError, GithubOpContext>;
export type DeleteThreadSubscriptionError = GithubOpError;
/** Delete a thread subscription Mutes all future notifications for a conversation until you comment on the thread or get an **@mention**. If you are watching the repository of the thread, you will still receive notifications. To ignore future notifications for a repository you are watching, use the [Set a thread subscription](https://docs.github.com/rest/activity/notifications#set-a-thread-subscription) endpoint and set `ignore` to `true`. */
export declare const deleteThreadSubscription: API.OperationMethod<DeleteThreadSubscriptionRequest, DeleteThreadSubscriptionResponse, DeleteThreadSubscriptionError, GithubOpContext>;
export type GetFeedsError = GithubOpError;
/** Get feeds Lists the feeds available to the authenticated user. The response provides a URL for each feed. You can then get a specific feed by sending a request to one of the feed URLs. * **Timeline**: The GitHub global public timeline * **User**: The public timeline for any user, using `uri_template`. For more information, see "[Hypermedia](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#hypermedia)." * **Current user public**: The public timeline for the authenticated user * **Current user**: The private timeline for the authenticated user * **Current user actor**: The private timeline for activity created by the authenticated user * **Current user organizations**: The private timeline for the organizations the authenticated user is a member of. * **Security advisories**: A collection of public announcements that provide information about security-related vulnerabilities in software on GitHub. By default, timeline resources are returned in JSON. You can specify the `application/atom+xml` type in the `Accept` header to return timeline resources in Atom format. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." > [!NOTE] > Private feeds are only returned when [authenticating via Basic Auth](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) since current feed URIs use the older, non revocable auth tokens. */
export declare const getFeeds: API.OperationMethod<GetFeedsRequest, Feed, GetFeedsError, GithubOpContext>;
export type GetRepoSubscriptionError = GithubOpError;
/** Get a repository subscription Gets information about whether the authenticated user is subscribed to the repository. */
export declare const getRepoSubscription: API.OperationMethod<GetRepoSubscriptionRequest, RepositorySubscription, GetRepoSubscriptionError, GithubOpContext>;
export type GetStargazerCountForRepoError = GithubOpError;
/** Get stargazer count Gets the current number of users who have starred the repository. Users who previously starred the repository but later removed their star are not included. */
export declare const getStargazerCountForRepo: API.OperationMethod<GetStargazerCountForRepoRequest, GetStargazerCountForRepoResponse, GetStargazerCountForRepoError, GithubOpContext>;
export type GetStargazerHistoryForRepoError = GithubOpError;
/** Get repository star history Returns repository stars grouped by calendar weeks, most recent first. Pages move backward toward the repository's creation week, and weeks within a page are ordered newest to oldest, so concatenating pages produces one continuous series. Weeks without stars contain zero counts. Week and day boundaries are not guaranteed to align with UTC. The `days` array contains the number of stars created on each day of the week, starting on Sunday. */
export declare const getStargazerHistoryForRepo: API.PaginatedOperationMethod<GetStargazerHistoryForRepoRequest, GetStargazerHistoryForRepoResponse, GetStargazerHistoryForRepoError, GithubOpContext, StargazerHistory>;
export type GetThreadError = GithubOpError;
/** Get a thread Gets information about a notification thread. */
export declare const getThread: API.OperationMethod<GetThreadRequest, Thread, GetThreadError, GithubOpContext>;
export type GetThreadSubscriptionForAuthenticatedUserError = GithubOpError;
/** Get a thread subscription for the authenticated user This checks to see if the current user is subscribed to a thread. You can also [get a repository subscription](https://docs.github.com/rest/activity/watching#get-a-repository-subscription). Note that subscriptions are only generated if a user is participating in a conversation--for example, they've replied to the thread, were **@mentioned**, or manually subscribe to a thread. */
export declare const getThreadSubscriptionForAuthenticatedUser: API.OperationMethod<GetThreadSubscriptionForAuthenticatedUserRequest, ThreadSubscription, GetThreadSubscriptionForAuthenticatedUserError, GithubOpContext>;
export type ListEventsForAuthenticatedUserError = GithubOpError;
/** List events for the authenticated user If you are authenticated as the given user, you will see your private events. Otherwise, you'll only see public events. _Optional_: use the fine-grained token with following permission set to view private events: "Events" user permissions (read). > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listEventsForAuthenticatedUser: API.PaginatedOperationMethod<ListEventsForAuthenticatedUserRequest, ListEventsForAuthenticatedUserResponse, ListEventsForAuthenticatedUserError, GithubOpContext, Event>;
export type ListNotificationsForAuthenticatedUserError = GithubOpError;
/** List notifications for the authenticated user List all notifications for the current user, sorted by most recently updated. */
export declare const listNotificationsForAuthenticatedUser: API.PaginatedOperationMethod<ListNotificationsForAuthenticatedUserRequest, ListNotificationsForAuthenticatedUserResponse, ListNotificationsForAuthenticatedUserError, GithubOpContext, Thread>;
export type ListOrgEventsForAuthenticatedUserError = GithubOpError;
/** List organization events for the authenticated user This is the user's organization dashboard. You must be authenticated as the user to view this. > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listOrgEventsForAuthenticatedUser: API.PaginatedOperationMethod<ListOrgEventsForAuthenticatedUserRequest, ListOrgEventsForAuthenticatedUserResponse, ListOrgEventsForAuthenticatedUserError, GithubOpContext, Event>;
export type ListPublicEventsError = GithubOpError;
/** List public events > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listPublicEvents: API.PaginatedOperationMethod<ListPublicEventsRequest, ListPublicEventsResponse, ListPublicEventsError, GithubOpContext, Event>;
export type ListPublicEventsForRepoNetworkError = GithubOpError;
/** List public events for a network of repositories > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listPublicEventsForRepoNetwork: API.PaginatedOperationMethod<ListPublicEventsForRepoNetworkRequest, ListPublicEventsForRepoNetworkResponse, ListPublicEventsForRepoNetworkError, GithubOpContext, Event>;
export type ListPublicEventsForUserError = GithubOpError;
/** List public events for a user > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listPublicEventsForUser: API.PaginatedOperationMethod<ListPublicEventsForUserRequest, ListPublicEventsForUserResponse, ListPublicEventsForUserError, GithubOpContext, Event>;
export type ListPublicOrgEventsError = GithubOpError;
/** List public organization events > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listPublicOrgEvents: API.PaginatedOperationMethod<ListPublicOrgEventsRequest, ListPublicOrgEventsResponse, ListPublicOrgEventsError, GithubOpContext, Event>;
export type ListReceivedEventsForUserError = GithubOpError;
/** List events received by the authenticated user These are events that you've received by watching repositories and following users. If you are authenticated as the given user, you will see private events. Otherwise, you'll only see public events. > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listReceivedEventsForUser: API.PaginatedOperationMethod<ListReceivedEventsForUserRequest, ListReceivedEventsForUserResponse, ListReceivedEventsForUserError, GithubOpContext, Event>;
export type ListReceivedPublicEventsForUserError = GithubOpError;
/** List public events received by a user > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listReceivedPublicEventsForUser: API.PaginatedOperationMethod<ListReceivedPublicEventsForUserRequest, ListReceivedPublicEventsForUserResponse, ListReceivedPublicEventsForUserError, GithubOpContext, Event>;
export type ListRepoEventsError = GithubOpError;
/** List repository events > [!NOTE] > This API is not built to serve real-time use cases. Depending on the time of day, event latency can be anywhere from 30s to 6h. */
export declare const listRepoEvents: API.PaginatedOperationMethod<ListRepoEventsRequest, ListRepoEventsResponse, ListRepoEventsError, GithubOpContext, Event>;
export type ListRepoNotificationsForAuthenticatedUserError = GithubOpError;
/** List repository notifications for the authenticated user Lists all notifications for the current user in the specified repository. */
export declare const listRepoNotificationsForAuthenticatedUser: API.PaginatedOperationMethod<ListRepoNotificationsForAuthenticatedUserRequest, ListRepoNotificationsForAuthenticatedUserResponse, ListRepoNotificationsForAuthenticatedUserError, GithubOpContext, Thread>;
export type ListReposStarredByAuthenticatedUserError = GithubOpError;
/** List repositories starred by the authenticated user Lists repositories the authenticated user has starred. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.star+json`**: Includes a timestamp of when the star was created. */
export declare const listReposStarredByAuthenticatedUser: API.PaginatedOperationMethod<ListReposStarredByAuthenticatedUserRequest, ListReposStarredByAuthenticatedUserResponse, ListReposStarredByAuthenticatedUserError, GithubOpContext, Repository>;
export type ListReposStarredByUserError = GithubOpError;
/** List repositories starred by a user Lists repositories a user has starred. If the specified user has a [private profile](https://docs.github.com/account-and-profile/concepts/personal-profile#private-profiles), this endpoint returns an empty list unless the request is authenticated as that user. A request authenticated as the specified user returns starred repositories visible to the token even if the token has no OAuth scopes. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.star+json`**: Includes a timestamp of when the star was created. */
export declare const listReposStarredByUser: API.OperationMethod<ListReposStarredByUserRequest, ListReposStarredByUserResponse, ListReposStarredByUserError, GithubOpContext>;
export type ListReposWatchedByUserError = GithubOpError;
/** List repositories watched by a user Lists repositories a user is watching. */
export declare const listReposWatchedByUser: API.PaginatedOperationMethod<ListReposWatchedByUserRequest, ListReposWatchedByUserResponse, ListReposWatchedByUserError, GithubOpContext, MinimalRepository>;
export type ListStargazersForRepoError = GithubOpError;
/** List stargazers Lists the people that have starred the repository. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/vnd.github.star+json`**: Includes a timestamp of when the star was created. */
export declare const listStargazersForRepo: API.OperationMethod<ListStargazersForRepoRequest, ListStargazersForRepoResponse, ListStargazersForRepoError, GithubOpContext>;
export type ListWatchedReposForAuthenticatedUserError = GithubOpError;
/** List repositories watched by the authenticated user Lists repositories the authenticated user is watching. */
export declare const listWatchedReposForAuthenticatedUser: API.PaginatedOperationMethod<ListWatchedReposForAuthenticatedUserRequest, ListWatchedReposForAuthenticatedUserResponse, ListWatchedReposForAuthenticatedUserError, GithubOpContext, MinimalRepository>;
export type ListWatchersForRepoError = GithubOpError;
/** List watchers Lists the people watching the specified repository. */
export declare const listWatchersForRepo: API.PaginatedOperationMethod<ListWatchersForRepoRequest, ListWatchersForRepoResponse, ListWatchersForRepoError, GithubOpContext, SimpleUser>;
export type MarkThreadAsDoneError = GithubOpError;
/** Mark a thread as done Marks a thread as "done." Marking a thread as "done" is equivalent to marking a notification in your notification inbox on GitHub as done: https://github.com/notifications. */
export declare const markThreadAsDone: API.OperationMethod<MarkThreadAsDoneRequest, MarkThreadAsDoneResponse, MarkThreadAsDoneError, GithubOpContext>;
export type ReadMarkNotificationsAsError = GithubOpError;
/** Mark notifications as read Marks all notifications as "read" for the current user. If the number of notifications is too large to complete in one request, you will receive a `202 Accepted` status and GitHub will run an asynchronous process to mark notifications as "read." To check whether any "unread" notifications remain, you can use the [List notifications for the authenticated user](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user) endpoint and pass the query parameter `all=false`. */
export declare const readMarkNotificationsAs: API.OperationMethod<ReadMarkNotificationsAsRequest, ReadMarkNotificationsAsResponse, ReadMarkNotificationsAsError, GithubOpContext>;
export type ReadMarkRepoNotificationsAsError = GithubOpError;
/** Mark repository notifications as read Marks all notifications in a repository as "read" for the current user. If the number of notifications is too large to complete in one request, you will receive a `202 Accepted` status and GitHub will run an asynchronous process to mark notifications as "read." To check whether any "unread" notifications remain, you can use the [List repository notifications for the authenticated user](https://docs.github.com/rest/activity/notifications#list-repository-notifications-for-the-authenticated-user) endpoint and pass the query parameter `all=false`. */
export declare const readMarkRepoNotificationsAs: API.OperationMethod<ReadMarkRepoNotificationsAsRequest, ReadMarkRepoNotificationsAsResponse, ReadMarkRepoNotificationsAsError, GithubOpContext>;
export type ReadMarkThreadAsError = GithubOpError;
/** Mark a thread as read Marks a thread as "read." Marking a thread as "read" is equivalent to clicking a notification in your notification inbox on GitHub: https://github.com/notifications. */
export declare const readMarkThreadAs: API.OperationMethod<ReadMarkThreadAsRequest, ReadMarkThreadAsResponse, ReadMarkThreadAsError, GithubOpContext>;
export type SetRepoSubscriptionError = GithubOpError;
/** Set a repository subscription If you would like to watch a repository, set `subscribed` to `true`. If you would like to ignore notifications made within a repository, set `ignored` to `true`. If you would like to stop watching a repository, [delete the repository's subscription](https://docs.github.com/rest/activity/watching#delete-a-repository-subscription) completely. */
export declare const setRepoSubscription: API.OperationMethod<SetRepoSubscriptionRequest, RepositorySubscription, SetRepoSubscriptionError, GithubOpContext>;
export type SetThreadSubscriptionError = GithubOpError;
/** Set a thread subscription If you are watching a repository, you receive notifications for all threads by default. Use this endpoint to ignore future notifications for threads until you comment on the thread or get an **@mention**. You can also use this endpoint to subscribe to threads that you are currently not receiving notifications for or to subscribed to threads that you have previously ignored. Unsubscribing from a conversation in a repository that you are not watching is functionally equivalent to the [Delete a thread subscription](https://docs.github.com/rest/activity/notifications#delete-a-thread-subscription) endpoint. */
export declare const setThreadSubscription: API.OperationMethod<SetThreadSubscriptionRequest, ThreadSubscription, SetThreadSubscriptionError, GithubOpContext>;
export type StarRepoForAuthenticatedUserError = GithubOpError;
/** Star a repository for the authenticated user Note that you'll need to set `Content-Length` to zero when calling out to this endpoint. For more information, see "[HTTP method](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#http-method)." */
export declare const starRepoForAuthenticatedUser: API.OperationMethod<StarRepoForAuthenticatedUserRequest, StarRepoForAuthenticatedUserResponse, StarRepoForAuthenticatedUserError, GithubOpContext>;
export type UnstarRepoForAuthenticatedUserError = GithubOpError;
/** Unstar a repository for the authenticated user Unstar a repository that the authenticated user has previously starred. */
export declare const unstarRepoForAuthenticatedUser: API.OperationMethod<UnstarRepoForAuthenticatedUserRequest, UnstarRepoForAuthenticatedUserResponse, UnstarRepoForAuthenticatedUserError, GithubOpContext>;
//# sourceMappingURL=activity.d.ts.map