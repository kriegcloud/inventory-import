/** Terminal-emulator features shared by CLI components. */
import { type ChalkInstance } from "@alchemy.run/sigil/ansi";
import { detectUnicodeSupport } from "@alchemy.run/sigil/capabilities";
/**
 * The canonical color-support decision, shared by raw terminal strings and
 * terminal capability detection so the two can never disagree.
 */
export declare const colorsEnabled: (stream?: Pick<NodeJS.WriteStream, "isTTY">) => boolean;
/** The canonical Unicode-support decision for raw terminal strings. */
export declare const unicodeEnabled: typeof detectUnicodeSupport;
/**
 * Environment override for child processes whose piped output returns here:
 * forwards this terminal's color level, since the child only sees a pipe.
 */
export declare const pipedColorEnv: () => Record<string, string>;
/**
 * Chainable styles for raw, non-layout output (`style.bold.hex("#e28a5b")(text)`),
 * with the color level detected for `stream`. `colors` overrides detection:
 * `true` is truecolor, `false` plain text.
 */
export declare const terminalStyle: (options?: {
    readonly stream?: Pick<NodeJS.WriteStream, "isTTY">;
    readonly colors?: boolean;
}) => ChalkInstance;
/**
 * Copy to the user's clipboard: OSC 52 (wrapped for tmux or screen), tmux's
 * own buffer, and the system clipboard tool for local sessions.
 */
export declare const copyToClipboard: (text: string, stdout?: {
    write(data: string): boolean;
}) => void;
/** Display-width-aware truncation (wide CJK/emoji count by rendered cells). */
export declare const truncate: (value: string, width: number) => string;
//# sourceMappingURL=Terminal.d.ts.map