import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type * as stream from "effect/Stream";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExternalResourceException_base: S.TaggedErrorClass<"ExternalResourceException", {
    readonly message: any;
}>;
export declare class ExternalResourceException extends /*@__PURE__*/ ExternalResourceException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const LicenseNotFoundException_base: S.TaggedErrorClass<"LicenseNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LicenseNotFoundException extends /*@__PURE__*/ LicenseNotFoundException_base {
}
declare const MediaTooLargeException_base: S.TaggedErrorClass<"MediaTooLargeException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class MediaTooLargeException extends /*@__PURE__*/ MediaTooLargeException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fields: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ApplicationId = string;
export type StatementId = string;
export type QIamAction = string;
export type QIamActions = string[];
export type PermissionConditionOperator = "StringEquals" | (string & {});
export type PermissionConditionKey = string;
export type PermissionConditionValue = string;
export type PermissionConditionValues = string[];
export interface PermissionCondition {
    conditionOperator: PermissionConditionOperator;
    conditionKey: string;
    conditionValues: string[];
}
export type PermissionConditions = PermissionCondition[];
export type PrincipalRoleArn = string;
export interface AssociatePermissionRequest {
    applicationId: string;
    statementId: string;
    actions: string[];
    conditions?: PermissionCondition[] | undefined;
    principal: string;
}
export interface AssociatePermissionResponse {
    statement?: string | undefined;
}
export type IndexId = string;
export type DocumentId = string;
export interface DeleteDocument {
    documentId: string;
}
export type DeleteDocuments = DeleteDocument[];
export type ExecutionId = string;
export interface BatchDeleteDocumentRequest {
    applicationId: string;
    indexId: string;
    documents: DeleteDocument[];
    dataSourceSyncId?: string | undefined;
}
export type ErrorMessage = string;
export type ErrorCode = "InternalError" | "InvalidRequest" | "ResourceInactive" | "ResourceNotFound" | (string & {});
export interface ErrorDetail {
    errorMessage?: string | undefined;
    errorCode?: ErrorCode | undefined;
}
export type DataSourceId = string;
export interface FailedDocument {
    id?: string | undefined;
    error?: ErrorDetail | undefined;
    dataSourceId?: string | undefined;
}
export type FailedDocuments = FailedDocument[];
export interface BatchDeleteDocumentResponse {
    failedDocuments?: FailedDocument[] | undefined;
}
export type DocumentAttributeKey = string;
export type DocumentAttributeStringValue = string;
export type DocumentAttributeStringListValue = string[];
export type DocumentAttributeValue = {
    stringValue: string;
    stringListValue?: undefined;
    longValue?: undefined;
    dateValue?: undefined;
} | {
    stringValue?: undefined;
    stringListValue: string[];
    longValue?: undefined;
    dateValue?: undefined;
} | {
    stringValue?: undefined;
    stringListValue?: undefined;
    longValue: number;
    dateValue?: undefined;
} | {
    stringValue?: undefined;
    stringListValue?: undefined;
    longValue?: undefined;
    dateValue: Date;
};
export interface DocumentAttribute {
    name: string;
    value: DocumentAttributeValue;
}
export type DocumentAttributes = DocumentAttribute[];
export type S3BucketName = string;
export type S3ObjectKey = string;
export interface S3 {
    bucket: string;
    key: string;
}
export type DocumentContent = {
    blob: Uint8Array;
    s3?: undefined;
} | {
    blob?: undefined;
    s3: S3;
};
export type ContentType = "PDF" | "HTML" | "MS_WORD" | "PLAIN_TEXT" | "PPT" | "RTF" | "XML" | "XSLT" | "MS_EXCEL" | "CSV" | "JSON" | "MD" | (string & {});
export type Title = string;
export type UserId = string;
export type ReadAccessType = "ALLOW" | "DENY" | (string & {});
export type MembershipType = "INDEX" | "DATASOURCE" | (string & {});
export interface PrincipalUser {
    id?: string | undefined;
    access: ReadAccessType;
    membershipType?: MembershipType | undefined;
}
export type GroupName = string;
export interface PrincipalGroup {
    name?: string | undefined;
    access: ReadAccessType;
    membershipType?: MembershipType | undefined;
}
export type Principal = {
    user: PrincipalUser;
    group?: undefined;
} | {
    user?: undefined;
    group: PrincipalGroup;
};
export type Principals = Principal[];
export type MemberRelation = "AND" | "OR" | (string & {});
export interface AccessControl {
    principals: Principal[];
    memberRelation?: MemberRelation | undefined;
}
export type AccessControls = AccessControl[];
export interface AccessConfiguration {
    accessControls: AccessControl[];
    memberRelation?: MemberRelation | undefined;
}
export type DocumentEnrichmentConditionOperator = "GREATER_THAN" | "GREATER_THAN_OR_EQUALS" | "LESS_THAN" | "LESS_THAN_OR_EQUALS" | "EQUALS" | "NOT_EQUALS" | "CONTAINS" | "NOT_CONTAINS" | "EXISTS" | "NOT_EXISTS" | "BEGINS_WITH" | (string & {});
export interface DocumentAttributeCondition {
    key: string;
    operator: DocumentEnrichmentConditionOperator;
    value?: DocumentAttributeValue | undefined;
}
export type AttributeValueOperator = "DELETE" | (string & {});
export interface DocumentAttributeTarget {
    key: string;
    value?: DocumentAttributeValue | undefined;
    attributeValueOperator?: AttributeValueOperator | undefined;
}
export type DocumentContentOperator = "DELETE" | (string & {});
export interface InlineDocumentEnrichmentConfiguration {
    condition?: DocumentAttributeCondition | undefined;
    target?: DocumentAttributeTarget | undefined;
    documentContentOperator?: DocumentContentOperator | undefined;
}
export type InlineDocumentEnrichmentConfigurations = InlineDocumentEnrichmentConfiguration[];
export type LambdaArn = string;
export type RoleArn = string;
export interface HookConfiguration {
    invocationCondition?: DocumentAttributeCondition | undefined;
    lambdaArn?: string | undefined;
    s3BucketName?: string | undefined;
    roleArn?: string | undefined;
}
export interface DocumentEnrichmentConfiguration {
    inlineConfigurations?: InlineDocumentEnrichmentConfiguration[] | undefined;
    preExtractionHookConfiguration?: HookConfiguration | undefined;
    postExtractionHookConfiguration?: HookConfiguration | undefined;
}
export type ImageExtractionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface ImageExtractionConfiguration {
    imageExtractionStatus: ImageExtractionStatus;
}
export type AudioExtractionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AudioExtractionConfiguration {
    audioExtractionStatus: AudioExtractionStatus;
}
export type VideoExtractionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface VideoExtractionConfiguration {
    videoExtractionStatus: VideoExtractionStatus;
}
export interface MediaExtractionConfiguration {
    imageExtractionConfiguration?: ImageExtractionConfiguration | undefined;
    audioExtractionConfiguration?: AudioExtractionConfiguration | undefined;
    videoExtractionConfiguration?: VideoExtractionConfiguration | undefined;
}
export interface Document {
    id: string;
    attributes?: DocumentAttribute[] | undefined;
    content?: DocumentContent | undefined;
    contentType?: ContentType | undefined;
    title?: string | undefined;
    accessConfiguration?: AccessConfiguration | undefined;
    documentEnrichmentConfiguration?: DocumentEnrichmentConfiguration | undefined;
    mediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
}
export type Documents = Document[];
export interface BatchPutDocumentRequest {
    applicationId: string;
    indexId: string;
    documents: Document[];
    roleArn?: string | undefined;
    dataSourceSyncId?: string | undefined;
}
export interface BatchPutDocumentResponse {
    failedDocuments?: FailedDocument[] | undefined;
}
export type SubscriptionId = string;
export interface CancelSubscriptionRequest {
    applicationId: string;
    subscriptionId: string;
}
export type SubscriptionArn = string;
export type SubscriptionType = "Q_LITE" | "Q_BUSINESS" | (string & {});
export interface SubscriptionDetails {
    type?: SubscriptionType | undefined;
}
export interface CancelSubscriptionResponse {
    subscriptionArn?: string | undefined;
    currentSubscription?: SubscriptionDetails | undefined;
    nextSubscription?: SubscriptionDetails | undefined;
}
export type UserGroups = string[];
export type ConversationId = string;
export type MessageId = string;
export type ClientToken = string;
export type ChatMode = "RETRIEVAL_MODE" | "CREATOR_MODE" | "PLUGIN_MODE" | (string & {});
export type PluginId = string;
export interface PluginConfiguration {
    pluginId: string;
}
export type ChatModeConfiguration = {
    pluginConfiguration: PluginConfiguration;
};
export type AttributeFilters = AttributeFilter[];
export interface AttributeFilter {
    andAllFilters?: AttributeFilter[] | undefined;
    orAllFilters?: AttributeFilter[] | undefined;
    notFilter?: AttributeFilter | undefined;
    equalsTo?: DocumentAttribute | undefined;
    containsAll?: DocumentAttribute | undefined;
    containsAny?: DocumentAttribute | undefined;
    greaterThan?: DocumentAttribute | undefined;
    greaterThanOrEquals?: DocumentAttribute | undefined;
    lessThan?: DocumentAttribute | undefined;
    lessThanOrEquals?: DocumentAttribute | undefined;
}
export interface ConfigurationEvent {
    chatMode?: ChatMode | undefined;
    chatModeConfiguration?: ChatModeConfiguration | undefined;
    attributeFilter?: AttributeFilter | undefined;
}
export type UserMessage = string;
export interface TextInputEvent {
    userMessage: string;
}
export type AttachmentName = string;
export type AttachmentId = string;
export interface ConversationSource {
    conversationId: string;
    attachmentId: string;
}
export type CopyFromSource = {
    conversation: ConversationSource;
};
export interface AttachmentInput {
    data?: Uint8Array | undefined;
    name?: string | undefined;
    copyFrom?: CopyFromSource | undefined;
}
export interface AttachmentInputEvent {
    attachment?: AttachmentInput | undefined;
}
export type ActionPayloadFieldKey = string;
export type ActionPayloadFieldValue = unknown;
export interface ActionExecutionPayloadField {
    value: any;
}
export type ActionExecutionPayload = {
    [key: string]: ActionExecutionPayloadField | undefined;
};
export type ActionPayloadFieldNameSeparator = string;
export interface ActionExecutionEvent {
    pluginId: string;
    payload: {
        [key: string]: ActionExecutionPayloadField | undefined;
    };
    payloadFieldNameSeparator: string;
}
export interface EndOfInputEvent {
}
export type AuthResponseKey = string;
export type AuthResponseValue = string;
export type AuthorizationResponseMap = {
    [key: string]: string | undefined;
};
export interface AuthChallengeResponseEvent {
    responseMap: {
        [key: string]: string | undefined;
    };
}
export type ChatInputStream = {
    configurationEvent: ConfigurationEvent;
    textEvent?: undefined;
    attachmentEvent?: undefined;
    actionExecutionEvent?: undefined;
    endOfInputEvent?: undefined;
    authChallengeResponseEvent?: undefined;
} | {
    configurationEvent?: undefined;
    textEvent: TextInputEvent;
    attachmentEvent?: undefined;
    actionExecutionEvent?: undefined;
    endOfInputEvent?: undefined;
    authChallengeResponseEvent?: undefined;
} | {
    configurationEvent?: undefined;
    textEvent?: undefined;
    attachmentEvent: AttachmentInputEvent;
    actionExecutionEvent?: undefined;
    endOfInputEvent?: undefined;
    authChallengeResponseEvent?: undefined;
} | {
    configurationEvent?: undefined;
    textEvent?: undefined;
    attachmentEvent?: undefined;
    actionExecutionEvent: ActionExecutionEvent;
    endOfInputEvent?: undefined;
    authChallengeResponseEvent?: undefined;
} | {
    configurationEvent?: undefined;
    textEvent?: undefined;
    attachmentEvent?: undefined;
    actionExecutionEvent?: undefined;
    endOfInputEvent: EndOfInputEvent;
    authChallengeResponseEvent?: undefined;
} | {
    configurationEvent?: undefined;
    textEvent?: undefined;
    attachmentEvent?: undefined;
    actionExecutionEvent?: undefined;
    endOfInputEvent?: undefined;
    authChallengeResponseEvent: AuthChallengeResponseEvent;
};
export interface ChatInput {
    applicationId: string;
    userId?: string | undefined;
    userGroups?: string[] | undefined;
    conversationId?: string | undefined;
    parentMessageId?: string | undefined;
    clientToken?: string | undefined;
    inputStream?: stream.Stream<ChatInputStream, Error, never> | undefined;
}
export type SystemMessageType = "RESPONSE" | "GROUNDED_RESPONSE" | (string & {});
export interface TextOutputEvent {
    systemMessageType?: SystemMessageType | undefined;
    conversationId?: string | undefined;
    userMessageId?: string | undefined;
    systemMessageId?: string | undefined;
    systemMessage?: string | undefined;
}
export type SnippetExcerptText = string;
export interface SnippetExcerpt {
    text?: string | undefined;
}
export type SourceAttributionMediaId = string;
export type MediaId = string;
export interface ImageSourceDetails {
    mediaId?: string | undefined;
    mediaMimeType?: string | undefined;
}
export type AudioExtractionType = "TRANSCRIPT" | "SUMMARY" | (string & {});
export interface AudioSourceDetails {
    mediaId?: string | undefined;
    mediaMimeType?: string | undefined;
    startTimeMilliseconds?: number | undefined;
    endTimeMilliseconds?: number | undefined;
    audioExtractionType?: AudioExtractionType | undefined;
}
export type VideoExtractionType = "TRANSCRIPT" | "SUMMARY" | (string & {});
export interface VideoSourceDetails {
    mediaId?: string | undefined;
    mediaMimeType?: string | undefined;
    startTimeMilliseconds?: number | undefined;
    endTimeMilliseconds?: number | undefined;
    videoExtractionType?: VideoExtractionType | undefined;
}
export type SourceDetails = {
    imageSourceDetails: ImageSourceDetails;
    audioSourceDetails?: undefined;
    videoSourceDetails?: undefined;
} | {
    imageSourceDetails?: undefined;
    audioSourceDetails: AudioSourceDetails;
    videoSourceDetails?: undefined;
} | {
    imageSourceDetails?: undefined;
    audioSourceDetails?: undefined;
    videoSourceDetails: VideoSourceDetails;
};
export interface TextSegment {
    beginOffset?: number | undefined;
    endOffset?: number | undefined;
    snippetExcerpt?: SnippetExcerpt | undefined;
    mediaId?: string | undefined;
    mediaMimeType?: string | undefined;
    sourceDetails?: SourceDetails | undefined;
}
export type TextSegmentList = TextSegment[];
export interface SourceAttribution {
    title?: string | undefined;
    snippet?: string | undefined;
    url?: string | undefined;
    citationNumber?: number | undefined;
    updatedAt?: Date | undefined;
    textMessageSegments?: TextSegment[] | undefined;
    documentId?: string | undefined;
    indexId?: string | undefined;
    datasourceId?: string | undefined;
}
export type SourceAttributions = (SourceAttribution | null)[];
export interface MetadataEvent {
    conversationId?: string | undefined;
    userMessageId?: string | undefined;
    systemMessageId?: string | undefined;
    sourceAttributions?: (SourceAttribution | null)[] | undefined;
    finalTextMessage?: string | undefined;
}
export type PluginType = "SERVICE_NOW" | "SALESFORCE" | "JIRA" | "ZENDESK" | "CUSTOM" | "QUICKSIGHT" | "SERVICENOW_NOW_PLATFORM" | "JIRA_CLOUD" | "SALESFORCE_CRM" | "ZENDESK_SUITE" | "ATLASSIAN_CONFLUENCE" | "GOOGLE_CALENDAR" | "MICROSOFT_TEAMS" | "MICROSOFT_EXCHANGE" | "PAGERDUTY_ADVANCE" | "SMARTSHEET" | "ASANA" | (string & {});
export type ActionPayloadFieldType = "STRING" | "NUMBER" | "ARRAY" | "BOOLEAN" | (string & {});
export interface ActionReviewPayloadFieldAllowedValue {
    value?: any | undefined;
    displayValue?: any | undefined;
}
export type ActionReviewPayloadFieldAllowedValues = ActionReviewPayloadFieldAllowedValue[];
export type ActionReviewPayloadFieldArrayItemJsonSchema = unknown;
export interface ActionReviewPayloadField {
    displayName?: string | undefined;
    displayOrder?: number | undefined;
    displayDescription?: string | undefined;
    type?: ActionPayloadFieldType | undefined;
    value?: any | undefined;
    allowedValues?: ActionReviewPayloadFieldAllowedValue[] | undefined;
    allowedFormat?: string | undefined;
    arrayItemJsonSchema?: any | undefined;
    required?: boolean | undefined;
}
export type ActionReviewPayload = {
    [key: string]: ActionReviewPayloadField | undefined;
};
export interface ActionReviewEvent {
    conversationId?: string | undefined;
    userMessageId?: string | undefined;
    systemMessageId?: string | undefined;
    pluginId?: string | undefined;
    pluginType?: PluginType | undefined;
    payload?: {
        [key: string]: ActionReviewPayloadField | undefined;
    } | undefined;
    payloadFieldNameSeparator?: string | undefined;
}
export type AttachmentStatus = "FAILED" | "SUCCESS" | (string & {});
export interface AttachmentOutput {
    name?: string | undefined;
    status?: AttachmentStatus | undefined;
    error?: ErrorDetail | undefined;
    attachmentId?: string | undefined;
    conversationId?: string | undefined;
}
export interface FailedAttachmentEvent {
    conversationId?: string | undefined;
    userMessageId?: string | undefined;
    systemMessageId?: string | undefined;
    attachment?: AttachmentOutput | undefined;
}
export type Url = string;
export interface AuthChallengeRequestEvent {
    authorizationUrl: string;
}
export type ChatOutputStream = {
    textEvent: TextOutputEvent;
    metadataEvent?: undefined;
    actionReviewEvent?: undefined;
    failedAttachmentEvent?: undefined;
    authChallengeRequestEvent?: undefined;
} | {
    textEvent?: undefined;
    metadataEvent: MetadataEvent;
    actionReviewEvent?: undefined;
    failedAttachmentEvent?: undefined;
    authChallengeRequestEvent?: undefined;
} | {
    textEvent?: undefined;
    metadataEvent?: undefined;
    actionReviewEvent: ActionReviewEvent;
    failedAttachmentEvent?: undefined;
    authChallengeRequestEvent?: undefined;
} | {
    textEvent?: undefined;
    metadataEvent?: undefined;
    actionReviewEvent?: undefined;
    failedAttachmentEvent: FailedAttachmentEvent;
    authChallengeRequestEvent?: undefined;
} | {
    textEvent?: undefined;
    metadataEvent?: undefined;
    actionReviewEvent?: undefined;
    failedAttachmentEvent?: undefined;
    authChallengeRequestEvent: AuthChallengeRequestEvent;
};
export interface ChatOutput {
    outputStream?: stream.Stream<ChatOutputStream, Error, never> | undefined;
}
export type AttachmentsInput = AttachmentInput[];
export interface ActionExecution {
    pluginId: string;
    payload: {
        [key: string]: ActionExecutionPayloadField | undefined;
    };
    payloadFieldNameSeparator: string;
}
export interface AuthChallengeResponse {
    responseMap: {
        [key: string]: string | undefined;
    };
}
export interface ChatSyncInput {
    applicationId: string;
    userId?: string | undefined;
    userGroups?: string[] | undefined;
    userMessage?: string | undefined;
    attachments?: AttachmentInput[] | undefined;
    actionExecution?: ActionExecution | undefined;
    authChallengeResponse?: AuthChallengeResponse | undefined;
    conversationId?: string | undefined;
    parentMessageId?: string | undefined;
    attributeFilter?: AttributeFilter | undefined;
    chatMode?: ChatMode | undefined;
    chatModeConfiguration?: ChatModeConfiguration | undefined;
    clientToken?: string | undefined;
}
export interface ActionReview {
    pluginId?: string | undefined;
    pluginType?: PluginType | undefined;
    payload?: {
        [key: string]: ActionReviewPayloadField | undefined;
    } | undefined;
    payloadFieldNameSeparator?: string | undefined;
}
export interface AuthChallengeRequest {
    authorizationUrl: string;
}
export type AttachmentsOutput = AttachmentOutput[];
export interface ChatSyncOutput {
    conversationId?: string | undefined;
    systemMessage?: string | undefined;
    systemMessageId?: string | undefined;
    userMessageId?: string | undefined;
    actionReview?: ActionReview | undefined;
    authChallengeRequest?: AuthChallengeRequest | undefined;
    sourceAttributions?: (SourceAttribution | null)[] | undefined;
    failedAttachments?: AttachmentOutput[] | undefined;
}
export interface CheckDocumentAccessRequest {
    applicationId: string;
    indexId: string;
    userId: string;
    documentId: string;
    dataSourceId?: string | undefined;
}
export interface AssociatedGroup {
    name?: string | undefined;
    type?: MembershipType | undefined;
}
export type AssociatedGroups = AssociatedGroup[];
export interface AssociatedUser {
    id?: string | undefined;
    type?: MembershipType | undefined;
}
export type AssociatedUsers = AssociatedUser[];
export interface DocumentAclUser {
    id?: string | undefined;
    type?: MembershipType | undefined;
}
export type DocumentAclUsers = DocumentAclUser[];
export interface DocumentAclGroup {
    name?: string | undefined;
    type?: MembershipType | undefined;
}
export type DocumentAclGroups = DocumentAclGroup[];
export interface DocumentAclCondition {
    memberRelation?: MemberRelation | undefined;
    users?: DocumentAclUser[] | undefined;
    groups?: DocumentAclGroup[] | undefined;
}
export type DocumentAclConditions = DocumentAclCondition[];
export interface DocumentAclMembership {
    memberRelation?: MemberRelation | undefined;
    conditions?: DocumentAclCondition[] | undefined;
}
export interface DocumentAcl {
    allowlist?: DocumentAclMembership | undefined;
    denyList?: DocumentAclMembership | undefined;
}
export interface CheckDocumentAccessResponse {
    userGroups?: AssociatedGroup[] | undefined;
    userAliases?: AssociatedUser[] | undefined;
    hasAccess?: boolean | undefined;
    documentAcl?: DocumentAcl | undefined;
}
export type WebExperienceId = string;
export type SessionDurationInMinutes = number;
export interface CreateAnonymousWebExperienceUrlRequest {
    applicationId: string;
    webExperienceId: string;
    sessionDurationInMinutes?: number | undefined;
}
export interface CreateAnonymousWebExperienceUrlResponse {
    anonymousUrl?: string | undefined;
}
export type ApplicationName = string;
export type IdentityType = "AWS_IAM_IDP_SAML" | "AWS_IAM_IDP_OIDC" | "AWS_IAM_IDC" | "AWS_QUICKSIGHT_IDP" | "ANONYMOUS" | (string & {});
export type IAMIdentityProviderArn = string;
export type InstanceArn = string;
export type ClientIdForOIDC = string;
export type ClientIdsForOIDC = string[];
export type Description = string;
export type KmsKeyId = string | redacted.Redacted<string>;
export interface EncryptionConfiguration {
    kmsKeyId?: string | redacted.Redacted<string> | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type Tags = Tag[];
export type AttachmentsControlMode = "ENABLED" | "DISABLED" | (string & {});
export interface AttachmentsConfiguration {
    attachmentsControlMode: AttachmentsControlMode;
}
export type QAppsControlMode = "ENABLED" | "DISABLED" | (string & {});
export interface QAppsConfiguration {
    qAppsControlMode: QAppsControlMode;
}
export type PersonalizationControlMode = "ENABLED" | "DISABLED" | (string & {});
export interface PersonalizationConfiguration {
    personalizationControlMode: PersonalizationControlMode;
}
export type ClientNamespace = string;
export interface QuickSightConfiguration {
    clientNamespace: string;
}
export interface CreateApplicationRequest {
    displayName: string;
    roleArn?: string | undefined;
    identityType?: IdentityType | undefined;
    iamIdentityProviderArn?: string | undefined;
    identityCenterInstanceArn?: string | undefined;
    clientIdsForOIDC?: string[] | undefined;
    description?: string | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
    attachmentsConfiguration?: AttachmentsConfiguration | undefined;
    qAppsConfiguration?: QAppsConfiguration | undefined;
    personalizationConfiguration?: PersonalizationConfiguration | undefined;
    quickSightConfiguration?: QuickSightConfiguration | undefined;
}
export type ApplicationArn = string;
export interface CreateApplicationResponse {
    applicationId?: string | undefined;
    applicationArn?: string | undefined;
}
export type DisplayName = string;
export type ResponseConfigurationType = "ALL" | (string & {});
export type Instruction = string;
export interface InstructionCollection {
    responseLength?: string | undefined;
    targetAudience?: string | undefined;
    perspective?: string | undefined;
    outputStyle?: string | undefined;
    identity?: string | undefined;
    tone?: string | undefined;
    customInstructions?: string | undefined;
    examples?: string | undefined;
}
export interface ResponseConfiguration {
    instructionCollection?: InstructionCollection | undefined;
}
export type ResponseConfigurations = {
    [key in ResponseConfigurationType]?: ResponseConfiguration | undefined;
};
export interface CreateChatResponseConfigurationRequest {
    applicationId: string;
    displayName: string;
    clientToken?: string | undefined;
    responseConfigurations: {
        [key: string]: ResponseConfiguration | undefined;
    };
    tags?: Tag[] | undefined;
}
export type ChatResponseConfigurationId = string;
export type ChatResponseConfigurationArn = string;
export interface CreateChatResponseConfigurationResponse {
    chatResponseConfigurationId: string;
    chatResponseConfigurationArn: string;
}
export interface ActionFilterConfiguration {
    documentAttributeFilter: AttributeFilter;
}
export interface ActionConfiguration {
    action: string;
    filterConfiguration?: ActionFilterConfiguration | undefined;
}
export type ActionConfigurationList = ActionConfiguration[];
export type DataAccessorName = string | redacted.Redacted<string>;
export type DataAccessorAuthenticationType = "AWS_IAM_IDC_TTI" | "AWS_IAM_IDC_AUTH_CODE" | (string & {});
export type IdcTrustedTokenIssuerArn = string;
export interface DataAccessorIdcTrustedTokenIssuerConfiguration {
    idcTrustedTokenIssuerArn: string;
}
export type DataAccessorAuthenticationConfiguration = {
    idcTrustedTokenIssuerConfiguration: DataAccessorIdcTrustedTokenIssuerConfiguration;
};
export type DataAccessorExternalId = string;
export type DataAccessorExternalIds = string[];
export interface DataAccessorAuthenticationDetail {
    authenticationType: DataAccessorAuthenticationType;
    authenticationConfiguration?: DataAccessorAuthenticationConfiguration | undefined;
    externalIds?: string[] | undefined;
}
export interface CreateDataAccessorRequest {
    applicationId: string;
    principal: string;
    actionConfigurations: ActionConfiguration[];
    clientToken?: string | undefined;
    displayName: string | redacted.Redacted<string>;
    authenticationDetail?: DataAccessorAuthenticationDetail | undefined;
    tags?: Tag[] | undefined;
}
export type DataAccessorId = string;
export type IdcApplicationArn = string;
export type DataAccessorArn = string;
export interface CreateDataAccessorResponse {
    dataAccessorId: string;
    idcApplicationArn: string;
    dataAccessorArn: string;
}
export type DataSourceName = string;
export type DataSourceConfiguration = unknown;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface DataSourceVpcConfiguration {
    subnetIds: string[];
    securityGroupIds: string[];
}
export type SyncSchedule = string;
export interface CreateDataSourceRequest {
    applicationId: string;
    indexId: string;
    displayName: string;
    configuration: any;
    vpcConfiguration?: DataSourceVpcConfiguration | undefined;
    description?: string | undefined;
    tags?: Tag[] | undefined;
    syncSchedule?: string | undefined;
    roleArn?: string | undefined;
    clientToken?: string | undefined;
    documentEnrichmentConfiguration?: DocumentEnrichmentConfiguration | undefined;
    mediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
}
export type DataSourceArn = string;
export interface CreateDataSourceResponse {
    dataSourceId?: string | undefined;
    dataSourceArn?: string | undefined;
}
export type IndexName = string;
export type IndexType = "ENTERPRISE" | "STARTER" | (string & {});
export type IndexCapacityInteger = number;
export interface IndexCapacityConfiguration {
    units?: number | undefined;
}
export interface CreateIndexRequest {
    applicationId: string;
    displayName: string;
    description?: string | undefined;
    type?: IndexType | undefined;
    tags?: Tag[] | undefined;
    capacityConfiguration?: IndexCapacityConfiguration | undefined;
    clientToken?: string | undefined;
}
export type IndexArn = string;
export interface CreateIndexResponse {
    indexId?: string | undefined;
    indexArn?: string | undefined;
}
export type PluginName = string;
export type SecretArn = string;
export interface BasicAuthConfiguration {
    secretArn: string;
    roleArn: string;
}
export interface OAuth2ClientCredentialConfiguration {
    secretArn: string;
    roleArn: string;
    authorizationUrl?: string | undefined;
    tokenUrl?: string | undefined;
}
export interface NoAuthConfiguration {
}
export interface IdcAuthConfiguration {
    idcApplicationArn: string;
    roleArn: string;
}
export type PluginAuthConfiguration = {
    basicAuthConfiguration: BasicAuthConfiguration;
    oAuth2ClientCredentialConfiguration?: undefined;
    noAuthConfiguration?: undefined;
    idcAuthConfiguration?: undefined;
} | {
    basicAuthConfiguration?: undefined;
    oAuth2ClientCredentialConfiguration: OAuth2ClientCredentialConfiguration;
    noAuthConfiguration?: undefined;
    idcAuthConfiguration?: undefined;
} | {
    basicAuthConfiguration?: undefined;
    oAuth2ClientCredentialConfiguration?: undefined;
    noAuthConfiguration: NoAuthConfiguration;
    idcAuthConfiguration?: undefined;
} | {
    basicAuthConfiguration?: undefined;
    oAuth2ClientCredentialConfiguration?: undefined;
    noAuthConfiguration?: undefined;
    idcAuthConfiguration: IdcAuthConfiguration;
};
export type PluginDescription = string;
export type APISchemaType = "OPEN_API_V3" | (string & {});
export type Payload = string | redacted.Redacted<string>;
export type APISchema = {
    payload: string | redacted.Redacted<string>;
    s3?: undefined;
} | {
    payload?: undefined;
    s3: S3;
};
export interface CustomPluginConfiguration {
    description: string;
    apiSchemaType: APISchemaType;
    apiSchema?: APISchema | undefined;
}
export interface CreatePluginRequest {
    applicationId: string;
    displayName: string;
    type: PluginType;
    authConfiguration: PluginAuthConfiguration;
    serverUrl?: string | undefined;
    customPluginConfiguration?: CustomPluginConfiguration | undefined;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export type PluginArn = string;
export type PluginBuildStatus = "READY" | "CREATE_IN_PROGRESS" | "CREATE_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export interface CreatePluginResponse {
    pluginId?: string | undefined;
    pluginArn?: string | undefined;
    buildStatus?: PluginBuildStatus | undefined;
}
export type RetrieverType = "NATIVE_INDEX" | "KENDRA_INDEX" | (string & {});
export type RetrieverName = string;
export type DocumentAttributeBoostingLevel = "NONE" | "LOW" | "MEDIUM" | "HIGH" | "VERY_HIGH" | "ONE" | "TWO" | (string & {});
export type NumberAttributeBoostingType = "PRIORITIZE_LARGER_VALUES" | "PRIORITIZE_SMALLER_VALUES" | (string & {});
export interface NumberAttributeBoostingConfiguration {
    boostingLevel: DocumentAttributeBoostingLevel;
    boostingType?: NumberAttributeBoostingType | undefined;
}
export type StringAttributeValueBoostingLevel = "LOW" | "MEDIUM" | "HIGH" | "VERY_HIGH" | "ONE" | "TWO" | "THREE" | "FOUR" | "FIVE" | (string & {});
export type StringAttributeValueBoosting = {
    [key: string]: StringAttributeValueBoostingLevel | undefined;
};
export interface StringAttributeBoostingConfiguration {
    boostingLevel: DocumentAttributeBoostingLevel;
    attributeValueBoosting?: {
        [key: string]: StringAttributeValueBoostingLevel | undefined;
    } | undefined;
}
export type BoostingDurationInSeconds = number;
export interface DateAttributeBoostingConfiguration {
    boostingLevel: DocumentAttributeBoostingLevel;
    boostingDurationInSeconds?: number | undefined;
}
export interface StringListAttributeBoostingConfiguration {
    boostingLevel: DocumentAttributeBoostingLevel;
}
export type DocumentAttributeBoostingConfiguration = {
    numberConfiguration: NumberAttributeBoostingConfiguration;
    stringConfiguration?: undefined;
    dateConfiguration?: undefined;
    stringListConfiguration?: undefined;
} | {
    numberConfiguration?: undefined;
    stringConfiguration: StringAttributeBoostingConfiguration;
    dateConfiguration?: undefined;
    stringListConfiguration?: undefined;
} | {
    numberConfiguration?: undefined;
    stringConfiguration?: undefined;
    dateConfiguration: DateAttributeBoostingConfiguration;
    stringListConfiguration?: undefined;
} | {
    numberConfiguration?: undefined;
    stringConfiguration?: undefined;
    dateConfiguration?: undefined;
    stringListConfiguration: StringListAttributeBoostingConfiguration;
};
export type DocumentAttributeBoostingOverrideMap = {
    [key: string]: DocumentAttributeBoostingConfiguration | undefined;
};
export interface NativeIndexConfiguration {
    indexId: string;
    version?: number | undefined;
    boostingOverride?: {
        [key: string]: DocumentAttributeBoostingConfiguration | undefined;
    } | undefined;
}
export type KendraIndexId = string;
export interface KendraIndexConfiguration {
    indexId: string;
}
export type RetrieverConfiguration = {
    nativeIndexConfiguration: NativeIndexConfiguration;
    kendraIndexConfiguration?: undefined;
} | {
    nativeIndexConfiguration?: undefined;
    kendraIndexConfiguration: KendraIndexConfiguration;
};
export interface CreateRetrieverRequest {
    applicationId: string;
    type: RetrieverType;
    displayName: string;
    configuration: RetrieverConfiguration;
    roleArn?: string | undefined;
    clientToken?: string | undefined;
    tags?: Tag[] | undefined;
}
export type RetrieverId = string;
export type RetrieverArn = string;
export interface CreateRetrieverResponse {
    retrieverId?: string | undefined;
    retrieverArn?: string | undefined;
}
export type UserIdentifier = string;
export type GroupIdentifier = string;
export type SubscriptionPrincipal = {
    user: string;
    group?: undefined;
} | {
    user?: undefined;
    group: string;
};
export interface CreateSubscriptionRequest {
    applicationId: string;
    principal: SubscriptionPrincipal;
    type: SubscriptionType;
    clientToken?: string | undefined;
}
export interface CreateSubscriptionResponse {
    subscriptionId?: string | undefined;
    subscriptionArn?: string | undefined;
    currentSubscription?: SubscriptionDetails | undefined;
    nextSubscription?: SubscriptionDetails | undefined;
}
export interface UserAlias {
    indexId?: string | undefined;
    dataSourceId?: string | undefined;
    userId: string;
}
export type UserAliases = UserAlias[];
export interface CreateUserRequest {
    applicationId: string;
    userId: string;
    userAliases?: UserAlias[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateUserResponse {
}
export type WebExperienceTitle = string;
export type WebExperienceSubtitle = string;
export type WebExperienceWelcomeMessage = string;
export type WebExperienceSamplePromptsControlMode = "ENABLED" | "DISABLED" | (string & {});
export type Origin = string;
export type WebExperienceOrigins = string[];
export type SamlAuthenticationUrl = string;
export interface SamlProviderConfiguration {
    authenticationUrl: string;
}
export interface OpenIDConnectProviderConfiguration {
    secretsArn: string;
    secretsRole: string;
}
export type IdentityProviderConfiguration = {
    samlConfiguration: SamlProviderConfiguration;
    openIDConnectConfiguration?: undefined;
} | {
    samlConfiguration?: undefined;
    openIDConnectConfiguration: OpenIDConnectProviderConfiguration;
};
export type BrowserExtension = string;
export type BrowserExtensionList = string[];
export interface BrowserExtensionConfiguration {
    enabledBrowserExtensions: string[];
}
export type CustomCSSUrl = string;
export type LogoUrl = string;
export type FontUrl = string;
export type FaviconUrl = string;
export interface CustomizationConfiguration {
    customCSSUrl?: string | undefined;
    logoUrl?: string | undefined;
    fontUrl?: string | undefined;
    faviconUrl?: string | undefined;
}
export interface CreateWebExperienceRequest {
    applicationId: string;
    title?: string | undefined;
    subtitle?: string | undefined;
    welcomeMessage?: string | undefined;
    samplePromptsControlMode?: WebExperienceSamplePromptsControlMode | undefined;
    origins?: string[] | undefined;
    roleArn?: string | undefined;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
    identityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    browserExtensionConfiguration?: BrowserExtensionConfiguration | undefined;
    customizationConfiguration?: CustomizationConfiguration | undefined;
}
export type WebExperienceArn = string;
export interface CreateWebExperienceResponse {
    webExperienceId?: string | undefined;
    webExperienceArn?: string | undefined;
}
export interface DeleteApplicationRequest {
    applicationId: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteAttachmentRequest {
    applicationId: string;
    conversationId: string;
    attachmentId: string;
    userId?: string | undefined;
}
export interface DeleteAttachmentResponse {
}
export interface DeleteChatControlsConfigurationRequest {
    applicationId: string;
}
export interface DeleteChatControlsConfigurationResponse {
}
export interface DeleteChatResponseConfigurationRequest {
    applicationId: string;
    chatResponseConfigurationId: string;
}
export interface DeleteChatResponseConfigurationResponse {
}
export interface DeleteConversationRequest {
    conversationId: string;
    applicationId: string;
    userId?: string | undefined;
}
export interface DeleteConversationResponse {
}
export interface DeleteDataAccessorRequest {
    applicationId: string;
    dataAccessorId: string;
}
export interface DeleteDataAccessorResponse {
}
export interface DeleteDataSourceRequest {
    applicationId: string;
    indexId: string;
    dataSourceId: string;
}
export interface DeleteDataSourceResponse {
}
export interface DeleteGroupRequest {
    applicationId: string;
    indexId: string;
    groupName: string;
    dataSourceId?: string | undefined;
}
export interface DeleteGroupResponse {
}
export interface DeleteIndexRequest {
    applicationId: string;
    indexId: string;
}
export interface DeleteIndexResponse {
}
export interface DeletePluginRequest {
    applicationId: string;
    pluginId: string;
}
export interface DeletePluginResponse {
}
export interface DeleteRetrieverRequest {
    applicationId: string;
    retrieverId: string;
}
export interface DeleteRetrieverResponse {
}
export interface DeleteUserRequest {
    applicationId: string;
    userId: string;
}
export interface DeleteUserResponse {
}
export interface DeleteWebExperienceRequest {
    applicationId: string;
    webExperienceId: string;
}
export interface DeleteWebExperienceResponse {
}
export interface DisassociatePermissionRequest {
    applicationId: string;
    statementId: string;
}
export interface DisassociatePermissionResponse {
}
export interface GetApplicationRequest {
    applicationId: string;
}
export type ApplicationStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | (string & {});
export interface AppliedAttachmentsConfiguration {
    attachmentsControlMode?: AttachmentsControlMode | undefined;
}
export type AutoSubscriptionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AutoSubscriptionConfiguration {
    autoSubscribe?: AutoSubscriptionStatus | undefined;
    defaultSubscriptionType?: SubscriptionType | undefined;
}
export interface GetApplicationResponse {
    displayName?: string | undefined;
    applicationId?: string | undefined;
    applicationArn?: string | undefined;
    identityType?: IdentityType | undefined;
    iamIdentityProviderArn?: string | undefined;
    identityCenterApplicationArn?: string | undefined;
    roleArn?: string | undefined;
    status?: ApplicationStatus | undefined;
    description?: string | undefined;
    encryptionConfiguration?: EncryptionConfiguration | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    error?: ErrorDetail | undefined;
    attachmentsConfiguration?: AppliedAttachmentsConfiguration | undefined;
    qAppsConfiguration?: QAppsConfiguration | undefined;
    personalizationConfiguration?: PersonalizationConfiguration | undefined;
    autoSubscriptionConfiguration?: AutoSubscriptionConfiguration | undefined;
    clientIdsForOIDC?: string[] | undefined;
    quickSightConfiguration?: QuickSightConfiguration | undefined;
}
export type MaxResultsIntegerForGetTopicConfigurations = number;
export type NextToken = string;
export interface GetChatControlsConfigurationRequest {
    applicationId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ResponseScope = "ENTERPRISE_CONTENT_ONLY" | "EXTENDED_KNOWLEDGE_ENABLED" | (string & {});
export type OrchestrationControl = "ENABLED" | "DISABLED" | (string & {});
export interface AppliedOrchestrationConfiguration {
    control: OrchestrationControl;
}
export type BlockedPhrase = string;
export type BlockedPhrases = string[];
export type SystemMessageOverride = string;
export interface BlockedPhrasesConfiguration {
    blockedPhrases?: string[] | undefined;
    systemMessageOverride?: string | undefined;
}
export type TopicConfigurationName = string;
export type TopicDescription = string;
export type ExampleChatMessage = string;
export type ExampleChatMessages = string[];
export type UserIds = string[];
export interface UsersAndGroups {
    userIds?: string[] | undefined;
    userGroups?: string[] | undefined;
}
export type RuleType = "CONTENT_BLOCKER_RULE" | "CONTENT_RETRIEVAL_RULE" | (string & {});
export interface ContentBlockerRule {
    systemMessageOverride?: string | undefined;
}
export interface EligibleDataSource {
    indexId?: string | undefined;
    dataSourceId?: string | undefined;
}
export type EligibleDataSources = EligibleDataSource[];
export interface ContentRetrievalRule {
    eligibleDataSources?: EligibleDataSource[] | undefined;
}
export type RuleConfiguration = {
    contentBlockerRule: ContentBlockerRule;
    contentRetrievalRule?: undefined;
} | {
    contentBlockerRule?: undefined;
    contentRetrievalRule: ContentRetrievalRule;
};
export interface Rule {
    includedUsersAndGroups?: UsersAndGroups | undefined;
    excludedUsersAndGroups?: UsersAndGroups | undefined;
    ruleType: RuleType;
    ruleConfiguration?: RuleConfiguration | undefined;
}
export type Rules = Rule[];
export interface TopicConfiguration {
    name: string;
    description?: string | undefined;
    exampleChatMessages?: string[] | undefined;
    rules: Rule[];
}
export type TopicConfigurations = TopicConfiguration[];
export type CreatorModeControl = "ENABLED" | "DISABLED" | (string & {});
export interface AppliedCreatorModeConfiguration {
    creatorModeControl: CreatorModeControl;
}
export type HallucinationReductionControl = "ENABLED" | "DISABLED" | (string & {});
export interface HallucinationReductionConfiguration {
    hallucinationReductionControl?: HallucinationReductionControl | undefined;
}
export interface GetChatControlsConfigurationResponse {
    responseScope?: ResponseScope | undefined;
    orchestrationConfiguration?: AppliedOrchestrationConfiguration | undefined;
    blockedPhrases?: BlockedPhrasesConfiguration | undefined;
    topicConfigurations?: TopicConfiguration[] | undefined;
    creatorModeConfiguration?: AppliedCreatorModeConfiguration | undefined;
    nextToken?: string | undefined;
    hallucinationReductionConfiguration?: HallucinationReductionConfiguration | undefined;
}
export interface GetChatResponseConfigurationRequest {
    applicationId: string;
    chatResponseConfigurationId: string;
}
export type ChatResponseConfigurationStatus = "CREATING" | "UPDATING" | "FAILED" | "ACTIVE" | (string & {});
export interface ChatResponseConfigurationDetail {
    responseConfigurations?: {
        [key: string]: ResponseConfiguration | undefined;
    } | undefined;
    responseConfigurationSummary?: string | undefined;
    status?: ChatResponseConfigurationStatus | undefined;
    error?: ErrorDetail | undefined;
    updatedAt?: Date | undefined;
}
export interface GetChatResponseConfigurationResponse {
    chatResponseConfigurationId?: string | undefined;
    chatResponseConfigurationArn?: string | undefined;
    displayName?: string | undefined;
    createdAt?: Date | undefined;
    inUseConfiguration?: ChatResponseConfigurationDetail | undefined;
    lastUpdateConfiguration?: ChatResponseConfigurationDetail | undefined;
}
export interface GetDataAccessorRequest {
    applicationId: string;
    dataAccessorId: string;
}
export interface GetDataAccessorResponse {
    displayName?: string | redacted.Redacted<string> | undefined;
    dataAccessorId?: string | undefined;
    dataAccessorArn?: string | undefined;
    applicationId?: string | undefined;
    idcApplicationArn?: string | undefined;
    principal?: string | undefined;
    actionConfigurations?: ActionConfiguration[] | undefined;
    authenticationDetail?: DataAccessorAuthenticationDetail | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetDataSourceRequest {
    applicationId: string;
    indexId: string;
    dataSourceId: string;
}
export type DataSourceStatus = "PENDING_CREATION" | "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | (string & {});
export interface GetDataSourceResponse {
    applicationId?: string | undefined;
    indexId?: string | undefined;
    dataSourceId?: string | undefined;
    dataSourceArn?: string | undefined;
    displayName?: string | undefined;
    type?: string | undefined;
    configuration?: any | undefined;
    vpcConfiguration?: DataSourceVpcConfiguration | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    description?: string | undefined;
    status?: DataSourceStatus | undefined;
    syncSchedule?: string | undefined;
    roleArn?: string | undefined;
    error?: ErrorDetail | undefined;
    documentEnrichmentConfiguration?: DocumentEnrichmentConfiguration | undefined;
    mediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
}
export type OutputFormat = "RAW" | "EXTRACTED" | (string & {});
export interface GetDocumentContentRequest {
    applicationId: string;
    indexId: string;
    dataSourceId?: string | undefined;
    documentId: string;
    outputFormat?: OutputFormat | undefined;
}
export interface GetDocumentContentResponse {
    presignedUrl: string;
    mimeType: string;
}
export interface GetGroupRequest {
    applicationId: string;
    indexId: string;
    groupName: string;
    dataSourceId?: string | undefined;
}
export type GroupStatus = "FAILED" | "SUCCEEDED" | "PROCESSING" | "DELETING" | "DELETED" | (string & {});
export interface GroupStatusDetail {
    status?: GroupStatus | undefined;
    lastUpdatedAt?: Date | undefined;
    errorDetail?: ErrorDetail | undefined;
}
export type GroupStatusDetails = GroupStatusDetail[];
export interface GetGroupResponse {
    status?: GroupStatusDetail | undefined;
    statusHistory?: GroupStatusDetail[] | undefined;
}
export interface GetIndexRequest {
    applicationId: string;
    indexId: string;
}
export type IndexStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "UPDATING" | (string & {});
export type DocumentMetadataConfigurationName = string;
export type AttributeType = "STRING" | "STRING_LIST" | "NUMBER" | "DATE" | (string & {});
export type Status = "ENABLED" | "DISABLED" | (string & {});
export interface DocumentAttributeConfiguration {
    name?: string | undefined;
    type?: AttributeType | undefined;
    search?: Status | undefined;
}
export type DocumentAttributeConfigurations = DocumentAttributeConfiguration[];
export type IndexedTextBytes = number;
export type IndexedTextDocument = number;
export interface TextDocumentStatistics {
    indexedTextBytes?: number | undefined;
    indexedTextDocumentCount?: number | undefined;
}
export interface IndexStatistics {
    textDocumentStatistics?: TextDocumentStatistics | undefined;
}
export interface GetIndexResponse {
    applicationId?: string | undefined;
    indexId?: string | undefined;
    displayName?: string | undefined;
    indexArn?: string | undefined;
    status?: IndexStatus | undefined;
    type?: IndexType | undefined;
    description?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    capacityConfiguration?: IndexCapacityConfiguration | undefined;
    documentAttributeConfigurations?: DocumentAttributeConfiguration[] | undefined;
    error?: ErrorDetail | undefined;
    indexStatistics?: IndexStatistics | undefined;
}
export interface GetMediaRequest {
    applicationId: string;
    conversationId: string;
    messageId: string;
    mediaId: string;
}
export interface GetMediaResponse {
    mediaBytes?: Uint8Array | undefined;
    mediaMimeType?: string | undefined;
}
export interface GetPluginRequest {
    applicationId: string;
    pluginId: string;
}
export type PluginState = "ENABLED" | "DISABLED" | (string & {});
export interface GetPluginResponse {
    applicationId?: string | undefined;
    pluginId?: string | undefined;
    displayName?: string | undefined;
    type?: PluginType | undefined;
    serverUrl?: string | undefined;
    authConfiguration?: PluginAuthConfiguration | undefined;
    customPluginConfiguration?: CustomPluginConfiguration | undefined;
    buildStatus?: PluginBuildStatus | undefined;
    pluginArn?: string | undefined;
    state?: PluginState | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetPolicyRequest {
    applicationId: string;
}
export interface GetPolicyResponse {
    policy?: string | undefined;
}
export interface GetRetrieverRequest {
    applicationId: string;
    retrieverId: string;
}
export type RetrieverStatus = "CREATING" | "ACTIVE" | "FAILED" | (string & {});
export interface GetRetrieverResponse {
    applicationId?: string | undefined;
    retrieverId?: string | undefined;
    retrieverArn?: string | undefined;
    type?: RetrieverType | undefined;
    status?: RetrieverStatus | undefined;
    displayName?: string | undefined;
    configuration?: RetrieverConfiguration | undefined;
    roleArn?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface GetUserRequest {
    applicationId: string;
    userId: string;
}
export interface GetUserResponse {
    userAliases?: UserAlias[] | undefined;
}
export interface GetWebExperienceRequest {
    applicationId: string;
    webExperienceId: string;
}
export type WebExperienceStatus = "CREATING" | "ACTIVE" | "DELETING" | "FAILED" | "PENDING_AUTH_CONFIG" | (string & {});
export type SamlMetadataXML = string;
export type SamlAttribute = string;
export interface SamlConfiguration {
    metadataXML: string;
    roleArn: string;
    userIdAttribute: string;
    userGroupAttribute?: string | undefined;
}
export type WebExperienceAuthConfiguration = {
    samlConfiguration: SamlConfiguration;
};
export interface GetWebExperienceResponse {
    applicationId?: string | undefined;
    webExperienceId?: string | undefined;
    webExperienceArn?: string | undefined;
    defaultEndpoint?: string | undefined;
    status?: WebExperienceStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    title?: string | undefined;
    subtitle?: string | undefined;
    welcomeMessage?: string | undefined;
    samplePromptsControlMode?: WebExperienceSamplePromptsControlMode | undefined;
    origins?: string[] | undefined;
    roleArn?: string | undefined;
    identityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    authenticationConfiguration?: WebExperienceAuthConfiguration | undefined;
    error?: ErrorDetail | undefined;
    browserExtensionConfiguration?: BrowserExtensionConfiguration | undefined;
    customizationConfiguration?: CustomizationConfiguration | undefined;
}
export type MaxResultsIntegerForListApplications = number;
export interface ListApplicationsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Application {
    displayName?: string | undefined;
    applicationId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    status?: ApplicationStatus | undefined;
    identityType?: IdentityType | undefined;
    quickSightConfiguration?: QuickSightConfiguration | undefined;
}
export type Applications = Application[];
export interface ListApplicationsResponse {
    nextToken?: string | undefined;
    applications?: Application[] | undefined;
}
export type MaxResultsIntegerForListAttachments = number;
export interface ListAttachmentsRequest {
    applicationId: string;
    conversationId?: string | undefined;
    userId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Attachment {
    attachmentId?: string | undefined;
    conversationId?: string | undefined;
    name?: string | undefined;
    copyFrom?: CopyFromSource | undefined;
    fileType?: string | undefined;
    fileSize?: number | undefined;
    md5chksum?: string | undefined;
    createdAt?: Date | undefined;
    status?: AttachmentStatus | undefined;
    error?: ErrorDetail | undefined;
}
export type AttachmentList = Attachment[];
export interface ListAttachmentsResponse {
    attachments?: Attachment[] | undefined;
    nextToken?: string | undefined;
}
export interface ListChatResponseConfigurationsRequest {
    applicationId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ResponseConfigurationSummary = string;
export interface ChatResponseConfiguration {
    chatResponseConfigurationId: string;
    chatResponseConfigurationArn: string;
    displayName: string;
    responseConfigurationSummary?: string | undefined;
    status: ChatResponseConfigurationStatus;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type ChatResponseConfigurations = ChatResponseConfiguration[];
export interface ListChatResponseConfigurationsResponse {
    chatResponseConfigurations?: ChatResponseConfiguration[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsIntegerForListConversations = number;
export interface ListConversationsRequest {
    applicationId: string;
    userId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ConversationTitle = string;
export interface Conversation {
    conversationId?: string | undefined;
    title?: string | undefined;
    startTime?: Date | undefined;
}
export type Conversations = Conversation[];
export interface ListConversationsResponse {
    nextToken?: string | undefined;
    conversations?: Conversation[] | undefined;
}
export type NextToken1500 = string;
export type MaxResultsIntegerForListDataAccessors = number;
export interface ListDataAccessorsRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataAccessor {
    displayName?: string | redacted.Redacted<string> | undefined;
    dataAccessorId?: string | undefined;
    dataAccessorArn?: string | undefined;
    idcApplicationArn?: string | undefined;
    principal?: string | undefined;
    authenticationDetail?: DataAccessorAuthenticationDetail | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type DataAccessors = DataAccessor[];
export interface ListDataAccessorsResponse {
    dataAccessors?: DataAccessor[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsIntegerForListDataSources = number;
export interface ListDataSourcesRequest {
    applicationId: string;
    indexId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DataSource {
    displayName?: string | undefined;
    dataSourceId?: string | undefined;
    type?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    status?: DataSourceStatus | undefined;
}
export type DataSources = DataSource[];
export interface ListDataSourcesResponse {
    dataSources?: DataSource[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsIntegerForListDataSourcesSyncJobs = number;
export type DataSourceSyncJobStatus = "FAILED" | "SUCCEEDED" | "SYNCING" | "INCOMPLETE" | "STOPPING" | "ABORTED" | "SYNCING_INDEXING" | (string & {});
export interface ListDataSourceSyncJobsRequest {
    dataSourceId: string;
    applicationId: string;
    indexId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    statusFilter?: DataSourceSyncJobStatus | undefined;
}
export type MetricValue = string;
export interface DataSourceSyncJobMetrics {
    documentsAdded?: string | undefined;
    documentsModified?: string | undefined;
    documentsDeleted?: string | undefined;
    documentsFailed?: string | undefined;
    documentsScanned?: string | undefined;
}
export interface DataSourceSyncJob {
    executionId?: string | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
    status?: DataSourceSyncJobStatus | undefined;
    error?: ErrorDetail | undefined;
    dataSourceErrorCode?: string | undefined;
    metrics?: DataSourceSyncJobMetrics | undefined;
}
export type DataSourceSyncJobs = DataSourceSyncJob[];
export interface ListDataSourceSyncJobsResponse {
    history?: DataSourceSyncJob[] | undefined;
    nextToken?: string | undefined;
}
export type DataSourceIds = string[];
export type MaxResultsIntegerForListDocuments = number;
export interface ListDocumentsRequest {
    applicationId: string;
    indexId: string;
    dataSourceIds?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type DocumentStatus = "RECEIVED" | "PROCESSING" | "INDEXED" | "UPDATED" | "FAILED" | "DELETING" | "DELETED" | "DOCUMENT_FAILED_TO_INDEX" | (string & {});
export interface DocumentDetails {
    documentId?: string | undefined;
    status?: DocumentStatus | undefined;
    error?: ErrorDetail | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type DocumentDetailList = DocumentDetails[];
export interface ListDocumentsResponse {
    documentDetailList?: DocumentDetails[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsIntegerForListGroupsRequest = number;
export interface ListGroupsRequest {
    applicationId: string;
    indexId: string;
    updatedEarlierThan: Date;
    dataSourceId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface GroupSummary {
    groupName?: string | undefined;
}
export type GroupSummaryList = GroupSummary[];
export interface ListGroupsResponse {
    nextToken?: string | undefined;
    items?: GroupSummary[] | undefined;
}
export type MaxResultsIntegerForListIndices = number;
export interface ListIndicesRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Index {
    displayName?: string | undefined;
    indexId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    status?: IndexStatus | undefined;
}
export type Indices = Index[];
export interface ListIndicesResponse {
    nextToken?: string | undefined;
    indices?: Index[] | undefined;
}
export type MaxResultsIntegerForListMessages = number;
export interface ListMessagesRequest {
    conversationId: string;
    applicationId: string;
    userId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type MessageBody = string;
export type MessageType = "USER" | "SYSTEM" | (string & {});
export interface Message {
    messageId?: string | undefined;
    body?: string | undefined;
    time?: Date | undefined;
    type?: MessageType | undefined;
    attachments?: AttachmentOutput[] | undefined;
    sourceAttribution?: (SourceAttribution | null)[] | undefined;
    actionReview?: ActionReview | undefined;
    actionExecution?: ActionExecution | undefined;
}
export type Messages = Message[];
export interface ListMessagesResponse {
    messages?: Message[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsIntegerForListPluginActions = number;
export interface ListPluginActionsRequest {
    applicationId: string;
    pluginId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ActionSummary {
    actionIdentifier?: string | undefined;
    displayName?: string | undefined;
    instructionExample?: string | undefined;
    description?: string | undefined;
}
export type Actions = ActionSummary[];
export interface ListPluginActionsResponse {
    nextToken?: string | undefined;
    items?: ActionSummary[] | undefined;
}
export type MaxResultsIntegerForListPlugins = number;
export interface ListPluginsRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Plugin {
    pluginId?: string | undefined;
    displayName?: string | undefined;
    type?: PluginType | undefined;
    serverUrl?: string | undefined;
    state?: PluginState | undefined;
    buildStatus?: PluginBuildStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type Plugins = Plugin[];
export interface ListPluginsResponse {
    nextToken?: string | undefined;
    plugins?: Plugin[] | undefined;
}
export type MaxResultsIntegerForListPluginTypeActions = number;
export interface ListPluginTypeActionsRequest {
    pluginType: PluginType;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListPluginTypeActionsResponse {
    nextToken?: string | undefined;
    items?: ActionSummary[] | undefined;
}
export type MaxResultsIntegerForListPluginTypeMetadata = number;
export interface ListPluginTypeMetadataRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type PluginTypeCategory = "Customer relationship management (CRM)" | "Project management" | "Communication" | "Productivity" | "Ticketing and incident management" | (string & {});
export interface PluginTypeMetadataSummary {
    type?: PluginType | undefined;
    category?: PluginTypeCategory | undefined;
    description?: string | undefined;
}
export type ListPluginTypeMetadataSummaries = PluginTypeMetadataSummary[];
export interface ListPluginTypeMetadataResponse {
    nextToken?: string | undefined;
    items?: PluginTypeMetadataSummary[] | undefined;
}
export type MaxResultsIntegerForListRetrieversRequest = number;
export interface ListRetrieversRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Retriever {
    applicationId?: string | undefined;
    retrieverId?: string | undefined;
    type?: RetrieverType | undefined;
    status?: RetrieverStatus | undefined;
    displayName?: string | undefined;
}
export type Retrievers = Retriever[];
export interface ListRetrieversResponse {
    retrievers?: Retriever[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResultsIntegerForListSubscriptions = number;
export interface ListSubscriptionsRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface Subscription {
    subscriptionId?: string | undefined;
    subscriptionArn?: string | undefined;
    principal?: SubscriptionPrincipal | undefined;
    currentSubscription?: SubscriptionDetails | undefined;
    nextSubscription?: SubscriptionDetails | undefined;
}
export type Subscriptions = Subscription[];
export interface ListSubscriptionsResponse {
    nextToken?: string | undefined;
    subscriptions?: Subscription[] | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    resourceARN: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export type MaxResultsIntegerForListWebExperiencesRequest = number;
export interface ListWebExperiencesRequest {
    applicationId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface WebExperience {
    webExperienceId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    defaultEndpoint?: string | undefined;
    status?: WebExperienceStatus | undefined;
}
export type WebExperiences = WebExperience[];
export interface ListWebExperiencesResponse {
    webExperiences?: WebExperience[] | undefined;
    nextToken?: string | undefined;
}
export type SystemMessageId = string;
export type MessageUsefulness = "USEFUL" | "NOT_USEFUL" | (string & {});
export type MessageUsefulnessReason = "NOT_FACTUALLY_CORRECT" | "HARMFUL_OR_UNSAFE" | "INCORRECT_OR_MISSING_SOURCES" | "NOT_HELPFUL" | "FACTUALLY_CORRECT" | "COMPLETE" | "RELEVANT_SOURCES" | "HELPFUL" | "NOT_BASED_ON_DOCUMENTS" | "NOT_COMPLETE" | "NOT_CONCISE" | "OTHER" | (string & {});
export type MessageUsefulnessComment = string;
export interface MessageUsefulnessFeedback {
    usefulness: MessageUsefulness;
    reason?: MessageUsefulnessReason | undefined;
    comment?: string | undefined;
    submittedAt: Date;
}
export interface PutFeedbackRequest {
    applicationId: string;
    userId?: string | undefined;
    conversationId: string;
    messageId: string;
    messageCopiedAt?: Date | undefined;
    messageUsefulness?: MessageUsefulnessFeedback | undefined;
}
export interface PutFeedbackResponse {
}
export interface MemberGroup {
    groupName: string;
    type?: MembershipType | undefined;
}
export type MemberGroups = MemberGroup[];
export type DataSourceUserId = string;
export interface MemberUser {
    userId: string;
    type?: MembershipType | undefined;
}
export type MemberUsers = MemberUser[];
export interface GroupMembers {
    memberGroups?: MemberGroup[] | undefined;
    memberUsers?: MemberUser[] | undefined;
    s3PathForGroupMembers?: S3 | undefined;
}
export interface PutGroupRequest {
    applicationId: string;
    indexId: string;
    groupName: string;
    dataSourceId?: string | undefined;
    type: MembershipType;
    groupMembers: GroupMembers;
    roleArn?: string | undefined;
}
export interface PutGroupResponse {
}
export type QueryText = string;
export interface RetrieverContentSource {
    retrieverId: string;
}
export type ContentSource = {
    retriever: RetrieverContentSource;
};
export type MaxResults = number;
export interface SearchRelevantContentRequest {
    applicationId: string;
    queryText: string;
    contentSource: ContentSource;
    attributeFilter?: AttributeFilter | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type ScoreConfidence = "VERY_HIGH" | "HIGH" | "MEDIUM" | "LOW" | "NOT_AVAILABLE" | (string & {});
export interface ScoreAttributes {
    scoreConfidence?: ScoreConfidence | undefined;
}
export interface RelevantContent {
    content?: string | undefined;
    documentId?: string | undefined;
    documentTitle?: string | undefined;
    documentUri?: string | undefined;
    documentAttributes?: DocumentAttribute[] | undefined;
    scoreAttributes?: ScoreAttributes | undefined;
}
export type RelevantContentList = RelevantContent[];
export interface SearchRelevantContentResponse {
    relevantContent?: RelevantContent[] | undefined;
    nextToken?: string | undefined;
}
export interface StartDataSourceSyncJobRequest {
    dataSourceId: string;
    applicationId: string;
    indexId: string;
}
export interface StartDataSourceSyncJobResponse {
    executionId?: string | undefined;
}
export interface StopDataSourceSyncJobRequest {
    dataSourceId: string;
    applicationId: string;
    indexId: string;
}
export interface StopDataSourceSyncJobResponse {
}
export interface TagResourceRequest {
    resourceARN: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceARN: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApplicationRequest {
    applicationId: string;
    identityCenterInstanceArn?: string | undefined;
    displayName?: string | undefined;
    description?: string | undefined;
    roleArn?: string | undefined;
    attachmentsConfiguration?: AttachmentsConfiguration | undefined;
    qAppsConfiguration?: QAppsConfiguration | undefined;
    personalizationConfiguration?: PersonalizationConfiguration | undefined;
    autoSubscriptionConfiguration?: AutoSubscriptionConfiguration | undefined;
}
export interface UpdateApplicationResponse {
}
export interface OrchestrationConfiguration {
    control: OrchestrationControl;
}
export interface BlockedPhrasesConfigurationUpdate {
    blockedPhrasesToCreateOrUpdate?: string[] | undefined;
    blockedPhrasesToDelete?: string[] | undefined;
    systemMessageOverride?: string | undefined;
}
export interface CreatorModeConfiguration {
    creatorModeControl: CreatorModeControl;
}
export interface UpdateChatControlsConfigurationRequest {
    applicationId: string;
    clientToken?: string | undefined;
    responseScope?: ResponseScope | undefined;
    orchestrationConfiguration?: OrchestrationConfiguration | undefined;
    blockedPhrasesConfigurationUpdate?: BlockedPhrasesConfigurationUpdate | undefined;
    topicConfigurationsToCreateOrUpdate?: TopicConfiguration[] | undefined;
    topicConfigurationsToDelete?: TopicConfiguration[] | undefined;
    creatorModeConfiguration?: CreatorModeConfiguration | undefined;
    hallucinationReductionConfiguration?: HallucinationReductionConfiguration | undefined;
}
export interface UpdateChatControlsConfigurationResponse {
}
export interface UpdateChatResponseConfigurationRequest {
    applicationId: string;
    chatResponseConfigurationId: string;
    displayName?: string | undefined;
    responseConfigurations: {
        [key: string]: ResponseConfiguration | undefined;
    };
    clientToken?: string | undefined;
}
export interface UpdateChatResponseConfigurationResponse {
}
export interface UpdateDataAccessorRequest {
    applicationId: string;
    dataAccessorId: string;
    actionConfigurations: ActionConfiguration[];
    authenticationDetail?: DataAccessorAuthenticationDetail | undefined;
    displayName?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateDataAccessorResponse {
}
export interface UpdateDataSourceRequest {
    applicationId: string;
    indexId: string;
    dataSourceId: string;
    displayName?: string | undefined;
    configuration?: any | undefined;
    vpcConfiguration?: DataSourceVpcConfiguration | undefined;
    description?: string | undefined;
    syncSchedule?: string | undefined;
    roleArn?: string | undefined;
    documentEnrichmentConfiguration?: DocumentEnrichmentConfiguration | undefined;
    mediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
}
export interface UpdateDataSourceResponse {
}
export interface UpdateIndexRequest {
    applicationId: string;
    indexId: string;
    displayName?: string | undefined;
    description?: string | undefined;
    capacityConfiguration?: IndexCapacityConfiguration | undefined;
    documentAttributeConfigurations?: DocumentAttributeConfiguration[] | undefined;
}
export interface UpdateIndexResponse {
}
export interface UpdatePluginRequest {
    applicationId: string;
    pluginId: string;
    displayName?: string | undefined;
    state?: PluginState | undefined;
    serverUrl?: string | undefined;
    customPluginConfiguration?: CustomPluginConfiguration | undefined;
    authConfiguration?: PluginAuthConfiguration | undefined;
}
export interface UpdatePluginResponse {
}
export interface UpdateRetrieverRequest {
    applicationId: string;
    retrieverId: string;
    configuration?: RetrieverConfiguration | undefined;
    displayName?: string | undefined;
    roleArn?: string | undefined;
}
export interface UpdateRetrieverResponse {
}
export interface UpdateSubscriptionRequest {
    applicationId: string;
    subscriptionId: string;
    type: SubscriptionType;
}
export interface UpdateSubscriptionResponse {
    subscriptionArn?: string | undefined;
    currentSubscription?: SubscriptionDetails | undefined;
    nextSubscription?: SubscriptionDetails | undefined;
}
export interface UpdateUserRequest {
    applicationId: string;
    userId: string;
    userAliasesToUpdate?: UserAlias[] | undefined;
    userAliasesToDelete?: UserAlias[] | undefined;
}
export interface UpdateUserResponse {
    userAliasesAdded?: UserAlias[] | undefined;
    userAliasesUpdated?: UserAlias[] | undefined;
    userAliasesDeleted?: UserAlias[] | undefined;
}
export interface UpdateWebExperienceRequest {
    applicationId: string;
    webExperienceId: string;
    roleArn?: string | undefined;
    authenticationConfiguration?: WebExperienceAuthConfiguration | undefined;
    title?: string | undefined;
    subtitle?: string | undefined;
    welcomeMessage?: string | undefined;
    samplePromptsControlMode?: WebExperienceSamplePromptsControlMode | undefined;
    identityProviderConfiguration?: IdentityProviderConfiguration | undefined;
    origins?: string[] | undefined;
    browserExtensionConfiguration?: BrowserExtensionConfiguration | undefined;
    customizationConfiguration?: CustomizationConfiguration | undefined;
}
export interface UpdateWebExperienceResponse {
}
export type ValidationExceptionReason = "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "UNKNOWN_OPERATION" | (string & {});
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFields = ValidationExceptionField[];
export type AssociatePermissionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates a permission policy for a Amazon Q Business application, allowing cross-account access for an ISV. This operation creates a new policy statement for the specified Amazon Q Business application. The policy statement defines the IAM actions that the ISV is allowed to perform on the Amazon Q Business application's resources.
 */
export declare const associatePermission: API.OperationMethod<AssociatePermissionRequest & RegionInput, AssociatePermissionResponse, AssociatePermissionError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteDocumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Asynchronously deletes one or more documents added using the `BatchPutDocument` API from an Amazon Q Business index.
 *
 * You can see the progress of the deletion, and any error messages related to the process, by using CloudWatch.
 */
export declare const batchDeleteDocument: API.OperationMethod<BatchDeleteDocumentRequest & RegionInput, BatchDeleteDocumentResponse, BatchDeleteDocumentError, Credentials | HttpClient.HttpClient>;
export type BatchPutDocumentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds one or more documents to an Amazon Q Business index.
 *
 * You use this API to:
 *
 * - ingest your structured and unstructured documents and documents stored in an Amazon S3 bucket into an Amazon Q Business index.
 *
 * - add custom attributes to documents in an Amazon Q Business index.
 *
 * - attach an access control list to the documents added to an Amazon Q Business index.
 *
 * You can see the progress of the deletion, and any error messages related to the process, by using CloudWatch.
 */
export declare const batchPutDocument: API.OperationMethod<BatchPutDocumentRequest & RegionInput, BatchPutDocumentResponse, BatchPutDocumentError, Credentials | HttpClient.HttpClient>;
export type CancelSubscriptionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Unsubscribes a user or a group from their pricing tier in an Amazon Q Business application. An unsubscribed user or group loses all Amazon Q Business feature access at the start of next month.
 */
export declare const cancelSubscription: API.OperationMethod<CancelSubscriptionRequest & RegionInput, CancelSubscriptionResponse, CancelSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ChatError = AccessDeniedException | ConflictException | ExternalResourceException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts or continues a streaming Amazon Q Business conversation.
 */
export declare const chat: API.OperationMethod<ChatInput & RegionInput, ChatOutput, ChatError, Credentials | HttpClient.HttpClient>;
export type ChatSyncError = AccessDeniedException | ConflictException | ExternalResourceException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts or continues a non-streaming Amazon Q Business conversation.
 */
export declare const chatSync: API.OperationMethod<ChatSyncInput & RegionInput, ChatSyncOutput, ChatSyncError, Credentials | HttpClient.HttpClient>;
export type CheckDocumentAccessError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Verifies if a user has access permissions for a specified document and returns the actual ACL attached to the document. Resolves user access on the document via user aliases and groups when verifying user access.
 */
export declare const checkDocumentAccess: API.OperationMethod<CheckDocumentAccessRequest & RegionInput, CheckDocumentAccessResponse, CheckDocumentAccessError, Credentials | HttpClient.HttpClient>;
export type CreateAnonymousWebExperienceUrlError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a unique URL for anonymous Amazon Q Business web experience. This URL can only be used once and must be used within 5 minutes after it's generated.
 */
export declare const createAnonymousWebExperienceUrl: API.OperationMethod<CreateAnonymousWebExperienceUrlRequest & RegionInput, CreateAnonymousWebExperienceUrlResponse, CreateAnonymousWebExperienceUrlError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q Business application.
 *
 * There are new tiers for Amazon Q Business. Not all features in Amazon Q Business Pro are also available in Amazon Q Business Lite. For information on what's included in Amazon Q Business Lite and what's included in Amazon Q Business Pro, see Amazon Q Business tiers. You must use the Amazon Q Business console to assign subscription tiers to users.
 *
 * An Amazon Q Apps service linked role will be created if it's absent in the Amazon Web Services account when `QAppsConfiguration` is enabled in the request. For more information, see Using service-linked roles for Q Apps.
 *
 * When you create an application, Amazon Q Business may securely transmit data for processing from your selected Amazon Web Services region, but within your geography. For more information, see Cross region inference in Amazon Q Business.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateChatResponseConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new chat response configuration for an Amazon Q Business application. This operation establishes a set of parameters that define how the system generates and formats responses to user queries in chat interactions.
 */
export declare const createChatResponseConfiguration: API.OperationMethod<CreateChatResponseConfigurationRequest & RegionInput, CreateChatResponseConfigurationResponse, CreateChatResponseConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateDataAccessorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new data accessor for an ISV to access data from a Amazon Q Business application. The data accessor is an entity that represents the ISV's access to the Amazon Q Business application's data. It includes the IAM role ARN for the ISV, a friendly name, and a set of action configurations that define the specific actions the ISV is allowed to perform and any associated data filters. When the data accessor is created, an IAM Identity Center application is also created to manage the ISV's identity and authentication for accessing the Amazon Q Business application.
 */
export declare const createDataAccessor: API.OperationMethod<CreateDataAccessorRequest & RegionInput, CreateDataAccessorResponse, CreateDataAccessorError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a data source connector for an Amazon Q Business application.
 *
 * `CreateDataSource` is a synchronous operation. The operation returns 200 if the data source was successfully created. Otherwise, an exception is raised.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest & RegionInput, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q Business index.
 *
 * To determine if index creation has completed, check the `Status` field returned from a call to `DescribeIndex`. The `Status` field is set to `ACTIVE` when the index is ready to use.
 *
 * Once the index is active, you can index your documents using the `BatchPutDocument` API or the `CreateDataSource` API.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest & RegionInput, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreatePluginError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q Business plugin.
 */
export declare const createPlugin: API.OperationMethod<CreatePluginRequest & RegionInput, CreatePluginResponse, CreatePluginError, Credentials | HttpClient.HttpClient>;
export type CreateRetrieverError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds a retriever to your Amazon Q Business application.
 */
export declare const createRetriever: API.OperationMethod<CreateRetrieverRequest & RegionInput, CreateRetrieverResponse, CreateRetrieverError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Subscribes an IAM Identity Center user or a group to a pricing tier for an Amazon Q Business application.
 *
 * Amazon Q Business offers two subscription tiers: `Q_LITE` and `Q_BUSINESS`. Subscription tier determines feature access for the user. For more information on subscriptions and pricing tiers, see Amazon Q Business pricing.
 *
 * For an example IAM role policy for assigning subscriptions, see Set up required permissions in the Amazon Q Business User Guide.
 */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest & RegionInput, CreateSubscriptionResponse, CreateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a universally unique identifier (UUID) mapped to a list of local user ids within an application.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type CreateWebExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an Amazon Q Business web experience.
 */
export declare const createWebExperience: API.OperationMethod<CreateWebExperienceRequest & RegionInput, CreateWebExperienceResponse, CreateWebExperienceError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q Business application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteAttachmentError = AccessDeniedException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an attachment associated with a specific Amazon Q Business conversation.
 */
export declare const deleteAttachment: API.OperationMethod<DeleteAttachmentRequest & RegionInput, DeleteAttachmentResponse, DeleteAttachmentError, Credentials | HttpClient.HttpClient>;
export type DeleteChatControlsConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes chat controls configured for an existing Amazon Q Business application.
 */
export declare const deleteChatControlsConfiguration: API.OperationMethod<DeleteChatControlsConfigurationRequest & RegionInput, DeleteChatControlsConfigurationResponse, DeleteChatControlsConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteChatResponseConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified chat response configuration from an Amazon Q Business application.
 */
export declare const deleteChatResponseConfiguration: API.OperationMethod<DeleteChatResponseConfigurationRequest & RegionInput, DeleteChatResponseConfigurationResponse, DeleteChatResponseConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteConversationError = AccessDeniedException | ConflictException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q Business web experience conversation.
 */
export declare const deleteConversation: API.OperationMethod<DeleteConversationRequest & RegionInput, DeleteConversationResponse, DeleteConversationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataAccessorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified data accessor. This operation permanently removes the data accessor and its associated IAM Identity Center application. Any access granted to the ISV through this data accessor will be revoked.
 */
export declare const deleteDataAccessor: API.OperationMethod<DeleteDataAccessorRequest & RegionInput, DeleteDataAccessorResponse, DeleteDataAccessorError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q Business data source connector. While the data source is being deleted, the `Status` field returned by a call to the `DescribeDataSource` API is set to `DELETING`.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest & RegionInput, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a group so that all users and sub groups that belong to the group can no longer access documents only available to that group. For example, after deleting the group "Summer Interns", all interns who belonged to that group no longer see intern-only documents in their chat results.
 *
 * If you want to delete, update, or replace users or sub groups of a group, you need to use the `PutGroup` operation. For example, if a user in the group "Engineering" leaves the engineering team and another user takes their place, you provide an updated list of users or sub groups that belong to the "Engineering" group when calling `PutGroup`.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q Business index.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest & RegionInput, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeletePluginError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q Business plugin.
 */
export declare const deletePlugin: API.OperationMethod<DeletePluginRequest & RegionInput, DeletePluginResponse, DeletePluginError, Credentials | HttpClient.HttpClient>;
export type DeleteRetrieverError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the retriever used by an Amazon Q Business application.
 */
export declare const deleteRetriever: API.OperationMethod<DeleteRetrieverRequest & RegionInput, DeleteRetrieverResponse, DeleteRetrieverError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a user by email id.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteWebExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an Amazon Q Business web experience.
 */
export declare const deleteWebExperience: API.OperationMethod<DeleteWebExperienceRequest & RegionInput, DeleteWebExperienceResponse, DeleteWebExperienceError, Credentials | HttpClient.HttpClient>;
export type DisassociatePermissionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a permission policy from a Amazon Q Business application, revoking the cross-account access that was previously granted to an ISV. This operation deletes the specified policy statement from the application's permission policy.
 */
export declare const disassociatePermission: API.OperationMethod<DisassociatePermissionRequest & RegionInput, DisassociatePermissionResponse, DisassociatePermissionError, Credentials | HttpClient.HttpClient>;
export type GetApplicationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an existing Amazon Q Business application.
 */
export declare const getApplication: API.OperationMethod<GetApplicationRequest & RegionInput, GetApplicationResponse, GetApplicationError, Credentials | HttpClient.HttpClient>;
export type GetChatControlsConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about chat controls configured for an existing Amazon Q Business application.
 */
export declare const getChatControlsConfiguration: API.PaginatedOperationMethod<GetChatControlsConfigurationRequest & RegionInput, GetChatControlsConfigurationResponse, GetChatControlsConfigurationError, Credentials | HttpClient.HttpClient, TopicConfiguration>;
export type GetChatResponseConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific chat response configuration from an Amazon Q Business application. This operation returns the complete configuration settings and metadata.
 */
export declare const getChatResponseConfiguration: API.OperationMethod<GetChatResponseConfigurationRequest & RegionInput, GetChatResponseConfigurationResponse, GetChatResponseConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDataAccessorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a specified data accessor. This operation returns details about the data accessor, including its display name, unique identifier, Amazon Resource Name (ARN), the associated Amazon Q Business application and IAM Identity Center application, the IAM role for the ISV, the action configurations, and the timestamps for when the data accessor was created and last updated.
 */
export declare const getDataAccessor: API.OperationMethod<GetDataAccessorRequest & RegionInput, GetDataAccessorResponse, GetDataAccessorError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an existing Amazon Q Business data source connector.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest & RegionInput, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDocumentContentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the content of a document that was ingested into Amazon Q Business. This API validates user authorization against document ACLs before returning a pre-signed URL for secure document access. You can download or view source documents referenced in chat responses through the URL.
 */
export declare const getDocumentContent: API.OperationMethod<GetDocumentContentRequest & RegionInput, GetDocumentContentResponse, GetDocumentContentError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes a group by group name.
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest & RegionInput, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an existing Amazon Q Business index.
 */
export declare const getIndex: API.OperationMethod<GetIndexRequest & RegionInput, GetIndexResponse, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetMediaError = AccessDeniedException | InternalServerException | LicenseNotFoundException | MediaTooLargeException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the image bytes corresponding to a media object. If you have implemented your own application with the Chat and ChatSync APIs, and have enabled content extraction from visual data in Amazon Q Business, you use the GetMedia API operation to download the images so you can show them in your UI with responses.
 *
 * For more information, see Extracting semantic meaning from images and visuals.
 */
export declare const getMedia: API.OperationMethod<GetMediaRequest & RegionInput, GetMediaResponse, GetMediaError, Credentials | HttpClient.HttpClient>;
export type GetPluginError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an existing Amazon Q Business plugin.
 */
export declare const getPlugin: API.OperationMethod<GetPluginRequest & RegionInput, GetPluginResponse, GetPluginError, Credentials | HttpClient.HttpClient>;
export type GetPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current permission policy for a Amazon Q Business application. The policy is returned as a JSON-formatted string and defines the IAM actions that are allowed or denied for the application's resources.
 */
export declare const getPolicy: API.OperationMethod<GetPolicyRequest & RegionInput, GetPolicyResponse, GetPolicyError, Credentials | HttpClient.HttpClient>;
export type GetRetrieverError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an existing retriever used by an Amazon Q Business application.
 */
export declare const getRetriever: API.OperationMethod<GetRetrieverRequest & RegionInput, GetRetrieverResponse, GetRetrieverError, Credentials | HttpClient.HttpClient>;
export type GetUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Describes the universally unique identifier (UUID) associated with a local user in a data source.
 */
export declare const getUser: API.OperationMethod<GetUserRequest & RegionInput, GetUserResponse, GetUserError, Credentials | HttpClient.HttpClient>;
export type GetWebExperienceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about an existing Amazon Q Business web experience.
 */
export declare const getWebExperience: API.OperationMethod<GetWebExperienceRequest & RegionInput, GetWebExperienceResponse, GetWebExperienceError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists Amazon Q Business applications.
 *
 * Amazon Q Business applications may securely transmit data for processing across Amazon Web Services Regions within your geography. For more information, see Cross region inference in Amazon Q Business.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, Application>;
export type ListAttachmentsError = AccessDeniedException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of attachments associated with an Amazon Q Business web experience or a list of attachements associated with a specific Amazon Q Business conversation.
 */
export declare const listAttachments: API.PaginatedOperationMethod<ListAttachmentsRequest & RegionInput, ListAttachmentsResponse, ListAttachmentsError, Credentials | HttpClient.HttpClient, Attachment>;
export type ListChatResponseConfigurationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of all chat response configurations available in a specified Amazon Q Business application. This operation returns summary information about each configuration to help administrators manage and select appropriate response settings.
 */
export declare const listChatResponseConfigurations: API.PaginatedOperationMethod<ListChatResponseConfigurationsRequest & RegionInput, ListChatResponseConfigurationsResponse, ListChatResponseConfigurationsError, Credentials | HttpClient.HttpClient, ChatResponseConfiguration>;
export type ListConversationsError = AccessDeniedException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists one or more Amazon Q Business conversations.
 */
export declare const listConversations: API.PaginatedOperationMethod<ListConversationsRequest & RegionInput, ListConversationsResponse, ListConversationsError, Credentials | HttpClient.HttpClient, Conversation>;
export type ListDataAccessorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the data accessors for a Amazon Q Business application. This operation returns a paginated list of data accessor summaries, including the friendly name, unique identifier, ARN, associated IAM role, and creation/update timestamps for each data accessor.
 */
export declare const listDataAccessors: API.PaginatedOperationMethod<ListDataAccessorsRequest & RegionInput, ListDataAccessorsResponse, ListDataAccessorsError, Credentials | HttpClient.HttpClient, DataAccessor>;
export type ListDataSourcesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Q Business data source connectors that you have created.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest & RegionInput, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSource>;
export type ListDataSourceSyncJobsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get information about an Amazon Q Business data source connector synchronization.
 */
export declare const listDataSourceSyncJobs: API.PaginatedOperationMethod<ListDataSourceSyncJobsRequest & RegionInput, ListDataSourceSyncJobsResponse, ListDataSourceSyncJobsError, Credentials | HttpClient.HttpClient, DataSourceSyncJob>;
export type ListDocumentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * A list of documents attached to an index.
 */
export declare const listDocuments: API.PaginatedOperationMethod<ListDocumentsRequest & RegionInput, ListDocumentsResponse, ListDocumentsError, Credentials | HttpClient.HttpClient, DocumentDetails>;
export type ListGroupsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides a list of groups that are mapped to users.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, GroupSummary>;
export type ListIndicesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Amazon Q Business indices you have created.
 */
export declare const listIndices: API.PaginatedOperationMethod<ListIndicesRequest & RegionInput, ListIndicesResponse, ListIndicesError, Credentials | HttpClient.HttpClient, Index>;
export type ListMessagesError = AccessDeniedException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of messages associated with an Amazon Q Business web experience.
 */
export declare const listMessages: API.PaginatedOperationMethod<ListMessagesRequest & RegionInput, ListMessagesResponse, ListMessagesError, Credentials | HttpClient.HttpClient, Message>;
export type ListPluginActionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured Amazon Q Business actions for a specific plugin in an Amazon Q Business application.
 */
export declare const listPluginActions: API.PaginatedOperationMethod<ListPluginActionsRequest & RegionInput, ListPluginActionsResponse, ListPluginActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListPluginsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured Amazon Q Business plugins.
 */
export declare const listPlugins: API.PaginatedOperationMethod<ListPluginsRequest & RegionInput, ListPluginsResponse, ListPluginsError, Credentials | HttpClient.HttpClient, Plugin>;
export type ListPluginTypeActionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists configured Amazon Q Business actions for any plugin type--both built-in and custom.
 */
export declare const listPluginTypeActions: API.PaginatedOperationMethod<ListPluginTypeActionsRequest & RegionInput, ListPluginTypeActionsResponse, ListPluginTypeActionsError, Credentials | HttpClient.HttpClient, ActionSummary>;
export type ListPluginTypeMetadataError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists metadata for all Amazon Q Business plugin types.
 */
export declare const listPluginTypeMetadata: API.PaginatedOperationMethod<ListPluginTypeMetadataRequest & RegionInput, ListPluginTypeMetadataResponse, ListPluginTypeMetadataError, Credentials | HttpClient.HttpClient, PluginTypeMetadataSummary>;
export type ListRetrieversError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the retriever used by an Amazon Q Business application.
 */
export declare const listRetrievers: API.PaginatedOperationMethod<ListRetrieversRequest & RegionInput, ListRetrieversResponse, ListRetrieversError, Credentials | HttpClient.HttpClient, Retriever>;
export type ListSubscriptionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all subscriptions created in an Amazon Q Business application.
 */
export declare const listSubscriptions: API.PaginatedOperationMethod<ListSubscriptionsRequest & RegionInput, ListSubscriptionsResponse, ListSubscriptionsError, Credentials | HttpClient.HttpClient, Subscription>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets a list of tags associated with a specified resource. Amazon Q Business applications and data sources can have tags associated with them.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWebExperiencesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists one or more Amazon Q Business Web Experiences.
 */
export declare const listWebExperiences: API.PaginatedOperationMethod<ListWebExperiencesRequest & RegionInput, ListWebExperiencesResponse, ListWebExperiencesError, Credentials | HttpClient.HttpClient, WebExperience>;
export type PutFeedbackError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables your end user to provide feedback on their Amazon Q Business generated chat responses.
 */
export declare const putFeedback: API.OperationMethod<PutFeedbackRequest & RegionInput, PutFeedbackResponse, PutFeedbackError, Credentials | HttpClient.HttpClient>;
export type PutGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create, or updates, a mapping of users--who have access to a document--to groups.
 *
 * You can also map sub groups to groups. For example, the group "Company Intellectual Property Teams" includes sub groups "Research" and "Engineering". These sub groups include their own list of users or people who work in these teams. Only users who work in research and engineering, and therefore belong in the intellectual property group, can see top-secret company documents in their Amazon Q Business chat results.
 *
 * There are two options for creating groups, either passing group members inline or using an S3 file via the S3PathForGroupMembers field. For inline groups, there is a limit of 1000 members per group and for provided S3 files there is a limit of 100 thousand members. When creating a group using an S3 file, you provide both an S3 file and a `RoleArn` for Amazon Q Buisness to access the file.
 */
export declare const putGroup: API.OperationMethod<PutGroupRequest & RegionInput, PutGroupResponse, PutGroupError, Credentials | HttpClient.HttpClient>;
export type SearchRelevantContentError = AccessDeniedException | InternalServerException | LicenseNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Searches for relevant content in a Amazon Q Business application based on a query. This operation takes a search query text, the Amazon Q Business application identifier, and optional filters (such as content source and maximum results) as input. It returns a list of relevant content items, where each item includes the content text, the unique document identifier, the document title, the document URI, any relevant document attributes, and score attributes indicating the confidence level of the relevance.
 */
export declare const searchRelevantContent: API.PaginatedOperationMethod<SearchRelevantContentRequest & RegionInput, SearchRelevantContentResponse, SearchRelevantContentError, Credentials | HttpClient.HttpClient, RelevantContent>;
export type StartDataSourceSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a data source connector synchronization job. If a synchronization job is already in progress, Amazon Q Business returns a `ConflictException`.
 */
export declare const startDataSourceSyncJob: API.OperationMethod<StartDataSourceSyncJobRequest & RegionInput, StartDataSourceSyncJobResponse, StartDataSourceSyncJobError, Credentials | HttpClient.HttpClient>;
export type StopDataSourceSyncJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops an Amazon Q Business data source connector synchronization job already in progress.
 */
export declare const stopDataSourceSyncJob: API.OperationMethod<StopDataSourceSyncJobRequest & RegionInput, StopDataSourceSyncJobResponse, StopDataSourceSyncJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds the specified tag to the specified Amazon Q Business application or data source resource. If the tag already exists, the existing value is replaced with the new value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag from an Amazon Q Business application or a data source.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Q Business application.
 *
 * Amazon Q Business applications may securely transmit data for processing across Amazon Web Services Regions within your geography. For more information, see Cross region inference in Amazon Q Business.
 *
 * An Amazon Q Apps service-linked role will be created if it's absent in the Amazon Web Services account when `QAppsConfiguration` is enabled in the request. For more information, see Using service-linked roles for Q Apps.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateChatControlsConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a set of chat controls configured for an existing Amazon Q Business application.
 */
export declare const updateChatControlsConfiguration: API.OperationMethod<UpdateChatControlsConfigurationRequest & RegionInput, UpdateChatControlsConfigurationResponse, UpdateChatControlsConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateChatResponseConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing chat response configuration in an Amazon Q Business application. This operation allows administrators to modify configuration settings, display name, and response parameters to refine how the system generates responses.
 */
export declare const updateChatResponseConfiguration: API.OperationMethod<UpdateChatResponseConfigurationRequest & RegionInput, UpdateChatResponseConfigurationResponse, UpdateChatResponseConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataAccessorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing data accessor. This operation allows modifying the action configurations (the allowed actions and associated filters) and the display name of the data accessor. It does not allow changing the IAM role associated with the data accessor or other core properties of the data accessor.
 */
export declare const updateDataAccessor: API.OperationMethod<UpdateDataAccessorRequest & RegionInput, UpdateDataAccessorResponse, UpdateDataAccessorError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing Amazon Q Business data source connector.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest & RegionInput, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Q Business index.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest & RegionInput, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdatePluginError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Q Business plugin.
 */
export declare const updatePlugin: API.OperationMethod<UpdatePluginRequest & RegionInput, UpdatePluginResponse, UpdatePluginError, Credentials | HttpClient.HttpClient>;
export type UpdateRetrieverError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the retriever used for your Amazon Q Business application.
 */
export declare const updateRetriever: API.OperationMethod<UpdateRetrieverRequest & RegionInput, UpdateRetrieverResponse, UpdateRetrieverError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the pricing tier for an Amazon Q Business subscription. Upgrades are instant. Downgrades apply at the start of the next month. Subscription tier determines feature access for the user. For more information on subscriptions and pricing tiers, see Amazon Q Business pricing.
 */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionRequest & RegionInput, UpdateSubscriptionResponse, UpdateSubscriptionError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a information associated with a user id.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export type UpdateWebExperienceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an Amazon Q Business web experience.
 */
export declare const updateWebExperience: API.OperationMethod<UpdateWebExperienceRequest & RegionInput, UpdateWebExperienceResponse, UpdateWebExperienceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=qbusiness.d.ts.map