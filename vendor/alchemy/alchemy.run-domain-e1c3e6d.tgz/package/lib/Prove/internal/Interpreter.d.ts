import * as Effect from "effect/Effect";
import * as Library from "./Library.ts";
import type { Loader } from "./Source.ts";
import type { Env, Eval, Module, Node, Run, Site, V } from "./Value.ts";
export interface Interpreter {
    /** The run the interpreter records choices and assumptions in. */
    readonly current: {
        run: Run;
        /**
         * Whether some inputs take the run's path and make a condition true.
         * Without it, both sides of every test are taken.
         */
        feasible?: (run: Run, condition: string) => Effect.Effect<boolean>;
    };
    /**
     * Take one side of a condition of the inputs. A side no inputs reach on
     * this path is not taken, and makes no path.
     */
    readonly branch: (condition: string) => Eval<boolean>;
    readonly evaluate: (node: Node, env: Env) => Eval<V>;
    readonly call: (fn: V, args: ReadonlyArray<V>, site: Site) => Eval<V>;
    /** The result of `yield*` on a value: an effect's result, or a request context's value. */
    readonly settle: (value: V, site: Site) => Eval<V>;
    readonly member: (value: V, key: string, site: Site) => Eval<V>;
    /** Whether a value is truthy on this path. A symbolic value splits the path. */
    readonly decide: (value: V, site: Site) => Eval<boolean>;
    /** The formula for "this value is truthy", without splitting the path. */
    readonly truth: (value: V, site: Site) => Eval<boolean | string>;
    readonly moduleEnv: (module: Module) => Env;
    /** A value used as an id: what an opaque function returned is the text it gives. */
    readonly id: (value: V) => V;
    /** What the interpreter reads, by name: the tests hold a case for each. */
    readonly surface: {
        readonly library: ReadonlyArray<string>;
        readonly strings: ReadonlyArray<string>;
        readonly arrays: ReadonlyArray<string>;
    };
    /** What a model explorer plugs in. */
    readonly hooks: Hooks;
}
export interface Hooks {
    /**
     * What `yield*` on a class gives, for the classes the caller knows: an
     * aggregate's client, a saga's, an external system's.
     */
    service: ((host: unknown, site: Site) => V | undefined) | undefined;
    /** What calling a function the prover does not read gives, for the functions the caller knows. */
    host: ((value: unknown, args: ReadonlyArray<V>, site: Site) => Eval<V> | undefined) | undefined;
    /** The request contexts provided around the code being run, by tag. */
    readonly provided: Map<unknown, V>;
    /**
     * The time the command being decided is handled at. It is what the clock
     * reads inside `decide`, and there is none anywhere else.
     */
    now: V | undefined;
    /** Models of library functions the caller adds, by `module:path`. */
    readonly models: Map<string, Library.Model>;
}
/**
 * Runs the TypeScript of `decide`, `evolve` and the invariants on symbolic
 * values. It follows calls into the code the model is written in, uses a
 * model for each library function it knows, and stops with `NotTranslated`
 * at anything else.
 */
export declare const make: (loader: Loader, run: Run) => Interpreter;
//# sourceMappingURL=Interpreter.d.ts.map