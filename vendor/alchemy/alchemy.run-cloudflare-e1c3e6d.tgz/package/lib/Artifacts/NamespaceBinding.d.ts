import type { Namespace } from "./Namespace.ts";
import { type ReadWriteNamespaceClient, type RepoClient, type RepoHandle } from "./ReadWriteNamespace.ts";
/** Wrap a runtime repo handle so each method returns an Effect. */
export declare const makeArtifactsRepoClient: (raw: RepoHandle) => RepoClient;
/**
 * Builds the full Artifacts client over the native worker binding. Each access
 * level (Read / Write / ReadWrite) returns this same object typed to its subset
 * — least-privilege by construction at the call site.
 */
export declare const makeArtifactsNamespaceClient: (env: Record<string, any>, namespace: Namespace) => ReadWriteNamespaceClient;
//# sourceMappingURL=NamespaceBinding.d.ts.map