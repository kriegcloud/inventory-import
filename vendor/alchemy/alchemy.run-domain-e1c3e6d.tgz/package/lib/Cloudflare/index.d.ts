import { type DurableObjectJurisdiction, type DurableObjectLocationHint } from "@alchemy.run/cloudflare/Workers/DurableObject";
import { type Worker } from "@alchemy.run/cloudflare/Workers/Worker";
import type * as SecureRandom from "effect/crypto/SecureRandom";
import * as Duration from "effect/Duration";
import * as Layer from "effect/Layer";
import { WorkflowEngine } from "effect/workflow";
import { type Retention } from "../DurableObjects.ts";
import { type Platform } from "../Platform.ts";
import type { Providers } from "./Providers.ts";
export type { Retention } from "../DurableObjects.ts";
export { Backfill, BackfillFailed, BackfillStillRunning } from "./Backfill.ts";
export { D1KeyStore, type D1KeyStoreOptions } from "./D1KeyStore.ts";
export { providers, Providers, type ProviderRequirements } from "./Providers.ts";
export { SecretKeyWrap } from "./SecretKeyWrap.ts";
/**
 * Host a domain model on Cloudflare Durable Objects. Every aggregate, view
 * and policy becomes a Durable Object class on the host Worker, declared
 * while the model's Layer is built, so there are no bindings to write. One
 * instance per aggregate id, per view key, and per policy and source.
 *
 * Commands to one instance run one at a time, and their events, state and
 * outbox commit together. Deliveries to views and policies are at least once
 * and in order per source, and survive restarts. Live reads over
 * `Domain.protocolWebSocket` are WebSockets to the object that owns the key,
 * pushed on every commit; the object hibernates in between.
 *
 * A view or projection added in a later deploy receives the history recorded
 * before it, and the deploy waits until it has. Every instance lists itself in
 * a directory of Durable Objects; a run of new objects reads it, fans out six
 * ways, and gives each key of the new consumer its sources' events, which the
 * key applies in timestamp order.
 *
 * ### Hosting on Cloudflare
 * The Stack that deploys the Worker registers `DomainCloudflare.providers()`
 * next to `Cloudflare.providers()`, for the backfills its deploys wait on.
 *
 * **Example:** A Worker serving an Api
 * ```typescript
 * import * as Cloudflare from "@alchemy.run/cloudflare";
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 * import { CustomerApi } from "./CustomerApi.ts";
 * import { SessionLive } from "./Session.ts";
 *
 * const BankLive = SessionLive.pipe(
 *   Layer.provideMerge(Bank.layer(BankPolicies)),
 *   Layer.provide(DomainCloudflare.layerDurableObjects()),
 * );
 *
 * export default class BankWorker extends Cloudflare.Worker<BankWorker>()(
 *   "BankWorker",
 *   { main: import.meta.url },
 *   Effect.gen(function* () {
 *     const api = yield* CustomerApi;
 *     return { fetch: api.fetch };
 *   }).pipe(Effect.provide(BankLive)),
 * ) {}
 * ```
 *
 * ### Restricting a model to a jurisdiction
 * **Example:** Every Durable Object of the model in the EU
 * ```typescript
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 *
 * const BankLive = Bank.layer(BankPolicies).pipe(
 *   Layer.provide(DomainCloudflare.layerDurableObjects({ jurisdiction: "eu" })),
 * );
 * ```
 *
 * ### Placing a model's Durable Objects
 * A Durable Object is created near the Worker that first reaches it, and
 * stays there. When the model's other dependencies sit in one region (the
 * database its projections write to, the Workers that call it), hint that
 * region instead.
 *
 * **Example:** Every new Durable Object of the model in western North America
 * ```typescript
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 *
 * const BankLive = Bank.layer(BankPolicies).pipe(
 *   Layer.provide(DomainCloudflare.layerDurableObjects({ locationHint: "wnam" })),
 * );
 * ```
 *
 * ### Hosting several models in one Worker
 * Each model gets its own Durable Object classes, named after the model
 * (`Billing.AccountAggregate`), so models that list the same aggregate never
 * share its data. A Worker deployed before Domain version 0 named a class
 * after its definition alone (`AccountAggregate`), shared by every model that
 * listed it; the next deploy renames it to the model's class with
 * `renamedFrom`, keeping its objects. When two models shared one, set
 * `legacyData: false` on the `layer` of each model that starts empty.
 *
 * **Example:** Two models that both list `Account`
 * ```typescript
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Layer from "effect/Layer";
 * import { Audit, AuditHandlers } from "./Audit.ts";
 * import { Billing, BillingHandlers } from "./Billing.ts";
 *
 * const Platform = DomainCloudflare.layerDurableObjects();
 * const BillingLive = Billing.layer(BillingHandlers).pipe(Layer.provide(Platform));
 * const AuditLive = Audit.layer(AuditHandlers).pipe(Layer.provide(Platform));
 * ```
 *
 * ### Keeping dedupe rows for a while
 * Receipts, policy delivery marks and cancelled scheduled commands exist only
 * to drop repeats. Each Durable Object deletes a few that are past their
 * window every time it commits.
 *
 * **Example:** Receipts for a year, delivery marks forever
 * ```typescript
 * import * as DomainCloudflare from "@alchemy.run/domain/Cloudflare";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankPolicies } from "./Bank.ts";
 *
 * const BankLive = Bank.layer(BankPolicies).pipe(
 *   Layer.provide(
 *     DomainCloudflare.layerDurableObjects({
 *       retention: { receipts: "365 days", deliveries: "forever" },
 *     }),
 *   ),
 * );
 * ```
 *
 * @layer
 * @provides Domain.Platform
 * @provides WorkflowEngine
 */
export declare function layerDurableObjects({ jurisdiction, locationHint, backfillTimeout, retention, }?: DurableObjectsOptions): Layer.Layer<Platform | WorkflowEngine.WorkflowEngine, never, Worker | SecureRandom.SecureRandom | Providers>;
/** Options for {@link layerDurableObjects}. */
export interface DurableObjectsOptions {
    /**
     * Create and store every Durable Object of the model (aggregates, views,
     * policies, projections, streams and saga executions) only inside this
     * jurisdiction, e.g. `"eu"`.
     *
     * A Durable Object in a jurisdiction is a different object from the one
     * with the same name outside it. Setting this on a model that already has
     * data does not move that data: the model starts empty in the
     * jurisdiction, and the old objects are left as they were. Choose it before
     * the first deploy, or migrate deliberately.
     *
     * Like a D1 database, R2 bucket or Queue declared with a jurisdiction, it is
     * enforced when deployed and not emulated in `alchemy dev`: local workerd
     * does not implement jurisdictions, so the model runs unrestricted there.
     *
     * @default undefined (no jurisdiction restriction)
     */
    readonly jurisdiction?: DurableObjectJurisdiction;
    /**
     * Create every new Durable Object of the model (aggregates, views,
     * policies, projections, streams and saga executions) near this location,
     * e.g. `"wnam"`, instead of near the Worker that first reaches it.
     *
     * It only affects objects that do not exist yet: an object stays where it
     * was created, so setting or changing the hint does not move existing
     * ones. It is a hint, as on Cloudflare: an object is created in the
     * nearest location that can host it, which may not be the hinted one.
     * Unlike `jurisdiction`, it does not change which object a name refers to.
     *
     * Not emulated in `alchemy dev`, where every object runs on this machine.
     *
     * @default undefined (each object is created near its first request)
     */
    readonly locationHint?: DurableObjectLocationHint;
    /**
     * How long a deploy waits for the backfill of the views and projections it
     * adds or rebuilds. Past it the deploy fails with `BackfillStillRunning`,
     * naming how far each one has got, while the backfill keeps running on
     * Cloudflare: the next deploy waits on it again, from where it is.
     *
     * @default "30 minutes"
     */
    readonly backfillTimeout?: Duration.Input;
    /**
     * How long each Durable Object keeps the rows that only dedupe needs:
     * command and decision receipts, policy delivery marks, and cancelled
     * scheduled commands. An object deletes a few rows past their window each
     * time it commits, so an instance stops growing with its traffic.
     * `"forever"` keeps a kind of row.
     *
     * @default { receipts: "30 days", deliveries: "7 days", cancelled: "7 days" }
     */
    readonly retention?: Retention;
}
//# sourceMappingURL=index.d.ts.map