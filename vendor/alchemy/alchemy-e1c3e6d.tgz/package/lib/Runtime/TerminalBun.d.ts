import * as Layer from "effect/Layer";
import { Terminals } from "../Terminal.ts";
/** Pseudo-terminals from Bun's built-in `Bun.spawn({ terminal })`. */
export declare const TerminalsBun: Layer.Layer<Terminals, never, never>;
//# sourceMappingURL=TerminalBun.d.ts.map