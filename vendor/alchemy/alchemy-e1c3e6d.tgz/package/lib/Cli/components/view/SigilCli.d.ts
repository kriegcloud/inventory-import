import * as Layer from "effect/Layer";
import { Interaction } from "../../../Interaction.ts";
import { Cli } from "../../../Report.ts";
export declare const sigilCli: () => Layer.Layer<Cli, never, Interaction>;
//# sourceMappingURL=SigilCli.d.ts.map