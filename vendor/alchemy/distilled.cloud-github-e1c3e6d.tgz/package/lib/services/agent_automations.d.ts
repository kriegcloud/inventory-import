import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export type CreateRepoAutomationRequestTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type CreateRepoAutomationRequestTriggersIntervalCadenceList = Array<CreateRepoAutomationRequestTriggersIntervalCadenceItem | (string & {})>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type CreateRepoAutomationRequestTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type CreateRepoAutomationRequestTriggersIntervalWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: CreateRepoAutomationRequestTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: CreateRepoAutomationRequestTriggersIntervalMinuteUtc | (number & {}) | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: CreateRepoAutomationRequestTriggersIntervalWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersIssueOpenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type CreateRepoAutomationRequestTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: CreateRepoAutomationRequestTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersIssueLabeledWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type CreateRepoAutomationRequestTriggersWorkflowRunWorkflowsList = Array<string>;
export type CreateRepoAutomationRequestTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type CreateRepoAutomationRequestTriggersWorkflowRunConclusionsList = Array<CreateRepoAutomationRequestTriggersWorkflowRunConclusionsItem | (string & {})>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: CreateRepoAutomationRequestTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: CreateRepoAutomationRequestTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersWorkflowRunWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestOpenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestSynchronizeWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestMergedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersIssueCommentWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type CreateRepoAutomationRequestTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type CreateRepoAutomationRequestTriggersPullRequestCommentCommentTypesList = Array<CreateRepoAutomationRequestTriggersPullRequestCommentCommentTypesItem | (string & {})>;
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: CreateRepoAutomationRequestTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestCommentWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type CreateRepoAutomationRequestTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: CreateRepoAutomationRequestTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersDiscussionOpenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type CreateRepoAutomationRequestTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: CreateRepoAutomationRequestTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersDiscussionUpdatedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type CreateRepoAutomationRequestTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type CreateRepoAutomationRequestTriggersDiscussionCommentCommentTypesList = Array<CreateRepoAutomationRequestTriggersDiscussionCommentCommentTypesItem | (string & {})>;
/** Discussion category names matched case-insensitively. */
export type CreateRepoAutomationRequestTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: CreateRepoAutomationRequestTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: CreateRepoAutomationRequestTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersDiscussionCommentWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type CreateRepoAutomationRequestTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: CreateRepoAutomationRequestTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersIssueAssignedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type CreateRepoAutomationRequestTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: CreateRepoAutomationRequestTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestAssignedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersSubIssueAddedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReadyForReviewWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type CreateRepoAutomationRequestTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: CreateRepoAutomationRequestTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestLabeledWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestMergeConflictWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesList = Array<CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesItem | (string & {})>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReviewSubmittedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReviewRequestedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersIssueClosedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersIssueReopenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestClosedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReopenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestConvertedToDraftWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReviewDismissedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReviewThreadResolvedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type CreateRepoAutomationRequestTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: CreateRepoAutomationRequestTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersAutomationCompletedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type CreateRepoAutomationRequestTriggersAutomationFailedAutomationIdsList = Array<string>;
export type CreateRepoAutomationRequestTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type CreateRepoAutomationRequestTriggersAutomationFailedReasonsList = Array<CreateRepoAutomationRequestTriggersAutomationFailedReasonsItem | (string & {})>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationRequestTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: CreateRepoAutomationRequestTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: CreateRepoAutomationRequestTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersAutomationFailedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface CreateRepoAutomationRequestTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersCodeScanningAlertWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface CreateRepoAutomationRequestTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersSecretScanningAlertWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationRequestTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface CreateRepoAutomationRequestTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationRequestTriggersDependabotAlertWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface CreateRepoAutomationRequestTriggers {
    interval?: CreateRepoAutomationRequestTriggersInterval | undefined;
    issue_opened?: CreateRepoAutomationRequestTriggersIssueOpened | undefined;
    issue_labeled?: CreateRepoAutomationRequestTriggersIssueLabeled | undefined;
    workflow_run?: CreateRepoAutomationRequestTriggersWorkflowRun | undefined;
    pull_request_opened?: CreateRepoAutomationRequestTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: CreateRepoAutomationRequestTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: CreateRepoAutomationRequestTriggersPullRequestMerged | undefined;
    issue_comment?: CreateRepoAutomationRequestTriggersIssueComment | undefined;
    pull_request_comment?: CreateRepoAutomationRequestTriggersPullRequestComment | undefined;
    discussion_opened?: CreateRepoAutomationRequestTriggersDiscussionOpened | undefined;
    discussion_updated?: CreateRepoAutomationRequestTriggersDiscussionUpdated | undefined;
    discussion_comment?: CreateRepoAutomationRequestTriggersDiscussionComment | undefined;
    issue_assigned?: CreateRepoAutomationRequestTriggersIssueAssigned | undefined;
    pull_request_assigned?: CreateRepoAutomationRequestTriggersPullRequestAssigned | undefined;
    sub_issue_added?: CreateRepoAutomationRequestTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: CreateRepoAutomationRequestTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: CreateRepoAutomationRequestTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: CreateRepoAutomationRequestTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: CreateRepoAutomationRequestTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: CreateRepoAutomationRequestTriggersPullRequestReviewRequested | undefined;
    issue_closed?: CreateRepoAutomationRequestTriggersIssueClosed | undefined;
    issue_reopened?: CreateRepoAutomationRequestTriggersIssueReopened | undefined;
    pull_request_closed?: CreateRepoAutomationRequestTriggersPullRequestClosed | undefined;
    pull_request_reopened?: CreateRepoAutomationRequestTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: CreateRepoAutomationRequestTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: CreateRepoAutomationRequestTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: CreateRepoAutomationRequestTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: CreateRepoAutomationRequestTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: CreateRepoAutomationRequestTriggersAutomationCompleted | undefined;
    automation_failed?: CreateRepoAutomationRequestTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: CreateRepoAutomationRequestTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: CreateRepoAutomationRequestTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: CreateRepoAutomationRequestTriggersDependabotAlert | undefined;
}
export type CreateRepoAutomationRequestReasoningEffortCase1 = "none" | "low" | "medium" | "high" | "xhigh" | "max";
/** The reasoning effort to use for sessions triggered by this automation. Omit or leave empty to use the model's default. */
export type CreateRepoAutomationRequestReasoningEffort = string | CreateRepoAutomationRequestReasoningEffortCase1;
/** The tools available to the automation. */
export type CreateRepoAutomationRequestToolsList = Array<string>;
/** The type of automation, fixed at creation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository and maintainable by anyone with write access to the repository, and its runs act as the Copilot app rather than as a person. `shared` is rejected when repository ownership is not available for the repository. Supported values: `personal`, `shared`. Defaults to `personal`. */
export type CreateRepoAutomationRequestType = "personal" | "shared";
export interface CreateRepoAutomationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The name of the automation. */
    name: string;
    /** Trigger configuration for the automation. */
    triggers?: CreateRepoAutomationRequestTriggers | undefined;
    /** The prompt for the automation. */
    prompt: string;
    /** The model to use for sessions triggered by this automation. Omit or leave empty to let the platform select the model. */
    model?: string | undefined;
    /** The reasoning effort to use for sessions triggered by this automation. Omit or leave empty to use the model's default. */
    reasoning_effort?: CreateRepoAutomationRequestReasoningEffort | undefined;
    /** The tools available to the automation. */
    tools?: CreateRepoAutomationRequestToolsList | undefined;
    /** Whether the automation should be created enabled. Defaults to true when omitted. */
    enabled?: boolean | undefined;
    /** The type of automation, fixed at creation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository and maintainable by anyone with write access to the repository, and its runs act as the Copilot app rather than as a person. `shared` is rejected when repository ownership is not available for the repository. Supported values: `personal`, `shared`. Defaults to `personal`. */
    type?: CreateRepoAutomationRequestType | (string & {}) | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. When policy validation is enabled, explicitly setting false returns 422 if effective organization or repository policy disallows read-access triggers. If omitted, defaults to false when policy permits read-access triggers, otherwise true. The actor requirement does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** When true, runs of this automation build on the session history of its previous runs, and runs of the same automation are serialized. Not tracked in revision history. Defaults to false. */
    continuous_history?: boolean | undefined;
}
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type CreateRepoAutomationResponseType = "personal" | "shared";
export type CreateRepoAutomationResponseTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type CreateRepoAutomationResponseTriggersIntervalCadenceList = Array<CreateRepoAutomationResponseTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type CreateRepoAutomationResponseTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type CreateRepoAutomationResponseTriggersIntervalWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: CreateRepoAutomationResponseTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: CreateRepoAutomationResponseTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: CreateRepoAutomationResponseTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type CreateRepoAutomationResponseTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: CreateRepoAutomationResponseTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type CreateRepoAutomationResponseTriggersWorkflowRunWorkflowsList = Array<string>;
export type CreateRepoAutomationResponseTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type CreateRepoAutomationResponseTriggersWorkflowRunConclusionsList = Array<CreateRepoAutomationResponseTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: CreateRepoAutomationResponseTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: CreateRepoAutomationResponseTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type CreateRepoAutomationResponseTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type CreateRepoAutomationResponseTriggersPullRequestCommentCommentTypesList = Array<CreateRepoAutomationResponseTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: CreateRepoAutomationResponseTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type CreateRepoAutomationResponseTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: CreateRepoAutomationResponseTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type CreateRepoAutomationResponseTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: CreateRepoAutomationResponseTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type CreateRepoAutomationResponseTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type CreateRepoAutomationResponseTriggersDiscussionCommentCommentTypesList = Array<CreateRepoAutomationResponseTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type CreateRepoAutomationResponseTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: CreateRepoAutomationResponseTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: CreateRepoAutomationResponseTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type CreateRepoAutomationResponseTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: CreateRepoAutomationResponseTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type CreateRepoAutomationResponseTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: CreateRepoAutomationResponseTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type CreateRepoAutomationResponseTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: CreateRepoAutomationResponseTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesList = Array<CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: CreateRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type CreateRepoAutomationResponseTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: CreateRepoAutomationResponseTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type CreateRepoAutomationResponseTriggersAutomationFailedAutomationIdsList = Array<string>;
export type CreateRepoAutomationResponseTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type CreateRepoAutomationResponseTriggersAutomationFailedReasonsList = Array<CreateRepoAutomationResponseTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface CreateRepoAutomationResponseTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: CreateRepoAutomationResponseTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: CreateRepoAutomationResponseTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface CreateRepoAutomationResponseTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface CreateRepoAutomationResponseTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type CreateRepoAutomationResponseTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface CreateRepoAutomationResponseTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: CreateRepoAutomationResponseTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface CreateRepoAutomationResponseTriggers {
    interval?: CreateRepoAutomationResponseTriggersInterval | undefined;
    issue_opened?: CreateRepoAutomationResponseTriggersIssueOpened | undefined;
    issue_labeled?: CreateRepoAutomationResponseTriggersIssueLabeled | undefined;
    workflow_run?: CreateRepoAutomationResponseTriggersWorkflowRun | undefined;
    pull_request_opened?: CreateRepoAutomationResponseTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: CreateRepoAutomationResponseTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: CreateRepoAutomationResponseTriggersPullRequestMerged | undefined;
    issue_comment?: CreateRepoAutomationResponseTriggersIssueComment | undefined;
    pull_request_comment?: CreateRepoAutomationResponseTriggersPullRequestComment | undefined;
    discussion_opened?: CreateRepoAutomationResponseTriggersDiscussionOpened | undefined;
    discussion_updated?: CreateRepoAutomationResponseTriggersDiscussionUpdated | undefined;
    discussion_comment?: CreateRepoAutomationResponseTriggersDiscussionComment | undefined;
    issue_assigned?: CreateRepoAutomationResponseTriggersIssueAssigned | undefined;
    pull_request_assigned?: CreateRepoAutomationResponseTriggersPullRequestAssigned | undefined;
    sub_issue_added?: CreateRepoAutomationResponseTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: CreateRepoAutomationResponseTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: CreateRepoAutomationResponseTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: CreateRepoAutomationResponseTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: CreateRepoAutomationResponseTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: CreateRepoAutomationResponseTriggersPullRequestReviewRequested | undefined;
    issue_closed?: CreateRepoAutomationResponseTriggersIssueClosed | undefined;
    issue_reopened?: CreateRepoAutomationResponseTriggersIssueReopened | undefined;
    pull_request_closed?: CreateRepoAutomationResponseTriggersPullRequestClosed | undefined;
    pull_request_reopened?: CreateRepoAutomationResponseTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: CreateRepoAutomationResponseTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: CreateRepoAutomationResponseTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: CreateRepoAutomationResponseTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: CreateRepoAutomationResponseTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: CreateRepoAutomationResponseTriggersAutomationCompleted | undefined;
    automation_failed?: CreateRepoAutomationResponseTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: CreateRepoAutomationResponseTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: CreateRepoAutomationResponseTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: CreateRepoAutomationResponseTriggersDependabotAlert | undefined;
}
/** The tools available to the automation. */
export type CreateRepoAutomationResponseToolsList = Array<string>;
/** A GitHub user */
export interface CreateRepoAutomationResponseCreatedBy {
    /** The unique identifier of the user */
    id?: number | undefined;
}
export interface CreateRepoAutomationResponse {
    /** The unique identifier of the automation. */
    id: string;
    /** The name of the automation. */
    name: string;
    /** Whether the automation is currently enabled. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: CreateRepoAutomationResponseType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** When true, runs of this automation build on the session history of its previous runs, and runs of the same automation are serialized. Not tracked in revision history. */
    continuous_history?: boolean | undefined;
    /** Trigger configuration for the automation. */
    triggers?: CreateRepoAutomationResponseTriggers | undefined;
    /** The prompt for the automation. */
    prompt: string;
    /** The tools available to the automation. */
    tools?: CreateRepoAutomationResponseToolsList | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
/** The event to trigger. Only `manual` is supported. */
export type CreateRepoAutomationTaskRequestEvent = "manual";
export interface CreateRepoAutomationTaskRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
    /** The event to trigger. Only `manual` is supported. */
    event: CreateRepoAutomationTaskRequestEvent | (string & {});
    /** Additional context for this automation run, up to 10,000 characters. Supported only when `event` is `manual`. The context supplements the automation's configured instructions. */
    context?: string | undefined;
}
export interface CreateRepoAutomationTaskResponse {
}
export interface DeleteRepoAutomationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
}
export interface DeleteRepoAutomationResponse {
}
export type EditRepoAutomationRequestReasoningEffortCase1 = "none" | "low" | "medium" | "high" | "xhigh" | "max";
/** The reasoning effort to use for sessions triggered by this automation. Omit to leave unchanged. Send an empty string to clear the override and use the model's default. */
export type EditRepoAutomationRequestReasoningEffort = string | EditRepoAutomationRequestReasoningEffortCase1;
export type EditRepoAutomationRequestTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type EditRepoAutomationRequestTriggersIntervalCadenceList = Array<EditRepoAutomationRequestTriggersIntervalCadenceItem | (string & {})>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type EditRepoAutomationRequestTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type EditRepoAutomationRequestTriggersIntervalWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: EditRepoAutomationRequestTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: EditRepoAutomationRequestTriggersIntervalMinuteUtc | (number & {}) | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: EditRepoAutomationRequestTriggersIntervalWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersIssueOpenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type EditRepoAutomationRequestTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: EditRepoAutomationRequestTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersIssueLabeledWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type EditRepoAutomationRequestTriggersWorkflowRunWorkflowsList = Array<string>;
export type EditRepoAutomationRequestTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type EditRepoAutomationRequestTriggersWorkflowRunConclusionsList = Array<EditRepoAutomationRequestTriggersWorkflowRunConclusionsItem | (string & {})>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: EditRepoAutomationRequestTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: EditRepoAutomationRequestTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersWorkflowRunWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestOpenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestSynchronizeWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestMergedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersIssueCommentWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type EditRepoAutomationRequestTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type EditRepoAutomationRequestTriggersPullRequestCommentCommentTypesList = Array<EditRepoAutomationRequestTriggersPullRequestCommentCommentTypesItem | (string & {})>;
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: EditRepoAutomationRequestTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestCommentWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type EditRepoAutomationRequestTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: EditRepoAutomationRequestTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersDiscussionOpenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type EditRepoAutomationRequestTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: EditRepoAutomationRequestTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersDiscussionUpdatedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type EditRepoAutomationRequestTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type EditRepoAutomationRequestTriggersDiscussionCommentCommentTypesList = Array<EditRepoAutomationRequestTriggersDiscussionCommentCommentTypesItem | (string & {})>;
/** Discussion category names matched case-insensitively. */
export type EditRepoAutomationRequestTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: EditRepoAutomationRequestTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: EditRepoAutomationRequestTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersDiscussionCommentWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type EditRepoAutomationRequestTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: EditRepoAutomationRequestTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersIssueAssignedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type EditRepoAutomationRequestTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: EditRepoAutomationRequestTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestAssignedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersSubIssueAddedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReadyForReviewWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type EditRepoAutomationRequestTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: EditRepoAutomationRequestTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestLabeledWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestMergeConflictWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type EditRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type EditRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesList = Array<EditRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesItem | (string & {})>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: EditRepoAutomationRequestTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReviewSubmittedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReviewRequestedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersIssueClosedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersIssueReopenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestClosedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReopenedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestConvertedToDraftWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReviewDismissedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReviewThreadResolvedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersPullRequestReviewThreadUnresolvedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type EditRepoAutomationRequestTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: EditRepoAutomationRequestTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersAutomationCompletedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type EditRepoAutomationRequestTriggersAutomationFailedAutomationIdsList = Array<string>;
export type EditRepoAutomationRequestTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type EditRepoAutomationRequestTriggersAutomationFailedReasonsList = Array<EditRepoAutomationRequestTriggersAutomationFailedReasonsItem | (string & {})>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationRequestTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: EditRepoAutomationRequestTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: EditRepoAutomationRequestTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersAutomationFailedWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface EditRepoAutomationRequestTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersCodeScanningAlertWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface EditRepoAutomationRequestTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersSecretScanningAlertWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationRequestTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface EditRepoAutomationRequestTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationRequestTriggersDependabotAlertWriteScope | (string & {}) | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface EditRepoAutomationRequestTriggers {
    interval?: EditRepoAutomationRequestTriggersInterval | undefined;
    issue_opened?: EditRepoAutomationRequestTriggersIssueOpened | undefined;
    issue_labeled?: EditRepoAutomationRequestTriggersIssueLabeled | undefined;
    workflow_run?: EditRepoAutomationRequestTriggersWorkflowRun | undefined;
    pull_request_opened?: EditRepoAutomationRequestTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: EditRepoAutomationRequestTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: EditRepoAutomationRequestTriggersPullRequestMerged | undefined;
    issue_comment?: EditRepoAutomationRequestTriggersIssueComment | undefined;
    pull_request_comment?: EditRepoAutomationRequestTriggersPullRequestComment | undefined;
    discussion_opened?: EditRepoAutomationRequestTriggersDiscussionOpened | undefined;
    discussion_updated?: EditRepoAutomationRequestTriggersDiscussionUpdated | undefined;
    discussion_comment?: EditRepoAutomationRequestTriggersDiscussionComment | undefined;
    issue_assigned?: EditRepoAutomationRequestTriggersIssueAssigned | undefined;
    pull_request_assigned?: EditRepoAutomationRequestTriggersPullRequestAssigned | undefined;
    sub_issue_added?: EditRepoAutomationRequestTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: EditRepoAutomationRequestTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: EditRepoAutomationRequestTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: EditRepoAutomationRequestTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: EditRepoAutomationRequestTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: EditRepoAutomationRequestTriggersPullRequestReviewRequested | undefined;
    issue_closed?: EditRepoAutomationRequestTriggersIssueClosed | undefined;
    issue_reopened?: EditRepoAutomationRequestTriggersIssueReopened | undefined;
    pull_request_closed?: EditRepoAutomationRequestTriggersPullRequestClosed | undefined;
    pull_request_reopened?: EditRepoAutomationRequestTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: EditRepoAutomationRequestTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: EditRepoAutomationRequestTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: EditRepoAutomationRequestTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: EditRepoAutomationRequestTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: EditRepoAutomationRequestTriggersAutomationCompleted | undefined;
    automation_failed?: EditRepoAutomationRequestTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: EditRepoAutomationRequestTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: EditRepoAutomationRequestTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: EditRepoAutomationRequestTriggersDependabotAlert | undefined;
}
/** The tools available to the automation. Send an empty array to clear all tools. */
export type EditRepoAutomationRequestToolsList = Array<string>;
export interface EditRepoAutomationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
    /** The name of the automation. */
    name?: string | undefined;
    /** Set to true to enable, false to disable. Omit to leave unchanged. */
    enabled?: boolean | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. When policy validation is enabled, explicitly setting false returns 422 if effective organization or repository policy disallows read-access triggers. The actor requirement does not apply to interval-scheduled runs, which always run as the automation owner. Omit to leave unchanged. */
    require_actor_write_permission?: boolean | undefined;
    /** When true, runs of this automation build on the session history of its previous runs, and runs of the same automation are serialized. Not tracked in revision history. Omit to leave unchanged. */
    continuous_history?: boolean | undefined;
    /** The model to use for sessions triggered by this automation. Omit to leave unchanged. Send an empty string to clear the override and let the platform select the model. */
    model?: string | undefined;
    /** The reasoning effort to use for sessions triggered by this automation. Omit to leave unchanged. Send an empty string to clear the override and use the model's default. */
    reasoning_effort?: EditRepoAutomationRequestReasoningEffort | undefined;
    /** Trigger configuration for the automation. */
    triggers?: EditRepoAutomationRequestTriggers | undefined;
    /** The prompt for the automation. */
    prompt?: string | undefined;
    /** The tools available to the automation. Send an empty array to clear all tools. */
    tools?: EditRepoAutomationRequestToolsList | undefined;
}
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type EditRepoAutomationResponseType = "personal" | "shared";
export type EditRepoAutomationResponseTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type EditRepoAutomationResponseTriggersIntervalCadenceList = Array<EditRepoAutomationResponseTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type EditRepoAutomationResponseTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type EditRepoAutomationResponseTriggersIntervalWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: EditRepoAutomationResponseTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: EditRepoAutomationResponseTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: EditRepoAutomationResponseTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type EditRepoAutomationResponseTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: EditRepoAutomationResponseTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type EditRepoAutomationResponseTriggersWorkflowRunWorkflowsList = Array<string>;
export type EditRepoAutomationResponseTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type EditRepoAutomationResponseTriggersWorkflowRunConclusionsList = Array<EditRepoAutomationResponseTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: EditRepoAutomationResponseTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: EditRepoAutomationResponseTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type EditRepoAutomationResponseTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type EditRepoAutomationResponseTriggersPullRequestCommentCommentTypesList = Array<EditRepoAutomationResponseTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: EditRepoAutomationResponseTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type EditRepoAutomationResponseTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: EditRepoAutomationResponseTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type EditRepoAutomationResponseTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: EditRepoAutomationResponseTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type EditRepoAutomationResponseTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type EditRepoAutomationResponseTriggersDiscussionCommentCommentTypesList = Array<EditRepoAutomationResponseTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type EditRepoAutomationResponseTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: EditRepoAutomationResponseTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: EditRepoAutomationResponseTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type EditRepoAutomationResponseTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: EditRepoAutomationResponseTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type EditRepoAutomationResponseTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: EditRepoAutomationResponseTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type EditRepoAutomationResponseTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: EditRepoAutomationResponseTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type EditRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type EditRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesList = Array<EditRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: EditRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type EditRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: EditRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type EditRepoAutomationResponseTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: EditRepoAutomationResponseTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type EditRepoAutomationResponseTriggersAutomationFailedAutomationIdsList = Array<string>;
export type EditRepoAutomationResponseTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type EditRepoAutomationResponseTriggersAutomationFailedReasonsList = Array<EditRepoAutomationResponseTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface EditRepoAutomationResponseTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: EditRepoAutomationResponseTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: EditRepoAutomationResponseTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface EditRepoAutomationResponseTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface EditRepoAutomationResponseTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type EditRepoAutomationResponseTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface EditRepoAutomationResponseTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: EditRepoAutomationResponseTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface EditRepoAutomationResponseTriggers {
    interval?: EditRepoAutomationResponseTriggersInterval | undefined;
    issue_opened?: EditRepoAutomationResponseTriggersIssueOpened | undefined;
    issue_labeled?: EditRepoAutomationResponseTriggersIssueLabeled | undefined;
    workflow_run?: EditRepoAutomationResponseTriggersWorkflowRun | undefined;
    pull_request_opened?: EditRepoAutomationResponseTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: EditRepoAutomationResponseTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: EditRepoAutomationResponseTriggersPullRequestMerged | undefined;
    issue_comment?: EditRepoAutomationResponseTriggersIssueComment | undefined;
    pull_request_comment?: EditRepoAutomationResponseTriggersPullRequestComment | undefined;
    discussion_opened?: EditRepoAutomationResponseTriggersDiscussionOpened | undefined;
    discussion_updated?: EditRepoAutomationResponseTriggersDiscussionUpdated | undefined;
    discussion_comment?: EditRepoAutomationResponseTriggersDiscussionComment | undefined;
    issue_assigned?: EditRepoAutomationResponseTriggersIssueAssigned | undefined;
    pull_request_assigned?: EditRepoAutomationResponseTriggersPullRequestAssigned | undefined;
    sub_issue_added?: EditRepoAutomationResponseTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: EditRepoAutomationResponseTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: EditRepoAutomationResponseTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: EditRepoAutomationResponseTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: EditRepoAutomationResponseTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: EditRepoAutomationResponseTriggersPullRequestReviewRequested | undefined;
    issue_closed?: EditRepoAutomationResponseTriggersIssueClosed | undefined;
    issue_reopened?: EditRepoAutomationResponseTriggersIssueReopened | undefined;
    pull_request_closed?: EditRepoAutomationResponseTriggersPullRequestClosed | undefined;
    pull_request_reopened?: EditRepoAutomationResponseTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: EditRepoAutomationResponseTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: EditRepoAutomationResponseTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: EditRepoAutomationResponseTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: EditRepoAutomationResponseTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: EditRepoAutomationResponseTriggersAutomationCompleted | undefined;
    automation_failed?: EditRepoAutomationResponseTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: EditRepoAutomationResponseTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: EditRepoAutomationResponseTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: EditRepoAutomationResponseTriggersDependabotAlert | undefined;
}
/** The tools available to the automation. */
export type EditRepoAutomationResponseToolsList = Array<string>;
/** A GitHub user */
export type EditRepoAutomationResponseCreatedBy = CreateRepoAutomationResponseCreatedBy;
export interface EditRepoAutomationResponse {
    /** The unique identifier of the automation. */
    id: string;
    /** The name of the automation. */
    name: string;
    /** Whether the automation is currently enabled. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: EditRepoAutomationResponseType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** When true, runs of this automation build on the session history of its previous runs, and runs of the same automation are serialized. Not tracked in revision history. */
    continuous_history?: boolean | undefined;
    /** Trigger configuration for the automation. */
    triggers?: EditRepoAutomationResponseTriggers | undefined;
    /** The prompt for the automation. */
    prompt: string;
    /** The tools available to the automation. */
    tools?: EditRepoAutomationResponseToolsList | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
export interface GetAutomationRevisionRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
    /** The unique identifier of the automation revision. */
    revision_id: string;
}
/** The kind of change recorded by the revision. */
export type GetAutomationRevisionResponseChangeType = "created" | "edited" | "enabled" | "disabled" | "deleted" | "rolled_back" | "unknown";
/** A GitHub user */
export type GetAutomationRevisionResponseCreator = CreateRepoAutomationResponseCreatedBy;
/** A GitHub user */
export type GetAutomationRevisionResponseEditor = CreateRepoAutomationResponseCreatedBy;
/** The kind of actor that made the change. */
export type GetAutomationRevisionResponseEditorType = "user" | "system" | "unknown";
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type GetAutomationRevisionResponseSnapshotType = "personal" | "shared";
export type GetAutomationRevisionResponseSnapshotTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type GetAutomationRevisionResponseSnapshotTriggersIntervalCadenceList = Array<GetAutomationRevisionResponseSnapshotTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type GetAutomationRevisionResponseSnapshotTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type GetAutomationRevisionResponseSnapshotTriggersIntervalWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: GetAutomationRevisionResponseSnapshotTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: GetAutomationRevisionResponseSnapshotTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: GetAutomationRevisionResponseSnapshotTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type GetAutomationRevisionResponseSnapshotTriggersWorkflowRunWorkflowsList = Array<string>;
export type GetAutomationRevisionResponseSnapshotTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type GetAutomationRevisionResponseSnapshotTriggersWorkflowRunConclusionsList = Array<GetAutomationRevisionResponseSnapshotTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: GetAutomationRevisionResponseSnapshotTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: GetAutomationRevisionResponseSnapshotTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentCommentTypesList = Array<GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: GetAutomationRevisionResponseSnapshotTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: GetAutomationRevisionResponseSnapshotTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentCommentTypesList = Array<GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: GetAutomationRevisionResponseSnapshotTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: GetAutomationRevisionResponseSnapshotTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedStatesList = Array<GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type GetAutomationRevisionResponseSnapshotTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: GetAutomationRevisionResponseSnapshotTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type GetAutomationRevisionResponseSnapshotTriggersAutomationFailedAutomationIdsList = Array<string>;
export type GetAutomationRevisionResponseSnapshotTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type GetAutomationRevisionResponseSnapshotTriggersAutomationFailedReasonsList = Array<GetAutomationRevisionResponseSnapshotTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface GetAutomationRevisionResponseSnapshotTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: GetAutomationRevisionResponseSnapshotTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: GetAutomationRevisionResponseSnapshotTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface GetAutomationRevisionResponseSnapshotTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface GetAutomationRevisionResponseSnapshotTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetAutomationRevisionResponseSnapshotTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface GetAutomationRevisionResponseSnapshotTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetAutomationRevisionResponseSnapshotTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface GetAutomationRevisionResponseSnapshotTriggers {
    interval?: GetAutomationRevisionResponseSnapshotTriggersInterval | undefined;
    issue_opened?: GetAutomationRevisionResponseSnapshotTriggersIssueOpened | undefined;
    issue_labeled?: GetAutomationRevisionResponseSnapshotTriggersIssueLabeled | undefined;
    workflow_run?: GetAutomationRevisionResponseSnapshotTriggersWorkflowRun | undefined;
    pull_request_opened?: GetAutomationRevisionResponseSnapshotTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: GetAutomationRevisionResponseSnapshotTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: GetAutomationRevisionResponseSnapshotTriggersPullRequestMerged | undefined;
    issue_comment?: GetAutomationRevisionResponseSnapshotTriggersIssueComment | undefined;
    pull_request_comment?: GetAutomationRevisionResponseSnapshotTriggersPullRequestComment | undefined;
    discussion_opened?: GetAutomationRevisionResponseSnapshotTriggersDiscussionOpened | undefined;
    discussion_updated?: GetAutomationRevisionResponseSnapshotTriggersDiscussionUpdated | undefined;
    discussion_comment?: GetAutomationRevisionResponseSnapshotTriggersDiscussionComment | undefined;
    issue_assigned?: GetAutomationRevisionResponseSnapshotTriggersIssueAssigned | undefined;
    pull_request_assigned?: GetAutomationRevisionResponseSnapshotTriggersPullRequestAssigned | undefined;
    sub_issue_added?: GetAutomationRevisionResponseSnapshotTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: GetAutomationRevisionResponseSnapshotTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: GetAutomationRevisionResponseSnapshotTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewRequested | undefined;
    issue_closed?: GetAutomationRevisionResponseSnapshotTriggersIssueClosed | undefined;
    issue_reopened?: GetAutomationRevisionResponseSnapshotTriggersIssueReopened | undefined;
    pull_request_closed?: GetAutomationRevisionResponseSnapshotTriggersPullRequestClosed | undefined;
    pull_request_reopened?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: GetAutomationRevisionResponseSnapshotTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: GetAutomationRevisionResponseSnapshotTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: GetAutomationRevisionResponseSnapshotTriggersAutomationCompleted | undefined;
    automation_failed?: GetAutomationRevisionResponseSnapshotTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: GetAutomationRevisionResponseSnapshotTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: GetAutomationRevisionResponseSnapshotTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: GetAutomationRevisionResponseSnapshotTriggersDependabotAlert | undefined;
}
/** The tools available to the automation. */
export type GetAutomationRevisionResponseSnapshotToolsList = Array<string>;
/** A GitHub user */
export type GetAutomationRevisionResponseSnapshotCreatedBy = CreateRepoAutomationResponseCreatedBy;
/** The automation's public detail representation after the change, including its enabled state at configuration-save time, not its current lifecycle state. Legacy deleted revisions are identified by `change_type`. */
export interface GetAutomationRevisionResponseSnapshot {
    /** The unique identifier of the automation. */
    id: string;
    /** The name of the automation. */
    name: string;
    /** Whether the automation was enabled when this configuration was saved. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: GetAutomationRevisionResponseSnapshotType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** Trigger configuration for the automation. */
    triggers?: GetAutomationRevisionResponseSnapshotTriggers | undefined;
    /** The prompt for the automation. */
    prompt: string;
    /** The tools available to the automation. */
    tools?: GetAutomationRevisionResponseSnapshotToolsList | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
export interface GetAutomationRevisionResponse {
    /** The unique identifier of this revision. */
    id: string;
    /** The automation this revision belongs to. */
    automation_id: string;
    /** Position of this revision in the automation's history, starting at 1. */
    revision_number: number;
    /** The kind of change recorded by the revision. */
    change_type: GetAutomationRevisionResponseChangeType;
    /** The automation's original creator. Omitted when not recorded. */
    creator?: CreateRepoAutomationResponseCreatedBy | undefined;
    /** The person who made this change. Omitted for system changes and legacy records. */
    editor?: CreateRepoAutomationResponseCreatedBy | undefined;
    /** The kind of actor that made the change. */
    editor_type?: GetAutomationRevisionResponseEditorType | undefined;
    /** When the change was applied. */
    changed_at: string;
    /** The revision a rollback restored. Present only when `change_type` is `rolled_back`. */
    restored_from_revision_id?: string | undefined;
    /** The automation's public detail representation after the change, including its enabled state at configuration-save time, not its current lifecycle state. Legacy deleted revisions are identified by `change_type`. */
    snapshot?: GetAutomationRevisionResponseSnapshot | undefined;
}
export interface GetRepoAutomationRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
}
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type GetRepoAutomationResponseType = "personal" | "shared";
export type GetRepoAutomationResponseTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type GetRepoAutomationResponseTriggersIntervalCadenceList = Array<GetRepoAutomationResponseTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type GetRepoAutomationResponseTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type GetRepoAutomationResponseTriggersIntervalWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: GetRepoAutomationResponseTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: GetRepoAutomationResponseTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: GetRepoAutomationResponseTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type GetRepoAutomationResponseTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: GetRepoAutomationResponseTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type GetRepoAutomationResponseTriggersWorkflowRunWorkflowsList = Array<string>;
export type GetRepoAutomationResponseTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type GetRepoAutomationResponseTriggersWorkflowRunConclusionsList = Array<GetRepoAutomationResponseTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: GetRepoAutomationResponseTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: GetRepoAutomationResponseTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type GetRepoAutomationResponseTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type GetRepoAutomationResponseTriggersPullRequestCommentCommentTypesList = Array<GetRepoAutomationResponseTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: GetRepoAutomationResponseTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type GetRepoAutomationResponseTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: GetRepoAutomationResponseTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type GetRepoAutomationResponseTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: GetRepoAutomationResponseTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type GetRepoAutomationResponseTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type GetRepoAutomationResponseTriggersDiscussionCommentCommentTypesList = Array<GetRepoAutomationResponseTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type GetRepoAutomationResponseTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: GetRepoAutomationResponseTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: GetRepoAutomationResponseTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type GetRepoAutomationResponseTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: GetRepoAutomationResponseTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type GetRepoAutomationResponseTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: GetRepoAutomationResponseTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type GetRepoAutomationResponseTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: GetRepoAutomationResponseTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type GetRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type GetRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesList = Array<GetRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: GetRepoAutomationResponseTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type GetRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: GetRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type GetRepoAutomationResponseTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: GetRepoAutomationResponseTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type GetRepoAutomationResponseTriggersAutomationFailedAutomationIdsList = Array<string>;
export type GetRepoAutomationResponseTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type GetRepoAutomationResponseTriggersAutomationFailedReasonsList = Array<GetRepoAutomationResponseTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface GetRepoAutomationResponseTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: GetRepoAutomationResponseTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: GetRepoAutomationResponseTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface GetRepoAutomationResponseTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface GetRepoAutomationResponseTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type GetRepoAutomationResponseTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface GetRepoAutomationResponseTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: GetRepoAutomationResponseTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface GetRepoAutomationResponseTriggers {
    interval?: GetRepoAutomationResponseTriggersInterval | undefined;
    issue_opened?: GetRepoAutomationResponseTriggersIssueOpened | undefined;
    issue_labeled?: GetRepoAutomationResponseTriggersIssueLabeled | undefined;
    workflow_run?: GetRepoAutomationResponseTriggersWorkflowRun | undefined;
    pull_request_opened?: GetRepoAutomationResponseTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: GetRepoAutomationResponseTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: GetRepoAutomationResponseTriggersPullRequestMerged | undefined;
    issue_comment?: GetRepoAutomationResponseTriggersIssueComment | undefined;
    pull_request_comment?: GetRepoAutomationResponseTriggersPullRequestComment | undefined;
    discussion_opened?: GetRepoAutomationResponseTriggersDiscussionOpened | undefined;
    discussion_updated?: GetRepoAutomationResponseTriggersDiscussionUpdated | undefined;
    discussion_comment?: GetRepoAutomationResponseTriggersDiscussionComment | undefined;
    issue_assigned?: GetRepoAutomationResponseTriggersIssueAssigned | undefined;
    pull_request_assigned?: GetRepoAutomationResponseTriggersPullRequestAssigned | undefined;
    sub_issue_added?: GetRepoAutomationResponseTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: GetRepoAutomationResponseTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: GetRepoAutomationResponseTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: GetRepoAutomationResponseTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: GetRepoAutomationResponseTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: GetRepoAutomationResponseTriggersPullRequestReviewRequested | undefined;
    issue_closed?: GetRepoAutomationResponseTriggersIssueClosed | undefined;
    issue_reopened?: GetRepoAutomationResponseTriggersIssueReopened | undefined;
    pull_request_closed?: GetRepoAutomationResponseTriggersPullRequestClosed | undefined;
    pull_request_reopened?: GetRepoAutomationResponseTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: GetRepoAutomationResponseTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: GetRepoAutomationResponseTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: GetRepoAutomationResponseTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: GetRepoAutomationResponseTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: GetRepoAutomationResponseTriggersAutomationCompleted | undefined;
    automation_failed?: GetRepoAutomationResponseTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: GetRepoAutomationResponseTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: GetRepoAutomationResponseTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: GetRepoAutomationResponseTriggersDependabotAlert | undefined;
}
/** The tools available to the automation. */
export type GetRepoAutomationResponseToolsList = Array<string>;
/** A GitHub user */
export type GetRepoAutomationResponseCreatedBy = CreateRepoAutomationResponseCreatedBy;
export interface GetRepoAutomationResponse {
    /** The unique identifier of the automation. */
    id: string;
    /** The name of the automation. */
    name: string;
    /** Whether the automation is currently enabled. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: GetRepoAutomationResponseType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** When true, runs of this automation build on the session history of its previous runs, and runs of the same automation are serialized. Not tracked in revision history. */
    continuous_history?: boolean | undefined;
    /** Trigger configuration for the automation. */
    triggers?: GetRepoAutomationResponseTriggers | undefined;
    /** The prompt for the automation. */
    prompt: string;
    /** The tools available to the automation. */
    tools?: GetRepoAutomationResponseToolsList | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
export interface ListAutomationRevisionsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
    /** Opaque cursor identifying where to continue reading revision history, taken from the `next` link of a previous response. Omit to start from the most recent revision. */
    cursor?: string | undefined;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
}
/** The kind of change recorded by the revision. */
export type ListAutomationRevisionsResponseRevisionsItemChangeType = "created" | "edited" | "enabled" | "disabled" | "deleted" | "rolled_back" | "unknown";
/** A GitHub user */
export type ListAutomationRevisionsResponseRevisionsItemCreator = CreateRepoAutomationResponseCreatedBy;
/** A GitHub user */
export type ListAutomationRevisionsResponseRevisionsItemEditor = CreateRepoAutomationResponseCreatedBy;
/** The kind of actor that made the change. */
export type ListAutomationRevisionsResponseRevisionsItemEditorType = "user" | "system" | "unknown";
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotType = "personal" | "shared";
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalCadenceList = Array<ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunWorkflowsList = Array<string>;
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunConclusionsList = Array<ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentCommentTypesList = Array<ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentCommentTypesList = Array<ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedStatesList = Array<ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedAutomationIdsList = Array<string>;
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedReasonsList = Array<ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface ListAutomationRevisionsResponseRevisionsItemSnapshotTriggers {
    interval?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersInterval | undefined;
    issue_opened?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueOpened | undefined;
    issue_labeled?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueLabeled | undefined;
    workflow_run?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersWorkflowRun | undefined;
    pull_request_opened?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMerged | undefined;
    issue_comment?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueComment | undefined;
    pull_request_comment?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestComment | undefined;
    discussion_opened?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionOpened | undefined;
    discussion_updated?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionUpdated | undefined;
    discussion_comment?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDiscussionComment | undefined;
    issue_assigned?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueAssigned | undefined;
    pull_request_assigned?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestAssigned | undefined;
    sub_issue_added?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewRequested | undefined;
    issue_closed?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueClosed | undefined;
    issue_reopened?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersIssueReopened | undefined;
    pull_request_closed?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestClosed | undefined;
    pull_request_reopened?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationCompleted | undefined;
    automation_failed?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggersDependabotAlert | undefined;
}
/** The tools available to the automation. */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotToolsList = Array<string>;
/** A GitHub user */
export type ListAutomationRevisionsResponseRevisionsItemSnapshotCreatedBy = CreateRepoAutomationResponseCreatedBy;
/** The automation's public detail representation after the change, including its enabled state at configuration-save time, not its current lifecycle state. Legacy deleted revisions are identified by `change_type`. */
export interface ListAutomationRevisionsResponseRevisionsItemSnapshot {
    /** The unique identifier of the automation. */
    id: string;
    /** The name of the automation. */
    name: string;
    /** Whether the automation was enabled when this configuration was saved. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: ListAutomationRevisionsResponseRevisionsItemSnapshotType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** Trigger configuration for the automation. */
    triggers?: ListAutomationRevisionsResponseRevisionsItemSnapshotTriggers | undefined;
    /** The prompt for the automation. */
    prompt: string;
    /** The tools available to the automation. */
    tools?: ListAutomationRevisionsResponseRevisionsItemSnapshotToolsList | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
/** An immutable snapshot of an automation's public definition after one configuration save, with the attribution needed to understand who made the change. Legacy history may also contain lifecycle-only snapshots. */
export interface ListAutomationRevisionsResponseRevisionsItem {
    /** The unique identifier of this revision. */
    id: string;
    /** The automation this revision belongs to. */
    automation_id: string;
    /** Position of this revision in the automation's history, starting at 1. */
    revision_number: number;
    /** The kind of change recorded by the revision. */
    change_type: ListAutomationRevisionsResponseRevisionsItemChangeType;
    /** The automation's original creator. Omitted when not recorded. */
    creator?: CreateRepoAutomationResponseCreatedBy | undefined;
    /** The person who made this change. Omitted for system changes and legacy records. */
    editor?: CreateRepoAutomationResponseCreatedBy | undefined;
    /** The kind of actor that made the change. */
    editor_type?: ListAutomationRevisionsResponseRevisionsItemEditorType | undefined;
    /** When the change was applied. */
    changed_at: string;
    /** The revision a rollback restored. Present only when `change_type` is `rolled_back`. */
    restored_from_revision_id?: string | undefined;
    /** The automation's public detail representation after the change, including its enabled state at configuration-save time, not its current lifecycle state. Legacy deleted revisions are identified by `change_type`. */
    snapshot?: ListAutomationRevisionsResponseRevisionsItemSnapshot | undefined;
}
/** Revisions ordered by revision number descending. */
export type ListAutomationRevisionsResponseRevisionsList = Array<ListAutomationRevisionsResponseRevisionsItem>;
export interface ListAutomationRevisionsResponse {
    /** Revisions ordered by revision number descending. */
    revisions: ListAutomationRevisionsResponseRevisionsList;
}
export type ListAutomationsRequestType = "personal" | "shared";
export interface ListAutomationsRequest {
    /** The page number of the results to fetch. */
    page?: number | undefined;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
    /** Filter automations by type. `personal` returns automations owned by their creator, `shared` returns automations owned by the repository. Omit to return both. */
    type?: ListAutomationsRequestType | (string & {}) | undefined;
}
/** The tools available to the automation. Omitted when no tools are configured. */
export type ListAutomationsResponseBodyItemToolsList = Array<string>;
/** Repository identity for an automation in cross-repository list responses. */
export interface ListAutomationsResponseBodyItemRepository {
    /** The unique identifier of the repository. */
    id: number;
    /** The repository owner login. */
    owner: string;
    /** The repository name. */
    name: string;
}
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type ListAutomationsResponseBodyItemType = "personal" | "shared";
export type ListAutomationsResponseBodyItemTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type ListAutomationsResponseBodyItemTriggersIntervalCadenceList = Array<ListAutomationsResponseBodyItemTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type ListAutomationsResponseBodyItemTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type ListAutomationsResponseBodyItemTriggersIntervalWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: ListAutomationsResponseBodyItemTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: ListAutomationsResponseBodyItemTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type ListAutomationsResponseBodyItemTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: ListAutomationsResponseBodyItemTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type ListAutomationsResponseBodyItemTriggersWorkflowRunWorkflowsList = Array<string>;
export type ListAutomationsResponseBodyItemTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type ListAutomationsResponseBodyItemTriggersWorkflowRunConclusionsList = Array<ListAutomationsResponseBodyItemTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: ListAutomationsResponseBodyItemTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: ListAutomationsResponseBodyItemTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type ListAutomationsResponseBodyItemTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type ListAutomationsResponseBodyItemTriggersPullRequestCommentCommentTypesList = Array<ListAutomationsResponseBodyItemTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: ListAutomationsResponseBodyItemTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type ListAutomationsResponseBodyItemTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: ListAutomationsResponseBodyItemTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type ListAutomationsResponseBodyItemTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: ListAutomationsResponseBodyItemTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type ListAutomationsResponseBodyItemTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type ListAutomationsResponseBodyItemTriggersDiscussionCommentCommentTypesList = Array<ListAutomationsResponseBodyItemTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type ListAutomationsResponseBodyItemTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: ListAutomationsResponseBodyItemTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: ListAutomationsResponseBodyItemTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type ListAutomationsResponseBodyItemTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: ListAutomationsResponseBodyItemTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type ListAutomationsResponseBodyItemTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: ListAutomationsResponseBodyItemTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type ListAutomationsResponseBodyItemTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: ListAutomationsResponseBodyItemTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedStatesList = Array<ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type ListAutomationsResponseBodyItemTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: ListAutomationsResponseBodyItemTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type ListAutomationsResponseBodyItemTriggersAutomationFailedAutomationIdsList = Array<string>;
export type ListAutomationsResponseBodyItemTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type ListAutomationsResponseBodyItemTriggersAutomationFailedReasonsList = Array<ListAutomationsResponseBodyItemTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface ListAutomationsResponseBodyItemTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: ListAutomationsResponseBodyItemTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: ListAutomationsResponseBodyItemTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListAutomationsResponseBodyItemTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListAutomationsResponseBodyItemTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListAutomationsResponseBodyItemTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListAutomationsResponseBodyItemTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListAutomationsResponseBodyItemTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface ListAutomationsResponseBodyItemTriggers {
    interval?: ListAutomationsResponseBodyItemTriggersInterval | undefined;
    issue_opened?: ListAutomationsResponseBodyItemTriggersIssueOpened | undefined;
    issue_labeled?: ListAutomationsResponseBodyItemTriggersIssueLabeled | undefined;
    workflow_run?: ListAutomationsResponseBodyItemTriggersWorkflowRun | undefined;
    pull_request_opened?: ListAutomationsResponseBodyItemTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: ListAutomationsResponseBodyItemTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: ListAutomationsResponseBodyItemTriggersPullRequestMerged | undefined;
    issue_comment?: ListAutomationsResponseBodyItemTriggersIssueComment | undefined;
    pull_request_comment?: ListAutomationsResponseBodyItemTriggersPullRequestComment | undefined;
    discussion_opened?: ListAutomationsResponseBodyItemTriggersDiscussionOpened | undefined;
    discussion_updated?: ListAutomationsResponseBodyItemTriggersDiscussionUpdated | undefined;
    discussion_comment?: ListAutomationsResponseBodyItemTriggersDiscussionComment | undefined;
    issue_assigned?: ListAutomationsResponseBodyItemTriggersIssueAssigned | undefined;
    pull_request_assigned?: ListAutomationsResponseBodyItemTriggersPullRequestAssigned | undefined;
    sub_issue_added?: ListAutomationsResponseBodyItemTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: ListAutomationsResponseBodyItemTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: ListAutomationsResponseBodyItemTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: ListAutomationsResponseBodyItemTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: ListAutomationsResponseBodyItemTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: ListAutomationsResponseBodyItemTriggersPullRequestReviewRequested | undefined;
    issue_closed?: ListAutomationsResponseBodyItemTriggersIssueClosed | undefined;
    issue_reopened?: ListAutomationsResponseBodyItemTriggersIssueReopened | undefined;
    pull_request_closed?: ListAutomationsResponseBodyItemTriggersPullRequestClosed | undefined;
    pull_request_reopened?: ListAutomationsResponseBodyItemTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: ListAutomationsResponseBodyItemTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: ListAutomationsResponseBodyItemTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: ListAutomationsResponseBodyItemTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: ListAutomationsResponseBodyItemTriggersAutomationCompleted | undefined;
    automation_failed?: ListAutomationsResponseBodyItemTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: ListAutomationsResponseBodyItemTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: ListAutomationsResponseBodyItemTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: ListAutomationsResponseBodyItemTriggersDependabotAlert | undefined;
}
/** A GitHub user */
export type ListAutomationsResponseBodyItemCreatedBy = CreateRepoAutomationResponseCreatedBy;
/** A summary representation of an automation including repository identity (used in cross-repository list responses). */
export interface ListAutomationsResponseBodyItem {
    /** The tools available to the automation. Omitted when no tools are configured. */
    tools?: ListAutomationsResponseBodyItemToolsList | undefined;
    /** The unique identifier of the automation. */
    id: string;
    /** Repository identity for an automation in cross-repository list responses. */
    repository: ListAutomationsResponseBodyItemRepository;
    /** The name of the automation. */
    name: string;
    /** Whether the automation is currently enabled. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: ListAutomationsResponseBodyItemType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** Trigger configuration for the automation. */
    triggers?: ListAutomationsResponseBodyItemTriggers | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
export type ListAutomationsResponseBodyList = Array<ListAutomationsResponseBodyItem>;
export type ListAutomationsResponse = ListAutomationsResponseBodyList;
export interface ListAvailableRepoAutomationToolsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
}
/** The tool's behavior level. `read` tools only retrieve data. `write` tools can change data. This is not a GitHub token permission. */
export type ListAvailableRepoAutomationToolsResponseToolGroupsItemToolsItemScope = "read" | "write";
/** A tool that can be selected for use in an automation. */
export interface ListAvailableRepoAutomationToolsResponseToolGroupsItemToolsItem {
    /** The unique identifier of the tool accepted when creating or updating an automation. */
    id: string;
    /** The human-readable name of the tool. */
    title: string;
    /** A short description of what the tool does. */
    description: string;
    /** The tool's behavior level. `read` tools only retrieve data. `write` tools can change data. This is not a GitHub token permission. */
    scope?: ListAvailableRepoAutomationToolsResponseToolGroupsItemToolsItemScope | undefined;
}
/** The tools currently available in this group. */
export type ListAvailableRepoAutomationToolsResponseToolGroupsItemToolsList = Array<ListAvailableRepoAutomationToolsResponseToolGroupsItemToolsItem>;
/** A group of tools available for use in automations */
export interface ListAvailableRepoAutomationToolsResponseToolGroupsItem {
    /** The unique identifier of the group. */
    id: string;
    /** The human-readable name of the group. */
    title: string;
    /** The tools currently available in this group. */
    tools: ListAvailableRepoAutomationToolsResponseToolGroupsItemToolsList;
}
/** Caller-filtered built-in automation tool groups. */
export type ListAvailableRepoAutomationToolsResponseToolGroupsList = Array<ListAvailableRepoAutomationToolsResponseToolGroupsItem>;
/** An explicitly configured MCP tool with a server-qualified ID. Descriptions and input schemas are not discovered. */
export interface ListAvailableRepoAutomationToolsResponseMcpServersItemToolsItem {
    /** The tool identifier in `<server-name>/<tool-name>` format, for example `sentry/list_issues`. */
    id: string;
}
/** Explicitly configured tools with server-qualified IDs, in configuration order. Empty when the server's allowlist is ["*"]. */
export type ListAvailableRepoAutomationToolsResponseMcpServersItemToolsList = Array<ListAvailableRepoAutomationToolsResponseMcpServersItemToolsItem>;
/** A projection of a repository MCP server's configured tool allowlist, not live tool discovery or a guarantee of runtime availability. */
export interface ListAvailableRepoAutomationToolsResponseMcpServersItem {
    /** The server name from the repository MCP configuration. */
    name: string;
    /** Explicitly configured tools with server-qualified IDs, in configuration order. Empty when the server's allowlist is ["*"]. */
    tools: ListAvailableRepoAutomationToolsResponseMcpServersItemToolsList;
    /** Whether the effective repository configuration permits selecting all tools on this server using ["*"], including future tools. Mutually exclusive with a non-empty tools list. */
    supports_wildcard: boolean;
}
/** Configured repository MCP servers, sorted by name. Empty when repository MCP is disabled or unconfigured. */
export type ListAvailableRepoAutomationToolsResponseMcpServersList = Array<ListAvailableRepoAutomationToolsResponseMcpServersItem>;
export interface ListAvailableRepoAutomationToolsResponse {
    /** Caller-filtered built-in automation tool groups. */
    tool_groups: ListAvailableRepoAutomationToolsResponseToolGroupsList;
    /** Configured repository MCP servers, sorted by name. Empty when repository MCP is disabled or unconfigured. */
    mcp_servers: ListAvailableRepoAutomationToolsResponseMcpServersList;
}
export interface ListAvailableRepoAutomationTriggersRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
}
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase0Type = "string";
/** The allowed string values. */
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase0EnumList = Array<string>;
export interface ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase0 {
    type: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase0Type;
    /** The allowed string values. */
    enum?: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase0EnumList | undefined;
    /** The minimum accepted string length. */
    minLength?: number | undefined;
}
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1Type = "array";
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1ItemsType = "string";
/** The allowed string item values. */
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1ItemsEnumList = Array<string>;
export interface ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1Items {
    type: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1ItemsType;
    /** The allowed string item values. */
    enum?: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1ItemsEnumList | undefined;
    /** The minimum accepted string item length. */
    minLength?: number | undefined;
}
export interface ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1 {
    type: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1Type;
    items: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1Items;
    /** The minimum accepted number of array items. */
    minItems?: number | undefined;
    /** The maximum accepted number of array items. */
    maxItems?: number | undefined;
    /** Whether duplicate array items are rejected. */
    uniqueItems?: boolean | undefined;
}
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase2Type = "integer";
/** The allowed integer values. */
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase2EnumList = Array<number>;
export interface ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase2 {
    type: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase2Type;
    /** The allowed integer values. */
    enum?: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase2EnumList | undefined;
    /** The minimum accepted integer value. */
    minimum?: number | undefined;
    /** The maximum accepted integer value. */
    maximum?: number | undefined;
}
/** A JSON Schema fragment describing the expected structure of the field value. */
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchema = ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase0 | ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase1 | ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchemaCase2;
/** A filter that can be configured when using a trigger in an automation. */
export interface ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItem {
    /** The stable identifier of the field. */
    id: string;
    /** The human-readable name of the field. */
    label: string;
    /** Whether the field must be provided. */
    required: boolean;
    /** The human-readable description of the field. */
    description?: string | undefined;
    /** A JSON Schema fragment describing the expected structure of the field value. */
    schema: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItemSchema;
}
/** The fields that can be specified to configure this trigger. */
export type ListAvailableRepoAutomationTriggersResponseBodyItemFieldsList = Array<ListAvailableRepoAutomationTriggersResponseBodyItemFieldsItem>;
/** An available trigger for automations */
export interface ListAvailableRepoAutomationTriggersResponseBodyItem {
    /** The unique identifier of the trigger. */
    id: string;
    /** The human-readable name of the trigger. */
    title: string;
    /** A short description of when the trigger fires. */
    description: string;
    /** The fields that can be specified to configure this trigger. */
    fields: ListAvailableRepoAutomationTriggersResponseBodyItemFieldsList;
}
export type ListAvailableRepoAutomationTriggersResponseBodyList = Array<ListAvailableRepoAutomationTriggersResponseBodyItem>;
export type ListAvailableRepoAutomationTriggersResponse = ListAvailableRepoAutomationTriggersResponseBodyList;
export type ListRepoAutomationsRequestType = "personal" | "shared";
export interface ListRepoAutomationsRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The page number of the results to fetch. */
    page?: number | undefined;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
    /** Filter automations by type. `personal` returns automations owned by their creator, `shared` returns automations owned by the repository. Omit to return both. */
    type?: ListRepoAutomationsRequestType | (string & {}) | undefined;
}
/** The tools available to the automation. Omitted when no tools are configured. */
export type ListRepoAutomationsResponseAutomationsItemToolsList = Array<string>;
/** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
export type ListRepoAutomationsResponseAutomationsItemType = "personal" | "shared";
export type ListRepoAutomationsResponseAutomationsItemTriggersIntervalCadenceItem = "hourly" | "daily" | "weekly";
/** One or more schedules on which the Automation runs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIntervalCadenceList = Array<ListRepoAutomationsResponseAutomationsItemTriggersIntervalCadenceItem>;
/** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIntervalMinuteUtc = 0 | 15 | 30 | 45;
/** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIntervalWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersInterval {
    /** One or more schedules on which the Automation runs. */
    cadence: ListRepoAutomationsResponseAutomationsItemTriggersIntervalCadenceList;
    /** UTC hour anchor (0 through 23) for daily and weekly schedules. Omitted daily and weekly values default to `0` (midnight UTC). */
    hour_utc?: number | undefined;
    /** UTC weekday anchor for weekly schedules, where `0` is Sunday and `6` is Saturday. Omitted weekly values default to Monday (`1`). */
    day_of_week?: number | undefined;
    /** UTC minute anchor for daily and weekly schedules. Omitted daily and weekly values default to `0`. Must be omitted whenever `cadence` includes `hourly`. */
    minute_utc?: ListRepoAutomationsResponseAutomationsItemTriggersIntervalMinuteUtc | undefined;
    /** Has no effect: scheduled runs can change any resource in the repository, and an organization or repository policy requiring trigger-scoped writes does not apply to them. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIntervalWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueOpenedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersIssueOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIssueOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueLabeledWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersIssueLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: ListRepoAutomationsResponseAutomationsItemTriggersIssueLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIssueLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Workflow names matched against the name in each workflow YAML file. */
export type ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunWorkflowsList = Array<string>;
export type ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunConclusionsItem = "failure";
/** Workflow conclusions to match. The current trigger supports failure. */
export type ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunConclusionsList = Array<ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunConclusionsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRun {
    /** Workflow names matched against the name in each workflow YAML file. */
    workflows: ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunWorkflowsList;
    /** Workflow conclusions to match. The current trigger supports failure. */
    conclusions: ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunConclusionsList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRunWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestOpenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestOpenedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestOpened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestOpenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestSynchronizePathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestSynchronizeWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestSynchronize {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestSynchronizePathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestSynchronizeWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMerged {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueCommentWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersIssueComment {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIssueCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentCommentTypesItem = "timeline_comment" | "review_comment";
/** Pull request conversation and inline review comment types to match. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentCommentTypesList = Array<ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentCommentTypesItem>;
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestComment {
    /** Pull request conversation and inline review comment types to match. */
    comment_types: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentCommentTypesList;
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentPathsList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionOpenedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionOpenedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersDiscussionOpened {
    /** Discussion category names matched case-insensitively. */
    categories?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionOpenedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionOpenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Discussion category names matched case-insensitively. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionUpdatedCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionUpdatedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersDiscussionUpdated {
    /** Discussion category names matched case-insensitively. */
    categories?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionUpdatedCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionUpdatedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentCommentTypesItem = "comment" | "reply";
/** Top-level discussion comments and replies to match. Omit to match both. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentCommentTypesList = Array<ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentCommentTypesItem>;
/** Discussion category names matched case-insensitively. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentCategoriesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersDiscussionComment {
    /** Top-level discussion comments and replies to match. Omit to match both. */
    comment_types?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentCommentTypesList | undefined;
    /** Discussion category names matched case-insensitively. */
    categories?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentCategoriesList | undefined;
    /** A case-insensitive substring matched against the event body. */
    body_substring?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionCommentWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Affected assignee logins matched case-insensitively. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueAssignedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersIssueAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: ListRepoAutomationsResponseAutomationsItemTriggersIssueAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIssueAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssignedPathsList = Array<string>;
/** Affected assignee logins matched case-insensitively. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssignedAssigneesList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssignedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssigned {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssignedPathsList | undefined;
    /** Affected assignee logins matched case-insensitively. */
    assignees?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssignedAssigneesList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssignedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersSubIssueAddedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersSubIssueAdded {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersSubIssueAddedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReadyForReviewPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReadyForReviewWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReadyForReview {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReadyForReviewPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReadyForReviewWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeledPathsList = Array<string>;
/** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeledLabelsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeledWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeled {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeledPathsList | undefined;
    /** Label names matched case-insensitively against the label added by the event. Omit or use an empty array to match every added label. */
    labels?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeledLabelsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeledWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergeConflictPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergeConflictWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergeConflict {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergeConflictPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergeConflictWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedPathsList = Array<string>;
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedStatesItem = "approved" | "changes_requested" | "commented";
/** Submitted review states to match. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedStatesList = Array<ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedStatesItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmitted {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedPathsList | undefined;
    /** Submitted review states to match. */
    states: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedStatesList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmittedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewRequestedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewRequestedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewRequested {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewRequestedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewRequestedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueClosedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersIssueClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIssueClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersIssueReopenedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersIssueReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersIssueReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestClosedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestClosedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestClosed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestClosedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestClosedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReopenedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReopenedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReopened {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReopenedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReopenedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestConvertedToDraftPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestConvertedToDraftWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestConvertedToDraft {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestConvertedToDraftPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestConvertedToDraftWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewDismissedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewDismissedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewDismissed {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewDismissedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewDismissedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadResolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadResolvedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadResolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadResolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadResolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Gitignore-style changed-file path globs. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadUnresolvedPathsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadUnresolvedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadUnresolved {
    /** A GitHub issue or pull request search query. */
    query?: string | undefined;
    /** Gitignore-style changed-file path globs. */
    paths?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadUnresolvedPathsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadUnresolvedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. */
export type ListRepoAutomationsResponseAutomationsItemTriggersAutomationCompletedAutomationIdsList = Array<string>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersAutomationCompletedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersAutomationCompleted {
    /** Upstream Automation IDs in the same repository. */
    automation_ids: ListRepoAutomationsResponseAutomationsItemTriggersAutomationCompletedAutomationIdsList;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersAutomationCompletedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
export type ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedAutomationIdsList = Array<string>;
export type ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedReasonsItem = "reported" | "crashed" | "timed_out";
/** Failure reasons to match. Omit to match only reported failures. */
export type ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedReasonsList = Array<ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedReasonsItem>;
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedWriteScope = "trigger" | "repository";
export interface ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailed {
    /** Upstream Automation IDs in the same repository. An Automation cannot list itself, and a user-owned Automation can only be listed by its creator's user-owned Automations. */
    automation_ids: ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedAutomationIdsList;
    /** Failure reasons to match. Omit to match only reported failures. */
    reasons?: ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedReasonsList | undefined;
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailedWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersCodeScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListRepoAutomationsResponseAutomationsItemTriggersCodeScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersCodeScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersSecretScanningAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListRepoAutomationsResponseAutomationsItemTriggersSecretScanningAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersSecretScanningAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
export type ListRepoAutomationsResponseAutomationsItemTriggersDependabotAlertWriteScope = "trigger" | "repository";
/** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
export interface ListRepoAutomationsResponseAutomationsItemTriggersDependabotAlert {
    /** Sets the write scope for this trigger's runs. Omit to inherit the automation's effective scope (default `trigger`). Organization or repository policy may restrict the effective scope to `trigger`. Explicitly setting `repository` on create or edit returns 422 when policy validation is enabled and that policy applies. */
    write_scope?: ListRepoAutomationsResponseAutomationsItemTriggersDependabotAlertWriteScope | undefined;
    /** When true, events Copilot creates, including from other automations and Copilot sessions, can start this automation through this trigger. Defaults to false. The Copilot coding agent app cannot turn it on: creating a trigger with true, or changing it from false to true, returns 422. */
    allow_copilot_triggers?: boolean | undefined;
}
/** Trigger configuration for the automation. */
export interface ListRepoAutomationsResponseAutomationsItemTriggers {
    interval?: ListRepoAutomationsResponseAutomationsItemTriggersInterval | undefined;
    issue_opened?: ListRepoAutomationsResponseAutomationsItemTriggersIssueOpened | undefined;
    issue_labeled?: ListRepoAutomationsResponseAutomationsItemTriggersIssueLabeled | undefined;
    workflow_run?: ListRepoAutomationsResponseAutomationsItemTriggersWorkflowRun | undefined;
    pull_request_opened?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestOpened | undefined;
    pull_request_synchronize?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestSynchronize | undefined;
    pull_request_merged?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMerged | undefined;
    issue_comment?: ListRepoAutomationsResponseAutomationsItemTriggersIssueComment | undefined;
    pull_request_comment?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestComment | undefined;
    discussion_opened?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionOpened | undefined;
    discussion_updated?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionUpdated | undefined;
    discussion_comment?: ListRepoAutomationsResponseAutomationsItemTriggersDiscussionComment | undefined;
    issue_assigned?: ListRepoAutomationsResponseAutomationsItemTriggersIssueAssigned | undefined;
    pull_request_assigned?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestAssigned | undefined;
    sub_issue_added?: ListRepoAutomationsResponseAutomationsItemTriggersSubIssueAdded | undefined;
    pull_request_ready_for_review?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReadyForReview | undefined;
    pull_request_labeled?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestLabeled | undefined;
    pull_request_merge_conflict?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestMergeConflict | undefined;
    pull_request_review_submitted?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewSubmitted | undefined;
    pull_request_review_requested?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewRequested | undefined;
    issue_closed?: ListRepoAutomationsResponseAutomationsItemTriggersIssueClosed | undefined;
    issue_reopened?: ListRepoAutomationsResponseAutomationsItemTriggersIssueReopened | undefined;
    pull_request_closed?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestClosed | undefined;
    pull_request_reopened?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReopened | undefined;
    pull_request_converted_to_draft?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestConvertedToDraft | undefined;
    pull_request_review_dismissed?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewDismissed | undefined;
    pull_request_review_thread_resolved?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadResolved | undefined;
    pull_request_review_thread_unresolved?: ListRepoAutomationsResponseAutomationsItemTriggersPullRequestReviewThreadUnresolved | undefined;
    automation_completed?: ListRepoAutomationsResponseAutomationsItemTriggersAutomationCompleted | undefined;
    automation_failed?: ListRepoAutomationsResponseAutomationsItemTriggersAutomationFailed | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    code_scanning_alert?: ListRepoAutomationsResponseAutomationsItemTriggersCodeScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    secret_scanning_alert?: ListRepoAutomationsResponseAutomationsItemTriggersSecretScanningAlert | undefined;
    /** Runs on the default branch when a security alert of this kind is created in the repository. These are system events without an issue, pull request, or human actor, and cannot be run manually. */
    dependabot_alert?: ListRepoAutomationsResponseAutomationsItemTriggersDependabotAlert | undefined;
}
/** A GitHub user */
export type ListRepoAutomationsResponseAutomationsItemCreatedBy = CreateRepoAutomationResponseCreatedBy;
/** A summary representation of an automation (used in list responses). */
export interface ListRepoAutomationsResponseAutomationsItem {
    /** The tools available to the automation. Omitted when no tools are configured. */
    tools?: ListRepoAutomationsResponseAutomationsItemToolsList | undefined;
    /** The unique identifier of the automation. */
    id: string;
    /** The name of the automation. */
    name: string;
    /** Whether the automation is currently enabled. */
    enabled?: boolean | undefined;
    /** The type of automation. `personal` keeps it private to its creator and its runs act as that user. `shared` makes it belong to the repository, visible to anyone with read access to the repository, and its runs act as the Copilot app rather than as a person. */
    type?: ListRepoAutomationsResponseAutomationsItemType | undefined;
    /** When true, event-triggered runs require the event actor to have repo write permission, even when the org's allow_read_access_triggers policy is enabled. Does not apply to interval-scheduled runs, which always run as the automation owner. */
    require_actor_write_permission?: boolean | undefined;
    /** The model override for sessions triggered by this automation. Absent when the platform selects the model. */
    model?: string | undefined;
    /** The reasoning effort override for sessions triggered by this automation. Absent when the model's default is used. */
    reasoning_effort?: string | undefined;
    /** Trigger configuration for the automation. */
    triggers?: ListRepoAutomationsResponseAutomationsItemTriggers | undefined;
    /** When the automation was created. */
    created_at: string;
    /** When the automation was last updated. */
    updated_at: string;
    /** A GitHub user */
    created_by: CreateRepoAutomationResponseCreatedBy;
}
/** List of automations in the repository */
export type ListRepoAutomationsResponseAutomationsList = Array<ListRepoAutomationsResponseAutomationsItem>;
export interface ListRepoAutomationsResponse {
    /** List of automations in the repository */
    automations: ListRepoAutomationsResponseAutomationsList;
    /** Total count of caller-visible automations matching the supplied filters (across all pages) */
    total_count: number;
}
export type ListRepoAutomationTasksRequestSort = "updated_at" | "created_at";
export type ListRepoAutomationTasksRequestDirection = "asc" | "desc";
export interface ListRepoAutomationTasksRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the automation. */
    automation_id: string;
    /** The number of results per page (max 100). */
    per_page?: number | undefined;
    /** The page number of the results to fetch. */
    page?: number | undefined;
    /** The field to sort results by. Can be `updated_at` or `created_at`. */
    sort?: ListRepoAutomationTasksRequestSort | (string & {}) | undefined;
    /** The direction to sort results. Can be `asc` or `desc`. */
    direction?: ListRepoAutomationTasksRequestDirection | (string & {}) | undefined;
    /** Comma-separated list of task states to filter by. Can be any combination of: `queued`, `in_progress`, `completed`, `failed`, `idle`, `waiting_for_user`, `timed_out`, `cancelled`. */
    state?: string | undefined;
    /** Filter by archived status. When `true`, returns only archived tasks. When `false` or omitted, returns only non-archived tasks. Defaults to `false`. */
    is_archived?: boolean | undefined;
}
export interface ListRepoAutomationTasksResponseTasksItemClientsItem {
    /** Server-resolved integration identity for the client product. */
    integration_id: string;
    /** Stable client product identifier, not an agent or host identifier. Clients must tolerate unknown future slugs. */
    slug: string;
    /** True only when the service has explicit evidence this client created the containing session or task. False does not imply the original client is known. */
    creator: boolean;
}
/** Known client products that created or participated in this task, independent of its executing agents. Omitted when no client identity is known. */
export type ListRepoAutomationTasksResponseTasksItemClientsList = Array<ListRepoAutomationTasksResponseTasksItemClientsItem>;
/** A GitHub user */
export type ListRepoAutomationTasksResponseTasksItemCreator = CreateRepoAutomationResponseCreatedBy;
/** Type of the task creator */
export type ListRepoAutomationTasksResponseTasksItemCreatorType = "user" | "organization";
/** A GitHub user */
export type ListRepoAutomationTasksResponseTasksItemUserCollaboratorsItem = CreateRepoAutomationResponseCreatedBy;
/** User objects of collaborators on this task */
export type ListRepoAutomationTasksResponseTasksItemUserCollaboratorsList = Array<CreateRepoAutomationResponseCreatedBy>;
/** The owner of the repository */
export type ListRepoAutomationTasksResponseTasksItemOwner = CreateRepoAutomationResponseCreatedBy;
/** The repository this task belongs to */
export interface ListRepoAutomationTasksResponseTasksItemRepository {
    /** The unique identifier of the repository */
    id?: number | undefined;
}
/** Current state of the task, derived from its most recent session */
export type ListRepoAutomationTasksResponseTasksItemState = "queued" | "in_progress" | "completed" | "failed" | "idle" | "waiting_for_user" | "timed_out" | "cancelled";
/** Provider namespace */
export type ListRepoAutomationTasksResponseTasksItemArtifactsItemProvider = "github";
/** Type of artifact. Available Values: `pull`, `branch`. */
export type ListRepoAutomationTasksResponseTasksItemArtifactsItemType = "pull" | "branch";
/** A GitHub resource (pull request, issue, etc.) */
export interface ListRepoAutomationTasksResponseTasksItemArtifactsItemDataCase0 {
    /** GitHub resource ID */
    id: number;
    /** GraphQL global ID */
    global_id?: string | undefined;
}
/** A Git branch reference */
export interface ListRepoAutomationTasksResponseTasksItemArtifactsItemDataCase1 {
    /** Head branch name */
    head_ref: string;
    /** Base branch name */
    base_ref: string;
}
/** Resource data (shape depends on type) */
export type ListRepoAutomationTasksResponseTasksItemArtifactsItemData = ListRepoAutomationTasksResponseTasksItemArtifactsItemDataCase0 | ListRepoAutomationTasksResponseTasksItemArtifactsItemDataCase1;
/** A resource generated by the task */
export interface ListRepoAutomationTasksResponseTasksItemArtifactsItem {
    /** Provider namespace */
    provider: ListRepoAutomationTasksResponseTasksItemArtifactsItemProvider;
    /** Type of artifact. Available Values: `pull`, `branch`. */
    type: ListRepoAutomationTasksResponseTasksItemArtifactsItemType;
    /** Resource data (shape depends on type) */
    data: ListRepoAutomationTasksResponseTasksItemArtifactsItemData;
}
/** Resources created by this task (PRs, branches, etc.) */
export type ListRepoAutomationTasksResponseTasksItemArtifactsList = Array<ListRepoAutomationTasksResponseTasksItemArtifactsItem>;
/** Custom agent metadata associated with this task */
export interface ListRepoAutomationTasksResponseTasksItemCustomAgent {
    /** The custom agent's filename without the extension - for example, `performance-optimizer` for a `.github/agents/performance-optimizer.agent.md` custom agent. */
    id?: string | undefined;
}
export interface ListRepoAutomationTasksResponseTasksItem {
    /** Unique task identifier */
    id: string;
    /** API URL for this task */
    url?: string | undefined;
    /** Web URL for this task */
    html_url?: string | undefined;
    /** Human-readable name derived from the task prompt */
    name?: string | undefined;
    /** Known client products that created or participated in this task, independent of its executing agents. Omitted when no client identity is known. */
    clients?: ListRepoAutomationTasksResponseTasksItemClientsList | undefined;
    /** The entity who created this task */
    creator?: CreateRepoAutomationResponseCreatedBy | undefined;
    /** Type of the task creator */
    creator_type?: ListRepoAutomationTasksResponseTasksItemCreatorType | undefined;
    /** User objects of collaborators on this task */
    user_collaborators?: ListRepoAutomationTasksResponseTasksItemUserCollaboratorsList | undefined;
    /** The owner of the repository */
    owner?: CreateRepoAutomationResponseCreatedBy | undefined;
    /** The repository this task belongs to */
    repository?: ListRepoAutomationTasksResponseTasksItemRepository | undefined;
    /** Current state of the task, derived from its most recent session */
    state: ListRepoAutomationTasksResponseTasksItemState;
    /** Number of sessions in this task */
    session_count?: number | undefined;
    /** Resources created by this task (PRs, branches, etc.) */
    artifacts?: ListRepoAutomationTasksResponseTasksItemArtifactsList | undefined;
    /** Timestamp when the task was archived, null if not archived */
    archived_at?: string | null | undefined;
    /** Timestamp of the most recent update */
    updated_at?: string | undefined;
    /** Timestamp when the task was created */
    created_at: string;
    /** Custom agent metadata associated with this task */
    custom_agent?: ListRepoAutomationTasksResponseTasksItemCustomAgent | undefined;
}
/** Tasks created by the automation. */
export type ListRepoAutomationTasksResponseTasksList = Array<ListRepoAutomationTasksResponseTasksItem>;
export interface ListRepoAutomationTasksResponse {
    /** Tasks created by the automation. */
    tasks: ListRepoAutomationTasksResponseTasksList;
}
export type CreateRepoAutomationError = GithubOpError;
/** Create an automation for a repository > [!NOTE] > This endpoint is in public preview and is subject to change. Creates a new automation in a repository. Personal automations are private to their creator. Shared automations are visible to anyone with read access to the repository and manageable by anyone with write access to the repository. GitHub App installation access tokens can create shared automations by setting `type` to `shared`. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (write). Personal automations require a user token. For installation tokens, `created_by` identifies the App's bot account. To call this endpoint, you must have write access to the repository and the "Allow automations" setting must be enabled for the repository. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "Create an automation for a repository"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (write) */
export declare const createRepoAutomation: API.OperationMethod<CreateRepoAutomationRequest, CreateRepoAutomationResponse, CreateRepoAutomationError, GithubOpContext>;
export type CreateRepoAutomationTaskError = GithubOpError;
/** Run an automation > [!NOTE] > This endpoint is in public preview and is subject to change. Runs an automation in a repository. Set `event` to `manual` and optionally include `context` of up to 10,000 characters, which will be injected into the automation's prompt. The repository must have the "Allow automations" setting enabled, and the automation must be a personal automation belonging to you or a shared automation. GitHub App installation access tokens can run shared automations. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (write). Personal automations require a user token. A successful response accepts the run request and includes a preallocated `task_id`. User tokens can fetch it with the "Get a task by repo" Agent tasks API. GitHub App installation tokens can list tasks for the automation in the repository and match the returned `task_id`. The response does not confirm execution or task creation. Task creation is asynchronous, so fetching the task immediately may return `404 Not Found`, and downstream skips or failures can prevent its creation. To call this endpoint, you must have write access to the repository. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "Run an automation"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (write) */
export declare const createRepoAutomationTask: API.OperationMethod<CreateRepoAutomationTaskRequest, CreateRepoAutomationTaskResponse, CreateRepoAutomationTaskError, GithubOpContext>;
export type DeleteRepoAutomationError = GithubOpError;
/** Delete an automation > [!NOTE] > This endpoint is in public preview and is subject to change. Deletes an automation in a repository. The automation must be a personal automation belonging to you or a shared automation. Data dedicated to the automation is also deleted when present and may remain recoverable for a limited period according to the configured retention policy. GitHub App installation access tokens can delete shared automations. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (write). Personal automations require a user token. To call this endpoint, you must have write access to the repository and the "Allow automations" setting must be enabled for the repository. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "Delete an automation"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (write) */
export declare const deleteRepoAutomation: API.OperationMethod<DeleteRepoAutomationRequest, DeleteRepoAutomationResponse, DeleteRepoAutomationError, GithubOpContext>;
export type EditRepoAutomationError = GithubOpError;
/** Update an automation > [!NOTE] > This endpoint is in public preview and is subject to change. Updates an existing automation in a repository. The automation must be a personal automation belonging to you or a shared automation. Omitted fields are left unchanged. The automation's `type` is immutable. GitHub App installation access tokens can update shared automations. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (write). Personal automations require a user token. To call this endpoint, you must have write access to the repository and the "Allow automations" setting must be enabled for the repository. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "Update an automation"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (write) */
export declare const editRepoAutomation: API.OperationMethod<EditRepoAutomationRequest, EditRepoAutomationResponse, EditRepoAutomationError, GithubOpContext>;
export type GetAutomationRevisionError = GithubOpError;
/** Get an automation revision > [!NOTE] > This endpoint is in public preview and is subject to change. Returns a specific revision of an automation, including its configuration after that change. Access follows the automation's own ownership rules: a user-owned automation's history is readable only by its creator, and a repository-owned automation's history follows repository read access. History remains readable after the automation is deleted. A revision ID belonging to a different automation returns `404`. **Fine-grained access tokens for "Get an automation revision"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) GitHub App installation access tokens are not supported for this endpoint. */
export declare const getAutomationRevision: API.OperationMethod<GetAutomationRevisionRequest, GetAutomationRevisionResponse, GetAutomationRevisionError, GithubOpContext>;
export type GetRepoAutomationError = GithubOpError;
/** Get an automation > [!NOTE] > This endpoint is in public preview and is subject to change. Fetches a repository automation by ID. The automation must be a personal automation belonging to you or a shared automation. Shared automations are visible to anyone with read access to the repository. The `created_by` field identifies the creator and is distinct from the automation's `type`. GitHub App installation access tokens can access shared automations. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (read). Personal automations require a user token. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "Get an automation"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) */
export declare const getRepoAutomation: API.OperationMethod<GetRepoAutomationRequest, GetRepoAutomationResponse, GetRepoAutomationError, GithubOpContext>;
export type ListAutomationRevisionsError = GithubOpError;
/** List revisions for an automation > [!NOTE] > This endpoint is in public preview and is subject to change. Returns a list of revisions for an automation, ordered from newest to oldest. Access follows the automation's own ownership rules: a user-owned automation's history is readable only by its creator, and a repository-owned automation's history follows repository read access. History remains readable after the automation is deleted. Follow the opaque cursor in the `rel="next"` link from the `Link` header to continue when more revisions are available. **Fine-grained access tokens for "List revisions for an automation"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) GitHub App installation access tokens are not supported for this endpoint. */
export declare const listAutomationRevisions: API.OperationMethod<ListAutomationRevisionsRequest, ListAutomationRevisionsResponse, ListAutomationRevisionsError, GithubOpContext>;
export type ListAutomationsError = GithubOpError;
/** List automations for user > [!NOTE] > This endpoint is in public preview and is subject to change. Lists automations created by the authenticated user across repositories they can read. This includes both personal and shared automations created by the caller, but excludes shared automations created by another user. Use the repository-scoped list operation for those automations. The `type` filter only narrows this creator-scoped collection. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "List automations for user"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) GitHub App installation access tokens are not supported for this endpoint. */
export declare const listAutomations: API.PaginatedOperationMethod<ListAutomationsRequest, ListAutomationsResponse, ListAutomationsError, GithubOpContext, ListAutomationsResponseBodyItem>;
export type ListAvailableRepoAutomationToolsError = GithubOpError;
/** List available automation tools for a repository > [!NOTE] > This endpoint is in public preview and is subject to change. Lists available tools for automations in a repository, including both GitHub-provided tools and tools provided by custom MCP servers. GitHub-provided tools are returned in named groups, with a name and description provided for each tool. MCP entries describe configured tool selection, not live discovery or runtime availability. An explicit allowlist is returned in `tools`, with each `id` in `<server-name>/<tool-name>` format, for example `sentry/list_issues`. An allowlist of `["*"]` is returned as `supports_wildcard: true` with an empty `tools` array. Server URLs, authentication headers, environment variables, and credentials are never returned. For MCP tools, a list of configured MCP servers is provided, along with the tools allowlisted for each server. Where `supports_wildcard` is true, any tool that exists on the server can be used. GitHub App installation access tokens can list available automation tools. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (read). To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "List available automation tools for a repository"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) */
export declare const listAvailableRepoAutomationTools: API.OperationMethod<ListAvailableRepoAutomationToolsRequest, ListAvailableRepoAutomationToolsResponse, ListAvailableRepoAutomationToolsError, GithubOpContext>;
export type ListAvailableRepoAutomationTriggersError = GithubOpError;
/** List available automation triggers for a repository > [!NOTE] > This endpoint is in public preview and is subject to change. Lists available triggers for automations in a repository. Each available trigger includes a title and description that can be presented in user interfaces, plus a machine-readable schema of filters supported by the trigger. GitHub App installation access tokens can list available automation triggers. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (read). To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "List available automation triggers for a repository"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) */
export declare const listAvailableRepoAutomationTriggers: API.OperationMethod<ListAvailableRepoAutomationTriggersRequest, ListAvailableRepoAutomationTriggersResponse, ListAvailableRepoAutomationTriggersError, GithubOpContext>;
export type ListRepoAutomationsError = GithubOpError;
/** List automations for a repository > [!NOTE] > This endpoint is in public preview and is subject to change. Returns a paginated list of automations for a repository, including shared automations and personal automations created by the caller. `total_count` is the number of caller-visible automations matching the supplied filters across all pages. Use the `type` field to distinguish personal and shared automations. GitHub App installation access tokens can list shared automations. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (read). Personal automations require a user token. To call this endpoint, OAuth app tokens and personal access tokens (classic) need the `repo` scope. **Fine-grained access tokens for "List automations for a repository"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) */
export declare const listRepoAutomations: API.PaginatedOperationMethod<ListRepoAutomationsRequest, ListRepoAutomationsResponse, ListRepoAutomationsError, GithubOpContext, ListRepoAutomationsResponseAutomationsItem>;
export type ListRepoAutomationTasksError = GithubOpError;
/** List tasks for an automation in a repository > [!NOTE] > This endpoint is in public preview and is subject to change. Returns a paginated list of tasks created by an automation in the specified repository. The automation must belong to that exact repository. User-owned automation history is visible only to the automation's creator. Repository-owned automation history is visible to callers with read access to repository automations. Deleted and unlisted tasks are excluded. Tasks produced by private-session agents are excluded unless the caller created the task, is a task collaborator, or the task is shared. A missing repository, an inaccessible repository, or an automation that does not belong to the specified repository returns `404` without revealing which condition occurred. GitHub App installation access tokens can list tasks for shared automations. The installation must belong to the repository owner and the token must have "Agent tasks" repository permissions (read). Personal automations require a user token. **Fine-grained access tokens for "List tasks for an automation in a repository"** This endpoint works with the following fine-grained token types: * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app) * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app) * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token) The fine-grained token must have the following permission set: * "Agent tasks" repository permissions (read) */
export declare const listRepoAutomationTasks: API.PaginatedOperationMethod<ListRepoAutomationTasksRequest, ListRepoAutomationTasksResponse, ListRepoAutomationTasksError, GithubOpContext, ListRepoAutomationTasksResponseTasksItem>;
//# sourceMappingURL=agent_automations.d.ts.map