import type { GraphQLTelemetry } from "@distilled.cloud/core/graphql";
/** Span facts for every document this SDK sends. */
export declare const TELEMETRY: GraphQLTelemetry;
//# sourceMappingURL=graphql-telemetry.d.ts.map