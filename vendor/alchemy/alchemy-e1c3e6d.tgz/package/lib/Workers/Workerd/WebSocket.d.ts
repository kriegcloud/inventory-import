import type * as cf from "@cloudflare/workers-types";
import * as Effect from "effect/Effect";
import * as HttpServerResponse from "effect/http/HttpServerResponse";
import * as Schema from "effect/Schema";
export type RawWebSocket = cf.WebSocket;
declare const WebSocketAttachmentError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "WebSocketAttachmentError";
} & Readonly<A>;
/**
 * An application attachment could not be encoded, decoded, read, or written.
 * Catch this tag to choose whether to fail, ignore the attachment, or close the
 * connection. Codec failures and native exceptions are preserved in `cause`.
 */
export declare class WebSocketAttachmentError extends WebSocketAttachmentError_base<{
    /** The failed attachment operation, or `missing` for a nullish attachment. */
    readonly reason: "encode" | "decode" | "missing" | "read" | "write";
    /** A description of the failed operation. */
    readonly message: string;
    /** The original schema error or native exception, when present. */
    readonly cause?: unknown;
}> {
}
export interface WebSocket {
    readonly ws: RawWebSocket;
    send(data: string | Uint8Array): Effect.Effect<void>;
    close(code: number, reason: string): Effect.Effect<void>;
    /**
     * Encode an application value and persist the encoded representation alongside
     * this socket. The native structured-clone and serialized-size limits apply;
     * schema validation does not guarantee that the encoded value is cloneable.
     * Requires only the codec's encoding services. Does not close the socket.
     *
     * @example
     * ```ts
     * yield* socket.setAttachment(Schema.NumberFromString, 42);
     * // The unchecked deserializeAttachment() now returns "42".
     * ```
     */
    setAttachment<S extends Schema.Constraint>(schema: S, value: NoInfer<S["Type"]>): Effect.Effect<void, WebSocketAttachmentError, S["EncodingServices"]>;
    /**
     * Read and decode an application attachment, including after hibernation.
     * A nullish native value fails with reason `missing`; other values are decoded
     * from the codec's encoded side. Requires only its decoding services.
     * No envelope or schema version is added, so unchecked attachments interoperate
     * and applications own migrations and invalid-attachment policy.
     *
     * @example
     * ```ts
     * const count = yield* socket.getAttachment(Schema.NumberFromString);
     * // count is a number, not the stored string.
     * ```
     */
    getAttachment<S extends Schema.Constraint>(schema: S): Effect.Effect<S["Type"], WebSocketAttachmentError, S["DecodingServices"]>;
    serializeAttachment<T>(value: T): void;
    deserializeAttachment<T>(): T | null;
}
export declare const fromWebSocket: (ws: RawWebSocket) => WebSocket;
/**
 * A state that can accept a hibernatable WebSocket. `R` is what accepting
 * requires, so it reaches the caller of {@link acceptWebSocketPair}.
 */
export interface WebSocketAcceptor<R = never> {
    acceptWebSocket(ws: WebSocket, tags?: string[]): Effect.Effect<void, never, R>;
}
/**
 * Accept a hibernatable WebSocket on a workerd-style `WebSocketPair` and
 * build the `101 Switching Protocols` response for it.
 */
export declare const acceptWebSocketPair: <R>(state: WebSocketAcceptor<R>, tags?: readonly string[] | undefined) => Effect.Effect<readonly [HttpServerResponse.HttpServerResponse, WebSocket], never, R>;
export {};
//# sourceMappingURL=WebSocket.d.ts.map