import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
    readonly Code: any;
    readonly RequiredParameters: any;
    readonly MutuallyExclusiveParameters: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly Code: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Code: any;
    readonly ResourceType: any;
    readonly ResourceIds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type ExecutionRoleArn = string;
export type PolicyDescription = string;
export type SettablePolicyStateValues = "ENABLED" | "DISABLED" | (string & {});
export type PolicyTypeValues = "EBS_SNAPSHOT_MANAGEMENT" | "IMAGE_MANAGEMENT" | "EVENT_BASED_POLICY" | (string & {});
export type ResourceTypeValues = "VOLUME" | "INSTANCE" | (string & {});
export type ResourceTypeValuesList = ResourceTypeValues[];
export type ResourceLocationValues = "CLOUD" | "OUTPOST" | "LOCAL_ZONE" | (string & {});
export type ResourceLocationList = ResourceLocationValues[];
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TargetTagList = Tag[];
export type ScheduleName = string;
export type CopyTags = boolean;
export type TagsToAddList = Tag[];
export type VariableTagsList = Tag[];
export type LocationValues = "CLOUD" | "OUTPOST_LOCAL" | "LOCAL_ZONE" | (string & {});
export type Interval = number;
export type IntervalUnitValues = "HOURS" | (string & {});
export type TimesList = string[];
export type CronExpression = string;
export type StageValues = "PRE" | "POST" | (string & {});
export type StagesList = StageValues[];
export type ExecutionHandlerServiceValues = "AWS_SYSTEMS_MANAGER" | (string & {});
export type ExecutionHandler = string;
export type ExecuteOperationOnScriptFailure = boolean;
export type ScriptExecutionTimeout = number;
export type ScriptMaximumRetryCount = number;
export interface Script {
    Stages?: StageValues[] | undefined;
    ExecutionHandlerService?: ExecutionHandlerServiceValues | undefined;
    ExecutionHandler?: string | undefined;
    ExecuteOperationOnScriptFailure?: boolean | undefined;
    ExecutionTimeout?: number | undefined;
    MaximumRetryCount?: number | undefined;
}
export type ScriptsList = Script[];
export interface CreateRule {
    Location?: LocationValues | undefined;
    Interval?: number | undefined;
    IntervalUnit?: IntervalUnitValues | undefined;
    Times?: string[] | undefined;
    CronExpression?: string | undefined;
    Scripts?: Script[] | undefined;
}
export type StandardTierRetainRuleCount = number;
export type StandardTierRetainRuleInterval = number;
export type RetentionIntervalUnitValues = "DAYS" | "WEEKS" | "MONTHS" | "YEARS" | (string & {});
export interface RetainRule {
    Count?: number | undefined;
    Interval?: number | undefined;
    IntervalUnit?: RetentionIntervalUnitValues | undefined;
}
export type Count = number;
export type AvailabilityZone = string;
export type AvailabilityZoneList = string[];
export type AvailabilityZoneId = string;
export type AvailabilityZoneIdList = string[];
export interface FastRestoreRule {
    Count?: number | undefined;
    Interval?: number | undefined;
    IntervalUnit?: RetentionIntervalUnitValues | undefined;
    AvailabilityZones?: string[] | undefined;
    AvailabilityZoneIds?: string[] | undefined;
}
export type TargetRegion = string;
export type Target = string;
export type Encrypted = boolean;
export type CmkArn = string;
export type CopyTagsNullable = boolean;
export interface CrossRegionCopyRetainRule {
    Interval?: number | undefined;
    IntervalUnit?: RetentionIntervalUnitValues | undefined;
}
export interface CrossRegionCopyDeprecateRule {
    Interval?: number | undefined;
    IntervalUnit?: RetentionIntervalUnitValues | undefined;
}
export interface CrossRegionCopyRule {
    TargetRegion?: string | undefined;
    Target?: string | undefined;
    Encrypted?: boolean | undefined;
    CmkArn?: string | undefined;
    CopyTags?: boolean | undefined;
    RetainRule?: CrossRegionCopyRetainRule | undefined;
    DeprecateRule?: CrossRegionCopyDeprecateRule | undefined;
}
export type CrossRegionCopyRules = CrossRegionCopyRule[];
export type AwsAccountId = string;
export type ShareTargetAccountList = string[];
export interface ShareRule {
    TargetAccounts?: string[] | undefined;
    UnshareInterval?: number | undefined;
    UnshareIntervalUnit?: RetentionIntervalUnitValues | undefined;
}
export type ShareRules = ShareRule[];
export interface DeprecateRule {
    Count?: number | undefined;
    Interval?: number | undefined;
    IntervalUnit?: RetentionIntervalUnitValues | undefined;
}
export interface RetentionArchiveTier {
    Count?: number | undefined;
    Interval?: number | undefined;
    IntervalUnit?: RetentionIntervalUnitValues | undefined;
}
export interface ArchiveRetainRule {
    RetentionArchiveTier?: RetentionArchiveTier | undefined;
}
export interface ArchiveRule {
    RetainRule?: ArchiveRetainRule | undefined;
}
export interface Schedule {
    Name?: string | undefined;
    CopyTags?: boolean | undefined;
    TagsToAdd?: Tag[] | undefined;
    VariableTags?: Tag[] | undefined;
    CreateRule?: CreateRule | undefined;
    RetainRule?: RetainRule | undefined;
    FastRestoreRule?: FastRestoreRule | undefined;
    CrossRegionCopyRules?: CrossRegionCopyRule[] | undefined;
    ShareRules?: ShareRule[] | undefined;
    DeprecateRule?: DeprecateRule | undefined;
    ArchiveRule?: ArchiveRule | undefined;
}
export type ScheduleList = Schedule[];
export type ExcludeBootVolume = boolean;
export type NoReboot = boolean;
export type ExcludeDataVolumeTagList = Tag[];
export interface Parameters {
    ExcludeBootVolume?: boolean | undefined;
    NoReboot?: boolean | undefined;
    ExcludeDataVolumeTags?: Tag[] | undefined;
}
export type EventSourceValues = "MANAGED_CWE" | (string & {});
export type EventTypeValues = "shareSnapshot" | (string & {});
export type SnapshotOwnerList = string[];
export type DescriptionRegex = string;
export interface EventParameters {
    EventType?: EventTypeValues | undefined;
    SnapshotOwner?: string[] | undefined;
    DescriptionRegex?: string | undefined;
}
export interface EventSource {
    Type?: EventSourceValues | undefined;
    Parameters?: EventParameters | undefined;
}
export type ActionName = string;
export interface EncryptionConfiguration {
    Encrypted?: boolean | undefined;
    CmkArn?: string | undefined;
}
export interface CrossRegionCopyAction {
    Target?: string | undefined;
    EncryptionConfiguration?: EncryptionConfiguration | undefined;
    RetainRule?: CrossRegionCopyRetainRule | undefined;
}
export type CrossRegionCopyActionList = CrossRegionCopyAction[];
export interface Action {
    Name?: string | undefined;
    CrossRegionCopy?: CrossRegionCopyAction[] | undefined;
}
export type ActionList = Action[];
export type PolicyLanguageValues = "SIMPLIFIED" | "STANDARD" | (string & {});
export type CreateInterval = number;
export type RetainInterval = number;
export interface CrossRegionCopyTarget {
    TargetRegion?: string | undefined;
}
export type CrossRegionCopyTargetList = CrossRegionCopyTarget[];
export type ExtendDeletion = boolean;
export type ExcludeBootVolumes = boolean;
export type VolumeTypeValues = string;
export type ExcludeVolumeTypesList = string[];
export type ExcludeTagsList = Tag[];
export interface Exclusions {
    ExcludeBootVolumes?: boolean | undefined;
    ExcludeVolumeTypes?: string[] | undefined;
    ExcludeTags?: Tag[] | undefined;
}
export interface PolicyDetails {
    PolicyType?: PolicyTypeValues | undefined;
    ResourceTypes?: ResourceTypeValues[] | undefined;
    ResourceLocations?: ResourceLocationValues[] | undefined;
    TargetTags?: Tag[] | undefined;
    Schedules?: Schedule[] | undefined;
    Parameters?: Parameters | undefined;
    EventSource?: EventSource | undefined;
    Actions?: Action[] | undefined;
    PolicyLanguage?: PolicyLanguageValues | undefined;
    ResourceType?: ResourceTypeValues | undefined;
    CreateInterval?: number | undefined;
    RetainInterval?: number | undefined;
    CopyTags?: boolean | undefined;
    CrossRegionCopyTargets?: CrossRegionCopyTarget[] | undefined;
    ExtendDeletion?: boolean | undefined;
    Exclusions?: Exclusions | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type DefaultPolicyTypeValues = "VOLUME" | "INSTANCE" | (string & {});
export interface CreateLifecyclePolicyRequest {
    ExecutionRoleArn?: string | undefined;
    Description?: string | undefined;
    State?: SettablePolicyStateValues | undefined;
    PolicyDetails?: PolicyDetails | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    DefaultPolicy?: DefaultPolicyTypeValues | undefined;
    CreateInterval?: number | undefined;
    RetainInterval?: number | undefined;
    CopyTags?: boolean | undefined;
    ExtendDeletion?: boolean | undefined;
    CrossRegionCopyTargets?: CrossRegionCopyTarget[] | undefined;
    Exclusions?: Exclusions | undefined;
}
export type PolicyId = string;
export interface CreateLifecyclePolicyResponse {
    PolicyId?: string | undefined;
}
export interface DeleteLifecyclePolicyRequest {
    PolicyId: string;
}
export interface DeleteLifecyclePolicyResponse {
}
export type PolicyIdList = string[];
export type GettablePolicyStateValues = "ENABLED" | "DISABLED" | "ERROR" | (string & {});
export type TagFilter = string;
export type TargetTagsFilterList = string[];
export type TagsToAddFilterList = string[];
export type DefaultPoliciesTypeValues = "VOLUME" | "INSTANCE" | "ALL" | (string & {});
export interface GetLifecyclePoliciesRequest {
    PolicyIds?: string[] | undefined;
    State?: GettablePolicyStateValues | undefined;
    ResourceTypes?: ResourceTypeValues[] | undefined;
    TargetTags?: string[] | undefined;
    TagsToAdd?: string[] | undefined;
    DefaultPolicyType?: DefaultPoliciesTypeValues | undefined;
}
export type DefaultPolicy = boolean;
export interface LifecyclePolicySummary {
    PolicyId?: string | undefined;
    Description?: string | undefined;
    State?: GettablePolicyStateValues | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    PolicyType?: PolicyTypeValues | undefined;
    DefaultPolicy?: boolean | undefined;
}
export type LifecyclePolicySummaryList = LifecyclePolicySummary[];
export interface GetLifecyclePoliciesResponse {
    Policies?: LifecyclePolicySummary[] | undefined;
}
export interface GetLifecyclePolicyRequest {
    PolicyId: string;
}
export type StatusMessage = string;
export type PolicyArn = string;
export interface LifecyclePolicy {
    PolicyId?: string | undefined;
    Description?: string | undefined;
    State?: GettablePolicyStateValues | undefined;
    StatusMessage?: string | undefined;
    ExecutionRoleArn?: string | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
    PolicyDetails?: PolicyDetails | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    PolicyArn?: string | undefined;
    DefaultPolicy?: boolean | undefined;
}
export interface GetLifecyclePolicyResponse {
    Policy?: (LifecyclePolicy & {
        PolicyDetails: PolicyDetails & {
            TargetTags: (Tag & {
                Key: string;
                Value: string;
            })[];
            Schedules: (Schedule & {
                TagsToAdd: (Tag & {
                    Key: string;
                    Value: string;
                })[];
                VariableTags: (Tag & {
                    Key: string;
                    Value: string;
                })[];
                CreateRule: CreateRule & {
                    Scripts: (Script & {
                        ExecutionHandler: ExecutionHandler;
                    })[];
                };
                CrossRegionCopyRules: (CrossRegionCopyRule & {
                    Encrypted: Encrypted;
                })[];
                ShareRules: (ShareRule & {
                    TargetAccounts: ShareTargetAccountList;
                })[];
                ArchiveRule: ArchiveRule & {
                    RetainRule: ArchiveRetainRule & {
                        RetentionArchiveTier: RetentionArchiveTier;
                    };
                };
            })[];
            Parameters: Parameters & {
                ExcludeDataVolumeTags: (Tag & {
                    Key: string;
                    Value: string;
                })[];
            };
            EventSource: EventSource & {
                Type: EventSourceValues;
                Parameters: EventParameters & {
                    EventType: EventTypeValues;
                    SnapshotOwner: SnapshotOwnerList;
                    DescriptionRegex: DescriptionRegex;
                };
            };
            Actions: (Action & {
                Name: ActionName;
                CrossRegionCopy: (CrossRegionCopyAction & {
                    Target: Target;
                    EncryptionConfiguration: EncryptionConfiguration & {
                        Encrypted: Encrypted;
                    };
                })[];
            })[];
            Exclusions: Exclusions & {
                ExcludeTags: (Tag & {
                    Key: string;
                    Value: string;
                })[];
            };
        };
    }) | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateLifecyclePolicyRequest {
    PolicyId: string;
    ExecutionRoleArn?: string | undefined;
    State?: SettablePolicyStateValues | undefined;
    Description?: string | undefined;
    PolicyDetails?: PolicyDetails | undefined;
    CreateInterval?: number | undefined;
    RetainInterval?: number | undefined;
    CopyTags?: boolean | undefined;
    ExtendDeletion?: boolean | undefined;
    CrossRegionCopyTargets?: CrossRegionCopyTarget[] | undefined;
    Exclusions?: Exclusions | undefined;
}
export interface UpdateLifecyclePolicyResponse {
}
export type ErrorMessage = string;
export type ErrorCode = string;
export type Parameter = string;
export type ParameterList = string[];
export type CreateLifecyclePolicyError = InternalServerException | InvalidRequestException | LimitExceededException | CommonErrors;
/**
 * Creates an Amazon Data Lifecycle Manager lifecycle policy. Amazon Data Lifecycle Manager supports the following policy types:
 *
 * - Custom EBS snapshot policy
 *
 * - Custom EBS-backed AMI policy
 *
 * - Cross-account copy event policy
 *
 * - Default policy for EBS snapshots
 *
 * - Default policy for EBS-backed AMIs
 *
 * For more information, see
 * Default policies vs custom policies.
 *
 * If you create a default policy, you can specify the request parameters either in
 * the request body, or in the PolicyDetails request structure, but not both.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest & RegionInput, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = InternalServerException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified lifecycle policy and halts the automated operations that the
 * policy specified.
 *
 * For more information about deleting a policy, see Delete lifecycle
 * policies.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest & RegionInput, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePoliciesError = InternalServerException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Gets summary information about all or the specified data lifecycle policies.
 *
 * To get complete information about a policy, use GetLifecyclePolicy.
 */
export declare const getLifecyclePolicies: API.OperationMethod<GetLifecyclePoliciesRequest & RegionInput, GetLifecyclePoliciesResponse, GetLifecyclePoliciesError, Credentials | HttpClient.HttpClient>;
export type GetLifecyclePolicyError = InternalServerException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Gets detailed information about the specified lifecycle policy.
 */
export declare const getLifecyclePolicy: API.OperationMethod<GetLifecyclePolicyRequest & RegionInput, GetLifecyclePolicyResponse, GetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = InternalServerException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified lifecycle policy.
 *
 * For more information about updating a policy, see Modify lifecycle
 * policies.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest & RegionInput, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=dlm.d.ts.map