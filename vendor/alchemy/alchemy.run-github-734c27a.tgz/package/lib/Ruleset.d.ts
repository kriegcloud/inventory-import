import * as Repos from "@distilled.cloud/github/repos";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface RulesetProps {
    /**
     * Repository owner — a user or organization login.
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Ruleset name. The name is displayed in the GitHub UI and can be updated.
     */
    name: string;
    /**
     * The enforcement level of the ruleset. Can be `disabled`, `active`, or
     * `evaluate` (log-only mode).
     * @default "active"
     */
    enforcement?: "disabled" | "active" | "evaluate";
    /**
     * Whether the ruleset targets branches or tags.
     * @default "branch"
     */
    target?: "branch" | "tag";
    /**
     * Conditions for targeting refs. When omitted, applies to all refs of the
     * target type.
     */
    conditions?: {
        /**
         * Ref patterns to include (e.g. `["refs/heads/main", "refs/heads/release/*"]`).
         * Supports glob patterns.
         */
        include?: string[];
        /**
         * Ref patterns to exclude (e.g. `["refs/heads/dev/*"]`).
         * Supports glob patterns.
         */
        exclude?: string[];
    };
    /**
     * Actors allowed to bypass the ruleset. Omit to allow no bypasses.
     */
    bypassActors?: Array<{
        /**
         * The type of actor that can bypass the ruleset.
         */
        actorType: "RepositoryRole" | "Team" | "Integration" | "OrganizationAdmin";
        /**
         * The ID of the actor (role ID, team ID, or integration ID).
         * RepositoryRole IDs are 2 for write, 4 for maintain, and 5 for admin.
         */
        actorId?: number;
        /**
         * Whether the actor can always bypass or only through pull requests.
         * @default "always"
         */
        bypassMode?: "always" | "pull_request";
    }>;
    /**
     * Require status checks to pass before merging.
     */
    requiredStatusChecks?: {
        /**
         * Status checks that must pass. Each entry is a context name or
         * integration ID.
         */
        checks: Array<{
            /**
             * The status check context name.
             */
            context: string;
            /**
             * Optional integration ID.
             */
            integrationId?: number;
        }>;
        /**
         * Whether to require branches to be up to date before merging.
         * @default false
         */
        strictRequiredStatusChecksPolicy?: boolean;
    };
    /**
     * Require commits to be signed.
     */
    requiredSignatures?: boolean;
    /**
     * Require pull request before merging.
     */
    pullRequest?: {
        /**
         * Number of required approving reviews.
         */
        requiredApprovingReviewCount?: number;
        /**
         * Dismiss stale reviews when new commits are pushed.
         */
        dismissStaleReviewsOnPush?: boolean;
        /**
         * Require review from code owners.
         */
        requireCodeOwnerReview?: boolean;
        /**
         * Require approval of the most recent reviewable push.
         */
        requireLastPushApproval?: boolean;
        /**
         * Required review thread resolution.
         */
        requiredReviewThreadResolution?: boolean;
        /**
         * Merge methods allowed for pull requests. GitHub allows all three when omitted.
         */
        allowedMergeMethods?: Array<"merge" | "squash" | "rebase">;
        /**
         * Require another approval for changes pushed by someone other than the commit author.
         * @default true
         */
        requireExtraApprovalForUnattributedChanges?: boolean;
    };
    /**
     * Prevent creation of matching refs.
     */
    creation?: boolean;
    /**
     * Prevent updates to matching refs.
     */
    update?: boolean;
    /**
     * Prevent deletion of matching refs.
     */
    deletion?: boolean;
    /**
     * Require linear history.
     */
    requiredLinearHistory?: boolean;
    /**
     * Prevent force pushes.
     */
    nonFastForward?: boolean;
    /**
     * Require pull requests to merge through a merge queue. Only applies to
     * branch rulesets in organization-owned repositories.
     */
    mergeQueue?: {
        /**
         * Method used to merge the queued pull requests.
         * @default "MERGE"
         */
        mergeMethod?: "MERGE" | "SQUASH" | "REBASE";
        /**
         * `ALLGREEN` requires every entry's checks to pass; `HEADGREEN` only
         * requires the checks of the group's head commit.
         * @default "ALLGREEN"
         */
        groupingStrategy?: "ALLGREEN" | "HEADGREEN";
        /**
         * Maximum number of queued pull requests building at the same time.
         * @default 5
         */
        maxEntriesToBuild?: number;
        /**
         * Minimum number of pull requests merged together in a group.
         * @default 1
         */
        minEntriesToMerge?: number;
        /**
         * Maximum number of pull requests merged together in a group.
         * @default 5
         */
        maxEntriesToMerge?: number;
        /**
         * Minutes to wait for `minEntriesToMerge` pull requests after the first
         * one is queued before merging a smaller group.
         * @default 5
         */
        minEntriesToMergeWaitMinutes?: number;
        /**
         * Minutes to wait for a required status check before treating it as failed.
         * @default 60
         */
        checkResponseTimeoutMinutes?: number;
    };
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface Ruleset extends Resource<"GitHub.Ruleset", RulesetProps, {
    /**
     * Numeric GitHub ruleset ID.
     */
    rulesetId: number;
    /**
     * GraphQL node ID of the ruleset, when returned by GitHub.
     */
    nodeId: string | undefined;
    /**
     * The ruleset name.
     */
    name: string;
    /**
     * ISO-8601 timestamp of when the ruleset was created.
     */
    createdAt: string | undefined;
    /**
     * ISO-8601 timestamp of the last update.
     */
    updatedAt: string | undefined;
}, never, GitHub.Providers, RulesetLookup> {
}
/**
 * Props for {@link Ruleset.lookup}: find a repository ruleset this
 * stack doesn't manage by its repository and id.
 */
export interface RulesetLookup {
    /** Repository owner (user or organization). */
    owner: string;
    /** Repository name. */
    repository: string;
    /** Ruleset id. */
    rulesetId: number;
    /**
     * GitHub Enterprise Server URL.
     * @default `https://github.com`
     */
    baseUrl?: string;
}
/**
 * A GitHub repository ruleset.
 *
 * `Ruleset` manages branch and tag protection rules at the repository level.
 * Rulesets replace the legacy branch protection API with a more flexible
 * system that can target multiple branches or tags with a single ruleset.
 *
 * Rulesets default to **retain** on removal — destroying the stack does NOT
 * delete the ruleset on GitHub, protecting production branches from
 * accidental removal. Opt in to actual deletion by wrapping the resource in
 * {@link destroy}() from `alchemy/RemovalPolicy`.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope, or repository Administration write permission for a
 * fine-grained token. Ruleset deletion does not require `delete_repo`.
 *
 * ### Creating a Ruleset
 * **Example:** Protect Main Branch
 * ```typescript
 * yield* GitHub.Ruleset("main-protection", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "main protection",
 *   target: "branch",
 *   conditions: {
 *     include: ["refs/heads/main"],
 *   },
 *   nonFastForward: true,
 *   deletion: true,
 *   requiredLinearHistory: true,
 * })
 * ```
 *
 * **Example:** Require PR Reviews
 * ```typescript
 * yield* GitHub.Ruleset("pr-reviews", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "require reviews",
 *   target: "branch",
 *   conditions: {
 *     include: ["refs/heads/main", "refs/heads/release/*"],
 *   },
 *   pullRequest: {
 *     requiredApprovingReviewCount: 2,
 *     requireCodeOwnerReview: true,
 *     dismissStaleReviewsOnPush: true,
 *     requiredReviewThreadResolution: true,
 *   },
 * })
 * ```
 *
 * ### Status Checks
 * **Example:** Require CI to Pass
 * ```typescript
 * yield* GitHub.Ruleset("ci-checks", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "CI required",
 *   target: "branch",
 *   conditions: {
 *     include: ["refs/heads/main"],
 *   },
 *   requiredStatusChecks: {
 *     checks: [
 *       { context: "ci/test" },
 *       { context: "ci/lint" },
 *     ],
 *     strictRequiredStatusChecksPolicy: true,
 *   },
 * })
 * ```
 *
 * ### Merge Queue
 * GitHub only supports merge queues on branch rulesets in
 * organization-owned repositories.
 *
 * **Example:** Merge Through a Squash Merge Queue
 * ```typescript
 * yield* GitHub.Ruleset("merge-queue", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "Merge queue",
 *   conditions: {
 *     include: ["~DEFAULT_BRANCH"],
 *   },
 *   mergeQueue: {
 *     mergeMethod: "SQUASH",
 *     groupingStrategy: "ALLGREEN",
 *     maxEntriesToBuild: 2,
 *     maxEntriesToMerge: 1,
 *     minEntriesToMergeWaitMinutes: 1,
 *   },
 * })
 * ```
 *
 * ### Bypass Actors
 * **Example:** Allow Admins to Bypass
 * ```typescript
 * yield* GitHub.Ruleset("protected-with-bypass", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "protected with bypass",
 *   target: "branch",
 *   conditions: {
 *     include: ["refs/heads/main"],
 *   },
 *   bypassActors: [
 *     { actorType: "RepositoryRole", actorId: 5 },
 *   ],
 *   nonFastForward: true,
 * })
 * ```
 *
 * ### Adopting an Existing Ruleset
 * Ruleset names are unique per repository. A ruleset that already exists
 * with the same name is foreign until you opt in with `adopt(true)` or
 * `--adopt`; adoption then converges it to the declared props in place.
 *
 * **Example:** Take over a ruleset created in the GitHub UI
 * ```typescript
 * import { adopt } from "alchemy/AdoptPolicy";
 *
 * yield* GitHub.Ruleset("main-protection", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "main protection",
 *   conditions: {
 *     include: ["~DEFAULT_BRANCH"],
 *   },
 *   deletion: true,
 *   nonFastForward: true,
 * }).pipe(adopt(true))
 * ```
 *
 * ### Looking up an existing ruleset
 * `Ruleset.lookup` references a ruleset Alchemy doesn't manage (created on
 * GitHub or by another stack). It is read during plan/deploy, never created,
 * updated or deleted.
 *
 * **Example:** Reference an existing ruleset
 * ```typescript
 * const main = GitHub.Ruleset.lookup({ owner: "alchemy-run", repository: "alchemy", rulesetId: 1234 });
 * ```
 *
 * @resource
 * @product Repository
 */
export declare const Ruleset: import("alchemy/Resource").ResourceClass<Ruleset>;
export declare const RulesetProvider: () => import("effect/Layer").Layer<Provider.Provider<Ruleset>, never, Repos.GithubOpContext>;
//# sourceMappingURL=Ruleset.d.ts.map