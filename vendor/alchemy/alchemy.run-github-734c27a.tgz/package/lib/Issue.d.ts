import * as Issues from "@distilled.cloud/github/issues";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface IssueProps {
    /**
     * Repository owner (user or organization).
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Issue title.
     */
    title: string;
    /**
     * Issue body (supports GitHub Markdown).
     *
     * The body is automatically dedented, so you can use indented template
     * literals without worrying about leading whitespace. Accepts
     * `Output<string>` at the call site via `Output.interpolate` to embed
     * resource attributes that are not yet resolved.
     */
    body?: string;
    /**
     * State of the issue. Use "open" to reopen a closed issue or "closed" to
     * close an open issue.
     * @default "open"
     */
    state?: "open" | "closed";
    /**
     * Labels to attach to the issue. The provided list fully replaces any
     * existing labels.
     */
    labels?: string[];
    /**
     * Assignees (user logins) to assign to the issue. The provided list fully
     * replaces existing assignees.
     */
    assignees?: string[];
    /**
     * Milestone number to assign to the issue. Use `null` to remove milestone.
     */
    milestone?: number | null;
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface Issue extends Resource<"GitHub.Issue", IssueProps, {
    /**
     * The numeric ID of the issue in GitHub.
     */
    issueNumber: number;
    /**
     * GraphQL node ID of the issue.
     */
    nodeId: string;
    /**
     * URL to view the issue in a browser.
     */
    htmlUrl: string;
    /**
     * State of the issue (open or closed).
     */
    state: "open" | "closed";
    /**
     * ISO-8601 timestamp of when the issue was created.
     */
    createdAt: string;
    /**
     * ISO-8601 timestamp of the last update.
     */
    updatedAt: string;
}, never, GitHub.Providers, IssueLookup> {
}
/**
 * Props for {@link Issue.lookup}: find an issue this stack
 * doesn't manage by its repository and number.
 */
export interface IssueLookup {
    /** Repository owner (user or organization). */
    owner: string;
    /** Repository name. */
    repository: string;
    /** Issue number. */
    number: number;
    /**
     * GitHub Enterprise Server URL.
     * @default `https://github.com`
     */
    baseUrl?: string;
}
/**
 * A GitHub repository issue.
 *
 * `Issue` manages the lifecycle of a single issue in a repository. Issues are
 * created on the first deploy and updated in place on subsequent deploys when
 * properties change. By default, issues are retained on destruction to preserve
 * discussion history. Pipe the resource through `destroy()` to close the issue
 * on destruction instead; its discussion remains on GitHub.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope for private repositories or `public_repo` for public ones.
 *
 * ### Creating Issues
 * **Example:** Create a Basic Issue
 * ```typescript
 * const issue = yield* GitHub.Issue("bug-report", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Bug: Application crashes on startup",
 *   body: "## Description\n\nThe application crashes when...",
 * })
 * ```
 *
 * **Example:** Issue with Labels and Assignees
 * ```typescript
 * const issue = yield* GitHub.Issue("feature-request", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Feature: Add dark mode",
 *   body: "Users have requested...",
 *   labels: ["enhancement", "ui"],
 *   assignees: ["developer1"],
 * })
 * ```
 *
 * ### Updating Issues
 * Deploy with the same logical ID and different properties to update the
 * existing issue in place rather than creating a new one.
 *
 * **Example:** Update Issue State
 * ```typescript
 * const issue = yield* GitHub.Issue("resolved-bug", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Bug: Application crashes on startup",
 *   body: "This has been resolved.",
 *   state: "closed",
 * })
 * ```
 *
 * ### Issue with Milestone
 * **Example:** Assign to Milestone
 * ```typescript
 * const issue = yield* GitHub.Issue("v1-task", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Implement authentication",
 *   milestone: 1,
 * })
 * ```
 *
 * ### Tracking Infrastructure Changes
 * A common pattern is creating issues to track infrastructure changes or
 * deployment status.
 *
 * **Example:** Infrastructure Status Issue
 * ```typescript
 * yield* GitHub.Issue("infra-status", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   title: "Infrastructure Status",
 *   body: Output.interpolate`
 *     ## Current Status
 *
 *     **Database:** ${database.endpoint}
 *     **Cache:** ${cache.endpoint}
 *   `,
 *   labels: ["infrastructure"],
 * })
 * ```
 *
 * ### Looking up an existing issue
 * `Issue.lookup` references an issue Alchemy doesn't manage (created on
 * GitHub or by another stack). It is read during plan/deploy, never created,
 * updated or deleted.
 * A pull request's number finds nothing: use `PullRequest.lookup`.
 *
 * **Example:** Comment on an existing issue
 * ```typescript
 * const issue = GitHub.Issue.lookup({ owner: "alchemy-run", repository: "alchemy", number: 42 });
 * ```
 *
 * @resource
 * @product Issue
 */
export declare const Issue: import("alchemy/Resource").ResourceClass<Issue>;
export declare const IssueProvider: () => import("effect/Layer").Layer<Provider.Provider<Issue>, never, Issues.GithubOpContext>;
//# sourceMappingURL=Issue.d.ts.map