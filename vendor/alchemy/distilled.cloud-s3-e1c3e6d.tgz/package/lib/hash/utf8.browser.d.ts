/**
 * UTF-8 conversion for browsers, with `TextEncoder` instead of `Buffer`.
 * Selected through the package's `#utf8` import.
 */
export declare function toUint8Array(data: string | ArrayBuffer | ArrayBufferView): Uint8Array;
//# sourceMappingURL=utf8.browser.d.ts.map