import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const CodeValidationException_base: S.TaggedErrorClass<"CodeValidationException", {
    readonly message: any;
}>;
export declare class CodeValidationException extends /*@__PURE__*/ CodeValidationException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const InvalidApplicationConfigurationException_base: S.TaggedErrorClass<"InvalidApplicationConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidApplicationConfigurationException extends /*@__PURE__*/ InvalidApplicationConfigurationException_base {
}
declare const InvalidArgumentException_base: S.TaggedErrorClass<"InvalidArgumentException", {
    readonly message: any;
}>;
export declare class InvalidArgumentException extends /*@__PURE__*/ InvalidArgumentException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}>;
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceProvisionedThroughputExceededException_base: S.TaggedErrorClass<"ResourceProvisionedThroughputExceededException", {
    readonly message: any;
}>;
export declare class ResourceProvisionedThroughputExceededException extends /*@__PURE__*/ ResourceProvisionedThroughputExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnableToDetectSchemaException_base: S.TaggedErrorClass<"UnableToDetectSchemaException", {
    readonly message: any;
    readonly RawInputRecords: any;
    readonly ProcessedInputRecords: any;
}>;
export declare class UnableToDetectSchemaException extends /*@__PURE__*/ UnableToDetectSchemaException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type ApplicationName = string;
export type ApplicationVersionId = number;
export type LogStreamARN = string;
export type RoleARN = string;
export interface CloudWatchLoggingOption {
    LogStreamARN: string;
    RoleARN: string;
}
export interface AddApplicationCloudWatchLoggingOptionRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    CloudWatchLoggingOption: CloudWatchLoggingOption;
}
export interface AddApplicationCloudWatchLoggingOptionResponse {
}
export type InAppStreamName = string;
export type ResourceARN = string;
export interface InputLambdaProcessor {
    ResourceARN: string;
    RoleARN: string;
}
export interface InputProcessingConfiguration {
    InputLambdaProcessor: InputLambdaProcessor;
}
export interface KinesisStreamsInput {
    ResourceARN: string;
    RoleARN: string;
}
export interface KinesisFirehoseInput {
    ResourceARN: string;
    RoleARN: string;
}
export type InputParallelismCount = number;
export interface InputParallelism {
    Count?: number | undefined;
}
export type RecordFormatType = "JSON" | "CSV" | (string & {});
export type RecordRowPath = string;
export interface JSONMappingParameters {
    RecordRowPath: string;
}
export type RecordRowDelimiter = string;
export type RecordColumnDelimiter = string;
export interface CSVMappingParameters {
    RecordRowDelimiter: string;
    RecordColumnDelimiter: string;
}
export interface MappingParameters {
    JSONMappingParameters?: JSONMappingParameters | undefined;
    CSVMappingParameters?: CSVMappingParameters | undefined;
}
export interface RecordFormat {
    RecordFormatType: RecordFormatType;
    MappingParameters?: MappingParameters | undefined;
}
export type RecordEncoding = string;
export type RecordColumnName = string;
export type RecordColumnMapping = string;
export type RecordColumnSqlType = string;
export interface RecordColumn {
    Name: string;
    Mapping?: string | undefined;
    SqlType: string;
}
export type RecordColumns = RecordColumn[];
export interface SourceSchema {
    RecordFormat: RecordFormat;
    RecordEncoding?: string | undefined;
    RecordColumns: RecordColumn[];
}
export interface Input {
    NamePrefix: string;
    InputProcessingConfiguration?: InputProcessingConfiguration | undefined;
    KinesisStreamsInput?: KinesisStreamsInput | undefined;
    KinesisFirehoseInput?: KinesisFirehoseInput | undefined;
    InputParallelism?: InputParallelism | undefined;
    InputSchema: SourceSchema;
}
export interface AddApplicationInputRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    Input: Input;
}
export interface AddApplicationInputResponse {
}
export type Id = string;
export interface AddApplicationInputProcessingConfigurationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    InputId: string;
    InputProcessingConfiguration: InputProcessingConfiguration;
}
export interface AddApplicationInputProcessingConfigurationResponse {
}
export interface KinesisStreamsOutput {
    ResourceARN: string;
    RoleARN: string;
}
export interface KinesisFirehoseOutput {
    ResourceARN: string;
    RoleARN: string;
}
export interface LambdaOutput {
    ResourceARN: string;
    RoleARN: string;
}
export interface DestinationSchema {
    RecordFormatType: RecordFormatType;
}
export interface Output {
    Name: string;
    KinesisStreamsOutput?: KinesisStreamsOutput | undefined;
    KinesisFirehoseOutput?: KinesisFirehoseOutput | undefined;
    LambdaOutput?: LambdaOutput | undefined;
    DestinationSchema: DestinationSchema;
}
export interface AddApplicationOutputRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    Output: Output;
}
export interface AddApplicationOutputResponse {
}
export type InAppTableName = string;
export type BucketARN = string;
export type FileKey = string;
export interface S3ReferenceDataSource {
    BucketARN: string;
    FileKey: string;
    ReferenceRoleARN: string;
}
export interface ReferenceDataSource {
    TableName: string;
    S3ReferenceDataSource?: S3ReferenceDataSource | undefined;
    ReferenceSchema: SourceSchema;
}
export interface AddApplicationReferenceDataSourceRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    ReferenceDataSource: ReferenceDataSource;
}
export interface AddApplicationReferenceDataSourceResponse {
}
export type ApplicationDescription = string;
export type Inputs = Input[];
export type Outputs = Output[];
export type CloudWatchLoggingOptions = CloudWatchLoggingOption[];
export type ApplicationCode = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value?: string | undefined;
}
export type Tags = Tag[];
export interface CreateApplicationRequest {
    ApplicationName: string;
    ApplicationDescription?: string | undefined;
    Inputs?: Input[] | undefined;
    Outputs?: Output[] | undefined;
    CloudWatchLoggingOptions?: CloudWatchLoggingOption[] | undefined;
    ApplicationCode?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ApplicationStatus = "DELETING" | "STARTING" | "STOPPING" | "READY" | "RUNNING" | "UPDATING" | (string & {});
export interface ApplicationSummary {
    ApplicationName: string;
    ApplicationARN: string;
    ApplicationStatus: ApplicationStatus;
}
export interface CreateApplicationResponse {
    ApplicationSummary: ApplicationSummary;
}
export interface DeleteApplicationRequest {
    ApplicationName: string;
    CreateTimestamp: Date;
}
export interface DeleteApplicationResponse {
}
export interface DeleteApplicationCloudWatchLoggingOptionRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    CloudWatchLoggingOptionId: string;
}
export interface DeleteApplicationCloudWatchLoggingOptionResponse {
}
export interface DeleteApplicationInputProcessingConfigurationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    InputId: string;
}
export interface DeleteApplicationInputProcessingConfigurationResponse {
}
export interface DeleteApplicationOutputRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    OutputId: string;
}
export interface DeleteApplicationOutputResponse {
}
export interface DeleteApplicationReferenceDataSourceRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    ReferenceId: string;
}
export interface DeleteApplicationReferenceDataSourceResponse {
}
export interface DescribeApplicationRequest {
    ApplicationName: string;
}
export type InAppStreamNames = string[];
export interface InputLambdaProcessorDescription {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
}
export interface InputProcessingConfigurationDescription {
    InputLambdaProcessorDescription?: InputLambdaProcessorDescription | undefined;
}
export interface KinesisStreamsInputDescription {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
}
export interface KinesisFirehoseInputDescription {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
}
export type InputStartingPosition = "NOW" | "TRIM_HORIZON" | "LAST_STOPPED_POINT" | (string & {});
export interface InputStartingPositionConfiguration {
    InputStartingPosition?: InputStartingPosition | undefined;
}
export interface InputDescription {
    InputId?: string | undefined;
    NamePrefix?: string | undefined;
    InAppStreamNames?: string[] | undefined;
    InputProcessingConfigurationDescription?: InputProcessingConfigurationDescription | undefined;
    KinesisStreamsInputDescription?: KinesisStreamsInputDescription | undefined;
    KinesisFirehoseInputDescription?: KinesisFirehoseInputDescription | undefined;
    InputSchema?: SourceSchema | undefined;
    InputParallelism?: InputParallelism | undefined;
    InputStartingPositionConfiguration?: InputStartingPositionConfiguration | undefined;
}
export type InputDescriptions = InputDescription[];
export interface KinesisStreamsOutputDescription {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
}
export interface KinesisFirehoseOutputDescription {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
}
export interface LambdaOutputDescription {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
}
export interface OutputDescription {
    OutputId?: string | undefined;
    Name?: string | undefined;
    KinesisStreamsOutputDescription?: KinesisStreamsOutputDescription | undefined;
    KinesisFirehoseOutputDescription?: KinesisFirehoseOutputDescription | undefined;
    LambdaOutputDescription?: LambdaOutputDescription | undefined;
    DestinationSchema?: DestinationSchema | undefined;
}
export type OutputDescriptions = OutputDescription[];
export interface S3ReferenceDataSourceDescription {
    BucketARN: string;
    FileKey: string;
    ReferenceRoleARN: string;
}
export interface ReferenceDataSourceDescription {
    ReferenceId: string;
    TableName: string;
    S3ReferenceDataSourceDescription: S3ReferenceDataSourceDescription;
    ReferenceSchema?: SourceSchema | undefined;
}
export type ReferenceDataSourceDescriptions = ReferenceDataSourceDescription[];
export interface CloudWatchLoggingOptionDescription {
    CloudWatchLoggingOptionId?: string | undefined;
    LogStreamARN: string;
    RoleARN: string;
}
export type CloudWatchLoggingOptionDescriptions = CloudWatchLoggingOptionDescription[];
export interface ApplicationDetail {
    ApplicationName: string;
    ApplicationDescription?: string | undefined;
    ApplicationARN: string;
    ApplicationStatus: ApplicationStatus;
    CreateTimestamp?: Date | undefined;
    LastUpdateTimestamp?: Date | undefined;
    InputDescriptions?: InputDescription[] | undefined;
    OutputDescriptions?: OutputDescription[] | undefined;
    ReferenceDataSourceDescriptions?: ReferenceDataSourceDescription[] | undefined;
    CloudWatchLoggingOptionDescriptions?: CloudWatchLoggingOptionDescription[] | undefined;
    ApplicationCode?: string | undefined;
    ApplicationVersionId: number;
}
export interface DescribeApplicationResponse {
    ApplicationDetail: ApplicationDetail;
}
export interface S3Configuration {
    RoleARN: string;
    BucketARN: string;
    FileKey: string;
}
export interface DiscoverInputSchemaRequest {
    ResourceARN?: string | undefined;
    RoleARN?: string | undefined;
    InputStartingPositionConfiguration?: InputStartingPositionConfiguration | undefined;
    S3Configuration?: S3Configuration | undefined;
    InputProcessingConfiguration?: InputProcessingConfiguration | undefined;
}
export type ParsedInputRecordField = string;
export type ParsedInputRecord = string[];
export type ParsedInputRecords = string[][];
export type ProcessedInputRecord = string;
export type ProcessedInputRecords = string[];
export type RawInputRecord = string;
export type RawInputRecords = string[];
export interface DiscoverInputSchemaResponse {
    InputSchema?: SourceSchema | undefined;
    ParsedInputRecords?: string[][] | undefined;
    ProcessedInputRecords?: string[] | undefined;
    RawInputRecords?: string[] | undefined;
}
export type ListApplicationsInputLimit = number;
export interface ListApplicationsRequest {
    Limit?: number | undefined;
    ExclusiveStartApplicationName?: string | undefined;
}
export type ApplicationSummaries = ApplicationSummary[];
export interface ListApplicationsResponse {
    ApplicationSummaries: ApplicationSummary[];
    HasMoreApplications: boolean;
}
export type KinesisAnalyticsARN = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface InputConfiguration {
    Id: string;
    InputStartingPositionConfiguration: InputStartingPositionConfiguration;
}
export type InputConfigurations = InputConfiguration[];
export interface StartApplicationRequest {
    ApplicationName: string;
    InputConfigurations: InputConfiguration[];
}
export interface StartApplicationResponse {
}
export interface StopApplicationRequest {
    ApplicationName: string;
}
export interface StopApplicationResponse {
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface InputLambdaProcessorUpdate {
    ResourceARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export interface InputProcessingConfigurationUpdate {
    InputLambdaProcessorUpdate: InputLambdaProcessorUpdate;
}
export interface KinesisStreamsInputUpdate {
    ResourceARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export interface KinesisFirehoseInputUpdate {
    ResourceARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export interface InputSchemaUpdate {
    RecordFormatUpdate?: RecordFormat | undefined;
    RecordEncodingUpdate?: string | undefined;
    RecordColumnUpdates?: RecordColumn[] | undefined;
}
export interface InputParallelismUpdate {
    CountUpdate?: number | undefined;
}
export interface InputUpdate {
    InputId: string;
    NamePrefixUpdate?: string | undefined;
    InputProcessingConfigurationUpdate?: InputProcessingConfigurationUpdate | undefined;
    KinesisStreamsInputUpdate?: KinesisStreamsInputUpdate | undefined;
    KinesisFirehoseInputUpdate?: KinesisFirehoseInputUpdate | undefined;
    InputSchemaUpdate?: InputSchemaUpdate | undefined;
    InputParallelismUpdate?: InputParallelismUpdate | undefined;
}
export type InputUpdates = InputUpdate[];
export interface KinesisStreamsOutputUpdate {
    ResourceARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export interface KinesisFirehoseOutputUpdate {
    ResourceARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export interface LambdaOutputUpdate {
    ResourceARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export interface OutputUpdate {
    OutputId: string;
    NameUpdate?: string | undefined;
    KinesisStreamsOutputUpdate?: KinesisStreamsOutputUpdate | undefined;
    KinesisFirehoseOutputUpdate?: KinesisFirehoseOutputUpdate | undefined;
    LambdaOutputUpdate?: LambdaOutputUpdate | undefined;
    DestinationSchemaUpdate?: DestinationSchema | undefined;
}
export type OutputUpdates = OutputUpdate[];
export interface S3ReferenceDataSourceUpdate {
    BucketARNUpdate?: string | undefined;
    FileKeyUpdate?: string | undefined;
    ReferenceRoleARNUpdate?: string | undefined;
}
export interface ReferenceDataSourceUpdate {
    ReferenceId: string;
    TableNameUpdate?: string | undefined;
    S3ReferenceDataSourceUpdate?: S3ReferenceDataSourceUpdate | undefined;
    ReferenceSchemaUpdate?: SourceSchema | undefined;
}
export type ReferenceDataSourceUpdates = ReferenceDataSourceUpdate[];
export interface CloudWatchLoggingOptionUpdate {
    CloudWatchLoggingOptionId: string;
    LogStreamARNUpdate?: string | undefined;
    RoleARNUpdate?: string | undefined;
}
export type CloudWatchLoggingOptionUpdates = CloudWatchLoggingOptionUpdate[];
export interface ApplicationUpdate {
    InputUpdates?: InputUpdate[] | undefined;
    ApplicationCodeUpdate?: string | undefined;
    OutputUpdates?: OutputUpdate[] | undefined;
    ReferenceDataSourceUpdates?: ReferenceDataSourceUpdate[] | undefined;
    CloudWatchLoggingOptionUpdates?: CloudWatchLoggingOptionUpdate[] | undefined;
}
export interface UpdateApplicationRequest {
    ApplicationName: string;
    CurrentApplicationVersionId: number;
    ApplicationUpdate: ApplicationUpdate;
}
export interface UpdateApplicationResponse {
}
export type ErrorMessage = string;
export type AddApplicationCloudWatchLoggingOptionError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Adds a CloudWatch log stream to monitor application configuration errors. For more
 * information about using CloudWatch log streams with Amazon Kinesis Analytics
 * applications, see Working with Amazon
 * CloudWatch Logs.
 */
export declare const addApplicationCloudWatchLoggingOption: API.OperationMethod<AddApplicationCloudWatchLoggingOptionRequest & RegionInput, AddApplicationCloudWatchLoggingOptionResponse, AddApplicationCloudWatchLoggingOptionError, Credentials | HttpClient.HttpClient>;
export type AddApplicationInputError = CodeValidationException | ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Adds a streaming source to your Amazon Kinesis application.
 * For conceptual information,
 * see Configuring Application Input.
 *
 * You can add a streaming source either when you create an application or you can use
 * this operation to add a streaming source after you create an application. For more information, see
 * CreateApplication.
 *
 * Any configuration update, including adding a streaming source using this operation,
 * results in a new version of the application. You can use the DescribeApplication operation
 * to find the current application version.
 *
 * This operation requires permissions to perform the
 * `kinesisanalytics:AddApplicationInput` action.
 */
export declare const addApplicationInput: API.OperationMethod<AddApplicationInputRequest & RegionInput, AddApplicationInputResponse, AddApplicationInputError, Credentials | HttpClient.HttpClient>;
export type AddApplicationInputProcessingConfigurationError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Adds an InputProcessingConfiguration to an application. An input processor preprocesses records on the input stream
 * before the application's SQL code executes. Currently, the only input processor available is
 * AWS Lambda.
 */
export declare const addApplicationInputProcessingConfiguration: API.OperationMethod<AddApplicationInputProcessingConfigurationRequest & RegionInput, AddApplicationInputProcessingConfigurationResponse, AddApplicationInputProcessingConfigurationError, Credentials | HttpClient.HttpClient>;
export type AddApplicationOutputError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Adds an external destination to your Amazon Kinesis Analytics application.
 *
 * If you want Amazon Kinesis Analytics to deliver data from an in-application stream
 * within your application to an external destination (such as an Amazon Kinesis stream, an
 * Amazon Kinesis Firehose delivery stream, or an AWS Lambda function), you add the
 * relevant configuration to your application using this operation. You can configure one
 * or more outputs for your application. Each output configuration maps an in-application
 * stream and an external destination.
 *
 * You can use one of the output configurations to deliver data from your
 * in-application error stream to an external destination so that you can analyze the
 * errors. For more information, see Understanding Application
 * Output (Destination).
 *
 * Any configuration update, including adding a streaming source using this
 * operation, results in a new version of the application. You can use the DescribeApplication operation to find the current application
 * version.
 *
 * For the limits on the number of application inputs and outputs
 * you can configure, see Limits.
 *
 * This operation requires permissions to perform the `kinesisanalytics:AddApplicationOutput` action.
 */
export declare const addApplicationOutput: API.OperationMethod<AddApplicationOutputRequest & RegionInput, AddApplicationOutputResponse, AddApplicationOutputError, Credentials | HttpClient.HttpClient>;
export type AddApplicationReferenceDataSourceError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Adds a reference data source to an existing application.
 *
 * Amazon Kinesis Analytics reads reference data (that is, an Amazon S3 object) and creates an in-application table within your application. In the request, you provide the source (S3 bucket name and object key name), name of the in-application table to create, and the necessary mapping information that describes how data in Amazon S3 object maps to columns in the resulting in-application table.
 *
 * For conceptual information,
 * see Configuring Application Input.
 * For the limits on data sources you can add to your application, see
 * Limits.
 *
 * This operation requires permissions to perform the `kinesisanalytics:AddApplicationOutput` action.
 */
export declare const addApplicationReferenceDataSource: API.OperationMethod<AddApplicationReferenceDataSourceRequest & RegionInput, AddApplicationReferenceDataSourceResponse, AddApplicationReferenceDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = CodeValidationException | ConcurrentModificationException | InvalidArgumentException | LimitExceededException | ResourceInUseException | TooManyTagsException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Creates an Amazon Kinesis Analytics application.
 * You can configure each application with one streaming source as input,
 * application code to process the input, and up to
 * three destinations where
 * you want Amazon Kinesis Analytics to write the output data from your application.
 * For an overview, see
 * How it Works.
 *
 * In the input configuration, you map the streaming source to an in-application stream, which you can think of as a constantly updating table. In the mapping, you must provide a schema for the in-application stream and map each data column in the in-application stream to a
 * data element in the streaming source.
 *
 * Your application code is one or more SQL statements that read input data, transform it, and generate output. Your application code can create one or more SQL artifacts like SQL streams or pumps.
 *
 * In the output configuration, you can configure the application to write data from in-application streams created in your applications to up to three destinations.
 *
 * To read data from your source stream or write data to destination streams, Amazon Kinesis Analytics
 * needs your permissions. You grant these permissions by creating IAM roles. This operation requires permissions to perform the
 * `kinesisanalytics:CreateApplication` action.
 *
 * For introductory exercises to create an Amazon Kinesis Analytics application, see
 * Getting Started.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = ConcurrentModificationException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Deletes the specified application. Amazon Kinesis Analytics halts application execution and deletes the application, including any application artifacts (such as in-application streams, reference table, and application code).
 *
 * This operation requires permissions to perform the `kinesisanalytics:DeleteApplication` action.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationCloudWatchLoggingOptionError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Deletes a CloudWatch log stream from an application. For more information about
 * using CloudWatch log streams with Amazon Kinesis Analytics applications, see
 * Working with Amazon CloudWatch Logs.
 */
export declare const deleteApplicationCloudWatchLoggingOption: API.OperationMethod<DeleteApplicationCloudWatchLoggingOptionRequest & RegionInput, DeleteApplicationCloudWatchLoggingOptionResponse, DeleteApplicationCloudWatchLoggingOptionError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationInputProcessingConfigurationError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Deletes an InputProcessingConfiguration from an input.
 */
export declare const deleteApplicationInputProcessingConfiguration: API.OperationMethod<DeleteApplicationInputProcessingConfigurationRequest & RegionInput, DeleteApplicationInputProcessingConfigurationResponse, DeleteApplicationInputProcessingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationOutputError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Deletes output destination configuration from your application configuration. Amazon Kinesis Analytics will no longer write data from the corresponding in-application stream to the external output destination.
 *
 * This operation requires permissions to perform the
 * `kinesisanalytics:DeleteApplicationOutput` action.
 */
export declare const deleteApplicationOutput: API.OperationMethod<DeleteApplicationOutputRequest & RegionInput, DeleteApplicationOutputResponse, DeleteApplicationOutputError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationReferenceDataSourceError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Deletes a reference data source configuration from the specified application configuration.
 *
 * If the application is running, Amazon Kinesis Analytics immediately removes the in-application table
 * that you created using the AddApplicationReferenceDataSource operation.
 *
 * This operation requires permissions to perform the `kinesisanalytics.DeleteApplicationReferenceDataSource`
 * action.
 */
export declare const deleteApplicationReferenceDataSource: API.OperationMethod<DeleteApplicationReferenceDataSourceRequest & RegionInput, DeleteApplicationReferenceDataSourceResponse, DeleteApplicationReferenceDataSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Returns information about a specific Amazon Kinesis Analytics application.
 *
 * If you want to retrieve a list of all applications in your account,
 * use the ListApplications operation.
 *
 * This operation requires permissions to perform the `kinesisanalytics:DescribeApplication`
 * action. You can use `DescribeApplication` to get the current application versionId, which you need to call other
 * operations such as `Update`.
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest & RegionInput, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DiscoverInputSchemaError = InvalidArgumentException | ResourceProvisionedThroughputExceededException | ServiceUnavailableException | UnableToDetectSchemaException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Infers a schema by evaluating sample records on the specified streaming source (Amazon Kinesis stream or Amazon Kinesis Firehose delivery stream) or S3 object. In the response, the operation returns the inferred schema and also the sample records that the operation used to infer the schema.
 *
 * You can use the inferred schema when configuring a streaming source
 * for your application. For conceptual information,
 * see Configuring Application Input.
 * Note that when you create an application using the Amazon Kinesis Analytics console,
 * the console uses this operation to infer a schema and show it in the console user interface.
 *
 * This operation requires permissions to perform the
 * `kinesisanalytics:DiscoverInputSchema` action.
 */
export declare const discoverInputSchema: API.OperationMethod<DiscoverInputSchemaRequest & RegionInput, DiscoverInputSchemaResponse, DiscoverInputSchemaError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Returns a list of Amazon Kinesis Analytics applications in your account.
 * For each application, the response includes the application name,
 * Amazon Resource Name (ARN), and status.
 *
 * If the response returns the `HasMoreApplications` value as true,
 * you can send another request by adding the
 * `ExclusiveStartApplicationName` in the request body, and
 * set the value of this to the last application name from
 * the previous response.
 *
 * If you want detailed information about a specific application, use
 * DescribeApplication.
 *
 * This operation requires permissions to perform the
 * `kinesisanalytics:ListApplications` action.
 */
export declare const listApplications: API.OperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = ConcurrentModificationException | InvalidArgumentException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the list of key-value tags assigned to the application. For more information, see Using Tagging.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type StartApplicationError = InvalidApplicationConfigurationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Starts the specified Amazon Kinesis Analytics application. After creating an application, you must exclusively call this operation to start your application.
 *
 * After the application starts, it begins consuming the input data, processes it, and writes the output to the configured destination.
 *
 * The application status must be `READY` for you to start an application. You can
 * get the application status in the console or using the DescribeApplication operation.
 *
 * After you start the application, you can stop the application from processing
 * the input by calling the StopApplication operation.
 *
 * This operation requires permissions to perform the
 * `kinesisanalytics:StartApplication` action.
 */
export declare const startApplication: API.OperationMethod<StartApplicationRequest & RegionInput, StartApplicationResponse, StartApplicationError, Credentials | HttpClient.HttpClient>;
export type StopApplicationError = ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Stops the application from processing input data. You can stop
 * an application only if it is in the running state.
 * You can use the DescribeApplication operation to find the application state.
 * After the application is stopped,
 * Amazon Kinesis Analytics stops reading data from the input, the
 * application stops processing data, and there is no output written to the destination.
 *
 * This operation requires permissions to perform the
 * `kinesisanalytics:StopApplication` action.
 */
export declare const stopApplication: API.OperationMethod<StopApplicationRequest & RegionInput, StopApplicationResponse, StopApplicationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds one or more key-value tags to a Kinesis Analytics application. Note that the maximum number of application tags includes system tags. The maximum number of user-defined application tags is 50.
 * For more information, see Using Tagging.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Removes one or more tags from a Kinesis Analytics application. For more information, see Using Tagging.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = CodeValidationException | ConcurrentModificationException | InvalidArgumentException | ResourceInUseException | ResourceNotFoundException | UnsupportedOperationException | CommonErrors;
/**
 * This documentation is for version 1 of the Amazon Kinesis Data Analytics API, which only supports SQL applications. Version 2 of the API supports SQL and Java applications. For more information about version 2, see Amazon Kinesis Data Analytics API V2 Documentation.
 *
 * Updates an existing Amazon Kinesis Analytics application. Using this API,
 * you can update application code, input configuration, and
 * output configuration.
 *
 * Note that Amazon Kinesis Analytics updates the `CurrentApplicationVersionId`
 * each time you update your application.
 *
 * This operation requires permission for the
 * `kinesisanalytics:UpdateApplication` action.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=kinesis-analytics.d.ts.map