import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
export interface CommitAutofixRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
    /** The Git reference of target branch for the commit. Branch needs to already exist. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    target_ref?: string | undefined;
    /** Commit message to be used. */
    message?: string | undefined;
}
export interface CodeScanningAutofixCommitsResponse {
    /** The Git reference of target branch for the commit. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation. */
    target_ref?: string | undefined;
    /** SHA of commit with autofix. */
    sha?: string | undefined;
}
export interface CreateAutofixRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
}
/** The status of an autofix. */
export type CodeScanningAutofixStatus = "pending" | "error" | "success" | "outdated";
export interface CodeScanningAutofix {
    status: CodeScanningAutofixStatus;
    description: string | null;
    started_at: string;
}
/** The language targeted by the CodeQL query */
export type CodeScanningVariantAnalysisLanguage = "actions" | "cpp" | "csharp" | "go" | "java" | "javascript" | "python" | "ruby" | "rust" | "swift";
/** List of repository names (in the form `owner/repo-name`) to run the query against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required. */
export type CreateVariantAnalysisRequestRepositoriesList = Array<string>;
/** List of repository lists to run the query against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required. */
export type CreateVariantAnalysisRequestRepositoryListsList = Array<string>;
/** List of organization or user names whose repositories the query should be run against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required. */
export type CreateVariantAnalysisRequestRepositoryOwnersList = Array<string>;
export interface CreateVariantAnalysisRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    language: CodeScanningVariantAnalysisLanguage | (string & {});
    /** A Base64-encoded tarball containing a CodeQL query and all its dependencies */
    query_pack: string;
    /** List of repository names (in the form `owner/repo-name`) to run the query against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required. */
    repositories?: CreateVariantAnalysisRequestRepositoriesList | undefined;
    /** List of repository lists to run the query against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required. */
    repository_lists?: CreateVariantAnalysisRequestRepositoryListsList | undefined;
    /** List of organization or user names whose repositories the query should be run against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required. */
    repository_owners?: CreateVariantAnalysisRequestRepositoryOwnersList | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** A GitHub repository. */
export interface SimpleRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The GraphQL identifier of the repository. */
    node_id: string;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    owner: SimpleUser;
    /** Whether the repository is private. */
    private: boolean;
    /** The URL to view the repository on GitHub.com. */
    html_url: string;
    /** The repository description. */
    description: string | null;
    /** Whether the repository is a fork. */
    fork: boolean;
    /** The URL to get more information about the repository from the GitHub API. */
    url: string;
    /** A template for the API URL to download the repository as an archive. */
    archive_url: string;
    /** A template for the API URL to list the available assignees for issues in the repository. */
    assignees_url: string;
    /** A template for the API URL to create or retrieve a raw Git blob in the repository. */
    blobs_url: string;
    /** A template for the API URL to get information about branches in the repository. */
    branches_url: string;
    /** A template for the API URL to get information about collaborators of the repository. */
    collaborators_url: string;
    /** A template for the API URL to get information about comments on the repository. */
    comments_url: string;
    /** A template for the API URL to get information about commits on the repository. */
    commits_url: string;
    /** A template for the API URL to compare two commits or refs. */
    compare_url: string;
    /** A template for the API URL to get the contents of the repository. */
    contents_url: string;
    /** A template for the API URL to list the contributors to the repository. */
    contributors_url: string;
    /** The API URL to list the deployments of the repository. */
    deployments_url: string;
    /** The API URL to list the downloads on the repository. */
    downloads_url: string;
    /** The API URL to list the events of the repository. */
    events_url: string;
    /** The API URL to list the forks of the repository. */
    forks_url: string;
    /** A template for the API URL to get information about Git commits of the repository. */
    git_commits_url: string;
    /** A template for the API URL to get information about Git refs of the repository. */
    git_refs_url: string;
    /** A template for the API URL to get information about Git tags of the repository. */
    git_tags_url: string;
    /** A template for the API URL to get information about issue comments on the repository. */
    issue_comment_url: string;
    /** A template for the API URL to get information about issue events on the repository. */
    issue_events_url: string;
    /** A template for the API URL to get information about issues on the repository. */
    issues_url: string;
    /** A template for the API URL to get information about deploy keys on the repository. */
    keys_url: string;
    /** A template for the API URL to get information about labels of the repository. */
    labels_url: string;
    /** The API URL to get information about the languages of the repository. */
    languages_url: string;
    /** The API URL to merge branches in the repository. */
    merges_url: string;
    /** A template for the API URL to get information about milestones of the repository. */
    milestones_url: string;
    /** A template for the API URL to get information about notifications on the repository. */
    notifications_url: string;
    /** A template for the API URL to get information about pull requests on the repository. */
    pulls_url: string;
    /** A template for the API URL to get information about releases on the repository. */
    releases_url: string;
    /** The API URL to list the stargazers on the repository. */
    stargazers_url: string;
    /** A template for the API URL to get information about statuses of a commit. */
    statuses_url: string;
    /** The API URL to list the subscribers on the repository. */
    subscribers_url: string;
    /** The API URL to subscribe to notifications for this repository. */
    subscription_url: string;
    /** The API URL to get information about tags on the repository. */
    tags_url: string;
    /** The API URL to list the teams on the repository. */
    teams_url: string;
    /** A template for the API URL to create or retrieve a raw Git tree of the repository. */
    trees_url: string;
    /** The API URL to list the hooks on the repository. */
    hooks_url: string;
}
export type CodeScanningVariantAnalysisStatus = "in_progress" | "succeeded" | "failed" | "cancelled";
/** The reason for a failure of the variant analysis. This is only available if the variant analysis has failed. */
export type CodeScanningVariantAnalysisFailureReason = "no_repos_queried" | "actions_workflow_run_failed" | "internal_error";
/** Repository Identifier */
export interface CodeScanningVariantAnalysisRepository {
    /** A unique identifier of the repository. */
    id: number;
    /** The name of the repository. */
    name: string;
    /** The full, globally unique, name of the repository. */
    full_name: string;
    /** Whether the repository is private. */
    private: boolean;
    stargazers_count: number;
    updated_at: string | null;
}
/** The new status of the CodeQL variant analysis repository task. */
export type CodeScanningVariantAnalysisStatus2 = "pending" | "in_progress" | "succeeded" | "failed" | "canceled" | "timed_out";
export interface CodeScanningVariantAnalysisScannedRepositoriesItem {
    repository: CodeScanningVariantAnalysisRepository;
    analysis_status: CodeScanningVariantAnalysisStatus2;
    /** The number of results in the case of a successful analysis. This is only available for successful analyses. */
    result_count?: number | undefined;
    /** The size of the artifact. This is only available for successful analyses. */
    artifact_size_in_bytes?: number | undefined;
    /** The reason of the failure of this repo task. This is only available if the repository task has failed. */
    failure_message?: string | undefined;
}
export type CodeScanningVariantAnalysisScannedRepositoriesList = Array<CodeScanningVariantAnalysisScannedRepositoriesItem>;
/** A list of repositories that were skipped. This list may not include all repositories that were skipped. This is only available when the repository was found and the user has access to it. */
export type CodeScanningVariantAnalysisSkippedRepoGroupRepositoriesList = Array<CodeScanningVariantAnalysisRepository>;
export interface CodeScanningVariantAnalysisSkippedRepoGroup {
    /** The total number of repositories that were skipped for this reason. */
    repository_count: number;
    /** A list of repositories that were skipped. This list may not include all repositories that were skipped. This is only available when the repository was found and the user has access to it. */
    repositories: CodeScanningVariantAnalysisSkippedRepoGroupRepositoriesList;
}
/** A list of full repository names that were skipped. This list may not include all repositories that were skipped. */
export type CodeScanningVariantAnalysisSkippedRepositoriesNotFoundReposRepositoryFullNamesList = Array<string>;
export interface CodeScanningVariantAnalysisSkippedRepositoriesNotFoundRepos {
    /** The total number of repositories that were skipped for this reason. */
    repository_count: number;
    /** A list of full repository names that were skipped. This list may not include all repositories that were skipped. */
    repository_full_names: CodeScanningVariantAnalysisSkippedRepositoriesNotFoundReposRepositoryFullNamesList;
}
/** Information about repositories that were skipped from processing. This information is only available to the user that initiated the variant analysis. */
export interface CodeScanningVariantAnalysisSkippedRepositories {
    access_mismatch_repos: CodeScanningVariantAnalysisSkippedRepoGroup;
    not_found_repos: CodeScanningVariantAnalysisSkippedRepositoriesNotFoundRepos;
    no_codeql_db_repos: CodeScanningVariantAnalysisSkippedRepoGroup;
    over_limit_repos: CodeScanningVariantAnalysisSkippedRepoGroup;
}
/** A run of a CodeQL query against one or more repositories. */
export interface CodeScanningVariantAnalysis {
    /** The ID of the variant analysis. */
    id: number;
    controller_repo: SimpleRepository;
    actor: SimpleUser;
    query_language: CodeScanningVariantAnalysisLanguage;
    /** The download url for the query pack. */
    query_pack_url: string;
    /** The date and time at which the variant analysis was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at?: string | undefined;
    /** The date and time at which the variant analysis was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at?: string | undefined;
    /** The date and time at which the variant analysis was completed, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. Will be null if the variant analysis has not yet completed or this information is not available. */
    completed_at?: string | null | undefined;
    status: CodeScanningVariantAnalysisStatus;
    /** The GitHub Actions workflow run used to execute this variant analysis. This is only available if the workflow run has started. */
    actions_workflow_run_id?: number | undefined;
    /** The reason for a failure of the variant analysis. This is only available if the variant analysis has failed. */
    failure_reason?: CodeScanningVariantAnalysisFailureReason | undefined;
    scanned_repositories?: CodeScanningVariantAnalysisScannedRepositoriesList | undefined;
    /** Information about repositories that were skipped from processing. This information is only available to the user that initiated the variant analysis. */
    skipped_repositories?: CodeScanningVariantAnalysisSkippedRepositories | undefined;
}
export interface DeleteAnalysisRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the analysis, as returned from the `GET /repos/{owner}/{repo}/code-scanning/analyses` operation. */
    analysis_id: number;
    /** Allow deletion if the specified analysis is the last in a set. If you attempt to delete the final analysis in a set without setting this parameter to `true`, you'll get a 400 response with the message: `Analysis is last of its type and deletion may result in the loss of historical alert data. Please specify confirm_delete.` */
    confirm_delete?: string | undefined;
}
/** Successful deletion of a code scanning analysis */
export interface CodeScanningAnalysisDeletion {
    /** Next deletable analysis in chain, without last analysis deletion confirmation */
    next_analysis_url: string | null;
    /** Next deletable analysis in chain, with last analysis deletion confirmation */
    confirm_delete_url: string | null;
}
export interface DeleteCodeqlDatabaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The language of the CodeQL database. */
    language: string;
}
export interface DeleteCodeqlDatabaseResponse {
}
export interface GetAiScanEnablementRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Whether AI Scan is enabled for the repository. */
export type CodeScanningAiScanEnablementPrScan = "enabled" | "disabled";
/** AI Scan enablement for a repository. */
export interface CodeScanningAiScanEnablement {
    /** Whether AI Scan is enabled for the repository. */
    pr_scan: CodeScanningAiScanEnablementPrScan;
}
export interface GetAiScanEnablementForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
}
/** Whether AI Scan on pull requests is enabled for the organization. The organization setting respects enterprise policy, and repositories inherit it: when disabled, repositories cannot enable AI Scan; when enabled, repositories can still opt out. */
export type CodeScanningAiScanOrgSettingsPrScan = "enabled" | "disabled";
/** The AI Scan organization setting */
export interface CodeScanningAiScanOrgSettings {
    /** Whether AI Scan on pull requests is enabled for the organization. The organization setting respects enterprise policy, and repositories inherit it: when disabled, repositories cannot enable AI Scan; when enabled, repositories can still opt out. */
    pr_scan: CodeScanningAiScanOrgSettingsPrScan;
}
export interface GetAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
}
/** State of a code scanning alert. */
export type CodeScanningAlertState = "open" | "dismissed" | "fixed";
/** A GitHub user. */
export type NullableSimpleUser = SimpleUser;
/** **Required when the state is dismissed.** The reason for dismissing or closing the alert. */
export type CodeScanningAlertDismissedReason = "false positive" | "won't fix" | "used in tests" | "mitigated";
/** The severity of the alert. */
export type CodeScanningAlertRuleSeverity = "none" | "note" | "warning" | "error";
/** The security severity of the alert. */
export type CodeScanningAlertRuleSecuritySeverityLevel = "low" | "medium" | "high" | "critical";
/** A set of tags applicable for the rule. */
export type CodeScanningAlertRuleTagsList = Array<string>;
export interface CodeScanningAlertRule {
    /** A unique identifier for the rule used to detect the alert. */
    id?: string | null | undefined;
    /** The name of the rule used to detect the alert. */
    name?: string | undefined;
    /** The severity of the alert. */
    severity?: CodeScanningAlertRuleSeverity | null | undefined;
    /** The security severity of the alert. */
    security_severity_level?: CodeScanningAlertRuleSecuritySeverityLevel | null | undefined;
    /** A short description of the rule used to detect the alert. */
    description?: string | undefined;
    /** A description of the rule used to detect the alert. */
    full_description?: string | undefined;
    /** A set of tags applicable for the rule. */
    tags?: CodeScanningAlertRuleTagsList | null | undefined;
    /** Detailed documentation for the rule as GitHub Flavored Markdown. */
    help?: string | null | undefined;
    /** A link to the documentation for the rule used to detect the alert. */
    help_uri?: string | null | undefined;
}
export interface CodeScanningAnalysisTool {
    name?: string | undefined;
    version?: string | null | undefined;
    guid?: string | null | undefined;
}
export interface CodeScanningAlertInstanceMessage {
    text?: string | undefined;
    /** The message text as GitHub-flavored Markdown, with placeholder links for related locations replaced by links to the relevant code. Only populated when related locations are available for the alert instance. */
    markdown?: string | undefined;
}
/** Describe a region within a file for the alert. */
export interface CodeScanningAlertLocation {
    path?: string | undefined;
    start_line?: number | undefined;
    end_line?: number | undefined;
    start_column?: number | undefined;
    end_column?: number | undefined;
}
/** A classification of the file. For example to identify it as generated. */
export type CodeScanningAlertClassification = "source" | "generated" | "test" | "library";
/** Classifications that have been applied to the file that triggered the alert. For example identifying it as documentation, or a generated file. */
export type CodeScanningAlertInstanceClassificationsList = Array<CodeScanningAlertClassification | null>;
export interface CodeScanningAlertInstance {
    ref?: string | undefined;
    analysis_key?: string | undefined;
    environment?: string | undefined;
    category?: string | undefined;
    state?: CodeScanningAlertState | null | undefined;
    commit_sha?: string | undefined;
    message?: CodeScanningAlertInstanceMessage | undefined;
    location?: CodeScanningAlertLocation | undefined;
    html_url?: string | undefined;
    /** Classifications that have been applied to the file that triggered the alert. For example identifying it as documentation, or a generated file. */
    classifications?: CodeScanningAlertInstanceClassificationsList | undefined;
}
export type CodeScanningAlertAssigneesList = Array<SimpleUser>;
export interface PullRequestSimpleLabelsItem {
    id: number;
    node_id: string;
    url: string;
    name: string;
    description: string;
    color: string;
    default: boolean;
    /** The user who archived the label, or `null` if it has not been archived. */
    archived_by: SimpleUser | null;
}
export type PullRequestSimpleLabelsList = Array<PullRequestSimpleLabelsItem>;
/** The state of the milestone. */
export type NullableMilestoneState = "open" | "closed";
/** A collection of related issues and pull requests. */
export interface NullableMilestone {
    url: string;
    html_url: string;
    labels_url: string;
    id: number;
    node_id: string;
    /** The number of the milestone. */
    number: number;
    /** The state of the milestone. */
    state: NullableMilestoneState;
    /** The title of the milestone. */
    title: string;
    description: string | null;
    creator: SimpleUser | null;
    open_issues: number;
    closed_issues: number;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    due_on: string | null;
}
export type PullRequestSimpleAssigneesList = Array<SimpleUser>;
export type PullRequestSimpleRequestedReviewersList = Array<SimpleUser>;
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
export type PullRequestSimpleRequestedTeamsList = Array<Team>;
/** License Simple */
export interface NullableLicenseSimple {
    key: string;
    name: string;
    url: string | null;
    spdx_id: string | null;
    node_id: string;
    html_url?: string | undefined;
}
export interface RepositoryPermissions {
    admin: boolean;
    pull: boolean;
    triage?: boolean | undefined;
    push: boolean;
    maintain?: boolean | undefined;
}
export type RepositoryTopicsList = Array<string>;
/** The policy controlling who can create pull requests: all or collaborators_only. */
export type RepositoryPullRequestCreationPolicy = "all" | "collaborators_only";
/** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
export type RepositorySquashMergeCommitTitle = "PR_TITLE" | "COMMIT_OR_PR_TITLE";
/** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
export type RepositorySquashMergeCommitMessage = "PR_BODY" | "COMMIT_MESSAGES" | "BLANK";
/** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
export type RepositoryMergeCommitTitle = "PR_TITLE" | "MERGE_MESSAGE";
/** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
export type RepositoryMergeCommitMessage = "PR_BODY" | "PR_TITLE" | "BLANK";
/** The status of the code search index for this repository */
export interface RepositoryCodeSearchIndexStatus {
    lexical_search_ok?: boolean | undefined;
    lexical_commit_sha?: string | undefined;
}
/** A repository on GitHub. */
export interface Repository {
    /** Unique identifier of the repository */
    id: number;
    node_id: string;
    /** The name of the repository. */
    name: string;
    full_name: string;
    license: NullableLicenseSimple | null;
    forks: number;
    permissions?: RepositoryPermissions | undefined;
    owner: SimpleUser;
    /** Whether the repository is private or public. */
    private: boolean;
    html_url: string;
    description: string | null;
    fork: boolean;
    url: string;
    archive_url: string;
    assignees_url: string;
    blobs_url: string;
    branches_url: string;
    collaborators_url: string;
    comments_url: string;
    commits_url: string;
    compare_url: string;
    contents_url: string;
    contributors_url: string;
    deployments_url: string;
    downloads_url: string;
    events_url: string;
    forks_url: string;
    git_commits_url: string;
    git_refs_url: string;
    git_tags_url: string;
    git_url: string;
    issue_comment_url: string;
    issue_events_url: string;
    issues_url: string;
    keys_url: string;
    labels_url: string;
    languages_url: string;
    merges_url: string;
    milestones_url: string;
    notifications_url: string;
    pulls_url: string;
    releases_url: string;
    ssh_url: string;
    stargazers_url: string;
    statuses_url: string;
    subscribers_url: string;
    subscription_url: string;
    tags_url: string;
    teams_url: string;
    trees_url: string;
    clone_url: string;
    mirror_url: string | null;
    hooks_url: string;
    svn_url: string;
    homepage: string | null;
    language: string | null;
    forks_count: number;
    stargazers_count: number;
    watchers_count: number;
    /** The size of the repository, in kilobytes. Size is calculated hourly. When a repository is initially created, the size is 0. */
    size: number;
    /** The default branch of the repository. */
    default_branch: string;
    open_issues_count: number;
    /** Whether this repository acts as a template that can be used to generate new repositories. */
    is_template?: boolean | undefined;
    topics?: RepositoryTopicsList | undefined;
    /** Whether issues are enabled. */
    has_issues: boolean;
    /** Whether projects are enabled. */
    has_projects: boolean;
    /** Whether the wiki is enabled. */
    has_wiki: boolean;
    has_pages: boolean;
    /** Whether downloads are enabled. */
    has_downloads: boolean;
    /** Whether discussions are enabled. */
    has_discussions?: boolean | undefined;
    /** Whether pull requests are enabled. */
    has_pull_requests?: boolean | undefined;
    /** The policy controlling who can create pull requests: all or collaborators_only. */
    pull_request_creation_policy?: RepositoryPullRequestCreationPolicy | undefined;
    /** Whether the repository is archived. */
    archived: boolean;
    /** Returns whether or not this repository disabled. */
    disabled: boolean;
    /** The repository visibility: public, private, or internal. */
    visibility?: string | undefined;
    pushed_at: string | null;
    created_at: string | null;
    updated_at: string | null;
    /** Whether to allow rebase merges for pull requests. */
    allow_rebase_merge?: boolean | undefined;
    /** When present and non-empty, a temporary credential for read-only Git access to this repository. It expires five minutes after generation and cannot be used to push changes. Treat this value as sensitive and avoid recording it in logs. */
    temp_clone_token?: string | undefined;
    /** Whether to allow squash merges for pull requests. */
    allow_squash_merge?: boolean | undefined;
    /** Whether to allow Auto-merge to be used on pull requests. */
    allow_auto_merge?: boolean | undefined;
    /** Whether to delete head branches when pull requests are merged */
    delete_branch_on_merge?: boolean | undefined;
    /** Whether or not a pull request head branch that is behind its base branch can always be updated even if it is not required to be up to date before merging. */
    allow_update_branch?: boolean | undefined;
    /** Whether a squash merge commit can use the pull request title as default. **This property is closing down. Please use `squash_merge_commit_title` instead. */
    use_squash_pr_title_as_default?: boolean | undefined;
    /** The default value for a squash merge commit title: - `PR_TITLE` - default to the pull request's title. - `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit). */
    squash_merge_commit_title?: RepositorySquashMergeCommitTitle | undefined;
    /** The default value for a squash merge commit message: - `PR_BODY` - default to the pull request's body. - `COMMIT_MESSAGES` - default to the branch's commit messages. - `BLANK` - default to a blank commit message. */
    squash_merge_commit_message?: RepositorySquashMergeCommitMessage | undefined;
    /** The default value for a merge commit title. - `PR_TITLE` - default to the pull request's title. - `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name). */
    merge_commit_title?: RepositoryMergeCommitTitle | undefined;
    /** The default value for a merge commit message. - `PR_TITLE` - default to the pull request's title. - `PR_BODY` - default to the pull request's body. - `BLANK` - default to a blank commit message. */
    merge_commit_message?: RepositoryMergeCommitMessage | undefined;
    /** Whether to allow merge commits for pull requests. */
    allow_merge_commit?: boolean | undefined;
    /** Whether to allow forking this repo */
    allow_forking?: boolean | undefined;
    /** Whether to require contributors to sign off on web-based commits */
    web_commit_signoff_required?: boolean | undefined;
    open_issues: number;
    watchers: number;
    master_branch?: string | undefined;
    starred_at?: string | undefined;
    /** Whether anonymous git access is enabled for this repository */
    anonymous_access_enabled?: boolean | undefined;
    /** The status of the code search index for this repository */
    code_search_index_status?: RepositoryCodeSearchIndexStatus | undefined;
}
export interface PullRequestSimpleHead {
    label: string;
    ref: string;
    repo: Repository;
    sha: string;
    user: SimpleUser | null;
}
export type PullRequestSimpleBase = PullRequestSimpleHead;
/** Hypermedia Link */
export interface Link {
    href: string;
}
export interface PullRequestSimpleLinks {
    comments: Link;
    commits: Link;
    statuses: Link;
    html: Link;
    issue: Link;
    review_comments: Link;
    review_comment: Link;
    self: Link;
}
/** How the author is associated with the repository. */
export type AuthorAssociation = "COLLABORATOR" | "CONTRIBUTOR" | "FIRST_TIMER" | "FIRST_TIME_CONTRIBUTOR" | "MANNEQUIN" | "MEMBER" | "NONE" | "OWNER";
/** The merge method to use. */
export type AutoMergeMergeMethod = "merge" | "squash" | "rebase";
/** The status of auto merging a pull request. */
export interface AutoMerge {
    enabled_by: SimpleUser;
    /** The merge method to use. */
    merge_method: AutoMergeMergeMethod;
    /** Title for the merge commit message. */
    commit_title: string;
    /** Commit message for the merge commit. */
    commit_message: string;
}
export interface PullRequestStackBase {
    /** The base ref of the stack this pull request belongs to. */
    ref: string;
    /** The base SHA of the stack this pull request belongs to. */
    sha: string;
}
/** The stack information associated with a pull request. */
export interface PullRequestStack {
    base: PullRequestStackBase;
    /** The total number of pull requests in the stack. */
    size?: number | undefined;
    /** The one-based position of this pull request within the stack, where 1 is the bottom of the stack. */
    position?: number | undefined;
    /** The ID of the stack that this pull request belongs to. */
    id?: number | undefined;
    /** The number of the stack that this pull request belongs to. */
    number?: number | undefined;
}
/** Pull Request Simple */
export interface PullRequestSimple {
    url: string;
    id: number;
    node_id: string;
    html_url: string;
    diff_url: string;
    patch_url: string;
    issue_url: string;
    commits_url: string;
    review_comments_url: string;
    review_comment_url: string;
    comments_url: string;
    statuses_url: string;
    number: number;
    state: string;
    locked: boolean;
    title: string;
    user: SimpleUser | null;
    body: string | null;
    labels: PullRequestSimpleLabelsList;
    milestone: NullableMilestone | null;
    active_lock_reason?: string | null | undefined;
    created_at: string;
    updated_at: string;
    closed_at: string | null;
    merged_at: string | null;
    merge_commit_sha: string | null;
    assignee: SimpleUser | null;
    assignees?: PullRequestSimpleAssigneesList | undefined;
    requested_reviewers?: PullRequestSimpleRequestedReviewersList | undefined;
    requested_teams?: PullRequestSimpleRequestedTeamsList | undefined;
    head: PullRequestSimpleHead;
    base: PullRequestSimpleHead;
    _links: PullRequestSimpleLinks;
    author_association: AuthorAssociation;
    auto_merge: AutoMerge | null;
    stack?: PullRequestStack | null | undefined;
    /** Indicates whether or not the pull request is a draft. */
    draft?: boolean | undefined;
}
/** Pull requests linked to this alert. */
export type CodeScanningAlertLinkedPullRequestsList = Array<PullRequestSimple>;
export interface CodeScanningAlert {
    number: number;
    created_at: string;
    updated_at?: string | undefined;
    url: string;
    html_url: string;
    instances_url: string;
    state: CodeScanningAlertState | null;
    fixed_at?: string | null | undefined;
    dismissed_by: SimpleUser | null;
    dismissed_at: string | null;
    dismissed_reason: CodeScanningAlertDismissedReason | null;
    dismissed_comment?: string | null | undefined;
    rule: CodeScanningAlertRule;
    tool: CodeScanningAnalysisTool;
    most_recent_instance: CodeScanningAlertInstance;
    dismissal_approved_by?: SimpleUser | null | undefined;
    assignees?: CodeScanningAlertAssigneesList | undefined;
    /** Pull requests linked to this alert. */
    linked_pull_requests?: CodeScanningAlertLinkedPullRequestsList | undefined;
}
export interface GetAnalysisRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The ID of the analysis, as returned from the `GET /repos/{owner}/{repo}/code-scanning/analyses` operation. */
    analysis_id: number;
}
export interface CodeScanningAnalysis {
    ref: string;
    commit_sha: string;
    analysis_key: string;
    environment: string;
    category?: string | undefined;
    error: string;
    created_at: string;
    /** The total number of results in the analysis. */
    results_count: number;
    /** The total number of rules used in the analysis. */
    rules_count: number;
    /** Unique identifier for this analysis. */
    id: number;
    url: string;
    sarif_id: string;
    tool: CodeScanningAnalysisTool;
    deletable: boolean;
    /** Warning generated when processing the analysis */
    warning: string;
}
export interface GetAutofixRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
}
export interface GetCodeqlDatabaseRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The language of the CodeQL database. */
    language: string;
}
/** A CodeQL database. */
export interface CodeScanningCodeqlDatabase {
    /** The ID of the CodeQL database. */
    id: number;
    /** The name of the CodeQL database. */
    name: string;
    /** The language of the CodeQL database. */
    language: string;
    uploader: SimpleUser;
    /** The MIME type of the CodeQL database file. */
    content_type: string;
    /** The size of the CodeQL database file in bytes. */
    size: number;
    /** The date and time at which the CodeQL database was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time at which the CodeQL database was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
    /** The URL at which to download the CodeQL database. The `Accept` header must be set to the value of the `content_type` property. */
    url: string;
    /** The commit SHA of the repository at the time the CodeQL database was created. */
    commit_oid?: string | null | undefined;
}
export interface GetDefaultSetupRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
/** Code scanning default setup has been configured or not. */
export type CodeScanningDefaultSetupState = "configured" | "not-configured";
export type CodeScanningDefaultSetupLanguagesItem = "actions" | "c-cpp" | "csharp" | "go" | "java-kotlin" | "javascript-typescript" | "javascript" | "python" | "ruby" | "typescript" | "swift";
/** Languages to be analyzed. */
export type CodeScanningDefaultSetupLanguagesList = Array<CodeScanningDefaultSetupLanguagesItem>;
/** Runner type to be used. */
export type CodeScanningDefaultSetupRunnerType = "standard" | "labeled";
/** CodeQL query suite to be used. */
export type CodeScanningDefaultSetupQuerySuite = "default" | "extended";
/** Threat model to be used for code scanning analysis. Use `remote` to analyze only network sources and `remote_and_local` to include local sources like filesystem access, command-line arguments, database reads, environment variable and standard input. */
export type CodeScanningDefaultSetupThreatModel = "remote" | "remote_and_local";
/** The frequency of the periodic analysis. */
export type CodeScanningDefaultSetupSchedule = "weekly";
/** Configuration for code scanning default setup. */
export interface CodeScanningDefaultSetup {
    /** Code scanning default setup has been configured or not. */
    state?: CodeScanningDefaultSetupState | undefined;
    /** Languages to be analyzed. */
    languages?: CodeScanningDefaultSetupLanguagesList | undefined;
    /** Runner type to be used. */
    runner_type?: CodeScanningDefaultSetupRunnerType | null | undefined;
    /** Runner label to be used if the runner type is labeled. */
    runner_label?: string | null | undefined;
    /** CodeQL query suite to be used. */
    query_suite?: CodeScanningDefaultSetupQuerySuite | undefined;
    /** Threat model to be used for code scanning analysis. Use `remote` to analyze only network sources and `remote_and_local` to include local sources like filesystem access, command-line arguments, database reads, environment variable and standard input. */
    threat_model?: CodeScanningDefaultSetupThreatModel | undefined;
    /** Timestamp of latest configuration update. */
    updated_at?: string | null | undefined;
    /** The frequency of the periodic analysis. */
    schedule?: CodeScanningDefaultSetupSchedule | null | undefined;
}
export interface GetSarifRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The SARIF ID obtained after uploading. */
    sarif_id: string;
}
/** `pending` files have not yet been processed, while `complete` means results from the SARIF have been stored. `failed` files have either not been processed at all, or could only be partially processed. */
export type CodeScanningSarifsStatusProcessingStatus = "pending" | "complete" | "failed";
/** Any errors that ocurred during processing of the delivery. */
export type CodeScanningSarifsStatusErrorsList = Array<string>;
export interface CodeScanningSarifsStatus {
    /** `pending` files have not yet been processed, while `complete` means results from the SARIF have been stored. `failed` files have either not been processed at all, or could only be partially processed. */
    processing_status?: CodeScanningSarifsStatusProcessingStatus | undefined;
    /** The REST API URL for getting the analyses associated with the upload. */
    analyses_url?: string | null | undefined;
    /** Any errors that ocurred during processing of the delivery. */
    errors?: CodeScanningSarifsStatusErrorsList | null | undefined;
}
export interface GetVariantAnalysisRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The unique identifier of the variant analysis. */
    codeql_variant_analysis_id: number;
}
export interface GetVariantAnalysisRepoTaskRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the controller repository. */
    repo: string;
    /** The ID of the variant analysis. */
    codeql_variant_analysis_id: number;
    /** The account owner of the variant analysis repository. The name is not case sensitive. */
    repo_owner: string;
    /** The name of the variant analysis repository. */
    repo_name: string;
}
export interface CodeScanningVariantAnalysisRepoTask {
    repository: SimpleRepository;
    analysis_status: CodeScanningVariantAnalysisStatus2;
    /** The size of the artifact. This is only available for successful analyses. */
    artifact_size_in_bytes?: number | undefined;
    /** The number of results in the case of a successful analysis. This is only available for successful analyses. */
    result_count?: number | undefined;
    /** The reason of the failure of this repo task. This is only available if the repository task has failed. */
    failure_message?: string | undefined;
    /** The SHA of the commit the CodeQL database was built against. This is only available for successful analyses. */
    database_commit_sha?: string | undefined;
    /** The source location prefix to use. This is only available for successful analyses. */
    source_location_prefix?: string | undefined;
    /** The URL of the artifact. This is only available for successful analyses. */
    artifact_url?: string | undefined;
}
export interface ListAlertInstancesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`. */
    ref?: string | undefined;
    /** The number of the pull request for the results you want to list. */
    pr?: number | undefined;
}
/** State of a code scanning alert instance. */
export type CodeScanningAlertInstanceState = "open" | "fixed";
export interface CodeScanningAlertInstanceListMessage {
    text?: string | undefined;
}
/** Classifications that have been applied to the file that triggered the alert. For example identifying it as documentation, or a generated file. */
export type CodeScanningAlertInstanceListClassificationsList = Array<CodeScanningAlertClassification | null>;
export interface CodeScanningAlertInstanceList {
    ref?: string | undefined;
    analysis_key?: string | undefined;
    environment?: string | undefined;
    category?: string | undefined;
    state?: CodeScanningAlertInstanceState | null | undefined;
    commit_sha?: string | undefined;
    message?: CodeScanningAlertInstanceListMessage | undefined;
    location?: CodeScanningAlertLocation | undefined;
    html_url?: string | undefined;
    /** Classifications that have been applied to the file that triggered the alert. For example identifying it as documentation, or a generated file. */
    classifications?: CodeScanningAlertInstanceListClassificationsList | undefined;
}
export type ListAlertInstancesResponseBodyList = Array<CodeScanningAlertInstanceList>;
export type ListAlertInstancesResponse = ListAlertInstancesResponseBodyList;
export type ListAlertsForOrgRequestDirection = "asc" | "desc";
/** State of a code scanning alert. */
export type CodeScanningAlertStateQuery = "open" | "closed" | "dismissed" | "fixed";
export type ListAlertsForOrgRequestSort = "created" | "updated";
/** Severity of a code scanning alert. */
export type CodeScanningAlertSeverity = "critical" | "high" | "medium" | "low" | "warning" | "note" | "error";
export interface ListAlertsForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both. */
    tool_name?: string | undefined;
    /** The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both. */
    tool_guid?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForOrgRequestDirection | (string & {}) | undefined;
    /** If specified, only code scanning alerts with this state will be returned. */
    state?: CodeScanningAlertStateQuery | (string & {}) | undefined;
    /** The property by which to sort the results. */
    sort?: ListAlertsForOrgRequestSort | (string & {}) | undefined;
    /** If specified, only code scanning alerts with this severity will be returned. */
    severity?: CodeScanningAlertSeverity | (string & {}) | undefined;
    /** Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`). Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees. */
    assignees?: string | undefined;
}
/** The severity of the alert. */
export type CodeScanningAlertRuleSummarySeverity = "none" | "note" | "warning" | "error";
/** The security severity of the alert. */
export type CodeScanningAlertRuleSummarySecuritySeverityLevel = "low" | "medium" | "high" | "critical";
/** A set of tags applicable for the rule. */
export type CodeScanningAlertRuleSummaryTagsList = Array<string>;
export interface CodeScanningAlertRuleSummary {
    /** A unique identifier for the rule used to detect the alert. */
    id?: string | null | undefined;
    /** The name of the rule used to detect the alert. */
    name?: string | undefined;
    /** The severity of the alert. */
    severity?: CodeScanningAlertRuleSummarySeverity | null | undefined;
    /** The security severity of the alert. */
    security_severity_level?: CodeScanningAlertRuleSummarySecuritySeverityLevel | null | undefined;
    /** A short description of the rule used to detect the alert. */
    description?: string | undefined;
    /** A description of the rule used to detect the alert. */
    full_description?: string | undefined;
    /** A set of tags applicable for the rule. */
    tags?: CodeScanningAlertRuleSummaryTagsList | null | undefined;
    /** Detailed documentation for the rule as GitHub Flavored Markdown. */
    help?: string | null | undefined;
    /** A link to the documentation for the rule used to detect the alert. */
    help_uri?: string | null | undefined;
}
export type CodeScanningOrganizationAlertItemsAssigneesList = Array<SimpleUser>;
export interface CodeScanningOrganizationAlertItems {
    number: number;
    created_at: string;
    updated_at?: string | undefined;
    url: string;
    html_url: string;
    instances_url: string;
    state: CodeScanningAlertState | null;
    fixed_at?: string | null | undefined;
    dismissed_by: SimpleUser | null;
    dismissed_at: string | null;
    dismissed_reason: CodeScanningAlertDismissedReason | null;
    dismissed_comment?: string | null | undefined;
    rule: CodeScanningAlertRuleSummary;
    tool: CodeScanningAnalysisTool;
    most_recent_instance: CodeScanningAlertInstance;
    repository: SimpleRepository;
    dismissal_approved_by?: SimpleUser | null | undefined;
    assignees?: CodeScanningOrganizationAlertItemsAssigneesList | undefined;
}
export type ListAlertsForOrgResponseBodyList = Array<CodeScanningOrganizationAlertItems>;
export type ListAlertsForOrgResponse = ListAlertsForOrgResponseBodyList;
export type ListAlertsForRepoRequestDirection = "asc" | "desc";
export type ListAlertsForRepoRequestSort = "created" | "updated";
export interface ListAlertsForRepoRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both. */
    tool_name?: string | undefined;
    /** The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both. */
    tool_guid?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`. */
    ref?: string | undefined;
    /** The number of the pull request for the results you want to list. */
    pr?: number | undefined;
    /** The direction to sort the results by. */
    direction?: ListAlertsForRepoRequestDirection | (string & {}) | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    before?: string | undefined;
    /** A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    after?: string | undefined;
    /** The property by which to sort the results. */
    sort?: ListAlertsForRepoRequestSort | (string & {}) | undefined;
    /** If specified, only code scanning alerts with this state will be returned. */
    state?: CodeScanningAlertStateQuery | (string & {}) | undefined;
    /** If specified, only code scanning alerts with this severity will be returned. */
    severity?: CodeScanningAlertSeverity | (string & {}) | undefined;
    /** Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`). Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees. */
    assignees?: string | undefined;
}
export type CodeScanningAlertItemsAssigneesList = Array<SimpleUser>;
export interface CodeScanningAlertItems {
    number: number;
    created_at: string;
    updated_at?: string | undefined;
    url: string;
    html_url: string;
    instances_url: string;
    state: CodeScanningAlertState | null;
    fixed_at?: string | null | undefined;
    dismissed_by: SimpleUser | null;
    dismissed_at: string | null;
    dismissed_reason: CodeScanningAlertDismissedReason | null;
    dismissed_comment?: string | null | undefined;
    rule: CodeScanningAlertRuleSummary;
    tool: CodeScanningAnalysisTool;
    most_recent_instance: CodeScanningAlertInstance;
    dismissal_approved_by?: SimpleUser | null | undefined;
    assignees?: CodeScanningAlertItemsAssigneesList | undefined;
}
export type ListAlertsForRepoResponseBodyList = Array<CodeScanningAlertItems>;
export type ListAlertsForRepoResponse = ListAlertsForRepoResponseBodyList;
export interface ListCodeqlDatabasesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
}
export type ListCodeqlDatabasesResponseBodyList = Array<CodeScanningCodeqlDatabase>;
export type ListCodeqlDatabasesResponse = ListCodeqlDatabasesResponseBodyList;
export type ListRecentAnalysesRequestDirection = "asc" | "desc";
export type ListRecentAnalysesRequestSort = "created";
export interface ListRecentAnalysesRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both. */
    tool_name?: string | undefined;
    /** The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both. */
    tool_guid?: string | undefined;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The number of the pull request for the results you want to list. */
    pr?: number | undefined;
    /** The Git reference for the analyses you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`. */
    ref?: string | undefined;
    /** Filter analyses belonging to the same SARIF upload. */
    sarif_id?: string | undefined;
    /** The direction to sort the results by. */
    direction?: ListRecentAnalysesRequestDirection | (string & {}) | undefined;
    /** The property by which to sort the results. */
    sort?: ListRecentAnalysesRequestSort | (string & {}) | undefined;
}
export type ListRecentAnalysesResponseBodyList = Array<CodeScanningAnalysis>;
export type ListRecentAnalysesResponse = ListRecentAnalysesResponseBodyList;
/** Whether to enable or disable AI Scan for the repository. */
export type UpdateAiScanEnablementRequestPrScan = "enabled" | "disabled";
export interface UpdateAiScanEnablementRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** Whether to enable or disable AI Scan for the repository. */
    pr_scan?: UpdateAiScanEnablementRequestPrScan | (string & {}) | undefined;
}
/** Whether AI Scan is enabled for the organization. Organization respects enterprise policy. Disabled organizations prevent repositories from enabling AI Scan. Enabled organizations enable AI Scan for their repositories, but individual repositories can opt out. */
export type UpdateAiScanEnablementForOrgRequestPrScan = "enabled" | "disabled";
export interface UpdateAiScanEnablementForOrgRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** Whether AI Scan is enabled for the organization. Organization respects enterprise policy. Disabled organizations prevent repositories from enabling AI Scan. Enabled organizations enable AI Scan for their repositories, but individual repositories can opt out. */
    pr_scan?: UpdateAiScanEnablementForOrgRequestPrScan | (string & {}) | undefined;
}
/** Sets the state of the code scanning alert. You must provide `dismissed_reason` when you set the state to `dismissed`. */
export type CodeScanningAlertSetState = "open" | "dismissed";
/** The list of users to assign to the code scanning alert. An empty array unassigns all previous assignees from the alert. */
export type CodeScanningAlertAssignees = Array<string>;
export interface UpdateAlertRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation. */
    alert_number: number;
    state?: CodeScanningAlertSetState | (string & {}) | undefined;
    dismissed_reason?: CodeScanningAlertDismissedReason | (string & {}) | null | undefined;
    dismissed_comment?: string | null | undefined;
    create_request?: boolean | undefined;
    assignees?: CodeScanningAlertAssignees | undefined;
}
/** The desired state of code scanning default setup. */
export type UpdateDefaultSetupRequestState = "configured" | "not-configured";
/** Runner type to be used. */
export type UpdateDefaultSetupRequestRunnerType = "standard" | "labeled";
/** CodeQL query suite to be used. */
export type UpdateDefaultSetupRequestQuerySuite = "default" | "extended";
/** Threat model to be used for code scanning analysis. Use `remote` to analyze only network sources and `remote_and_local` to include local sources like filesystem access, command-line arguments, database reads, environment variable and standard input. */
export type UpdateDefaultSetupRequestThreatModel = "remote" | "remote_and_local";
export type UpdateDefaultSetupRequestLanguagesItem = "actions" | "c-cpp" | "csharp" | "go" | "java-kotlin" | "javascript-typescript" | "python" | "ruby" | "swift";
/** CodeQL languages to be analyzed. */
export type UpdateDefaultSetupRequestLanguagesList = Array<UpdateDefaultSetupRequestLanguagesItem | (string & {})>;
export interface UpdateDefaultSetupRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    /** The desired state of code scanning default setup. */
    state?: UpdateDefaultSetupRequestState | (string & {}) | undefined;
    /** Runner type to be used. */
    runner_type?: UpdateDefaultSetupRequestRunnerType | (string & {}) | undefined;
    /** Runner label to be used if the runner type is labeled. */
    runner_label?: string | null | undefined;
    /** CodeQL query suite to be used. */
    query_suite?: UpdateDefaultSetupRequestQuerySuite | (string & {}) | undefined;
    /** Threat model to be used for code scanning analysis. Use `remote` to analyze only network sources and `remote_and_local` to include local sources like filesystem access, command-line arguments, database reads, environment variable and standard input. */
    threat_model?: UpdateDefaultSetupRequestThreatModel | (string & {}) | undefined;
    /** CodeQL languages to be analyzed. */
    languages?: UpdateDefaultSetupRequestLanguagesList | undefined;
}
export type UpdateDefaultSetupResponse = unknown;
export interface UploadSarifRequest {
    /** The account owner of the repository. The name is not case sensitive. */
    owner: string;
    /** The name of the repository without the `.git` extension. The name is not case sensitive. */
    repo: string;
    commit_sha: string;
    ref: string;
    sarif: string;
    /** The base directory used in the analysis, as it appears in the SARIF file. This property is used to convert file paths from absolute to relative, so that alerts can be mapped to their correct location in the repository. */
    checkout_uri?: string | undefined;
    /** The time that the analysis run began. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. */
    started_at?: string | undefined;
    /** The name of the tool used to generate the code scanning analysis. If this parameter is not used, the tool name defaults to "API". If the uploaded SARIF contains a tool GUID, this will be available for filtering using the `tool_guid` parameter of operations such as `GET /repos/{owner}/{repo}/code-scanning/alerts`. */
    tool_name?: string | undefined;
    /** Whether the SARIF file will be validated according to the code scanning specifications. This parameter is intended to help integrators ensure that the uploaded SARIF files are correctly rendered by code scanning. */
    validate?: boolean | undefined;
}
export interface UploadSarifResponse {
}
export type CommitAutofixError = GithubOpError;
/** Commit an autofix for a code scanning alert Commits an autofix for a code scanning alert from the repository's default branch. If an autofix is committed as a result of this request, then this endpoint will return a 201 Created response. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const commitAutofix: API.OperationMethod<CommitAutofixRequest, CodeScanningAutofixCommitsResponse, CommitAutofixError, GithubOpContext>;
export type CreateAutofixError = GithubOpError;
/** Create an autofix for a code scanning alert Creates an autofix for a code scanning alert from the repository's default branch. If a new autofix is to be created as a result of this request or is currently being generated, then this endpoint will return a 202 Accepted response. If an autofix already exists for a given alert, then this endpoint will return a 200 OK response. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const createAutofix: API.OperationMethod<CreateAutofixRequest, CodeScanningAutofix, CreateAutofixError, GithubOpContext>;
export type CreateVariantAnalysisError = GithubOpError;
/** Create a CodeQL variant analysis Creates a new CodeQL variant analysis, which will run a CodeQL query against one or more repositories. Get started by learning more about [running CodeQL queries at scale with Multi-Repository Variant Analysis](https://docs.github.com/code-security/codeql-for-vs-code/getting-started-with-codeql-for-vs-code/running-codeql-queries-at-scale-with-multi-repository-variant-analysis). Use the `owner` and `repo` parameters in the URL to specify the controller repository that will be used for running GitHub Actions workflows and storing the results of the CodeQL variant analysis. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint. */
export declare const createVariantAnalysis: API.OperationMethod<CreateVariantAnalysisRequest, CodeScanningVariantAnalysis, CreateVariantAnalysisError, GithubOpContext>;
export type DeleteAnalysisError = GithubOpError;
/** Delete a code scanning analysis from a repository Deletes a specified code scanning analysis from a repository. You can delete one analysis at a time. To delete a series of analyses, start with the most recent analysis and work backwards. Conceptually, the process is similar to the undo function in a text editor. When you list the analyses for a repository, one or more will be identified as deletable in the response: ``` "deletable": true ``` An analysis is deletable when it's the most recent in a set of analyses. Typically, a repository will have multiple sets of analyses for each enabled code scanning tool, where a set is determined by a unique combination of analysis values: * `ref` * `tool` * `category` If you attempt to delete an analysis that is not the most recent in a set, you'll get a 400 response with the message: ``` Analysis specified is not deletable. ``` The response from a successful `DELETE` operation provides you with two alternative URLs for deleting the next analysis in the set: `next_analysis_url` and `confirm_delete_url`. Use the `next_analysis_url` URL if you want to avoid accidentally deleting the final analysis in a set. This is a useful option if you want to preserve at least one analysis for the specified tool in your repository. Use the `confirm_delete_url` URL if you are content to remove all analyses for a tool. When you delete the last analysis in a set, the value of `next_analysis_url` and `confirm_delete_url` in the 200 response is `null`. As an example of the deletion process, let's imagine that you added a workflow that configured a particular code scanning tool to analyze the code in a repository. This tool has added 15 analyses: 10 on the default branch, and another 5 on a topic branch. You therefore have two separate sets of analyses for this tool. You've now decided that you want to remove all of the analyses for the tool. To do this you must make 15 separate deletion requests. To start, you must find an analysis that's identified as deletable. Each set of analyses always has one that's identified as deletable. Having found the deletable analysis for one of the two sets, delete this analysis and then continue deleting the next analysis in the set until they're all deleted. Then repeat the process for the second set. The procedure therefore consists of a nested loop: **Outer loop**: * List the analyses for the repository, filtered by tool. * Parse this list to find a deletable analysis. If found: **Inner loop**: * Delete the identified analysis. * Parse the response for the value of `confirm_delete_url` and, if found, use this in the next iteration. The above process assumes that you want to remove all trace of the tool's analyses from the GitHub user interface, for the specified repository, and it therefore uses the `confirm_delete_url` value. Alternatively, you could use the `next_analysis_url` value, which would leave the last analysis in each set undeleted to avoid removing a tool's analysis entirely. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const deleteAnalysis: API.OperationMethod<DeleteAnalysisRequest, CodeScanningAnalysisDeletion, DeleteAnalysisError, GithubOpContext>;
export type DeleteCodeqlDatabaseError = GithubOpError;
/** Delete a CodeQL database Deletes a CodeQL database for a language in a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const deleteCodeqlDatabase: API.OperationMethod<DeleteCodeqlDatabaseRequest, DeleteCodeqlDatabaseResponse, DeleteCodeqlDatabaseError, GithubOpContext>;
export type GetAiScanEnablementError = GithubOpError;
/** Get AI Scan enablement for a repository Gets whether AI Scan is enabled for a repository. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getAiScanEnablement: API.OperationMethod<GetAiScanEnablementRequest, CodeScanningAiScanEnablement, GetAiScanEnablementError, GithubOpContext>;
export type GetAiScanEnablementForOrgError = GithubOpError;
/** Get the AI Scan setting for an organization Gets the AI Scan setting stored on an organization. The response reports the value stored on the organization. Organization respects enterprise policy. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `admin:org`, `repo`, or `write:org` scope to use this endpoint. Organization owners can use `admin:org` or `repo`; security managers need `write:org`. */
export declare const getAiScanEnablementForOrg: API.OperationMethod<GetAiScanEnablementForOrgRequest, CodeScanningAiScanOrgSettings, GetAiScanEnablementForOrgError, GithubOpContext>;
export type GetAlertError = GithubOpError;
/** Get a code scanning alert Gets a single code scanning alert. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getAlert: API.OperationMethod<GetAlertRequest, CodeScanningAlert, GetAlertError, GithubOpContext>;
export type GetAnalysisError = GithubOpError;
/** Get a code scanning analysis for a repository Gets a specified code scanning analysis for a repository. The default JSON response contains fields that describe the analysis. This includes the Git reference and commit SHA to which the analysis relates, the datetime of the analysis, the name of the code scanning tool, and the number of alerts. The `rules_count` field in the default response give the number of rules that were run in the analysis. For very old analyses this data is not available, and `0` is returned in this field. This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." - **`application/sarif+json`**: Instead of returning a summary of the analysis, this endpoint returns a subset of the analysis data that was uploaded. The data is formatted as [SARIF version 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/cs01/sarif-v2.1.0-cs01.html). It also returns additional data such as the `github/alertNumber` and `github/alertUrl` properties. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getAnalysis: API.OperationMethod<GetAnalysisRequest, CodeScanningAnalysis, GetAnalysisError, GithubOpContext>;
export type GetAutofixError = GithubOpError;
/** Get the status of an autofix for a code scanning alert Gets the status and description of an autofix for a code scanning alert on the repository's default branch. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getAutofix: API.OperationMethod<GetAutofixRequest, CodeScanningAutofix, GetAutofixError, GithubOpContext>;
export type GetCodeqlDatabaseError = GithubOpError;
/** Get a CodeQL database for a repository Gets a CodeQL database for a language in a repository. By default this endpoint returns JSON metadata about the CodeQL database. To download the CodeQL database binary content, set the `Accept` header of the request to [`application/zip`](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types), and make sure your HTTP client is configured to follow redirects or use the `Location` header to make a second request to get the redirect URL. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getCodeqlDatabase: API.OperationMethod<GetCodeqlDatabaseRequest, CodeScanningCodeqlDatabase, GetCodeqlDatabaseError, GithubOpContext>;
export type GetDefaultSetupError = GithubOpError;
/** Get a code scanning default setup configuration Gets a code scanning default setup configuration. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getDefaultSetup: API.OperationMethod<GetDefaultSetupRequest, CodeScanningDefaultSetup, GetDefaultSetupError, GithubOpContext>;
export type GetSarifError = GithubOpError;
/** Get information about a SARIF upload Gets information about a SARIF upload, including the status and the URL of the analysis that was uploaded so that you can retrieve details of the analysis. For more information, see "[Get a code scanning analysis for a repository](/rest/code-scanning/code-scanning#get-a-code-scanning-analysis-for-a-repository)." OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getSarif: API.OperationMethod<GetSarifRequest, CodeScanningSarifsStatus, GetSarifError, GithubOpContext>;
export type GetVariantAnalysisError = GithubOpError;
/** Get the summary of a CodeQL variant analysis Gets the summary of a CodeQL variant analysis. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getVariantAnalysis: API.OperationMethod<GetVariantAnalysisRequest, CodeScanningVariantAnalysis, GetVariantAnalysisError, GithubOpContext>;
export type GetVariantAnalysisRepoTaskError = GithubOpError;
/** Get the analysis status of a repository in a CodeQL variant analysis Gets the analysis status of a repository in a CodeQL variant analysis. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const getVariantAnalysisRepoTask: API.OperationMethod<GetVariantAnalysisRepoTaskRequest, CodeScanningVariantAnalysisRepoTask, GetVariantAnalysisRepoTaskError, GithubOpContext>;
export type ListAlertInstancesError = GithubOpError;
/** List instances of a code scanning alert Lists all instances of the specified code scanning alert. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const listAlertInstances: API.PaginatedOperationMethod<ListAlertInstancesRequest, ListAlertInstancesResponse, ListAlertInstancesError, GithubOpContext, CodeScanningAlertInstanceList>;
export type ListAlertsForOrgError = GithubOpError;
/** List code scanning alerts for an organization Lists code scanning alerts for the default branch for all eligible repositories in an organization. Eligible repositories are repositories that are owned by organizations that you own or for which you are a security manager. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` or `repo`s cope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const listAlertsForOrg: API.PaginatedOperationMethod<ListAlertsForOrgRequest, ListAlertsForOrgResponse, ListAlertsForOrgError, GithubOpContext, CodeScanningOrganizationAlertItems>;
export type ListAlertsForRepoError = GithubOpError;
/** List code scanning alerts for a repository Lists code scanning alerts. The response includes a `most_recent_instance` object. This provides details of the most recent instance of this alert for the default branch (or for the specified Git reference if you used `ref` in the request). OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const listAlertsForRepo: API.PaginatedOperationMethod<ListAlertsForRepoRequest, ListAlertsForRepoResponse, ListAlertsForRepoError, GithubOpContext, CodeScanningAlertItems>;
export type ListCodeqlDatabasesError = GithubOpError;
/** List CodeQL databases for a repository Lists the CodeQL databases that are available in a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const listCodeqlDatabases: API.OperationMethod<ListCodeqlDatabasesRequest, ListCodeqlDatabasesResponse, ListCodeqlDatabasesError, GithubOpContext>;
export type ListRecentAnalysesError = GithubOpError;
/** List code scanning analyses for a repository Lists the details of all code scanning analyses for a repository, starting with the most recent. The response is paginated and you can use the `page` and `per_page` parameters to list the analyses you're interested in. By default 30 analyses are listed per page. The `rules_count` field in the response give the number of rules that were run in the analysis. For very old analyses this data is not available, and `0` is returned in this field. > [!WARNING] > **Closing down notice:** The `tool_name` field is closing down and will, in future, not be included in the response for this endpoint. The example response reflects this change. The tool name can now be found inside the `tool` field. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const listRecentAnalyses: API.PaginatedOperationMethod<ListRecentAnalysesRequest, ListRecentAnalysesResponse, ListRecentAnalysesError, GithubOpContext, CodeScanningAnalysis>;
export type UpdateAiScanEnablementError = GithubOpError;
/** Update AI Scan enablement for a repository Updates whether AI Scan is enabled for a repository. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const updateAiScanEnablement: API.OperationMethod<UpdateAiScanEnablementRequest, CodeScanningAiScanEnablement, UpdateAiScanEnablementError, GithubOpContext>;
export type UpdateAiScanEnablementForOrgError = GithubOpError;
/** Update the AI Scan setting for an organization Updates the AI Scan setting stored on an organization. The organization respects the enterprise policy, so enabling is rejected when the enterprise disallows AI Scan. OAuth app tokens and personal access tokens (classic) need the `admin:org`, `repo`, or `write:org` scope to use this endpoint. Organization owners can use `admin:org` or `repo`; security managers need `write:org`. */
export declare const updateAiScanEnablementForOrg: API.OperationMethod<UpdateAiScanEnablementForOrgRequest, CodeScanningAiScanOrgSettings, UpdateAiScanEnablementForOrgError, GithubOpContext>;
export type UpdateAlertError = GithubOpError;
/** Update a code scanning alert Updates the status of a single code scanning alert. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const updateAlert: API.OperationMethod<UpdateAlertRequest, CodeScanningAlert, UpdateAlertError, GithubOpContext>;
export type UpdateDefaultSetupError = GithubOpError;
/** Update a code scanning default setup configuration Updates a code scanning default setup configuration. OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. */
export declare const updateDefaultSetup: API.OperationMethod<UpdateDefaultSetupRequest, UpdateDefaultSetupResponse, UpdateDefaultSetupError, GithubOpContext>;
export type UploadSarifError = GithubOpError;
/** Upload an analysis as SARIF data Uploads SARIF data containing the results of a code scanning analysis to make the results available in a repository. For troubleshooting information, see "[Troubleshooting SARIF uploads](https://docs.github.com/code-security/code-scanning/troubleshooting-sarif)." There are two places where you can upload code scanning results. - If you upload to a pull request, for example `--ref refs/pull/42/merge` or `--ref refs/pull/42/head`, then the results appear as alerts in a pull request check. For more information, see "[Triaging code scanning alerts in pull requests](/code-security/secure-coding/triaging-code-scanning-alerts-in-pull-requests)." - If you upload to a branch, for example `--ref refs/heads/my-branch`, then the results appear in the **Security** tab for your repository. For more information, see "[Managing code scanning alerts for your repository](/code-security/secure-coding/managing-code-scanning-alerts-for-your-repository#viewing-the-alerts-for-a-repository)." You must compress the SARIF-formatted analysis data that you want to upload, using `gzip`, and then encode it as a Base64 format string. For example: ``` gzip -c analysis-data.sarif | base64 -w0 ``` SARIF upload supports a maximum number of entries per the following data objects, and an analysis will be rejected if any of these objects is above its maximum value. For some objects, there are additional values over which the entries will be ignored while keeping the most important entries whenever applicable. To get the most out of your analysis when it includes data above the supported limits, try to optimize the analysis configuration. For example, for the CodeQL tool, identify and remove the most noisy queries. For more information, see "[SARIF results exceed one or more limits](https://docs.github.com/code-security/code-scanning/troubleshooting-sarif/results-exceed-limit)." The `202 Accepted` response includes an `id` value. You can use this ID to check the status of the upload by using it in the `/sarifs/{sarif_id}` endpoint. For more information, see "[Get information about a SARIF upload](/rest/code-scanning/code-scanning#get-information-about-a-sarif-upload)." OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint with private or public repositories, or the `public_repo` scope to use this endpoint with only public repositories. This endpoint is limited to 1,000 requests per hour for each user or app installation calling it. */
export declare const uploadSarif: API.OperationMethod<UploadSarifRequest, UploadSarifResponse, UploadSarifError, GithubOpContext>;
//# sourceMappingURL=code_scanning.d.ts.map