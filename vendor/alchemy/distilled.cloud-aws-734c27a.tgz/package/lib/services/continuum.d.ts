import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly quotaCode: any;
    readonly serviceCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly fieldList: any;
}>;
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EnvironmentId = string;
export type AssociationClientToken = string;
export type CollectorArn = string;
export type EnvironmentSourceRoleArn = string;
export interface AssociateCollectorInput {
    environmentId: string;
    clientToken?: string | undefined;
    collectorArn: string;
    collectorDataAccessRoleArn: string;
}
export type EnvironmentArn = string;
export type CollectorId = string;
export interface AssociatedCollector {
    collectorId: string;
    collectorArn: string;
}
export interface AssociateCollectorOutput {
    environmentId: string;
    environmentArn: string;
    associatedCollector: AssociatedCollector;
}
export type FindingClientToken = string;
export interface CreateCodeFindingInput {
    environmentId: string;
    ocsfDocument: any;
    clientToken?: string | undefined;
}
export type FindingId = string;
export type FindingArn = string;
export type FindingTitle = string;
export type FindingStatus = "SUBMITTED" | "VALIDATING" | "CONFIRMED" | "DISCARDED" | (string & {});
export interface CreateCodeFindingOutput {
    findingId: string;
    findingArn: string;
    title: string;
    status: FindingStatus;
    createdAt: Date;
}
export type ScanClientToken = string;
export interface CreateCodeScanInput {
    environmentId: string;
    clientToken?: string | undefined;
}
export type ScanRunId = string;
export type ScanStatus = "SUBMITTED" | "WAITING_FOR_BUILD" | "BUILDING" | "WAITING_FOR_SCAN" | "SCANNING" | "SUCCEEDED" | "FAILED" | (string & {});
export type ScanOrigin = "MANUAL" | "SCHEDULED" | (string & {});
export type ScanRunFailureMessage = string;
export type ScanFailureStage = "SUBMITTED" | "WAITING_FOR_BUILD" | "BUILDING" | "WAITING_FOR_SCAN" | "SCANNING" | (string & {});
export interface CodeScanSummary {
    scanRunId: string;
    status: ScanStatus;
    origin: ScanOrigin;
    createdAt: Date;
    completedAt?: Date | undefined;
    failureMessage?: string | undefined;
    failureStage?: ScanFailureStage | undefined;
}
export interface CreateCodeScanOutput {
    scan: CodeScanSummary;
}
export type CollectorType = "AWS_COLLECTOR" | (string & {});
export type KubernetesClusterRoleArn = string;
export type KubernetesClusterExternalId = string | redacted.Redacted<string>;
export interface KubernetesClusterRoleConfiguration {
    roleArn: string;
    externalId?: string | redacted.Redacted<string> | undefined;
}
export type CollectorClientToken = string;
export interface CreateCollectorInput {
    type?: CollectorType | undefined;
    kubernetesClusterRole?: KubernetesClusterRoleConfiguration | undefined;
    clientToken?: string | undefined;
}
export type CollectorStatus = "ACTIVE" | "PENDING_DELETION" | (string & {});
export interface CreateCollectorOutput {
    collectorId: string;
    collectorArn: string;
    type: CollectorType;
    status: CollectorStatus;
    createdAt: Date;
}
export type EnvironmentName = string;
export type IntegrationId = string;
export type EnvironmentSourcePrefix = string;
export interface EnvironmentS3IntegrationSource {
    integrationId: string;
    codePrefix?: string | undefined;
    contextPrefix?: string | undefined;
}
export type EnvironmentS3Sources = EnvironmentS3IntegrationSource[];
export type RepositoryName = string;
export type RepositoryBranch = string;
export interface EnvironmentRepositorySource {
    integrationId: string;
    repository: string;
    defaultBranch?: string | undefined;
}
export type EnvironmentRepositorySources = EnvironmentRepositorySource[];
export interface EnvironmentSourceConfiguration {
    s3Sources?: EnvironmentS3IntegrationSource[] | undefined;
    repositorySources?: EnvironmentRepositorySource[] | undefined;
}
export type DomainName = string;
export type DomainNames = string[];
export interface EnvironmentNetworkConfiguration {
    allowedDomains?: string[] | undefined;
}
export type ScanFrequency = string;
export type PatchCreationPolicy = "ENABLED" | "DISABLED" | (string & {});
export interface EnvironmentConfiguration {
    network?: EnvironmentNetworkConfiguration | undefined;
    scanFrequency?: string | undefined;
    patchCreationPolicy?: PatchCreationPolicy | undefined;
}
export interface CreateCodeConfiguration {
    sourceConfiguration?: EnvironmentSourceConfiguration | undefined;
    environmentConfiguration?: EnvironmentConfiguration | undefined;
}
export interface CreateEnvironmentConfiguration {
    codeConfiguration?: CreateCodeConfiguration | undefined;
}
export interface CreateEnvironmentInput {
    name: string;
    configuration?: CreateEnvironmentConfiguration | undefined;
}
export type EnvironmentStatus = "ACTIVE" | (string & {});
export interface CreateEnvironmentOutput {
    environmentId: string;
    environmentArn: string;
    status: EnvironmentStatus;
    createdAt: Date;
}
export type IntegrationClientToken = string;
export type IntegrationName = string;
export type AuthorizationCode = string | redacted.Redacted<string>;
export type OAuthState = string | redacted.Redacted<string>;
export type RedirectUrl = string;
export interface GitHubAuthorizationConfiguration {
    authorizationCode: string | redacted.Redacted<string>;
    state: string | redacted.Redacted<string>;
    redirectUrl?: string | undefined;
}
export type GitHubOrganizationName = string;
export interface GitHubConfiguration {
    authorization: GitHubAuthorizationConfiguration;
    organizationName?: string | undefined;
}
export type GitLabInstanceUrl = string;
export type GitLabTargetType = "GROUP" | "PROJECT" | (string & {});
export type GitLabTargetPath = string;
export type GitLabAccessToken = string | redacted.Redacted<string>;
export interface GitLabConfiguration {
    instanceUrl: string;
    targetType: GitLabTargetType;
    targetPath: string;
    accessToken: string | redacted.Redacted<string>;
}
export type IntegrationS3BucketName = string;
export type IntegrationS3RoleArn = string;
export type IntegrationS3ExternalId = string | redacted.Redacted<string>;
export interface S3Configuration {
    bucket: string;
    roleArn: string;
    externalId: string | redacted.Redacted<string>;
}
export type ProviderConfiguration = {
    github: GitHubConfiguration;
    gitlab?: undefined;
    s3?: undefined;
} | {
    github?: undefined;
    gitlab: GitLabConfiguration;
    s3?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    s3: S3Configuration;
};
export interface CreateIntegrationInput {
    clientToken?: string | undefined;
    name: string;
    providerConfiguration: ProviderConfiguration;
}
export type IntegrationArn = string;
export interface CreateIntegrationOutput {
    integrationId: string;
    integrationArn: string;
    createdAt: Date;
}
export interface DeleteCollectorInput {
    collectorId: string;
}
export interface DeleteCollectorResponse {
}
export interface DeleteEnvironmentInput {
    environmentId: string;
}
export interface DeleteEnvironmentResponse {
}
export interface DeleteIntegrationInput {
    integrationId: string;
}
export interface DeleteIntegrationResponse {
}
export interface DisassociateCollectorInput {
    environmentId: string;
    collectorArn: string;
}
export interface DisassociateCollectorResponse {
}
export interface GetCodeFindingInput {
    environmentId: string;
    findingId: string;
}
export type FindingType = "CONTINUUM_CODE_VULN" | "CUSTOMER_CODE_VULN" | (string & {});
export type FindingSeverityId = "UNKNOWN" | "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | "FATAL" | "OTHER" | (string & {});
export type FindingDescription = string;
export type FindingCategory = string;
export type CweId = string;
export type CweIdList = string[];
export type FindingFilePath = string;
export type CveId = string;
export type PackageName = string;
export type PackageVersion = string;
export type PackageManager = string;
export interface AffectedPackage {
    name: string;
    version?: string | undefined;
    fixedInVersion?: string | undefined;
    packageManager?: string | undefined;
}
export type AffectedPackageList = AffectedPackage[];
export type FindingCodeSnippet = string;
export type FindingListEntry = string;
export type FindingStringList = string[];
export type FindingVerdict = "TRUE_POSITIVE" | "FALSE_POSITIVE" | "BENIGN_TRUE_POSITIVE" | "NEEDS_REVIEW" | (string & {});
export type FindingBlockingReason = "UNREACHABLE" | "PROTECTED" | "MISCLASSIFIED" | "EXCLUDED" | "NOT_FEASIBLE" | "RISK_MITIGATED" | "NONE" | (string & {});
export type FindingSeverityAdjustment = "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "INFORMATIONAL" | "UNCHANGED" | (string & {});
export interface FindingEvidence {
    file?: string | undefined;
    line?: number | undefined;
    snippet?: string | undefined;
}
export type FindingEvidenceList = FindingEvidence[];
export interface FindingValidation {
    verdict: FindingVerdict;
    blockingReason?: FindingBlockingReason | undefined;
    confidence?: number | undefined;
    rationale?: string | undefined;
    severityAdjustment?: FindingSeverityAdjustment | undefined;
    mitigatingControls?: string[] | undefined;
    preconditions?: string[] | undefined;
    evidence?: FindingEvidence[] | undefined;
}
export type FindingOcsfClass = "VULNERABILITY_FINDING" | "APPLICATION_SECURITY_POSTURE_FINDING" | (string & {});
export interface FindingLocation {
    filePath?: string | undefined;
    startLine?: number | undefined;
    endLine?: number | undefined;
}
export type FindingLocationList = FindingLocation[];
export interface FindingVulnerability {
    title?: string | undefined;
    description?: string | undefined;
    cweId?: string | undefined;
    cweCaption?: string | undefined;
    additionalCweIds?: string[] | undefined;
    cveId?: string | undefined;
    cvssBaseScore?: number | undefined;
    fixCoverage?: string | undefined;
    fixCoverageId?: number | undefined;
    locations?: FindingLocation[] | undefined;
    remediation?: string | undefined;
    remediationReferences?: string[] | undefined;
    code?: string | undefined;
    details?: string | undefined;
    affectedPackages?: AffectedPackage[] | undefined;
}
export type FindingVulnerabilityList = FindingVulnerability[];
export type FindingResourceUid = string;
export interface FindingResource {
    uid?: string | undefined;
    name?: string | undefined;
    type?: string | undefined;
    region?: string | undefined;
}
export type FindingResourceList = FindingResource[];
export interface FindingComplianceCheck {
    uid?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
}
export type FindingComplianceCheckList = FindingComplianceCheck[];
export interface FindingPosture {
    application?: string | undefined;
    applicationUid?: string | undefined;
    applicationVersion?: string | undefined;
    control?: string | undefined;
    description?: string | undefined;
    standards?: string[] | undefined;
    requirements?: string[] | undefined;
    checks?: FindingComplianceCheck[] | undefined;
    status?: string | undefined;
    statusId?: number | undefined;
    remediation?: string | undefined;
    remediationReferences?: string[] | undefined;
}
export type FindingSource = string;
export type SourceFindingId = string;
export type FindingStatusMessage = string;
export type FindingDiscardReason = "SCANNER_VALIDATED_FALSE_POSITIVE" | "SCANNER_NEEDS_REVIEW" | "FALSE_POSITIVE_VALIDATED_AGAINST_CONTEXT" | "DUPLICATE_OF_OPEN_ISSUE" | "DUPLICATE_OF_CLOSED_ISSUE" | "COMPENSATING_CONTROL_PRESENT" | "OUT_OF_SCOPE" | "INSUFFICIENT_EVIDENCE" | "PROCESSING_FAILED" | "SOURCE_REPO_NOT_FOUND" | (string & {});
export type IssueId = string;
export interface GetCodeFindingOutput {
    type: FindingType;
    title: string;
    severity: FindingSeverityId;
    summary?: string | undefined;
    detailedDescription?: string | undefined;
    category?: string | undefined;
    subCategory?: string | undefined;
    cweIds?: string[] | undefined;
    owaspCategory?: string | undefined;
    mitigation?: string | undefined;
    filePath?: string | undefined;
    lineNumber?: number | undefined;
    cveId?: string | undefined;
    cvssBaseScore?: number | undefined;
    affectedPackages?: AffectedPackage[] | undefined;
    vulnerableCode?: string | undefined;
    relevantInputs?: string[] | undefined;
    stepsToReproduce?: string[] | undefined;
    validation?: FindingValidation | undefined;
    endLine?: number | undefined;
    mitreTechniques?: string[] | undefined;
    remediationReferences?: string[] | undefined;
    ocsfClass?: FindingOcsfClass | undefined;
    ocsfSchemaVersion?: string | undefined;
    productName?: string | undefined;
    productVendorName?: string | undefined;
    productVersion?: string | undefined;
    sourceStatus?: string | undefined;
    sourceStatusId?: number | undefined;
    firstSeenAt?: Date | undefined;
    findingTypes?: string[] | undefined;
    vulnerabilities?: FindingVulnerability[] | undefined;
    resources?: FindingResource[] | undefined;
    posture?: FindingPosture | undefined;
    findingId: string;
    findingArn: string;
    environmentId: string;
    source: string;
    sourceFindingId: string;
    reportedAt: Date;
    status: FindingStatus;
    statusUpdatedAt: Date;
    createdAt: Date;
    scanRunId?: string | undefined;
    statusMessage?: string | undefined;
    discardReason?: FindingDiscardReason | undefined;
    discardReasoning?: string | undefined;
    duplicateOfIssueId?: string | undefined;
    createdIssueId?: string | undefined;
    completedAt?: Date | undefined;
}
export interface GetCodeIssueInput {
    environmentId: string;
    issueId: string;
}
export type IssueArn = string;
export type IssueName = string;
export type IssueSynopsis = string;
export type IssueSeverity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export type IssueConfidence = number;
export type IssueSeverityReasoning = string;
export type IssueRemediationSummary = string;
export type IssueFindingIds = string[];
export type IssueStatus = "CREATED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type IssuePhase = "VALIDATION" | "PRIORITIZATION" | "REMEDIATION" | (string & {});
export type IssueStatusReason = "INTERNAL_ERROR" | "REMEDIATION_FAILED" | (string & {});
export type IssueStatusMessage = string;
export type IssueEvidenceAvailability = "NONE" | "AVAILABLE" | (string & {});
export type IssuePatchDeliveryStatus = "PENDING" | "SUCCEEDED" | "FAILED" | "SKIPPED" | (string & {});
export type IssuePatchDeliveryCount = number;
export type DeliveryReason = "ARTIFACT_READ_FAILED" | "ARTIFACT_SOURCE_MISMATCH" | "ARTIFACT_SOURCE_MISSING" | "BUILD_NOT_FOUND" | "BUILD_READ_FAILED" | "BUILD_RESULT_SCOPE_MISMATCH" | "DELIVERY_NOT_CONFIGURED" | "DELIVERY_SOURCE_KIND_CHANGED" | "DUPLICATE_LOGICAL_REPOSITORY" | "DUPLICATE_OR_INVALID_REPOSITORY" | "ENVIRONMENT_DELETED" | "ENVIRONMENT_NOT_ACTIVE" | "ENVIRONMENT_NOT_FOUND" | "ENVIRONMENT_READ_FAILED" | "S3_ACCESS_DENIED" | "S3_SOURCE_PREFIX_OVERLAP" | "SOURCE_INTEGRATION_UNRESOLVED" | "SOURCE_INTEGRATION_READ_FAILED" | "SOURCE_INTEGRATION_INVALID" | "SOURCE_INTEGRATION_CHANGED" | "EXPORT_CREDENTIALS_MISSING" | "EXPORT_CREDENTIAL_EXPIRY_INVALID" | "EXPORT_DESTINATION_INVALID" | "EXPORT_EXISTING_OBJECT_MISMATCH" | "EXPORT_PUT_FAILED" | "EXPORT_RECONCILIATION_READ_FAILED" | "EXPORT_ROLE_ASSUMPTION_FAILED" | "GITHUB_ACCESS_DENIED" | "GITHUB_BASE_NOT_FOUND" | "GITHUB_BRANCH_CONFLICT" | "GITHUB_NOT_FOUND" | "GITHUB_RATE_LIMITED" | "GITHUB_REPOSITORY_CHANGED" | "GITHUB_REPOSITORY_NOT_FOUND" | "GITHUB_REQUEST_FAILED" | "GITHUB_REQUEST_REJECTED" | "GITHUB_RESPONSE_INVALID" | "GREEN_ATTEMPT_NOT_SUCCESSFUL" | "GREEN_COMPLETION_NOT_OBSERVED" | "PATCH_NOT_SELECTED" | "INCOMPLETE_SOURCE_REFERENCE" | "INVALID_ARCHIVE_DIGEST" | "INVALID_ARTIFACT_SOURCE" | "INVALID_COMPLETED_MANIFEST" | "INVALID_EXPORT_RECEIPT" | "INVALID_GITHUB_PROVENANCE" | "INVALID_S3_DESTINATION" | "INVALID_SERVICE_RECEIPT" | "INVALID_SOURCE_INVENTORY" | "INVALID_SOURCE_MANIFEST" | "INVALID_SOURCE_REFERENCE" | "ISSUE_INTEGRITY_FAILURE" | "ISSUE_NOT_FOUND" | "MANIFEST_INVENTORY_MISMATCH" | "MANIFEST_PROVENANCE_CHANGED" | "MANIFEST_REPOSITORY_SET_MISMATCH" | "MANIFEST_SCOPE_OR_VERSION_MISMATCH" | "MISSING_BUILD_RESULT" | "MISSING_COMPLETED_MANIFEST" | "MISSING_RESULT_DIGEST" | "MISSING_SOURCE_MANIFEST" | "MISSING_SOURCE_TARGET" | "PATCH_NOT_APPLICABLE" | "PATCH_STORAGE_IDENTITY_MISSING" | "PATCH_UNSUPPORTED" | "PUBLICATION_OUTCOME_UNKNOWN_AFTER_RETRY_LIMIT" | "PUBLISHER_DEADLINE_EXCEEDED" | "RESULT_COMPLETED_MANIFEST_MISMATCH" | "RESULT_SOURCE_BINDING_MISMATCH" | "SERVICE_COPY_DIGEST_MISMATCH" | "SERVICE_OBJECT_READ_FAILED" | "SERVICE_OBJECT_TOO_LARGE" | "SERVICE_RECEIPT_OUTSIDE_ISSUE" | "SOURCE_OBJECT_DIGEST_MISMATCH" | "SOURCE_REFERENCE_OUTSIDE_BUILD" | "SOURCE_TARGET_BUILD_MISMATCH" | "UNKNOWN_REPOSITORY" | "UNKNOWN_SOURCE_PROVIDER" | "UNSUPPORTED_ENVIRONMENT_SCHEMA" | "github_destination_not_enabled" | "patch_creation_policy_disabled" | (string & {});
export type IssuePatchDeliveryFailureReasons = DeliveryReason[];
export interface IssuePatchDelivery {
    status: IssuePatchDeliveryStatus;
    patchCount: number;
    succeededCount: number;
    failedCount: number;
    failureReasons?: DeliveryReason[] | undefined;
}
export interface GetCodeIssueOutput {
    issueId: string;
    issueArn: string;
    name: string;
    synopsis: string;
    severity?: IssueSeverity | undefined;
    confidence?: number | undefined;
    severityReasoning?: string | undefined;
    summary?: string | undefined;
    findingIds: string[];
    status: IssueStatus;
    phase?: IssuePhase | undefined;
    statusReason?: IssueStatusReason | undefined;
    statusMessage?: string | undefined;
    statusUpdatedAt: Date;
    createdAt: Date;
    updatedAt?: Date | undefined;
    evidenceAvailability?: IssueEvidenceAvailability | undefined;
    patchDelivery?: IssuePatchDelivery | undefined;
}
export type IssueArtifactId = string;
export interface GetCodeIssueArtifactInput {
    environmentId: string;
    issueId: string;
    artifactId: string;
}
export type IssueArtifactType = "EVIDENCE" | "AGENT_COMMUNICATION" | "VALIDATION_EVIDENCE" | "REMEDIATION_PROPOSAL" | "DECISION" | "PATCH" | (string & {});
export type IssueArtifactMediaType = string;
export type ExploitabilityVerdict = "EXPLOITABLE" | "NOT_EXPLOITABLE" | "UNCERTAIN" | (string & {});
export type ValidationTerminalStatus = "COMPLETED" | "FAILED" | "NO_SOURCE_AVAILABLE" | "PARTIAL" | (string & {});
export type AttackFlowId = string;
export type FlowVerdictValue = "CONFIRMED" | "DENIED" | "INCONCLUSIVE" | (string & {});
export type ValidationConfidence = number;
export type ArtifactCitation = string;
export type ArtifactCitations = string[];
export interface FlowVerdict {
    flowId: string;
    verdict: FlowVerdictValue;
    confidence?: number | undefined;
    evidence?: string[] | undefined;
}
export type FlowVerdicts = FlowVerdict[];
export type AttackFlowIds = string[];
export type ArtifactText = string;
export type ArtifactHttpMethod = "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE" | "OPTIONS" | (string & {});
export type ArtifactHeaders = {
    [key: string]: string | undefined;
};
export type ArtifactProofBody = string;
export type ExploitEffect = "DATA_LEAKED" | "ERROR_REVEALED" | "BEHAVIOR_CHANGED" | "NO_EFFECT" | (string & {});
export interface ValidationExploitArtifact {
    payload: string;
    targetUrl: string;
    httpMethod: ArtifactHttpMethod;
    headers?: {
        [key: string]: string | undefined;
    } | undefined;
    responseStatus?: number | undefined;
    responseSnippet?: string | undefined;
    effect: ExploitEffect;
}
export type ValidationProofMaterialText = string;
export interface ValidationProofMaterial {
    content: string;
}
export type ValidationProofMaterials = ValidationProofMaterial[];
export interface ValidationProofCode {
    proofCode: ValidationProofMaterial[];
}
export type ValidationProofConsoleOutput = string;
export interface ValidationProofOutput {
    consoleOutput: string;
}
export interface ValidationExecutedProof {
    code: ValidationProofCode;
    output?: ValidationProofOutput | undefined;
    observedEffect?: ExploitEffect | undefined;
}
export type ValidationProofSummary = string;
export interface ValidationSourceAnalysis {
    summary: string;
    inferredEffect?: ExploitEffect | undefined;
}
export interface ReasoningStep {
    step: number;
    claim: string;
    source: string;
    confidence?: number | undefined;
}
export type ReasoningSteps = ReasoningStep[];
export interface PerFindingResult {
    findingId: string;
    exploitable: ExploitabilityVerdict;
    confidence?: number | undefined;
    flowVerdicts?: FlowVerdict[] | undefined;
    reasoningChain?: ReasoningStep[] | undefined;
    exploitArtifact?: ValidationExploitArtifact | undefined;
}
export type PerFindingResults = PerFindingResult[];
export interface ValidationEvidenceBody {
    exploitable: ExploitabilityVerdict;
    terminalStatus?: ValidationTerminalStatus | undefined;
    flowVerdicts?: FlowVerdict[] | undefined;
    attackFlowsConfirmed?: string[] | undefined;
    exploitArtifact?: ValidationExploitArtifact | undefined;
    executedProof?: ValidationExecutedProof | undefined;
    sourceAnalysis?: ValidationSourceAnalysis | undefined;
    perFindingResults?: PerFindingResult[] | undefined;
}
export type IssueArtifactProducerName = string;
export type SignalDimension = "EXPLOITABILITY" | "BLAST_RADIUS" | "NETWORK_EXPOSURE" | "PRECONDITION" | "CODE_CONTEXT" | "LIKELIHOOD_ASSESSMENT" | "IMPACT_ASSESSMENT" | (string & {});
export type SignalStrength = "NONE" | "WEAK" | "MODERATE" | "STRONG" | (string & {});
export interface SignalConfidenceReasoning {
    summary: string;
    factors?: string[] | undefined;
}
export type SignalBand = "VERY_LOW" | "LOW" | "MODERATE" | "HIGH" | (string & {});
export interface SignalComputation {
    likelihoodBand?: SignalBand | undefined;
    impactBand?: SignalBand | undefined;
    barriers?: number | undefined;
}
export type SignalBasis = "CODE" | "GRAPH" | "FINDING" | "INFERRED" | "NO_EVIDENCE_DEFAULT" | (string & {});
export interface SignalPrecondition {
    value?: boolean | undefined;
    basis?: SignalBasis | undefined;
    reason?: string | undefined;
    missingInfo?: string | undefined;
}
export type SignalAccessLevel = "NONE" | "ANY_AUTHENTICATED" | "PRIVILEGED" | (string & {});
export interface SignalAccessPrecondition {
    value?: SignalAccessLevel | undefined;
    basis?: SignalBasis | undefined;
    reason?: string | undefined;
    missingInfo?: string | undefined;
}
export interface SignalPreconditions {
    reachableFromAttacker?: SignalPrecondition | undefined;
    configurationNeeded?: SignalPrecondition | undefined;
    accessLevel?: SignalAccessPrecondition | undefined;
    userInteractionRequired?: SignalPrecondition | undefined;
}
export type SignalAttackerGains = "EXECUTE" | "MODIFY_PRIVILEGED" | "MODIFY_DATA" | "MODIFY_COSMETIC" | "READ" | "NEITHER" | (string & {});
export interface SignalAttackerGainsDimension {
    value?: SignalAttackerGains | undefined;
    basis?: SignalBasis | undefined;
    reason?: string | undefined;
    missingInfo?: string | undefined;
}
export type SignalBlastRadius = "CROSS_TENANT" | "OTHER_USERS_IN_TENANT" | "OWN_SCOPE" | (string & {});
export interface SignalBlastRadiusDimension {
    value?: SignalBlastRadius | undefined;
    basis?: SignalBasis | undefined;
    reason?: string | undefined;
    missingInfo?: string | undefined;
}
export type SignalTargetValue = "HIGH" | "MEDIUM" | "LOW" | (string & {});
export interface SignalTargetValueDimension {
    value?: SignalTargetValue | undefined;
    basis?: SignalBasis | undefined;
    reason?: string | undefined;
    missingInfo?: string | undefined;
}
export interface SignalImpactDimensions {
    attackerGains?: SignalAttackerGainsDimension | undefined;
    blastRadius?: SignalBlastRadiusDimension | undefined;
    targetValue?: SignalTargetValueDimension | undefined;
}
export type ValidationConfidenceTier = "SOURCE_READ" | "STATIC_PROVEN" | "BUILD_PROVEN" | "RUNTIME_PROVEN" | (string & {});
export interface SignalExploitability {
    verdict?: ExploitabilityVerdict | undefined;
    reachedCrownJewels?: boolean | undefined;
    highestLayerReached?: number | undefined;
    confidenceTier?: ValidationConfidenceTier | undefined;
    scriptable?: boolean | undefined;
    sourceValidationArtifactId?: string | undefined;
}
export interface PrevalidationSignal {
    subjectRef?: string | undefined;
    dimension?: SignalDimension | undefined;
    signalStrength?: SignalStrength | undefined;
    conclusion?: string | undefined;
    producerId?: string | undefined;
    producerVersion?: string | undefined;
    confidence?: number | undefined;
    confidenceReasoning?: SignalConfidenceReasoning | undefined;
    computed?: SignalComputation | undefined;
    preconditions?: SignalPreconditions | undefined;
    impactDimensions?: SignalImpactDimensions | undefined;
    exploitability?: SignalExploitability | undefined;
}
export type PrevalidationSignals = PrevalidationSignal[];
export interface PrevalidationSignalsBody {
    producedBy?: string | undefined;
    signals?: PrevalidationSignal[] | undefined;
}
export type IssueArtifactContent = string;
export type PatchFormat = "GIT_MAILBOX_PATCH" | "GIT_BINARY_DIFF" | "GIT_DIFF" | (string & {});
export type ArtifactSha256 = string;
export interface RemediationProposalBody {
    patch: string;
    format?: PatchFormat | undefined;
    filename?: string | undefined;
    patchSha256?: string | undefined;
}
export type BuildRepositoryName = string;
export type DeliveryStatus = "PENDING" | "SUCCEEDED" | "FAILED" | "SKIPPED" | "ABANDONED" | (string & {});
export type EnvironmentSourceBucketName = string;
export type DeliveryObjectKey = string;
export type DeliveryVersionId = string;
export interface S3Target {
    bucket: string;
    key: string;
    version?: string | undefined;
}
export type DeliveryGitHubName = string;
export type DeliveryPullRequestNumber = number;
export type DeliveryGitCommitSha = string;
export interface GitHubTarget {
    owner: string;
    repository: string;
    pullRequestNumber?: number | undefined;
    headSha?: string | undefined;
}
export type DestinationTarget = {
    s3: S3Target;
    github?: undefined;
} | {
    s3?: undefined;
    github: GitHubTarget;
};
export interface PatchDelivery {
    status: DeliveryStatus;
    target?: DestinationTarget | undefined;
    updatedAt: Date;
}
export interface PatchBody {
    patch: string;
    format?: PatchFormat | undefined;
    repositoryName?: string | undefined;
    patchSha256: string;
    sizeBytes: number;
    delivery?: PatchDelivery | undefined;
}
export type IssueArtifactBody = {
    validationEvidence: ValidationEvidenceBody;
    prevalidationSignals?: undefined;
    remediationProposal?: undefined;
    patch?: undefined;
    raw?: undefined;
} | {
    validationEvidence?: undefined;
    prevalidationSignals: PrevalidationSignalsBody;
    remediationProposal?: undefined;
    patch?: undefined;
    raw?: undefined;
} | {
    validationEvidence?: undefined;
    prevalidationSignals?: undefined;
    remediationProposal: RemediationProposalBody;
    patch?: undefined;
    raw?: undefined;
} | {
    validationEvidence?: undefined;
    prevalidationSignals?: undefined;
    remediationProposal?: undefined;
    patch: PatchBody;
    raw?: undefined;
} | {
    validationEvidence?: undefined;
    prevalidationSignals?: undefined;
    remediationProposal?: undefined;
    patch?: undefined;
    raw: string;
};
export interface IssueArtifactProducerSummary {
    agent: string;
}
export interface GetCodeIssueArtifactOutput {
    artifactId: string;
    artifactType: IssueArtifactType;
    mediaType: string;
    body: IssueArtifactBody;
    metadata?: any | undefined;
    producer: IssueArtifactProducerSummary;
    createdAt: Date;
}
export interface GetCodeScanInput {
    environmentId: string;
    scanRunId: string;
}
export interface CodeScanData {
    scanRunId: string;
    status: ScanStatus;
    origin: ScanOrigin;
    createdAt: Date;
    completedAt?: Date | undefined;
    failureMessage?: string | undefined;
    failureStage?: ScanFailureStage | undefined;
}
export interface GetCodeScanOutput {
    scan: CodeScanData;
}
export interface GetCollectorInput {
    collectorId: string;
}
export type ConfigRecorderArn = string;
export interface GetCollectorOutput {
    collectorId: string;
    collectorArn: string;
    type: CollectorType;
    status: CollectorStatus;
    configRecorderArn?: string | undefined;
    kubernetesClusterRoleArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export type AwsAccountId = string;
export interface GetCollectorDataAccessAuthorizationInput {
    accountId: string;
    collectorId: string;
    environmentArn?: string | undefined;
}
export interface GetCollectorDataAccessAuthorizationOutput {
}
export interface GetEnvironmentInput {
    environmentId: string;
}
export type EnvironmentStatusMessage = string;
export interface CollectorDetails {
    collectorDataAccessRoleArn?: string | undefined;
}
export interface CodeConfigurationDetails {
    collectorDetails?: CollectorDetails | undefined;
    sourceConfiguration?: EnvironmentSourceConfiguration | undefined;
    environmentConfiguration?: EnvironmentConfiguration | undefined;
    latestScan?: CodeScanSummary | undefined;
}
export interface EnvironmentConfigurationDetails {
    codeConfiguration?: CodeConfigurationDetails | undefined;
}
export interface GetEnvironmentOutput {
    environmentId: string;
    environmentArn: string;
    name: string;
    status: EnvironmentStatus;
    statusMessage?: string | undefined;
    statusUpdatedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    configuration: EnvironmentConfigurationDetails;
}
export interface GetIntegrationInput {
    integrationId: string;
}
export type IntegrationType = "GITHUB" | "GITLAB" | "S3" | (string & {});
export interface GitHubDetails {
    organizationName?: string | undefined;
}
export type GitLabTokenRotation = "AUTOMATIC" | "NONE" | (string & {});
export interface GitLabDetails {
    instanceUrl: string;
    targetType: GitLabTargetType;
    targetPath: string;
    tokenRotation: GitLabTokenRotation;
    expiresAt?: Date | undefined;
}
export interface S3Details {
    bucket: string;
    roleArn: string;
}
export type ProviderDetails = {
    github: GitHubDetails;
    gitlab?: undefined;
    s3?: undefined;
} | {
    github?: undefined;
    gitlab: GitLabDetails;
    s3?: undefined;
} | {
    github?: undefined;
    gitlab?: undefined;
    s3: S3Details;
};
export interface GetIntegrationOutput {
    integrationId: string;
    integrationArn: string;
    name: string;
    integrationType: IntegrationType;
    providerDetails: ProviderDetails;
    createdAt: Date;
    updatedAt: Date;
}
export type ResourcePolicyTargetArn = string;
export interface GetResourcePolicyInput {
    arn: string;
}
export type ResourcePolicyDocument = string | redacted.Redacted<string>;
export type ResourcePolicyRevisionId = string;
export interface GetResourcePolicyOutput {
    arn: string;
    policy: string | redacted.Redacted<string>;
    revisionId: string;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAssociatedCollectorsInput {
    environmentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type AssociatedCollectors = AssociatedCollector[];
export interface ListAssociatedCollectorsOutput {
    associatedCollectors: AssociatedCollector[];
    nextToken?: string | undefined;
}
export interface ListAssociatedEnvironmentsInput {
    collectorId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AssociatedEnvironment {
    environmentId: string;
    environmentArn: string;
    name: string;
    status: EnvironmentStatus;
    createdAt: Date;
}
export type AssociatedEnvironments = AssociatedEnvironment[];
export interface ListAssociatedEnvironmentsOutput {
    associatedEnvironments: AssociatedEnvironment[];
    nextToken?: string | undefined;
}
export interface ListCodeFindingsInput {
    environmentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface FindingSummary {
    findingId: string;
    findingArn: string;
    environmentId: string;
    source: string;
    sourceFindingId: string;
    reportedAt: Date;
    status: FindingStatus;
    statusUpdatedAt: Date;
    createdAt: Date;
    scanRunId?: string | undefined;
    statusMessage?: string | undefined;
    discardReason?: FindingDiscardReason | undefined;
    discardReasoning?: string | undefined;
    duplicateOfIssueId?: string | undefined;
    createdIssueId?: string | undefined;
    completedAt?: Date | undefined;
    type: FindingType;
    title: string;
    severity: FindingSeverityId;
    category?: string | undefined;
    filePath?: string | undefined;
}
export type CodeFindingSummaries = FindingSummary[];
export interface ListCodeFindingsOutput {
    items: FindingSummary[];
    nextToken?: string | undefined;
}
export interface ListCodeIssueArtifactsInput {
    environmentId: string;
    issueId: string;
    artifactType?: IssueArtifactType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface IssueArtifactItem {
    artifactId: string;
    artifactType: IssueArtifactType;
    mediaType: string;
    producer: IssueArtifactProducerSummary;
    contentSizeBytes: number;
    createdAt: Date;
}
export type CodeIssueArtifactItems = IssueArtifactItem[];
export interface ListCodeIssueArtifactsOutput {
    items: IssueArtifactItem[];
    nextToken?: string | undefined;
}
export interface ListCodeIssuesInput {
    environmentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface IssueSummary {
    issueId: string;
    issueArn: string;
    name: string;
    severity?: IssueSeverity | undefined;
    confidence?: number | undefined;
    status: IssueStatus;
    phase?: IssuePhase | undefined;
    statusReason?: IssueStatusReason | undefined;
    statusMessage?: string | undefined;
    statusUpdatedAt: Date;
    createdAt: Date;
    updatedAt?: Date | undefined;
}
export type CodeIssueSummaries = IssueSummary[];
export interface ListCodeIssuesOutput {
    items: IssueSummary[];
    nextToken?: string | undefined;
}
export interface ListCodeScansInput {
    environmentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type CodeScanSummaries = CodeScanSummary[];
export interface ListCodeScansOutput {
    scans: CodeScanSummary[];
    nextToken?: string | undefined;
}
export interface ListCollectorsInput {
}
export interface CollectorSummary {
    collectorId: string;
    collectorArn: string;
    type: CollectorType;
    status: CollectorStatus;
    createdAt: Date;
}
export type CollectorSummaries = CollectorSummary[];
export interface ListCollectorsOutput {
    items: CollectorSummary[];
}
export interface ListEnvironmentsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EnvironmentListEntry {
    environmentId: string;
    environmentArn: string;
    name: string;
    status: EnvironmentStatus;
    createdAt: Date;
}
export type EnvironmentListEntries = EnvironmentListEntry[];
export interface ListEnvironmentsOutput {
    items: EnvironmentListEntry[];
    nextToken?: string | undefined;
}
export interface ListIntegrationsInput {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface IntegrationSummary {
    integrationId: string;
    integrationArn: string;
    name: string;
    integrationType: IntegrationType;
    providerDetails: ProviderDetails;
    createdAt: Date;
    updatedAt: Date;
}
export type IntegrationSummaries = IntegrationSummary[];
export interface ListIntegrationsOutput {
    items: IntegrationSummary[];
    nextToken?: string | undefined;
}
export type ResourcePolicyInputDocument = string | redacted.Redacted<string>;
export interface PutResourcePolicyInput {
    arn: string;
    policy?: string | redacted.Redacted<string> | undefined;
    expectedRevisionId?: string | undefined;
}
export interface PutResourcePolicyOutput {
    arn: string;
    policy: string | redacted.Redacted<string>;
    revisionId: string;
}
export type IntegrationAuthorizationProviderType = "GITHUB" | (string & {});
export interface StartIntegrationAuthorizationInput {
    providerType: IntegrationAuthorizationProviderType;
    name?: string | undefined;
}
export type OAuthCodeChallenge = string;
export type OAuthCodeChallengeMethod = "S256" | (string & {});
export interface StartIntegrationAuthorizationOutput {
    state: string | redacted.Redacted<string>;
    codeChallenge: string;
    codeChallengeMethod: OAuthCodeChallengeMethod;
    expiresAt: Date;
}
export type CollectorName = string;
export interface RemoveKubernetesClusterRole {
}
export type KubernetesClusterRoleUpdate = {
    set: KubernetesClusterRoleConfiguration;
    remove?: undefined;
} | {
    set?: undefined;
    remove: RemoveKubernetesClusterRole;
};
export interface UpdateCollectorInput {
    collectorId: string;
    name?: string | undefined;
    kubernetesClusterRole?: KubernetesClusterRoleUpdate | undefined;
}
export interface UpdateCollectorOutput {
    collectorId: string;
    collectorArn: string;
    type: CollectorType;
    status: CollectorStatus;
    configRecorderArn?: string | undefined;
    kubernetesClusterRoleArn?: string | undefined;
    createdAt: Date;
    updatedAt: Date;
}
export interface UpdateCodeConfiguration {
    sourceConfiguration?: EnvironmentSourceConfiguration | undefined;
    environmentConfiguration?: EnvironmentConfiguration | undefined;
}
export interface UpdateEnvironmentConfiguration {
    codeConfiguration?: UpdateCodeConfiguration | undefined;
}
export interface UpdateEnvironmentInput {
    environmentId: string;
    name?: string | undefined;
    configuration?: UpdateEnvironmentConfiguration | undefined;
}
export interface UpdateEnvironmentOutput {
    environmentId: string;
    environmentArn: string;
    name: string;
    status: EnvironmentStatus;
    statusMessage?: string | undefined;
    statusUpdatedAt: Date;
    createdAt: Date;
    configuration: EnvironmentConfigurationDetails;
}
export interface UpdateS3Configuration {
    roleArn: string;
    externalId?: string | redacted.Redacted<string> | undefined;
}
export type UpdateProviderConfiguration = {
    s3: UpdateS3Configuration;
};
export interface UpdateIntegrationInput {
    integrationId: string;
    providerConfiguration: UpdateProviderConfiguration;
}
export interface UpdateIntegrationOutput {
    integrationId: string;
    integrationArn: string;
    name: string;
    integrationType: IntegrationType;
    providerDetails: ProviderDetails;
    createdAt: Date;
    updatedAt: Date;
}
export interface ValidationExceptionField {
    path: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateCollectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Associates one Collector with this Environment and configures the customer role Continuum uses to authorize access to associated Collector data. The caller must have permission on the Environment and permission to pass the role. Continuum assumes the supplied role and calls GetCollectorDataAccessAuthorization on the requested Collector; only a successful authorization response permits the association. The caller does not need Collector data-access permission. The Environment retains its other Collector associations. Calling again with an existing association is safe and does not create a duplicate.
 */
export declare const associateCollector: API.OperationMethod<AssociateCollectorInput & RegionInput, AssociateCollectorOutput, AssociateCollectorError, Credentials | HttpClient.HttpClient>;
export type CreateCodeFindingError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Ingests a customer-supplied security finding into an environment. Continuum validates the document synchronously against the required overlay fields for the declared format; invalid documents are rejected with a ValidationException. The maximum accepted document size is 256 KB. The environment must have a source configured, and the finding must identify a code location so Continuum can tie it to a repository in the environment's build. Continuum assigns a findingId and stores the verbatim document. When no successful build yet contains the finding's repository, the finding stays SUBMITTED until the next successful build; if that build does not contain it either, the finding is DISCARDED with discardReason SOURCE_REPO_NOT_FOUND.
 */
export declare const createCodeFinding: API.OperationMethod<CreateCodeFindingInput & RegionInput, CreateCodeFindingOutput, CreateCodeFindingError, Credentials | HttpClient.HttpClient>;
export type CreateCodeScanError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an explicit scan request for one environment. CP creates durable work before
 * any queue delivery occurs.
 *
 * Retrying a request that succeeded, with the same clientToken on the same environment,
 * returns the original scan instead of starting another one. Token handling is not yet
 * atomic: requests with the same token that run at the same time, or a retry after a
 * request that failed partway through, can leave an additional scan, which may end in
 * the FAILED state with a message that it was superseded. Deleting the environment
 * makes its tokens unusable; a later request with one of them returns
 * ResourceNotFoundException.
 *
 * Each environment can have a limited number of scans in progress at the same time.
 * Once that limit is enforced, a request that would exceed it returns
 * ServiceQuotaExceededException; wait for a scan to finish (ListCodeScans shows each
 * scan's status), then retry.
 */
export declare const createCodeScan: API.OperationMethod<CreateCodeScanInput & RegionInput, CreateCodeScanOutput, CreateCodeScanError, Credentials | HttpClient.HttpClient>;
export type CreateCollectorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates the Collector for the caller's account. Provisions an AWS Config service-linked recorder using the caller's federated access session and begins recording infrastructure changes.
 */
export declare const createCollector: API.OperationMethod<CreateCollectorInput & RegionInput, CreateCollectorOutput, CreateCollectorError, Credentials | HttpClient.HttpClient>;
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an environment and starts its validation and any requested provisioning. Storage provisioning and dependency checks may continue after the initial 201 response; use GetEnvironment to observe completion.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentInput & RegionInput, CreateEnvironmentOutput, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new integration with an external source provider. Repeating an identical
 * request with the same clientToken returns the original integrationId, integrationArn,
 * and createdAt. Token records are retained for eight hours after success or terminal failure,
 * including after the integration is deleted; replaying a deleted integration's token
 * does not recreate it. An identical request with a retained terminal failure returns
 * the recorded error.
 *
 * Reusing a token with different parameters returns ValidationException. A fresh token
 * starts a new create attempt; if the name is already owned by another integration,
 * ConflictException includes that integration's identifier. An attempt still in progress
 * may return ThrottlingException with retryAfterSeconds set to 1; retry with the same token
 * and identical parameters.
 *
 * GitHub authorization codes are single use. Retry an unresolved attempt with its
 * original token and unchanged parameters first. If the service reports a terminal
 * failure, an expired attempt, or a successful token exchange whose integration could
 * not be saved, restart GitHub authorization with a fresh token and authorization code.
 * The service does not checkpoint provider results for recovery by another request.
 */
export declare const createIntegration: API.OperationMethod<CreateIntegrationInput & RegionInput, CreateIntegrationOutput, CreateIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteCollectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the Collector for the caller's account. The Collector first enters PENDING_DELETION, then the service removes its schedule, AWS Config service-linked recorder, versioned S3 bucket, KMS key, and persisted record.
 */
export declare const deleteCollector: API.OperationMethod<DeleteCollectorInput & RegionInput, DeleteCollectorResponse, DeleteCollectorError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an environment and its associated resources.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentInput & RegionInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an integration and releases its name and account quota. Its retained
 * CreateIntegration token receipt can still replay the original result without
 * recreating the integration. Shared provider registrations are retained: deleting
 * one integration does not remove provider access used by another integration.
 * A fresh GitHub CreateIntegration attempt requires a fresh OAuth authorization
 * code and a new clientToken.
 */
export declare const deleteIntegration: API.OperationMethod<DeleteIntegrationInput & RegionInput, DeleteIntegrationResponse, DeleteIntegrationError, Credentials | HttpClient.HttpClient>;
export type DisassociateCollectorError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one Collector association from this Environment, preserving its other associations. The stored Collector data-access role is cleared when no Collector associations remain. The Environment owner must have permission to disassociate. A current Collector access grant is not required, and the Collector does not need to remain active or present, so stale or revoked associations can be cleaned up.
 */
export declare const disassociateCollector: API.OperationMethod<DisassociateCollectorInput & RegionInput, DisassociateCollectorResponse, DisassociateCollectorError, Credentials | HttpClient.HttpClient>;
export type GetCodeFindingError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current state and details of a finding.
 */
export declare const getCodeFinding: API.OperationMethod<GetCodeFindingInput & RegionInput, GetCodeFindingOutput, GetCodeFindingError, Credentials | HttpClient.HttpClient>;
export type GetCodeIssueError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current state and details of an issue.
 */
export declare const getCodeIssue: API.OperationMethod<GetCodeIssueInput & RegionInput, GetCodeIssueOutput, GetCodeIssueError, Credentials | HttpClient.HttpClient>;
export type GetCodeIssueArtifactError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves one immutable artifact attached to an issue, including its content.
 */
export declare const getCodeIssueArtifact: API.OperationMethod<GetCodeIssueArtifactInput & RegionInput, GetCodeIssueArtifactOutput, GetCodeIssueArtifactError, Credentials | HttpClient.HttpClient>;
export type GetCodeScanError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves one customer-visible environment scan.
 */
export declare const getCodeScan: API.OperationMethod<GetCodeScanInput & RegionInput, GetCodeScanOutput, GetCodeScanError, Credentials | HttpClient.HttpClient>;
export type GetCollectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current state of the Collector for the caller's account.
 */
export declare const getCollector: API.OperationMethod<GetCollectorInput & RegionInput, GetCollectorOutput, GetCollectorError, Credentials | HttpClient.HttpClient>;
export type GetCollectorDataAccessAuthorizationError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Authorizes an Environment's access to a Collector's data. Continuum calls this
 * operation with the Environment's Collector data-access role before it reads the
 * Collector's inventory, so grant continuum:GetCollectorDataAccessAuthorization to
 * that role and, for a Collector in another account, in the Collector's resource
 * policy. The operation evaluates the action against the exact Collector ARN and
 * the Collector's current resource policy using IAM and the caller's authenticated
 * request context, with environmentArn as the continuum:EnvironmentArn condition
 * key. A successful request returns HTTP 200 with no response members. If access
 * is not granted, the operation returns AccessDeniedException without disclosing
 * Collector existence, ownership, or the policy layer that denied access. The
 * service does not reinterpret the policy using only an account ID.
 */
export declare const getCollectorDataAccessAuthorization: API.OperationMethod<GetCollectorDataAccessAuthorizationInput & RegionInput, GetCollectorDataAccessAuthorizationOutput, GetCollectorDataAccessAuthorizationError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the current state and configuration of an environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentInput & RegionInput, GetEnvironmentOutput, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about an integration.
 */
export declare const getIntegration: API.OperationMethod<GetIntegrationInput & RegionInput, GetIntegrationOutput, GetIntegrationError, Credentials | HttpClient.HttpClient>;
export type GetResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the resource policy attached to a Continuum resource.
 */
export declare const getResourcePolicy: API.OperationMethod<GetResourcePolicyInput & RegionInput, GetResourcePolicyOutput, GetResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type ListAssociatedCollectorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Collectors currently associated with one Environment in ascending collectorId order. Each entry carries the Collector ARN, so a listed association can be passed straight to DisassociateCollector, including when the Collector belongs to another account. An association recorded before Continuum persisted the ARN is omitted from the response, because without the ARN it cannot be acted on.
 */
export declare const listAssociatedCollectors: API.PaginatedOperationMethod<ListAssociatedCollectorsInput & RegionInput, ListAssociatedCollectorsOutput, ListAssociatedCollectorsError, Credentials | HttpClient.HttpClient, AssociatedCollector>;
export type ListAssociatedEnvironmentsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Environments currently associated with one Collector in lexicographically ascending environmentArn order. The ARN identifies each Environment across accounts within the Collector's Region.
 */
export declare const listAssociatedEnvironments: API.PaginatedOperationMethod<ListAssociatedEnvironmentsInput & RegionInput, ListAssociatedEnvironmentsOutput, ListAssociatedEnvironmentsError, Credentials | HttpClient.HttpClient, AssociatedEnvironment>;
export type ListCodeFindingsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the findings in an environment in descending findingId order.
 */
export declare const listCodeFindings: API.PaginatedOperationMethod<ListCodeFindingsInput & RegionInput, ListCodeFindingsOutput, ListCodeFindingsError, Credentials | HttpClient.HttpClient, FindingSummary>;
export type ListCodeIssueArtifactsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the artifacts attached to an issue in descending artifactId order. Content is returned by GetCodeIssueArtifact.
 */
export declare const listCodeIssueArtifacts: API.PaginatedOperationMethod<ListCodeIssueArtifactsInput & RegionInput, ListCodeIssueArtifactsOutput, ListCodeIssueArtifactsError, Credentials | HttpClient.HttpClient, IssueArtifactItem>;
export type ListCodeIssuesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the issues in an environment in descending issueId order.
 */
export declare const listCodeIssues: API.PaginatedOperationMethod<ListCodeIssuesInput & RegionInput, ListCodeIssuesOutput, ListCodeIssuesError, Credentials | HttpClient.HttpClient, IssueSummary>;
export type ListCodeScansError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists customer-visible scans for one environment in descending scanRunId order.
 */
export declare const listCodeScans: API.PaginatedOperationMethod<ListCodeScansInput & RegionInput, ListCodeScansOutput, ListCodeScansError, Credentials | HttpClient.HttpClient, CodeScanSummary>;
export type ListCollectorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the Collectors owned by the authenticated caller's account, including a Collector whose deletion is in progress. A Collector that is still being created is omitted. The account-scoped Collector quota currently permits at most one result, so no result ordering applies.
 */
export declare const listCollectors: API.OperationMethod<ListCollectorsInput & RegionInput, ListCollectorsOutput, ListCollectorsError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all environments in your account in descending environmentId order. This complete-inventory operation intentionally has no response filters; see the input documentation for the API standards justification.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsInput & RegionInput, ListEnvironmentsOutput, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentListEntry>;
export type ListIntegrationsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the integrations in your account in descending integrationId order.
 */
export declare const listIntegrations: API.PaginatedOperationMethod<ListIntegrationsInput & RegionInput, ListIntegrationsOutput, ListIntegrationsError, Credentials | HttpClient.HttpClient, IntegrationSummary>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or replaces the resource policy attached to a Continuum resource.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyInput & RegionInput, PutResourcePolicyOutput, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type StartIntegrationAuthorizationError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an OAuth authorization for a new integration and returns the values the caller sends to the provider's authorization endpoint. The authorization belongs to the calling AWS account, can be redeemed once by CreateIntegration from that same account, and expires after ten minutes.
 */
export declare const startIntegrationAuthorization: API.OperationMethod<StartIntegrationAuthorizationInput & RegionInput, StartIntegrationAuthorizationOutput, StartIntegrationAuthorizationError, Credentials | HttpClient.HttpClient>;
export type UpdateCollectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the customer-controlled mutable properties of a Collector. Only the name and Kubernetes cluster IAM role can be changed.
 */
export declare const updateCollector: API.OperationMethod<UpdateCollectorInput & RegionInput, UpdateCollectorOutput, UpdateCollectorError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the customer-controlled mutable properties of an environment. Only the name, the environment's S3 integration source and repository selections, its scan frequency, its network policy, and its patch creation policy can be changed.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentInput & RegionInput, UpdateEnvironmentOutput, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Rotates the credentials used by an Amazon S3 integration. Only S3 integrations can
 * be updated; GitHub integrations cannot be modified. The integration's name,
 * provider type, and bucket remain fixed.
 *
 * The caller must have iam:PassRole permission for the supplied role, including
 * when only the external ID changes. Continuum verifies that the role can be
 * assumed with the requested external ID and can access the existing bucket before
 * saving both credentials atomically. Omitting externalId preserves its current
 * value. Repeating both current credentials leaves updatedAt unchanged, but still
 * requires authorization and access validation.
 */
export declare const updateIntegration: API.OperationMethod<UpdateIntegrationInput & RegionInput, UpdateIntegrationOutput, UpdateIntegrationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=continuum.d.ts.map