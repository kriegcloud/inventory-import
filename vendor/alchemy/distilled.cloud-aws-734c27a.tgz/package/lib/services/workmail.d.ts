import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DirectoryInUseException_base: S.TaggedErrorClass<"DirectoryInUseException", {
    readonly message: any;
}>;
export declare class DirectoryInUseException extends /*@__PURE__*/ DirectoryInUseException_base {
}
declare const DirectoryServiceAuthenticationFailedException_base: S.TaggedErrorClass<"DirectoryServiceAuthenticationFailedException", {
    readonly message: any;
}>;
export declare class DirectoryServiceAuthenticationFailedException extends /*@__PURE__*/ DirectoryServiceAuthenticationFailedException_base {
}
declare const DirectoryUnavailableException_base: S.TaggedErrorClass<"DirectoryUnavailableException", {
    readonly message: any;
}>;
export declare class DirectoryUnavailableException extends /*@__PURE__*/ DirectoryUnavailableException_base {
}
declare const EmailAddressInUseException_base: S.TaggedErrorClass<"EmailAddressInUseException", {
    readonly message: any;
}>;
export declare class EmailAddressInUseException extends /*@__PURE__*/ EmailAddressInUseException_base {
}
declare const EntityAlreadyRegisteredException_base: S.TaggedErrorClass<"EntityAlreadyRegisteredException", {
    readonly message: any;
}>;
export declare class EntityAlreadyRegisteredException extends /*@__PURE__*/ EntityAlreadyRegisteredException_base {
}
declare const EntityNotFoundException_base: S.TaggedErrorClass<"EntityNotFoundException", {
    readonly message: any;
}>;
export declare class EntityNotFoundException extends /*@__PURE__*/ EntityNotFoundException_base {
}
declare const EntityStateException_base: S.TaggedErrorClass<"EntityStateException", {
    readonly message: any;
}>;
export declare class EntityStateException extends /*@__PURE__*/ EntityStateException_base {
}
declare const InvalidConfigurationException_base: S.TaggedErrorClass<"InvalidConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidConfigurationException extends /*@__PURE__*/ InvalidConfigurationException_base {
}
declare const InvalidCustomSesConfigurationException_base: S.TaggedErrorClass<"InvalidCustomSesConfigurationException", {
    readonly message: any;
}>;
export declare class InvalidCustomSesConfigurationException extends /*@__PURE__*/ InvalidCustomSesConfigurationException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
}>;
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidPasswordException_base: S.TaggedErrorClass<"InvalidPasswordException", {
    readonly message: any;
}>;
export declare class InvalidPasswordException extends /*@__PURE__*/ InvalidPasswordException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const MailDomainInUseException_base: S.TaggedErrorClass<"MailDomainInUseException", {
    readonly message: any;
}>;
export declare class MailDomainInUseException extends /*@__PURE__*/ MailDomainInUseException_base {
}
declare const MailDomainNotFoundException_base: S.TaggedErrorClass<"MailDomainNotFoundException", {
    readonly message: any;
}>;
export declare class MailDomainNotFoundException extends /*@__PURE__*/ MailDomainNotFoundException_base {
}
declare const MailDomainStateException_base: S.TaggedErrorClass<"MailDomainStateException", {
    readonly message: any;
}>;
export declare class MailDomainStateException extends /*@__PURE__*/ MailDomainStateException_base {
}
declare const NameAvailabilityException_base: S.TaggedErrorClass<"NameAvailabilityException", {
    readonly message: any;
}>;
export declare class NameAvailabilityException extends /*@__PURE__*/ NameAvailabilityException_base {
}
declare const OrganizationNotFoundException_base: S.TaggedErrorClass<"OrganizationNotFoundException", {
    readonly message: any;
}>;
export declare class OrganizationNotFoundException extends /*@__PURE__*/ OrganizationNotFoundException_base {
}
declare const OrganizationStateException_base: S.TaggedErrorClass<"OrganizationStateException", {
    readonly message: any;
}>;
export declare class OrganizationStateException extends /*@__PURE__*/ OrganizationStateException_base {
}
declare const ReservedNameException_base: S.TaggedErrorClass<"ReservedNameException", {
    readonly message: any;
}>;
export declare class ReservedNameException extends /*@__PURE__*/ ReservedNameException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const UnsupportedOperationException_base: S.TaggedErrorClass<"UnsupportedOperationException", {
    readonly message: any;
}>;
export declare class UnsupportedOperationException extends /*@__PURE__*/ UnsupportedOperationException_base {
}
export type OrganizationId = string;
export type EntityIdentifier = string;
export interface AssociateDelegateToResourceRequest {
    OrganizationId: string;
    ResourceId: string;
    EntityId: string;
}
export interface AssociateDelegateToResourceResponse {
}
export interface AssociateMemberToGroupRequest {
    OrganizationId: string;
    GroupId: string;
    MemberId: string;
}
export interface AssociateMemberToGroupResponse {
}
export type ImpersonationRoleId = string;
export interface AssumeImpersonationRoleRequest {
    OrganizationId: string;
    ImpersonationRoleId: string;
}
export type ImpersonationToken = string;
export type ExpiresIn = number;
export interface AssumeImpersonationRoleResponse {
    Token?: string | undefined;
    ExpiresIn?: number | undefined;
}
export type IdempotencyClientToken = string;
export type MailboxExportJobId = string;
export interface CancelMailboxExportJobRequest {
    ClientToken: string;
    JobId: string;
    OrganizationId: string;
}
export interface CancelMailboxExportJobResponse {
}
export type WorkMailIdentifier = string;
export type EmailAddress = string;
export interface CreateAliasRequest {
    OrganizationId: string;
    EntityId: string;
    Alias: string;
}
export interface CreateAliasResponse {
}
export type DomainName = string;
export type Url = string;
export type ExternalUserName = string;
export type Password = string | redacted.Redacted<string>;
export interface EwsAvailabilityProvider {
    EwsEndpoint: string;
    EwsUsername: string;
    EwsPassword: string | redacted.Redacted<string>;
}
export type LambdaArn = string;
export interface LambdaAvailabilityProvider {
    LambdaArn: string;
}
export interface CreateAvailabilityConfigurationRequest {
    ClientToken?: string | undefined;
    OrganizationId: string;
    DomainName: string;
    EwsProvider?: EwsAvailabilityProvider | undefined;
    LambdaProvider?: LambdaAvailabilityProvider | undefined;
}
export interface CreateAvailabilityConfigurationResponse {
}
export type GroupName = string;
export interface CreateGroupRequest {
    OrganizationId: string;
    Name: string;
    HiddenFromGlobalAddressList?: boolean | undefined;
}
export interface CreateGroupResponse {
    GroupId?: string | undefined;
}
export type IdentityCenterApplicationName = string;
export type InstanceArn = string;
export interface CreateIdentityCenterApplicationRequest {
    Name: string;
    InstanceArn: string;
    ClientToken?: string | undefined;
}
export type ApplicationArn = string;
export interface CreateIdentityCenterApplicationResponse {
    ApplicationArn?: string | undefined;
}
export type ImpersonationRoleName = string;
export type ImpersonationRoleType = "FULL_ACCESS" | "READ_ONLY" | (string & {});
export type ImpersonationRoleDescription = string;
export type ImpersonationRuleId = string;
export type ImpersonationRuleName = string;
export type ImpersonationRuleDescription = string;
export type AccessEffect = "ALLOW" | "DENY" | (string & {});
export type TargetUsers = string[];
export interface ImpersonationRule {
    ImpersonationRuleId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Effect: AccessEffect;
    TargetUsers?: string[] | undefined;
    NotTargetUsers?: string[] | undefined;
}
export type ImpersonationRuleList = ImpersonationRule[];
export interface CreateImpersonationRoleRequest {
    ClientToken?: string | undefined;
    OrganizationId: string;
    Name: string;
    Type: ImpersonationRoleType;
    Description?: string | undefined;
    Rules: ImpersonationRule[];
}
export interface CreateImpersonationRoleResponse {
    ImpersonationRoleId?: string | undefined;
}
export type MobileDeviceAccessRuleName = string;
export type MobileDeviceAccessRuleDescription = string;
export type MobileDeviceAccessRuleEffect = "ALLOW" | "DENY" | (string & {});
export type DeviceType = string;
export type DeviceTypeList = string[];
export type DeviceModel = string;
export type DeviceModelList = string[];
export type DeviceOperatingSystem = string;
export type DeviceOperatingSystemList = string[];
export type DeviceUserAgent = string;
export type DeviceUserAgentList = string[];
export interface CreateMobileDeviceAccessRuleRequest {
    OrganizationId: string;
    ClientToken?: string | undefined;
    Name: string;
    Description?: string | undefined;
    Effect: MobileDeviceAccessRuleEffect;
    DeviceTypes?: string[] | undefined;
    NotDeviceTypes?: string[] | undefined;
    DeviceModels?: string[] | undefined;
    NotDeviceModels?: string[] | undefined;
    DeviceOperatingSystems?: string[] | undefined;
    NotDeviceOperatingSystems?: string[] | undefined;
    DeviceUserAgents?: string[] | undefined;
    NotDeviceUserAgents?: string[] | undefined;
}
export type MobileDeviceAccessRuleId = string;
export interface CreateMobileDeviceAccessRuleResponse {
    MobileDeviceAccessRuleId?: string | undefined;
}
export type DirectoryId = string;
export type OrganizationName = string;
export type HostedZoneId = string;
export interface Domain {
    DomainName: string;
    HostedZoneId?: string | undefined;
}
export type Domains = Domain[];
export type KmsKeyArn = string;
export interface CreateOrganizationRequest {
    DirectoryId?: string | undefined;
    Alias: string;
    ClientToken?: string | undefined;
    Domains?: Domain[] | undefined;
    KmsKeyArn?: string | undefined;
    EnableInteroperability?: boolean | undefined;
}
export interface CreateOrganizationResponse {
    OrganizationId?: string | undefined;
}
export type ResourceName = string;
export type ResourceType = "ROOM" | "EQUIPMENT" | (string & {});
export type ResourceDescription = string | redacted.Redacted<string>;
export interface CreateResourceRequest {
    OrganizationId: string;
    Name: string;
    Type: ResourceType;
    Description?: string | redacted.Redacted<string> | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
}
export type ResourceId = string;
export interface CreateResourceResponse {
    ResourceId?: string | undefined;
}
export type UserName = string;
export type UserAttribute = string | redacted.Redacted<string>;
export type UserRole = "USER" | "RESOURCE" | "SYSTEM_USER" | "REMOTE_USER" | (string & {});
export type IdentityProviderUserId = string;
export interface CreateUserRequest {
    OrganizationId: string;
    Name: string;
    DisplayName: string | redacted.Redacted<string>;
    Password?: string | redacted.Redacted<string> | undefined;
    Role?: UserRole | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
    IdentityProviderUserId?: string | undefined;
}
export interface CreateUserResponse {
    UserId?: string | undefined;
}
export type AccessControlRuleName = string;
export interface DeleteAccessControlRuleRequest {
    OrganizationId: string;
    Name: string;
}
export interface DeleteAccessControlRuleResponse {
}
export interface DeleteAliasRequest {
    OrganizationId: string;
    EntityId: string;
    Alias: string;
}
export interface DeleteAliasResponse {
}
export interface DeleteAvailabilityConfigurationRequest {
    OrganizationId: string;
    DomainName: string;
}
export interface DeleteAvailabilityConfigurationResponse {
}
export interface DeleteEmailMonitoringConfigurationRequest {
    OrganizationId: string;
}
export interface DeleteEmailMonitoringConfigurationResponse {
}
export interface DeleteGroupRequest {
    OrganizationId: string;
    GroupId: string;
}
export interface DeleteGroupResponse {
}
export interface DeleteIdentityCenterApplicationRequest {
    ApplicationArn: string;
}
export interface DeleteIdentityCenterApplicationResponse {
}
export interface DeleteIdentityProviderConfigurationRequest {
    OrganizationId: string;
}
export interface DeleteIdentityProviderConfigurationResponse {
}
export interface DeleteImpersonationRoleRequest {
    OrganizationId: string;
    ImpersonationRoleId: string;
}
export interface DeleteImpersonationRoleResponse {
}
export interface DeleteMailboxPermissionsRequest {
    OrganizationId: string;
    EntityId: string;
    GranteeId: string;
}
export interface DeleteMailboxPermissionsResponse {
}
export type DeviceId = string;
export interface DeleteMobileDeviceAccessOverrideRequest {
    OrganizationId: string;
    UserId: string;
    DeviceId: string;
}
export interface DeleteMobileDeviceAccessOverrideResponse {
}
export interface DeleteMobileDeviceAccessRuleRequest {
    OrganizationId: string;
    MobileDeviceAccessRuleId: string;
}
export interface DeleteMobileDeviceAccessRuleResponse {
}
export interface DeleteOrganizationRequest {
    ClientToken?: string | undefined;
    OrganizationId: string;
    DeleteDirectory: boolean;
    ForceDelete?: boolean | undefined;
    DeleteIdentityCenterApplication?: boolean | undefined;
}
export interface DeleteOrganizationResponse {
    OrganizationId?: string | undefined;
    State?: string | undefined;
}
export type PersonalAccessTokenId = string;
export interface DeletePersonalAccessTokenRequest {
    OrganizationId: string;
    PersonalAccessTokenId: string;
}
export interface DeletePersonalAccessTokenResponse {
}
export interface DeleteResourceRequest {
    OrganizationId: string;
    ResourceId: string;
}
export interface DeleteResourceResponse {
}
export type ShortString = string;
export interface DeleteRetentionPolicyRequest {
    OrganizationId: string;
    Id: string;
}
export interface DeleteRetentionPolicyResponse {
}
export interface DeleteUserRequest {
    OrganizationId: string;
    UserId: string;
}
export interface DeleteUserResponse {
}
export interface DeregisterFromWorkMailRequest {
    OrganizationId: string;
    EntityId: string;
}
export interface DeregisterFromWorkMailResponse {
}
export type WorkMailDomainName = string;
export interface DeregisterMailDomainRequest {
    OrganizationId: string;
    DomainName: string;
}
export interface DeregisterMailDomainResponse {
}
export interface DescribeEmailMonitoringConfigurationRequest {
    OrganizationId: string;
}
export type RoleArn = string;
export type LogGroupArn = string;
export interface DescribeEmailMonitoringConfigurationResponse {
    RoleArn?: string | undefined;
    LogGroupArn?: string | undefined;
}
export interface DescribeEntityRequest {
    OrganizationId: string;
    Email: string;
}
export type EntityType = "GROUP" | "USER" | "RESOURCE" | (string & {});
export interface DescribeEntityResponse {
    EntityId?: string | undefined;
    Name?: string | undefined;
    Type?: EntityType | undefined;
}
export interface DescribeGroupRequest {
    OrganizationId: string;
    GroupId: string;
}
export type EntityState = "ENABLED" | "DISABLED" | "DELETED" | (string & {});
export interface DescribeGroupResponse {
    GroupId?: string | undefined;
    Name?: string | undefined;
    Email?: string | undefined;
    State?: EntityState | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
}
export interface DescribeIdentityProviderConfigurationRequest {
    OrganizationId: string;
}
export type IdentityProviderAuthenticationMode = "IDENTITY_PROVIDER_ONLY" | "IDENTITY_PROVIDER_AND_DIRECTORY" | (string & {});
export interface IdentityCenterConfiguration {
    InstanceArn: string;
    ApplicationArn: string;
}
export type PersonalAccessTokenConfigurationStatus = "ACTIVE" | "INACTIVE" | (string & {});
export type PersonalAccessTokenLifetimeInDays = number;
export interface PersonalAccessTokenConfiguration {
    Status: PersonalAccessTokenConfigurationStatus;
    LifetimeInDays?: number | undefined;
}
export interface DescribeIdentityProviderConfigurationResponse {
    AuthenticationMode?: IdentityProviderAuthenticationMode | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
    PersonalAccessTokenConfiguration?: PersonalAccessTokenConfiguration | undefined;
}
export interface DescribeInboundDmarcSettingsRequest {
    OrganizationId: string;
}
export interface DescribeInboundDmarcSettingsResponse {
    Enforced?: boolean | undefined;
}
export interface DescribeMailboxExportJobRequest {
    JobId: string;
    OrganizationId: string;
}
export type Description = string;
export type S3BucketName = string;
export type S3ObjectKey = string;
export type Percentage = number;
export type MailboxExportJobState = "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | (string & {});
export type MailboxExportErrorInfo = string;
export interface DescribeMailboxExportJobResponse {
    EntityId?: string | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    KmsKeyArn?: string | undefined;
    S3BucketName?: string | undefined;
    S3Prefix?: string | undefined;
    S3Path?: string | undefined;
    EstimatedProgress?: number | undefined;
    State?: MailboxExportJobState | undefined;
    ErrorInfo?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface DescribeOrganizationRequest {
    OrganizationId: string;
}
export type AmazonResourceName = string;
export interface DescribeOrganizationResponse {
    OrganizationId?: string | undefined;
    Alias?: string | undefined;
    State?: string | undefined;
    DirectoryId?: string | undefined;
    DirectoryType?: string | undefined;
    DefaultMailDomain?: string | undefined;
    CompletedDate?: Date | undefined;
    ErrorMessage?: string | undefined;
    ARN?: string | undefined;
    MigrationAdmin?: string | undefined;
    InteroperabilityEnabled?: boolean | undefined;
}
export interface DescribeResourceRequest {
    OrganizationId: string;
    ResourceId: string;
}
export interface BookingOptions {
    AutoAcceptRequests?: boolean | undefined;
    AutoDeclineRecurringRequests?: boolean | undefined;
    AutoDeclineConflictingRequests?: boolean | undefined;
}
export interface DescribeResourceResponse {
    ResourceId?: string | undefined;
    Email?: string | undefined;
    Name?: string | undefined;
    Type?: ResourceType | undefined;
    BookingOptions?: BookingOptions | undefined;
    State?: EntityState | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
}
export interface DescribeUserRequest {
    OrganizationId: string;
    UserId: string;
}
export type IdentityProviderIdentityStoreId = string;
export interface DescribeUserResponse {
    UserId?: string | undefined;
    Name?: string | undefined;
    Email?: string | undefined;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    State?: EntityState | undefined;
    UserRole?: UserRole | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
    MailboxProvisionedDate?: Date | undefined;
    MailboxDeprovisionedDate?: Date | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
    Initials?: string | redacted.Redacted<string> | undefined;
    Telephone?: string | redacted.Redacted<string> | undefined;
    Street?: string | redacted.Redacted<string> | undefined;
    JobTitle?: string | redacted.Redacted<string> | undefined;
    City?: string | redacted.Redacted<string> | undefined;
    Company?: string | redacted.Redacted<string> | undefined;
    ZipCode?: string | redacted.Redacted<string> | undefined;
    Department?: string | redacted.Redacted<string> | undefined;
    Country?: string | redacted.Redacted<string> | undefined;
    Office?: string | redacted.Redacted<string> | undefined;
    IdentityProviderUserId?: string | undefined;
    IdentityProviderIdentityStoreId?: string | undefined;
}
export interface DisassociateDelegateFromResourceRequest {
    OrganizationId: string;
    ResourceId: string;
    EntityId: string;
}
export interface DisassociateDelegateFromResourceResponse {
}
export interface DisassociateMemberFromGroupRequest {
    OrganizationId: string;
    GroupId: string;
    MemberId: string;
}
export interface DisassociateMemberFromGroupResponse {
}
export type IpAddress = string;
export type AccessControlRuleAction = string;
export interface GetAccessControlEffectRequest {
    OrganizationId: string;
    IpAddress: string;
    Action: string;
    UserId?: string | undefined;
    ImpersonationRoleId?: string | undefined;
}
export type AccessControlRuleEffect = "ALLOW" | "DENY" | (string & {});
export type AccessControlRuleNameList = string[];
export interface GetAccessControlEffectResponse {
    Effect?: AccessControlRuleEffect | undefined;
    MatchedRules?: string[] | undefined;
}
export interface GetDefaultRetentionPolicyRequest {
    OrganizationId: string;
}
export type FolderName = "INBOX" | "DELETED_ITEMS" | "SENT_ITEMS" | "DRAFTS" | "JUNK_EMAIL" | (string & {});
export type RetentionAction = "NONE" | "DELETE" | "PERMANENTLY_DELETE" | (string & {});
export type RetentionPeriod = number;
export interface FolderConfiguration {
    Name: FolderName;
    Action: RetentionAction;
    Period?: number | undefined;
}
export type FolderConfigurations = FolderConfiguration[];
export interface GetDefaultRetentionPolicyResponse {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    FolderConfigurations?: FolderConfiguration[] | undefined;
}
export interface GetImpersonationRoleRequest {
    OrganizationId: string;
    ImpersonationRoleId: string;
}
export interface GetImpersonationRoleResponse {
    ImpersonationRoleId?: string | undefined;
    Name?: string | undefined;
    Type?: ImpersonationRoleType | undefined;
    Description?: string | undefined;
    Rules?: ImpersonationRule[] | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
}
export interface GetImpersonationRoleEffectRequest {
    OrganizationId: string;
    ImpersonationRoleId: string;
    TargetUser: string;
}
export interface ImpersonationMatchedRule {
    ImpersonationRuleId?: string | undefined;
    Name?: string | undefined;
}
export type ImpersonationMatchedRuleList = ImpersonationMatchedRule[];
export interface GetImpersonationRoleEffectResponse {
    Type?: ImpersonationRoleType | undefined;
    Effect?: AccessEffect | undefined;
    MatchedRules?: ImpersonationMatchedRule[] | undefined;
}
export interface GetMailboxDetailsRequest {
    OrganizationId: string;
    UserId: string;
}
export type MailboxQuota = number;
export type MailboxSize = number;
export interface GetMailboxDetailsResponse {
    MailboxQuota?: number | undefined;
    MailboxSize?: number | undefined;
}
export interface GetMailDomainRequest {
    OrganizationId: string;
    DomainName: string;
}
export interface DnsRecord {
    Type?: string | undefined;
    Hostname?: string | undefined;
    Value?: string | undefined;
}
export type DnsRecords = DnsRecord[];
export type DnsRecordVerificationStatus = "PENDING" | "VERIFIED" | "FAILED" | (string & {});
export interface GetMailDomainResponse {
    Records?: DnsRecord[] | undefined;
    IsTestDomain?: boolean | undefined;
    IsDefault?: boolean | undefined;
    OwnershipVerificationStatus?: DnsRecordVerificationStatus | undefined;
    DkimVerificationStatus?: DnsRecordVerificationStatus | undefined;
}
export interface GetMobileDeviceAccessEffectRequest {
    OrganizationId: string;
    DeviceType?: string | undefined;
    DeviceModel?: string | undefined;
    DeviceOperatingSystem?: string | undefined;
    DeviceUserAgent?: string | undefined;
}
export interface MobileDeviceAccessMatchedRule {
    MobileDeviceAccessRuleId?: string | undefined;
    Name?: string | undefined;
}
export type MobileDeviceAccessMatchedRuleList = MobileDeviceAccessMatchedRule[];
export interface GetMobileDeviceAccessEffectResponse {
    Effect?: MobileDeviceAccessRuleEffect | undefined;
    MatchedRules?: MobileDeviceAccessMatchedRule[] | undefined;
}
export interface GetMobileDeviceAccessOverrideRequest {
    OrganizationId: string;
    UserId: string;
    DeviceId: string;
}
export interface GetMobileDeviceAccessOverrideResponse {
    UserId?: string | undefined;
    DeviceId?: string | undefined;
    Effect?: MobileDeviceAccessRuleEffect | undefined;
    Description?: string | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
}
export interface GetPersonalAccessTokenMetadataRequest {
    OrganizationId: string;
    PersonalAccessTokenId: string;
}
export type PersonalAccessTokenName = string;
export type PersonalAccessTokenScope = string;
export type PersonalAccessTokenScopeList = string[];
export interface GetPersonalAccessTokenMetadataResponse {
    PersonalAccessTokenId?: string | undefined;
    UserId?: string | undefined;
    Name?: string | undefined;
    DateCreated?: Date | undefined;
    DateLastUsed?: Date | undefined;
    ExpiresTime?: Date | undefined;
    Scopes?: string[] | undefined;
}
export interface ListAccessControlRulesRequest {
    OrganizationId: string;
}
export type AccessControlRuleDescription = string;
export type IpRange = string;
export type IpRangeList = string[];
export type ActionsList = string[];
export type UserIdList = string[];
export type ImpersonationRoleIdList = string[];
export interface AccessControlRule {
    Name?: string | undefined;
    Effect?: AccessControlRuleEffect | undefined;
    Description?: string | undefined;
    IpRanges?: string[] | undefined;
    NotIpRanges?: string[] | undefined;
    Actions?: string[] | undefined;
    NotActions?: string[] | undefined;
    UserIds?: string[] | undefined;
    NotUserIds?: string[] | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
    ImpersonationRoleIds?: string[] | undefined;
    NotImpersonationRoleIds?: string[] | undefined;
}
export type AccessControlRulesList = AccessControlRule[];
export interface ListAccessControlRulesResponse {
    Rules?: AccessControlRule[] | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListAliasesRequest {
    OrganizationId: string;
    EntityId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Aliases = string[];
export interface ListAliasesResponse {
    Aliases?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAvailabilityConfigurationsRequest {
    OrganizationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AvailabilityProviderType = "EWS" | "LAMBDA" | (string & {});
export interface RedactedEwsAvailabilityProvider {
    EwsEndpoint?: string | undefined;
    EwsUsername?: string | undefined;
}
export interface AvailabilityConfiguration {
    DomainName?: string | undefined;
    ProviderType?: AvailabilityProviderType | undefined;
    EwsProvider?: RedactedEwsAvailabilityProvider | undefined;
    LambdaProvider?: LambdaAvailabilityProvider | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
}
export type AvailabilityConfigurationList = AvailabilityConfiguration[];
export interface ListAvailabilityConfigurationsResponse {
    AvailabilityConfigurations?: AvailabilityConfiguration[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupMembersRequest {
    OrganizationId: string;
    GroupId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type MemberType = "GROUP" | "USER" | (string & {});
export interface Member {
    Id?: string | undefined;
    Name?: string | undefined;
    Type?: MemberType | undefined;
    State?: EntityState | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
}
export type Members = Member[];
export interface ListGroupMembersResponse {
    Members?: Member[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupsFilters {
    NamePrefix?: string | undefined;
    PrimaryEmailPrefix?: string | undefined;
    State?: EntityState | undefined;
}
export interface ListGroupsRequest {
    OrganizationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: ListGroupsFilters | undefined;
}
export interface Group {
    Id?: string | undefined;
    Email?: string | undefined;
    Name?: string | undefined;
    State?: EntityState | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
}
export type Groups = Group[];
export interface ListGroupsResponse {
    Groups?: Group[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupsForEntityFilters {
    GroupNamePrefix?: string | undefined;
}
export interface ListGroupsForEntityRequest {
    OrganizationId: string;
    EntityId: string;
    Filters?: ListGroupsForEntityFilters | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface GroupIdentifier {
    GroupId?: string | undefined;
    GroupName?: string | undefined;
}
export type GroupIdentifiers = GroupIdentifier[];
export interface ListGroupsForEntityResponse {
    Groups?: GroupIdentifier[] | undefined;
    NextToken?: string | undefined;
}
export interface ListImpersonationRolesRequest {
    OrganizationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ImpersonationRole {
    ImpersonationRoleId?: string | undefined;
    Name?: string | undefined;
    Type?: ImpersonationRoleType | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
}
export type ImpersonationRoleList = ImpersonationRole[];
export interface ListImpersonationRolesResponse {
    Roles?: ImpersonationRole[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMailboxExportJobsRequest {
    OrganizationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MailboxExportJob {
    JobId?: string | undefined;
    EntityId?: string | undefined;
    Description?: string | undefined;
    S3BucketName?: string | undefined;
    S3Path?: string | undefined;
    EstimatedProgress?: number | undefined;
    State?: MailboxExportJobState | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export type Jobs = MailboxExportJob[];
export interface ListMailboxExportJobsResponse {
    Jobs?: MailboxExportJob[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMailboxPermissionsRequest {
    OrganizationId: string;
    EntityId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type PermissionType = "FULL_ACCESS" | "SEND_AS" | "SEND_ON_BEHALF" | (string & {});
export type PermissionValues = PermissionType[];
export interface Permission {
    GranteeId: string;
    GranteeType: MemberType;
    PermissionValues: PermissionType[];
}
export type Permissions = Permission[];
export interface ListMailboxPermissionsResponse {
    Permissions?: Permission[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMailDomainsRequest {
    OrganizationId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface MailDomainSummary {
    DomainName?: string | undefined;
    DefaultDomain?: boolean | undefined;
}
export type MailDomains = MailDomainSummary[];
export interface ListMailDomainsResponse {
    MailDomains?: MailDomainSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMobileDeviceAccessOverridesRequest {
    OrganizationId: string;
    UserId?: string | undefined;
    DeviceId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MobileDeviceAccessOverride {
    UserId?: string | undefined;
    DeviceId?: string | undefined;
    Effect?: MobileDeviceAccessRuleEffect | undefined;
    Description?: string | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
}
export type MobileDeviceAccessOverridesList = MobileDeviceAccessOverride[];
export interface ListMobileDeviceAccessOverridesResponse {
    Overrides?: MobileDeviceAccessOverride[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMobileDeviceAccessRulesRequest {
    OrganizationId: string;
}
export interface MobileDeviceAccessRule {
    MobileDeviceAccessRuleId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Effect?: MobileDeviceAccessRuleEffect | undefined;
    DeviceTypes?: string[] | undefined;
    NotDeviceTypes?: string[] | undefined;
    DeviceModels?: string[] | undefined;
    NotDeviceModels?: string[] | undefined;
    DeviceOperatingSystems?: string[] | undefined;
    NotDeviceOperatingSystems?: string[] | undefined;
    DeviceUserAgents?: string[] | undefined;
    NotDeviceUserAgents?: string[] | undefined;
    DateCreated?: Date | undefined;
    DateModified?: Date | undefined;
}
export type MobileDeviceAccessRulesList = MobileDeviceAccessRule[];
export interface ListMobileDeviceAccessRulesResponse {
    Rules?: MobileDeviceAccessRule[] | undefined;
}
export interface ListOrganizationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface OrganizationSummary {
    OrganizationId?: string | undefined;
    Alias?: string | undefined;
    DefaultMailDomain?: string | undefined;
    ErrorMessage?: string | undefined;
    State?: string | undefined;
}
export type OrganizationSummaries = OrganizationSummary[];
export interface ListOrganizationsResponse {
    OrganizationSummaries?: OrganizationSummary[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPersonalAccessTokensRequest {
    OrganizationId: string;
    UserId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface PersonalAccessTokenSummary {
    PersonalAccessTokenId?: string | undefined;
    UserId?: string | undefined;
    Name?: string | undefined;
    DateCreated?: Date | undefined;
    DateLastUsed?: Date | undefined;
    ExpiresTime?: Date | undefined;
    Scopes?: string[] | undefined;
}
export type PersonalAccessTokenSummaryList = PersonalAccessTokenSummary[];
export interface ListPersonalAccessTokensResponse {
    NextToken?: string | undefined;
    PersonalAccessTokenSummaries?: PersonalAccessTokenSummary[] | undefined;
}
export interface ListResourceDelegatesRequest {
    OrganizationId: string;
    ResourceId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface Delegate {
    Id: string;
    Type: MemberType;
}
export type ResourceDelegates = Delegate[];
export interface ListResourceDelegatesResponse {
    Delegates?: Delegate[] | undefined;
    NextToken?: string | undefined;
}
export interface ListResourcesFilters {
    NamePrefix?: string | undefined;
    PrimaryEmailPrefix?: string | undefined;
    State?: EntityState | undefined;
}
export interface ListResourcesRequest {
    OrganizationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: ListResourcesFilters | undefined;
}
export interface Resource {
    Id?: string | undefined;
    Email?: string | undefined;
    Name?: string | undefined;
    Type?: ResourceType | undefined;
    State?: EntityState | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export type Resources = Resource[];
export interface ListResourcesResponse {
    Resources?: Resource[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export type IdentityProviderUserIdPrefix = string;
export interface ListUsersFilters {
    UsernamePrefix?: string | undefined;
    DisplayNamePrefix?: string | redacted.Redacted<string> | undefined;
    PrimaryEmailPrefix?: string | undefined;
    State?: EntityState | undefined;
    IdentityProviderUserIdPrefix?: string | undefined;
}
export interface ListUsersRequest {
    OrganizationId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: ListUsersFilters | undefined;
}
export interface User {
    Id?: string | undefined;
    Email?: string | undefined;
    Name?: string | undefined;
    DisplayName?: string | undefined;
    State?: EntityState | undefined;
    UserRole?: UserRole | undefined;
    EnabledDate?: Date | undefined;
    DisabledDate?: Date | undefined;
    IdentityProviderUserId?: string | undefined;
    IdentityProviderIdentityStoreId?: string | undefined;
}
export type Users = User[];
export interface ListUsersResponse {
    Users?: User[] | undefined;
    NextToken?: string | undefined;
}
export interface PutAccessControlRuleRequest {
    Name: string;
    Effect: AccessControlRuleEffect;
    Description: string;
    IpRanges?: string[] | undefined;
    NotIpRanges?: string[] | undefined;
    Actions?: string[] | undefined;
    NotActions?: string[] | undefined;
    UserIds?: string[] | undefined;
    NotUserIds?: string[] | undefined;
    OrganizationId: string;
    ImpersonationRoleIds?: string[] | undefined;
    NotImpersonationRoleIds?: string[] | undefined;
}
export interface PutAccessControlRuleResponse {
}
export interface PutEmailMonitoringConfigurationRequest {
    OrganizationId: string;
    RoleArn?: string | undefined;
    LogGroupArn: string;
}
export interface PutEmailMonitoringConfigurationResponse {
}
export interface PutIdentityProviderConfigurationRequest {
    OrganizationId: string;
    AuthenticationMode: IdentityProviderAuthenticationMode;
    IdentityCenterConfiguration: IdentityCenterConfiguration;
    PersonalAccessTokenConfiguration: PersonalAccessTokenConfiguration;
}
export interface PutIdentityProviderConfigurationResponse {
}
export interface PutInboundDmarcSettingsRequest {
    OrganizationId: string;
    Enforced: boolean;
}
export interface PutInboundDmarcSettingsResponse {
}
export interface PutMailboxPermissionsRequest {
    OrganizationId: string;
    EntityId: string;
    GranteeId: string;
    PermissionValues: PermissionType[];
}
export interface PutMailboxPermissionsResponse {
}
export interface PutMobileDeviceAccessOverrideRequest {
    OrganizationId: string;
    UserId: string;
    DeviceId: string;
    Effect: MobileDeviceAccessRuleEffect;
    Description?: string | undefined;
}
export interface PutMobileDeviceAccessOverrideResponse {
}
export type PolicyDescription = string | redacted.Redacted<string>;
export interface PutRetentionPolicyRequest {
    OrganizationId: string;
    Id?: string | undefined;
    Name: string;
    Description?: string | redacted.Redacted<string> | undefined;
    FolderConfigurations: FolderConfiguration[];
}
export interface PutRetentionPolicyResponse {
}
export interface RegisterMailDomainRequest {
    ClientToken?: string | undefined;
    OrganizationId: string;
    DomainName: string;
}
export interface RegisterMailDomainResponse {
}
export interface RegisterToWorkMailRequest {
    OrganizationId: string;
    EntityId: string;
    Email: string;
}
export interface RegisterToWorkMailResponse {
}
export interface ResetPasswordRequest {
    OrganizationId: string;
    UserId: string;
    Password: string | redacted.Redacted<string>;
}
export interface ResetPasswordResponse {
}
export interface StartMailboxExportJobRequest {
    ClientToken: string;
    OrganizationId: string;
    EntityId: string;
    Description?: string | undefined;
    RoleArn: string;
    KmsKeyArn: string;
    S3BucketName: string;
    S3Prefix: string;
}
export interface StartMailboxExportJobResponse {
    JobId?: string | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface TestAvailabilityConfigurationRequest {
    OrganizationId: string;
    DomainName?: string | undefined;
    EwsProvider?: EwsAvailabilityProvider | undefined;
    LambdaProvider?: LambdaAvailabilityProvider | undefined;
}
export interface TestAvailabilityConfigurationResponse {
    TestPassed?: boolean | undefined;
    FailureReason?: string | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAvailabilityConfigurationRequest {
    OrganizationId: string;
    DomainName: string;
    EwsProvider?: EwsAvailabilityProvider | undefined;
    LambdaProvider?: LambdaAvailabilityProvider | undefined;
}
export interface UpdateAvailabilityConfigurationResponse {
}
export interface UpdateDefaultMailDomainRequest {
    OrganizationId: string;
    DomainName: string;
}
export interface UpdateDefaultMailDomainResponse {
}
export interface UpdateGroupRequest {
    OrganizationId: string;
    GroupId: string;
    HiddenFromGlobalAddressList?: boolean | undefined;
}
export interface UpdateGroupResponse {
}
export interface UpdateImpersonationRoleRequest {
    OrganizationId: string;
    ImpersonationRoleId: string;
    Name: string;
    Type: ImpersonationRoleType;
    Description?: string | undefined;
    Rules: ImpersonationRule[];
}
export interface UpdateImpersonationRoleResponse {
}
export interface UpdateMailboxQuotaRequest {
    OrganizationId: string;
    UserId: string;
    MailboxQuota: number;
}
export interface UpdateMailboxQuotaResponse {
}
export interface UpdateMobileDeviceAccessRuleRequest {
    OrganizationId: string;
    MobileDeviceAccessRuleId: string;
    Name: string;
    Description?: string | undefined;
    Effect: MobileDeviceAccessRuleEffect;
    DeviceTypes?: string[] | undefined;
    NotDeviceTypes?: string[] | undefined;
    DeviceModels?: string[] | undefined;
    NotDeviceModels?: string[] | undefined;
    DeviceOperatingSystems?: string[] | undefined;
    NotDeviceOperatingSystems?: string[] | undefined;
    DeviceUserAgents?: string[] | undefined;
    NotDeviceUserAgents?: string[] | undefined;
}
export interface UpdateMobileDeviceAccessRuleResponse {
}
export interface UpdatePrimaryEmailAddressRequest {
    OrganizationId: string;
    EntityId: string;
    Email: string;
}
export interface UpdatePrimaryEmailAddressResponse {
}
export type NewResourceDescription = string | redacted.Redacted<string>;
export interface UpdateResourceRequest {
    OrganizationId: string;
    ResourceId: string;
    Name?: string | undefined;
    BookingOptions?: BookingOptions | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Type?: ResourceType | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
}
export interface UpdateResourceResponse {
}
export type IdentityProviderUserIdForUpdate = string;
export interface UpdateUserRequest {
    OrganizationId: string;
    UserId: string;
    Role?: UserRole | undefined;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    FirstName?: string | redacted.Redacted<string> | undefined;
    LastName?: string | redacted.Redacted<string> | undefined;
    HiddenFromGlobalAddressList?: boolean | undefined;
    Initials?: string | redacted.Redacted<string> | undefined;
    Telephone?: string | redacted.Redacted<string> | undefined;
    Street?: string | redacted.Redacted<string> | undefined;
    JobTitle?: string | redacted.Redacted<string> | undefined;
    City?: string | redacted.Redacted<string> | undefined;
    Company?: string | redacted.Redacted<string> | undefined;
    ZipCode?: string | redacted.Redacted<string> | undefined;
    Department?: string | redacted.Redacted<string> | undefined;
    Country?: string | redacted.Redacted<string> | undefined;
    Office?: string | redacted.Redacted<string> | undefined;
    IdentityProviderUserId?: string | undefined;
}
export interface UpdateUserResponse {
}
export type AssociateDelegateToResourceError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Adds a member (user or group) to the resource's set of delegates.
 */
export declare const associateDelegateToResource: API.OperationMethod<AssociateDelegateToResourceRequest & RegionInput, AssociateDelegateToResourceResponse, AssociateDelegateToResourceError, Credentials | HttpClient.HttpClient>;
export type AssociateMemberToGroupError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Adds a member (user or group) to the group's set.
 */
export declare const associateMemberToGroup: API.OperationMethod<AssociateMemberToGroupRequest & RegionInput, AssociateMemberToGroupResponse, AssociateMemberToGroupError, Credentials | HttpClient.HttpClient>;
export type AssumeImpersonationRoleError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Assumes an impersonation role for the given WorkMail organization. This method returns an
 * authentication token you can use to make impersonated calls.
 */
export declare const assumeImpersonationRole: API.OperationMethod<AssumeImpersonationRoleRequest & RegionInput, AssumeImpersonationRoleResponse, AssumeImpersonationRoleError, Credentials | HttpClient.HttpClient>;
export type CancelMailboxExportJobError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Cancels a mailbox export job.
 *
 * If the mailbox export job is near completion, it might not be possible to cancel
 * it.
 */
export declare const cancelMailboxExportJob: API.OperationMethod<CancelMailboxExportJobRequest & RegionInput, CancelMailboxExportJobResponse, CancelMailboxExportJobError, Credentials | HttpClient.HttpClient>;
export type CreateAliasError = EmailAddressInUseException | EntityNotFoundException | EntityStateException | InvalidParameterException | LimitExceededException | MailDomainNotFoundException | MailDomainStateException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Adds an alias to the set of a given member (user or group) of WorkMail.
 */
export declare const createAlias: API.OperationMethod<CreateAliasRequest & RegionInput, CreateAliasResponse, CreateAliasError, Credentials | HttpClient.HttpClient>;
export type CreateAvailabilityConfigurationError = InvalidParameterException | LimitExceededException | NameAvailabilityException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Creates an `AvailabilityConfiguration` for the given WorkMail organization and domain.
 */
export declare const createAvailabilityConfiguration: API.OperationMethod<CreateAvailabilityConfigurationRequest & RegionInput, CreateAvailabilityConfigurationResponse, CreateAvailabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | InvalidParameterException | NameAvailabilityException | OrganizationNotFoundException | OrganizationStateException | ReservedNameException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a group that can be used in WorkMail by calling the RegisterToWorkMail operation.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateIdentityCenterApplicationError = InvalidParameterException | CommonErrors;
/**
 * Creates the WorkMail application in IAM Identity Center that can be used later in the WorkMail - IdC integration. For more information, see PutIdentityProviderConfiguration. This action does not affect the authentication settings for any WorkMail organizations.
 */
export declare const createIdentityCenterApplication: API.OperationMethod<CreateIdentityCenterApplicationRequest & RegionInput, CreateIdentityCenterApplicationResponse, CreateIdentityCenterApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateImpersonationRoleError = EntityNotFoundException | EntityStateException | InvalidParameterException | LimitExceededException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Creates an impersonation role for the given WorkMail organization.
 *
 * *Idempotency* ensures that an API request completes no more than one
 * time. With an idempotent request, if the original request completes successfully, any
 * subsequent retries also complete successfully without performing any further
 * actions.
 */
export declare const createImpersonationRole: API.OperationMethod<CreateImpersonationRoleRequest & RegionInput, CreateImpersonationRoleResponse, CreateImpersonationRoleError, Credentials | HttpClient.HttpClient>;
export type CreateMobileDeviceAccessRuleError = InvalidParameterException | LimitExceededException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Creates a new mobile device access rule for the specified WorkMail organization.
 */
export declare const createMobileDeviceAccessRule: API.OperationMethod<CreateMobileDeviceAccessRuleRequest & RegionInput, CreateMobileDeviceAccessRuleResponse, CreateMobileDeviceAccessRuleError, Credentials | HttpClient.HttpClient>;
export type CreateOrganizationError = DirectoryInUseException | DirectoryUnavailableException | InvalidParameterException | LimitExceededException | NameAvailabilityException | CommonErrors;
/**
 * Creates a new WorkMail organization. Optionally, you can choose to associate an existing AWS Directory Service directory with your organization. If an AWS Directory Service directory ID is specified, the organization alias must match the directory alias. If you choose not to associate an existing directory with your organization, then we create a new WorkMail directory for you. For more information, see Adding an organization in the *WorkMail Administrator Guide*.
 *
 * You can associate multiple email domains with an organization, then choose your
 * default email domain from the WorkMail console. You can also associate a domain that is managed
 * in an Amazon Route 53 public hosted zone. For more information, see Adding a
 * domain and Choosing the default domain
 * in the *WorkMail Administrator Guide*.
 *
 * Optionally, you can use a customer managed key from AWS Key Management Service (AWS
 * KMS) to encrypt email for your organization. If you don't associate an AWS KMS key, WorkMail
 * creates a default, AWS managed key for you.
 */
export declare const createOrganization: API.OperationMethod<CreateOrganizationRequest & RegionInput, CreateOrganizationResponse, CreateOrganizationError, Credentials | HttpClient.HttpClient>;
export type CreateResourceError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | InvalidParameterException | NameAvailabilityException | OrganizationNotFoundException | OrganizationStateException | ReservedNameException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a new WorkMail resource.
 */
export declare const createResource: API.OperationMethod<CreateResourceRequest & RegionInput, CreateResourceResponse, CreateResourceError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | InvalidParameterException | InvalidPasswordException | NameAvailabilityException | OrganizationNotFoundException | OrganizationStateException | ReservedNameException | UnsupportedOperationException | CommonErrors;
/**
 * Creates a user who can be used in WorkMail by calling the RegisterToWorkMail operation.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessControlRuleError = OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes an access control rule for the specified WorkMail organization.
 *
 * Deleting already deleted and non-existing rules does not produce an error. In those cases, the service sends back an HTTP 200 response with an empty HTTP body.
 */
export declare const deleteAccessControlRule: API.OperationMethod<DeleteAccessControlRuleRequest & RegionInput, DeleteAccessControlRuleResponse, DeleteAccessControlRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteAliasError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Remove one or more specified aliases from a set of aliases for a given
 * user.
 */
export declare const deleteAlias: API.OperationMethod<DeleteAliasRequest & RegionInput, DeleteAliasResponse, DeleteAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteAvailabilityConfigurationError = OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes the `AvailabilityConfiguration` for the given WorkMail organization and domain.
 */
export declare const deleteAvailabilityConfiguration: API.OperationMethod<DeleteAvailabilityConfigurationRequest & RegionInput, DeleteAvailabilityConfigurationResponse, DeleteAvailabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteEmailMonitoringConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes the email monitoring configuration for a specified organization.
 */
export declare const deleteEmailMonitoringConfiguration: API.OperationMethod<DeleteEmailMonitoringConfigurationRequest & RegionInput, DeleteEmailMonitoringConfigurationResponse, DeleteEmailMonitoringConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a group from WorkMail.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityCenterApplicationError = InvalidParameterException | OrganizationStateException | CommonErrors;
/**
 * Deletes the IAM Identity Center application from WorkMail. This action does not affect the authentication settings for any WorkMail organizations.
 */
export declare const deleteIdentityCenterApplication: API.OperationMethod<DeleteIdentityCenterApplicationRequest & RegionInput, DeleteIdentityCenterApplicationResponse, DeleteIdentityCenterApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityProviderConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Disables the integration between IdC and WorkMail. Authentication will continue with the directory as it was before the IdC integration. You might have to reset your directory passwords and reconfigure your desktop and mobile email clients.
 */
export declare const deleteIdentityProviderConfiguration: API.OperationMethod<DeleteIdentityProviderConfigurationRequest & RegionInput, DeleteIdentityProviderConfigurationResponse, DeleteIdentityProviderConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteImpersonationRoleError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes an impersonation role for the given WorkMail organization.
 */
export declare const deleteImpersonationRole: API.OperationMethod<DeleteImpersonationRoleRequest & RegionInput, DeleteImpersonationRoleResponse, DeleteImpersonationRoleError, Credentials | HttpClient.HttpClient>;
export type DeleteMailboxPermissionsError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes permissions granted to a member (user or group).
 */
export declare const deleteMailboxPermissions: API.OperationMethod<DeleteMailboxPermissionsRequest & RegionInput, DeleteMailboxPermissionsResponse, DeleteMailboxPermissionsError, Credentials | HttpClient.HttpClient>;
export type DeleteMobileDeviceAccessOverrideError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes the mobile device access override for the given WorkMail organization, user, and device.
 *
 * Deleting already deleted and non-existing overrides does not produce an error. In those cases, the service sends back an HTTP 200 response with an empty HTTP body.
 */
export declare const deleteMobileDeviceAccessOverride: API.OperationMethod<DeleteMobileDeviceAccessOverrideRequest & RegionInput, DeleteMobileDeviceAccessOverrideResponse, DeleteMobileDeviceAccessOverrideError, Credentials | HttpClient.HttpClient>;
export type DeleteMobileDeviceAccessRuleError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes a mobile device access rule for the specified WorkMail organization.
 *
 * Deleting already deleted and non-existing rules does not produce an error. In those cases, the service sends back an HTTP 200 response with an empty HTTP body.
 */
export declare const deleteMobileDeviceAccessRule: API.OperationMethod<DeleteMobileDeviceAccessRuleRequest & RegionInput, DeleteMobileDeviceAccessRuleResponse, DeleteMobileDeviceAccessRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteOrganizationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes an WorkMail organization and all underlying AWS resources managed by WorkMail as part of the organization. You can choose whether to delete the associated directory. For more information, see Removing an organization in the *WorkMail Administrator Guide*.
 */
export declare const deleteOrganization: API.OperationMethod<DeleteOrganizationRequest & RegionInput, DeleteOrganizationResponse, DeleteOrganizationError, Credentials | HttpClient.HttpClient>;
export type DeletePersonalAccessTokenError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes the Personal Access Token from the provided WorkMail Organization.
 */
export declare const deletePersonalAccessToken: API.OperationMethod<DeletePersonalAccessTokenRequest & RegionInput, DeletePersonalAccessTokenResponse, DeletePersonalAccessTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceError = EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes the specified resource.
 */
export declare const deleteResource: API.OperationMethod<DeleteResourceRequest & RegionInput, DeleteResourceResponse, DeleteResourceError, Credentials | HttpClient.HttpClient>;
export type DeleteRetentionPolicyError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Deletes the specified retention policy from the specified organization.
 */
export declare const deleteRetentionPolicy: API.OperationMethod<DeleteRetentionPolicyRequest & RegionInput, DeleteRetentionPolicyResponse, DeleteRetentionPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Deletes a user from WorkMail and all subsequent systems. Before you can delete a
 * user, the user state must be `DISABLED`. Use the DescribeUser
 * action to confirm the user state.
 *
 * Deleting a user is permanent and cannot be undone. WorkMail archives user mailboxes for
 * 30 days before they are permanently removed.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeregisterFromWorkMailError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Mark a user, group, or resource as no longer used in WorkMail. This action
 * disassociates the mailbox and schedules it for clean-up. WorkMail keeps mailboxes for 30 days
 * before they are permanently removed. The functionality in the console is
 * *Disable*.
 */
export declare const deregisterFromWorkMail: API.OperationMethod<DeregisterFromWorkMailRequest & RegionInput, DeregisterFromWorkMailResponse, DeregisterFromWorkMailError, Credentials | HttpClient.HttpClient>;
export type DeregisterMailDomainError = InvalidCustomSesConfigurationException | InvalidParameterException | MailDomainInUseException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Removes a domain from WorkMail, stops email routing to WorkMail, and removes the authorization allowing WorkMail use. SES keeps the domain because other applications may use it. You must first
 * remove any email address used by WorkMail entities before you remove the domain.
 */
export declare const deregisterMailDomain: API.OperationMethod<DeregisterMailDomainRequest & RegionInput, DeregisterMailDomainResponse, DeregisterMailDomainError, Credentials | HttpClient.HttpClient>;
export type DescribeEmailMonitoringConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the current email monitoring configuration for a specified organization.
 */
export declare const describeEmailMonitoringConfiguration: API.OperationMethod<DescribeEmailMonitoringConfigurationRequest & RegionInput, DescribeEmailMonitoringConfigurationResponse, DescribeEmailMonitoringConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeEntityError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns basic details about an entity in WorkMail.
 */
export declare const describeEntity: API.OperationMethod<DescribeEntityRequest & RegionInput, DescribeEntityResponse, DescribeEntityError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns the data available for the group.
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest & RegionInput, DescribeGroupResponse, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityProviderConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Returns detailed information on the current IdC setup for the WorkMail organization.
 */
export declare const describeIdentityProviderConfiguration: API.OperationMethod<DescribeIdentityProviderConfigurationRequest & RegionInput, DescribeIdentityProviderConfigurationResponse, DescribeIdentityProviderConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeInboundDmarcSettingsError = OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists the settings in a DMARC policy for a specified organization.
 */
export declare const describeInboundDmarcSettings: API.OperationMethod<DescribeInboundDmarcSettingsRequest & RegionInput, DescribeInboundDmarcSettingsResponse, DescribeInboundDmarcSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeMailboxExportJobError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Describes the current status of a mailbox export job.
 */
export declare const describeMailboxExportJob: API.OperationMethod<DescribeMailboxExportJobRequest & RegionInput, DescribeMailboxExportJobResponse, DescribeMailboxExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationError = InvalidParameterException | OrganizationNotFoundException | CommonErrors;
/**
 * Provides more information regarding a given organization based on its
 * identifier.
 */
export declare const describeOrganization: API.OperationMethod<DescribeOrganizationRequest & RegionInput, DescribeOrganizationResponse, DescribeOrganizationError, Credentials | HttpClient.HttpClient>;
export type DescribeResourceError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Returns the data available for the resource.
 */
export declare const describeResource: API.OperationMethod<DescribeResourceRequest & RegionInput, DescribeResourceResponse, DescribeResourceError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Provides information regarding the user.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest & RegionInput, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type DisassociateDelegateFromResourceError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Removes a member from the resource's set of delegates.
 */
export declare const disassociateDelegateFromResource: API.OperationMethod<DisassociateDelegateFromResourceRequest & RegionInput, DisassociateDelegateFromResourceResponse, DisassociateDelegateFromResourceError, Credentials | HttpClient.HttpClient>;
export type DisassociateMemberFromGroupError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Removes a member from a group.
 */
export declare const disassociateMemberFromGroup: API.OperationMethod<DisassociateMemberFromGroupRequest & RegionInput, DisassociateMemberFromGroupResponse, DisassociateMemberFromGroupError, Credentials | HttpClient.HttpClient>;
export type GetAccessControlEffectError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the effects of an organization's access control rules as they apply to a
 * specified IPv4 address, access protocol action, and user ID or impersonation role ID. You must provide either the user ID or impersonation role ID. Impersonation role ID can only be used with Action EWS.
 */
export declare const getAccessControlEffect: API.OperationMethod<GetAccessControlEffectRequest & RegionInput, GetAccessControlEffectResponse, GetAccessControlEffectError, Credentials | HttpClient.HttpClient>;
export type GetDefaultRetentionPolicyError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Gets the default retention policy details for the specified organization.
 */
export declare const getDefaultRetentionPolicy: API.OperationMethod<GetDefaultRetentionPolicyRequest & RegionInput, GetDefaultRetentionPolicyResponse, GetDefaultRetentionPolicyError, Credentials | HttpClient.HttpClient>;
export type GetImpersonationRoleError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the impersonation role details for the given WorkMail organization.
 */
export declare const getImpersonationRole: API.OperationMethod<GetImpersonationRoleRequest & RegionInput, GetImpersonationRoleResponse, GetImpersonationRoleError, Credentials | HttpClient.HttpClient>;
export type GetImpersonationRoleEffectError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Tests whether the given impersonation role can impersonate a target user.
 */
export declare const getImpersonationRoleEffect: API.OperationMethod<GetImpersonationRoleEffectRequest & RegionInput, GetImpersonationRoleEffectResponse, GetImpersonationRoleEffectError, Credentials | HttpClient.HttpClient>;
export type GetMailboxDetailsError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Requests a user's mailbox details for a specified organization and user.
 */
export declare const getMailboxDetails: API.OperationMethod<GetMailboxDetailsRequest & RegionInput, GetMailboxDetailsResponse, GetMailboxDetailsError, Credentials | HttpClient.HttpClient>;
export type GetMailDomainError = InvalidParameterException | MailDomainNotFoundException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Gets details for a mail domain, including domain records required to configure your domain with recommended security.
 */
export declare const getMailDomain: API.OperationMethod<GetMailDomainRequest & RegionInput, GetMailDomainResponse, GetMailDomainError, Credentials | HttpClient.HttpClient>;
export type GetMobileDeviceAccessEffectError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Simulates the effect of the mobile device access rules for the given attributes of a sample access event. Use this method to test the effects of the current set of mobile device access
 * rules for the WorkMail organization for a particular user's attributes.
 */
export declare const getMobileDeviceAccessEffect: API.OperationMethod<GetMobileDeviceAccessEffectRequest & RegionInput, GetMobileDeviceAccessEffectResponse, GetMobileDeviceAccessEffectError, Credentials | HttpClient.HttpClient>;
export type GetMobileDeviceAccessOverrideError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Gets the mobile device access override for the given WorkMail organization, user, and device.
 */
export declare const getMobileDeviceAccessOverride: API.OperationMethod<GetMobileDeviceAccessOverrideRequest & RegionInput, GetMobileDeviceAccessOverrideResponse, GetMobileDeviceAccessOverrideError, Credentials | HttpClient.HttpClient>;
export type GetPersonalAccessTokenMetadataError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Requests details of a specific Personal Access Token within the WorkMail organization.
 */
export declare const getPersonalAccessTokenMetadata: API.OperationMethod<GetPersonalAccessTokenMetadataRequest & RegionInput, GetPersonalAccessTokenMetadataResponse, GetPersonalAccessTokenMetadataError, Credentials | HttpClient.HttpClient>;
export type ListAccessControlRulesError = OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists the access control rules for the specified organization.
 */
export declare const listAccessControlRules: API.OperationMethod<ListAccessControlRulesRequest & RegionInput, ListAccessControlRulesResponse, ListAccessControlRulesError, Credentials | HttpClient.HttpClient>;
export type ListAliasesError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Creates a paginated call to list the aliases associated with a given
 * entity.
 */
export declare const listAliases: API.PaginatedOperationMethod<ListAliasesRequest & RegionInput, ListAliasesResponse, ListAliasesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListAvailabilityConfigurationsError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * List all the `AvailabilityConfiguration`'s for the given WorkMail organization.
 */
export declare const listAvailabilityConfigurations: API.PaginatedOperationMethod<ListAvailabilityConfigurationsRequest & RegionInput, ListAvailabilityConfigurationsResponse, ListAvailabilityConfigurationsError, Credentials | HttpClient.HttpClient, AvailabilityConfiguration>;
export type ListGroupMembersError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns an overview of the members of a group. Users and groups can be members of a
 * group.
 */
export declare const listGroupMembers: API.PaginatedOperationMethod<ListGroupMembersRequest & RegionInput, ListGroupMembersResponse, ListGroupMembersError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupsError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns summaries of the organization's groups.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListGroupsForEntityError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns all the groups to which an entity belongs.
 */
export declare const listGroupsForEntity: API.PaginatedOperationMethod<ListGroupsForEntityRequest & RegionInput, ListGroupsForEntityResponse, ListGroupsForEntityError, Credentials | HttpClient.HttpClient, unknown>;
export type ListImpersonationRolesError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists all the impersonation roles for the given WorkMail organization.
 */
export declare const listImpersonationRoles: API.PaginatedOperationMethod<ListImpersonationRolesRequest & RegionInput, ListImpersonationRolesResponse, ListImpersonationRolesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMailboxExportJobsError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists the mailbox export jobs started for the specified organization within the last
 * seven days.
 */
export declare const listMailboxExportJobs: API.PaginatedOperationMethod<ListMailboxExportJobsRequest & RegionInput, ListMailboxExportJobsResponse, ListMailboxExportJobsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMailboxPermissionsError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists the mailbox permissions associated with a user, group, or resource
 * mailbox.
 */
export declare const listMailboxPermissions: API.PaginatedOperationMethod<ListMailboxPermissionsRequest & RegionInput, ListMailboxPermissionsResponse, ListMailboxPermissionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMailDomainsError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists the mail domains in a given WorkMail organization.
 */
export declare const listMailDomains: API.PaginatedOperationMethod<ListMailDomainsRequest & RegionInput, ListMailDomainsResponse, ListMailDomainsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMobileDeviceAccessOverridesError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists all the mobile device access overrides for any given combination of WorkMail organization, user, or device.
 */
export declare const listMobileDeviceAccessOverrides: API.PaginatedOperationMethod<ListMobileDeviceAccessOverridesRequest & RegionInput, ListMobileDeviceAccessOverridesResponse, ListMobileDeviceAccessOverridesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListMobileDeviceAccessRulesError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Lists the mobile device access rules for the specified WorkMail organization.
 */
export declare const listMobileDeviceAccessRules: API.OperationMethod<ListMobileDeviceAccessRulesRequest & RegionInput, ListMobileDeviceAccessRulesResponse, ListMobileDeviceAccessRulesError, Credentials | HttpClient.HttpClient>;
export type ListOrganizationsError = InvalidParameterException | CommonErrors;
/**
 * Returns summaries of the customer's organizations.
 */
export declare const listOrganizations: API.PaginatedOperationMethod<ListOrganizationsRequest & RegionInput, ListOrganizationsResponse, ListOrganizationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListPersonalAccessTokensError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns a summary of your Personal Access Tokens.
 */
export declare const listPersonalAccessTokens: API.PaginatedOperationMethod<ListPersonalAccessTokensRequest & RegionInput, ListPersonalAccessTokensResponse, ListPersonalAccessTokensError, Credentials | HttpClient.HttpClient, PersonalAccessTokenSummary>;
export type ListResourceDelegatesError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Lists the delegates associated with a resource. Users and groups can be resource
 * delegates and answer requests on behalf of the resource.
 */
export declare const listResourceDelegates: API.PaginatedOperationMethod<ListResourceDelegatesRequest & RegionInput, ListResourceDelegatesResponse, ListResourceDelegatesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListResourcesError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Returns summaries of the organization's resources.
 */
export declare const listResources: API.PaginatedOperationMethod<ListResourcesRequest & RegionInput, ListResourcesResponse, ListResourcesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Lists the tags applied to an WorkMail organization resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListUsersError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Returns summaries of the organization's users.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, unknown>;
export type PutAccessControlRuleError = EntityNotFoundException | InvalidParameterException | LimitExceededException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Adds a new access control rule for the specified organization. The rule allows or
 * denies access to the organization for the specified IPv4 addresses, access protocol
 * actions, user IDs and impersonation IDs. Adding a new rule with the same name as an existing rule replaces
 * the older rule.
 */
export declare const putAccessControlRule: API.OperationMethod<PutAccessControlRuleRequest & RegionInput, PutAccessControlRuleResponse, PutAccessControlRuleError, Credentials | HttpClient.HttpClient>;
export type PutEmailMonitoringConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Creates or updates the email monitoring configuration for a specified organization.
 */
export declare const putEmailMonitoringConfiguration: API.OperationMethod<PutEmailMonitoringConfigurationRequest & RegionInput, PutEmailMonitoringConfigurationResponse, PutEmailMonitoringConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutIdentityProviderConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Enables integration between IAM Identity Center (IdC) and WorkMail to proxy authentication requests for mailbox users. You can connect your IdC directory or your external directory to WorkMail through
 * IdC and manage access to WorkMail mailboxes in a single place. For enhanced protection, you could enable Multifactor Authentication (MFA) and Personal Access Tokens.
 */
export declare const putIdentityProviderConfiguration: API.OperationMethod<PutIdentityProviderConfigurationRequest & RegionInput, PutIdentityProviderConfigurationResponse, PutIdentityProviderConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutInboundDmarcSettingsError = OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Enables or disables a DMARC policy for a given organization.
 */
export declare const putInboundDmarcSettings: API.OperationMethod<PutInboundDmarcSettingsRequest & RegionInput, PutInboundDmarcSettingsResponse, PutInboundDmarcSettingsError, Credentials | HttpClient.HttpClient>;
export type PutMailboxPermissionsError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Sets permissions for a user, group, or resource. This replaces any pre-existing
 * permissions.
 */
export declare const putMailboxPermissions: API.OperationMethod<PutMailboxPermissionsRequest & RegionInput, PutMailboxPermissionsResponse, PutMailboxPermissionsError, Credentials | HttpClient.HttpClient>;
export type PutMobileDeviceAccessOverrideError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Creates or updates a mobile device access override for the given WorkMail organization, user, and device.
 */
export declare const putMobileDeviceAccessOverride: API.OperationMethod<PutMobileDeviceAccessOverrideRequest & RegionInput, PutMobileDeviceAccessOverrideResponse, PutMobileDeviceAccessOverrideError, Credentials | HttpClient.HttpClient>;
export type PutRetentionPolicyError = InvalidParameterException | LimitExceededException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Puts a retention policy to the specified organization.
 */
export declare const putRetentionPolicy: API.OperationMethod<PutRetentionPolicyRequest & RegionInput, PutRetentionPolicyResponse, PutRetentionPolicyError, Credentials | HttpClient.HttpClient>;
export type RegisterMailDomainError = InvalidParameterException | LimitExceededException | MailDomainInUseException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Registers a new domain in WorkMail and SES, and configures it for use by WorkMail. Emails received by SES for this domain are routed to the specified WorkMail organization, and WorkMail has
 * permanent permission to use the specified domain for sending your users' emails.
 */
export declare const registerMailDomain: API.OperationMethod<RegisterMailDomainRequest & RegionInput, RegisterMailDomainResponse, RegisterMailDomainError, Credentials | HttpClient.HttpClient>;
export type RegisterToWorkMailError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EmailAddressInUseException | EntityAlreadyRegisteredException | EntityNotFoundException | EntityStateException | InvalidParameterException | MailDomainNotFoundException | MailDomainStateException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Registers an existing and disabled user, group, or resource for WorkMail use by
 * associating a mailbox and calendaring capabilities. It performs no change if the user,
 * group, or resource is enabled and fails if the user, group, or resource is deleted. This
 * operation results in the accumulation of costs. For more information, see Pricing. The equivalent console
 * functionality for this operation is *Enable*.
 *
 * Users can either be created by calling the CreateUser API operation
 * or they can be synchronized from your directory. For more information, see DeregisterFromWorkMail.
 */
export declare const registerToWorkMail: API.OperationMethod<RegisterToWorkMailRequest & RegionInput, RegisterToWorkMailResponse, RegisterToWorkMailError, Credentials | HttpClient.HttpClient>;
export type ResetPasswordError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityNotFoundException | EntityStateException | InvalidParameterException | InvalidPasswordException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Allows the administrator to reset the password for a user.
 */
export declare const resetPassword: API.OperationMethod<ResetPasswordRequest & RegionInput, ResetPasswordResponse, ResetPasswordError, Credentials | HttpClient.HttpClient>;
export type StartMailboxExportJobError = EntityNotFoundException | InvalidParameterException | LimitExceededException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Starts a mailbox export job to export MIME-format email messages and calendar items
 * from the specified mailbox to the specified Amazon Simple Storage Service (Amazon S3)
 * bucket. For more information, see Exporting mailbox content in
 * the *WorkMail Administrator Guide*.
 */
export declare const startMailboxExportJob: API.OperationMethod<StartMailboxExportJobRequest & RegionInput, StartMailboxExportJobResponse, StartMailboxExportJobError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidParameterException | OrganizationStateException | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Applies the specified tags to the specified WorkMailorganization
 * resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestAvailabilityConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Performs a test on an availability provider to ensure that access is allowed. For EWS, it verifies the provided credentials can be used to successfully log in. For Lambda, it verifies that the Lambda function can be invoked and that the resource access
 * policy was configured to deny anonymous access. An anonymous invocation is one done without providing either a `SourceArn` or `SourceAccount` header.
 *
 * The request must contain either one provider definition (`EwsProvider` or
 * `LambdaProvider`) or the `DomainName` parameter. If the
 * `DomainName` parameter is provided, the configuration stored under the
 * `DomainName` will be tested.
 */
export declare const testAvailabilityConfiguration: API.OperationMethod<TestAvailabilityConfigurationRequest & RegionInput, TestAvailabilityConfigurationResponse, TestAvailabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Untags the specified tags from the specified WorkMail organization
 * resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAvailabilityConfigurationError = InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an existing `AvailabilityConfiguration` for the given WorkMail
 * organization and domain.
 */
export declare const updateAvailabilityConfiguration: API.OperationMethod<UpdateAvailabilityConfigurationRequest & RegionInput, UpdateAvailabilityConfigurationResponse, UpdateAvailabilityConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateDefaultMailDomainError = InvalidParameterException | MailDomainNotFoundException | MailDomainStateException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Updates the default mail domain for an organization. The default mail domain is used by the WorkMail AWS Console to suggest an email address when enabling a mail user. You can only have one default domain.
 */
export declare const updateDefaultMailDomain: API.OperationMethod<UpdateDefaultMailDomainRequest & RegionInput, UpdateDefaultMailDomainResponse, UpdateDefaultMailDomainError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Updates attributes in a group.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateImpersonationRoleError = EntityNotFoundException | EntityStateException | InvalidParameterException | LimitExceededException | OrganizationNotFoundException | OrganizationStateException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an impersonation role for the given WorkMail organization.
 */
export declare const updateImpersonationRole: API.OperationMethod<UpdateImpersonationRoleRequest & RegionInput, UpdateImpersonationRoleResponse, UpdateImpersonationRoleError, Credentials | HttpClient.HttpClient>;
export type UpdateMailboxQuotaError = EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Updates a user's current mailbox quota for a specified organization and
 * user.
 */
export declare const updateMailboxQuota: API.OperationMethod<UpdateMailboxQuotaRequest & RegionInput, UpdateMailboxQuotaResponse, UpdateMailboxQuotaError, Credentials | HttpClient.HttpClient>;
export type UpdateMobileDeviceAccessRuleError = EntityNotFoundException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | CommonErrors;
/**
 * Updates a mobile device access rule for the specified WorkMail organization.
 */
export declare const updateMobileDeviceAccessRule: API.OperationMethod<UpdateMobileDeviceAccessRuleRequest & RegionInput, UpdateMobileDeviceAccessRuleResponse, UpdateMobileDeviceAccessRuleError, Credentials | HttpClient.HttpClient>;
export type UpdatePrimaryEmailAddressError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EmailAddressInUseException | EntityNotFoundException | EntityStateException | InvalidParameterException | MailDomainNotFoundException | MailDomainStateException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Updates the primary email for a user, group, or resource. The current email is moved
 * into the list of aliases (or swapped between an existing alias and the current primary
 * email), and the email provided in the input is promoted as the primary.
 */
export declare const updatePrimaryEmailAddress: API.OperationMethod<UpdatePrimaryEmailAddressRequest & RegionInput, UpdatePrimaryEmailAddressResponse, UpdatePrimaryEmailAddressError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceError = DirectoryUnavailableException | EmailAddressInUseException | EntityNotFoundException | EntityStateException | InvalidConfigurationException | InvalidParameterException | MailDomainNotFoundException | MailDomainStateException | NameAvailabilityException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Updates data for the resource. To have the latest information, it must be preceded by
 * a DescribeResource call. The dataset in the request should be the one
 * expected when performing another `DescribeResource` call.
 */
export declare const updateResource: API.OperationMethod<UpdateResourceRequest & RegionInput, UpdateResourceResponse, UpdateResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = DirectoryServiceAuthenticationFailedException | DirectoryUnavailableException | EntityNotFoundException | EntityStateException | InvalidParameterException | OrganizationNotFoundException | OrganizationStateException | UnsupportedOperationException | CommonErrors;
/**
 * Updates data for the user. To have the latest information, it must be preceded by a
 * DescribeUser call. The dataset in the request should be the one
 * expected when performing another `DescribeUser` call.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workmail.d.ts.map