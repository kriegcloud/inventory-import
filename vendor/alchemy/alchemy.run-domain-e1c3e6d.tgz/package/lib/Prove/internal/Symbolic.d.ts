import type * as SchemaAST from "effect/SchemaAST";
import type { Term } from "./Smt.ts";
import type { Brand, Run, V } from "./Value.ts";
/** A check the prover does not read, and the part of a value it is on. */
export interface Unread {
    /** The properties that lead to the part, from the top. */
    readonly path: ReadonlyArray<string>;
    /** The part, as a reader names it: `state.code`. */
    readonly at: string;
    /** The check, as its schema says it. */
    readonly check: string;
}
/** The checks of a schema the prover does not read, each with the part it is on. */
export declare const unread: (schema: unknown, name: string) => ReadonlyArray<Unread>;
/** The most items the prover gives a list whose length the schema leaves open. */
export declare const MAX_ITEMS = 2;
/**
 * The items of a list an input holds, on this path: a length the run chooses,
 * and an input for each item. A list the schema lets grow past `MAX_ITEMS` is
 * tried only up to there, and the run says so.
 */
export declare const force: (list: V & {
    readonly _tag: "List";
}, run: Run) => V;
/**
 * A field of an input: one the run has to choose something for is left
 * until the code reads it. A tag is never left: it says what the object is.
 */
export declare const field: (ast: SchemaAST.AST, name: string, key: string, run: Run) => V;
/**
 * What a field holds on this path, now that the code reads it: `undefined`
 * for an optional field the run leaves out. The run chooses once, and every
 * copy of the field reads the same.
 */
export declare const resolve: (pending: V & {
    readonly _tag: "Pending";
}, run: Run) => V | undefined;
/**
 * A field read only for the value it holds, or a default: whether it holds
 * one is an input, and no path is made for each way.
 */
export interface Kept {
    /** Whether the field holds a value. */
    readonly present: Term;
    /** The value it holds where it holds one: a string, a number or a boolean. */
    readonly value: V;
    /** Whether the field is an `Option`: `value` is then what its `Some` holds. */
    readonly option: boolean;
    /** The field where it holds a value. */
    readonly whole: V;
    /** What the field is where it holds none: `undefined` for a field left out. */
    readonly others: ReadonlyArray<V | undefined>;
}
/** A field read only for a value, as the path that read it kept it. */
export declare const keptOf: (pending: V & {
    readonly _tag: "Pending";
}, lists: ReadonlyMap<string, V> | undefined) => Kept | undefined;
/**
 * A field the code reads only for a value, or a default: `field ?? other`,
 * `Option.getOrElse(field, other)`. Both ways go to the same code, so the run
 * does not choose: whether the field holds a value is an input, and what the
 * code computes is one value that depends on it. `undefined` where the field
 * was chosen already, or holds more than one kind of value.
 */
export declare const keep: (pending: V & {
    readonly _tag: "Pending";
}, run: Run) => Kept | undefined;
/** Whether an object has a field the run has not chosen yet. */
export declare const isUnsettled: (value: V) => value is V & {
    readonly _tag: "Obj";
};
/**
 * An object with every field chosen: what code that goes over its keys, or
 * compares it whole, has to see. A run settles an object once, so it stays
 * the one object.
 */
export declare const settle: (value: V, run: Run) => V;
/** The type side of a schema: what `decide` and `evolve` see. */
export declare const typeOf: (schema: unknown) => SchemaAST.AST | undefined;
/**
 * Every value a schema allows, as one symbolic value: an input constant per
 * leaf, with the schema's bounds assumed. A union is a choice the run makes.
 */
export declare const symbolic: (ast: SchemaAST.AST, name: string, run: Run, brand?: Brand) => V;
/**
 * Assume a value passes a schema's checks, where the prover reads them: a
 * domain class refuses to construct otherwise, so nothing is committed.
 * Returns `false` when the value can never pass.
 */
export declare const assumeFits: (value: V, ast: SchemaAST.AST, run: Run) => boolean;
/**
 * That a value is one a schema allows, as a formula: what `symbolic` assumes
 * of an input, asked of a value the code made. Where the prover does not read
 * a schema, the formula is `true`.
 */
export declare const fits: (value: V, ast: SchemaAST.AST, run?: Run) => string;
/** A reason a counterexample's input cannot be built as a real value. */
export interface Unbuildable {
    readonly _tag: "Unbuildable";
    readonly reason: string;
}
/**
 * The real value of a symbolic one in a counterexample: each input constant
 * takes the value the solver found.
 */
export declare const concretize: (value: V, model: ReadonlyMap<string, number | bigint | string | boolean>, 
/** The items each list was given on the path the values come from. */
lists?: ReadonlyMap<string, V>) => {
    readonly value: unknown;
} | Unbuildable;
/** A value as it would be written in TypeScript, on one line. */
export declare const show: (value: unknown) => string;
//# sourceMappingURL=Symbolic.d.ts.map