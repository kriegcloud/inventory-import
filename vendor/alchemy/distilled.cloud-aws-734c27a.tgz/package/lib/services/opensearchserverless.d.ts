import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const OcuLimitExceededException_base: S.TaggedErrorClass<"OcuLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class OcuLimitExceededException extends /*@__PURE__*/ OcuLimitExceededException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CollectionId = string;
export type CollectionIds = string[];
export type CollectionName = string;
export type CollectionNames = string[];
export interface BatchGetCollectionRequest {
    ids?: string[] | undefined;
    names?: string[] | undefined;
}
export type CollectionStatus = string;
export type CollectionType = string;
export type StandbyReplicas = string;
export type DeletionProtection = string;
export type ServerlessVectorAccelerationStatus = string;
export interface VectorOptions {
    ServerlessVectorAcceleration: string;
}
export interface FipsEndpoints {
    collectionEndpoint?: string | undefined;
    dashboardEndpoint?: string | undefined;
}
export type CollectionGroupName = string;
export interface CollectionDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    type?: string | undefined;
    description?: string | undefined;
    arn?: string | undefined;
    kmsKeyArn?: string | undefined;
    standbyReplicas?: string | undefined;
    deletionProtection?: string | undefined;
    vectorOptions?: VectorOptions | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
    collectionEndpoint?: string | undefined;
    dashboardEndpoint?: string | undefined;
    fipsEndpoints?: FipsEndpoints | undefined;
    failureCode?: string | undefined;
    failureMessage?: string | undefined;
    collectionGroupName?: string | undefined;
}
export type CollectionDetails = CollectionDetail[];
export interface CollectionErrorDetail {
    id?: string | undefined;
    name?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
}
export type CollectionErrorDetails = CollectionErrorDetail[];
export interface BatchGetCollectionResponse {
    collectionDetails?: CollectionDetail[] | undefined;
    collectionErrorDetails?: CollectionErrorDetail[] | undefined;
}
export type CollectionGroupId = string;
export type CollectionGroupIds = string[];
export type CollectionGroupNames = string[];
export interface BatchGetCollectionGroupRequest {
    ids?: string[] | undefined;
    names?: string[] | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type Tags = Tag[];
export type CollectionGroupMaxIndexingCapacityValue = number;
export type CollectionGroupMaxSearchCapacityValue = number;
export type CollectionGroupMinIndexingCapacityValue = number;
export type CollectionGroupMinSearchCapacityValue = number;
export interface CollectionGroupCapacityLimits {
    maxIndexingCapacityInOCU?: number | undefined;
    maxSearchCapacityInOCU?: number | undefined;
    minIndexingCapacityInOCU?: number | undefined;
    minSearchCapacityInOCU?: number | undefined;
}
export type AutoscalingStatus = string;
export interface CapacityDetails {
    capacityInOcu?: number | undefined;
    autoscalingStatus?: string | undefined;
}
export interface CurrentCapacity {
    search?: CapacityDetails | undefined;
    indexing?: CapacityDetails | undefined;
}
export type ServerlessGeneration = string;
export interface CollectionGroupDetail {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    standbyReplicas?: string | undefined;
    description?: string | undefined;
    tags?: Tag[] | undefined;
    createdDate?: number | undefined;
    capacityLimits?: CollectionGroupCapacityLimits | undefined;
    currentCapacity?: CurrentCapacity | undefined;
    numberOfCollections?: number | undefined;
    generation?: string | undefined;
}
export type CollectionGroupDetails = CollectionGroupDetail[];
export interface CollectionGroupErrorDetail {
    id?: string | undefined;
    name?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
}
export type CollectionGroupErrorDetails = CollectionGroupErrorDetail[];
export interface BatchGetCollectionGroupResponse {
    collectionGroupDetails?: CollectionGroupDetail[] | undefined;
    collectionGroupErrorDetails?: CollectionGroupErrorDetail[] | undefined;
}
export type LifecyclePolicyType = string;
export type ResourceName = string;
export interface LifecyclePolicyResourceIdentifier {
    type: string;
    resource: string;
}
export type LifecyclePolicyResourceIdentifiers = LifecyclePolicyResourceIdentifier[];
export interface BatchGetEffectiveLifecyclePolicyRequest {
    resourceIdentifiers: LifecyclePolicyResourceIdentifier[];
}
export type Resource = string;
export type PolicyName = string;
export type ResourceType = string;
export interface EffectiveLifecyclePolicyDetail {
    type?: string | undefined;
    resource?: string | undefined;
    policyName?: string | undefined;
    resourceType?: string | undefined;
    retentionPeriod?: string | undefined;
    noMinRetentionPeriod?: boolean | undefined;
}
export type EffectiveLifecyclePolicyDetails = EffectiveLifecyclePolicyDetail[];
export interface EffectiveLifecyclePolicyErrorDetail {
    type?: string | undefined;
    resource?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
}
export type EffectiveLifecyclePolicyErrorDetails = EffectiveLifecyclePolicyErrorDetail[];
export interface BatchGetEffectiveLifecyclePolicyResponse {
    effectiveLifecyclePolicyDetails?: EffectiveLifecyclePolicyDetail[] | undefined;
    effectiveLifecyclePolicyErrorDetails?: EffectiveLifecyclePolicyErrorDetail[] | undefined;
}
export interface LifecyclePolicyIdentifier {
    type: string;
    name: string;
}
export type LifecyclePolicyIdentifiers = LifecyclePolicyIdentifier[];
export interface BatchGetLifecyclePolicyRequest {
    identifiers: LifecyclePolicyIdentifier[];
}
export type PolicyVersion = string;
export type PolicyDescription = string;
export interface LifecyclePolicyDetail {
    type?: string | undefined;
    name?: string | undefined;
    policyVersion?: string | undefined;
    description?: string | undefined;
    policy?: any | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export type LifecyclePolicyDetails = LifecyclePolicyDetail[];
export interface LifecyclePolicyErrorDetail {
    type?: string | undefined;
    name?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
}
export type LifecyclePolicyErrorDetails = LifecyclePolicyErrorDetail[];
export interface BatchGetLifecyclePolicyResponse {
    lifecyclePolicyDetails?: LifecyclePolicyDetail[] | undefined;
    lifecyclePolicyErrorDetails?: LifecyclePolicyErrorDetail[] | undefined;
}
export type VpcEndpointId = string;
export type VpcEndpointIds = string[];
export interface BatchGetVpcEndpointRequest {
    ids: string[];
}
export type VpcEndpointName = string;
export type VpcId = string;
export type SubnetId = string;
export type SubnetIds = string[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type VpcEndpointStatus = string;
export interface VpcEndpointDetail {
    id?: string | undefined;
    name?: string | undefined;
    vpcId?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    status?: string | undefined;
    createdDate?: number | undefined;
    failureCode?: string | undefined;
    failureMessage?: string | undefined;
}
export type VpcEndpointDetails = VpcEndpointDetail[];
export interface VpcEndpointErrorDetail {
    id?: string | undefined;
    errorMessage?: string | undefined;
    errorCode?: string | undefined;
}
export type VpcEndpointErrorDetails = VpcEndpointErrorDetail[];
export interface BatchGetVpcEndpointResponse {
    vpcEndpointDetails?: VpcEndpointDetail[] | undefined;
    vpcEndpointErrorDetails?: VpcEndpointErrorDetail[] | undefined;
}
export type IngestionJobId = string;
export type ClientToken = string;
export interface CancelIngestionJobRequest {
    collectionId: string;
    ingestionJobId: string;
    clientToken?: string | undefined;
}
export type IngestionJobName = string;
export type IngestionJobStatus = string;
export interface CancelIngestionJobResponse {
    ingestionJobId?: string | undefined;
    collectionId?: string | undefined;
    ingestionJobName?: string | undefined;
    status?: string | undefined;
}
export type AccessPolicyType = string;
export type PolicyDocument = string;
export interface CreateAccessPolicyRequest {
    type: string;
    name: string;
    description?: string | undefined;
    policy: string;
    clientToken?: string | undefined;
}
export interface AccessPolicyDetail {
    type?: string | undefined;
    name?: string | undefined;
    policyVersion?: string | undefined;
    description?: string | undefined;
    policy?: any | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export interface CreateAccessPolicyResponse {
    accessPolicyDetail?: AccessPolicyDetail | undefined;
}
export interface EncryptionConfig {
    aWSOwnedKey?: boolean | undefined;
    kmsKeyArn?: string | undefined;
}
export interface CreateCollectionRequest {
    name: string;
    type?: string | undefined;
    description?: string | undefined;
    tags?: Tag[] | undefined;
    standbyReplicas?: string | undefined;
    vectorOptions?: VectorOptions | undefined;
    collectionGroupName?: string | undefined;
    encryptionConfig?: EncryptionConfig | undefined;
    deletionProtection?: string | undefined;
    clientToken?: string | undefined;
}
export interface CreateCollectionDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    type?: string | undefined;
    description?: string | undefined;
    arn?: string | undefined;
    kmsKeyArn?: string | undefined;
    standbyReplicas?: string | undefined;
    deletionProtection?: string | undefined;
    vectorOptions?: VectorOptions | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
    collectionGroupName?: string | undefined;
}
export interface CreateCollectionResponse {
    createCollectionDetail?: CreateCollectionDetail | undefined;
}
export interface CreateCollectionGroupRequest {
    name: string;
    standbyReplicas: string;
    description?: string | undefined;
    tags?: Tag[] | undefined;
    capacityLimits?: CollectionGroupCapacityLimits | undefined;
    generation?: string | undefined;
    clientToken?: string | undefined;
}
export interface CreateCollectionGroupDetail {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    standbyReplicas?: string | undefined;
    description?: string | undefined;
    tags?: Tag[] | undefined;
    createdDate?: number | undefined;
    capacityLimits?: CollectionGroupCapacityLimits | undefined;
    generation?: string | undefined;
}
export interface CreateCollectionGroupResponse {
    createCollectionGroupDetail?: CreateCollectionGroupDetail | undefined;
}
export type IndexName = string;
export type IndexSchema = unknown;
export interface CreateIndexRequest {
    id: string;
    indexName: string;
    indexSchema?: any | undefined;
}
export interface CreateIndexResponse {
}
export type IngestionIndexName = string;
export type S3BucketNameOrArn = string;
export type BucketOwnerAccountId = string;
export interface IngestionJobS3Source {
    bucket?: string | undefined;
    bucketOwnerAccountId?: string | undefined;
    keyPrefix?: string | undefined;
}
export interface IngestionJobSource {
    s3: IngestionJobS3Source;
}
export interface CreateIngestionJobRequest {
    collectionId: string;
    ingestionJobName: string;
    indexName: string;
    failureIndexName?: string | undefined;
    source: IngestionJobSource;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export type IngestionJobResourceArn = string;
export type IngestionState = string;
export interface S3Statistics {
    objectsDiscovered?: number | undefined;
    objectsIngested?: number | undefined;
    objectsFailed?: number | undefined;
}
export interface IngestionStatistics {
    s3?: S3Statistics | undefined;
}
export type IngestionFailureCode = string;
export interface IngestionFailureReason {
    code?: string | undefined;
    message?: string | undefined;
}
export type IngestionFailureReasons = IngestionFailureReason[];
export type IngestionAlertCode = string;
export interface IngestionAlert {
    code?: string | undefined;
    message?: string | undefined;
}
export type IngestionAlerts = IngestionAlert[];
export interface IngestionJobDetail {
    ingestionJobId?: string | undefined;
    arn?: string | undefined;
    collectionId?: string | undefined;
    ingestionJobName?: string | undefined;
    indexName?: string | undefined;
    failureIndexName?: string | undefined;
    source?: IngestionJobSource | undefined;
    status?: string | undefined;
    state?: string | undefined;
    statistics?: IngestionStatistics | undefined;
    revision?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    failureReasons?: IngestionFailureReason[] | undefined;
    activeAlerts?: IngestionAlert[] | undefined;
}
export interface CreateIngestionJobResponse {
    ingestionJobDetail?: IngestionJobDetail | undefined;
}
export type IngestionStreamName = string;
export type SqsArn = string;
export type InitialScan = string;
export interface StreamBucketConfig {
    bucket: string;
    bucketOwnerAccountId?: string | undefined;
    initialScan?: string | undefined;
}
export type StreamBucketConfigs = StreamBucketConfig[];
export interface IngestionStreamS3Source {
    sqsArn: string;
    buckets?: StreamBucketConfig[] | undefined;
}
export interface IngestionStreamSource {
    s3: IngestionStreamS3Source;
}
export type RoleArn = string;
export interface CreateIngestionStreamRequest {
    collectionId: string;
    ingestionStreamName: string;
    indexName: string;
    failureIndexName?: string | undefined;
    source: IngestionStreamSource;
    roleArn: string;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export type IngestionStreamId = string;
export type IngestionStreamResourceArn = string;
export type IngestionStreamStatus = string;
export interface IngestionStreamDetail {
    ingestionStreamId?: string | undefined;
    arn?: string | undefined;
    collectionId?: string | undefined;
    ingestionStreamName?: string | undefined;
    indexName?: string | undefined;
    failureIndexName?: string | undefined;
    source?: IngestionStreamSource | undefined;
    roleArn?: string | undefined;
    status?: string | undefined;
    state?: string | undefined;
    statistics?: IngestionStatistics | undefined;
    revision?: number | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    failureReasons?: IngestionFailureReason[] | undefined;
    activeAlerts?: IngestionAlert[] | undefined;
}
export interface CreateIngestionStreamResponse {
    ingestionStreamDetail?: IngestionStreamDetail | undefined;
}
export interface CreateLifecyclePolicyRequest {
    type: string;
    name: string;
    description?: string | undefined;
    policy: string;
    clientToken?: string | undefined;
}
export interface CreateLifecyclePolicyResponse {
    lifecyclePolicyDetail?: LifecyclePolicyDetail | undefined;
}
export type SecurityConfigType = string;
export type ConfigName = string;
export type ConfigDescription = string;
export type SamlMetadata = string;
export type SamlUserAttribute = string;
export type SamlGroupAttribute = string;
export type OpenSearchServerlessEntityId = string;
export interface SamlConfigOptions {
    metadata: string;
    userAttribute?: string | undefined;
    groupAttribute?: string | undefined;
    openSearchServerlessEntityId?: string | undefined;
    sessionTimeout?: number | undefined;
}
export type IamIdentityCenterInstanceArn = string;
export type IamIdentityCenterUserAttribute = string;
export type IamIdentityCenterGroupAttribute = string;
export interface CreateIamIdentityCenterConfigOptions {
    instanceArn: string;
    userAttribute?: string | undefined;
    groupAttribute?: string | undefined;
}
export type IamFederationGroupAttribute = string;
export type IamFederationUserAttribute = string;
export interface IamFederationConfigOptions {
    groupAttribute?: string | undefined;
    userAttribute?: string | undefined;
}
export interface CreateSecurityConfigRequest {
    type: string;
    name: string;
    description?: string | undefined;
    samlOptions?: SamlConfigOptions | undefined;
    iamIdentityCenterOptions?: CreateIamIdentityCenterConfigOptions | undefined;
    iamFederationOptions?: IamFederationConfigOptions | undefined;
    clientToken?: string | undefined;
}
export type SecurityConfigId = string;
export type IamIdentityCenterApplicationArn = string;
export interface IamIdentityCenterConfigOptions {
    instanceArn?: string | undefined;
    applicationArn?: string | undefined;
    applicationName?: string | undefined;
    applicationDescription?: string | undefined;
    userAttribute?: string | undefined;
    groupAttribute?: string | undefined;
}
export interface SecurityConfigDetail {
    id?: string | undefined;
    type?: string | undefined;
    configVersion?: string | undefined;
    description?: string | undefined;
    samlOptions?: SamlConfigOptions | undefined;
    iamIdentityCenterOptions?: IamIdentityCenterConfigOptions | undefined;
    iamFederationOptions?: IamFederationConfigOptions | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export interface CreateSecurityConfigResponse {
    securityConfigDetail?: SecurityConfigDetail | undefined;
}
export type SecurityPolicyType = string;
export interface CreateSecurityPolicyRequest {
    type: string;
    name: string;
    description?: string | undefined;
    policy: string;
    clientToken?: string | undefined;
}
export interface SecurityPolicyDetail {
    type?: string | undefined;
    name?: string | undefined;
    policyVersion?: string | undefined;
    description?: string | undefined;
    policy?: any | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export interface CreateSecurityPolicyResponse {
    securityPolicyDetail?: SecurityPolicyDetail | undefined;
}
export interface CreateVpcEndpointRequest {
    name: string;
    vpcId: string;
    subnetIds: string[];
    securityGroupIds?: string[] | undefined;
    clientToken?: string | undefined;
}
export interface CreateVpcEndpointDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
}
export interface CreateVpcEndpointResponse {
    createVpcEndpointDetail?: CreateVpcEndpointDetail | undefined;
}
export interface DeleteAccessPolicyRequest {
    type: string;
    name: string;
    clientToken?: string | undefined;
}
export interface DeleteAccessPolicyResponse {
}
export interface DeleteCollectionRequest {
    id: string;
    clientToken?: string | undefined;
}
export interface DeleteCollectionDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    deletionProtection?: string | undefined;
}
export interface DeleteCollectionResponse {
    deleteCollectionDetail?: DeleteCollectionDetail | undefined;
}
export interface DeleteCollectionGroupRequest {
    id: string;
    clientToken?: string | undefined;
}
export interface DeleteCollectionGroupResponse {
}
export interface DeleteIndexRequest {
    id: string;
    indexName: string;
}
export interface DeleteIndexResponse {
}
export interface DeleteIngestionStreamRequest {
    collectionId: string;
    ingestionStreamId: string;
    clientToken?: string | undefined;
}
export interface DeleteIngestionStreamResponse {
    ingestionStreamId?: string | undefined;
    collectionId?: string | undefined;
    ingestionStreamName?: string | undefined;
    status?: string | undefined;
}
export interface DeleteLifecyclePolicyRequest {
    type: string;
    name: string;
    clientToken?: string | undefined;
}
export interface DeleteLifecyclePolicyResponse {
}
export interface DeleteSecurityConfigRequest {
    id: string;
    clientToken?: string | undefined;
}
export interface DeleteSecurityConfigResponse {
}
export interface DeleteSecurityPolicyRequest {
    type: string;
    name: string;
    clientToken?: string | undefined;
}
export interface DeleteSecurityPolicyResponse {
}
export interface DeleteVpcEndpointRequest {
    id: string;
    clientToken?: string | undefined;
}
export interface DeleteVpcEndpointDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
}
export interface DeleteVpcEndpointResponse {
    deleteVpcEndpointDetail?: DeleteVpcEndpointDetail | undefined;
}
export interface GetAccessPolicyRequest {
    type: string;
    name: string;
}
export interface GetAccessPolicyResponse {
    accessPolicyDetail?: AccessPolicyDetail | undefined;
}
export interface GetAccountSettingsRequest {
}
export type IndexingCapacityValue = number;
export type SearchCapacityValue = number;
export interface CapacityLimits {
    maxIndexingCapacityInOCU?: number | undefined;
    maxSearchCapacityInOCU?: number | undefined;
}
export interface AccountSettingsDetail {
    capacityLimits?: CapacityLimits | undefined;
}
export interface GetAccountSettingsResponse {
    accountSettingsDetail?: AccountSettingsDetail | undefined;
}
export interface GetIndexRequest {
    id: string;
    indexName: string;
}
export interface GetIndexResponse {
    indexSchema?: any | undefined;
}
export interface GetIngestionJobRequest {
    collectionId: string;
    ingestionJobId: string;
}
export interface GetIngestionJobResponse {
    ingestionJobDetail?: IngestionJobDetail | undefined;
}
export interface GetIngestionStreamRequest {
    collectionId: string;
    ingestionStreamId: string;
}
export interface GetIngestionStreamResponse {
    ingestionStreamDetail?: IngestionStreamDetail | undefined;
}
export interface GetPoliciesStatsRequest {
}
export interface AccessPolicyStats {
    DataPolicyCount?: number | undefined;
}
export interface SecurityPolicyStats {
    EncryptionPolicyCount?: number | undefined;
    NetworkPolicyCount?: number | undefined;
}
export interface SecurityConfigStats {
    SamlConfigCount?: number | undefined;
}
export interface LifecyclePolicyStats {
    RetentionPolicyCount?: number | undefined;
}
export interface GetPoliciesStatsResponse {
    AccessPolicyStats?: AccessPolicyStats | undefined;
    SecurityPolicyStats?: SecurityPolicyStats | undefined;
    SecurityConfigStats?: SecurityConfigStats | undefined;
    LifecyclePolicyStats?: LifecyclePolicyStats | undefined;
    TotalPolicyCount?: number | undefined;
}
export interface GetSecurityConfigRequest {
    id: string;
}
export interface GetSecurityConfigResponse {
    securityConfigDetail?: SecurityConfigDetail | undefined;
}
export interface GetSecurityPolicyRequest {
    type: string;
    name: string;
}
export interface GetSecurityPolicyResponse {
    securityPolicyDetail?: SecurityPolicyDetail | undefined;
}
export type ResourceFilter = string[];
export interface ListAccessPoliciesRequest {
    type: string;
    resource?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface AccessPolicySummary {
    type?: string | undefined;
    name?: string | undefined;
    policyVersion?: string | undefined;
    description?: string | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export type AccessPolicySummaries = AccessPolicySummary[];
export interface ListAccessPoliciesResponse {
    accessPolicySummaries?: AccessPolicySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListCollectionGroupsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CollectionGroupSummary {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    numberOfCollections?: number | undefined;
    createdDate?: number | undefined;
    capacityLimits?: CollectionGroupCapacityLimits | undefined;
    generation?: string | undefined;
}
export type CollectionGroupSummaries = CollectionGroupSummary[];
export interface ListCollectionGroupsResponse {
    collectionGroupSummaries?: CollectionGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface CollectionFilters {
    name?: string | undefined;
    status?: string | undefined;
    collectionGroupName?: string | undefined;
}
export interface ListCollectionsRequest {
    collectionFilters?: CollectionFilters | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface CollectionSummary {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    arn?: string | undefined;
    kmsKeyArn?: string | undefined;
    collectionGroupName?: string | undefined;
}
export type CollectionSummaries = CollectionSummary[];
export interface ListCollectionsResponse {
    collectionSummaries?: CollectionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListIngestionJobsRequest {
    collectionId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IngestionJobSummary {
    ingestionJobId?: string | undefined;
    arn?: string | undefined;
    ingestionJobName?: string | undefined;
    indexName?: string | undefined;
    status?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type IngestionJobSummaries = IngestionJobSummary[];
export interface ListIngestionJobsResponse {
    ingestionJobSummaries?: IngestionJobSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListIngestionStreamsRequest {
    collectionId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface IngestionStreamSummary {
    ingestionStreamId?: string | undefined;
    arn?: string | undefined;
    ingestionStreamName?: string | undefined;
    indexName?: string | undefined;
    status?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export type IngestionStreamSummaries = IngestionStreamSummary[];
export interface ListIngestionStreamsResponse {
    ingestionStreamSummaries?: IngestionStreamSummary[] | undefined;
    nextToken?: string | undefined;
}
export type LifecycleResource = string;
export type LifecycleResourceFilter = string[];
export interface ListLifecyclePoliciesRequest {
    type: string;
    resources?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface LifecyclePolicySummary {
    type?: string | undefined;
    name?: string | undefined;
    policyVersion?: string | undefined;
    description?: string | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export type LifecyclePolicySummaries = LifecyclePolicySummary[];
export interface ListLifecyclePoliciesResponse {
    lifecyclePolicySummaries?: LifecyclePolicySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSecurityConfigsRequest {
    type: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SecurityConfigSummary {
    id?: string | undefined;
    type?: string | undefined;
    configVersion?: string | undefined;
    description?: string | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export type SecurityConfigSummaries = SecurityConfigSummary[];
export interface ListSecurityConfigsResponse {
    securityConfigSummaries?: SecurityConfigSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSecurityPoliciesRequest {
    type: string;
    resource?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SecurityPolicySummary {
    type?: string | undefined;
    name?: string | undefined;
    policyVersion?: string | undefined;
    description?: string | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
}
export type SecurityPolicySummaries = SecurityPolicySummary[];
export interface ListSecurityPoliciesResponse {
    securityPolicySummaries?: SecurityPolicySummary[] | undefined;
    nextToken?: string | undefined;
}
export type Arn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface VpcEndpointFilters {
    status?: string | undefined;
}
export interface ListVpcEndpointsRequest {
    vpcEndpointFilters?: VpcEndpointFilters | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface VpcEndpointSummary {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
}
export type VpcEndpointSummaries = VpcEndpointSummary[];
export interface ListVpcEndpointsResponse {
    vpcEndpointSummaries?: VpcEndpointSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessPolicyRequest {
    type: string;
    name: string;
    policyVersion: string;
    description?: string | undefined;
    policy?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateAccessPolicyResponse {
    accessPolicyDetail?: AccessPolicyDetail | undefined;
}
export interface UpdateAccountSettingsRequest {
    capacityLimits?: CapacityLimits | undefined;
}
export interface UpdateAccountSettingsResponse {
    accountSettingsDetail?: AccountSettingsDetail | undefined;
}
export interface UpdateCollectionRequest {
    id: string;
    description?: string | undefined;
    vectorOptions?: VectorOptions | undefined;
    deletionProtection?: string | undefined;
    encryptionConfig?: EncryptionConfig | undefined;
    clientToken?: string | undefined;
}
export interface UpdateCollectionDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    type?: string | undefined;
    description?: string | undefined;
    vectorOptions?: VectorOptions | undefined;
    kmsKeyArn?: string | undefined;
    arn?: string | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
    deletionProtection?: string | undefined;
}
export interface UpdateCollectionResponse {
    updateCollectionDetail?: UpdateCollectionDetail | undefined;
}
export interface UpdateCollectionGroupRequest {
    id: string;
    description?: string | undefined;
    capacityLimits?: CollectionGroupCapacityLimits | undefined;
    clientToken?: string | undefined;
}
export interface UpdateCollectionGroupDetail {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    capacityLimits?: CollectionGroupCapacityLimits | undefined;
    createdDate?: number | undefined;
    lastModifiedDate?: number | undefined;
    generation?: string | undefined;
}
export interface UpdateCollectionGroupResponse {
    updateCollectionGroupDetail?: UpdateCollectionGroupDetail | undefined;
}
export interface UpdateIndexRequest {
    id: string;
    indexName: string;
    indexSchema?: any | undefined;
}
export interface UpdateIndexResponse {
}
export interface UpdateLifecyclePolicyRequest {
    type: string;
    name: string;
    policyVersion: string;
    description?: string | undefined;
    policy?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateLifecyclePolicyResponse {
    lifecyclePolicyDetail?: LifecyclePolicyDetail | undefined;
}
export interface UpdateIamIdentityCenterConfigOptions {
    userAttribute?: string | undefined;
    groupAttribute?: string | undefined;
}
export interface UpdateSecurityConfigRequest {
    id: string;
    configVersion: string;
    description?: string | undefined;
    samlOptions?: SamlConfigOptions | undefined;
    iamIdentityCenterOptionsUpdates?: UpdateIamIdentityCenterConfigOptions | undefined;
    iamFederationOptions?: IamFederationConfigOptions | undefined;
    clientToken?: string | undefined;
}
export interface UpdateSecurityConfigResponse {
    securityConfigDetail?: SecurityConfigDetail | undefined;
}
export interface UpdateSecurityPolicyRequest {
    type: string;
    name: string;
    policyVersion: string;
    description?: string | undefined;
    policy?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateSecurityPolicyResponse {
    securityPolicyDetail?: SecurityPolicyDetail | undefined;
}
export interface UpdateVpcEndpointRequest {
    id: string;
    addSubnetIds?: string[] | undefined;
    removeSubnetIds?: string[] | undefined;
    addSecurityGroupIds?: string[] | undefined;
    removeSecurityGroupIds?: string[] | undefined;
    clientToken?: string | undefined;
}
export interface UpdateVpcEndpointDetail {
    id?: string | undefined;
    name?: string | undefined;
    status?: string | undefined;
    subnetIds?: string[] | undefined;
    securityGroupIds?: string[] | undefined;
    lastModifiedDate?: number | undefined;
}
export interface UpdateVpcEndpointResponse {
    UpdateVpcEndpointDetail?: UpdateVpcEndpointDetail | undefined;
}
export type BatchGetCollectionError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns attributes for one or more collections, including the collection endpoint, the OpenSearch Dashboards endpoint, and FIPS-compliant endpoints. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const batchGetCollection: API.OperationMethod<BatchGetCollectionRequest & RegionInput, BatchGetCollectionResponse, BatchGetCollectionError, Credentials | HttpClient.HttpClient>;
export type BatchGetCollectionGroupError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns attributes for one or more collection groups, including capacity limits and the number of collections in each group. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const batchGetCollectionGroup: API.OperationMethod<BatchGetCollectionGroupRequest & RegionInput, BatchGetCollectionGroupResponse, BatchGetCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type BatchGetEffectiveLifecyclePolicyError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of successful and failed retrievals for the OpenSearch Serverless indexes. For more information, see Viewing data lifecycle policies.
 */
export declare const batchGetEffectiveLifecyclePolicy: API.OperationMethod<BatchGetEffectiveLifecyclePolicyRequest & RegionInput, BatchGetEffectiveLifecyclePolicyResponse, BatchGetEffectiveLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type BatchGetLifecyclePolicyError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns one or more configured OpenSearch Serverless lifecycle policies. For more information, see Viewing data lifecycle policies.
 */
export declare const batchGetLifecyclePolicy: API.OperationMethod<BatchGetLifecyclePolicyRequest & RegionInput, BatchGetLifecyclePolicyResponse, BatchGetLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type BatchGetVpcEndpointError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns attributes for one or more VPC endpoints associated with the current account. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const batchGetVpcEndpoint: API.OperationMethod<BatchGetVpcEndpointRequest & RegionInput, BatchGetVpcEndpointResponse, BatchGetVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type CancelIngestionJobError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Cancels an in-progress ingestion job. Documents that were already indexed before the cancellation remain in the index.
 */
export declare const cancelIngestionJob: API.OperationMethod<CancelIngestionJobRequest & RegionInput, CancelIngestionJobResponse, CancelIngestionJobError, Credentials | HttpClient.HttpClient>;
export type CreateAccessPolicyError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a data access policy for OpenSearch Serverless. Access policies limit access to collections and the resources within them, and allow a user to access that data irrespective of the access mechanism or network source. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const createAccessPolicy: API.OperationMethod<CreateAccessPolicyRequest & RegionInput, CreateAccessPolicyResponse, CreateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateCollectionError = ConflictException | InternalServerException | OcuLimitExceededException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a new OpenSearch Serverless collection. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const createCollection: API.OperationMethod<CreateCollectionRequest & RegionInput, CreateCollectionResponse, CreateCollectionError, Credentials | HttpClient.HttpClient>;
export type CreateCollectionGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a collection group within OpenSearch Serverless. Collection groups let you manage OpenSearch Compute Units (OCUs) at a group level, with multiple collections sharing the group's capacity limits.
 *
 * For more information, see Managing collection groups.
 */
export declare const createCollectionGroup: API.OperationMethod<CreateCollectionGroupRequest & RegionInput, CreateCollectionGroupResponse, CreateCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type CreateIndexError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates an index within an OpenSearch Serverless collection. Unlike other OpenSearch indexes, indexes created by this API are automatically configured to conduct automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment in the *OpenSearch User Guide*.
 */
export declare const createIndex: API.OperationMethod<CreateIndexRequest & RegionInput, CreateIndexResponse, CreateIndexError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionJobError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an ingestion job that performs a one-time bulk ingestion of data from an Amazon S3 bucket into an index in an OpenSearch Serverless collection. An ingestion job scans the source bucket, indexes the documents it finds, and then completes. To continuously ingest new data as it arrives, use `CreateIngestionStream` instead.
 */
export declare const createIngestionJob: API.OperationMethod<CreateIngestionJobRequest & RegionInput, CreateIngestionJobResponse, CreateIngestionJobError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionStreamError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an ingestion stream that continuously ingests data from an Amazon S3 bucket into an index in an OpenSearch Serverless collection. An ingestion stream processes Amazon S3 event notifications delivered to an Amazon SQS queue and ingests new objects as they arrive. The stream continues to ingest data until you delete it. To perform a one-time bulk ingestion instead, use `CreateIngestionJob`.
 */
export declare const createIngestionStream: API.OperationMethod<CreateIngestionStreamRequest & RegionInput, CreateIngestionStreamResponse, CreateIngestionStreamError, Credentials | HttpClient.HttpClient>;
export type CreateLifecyclePolicyError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a lifecyle policy to be applied to OpenSearch Serverless indexes. Lifecycle policies define the number of days or hours to retain the data on an OpenSearch Serverless index. For more information, see Creating data lifecycle policies.
 */
export declare const createLifecyclePolicy: API.OperationMethod<CreateLifecyclePolicyRequest & RegionInput, CreateLifecyclePolicyResponse, CreateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityConfigError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Specifies a security configuration for OpenSearch Serverless. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const createSecurityConfig: API.OperationMethod<CreateSecurityConfigRequest & RegionInput, CreateSecurityConfigResponse, CreateSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type CreateSecurityPolicyError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a security policy to be used by one or more OpenSearch Serverless collections. Security policies provide access to a collection and its OpenSearch Dashboards endpoint from public networks or specific VPC endpoints. They also allow you to secure a collection with a KMS encryption key. For more information, see Network access for Amazon OpenSearch Serverless and Encryption at rest for Amazon OpenSearch Serverless.
 */
export declare const createSecurityPolicy: API.OperationMethod<CreateSecurityPolicyRequest & RegionInput, CreateSecurityPolicyResponse, CreateSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateVpcEndpointError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates an OpenSearch Serverless-managed interface VPC endpoint. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const createVpcEndpoint: API.OperationMethod<CreateVpcEndpointRequest & RegionInput, CreateVpcEndpointResponse, CreateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless access policy. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const deleteAccessPolicy: API.OperationMethod<DeleteAccessPolicyRequest & RegionInput, DeleteAccessPolicyResponse, DeleteAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteCollectionError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless collection. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const deleteCollection: API.OperationMethod<DeleteCollectionRequest & RegionInput, DeleteCollectionResponse, DeleteCollectionError, Credentials | HttpClient.HttpClient>;
export type DeleteCollectionGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a collection group. You can only delete empty collection groups that contain no collections. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const deleteCollectionGroup: API.OperationMethod<DeleteCollectionGroupRequest & RegionInput, DeleteCollectionGroupResponse, DeleteCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteIndexError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an index from an OpenSearch Serverless collection. Be aware that the index might be configured to conduct automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment.
 */
export declare const deleteIndex: API.OperationMethod<DeleteIndexRequest & RegionInput, DeleteIndexResponse, DeleteIndexError, Credentials | HttpClient.HttpClient>;
export type DeleteIngestionStreamError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an ingestion stream. Documents that were already indexed by the stream remain in the index.
 */
export declare const deleteIngestionStream: API.OperationMethod<DeleteIngestionStreamRequest & RegionInput, DeleteIngestionStreamResponse, DeleteIngestionStreamError, Credentials | HttpClient.HttpClient>;
export type DeleteLifecyclePolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless lifecycle policy. For more information, see Deleting data lifecycle policies.
 */
export declare const deleteLifecyclePolicy: API.OperationMethod<DeleteLifecyclePolicyRequest & RegionInput, DeleteLifecyclePolicyResponse, DeleteLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityConfigError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a security configuration for OpenSearch Serverless. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const deleteSecurityConfig: API.OperationMethod<DeleteSecurityConfigRequest & RegionInput, DeleteSecurityConfigResponse, DeleteSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteSecurityPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless security policy.
 */
export declare const deleteSecurityPolicy: API.OperationMethod<DeleteSecurityPolicyRequest & RegionInput, DeleteSecurityPolicyResponse, DeleteSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteVpcEndpointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes an OpenSearch Serverless-managed interface endpoint. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const deleteVpcEndpoint: API.OperationMethod<DeleteVpcEndpointRequest & RegionInput, DeleteVpcEndpointResponse, DeleteVpcEndpointError, Credentials | HttpClient.HttpClient>;
export type GetAccessPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns an OpenSearch Serverless access policy. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const getAccessPolicy: API.OperationMethod<GetAccessPolicyRequest & RegionInput, GetAccessPolicyResponse, GetAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type GetAccountSettingsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns account-level settings related to OpenSearch Serverless.
 */
export declare const getAccountSettings: API.OperationMethod<GetAccountSettingsRequest & RegionInput, GetAccountSettingsResponse, GetAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type GetIndexError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves information about an index in an OpenSearch Serverless collection, including its schema definition. The index might be configured to conduct automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment.
 */
export declare const getIndex: API.OperationMethod<GetIndexRequest & RegionInput, GetIndexResponse, GetIndexError, Credentials | HttpClient.HttpClient>;
export type GetIngestionJobError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an ingestion job, including its configuration, status, and processing state.
 */
export declare const getIngestionJob: API.OperationMethod<GetIngestionJobRequest & RegionInput, GetIngestionJobResponse, GetIngestionJobError, Credentials | HttpClient.HttpClient>;
export type GetIngestionStreamError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an ingestion stream, including its configuration, status, and processing state.
 */
export declare const getIngestionStream: API.OperationMethod<GetIngestionStreamRequest & RegionInput, GetIngestionStreamResponse, GetIngestionStreamError, Credentials | HttpClient.HttpClient>;
export type GetPoliciesStatsError = InternalServerException | CommonErrors;
/**
 * Returns statistical information about your OpenSearch Serverless access policies, security configurations, and security policies.
 */
export declare const getPoliciesStats: API.OperationMethod<GetPoliciesStatsRequest & RegionInput, GetPoliciesStatsResponse, GetPoliciesStatsError, Credentials | HttpClient.HttpClient>;
export type GetSecurityConfigError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about an OpenSearch Serverless security configuration. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const getSecurityConfig: API.OperationMethod<GetSecurityConfigRequest & RegionInput, GetSecurityConfigResponse, GetSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type GetSecurityPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns information about a configured OpenSearch Serverless security policy. For more information, see Network access for Amazon OpenSearch Serverless and Encryption at rest for Amazon OpenSearch Serverless.
 */
export declare const getSecurityPolicy: API.OperationMethod<GetSecurityPolicyRequest & RegionInput, GetSecurityPolicyResponse, GetSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAccessPoliciesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about a list of OpenSearch Serverless access policies.
 */
export declare const listAccessPolicies: API.PaginatedOperationMethod<ListAccessPoliciesRequest & RegionInput, ListAccessPoliciesResponse, ListAccessPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCollectionGroupsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of collection groups. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 */
export declare const listCollectionGroups: API.PaginatedOperationMethod<ListCollectionGroupsRequest & RegionInput, ListCollectionGroupsResponse, ListCollectionGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListCollectionsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists all OpenSearch Serverless collections. For more information, see Creating and managing Amazon OpenSearch Serverless collections.
 *
 * Make sure to include an empty request body {} if you don't include any collection filters in the request.
 */
export declare const listCollections: API.PaginatedOperationMethod<ListCollectionsRequest & RegionInput, ListCollectionsResponse, ListCollectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListIngestionJobsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of ingestion jobs in a collection.
 */
export declare const listIngestionJobs: API.PaginatedOperationMethod<ListIngestionJobsRequest & RegionInput, ListIngestionJobsResponse, ListIngestionJobsError, Credentials | HttpClient.HttpClient, IngestionJobSummary>;
export type ListIngestionStreamsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of ingestion streams in a collection.
 */
export declare const listIngestionStreams: API.PaginatedOperationMethod<ListIngestionStreamsRequest & RegionInput, ListIngestionStreamsResponse, ListIngestionStreamsError, Credentials | HttpClient.HttpClient, IngestionStreamSummary>;
export type ListLifecyclePoliciesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of OpenSearch Serverless lifecycle policies. For more information, see Viewing data lifecycle policies.
 */
export declare const listLifecyclePolicies: API.PaginatedOperationMethod<ListLifecyclePoliciesRequest & RegionInput, ListLifecyclePoliciesResponse, ListLifecyclePoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSecurityConfigsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about configured OpenSearch Serverless security configurations. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const listSecurityConfigs: API.PaginatedOperationMethod<ListSecurityConfigsRequest & RegionInput, ListSecurityConfigsResponse, ListSecurityConfigsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListSecurityPoliciesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns information about configured OpenSearch Serverless security policies.
 */
export declare const listSecurityPolicies: API.PaginatedOperationMethod<ListSecurityPoliciesRequest & RegionInput, ListSecurityPoliciesResponse, ListSecurityPoliciesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the tags for an OpenSearch Serverless resource. For more information, see Tagging Amazon OpenSearch Serverless collections.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListVpcEndpointsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Returns the OpenSearch Serverless-managed interface VPC endpoints associated with the current account. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const listVpcEndpoints: API.PaginatedOperationMethod<ListVpcEndpointsRequest & RegionInput, ListVpcEndpointsResponse, ListVpcEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type TagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Associates tags with an OpenSearch Serverless resource. For more information, see Tagging Amazon OpenSearch Serverless collections.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes a tag or set of tags from an OpenSearch Serverless resource. For more information, see Tagging Amazon OpenSearch Serverless collections.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless access policy. For more information, see Data access control for Amazon OpenSearch Serverless.
 */
export declare const updateAccessPolicy: API.OperationMethod<UpdateAccessPolicyRequest & RegionInput, UpdateAccessPolicyResponse, UpdateAccessPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Update the OpenSearch Serverless settings for the current Amazon Web Services account. For more information, see Managing capacity limits for Amazon OpenSearch Serverless.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsRequest & RegionInput, UpdateAccountSettingsResponse, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateCollectionError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless collection.
 */
export declare const updateCollection: API.OperationMethod<UpdateCollectionRequest & RegionInput, UpdateCollectionResponse, UpdateCollectionError, Credentials | HttpClient.HttpClient>;
export type UpdateCollectionGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates the description and capacity limits of a collection group.
 */
export declare const updateCollectionGroup: API.OperationMethod<UpdateCollectionGroupRequest & RegionInput, UpdateCollectionGroupResponse, UpdateCollectionGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIndexError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates an existing index in an OpenSearch Serverless collection. This operation allows you to modify the index schema, including adding new fields or changing field mappings. You can also enable automatic semantic enrichment ingestion and search. For more information, see About automatic semantic enrichment.
 */
export declare const updateIndex: API.OperationMethod<UpdateIndexRequest & RegionInput, UpdateIndexResponse, UpdateIndexError, Credentials | HttpClient.HttpClient>;
export type UpdateLifecyclePolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless access policy. For more information, see Updating data lifecycle policies.
 */
export declare const updateLifecyclePolicy: API.OperationMethod<UpdateLifecyclePolicyRequest & RegionInput, UpdateLifecyclePolicyResponse, UpdateLifecyclePolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityConfigError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates a security configuration for OpenSearch Serverless. For more information, see SAML authentication for Amazon OpenSearch Serverless.
 */
export declare const updateSecurityConfig: API.OperationMethod<UpdateSecurityConfigRequest & RegionInput, UpdateSecurityConfigResponse, UpdateSecurityConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityPolicyError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless security policy. For more information, see Network access for Amazon OpenSearch Serverless and Encryption at rest for Amazon OpenSearch Serverless.
 */
export declare const updateSecurityPolicy: API.OperationMethod<UpdateSecurityPolicyRequest & RegionInput, UpdateSecurityPolicyResponse, UpdateSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateVpcEndpointError = ConflictException | InternalServerException | ValidationException | CommonErrors;
/**
 * Updates an OpenSearch Serverless-managed interface endpoint. For more information, see Access Amazon OpenSearch Serverless using an interface endpoint.
 */
export declare const updateVpcEndpoint: API.OperationMethod<UpdateVpcEndpointRequest & RegionInput, UpdateVpcEndpointResponse, UpdateVpcEndpointError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=opensearchserverless.d.ts.map