import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
import * as Alchemist from "../../../Alchemist/index.ts";
import * as Interaction from "../../../Interaction.ts";
export declare const profileTui: Effect.Effect<typeof import("../../../Cli/components/view/Profile.tsx"), never, never>;
export type EditAction = "add" | "reconfigure" | "remove";
export interface EditOutcome {
    readonly provider: string;
    readonly action: EditAction;
    readonly outcome: "done" | "skipped";
}
export declare const showProfileFlow: (options: {
    profileName: string;
    activeProfile: string;
    envFile: Option.Option<string>;
    main: string;
}) => Effect.Effect<void, Alchemist.AlchemistNotFound | import("../../../Auth/Profile.ts").ProfileError | import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersError, import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersServices>;
export declare const renameProfileFlow: (name: string, suppliedNewName: string | undefined) => Effect.Effect<string, Alchemist.AlchemistNotFound | import("../../../Auth/Profile.ts").ProfileError | import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersError | Interaction.InteractionError, import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersServices>;
export declare const deleteProfileFlow: (options: {
    name: string;
    envFile: Option.Option<string>;
    main: string;
    yes: boolean;
}) => Effect.Effect<boolean, Alchemist.AlchemistNotFound | import("../../../Auth/AuthProvider.ts").AuthError | import("../confirm.ts").ConfirmationDeclined | import("effect/PlatformError").PlatformError | import("../../../Auth/Profile.ts").ProfileError | Interaction.InteractionError, import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersServices>;
export declare const editProfileFlow: (options: {
    selectedProfile: string;
    add: ReadonlyArray<string>;
    reconfigure: ReadonlyArray<string>;
    remove: ReadonlyArray<string>;
    envFile: Option.Option<string>;
    main: string;
    configureInput?: {
        method?: string;
        values: Record<string, string>;
    };
}) => Effect.Effect<EditOutcome[], Alchemist.AlchemistInvalidInput | Alchemist.AlchemistNotFound | import("../../../Auth/Profile.ts").ProfileError | import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersError | Interaction.InteractionError, import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersServices>;
//# sourceMappingURL=flows.d.ts.map