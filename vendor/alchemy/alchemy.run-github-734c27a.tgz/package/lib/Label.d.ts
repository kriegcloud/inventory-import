import * as Issues from "@distilled.cloud/github/issues";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import type * as GitHub from "./Providers.ts";
export interface LabelProps {
    /**
     * Repository owner (user or organization).
     */
    owner: string;
    /**
     * Repository name.
     */
    repository: string;
    /**
     * Label name. The name is the label's identity — changing it replaces the
     * label.
     */
    name: string;
    /**
     * Label color (6-character hex code without the leading `#`).
     * @default "ededed"
     */
    color?: string;
    /**
     * Short description of the label.
     */
    description?: string;
    /**
     * Override the GitHub host or API base URL for this resource only (e.g.
     * `github.example.com` for GitHub Enterprise). Falls back to
     * `GitHub.providers({ baseUrl })`, then to the host resolved by the auth
     * provider. Changing it replaces the resource — the same name on a
     * different GitHub instance is a different physical resource.
     */
    baseUrl?: string;
}
export interface Label extends Resource<"GitHub.Label", LabelProps, {
    /**
     * Numeric label ID.
     */
    labelId: number;
    /**
     * GraphQL node ID of the label.
     */
    nodeId: string;
    /**
     * The label name.
     */
    name: string;
    /**
     * The label color (6-character hex code without the leading `#`).
     */
    color: string;
    /**
     * Label description.
     */
    description: string | null;
    /**
     * URL to view the label in a browser.
     */
    url: string;
    /**
     * Whether this is a default label (created by GitHub).
     */
    default: boolean;
}, never, GitHub.Providers, LabelLookup> {
}
/**
 * Props for {@link Label.lookup}: find a label this stack
 * doesn't manage by its repository and name.
 */
export interface LabelLookup {
    /** Repository owner (user or organization). */
    owner: string;
    /** Repository name. */
    repository: string;
    /** Label name. */
    name: string;
    /**
     * GitHub Enterprise Server URL.
     * @default `https://github.com`
     */
    baseUrl?: string;
}
/**
 * A GitHub repository label.
 *
 * `Label` manages repository labels for categorizing issues and pull requests.
 * Labels are created on first deploy and updated in place on subsequent
 * deploys when properties change.
 *
 * Authentication is resolved via the GitHub `Credentials` service supplied by
 * `GitHub.providers()` (env, stored PAT, `gh` CLI, or OAuth). The token needs
 * `repo` scope for private repositories or `public_repo` for public ones.
 * ### Creating Labels
 * **Example:** Basic Label
 * ```typescript
 * const bug = yield* GitHub.Label("bug", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "bug",
 *   color: "d73a4a",
 *   description: "Something isn't working",
 * });
 * ```
 *
 * **Example:** Multiple Labels
 * ```typescript
 * yield* GitHub.Label("feature", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "feature",
 *   color: "a2eeef",
 *   description: "New feature or request",
 * });
 *
 * yield* GitHub.Label("documentation", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "documentation",
 *   color: "0075ca",
 *   description: "Improvements or additions to documentation",
 * });
 * ```
 *
 * ### Updating Labels
 * Deploy with the same logical ID and different properties to update the
 * existing label in place.
 *
 * **Example:** Update Color and Description
 * ```typescript
 * yield* GitHub.Label("priority-high", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "priority: high",
 *   color: "ff0000",
 *   description: "Updated: Critical issues requiring immediate attention",
 * });
 * ```
 *
 * ### Label Color Codes
 * GitHub uses 6-character hex codes without the `#` prefix. Common colors:
 * - `d73a4a` - Red (bugs)
 * - `0075ca` - Blue (documentation)
 * - `a2eeef` - Light blue (features)
 * - `7057ff` - Purple (good first issue)
 * - `008672` - Green (improvement)
 * - `e4e669` - Yellow (question)
 *
 * **Example:** Standard Label Set
 * ```typescript
 * const labels = [
 *   { name: "bug", color: "d73a4a", description: "Something isn't working" },
 *   { name: "enhancement", color: "a2eeef", description: "New feature" },
 *   { name: "documentation", color: "0075ca", description: "Documentation" },
 * ];
 *
 * for (const { name, color, description } of labels) {
 *   yield* GitHub.Label(name, {
 *     owner: "my-org",
 *     repository: "my-repo",
 *     name,
 *     color,
 *     description,
 *   });
 * }
 * ```
 *
 * ### Replacing on Name Change
 * Changing the name creates a new label and deletes the old one.
 *
 * **Example:** Replace by Changing Name
 * ```typescript
 * // First deploy creates "wip"
 * const label = yield* GitHub.Label("work", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "wip",
 *   color: "fbca04",
 * });
 *
 * // Later deploy with same logical ID but different name replaces it
 * const label = yield* GitHub.Label("work", {
 *   owner: "my-org",
 *   repository: "my-repo",
 *   name: "in-progress",
 *   color: "fbca04",
 * });
 * ```
 *
 * ### Wiring with Other Resources
 * **Example:** Create Repository with Labels
 * ```typescript
 * const repo = yield* GitHub.Repository("api", {
 *   owner: "my-org",
 *   name: "api",
 *   autoInit: true,
 * });
 *
 * yield* GitHub.Label("bug", {
 *   owner: repo.owner!,
 *   repository: repo.name!,
 *   name: "bug",
 *   color: "d73a4a",
 * });
 * ```
 *
 * ### Looking up an existing label
 * `Label.lookup` references a label Alchemy doesn't manage (created on
 * GitHub or by another stack). It is read during plan/deploy, never created,
 * updated or deleted.
 *
 * **Example:** Reference an existing label
 * ```typescript
 * const bug = GitHub.Label.lookup({ owner: "alchemy-run", repository: "alchemy", name: "bug" });
 * ```
 *
 * @resource
 * @product Issue
 */
export declare const Label: import("alchemy/Resource").ResourceClass<Label>;
export declare const LabelProvider: () => import("effect/Layer").Layer<Provider.Provider<Label>, never, Issues.GithubOpContext>;
//# sourceMappingURL=Label.d.ts.map