import * as API from "@distilled.cloud/core/api";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
export type MetricName = string;
export type SageMakerResourceArn = string;
export type MetricStatistic = "Min" | "Max" | "Avg" | "Count" | "StdDev" | "Last" | (string & {});
export type Period = "OneMinute" | "FiveMinute" | "OneHour" | "IterationNumber" | (string & {});
export type XAxisType = "IterationNumber" | "Timestamp" | (string & {});
export interface MetricQuery {
    MetricName?: string | undefined;
    ResourceArn?: string | undefined;
    MetricStat?: MetricStatistic | undefined;
    Period?: Period | undefined;
    XAxisType?: XAxisType | undefined;
    Start?: number | undefined;
    End?: number | undefined;
}
export type MetricQueryList = MetricQuery[];
export interface BatchGetMetricsRequest {
    MetricQueries?: MetricQuery[] | undefined;
}
export type MetricQueryResultStatus = "Complete" | "Truncated" | "InternalError" | "ValidationError" | (string & {});
export type Message = string;
export type XAxisValues = number[];
export type MetricValues = number[];
export interface MetricQueryResult {
    Status?: MetricQueryResultStatus | undefined;
    Message?: string | undefined;
    XAxisValues?: number[] | undefined;
    MetricValues?: number[] | undefined;
}
export type MetricQueryResultList = MetricQueryResult[];
export interface BatchGetMetricsResponse {
    MetricQueryResults?: (MetricQueryResult & {
        Status: MetricQueryResultStatus;
        XAxisValues: XAxisValues;
        MetricValues: MetricValues;
    })[] | undefined;
}
export type ExperimentEntityName = string;
export type Step = number;
export interface RawMetricData {
    MetricName?: string | undefined;
    Timestamp?: Date | undefined;
    Step?: number | undefined;
    Value?: number | undefined;
}
export type RawMetricDataList = RawMetricData[];
export interface BatchPutMetricsRequest {
    TrialComponentName?: string | undefined;
    MetricData?: RawMetricData[] | undefined;
}
export type PutMetricsErrorCode = "METRIC_LIMIT_EXCEEDED" | "INTERNAL_ERROR" | "VALIDATION_ERROR" | "CONFLICT_ERROR" | (string & {});
export interface BatchPutMetricsError_ {
    Code?: PutMetricsErrorCode | undefined;
    MetricIndex?: number | undefined;
}
export type BatchPutMetricsErrorList = BatchPutMetricsError_[];
export interface BatchPutMetricsResponse {
    Errors?: BatchPutMetricsError_[] | undefined;
}
export type BatchGetMetricsError = CommonErrors;
/**
 * Used to retrieve training metrics from SageMaker.
 */
export declare const batchGetMetrics: API.OperationMethod<BatchGetMetricsRequest & RegionInput, BatchGetMetricsResponse, BatchGetMetricsError, Credentials | HttpClient.HttpClient>;
export type BatchPutMetricsError = CommonErrors;
/**
 * Used to ingest training metrics into SageMaker. These metrics can be visualized in SageMaker Studio.
 */
export declare const batchPutMetrics: API.OperationMethod<BatchPutMetricsRequest & RegionInput, BatchPutMetricsResponse, BatchPutMetricsError, Credentials | HttpClient.HttpClient>;
//# sourceMappingURL=sagemaker-metrics.d.ts.map