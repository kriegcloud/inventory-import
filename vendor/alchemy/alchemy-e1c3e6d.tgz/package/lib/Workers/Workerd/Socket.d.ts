import type * as cf from "@cloudflare/workers-types";
import * as Socket from "effect/socket/Socket";
/**
 * A workerd TCP socket as an Effect {@link Socket.Socket}: read batches with
 * `socket.reader`, write with `socket.writer`. `raw` is the
 * underlying workerd `Socket`, for APIs that take one (piping its
 * `readable`/`writable` into another socket keeps TCP half-closes intact).
 *
 * Both directions use it: the socket a Worker's `connect` handler receives,
 * and the socket an outbound `connect(address)` opens.
 */
export interface TcpSocket extends Socket.Socket {
    /** The underlying workerd `Socket`. */
    readonly raw: cf.Socket;
}
/**
 * Wrap a workerd `Socket` as a {@link TcpSocket}. The streams are acquired
 * once `opened` resolves, on the first read; an open failure surfaces as a
 * `SocketError` from `run`.
 */
export declare const fromWorkerdSocket: (raw: cf.Socket) => TcpSocket;
//# sourceMappingURL=Socket.d.ts.map