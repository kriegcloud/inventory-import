import * as API from "@distilled.cloud/core/api";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CacheReserveClearStatusRequest {
    /** Identifier. */
    zoneId: string;
}
export type CacheReserveClearStatusResultState = "In-progress" | "Completed";
export interface CacheReserveClearStatusResult {
    /** ID of the zone setting. */
    id?: unknown | null | undefined;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null | undefined;
    /** Last time this setting was modified. */
    modifiedOn?: string | null | undefined;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs?: string | null | undefined;
    /** The current state of the Cache Reserve Clear operation. */
    state?: CacheReserveClearStatusResultState | null | undefined;
}
export type CacheReserveClearStatusResponse = CacheReserveClearStatusResult;
export interface ClearCacheReserveClearRequest {
    /** Identifier. */
    zoneId: string;
}
export type ClearCacheReserveClearResultState = "In-progress" | "Completed";
export interface ClearCacheReserveClearResult {
    /** ID of the zone setting. */
    id?: unknown | null | undefined;
    /** The time that the latest Cache Reserve Clear operation completed. */
    endTs?: string | null | undefined;
    /** Last time this setting was modified. */
    modifiedOn?: string | null | undefined;
    /** The time that the latest Cache Reserve Clear operation started. */
    startTs?: string | null | undefined;
    /** The current state of the Cache Reserve Clear operation. */
    state?: ClearCacheReserveClearResultState | null | undefined;
}
export type ClearCacheReserveClearResponse = ClearCacheReserveClearResult;
export type CreateHealthCheckRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateHealthCheckRequestCheckRegionsList = Array<CreateHealthCheckRequestCheckRegionsItem | (string & {})>;
export type CreateHealthCheckRequestHttpConfigExpectedCodesList = Array<string>;
export type CreateHealthCheckRequestHttpConfigHeaderValueList = Array<string>;
export type CreateHealthCheckRequestHttpConfigHeaderMap = {
    [key: string]: CreateHealthCheckRequestHttpConfigHeaderValueList | undefined;
};
export type CreateHealthCheckRequestHttpConfigMethod = "GET" | "HEAD";
export interface CreateHealthCheckRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateHealthCheckRequestHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateHealthCheckRequestHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: CreateHealthCheckRequestHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type CreateHealthCheckRequestTcpConfigMethod = "connection_established";
export interface CreateHealthCheckRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateHealthCheckRequestTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface CreateHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateHealthCheckRequestCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateHealthCheckRequestHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateHealthCheckRequestTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export type CreateHealthCheckResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type CreateHealthCheckResultCheckRegionsList = Array<CreateHealthCheckResultCheckRegionsItem>;
export type CreateHealthCheckResultHttpConfigExpectedCodesList = Array<string>;
export type CreateHealthCheckResultHttpConfigHeaderValueList = Array<string>;
export type CreateHealthCheckResultHttpConfigHeaderMap = {
    [key: string]: CreateHealthCheckResultHttpConfigHeaderValueList | undefined;
};
export type CreateHealthCheckResultHttpConfigMethod = "GET" | "HEAD";
export interface CreateHealthCheckResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: CreateHealthCheckResultHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: CreateHealthCheckResultHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: CreateHealthCheckResultHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type CreateHealthCheckResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type CreateHealthCheckResultTcpConfigMethod = "connection_established";
export interface CreateHealthCheckResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: CreateHealthCheckResultTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
export interface CreateHealthCheckResult {
    /** Identifier. */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: CreateHealthCheckResultCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: CreateHealthCheckResultHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: CreateHealthCheckResultStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: CreateHealthCheckResultTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type CreateHealthCheckResponse = CreateHealthCheckResult;
export interface DeleteHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
}
export interface DeleteHealthCheckResult {
    /** Identifier. */
    id?: string | null | undefined;
}
export type DeleteHealthCheckResponse = DeleteHealthCheckResult;
export type EditHealthCheckRequestCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditHealthCheckRequestCheckRegionsList = Array<EditHealthCheckRequestCheckRegionsItem | (string & {})>;
export type EditHealthCheckRequestHttpConfigExpectedCodesList = Array<string>;
export type EditHealthCheckRequestHttpConfigHeaderValueList = Array<string>;
export type EditHealthCheckRequestHttpConfigHeaderMap = {
    [key: string]: EditHealthCheckRequestHttpConfigHeaderValueList | undefined;
};
export type EditHealthCheckRequestHttpConfigMethod = "GET" | "HEAD";
export interface EditHealthCheckRequestHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditHealthCheckRequestHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditHealthCheckRequestHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: EditHealthCheckRequestHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type EditHealthCheckRequestTcpConfigMethod = "connection_established";
export interface EditHealthCheckRequestTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditHealthCheckRequestTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface EditHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
    /** The hostname or IP address of the origin server to run health checks on. */
    address: string;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name: string;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditHealthCheckRequestCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditHealthCheckRequestHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditHealthCheckRequestTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export type EditHealthCheckResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type EditHealthCheckResultCheckRegionsList = Array<EditHealthCheckResultCheckRegionsItem>;
export type EditHealthCheckResultHttpConfigExpectedCodesList = Array<string>;
export type EditHealthCheckResultHttpConfigHeaderValueList = Array<string>;
export type EditHealthCheckResultHttpConfigHeaderMap = {
    [key: string]: EditHealthCheckResultHttpConfigHeaderValueList | undefined;
};
export type EditHealthCheckResultHttpConfigMethod = "GET" | "HEAD";
export interface EditHealthCheckResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: EditHealthCheckResultHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: EditHealthCheckResultHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: EditHealthCheckResultHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type EditHealthCheckResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type EditHealthCheckResultTcpConfigMethod = "connection_established";
export interface EditHealthCheckResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: EditHealthCheckResultTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
export interface EditHealthCheckResult {
    /** Identifier. */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: EditHealthCheckResultCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: EditHealthCheckResultHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: EditHealthCheckResultStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: EditHealthCheckResultTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type EditHealthCheckResponse = EditHealthCheckResult;
export interface GetRequest {
    /** Identifier. */
    zoneId: string;
}
export type GetResultCacheReserveValue = "on" | "off";
export interface GetResultCacheReserve {
    /** The id of the Cache Reserve setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** Specifies the enablement value of Cache Reserve. */
    value?: GetResultCacheReserveValue | null | undefined;
}
export type GetResultRegionalTieredCacheValue = "on" | "off";
export interface GetResultRegionalTieredCache {
    /** The id of the Regional Tiered Cache setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** Specifies the enablement value of Cache Reserve. */
    value?: GetResultRegionalTieredCacheValue | null | undefined;
}
export type GetResultSmartRoutingValue = "on" | "off";
export interface GetResultSmartRouting {
    /** The id of the Smart Routing setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** Specifies the enablement value of Argo Smart Routing. */
    value?: GetResultSmartRoutingValue | null | undefined;
}
export type GetResultSmartTieredCacheValue = "on" | "off";
export interface GetResultSmartTieredCache {
    /** The id of the Smart Tiered Cache setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** The last time the setting was modified. */
    modifiedOn?: string | null | undefined;
    /** Specifies the enablement value of Tiered Cache. */
    value?: GetResultSmartTieredCacheValue | null | undefined;
}
export interface GetResult {
    cacheReserve?: GetResultCacheReserve | null | undefined;
    /** The total number of health checks associated with the zone. */
    healthchecksCount?: number | null | undefined;
    regionalTieredCache?: GetResultRegionalTieredCache | null | undefined;
    smartRouting?: GetResultSmartRouting | null | undefined;
    smartTieredCache?: GetResultSmartTieredCache | null | undefined;
}
export type GetResponse = GetResult;
export interface GetHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
}
export type GetHealthCheckResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type GetHealthCheckResultCheckRegionsList = Array<GetHealthCheckResultCheckRegionsItem>;
export type GetHealthCheckResultHttpConfigExpectedCodesList = Array<string>;
export type GetHealthCheckResultHttpConfigHeaderValueList = Array<string>;
export type GetHealthCheckResultHttpConfigHeaderMap = {
    [key: string]: GetHealthCheckResultHttpConfigHeaderValueList | undefined;
};
export type GetHealthCheckResultHttpConfigMethod = "GET" | "HEAD";
export interface GetHealthCheckResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: GetHealthCheckResultHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: GetHealthCheckResultHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: GetHealthCheckResultHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type GetHealthCheckResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type GetHealthCheckResultTcpConfigMethod = "connection_established";
export interface GetHealthCheckResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: GetHealthCheckResultTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
export interface GetHealthCheckResult {
    /** Identifier. */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: GetHealthCheckResultCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: GetHealthCheckResultHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: GetHealthCheckResultStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: GetHealthCheckResultTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type GetHealthCheckResponse = GetHealthCheckResult;
export interface ListHealthChecksRequest {
    /** Identifier. */
    zoneId: string;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Maximum number of results per page. Must be a multiple of 5. */
    perPage?: number | undefined;
}
export type ListHealthChecksResponse = unknown;
export type UpdateRequestCacheReserveValue = "on" | "off";
export interface UpdateRequestCacheReserve {
    /** Specifies the enablement value of Cache Reserve. */
    value?: UpdateRequestCacheReserveValue | (string & {}) | undefined;
}
export type UpdateRequestRegionalTieredCacheValue = "on" | "off";
export interface UpdateRequestRegionalTieredCache {
    /** Specifies the enablement value of Regional Tiered Cache. */
    value?: UpdateRequestRegionalTieredCacheValue | (string & {}) | undefined;
}
export type UpdateRequestSmartRoutingValue = "on" | "off";
export interface UpdateRequestSmartRouting {
    /** Specifies the enablement value of Smart Routing. */
    value?: UpdateRequestSmartRoutingValue | (string & {}) | undefined;
}
export type UpdateRequestSmartTieredCacheValue = "on" | "off";
export interface UpdateRequestSmartTieredCache {
    /** Specifies the enablement value of Smart Tiered Cache. */
    value?: UpdateRequestSmartTieredCacheValue | (string & {}) | undefined;
}
export interface UpdateRequest {
    /** Identifier. */
    zoneId: string;
    cacheReserve?: UpdateRequestCacheReserve | undefined;
    regionalTieredCache?: UpdateRequestRegionalTieredCache | undefined;
    smartRouting?: UpdateRequestSmartRouting | undefined;
    smartTieredCache?: UpdateRequestSmartTieredCache | undefined;
}
export type UpdateResultCacheReserveValue = "on" | "off";
export interface UpdateResultCacheReserve {
    /** The id of the Cache Reserve setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** Specifies the enablement value of Cache Reserve. */
    value?: UpdateResultCacheReserveValue | null | undefined;
}
export type UpdateResultRegionalTieredCacheValue = "on" | "off";
export interface UpdateResultRegionalTieredCache {
    /** The id of the Regional Tiered Cache setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** Specifies the enablement value of Regional Tiered Cache. */
    value?: UpdateResultRegionalTieredCacheValue | null | undefined;
}
export type UpdateResultSmartRoutingValue = "on" | "off";
export interface UpdateResultSmartRouting {
    /** The id of the Smart Routing setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** Specifies the enablement value of Argo Smart Routing. */
    value?: UpdateResultSmartRoutingValue | null | undefined;
}
export type UpdateResultSmartTieredCacheValue = "on" | "off";
export interface UpdateResultSmartTieredCache {
    /** The id of the Smart Tiered Cache setting. */
    id?: string | null | undefined;
    /** Whether the setting is editable. */
    editable?: boolean | null | undefined;
    /** The last time the setting was modified. */
    modifiedOn?: string | null | undefined;
    /** Specifies the enablement value of Tiered Cache. */
    value?: UpdateResultSmartTieredCacheValue | null | undefined;
}
export interface UpdateResult {
    cacheReserve?: UpdateResultCacheReserve | null | undefined;
    regionalTieredCache?: UpdateResultRegionalTieredCache | null | undefined;
    smartRouting?: UpdateResultSmartRouting | null | undefined;
    smartTieredCache?: UpdateResultSmartTieredCache | null | undefined;
}
export type UpdateResponse = UpdateResult;
export interface UpdateHealthCheckRequestErrorsItemSource {
    pointer?: string | undefined;
}
export interface UpdateHealthCheckRequestErrorsItem {
    code: number;
    message: string;
    documentationUrl?: string | undefined;
    source?: UpdateHealthCheckRequestErrorsItemSource | undefined;
}
export type UpdateHealthCheckRequestErrorsList = Array<UpdateHealthCheckRequestErrorsItem>;
export type UpdateHealthCheckRequestMessagesItemSource = UpdateHealthCheckRequestErrorsItemSource;
export type UpdateHealthCheckRequestMessagesItem = UpdateHealthCheckRequestErrorsItem;
export type UpdateHealthCheckRequestMessagesList = Array<UpdateHealthCheckRequestErrorsItem>;
export type UpdateHealthCheckRequestResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateHealthCheckRequestResultCheckRegionsList = Array<UpdateHealthCheckRequestResultCheckRegionsItem | (string & {})>;
export type UpdateHealthCheckRequestResultHttpConfigExpectedCodesList = Array<string>;
export type UpdateHealthCheckRequestResultHttpConfigHeaderValueList = Array<string>;
export type UpdateHealthCheckRequestResultHttpConfigHeaderMap = {
    [key: string]: UpdateHealthCheckRequestResultHttpConfigHeaderValueList | undefined;
};
export type UpdateHealthCheckRequestResultHttpConfigMethod = "GET" | "HEAD";
export interface UpdateHealthCheckRequestResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateHealthCheckRequestResultHttpConfigExpectedCodesList | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateHealthCheckRequestResultHttpConfigHeaderMap | undefined;
    /** The HTTP method to use for the health check. */
    method?: UpdateHealthCheckRequestResultHttpConfigMethod | (string & {}) | undefined;
    /** The endpoint path to health check against. */
    path?: string | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | undefined;
}
export type UpdateHealthCheckRequestResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type UpdateHealthCheckRequestResultTcpConfigMethod = "connection_established";
export interface UpdateHealthCheckRequestResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateHealthCheckRequestResultTcpConfigMethod | (string & {}) | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | undefined;
}
export interface UpdateHealthCheckRequestResult {
    /** Identifier. */
    id?: string | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateHealthCheckRequestResultCheckRegionsList | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | undefined;
    createdOn?: string | undefined;
    /** A human-readable description of the health check. */
    description?: string | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateHealthCheckRequestResultHttpConfig | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | undefined;
    modifiedOn?: string | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | undefined;
    /** The current status of the origin server according to the health check. */
    status?: UpdateHealthCheckRequestResultStatus | (string & {}) | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateHealthCheckRequestResultTcpConfig | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | undefined;
}
export interface UpdateHealthCheckRequest {
    /** Identifier. */
    zoneId: string;
    /** Identifier. */
    healthcheckId: string;
    errors: UpdateHealthCheckRequestErrorsList;
    messages: UpdateHealthCheckRequestMessagesList;
    result: UpdateHealthCheckRequestResult;
    /** Whether the API call was successful. */
    success: boolean;
}
export type UpdateHealthCheckResultCheckRegionsItem = "WNAM" | "ENAM" | "WEU" | "EEU" | "NSAM" | "SSAM" | "OC" | "ME" | "NAF" | "SAF" | "IN" | "SEAS" | "NEAS" | "ALL_REGIONS";
export type UpdateHealthCheckResultCheckRegionsList = Array<UpdateHealthCheckResultCheckRegionsItem>;
export type UpdateHealthCheckResultHttpConfigExpectedCodesList = Array<string>;
export type UpdateHealthCheckResultHttpConfigHeaderValueList = Array<string>;
export type UpdateHealthCheckResultHttpConfigHeaderMap = {
    [key: string]: UpdateHealthCheckResultHttpConfigHeaderValueList | undefined;
};
export type UpdateHealthCheckResultHttpConfigMethod = "GET" | "HEAD";
export interface UpdateHealthCheckResultHttpConfig {
    /** Do not validate the certificate when the health check uses HTTPS. */
    allowInsecure?: boolean | null | undefined;
    /** A case-insensitive sub-string to look for in the response body. If this string is not found, the origin will be marked as unhealthy. */
    expectedBody?: string | null | undefined;
    /** The expected HTTP response codes (e.g. "200") or code ranges (e.g. "2xx" for all codes starting with 2) of the health check. */
    expectedCodes?: UpdateHealthCheckResultHttpConfigExpectedCodesList | null | undefined;
    /** Follow redirects if the origin returns a 3xx status code. */
    followRedirects?: boolean | null | undefined;
    /** The HTTP request headers to send in the health check. It is recommended you set a Host header by default. The User-Agent header cannot be overridden. */
    header?: UpdateHealthCheckResultHttpConfigHeaderMap | null | undefined;
    /** The HTTP method to use for the health check. */
    method?: UpdateHealthCheckResultHttpConfigMethod | null | undefined;
    /** The endpoint path to health check against. */
    path?: string | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80 if type is HTTP or 443 if type is HTTPS. */
    port?: number | null | undefined;
}
export type UpdateHealthCheckResultStatus = "unknown" | "healthy" | "unhealthy" | "suspended";
export type UpdateHealthCheckResultTcpConfigMethod = "connection_established";
export interface UpdateHealthCheckResultTcpConfig {
    /** The TCP connection method to use for the health check. */
    method?: UpdateHealthCheckResultTcpConfigMethod | null | undefined;
    /** Port number to connect to for the health check. Defaults to 80. */
    port?: number | null | undefined;
}
export interface UpdateHealthCheckResult {
    /** Identifier. */
    id?: string | null | undefined;
    /** The hostname or IP address of the origin server to run health checks on. */
    address?: string | null | undefined;
    /** A list of regions from which to run health checks. Null means Cloudflare will pick a default region. */
    checkRegions?: UpdateHealthCheckResultCheckRegionsList | null | undefined;
    /** The number of consecutive fails required from a health check before changing the health to unhealthy. */
    consecutiveFails?: number | null | undefined;
    /** The number of consecutive successes required from a health check before changing the health to healthy. */
    consecutiveSuccesses?: number | null | undefined;
    createdOn?: string | null | undefined;
    /** A human-readable description of the health check. */
    description?: string | null | undefined;
    /** The current failure reason if status is unhealthy. */
    failureReason?: string | null | undefined;
    /** Parameters specific to an HTTP or HTTPS health check. */
    httpConfig?: UpdateHealthCheckResultHttpConfig | null | undefined;
    /** The interval between each health check. Shorter intervals may give quicker notifications if the origin status changes, but will increase load on the origin as we check from multiple locations. */
    interval?: number | null | undefined;
    modifiedOn?: string | null | undefined;
    /** A short name to identify the health check. Only alphanumeric characters, hyphens and underscores are allowed. */
    name?: string | null | undefined;
    /** The number of retries to attempt in case of a timeout before marking the origin as unhealthy. Retries are attempted immediately. */
    retries?: number | null | undefined;
    /** The current status of the origin server according to the health check. */
    status?: UpdateHealthCheckResultStatus | null | undefined;
    /** If suspended, no health checks are sent to the origin. */
    suspended?: boolean | null | undefined;
    /** Parameters specific to TCP health check. */
    tcpConfig?: UpdateHealthCheckResultTcpConfig | null | undefined;
    /** The timeout (in seconds) before marking the health check as failed. */
    timeout?: number | null | undefined;
    /** The protocol to use for the health check. Currently supported protocols are 'HTTP', 'HTTPS' and 'TCP'. */
    type?: string | null | undefined;
}
export type UpdateHealthCheckResponse = UpdateHealthCheckResult;
export type CacheReserveClearStatusError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const cacheReserveClearStatus: API.OperationMethod<CacheReserveClearStatusRequest, CacheReserveClearStatusResponse, CacheReserveClearStatusError, CloudflareOpContext>;
export type ClearCacheReserveClearError = CloudflareOpError;
/** You can use Cache Reserve Clear to clear your Cache Reserve, but you must first disable Cache Reserve. In most cases, this will be accomplished within 24 hours. You cannot re-enable Cache Reserve while this process is ongoing. Keep in mind that you cannot undo or cancel this operation. */
export declare const clearCacheReserveClear: API.OperationMethod<ClearCacheReserveClearRequest, ClearCacheReserveClearResponse, ClearCacheReserveClearError, CloudflareOpContext>;
export type CreateHealthCheckError = CloudflareOpError;
/** Create a new health check. */
export declare const createHealthCheck: API.OperationMethod<CreateHealthCheckRequest, CreateHealthCheckResponse, CreateHealthCheckError, CloudflareOpContext>;
export type DeleteHealthCheckError = CloudflareOpError;
/** Delete a health check. */
export declare const deleteHealthCheck: API.OperationMethod<DeleteHealthCheckRequest, DeleteHealthCheckResponse, DeleteHealthCheckError, CloudflareOpContext>;
export type EditHealthCheckError = CloudflareOpError;
/** Patch a configured health check. */
export declare const editHealthCheck: API.OperationMethod<EditHealthCheckRequest, EditHealthCheckResponse, EditHealthCheckError, CloudflareOpContext>;
export type GetError = CloudflareOpError;
/** Retrieve Smart Shield Settings. */
export declare const get: API.OperationMethod<GetRequest, GetResponse, GetError, CloudflareOpContext>;
export type GetHealthCheckError = CloudflareOpError;
/** Fetch a single configured health check. */
export declare const getHealthCheck: API.OperationMethod<GetHealthCheckRequest, GetHealthCheckResponse, GetHealthCheckError, CloudflareOpContext>;
export type ListHealthChecksError = CloudflareOpError;
/** List configured health checks. */
export declare const listHealthChecks: API.OperationMethod<ListHealthChecksRequest, ListHealthChecksResponse, ListHealthChecksError, CloudflareOpContext>;
export type UpdateError = CloudflareOpError;
/** Set Smart Shield Settings. */
export declare const update: API.OperationMethod<UpdateRequest, UpdateResponse, UpdateError, CloudflareOpContext>;
export type UpdateHealthCheckError = CloudflareOpError;
/** Update a configured health check. */
export declare const updateHealthCheck: API.OperationMethod<UpdateHealthCheckRequest, UpdateHealthCheckResponse, UpdateHealthCheckError, CloudflareOpContext>;
//# sourceMappingURL=smart_shield.d.ts.map