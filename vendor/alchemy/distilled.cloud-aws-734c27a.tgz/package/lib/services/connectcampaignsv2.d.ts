import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidCampaignStateException_base: S.TaggedErrorClass<"InvalidCampaignStateException", {
    readonly state: any;
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidCampaignStateException extends /*@__PURE__*/ InvalidCampaignStateException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly xAmzErrorType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type CampaignName = string;
export type InstanceId = string;
export type Capacity = number;
export type QueueId = string;
export type BandwidthAllocation = number;
export interface ProgressiveConfig {
    bandwidthAllocation: number;
}
export type TargetRate = number;
export type ConnectionStartPoint = string;
export type EvaluationWindow = string;
export interface AbandonmentRatePacingConfig {
    targetRate: number;
    connectionStartPoint: string;
    connectionThresholdSeconds: number;
    evaluationWindow: string;
}
export type PacingStrategy = {
    abandonmentRate: AbandonmentRatePacingConfig;
};
export type PacingStrategyList = PacingStrategy[];
export interface PredictiveConfig {
    bandwidthAllocation: number;
    pacingStrategies?: PacingStrategy[] | undefined;
}
export interface AgentlessConfig {
}
export type TimeoutDuration = number;
export interface TimeoutConfig {
    durationInSeconds: number;
}
export type AgentAction = string;
export type AgentActions = string[];
export interface PreviewConfig {
    bandwidthAllocation: number;
    timeoutConfig: TimeoutConfig;
    agentActions?: string[] | undefined;
}
export type TelephonyOutboundMode = {
    progressive: ProgressiveConfig;
    predictive?: undefined;
    agentless?: undefined;
    preview?: undefined;
} | {
    progressive?: undefined;
    predictive: PredictiveConfig;
    agentless?: undefined;
    preview?: undefined;
} | {
    progressive?: undefined;
    predictive?: undefined;
    agentless: AgentlessConfig;
    preview?: undefined;
} | {
    progressive?: undefined;
    predictive?: undefined;
    agentless?: undefined;
    preview: PreviewConfig;
};
export type ContactFlowId = string;
export type SourcePhoneNumber = string;
export interface AnswerMachineDetectionConfig {
    enableAnswerMachineDetection: boolean;
    awaitAnswerMachinePrompt?: boolean | undefined;
}
export type RingTimeout = number;
export interface TelephonyOutboundConfig {
    connectContactFlowId: string;
    connectSourcePhoneNumber?: string | undefined;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig | undefined;
    ringTimeout?: number | undefined;
}
export interface TelephonyChannelSubtypeConfig {
    capacity?: number | undefined;
    connectQueueId?: string | undefined;
    outboundMode: TelephonyOutboundMode;
    defaultOutboundConfig: TelephonyOutboundConfig;
}
export type SmsOutboundMode = {
    agentless: AgentlessConfig;
};
export type Arn = string;
export interface SmsOutboundConfig {
    connectSourcePhoneNumberArn: string;
    wisdomTemplateArn: string;
}
export interface SmsChannelSubtypeConfig {
    capacity?: number | undefined;
    outboundMode: SmsOutboundMode;
    defaultOutboundConfig: SmsOutboundConfig;
}
export type EmailOutboundMode = {
    agentless: AgentlessConfig;
};
export type EmailAddress = string | redacted.Redacted<string>;
export type EmailDisplayName = string | redacted.Redacted<string>;
export interface EmailOutboundConfig {
    connectSourceEmailAddress: string | redacted.Redacted<string>;
    sourceEmailAddressDisplayName?: string | redacted.Redacted<string> | undefined;
    wisdomTemplateArn: string;
}
export interface EmailChannelSubtypeConfig {
    capacity?: number | undefined;
    outboundMode: EmailOutboundMode;
    defaultOutboundConfig: EmailOutboundConfig;
}
export type WhatsAppOutboundMode = {
    agentless: AgentlessConfig;
};
export interface WhatsAppOutboundConfig {
    connectSourcePhoneNumberArn: string;
    wisdomTemplateArn: string;
}
export interface WhatsAppChannelSubtypeConfig {
    capacity?: number | undefined;
    outboundMode: WhatsAppOutboundMode;
    defaultOutboundConfig: WhatsAppOutboundConfig;
}
export interface ChannelSubtypeConfig {
    telephony?: TelephonyChannelSubtypeConfig | undefined;
    sms?: SmsChannelSubtypeConfig | undefined;
    email?: EmailChannelSubtypeConfig | undefined;
    whatsApp?: WhatsAppChannelSubtypeConfig | undefined;
}
export type ExternalCampaignType = string;
export interface EventTrigger {
    customerProfilesDomainArn?: string | undefined;
}
export type Source = {
    customerProfilesSegmentArn: string;
    eventTrigger?: undefined;
} | {
    customerProfilesSegmentArn?: undefined;
    eventTrigger: EventTrigger;
};
export type Iso8601Duration = string;
export interface Schedule {
    startTime: Date;
    endTime: Date;
    refreshFrequency?: string | undefined;
}
export interface EntryLimitsConfig {
    maxEntryCount: number;
    minEntryInterval: string;
}
export type TimeZone = string;
export type LocalTimeZoneDetectionType = string;
export type LocalTimeZoneDetection = string[];
export type LocalTimeZoneDetectionScope = string;
export interface LocalTimeZoneConfig {
    defaultTimeZone?: string | undefined;
    localTimeZoneDetection?: string[] | undefined;
    localTimeZoneDetectionScope?: string | undefined;
}
export type DayOfWeek = string;
export type Iso8601Time = string;
export interface TimeRange {
    startTime: string;
    endTime: string;
}
export type TimeRangeList = TimeRange[];
export type DailyHours = {
    [key: string]: TimeRange[] | undefined;
};
export type OpenHours = {
    dailyHours: {
        [key: string]: TimeRange[] | undefined;
    };
};
export type RestrictedPeriodName = string;
export type Iso8601Date = string;
export interface RestrictedPeriod {
    name?: string | undefined;
    startDate: string;
    endDate: string;
}
export type RestrictedPeriodList = RestrictedPeriod[];
export type RestrictedPeriods = {
    restrictedPeriodList: RestrictedPeriod[];
};
export interface TimeWindow {
    openHours: OpenHours;
    restrictedPeriods?: RestrictedPeriods | undefined;
}
export interface CommunicationTimeConfig {
    localTimeZoneConfig: LocalTimeZoneConfig;
    telephony?: TimeWindow | undefined;
    sms?: TimeWindow | undefined;
    email?: TimeWindow | undefined;
    whatsApp?: TimeWindow | undefined;
}
export type CommunicationLimitTimeUnit = string;
export interface CommunicationLimit {
    maxCountPerRecipient: number;
    frequency: number;
    unit: string;
}
export type CommunicationLimitList = CommunicationLimit[];
export type CommunicationLimits = {
    communicationLimitsList: CommunicationLimit[];
};
export type InstanceLimitsHandling = string;
export interface CommunicationLimitsConfig {
    allChannelSubtypes?: CommunicationLimits | undefined;
    instanceLimitsHandling?: string | undefined;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateCampaignRequest {
    name: string;
    connectInstanceId: string;
    channelSubtypeConfig?: ChannelSubtypeConfig | undefined;
    type?: string | undefined;
    source?: Source | undefined;
    connectCampaignFlowArn?: string | undefined;
    schedule?: Schedule | undefined;
    entryLimitsConfig?: EntryLimitsConfig | undefined;
    communicationTimeConfig?: CommunicationTimeConfig | undefined;
    communicationLimitsOverride?: CommunicationLimitsConfig | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CampaignId = string;
export type CampaignArn = string;
export interface CreateCampaignResponse {
    id?: string | undefined;
    arn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteCampaignRequest {
    id: string;
}
export interface DeleteCampaignResponse {
}
export type ChannelSubtype = string;
export interface DeleteCampaignChannelSubtypeConfigRequest {
    id: string;
    channelSubtype: string;
}
export interface DeleteCampaignChannelSubtypeConfigResponse {
}
export type CommunicationLimitsConfigType = string;
export interface DeleteCampaignCommunicationLimitsRequest {
    id: string;
    config: string;
}
export interface DeleteCampaignCommunicationLimitsResponse {
}
export type CommunicationTimeConfigType = string;
export interface DeleteCampaignCommunicationTimeRequest {
    id: string;
    config: string;
}
export interface DeleteCampaignCommunicationTimeResponse {
}
export interface DeleteCampaignEntryLimitsRequest {
    id: string;
}
export interface DeleteCampaignEntryLimitsResponse {
}
export type CampaignDeletionPolicy = string;
export interface DeleteConnectInstanceConfigRequest {
    connectInstanceId: string;
    campaignDeletionPolicy?: string | undefined;
}
export interface DeleteConnectInstanceConfigResponse {
}
export interface CustomerProfilesIntegrationIdentifier {
    domainArn: string;
}
export interface QConnectIntegrationIdentifier {
    knowledgeBaseArn: string;
}
export type LambdaArn = string;
export interface LambdaIntegrationIdentifier {
    functionArn: string;
}
export type IntegrationIdentifier = {
    customerProfiles: CustomerProfilesIntegrationIdentifier;
    qConnect?: undefined;
    lambda?: undefined;
} | {
    customerProfiles?: undefined;
    qConnect: QConnectIntegrationIdentifier;
    lambda?: undefined;
} | {
    customerProfiles?: undefined;
    qConnect?: undefined;
    lambda: LambdaIntegrationIdentifier;
};
export interface DeleteConnectInstanceIntegrationRequest {
    connectInstanceId: string;
    integrationIdentifier: IntegrationIdentifier;
}
export interface DeleteConnectInstanceIntegrationResponse {
}
export interface DeleteInstanceOnboardingJobRequest {
    connectInstanceId: string;
}
export interface DeleteInstanceOnboardingJobResponse {
}
export interface DescribeCampaignRequest {
    id: string;
}
export interface Campaign {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
    channelSubtypeConfig?: ChannelSubtypeConfig | undefined;
    type?: string | undefined;
    source?: Source | undefined;
    connectCampaignFlowArn?: string | undefined;
    schedule?: Schedule | undefined;
    entryLimitsConfig?: EntryLimitsConfig | undefined;
    communicationTimeConfig?: CommunicationTimeConfig | undefined;
    communicationLimitsOverride?: CommunicationLimitsConfig | undefined;
    lastModifiedTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeCampaignResponse {
    campaign?: Campaign | undefined;
}
export interface GetCampaignStateRequest {
    id: string;
}
export type CampaignState = string;
export interface GetCampaignStateResponse {
    state?: string | undefined;
}
export type CampaignIdList = string[];
export interface GetCampaignStateBatchRequest {
    campaignIds: string[];
}
export interface SuccessfulCampaignStateResponse {
    campaignId?: string | undefined;
    state?: string | undefined;
}
export type SuccessfulCampaignStateResponseList = SuccessfulCampaignStateResponse[];
export type GetCampaignStateBatchFailureCode = string;
export interface FailedCampaignStateResponse {
    campaignId?: string | undefined;
    failureCode?: string | undefined;
}
export type FailedCampaignStateResponseList = FailedCampaignStateResponse[];
export interface GetCampaignStateBatchResponse {
    successfulRequests?: SuccessfulCampaignStateResponse[] | undefined;
    failedRequests?: FailedCampaignStateResponse[] | undefined;
}
export interface GetConnectInstanceConfigRequest {
    connectInstanceId: string;
}
export type ServiceLinkedRoleArn = string;
export type Enabled = boolean;
export type EncryptionType = string;
export type EncryptionKey = string;
export interface EncryptionConfig {
    enabled: boolean;
    encryptionType?: string | undefined;
    keyArn?: string | undefined;
}
export interface InstanceConfig {
    connectInstanceId: string;
    serviceLinkedRoleArn: string;
    encryptionConfig: EncryptionConfig;
}
export interface GetConnectInstanceConfigResponse {
    connectInstanceConfig?: InstanceConfig | undefined;
}
export interface GetInstanceCommunicationLimitsRequest {
    connectInstanceId: string;
}
export interface InstanceCommunicationLimitsConfig {
    allChannelSubtypes?: CommunicationLimits | undefined;
}
export interface GetInstanceCommunicationLimitsResponse {
    communicationLimitsConfig?: InstanceCommunicationLimitsConfig | undefined;
}
export interface GetInstanceOnboardingJobStatusRequest {
    connectInstanceId: string;
}
export type InstanceOnboardingJobStatusCode = string;
export type InstanceOnboardingJobFailureCode = string;
export interface InstanceOnboardingJobStatus {
    connectInstanceId: string;
    status: string;
    failureCode?: string | undefined;
}
export interface GetInstanceOnboardingJobStatusResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export type InstanceIdFilterOperator = string;
export interface InstanceIdFilter {
    value: string;
    operator: string;
}
export interface CampaignFilters {
    instanceIdFilter?: InstanceIdFilter | undefined;
}
export interface ListCampaignsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    filters?: CampaignFilters | undefined;
}
export type ChannelSubtypeList = string[];
export interface CampaignSummary {
    id: string;
    arn: string;
    name: string;
    connectInstanceId: string;
    channelSubtypes: string[];
    type?: string | undefined;
    schedule?: Schedule | undefined;
    entryLimitsConfig?: EntryLimitsConfig | undefined;
    connectCampaignFlowArn?: string | undefined;
    lastModifiedTime?: Date | undefined;
}
export type CampaignSummaryList = CampaignSummary[];
export interface ListCampaignsResponse {
    nextToken?: string | undefined;
    campaignSummaryList?: CampaignSummary[] | undefined;
}
export interface ListConnectInstanceIntegrationsRequest {
    connectInstanceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type EventType = string;
export type ObjectTypeName = string;
export type ObjectTypeNamesMap = {
    [key: string]: string | undefined;
};
export interface CustomerProfilesIntegrationSummary {
    domainArn: string;
    objectTypeNames: {
        [key: string]: string | undefined;
    };
}
export interface QConnectIntegrationSummary {
    knowledgeBaseArn: string;
}
export interface LambdaIntegrationSummary {
    functionArn: string;
}
export type IntegrationSummary = {
    customerProfiles: CustomerProfilesIntegrationSummary;
    qConnect?: undefined;
    lambda?: undefined;
} | {
    customerProfiles?: undefined;
    qConnect: QConnectIntegrationSummary;
    lambda?: undefined;
} | {
    customerProfiles?: undefined;
    qConnect?: undefined;
    lambda: LambdaIntegrationSummary;
};
export type IntegrationSummaryList = IntegrationSummary[];
export interface ListConnectInstanceIntegrationsResponse {
    nextToken?: string | undefined;
    integrationSummaryList?: IntegrationSummary[] | undefined;
}
export interface ListTagsForResourceRequest {
    arn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PauseCampaignRequest {
    id: string;
}
export interface PauseCampaignResponse {
}
export interface CustomerProfilesIntegrationConfig {
    domainArn: string;
    objectTypeNames: {
        [key: string]: string | undefined;
    };
}
export interface QConnectIntegrationConfig {
    knowledgeBaseArn: string;
}
export interface LambdaIntegrationConfig {
    functionArn: string;
}
export type IntegrationConfig = {
    customerProfiles: CustomerProfilesIntegrationConfig;
    qConnect?: undefined;
    lambda?: undefined;
} | {
    customerProfiles?: undefined;
    qConnect: QConnectIntegrationConfig;
    lambda?: undefined;
} | {
    customerProfiles?: undefined;
    qConnect?: undefined;
    lambda: LambdaIntegrationConfig;
};
export interface PutConnectInstanceIntegrationRequest {
    connectInstanceId: string;
    integrationConfig: IntegrationConfig;
}
export interface PutConnectInstanceIntegrationResponse {
}
export interface PutInstanceCommunicationLimitsRequest {
    connectInstanceId: string;
    communicationLimitsConfig: InstanceCommunicationLimitsConfig;
}
export interface PutInstanceCommunicationLimitsResponse {
}
export type ClientToken = string;
export type DestinationPhoneNumber = string | redacted.Redacted<string>;
export type AttributeName = string;
export type AttributeValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export interface TelephonyChannelSubtypeParameters {
    destinationPhoneNumber: string | redacted.Redacted<string>;
    attributes: {
        [key: string]: string | undefined;
    };
    connectSourcePhoneNumber?: string | undefined;
    answerMachineDetectionConfig?: AnswerMachineDetectionConfig | undefined;
    ringTimeout?: number | undefined;
}
export interface SmsChannelSubtypeParameters {
    destinationPhoneNumber: string | redacted.Redacted<string>;
    connectSourcePhoneNumberArn?: string | undefined;
    templateArn?: string | undefined;
    templateParameters: {
        [key: string]: string | undefined;
    };
}
export interface EmailChannelSubtypeParameters {
    destinationEmailAddress: string | redacted.Redacted<string>;
    connectSourceEmailAddress?: string | redacted.Redacted<string> | undefined;
    templateArn?: string | undefined;
    templateParameters: {
        [key: string]: string | undefined;
    };
}
export interface WhatsAppChannelSubtypeParameters {
    destinationPhoneNumber: string | redacted.Redacted<string>;
    connectSourcePhoneNumberArn?: string | undefined;
    templateArn?: string | undefined;
    templateParameters: {
        [key: string]: string | undefined;
    };
}
export type ChannelSubtypeParameters = {
    telephony: TelephonyChannelSubtypeParameters;
    sms?: undefined;
    email?: undefined;
    whatsApp?: undefined;
} | {
    telephony?: undefined;
    sms: SmsChannelSubtypeParameters;
    email?: undefined;
    whatsApp?: undefined;
} | {
    telephony?: undefined;
    sms?: undefined;
    email: EmailChannelSubtypeParameters;
    whatsApp?: undefined;
} | {
    telephony?: undefined;
    sms?: undefined;
    email?: undefined;
    whatsApp: WhatsAppChannelSubtypeParameters;
};
export interface OutboundRequest {
    clientToken: string;
    expirationTime: Date;
    channelSubtypeParameters: ChannelSubtypeParameters;
}
export type OutboundRequestList = OutboundRequest[];
export interface PutOutboundRequestBatchRequest {
    id: string;
    outboundRequests: OutboundRequest[];
}
export type DialRequestId = string;
export interface SuccessfulRequest {
    clientToken?: string | undefined;
    id?: string | undefined;
}
export type SuccessfulRequestList = SuccessfulRequest[];
export type FailureCode = string;
export interface FailedRequest {
    clientToken?: string | undefined;
    id?: string | undefined;
    failureCode?: string | undefined;
}
export type FailedRequestList = FailedRequest[];
export interface PutOutboundRequestBatchResponse {
    successfulRequests?: SuccessfulRequest[] | undefined;
    failedRequests?: FailedRequest[] | undefined;
}
export type ProfileId = string;
export type SourceEvent = string;
export type SessionId = string;
export type BrowserId = string;
export interface WebNotificationContext {
    sessionId?: string | undefined;
    browserId?: string | undefined;
}
export interface ChannelContext {
    webNotificationContext?: WebNotificationContext | undefined;
}
export interface EventTriggerContext {
    sourceEvent?: string | undefined;
    channelContext?: ChannelContext | undefined;
}
export interface ProfileOutboundRequest {
    clientToken: string;
    profileId: string;
    expirationTime?: Date | undefined;
    eventTriggerContext?: EventTriggerContext | undefined;
}
export type ProfileOutboundRequestList = ProfileOutboundRequest[];
export interface PutProfileOutboundRequestBatchRequest {
    id: string;
    profileOutboundRequests: ProfileOutboundRequest[];
}
export type ProfileOutboundRequestId = string;
export interface SuccessfulProfileOutboundRequest {
    clientToken?: string | undefined;
    id?: string | undefined;
}
export type SuccessfulProfileOutboundRequestList = SuccessfulProfileOutboundRequest[];
export type ProfileOutboundRequestFailureCode = string;
export interface FailedProfileOutboundRequest {
    clientToken?: string | undefined;
    id?: string | undefined;
    failureCode?: string | undefined;
}
export type FailedProfileOutboundRequestList = FailedProfileOutboundRequest[];
export interface PutProfileOutboundRequestBatchResponse {
    successfulRequests?: SuccessfulProfileOutboundRequest[] | undefined;
    failedRequests?: FailedProfileOutboundRequest[] | undefined;
}
export interface ResumeCampaignRequest {
    id: string;
}
export interface ResumeCampaignResponse {
}
export interface StartCampaignRequest {
    id: string;
}
export interface StartCampaignResponse {
}
export interface StartInstanceOnboardingJobRequest {
    connectInstanceId: string;
    encryptionConfig: EncryptionConfig;
}
export interface StartInstanceOnboardingJobResponse {
    connectInstanceOnboardingJobStatus?: InstanceOnboardingJobStatus | undefined;
}
export interface StopCampaignRequest {
    id: string;
}
export interface StopCampaignResponse {
}
export interface TagResourceRequest {
    arn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    arn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateCampaignChannelSubtypeConfigRequest {
    id: string;
    channelSubtypeConfig: ChannelSubtypeConfig;
}
export interface UpdateCampaignChannelSubtypeConfigResponse {
}
export interface UpdateCampaignCommunicationLimitsRequest {
    id: string;
    communicationLimitsOverride: CommunicationLimitsConfig;
}
export interface UpdateCampaignCommunicationLimitsResponse {
}
export interface UpdateCampaignCommunicationTimeRequest {
    id: string;
    communicationTimeConfig: CommunicationTimeConfig;
}
export interface UpdateCampaignCommunicationTimeResponse {
}
export interface UpdateCampaignEntryLimitsRequest {
    id: string;
    entryLimitsConfig: EntryLimitsConfig;
}
export interface UpdateCampaignEntryLimitsResponse {
}
export interface UpdateCampaignFlowAssociationRequest {
    id: string;
    connectCampaignFlowArn: string;
}
export interface UpdateCampaignFlowAssociationResponse {
}
export interface UpdateCampaignNameRequest {
    id: string;
    name: string;
}
export interface UpdateCampaignNameResponse {
}
export interface UpdateCampaignScheduleRequest {
    id: string;
    schedule: Schedule;
}
export interface UpdateCampaignScheduleResponse {
}
export interface UpdateCampaignSourceRequest {
    id: string;
    source: Source;
}
export interface UpdateCampaignSourceResponse {
}
export type XAmazonErrorType = string;
export type CreateCampaignError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a campaign for the specified Amazon Connect account. This API is idempotent.
 */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest & RegionInput, CreateCampaignResponse, CreateCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes a campaign from the specified Amazon Connect account.
 */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest & RegionInput, DeleteCampaignResponse, DeleteCampaignError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignChannelSubtypeConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the channel subtype config of a campaign. This API is idempotent.
 */
export declare const deleteCampaignChannelSubtypeConfig: API.OperationMethod<DeleteCampaignChannelSubtypeConfigRequest & RegionInput, DeleteCampaignChannelSubtypeConfigResponse, DeleteCampaignChannelSubtypeConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignCommunicationLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the communication limits config for a campaign. This API is idempotent.
 */
export declare const deleteCampaignCommunicationLimits: API.OperationMethod<DeleteCampaignCommunicationLimitsRequest & RegionInput, DeleteCampaignCommunicationLimitsResponse, DeleteCampaignCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignCommunicationTimeError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the communication time config for a campaign. This API is idempotent.
 */
export declare const deleteCampaignCommunicationTime: API.OperationMethod<DeleteCampaignCommunicationTimeRequest & RegionInput, DeleteCampaignCommunicationTimeResponse, DeleteCampaignCommunicationTimeError, Credentials | HttpClient.HttpClient>;
export type DeleteCampaignEntryLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the entry limits config for a campaign. This API is idempotent.
 */
export declare const deleteCampaignEntryLimits: API.OperationMethod<DeleteCampaignEntryLimitsRequest & RegionInput, DeleteCampaignEntryLimitsResponse, DeleteCampaignEntryLimitsError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectInstanceConfigError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a connect instance config from the specified AWS account.
 */
export declare const deleteConnectInstanceConfig: API.OperationMethod<DeleteConnectInstanceConfigRequest & RegionInput, DeleteConnectInstanceConfigResponse, DeleteConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectInstanceIntegrationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete the integration for the specified Amazon Connect instance.
 */
export declare const deleteConnectInstanceIntegration: API.OperationMethod<DeleteConnectInstanceIntegrationRequest & RegionInput, DeleteConnectInstanceIntegrationResponse, DeleteConnectInstanceIntegrationError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceOnboardingJobError = AccessDeniedException | InternalServerException | InvalidStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Delete the Connect Campaigns onboarding job for the specified Amazon Connect instance.
 */
export declare const deleteInstanceOnboardingJob: API.OperationMethod<DeleteInstanceOnboardingJobRequest & RegionInput, DeleteInstanceOnboardingJobResponse, DeleteInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type DescribeCampaignError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the specific campaign.
 */
export declare const describeCampaign: API.OperationMethod<DescribeCampaignRequest & RegionInput, DescribeCampaignResponse, DescribeCampaignError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of a campaign for the specified Amazon Connect account.
 */
export declare const getCampaignState: API.OperationMethod<GetCampaignStateRequest & RegionInput, GetCampaignStateResponse, GetCampaignStateError, Credentials | HttpClient.HttpClient>;
export type GetCampaignStateBatchError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get state of campaigns for the specified Amazon Connect account.
 */
export declare const getCampaignStateBatch: API.OperationMethod<GetCampaignStateBatchRequest & RegionInput, GetCampaignStateBatchResponse, GetCampaignStateBatchError, Credentials | HttpClient.HttpClient>;
export type GetConnectInstanceConfigError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific Connect instance config.
 */
export declare const getConnectInstanceConfig: API.OperationMethod<GetConnectInstanceConfigRequest & RegionInput, GetConnectInstanceConfigResponse, GetConnectInstanceConfigError, Credentials | HttpClient.HttpClient>;
export type GetInstanceCommunicationLimitsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the instance communication limits.
 */
export declare const getInstanceCommunicationLimits: API.OperationMethod<GetInstanceCommunicationLimitsRequest & RegionInput, GetInstanceCommunicationLimitsResponse, GetInstanceCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type GetInstanceOnboardingJobStatusError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Get the specific instance onboarding job status.
 */
export declare const getInstanceOnboardingJobStatus: API.OperationMethod<GetInstanceOnboardingJobStatusRequest & RegionInput, GetInstanceOnboardingJobStatusResponse, GetInstanceOnboardingJobStatusError, Credentials | HttpClient.HttpClient>;
export type ListCampaignsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Provides summary information about the campaigns under the specified Amazon Connect account.
 */
export declare const listCampaigns: API.PaginatedOperationMethod<ListCampaignsRequest & RegionInput, ListCampaignsResponse, ListCampaignsError, Credentials | HttpClient.HttpClient, CampaignSummary>;
export type ListConnectInstanceIntegrationsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Provides summary information about the integration under the specified Connect instance.
 */
export declare const listConnectInstanceIntegrations: API.PaginatedOperationMethod<ListConnectInstanceIntegrationsRequest & RegionInput, ListConnectInstanceIntegrationsResponse, ListConnectInstanceIntegrationsError, Credentials | HttpClient.HttpClient, IntegrationSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PauseCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Pauses a campaign for the specified Amazon Connect account.
 */
export declare const pauseCampaign: API.OperationMethod<PauseCampaignRequest & RegionInput, PauseCampaignResponse, PauseCampaignError, Credentials | HttpClient.HttpClient>;
export type PutConnectInstanceIntegrationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Put or update the integration for the specified Amazon Connect instance.
 */
export declare const putConnectInstanceIntegration: API.OperationMethod<PutConnectInstanceIntegrationRequest & RegionInput, PutConnectInstanceIntegrationResponse, PutConnectInstanceIntegrationError, Credentials | HttpClient.HttpClient>;
export type PutInstanceCommunicationLimitsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Put the instance communication limits. This API is idempotent.
 */
export declare const putInstanceCommunicationLimits: API.OperationMethod<PutInstanceCommunicationLimitsRequest & RegionInput, PutInstanceCommunicationLimitsResponse, PutInstanceCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type PutOutboundRequestBatchError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates outbound requests for the specified campaign Amazon Connect account. This API is idempotent.
 */
export declare const putOutboundRequestBatch: API.OperationMethod<PutOutboundRequestBatchRequest & RegionInput, PutOutboundRequestBatchResponse, PutOutboundRequestBatchError, Credentials | HttpClient.HttpClient>;
export type PutProfileOutboundRequestBatchError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Takes in a list of profile outbound requests to be placed as part of an outbound campaign. This API is idempotent.
 */
export declare const putProfileOutboundRequestBatch: API.OperationMethod<PutProfileOutboundRequestBatchRequest & RegionInput, PutProfileOutboundRequestBatchResponse, PutProfileOutboundRequestBatchError, Credentials | HttpClient.HttpClient>;
export type ResumeCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const resumeCampaign: API.OperationMethod<ResumeCampaignRequest & RegionInput, ResumeCampaignResponse, ResumeCampaignError, Credentials | HttpClient.HttpClient>;
export type StartCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a campaign for the specified Amazon Connect account.
 */
export declare const startCampaign: API.OperationMethod<StartCampaignRequest & RegionInput, StartCampaignResponse, StartCampaignError, Credentials | HttpClient.HttpClient>;
export type StartInstanceOnboardingJobError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Onboard the specific Amazon Connect instance to Connect Campaigns.
 */
export declare const startInstanceOnboardingJob: API.OperationMethod<StartInstanceOnboardingJobRequest & RegionInput, StartInstanceOnboardingJobResponse, StartInstanceOnboardingJobError, Credentials | HttpClient.HttpClient>;
export type StopCampaignError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a campaign for the specified Amazon Connect account.
 */
export declare const stopCampaign: API.OperationMethod<StopCampaignRequest & RegionInput, StopCampaignResponse, StopCampaignError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Tag a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Untag a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignChannelSubtypeConfigError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the channel subtype config of a campaign. This API is idempotent.
 */
export declare const updateCampaignChannelSubtypeConfig: API.OperationMethod<UpdateCampaignChannelSubtypeConfigRequest & RegionInput, UpdateCampaignChannelSubtypeConfigResponse, UpdateCampaignChannelSubtypeConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignCommunicationLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the communication limits config for a campaign. This API is idempotent.
 */
export declare const updateCampaignCommunicationLimits: API.OperationMethod<UpdateCampaignCommunicationLimitsRequest & RegionInput, UpdateCampaignCommunicationLimitsResponse, UpdateCampaignCommunicationLimitsError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignCommunicationTimeError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the communication time config for a campaign. This API is idempotent.
 */
export declare const updateCampaignCommunicationTime: API.OperationMethod<UpdateCampaignCommunicationTimeRequest & RegionInput, UpdateCampaignCommunicationTimeResponse, UpdateCampaignCommunicationTimeError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignEntryLimitsError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the entry limits config for a campaign. This API is idempotent.
 */
export declare const updateCampaignEntryLimits: API.OperationMethod<UpdateCampaignEntryLimitsRequest & RegionInput, UpdateCampaignEntryLimitsResponse, UpdateCampaignEntryLimitsError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignFlowAssociationError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the campaign flow associated with a campaign. This API is idempotent.
 */
export declare const updateCampaignFlowAssociation: API.OperationMethod<UpdateCampaignFlowAssociationRequest & RegionInput, UpdateCampaignFlowAssociationResponse, UpdateCampaignFlowAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignNameError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the name of a campaign. This API is idempotent.
 */
export declare const updateCampaignName: API.OperationMethod<UpdateCampaignNameRequest & RegionInput, UpdateCampaignNameResponse, UpdateCampaignNameError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignScheduleError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the schedule for a campaign. This API is idempotent.
 */
export declare const updateCampaignSchedule: API.OperationMethod<UpdateCampaignScheduleRequest & RegionInput, UpdateCampaignScheduleResponse, UpdateCampaignScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateCampaignSourceError = AccessDeniedException | ConflictException | InternalServerException | InvalidCampaignStateException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the campaign source with a campaign. This API is idempotent.
 */
export declare const updateCampaignSource: API.OperationMethod<UpdateCampaignSourceRequest & RegionInput, UpdateCampaignSourceResponse, UpdateCampaignSourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=connectcampaignsv2.d.ts.map