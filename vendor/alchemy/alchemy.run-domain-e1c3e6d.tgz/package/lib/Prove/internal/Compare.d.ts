import type { Term } from "./Smt.ts";
import type { V } from "./Value.ts";
/** A number as a solver term, or `undefined` when the value is not a number. */
export declare const numeric: (v: V) => Term | undefined;
/** Two numbers in one sort: an integer next to a real becomes a real. */
export declare const promote: (a: Term, b: Term) => readonly [Term, Term];
/** What is known of a condition: whether it holds, the formula for it, or nothing. */
export type Known = boolean | string | undefined;
/** `true`/`false` when known, else the formula for "this value is truthy". */
export declare const truth: (v: V) => Known;
export declare const fromTruth: (t: boolean | string) => V;
/** A string as a solver term, or `undefined` when the value is not a string. */
export declare const textual: (v: V) => Term | undefined;
export declare const isQuotient: (v: V) => boolean;
/** `a === b`: known, a formula, or `undefined` when the prover cannot tell. */
export declare const same: (a: V, b: V) => Known;
/** Every part holds. One that does not settles it, whatever is unknown of the others. */
export declare const all: (parts: ReadonlyArray<Known>) => Known;
/** Some part holds. One that does settles it, whatever is unknown of the others. */
export declare const any: (parts: ReadonlyArray<Known>) => Known;
export declare const negate: (known: Known) => Known;
/**
 * `Equal.equals(a, b)`: the library's equality, which compares objects,
 * arrays and its own data types by what they hold. Known, a formula, or
 * `undefined` when the prover cannot tell.
 */
export declare const equals: (a: V, b: V, force?: (list: V) => V) => Known;
//# sourceMappingURL=Compare.d.ts.map