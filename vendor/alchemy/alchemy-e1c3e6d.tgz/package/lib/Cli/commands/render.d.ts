import * as Effect from "effect/Effect";
import { Interaction } from "../../Interaction.ts";
import * as Report from "../../Report.ts";
export declare const renderPlanning: (options: {
    operation: string;
    stage: string;
    computingLabel?: string;
    readyLabel?: string;
}) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R | Report.Cli | Interaction>;
//# sourceMappingURL=render.d.ts.map