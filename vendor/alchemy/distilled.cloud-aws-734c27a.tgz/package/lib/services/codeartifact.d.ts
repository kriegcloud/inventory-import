import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DomainName = string;
export type AccountId = string;
export type RepositoryName = string;
export type ExternalConnectionName = string;
export interface AssociateExternalConnectionRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    externalConnection: string;
}
export type Arn = string;
export type Description = string;
export interface UpstreamRepositoryInfo {
    repositoryName?: string | undefined;
}
export type UpstreamRepositoryInfoList = UpstreamRepositoryInfo[];
export type PackageFormat = "npm" | "pypi" | "maven" | "nuget" | "generic" | "ruby" | "swift" | "cargo" | (string & {});
export type ExternalConnectionStatus = "Available" | (string & {});
export interface RepositoryExternalConnectionInfo {
    externalConnectionName?: string | undefined;
    packageFormat?: PackageFormat | undefined;
    status?: ExternalConnectionStatus | undefined;
}
export type RepositoryExternalConnectionInfoList = RepositoryExternalConnectionInfo[];
export interface RepositoryDescription {
    name?: string | undefined;
    administratorAccount?: string | undefined;
    domainName?: string | undefined;
    domainOwner?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    upstreams?: UpstreamRepositoryInfo[] | undefined;
    externalConnections?: RepositoryExternalConnectionInfo[] | undefined;
    createdTime?: Date | undefined;
}
export interface AssociateExternalConnectionResult {
    repository?: RepositoryDescription | undefined;
}
export type PackageNamespace = string;
export type PackageName = string;
export type PackageVersion = string;
export type PackageVersionList = string[];
export type PackageVersionRevision = string;
export type PackageVersionRevisionMap = {
    [key: string]: string | undefined;
};
export interface CopyPackageVersionsRequest {
    domain: string;
    domainOwner?: string | undefined;
    sourceRepository: string;
    destinationRepository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    versions?: string[] | undefined;
    versionRevisions?: {
        [key: string]: string | undefined;
    } | undefined;
    allowOverwrite?: boolean | undefined;
    includeFromUpstream?: boolean | undefined;
}
export type PackageVersionStatus = "Published" | "Unfinished" | "Unlisted" | "Archived" | "Disposed" | "Deleted" | (string & {});
export interface SuccessfulPackageVersionInfo {
    revision?: string | undefined;
    status?: PackageVersionStatus | undefined;
}
export type SuccessfulPackageVersionInfoMap = {
    [key: string]: SuccessfulPackageVersionInfo | undefined;
};
export type PackageVersionErrorCode = "ALREADY_EXISTS" | "MISMATCHED_REVISION" | "MISMATCHED_STATUS" | "NOT_ALLOWED" | "NOT_FOUND" | "SKIPPED" | (string & {});
export type ErrorMessage = string;
export interface PackageVersionError {
    errorCode?: PackageVersionErrorCode | undefined;
    errorMessage?: string | undefined;
}
export type PackageVersionErrorMap = {
    [key: string]: PackageVersionError | undefined;
};
export interface CopyPackageVersionsResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    } | undefined;
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    } | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateDomainRequest {
    domain: string;
    encryptionKey?: string | undefined;
    tags?: Tag[] | undefined;
}
export type DomainStatus = "Active" | "Deleted" | (string & {});
export interface DomainDescription {
    name?: string | undefined;
    owner?: string | undefined;
    arn?: string | undefined;
    status?: DomainStatus | undefined;
    createdTime?: Date | undefined;
    encryptionKey?: string | undefined;
    repositoryCount?: number | undefined;
    assetSizeBytes?: number | undefined;
    s3BucketArn?: string | undefined;
}
export interface CreateDomainResult {
    domain?: DomainDescription | undefined;
}
export type PackageGroupPattern = string;
export type PackageGroupContactInfo = string;
export interface CreatePackageGroupRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
    contactInfo?: string | undefined;
    description?: string | undefined;
    tags?: Tag[] | undefined;
}
export type PackageGroupOriginRestrictionType = "EXTERNAL_UPSTREAM" | "INTERNAL_UPSTREAM" | "PUBLISH" | (string & {});
export type PackageGroupOriginRestrictionMode = "ALLOW" | "ALLOW_SPECIFIC_REPOSITORIES" | "BLOCK" | "INHERIT" | (string & {});
export interface PackageGroupReference {
    arn?: string | undefined;
    pattern?: string | undefined;
}
export interface PackageGroupOriginRestriction {
    mode?: PackageGroupOriginRestrictionMode | undefined;
    effectiveMode?: PackageGroupOriginRestrictionMode | undefined;
    inheritedFrom?: PackageGroupReference | undefined;
    repositoriesCount?: number | undefined;
}
export type PackageGroupOriginRestrictions = {
    [key in PackageGroupOriginRestrictionType]?: PackageGroupOriginRestriction | undefined;
};
export interface PackageGroupOriginConfiguration {
    restrictions?: {
        [key: string]: PackageGroupOriginRestriction | undefined;
    } | undefined;
}
export interface PackageGroupDescription {
    arn?: string | undefined;
    pattern?: string | undefined;
    domainName?: string | undefined;
    domainOwner?: string | undefined;
    createdTime?: Date | undefined;
    contactInfo?: string | undefined;
    description?: string | undefined;
    originConfiguration?: PackageGroupOriginConfiguration | undefined;
    parent?: PackageGroupReference | undefined;
}
export interface CreatePackageGroupResult {
    packageGroup?: PackageGroupDescription | undefined;
}
export interface UpstreamRepository {
    repositoryName: string;
}
export type UpstreamRepositoryList = UpstreamRepository[];
export interface CreateRepositoryRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    description?: string | undefined;
    upstreams?: UpstreamRepository[] | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateRepositoryResult {
    repository?: RepositoryDescription | undefined;
}
export interface DeleteDomainRequest {
    domain: string;
    domainOwner?: string | undefined;
}
export interface DeleteDomainResult {
    domain?: DomainDescription | undefined;
}
export type PolicyRevision = string;
export interface DeleteDomainPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string | undefined;
    policyRevision?: string | undefined;
}
export type PolicyDocument = string;
export interface ResourcePolicy {
    resourceArn?: string | undefined;
    revision?: string | undefined;
    document?: string | undefined;
}
export interface DeleteDomainPermissionsPolicyResult {
    policy?: ResourcePolicy | undefined;
}
export interface DeletePackageRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
}
export type AllowPublish = "ALLOW" | "BLOCK" | (string & {});
export type AllowUpstream = "ALLOW" | "BLOCK" | (string & {});
export interface PackageOriginRestrictions {
    publish: AllowPublish;
    upstream: AllowUpstream;
}
export interface PackageOriginConfiguration {
    restrictions?: PackageOriginRestrictions | undefined;
}
export interface PackageSummary {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    originConfiguration?: PackageOriginConfiguration | undefined;
}
export interface DeletePackageResult {
    deletedPackage?: PackageSummary | undefined;
}
export interface DeletePackageGroupRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
}
export interface DeletePackageGroupResult {
    packageGroup?: PackageGroupDescription | undefined;
}
export interface DeletePackageVersionsRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    versions: string[];
    expectedStatus?: PackageVersionStatus | undefined;
}
export interface DeletePackageVersionsResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    } | undefined;
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    } | undefined;
}
export interface DeleteRepositoryRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
}
export interface DeleteRepositoryResult {
    repository?: RepositoryDescription | undefined;
}
export interface DeleteRepositoryPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    policyRevision?: string | undefined;
}
export interface DeleteRepositoryPermissionsPolicyResult {
    policy?: ResourcePolicy | undefined;
}
export interface DescribeDomainRequest {
    domain: string;
    domainOwner?: string | undefined;
}
export interface DescribeDomainResult {
    domain?: DomainDescription | undefined;
}
export interface DescribePackageRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
}
export interface PackageDescription {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    name?: string | undefined;
    originConfiguration?: PackageOriginConfiguration | undefined;
}
export interface DescribePackageResult {
    package: PackageDescription;
}
export interface DescribePackageGroupRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
}
export interface DescribePackageGroupResult {
    packageGroup?: PackageGroupDescription | undefined;
}
export interface DescribePackageVersionRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    packageVersion: string;
}
export type String255 = string;
export interface LicenseInfo {
    name?: string | undefined;
    url?: string | undefined;
}
export type LicenseInfoList = LicenseInfo[];
export interface DomainEntryPoint {
    repositoryName?: string | undefined;
    externalConnectionName?: string | undefined;
}
export type PackageVersionOriginType = "INTERNAL" | "EXTERNAL" | "UNKNOWN" | (string & {});
export interface PackageVersionOrigin {
    domainEntryPoint?: DomainEntryPoint | undefined;
    originType?: PackageVersionOriginType | undefined;
}
export interface PackageVersionDescription {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    packageName?: string | undefined;
    displayName?: string | undefined;
    version?: string | undefined;
    summary?: string | undefined;
    homePage?: string | undefined;
    sourceCodeRepository?: string | undefined;
    publishedTime?: Date | undefined;
    licenses?: LicenseInfo[] | undefined;
    revision?: string | undefined;
    status?: PackageVersionStatus | undefined;
    origin?: PackageVersionOrigin | undefined;
}
export interface DescribePackageVersionResult {
    packageVersion: PackageVersionDescription;
}
export interface DescribeRepositoryRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
}
export interface DescribeRepositoryResult {
    repository?: RepositoryDescription | undefined;
}
export interface DisassociateExternalConnectionRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    externalConnection: string;
}
export interface DisassociateExternalConnectionResult {
    repository?: RepositoryDescription | undefined;
}
export interface DisposePackageVersionsRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    versions: string[];
    versionRevisions?: {
        [key: string]: string | undefined;
    } | undefined;
    expectedStatus?: PackageVersionStatus | undefined;
}
export interface DisposePackageVersionsResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    } | undefined;
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    } | undefined;
}
export interface GetAssociatedPackageGroupRequest {
    domain: string;
    domainOwner?: string | undefined;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
}
export type PackageGroupAssociationType = "STRONG" | "WEAK" | (string & {});
export interface GetAssociatedPackageGroupResult {
    packageGroup?: PackageGroupDescription | undefined;
    associationType?: PackageGroupAssociationType | undefined;
}
export type AuthorizationTokenDurationSeconds = number;
export interface GetAuthorizationTokenRequest {
    domain: string;
    domainOwner?: string | undefined;
    durationSeconds?: number | undefined;
}
export interface GetAuthorizationTokenResult {
    authorizationToken?: string | redacted.Redacted<string> | undefined;
    expiration?: Date | undefined;
}
export interface GetDomainPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string | undefined;
}
export interface GetDomainPermissionsPolicyResult {
    policy?: ResourcePolicy | undefined;
}
export type AssetName = string;
export interface GetPackageVersionAssetRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    packageVersion: string;
    asset: string;
    packageVersionRevision?: string | undefined;
}
export interface GetPackageVersionAssetResult {
    asset?: T.StreamingOutputBody | undefined;
    assetName?: string | undefined;
    packageVersion?: string | undefined;
    packageVersionRevision?: string | undefined;
}
export interface GetPackageVersionReadmeRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    packageVersion: string;
}
export interface GetPackageVersionReadmeResult {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    version?: string | undefined;
    versionRevision?: string | undefined;
    readme?: string | undefined;
}
export type EndpointType = "dualstack" | "ipv4" | (string & {});
export interface GetRepositoryEndpointRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    endpointType?: EndpointType | undefined;
}
export interface GetRepositoryEndpointResult {
    repositoryEndpoint?: string | undefined;
}
export interface GetRepositoryPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
}
export interface GetRepositoryPermissionsPolicyResult {
    policy?: ResourcePolicy | undefined;
}
export type ListAllowedRepositoriesForGroupMaxResults = number;
export type PaginationToken = string;
export interface ListAllowedRepositoriesForGroupRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
    originRestrictionType: PackageGroupOriginRestrictionType;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type RepositoryNameList = string[];
export interface ListAllowedRepositoriesForGroupResult {
    allowedRepositories?: string[] | undefined;
    nextToken?: string | undefined;
}
export type ListPackagesMaxResults = number;
export interface ListAssociatedPackagesRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    preview?: boolean | undefined;
}
export interface AssociatedPackage {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    associationType?: PackageGroupAssociationType | undefined;
}
export type AssociatedPackageList = AssociatedPackage[];
export interface ListAssociatedPackagesResult {
    packages?: AssociatedPackage[] | undefined;
    nextToken?: string | undefined;
}
export type ListDomainsMaxResults = number;
export interface ListDomainsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DomainSummary {
    name?: string | undefined;
    owner?: string | undefined;
    arn?: string | undefined;
    status?: DomainStatus | undefined;
    createdTime?: Date | undefined;
    encryptionKey?: string | undefined;
}
export type DomainSummaryList = DomainSummary[];
export interface ListDomainsResult {
    domains?: DomainSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListPackageGroupsMaxResults = number;
export type PackageGroupPatternPrefix = string;
export interface ListPackageGroupsRequest {
    domain: string;
    domainOwner?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    prefix?: string | undefined;
}
export interface PackageGroupSummary {
    arn?: string | undefined;
    pattern?: string | undefined;
    domainName?: string | undefined;
    domainOwner?: string | undefined;
    createdTime?: Date | undefined;
    contactInfo?: string | undefined;
    description?: string | undefined;
    originConfiguration?: PackageGroupOriginConfiguration | undefined;
    parent?: PackageGroupReference | undefined;
}
export type PackageGroupSummaryList = PackageGroupSummary[];
export interface ListPackageGroupsResult {
    packageGroups?: PackageGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListPackagesRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    packagePrefix?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    publish?: AllowPublish | undefined;
    upstream?: AllowUpstream | undefined;
}
export type PackageSummaryList = PackageSummary[];
export interface ListPackagesResult {
    packages?: PackageSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListPackageVersionAssetsMaxResults = number;
export interface ListPackageVersionAssetsRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    packageVersion: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type HashAlgorithm = "MD5" | "SHA-1" | "SHA-256" | "SHA-512" | (string & {});
export type HashValue = string;
export type AssetHashes = {
    [key in HashAlgorithm]?: string | undefined;
};
export interface AssetSummary {
    name: string;
    size?: number | undefined;
    hashes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AssetSummaryList = AssetSummary[];
export interface ListPackageVersionAssetsResult {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    version?: string | undefined;
    versionRevision?: string | undefined;
    nextToken?: string | undefined;
    assets?: AssetSummary[] | undefined;
}
export interface ListPackageVersionDependenciesRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    packageVersion: string;
    nextToken?: string | undefined;
}
export interface PackageDependency {
    namespace?: string | undefined;
    package?: string | undefined;
    dependencyType?: string | undefined;
    versionRequirement?: string | undefined;
}
export type PackageDependencyList = PackageDependency[];
export interface ListPackageVersionDependenciesResult {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    version?: string | undefined;
    versionRevision?: string | undefined;
    nextToken?: string | undefined;
    dependencies?: PackageDependency[] | undefined;
}
export type PackageVersionSortType = "PUBLISHED_TIME" | (string & {});
export type ListPackageVersionsMaxResults = number;
export interface ListPackageVersionsRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    status?: PackageVersionStatus | undefined;
    sortBy?: PackageVersionSortType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    originType?: PackageVersionOriginType | undefined;
}
export interface PackageVersionSummary {
    version: string;
    revision?: string | undefined;
    status: PackageVersionStatus;
    origin?: PackageVersionOrigin | undefined;
}
export type PackageVersionSummaryList = PackageVersionSummary[];
export interface ListPackageVersionsResult {
    defaultDisplayVersion?: string | undefined;
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    versions?: PackageVersionSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListRepositoriesMaxResults = number;
export interface ListRepositoriesRequest {
    repositoryPrefix?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RepositorySummary {
    name?: string | undefined;
    administratorAccount?: string | undefined;
    domainName?: string | undefined;
    domainOwner?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
    createdTime?: Date | undefined;
}
export type RepositorySummaryList = RepositorySummary[];
export interface ListRepositoriesResult {
    repositories?: RepositorySummary[] | undefined;
    nextToken?: string | undefined;
}
export type ListRepositoriesInDomainMaxResults = number;
export interface ListRepositoriesInDomainRequest {
    domain: string;
    domainOwner?: string | undefined;
    administratorAccount?: string | undefined;
    repositoryPrefix?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListRepositoriesInDomainResult {
    repositories?: RepositorySummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSubPackageGroupsRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListSubPackageGroupsResult {
    packageGroups?: PackageGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResult {
    tags?: Tag[] | undefined;
}
export type SHA256 = string;
export interface PublishPackageVersionRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    packageVersion: string;
    assetContent: T.StreamingInputBody;
    assetName: string;
    assetSHA256: string;
    unfinished?: boolean | undefined;
}
export interface PublishPackageVersionResult {
    format?: PackageFormat | undefined;
    namespace?: string | undefined;
    package?: string | undefined;
    version?: string | undefined;
    versionRevision?: string | undefined;
    status?: PackageVersionStatus | undefined;
    asset?: AssetSummary | undefined;
}
export interface PutDomainPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string | undefined;
    policyRevision?: string | undefined;
    policyDocument: string;
}
export interface PutDomainPermissionsPolicyResult {
    policy?: ResourcePolicy | undefined;
}
export interface PutPackageOriginConfigurationRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    restrictions: PackageOriginRestrictions;
}
export interface PutPackageOriginConfigurationResult {
    originConfiguration?: PackageOriginConfiguration | undefined;
}
export interface PutRepositoryPermissionsPolicyRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    policyRevision?: string | undefined;
    policyDocument: string;
}
export interface PutRepositoryPermissionsPolicyResult {
    policy?: ResourcePolicy | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResult {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResult {
}
export interface UpdatePackageGroupRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
    contactInfo?: string | undefined;
    description?: string | undefined;
}
export interface UpdatePackageGroupResult {
    packageGroup?: PackageGroupDescription | undefined;
}
export type OriginRestrictions = {
    [key in PackageGroupOriginRestrictionType]?: PackageGroupOriginRestrictionMode | undefined;
};
export interface PackageGroupAllowedRepository {
    repositoryName?: string | undefined;
    originRestrictionType?: PackageGroupOriginRestrictionType | undefined;
}
export type PackageGroupAllowedRepositoryList = PackageGroupAllowedRepository[];
export interface UpdatePackageGroupOriginConfigurationRequest {
    domain: string;
    domainOwner?: string | undefined;
    packageGroup: string;
    restrictions?: {
        [key: string]: PackageGroupOriginRestrictionMode | undefined;
    } | undefined;
    addAllowedRepositories?: PackageGroupAllowedRepository[] | undefined;
    removeAllowedRepositories?: PackageGroupAllowedRepository[] | undefined;
}
export type PackageGroupAllowedRepositoryUpdateType = "ADDED" | "REMOVED" | (string & {});
export type PackageGroupAllowedRepositoryUpdate = {
    [key in PackageGroupAllowedRepositoryUpdateType]?: string[] | undefined;
};
export type PackageGroupAllowedRepositoryUpdates = {
    [key in PackageGroupOriginRestrictionType]?: {
        [key: string]: string[] | undefined;
    } | undefined;
};
export interface UpdatePackageGroupOriginConfigurationResult {
    packageGroup?: PackageGroupDescription | undefined;
    allowedRepositoryUpdates?: {
        [key: string]: {
            [key: string]: string[] | undefined;
        } | undefined;
    } | undefined;
}
export interface UpdatePackageVersionsStatusRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    format: PackageFormat;
    namespace?: string | undefined;
    package: string;
    versions: string[];
    versionRevisions?: {
        [key: string]: string | undefined;
    } | undefined;
    expectedStatus?: PackageVersionStatus | undefined;
    targetStatus: PackageVersionStatus;
}
export interface UpdatePackageVersionsStatusResult {
    successfulVersions?: {
        [key: string]: SuccessfulPackageVersionInfo | undefined;
    } | undefined;
    failedVersions?: {
        [key: string]: PackageVersionError | undefined;
    } | undefined;
}
export interface UpdateRepositoryRequest {
    domain: string;
    domainOwner?: string | undefined;
    repository: string;
    description?: string | undefined;
    upstreams?: UpstreamRepository[] | undefined;
}
export interface UpdateRepositoryResult {
    repository?: RepositoryDescription | undefined;
}
export type ResourceType = "domain" | "repository" | "package" | "package-version" | "asset" | (string & {});
export type RetryAfterSeconds = number;
export type ValidationExceptionReason = "CANNOT_PARSE" | "ENCRYPTION_KEY_ERROR" | "FIELD_VALIDATION_FAILED" | "UNKNOWN_OPERATION" | "OTHER" | (string & {});
export type AssociateExternalConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds an existing external connection to a repository. One external connection is allowed
 * per repository.
 *
 * A repository can have one or more upstream repositories, or an external connection.
 */
export declare const associateExternalConnection: API.OperationMethod<AssociateExternalConnectionRequest & RegionInput, AssociateExternalConnectionResult, AssociateExternalConnectionError, Credentials | HttpClient.HttpClient>;
export type CopyPackageVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Copies package versions from one repository to another repository in the same domain.
 *
 * You must specify `versions` or `versionRevisions`. You cannot specify both.
 */
export declare const copyPackageVersions: API.OperationMethod<CopyPackageVersionsRequest & RegionInput, CopyPackageVersionsResult, CopyPackageVersionsError, Credentials | HttpClient.HttpClient>;
export type CreateDomainError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a domain. CodeArtifact *domains* make it easier to manage multiple repositories across an
 * organization. You can use a domain to apply permissions across many
 * repositories owned by different Amazon Web Services accounts. An asset is stored only once
 * in a domain, even if it's in multiple repositories.
 *
 * Although you can have multiple domains, we recommend a single production domain that contains all
 * published artifacts so that your development teams can find and share packages. You can use a second
 * pre-production domain to test changes to the production domain configuration.
 */
export declare const createDomain: API.OperationMethod<CreateDomainRequest & RegionInput, CreateDomainResult, CreateDomainError, Credentials | HttpClient.HttpClient>;
export type CreatePackageGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a package group. For more information about creating package groups, including example CLI commands, see Create a package group in the *CodeArtifact User Guide*.
 */
export declare const createPackageGroup: API.OperationMethod<CreatePackageGroupRequest & RegionInput, CreatePackageGroupResult, CreatePackageGroupError, Credentials | HttpClient.HttpClient>;
export type CreateRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a repository.
 */
export declare const createRepository: API.OperationMethod<CreateRepositoryRequest & RegionInput, CreateRepositoryResult, CreateRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a domain. You cannot delete a domain that contains repositories. If you want to delete a domain
 * with repositories, first delete its repositories.
 */
export declare const deleteDomain: API.OperationMethod<DeleteDomainRequest & RegionInput, DeleteDomainResult, DeleteDomainError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy set on a domain.
 */
export declare const deleteDomainPermissionsPolicy: API.OperationMethod<DeleteDomainPermissionsPolicyRequest & RegionInput, DeleteDomainPermissionsPolicyResult, DeleteDomainPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type DeletePackageError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a package and all associated package versions. A deleted package cannot be restored. To delete one or more package versions, use the
 * DeletePackageVersions API.
 */
export declare const deletePackage: API.OperationMethod<DeletePackageRequest & RegionInput, DeletePackageResult, DeletePackageError, Credentials | HttpClient.HttpClient>;
export type DeletePackageGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a package group.
 * Deleting a package group does not delete packages or package versions associated with the package group.
 * When a package group is deleted, the direct child package groups will become children of the package
 * group's direct parent package group. Therefore, if any of the child groups are inheriting any settings
 * from the parent, those settings could change.
 */
export declare const deletePackageGroup: API.OperationMethod<DeletePackageGroupRequest & RegionInput, DeletePackageGroupResult, DeletePackageGroupError, Credentials | HttpClient.HttpClient>;
export type DeletePackageVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one or more versions of a package. A deleted package version cannot be restored
 * in your repository. If you want to remove a package version from your repository and be able
 * to restore it later, set its status to `Archived`. Archived packages cannot be
 * downloaded from a repository and don't show up with list package APIs (for example,
 * ListPackageVersions), but you can restore them using UpdatePackageVersionsStatus.
 */
export declare const deletePackageVersions: API.OperationMethod<DeletePackageVersionsRequest & RegionInput, DeletePackageVersionsResult, DeletePackageVersionsError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a repository.
 */
export declare const deleteRepository: API.OperationMethod<DeleteRepositoryRequest & RegionInput, DeleteRepositoryResult, DeleteRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteRepositoryPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource policy that is set on a repository. After a resource policy is deleted, the
 * permissions allowed and denied by the deleted policy are removed. The effect of deleting a resource policy might not be immediate.
 *
 * Use `DeleteRepositoryPermissionsPolicy` with caution. After a policy is deleted, Amazon Web Services users, roles, and accounts lose permissions to perform
 * the repository actions granted by the deleted policy.
 */
export declare const deleteRepositoryPermissionsPolicy: API.OperationMethod<DeleteRepositoryPermissionsPolicyRequest & RegionInput, DeleteRepositoryPermissionsPolicyResult, DeleteRepositoryPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * DomainDescription
 * object that contains information about the requested domain.
 */
export declare const describeDomain: API.OperationMethod<DescribeDomainRequest & RegionInput, DescribeDomainResult, DescribeDomainError, Credentials | HttpClient.HttpClient>;
export type DescribePackageError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * PackageDescription
 * object that contains information about the requested package.
 */
export declare const describePackage: API.OperationMethod<DescribePackageRequest & RegionInput, DescribePackageResult, DescribePackageError, Credentials | HttpClient.HttpClient>;
export type DescribePackageGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a PackageGroupDescription object that
 * contains information about the requested package group.
 */
export declare const describePackageGroup: API.OperationMethod<DescribePackageGroupRequest & RegionInput, DescribePackageGroupResult, DescribePackageGroupError, Credentials | HttpClient.HttpClient>;
export type DescribePackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a
 * PackageVersionDescription
 * object that contains information about the requested package version.
 */
export declare const describePackageVersion: API.OperationMethod<DescribePackageVersionRequest & RegionInput, DescribePackageVersionResult, DescribePackageVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeRepositoryError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a `RepositoryDescription` object that contains detailed information
 * about the requested repository.
 */
export declare const describeRepository: API.OperationMethod<DescribeRepositoryRequest & RegionInput, DescribeRepositoryResult, DescribeRepositoryError, Credentials | HttpClient.HttpClient>;
export type DisassociateExternalConnectionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes an existing external connection from a repository.
 */
export declare const disassociateExternalConnection: API.OperationMethod<DisassociateExternalConnectionRequest & RegionInput, DisassociateExternalConnectionResult, DisassociateExternalConnectionError, Credentials | HttpClient.HttpClient>;
export type DisposePackageVersionsError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the assets in package versions and sets the package versions' status to `Disposed`.
 * A disposed package version cannot be restored in your repository because its assets are deleted.
 *
 * To view all disposed package versions in a repository, use ListPackageVersions and set the
 * status parameter
 * to `Disposed`.
 *
 * To view information about a disposed package version, use DescribePackageVersion.
 */
export declare const disposePackageVersions: API.OperationMethod<DisposePackageVersionsRequest & RegionInput, DisposePackageVersionsResult, DisposePackageVersionsError, Credentials | HttpClient.HttpClient>;
export type GetAssociatedPackageGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the most closely associated package group to the specified package. This API does not require that the package exist
 * in any repository in the domain. As such, `GetAssociatedPackageGroup` can be used to see which package group's origin configuration
 * applies to a package before that package is in a repository. This can be helpful to check if public packages are blocked without ingesting them.
 *
 * For information package group association and matching, see
 * Package group
 * definition syntax and matching behavior in the *CodeArtifact User Guide*.
 */
export declare const getAssociatedPackageGroup: API.OperationMethod<GetAssociatedPackageGroupRequest & RegionInput, GetAssociatedPackageGroupResult, GetAssociatedPackageGroupError, Credentials | HttpClient.HttpClient>;
export type GetAuthorizationTokenError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Generates a temporary authorization token for accessing repositories in the domain.
 * This API requires the `codeartifact:GetAuthorizationToken` and `sts:GetServiceBearerToken` permissions.
 * For more information about authorization tokens, see
 * CodeArtifact authentication and tokens.
 *
 * CodeArtifact authorization tokens are valid for a period of 12 hours when created with the `login` command.
 * You can call `login` periodically to refresh the token. When
 * you create an authorization token with the `GetAuthorizationToken` API, you can set a custom authorization period,
 * up to a maximum of 12 hours, with the `durationSeconds` parameter.
 *
 * The authorization period begins after `login`
 * or `GetAuthorizationToken` is called. If `login` or `GetAuthorizationToken` is called while
 * assuming a role, the token lifetime is independent of the maximum session duration
 * of the role. For example, if you call `sts assume-role` and specify a session duration of 15 minutes, then
 * generate a CodeArtifact authorization token, the token will be valid for the full authorization period
 * even though this is longer than the 15-minute session duration.
 *
 * See
 * Using IAM Roles
 * for more information on controlling session duration.
 */
export declare const getAuthorizationToken: API.OperationMethod<GetAuthorizationTokenRequest & RegionInput, GetAuthorizationTokenResult, GetAuthorizationTokenError, Credentials | HttpClient.HttpClient>;
export type GetDomainPermissionsPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource policy attached to the specified domain.
 *
 * The policy is a resource-based policy, not an identity-based policy. For more information, see
 * Identity-based policies
 * and resource-based policies in the *IAM User Guide*.
 */
export declare const getDomainPermissionsPolicy: API.OperationMethod<GetDomainPermissionsPolicyRequest & RegionInput, GetDomainPermissionsPolicyResult, GetDomainPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionAssetError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an asset (or file) that is in a package. For example, for a Maven package version, use
 * `GetPackageVersionAsset` to download a `JAR` file, a `POM` file,
 * or any other assets in the package version.
 */
export declare const getPackageVersionAsset: API.OperationMethod<GetPackageVersionAssetRequest & RegionInput, GetPackageVersionAssetResult, GetPackageVersionAssetError, Credentials | HttpClient.HttpClient>;
export type GetPackageVersionReadmeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets the readme file or descriptive text for a package version.
 *
 * The returned text might contain formatting. For example, it might contain formatting for Markdown or reStructuredText.
 */
export declare const getPackageVersionReadme: API.OperationMethod<GetPackageVersionReadmeRequest & RegionInput, GetPackageVersionReadmeResult, GetPackageVersionReadmeError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryEndpointError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the endpoint of a repository for a specific package format. A repository has one endpoint for each
 * package format:
 *
 * - `cargo`
 *
 * - `generic`
 *
 * - `maven`
 *
 * - `npm`
 *
 * - `nuget`
 *
 * - `pypi`
 *
 * - `ruby`
 *
 * - `swift`
 */
export declare const getRepositoryEndpoint: API.OperationMethod<GetRepositoryEndpointRequest & RegionInput, GetRepositoryEndpointResult, GetRepositoryEndpointError, Credentials | HttpClient.HttpClient>;
export type GetRepositoryPermissionsPolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the resource policy that is set on a repository.
 */
export declare const getRepositoryPermissionsPolicy: API.OperationMethod<GetRepositoryPermissionsPolicyRequest & RegionInput, GetRepositoryPermissionsPolicyResult, GetRepositoryPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type ListAllowedRepositoriesForGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the repositories in the added repositories list of the specified restriction type for a package group. For more information about restriction types
 * and added repository lists, see Package group origin controls in the *CodeArtifact User Guide*.
 */
export declare const listAllowedRepositoriesForGroup: API.PaginatedOperationMethod<ListAllowedRepositoriesForGroupRequest & RegionInput, ListAllowedRepositoriesForGroupResult, ListAllowedRepositoriesForGroupError, Credentials | HttpClient.HttpClient, RepositoryName>;
export type ListAssociatedPackagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns a list of packages associated with the requested package group. For information package group association and matching, see
 * Package group
 * definition syntax and matching behavior in the *CodeArtifact User Guide*.
 */
export declare const listAssociatedPackages: API.PaginatedOperationMethod<ListAssociatedPackagesRequest & RegionInput, ListAssociatedPackagesResult, ListAssociatedPackagesError, Credentials | HttpClient.HttpClient, AssociatedPackage>;
export type ListDomainsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of DomainSummary objects for all domains owned by the Amazon Web Services account that makes
 * this call. Each returned `DomainSummary` object contains information about a
 * domain.
 */
export declare const listDomains: API.PaginatedOperationMethod<ListDomainsRequest & RegionInput, ListDomainsResult, ListDomainsError, Credentials | HttpClient.HttpClient, DomainSummary>;
export type ListPackageGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of package groups in the requested domain.
 */
export declare const listPackageGroups: API.PaginatedOperationMethod<ListPackageGroupsRequest & RegionInput, ListPackageGroupsResult, ListPackageGroupsError, Credentials | HttpClient.HttpClient, PackageGroupSummary>;
export type ListPackagesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * PackageSummary
 * objects for packages in a repository that match the request parameters.
 */
export declare const listPackages: API.PaginatedOperationMethod<ListPackagesRequest & RegionInput, ListPackagesResult, ListPackagesError, Credentials | HttpClient.HttpClient, PackageSummary>;
export type ListPackageVersionAssetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * AssetSummary
 * objects for assets in a package version.
 */
export declare const listPackageVersionAssets: API.PaginatedOperationMethod<ListPackageVersionAssetsRequest & RegionInput, ListPackageVersionAssetsResult, ListPackageVersionAssetsError, Credentials | HttpClient.HttpClient, AssetSummary>;
export type ListPackageVersionDependenciesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the direct dependencies for a package version. The dependencies are returned as
 * PackageDependency
 * objects. CodeArtifact extracts the dependencies for a package version from the metadata file for the package
 * format (for example, the `package.json` file for npm packages and the `pom.xml` file
 * for Maven). Any package version dependencies that are not listed in the configuration file are not returned.
 */
export declare const listPackageVersionDependencies: API.OperationMethod<ListPackageVersionDependenciesRequest & RegionInput, ListPackageVersionDependenciesResult, ListPackageVersionDependenciesError, Credentials | HttpClient.HttpClient>;
export type ListPackageVersionsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * PackageVersionSummary
 * objects for package versions in a repository that match the request parameters. Package versions of all statuses will be returned by default when calling `list-package-versions` with no `--status` parameter.
 */
export declare const listPackageVersions: API.PaginatedOperationMethod<ListPackageVersionsRequest & RegionInput, ListPackageVersionsResult, ListPackageVersionsError, Credentials | HttpClient.HttpClient, PackageVersionSummary>;
export type ListRepositoriesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * RepositorySummary
 * objects. Each `RepositorySummary` contains information about a repository in the specified Amazon Web Services account and that matches the input
 * parameters.
 */
export declare const listRepositories: API.PaginatedOperationMethod<ListRepositoriesRequest & RegionInput, ListRepositoriesResult, ListRepositoriesError, Credentials | HttpClient.HttpClient, RepositorySummary>;
export type ListRepositoriesInDomainError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of
 * RepositorySummary
 * objects. Each `RepositorySummary` contains information about a repository in the specified domain and that matches the input
 * parameters.
 */
export declare const listRepositoriesInDomain: API.PaginatedOperationMethod<ListRepositoriesInDomainRequest & RegionInput, ListRepositoriesInDomainResult, ListRepositoriesInDomainError, Credentials | HttpClient.HttpClient, RepositorySummary>;
export type ListSubPackageGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of direct children of the specified package group.
 *
 * For information package group hierarchy, see
 * Package group
 * definition syntax and matching behavior in the *CodeArtifact User Guide*.
 */
export declare const listSubPackageGroups: API.PaginatedOperationMethod<ListSubPackageGroupsRequest & RegionInput, ListSubPackageGroupsResult, ListSubPackageGroupsError, Credentials | HttpClient.HttpClient, PackageGroupSummary>;
export type ListTagsForResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about Amazon Web Services tags for a specified Amazon Resource Name (ARN) in CodeArtifact.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResult, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type PublishPackageVersionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new package version containing one or more assets (or files).
 *
 * The `unfinished` flag can be used to keep the package version in the
 * `Unfinished` state until all of its assets have been uploaded (see Package version status in the *CodeArtifact user guide*). To set
 * the package version's status to `Published`, omit the `unfinished` flag
 * when uploading the final asset, or set the status using UpdatePackageVersionStatus. Once a package version's status is set to
 * `Published`, it cannot change back to `Unfinished`.
 *
 * Only generic packages can be published using this API. For more information, see Using generic
 * packages in the *CodeArtifact User Guide*.
 */
export declare const publishPackageVersion: API.OperationMethod<PublishPackageVersionRequest & RegionInput, PublishPackageVersionResult, PublishPackageVersionError, Credentials | HttpClient.HttpClient>;
export type PutDomainPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets a resource policy on a domain that specifies permissions to access it.
 *
 * When you call `PutDomainPermissionsPolicy`, the resource policy on the domain is ignored when evaluting permissions.
 * This ensures that the owner of a domain cannot lock themselves out of the domain, which would prevent them from being
 * able to update the resource policy.
 */
export declare const putDomainPermissionsPolicy: API.OperationMethod<PutDomainPermissionsPolicyRequest & RegionInput, PutDomainPermissionsPolicyResult, PutDomainPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type PutPackageOriginConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the package origin configuration for a package.
 *
 * The package origin configuration determines how new versions of a package can be added to a repository. You can allow or block direct
 * publishing of new package versions, or ingestion and retaining of new package versions from an external connection or upstream source.
 * For more information about package origin controls and configuration, see Editing package origin controls in the *CodeArtifact User Guide*.
 *
 * `PutPackageOriginConfiguration` can be called on a package that doesn't yet exist in the repository. When called
 * on a package that does not exist, a package is created in the repository with no versions and the requested restrictions are set on the package.
 * This can be used to preemptively block ingesting or retaining any versions from external connections or upstream repositories, or to block
 * publishing any versions of the package into the repository before connecting any package managers or publishers to the repository.
 */
export declare const putPackageOriginConfiguration: API.OperationMethod<PutPackageOriginConfigurationRequest & RegionInput, PutPackageOriginConfigurationResult, PutPackageOriginConfigurationError, Credentials | HttpClient.HttpClient>;
export type PutRepositoryPermissionsPolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Sets the resource policy on a repository that specifies permissions to access it.
 *
 * When you call `PutRepositoryPermissionsPolicy`, the resource policy on the repository is ignored when evaluting permissions.
 * This ensures that the owner of a repository cannot lock themselves out of the repository, which would prevent them from being
 * able to update the resource policy.
 */
export declare const putRepositoryPermissionsPolicy: API.OperationMethod<PutRepositoryPermissionsPolicyRequest & RegionInput, PutRepositoryPermissionsPolicyResult, PutRepositoryPermissionsPolicyError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds or updates tags for a resource in CodeArtifact.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResult, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a resource in CodeArtifact.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResult, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a package group. This API cannot be used to update a package group's origin configuration or pattern. To update a
 * package group's origin configuration, use UpdatePackageGroupOriginConfiguration.
 */
export declare const updatePackageGroup: API.OperationMethod<UpdatePackageGroupRequest & RegionInput, UpdatePackageGroupResult, UpdatePackageGroupError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageGroupOriginConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the package origin configuration for a package group.
 *
 * The package origin configuration determines how new versions of a package can be added to a repository. You can allow or block direct
 * publishing of new package versions, or ingestion and retaining of new package versions from an external connection or upstream source.
 * For more information about package group origin controls and configuration, see
 * Package group origin controls
 * in the *CodeArtifact User Guide*.
 */
export declare const updatePackageGroupOriginConfiguration: API.OperationMethod<UpdatePackageGroupOriginConfigurationRequest & RegionInput, UpdatePackageGroupOriginConfigurationResult, UpdatePackageGroupOriginConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdatePackageVersionsStatusError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the status of one or more versions of a package. Using `UpdatePackageVersionsStatus`,
 * you can update the status of package versions to `Archived`, `Published`, or `Unlisted`.
 * To set the status of a package version to `Disposed`, use
 * DisposePackageVersions.
 */
export declare const updatePackageVersionsStatus: API.OperationMethod<UpdatePackageVersionsStatusRequest & RegionInput, UpdatePackageVersionsStatusResult, UpdatePackageVersionsStatusError, Credentials | HttpClient.HttpClient>;
export type UpdateRepositoryError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the properties of a repository.
 */
export declare const updateRepository: API.OperationMethod<UpdateRepositoryRequest & RegionInput, UpdateRepositoryResult, UpdateRepositoryError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codeartifact.d.ts.map