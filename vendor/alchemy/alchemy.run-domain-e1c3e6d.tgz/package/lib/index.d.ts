/**
 * Model a domain from commands, events and rejections; aggregates that decide;
 * views that fold; policies that react; and queries that read across keys.
 * Expose it to clients as an Api, and host it on whichever Platform Layer is
 * provided.
 *
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 *
 * export class MoneyDeposited extends Domain.Event("MoneyDeposited", {
 *   amount: Cents,
 *   balanceAfter: Cents,
 * }) {}
 * ```
 *
 * Every building block is `Domain.<Noun>(...)`, and its types live on the
 * same name: `Domain.Event.Any`, `Domain.Aggregate.StateOf<typeof Account>`.
 * Stories (given / when / then specifications) are in `@alchemy.run/domain/Story`;
 * the Cloudflare platform is in `@alchemy.run/domain/Cloudflare`.
 */
import * as AggregateModule from "./Aggregate.ts";
import * as ApiModule from "./Api.ts";
import * as CommandModule from "./Command.ts";
import * as CompactionModule from "./Compaction.ts";
import * as DecisionModule from "./Decision.ts";
import * as EventModule from "./Event.ts";
import * as ExternalSystemModule from "./ExternalSystem.ts";
import type * as KeyModule from "./Key.ts";
import * as KeyStoreModule from "./KeyStore.ts";
import * as KeyWrapModule from "./KeyWrap.ts";
import * as ModelModule from "./Model.ts";
import * as PolicyModule from "./Policy.ts";
import * as ProjectionModule from "./Projection.ts";
import * as QueryModule from "./Query.ts";
import * as RejectionModule from "./Rejection.ts";
import * as RelationModule from "./Relation.ts";
import * as RequestContextModule from "./RequestContext.ts";
import * as RewriteModule from "./Rewrite.ts";
import { RootKeyWrap as RootKeyWrapLayer } from "./RootKeyWrap.ts";
import * as SagaModule from "./Saga.ts";
import * as StreamModule from "./Stream.ts";
import * as VaultModule from "./Vault.ts";
import * as ViewModule from "./View.ts";
export declare namespace Event {
    /** Any Event class. */
    type Any = EventModule.Any;
    /** An event value: its `_tag` plus its data. */
    type Instance<Tag extends string, F extends EventModule.Fields> = EventModule.Instance<Tag, F>;
}
/** A fact the domain recorded. See {@link EventModule.make}. */
export declare const Event: typeof EventModule.make;
export declare namespace Command {
    /** Any Command class. */
    type Any = CommandModule.Any;
    type Instance<Tag extends string, F extends EventModule.Fields> = CommandModule.Instance<Tag, F>;
    /** The services a command's middleware provides to `decide`. */
    type ContextOf<C extends CommandModule.Any> = CommandModule.ContextOf<C>;
}
/** A request to change one aggregate. See {@link CommandModule.make}. */
export declare const Command: typeof CommandModule.make;
/** When the commands of a client answer, unless a call says otherwise. See {@link CommandModule.DefaultConsistency}. */
export declare const DefaultConsistency: import("effect/Context").Reference<"eventual" | "strong">;
export declare namespace Rejection {
    /** Any Rejection class. */
    type Any = RejectionModule.Any;
    type Instance<Tag extends string, F extends EventModule.Fields> = RejectionModule.Instance<Tag, F>;
}
/** A typed reason a command or read was refused. See {@link RejectionModule.make}. */
export declare const Rejection: typeof RejectionModule.make;
export declare namespace Aggregate {
    /** Any Aggregate class. */
    type Any = AggregateModule.Any;
    type IdOf<A extends AggregateModule.Any> = AggregateModule.IdOf<A>;
    type StateOf<A extends AggregateModule.Any> = AggregateModule.StateOf<A>;
    type EventOf<A extends AggregateModule.Any> = AggregateModule.EventOf<A>;
    type CommandOf<A extends AggregateModule.Any> = AggregateModule.CommandOf<A>;
    /** A reference to one instance of an aggregate. */
    type Ref<A extends AggregateModule.Any = AggregateModule.Any> = AggregateModule.Ref<A>;
    /** What an accepted command returns: its stream, version, events and reply. */
    type Receipt<Ev = unknown, Reply = unknown> = AggregateModule.Receipt<Ev, Reply>;
    type ScheduleReceipt = AggregateModule.ScheduleReceipt;
    /** Where an event sits: its instance, stream, sequence, time and command. */
    type Envelope<Id = string> = AggregateModule.Envelope<Id>;
    type SendOptions = AggregateModule.SendOptions;
    type ScheduleOptions = AggregateModule.ScheduleOptions;
    /** Options for `client.import`: the import's command id and the version it expects. */
    type ImportOptions = AggregateModule.ImportOptions;
    /** One event for `client.import`: the event, or `{ event, at }` to keep its original commit time. */
    type Imported<Ev> = AggregateModule.Imported<Ev>;
    /** The instance type of a class: `InstanceOf<typeof NotOwner>` is `NotOwner`. */
    type InstanceOf<C> = AggregateModule.InstanceOf<C>;
    /** Options for `MyAggregate.predict`. */
    type PredictOptions<R = never> = AggregateModule.PredictOptions<R>;
    /** What `MyAggregate.predict` gives: accepted with events and state, rejected, or unpredictable. */
    type Prediction<State, Ev, Rej, Id = string> = AggregateModule.Prediction<State, Ev, Rej, Id>;
}
/** A consistency boundary that decides commands. See {@link AggregateModule.make}. */
export declare const Aggregate: typeof AggregateModule.make;
/** A command with this id already ran, so it can't be scheduled or cancelled. */
export declare const AlreadyExecuted: typeof AggregateModule.AlreadyExecuted;
export type AlreadyExecuted = AggregateModule.AlreadyExecuted;
/** The scheduled command was already cancelled. */
export declare const AlreadyCancelled: typeof AggregateModule.AlreadyCancelled;
export type AlreadyCancelled = AggregateModule.AlreadyCancelled;
/** No command was scheduled with that id. */
export declare const NotScheduled: typeof AggregateModule.NotScheduled;
export type NotScheduled = AggregateModule.NotScheduled;
/** An import found the instance at another version than it expected. */
export declare const UnexpectedVersion: typeof AggregateModule.UnexpectedVersion;
export type UnexpectedVersion = AggregateModule.UnexpectedVersion;
/** An import's commit times went back, or past the platform's clock. */
export declare const ImportOutOfOrder: typeof AggregateModule.ImportOutOfOrder;
export type ImportOutOfOrder = AggregateModule.ImportOutOfOrder;
export declare namespace Decision {
    /** Any Decision class. */
    type Any = DecisionModule.Any;
    /** One aggregate instance a decision read: its state, and `record`. */
    type Read<A extends AggregateModule.Any> = DecisionModule.Read<A>;
    /** An event recorded on an instance a decision read. */
    type Recorded<E = unknown> = DecisionModule.Recorded<E>;
    /** What an accepted command returns: every stream it committed to, its events and reply. */
    type Receipt<Ev = unknown, Reply = unknown> = DecisionModule.Receipt<Ev, Reply>;
    /** One stream a decision committed to, and its version after. */
    type Commit = DecisionModule.Commit;
}
/** A command decided across several aggregates, atomically. See {@link DecisionModule.make}. */
export declare const Decision: typeof DecisionModule.make;
/**
 * What keys a view, policy, projection or stream: an aggregate (one instance
 * per ref) or a string Schema such as an org id (one instance per value).
 */
export declare namespace Key {
    /** An aggregate, or a string Schema. */
    type Any = KeyModule.Any;
    /** A string Schema that keys instances by value. */
    type Schema = KeyModule.Schema;
    /** How one instance of a key is addressed: a ref, or a Schema key's value. */
    type RefOf<K> = KeyModule.RefOf<K>;
    /** The id of one instance of a key: the aggregate id, or the Schema key's value. */
    type IdOf<K> = KeyModule.IdOf<K>;
}
export declare namespace View {
    /** Any View class. */
    type Any = ViewModule.Any;
    type StateOf<V extends ViewModule.Any> = ViewModule.StateOf<V>;
    type EventOf<V extends ViewModule.Any> = ViewModule.EventOf<V>;
    type KeyOf<V extends ViewModule.Any> = ViewModule.KeyOf<V>;
    /** An event a view emitted, with its state after it. */
    type Entry<S, E, Id = string> = ViewModule.Entry<S, E, Id>;
    type Page<E> = ViewModule.Page<E>;
    /** What `MyView.evolve` applies. */
    type LocalInput<Def, Key extends KeyModule.Any> = ViewModule.LocalInput<Def, Key>;
    /** How much of the history recorded before a view or projection has reached it. */
    type History = ViewModule.History;
}
/** A read model folded from events, per key. See {@link ViewModule.make}. */
export declare const View: typeof ViewModule.make;
/** A view read waited longer than allowed. */
export declare const WaitTimeout: typeof ViewModule.WaitTimeout;
export type WaitTimeout = ViewModule.WaitTimeout;
/** A view did not catch up to a write in time. */
export declare const ConsistencyTimeout: typeof ViewModule.ConsistencyTimeout;
export type ConsistencyTimeout = ViewModule.ConsistencyTimeout;
export declare namespace Policy {
    /** Any Policy class. */
    type Any = PolicyModule.Any;
    /** What a policy reacts to: the event, its source and the source's state. */
    type Trigger<From extends PolicyModule.From, E> = PolicyModule.Trigger<From, E>;
}
/** A standing business rule: on an event, decide what to do next. See {@link PolicyModule.make}. */
export declare const Policy: typeof PolicyModule.make;
export declare namespace Saga {
    /** Any Saga class. */
    type Any = SagaModule.Any;
    /** Where a saga run is. */
    type Status<A, E> = SagaModule.Status<A, E>;
    /** A saga's client. */
    type Client<Key, Input, A, E> = SagaModule.Client<Key, Input, A, E>;
}
/** A process that spans aggregates and takes time, run as an Effect workflow. See {@link SagaModule.make}. */
export declare const Saga: typeof SagaModule.make;
export declare namespace Projection {
    /** Any Projection class. */
    type Any = ProjectionModule.Any;
    /** One input a projection's handler receives. */
    type Input<K extends KeyModule.Any, S, E> = ProjectionModule.Input<K, S, E>;
    /** How a projection's Layer tunes it. */
    type Options = ProjectionModule.Options;
    /** One event a projection's `rewrite` handler receives: what it was, and what it is now. */
    type Rewritten<K extends KeyModule.Any, S, E> = ProjectionModule.Rewritten<K, S, E>;
}
/** Consumes events into a store you own, in order per key; replayable, never sends commands. See {@link ProjectionModule.make}. */
export declare const Projection: typeof ProjectionModule.make;
export declare namespace Rewrite {
    /** Any Rewrite class. */
    type Any = RewriteModule.Any;
    /** What accepting a rewrite returns: pass it to `rewritten` to wait for what is built from it. */
    type Receipt = RewriteModule.Receipt;
    /** Options for `client.rewrite`: the id that names the run. */
    type Options = RewriteModule.Options;
}
/** A change to the events an instance has already recorded: keep, replace or remove each. See {@link RewriteModule.make}. */
export declare const Rewrite: typeof RewriteModule.make;
/** The schema of a rewrite's receipt, for a saga step that returns one. */
export declare const RewriteReceipt: import("effect/Schema").Struct<{
    readonly stream: import("effect/Schema").String;
    readonly rewriteId: import("effect/Schema").String;
    readonly changed: import("effect/Schema").Number;
}>;
export declare const InvariantBroken: typeof RewriteModule.InvariantBroken;
export type InvariantBroken = RewriteModule.InvariantBroken;
export declare namespace Compaction {
    /** Any Compaction class. */
    type Any = CompactionModule.Any;
    /** One run of events a compaction's handler is given before they are removed. */
    type Batch<A extends AggregateModule.Any> = CompactionModule.Batch<A>;
    /** What accepting a compaction returns. */
    type Receipt = CompactionModule.Receipt;
    /** How a compaction's Layer tunes it: when an instance compacts by itself. */
    type Options = CompactionModule.Options;
}
/** Replaces an instance's history with a roll-up of its state; its Layer keeps what it removes. See {@link CompactionModule.make}. */
export declare const Compaction: typeof CompactionModule.make;
/** The schema of a compaction's receipt, for a saga step that returns one. */
export declare const CompactionReceipt: import("effect/Schema").Struct<{
    readonly stream: import("effect/Schema").String;
    readonly version: import("effect/Schema").Number;
    readonly compacted: import("effect/Schema").Number;
}>;
export declare const CompactionLossy: typeof CompactionModule.CompactionLossy;
export type CompactionLossy = CompactionModule.CompactionLossy;
export declare namespace Query {
    /** Any Query class. */
    type Any = QueryModule.Any;
    type InputOf<Q extends QueryModule.Any> = QueryModule.InputOf<Q>;
    type ResultOf<Q extends QueryModule.Any> = QueryModule.ResultOf<Q>;
    /** A page of a paged query's rows. */
    type Page<Row> = QueryModule.Page<Row>;
    /** The page a paged query's handler is asked for. */
    type PageRequest = QueryModule.PageRequest;
    /** How a query's Layer runs it: page size limits. */
    type LayerOptions = QueryModule.LayerOptions;
}
export declare namespace Relation {
    /** Any relation. */
    type Any = RelationModule.Any;
    /** One instance a relation is about: its id and its state. */
    type Instance<A extends AggregateModule.Any> = RelationModule.Instance<A>;
}
/** A rule that relates a few instances at all times. See {@link RelationModule.make}. */
export declare const Relation: typeof RelationModule.make;
/** A question asked across keys, answered from a store a projection writes. See {@link QueryModule.make}. */
export declare const Query: typeof QueryModule.make;
export declare namespace Stream {
    /** Any Stream class. */
    type Any = StreamModule.Any;
    type EventOf<S extends StreamModule.Any> = StreamModule.EventOf<S>;
    type KeyOf<S extends StreamModule.Any> = StreamModule.KeyOf<S>;
    /** One entry of a stream key. */
    type Entry<E, Id = string> = StreamModule.Entry<E, Id>;
}
/** A keyed, append-only, replayable log a projection writes and clients read. See {@link StreamModule.make}. */
export declare const Stream: typeof StreamModule.make;
export declare namespace ExternalSystem {
    /** Any ExternalSystem class. */
    type Any = ExternalSystemModule.Any;
    type Op<Args = unknown, Success = unknown, Error = unknown> = ExternalSystemModule.Op<Args, Success, Error>;
}
/** An outside system the model calls, as an Effect service. See {@link ExternalSystemModule.make}. */
export declare const ExternalSystem: typeof ExternalSystemModule.make;
export declare namespace Api {
    /** What an Api may serve: commands, views, streams and queries. */
    type Servable = ApiModule.Servable;
    /** What `Domain.Api` takes: the model, and the names of what of it the Api serves. */
    type Options<M extends ModelModule.Any, C extends ReadonlyArray<ApiModule.CommandName<M>>, V extends ReadonlyArray<ApiModule.ViewName<M>>, S extends ReadonlyArray<ApiModule.StreamName<M>>, Q extends ReadonlyArray<ApiModule.QueryName<M>> = ReadonlyArray<ApiModule.QueryName<M>>> = ApiModule.Options<M, C, V, S, Q>;
    /** The names of the commands a model holds: their tags. */
    type CommandName<M extends ModelModule.Any> = ApiModule.CommandName<M>;
    /** The names of the views a model holds. */
    type ViewName<M extends ModelModule.Any> = ApiModule.ViewName<M>;
    /** The names of the streams a model holds. */
    type StreamName<M extends ModelModule.Any> = ApiModule.StreamName<M>;
    /** The names of the queries a model holds. */
    type QueryName<M extends ModelModule.Any> = ApiModule.QueryName<M>;
    /** The typed client of an Api. */
    type Client<E extends ApiModule.Servable> = ApiModule.ApiClient<E>;
    /** Type-level identity of an Api's client service, e.g. `Domain.Api.ClientKey<"BankApi">`. */
    type ClientKey<Name extends string> = ApiModule.ClientKey<Name>;
    type CommandClient<C extends CommandModule.Any> = ApiModule.CommandClient<C>;
    /** How a command is sent: its `commandId` and the call's headers. */
    type CommandOptions = ApiModule.CommandOptions;
    type ViewClient<V extends ViewModule.Any> = ApiModule.ViewClient<V>;
    type StreamClient<S extends StreamModule.Any> = ApiModule.StreamClient<S>;
    type QueryClient<Q extends QueryModule.Any> = ApiModule.QueryClient<Q>;
    /** A paged query's `pages` and `entries` Streams. */
    type PagedQueryClient<Q extends QueryModule.Any> = ApiModule.PagedQueryClient<Q>;
    /** How a client asks a query: `atLeast`, `after`, `take` and the call's headers. */
    type QueryOptions = ApiModule.QueryOptions;
    /** Everything a query can fail with. */
    type QueryError<Q extends QueryModule.Any> = ApiModule.QueryError<Q>;
    /** Everything a read can fail with. */
    type ReadError<D> = ApiModule.ReadError<D>;
    /** Any Api class, for code that works with every Api. */
    type Any = ApiModule.Any;
    /** The command classes an Api exposes. */
    type CommandsOf<A extends ApiModule.Any> = ApiModule.CommandsOf<A>;
    /** The rejection classes the commands of an Api declare. */
    type RejectionsOf<A extends ApiModule.Any> = ApiModule.RejectionsOf<A>;
    /** The client an Api's `Client` service gives. */
    type ClientOf<A extends ApiModule.Any> = ApiModule.ClientOf<A>;
}
/** The public surface of a domain for one client. See {@link ApiModule.make}. */
export declare const Api: typeof ApiModule.make;
/** An Api client protocol: everything over HTTP, live reads as streamed responses. */
export declare const protocolHttp: typeof ApiModule.protocolHttp;
/** An Api client protocol: calls over HTTP, each live read a WebSocket to the object that owns it. */
export declare const protocolWebSocket: typeof ApiModule.protocolWebSocket;
/** An Api client protocol: the Api served in the caller's process, through its middleware. */
export declare const protocolInProcess: typeof ApiModule.protocolInProcess;
export declare namespace Model {
    /** Any Model class. */
    type Any = ModelModule.Any;
    /** How a model's `layer` hosts it, including each view's version. */
    type LayerOptions<Views extends string = string> = ModelModule.LayerOptions<Views>;
}
/** The aggregates, views, policies, projections, streams and queries hosted together. See {@link ModelModule.make}. */
export declare const Model: typeof ModelModule.make;
export type { Annotations } from "./Annotations.ts";
/** A problem in a Model's definitions. Building its Layer dies with every one. */
export { DefinitionError } from "./Kernel.ts";
export declare namespace Sealed {
    /** A value encrypted under one subject's key. */
    type Value<A> = VaultModule.Sealed<A>;
    /** Any sealed field. */
    type Any = VaultModule.AnySealed;
}
/** A field encrypted under a key kept per subject. See {@link VaultModule.make}. */
export declare const Sealed: typeof VaultModule.make;
/** Seals, opens and shreds. See {@link VaultModule.Vault}. */
export declare const Vault: typeof VaultModule.Vault;
export type Vault = VaultModule.Vault;
/** Where a Vault keeps one key per subject. See {@link KeyStoreModule.KeyStore}. */
export declare const KeyStore: typeof KeyStoreModule.KeyStore;
export type KeyStore = KeyStoreModule.KeyStore;
/** Makes each subject's key and what is stored of it. See {@link KeyWrapModule.KeyWrap}. */
export declare const KeyWrap: typeof KeyWrapModule.KeyWrap;
export type KeyWrap = KeyWrapModule.KeyWrap;
/** A Vault that encrypts with AES-256-GCM. See {@link VaultLiveLayer}. */
export declare const VaultLive: import("effect/Layer").Layer<VaultModule.Vault, never, KeyStoreModule.KeyStore | KeyWrapModule.KeyWrap>;
/** Keys kept in memory. See {@link MemoryKeyStoreLayer}. */
export declare const MemoryKeyStore: import("effect/Layer").Layer<KeyStoreModule.KeyStore, never, never>;
/** Keys kept on the model's own host. See {@link HostKeyStoreLayer}. */
export declare const HostKeyStore: import("effect/Layer").Layer<KeyStoreModule.KeyStore, never, import("./Platform.ts").Platform>;
/** Keys stored as they are. See {@link NoKeyWrapLayer}. */
export declare const NoKeyWrap: import("effect/Layer").Layer<KeyWrapModule.KeyWrap, never, never>;
/** Keys wrapped under a root key you supply. See {@link RootKeyWrapLayer}. */
export declare const RootKeyWrap: typeof RootKeyWrapLayer;
/** A Vault for stories. See {@link VaultModule.VaultTest}. */
export declare const VaultTest: import("effect/Layer").Layer<VaultModule.Vault, never, never>;
/** A sealed value as the test Vault seals it. See {@link VaultModule.sealedInTest}. */
export declare const sealedInTest: typeof VaultModule.sealedInTest;
/** The Vault or its key store failed. See {@link VaultModule.VaultError}. */
export declare const VaultError: typeof VaultModule.VaultError;
export type VaultError = VaultModule.VaultError;
/** A service middleware provides to a request, carried into the domain. See {@link RequestContextModule.make}. */
export declare const RequestContext: typeof RequestContextModule.make;
/** When a middleware's verdict expires; a live read is judged again then. See {@link RequestContextModule.setExpiry}. */
export declare const setExpiry: (at: number | Date) => import("effect/Effect").Effect<void, never, never>;
export type { Filter, OrderBy } from "./Filter.ts";
export { InMemory } from "./InMemory.ts";
export type * as Middleware from "./Middleware.ts";
export { Platform } from "./Platform.ts";
export * as Read from "./Read.ts";
/** Trace attributes, hosting options and the metrics a model records. */
export * as Telemetry from "./Telemetry.ts";
//# sourceMappingURL=index.d.ts.map