import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const DirectConnectClientException_base: S.TaggedErrorClass<"DirectConnectClientException", {
    readonly message: any;
}>;
export declare class DirectConnectClientException extends /*@__PURE__*/ DirectConnectClientException_base {
}
declare const DirectConnectServerException_base: S.TaggedErrorClass<"DirectConnectServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class DirectConnectServerException extends /*@__PURE__*/ DirectConnectServerException_base {
}
declare const DuplicateTagKeysException_base: S.TaggedErrorClass<"DuplicateTagKeysException", {
    readonly message: any;
}>;
export declare class DuplicateTagKeysException extends /*@__PURE__*/ DuplicateTagKeysException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
}>;
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type DirectConnectGatewayId = string;
export type DirectConnectGatewayAssociationProposalId = string;
export type OwnerAccount = string;
export type CIDR = string;
export interface RouteFilterPrefix {
    cidr?: string | undefined;
}
export type RouteFilterPrefixList = RouteFilterPrefix[];
export interface AcceptDirectConnectGatewayAssociationProposalRequest {
    directConnectGatewayId: string;
    proposalId: string;
    associatedGatewayOwnerAccount: string;
    overrideAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
}
export type DirectConnectGatewayAssociationState = "associating" | "associated" | "disassociating" | "disassociated" | "updating" | (string & {});
export type StateChangeError = string;
export type GatewayIdentifier = string;
export type GatewayType = "virtualPrivateGateway" | "transitGateway" | (string & {});
export type Region = string;
export interface AssociatedGateway {
    id?: string | undefined;
    type?: GatewayType | undefined;
    ownerAccount?: string | undefined;
    region?: string | undefined;
}
export type DirectConnectGatewayAssociationId = string;
export type CoreNetworkIdentifier = string;
export type CoreNetworkAttachmentId = string;
export interface AssociatedCoreNetwork {
    id?: string | undefined;
    ownerAccount?: string | undefined;
    attachmentId?: string | undefined;
}
export type VirtualGatewayId = string;
export type VirtualGatewayRegion = string;
export interface DirectConnectGatewayAssociation {
    directConnectGatewayId?: string | undefined;
    directConnectGatewayOwnerAccount?: string | undefined;
    associationState?: DirectConnectGatewayAssociationState | undefined;
    stateChangeError?: string | undefined;
    associatedGateway?: AssociatedGateway | undefined;
    associationId?: string | undefined;
    allowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
    associatedCoreNetwork?: AssociatedCoreNetwork | undefined;
    virtualGatewayId?: string | undefined;
    virtualGatewayRegion?: string | undefined;
    virtualGatewayOwnerAccount?: string | undefined;
}
export interface AcceptDirectConnectGatewayAssociationProposalResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation | undefined;
}
export type Bandwidth = string;
export type ConnectionName = string;
export type InterconnectId = string;
export type VLAN = number;
export interface AllocateConnectionOnInterconnectRequest {
    bandwidth: string;
    connectionName: string;
    ownerAccount: string;
    interconnectId: string;
    vlan: number;
}
export type ConnectionId = string;
export type ConnectionState = "ordering" | "requested" | "pending" | "available" | "down" | "deleting" | "deleted" | "rejected" | "unknown" | (string & {});
export type LocationCode = string;
export type PartnerName = string;
export type LoaIssueTime = Date;
export type LagId = string;
export type AwsDevice = string;
export type JumboFrameCapable = boolean;
export type AwsDeviceV2 = string;
export type AwsLogicalDeviceId = string;
export type HasLogicalRedundancy = "unknown" | "yes" | "no" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value?: string | undefined;
}
export type TagList = Tag[];
export type ProviderName = string;
export type MacSecCapable = boolean;
export type PortEncryptionStatus = string;
export type EncryptionMode = string;
export type SecretARN = string;
export type Ckn = string;
export type State = string;
export type StartOnDate = string;
export interface MacSecKey {
    secretARN?: string | undefined;
    ckn?: string | undefined;
    state?: string | undefined;
    startOn?: string | undefined;
}
export type MacSecKeyList = MacSecKey[];
export type Count = number;
export interface RateLimiterStatus {
    maxAllowed?: number | undefined;
    inUse?: number | undefined;
    remaining?: number | undefined;
    totalBandwidth?: string | undefined;
}
export type PartnerInterconnectMacSecCapable = boolean;
export type PrefixPoolSize = number;
export type PrefixPoolUnallocatedCount = number;
export type BillingMode = "PayAsYouGo" | "FlatRateTier1" | "FlatRateTier2" | "FlatRateTier3" | "FlatRateTier4" | "FlatRateTier5" | "PortPairFlatRateTier1" | "PortPairFlatRateTier2" | "PortPairFlatRateTier3" | "PortPairFlatRateTier4" | "PortPairFlatRateTier5" | (string & {});
export interface Connection {
    ownerAccount?: string | undefined;
    connectionId?: string | undefined;
    connectionName?: string | undefined;
    connectionState?: ConnectionState | undefined;
    region?: string | undefined;
    location?: string | undefined;
    bandwidth?: string | undefined;
    vlan?: number | undefined;
    partnerName?: string | undefined;
    loaIssueTime?: Date | undefined;
    lagId?: string | undefined;
    awsDevice?: string | undefined;
    jumboFrameCapable?: boolean | undefined;
    awsDeviceV2?: string | undefined;
    awsLogicalDeviceId?: string | undefined;
    hasLogicalRedundancy?: HasLogicalRedundancy | undefined;
    tags?: Tag[] | undefined;
    providerName?: string | undefined;
    macSecCapable?: boolean | undefined;
    portEncryptionStatus?: string | undefined;
    encryptionMode?: string | undefined;
    macSecKeys?: MacSecKey[] | undefined;
    rateLimiterStatus?: RateLimiterStatus | undefined;
    partnerInterconnectMacSecCapable?: boolean | undefined;
    prefixPoolSizeIpv4?: number | undefined;
    prefixPoolSizeIpv6?: number | undefined;
    prefixPoolUnallocatedCountIpv4?: number | undefined;
    prefixPoolUnallocatedCountIpv6?: number | undefined;
    billingMode?: BillingMode | undefined;
}
export interface AllocateHostedConnectionRequest {
    connectionId: string;
    ownerAccount: string;
    bandwidth: string;
    connectionName: string;
    vlan: number;
    tags?: Tag[] | undefined;
}
export type VirtualInterfaceName = string;
export type ASN = number;
export type LongAsn = number;
export type MTU = number;
export type BGPAuthKey = string;
export type AmazonAddress = string;
export type AddressFamily = "ipv4" | "ipv6" | (string & {});
export type CustomerAddress = string;
export type RateLimit = string;
export interface NewPrivateVirtualInterfaceAllocation {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number | undefined;
    asnLong?: number | undefined;
    mtu?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    customerAddress?: string | undefined;
    tags?: Tag[] | undefined;
    rateLimit?: string | undefined;
}
export interface AllocatePrivateVirtualInterfaceRequest {
    connectionId: string;
    ownerAccount: string;
    newPrivateVirtualInterfaceAllocation: NewPrivateVirtualInterfaceAllocation;
}
export type VirtualInterfaceId = string;
export type VirtualInterfaceType = string;
export type VirtualInterfaceState = "confirming" | "verifying" | "pending" | "available" | "down" | "testing" | "deleting" | "deleted" | "rejected" | "unknown" | (string & {});
export type RouterConfig = string;
export type BGPPeerId = string;
export type BGPPeerState = "verifying" | "pending" | "available" | "deleting" | "deleted" | (string & {});
export type BGPStatus = "up" | "down" | "unknown" | (string & {});
export interface BGPPeer {
    bgpPeerId?: string | undefined;
    asn?: number | undefined;
    asnLong?: number | undefined;
    authKey?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    bgpPeerState?: BGPPeerState | undefined;
    bgpStatus?: BGPStatus | undefined;
    awsDeviceV2?: string | undefined;
    awsLogicalDeviceId?: string | undefined;
}
export type BGPPeerList = BGPPeer[];
export type SiteLinkEnabled = boolean;
export type PrefixPoolAllocatedCount = number;
export interface VirtualInterface {
    ownerAccount?: string | undefined;
    virtualInterfaceId?: string | undefined;
    location?: string | undefined;
    connectionId?: string | undefined;
    virtualInterfaceType?: string | undefined;
    virtualInterfaceName?: string | undefined;
    vlan?: number | undefined;
    asn?: number | undefined;
    asnLong?: number | undefined;
    amazonSideAsn?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    virtualInterfaceState?: VirtualInterfaceState | undefined;
    customerRouterConfig?: string | undefined;
    mtu?: number | undefined;
    jumboFrameCapable?: boolean | undefined;
    virtualGatewayId?: string | undefined;
    directConnectGatewayId?: string | undefined;
    routeFilterPrefixes?: RouteFilterPrefix[] | undefined;
    bgpPeers?: BGPPeer[] | undefined;
    region?: string | undefined;
    awsDeviceV2?: string | undefined;
    awsLogicalDeviceId?: string | undefined;
    tags?: Tag[] | undefined;
    siteLinkEnabled?: boolean | undefined;
    prefixPoolAllocatedCountIpv4?: number | undefined;
    prefixPoolAllocatedCountIpv6?: number | undefined;
    rateLimit?: string | undefined;
}
export interface NewPublicVirtualInterfaceAllocation {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number | undefined;
    asnLong?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    routeFilterPrefixes?: RouteFilterPrefix[] | undefined;
    tags?: Tag[] | undefined;
    rateLimit?: string | undefined;
}
export interface AllocatePublicVirtualInterfaceRequest {
    connectionId: string;
    ownerAccount: string;
    newPublicVirtualInterfaceAllocation: NewPublicVirtualInterfaceAllocation;
}
export interface NewTransitVirtualInterfaceAllocation {
    virtualInterfaceName?: string | undefined;
    vlan?: number | undefined;
    asn?: number | undefined;
    asnLong?: number | undefined;
    mtu?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    tags?: Tag[] | undefined;
    rateLimit?: string | undefined;
}
export interface AllocateTransitVirtualInterfaceRequest {
    connectionId: string;
    ownerAccount: string;
    newTransitVirtualInterfaceAllocation: NewTransitVirtualInterfaceAllocation;
}
export interface AllocateTransitVirtualInterfaceResult {
    virtualInterface?: VirtualInterface | undefined;
}
export type ConnectionIdentifier = string;
export type ConnectionIdentifierList = string[];
export type ResiliencyGroupId = string;
export type IdempotencyToken = string;
export interface AssociateConnectionsToResiliencyGroupRequest {
    connectionIdentifiers: string[];
    resiliencyGroupId: string;
    clientToken?: string | undefined;
}
export type ConnectionArn = string;
export type ResiliencyGroupAssociationState = "associating" | "associated" | "disassociating" | "disassociated" | (string & {});
export interface ResiliencyGroupAssociation {
    resiliencyGroupId?: string | undefined;
    connectionArn?: string | undefined;
    state?: ResiliencyGroupAssociationState | undefined;
}
export type ResiliencyGroupAssociationList = ResiliencyGroupAssociation[];
export interface AssociateConnectionsToResiliencyGroupResult {
    resiliencyGroupAssociations?: ResiliencyGroupAssociation[] | undefined;
}
export interface AssociateConnectionWithLagRequest {
    connectionId: string;
    lagId: string;
}
export interface AssociateHostedConnectionRequest {
    connectionId: string;
    parentConnectionId: string;
}
export type Cak = string;
export interface AssociateMacSecKeyRequest {
    connectionId: string;
    secretARN?: string | undefined;
    ckn?: string | undefined;
    cak?: string | undefined;
}
export interface AssociateMacSecKeyResponse {
    connectionId?: string | undefined;
    macSecKeys?: MacSecKey[] | undefined;
}
export interface AssociateVirtualInterfaceRequest {
    virtualInterfaceId: string;
    connectionId: string;
}
export interface ConfirmConnectionRequest {
    connectionId: string;
}
export interface ConfirmConnectionResponse {
    connectionState?: ConnectionState | undefined;
}
export type AgreementName = string;
export interface ConfirmCustomerAgreementRequest {
    agreementName?: string | undefined;
}
export type Status = string;
export interface ConfirmCustomerAgreementResponse {
    status?: string | undefined;
}
export interface ConfirmPrivateVirtualInterfaceRequest {
    virtualInterfaceId: string;
    virtualGatewayId?: string | undefined;
    directConnectGatewayId?: string | undefined;
}
export interface ConfirmPrivateVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState | undefined;
}
export interface ConfirmPublicVirtualInterfaceRequest {
    virtualInterfaceId: string;
}
export interface ConfirmPublicVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState | undefined;
}
export interface ConfirmTransitVirtualInterfaceRequest {
    virtualInterfaceId: string;
    directConnectGatewayId: string;
}
export interface ConfirmTransitVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState | undefined;
}
export interface NewBGPPeer {
    asn?: number | undefined;
    asnLong?: number | undefined;
    authKey?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
}
export interface CreateBGPPeerRequest {
    virtualInterfaceId?: string | undefined;
    newBGPPeer?: NewBGPPeer | undefined;
}
export interface CreateBGPPeerResponse {
    virtualInterface?: VirtualInterface | undefined;
}
export type RequestMACSec = boolean;
export type RequestBillingMode = "PayAsYouGo" | "FlatRateTier1" | "FlatRateTier2" | "FlatRateTier3" | "FlatRateTier4" | "FlatRateTier5" | (string & {});
export interface CreateConnectionRequest {
    location: string;
    bandwidth: string;
    connectionName: string;
    lagId?: string | undefined;
    tags?: Tag[] | undefined;
    providerName?: string | undefined;
    requestMACSec?: boolean | undefined;
    billingMode?: RequestBillingMode | undefined;
}
export type DirectConnectGatewayName = string;
export interface CreateDirectConnectGatewayRequest {
    directConnectGatewayName: string;
    tags?: Tag[] | undefined;
    amazonSideAsn?: number | undefined;
}
export type DirectConnectGatewayState = "pending" | "available" | "deleting" | "deleted" | (string & {});
export interface DirectConnectGateway {
    directConnectGatewayId?: string | undefined;
    directConnectGatewayName?: string | undefined;
    amazonSideAsn?: number | undefined;
    ownerAccount?: string | undefined;
    directConnectGatewayState?: DirectConnectGatewayState | undefined;
    stateChangeError?: string | undefined;
    totalPrefixPoolAllocations?: number | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateDirectConnectGatewayResult {
    directConnectGateway?: DirectConnectGateway | undefined;
}
export type GatewayIdToAssociate = string;
export interface CreateDirectConnectGatewayAssociationRequest {
    directConnectGatewayId: string;
    gatewayId?: string | undefined;
    addAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
    virtualGatewayId?: string | undefined;
}
export interface CreateDirectConnectGatewayAssociationResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation | undefined;
}
export interface CreateDirectConnectGatewayAssociationProposalRequest {
    directConnectGatewayId: string;
    directConnectGatewayOwnerAccount: string;
    gatewayId: string;
    addAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
    removeAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
}
export type DirectConnectGatewayAssociationProposalState = "requested" | "accepted" | "deleted" | (string & {});
export interface DirectConnectGatewayAssociationProposal {
    proposalId?: string | undefined;
    directConnectGatewayId?: string | undefined;
    directConnectGatewayOwnerAccount?: string | undefined;
    proposalState?: DirectConnectGatewayAssociationProposalState | undefined;
    associatedGateway?: AssociatedGateway | undefined;
    existingAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
    requestedAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
}
export interface CreateDirectConnectGatewayAssociationProposalResult {
    directConnectGatewayAssociationProposal?: DirectConnectGatewayAssociationProposal | undefined;
}
export type InterconnectName = string;
export interface CreateInterconnectRequest {
    interconnectName: string;
    bandwidth: string;
    location: string;
    lagId?: string | undefined;
    tags?: Tag[] | undefined;
    providerName?: string | undefined;
    requestMACSec?: boolean | undefined;
}
export type InterconnectState = "requested" | "pending" | "available" | "down" | "deleting" | "deleted" | "unknown" | (string & {});
export interface Interconnect {
    interconnectId?: string | undefined;
    interconnectName?: string | undefined;
    interconnectState?: InterconnectState | undefined;
    region?: string | undefined;
    location?: string | undefined;
    bandwidth?: string | undefined;
    loaIssueTime?: Date | undefined;
    lagId?: string | undefined;
    awsDevice?: string | undefined;
    jumboFrameCapable?: boolean | undefined;
    awsDeviceV2?: string | undefined;
    awsLogicalDeviceId?: string | undefined;
    hasLogicalRedundancy?: HasLogicalRedundancy | undefined;
    tags?: Tag[] | undefined;
    providerName?: string | undefined;
    macSecCapable?: boolean | undefined;
    portEncryptionStatus?: string | undefined;
    encryptionMode?: string | undefined;
    macSecKeys?: MacSecKey[] | undefined;
}
export type LagName = string;
export interface CreateLagRequest {
    numberOfConnections: number;
    location: string;
    connectionsBandwidth: string;
    lagName: string;
    connectionId?: string | undefined;
    tags?: Tag[] | undefined;
    childConnectionTags?: Tag[] | undefined;
    providerName?: string | undefined;
    requestMACSec?: boolean | undefined;
    billingMode?: RequestBillingMode | undefined;
}
export type LagState = "requested" | "pending" | "available" | "down" | "deleting" | "deleted" | "unknown" | (string & {});
export type ConnectionList = Connection[];
export type BooleanFlag = boolean;
export interface Lag {
    connectionsBandwidth?: string | undefined;
    numberOfConnections?: number | undefined;
    lagId?: string | undefined;
    ownerAccount?: string | undefined;
    lagName?: string | undefined;
    lagState?: LagState | undefined;
    location?: string | undefined;
    region?: string | undefined;
    minimumLinks?: number | undefined;
    awsDevice?: string | undefined;
    awsDeviceV2?: string | undefined;
    awsLogicalDeviceId?: string | undefined;
    connections?: Connection[] | undefined;
    allowsHostedConnections?: boolean | undefined;
    jumboFrameCapable?: boolean | undefined;
    hasLogicalRedundancy?: HasLogicalRedundancy | undefined;
    tags?: Tag[] | undefined;
    providerName?: string | undefined;
    macSecCapable?: boolean | undefined;
    encryptionMode?: string | undefined;
    macSecKeys?: MacSecKey[] | undefined;
    prefixPoolSizeIpv4?: number | undefined;
    prefixPoolSizeIpv6?: number | undefined;
    prefixPoolUnallocatedCountIpv4?: number | undefined;
    prefixPoolUnallocatedCountIpv6?: number | undefined;
    rateLimiterStatus?: RateLimiterStatus | undefined;
    billingMode?: BillingMode | undefined;
}
export type EnableSiteLink = boolean;
export interface NewPrivateVirtualInterface {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number | undefined;
    asnLong?: number | undefined;
    mtu?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    virtualGatewayId?: string | undefined;
    directConnectGatewayId?: string | undefined;
    tags?: Tag[] | undefined;
    enableSiteLink?: boolean | undefined;
    prefixPoolAllocatedCountIpv4?: number | undefined;
    prefixPoolAllocatedCountIpv6?: number | undefined;
    rateLimit?: string | undefined;
}
export interface CreatePrivateVirtualInterfaceRequest {
    connectionId: string;
    newPrivateVirtualInterface: NewPrivateVirtualInterface;
}
export interface NewPublicVirtualInterface {
    virtualInterfaceName: string;
    vlan: number;
    asn?: number | undefined;
    asnLong?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    routeFilterPrefixes?: RouteFilterPrefix[] | undefined;
    tags?: Tag[] | undefined;
    rateLimit?: string | undefined;
}
export interface CreatePublicVirtualInterfaceRequest {
    connectionId: string;
    newPublicVirtualInterface: NewPublicVirtualInterface;
}
export type ResiliencyGroupName = string;
export type ResiliencyModel = "maximum-resiliency" | "high-resiliency" | "basic-resiliency" | (string & {});
export interface CreateResiliencyGroupRequest {
    resiliencyGroupName: string;
    intendedResiliencyModel: ResiliencyModel;
    clientToken?: string | undefined;
    tags?: Tag[] | undefined;
}
export type ResiliencyGroupArn = string;
export type ResiliencyGroupType = "Managed" | (string & {});
export type ResiliencyGroupState = "pending" | "available" | "deleting" | "deleted" | (string & {});
export interface ResiliencyGroup {
    resiliencyGroupId?: string | undefined;
    resiliencyGroupArn?: string | undefined;
    resiliencyGroupName?: string | undefined;
    resiliencyGroupType?: ResiliencyGroupType | undefined;
    ownerAccount?: string | undefined;
    state?: ResiliencyGroupState | undefined;
    tags?: Tag[] | undefined;
}
export interface CreateResiliencyGroupResult {
    resiliencyGroup?: ResiliencyGroup | undefined;
}
export interface NewTransitVirtualInterface {
    virtualInterfaceName?: string | undefined;
    vlan?: number | undefined;
    asn?: number | undefined;
    asnLong?: number | undefined;
    mtu?: number | undefined;
    authKey?: string | undefined;
    amazonAddress?: string | undefined;
    customerAddress?: string | undefined;
    addressFamily?: AddressFamily | undefined;
    directConnectGatewayId?: string | undefined;
    tags?: Tag[] | undefined;
    enableSiteLink?: boolean | undefined;
    prefixPoolAllocatedCountIpv4?: number | undefined;
    prefixPoolAllocatedCountIpv6?: number | undefined;
    rateLimit?: string | undefined;
}
export interface CreateTransitVirtualInterfaceRequest {
    connectionId: string;
    newTransitVirtualInterface: NewTransitVirtualInterface;
}
export interface CreateTransitVirtualInterfaceResult {
    virtualInterface?: VirtualInterface | undefined;
}
export interface DeleteBGPPeerRequest {
    virtualInterfaceId?: string | undefined;
    asn?: number | undefined;
    asnLong?: number | undefined;
    customerAddress?: string | undefined;
    bgpPeerId?: string | undefined;
}
export interface DeleteBGPPeerResponse {
    virtualInterface?: VirtualInterface | undefined;
}
export interface DeleteConnectionRequest {
    connectionId: string;
}
export interface DeleteDirectConnectGatewayRequest {
    directConnectGatewayId: string;
}
export interface DeleteDirectConnectGatewayResult {
    directConnectGateway?: DirectConnectGateway | undefined;
}
export interface DeleteDirectConnectGatewayAssociationRequest {
    associationId?: string | undefined;
    directConnectGatewayId?: string | undefined;
    virtualGatewayId?: string | undefined;
}
export interface DeleteDirectConnectGatewayAssociationResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation | undefined;
}
export interface DeleteDirectConnectGatewayAssociationProposalRequest {
    proposalId: string;
}
export interface DeleteDirectConnectGatewayAssociationProposalResult {
    directConnectGatewayAssociationProposal?: DirectConnectGatewayAssociationProposal | undefined;
}
export interface DeleteInterconnectRequest {
    interconnectId: string;
}
export interface DeleteInterconnectResponse {
    interconnectState?: InterconnectState | undefined;
}
export interface DeleteLagRequest {
    lagId: string;
}
export interface DeleteResiliencyGroupRequest {
    resiliencyGroupId: string;
}
export interface DeleteResiliencyGroupResult {
    resiliencyGroup?: ResiliencyGroup | undefined;
}
export interface DeleteVirtualInterfaceRequest {
    virtualInterfaceId: string;
}
export interface DeleteVirtualInterfaceResponse {
    virtualInterfaceState?: VirtualInterfaceState | undefined;
}
export type LoaContentType = "application/pdf" | (string & {});
export interface DescribeConnectionLoaRequest {
    connectionId: string;
    providerName?: string | undefined;
    loaContentType?: LoaContentType | undefined;
}
export type LoaContent = Uint8Array;
export interface Loa {
    loaContent?: Uint8Array | undefined;
    loaContentType?: LoaContentType | undefined;
}
export interface DescribeConnectionLoaResponse {
    loa?: Loa | undefined;
}
export type MaxResultSetSize = number;
export type PaginationToken = string;
export interface DescribeConnectionsRequest {
    connectionId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface Connections {
    connections?: Connection[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeConnectionsOnInterconnectRequest {
    interconnectId: string;
}
export interface DescribeCustomerMetadataRequest {
}
export interface CustomerAgreement {
    agreementName?: string | undefined;
    status?: string | undefined;
}
export type AgreementList = CustomerAgreement[];
export type NniPartnerType = "v1" | "v2" | "nonPartner" | (string & {});
export interface DescribeCustomerMetadataResponse {
    agreements?: CustomerAgreement[] | undefined;
    nniPartnerType?: NniPartnerType | undefined;
}
export type AssociatedGatewayId = string;
export interface DescribeDirectConnectGatewayAssociationProposalsRequest {
    directConnectGatewayId?: string | undefined;
    proposalId?: string | undefined;
    associatedGatewayId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type DirectConnectGatewayAssociationProposalList = DirectConnectGatewayAssociationProposal[];
export interface DescribeDirectConnectGatewayAssociationProposalsResult {
    directConnectGatewayAssociationProposals?: DirectConnectGatewayAssociationProposal[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeDirectConnectGatewayAssociationsRequest {
    associationId?: string | undefined;
    associatedGatewayId?: string | undefined;
    directConnectGatewayId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    virtualGatewayId?: string | undefined;
}
export type DirectConnectGatewayAssociationList = DirectConnectGatewayAssociation[];
export interface DescribeDirectConnectGatewayAssociationsResult {
    directConnectGatewayAssociations?: DirectConnectGatewayAssociation[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeDirectConnectGatewayAttachmentsRequest {
    directConnectGatewayId?: string | undefined;
    virtualInterfaceId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type VirtualInterfaceRegion = string;
export type DirectConnectGatewayAttachmentState = "attaching" | "attached" | "detaching" | "detached" | (string & {});
export type DirectConnectGatewayAttachmentType = "TransitVirtualInterface" | "PrivateVirtualInterface" | (string & {});
export interface DirectConnectGatewayAttachment {
    directConnectGatewayId?: string | undefined;
    virtualInterfaceId?: string | undefined;
    virtualInterfaceRegion?: string | undefined;
    virtualInterfaceOwnerAccount?: string | undefined;
    attachmentState?: DirectConnectGatewayAttachmentState | undefined;
    attachmentType?: DirectConnectGatewayAttachmentType | undefined;
    stateChangeError?: string | undefined;
}
export type DirectConnectGatewayAttachmentList = DirectConnectGatewayAttachment[];
export interface DescribeDirectConnectGatewayAttachmentsResult {
    directConnectGatewayAttachments?: DirectConnectGatewayAttachment[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeDirectConnectGatewaysRequest {
    directConnectGatewayId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type DirectConnectGatewayList = DirectConnectGateway[];
export interface DescribeDirectConnectGatewaysResult {
    directConnectGateways?: DirectConnectGateway[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeHostedConnectionsRequest {
    connectionId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface DescribeInterconnectLoaRequest {
    interconnectId: string;
    providerName?: string | undefined;
    loaContentType?: LoaContentType | undefined;
}
export interface DescribeInterconnectLoaResponse {
    loa?: Loa | undefined;
}
export interface DescribeInterconnectsRequest {
    interconnectId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type InterconnectList = Interconnect[];
export interface Interconnects {
    interconnects?: Interconnect[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeLagsRequest {
    lagId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type LagList = Lag[];
export interface Lags {
    lags?: Lag[] | undefined;
    nextToken?: string | undefined;
}
export interface DescribeLoaRequest {
    connectionId: string;
    providerName?: string | undefined;
    loaContentType?: LoaContentType | undefined;
}
export interface DescribeLocationsRequest {
}
export type LocationName = string;
export type PortSpeed = string;
export type AvailablePortSpeeds = string[];
export type ProviderList = string[];
export type AvailableMacSecPortSpeeds = string[];
export type IncludedRegionList = string[];
export interface AvailableBillingMode {
    billingMode?: BillingMode | undefined;
    availablePortSpeeds?: string[] | undefined;
    includedRegions?: string[] | undefined;
}
export type AvailableBillingModeList = AvailableBillingMode[];
export interface Location {
    locationCode?: string | undefined;
    locationName?: string | undefined;
    region?: string | undefined;
    availablePortSpeeds?: string[] | undefined;
    availableProviders?: string[] | undefined;
    availableMacSecPortSpeeds?: string[] | undefined;
    availableBillingModes?: AvailableBillingMode[] | undefined;
}
export type LocationList = Location[];
export interface Locations {
    locations?: Location[] | undefined;
}
export type RouterTypeIdentifier = string;
export interface DescribeRouterConfigurationRequest {
    virtualInterfaceId: string;
    routerTypeIdentifier?: string | undefined;
}
export type Vendor = string;
export type Platform = string;
export type Software = string;
export type XsltTemplateName = string;
export type XsltTemplateNameForMacSec = string;
export interface RouterType {
    vendor?: string | undefined;
    platform?: string | undefined;
    software?: string | undefined;
    xsltTemplateName?: string | undefined;
    xsltTemplateNameForMacSec?: string | undefined;
    routerTypeIdentifier?: string | undefined;
}
export interface DescribeRouterConfigurationResponse {
    customerRouterConfig?: string | undefined;
    router?: RouterType | undefined;
    virtualInterfaceId?: string | undefined;
    virtualInterfaceName?: string | undefined;
}
export type ResourceArn = string;
export type ResourceArnList = string[];
export interface DescribeTagsRequest {
    resourceArns: string[];
}
export interface ResourceTag {
    resourceArn?: string | undefined;
    tags?: Tag[] | undefined;
}
export type ResourceTagList = ResourceTag[];
export interface DescribeTagsResponse {
    resourceTags?: ResourceTag[] | undefined;
}
export interface DescribeVirtualGatewaysRequest {
}
export type VirtualGatewayState = string;
export interface VirtualGateway {
    virtualGatewayId?: string | undefined;
    virtualGatewayState?: string | undefined;
}
export type VirtualGatewayList = VirtualGateway[];
export interface VirtualGateways {
    virtualGateways?: VirtualGateway[] | undefined;
}
export interface DescribeVirtualInterfacesRequest {
    connectionId?: string | undefined;
    virtualInterfaceId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type VirtualInterfaceList = VirtualInterface[];
export interface VirtualInterfaces {
    virtualInterfaces?: VirtualInterface[] | undefined;
    nextToken?: string | undefined;
}
export interface DisassociateConnectionFromLagRequest {
    connectionId: string;
    lagId: string;
}
export interface DisassociateConnectionsFromResiliencyGroupRequest {
    connectionIdentifiers: string[];
    resiliencyGroupId: string;
    clientToken?: string | undefined;
}
export interface DisassociateConnectionsFromResiliencyGroupResult {
    resiliencyGroupAssociations?: ResiliencyGroupAssociation[] | undefined;
}
export interface DisassociateMacSecKeyRequest {
    connectionId: string;
    secretARN: string;
}
export interface DisassociateMacSecKeyResponse {
    connectionId?: string | undefined;
    macSecKeys?: MacSecKey[] | undefined;
}
export interface GetResiliencyGroupRequest {
    resiliencyGroupId: string;
}
export interface GetResiliencyGroupResult {
    resiliencyGroup?: ResiliencyGroup | undefined;
}
export interface ListResiliencyGroupAssociationsRequest {
    resiliencyGroupId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListResiliencyGroupAssociationsResult {
    items?: ResiliencyGroupAssociation[] | undefined;
    nextToken?: string | undefined;
}
export interface ListResiliencyGroupsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ResiliencyGroupSummary {
    resiliencyGroupId?: string | undefined;
    resiliencyGroupArn?: string | undefined;
    resiliencyGroupName?: string | undefined;
    resiliencyGroupType?: ResiliencyGroupType | undefined;
    ownerAccount?: string | undefined;
    state?: ResiliencyGroupState | undefined;
}
export type ResiliencyGroupSummaryList = ResiliencyGroupSummary[];
export interface ListResiliencyGroupsResult {
    items?: ResiliencyGroupSummary[] | undefined;
    nextToken?: string | undefined;
}
export type RouteDirection = "accepted" | "advertised" | (string & {});
export type RouteFilterCidrString = string;
export type RouteFilterCidrStringList = string[];
export type AsPathList = number[];
export type CommunityEntry = string;
export type CommunityList = string[];
export interface RouteFilters {
    routeDirection?: RouteDirection | undefined;
    addressFamily?: AddressFamily | undefined;
    cidrs?: string[] | undefined;
    asPath?: number[] | undefined;
    communities?: string[] | undefined;
}
export interface ListVirtualInterfaceRoutesRequest {
    virtualInterfaceId?: string | undefined;
    filters?: RouteFilters | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type RouteCidr = string;
export type AsPathType = "seq" | "set" | (string & {});
export interface AsPathSegment {
    pathType?: AsPathType | undefined;
    path?: number[] | undefined;
}
export type AsPathSegmentList = AsPathSegment[];
export type RouteInstalledAt = Date;
export interface Route {
    cidr?: string | undefined;
    routeDirection?: RouteDirection | undefined;
    addressFamily?: AddressFamily | undefined;
    asPath?: AsPathSegment[] | undefined;
    communities?: string[] | undefined;
    awsLogicalDeviceId?: string | undefined;
    routeInstalledAt?: Date | undefined;
}
export type RouteList = Route[];
export interface ListVirtualInterfaceRoutesResponse {
    virtualInterfaceId?: string | undefined;
    routes?: Route[] | undefined;
    nextToken?: string | undefined;
}
export type TestId = string;
export type BGPPeerIdList = string[];
export type FailureTestHistoryStatus = string;
export interface ListVirtualInterfaceTestHistoryRequest {
    testId?: string | undefined;
    virtualInterfaceId?: string | undefined;
    bgpPeers?: string[] | undefined;
    status?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type TestDuration = number;
export type StartTime = Date;
export type EndTime = Date;
export interface VirtualInterfaceTestHistory {
    testId?: string | undefined;
    virtualInterfaceId?: string | undefined;
    bgpPeers?: string[] | undefined;
    status?: string | undefined;
    ownerAccount?: string | undefined;
    testDurationInMinutes?: number | undefined;
    startTime?: Date | undefined;
    endTime?: Date | undefined;
}
export type VirtualInterfaceTestHistoryList = VirtualInterfaceTestHistory[];
export interface ListVirtualInterfaceTestHistoryResponse {
    virtualInterfaceTestHistory?: VirtualInterfaceTestHistory[] | undefined;
    nextToken?: string | undefined;
}
export interface StartBgpFailoverTestRequest {
    virtualInterfaceId: string;
    bgpPeers?: string[] | undefined;
    testDurationInMinutes?: number | undefined;
}
export interface StartBgpFailoverTestResponse {
    virtualInterfaceTest?: VirtualInterfaceTestHistory | undefined;
}
export interface StopBgpFailoverTestRequest {
    virtualInterfaceId: string;
}
export interface StopBgpFailoverTestResponse {
    virtualInterfaceTest?: VirtualInterfaceTestHistory | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateConnectionRequest {
    connectionId: string;
    connectionName?: string | undefined;
    encryptionMode?: string | undefined;
}
export type ConnectionIdList = string[];
export interface UpdateConnectionsBillingModeRequest {
    connectionIds: string[];
    billingMode: RequestBillingMode;
}
export interface UpdateConnectionsBillingModeResponse {
    billingMode?: BillingMode | undefined;
    connections?: Connection[] | undefined;
}
export interface UpdateDirectConnectGatewayRequest {
    directConnectGatewayId: string;
    newDirectConnectGatewayName: string;
}
export interface UpdateDirectConnectGatewayResponse {
    directConnectGateway?: DirectConnectGateway | undefined;
}
export interface UpdateDirectConnectGatewayAssociationRequest {
    associationId?: string | undefined;
    addAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
    removeAllowedPrefixesToDirectConnectGateway?: RouteFilterPrefix[] | undefined;
}
export interface UpdateDirectConnectGatewayAssociationResult {
    directConnectGatewayAssociation?: DirectConnectGatewayAssociation | undefined;
}
export interface UpdateLagRequest {
    lagId: string;
    lagName?: string | undefined;
    minimumLinks?: number | undefined;
    encryptionMode?: string | undefined;
}
export interface UpdateResiliencyGroupRequest {
    resiliencyGroupId: string;
    resiliencyGroupName: string;
    clientToken?: string | undefined;
}
export interface UpdateResiliencyGroupResult {
    resiliencyGroup?: ResiliencyGroup | undefined;
}
export interface UpdateVirtualInterfaceAttributesRequest {
    virtualInterfaceId: string;
    mtu?: number | undefined;
    enableSiteLink?: boolean | undefined;
    virtualInterfaceName?: string | undefined;
    prefixPoolAllocatedCountIpv4?: number | undefined;
    prefixPoolAllocatedCountIpv6?: number | undefined;
    rateLimit?: string | undefined;
}
export type ErrorMessage = string;
export type AcceptDirectConnectGatewayAssociationProposalError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts a proposal request to attach a virtual private gateway or transit gateway to a Direct Connect gateway.
 */
export declare const acceptDirectConnectGatewayAssociationProposal: API.OperationMethod<AcceptDirectConnectGatewayAssociationProposalRequest & RegionInput, AcceptDirectConnectGatewayAssociationProposalResult, AcceptDirectConnectGatewayAssociationProposalError, Credentials | HttpClient.HttpClient>;
export type AllocateConnectionOnInterconnectError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use AllocateHostedConnection instead.
 *
 * Creates a hosted connection on an interconnect.
 *
 * Allocates a VLAN number and a specified amount of bandwidth for use by a hosted connection on the specified interconnect.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const allocateConnectionOnInterconnect: API.OperationMethod<AllocateConnectionOnInterconnectRequest & RegionInput, Connection, AllocateConnectionOnInterconnectError, Credentials | HttpClient.HttpClient>;
export type AllocateHostedConnectionError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates a hosted connection on the specified interconnect or a link aggregation group (LAG) of interconnects.
 *
 * Allocates a VLAN number and a specified amount of capacity (bandwidth) for use by a hosted connection on the specified interconnect or LAG of interconnects.
 * Amazon Web Services polices the hosted connection for the specified capacity and the Direct Connect Partner must also police the hosted connection for the specified capacity.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const allocateHostedConnection: API.OperationMethod<AllocateHostedConnectionRequest & RegionInput, Connection, AllocateHostedConnectionError, Credentials | HttpClient.HttpClient>;
export type AllocatePrivateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Provisions a private virtual interface to be owned by the specified Amazon Web Services account.
 *
 * Virtual interfaces created using this action must be confirmed by the owner using ConfirmPrivateVirtualInterface.
 * Until then, the virtual interface is in the `Confirming` state and is not available to handle traffic.
 */
export declare const allocatePrivateVirtualInterface: API.OperationMethod<AllocatePrivateVirtualInterfaceRequest & RegionInput, VirtualInterface, AllocatePrivateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type AllocatePublicVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Provisions a public virtual interface to be owned by the specified Amazon Web Services account.
 *
 * The owner of a connection calls this function to provision a public virtual interface to be owned by the specified Amazon Web Services account.
 *
 * Virtual interfaces created using this function must be confirmed by the owner using ConfirmPublicVirtualInterface.
 * Until this step has been completed, the virtual interface is in the `confirming` state and is not available to handle traffic.
 *
 * When creating an IPv6 public virtual interface, omit the Amazon address and customer address. IPv6 addresses are automatically assigned from
 * the Amazon pool of IPv6 addresses; you cannot specify custom IPv6 addresses.
 */
export declare const allocatePublicVirtualInterface: API.OperationMethod<AllocatePublicVirtualInterfaceRequest & RegionInput, VirtualInterface, AllocatePublicVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type AllocateTransitVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Provisions a transit virtual interface to be owned by the specified Amazon Web Services account. Use this type of interface to connect a transit gateway to your Direct Connect gateway.
 *
 * The owner of a connection provisions a transit virtual interface to be owned by the specified Amazon Web Services account.
 *
 * After you create a transit virtual interface, it must be confirmed by the owner using ConfirmTransitVirtualInterface. Until this step has been completed, the transit virtual interface is in the `requested` state and is not available to handle traffic.
 */
export declare const allocateTransitVirtualInterface: API.OperationMethod<AllocateTransitVirtualInterfaceRequest & RegionInput, AllocateTransitVirtualInterfaceResult, AllocateTransitVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type AssociateConnectionsToResiliencyGroupError = DirectConnectClientException | DirectConnectServerException | LimitExceededException | CommonErrors;
/**
 * Associates one or more connections with the specified resiliency group. This operation is
 * atomic: either all of the specified connections are associated, or the operation fails and no
 * changes are made.
 */
export declare const associateConnectionsToResiliencyGroup: API.OperationMethod<AssociateConnectionsToResiliencyGroupRequest & RegionInput, AssociateConnectionsToResiliencyGroupResult, AssociateConnectionsToResiliencyGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateConnectionWithLagError = DirectConnectClientException | DirectConnectServerException | LimitExceededException | CommonErrors;
/**
 * Associates an existing connection with a link aggregation group (LAG). The connection
 * is interrupted and re-established as a member of the LAG (connectivity to Amazon Web Services is
 * interrupted). The connection must be hosted on the same Direct Connect endpoint as the LAG, and its
 * bandwidth must match the bandwidth for the LAG. You can re-associate a connection that's
 * currently associated with a different LAG; however, if removing the connection would cause
 * the original LAG to fall below its setting for minimum number of operational connections,
 * the request fails.
 *
 * Any virtual interfaces that are directly associated with the connection are
 * automatically re-associated with the LAG. If the connection was originally associated
 * with a different LAG, the virtual interfaces remain associated with the original
 * LAG.
 *
 * For interconnects, any hosted connections are automatically re-associated with the
 * LAG. If the interconnect was originally associated with a different LAG, the hosted
 * connections remain associated with the original LAG.
 */
export declare const associateConnectionWithLag: API.OperationMethod<AssociateConnectionWithLagRequest & RegionInput, Connection, AssociateConnectionWithLagError, Credentials | HttpClient.HttpClient>;
export type AssociateHostedConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Associates a hosted connection and its virtual interfaces with a link aggregation
 * group (LAG) or interconnect. If the target interconnect or LAG has an existing hosted
 * connection with a conflicting VLAN number or IP address, the operation fails. This
 * action temporarily interrupts the hosted connection's connectivity to Amazon Web Services
 * as it is being migrated.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const associateHostedConnection: API.OperationMethod<AssociateHostedConnectionRequest & RegionInput, Connection, AssociateHostedConnectionError, Credentials | HttpClient.HttpClient>;
export type AssociateMacSecKeyError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Associates a MAC Security (MACsec) Connection Key Name (CKN)/ Connectivity Association Key (CAK) pair with a Direct Connect connection.
 *
 * You must supply either the `secretARN,` or the CKN/CAK (`ckn` and `cak`) pair in the request.
 *
 * For information about MAC Security (MACsec) key considerations, see MACsec pre-shared CKN/CAK key considerations in the *Direct Connect User Guide*.
 */
export declare const associateMacSecKey: API.OperationMethod<AssociateMacSecKeyRequest & RegionInput, AssociateMacSecKeyResponse, AssociateMacSecKeyError, Credentials | HttpClient.HttpClient>;
export type AssociateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Associates a virtual interface with a specified link aggregation group (LAG) or
 * connection. Connectivity to Amazon Web Services is temporarily interrupted as the virtual interface is
 * being migrated. If the target connection or LAG has an associated virtual interface with
 * a conflicting VLAN number or a conflicting IP address, the operation fails.
 *
 * Virtual interfaces associated with a hosted connection cannot be associated with a
 * LAG; hosted connections must be migrated along with their virtual interfaces using AssociateHostedConnection.
 *
 * To reassociate a virtual interface to a new connection or LAG, the requester
 * must own either the virtual interface itself or the connection to which the virtual
 * interface is currently associated. Additionally, the requester must own the connection
 * or LAG for the association.
 */
export declare const associateVirtualInterface: API.OperationMethod<AssociateVirtualInterfaceRequest & RegionInput, VirtualInterface, AssociateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type ConfirmConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Confirms the creation of the specified hosted connection on an interconnect.
 *
 * Upon creation, the hosted connection is initially in the `Ordering` state, and
 * remains in this state until the owner confirms creation of the hosted connection.
 */
export declare const confirmConnection: API.OperationMethod<ConfirmConnectionRequest & RegionInput, ConfirmConnectionResponse, ConfirmConnectionError, Credentials | HttpClient.HttpClient>;
export type ConfirmCustomerAgreementError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * The confirmation of the terms of agreement when creating the connection/link aggregation group (LAG).
 */
export declare const confirmCustomerAgreement: API.OperationMethod<ConfirmCustomerAgreementRequest & RegionInput, ConfirmCustomerAgreementResponse, ConfirmCustomerAgreementError, Credentials | HttpClient.HttpClient>;
export type ConfirmPrivateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts ownership of a private virtual interface created by another Amazon Web Services account.
 *
 * After the virtual interface owner makes this call, the virtual interface is
 * created and attached to the specified virtual private gateway or Direct Connect gateway, and is
 * made available to handle traffic.
 */
export declare const confirmPrivateVirtualInterface: API.OperationMethod<ConfirmPrivateVirtualInterfaceRequest & RegionInput, ConfirmPrivateVirtualInterfaceResponse, ConfirmPrivateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type ConfirmPublicVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts ownership of a public virtual interface created by another Amazon Web Services account.
 *
 * After the virtual interface owner makes this call, the specified virtual interface is
 * created and made available to handle traffic.
 */
export declare const confirmPublicVirtualInterface: API.OperationMethod<ConfirmPublicVirtualInterfaceRequest & RegionInput, ConfirmPublicVirtualInterfaceResponse, ConfirmPublicVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type ConfirmTransitVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Accepts ownership of a transit virtual interface created by another Amazon Web Services account.
 *
 * After the owner of the transit virtual interface makes this call, the specified transit virtual interface is created and made available to handle traffic.
 */
export declare const confirmTransitVirtualInterface: API.OperationMethod<ConfirmTransitVirtualInterfaceRequest & RegionInput, ConfirmTransitVirtualInterfaceResponse, ConfirmTransitVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreateBGPPeerError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates a BGP peer on the specified virtual interface.
 *
 * You must create a BGP peer for the corresponding address family (IPv4/IPv6) in order to
 * access Amazon Web Services resources that also use that address family.
 *
 * If logical redundancy is not supported by the connection, interconnect, or LAG, the BGP peer cannot
 * be in the same address family as an existing BGP peer on the virtual interface.
 *
 * When creating a IPv6 BGP peer, omit the Amazon address and customer address. IPv6 addresses are automatically assigned from
 * the Amazon pool of IPv6 addresses; you cannot specify custom IPv6 addresses.
 *
 * If you let Amazon Web Services auto-assign IPv4 addresses, a /30 CIDR will be allocated
 * from 169.254.0.0/16. Amazon Web Services does not recommend this option if you intend to use
 * the customer router peer IP address as the source and destination for traffic. Instead you
 * should use RFC 1918 or other addressing, and specify the address yourself. For more
 * information about RFC 1918 see
 * Address Allocation for Private Internets.
 *
 * For a public virtual interface, the Autonomous System Number (ASN) must be private or already on the allow list for the virtual interface.
 */
export declare const createBGPPeer: API.OperationMethod<CreateBGPPeerRequest & RegionInput, CreateBGPPeerResponse, CreateBGPPeerError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates a connection between a customer network and a specific Direct Connect location.
 *
 * A connection links your internal network to an Direct Connect location over a standard Ethernet fiber-optic
 * cable. One end of the cable is connected to your router, the other to an Direct Connect router.
 *
 * To find the locations for your Region, use DescribeLocations.
 *
 * You can automatically add the new connection to a link aggregation group (LAG) by
 * specifying a LAG ID in the request. This ensures that the new connection is allocated on the
 * same Direct Connect endpoint that hosts the specified LAG. If there are no available ports on the endpoint,
 * the request fails and no connection is created.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest & RegionInput, Connection, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates a Direct Connect gateway, which is an intermediate object that enables you to connect a set
 * of virtual interfaces and virtual private gateways. A Direct Connect gateway is global and visible in any
 * Amazon Web Services Region after it is created. The virtual interfaces and virtual private gateways that
 * are connected through a Direct Connect gateway can be in different Amazon Web Services Regions. This enables you to
 * connect to a VPC in any Region, regardless of the Region in which the virtual interfaces
 * are located, and pass traffic between them.
 */
export declare const createDirectConnectGateway: API.OperationMethod<CreateDirectConnectGatewayRequest & RegionInput, CreateDirectConnectGatewayResult, CreateDirectConnectGatewayError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayAssociationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates an association between a Direct Connect gateway and a virtual private gateway. The virtual
 * private gateway must be attached to a VPC and must not be associated with another Direct Connect gateway.
 */
export declare const createDirectConnectGatewayAssociation: API.OperationMethod<CreateDirectConnectGatewayAssociationRequest & RegionInput, CreateDirectConnectGatewayAssociationResult, CreateDirectConnectGatewayAssociationError, Credentials | HttpClient.HttpClient>;
export type CreateDirectConnectGatewayAssociationProposalError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Creates a proposal to associate the specified virtual private gateway or transit gateway with the specified Direct Connect gateway.
 *
 * You can associate a Direct Connect gateway and virtual private gateway or transit gateway that is owned by any Amazon Web Services account.
 */
export declare const createDirectConnectGatewayAssociationProposal: API.OperationMethod<CreateDirectConnectGatewayAssociationProposalRequest & RegionInput, CreateDirectConnectGatewayAssociationProposalResult, CreateDirectConnectGatewayAssociationProposalError, Credentials | HttpClient.HttpClient>;
export type CreateInterconnectError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates an interconnect between an Direct Connect Partner's network and a specific Direct Connect location.
 *
 * An interconnect is a connection that is capable of hosting other connections. The
 * Direct Connect Partner can use an interconnect to provide Direct Connect hosted
 * connections to customers through their own network services. Like a standard connection, an
 * interconnect links the partner's network to an Direct Connect location over a standard Ethernet
 * fiber-optic cable. One end is connected to the partner's router, the other to an Direct Connect
 * router.
 *
 * You can automatically add the new interconnect to a link aggregation group (LAG) by
 * specifying a LAG ID in the request. This ensures that the new interconnect is allocated on
 * the same Direct Connect endpoint that hosts the specified LAG. If there are no available ports on the
 * endpoint, the request fails and no interconnect is created.
 *
 * For each end customer, the Direct Connect Partner provisions a connection on their interconnect by calling AllocateHostedConnection.
 * The end customer can then connect to Amazon Web Services resources by creating a virtual interface on their connection, using the VLAN assigned to them by the Direct Connect Partner.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const createInterconnect: API.OperationMethod<CreateInterconnectRequest & RegionInput, Interconnect, CreateInterconnectError, Credentials | HttpClient.HttpClient>;
export type CreateLagError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Creates a link aggregation group (LAG) with the specified number of bundled
 * physical dedicated connections between the customer network and a specific Direct Connect location.
 * A LAG is a logical interface that uses the Link Aggregation Control Protocol
 * (LACP) to aggregate multiple interfaces, enabling you to treat them as a single
 * interface.
 *
 * All connections in a LAG must use the same bandwidth (either 1Gbps, 10Gbps, 100Gbps,
 * or 400Gbps) and must terminate at the same Direct Connect endpoint.
 *
 * You can have up to 10 dedicated connections per location. Regardless of this limit, if you
 * request more connections for the LAG than Direct Connect can allocate on a single endpoint, no LAG is
 * created..
 *
 * You can specify an existing physical dedicated connection or interconnect to include in
 * the LAG (which counts towards the total number of connections). Doing so interrupts the
 * current physical dedicated connection, and re-establishes them as a member of the LAG. The LAG
 * will be created on the same Direct Connect endpoint to which the dedicated connection terminates. Any
 * virtual interfaces associated with the dedicated connection are automatically disassociated
 * and re-associated with the LAG. The connection ID does not change.
 *
 * If the Amazon Web Services account used to create a LAG is a registered Direct Connect Partner, the LAG is
 * automatically enabled to host sub-connections. For a LAG owned by a partner, any associated virtual
 * interfaces cannot be directly configured.
 */
export declare const createLag: API.OperationMethod<CreateLagRequest & RegionInput, Lag, CreateLagError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a private virtual interface. A virtual interface is the VLAN that transports Direct Connect traffic.
 * A private virtual interface can be connected to either a Direct Connect gateway or a Virtual Private Gateway (VGW).
 * Connecting the private virtual interface to a Direct Connect gateway enables the possibility for connecting to multiple
 * VPCs, including VPCs in different Amazon Web Services Regions. Connecting the private virtual interface
 * to a VGW only provides access to a single VPC within the same Region.
 *
 * Setting the MTU of a virtual interface to 8500 (jumbo frames) can cause an update to
 * the underlying physical connection if it wasn't updated to support jumbo frames. Updating
 * the connection disrupts network connectivity for all virtual interfaces associated with
 * the connection for up to 30 seconds. To check whether your connection supports jumbo
 * frames, call DescribeConnections. To check whether your virtual
 * interface supports jumbo frames, call DescribeVirtualInterfaces.
 */
export declare const createPrivateVirtualInterface: API.OperationMethod<CreatePrivateVirtualInterfaceRequest & RegionInput, VirtualInterface, CreatePrivateVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreatePublicVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a public virtual interface. A virtual interface is the VLAN that transports Direct Connect traffic.
 * A public virtual interface supports sending traffic to public services of Amazon Web Services such as Amazon S3.
 *
 * When creating an IPv6 public virtual interface (`addressFamily` is `ipv6`), leave the `customer`
 * and `amazon` address fields blank to use auto-assigned IPv6 space. Custom IPv6 addresses are not supported.
 */
export declare const createPublicVirtualInterface: API.OperationMethod<CreatePublicVirtualInterfaceRequest & RegionInput, VirtualInterface, CreatePublicVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type CreateResiliencyGroupError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a resiliency group. A resiliency group lets you group Direct Connect connections together
 * and manage them as a single unit to meet a target resiliency model.
 */
export declare const createResiliencyGroup: API.OperationMethod<CreateResiliencyGroupRequest & RegionInput, CreateResiliencyGroupResult, CreateResiliencyGroupError, Credentials | HttpClient.HttpClient>;
export type CreateTransitVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | LimitExceededException | TooManyTagsException | CommonErrors;
/**
 * Creates a transit virtual interface. A transit virtual interface should be used to access one or more transit gateways associated with Direct Connect gateways. A transit virtual interface enables the connection of multiple VPCs attached to a transit gateway to a Direct Connect gateway.
 *
 * If you associate your transit gateway with one or more Direct Connect gateways, the Autonomous System Number (ASN) used by the transit gateway and the Direct Connect gateway must be different. For example, if you use the default ASN 64512 for both your the transit gateway and Direct Connect gateway, the association request fails.
 *
 * A jumbo MTU value must be either 1500 or 8500. No other values will be accepted. Setting
 * the MTU of a virtual interface to 8500 (jumbo frames) can cause an update to the underlying
 * physical connection if it wasn't updated to support jumbo frames. Updating the connection
 * disrupts network connectivity for all virtual interfaces associated with the connection for up
 * to 30 seconds. To check whether your connection supports jumbo frames, call DescribeConnections. To check whether your virtual interface supports jumbo
 * frames, call DescribeVirtualInterfaces.
 */
export declare const createTransitVirtualInterface: API.OperationMethod<CreateTransitVirtualInterfaceRequest & RegionInput, CreateTransitVirtualInterfaceResult, CreateTransitVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type DeleteBGPPeerError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified BGP peer on the specified virtual interface with the specified customer address and ASN.
 *
 * You cannot delete the last BGP peer from a virtual interface.
 */
export declare const deleteBGPPeer: API.OperationMethod<DeleteBGPPeerRequest & RegionInput, DeleteBGPPeerResponse, DeleteBGPPeerError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified connection.
 *
 * Deleting a connection only stops the Direct Connect port hour and data transfer charges.
 * If you are partnering with any third parties to connect with the Direct Connect location,
 * you must cancel your service with them separately.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest & RegionInput, Connection, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectConnectGatewayError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified Direct Connect gateway. You must first delete all virtual interfaces that are
 * attached to the Direct Connect gateway and disassociate all virtual private gateways associated
 * with the Direct Connect gateway.
 */
export declare const deleteDirectConnectGateway: API.OperationMethod<DeleteDirectConnectGatewayRequest & RegionInput, DeleteDirectConnectGatewayResult, DeleteDirectConnectGatewayError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectConnectGatewayAssociationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the association between the specified Direct Connect gateway and virtual private gateway.
 *
 * We recommend that you specify the `associationID` to delete the association. Alternatively, if you own virtual gateway and a Direct Connect gateway association, you can specify the `virtualGatewayId` and `directConnectGatewayId` to delete an association.
 */
export declare const deleteDirectConnectGatewayAssociation: API.OperationMethod<DeleteDirectConnectGatewayAssociationRequest & RegionInput, DeleteDirectConnectGatewayAssociationResult, DeleteDirectConnectGatewayAssociationError, Credentials | HttpClient.HttpClient>;
export type DeleteDirectConnectGatewayAssociationProposalError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the association proposal request between the specified Direct Connect gateway and virtual private gateway or transit gateway.
 */
export declare const deleteDirectConnectGatewayAssociationProposal: API.OperationMethod<DeleteDirectConnectGatewayAssociationProposalRequest & RegionInput, DeleteDirectConnectGatewayAssociationProposalResult, DeleteDirectConnectGatewayAssociationProposalError, Credentials | HttpClient.HttpClient>;
export type DeleteInterconnectError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified interconnect.
 *
 * Intended for use
 * by Direct Connect Partners only.
 */
export declare const deleteInterconnect: API.OperationMethod<DeleteInterconnectRequest & RegionInput, DeleteInterconnectResponse, DeleteInterconnectError, Credentials | HttpClient.HttpClient>;
export type DeleteLagError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified link aggregation group (LAG). You cannot delete a LAG if it has active
 * virtual interfaces or hosted connections.
 */
export declare const deleteLag: API.OperationMethod<DeleteLagRequest & RegionInput, Lag, DeleteLagError, Credentials | HttpClient.HttpClient>;
export type DeleteResiliencyGroupError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes the specified resiliency group. Deletion is asynchronous: the resiliency group
 * transitions through the `deleting` state before it reaches the
 * `deleted` state. The response returns the resiliency group so you can observe its
 * current state without a subsequent GetResiliencyGroup call.
 */
export declare const deleteResiliencyGroup: API.OperationMethod<DeleteResiliencyGroupRequest & RegionInput, DeleteResiliencyGroupResult, DeleteResiliencyGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteVirtualInterfaceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deletes a virtual interface.
 */
export declare const deleteVirtualInterface: API.OperationMethod<DeleteVirtualInterfaceRequest & RegionInput, DeleteVirtualInterfaceResponse, DeleteVirtualInterfaceError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionLoaError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use DescribeLoa instead.
 *
 * Gets the LOA-CFA for a connection.
 *
 * The Letter of Authorization - Connecting Facility Assignment (LOA-CFA) is a document that your APN partner or
 * service provider uses when establishing your cross connect to Amazon Web Services at the colocation facility. For more information,
 * see Requesting Cross Connects
 * at Direct Connect Locations in the *Direct Connect User Guide*.
 */
export declare const describeConnectionLoa: API.OperationMethod<DescribeConnectionLoaRequest & RegionInput, DescribeConnectionLoaResponse, DescribeConnectionLoaError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Displays the specified connection or all connections in this Region.
 */
export declare const describeConnections: API.OperationMethod<DescribeConnectionsRequest & RegionInput, Connections, DescribeConnectionsError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionsOnInterconnectError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use DescribeHostedConnections instead.
 *
 * Lists the connections that have been provisioned on the specified interconnect.
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const describeConnectionsOnInterconnect: API.OperationMethod<DescribeConnectionsOnInterconnectRequest & RegionInput, Connections, DescribeConnectionsOnInterconnectError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomerMetadataError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Get and view a list of customer agreements, along with their signed status and whether the customer is an NNIPartner, NNIPartnerV2, or a nonPartner.
 */
export declare const describeCustomerMetadata: API.OperationMethod<DescribeCustomerMetadataRequest & RegionInput, DescribeCustomerMetadataResponse, DescribeCustomerMetadataError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewayAssociationProposalsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Describes one or more association proposals for connection between a virtual private gateway or transit gateway and a Direct Connect gateway.
 */
export declare const describeDirectConnectGatewayAssociationProposals: API.OperationMethod<DescribeDirectConnectGatewayAssociationProposalsRequest & RegionInput, DescribeDirectConnectGatewayAssociationProposalsResult, DescribeDirectConnectGatewayAssociationProposalsError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewayAssociationsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the associations between your Direct Connect gateways and virtual private gateways and transit gateways. You must specify one of the following:
 *
 * - A Direct Connect gateway
 *
 * The response contains all virtual private gateways and transit gateways associated with the Direct Connect gateway.
 *
 * - A virtual private gateway
 *
 * The response contains the Direct Connect gateway.
 *
 * - A transit gateway
 *
 * The response contains the Direct Connect gateway.
 *
 * - A Direct Connect gateway and a virtual private gateway
 *
 * The response contains the association between the Direct Connect gateway and virtual private gateway.
 *
 * - A Direct Connect gateway and a transit gateway
 *
 * The response contains the association between the Direct Connect gateway and transit gateway.
 *
 * - A Direct Connect gateway and a virtual private gateway
 *
 * The response contains the association between the Direct Connect gateway and virtual private gateway.
 *
 * - A Direct Connect gateway association to a Cloud WAN core network
 *
 * The response contains the Cloud WAN core network ID that the Direct Connect gateway is associated to.
 */
export declare const describeDirectConnectGatewayAssociations: API.OperationMethod<DescribeDirectConnectGatewayAssociationsRequest & RegionInput, DescribeDirectConnectGatewayAssociationsResult, DescribeDirectConnectGatewayAssociationsError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewayAttachmentsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the attachments between your Direct Connect gateways and virtual interfaces. You must specify
 * a Direct Connect gateway, a virtual interface, or both. If you specify a Direct Connect gateway, the response contains
 * all virtual interfaces attached to the Direct Connect gateway. If you specify a virtual interface, the
 * response contains all Direct Connect gateways attached to the virtual interface. If you specify both,
 * the response contains the attachment between the Direct Connect gateway and the virtual interface.
 */
export declare const describeDirectConnectGatewayAttachments: API.OperationMethod<DescribeDirectConnectGatewayAttachmentsRequest & RegionInput, DescribeDirectConnectGatewayAttachmentsResult, DescribeDirectConnectGatewayAttachmentsError, Credentials | HttpClient.HttpClient>;
export type DescribeDirectConnectGatewaysError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists all your Direct Connect gateways or only the specified Direct Connect gateway. Deleted Direct Connect gateways are not returned.
 */
export declare const describeDirectConnectGateways: API.OperationMethod<DescribeDirectConnectGatewaysRequest & RegionInput, DescribeDirectConnectGatewaysResult, DescribeDirectConnectGatewaysError, Credentials | HttpClient.HttpClient>;
export type DescribeHostedConnectionsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the hosted connections that have been provisioned on the specified
 * interconnect or link aggregation group (LAG).
 *
 * Intended for use by Direct Connect Partners only.
 */
export declare const describeHostedConnections: API.OperationMethod<DescribeHostedConnectionsRequest & RegionInput, Connections, DescribeHostedConnectionsError, Credentials | HttpClient.HttpClient>;
export type DescribeInterconnectLoaError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use DescribeLoa instead.
 *
 * Gets the LOA-CFA for the specified interconnect.
 *
 * The Letter of Authorization - Connecting Facility Assignment (LOA-CFA) is a document that is used when establishing your cross connect to Amazon Web Services at the colocation facility.
 * For more information, see Requesting Cross Connects at Direct Connect Locations
 * in the *Direct Connect User Guide*.
 */
export declare const describeInterconnectLoa: API.OperationMethod<DescribeInterconnectLoaRequest & RegionInput, DescribeInterconnectLoaResponse, DescribeInterconnectLoaError, Credentials | HttpClient.HttpClient>;
export type DescribeInterconnectsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the interconnects owned by the Amazon Web Services account or only the specified interconnect.
 */
export declare const describeInterconnects: API.OperationMethod<DescribeInterconnectsRequest & RegionInput, Interconnects, DescribeInterconnectsError, Credentials | HttpClient.HttpClient>;
export type DescribeLagsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Describes all your link aggregation groups (LAG) or the specified LAG.
 */
export declare const describeLags: API.OperationMethod<DescribeLagsRequest & RegionInput, Lags, DescribeLagsError, Credentials | HttpClient.HttpClient>;
export type DescribeLoaError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Gets the LOA-CFA for a connection, interconnect, or link aggregation group (LAG).
 *
 * The Letter of Authorization - Connecting Facility Assignment (LOA-CFA) is a document that is used when establishing
 * your cross connect to Amazon Web Services at the colocation facility. For more information, see Requesting Cross Connects at Direct Connect Locations
 * in the *Direct Connect User Guide*.
 */
export declare const describeLoa: API.OperationMethod<DescribeLoaRequest & RegionInput, Loa, DescribeLoaError, Credentials | HttpClient.HttpClient>;
export type DescribeLocationsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the Direct Connect locations in the current Amazon Web Services Region. These are the locations that can be selected when calling
 * CreateConnection or CreateInterconnect.
 */
export declare const describeLocations: API.OperationMethod<DescribeLocationsRequest & RegionInput, Locations, DescribeLocationsError, Credentials | HttpClient.HttpClient>;
export type DescribeRouterConfigurationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Details about the router.
 */
export declare const describeRouterConfiguration: API.OperationMethod<DescribeRouterConfigurationRequest & RegionInput, DescribeRouterConfigurationResponse, DescribeRouterConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeTagsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Describes the tags associated with the specified Direct Connect resources.
 */
export declare const describeTags: API.OperationMethod<DescribeTagsRequest & RegionInput, DescribeTagsResponse, DescribeTagsError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualGatewaysError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Deprecated. Use `DescribeVpnGateways` instead. See DescribeVPNGateways in the *Amazon Elastic Compute Cloud API Reference*.
 *
 * Lists the virtual private gateways owned by the Amazon Web Services account.
 *
 * You can create one or more Direct Connect private virtual interfaces linked to a virtual private gateway.
 */
export declare const describeVirtualGateways: API.OperationMethod<DescribeVirtualGatewaysRequest & RegionInput, VirtualGateways, DescribeVirtualGatewaysError, Credentials | HttpClient.HttpClient>;
export type DescribeVirtualInterfacesError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Displays all virtual interfaces for an Amazon Web Services account. Virtual interfaces deleted fewer
 * than 15 minutes before you make the request are also returned. If you specify a
 * connection ID, only the virtual interfaces associated with the connection are returned.
 * If you specify a virtual interface ID, then only a single virtual interface is returned.
 *
 * A virtual interface (VLAN) transmits the traffic between the Direct Connect location and the customer network.
 *
 * - If you're using an `asn`, the response includes the ASN value in both the `asn` and `asnLong` fields.
 *
 * - If you're using `asnLong`, the response returns a value of `0` (zero) for the `asn` attribute because it exceeds the highest ASN value of 2,147,483,647 that it can support
 */
export declare const describeVirtualInterfaces: API.OperationMethod<DescribeVirtualInterfacesRequest & RegionInput, VirtualInterfaces, DescribeVirtualInterfacesError, Credentials | HttpClient.HttpClient>;
export type DisassociateConnectionFromLagError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Disassociates a connection from a link aggregation group (LAG). The connection is
 * interrupted and re-established as a standalone connection (the connection is not
 * deleted; to delete the connection, use the DeleteConnection request).
 * If the LAG has associated virtual interfaces or hosted connections, they remain
 * associated with the LAG. A disassociated connection owned by an Direct Connect Partner is
 * automatically converted to an interconnect.
 *
 * If disassociating the connection would cause the LAG to fall below its setting for
 * minimum number of operational connections, the request fails, except when it's the last
 * member of the LAG. If all connections are disassociated, the LAG continues to exist as
 * an empty LAG with no physical connections.
 */
export declare const disassociateConnectionFromLag: API.OperationMethod<DisassociateConnectionFromLagRequest & RegionInput, Connection, DisassociateConnectionFromLagError, Credentials | HttpClient.HttpClient>;
export type DisassociateConnectionsFromResiliencyGroupError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Disassociates one or more connections from the specified resiliency group. This operation
 * is atomic: either all of the specified connections are disassociated, or the operation fails
 * and no changes are made.
 */
export declare const disassociateConnectionsFromResiliencyGroup: API.OperationMethod<DisassociateConnectionsFromResiliencyGroupRequest & RegionInput, DisassociateConnectionsFromResiliencyGroupResult, DisassociateConnectionsFromResiliencyGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateMacSecKeyError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Removes the association between a MAC Security (MACsec) security key and a Direct Connect connection.
 */
export declare const disassociateMacSecKey: API.OperationMethod<DisassociateMacSecKeyRequest & RegionInput, DisassociateMacSecKeyResponse, DisassociateMacSecKeyError, Credentials | HttpClient.HttpClient>;
export type GetResiliencyGroupError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Gets information about the specified resiliency group.
 */
export declare const getResiliencyGroup: API.OperationMethod<GetResiliencyGroupRequest & RegionInput, GetResiliencyGroupResult, GetResiliencyGroupError, Credentials | HttpClient.HttpClient>;
export type ListResiliencyGroupAssociationsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the connection associations for the specified resiliency group.
 */
export declare const listResiliencyGroupAssociations: API.OperationMethod<ListResiliencyGroupAssociationsRequest & RegionInput, ListResiliencyGroupAssociationsResult, ListResiliencyGroupAssociationsError, Credentials | HttpClient.HttpClient>;
export type ListResiliencyGroupsError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the resiliency groups owned by your Amazon Web Services account in the current
 * Amazon Web Services Region.
 */
export declare const listResiliencyGroups: API.OperationMethod<ListResiliencyGroupsRequest & RegionInput, ListResiliencyGroupsResult, ListResiliencyGroupsError, Credentials | HttpClient.HttpClient>;
export type ListVirtualInterfaceRoutesError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the routes for the specified virtual interface.
 *
 * Use the `routeDirection` filter to control which routes are returned:
 *
 * - `accepted`: routes received from the customer network over the virtual interface.
 *
 * - `advertised`: routes advertised to the customer network over the virtual interface.
 */
export declare const listVirtualInterfaceRoutes: API.OperationMethod<ListVirtualInterfaceRoutesRequest & RegionInput, ListVirtualInterfaceRoutesResponse, ListVirtualInterfaceRoutesError, Credentials | HttpClient.HttpClient>;
export type ListVirtualInterfaceTestHistoryError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Lists the virtual interface failover test history.
 */
export declare const listVirtualInterfaceTestHistory: API.OperationMethod<ListVirtualInterfaceTestHistoryRequest & RegionInput, ListVirtualInterfaceTestHistoryResponse, ListVirtualInterfaceTestHistoryError, Credentials | HttpClient.HttpClient>;
export type StartBgpFailoverTestError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Starts the virtual interface failover test that verifies your configuration meets your resiliency requirements by placing the BGP peering session in the DOWN state. You can then send traffic to verify that there are no outages.
 *
 * You can run the test on public, private, transit, and hosted virtual interfaces.
 *
 * You can use ListVirtualInterfaceTestHistory to view the virtual interface test history.
 *
 * If you need to stop the test before the test interval completes, use StopBgpFailoverTest.
 */
export declare const startBgpFailoverTest: API.OperationMethod<StartBgpFailoverTestRequest & RegionInput, StartBgpFailoverTestResponse, StartBgpFailoverTestError, Credentials | HttpClient.HttpClient>;
export type StopBgpFailoverTestError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Stops the virtual interface failover test.
 */
export declare const stopBgpFailoverTest: API.OperationMethod<StopBgpFailoverTestRequest & RegionInput, StopBgpFailoverTestResponse, StopBgpFailoverTestError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = DirectConnectClientException | DirectConnectServerException | DuplicateTagKeysException | TooManyTagsException | CommonErrors;
/**
 * Adds the specified tags to the specified Direct Connect resource. Each resource can have a maximum of 50 tags.
 *
 * Each tag consists of a key and an optional value. If a tag with the same key is already associated with the resource, this action updates its value.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Removes one or more tags from the specified Direct Connect resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the Direct Connect connection configuration.
 *
 * You can update the following parameters for a connection:
 *
 * - The connection name
 *
 * - The connection's MAC Security (MACsec) encryption mode.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest & RegionInput, Connection, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionsBillingModeError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the billing mode for the specified Direct Connect connections. You can update the billing
 * mode for up to 200 connections in a single request.
 */
export declare const updateConnectionsBillingMode: API.OperationMethod<UpdateConnectionsBillingModeRequest & RegionInput, UpdateConnectionsBillingModeResponse, UpdateConnectionsBillingModeError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectConnectGatewayError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the name of a current Direct Connect gateway.
 */
export declare const updateDirectConnectGateway: API.OperationMethod<UpdateDirectConnectGatewayRequest & RegionInput, UpdateDirectConnectGatewayResponse, UpdateDirectConnectGatewayError, Credentials | HttpClient.HttpClient>;
export type UpdateDirectConnectGatewayAssociationError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the specified attributes of the Direct Connect gateway association.
 *
 * Add or remove prefixes from the association.
 */
export declare const updateDirectConnectGatewayAssociation: API.OperationMethod<UpdateDirectConnectGatewayAssociationRequest & RegionInput, UpdateDirectConnectGatewayAssociationResult, UpdateDirectConnectGatewayAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateLagError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the attributes of the specified link aggregation group (LAG).
 *
 * You can update the following LAG attributes:
 *
 * - The name of the LAG.
 *
 * - The value for the minimum number of connections that must be operational
 * for the LAG itself to be operational.
 *
 * - The LAG's MACsec encryption mode.
 *
 * Amazon Web Services assigns this value to each connection which is part of the LAG.
 *
 * - The tags
 *
 * If you adjust the threshold value for the minimum number of operational connections, ensure
 * that the new value does not cause the LAG to fall below the threshold and become
 * non-operational.
 */
export declare const updateLag: API.OperationMethod<UpdateLagRequest & RegionInput, Lag, UpdateLagError, Credentials | HttpClient.HttpClient>;
export type UpdateResiliencyGroupError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the name of the specified resiliency group.
 */
export declare const updateResiliencyGroup: API.OperationMethod<UpdateResiliencyGroupRequest & RegionInput, UpdateResiliencyGroupResult, UpdateResiliencyGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateVirtualInterfaceAttributesError = DirectConnectClientException | DirectConnectServerException | CommonErrors;
/**
 * Updates the specified attributes of the specified virtual private interface.
 *
 * Setting the MTU of a virtual interface to 8500 (jumbo frames) can cause an update to
 * the underlying physical connection if it wasn't updated to support jumbo frames. Updating
 * the connection disrupts network connectivity for all virtual interfaces associated with
 * the connection for up to 30 seconds. To check whether your connection supports jumbo
 * frames, call DescribeConnections. To check whether your virtual
 * interface supports jumbo frames, call DescribeVirtualInterfaces.
 */
export declare const updateVirtualInterfaceAttributes: API.OperationMethod<UpdateVirtualInterfaceAttributesRequest & RegionInput, VirtualInterface, UpdateVirtualInterfaceAttributesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=direct-connect.d.ts.map