import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly errorCode: any;
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly errorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly errorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly errorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly errorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly errorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export type FileSystemId = string;
export type Uid = number;
export type Gid = number;
export type SecondaryGids = number[];
export interface PosixUser {
    uid: number;
    gid: number;
    secondaryGids?: number[] | undefined;
}
export type Path = string;
export type OwnerUid = number;
export type OwnerGid = number;
export type Permissions = string;
export interface CreationPermissions {
    ownerUid: number;
    ownerGid: number;
    permissions: string;
}
export interface RootDirectory {
    path?: string | undefined;
    creationPermissions?: CreationPermissions | undefined;
}
export interface CreateAccessPointRequest {
    clientToken?: string | undefined;
    tags?: Tag[] | undefined;
    fileSystemId: string;
    posixUser?: PosixUser | undefined;
    rootDirectory?: RootDirectory | undefined;
}
export type AccessPointArn = string;
export type AccessPointId = string;
export type LifeCycleState = "available" | "creating" | "deleting" | "deleted" | "error" | "updating" | "misconfigured" | (string & {});
export type AwsAccountId = string;
export interface CreateAccessPointResponse {
    accessPointArn: string;
    accessPointId: string;
    clientToken: string;
    fileSystemId: string;
    status: LifeCycleState;
    ownerId: string;
    posixUser?: PosixUser | undefined;
    rootDirectory?: RootDirectory | undefined;
    tags?: Tag[] | undefined;
    name?: string | undefined;
}
export type BucketArn = string;
export type CreationToken = string;
export type KmsKeyId = string;
export type RoleArn = string;
export interface CreateFileSystemRequest {
    bucket: string;
    prefix?: string | undefined;
    clientToken?: string | undefined;
    kmsKeyId?: string | undefined;
    roleArn: string;
    tags?: Tag[] | undefined;
    acceptBucketWarning?: boolean | undefined;
}
export type FileSystemArn = string;
export type StatusMessage = string;
export interface CreateFileSystemResponse {
    creationTime?: Date | undefined;
    fileSystemArn?: string | undefined;
    fileSystemId?: string | undefined;
    bucket?: string | undefined;
    prefix?: string | undefined;
    clientToken?: string | undefined;
    kmsKeyId?: string | undefined;
    status?: LifeCycleState | undefined;
    statusMessage?: string | undefined;
    roleArn?: string | undefined;
    ownerId?: string | undefined;
    tags?: Tag[] | undefined;
    name?: string | undefined;
}
export type SubnetId = string;
export type Ipv4Address = string;
export type Ipv6Address = string;
export type IpAddressType = "IPV4_ONLY" | "IPV6_ONLY" | "DUAL_STACK" | (string & {});
export type SecurityGroup = string;
export type SecurityGroups = string[];
export interface CreateMountTargetRequest {
    fileSystemId: string;
    subnetId: string;
    ipv4Address?: string | undefined;
    ipv6Address?: string | undefined;
    ipAddressType?: IpAddressType | undefined;
    securityGroups?: string[] | undefined;
}
export type AvailabilityZoneId = string;
export type MountTargetId = string;
export type NetworkInterfaceId = string;
export type VpcId = string;
export interface CreateMountTargetResponse {
    availabilityZoneId?: string | undefined;
    ownerId: string;
    mountTargetId: string;
    fileSystemId?: string | undefined;
    subnetId: string;
    ipv4Address?: string | undefined;
    ipv6Address?: string | undefined;
    networkInterfaceId?: string | undefined;
    vpcId?: string | undefined;
    securityGroups?: string[] | undefined;
    status?: LifeCycleState | undefined;
    statusMessage?: string | undefined;
}
export interface DeleteAccessPointRequest {
    accessPointId: string;
}
export interface DeleteAccessPointResponse {
}
export interface DeleteFileSystemRequest {
    fileSystemId: string;
    forceDelete?: boolean | undefined;
}
export interface DeleteFileSystemResponse {
}
export interface DeleteFileSystemPolicyRequest {
    fileSystemId: string;
}
export interface DeleteFileSystemPolicyResponse {
}
export interface DeleteMountTargetRequest {
    mountTargetId: string;
}
export interface DeleteMountTargetResponse {
}
export interface GetAccessPointRequest {
    accessPointId: string;
}
export interface GetAccessPointResponse {
    accessPointArn: string;
    accessPointId: string;
    clientToken: string;
    fileSystemId: string;
    status: LifeCycleState;
    ownerId: string;
    posixUser?: PosixUser | undefined;
    rootDirectory?: RootDirectory | undefined;
    tags?: Tag[] | undefined;
    name?: string | undefined;
}
export interface GetFileSystemRequest {
    fileSystemId: string;
}
export interface GetFileSystemResponse {
    creationTime?: Date | undefined;
    fileSystemArn?: string | undefined;
    fileSystemId?: string | undefined;
    bucket?: string | undefined;
    prefix?: string | undefined;
    clientToken?: string | undefined;
    kmsKeyId?: string | undefined;
    status?: LifeCycleState | undefined;
    statusMessage?: string | undefined;
    roleArn?: string | undefined;
    ownerId?: string | undefined;
    tags?: Tag[] | undefined;
    name?: string | undefined;
}
export interface GetFileSystemPolicyRequest {
    fileSystemId: string;
}
export interface GetFileSystemPolicyResponse {
    fileSystemId: string;
    policy: string;
}
export interface GetMountTargetRequest {
    mountTargetId: string;
}
export interface GetMountTargetResponse {
    availabilityZoneId?: string | undefined;
    ownerId: string;
    mountTargetId: string;
    fileSystemId?: string | undefined;
    subnetId: string;
    ipv4Address?: string | undefined;
    ipv6Address?: string | undefined;
    networkInterfaceId?: string | undefined;
    vpcId?: string | undefined;
    securityGroups?: string[] | undefined;
    status?: LifeCycleState | undefined;
    statusMessage?: string | undefined;
}
export interface GetSynchronizationConfigurationRequest {
    fileSystemId: string;
}
export type ImportTrigger = "ON_DIRECTORY_FIRST_ACCESS" | "ON_FILE_ACCESS" | (string & {});
export interface ImportDataRule {
    prefix: string;
    trigger: ImportTrigger;
    sizeLessThan: number;
}
export type ImportDataRuleList = ImportDataRule[];
export interface ExpirationDataRule {
    daysAfterLastAccess: number;
}
export type ExpirationDataRuleList = ExpirationDataRule[];
export interface GetSynchronizationConfigurationResponse {
    latestVersionNumber?: number | undefined;
    importDataRules: ImportDataRule[];
    expirationDataRules: ExpirationDataRule[];
}
export interface ListAccessPointsRequest {
    fileSystemId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListAccessPointsDescription {
    accessPointArn: string;
    accessPointId: string;
    fileSystemId: string;
    status: LifeCycleState;
    ownerId: string;
    posixUser?: PosixUser | undefined;
    rootDirectory?: RootDirectory | undefined;
    name?: string | undefined;
}
export type AccessPoints = ListAccessPointsDescription[];
export interface ListAccessPointsResponse {
    nextToken?: string | undefined;
    accessPoints: ListAccessPointsDescription[];
}
export interface ListFileSystemsRequest {
    bucket?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListFileSystemsDescription {
    creationTime: Date;
    fileSystemArn: string;
    fileSystemId: string;
    name?: string | undefined;
    bucket: string;
    status: LifeCycleState;
    statusMessage?: string | undefined;
    roleArn: string;
    ownerId: string;
}
export type FileSystems = ListFileSystemsDescription[];
export interface ListFileSystemsResponse {
    nextToken?: string | undefined;
    fileSystems: ListFileSystemsDescription[];
}
export interface ListMountTargetsRequest {
    fileSystemId?: string | undefined;
    accessPointId?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListMountTargetsDescription {
    availabilityZoneId?: string | undefined;
    fileSystemId?: string | undefined;
    ipv4Address?: string | undefined;
    ipv6Address?: string | undefined;
    status?: LifeCycleState | undefined;
    statusMessage?: string | undefined;
    mountTargetId: string;
    networkInterfaceId?: string | undefined;
    ownerId: string;
    subnetId: string;
    vpcId?: string | undefined;
}
export type MountTargets = ListMountTargetsDescription[];
export interface ListMountTargetsResponse {
    nextToken?: string | undefined;
    mountTargets: ListMountTargetsDescription[];
}
export type ResourceId = string;
export interface ListTagsForResourceRequest {
    resourceId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
    nextToken?: string | undefined;
}
export interface PutFileSystemPolicyRequest {
    fileSystemId: string;
    policy: string;
}
export interface PutFileSystemPolicyResponse {
}
export interface PutSynchronizationConfigurationRequest {
    fileSystemId: string;
    latestVersionNumber?: number | undefined;
    importDataRules: ImportDataRule[];
    expirationDataRules: ExpirationDataRule[];
}
export interface PutSynchronizationConfigurationResponse {
}
export interface TagResourceRequest {
    resourceId: string;
    tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceId: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateMountTargetRequest {
    mountTargetId: string;
    securityGroups: string[];
}
export interface UpdateMountTargetResponse {
    availabilityZoneId?: string | undefined;
    ownerId: string;
    mountTargetId: string;
    fileSystemId?: string | undefined;
    subnetId: string;
    ipv4Address?: string | undefined;
    ipv6Address?: string | undefined;
    networkInterfaceId?: string | undefined;
    vpcId?: string | undefined;
    securityGroups?: string[] | undefined;
    status?: LifeCycleState | undefined;
    statusMessage?: string | undefined;
}
export type ErrorCode = string;
export type CreateAccessPointError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates an S3 File System Access Point for application-specific access with POSIX user identity and root directory enforcement. Access points provide a way to manage access to shared datasets in multi-tenant scenarios.
 */
export declare const createAccessPoint: API.OperationMethod<CreateAccessPointRequest & RegionInput, CreateAccessPointResponse, CreateAccessPointError, Credentials | HttpClient.HttpClient>;
export type CreateFileSystemError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates an S3 File System resource scoped to a bucket or prefix within a bucket, enabling file system access to S3 data. To create a file system, you need an S3 bucket and an IAM role that grants the service permission to access the bucket.
 */
export declare const createFileSystem: API.OperationMethod<CreateFileSystemRequest & RegionInput, CreateFileSystemResponse, CreateFileSystemError, Credentials | HttpClient.HttpClient>;
export type CreateMountTargetError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates a mount target resource as an endpoint for mounting the S3 File System from compute resources in a specific Availability Zone and VPC. Mount targets provide network access to the file system.
 */
export declare const createMountTarget: API.OperationMethod<CreateMountTargetRequest & RegionInput, CreateMountTargetResponse, CreateMountTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessPointError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes an S3 File System Access Point. This operation is irreversible.
 */
export declare const deleteAccessPoint: API.OperationMethod<DeleteAccessPointRequest & RegionInput, DeleteAccessPointResponse, DeleteAccessPointError, Credentials | HttpClient.HttpClient>;
export type DeleteFileSystemError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes an S3 File System. You can optionally force deletion of a file system that has pending export data.
 */
export declare const deleteFileSystem: API.OperationMethod<DeleteFileSystemRequest & RegionInput, DeleteFileSystemResponse, DeleteFileSystemError, Credentials | HttpClient.HttpClient>;
export type DeleteFileSystemPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the IAM resource policy of an S3 File System.
 */
export declare const deleteFileSystemPolicy: API.OperationMethod<DeleteFileSystemPolicyRequest & RegionInput, DeleteFileSystemPolicyResponse, DeleteFileSystemPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteMountTargetError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified mount target. This operation is irreversible.
 */
export declare const deleteMountTarget: API.OperationMethod<DeleteMountTargetRequest & RegionInput, DeleteMountTargetResponse, DeleteMountTargetError, Credentials | HttpClient.HttpClient>;
export type GetAccessPointError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns resource information for an S3 File System Access Point.
 */
export declare const getAccessPoint: API.OperationMethod<GetAccessPointRequest & RegionInput, GetAccessPointResponse, GetAccessPointError, Credentials | HttpClient.HttpClient>;
export type GetFileSystemError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns resource information for the specified S3 File System including status, configuration, and metadata.
 */
export declare const getFileSystem: API.OperationMethod<GetFileSystemRequest & RegionInput, GetFileSystemResponse, GetFileSystemError, Credentials | HttpClient.HttpClient>;
export type GetFileSystemPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns the IAM resource policy of an S3 File System.
 */
export declare const getFileSystemPolicy: API.OperationMethod<GetFileSystemPolicyRequest & RegionInput, GetFileSystemPolicyResponse, GetFileSystemPolicyError, Credentials | HttpClient.HttpClient>;
export type GetMountTargetError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns detailed resource information for the specified mount target including network configuration.
 */
export declare const getMountTarget: API.OperationMethod<GetMountTargetRequest & RegionInput, GetMountTargetResponse, GetMountTargetError, Credentials | HttpClient.HttpClient>;
export type GetSynchronizationConfigurationError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns the synchronization configuration for the specified S3 File System, including import data rules and expiration data rules.
 */
export declare const getSynchronizationConfiguration: API.OperationMethod<GetSynchronizationConfigurationRequest & RegionInput, GetSynchronizationConfigurationResponse, GetSynchronizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAccessPointsError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns resource information for all S3 File System Access Points associated with the specified S3 File System.
 */
export declare const listAccessPoints: API.PaginatedOperationMethod<ListAccessPointsRequest & RegionInput, ListAccessPointsResponse, ListAccessPointsError, Credentials | HttpClient.HttpClient, ListAccessPointsDescription>;
export type ListFileSystemsError = InternalServerException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all S3 File Systems owned by the account with optional filtering by bucket.
 */
export declare const listFileSystems: API.PaginatedOperationMethod<ListFileSystemsRequest & RegionInput, ListFileSystemsResponse, ListFileSystemsError, Credentials | HttpClient.HttpClient, ListFileSystemsDescription>;
export type ListMountTargetsError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Returns resource information for all mount targets with optional filtering by file system, access point, and VPC.
 */
export declare const listMountTargets: API.PaginatedOperationMethod<ListMountTargetsRequest & RegionInput, ListMountTargetsResponse, ListMountTargetsError, Credentials | HttpClient.HttpClient, ListMountTargetsDescription>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Lists all tags for S3 Files resources.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type PutFileSystemPolicyError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates or replaces the IAM resource policy for an S3 File System to control access permissions.
 */
export declare const putFileSystemPolicy: API.OperationMethod<PutFileSystemPolicyRequest & RegionInput, PutFileSystemPolicyResponse, PutFileSystemPolicyError, Credentials | HttpClient.HttpClient>;
export type PutSynchronizationConfigurationError = ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates or updates the synchronization configuration for the specified S3 File System, including import data rules and expiration data rules.
 */
export declare const putSynchronizationConfiguration: API.OperationMethod<PutSynchronizationConfigurationRequest & RegionInput, PutSynchronizationConfigurationResponse, PutSynchronizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Creates tags for S3 Files resources using standard Amazon Web Services tagging APIs.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Removes tags from S3 Files resources.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMountTargetError = InternalServerException | ResourceNotFoundException | ValidationException | ThrottlingException | CommonErrors;
/**
 * Updates the mount target resource, specifically security group configurations.
 */
export declare const updateMountTarget: API.OperationMethod<UpdateMountTargetRequest & RegionInput, UpdateMountTargetResponse, UpdateMountTargetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=s3files.d.ts.map