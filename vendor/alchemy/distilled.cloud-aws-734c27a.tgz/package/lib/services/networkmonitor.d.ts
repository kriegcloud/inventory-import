import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceName = string;
export type Arn = string;
export type Destination = string;
export type Port = number;
export type Protocol = "TCP" | "ICMP" | (string & {});
export type PacketSize = number;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateMonitorProbeInput {
    sourceArn: string;
    destination: string;
    destinationPort?: number | undefined;
    protocol: Protocol;
    packetSize?: number | undefined;
    probeTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CreateMonitorProbeInputList = CreateMonitorProbeInput[];
export type AggregationPeriod = number;
export interface CreateMonitorInput {
    monitorName: string;
    probes?: CreateMonitorProbeInput[] | undefined;
    aggregationPeriod?: number | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MonitorArn = string;
export type MonitorState = "PENDING" | "ACTIVE" | "INACTIVE" | "ERROR" | "DELETING" | (string & {});
export interface CreateMonitorOutput {
    monitorArn: string;
    monitorName: string;
    state: MonitorState;
    aggregationPeriod?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ProbeInput {
    sourceArn: string;
    destination: string;
    destinationPort?: number | undefined;
    protocol: Protocol;
    packetSize?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateProbeInput {
    monitorName: string;
    probe: ProbeInput;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProbeId = string;
export type AddressFamily = "IPV4" | "IPV6" | (string & {});
export type VpcId = string;
export type ProbeState = "PENDING" | "ACTIVE" | "INACTIVE" | "ERROR" | "DELETING" | "DELETED" | (string & {});
export type Iso8601Timestamp = Date;
export interface CreateProbeOutput {
    probeId?: string | undefined;
    probeArn?: string | undefined;
    sourceArn: string;
    destination: string;
    destinationPort?: number | undefined;
    protocol: Protocol;
    packetSize?: number | undefined;
    addressFamily?: AddressFamily | undefined;
    vpcId?: string | undefined;
    state?: ProbeState | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DeleteMonitorInput {
    monitorName: string;
}
export interface DeleteMonitorOutput {
}
export interface DeleteProbeInput {
    monitorName: string;
    probeId: string;
}
export interface DeleteProbeOutput {
}
export interface GetMonitorInput {
    monitorName: string;
}
export interface Probe {
    probeId?: string | undefined;
    probeArn?: string | undefined;
    sourceArn: string;
    destination: string;
    destinationPort?: number | undefined;
    protocol: Protocol;
    packetSize?: number | undefined;
    addressFamily?: AddressFamily | undefined;
    vpcId?: string | undefined;
    state?: ProbeState | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ProbeList = Probe[];
export interface GetMonitorOutput {
    monitorArn: string;
    monitorName: string;
    state: MonitorState;
    aggregationPeriod: number;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    probes?: Probe[] | undefined;
    createdAt: Date;
    modifiedAt: Date;
}
export interface GetProbeInput {
    monitorName: string;
    probeId: string;
}
export interface GetProbeOutput {
    probeId?: string | undefined;
    probeArn?: string | undefined;
    sourceArn: string;
    destination: string;
    destinationPort?: number | undefined;
    protocol: Protocol;
    packetSize?: number | undefined;
    addressFamily?: AddressFamily | undefined;
    vpcId?: string | undefined;
    state?: ProbeState | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListMonitorsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    state?: string | undefined;
}
export interface MonitorSummary {
    monitorArn: string;
    monitorName: string;
    state: MonitorState;
    aggregationPeriod?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MonitorList = MonitorSummary[];
export interface ListMonitorsOutput {
    monitors: MonitorSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceInput {
    resourceArn: string;
}
export interface ListTagsForResourceOutput {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceInput {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateMonitorInput {
    monitorName: string;
    aggregationPeriod: number;
}
export interface UpdateMonitorOutput {
    monitorArn: string;
    monitorName: string;
    state: MonitorState;
    aggregationPeriod?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateProbeInput {
    monitorName: string;
    probeId: string;
    state?: ProbeState | undefined;
    destination?: string | undefined;
    destinationPort?: number | undefined;
    protocol?: Protocol | undefined;
    packetSize?: number | undefined;
}
export interface UpdateProbeOutput {
    probeId?: string | undefined;
    probeArn?: string | undefined;
    sourceArn: string;
    destination: string;
    destinationPort?: number | undefined;
    protocol: Protocol;
    packetSize?: number | undefined;
    addressFamily?: AddressFamily | undefined;
    vpcId?: string | undefined;
    state?: ProbeState | undefined;
    createdAt?: Date | undefined;
    modifiedAt?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type CreateMonitorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a monitor between a source subnet and destination IP address. Within a monitor you'll create one or more probes that monitor network traffic between your source Amazon Web Services VPC subnets and your destination IP addresses. Each probe then aggregates and sends metrics to Amazon CloudWatch.
 *
 * You can also create a monitor with probes using this command. For each probe, you
 * define the following:
 *
 * - `source`--The subnet IDs where the probes will be created.
 *
 * - `destination`-- The target destination IP address for the
 * probe.
 *
 * - `destinationPort`--Required only if the protocol is
 * `TCP`.
 *
 * - `protocol`--The communication protocol between the source and
 * destination. This will be either `TCP` or `ICMP`.
 *
 * - `packetSize`--The size of the packets. This must be a number between
 * `56` and `8500`.
 *
 * - (Optional) `tags` --Key-value pairs created and assigned to the
 * probe.
 */
export declare const createMonitor: API.OperationMethod<CreateMonitorInput & RegionInput, CreateMonitorOutput, CreateMonitorError, Credentials | HttpClient.HttpClient>;
export type CreateProbeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a probe within a monitor. Once you create a probe, and it begins monitoring your
 * network traffic, you'll incur billing charges for that probe. This action requires the
 * `monitorName` parameter. Run `ListMonitors` to get a list of
 * monitor names. Note the name of the `monitorName` you want to create the
 * probe for.
 */
export declare const createProbe: API.OperationMethod<CreateProbeInput & RegionInput, CreateProbeOutput, CreateProbeError, Credentials | HttpClient.HttpClient>;
export type DeleteMonitorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified monitor.
 *
 * This action requires the `monitorName` parameter. Run
 * `ListMonitors` to get a list of monitor names.
 */
export declare const deleteMonitor: API.OperationMethod<DeleteMonitorInput & RegionInput, DeleteMonitorOutput, DeleteMonitorError, Credentials | HttpClient.HttpClient>;
export type DeleteProbeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified probe. Once a probe is deleted you'll no longer incur any billing
 * fees for that probe.
 *
 * This action requires both the `monitorName` and `probeId`
 * parameters. Run `ListMonitors` to get a list of monitor names. Run
 * `GetMonitor` to get a list of probes and probe IDs. You can only delete a
 * single probe at a time using this action.
 */
export declare const deleteProbe: API.OperationMethod<DeleteProbeInput & RegionInput, DeleteProbeOutput, DeleteProbeError, Credentials | HttpClient.HttpClient>;
export type GetMonitorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about a specific monitor.
 *
 * This action requires the `monitorName` parameter. Run
 * `ListMonitors` to get a list of monitor names.
 */
export declare const getMonitor: API.OperationMethod<GetMonitorInput & RegionInput, GetMonitorOutput, GetMonitorError, Credentials | HttpClient.HttpClient>;
export type GetProbeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details about a probe. This action requires both the
 * `monitorName` and `probeId` parameters. Run
 * `ListMonitors` to get a list of monitor names. Run
 * `GetMonitor` to get a list of probes and probe IDs.
 */
export declare const getProbe: API.OperationMethod<GetProbeInput & RegionInput, GetProbeOutput, GetProbeError, Credentials | HttpClient.HttpClient>;
export type ListMonitorsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all of your monitors.
 */
export declare const listMonitors: API.PaginatedOperationMethod<ListMonitorsInput & RegionInput, ListMonitorsOutput, ListMonitorsError, Credentials | HttpClient.HttpClient, MonitorSummary>;
export type ListTagsForResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags assigned to this resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds key-value pairs to a monitor or probe.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a key-value pair from a monitor or probe.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateMonitorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the `aggregationPeriod` for a monitor. Monitors support an
 * `aggregationPeriod` of either `30` or `60` seconds.
 * This action requires the `monitorName` and `probeId` parameter.
 * Run `ListMonitors` to get a list of monitor names.
 */
export declare const updateMonitor: API.OperationMethod<UpdateMonitorInput & RegionInput, UpdateMonitorOutput, UpdateMonitorError, Credentials | HttpClient.HttpClient>;
export type UpdateProbeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a monitor probe. This action requires both the `monitorName` and `probeId` parameters. Run `ListMonitors` to get a list of monitor names. Run `GetMonitor` to get a list of probes and probe IDs.
 *
 * You can update the following para create a monitor with probes using this command. For
 * each probe, you define the following:
 *
 * - `state`--The state of the probe.
 *
 * - `destination`-- The target destination IP address for the
 * probe.
 *
 * - `destinationPort`--Required only if the protocol is
 * `TCP`.
 *
 * - `protocol`--The communication protocol between the source and
 * destination. This will be either `TCP` or `ICMP`.
 *
 * - `packetSize`--The size of the packets. This must be a number between
 * `56` and `8500`.
 *
 * - (Optional) `tags` --Key-value pairs created and assigned to the
 * probe.
 */
export declare const updateProbe: API.OperationMethod<UpdateProbeInput & RegionInput, UpdateProbeOutput, UpdateProbeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=networkmonitor.d.ts.map