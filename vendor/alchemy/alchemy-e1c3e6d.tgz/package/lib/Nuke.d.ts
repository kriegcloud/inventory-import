import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import { type ProviderService } from "./Provider.ts";
import type { ProviderMode } from "./ProviderMode.ts";
/** A provider call that failed. These are collected into results, never thrown. */
export interface ProviderFailure {
    readonly provider: string;
    readonly operation: "list" | "delete";
    readonly message: string;
}
/** One cloud object a provider's `list()` turned up, bound to its provider. */
export interface Target {
    /** Unique within a scan; names the target's row in progress events and views. */
    readonly key: string;
    readonly providerId: string;
    readonly displayName: string;
    readonly attributes: Record<string, unknown>;
    readonly provider: ProviderService;
}
export interface DiscoverOptions {
    readonly mode: ProviderMode;
    /** Provider-id globs to include. Omitted means every provider. */
    readonly include?: ReadonlyArray<string>;
    /** Provider-id globs to exclude. Applied after {@link DiscoverOptions.include}. */
    readonly exclude?: ReadonlyArray<string>;
}
export interface ListOptions extends DiscoverOptions {
    /** The built provider context — what a stack's `providers` layer produced. */
    readonly context: Context.Context<never>;
    readonly concurrency?: number | "unbounded";
    readonly timeoutSeconds?: number;
}
export type Strategy = 
/** Delete in dependency order, retrying a wave until it stops making progress. */
{
    readonly type: "coordinated";
}
/** Delete everything at once, retrying each object on its own. */
 | {
    readonly type: "independent";
    readonly retries: number;
};
export interface DestroyOptions {
    readonly targets: ReadonlyArray<Target>;
    readonly context: Context.Context<never>;
    readonly strategy: Strategy;
    readonly concurrency?: number | "unbounded";
    readonly timeoutSeconds?: number;
}
export interface Result {
    readonly requested: number;
    readonly deleted: ReadonlyArray<Target>;
    readonly failed: ReadonlyArray<{
        readonly resource: Target;
        readonly failure: ProviderFailure;
    }>;
    /** Skipped because something they depend on could not be deleted first. */
    readonly held: ReadonlyArray<{
        readonly resource: Target;
        readonly blockedBy: ReadonlyArray<string>;
    }>;
    readonly passes: number;
}
/** Ask every selected provider what exists. Provider failures are collected, not thrown. */
export declare const list: (options: ListOptions) => Effect.Effect<{
    readonly resources: ReadonlyArray<Target>;
    readonly failures: ReadonlyArray<ProviderFailure>;
}>;
/** Delete the given targets under the chosen {@link Strategy}. */
export declare const destroy: ({ targets, context, strategy, concurrency, timeoutSeconds, }: DestroyOptions) => Effect.Effect<Result>;
//# sourceMappingURL=Nuke.d.ts.map