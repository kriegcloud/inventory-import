import * as Context from "effect/Context";
import * as DateTime from "effect/DateTime";
import * as Effect from "effect/Effect";
import * as Aggregate from "../../Aggregate.ts";
import type * as Decision from "../../Decision.ts";
import * as Decide from "./Decide.ts";
import type { DecisionStep, Inputs } from "./Paths.ts";
import * as Smt from "./Smt.ts";
import * as Symbolic from "./Symbolic.ts";
import type { Run, V } from "./Value.ts";
/** Inputs that break an invariant, and what the real code does with them. */
export interface Counterexample {
    readonly state: unknown;
    readonly command: unknown;
    /** What each request context the command read held. */
    readonly context: ReadonlyArray<{
        readonly name: string;
        readonly value: unknown;
    }>;
    readonly now: DateTime.Utc;
    readonly events: ReadonlyArray<unknown>;
    readonly after: unknown;
}
export type Verdict = 
/** No state and no input break the invariant. */
{
    readonly _tag: "Proved";
}
/** The real code breaks the invariant on these inputs. */
 | {
    readonly _tag: "Violated";
    readonly counterexample: Counterexample;
}
/** The solver found inputs, but the real code keeps the invariant on them. */
 | {
    readonly _tag: "Unconfirmed";
    readonly reason: string;
}
/** The prover met code it cannot read. */
 | {
    readonly _tag: "NotTranslated";
    readonly file: string;
    readonly line: number;
    readonly reason: string;
}
/** No list of up to a few items breaks it: longer lists were not looked at. */
 | {
    readonly _tag: "Bounded";
    readonly reason: string;
}
/** The solver gave up. */
 | {
    readonly _tag: "Unknown";
    readonly reason: string;
}
/** The prover read the code as doing one thing, and the real code does another on the same inputs. */
 | {
    readonly _tag: "Misread";
    readonly reason: string;
};
export type Model = ReadonlyMap<string, number | bigint | string | boolean>;
declare const unconfirmed: (reason: string) => Verdict;
/**
 * Ask the solver for inputs on this path that make `condition` false: with an
 * invariant, inputs that break it; with `"false"`, any inputs that take the path. A function
 * the prover knows only by its implementation starts free; each answer that
 * disagrees with the real function is ruled out, and the question is asked again.
 */
export declare const solve: (solver: Smt.Solver, run: Run, condition: string, reads?: readonly Smt.Term[] | undefined) => Effect.Effect<{
    readonly _tag: "Unsat";
} | {
    readonly _tag: "Unknown";
    readonly reason: string;
} | {
    readonly _tag: "Sat";
    readonly model: Map<string, string | number | bigint | boolean>;
}, Smt.SolverError, never>;
/** One step the real code took: a command on a state, and what it left. */
export interface Moved {
    readonly before: unknown;
    readonly after: unknown;
    readonly command: unknown;
    readonly events: ReadonlyArray<unknown>;
    /** The request contexts the command ran with. */
    readonly context: Context.Context<never>;
}
/** Something a command must keep true of the step it takes. */
export interface Kept {
    /** How a sentence names it: an invariant's name, or `the state's schema`. */
    readonly what: string;
    readonly holds: (moved: Moved) => boolean;
    /** What a counterexample shows as the states before and after, in place of the instance's own. */
    readonly shown?: (moved: Moved) => {
        readonly state: unknown;
        readonly after: unknown;
    };
}
/** The solver's value for part of a path, as a real value: it fails when it has none. */
export type Build = (what: string, value: Parameters<typeof Symbolic.concretize>[0]) => Effect.Effect<unknown, Verdict>;
/**
 * Something to keep, or how to make it from a counterexample: a rule about
 * more than the step's own instances builds the others from the solver's
 * answer, and fails when they are not ones the real code allows.
 */
export type Keeping<K> = K | ((build: Build) => Effect.Effect<K, Verdict>);
/** A verdict that the solver's answer is not one the real code confirms. */
export declare const notConfirmed: typeof unconfirmed;
/**
 * Every invariant and transition of an aggregate, by name, on a step the real
 * code took. An invariant looks at the state the step left.
 */
export declare const rules: (aggregate: Aggregate.Any) => Readonly<Record<string, Kept["holds"]>>;
/** The invariant or transition of an aggregate with this name, as something a command must keep. */
export declare const invariant: (aggregate: Aggregate.Any, name: string) => Kept;
/** That the state is one the aggregate's schema allows, as something a command must keep. */
export declare const schema: (aggregate: Aggregate.Any) => Kept;
/** What comparing a path with the real code gave. */
export type Agreement = {
    readonly _tag: "Agreed";
}
/**
 * Nothing was compared. No inputs take the path, or with `taken`, the ones
 * the solver found cannot be built as real values or run.
 */
 | {
    readonly _tag: "Skipped";
    readonly taken: boolean;
} | {
    readonly _tag: "Differs";
    readonly reason: string;
};
/** What the prover read a command to do on one path. */
export type Read = {
    readonly _tag: "Rejected";
    readonly rejection: V;
} | {
    readonly _tag: "Unchanged";
} | {
    readonly _tag: "Changed";
    readonly events: ReadonlyArray<V>;
    readonly after: V;
};
/**
 * Pick inputs that take one path, run the real `decide` and `evolve` on them,
 * and say whether they do what the prover read: the same rejection, or the
 * same events and the same state. A proof is about what the prover read, so
 * it stands only where the two agree.
 */
export declare const agree: (solver: Smt.Solver, aggregate: Aggregate.Any, run: Run, inputs: Inputs, read: Read) => Effect.Effect<Agreement, Smt.SolverError, never>;
/**
 * Whether an invariant, or the state's schema, can be false at the end of one
 * path. A counterexample counts only when the real code, run on it, breaks it
 * too.
 */
export declare const check: (solver: Smt.Solver, aggregate: Aggregate.Any, kept: Keeping<Kept>, run: Run, inputs: Inputs, condition: string) => Effect.Effect<Verdict, Smt.SolverError>;
/**
 * Whether `condition` can be false on a path where no command runs. `confirm`
 * builds the solver's answer as real values and says what the real code makes of it.
 */
export declare const checkAt: (solver: Smt.Solver, run: Run, condition: string, confirm: (build: Build) => Effect.Effect<Verdict, Verdict>) => Effect.Effect<Verdict, Smt.SolverError>;
/** One step the real code of a decision took: what it left of every instance it read. */
export interface DecisionMoved {
    readonly ran: Decide.Ran & {
        readonly _tag: "Accepted";
    };
    /** The stream of each instance the prover gave a state, in the order it read them. */
    readonly streams: ReadonlyArray<string>;
    readonly command: unknown;
    readonly context: Context.Context<never>;
}
/** Something a decision must keep true of the step it takes. */
export interface DecisionKept {
    readonly what: string;
    readonly holds: (moved: DecisionMoved) => boolean;
    /** What a counterexample shows as the states before and after, in place of the ones the decision read. */
    readonly shown?: (moved: DecisionMoved) => {
        readonly state: unknown;
        readonly after: unknown;
    };
}
/** An aggregate's invariant or transition, on the instance a decision read at this place. */
export declare const onInstance: (aggregate: Aggregate.Any, name: string, slot: number) => DecisionKept;
/** That every instance a decision read is left in its state's schema. */
export declare const schemas: DecisionKept;
/** One of a decision's own transitions, on the step it took. */
export declare const transition: (decision: Decision.Any, name: string) => DecisionKept;
/**
 * Whether something a decision must keep can be false at the end of one path.
 * A counterexample counts only when the real `decide` and `evolve`, run on
 * it, break it too.
 */
export declare const checkDecision: (solver: Smt.Solver, decision: Decision.Any, aggregates: ReadonlyArray<Aggregate.Any>, kept: Keeping<DecisionKept>, run: Run, step: DecisionStep, condition: string) => Effect.Effect<Verdict, Smt.SolverError>;
export {};
//# sourceMappingURL=Check.d.ts.map