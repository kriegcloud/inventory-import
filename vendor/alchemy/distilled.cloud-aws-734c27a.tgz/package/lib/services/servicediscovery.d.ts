import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const CustomHealthNotFound_base: S.TaggedErrorClass<"CustomHealthNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomHealthNotFound extends /*@__PURE__*/ CustomHealthNotFound_base {
}
declare const DuplicateRequest_base: S.TaggedErrorClass<"DuplicateRequest", {
    readonly message: any;
    readonly DuplicateOperationId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class DuplicateRequest extends /*@__PURE__*/ DuplicateRequest_base {
}
declare const InstanceNotFound_base: S.TaggedErrorClass<"InstanceNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InstanceNotFound extends /*@__PURE__*/ InstanceNotFound_base {
}
declare const InvalidInput_base: S.TaggedErrorClass<"InvalidInput", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInput extends /*@__PURE__*/ InvalidInput_base {
}
declare const NamespaceAlreadyExists_base: S.TaggedErrorClass<"NamespaceAlreadyExists", {
    readonly message: any;
    readonly CreatorRequestId: any;
    readonly NamespaceId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class NamespaceAlreadyExists extends /*@__PURE__*/ NamespaceAlreadyExists_base {
}
declare const NamespaceNotFound_base: S.TaggedErrorClass<"NamespaceNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NamespaceNotFound extends /*@__PURE__*/ NamespaceNotFound_base {
}
declare const OperationNotFound_base: S.TaggedErrorClass<"OperationNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OperationNotFound extends /*@__PURE__*/ OperationNotFound_base {
}
declare const RequestLimitExceeded_base: S.TaggedErrorClass<"RequestLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class RequestLimitExceeded extends /*@__PURE__*/ RequestLimitExceeded_base {
}
declare const ResourceInUse_base: S.TaggedErrorClass<"ResourceInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class ResourceInUse extends /*@__PURE__*/ ResourceInUse_base {
}
declare const ResourceLimitExceeded_base: S.TaggedErrorClass<"ResourceLimitExceeded", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ResourceLimitExceeded extends /*@__PURE__*/ ResourceLimitExceeded_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceAlreadyExists_base: S.TaggedErrorClass<"ServiceAlreadyExists", {
    readonly message: any;
    readonly CreatorRequestId: any;
    readonly ServiceId: any;
    readonly ServiceArn: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ServiceAlreadyExists extends /*@__PURE__*/ ServiceAlreadyExists_base {
}
declare const ServiceAttributesLimitExceededException_base: S.TaggedErrorClass<"ServiceAttributesLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceAttributesLimitExceededException extends /*@__PURE__*/ ServiceAttributesLimitExceededException_base {
}
declare const ServiceNotFound_base: S.TaggedErrorClass<"ServiceNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ServiceNotFound extends /*@__PURE__*/ ServiceNotFound_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
export type NamespaceNameHttp = string;
export type ResourceId = string;
export type ResourceDescription = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateHttpNamespaceRequest {
    Name: string;
    CreatorRequestId?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type OperationId = string;
export interface CreateHttpNamespaceResponse {
    OperationId?: string | undefined;
}
export type NamespaceNamePrivate = string;
export type RecordTTL = number;
export interface SOA {
    TTL?: number | undefined;
}
export interface PrivateDnsPropertiesMutable {
    SOA: SOA;
}
export interface PrivateDnsNamespaceProperties {
    DnsProperties: PrivateDnsPropertiesMutable;
}
export interface CreatePrivateDnsNamespaceRequest {
    Name: string;
    CreatorRequestId?: string | undefined;
    Description?: string | undefined;
    Vpc: string;
    Tags?: Tag[] | undefined;
    Properties?: PrivateDnsNamespaceProperties | undefined;
}
export interface CreatePrivateDnsNamespaceResponse {
    OperationId?: string | undefined;
}
export type NamespaceNamePublic = string;
export interface PublicDnsPropertiesMutable {
    SOA: SOA;
}
export interface PublicDnsNamespaceProperties {
    DnsProperties: PublicDnsPropertiesMutable;
}
export interface CreatePublicDnsNamespaceRequest {
    Name: string;
    CreatorRequestId?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    Properties?: PublicDnsNamespaceProperties | undefined;
}
export interface CreatePublicDnsNamespaceResponse {
    OperationId?: string | undefined;
}
export type ServiceName = string;
export type Arn = string;
export type RoutingPolicy = "MULTIVALUE" | "WEIGHTED" | (string & {});
export type RecordType = "SRV" | "A" | "AAAA" | "CNAME" | (string & {});
export interface DnsRecord {
    Type: RecordType;
    TTL: number;
}
export type DnsRecordList = DnsRecord[];
export interface DnsConfig {
    NamespaceId?: string | undefined;
    RoutingPolicy?: RoutingPolicy | undefined;
    DnsRecords?: DnsRecord[] | undefined;
}
export type HealthCheckType = "HTTP" | "HTTPS" | "TCP" | (string & {});
export type ResourcePath = string;
export type FailureThreshold = number;
export interface HealthCheckConfig {
    Type: HealthCheckType;
    ResourcePath?: string | undefined;
    FailureThreshold?: number | undefined;
}
export interface HealthCheckCustomConfig {
    FailureThreshold?: number | undefined;
}
export type ServiceTypeOption = "HTTP" | (string & {});
export interface CreateServiceRequest {
    Name: string;
    NamespaceId?: string | undefined;
    CreatorRequestId?: string | undefined;
    Description?: string | undefined;
    DnsConfig?: DnsConfig | undefined;
    HealthCheckConfig?: HealthCheckConfig | undefined;
    HealthCheckCustomConfig?: HealthCheckCustomConfig | undefined;
    Tags?: Tag[] | undefined;
    Type?: ServiceTypeOption | undefined;
}
export type AWSAccountId = string;
export type ResourceCount = number;
export type ServiceType = "HTTP" | "DNS_HTTP" | "DNS" | (string & {});
export interface Service {
    Id?: string | undefined;
    Arn?: string | undefined;
    ResourceOwner?: string | undefined;
    Name?: string | undefined;
    NamespaceId?: string | undefined;
    Description?: string | undefined;
    InstanceCount?: number | undefined;
    DnsConfig?: DnsConfig | undefined;
    Type?: ServiceType | undefined;
    HealthCheckConfig?: HealthCheckConfig | undefined;
    HealthCheckCustomConfig?: HealthCheckCustomConfig | undefined;
    CreateDate?: Date | undefined;
    CreatorRequestId?: string | undefined;
    CreatedByAccount?: string | undefined;
}
export interface CreateServiceResponse {
    Service?: Service | undefined;
}
export interface DeleteNamespaceRequest {
    Id: string;
}
export interface DeleteNamespaceResponse {
    OperationId?: string | undefined;
}
export interface DeleteServiceRequest {
    Id: string;
}
export interface DeleteServiceResponse {
}
export type ServiceAttributeKey = string;
export type ServiceAttributeKeyList = string[];
export interface DeleteServiceAttributesRequest {
    ServiceId: string;
    Attributes: string[];
}
export interface DeleteServiceAttributesResponse {
}
export interface DeregisterInstanceRequest {
    ServiceId: string;
    InstanceId: string;
}
export interface DeregisterInstanceResponse {
    OperationId?: string | undefined;
}
export type NamespaceName = string;
export type DiscoverMaxResults = number;
export type AttrKey = string;
export type AttrValue = string;
export type Attributes = {
    [key: string]: string | undefined;
};
export type HealthStatusFilter = "HEALTHY" | "UNHEALTHY" | "ALL" | "HEALTHY_OR_ELSE_ALL" | (string & {});
export interface DiscoverInstancesRequest {
    NamespaceName: string;
    ServiceName: string;
    MaxResults?: number | undefined;
    QueryParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    OptionalParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    HealthStatus?: HealthStatusFilter | undefined;
    OwnerAccount?: string | undefined;
}
export type HealthStatus = "HEALTHY" | "UNHEALTHY" | "UNKNOWN" | (string & {});
export interface HttpInstanceSummary {
    InstanceId?: string | undefined;
    NamespaceName?: string | undefined;
    ServiceName?: string | undefined;
    HealthStatus?: HealthStatus | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type HttpInstanceSummaryList = HttpInstanceSummary[];
export type Revision = number;
export interface DiscoverInstancesResponse {
    Instances?: HttpInstanceSummary[] | undefined;
    InstancesRevision?: number | undefined;
}
export interface DiscoverInstancesRevisionRequest {
    NamespaceName: string;
    ServiceName: string;
    OwnerAccount?: string | undefined;
}
export interface DiscoverInstancesRevisionResponse {
    InstancesRevision?: number | undefined;
}
export interface GetInstanceRequest {
    ServiceId: string;
    InstanceId: string;
}
export interface Instance {
    Id: string;
    CreatorRequestId?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedByAccount?: string | undefined;
}
export interface GetInstanceResponse {
    ResourceOwner?: string | undefined;
    Instance?: Instance | undefined;
}
export type InstanceIdList = string[];
export type MaxResults = number;
export type NextToken = string;
export interface GetInstancesHealthStatusRequest {
    ServiceId: string;
    Instances?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InstanceHealthStatusMap = {
    [key: string]: HealthStatus | undefined;
};
export interface GetInstancesHealthStatusResponse {
    Status?: {
        [key: string]: HealthStatus | undefined;
    } | undefined;
    NextToken?: string | undefined;
}
export interface GetNamespaceRequest {
    Id: string;
}
export type NamespaceType = "DNS_PUBLIC" | "DNS_PRIVATE" | "HTTP" | (string & {});
export interface DnsProperties {
    HostedZoneId?: string | undefined;
    SOA?: SOA | undefined;
}
export interface HttpProperties {
    HttpName?: string | undefined;
}
export interface NamespaceProperties {
    DnsProperties?: DnsProperties | undefined;
    HttpProperties?: HttpProperties | undefined;
}
export interface Namespace {
    Id?: string | undefined;
    Arn?: string | undefined;
    ResourceOwner?: string | undefined;
    Name?: string | undefined;
    Type?: NamespaceType | undefined;
    Description?: string | undefined;
    ServiceCount?: number | undefined;
    Properties?: NamespaceProperties | undefined;
    CreateDate?: Date | undefined;
    CreatorRequestId?: string | undefined;
}
export interface GetNamespaceResponse {
    Namespace?: Namespace | undefined;
}
export interface GetOperationRequest {
    OperationId: string;
    OwnerAccount?: string | undefined;
}
export type OperationType = "CREATE_NAMESPACE" | "DELETE_NAMESPACE" | "UPDATE_NAMESPACE" | "UPDATE_SERVICE" | "REGISTER_INSTANCE" | "DEREGISTER_INSTANCE" | (string & {});
export type OperationStatus = "SUBMITTED" | "PENDING" | "SUCCESS" | "FAIL" | (string & {});
export type Message = string;
export type Code = string;
export type OperationTargetType = "NAMESPACE" | "SERVICE" | "INSTANCE" | (string & {});
export type OperationTargetsMap = {
    [key in OperationTargetType]?: string | undefined;
};
export interface Operation {
    Id?: string | undefined;
    OwnerAccount?: string | undefined;
    Type?: OperationType | undefined;
    Status?: OperationStatus | undefined;
    ErrorMessage?: string | undefined;
    ErrorCode?: string | undefined;
    CreateDate?: Date | undefined;
    UpdateDate?: Date | undefined;
    Targets?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetOperationResponse {
    Operation?: Operation | undefined;
}
export interface GetServiceRequest {
    Id: string;
}
export interface GetServiceResponse {
    Service?: Service | undefined;
}
export interface GetServiceAttributesRequest {
    ServiceId: string;
}
export type ServiceAttributeValue = string;
export type ServiceAttributesMap = {
    [key: string]: string | undefined;
};
export interface ServiceAttributes {
    ServiceArn?: string | undefined;
    ResourceOwner?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetServiceAttributesResponse {
    ServiceAttributes?: ServiceAttributes | undefined;
}
export interface ListInstancesRequest {
    ServiceId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface InstanceSummary {
    Id?: string | undefined;
    Attributes?: {
        [key: string]: string | undefined;
    } | undefined;
    CreatedByAccount?: string | undefined;
}
export type InstanceSummaryList = InstanceSummary[];
export interface ListInstancesResponse {
    ResourceOwner?: string | undefined;
    Instances?: InstanceSummary[] | undefined;
    NextToken?: string | undefined;
}
export type NamespaceFilterName = "TYPE" | "NAME" | "HTTP_NAME" | "RESOURCE_OWNER" | (string & {});
export type FilterValue = string;
export type FilterValues = string[];
export type FilterCondition = "EQ" | "IN" | "BETWEEN" | "BEGINS_WITH" | (string & {});
export interface NamespaceFilter {
    Name: NamespaceFilterName;
    Values: string[];
    Condition?: FilterCondition | undefined;
}
export type NamespaceFilters = NamespaceFilter[];
export interface ListNamespacesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: NamespaceFilter[] | undefined;
}
export interface NamespaceSummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    ResourceOwner?: string | undefined;
    Name?: string | undefined;
    Type?: NamespaceType | undefined;
    Description?: string | undefined;
    ServiceCount?: number | undefined;
    Properties?: NamespaceProperties | undefined;
    CreateDate?: Date | undefined;
}
export type NamespaceSummariesList = NamespaceSummary[];
export interface ListNamespacesResponse {
    Namespaces?: NamespaceSummary[] | undefined;
    NextToken?: string | undefined;
}
export type OperationFilterName = "NAMESPACE_ID" | "SERVICE_ID" | "STATUS" | "TYPE" | "UPDATE_DATE" | (string & {});
export interface OperationFilter {
    Name: OperationFilterName;
    Values: string[];
    Condition?: FilterCondition | undefined;
}
export type OperationFilters = OperationFilter[];
export interface ListOperationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: OperationFilter[] | undefined;
}
export interface OperationSummary {
    Id?: string | undefined;
    Status?: OperationStatus | undefined;
}
export type OperationSummaryList = OperationSummary[];
export interface ListOperationsResponse {
    Operations?: OperationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type ServiceFilterName = "NAMESPACE_ID" | "RESOURCE_OWNER" | (string & {});
export interface ServiceFilter {
    Name: ServiceFilterName;
    Values: string[];
    Condition?: FilterCondition | undefined;
}
export type ServiceFilters = ServiceFilter[];
export interface ListServicesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: ServiceFilter[] | undefined;
}
export interface ServiceSummary {
    Id?: string | undefined;
    Arn?: string | undefined;
    ResourceOwner?: string | undefined;
    Name?: string | undefined;
    Type?: ServiceType | undefined;
    Description?: string | undefined;
    InstanceCount?: number | undefined;
    DnsConfig?: DnsConfig | undefined;
    HealthCheckConfig?: HealthCheckConfig | undefined;
    HealthCheckCustomConfig?: HealthCheckCustomConfig | undefined;
    CreateDate?: Date | undefined;
    CreatedByAccount?: string | undefined;
}
export type ServiceSummariesList = ServiceSummary[];
export interface ListServicesResponse {
    Services?: ServiceSummary[] | undefined;
    NextToken?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export type InstanceId = string;
export interface RegisterInstanceRequest {
    ServiceId: string;
    InstanceId: string;
    CreatorRequestId?: string | undefined;
    Attributes: {
        [key: string]: string | undefined;
    };
}
export interface RegisterInstanceResponse {
    OperationId?: string | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface HttpNamespaceChange {
    Description: string;
}
export interface UpdateHttpNamespaceRequest {
    Id: string;
    UpdaterRequestId?: string | undefined;
    Namespace: HttpNamespaceChange;
}
export interface UpdateHttpNamespaceResponse {
    OperationId?: string | undefined;
}
export type CustomHealthStatus = "HEALTHY" | "UNHEALTHY" | (string & {});
export interface UpdateInstanceCustomHealthStatusRequest {
    ServiceId: string;
    InstanceId: string;
    Status: CustomHealthStatus;
}
export interface UpdateInstanceCustomHealthStatusResponse {
}
export interface SOAChange {
    TTL: number;
}
export interface PrivateDnsPropertiesMutableChange {
    SOA: SOAChange;
}
export interface PrivateDnsNamespacePropertiesChange {
    DnsProperties: PrivateDnsPropertiesMutableChange;
}
export interface PrivateDnsNamespaceChange {
    Description?: string | undefined;
    Properties?: PrivateDnsNamespacePropertiesChange | undefined;
}
export interface UpdatePrivateDnsNamespaceRequest {
    Id: string;
    UpdaterRequestId?: string | undefined;
    Namespace: PrivateDnsNamespaceChange;
}
export interface UpdatePrivateDnsNamespaceResponse {
    OperationId?: string | undefined;
}
export interface PublicDnsPropertiesMutableChange {
    SOA: SOAChange;
}
export interface PublicDnsNamespacePropertiesChange {
    DnsProperties: PublicDnsPropertiesMutableChange;
}
export interface PublicDnsNamespaceChange {
    Description?: string | undefined;
    Properties?: PublicDnsNamespacePropertiesChange | undefined;
}
export interface UpdatePublicDnsNamespaceRequest {
    Id: string;
    UpdaterRequestId?: string | undefined;
    Namespace: PublicDnsNamespaceChange;
}
export interface UpdatePublicDnsNamespaceResponse {
    OperationId?: string | undefined;
}
export interface DnsConfigChange {
    DnsRecords: DnsRecord[];
}
export interface ServiceChange {
    Description?: string | undefined;
    DnsConfig?: DnsConfigChange | undefined;
    HealthCheckConfig?: HealthCheckConfig | undefined;
}
export interface UpdateServiceRequest {
    Id: string;
    Service: ServiceChange;
}
export interface UpdateServiceResponse {
    OperationId?: string | undefined;
}
export interface UpdateServiceAttributesRequest {
    ServiceId: string;
    Attributes: {
        [key: string]: string | undefined;
    };
}
export interface UpdateServiceAttributesResponse {
}
export type ErrorMessage = string;
export type CreateHttpNamespaceError = DuplicateRequest | InvalidInput | NamespaceAlreadyExists | ResourceLimitExceeded | TooManyTagsException | CommonErrors;
/**
 * Creates an HTTP namespace. Service instances registered using an HTTP namespace can be
 * discovered using a `DiscoverInstances` request but can't be discovered using
 * DNS.
 *
 * For the current quota on the number of namespaces that you can create using the same Amazon Web Services account, see Cloud Map quotas in the
 * *Cloud Map Developer Guide*.
 */
export declare const createHttpNamespace: API.OperationMethod<CreateHttpNamespaceRequest & RegionInput, CreateHttpNamespaceResponse, CreateHttpNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreatePrivateDnsNamespaceError = DuplicateRequest | InvalidInput | NamespaceAlreadyExists | ResourceLimitExceeded | TooManyTagsException | CommonErrors;
/**
 * Creates a private namespace based on DNS, which is visible only inside a specified Amazon
 * VPC. The namespace defines your service naming scheme. For example, if you name your namespace
 * `example.com` and name your service `backend`, the resulting DNS name for
 * the service is `backend.example.com`. Service instances that are registered using a
 * private DNS namespace can be discovered using either a `DiscoverInstances` request or
 * using DNS. For the current quota on the number of namespaces that you can create using the same
 * Amazon Web Services account, see Cloud Map quotas in the
 * *Cloud Map Developer Guide*.
 */
export declare const createPrivateDnsNamespace: API.OperationMethod<CreatePrivateDnsNamespaceRequest & RegionInput, CreatePrivateDnsNamespaceResponse, CreatePrivateDnsNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreatePublicDnsNamespaceError = DuplicateRequest | InvalidInput | NamespaceAlreadyExists | ResourceLimitExceeded | TooManyTagsException | CommonErrors;
/**
 * Creates a public namespace based on DNS, which is visible on the internet. The namespace
 * defines your service naming scheme. For example, if you name your namespace
 * `example.com` and name your service `backend`, the resulting DNS name for
 * the service is `backend.example.com`. You can discover instances that were registered
 * with a public DNS namespace by using either a `DiscoverInstances` request or using
 * DNS. For the current quota on the number of namespaces that you can create using the same Amazon Web Services account, see Cloud Map quotas in the
 * *Cloud Map Developer Guide*.
 *
 * The `CreatePublicDnsNamespace` API operation is not supported in the Amazon Web Services GovCloud (US) Regions.
 */
export declare const createPublicDnsNamespace: API.OperationMethod<CreatePublicDnsNamespaceRequest & RegionInput, CreatePublicDnsNamespaceResponse, CreatePublicDnsNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateServiceError = InvalidInput | NamespaceNotFound | ResourceLimitExceeded | ServiceAlreadyExists | TooManyTagsException | CommonErrors;
/**
 * Creates a service. This action defines the configuration for the following entities:
 *
 * - For public and private DNS namespaces, one of the following combinations of DNS records in
 * Amazon Route 53:
 *
 * - `A`
 *
 * - `AAAA`
 *
 * - `A` and `AAAA`
 *
 * - `SRV`
 *
 * - `CNAME`
 *
 * - Optionally, a health check
 *
 * After you create the service, you can submit a RegisterInstance request, and
 * Cloud Map uses the values in the configuration to create the specified entities.
 *
 * For the current quota on the number of instances that you can register using the same
 * namespace and using the same service, see Cloud Map quotas in the
 * *Cloud Map Developer Guide*.
 */
export declare const createService: API.OperationMethod<CreateServiceRequest & RegionInput, CreateServiceResponse, CreateServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = DuplicateRequest | InvalidInput | NamespaceNotFound | ResourceInUse | CommonErrors;
/**
 * Deletes a namespace from the current account. If the namespace still contains one or more
 * services, the request fails.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest & RegionInput, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceError = InvalidInput | ResourceInUse | ServiceNotFound | CommonErrors;
/**
 * Deletes a specified service and all associated service attributes. If the service still
 * contains one or more registered instances, the request fails.
 */
export declare const deleteService: API.OperationMethod<DeleteServiceRequest & RegionInput, DeleteServiceResponse, DeleteServiceError, Credentials | HttpClient.HttpClient>;
export type DeleteServiceAttributesError = InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Deletes specific attributes associated with a service.
 */
export declare const deleteServiceAttributes: API.OperationMethod<DeleteServiceAttributesRequest & RegionInput, DeleteServiceAttributesResponse, DeleteServiceAttributesError, Credentials | HttpClient.HttpClient>;
export type DeregisterInstanceError = DuplicateRequest | InstanceNotFound | InvalidInput | ResourceInUse | ServiceNotFound | CommonErrors;
/**
 * Deletes the Amazon Route 53 DNS records and health check, if any, that Cloud Map created for the
 * specified instance.
 */
export declare const deregisterInstance: API.OperationMethod<DeregisterInstanceRequest & RegionInput, DeregisterInstanceResponse, DeregisterInstanceError, Credentials | HttpClient.HttpClient>;
export type DiscoverInstancesError = InvalidInput | NamespaceNotFound | RequestLimitExceeded | ServiceNotFound | CommonErrors;
/**
 * Discovers registered instances for a specified namespace and service. You can use
 * `DiscoverInstances` to discover instances for any type of namespace.
 * `DiscoverInstances` returns a randomized list of instances allowing customers to
 * distribute traffic evenly across instances. For public and private DNS namespaces, you can also
 * use DNS queries to discover instances.
 */
export declare const discoverInstances: API.OperationMethod<DiscoverInstancesRequest & RegionInput, DiscoverInstancesResponse, DiscoverInstancesError, Credentials | HttpClient.HttpClient>;
export type DiscoverInstancesRevisionError = InvalidInput | NamespaceNotFound | RequestLimitExceeded | ServiceNotFound | CommonErrors;
/**
 * Discovers the increasing revision associated with an instance.
 */
export declare const discoverInstancesRevision: API.OperationMethod<DiscoverInstancesRevisionRequest & RegionInput, DiscoverInstancesRevisionResponse, DiscoverInstancesRevisionError, Credentials | HttpClient.HttpClient>;
export type GetInstanceError = InstanceNotFound | InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Gets information about a specified instance.
 */
export declare const getInstance: API.OperationMethod<GetInstanceRequest & RegionInput, GetInstanceResponse, GetInstanceError, Credentials | HttpClient.HttpClient>;
export type GetInstancesHealthStatusError = InstanceNotFound | InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Gets the current health status (`Healthy`, `Unhealthy`, or
 * `Unknown`) of one or more instances that are associated with a specified
 * service.
 *
 * There's a brief delay between when you register an instance and when the health status for
 * the instance is available.
 */
export declare const getInstancesHealthStatus: API.PaginatedOperationMethod<GetInstancesHealthStatusRequest & RegionInput, GetInstancesHealthStatusResponse, GetInstancesHealthStatusError, Credentials | HttpClient.HttpClient, unknown>;
export type GetNamespaceError = InvalidInput | NamespaceNotFound | CommonErrors;
/**
 * Gets information about a namespace.
 */
export declare const getNamespace: API.OperationMethod<GetNamespaceRequest & RegionInput, GetNamespaceResponse, GetNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetOperationError = InvalidInput | OperationNotFound | CommonErrors;
/**
 * Gets information about any operation that returns an operation ID in the response, such as a
 * `CreateHttpNamespace` request.
 *
 * To get a list of operations that match specified criteria, see ListOperations.
 */
export declare const getOperation: API.OperationMethod<GetOperationRequest & RegionInput, GetOperationResponse, GetOperationError, Credentials | HttpClient.HttpClient>;
export type GetServiceError = InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Gets the settings for a specified service.
 */
export declare const getService: API.OperationMethod<GetServiceRequest & RegionInput, GetServiceResponse, GetServiceError, Credentials | HttpClient.HttpClient>;
export type GetServiceAttributesError = InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Returns the attributes associated with a specified service.
 */
export declare const getServiceAttributes: API.OperationMethod<GetServiceAttributesRequest & RegionInput, GetServiceAttributesResponse, GetServiceAttributesError, Credentials | HttpClient.HttpClient>;
export type ListInstancesError = InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Lists summary information about the instances that you registered by using a specified
 * service.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesRequest & RegionInput, ListInstancesResponse, ListInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListNamespacesError = InvalidInput | CommonErrors;
/**
 * Lists summary information about the namespaces that were created by the current Amazon Web Services account and shared with the current Amazon Web Services account.
 */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest & RegionInput, ListNamespacesResponse, ListNamespacesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListOperationsError = InvalidInput | CommonErrors;
/**
 * Lists operations that match the criteria that you specify.
 */
export declare const listOperations: API.PaginatedOperationMethod<ListOperationsRequest & RegionInput, ListOperationsResponse, ListOperationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListServicesError = InvalidInput | CommonErrors;
/**
 * Lists summary information for all the services that are associated with one or more
 * namespaces.
 */
export declare const listServices: API.PaginatedOperationMethod<ListServicesRequest & RegionInput, ListServicesResponse, ListServicesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = InvalidInput | ResourceNotFoundException | CommonErrors;
/**
 * Lists tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterInstanceError = DuplicateRequest | InvalidInput | ResourceInUse | ResourceLimitExceeded | ServiceNotFound | CommonErrors;
/**
 * Creates or updates one or more records and, optionally, creates a health check based on the
 * settings in a specified service. When you submit a `RegisterInstance` request, the
 * following occurs:
 *
 * - For each DNS record that you define in the service that's specified by
 * `ServiceId`, a record is created or updated in the hosted zone that's associated
 * with the corresponding namespace.
 *
 * - If the service includes `HealthCheckConfig`, a health check is created based on
 * the settings in the health check configuration.
 *
 * - The health check, if any, is associated with each of the new or updated records.
 *
 * One `RegisterInstance` request must complete before you can submit another
 * request and specify the same service ID and instance ID.
 *
 * For more information, see CreateService.
 *
 * When Cloud Map receives a DNS query for the specified DNS name, it returns the applicable
 * value:
 *
 * - **If the health check is healthy**: returns all the
 * records
 *
 * - **If the health check is unhealthy**: returns the applicable
 * value for the last healthy instance
 *
 * - **If you didn't specify a health check configuration**:
 * returns all the records
 *
 * For the current quota on the number of instances that you can register using the same
 * namespace and using the same service, see Cloud Map quotas in the
 * *Cloud Map Developer Guide*.
 */
export declare const registerInstance: API.OperationMethod<RegisterInstanceRequest & RegionInput, RegisterInstanceResponse, RegisterInstanceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InvalidInput | ResourceNotFoundException | TooManyTagsException | CommonErrors;
/**
 * Adds one or more tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InvalidInput | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateHttpNamespaceError = DuplicateRequest | InvalidInput | NamespaceNotFound | ResourceInUse | CommonErrors;
/**
 * Updates an HTTP
 * namespace.
 */
export declare const updateHttpNamespace: API.OperationMethod<UpdateHttpNamespaceRequest & RegionInput, UpdateHttpNamespaceResponse, UpdateHttpNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateInstanceCustomHealthStatusError = CustomHealthNotFound | InstanceNotFound | InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Submits a request to change the health status of a custom health check to healthy or
 * unhealthy.
 *
 * You can use `UpdateInstanceCustomHealthStatus` to change the status only for
 * custom health checks, which you define using `HealthCheckCustomConfig` when you create
 * a service. You can't use it to change the status for Route 53 health checks, which you define using
 * `HealthCheckConfig`.
 *
 * For more information, see HealthCheckCustomConfig.
 */
export declare const updateInstanceCustomHealthStatus: API.OperationMethod<UpdateInstanceCustomHealthStatusRequest & RegionInput, UpdateInstanceCustomHealthStatusResponse, UpdateInstanceCustomHealthStatusError, Credentials | HttpClient.HttpClient>;
export type UpdatePrivateDnsNamespaceError = DuplicateRequest | InvalidInput | NamespaceNotFound | ResourceInUse | CommonErrors;
/**
 * Updates a private DNS
 * namespace.
 */
export declare const updatePrivateDnsNamespace: API.OperationMethod<UpdatePrivateDnsNamespaceRequest & RegionInput, UpdatePrivateDnsNamespaceResponse, UpdatePrivateDnsNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdatePublicDnsNamespaceError = DuplicateRequest | InvalidInput | NamespaceNotFound | ResourceInUse | CommonErrors;
/**
 * Updates a public DNS namespace.
 */
export declare const updatePublicDnsNamespace: API.OperationMethod<UpdatePublicDnsNamespaceRequest & RegionInput, UpdatePublicDnsNamespaceResponse, UpdatePublicDnsNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceError = DuplicateRequest | InvalidInput | ServiceNotFound | CommonErrors;
/**
 * Submits a request to perform the following operations:
 *
 * - Update the TTL setting for existing `DnsRecords` configurations
 *
 * - Add, update, or delete `HealthCheckConfig` for a specified service
 *
 * You can't add, update, or delete a `HealthCheckCustomConfig`
 * configuration.
 *
 * For public and private DNS namespaces, note the following:
 *
 * - If you omit any existing `DnsRecords` or `HealthCheckConfig`
 * configurations from an `UpdateService` request, the configurations are deleted from
 * the service.
 *
 * - If you omit an existing `HealthCheckCustomConfig` configuration from an
 * `UpdateService` request, the configuration isn't deleted from the service.
 *
 * You can't call `UpdateService` and update settings in the following
 * scenarios:
 *
 * - When the service is associated with an HTTP namespace
 *
 * - When the service is associated with a shared namespace and contains instances that were
 * registered by Amazon Web Services accounts other than the account making the `UpdateService`
 * call
 *
 * When you update settings for a service, Cloud Map also updates the corresponding settings
 * in all the records and health checks that were created by using the specified service.
 */
export declare const updateService: API.OperationMethod<UpdateServiceRequest & RegionInput, UpdateServiceResponse, UpdateServiceError, Credentials | HttpClient.HttpClient>;
export type UpdateServiceAttributesError = InvalidInput | ServiceAttributesLimitExceededException | ServiceNotFound | CommonErrors;
/**
 * Submits a request to update a specified service to add service-level attributes.
 */
export declare const updateServiceAttributes: API.OperationMethod<UpdateServiceAttributesRequest & RegionInput, UpdateServiceAttributesResponse, UpdateServiceAttributesError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=servicediscovery.d.ts.map