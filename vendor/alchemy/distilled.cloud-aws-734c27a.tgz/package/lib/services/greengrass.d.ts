import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly ErrorDetails: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerErrorException_base: S.TaggedErrorClass<"InternalServerErrorException", {
    readonly ErrorDetails: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerErrorException extends /*@__PURE__*/ InternalServerErrorException_base {
}
export interface AssociateRoleToGroupRequest {
    GroupId: string;
    RoleArn?: string | undefined;
}
export interface AssociateRoleToGroupResponse {
    AssociatedAt?: string | undefined;
}
export interface AssociateServiceRoleToAccountRequest {
    RoleArn?: string | undefined;
}
export interface AssociateServiceRoleToAccountResponse {
    AssociatedAt?: string | undefined;
}
export type __mapOf__string = {
    [key: string]: string | undefined;
};
export interface Connector {
    ConnectorArn?: string | undefined;
    Id?: string | undefined;
    Parameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfConnector = Connector[];
export interface ConnectorDefinitionVersion {
    Connectors?: Connector[] | undefined;
}
export type Tags = {
    [key: string]: string | undefined;
};
export interface CreateConnectorDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: ConnectorDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateConnectorDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateConnectorDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    ConnectorDefinitionId: string;
    Connectors?: Connector[] | undefined;
}
export interface CreateConnectorDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface Core {
    CertificateArn?: string | undefined;
    Id?: string | undefined;
    SyncShadow?: boolean | undefined;
    ThingArn?: string | undefined;
}
export type __listOfCore = Core[];
export interface CoreDefinitionVersion {
    Cores?: Core[] | undefined;
}
export interface CreateCoreDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: CoreDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateCoreDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateCoreDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    CoreDefinitionId: string;
    Cores?: Core[] | undefined;
}
export interface CreateCoreDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export type DeploymentType = "NewDeployment" | "Redeployment" | "ResetDeployment" | "ForceResetDeployment" | (string & {});
export interface CreateDeploymentRequest {
    AmznClientToken?: string | undefined;
    DeploymentId?: string | undefined;
    DeploymentType?: DeploymentType | undefined;
    GroupId: string;
    GroupVersionId?: string | undefined;
}
export interface CreateDeploymentResponse {
    DeploymentArn?: string | undefined;
    DeploymentId?: string | undefined;
}
export interface Device {
    CertificateArn?: string | undefined;
    Id?: string | undefined;
    SyncShadow?: boolean | undefined;
    ThingArn?: string | undefined;
}
export type __listOfDevice = Device[];
export interface DeviceDefinitionVersion {
    Devices?: Device[] | undefined;
}
export interface CreateDeviceDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: DeviceDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDeviceDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateDeviceDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    DeviceDefinitionId: string;
    Devices?: Device[] | undefined;
}
export interface CreateDeviceDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export type FunctionIsolationMode = "GreengrassContainer" | "NoContainer" | (string & {});
export interface FunctionRunAsConfig {
    Gid?: number | undefined;
    Uid?: number | undefined;
}
export interface FunctionDefaultExecutionConfig {
    IsolationMode?: FunctionIsolationMode | undefined;
    RunAs?: FunctionRunAsConfig | undefined;
}
export interface FunctionDefaultConfig {
    Execution?: FunctionDefaultExecutionConfig | undefined;
}
export type EncodingType = "binary" | "json" | (string & {});
export interface FunctionExecutionConfig {
    IsolationMode?: FunctionIsolationMode | undefined;
    RunAs?: FunctionRunAsConfig | undefined;
}
export type Permission = "ro" | "rw" | (string & {});
export interface ResourceAccessPolicy {
    Permission?: Permission | undefined;
    ResourceId?: string | undefined;
}
export type __listOfResourceAccessPolicy = ResourceAccessPolicy[];
export interface FunctionConfigurationEnvironment {
    AccessSysfs?: boolean | undefined;
    Execution?: FunctionExecutionConfig | undefined;
    ResourceAccessPolicies?: ResourceAccessPolicy[] | undefined;
    Variables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface FunctionConfiguration {
    EncodingType?: EncodingType | undefined;
    Environment?: FunctionConfigurationEnvironment | undefined;
    ExecArgs?: string | undefined;
    Executable?: string | undefined;
    MemorySize?: number | undefined;
    Pinned?: boolean | undefined;
    Timeout?: number | undefined;
    FunctionRuntimeOverride?: string | undefined;
}
export interface Function {
    FunctionArn?: string | undefined;
    FunctionConfiguration?: FunctionConfiguration | undefined;
    Id?: string | undefined;
}
export type __listOfFunction = Function[];
export interface FunctionDefinitionVersion {
    DefaultConfig?: FunctionDefaultConfig | undefined;
    Functions?: Function[] | undefined;
}
export interface CreateFunctionDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: FunctionDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateFunctionDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateFunctionDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    DefaultConfig?: FunctionDefaultConfig | undefined;
    FunctionDefinitionId: string;
    Functions?: Function[] | undefined;
}
export interface CreateFunctionDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface GroupVersion {
    ConnectorDefinitionVersionArn?: string | undefined;
    CoreDefinitionVersionArn?: string | undefined;
    DeviceDefinitionVersionArn?: string | undefined;
    FunctionDefinitionVersionArn?: string | undefined;
    LoggerDefinitionVersionArn?: string | undefined;
    ResourceDefinitionVersionArn?: string | undefined;
    SubscriptionDefinitionVersionArn?: string | undefined;
}
export interface CreateGroupRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: GroupVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateGroupResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateGroupCertificateAuthorityRequest {
    AmznClientToken?: string | undefined;
    GroupId: string;
}
export interface CreateGroupCertificateAuthorityResponse {
    GroupCertificateAuthorityArn?: string | undefined;
}
export interface CreateGroupVersionRequest {
    AmznClientToken?: string | undefined;
    ConnectorDefinitionVersionArn?: string | undefined;
    CoreDefinitionVersionArn?: string | undefined;
    DeviceDefinitionVersionArn?: string | undefined;
    FunctionDefinitionVersionArn?: string | undefined;
    GroupId: string;
    LoggerDefinitionVersionArn?: string | undefined;
    ResourceDefinitionVersionArn?: string | undefined;
    SubscriptionDefinitionVersionArn?: string | undefined;
}
export interface CreateGroupVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export type LoggerComponent = "GreengrassSystem" | "Lambda" | (string & {});
export type LoggerLevel = "DEBUG" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export type LoggerType = "FileSystem" | "AWSCloudWatch" | (string & {});
export interface Logger {
    Component?: LoggerComponent | undefined;
    Id?: string | undefined;
    Level?: LoggerLevel | undefined;
    Space?: number | undefined;
    Type?: LoggerType | undefined;
}
export type __listOfLogger = Logger[];
export interface LoggerDefinitionVersion {
    Loggers?: Logger[] | undefined;
}
export interface CreateLoggerDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: LoggerDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateLoggerDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateLoggerDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    LoggerDefinitionId: string;
    Loggers?: Logger[] | undefined;
}
export interface CreateLoggerDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface GroupOwnerSetting {
    AutoAddGroupOwner?: boolean | undefined;
    GroupOwner?: string | undefined;
}
export interface LocalDeviceResourceData {
    GroupOwnerSetting?: GroupOwnerSetting | undefined;
    SourcePath?: string | undefined;
}
export interface LocalVolumeResourceData {
    DestinationPath?: string | undefined;
    GroupOwnerSetting?: GroupOwnerSetting | undefined;
    SourcePath?: string | undefined;
}
export interface ResourceDownloadOwnerSetting {
    GroupOwner?: string | undefined;
    GroupPermission?: Permission | undefined;
}
export interface S3MachineLearningModelResourceData {
    DestinationPath?: string | undefined;
    OwnerSetting?: ResourceDownloadOwnerSetting | undefined;
    S3Uri?: string | undefined;
}
export interface SageMakerMachineLearningModelResourceData {
    DestinationPath?: string | undefined;
    OwnerSetting?: ResourceDownloadOwnerSetting | undefined;
    SageMakerJobArn?: string | undefined;
}
export type __listOf__string = string[];
export interface SecretsManagerSecretResourceData {
    ARN?: string | undefined;
    AdditionalStagingLabelsToDownload?: string[] | undefined;
}
export interface ResourceDataContainer {
    LocalDeviceResourceData?: LocalDeviceResourceData | undefined;
    LocalVolumeResourceData?: LocalVolumeResourceData | undefined;
    S3MachineLearningModelResourceData?: S3MachineLearningModelResourceData | undefined;
    SageMakerMachineLearningModelResourceData?: SageMakerMachineLearningModelResourceData | undefined;
    SecretsManagerSecretResourceData?: SecretsManagerSecretResourceData | undefined;
}
export interface Resource {
    Id?: string | undefined;
    Name?: string | undefined;
    ResourceDataContainer?: ResourceDataContainer | undefined;
}
export type __listOfResource = Resource[];
export interface ResourceDefinitionVersion {
    Resources?: Resource[] | undefined;
}
export interface CreateResourceDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: ResourceDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateResourceDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateResourceDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    ResourceDefinitionId: string;
    Resources?: Resource[] | undefined;
}
export interface CreateResourceDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export type S3UrlSignerRole = string;
export type SoftwareToUpdate = "core" | "ota_agent" | (string & {});
export type UpdateAgentLogLevel = "NONE" | "TRACE" | "DEBUG" | "VERBOSE" | "INFO" | "WARN" | "ERROR" | "FATAL" | (string & {});
export type UpdateTargets = string[];
export type UpdateTargetsArchitecture = "armv6l" | "armv7l" | "x86_64" | "aarch64" | (string & {});
export type UpdateTargetsOperatingSystem = "ubuntu" | "raspbian" | "amazon_linux" | "openwrt" | (string & {});
export interface CreateSoftwareUpdateJobRequest {
    AmznClientToken?: string | undefined;
    S3UrlSignerRole?: string | undefined;
    SoftwareToUpdate?: SoftwareToUpdate | undefined;
    UpdateAgentLogLevel?: UpdateAgentLogLevel | undefined;
    UpdateTargets?: string[] | undefined;
    UpdateTargetsArchitecture?: UpdateTargetsArchitecture | undefined;
    UpdateTargetsOperatingSystem?: UpdateTargetsOperatingSystem | undefined;
}
export interface CreateSoftwareUpdateJobResponse {
    IotJobArn?: string | undefined;
    IotJobId?: string | undefined;
    PlatformSoftwareVersion?: string | undefined;
}
export interface Subscription {
    Id?: string | undefined;
    Source?: string | undefined;
    Subject?: string | undefined;
    Target?: string | undefined;
}
export type __listOfSubscription = Subscription[];
export interface SubscriptionDefinitionVersion {
    Subscriptions?: Subscription[] | undefined;
}
export interface CreateSubscriptionDefinitionRequest {
    AmznClientToken?: string | undefined;
    InitialVersion?: SubscriptionDefinitionVersion | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateSubscriptionDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export interface CreateSubscriptionDefinitionVersionRequest {
    AmznClientToken?: string | undefined;
    SubscriptionDefinitionId: string;
    Subscriptions?: Subscription[] | undefined;
}
export interface CreateSubscriptionDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface DeleteConnectorDefinitionRequest {
    ConnectorDefinitionId: string;
}
export interface DeleteConnectorDefinitionResponse {
}
export interface DeleteCoreDefinitionRequest {
    CoreDefinitionId: string;
}
export interface DeleteCoreDefinitionResponse {
}
export interface DeleteDeviceDefinitionRequest {
    DeviceDefinitionId: string;
}
export interface DeleteDeviceDefinitionResponse {
}
export interface DeleteFunctionDefinitionRequest {
    FunctionDefinitionId: string;
}
export interface DeleteFunctionDefinitionResponse {
}
export interface DeleteGroupRequest {
    GroupId: string;
}
export interface DeleteGroupResponse {
}
export interface DeleteLoggerDefinitionRequest {
    LoggerDefinitionId: string;
}
export interface DeleteLoggerDefinitionResponse {
}
export interface DeleteResourceDefinitionRequest {
    ResourceDefinitionId: string;
}
export interface DeleteResourceDefinitionResponse {
}
export interface DeleteSubscriptionDefinitionRequest {
    SubscriptionDefinitionId: string;
}
export interface DeleteSubscriptionDefinitionResponse {
}
export interface DisassociateRoleFromGroupRequest {
    GroupId: string;
}
export interface DisassociateRoleFromGroupResponse {
    DisassociatedAt?: string | undefined;
}
export interface DisassociateServiceRoleFromAccountRequest {
}
export interface DisassociateServiceRoleFromAccountResponse {
    DisassociatedAt?: string | undefined;
}
export interface GetAssociatedRoleRequest {
    GroupId: string;
}
export interface GetAssociatedRoleResponse {
    AssociatedAt?: string | undefined;
    RoleArn?: string | undefined;
}
export interface GetBulkDeploymentStatusRequest {
    BulkDeploymentId: string;
}
export interface BulkDeploymentMetrics {
    InvalidInputRecords?: number | undefined;
    RecordsProcessed?: number | undefined;
    RetryAttempts?: number | undefined;
}
export type BulkDeploymentStatus = "Initializing" | "Running" | "Completed" | "Stopping" | "Stopped" | "Failed" | (string & {});
export interface ErrorDetail {
    DetailedErrorCode?: string | undefined;
    DetailedErrorMessage?: string | undefined;
}
export type ErrorDetails = ErrorDetail[];
export interface GetBulkDeploymentStatusResponse {
    BulkDeploymentMetrics?: BulkDeploymentMetrics | undefined;
    BulkDeploymentStatus?: BulkDeploymentStatus | undefined;
    CreatedAt?: string | undefined;
    ErrorDetails?: ErrorDetail[] | undefined;
    ErrorMessage?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetConnectivityInfoRequest {
    ThingName: string;
}
export interface ConnectivityInfo {
    HostAddress?: string | undefined;
    Id?: string | undefined;
    Metadata?: string | undefined;
    PortNumber?: number | undefined;
}
export type __listOfConnectivityInfo = ConnectivityInfo[];
export interface GetConnectivityInfoResponse {
    ConnectivityInfo?: ConnectivityInfo[] | undefined;
    Message?: string | undefined;
}
export interface GetConnectorDefinitionRequest {
    ConnectorDefinitionId: string;
}
export interface GetConnectorDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetConnectorDefinitionVersionRequest {
    ConnectorDefinitionId: string;
    ConnectorDefinitionVersionId: string;
    NextToken?: string | undefined;
}
export interface GetConnectorDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (ConnectorDefinitionVersion & {
        Connectors: (Connector & {
            ConnectorArn: string;
            Id: string;
        })[];
    }) | undefined;
    Id?: string | undefined;
    NextToken?: string | undefined;
    Version?: string | undefined;
}
export interface GetCoreDefinitionRequest {
    CoreDefinitionId: string;
}
export interface GetCoreDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetCoreDefinitionVersionRequest {
    CoreDefinitionId: string;
    CoreDefinitionVersionId: string;
}
export interface GetCoreDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (CoreDefinitionVersion & {
        Cores: (Core & {
            CertificateArn: string;
            Id: string;
            ThingArn: string;
        })[];
    }) | undefined;
    Id?: string | undefined;
    NextToken?: string | undefined;
    Version?: string | undefined;
}
export interface GetDeploymentStatusRequest {
    DeploymentId: string;
    GroupId: string;
}
export interface GetDeploymentStatusResponse {
    DeploymentStatus?: string | undefined;
    DeploymentType?: DeploymentType | undefined;
    ErrorDetails?: ErrorDetail[] | undefined;
    ErrorMessage?: string | undefined;
    UpdatedAt?: string | undefined;
}
export interface GetDeviceDefinitionRequest {
    DeviceDefinitionId: string;
}
export interface GetDeviceDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetDeviceDefinitionVersionRequest {
    DeviceDefinitionId: string;
    DeviceDefinitionVersionId: string;
    NextToken?: string | undefined;
}
export interface GetDeviceDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (DeviceDefinitionVersion & {
        Devices: (Device & {
            CertificateArn: string;
            Id: string;
            ThingArn: string;
        })[];
    }) | undefined;
    Id?: string | undefined;
    NextToken?: string | undefined;
    Version?: string | undefined;
}
export interface GetFunctionDefinitionRequest {
    FunctionDefinitionId: string;
}
export interface GetFunctionDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetFunctionDefinitionVersionRequest {
    FunctionDefinitionId: string;
    FunctionDefinitionVersionId: string;
    NextToken?: string | undefined;
}
export interface GetFunctionDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (FunctionDefinitionVersion & {
        Functions: (Function & {
            Id: string;
            FunctionConfiguration: FunctionConfiguration & {
                Environment: FunctionConfigurationEnvironment & {
                    ResourceAccessPolicies: (ResourceAccessPolicy & {
                        ResourceId: string;
                    })[];
                };
            };
        })[];
    }) | undefined;
    Id?: string | undefined;
    NextToken?: string | undefined;
    Version?: string | undefined;
}
export interface GetGroupRequest {
    GroupId: string;
}
export interface GetGroupResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetGroupCertificateAuthorityRequest {
    CertificateAuthorityId: string;
    GroupId: string;
}
export interface GetGroupCertificateAuthorityResponse {
    GroupCertificateAuthorityArn?: string | undefined;
    GroupCertificateAuthorityId?: string | undefined;
    PemEncodedCertificate?: string | undefined;
}
export interface GetGroupCertificateConfigurationRequest {
    GroupId: string;
}
export interface GetGroupCertificateConfigurationResponse {
    CertificateAuthorityExpiryInMilliseconds?: string | undefined;
    CertificateExpiryInMilliseconds?: string | undefined;
    GroupId?: string | undefined;
}
export interface GetGroupVersionRequest {
    GroupId: string;
    GroupVersionId: string;
}
export interface GetGroupVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: GroupVersion | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface GetLoggerDefinitionRequest {
    LoggerDefinitionId: string;
}
export interface GetLoggerDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetLoggerDefinitionVersionRequest {
    LoggerDefinitionId: string;
    LoggerDefinitionVersionId: string;
    NextToken?: string | undefined;
}
export interface GetLoggerDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (LoggerDefinitionVersion & {
        Loggers: (Logger & {
            Component: LoggerComponent;
            Id: string;
            Level: LoggerLevel;
            Type: LoggerType;
        })[];
    }) | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface GetResourceDefinitionRequest {
    ResourceDefinitionId: string;
}
export interface GetResourceDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetResourceDefinitionVersionRequest {
    ResourceDefinitionId: string;
    ResourceDefinitionVersionId: string;
}
export interface GetResourceDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (ResourceDefinitionVersion & {
        Resources: (Resource & {
            Id: string;
            Name: string;
            ResourceDataContainer: ResourceDataContainer & {
                S3MachineLearningModelResourceData: S3MachineLearningModelResourceData & {
                    OwnerSetting: ResourceDownloadOwnerSetting & {
                        GroupOwner: string;
                        GroupPermission: Permission;
                    };
                };
                SageMakerMachineLearningModelResourceData: SageMakerMachineLearningModelResourceData & {
                    OwnerSetting: ResourceDownloadOwnerSetting & {
                        GroupOwner: string;
                        GroupPermission: Permission;
                    };
                };
            };
        })[];
    }) | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export interface GetServiceRoleForAccountRequest {
}
export interface GetServiceRoleForAccountResponse {
    AssociatedAt?: string | undefined;
    RoleArn?: string | undefined;
}
export interface GetSubscriptionDefinitionRequest {
    SubscriptionDefinitionId: string;
}
export interface GetSubscriptionDefinitionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetSubscriptionDefinitionVersionRequest {
    NextToken?: string | undefined;
    SubscriptionDefinitionId: string;
    SubscriptionDefinitionVersionId: string;
}
export interface GetSubscriptionDefinitionVersionResponse {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Definition?: (SubscriptionDefinitionVersion & {
        Subscriptions: (Subscription & {
            Id: string;
            Source: string;
            Subject: string;
            Target: string;
        })[];
    }) | undefined;
    Id?: string | undefined;
    NextToken?: string | undefined;
    Version?: string | undefined;
}
export interface GetThingRuntimeConfigurationRequest {
    ThingName: string;
}
export type ConfigurationSyncStatus = "InSync" | "OutOfSync" | (string & {});
export type Telemetry = "On" | "Off" | (string & {});
export interface TelemetryConfiguration {
    ConfigurationSyncStatus?: ConfigurationSyncStatus | undefined;
    Telemetry?: Telemetry | undefined;
}
export interface RuntimeConfiguration {
    TelemetryConfiguration?: TelemetryConfiguration | undefined;
}
export interface GetThingRuntimeConfigurationResponse {
    RuntimeConfiguration?: (RuntimeConfiguration & {
        TelemetryConfiguration: TelemetryConfiguration & {
            Telemetry: Telemetry;
        };
    }) | undefined;
}
export interface ListBulkDeploymentDetailedReportsRequest {
    BulkDeploymentId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface BulkDeploymentResult {
    CreatedAt?: string | undefined;
    DeploymentArn?: string | undefined;
    DeploymentId?: string | undefined;
    DeploymentStatus?: string | undefined;
    DeploymentType?: DeploymentType | undefined;
    ErrorDetails?: ErrorDetail[] | undefined;
    ErrorMessage?: string | undefined;
    GroupArn?: string | undefined;
}
export type BulkDeploymentResults = BulkDeploymentResult[];
export interface ListBulkDeploymentDetailedReportsResponse {
    Deployments?: BulkDeploymentResult[] | undefined;
    NextToken?: string | undefined;
}
export interface ListBulkDeploymentsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface BulkDeployment {
    BulkDeploymentArn?: string | undefined;
    BulkDeploymentId?: string | undefined;
    CreatedAt?: string | undefined;
}
export type BulkDeployments = BulkDeployment[];
export interface ListBulkDeploymentsResponse {
    BulkDeployments?: BulkDeployment[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConnectorDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface DefinitionInformation {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type __listOfDefinitionInformation = DefinitionInformation[];
export interface ListConnectorDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConnectorDefinitionVersionsRequest {
    ConnectorDefinitionId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface VersionInformation {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    Version?: string | undefined;
}
export type __listOfVersionInformation = VersionInformation[];
export interface ListConnectorDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListCoreDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreDefinitionVersionsRequest {
    CoreDefinitionId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListCoreDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListDeploymentsRequest {
    GroupId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface Deployment {
    CreatedAt?: string | undefined;
    DeploymentArn?: string | undefined;
    DeploymentId?: string | undefined;
    DeploymentType?: DeploymentType | undefined;
    GroupArn?: string | undefined;
}
export type Deployments = Deployment[];
export interface ListDeploymentsResponse {
    Deployments?: Deployment[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeviceDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListDeviceDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListDeviceDefinitionVersionsRequest {
    DeviceDefinitionId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListDeviceDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListFunctionDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListFunctionDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListFunctionDefinitionVersionsRequest {
    FunctionDefinitionId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListFunctionDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListGroupCertificateAuthoritiesRequest {
    GroupId: string;
}
export interface GroupCertificateAuthorityProperties {
    GroupCertificateAuthorityArn?: string | undefined;
    GroupCertificateAuthorityId?: string | undefined;
}
export type __listOfGroupCertificateAuthorityProperties = GroupCertificateAuthorityProperties[];
export interface ListGroupCertificateAuthoritiesResponse {
    GroupCertificateAuthorities?: GroupCertificateAuthorityProperties[] | undefined;
}
export interface ListGroupsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface GroupInformation {
    Arn?: string | undefined;
    CreationTimestamp?: string | undefined;
    Id?: string | undefined;
    LastUpdatedTimestamp?: string | undefined;
    LatestVersion?: string | undefined;
    LatestVersionArn?: string | undefined;
    Name?: string | undefined;
}
export type __listOfGroupInformation = GroupInformation[];
export interface ListGroupsResponse {
    Groups?: GroupInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupVersionsRequest {
    GroupId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListLoggerDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListLoggerDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLoggerDefinitionVersionsRequest {
    LoggerDefinitionId: string;
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListLoggerDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListResourceDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListResourceDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListResourceDefinitionVersionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
    ResourceDefinitionId: string;
}
export interface ListResourceDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListSubscriptionDefinitionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListSubscriptionDefinitionsResponse {
    Definitions?: DefinitionInformation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSubscriptionDefinitionVersionsRequest {
    MaxResults?: string | undefined;
    NextToken?: string | undefined;
    SubscriptionDefinitionId: string;
}
export interface ListSubscriptionDefinitionVersionsResponse {
    NextToken?: string | undefined;
    Versions?: VersionInformation[] | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ResetDeploymentsRequest {
    AmznClientToken?: string | undefined;
    Force?: boolean | undefined;
    GroupId: string;
}
export interface ResetDeploymentsResponse {
    DeploymentArn?: string | undefined;
    DeploymentId?: string | undefined;
}
export interface StartBulkDeploymentRequest {
    AmznClientToken?: string | undefined;
    ExecutionRoleArn?: string | undefined;
    InputFileUri?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartBulkDeploymentResponse {
    BulkDeploymentArn?: string | undefined;
    BulkDeploymentId?: string | undefined;
}
export interface StopBulkDeploymentRequest {
    BulkDeploymentId: string;
}
export interface StopBulkDeploymentResponse {
}
export interface TagResourceRequest {
    ResourceArn: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateConnectivityInfoRequest {
    ConnectivityInfo?: ConnectivityInfo[] | undefined;
    ThingName: string;
}
export interface UpdateConnectivityInfoResponse {
    Message?: string | undefined;
    Version?: string | undefined;
}
export interface UpdateConnectorDefinitionRequest {
    ConnectorDefinitionId: string;
    Name?: string | undefined;
}
export interface UpdateConnectorDefinitionResponse {
}
export interface UpdateCoreDefinitionRequest {
    CoreDefinitionId: string;
    Name?: string | undefined;
}
export interface UpdateCoreDefinitionResponse {
}
export interface UpdateDeviceDefinitionRequest {
    DeviceDefinitionId: string;
    Name?: string | undefined;
}
export interface UpdateDeviceDefinitionResponse {
}
export interface UpdateFunctionDefinitionRequest {
    FunctionDefinitionId: string;
    Name?: string | undefined;
}
export interface UpdateFunctionDefinitionResponse {
}
export interface UpdateGroupRequest {
    GroupId: string;
    Name?: string | undefined;
}
export interface UpdateGroupResponse {
}
export interface UpdateGroupCertificateConfigurationRequest {
    CertificateExpiryInMilliseconds?: string | undefined;
    GroupId: string;
}
export interface UpdateGroupCertificateConfigurationResponse {
    CertificateAuthorityExpiryInMilliseconds?: string | undefined;
    CertificateExpiryInMilliseconds?: string | undefined;
    GroupId?: string | undefined;
}
export interface UpdateLoggerDefinitionRequest {
    LoggerDefinitionId: string;
    Name?: string | undefined;
}
export interface UpdateLoggerDefinitionResponse {
}
export interface UpdateResourceDefinitionRequest {
    Name?: string | undefined;
    ResourceDefinitionId: string;
}
export interface UpdateResourceDefinitionResponse {
}
export interface UpdateSubscriptionDefinitionRequest {
    Name?: string | undefined;
    SubscriptionDefinitionId: string;
}
export interface UpdateSubscriptionDefinitionResponse {
}
export interface TelemetryConfigurationUpdate {
    Telemetry?: Telemetry | undefined;
}
export interface UpdateThingRuntimeConfigurationRequest {
    TelemetryConfiguration?: TelemetryConfigurationUpdate | undefined;
    ThingName: string;
}
export interface UpdateThingRuntimeConfigurationResponse {
}
export type AssociateRoleToGroupError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Associates a role with a group. Your Greengrass core will use the role to access AWS cloud services. The role's permissions should allow Greengrass core Lambda functions to perform actions against the cloud.
 */
export declare const associateRoleToGroup: API.OperationMethod<AssociateRoleToGroupRequest & RegionInput, AssociateRoleToGroupResponse, AssociateRoleToGroupError, Credentials | HttpClient.HttpClient>;
export type AssociateServiceRoleToAccountError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Associates a role with your account. AWS IoT Greengrass will use the role to access your Lambda functions and AWS IoT resources. This is necessary for deployments to succeed. The role must have at least minimum permissions in the policy ''AWSGreengrassResourceAccessRolePolicy''.
 */
export declare const associateServiceRoleToAccount: API.OperationMethod<AssociateServiceRoleToAccountRequest & RegionInput, AssociateServiceRoleToAccountResponse, AssociateServiceRoleToAccountError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a connector definition. You may provide the initial version of the connector definition now or use ''CreateConnectorDefinitionVersion'' at a later time.
 */
export declare const createConnectorDefinition: API.OperationMethod<CreateConnectorDefinitionRequest & RegionInput, CreateConnectorDefinitionResponse, CreateConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a connector definition which has already been defined.
 */
export declare const createConnectorDefinitionVersion: API.OperationMethod<CreateConnectorDefinitionVersionRequest & RegionInput, CreateConnectorDefinitionVersionResponse, CreateConnectorDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a core definition. You may provide the initial version of the core definition now or use ''CreateCoreDefinitionVersion'' at a later time. Greengrass groups must each contain exactly one Greengrass core.
 */
export declare const createCoreDefinition: API.OperationMethod<CreateCoreDefinitionRequest & RegionInput, CreateCoreDefinitionResponse, CreateCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateCoreDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a core definition that has already been defined. Greengrass groups must each contain exactly one Greengrass core.
 */
export declare const createCoreDefinitionVersion: API.OperationMethod<CreateCoreDefinitionVersionRequest & RegionInput, CreateCoreDefinitionVersionResponse, CreateCoreDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateDeploymentError = BadRequestException | CommonErrors;
/**
 * Creates a deployment. ''CreateDeployment'' requests are idempotent with respect to the ''X-Amzn-Client-Token'' token and the request parameters.
 */
export declare const createDeployment: API.OperationMethod<CreateDeploymentRequest & RegionInput, CreateDeploymentResponse, CreateDeploymentError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a device definition. You may provide the initial version of the device definition now or use ''CreateDeviceDefinitionVersion'' at a later time.
 */
export declare const createDeviceDefinition: API.OperationMethod<CreateDeviceDefinitionRequest & RegionInput, CreateDeviceDefinitionResponse, CreateDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateDeviceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a device definition that has already been defined.
 */
export declare const createDeviceDefinitionVersion: API.OperationMethod<CreateDeviceDefinitionVersionRequest & RegionInput, CreateDeviceDefinitionVersionResponse, CreateDeviceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a Lambda function definition which contains a list of Lambda functions and their configurations to be used in a group. You can create an initial version of the definition by providing a list of Lambda functions and their configurations now, or use ''CreateFunctionDefinitionVersion'' later.
 */
export declare const createFunctionDefinition: API.OperationMethod<CreateFunctionDefinitionRequest & RegionInput, CreateFunctionDefinitionResponse, CreateFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a Lambda function definition that has already been defined.
 */
export declare const createFunctionDefinitionVersion: API.OperationMethod<CreateFunctionDefinitionVersionRequest & RegionInput, CreateFunctionDefinitionVersionResponse, CreateFunctionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = BadRequestException | CommonErrors;
/**
 * Creates a group. You may provide the initial version of the group or use ''CreateGroupVersion'' at a later time. Tip: You can use the ''gg_group_setup'' package (https://github.com/awslabs/aws-greengrass-group-setup) as a library or command-line application to create and deploy Greengrass groups.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGroupCertificateAuthorityError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a CA for the group. If a CA already exists, it will rotate the existing CA.
 */
export declare const createGroupCertificateAuthority: API.OperationMethod<CreateGroupCertificateAuthorityRequest & RegionInput, CreateGroupCertificateAuthorityResponse, CreateGroupCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type CreateGroupVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a group which has already been defined.
 */
export declare const createGroupVersion: API.OperationMethod<CreateGroupVersionRequest & RegionInput, CreateGroupVersionResponse, CreateGroupVersionError, Credentials | HttpClient.HttpClient>;
export type CreateLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a logger definition. You may provide the initial version of the logger definition now or use ''CreateLoggerDefinitionVersion'' at a later time.
 */
export declare const createLoggerDefinition: API.OperationMethod<CreateLoggerDefinitionRequest & RegionInput, CreateLoggerDefinitionResponse, CreateLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateLoggerDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a logger definition that has already been defined.
 */
export declare const createLoggerDefinitionVersion: API.OperationMethod<CreateLoggerDefinitionVersionRequest & RegionInput, CreateLoggerDefinitionVersionResponse, CreateLoggerDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a resource definition which contains a list of resources to be used in a group. You can create an initial version of the definition by providing a list of resources now, or use ''CreateResourceDefinitionVersion'' later.
 */
export declare const createResourceDefinition: API.OperationMethod<CreateResourceDefinitionRequest & RegionInput, CreateResourceDefinitionResponse, CreateResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateResourceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a resource definition that has already been defined.
 */
export declare const createResourceDefinitionVersion: API.OperationMethod<CreateResourceDefinitionVersionRequest & RegionInput, CreateResourceDefinitionVersionResponse, CreateResourceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type CreateSoftwareUpdateJobError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Creates a software update for a core or group of cores (specified as an IoT thing group.) Use this to update the OTA Agent as well as the Greengrass core software. It makes use of the IoT Jobs feature which provides additional commands to manage a Greengrass core software update job.
 */
export declare const createSoftwareUpdateJob: API.OperationMethod<CreateSoftwareUpdateJobRequest & RegionInput, CreateSoftwareUpdateJobResponse, CreateSoftwareUpdateJobError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Creates a subscription definition. You may provide the initial version of the subscription definition now or use ''CreateSubscriptionDefinitionVersion'' at a later time.
 */
export declare const createSubscriptionDefinition: API.OperationMethod<CreateSubscriptionDefinitionRequest & RegionInput, CreateSubscriptionDefinitionResponse, CreateSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateSubscriptionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Creates a version of a subscription definition which has already been defined.
 */
export declare const createSubscriptionDefinitionVersion: API.OperationMethod<CreateSubscriptionDefinitionVersionRequest & RegionInput, CreateSubscriptionDefinitionVersionResponse, CreateSubscriptionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a connector definition.
 */
export declare const deleteConnectorDefinition: API.OperationMethod<DeleteConnectorDefinitionRequest & RegionInput, DeleteConnectorDefinitionResponse, DeleteConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a core definition.
 */
export declare const deleteCoreDefinition: API.OperationMethod<DeleteCoreDefinitionRequest & RegionInput, DeleteCoreDefinitionResponse, DeleteCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a device definition.
 */
export declare const deleteDeviceDefinition: API.OperationMethod<DeleteDeviceDefinitionRequest & RegionInput, DeleteDeviceDefinitionResponse, DeleteDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a Lambda function definition.
 */
export declare const deleteFunctionDefinition: API.OperationMethod<DeleteFunctionDefinitionRequest & RegionInput, DeleteFunctionDefinitionResponse, DeleteFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = BadRequestException | CommonErrors;
/**
 * Deletes a group.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a logger definition.
 */
export declare const deleteLoggerDefinition: API.OperationMethod<DeleteLoggerDefinitionRequest & RegionInput, DeleteLoggerDefinitionResponse, DeleteLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a resource definition.
 */
export declare const deleteResourceDefinition: API.OperationMethod<DeleteResourceDefinitionRequest & RegionInput, DeleteResourceDefinitionResponse, DeleteResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Deletes a subscription definition.
 */
export declare const deleteSubscriptionDefinition: API.OperationMethod<DeleteSubscriptionDefinitionRequest & RegionInput, DeleteSubscriptionDefinitionResponse, DeleteSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type DisassociateRoleFromGroupError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Disassociates the role from a group.
 */
export declare const disassociateRoleFromGroup: API.OperationMethod<DisassociateRoleFromGroupRequest & RegionInput, DisassociateRoleFromGroupResponse, DisassociateRoleFromGroupError, Credentials | HttpClient.HttpClient>;
export type DisassociateServiceRoleFromAccountError = InternalServerErrorException | CommonErrors;
/**
 * Disassociates the service role from your account. Without a service role, deployments will not work.
 */
export declare const disassociateServiceRoleFromAccount: API.OperationMethod<DisassociateServiceRoleFromAccountRequest & RegionInput, DisassociateServiceRoleFromAccountResponse, DisassociateServiceRoleFromAccountError, Credentials | HttpClient.HttpClient>;
export type GetAssociatedRoleError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the role associated with a particular group.
 */
export declare const getAssociatedRole: API.OperationMethod<GetAssociatedRoleRequest & RegionInput, GetAssociatedRoleResponse, GetAssociatedRoleError, Credentials | HttpClient.HttpClient>;
export type GetBulkDeploymentStatusError = BadRequestException | CommonErrors;
/**
 * Returns the status of a bulk deployment.
 */
export declare const getBulkDeploymentStatus: API.OperationMethod<GetBulkDeploymentStatusRequest & RegionInput, GetBulkDeploymentStatusResponse, GetBulkDeploymentStatusError, Credentials | HttpClient.HttpClient>;
export type GetConnectivityInfoError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the connectivity information for a core.
 */
export declare const getConnectivityInfo: API.OperationMethod<GetConnectivityInfoRequest & RegionInput, GetConnectivityInfoResponse, GetConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a connector definition.
 */
export declare const getConnectorDefinition: API.OperationMethod<GetConnectorDefinitionRequest & RegionInput, GetConnectorDefinitionResponse, GetConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetConnectorDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a connector definition version, including the connectors that the version contains. Connectors are prebuilt modules that interact with local infrastructure, device protocols, AWS, and other cloud services.
 */
export declare const getConnectorDefinitionVersion: API.OperationMethod<GetConnectorDefinitionVersionRequest & RegionInput, GetConnectorDefinitionVersionResponse, GetConnectorDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a core definition version.
 */
export declare const getCoreDefinition: API.OperationMethod<GetCoreDefinitionRequest & RegionInput, GetCoreDefinitionResponse, GetCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetCoreDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a core definition version.
 */
export declare const getCoreDefinitionVersion: API.OperationMethod<GetCoreDefinitionVersionRequest & RegionInput, GetCoreDefinitionVersionResponse, GetCoreDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetDeploymentStatusError = BadRequestException | CommonErrors;
/**
 * Returns the status of a deployment.
 */
export declare const getDeploymentStatus: API.OperationMethod<GetDeploymentStatusRequest & RegionInput, GetDeploymentStatusResponse, GetDeploymentStatusError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a device definition.
 */
export declare const getDeviceDefinition: API.OperationMethod<GetDeviceDefinitionRequest & RegionInput, GetDeviceDefinitionResponse, GetDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetDeviceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a device definition version.
 */
export declare const getDeviceDefinitionVersion: API.OperationMethod<GetDeviceDefinitionVersionRequest & RegionInput, GetDeviceDefinitionVersionResponse, GetDeviceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a Lambda function definition, including its creation time and latest version.
 */
export declare const getFunctionDefinition: API.OperationMethod<GetFunctionDefinitionRequest & RegionInput, GetFunctionDefinitionResponse, GetFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetFunctionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a Lambda function definition version, including which Lambda functions are included in the version and their configurations.
 */
export declare const getFunctionDefinitionVersion: API.OperationMethod<GetFunctionDefinitionVersionRequest & RegionInput, GetFunctionDefinitionVersionResponse, GetFunctionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetGroupError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a group.
 */
export declare const getGroup: API.OperationMethod<GetGroupRequest & RegionInput, GetGroupResponse, GetGroupError, Credentials | HttpClient.HttpClient>;
export type GetGroupCertificateAuthorityError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retreives the CA associated with a group. Returns the public key of the CA.
 */
export declare const getGroupCertificateAuthority: API.OperationMethod<GetGroupCertificateAuthorityRequest & RegionInput, GetGroupCertificateAuthorityResponse, GetGroupCertificateAuthorityError, Credentials | HttpClient.HttpClient>;
export type GetGroupCertificateConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the current configuration for the CA used by the group.
 */
export declare const getGroupCertificateConfiguration: API.OperationMethod<GetGroupCertificateConfigurationRequest & RegionInput, GetGroupCertificateConfigurationResponse, GetGroupCertificateConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetGroupVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a group version.
 */
export declare const getGroupVersion: API.OperationMethod<GetGroupVersionRequest & RegionInput, GetGroupVersionResponse, GetGroupVersionError, Credentials | HttpClient.HttpClient>;
export type GetLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a logger definition.
 */
export declare const getLoggerDefinition: API.OperationMethod<GetLoggerDefinitionRequest & RegionInput, GetLoggerDefinitionResponse, GetLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetLoggerDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a logger definition version.
 */
export declare const getLoggerDefinitionVersion: API.OperationMethod<GetLoggerDefinitionVersionRequest & RegionInput, GetLoggerDefinitionVersionResponse, GetLoggerDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a resource definition, including its creation time and latest version.
 */
export declare const getResourceDefinition: API.OperationMethod<GetResourceDefinitionRequest & RegionInput, GetResourceDefinitionResponse, GetResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetResourceDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a resource definition version, including which resources are included in the version.
 */
export declare const getResourceDefinitionVersion: API.OperationMethod<GetResourceDefinitionVersionRequest & RegionInput, GetResourceDefinitionVersionResponse, GetResourceDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetServiceRoleForAccountError = InternalServerErrorException | CommonErrors;
/**
 * Retrieves the service role that is attached to your account.
 */
export declare const getServiceRoleForAccount: API.OperationMethod<GetServiceRoleForAccountRequest & RegionInput, GetServiceRoleForAccountResponse, GetServiceRoleForAccountError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a subscription definition.
 */
export declare const getSubscriptionDefinition: API.OperationMethod<GetSubscriptionDefinitionRequest & RegionInput, GetSubscriptionDefinitionResponse, GetSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionDefinitionVersionError = BadRequestException | CommonErrors;
/**
 * Retrieves information about a subscription definition version.
 */
export declare const getSubscriptionDefinitionVersion: API.OperationMethod<GetSubscriptionDefinitionVersionRequest & RegionInput, GetSubscriptionDefinitionVersionResponse, GetSubscriptionDefinitionVersionError, Credentials | HttpClient.HttpClient>;
export type GetThingRuntimeConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Get the runtime configuration of a thing.
 */
export declare const getThingRuntimeConfiguration: API.OperationMethod<GetThingRuntimeConfigurationRequest & RegionInput, GetThingRuntimeConfigurationResponse, GetThingRuntimeConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListBulkDeploymentDetailedReportsError = BadRequestException | CommonErrors;
/**
 * Gets a paginated list of the deployments that have been started in a bulk deployment operation, and their current deployment status.
 */
export declare const listBulkDeploymentDetailedReports: API.OperationMethod<ListBulkDeploymentDetailedReportsRequest & RegionInput, ListBulkDeploymentDetailedReportsResponse, ListBulkDeploymentDetailedReportsError, Credentials | HttpClient.HttpClient>;
export type ListBulkDeploymentsError = BadRequestException | CommonErrors;
/**
 * Returns a list of bulk deployments.
 */
export declare const listBulkDeployments: API.OperationMethod<ListBulkDeploymentsRequest & RegionInput, ListBulkDeploymentsResponse, ListBulkDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorDefinitionsError = CommonErrors;
/**
 * Retrieves a list of connector definitions.
 */
export declare const listConnectorDefinitions: API.OperationMethod<ListConnectorDefinitionsRequest & RegionInput, ListConnectorDefinitionsResponse, ListConnectorDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a connector definition, which are containers for connectors. Connectors run on the Greengrass core and contain built-in integration with local infrastructure, device protocols, AWS, and other cloud services.
 */
export declare const listConnectorDefinitionVersions: API.OperationMethod<ListConnectorDefinitionVersionsRequest & RegionInput, ListConnectorDefinitionVersionsResponse, ListConnectorDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListCoreDefinitionsError = CommonErrors;
/**
 * Retrieves a list of core definitions.
 */
export declare const listCoreDefinitions: API.OperationMethod<ListCoreDefinitionsRequest & RegionInput, ListCoreDefinitionsResponse, ListCoreDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListCoreDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a core definition.
 */
export declare const listCoreDefinitionVersions: API.OperationMethod<ListCoreDefinitionVersionsRequest & RegionInput, ListCoreDefinitionVersionsResponse, ListCoreDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListDeploymentsError = BadRequestException | CommonErrors;
/**
 * Returns a history of deployments for the group.
 */
export declare const listDeployments: API.OperationMethod<ListDeploymentsRequest & RegionInput, ListDeploymentsResponse, ListDeploymentsError, Credentials | HttpClient.HttpClient>;
export type ListDeviceDefinitionsError = CommonErrors;
/**
 * Retrieves a list of device definitions.
 */
export declare const listDeviceDefinitions: API.OperationMethod<ListDeviceDefinitionsRequest & RegionInput, ListDeviceDefinitionsResponse, ListDeviceDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListDeviceDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a device definition.
 */
export declare const listDeviceDefinitionVersions: API.OperationMethod<ListDeviceDefinitionVersionsRequest & RegionInput, ListDeviceDefinitionVersionsResponse, ListDeviceDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListFunctionDefinitionsError = CommonErrors;
/**
 * Retrieves a list of Lambda function definitions.
 */
export declare const listFunctionDefinitions: API.OperationMethod<ListFunctionDefinitionsRequest & RegionInput, ListFunctionDefinitionsResponse, ListFunctionDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListFunctionDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a Lambda function definition.
 */
export declare const listFunctionDefinitionVersions: API.OperationMethod<ListFunctionDefinitionVersionsRequest & RegionInput, ListFunctionDefinitionVersionsResponse, ListFunctionDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListGroupCertificateAuthoritiesError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Retrieves the current CAs for a group.
 */
export declare const listGroupCertificateAuthorities: API.OperationMethod<ListGroupCertificateAuthoritiesRequest & RegionInput, ListGroupCertificateAuthoritiesResponse, ListGroupCertificateAuthoritiesError, Credentials | HttpClient.HttpClient>;
export type ListGroupsError = CommonErrors;
/**
 * Retrieves a list of groups.
 */
export declare const listGroups: API.OperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient>;
export type ListGroupVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a group.
 */
export declare const listGroupVersions: API.OperationMethod<ListGroupVersionsRequest & RegionInput, ListGroupVersionsResponse, ListGroupVersionsError, Credentials | HttpClient.HttpClient>;
export type ListLoggerDefinitionsError = CommonErrors;
/**
 * Retrieves a list of logger definitions.
 */
export declare const listLoggerDefinitions: API.OperationMethod<ListLoggerDefinitionsRequest & RegionInput, ListLoggerDefinitionsResponse, ListLoggerDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListLoggerDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a logger definition.
 */
export declare const listLoggerDefinitionVersions: API.OperationMethod<ListLoggerDefinitionVersionsRequest & RegionInput, ListLoggerDefinitionVersionsResponse, ListLoggerDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListResourceDefinitionsError = CommonErrors;
/**
 * Retrieves a list of resource definitions.
 */
export declare const listResourceDefinitions: API.OperationMethod<ListResourceDefinitionsRequest & RegionInput, ListResourceDefinitionsResponse, ListResourceDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListResourceDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a resource definition.
 */
export declare const listResourceDefinitionVersions: API.OperationMethod<ListResourceDefinitionVersionsRequest & RegionInput, ListResourceDefinitionVersionsResponse, ListResourceDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListSubscriptionDefinitionsError = CommonErrors;
/**
 * Retrieves a list of subscription definitions.
 */
export declare const listSubscriptionDefinitions: API.OperationMethod<ListSubscriptionDefinitionsRequest & RegionInput, ListSubscriptionDefinitionsResponse, ListSubscriptionDefinitionsError, Credentials | HttpClient.HttpClient>;
export type ListSubscriptionDefinitionVersionsError = BadRequestException | CommonErrors;
/**
 * Lists the versions of a subscription definition.
 */
export declare const listSubscriptionDefinitionVersions: API.OperationMethod<ListSubscriptionDefinitionVersionsRequest & RegionInput, ListSubscriptionDefinitionVersionsResponse, ListSubscriptionDefinitionVersionsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = BadRequestException | CommonErrors;
/**
 * Retrieves a list of resource tags for a resource arn.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ResetDeploymentsError = BadRequestException | CommonErrors;
/**
 * Resets a group's deployments.
 */
export declare const resetDeployments: API.OperationMethod<ResetDeploymentsRequest & RegionInput, ResetDeploymentsResponse, ResetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type StartBulkDeploymentError = BadRequestException | CommonErrors;
/**
 * Deploys multiple groups in one operation. This action starts the bulk deployment of a specified set of group versions. Each group version deployment will be triggered with an adaptive rate that has a fixed upper limit. We recommend that you include an ''X-Amzn-Client-Token'' token in every ''StartBulkDeployment'' request. These requests are idempotent with respect to the token and the request parameters.
 */
export declare const startBulkDeployment: API.OperationMethod<StartBulkDeploymentRequest & RegionInput, StartBulkDeploymentResponse, StartBulkDeploymentError, Credentials | HttpClient.HttpClient>;
export type StopBulkDeploymentError = BadRequestException | CommonErrors;
/**
 * Stops the execution of a bulk deployment. This action returns a status of ''Stopping'' until the deployment is stopped. You cannot start a new bulk deployment while a previous deployment is in the ''Stopping'' state. This action doesn't rollback completed deployments or cancel pending deployments.
 */
export declare const stopBulkDeployment: API.OperationMethod<StopBulkDeploymentRequest & RegionInput, StopBulkDeploymentResponse, StopBulkDeploymentError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = BadRequestException | CommonErrors;
/**
 * Adds tags to a Greengrass resource. Valid resources are 'Group', 'ConnectorDefinition', 'CoreDefinition', 'DeviceDefinition', 'FunctionDefinition', 'LoggerDefinition', 'SubscriptionDefinition', 'ResourceDefinition', and 'BulkDeployment'.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = BadRequestException | CommonErrors;
/**
 * Remove resource tags from a Greengrass Resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectivityInfoError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the connectivity information for the core. Any devices that belong to the group which has this core will receive this information in order to find the location of the core and connect to it.
 */
export declare const updateConnectivityInfo: API.OperationMethod<UpdateConnectivityInfoRequest & RegionInput, UpdateConnectivityInfoResponse, UpdateConnectivityInfoError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a connector definition.
 */
export declare const updateConnectorDefinition: API.OperationMethod<UpdateConnectorDefinitionRequest & RegionInput, UpdateConnectorDefinitionResponse, UpdateConnectorDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateCoreDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a core definition.
 */
export declare const updateCoreDefinition: API.OperationMethod<UpdateCoreDefinitionRequest & RegionInput, UpdateCoreDefinitionResponse, UpdateCoreDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a device definition.
 */
export declare const updateDeviceDefinition: API.OperationMethod<UpdateDeviceDefinitionRequest & RegionInput, UpdateDeviceDefinitionResponse, UpdateDeviceDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a Lambda function definition.
 */
export declare const updateFunctionDefinition: API.OperationMethod<UpdateFunctionDefinitionRequest & RegionInput, UpdateFunctionDefinitionResponse, UpdateFunctionDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = BadRequestException | CommonErrors;
/**
 * Updates a group.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupCertificateConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the Certificate expiry time for a group.
 */
export declare const updateGroupCertificateConfiguration: API.OperationMethod<UpdateGroupCertificateConfigurationRequest & RegionInput, UpdateGroupCertificateConfigurationResponse, UpdateGroupCertificateConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLoggerDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a logger definition.
 */
export declare const updateLoggerDefinition: API.OperationMethod<UpdateLoggerDefinitionRequest & RegionInput, UpdateLoggerDefinitionResponse, UpdateLoggerDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateResourceDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a resource definition.
 */
export declare const updateResourceDefinition: API.OperationMethod<UpdateResourceDefinitionRequest & RegionInput, UpdateResourceDefinitionResponse, UpdateResourceDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionDefinitionError = BadRequestException | CommonErrors;
/**
 * Updates a subscription definition.
 */
export declare const updateSubscriptionDefinition: API.OperationMethod<UpdateSubscriptionDefinitionRequest & RegionInput, UpdateSubscriptionDefinitionResponse, UpdateSubscriptionDefinitionError, Credentials | HttpClient.HttpClient>;
export type UpdateThingRuntimeConfigurationError = BadRequestException | InternalServerErrorException | CommonErrors;
/**
 * Updates the runtime configuration of a thing.
 */
export declare const updateThingRuntimeConfiguration: API.OperationMethod<UpdateThingRuntimeConfigurationRequest & RegionInput, UpdateThingRuntimeConfigurationResponse, UpdateThingRuntimeConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=greengrass.d.ts.map