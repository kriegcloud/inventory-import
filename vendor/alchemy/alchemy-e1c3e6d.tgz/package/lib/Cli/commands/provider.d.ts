import { Command } from "effect/cli";
import * as Alchemist from "../../Alchemist/index.ts";
import * as Contributions from "../../Contributions.ts";
import { Interaction } from "../../Interaction.ts";
/**
 * `alchemy provider`: `check-env` plus each provider's provider subcommand. A
 * provider whose CLI fails to load never blocks another's: it runs as a
 * command failing with its error.
 */
export declare const providerCommand: (providers: ReadonlyArray<Contributions.Contributions>) => Promise<Command.Command<"provider", {} | {}, {}, Alchemist.AlchemistInvalidInput | Contributions.ContributionFailure | import("../../Auth/Profile.ts").ProfileError | import("../../Alchemist/AuthRegistry.ts").CollectAuthProvidersError, import("../../AlchemyContext.ts").AlchemyContext | import("../../Artifacts.ts").ArtifactStore | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | Interaction | import("effect/Path").Path | import("../../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom | import("effect/Stdio").Stdio | import("effect/Terminal").Terminal | import("effect/socket/Socket").WebSocketConstructor>>;
//# sourceMappingURL=provider.d.ts.map