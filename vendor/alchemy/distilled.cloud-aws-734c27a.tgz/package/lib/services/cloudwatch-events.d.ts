import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}>;
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const IllegalStatusException_base: S.TaggedErrorClass<"IllegalStatusException", {
    readonly message: any;
}>;
export declare class IllegalStatusException extends /*@__PURE__*/ IllegalStatusException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
}>;
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InvalidEventPatternException_base: S.TaggedErrorClass<"InvalidEventPatternException", {
    readonly message: any;
}>;
export declare class InvalidEventPatternException extends /*@__PURE__*/ InvalidEventPatternException_base {
}
declare const InvalidStateException_base: S.TaggedErrorClass<"InvalidStateException", {
    readonly message: any;
}>;
export declare class InvalidStateException extends /*@__PURE__*/ InvalidStateException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ManagedRuleException_base: S.TaggedErrorClass<"ManagedRuleException", {
    readonly message: any;
}>;
export declare class ManagedRuleException extends /*@__PURE__*/ ManagedRuleException_base {
}
declare const OperationDisabledException_base: S.TaggedErrorClass<"OperationDisabledException", {
    readonly message: any;
}>;
export declare class OperationDisabledException extends /*@__PURE__*/ OperationDisabledException_base {
}
declare const PolicyLengthExceededException_base: S.TaggedErrorClass<"PolicyLengthExceededException", {
    readonly message: any;
}>;
export declare class PolicyLengthExceededException extends /*@__PURE__*/ PolicyLengthExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}>;
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
export type EventSourceName = string;
export interface ActivateEventSourceRequest {
    Name: string;
}
export interface ActivateEventSourceResponse {
}
export type ReplayName = string;
export interface CancelReplayRequest {
    ReplayName: string;
}
export type ReplayArn = string;
export type ReplayState = "STARTING" | "RUNNING" | "CANCELLING" | "COMPLETED" | "CANCELLED" | "FAILED" | (string & {});
export type ReplayStateReason = string;
export interface CancelReplayResponse {
    ReplayArn?: string | undefined;
    State?: ReplayState | undefined;
    StateReason?: string | undefined;
}
export type ApiDestinationName = string;
export type ApiDestinationDescription = string;
export type ConnectionArn = string;
export type HttpsEndpoint = string;
export type ApiDestinationHttpMethod = "POST" | "GET" | "HEAD" | "OPTIONS" | "PUT" | "PATCH" | "DELETE" | (string & {});
export type ApiDestinationInvocationRateLimitPerSecond = number;
export interface CreateApiDestinationRequest {
    Name: string;
    Description?: string | undefined;
    ConnectionArn: string;
    InvocationEndpoint: string;
    HttpMethod: ApiDestinationHttpMethod;
    InvocationRateLimitPerSecond?: number | undefined;
}
export type ApiDestinationArn = string;
export type ApiDestinationState = "ACTIVE" | "INACTIVE" | (string & {});
export interface CreateApiDestinationResponse {
    ApiDestinationArn?: string | undefined;
    ApiDestinationState?: ApiDestinationState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ArchiveName = string;
export type Arn = string;
export type ArchiveDescription = string;
export type EventPattern = string;
export type RetentionDays = number;
export interface CreateArchiveRequest {
    ArchiveName: string;
    EventSourceArn: string;
    Description?: string | undefined;
    EventPattern?: string | undefined;
    RetentionDays?: number | undefined;
}
export type ArchiveArn = string;
export type ArchiveState = "ENABLED" | "DISABLED" | "CREATING" | "UPDATING" | "CREATE_FAILED" | "UPDATE_FAILED" | (string & {});
export type ArchiveStateReason = string;
export interface CreateArchiveResponse {
    ArchiveArn?: string | undefined;
    State?: ArchiveState | undefined;
    StateReason?: string | undefined;
    CreationTime?: Date | undefined;
}
export type ConnectionName = string;
export type ConnectionDescription = string;
export type ConnectionAuthorizationType = "BASIC" | "OAUTH_CLIENT_CREDENTIALS" | "API_KEY" | (string & {});
export type AuthHeaderParameters = string;
export type AuthHeaderParametersSensitive = string | redacted.Redacted<string>;
export interface CreateConnectionBasicAuthRequestParameters {
    Username: string;
    Password: string | redacted.Redacted<string>;
}
export interface CreateConnectionOAuthClientRequestParameters {
    ClientID: string;
    ClientSecret: string | redacted.Redacted<string>;
}
export type ConnectionOAuthHttpMethod = "GET" | "POST" | "PUT" | (string & {});
export type HeaderKey = string;
export type HeaderValueSensitive = string | redacted.Redacted<string>;
export interface ConnectionHeaderParameter {
    Key?: string | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    IsValueSecret?: boolean | undefined;
}
export type ConnectionHeaderParametersList = ConnectionHeaderParameter[];
export type QueryStringKey = string;
export type QueryStringValueSensitive = string | redacted.Redacted<string>;
export interface ConnectionQueryStringParameter {
    Key?: string | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    IsValueSecret?: boolean | undefined;
}
export type ConnectionQueryStringParametersList = ConnectionQueryStringParameter[];
export type SensitiveString = string | redacted.Redacted<string>;
export interface ConnectionBodyParameter {
    Key?: string | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
    IsValueSecret?: boolean | undefined;
}
export type ConnectionBodyParametersList = ConnectionBodyParameter[];
export interface ConnectionHttpParameters {
    HeaderParameters?: ConnectionHeaderParameter[] | undefined;
    QueryStringParameters?: ConnectionQueryStringParameter[] | undefined;
    BodyParameters?: ConnectionBodyParameter[] | undefined;
}
export interface CreateConnectionOAuthRequestParameters {
    ClientParameters: CreateConnectionOAuthClientRequestParameters;
    AuthorizationEndpoint: string;
    HttpMethod: ConnectionOAuthHttpMethod;
    OAuthHttpParameters?: ConnectionHttpParameters | undefined;
}
export interface CreateConnectionApiKeyAuthRequestParameters {
    ApiKeyName: string;
    ApiKeyValue: string | redacted.Redacted<string>;
}
export interface CreateConnectionAuthRequestParameters {
    BasicAuthParameters?: CreateConnectionBasicAuthRequestParameters | undefined;
    OAuthParameters?: CreateConnectionOAuthRequestParameters | undefined;
    ApiKeyAuthParameters?: CreateConnectionApiKeyAuthRequestParameters | undefined;
    InvocationHttpParameters?: ConnectionHttpParameters | undefined;
}
export interface CreateConnectionRequest {
    Name: string;
    Description?: string | undefined;
    AuthorizationType: ConnectionAuthorizationType;
    AuthParameters: CreateConnectionAuthRequestParameters;
}
export type ConnectionState = "CREATING" | "UPDATING" | "DELETING" | "AUTHORIZED" | "DEAUTHORIZED" | "AUTHORIZING" | "DEAUTHORIZING" | (string & {});
export interface CreateConnectionResponse {
    ConnectionArn?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type EventBusName = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateEventBusRequest {
    Name: string;
    EventSourceName?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateEventBusResponse {
    EventBusArn?: string | undefined;
}
export type AccountId = string;
export interface CreatePartnerEventSourceRequest {
    Name: string;
    Account: string;
}
export interface CreatePartnerEventSourceResponse {
    EventSourceArn?: string | undefined;
}
export interface DeactivateEventSourceRequest {
    Name: string;
}
export interface DeactivateEventSourceResponse {
}
export interface DeauthorizeConnectionRequest {
    Name: string;
}
export interface DeauthorizeConnectionResponse {
    ConnectionArn?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastAuthorizedTime?: Date | undefined;
}
export interface DeleteApiDestinationRequest {
    Name: string;
}
export interface DeleteApiDestinationResponse {
}
export interface DeleteArchiveRequest {
    ArchiveName: string;
}
export interface DeleteArchiveResponse {
}
export interface DeleteConnectionRequest {
    Name: string;
}
export interface DeleteConnectionResponse {
    ConnectionArn?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastAuthorizedTime?: Date | undefined;
}
export interface DeleteEventBusRequest {
    Name: string;
}
export interface DeleteEventBusResponse {
}
export interface DeletePartnerEventSourceRequest {
    Name: string;
    Account: string;
}
export interface DeletePartnerEventSourceResponse {
}
export type RuleName = string;
export type EventBusNameOrArn = string;
export interface DeleteRuleRequest {
    Name: string;
    EventBusName?: string | undefined;
    Force?: boolean | undefined;
}
export interface DeleteRuleResponse {
}
export interface DescribeApiDestinationRequest {
    Name: string;
}
export interface DescribeApiDestinationResponse {
    ApiDestinationArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ApiDestinationState?: ApiDestinationState | undefined;
    ConnectionArn?: string | undefined;
    InvocationEndpoint?: string | undefined;
    HttpMethod?: ApiDestinationHttpMethod | undefined;
    InvocationRateLimitPerSecond?: number | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface DescribeArchiveRequest {
    ArchiveName: string;
}
export interface DescribeArchiveResponse {
    ArchiveArn?: string | undefined;
    ArchiveName?: string | undefined;
    EventSourceArn?: string | undefined;
    Description?: string | undefined;
    EventPattern?: string | undefined;
    State?: ArchiveState | undefined;
    StateReason?: string | undefined;
    RetentionDays?: number | undefined;
    SizeBytes?: number | undefined;
    EventCount?: number | undefined;
    CreationTime?: Date | undefined;
}
export interface DescribeConnectionRequest {
    Name: string;
}
export type ConnectionStateReason = string;
export type SecretsManagerSecretArn = string;
export interface ConnectionBasicAuthResponseParameters {
    Username?: string | undefined;
}
export interface ConnectionOAuthClientResponseParameters {
    ClientID?: string | undefined;
}
export interface ConnectionOAuthResponseParameters {
    ClientParameters?: ConnectionOAuthClientResponseParameters | undefined;
    AuthorizationEndpoint?: string | undefined;
    HttpMethod?: ConnectionOAuthHttpMethod | undefined;
    OAuthHttpParameters?: ConnectionHttpParameters | undefined;
}
export interface ConnectionApiKeyAuthResponseParameters {
    ApiKeyName?: string | undefined;
}
export interface ConnectionAuthResponseParameters {
    BasicAuthParameters?: ConnectionBasicAuthResponseParameters | undefined;
    OAuthParameters?: ConnectionOAuthResponseParameters | undefined;
    ApiKeyAuthParameters?: ConnectionApiKeyAuthResponseParameters | undefined;
    InvocationHttpParameters?: ConnectionHttpParameters | undefined;
}
export interface DescribeConnectionResponse {
    ConnectionArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    StateReason?: string | undefined;
    AuthorizationType?: ConnectionAuthorizationType | undefined;
    SecretArn?: string | undefined;
    AuthParameters?: ConnectionAuthResponseParameters | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastAuthorizedTime?: Date | undefined;
}
export interface DescribeEventBusRequest {
    Name?: string | undefined;
}
export interface DescribeEventBusResponse {
    Name?: string | undefined;
    Arn?: string | undefined;
    Policy?: string | undefined;
}
export interface DescribeEventSourceRequest {
    Name: string;
}
export type EventSourceState = "PENDING" | "ACTIVE" | "DELETED" | (string & {});
export interface DescribeEventSourceResponse {
    Arn?: string | undefined;
    CreatedBy?: string | undefined;
    CreationTime?: Date | undefined;
    ExpirationTime?: Date | undefined;
    Name?: string | undefined;
    State?: EventSourceState | undefined;
}
export interface DescribePartnerEventSourceRequest {
    Name: string;
}
export interface DescribePartnerEventSourceResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export interface DescribeReplayRequest {
    ReplayName: string;
}
export type ReplayDescription = string;
export type ReplayDestinationFilters = string[];
export interface ReplayDestination {
    Arn: string;
    FilterArns?: string[] | undefined;
}
export interface DescribeReplayResponse {
    ReplayName?: string | undefined;
    ReplayArn?: string | undefined;
    Description?: string | undefined;
    State?: ReplayState | undefined;
    StateReason?: string | undefined;
    EventSourceArn?: string | undefined;
    Destination?: ReplayDestination | undefined;
    EventStartTime?: Date | undefined;
    EventEndTime?: Date | undefined;
    EventLastReplayedTime?: Date | undefined;
    ReplayStartTime?: Date | undefined;
    ReplayEndTime?: Date | undefined;
}
export interface DescribeRuleRequest {
    Name: string;
    EventBusName?: string | undefined;
}
export type RuleArn = string;
export type ScheduleExpression = string;
export type RuleState = "ENABLED" | "DISABLED" | (string & {});
export type RuleDescription = string;
export type RoleArn = string;
export type ManagedBy = string;
export type CreatedBy = string;
export interface DescribeRuleResponse {
    Name?: string | undefined;
    Arn?: string | undefined;
    EventPattern?: string | undefined;
    ScheduleExpression?: string | undefined;
    State?: RuleState | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    ManagedBy?: string | undefined;
    EventBusName?: string | undefined;
    CreatedBy?: string | undefined;
}
export interface DisableRuleRequest {
    Name: string;
    EventBusName?: string | undefined;
}
export interface DisableRuleResponse {
}
export interface EnableRuleRequest {
    Name: string;
    EventBusName?: string | undefined;
}
export interface EnableRuleResponse {
}
export type NextToken = string;
export type LimitMax100 = number;
export interface ListApiDestinationsRequest {
    NamePrefix?: string | undefined;
    ConnectionArn?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface ApiDestination {
    ApiDestinationArn?: string | undefined;
    Name?: string | undefined;
    ApiDestinationState?: ApiDestinationState | undefined;
    ConnectionArn?: string | undefined;
    InvocationEndpoint?: string | undefined;
    HttpMethod?: ApiDestinationHttpMethod | undefined;
    InvocationRateLimitPerSecond?: number | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export type ApiDestinationResponseList = ApiDestination[];
export interface ListApiDestinationsResponse {
    ApiDestinations?: ApiDestination[] | undefined;
    NextToken?: string | undefined;
}
export interface ListArchivesRequest {
    NamePrefix?: string | undefined;
    EventSourceArn?: string | undefined;
    State?: ArchiveState | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface Archive {
    ArchiveName?: string | undefined;
    EventSourceArn?: string | undefined;
    State?: ArchiveState | undefined;
    StateReason?: string | undefined;
    RetentionDays?: number | undefined;
    SizeBytes?: number | undefined;
    EventCount?: number | undefined;
    CreationTime?: Date | undefined;
}
export type ArchiveResponseList = Archive[];
export interface ListArchivesResponse {
    Archives?: Archive[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConnectionsRequest {
    NamePrefix?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface Connection {
    ConnectionArn?: string | undefined;
    Name?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    StateReason?: string | undefined;
    AuthorizationType?: ConnectionAuthorizationType | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastAuthorizedTime?: Date | undefined;
}
export type ConnectionResponseList = Connection[];
export interface ListConnectionsResponse {
    Connections?: Connection[] | undefined;
    NextToken?: string | undefined;
}
export interface ListEventBusesRequest {
    NamePrefix?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface EventBus {
    Name?: string | undefined;
    Arn?: string | undefined;
    Policy?: string | undefined;
}
export type EventBusList = EventBus[];
export interface ListEventBusesResponse {
    EventBuses?: EventBus[] | undefined;
    NextToken?: string | undefined;
}
export type EventSourceNamePrefix = string;
export interface ListEventSourcesRequest {
    NamePrefix?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface EventSource {
    Arn?: string | undefined;
    CreatedBy?: string | undefined;
    CreationTime?: Date | undefined;
    ExpirationTime?: Date | undefined;
    Name?: string | undefined;
    State?: EventSourceState | undefined;
}
export type EventSourceList = EventSource[];
export interface ListEventSourcesResponse {
    EventSources?: EventSource[] | undefined;
    NextToken?: string | undefined;
}
export interface ListPartnerEventSourceAccountsRequest {
    EventSourceName: string;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface PartnerEventSourceAccount {
    Account?: string | undefined;
    CreationTime?: Date | undefined;
    ExpirationTime?: Date | undefined;
    State?: EventSourceState | undefined;
}
export type PartnerEventSourceAccountList = PartnerEventSourceAccount[];
export interface ListPartnerEventSourceAccountsResponse {
    PartnerEventSourceAccounts?: PartnerEventSourceAccount[] | undefined;
    NextToken?: string | undefined;
}
export type PartnerEventSourceNamePrefix = string;
export interface ListPartnerEventSourcesRequest {
    NamePrefix: string;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface PartnerEventSource {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export type PartnerEventSourceList = PartnerEventSource[];
export interface ListPartnerEventSourcesResponse {
    PartnerEventSources?: PartnerEventSource[] | undefined;
    NextToken?: string | undefined;
}
export interface ListReplaysRequest {
    NamePrefix?: string | undefined;
    State?: ReplayState | undefined;
    EventSourceArn?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface Replay {
    ReplayName?: string | undefined;
    EventSourceArn?: string | undefined;
    State?: ReplayState | undefined;
    StateReason?: string | undefined;
    EventStartTime?: Date | undefined;
    EventEndTime?: Date | undefined;
    EventLastReplayedTime?: Date | undefined;
    ReplayStartTime?: Date | undefined;
    ReplayEndTime?: Date | undefined;
}
export type ReplayList = Replay[];
export interface ListReplaysResponse {
    Replays?: Replay[] | undefined;
    NextToken?: string | undefined;
}
export type TargetArn = string;
export interface ListRuleNamesByTargetRequest {
    TargetArn: string;
    EventBusName?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type RuleNameList = string[];
export interface ListRuleNamesByTargetResponse {
    RuleNames?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListRulesRequest {
    NamePrefix?: string | undefined;
    EventBusName?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export interface Rule {
    Name?: string | undefined;
    Arn?: string | undefined;
    EventPattern?: string | undefined;
    State?: RuleState | undefined;
    Description?: string | undefined;
    ScheduleExpression?: string | undefined;
    RoleArn?: string | undefined;
    ManagedBy?: string | undefined;
    EventBusName?: string | undefined;
}
export type RuleResponseList = Rule[];
export interface ListRulesResponse {
    Rules?: Rule[] | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListTargetsByRuleRequest {
    Rule: string;
    EventBusName?: string | undefined;
    NextToken?: string | undefined;
    Limit?: number | undefined;
}
export type TargetId = string;
export type TargetInput = string;
export type TargetInputPath = string;
export type InputTransformerPathKey = string;
export type TransformerPaths = {
    [key: string]: string | undefined;
};
export type TransformerInput = string;
export interface InputTransformer {
    InputPathsMap?: {
        [key: string]: string | undefined;
    } | undefined;
    InputTemplate: string;
}
export type TargetPartitionKeyPath = string;
export interface KinesisParameters {
    PartitionKeyPath: string;
}
export type RunCommandTargetKey = string;
export type RunCommandTargetValue = string;
export type RunCommandTargetValues = string[];
export interface RunCommandTarget {
    Key: string;
    Values: string[];
}
export type RunCommandTargets = RunCommandTarget[];
export interface RunCommandParameters {
    RunCommandTargets: RunCommandTarget[];
}
export type LimitMin1 = number;
export type LaunchType = "EC2" | "FARGATE" | "EXTERNAL" | (string & {});
export type StringList = string[];
export type AssignPublicIp = "ENABLED" | "DISABLED" | (string & {});
export interface AwsVpcConfiguration {
    Subnets: string[];
    SecurityGroups?: string[] | undefined;
    AssignPublicIp?: AssignPublicIp | undefined;
}
export interface NetworkConfiguration {
    awsvpcConfiguration?: AwsVpcConfiguration | undefined;
}
export type CapacityProvider = string;
export type CapacityProviderStrategyItemWeight = number;
export type CapacityProviderStrategyItemBase = number;
export interface CapacityProviderStrategyItem {
    capacityProvider: string;
    weight?: number | undefined;
    base?: number | undefined;
}
export type CapacityProviderStrategy = CapacityProviderStrategyItem[];
export type PlacementConstraintType = "distinctInstance" | "memberOf" | (string & {});
export type PlacementConstraintExpression = string;
export interface PlacementConstraint {
    type?: PlacementConstraintType | undefined;
    expression?: string | undefined;
}
export type PlacementConstraints = PlacementConstraint[];
export type PlacementStrategyType = "random" | "spread" | "binpack" | (string & {});
export type PlacementStrategyField = string;
export interface PlacementStrategy {
    type?: PlacementStrategyType | undefined;
    field?: string | undefined;
}
export type PlacementStrategies = PlacementStrategy[];
export type PropagateTags = "TASK_DEFINITION" | (string & {});
export type ReferenceId = string;
export interface EcsParameters {
    TaskDefinitionArn: string;
    TaskCount?: number | undefined;
    LaunchType?: LaunchType | undefined;
    NetworkConfiguration?: NetworkConfiguration | undefined;
    PlatformVersion?: string | undefined;
    Group?: string | undefined;
    CapacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    EnableECSManagedTags?: boolean | undefined;
    EnableExecuteCommand?: boolean | undefined;
    PlacementConstraints?: PlacementConstraint[] | undefined;
    PlacementStrategy?: PlacementStrategy[] | undefined;
    PropagateTags?: PropagateTags | undefined;
    ReferenceId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface BatchArrayProperties {
    Size?: number | undefined;
}
export interface BatchRetryStrategy {
    Attempts?: number | undefined;
}
export interface BatchParameters {
    JobDefinition: string;
    JobName: string;
    ArrayProperties?: BatchArrayProperties | undefined;
    RetryStrategy?: BatchRetryStrategy | undefined;
}
export type MessageGroupId = string;
export interface SqsParameters {
    MessageGroupId?: string | undefined;
}
export type PathParameter = string;
export type PathParameterList = string[];
export type HeaderValue = string;
export type HeaderParametersMap = {
    [key: string]: string | undefined;
};
export type QueryStringValue = string;
export type QueryStringParametersMap = {
    [key: string]: string | undefined;
};
export interface HttpParameters {
    PathParameterValues?: string[] | undefined;
    HeaderParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    QueryStringParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RedshiftSecretManagerArn = string;
export type Database = string;
export type DbUser = string;
export type Sql = string;
export type StatementName = string;
export interface RedshiftDataParameters {
    SecretManagerArn?: string | undefined;
    Database: string;
    DbUser?: string | undefined;
    Sql: string;
    StatementName?: string | undefined;
    WithEvent?: boolean | undefined;
}
export type SageMakerPipelineParameterName = string;
export type SageMakerPipelineParameterValue = string;
export interface SageMakerPipelineParameter {
    Name: string;
    Value: string;
}
export type SageMakerPipelineParameterList = SageMakerPipelineParameter[];
export interface SageMakerPipelineParameters {
    PipelineParameterList?: SageMakerPipelineParameter[] | undefined;
}
export type ResourceArn = string;
export interface DeadLetterConfig {
    Arn?: string | undefined;
}
export type MaximumRetryAttempts = number;
export type MaximumEventAgeInSeconds = number;
export interface RetryPolicy {
    MaximumRetryAttempts?: number | undefined;
    MaximumEventAgeInSeconds?: number | undefined;
}
export interface Target {
    Id: string;
    Arn: string;
    RoleArn?: string | undefined;
    Input?: string | undefined;
    InputPath?: string | undefined;
    InputTransformer?: InputTransformer | undefined;
    KinesisParameters?: KinesisParameters | undefined;
    RunCommandParameters?: RunCommandParameters | undefined;
    EcsParameters?: EcsParameters | undefined;
    BatchParameters?: BatchParameters | undefined;
    SqsParameters?: SqsParameters | undefined;
    HttpParameters?: HttpParameters | undefined;
    RedshiftDataParameters?: RedshiftDataParameters | undefined;
    SageMakerPipelineParameters?: SageMakerPipelineParameters | undefined;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    RetryPolicy?: RetryPolicy | undefined;
}
export type TargetList = Target[];
export interface ListTargetsByRuleResponse {
    Targets?: Target[] | undefined;
    NextToken?: string | undefined;
}
export type EventTime = Date;
export type EventResource = string;
export type EventResourceList = string[];
export type NonPartnerEventBusNameOrArn = string;
export type TraceHeader = string;
export interface PutEventsRequestEntry {
    Time?: Date | undefined;
    Source?: string | undefined;
    Resources?: string[] | undefined;
    DetailType?: string | undefined;
    Detail?: string | undefined;
    EventBusName?: string | undefined;
    TraceHeader?: string | undefined;
}
export type PutEventsRequestEntryList = PutEventsRequestEntry[];
export interface PutEventsRequest {
    Entries: PutEventsRequestEntry[];
}
export type EventId = string;
export type ErrorCode = string;
export type ErrorMessage = string;
export interface PutEventsResultEntry {
    EventId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type PutEventsResultEntryList = PutEventsResultEntry[];
export interface PutEventsResponse {
    FailedEntryCount?: number | undefined;
    Entries?: PutEventsResultEntry[] | undefined;
}
export interface PutPartnerEventsRequestEntry {
    Time?: Date | undefined;
    Source?: string | undefined;
    Resources?: string[] | undefined;
    DetailType?: string | undefined;
    Detail?: string | undefined;
}
export type PutPartnerEventsRequestEntryList = PutPartnerEventsRequestEntry[];
export interface PutPartnerEventsRequest {
    Entries: PutPartnerEventsRequestEntry[];
}
export interface PutPartnerEventsResultEntry {
    EventId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type PutPartnerEventsResultEntryList = PutPartnerEventsResultEntry[];
export interface PutPartnerEventsResponse {
    FailedEntryCount?: number | undefined;
    Entries?: PutPartnerEventsResultEntry[] | undefined;
}
export type NonPartnerEventBusName = string;
export type Action = string;
export type Principal = string;
export type StatementId = string;
export interface Condition {
    Type: string;
    Key: string;
    Value: string;
}
export interface PutPermissionRequest {
    EventBusName?: string | undefined;
    Action?: string | undefined;
    Principal?: string | undefined;
    StatementId?: string | undefined;
    Condition?: Condition | undefined;
    Policy?: string | undefined;
}
export interface PutPermissionResponse {
}
export interface PutRuleRequest {
    Name: string;
    ScheduleExpression?: string | undefined;
    EventPattern?: string | undefined;
    State?: RuleState | undefined;
    Description?: string | undefined;
    RoleArn?: string | undefined;
    Tags?: Tag[] | undefined;
    EventBusName?: string | undefined;
}
export interface PutRuleResponse {
    RuleArn?: string | undefined;
}
export interface PutTargetsRequest {
    Rule: string;
    EventBusName?: string | undefined;
    Targets: Target[];
}
export interface PutTargetsResultEntry {
    TargetId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type PutTargetsResultEntryList = PutTargetsResultEntry[];
export interface PutTargetsResponse {
    FailedEntryCount?: number | undefined;
    FailedEntries?: PutTargetsResultEntry[] | undefined;
}
export interface RemovePermissionRequest {
    StatementId?: string | undefined;
    RemoveAllPermissions?: boolean | undefined;
    EventBusName?: string | undefined;
}
export interface RemovePermissionResponse {
}
export type TargetIdList = string[];
export interface RemoveTargetsRequest {
    Rule: string;
    EventBusName?: string | undefined;
    Ids: string[];
    Force?: boolean | undefined;
}
export interface RemoveTargetsResultEntry {
    TargetId?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type RemoveTargetsResultEntryList = RemoveTargetsResultEntry[];
export interface RemoveTargetsResponse {
    FailedEntryCount?: number | undefined;
    FailedEntries?: RemoveTargetsResultEntry[] | undefined;
}
export interface StartReplayRequest {
    ReplayName: string;
    Description?: string | undefined;
    EventSourceArn: string;
    EventStartTime: Date;
    EventEndTime: Date;
    Destination: ReplayDestination;
}
export interface StartReplayResponse {
    ReplayArn?: string | undefined;
    State?: ReplayState | undefined;
    StateReason?: string | undefined;
    ReplayStartTime?: Date | undefined;
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface TestEventPatternRequest {
    EventPattern: string;
    Event: string;
}
export interface TestEventPatternResponse {
    Result?: boolean | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApiDestinationRequest {
    Name: string;
    Description?: string | undefined;
    ConnectionArn?: string | undefined;
    InvocationEndpoint?: string | undefined;
    HttpMethod?: ApiDestinationHttpMethod | undefined;
    InvocationRateLimitPerSecond?: number | undefined;
}
export interface UpdateApiDestinationResponse {
    ApiDestinationArn?: string | undefined;
    ApiDestinationState?: ApiDestinationState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface UpdateArchiveRequest {
    ArchiveName: string;
    Description?: string | undefined;
    EventPattern?: string | undefined;
    RetentionDays?: number | undefined;
}
export interface UpdateArchiveResponse {
    ArchiveArn?: string | undefined;
    State?: ArchiveState | undefined;
    StateReason?: string | undefined;
    CreationTime?: Date | undefined;
}
export interface UpdateConnectionBasicAuthRequestParameters {
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateConnectionOAuthClientRequestParameters {
    ClientID?: string | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateConnectionOAuthRequestParameters {
    ClientParameters?: UpdateConnectionOAuthClientRequestParameters | undefined;
    AuthorizationEndpoint?: string | undefined;
    HttpMethod?: ConnectionOAuthHttpMethod | undefined;
    OAuthHttpParameters?: ConnectionHttpParameters | undefined;
}
export interface UpdateConnectionApiKeyAuthRequestParameters {
    ApiKeyName?: string | undefined;
    ApiKeyValue?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateConnectionAuthRequestParameters {
    BasicAuthParameters?: UpdateConnectionBasicAuthRequestParameters | undefined;
    OAuthParameters?: UpdateConnectionOAuthRequestParameters | undefined;
    ApiKeyAuthParameters?: UpdateConnectionApiKeyAuthRequestParameters | undefined;
    InvocationHttpParameters?: ConnectionHttpParameters | undefined;
}
export interface UpdateConnectionRequest {
    Name: string;
    Description?: string | undefined;
    AuthorizationType?: ConnectionAuthorizationType | undefined;
    AuthParameters?: UpdateConnectionAuthRequestParameters | undefined;
}
export interface UpdateConnectionResponse {
    ConnectionArn?: string | undefined;
    ConnectionState?: ConnectionState | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastAuthorizedTime?: Date | undefined;
}
export type ActivateEventSourceError = ConcurrentModificationException | InternalException | InvalidStateException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * Activates a partner event source that has been deactivated. Once activated, your matching
 * event bus will start receiving events from the event source.
 */
export declare const activateEventSource: API.OperationMethod<ActivateEventSourceRequest & RegionInput, ActivateEventSourceResponse, ActivateEventSourceError, Credentials | HttpClient.HttpClient>;
export type CancelReplayError = ConcurrentModificationException | IllegalStatusException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Cancels the specified replay.
 */
export declare const cancelReplay: API.OperationMethod<CancelReplayRequest & RegionInput, CancelReplayResponse, CancelReplayError, Credentials | HttpClient.HttpClient>;
export type CreateApiDestinationError = InternalException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an API destination, which is an HTTP invocation endpoint configured as a target
 * for events.
 */
export declare const createApiDestination: API.OperationMethod<CreateApiDestinationRequest & RegionInput, CreateApiDestinationResponse, CreateApiDestinationError, Credentials | HttpClient.HttpClient>;
export type CreateArchiveError = ConcurrentModificationException | InternalException | InvalidEventPatternException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates an archive of events with the specified settings. When you create an archive,
 * incoming events might not immediately start being sent to the archive. Allow a short period of
 * time for changes to take effect. If you do not specify a pattern to filter events sent to the
 * archive, all events are sent to the archive except replayed events. Replayed events are not
 * sent to an archive.
 */
export declare const createArchive: API.OperationMethod<CreateArchiveRequest & RegionInput, CreateArchiveResponse, CreateArchiveError, Credentials | HttpClient.HttpClient>;
export type CreateConnectionError = InternalException | LimitExceededException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Creates a connection. A connection defines the authorization type and credentials to use
 * for authorization with an API destination HTTP endpoint.
 */
export declare const createConnection: API.OperationMethod<CreateConnectionRequest & RegionInput, CreateConnectionResponse, CreateConnectionError, Credentials | HttpClient.HttpClient>;
export type CreateEventBusError = ConcurrentModificationException | InternalException | InvalidStateException | LimitExceededException | OperationDisabledException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Creates a new event bus within your account. This can be a custom event bus which you can
 * use to receive events from your custom applications and services, or it can be a partner event
 * bus which can be matched to a partner event source.
 */
export declare const createEventBus: API.OperationMethod<CreateEventBusRequest & RegionInput, CreateEventBusResponse, CreateEventBusError, Credentials | HttpClient.HttpClient>;
export type CreatePartnerEventSourceError = ConcurrentModificationException | InternalException | LimitExceededException | OperationDisabledException | ResourceAlreadyExistsException | CommonErrors;
/**
 * Called by an SaaS partner to create a partner event source. This operation is not used by
 * Amazon Web Services customers.
 *
 * Each partner event source can be used by one Amazon Web Services account to create a matching partner
 * event bus in that Amazon Web Services account. A SaaS partner must create one partner event source for each
 * Amazon Web Services account that wants to receive those event types.
 *
 * A partner event source creates events based on resources within the SaaS partner's service
 * or application.
 *
 * An Amazon Web Services account that creates a partner event bus that matches the partner event source can
 * use that event bus to receive events from the partner, and then process them using Amazon Web Services Events
 * rules and targets.
 *
 * Partner event source names follow this format:
 *
 * *partner_name*\/*event_namespace*\/*event_name*
 *
 * *partner_name* is determined during partner registration and identifies
 * the partner to Amazon Web Services customers. *event_namespace* is determined by the
 * partner and is a way for the partner to categorize their events.
 * *event_name* is determined by the partner, and should uniquely identify
 * an event-generating resource within the partner system. The combination of
 * *event_namespace* and *event_name* should help Amazon Web Services
 * customers decide whether to create an event bus to receive these events.
 */
export declare const createPartnerEventSource: API.OperationMethod<CreatePartnerEventSourceRequest & RegionInput, CreatePartnerEventSourceResponse, CreatePartnerEventSourceError, Credentials | HttpClient.HttpClient>;
export type DeactivateEventSourceError = ConcurrentModificationException | InternalException | InvalidStateException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * You can use this operation to temporarily stop receiving events from the specified partner
 * event source. The matching event bus is not deleted.
 *
 * When you deactivate a partner event source, the source goes into PENDING state. If it
 * remains in PENDING state for more than two weeks, it is deleted.
 *
 * To activate a deactivated partner event source, use ActivateEventSource.
 */
export declare const deactivateEventSource: API.OperationMethod<DeactivateEventSourceRequest & RegionInput, DeactivateEventSourceResponse, DeactivateEventSourceError, Credentials | HttpClient.HttpClient>;
export type DeauthorizeConnectionError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Removes all authorization parameters from the connection. This lets you remove the secret
 * from the connection so you can reuse it without having to create a new connection.
 */
export declare const deauthorizeConnection: API.OperationMethod<DeauthorizeConnectionRequest & RegionInput, DeauthorizeConnectionResponse, DeauthorizeConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteApiDestinationError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified API destination.
 */
export declare const deleteApiDestination: API.OperationMethod<DeleteApiDestinationRequest & RegionInput, DeleteApiDestinationResponse, DeleteApiDestinationError, Credentials | HttpClient.HttpClient>;
export type DeleteArchiveError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified archive.
 */
export declare const deleteArchive: API.OperationMethod<DeleteArchiveRequest & RegionInput, DeleteArchiveResponse, DeleteArchiveError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = ConcurrentModificationException | InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a connection.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionRequest & RegionInput, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteEventBusError = ConcurrentModificationException | InternalException | CommonErrors;
/**
 * Deletes the specified custom event bus or partner event bus. All rules associated with
 * this event bus need to be deleted. You can't delete your account's default event bus.
 */
export declare const deleteEventBus: API.OperationMethod<DeleteEventBusRequest & RegionInput, DeleteEventBusResponse, DeleteEventBusError, Credentials | HttpClient.HttpClient>;
export type DeletePartnerEventSourceError = ConcurrentModificationException | InternalException | OperationDisabledException | CommonErrors;
/**
 * This operation is used by SaaS partners to delete a partner event source. This operation
 * is not used by Amazon Web Services customers.
 *
 * When you delete an event source, the status of the corresponding partner event bus in the
 * Amazon Web Services customer account becomes DELETED.
 */
export declare const deletePartnerEventSource: API.OperationMethod<DeletePartnerEventSourceRequest & RegionInput, DeletePartnerEventSourceResponse, DeletePartnerEventSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified rule.
 *
 * Before you can delete the rule, you must remove all targets, using RemoveTargets.
 *
 * When you delete a rule, incoming events might continue to match to the deleted rule. Allow
 * a short period of time for changes to take effect.
 *
 * If you call delete rule multiple times for the same rule, all calls will succeed. When you
 * call delete rule for a non-existent custom eventbus, `ResourceNotFoundException` is
 * returned.
 *
 * Managed rules are rules created and managed by another Amazon Web Services service on your behalf. These
 * rules are created by those other Amazon Web Services services to support functionality in those services. You
 * can delete these rules using the `Force` option, but you should do so only if you
 * are sure the other service is not still using that rule.
 */
export declare const deleteRule: API.OperationMethod<DeleteRuleRequest & RegionInput, DeleteRuleResponse, DeleteRuleError, Credentials | HttpClient.HttpClient>;
export type DescribeApiDestinationError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about an API destination.
 */
export declare const describeApiDestination: API.OperationMethod<DescribeApiDestinationRequest & RegionInput, DescribeApiDestinationResponse, DescribeApiDestinationError, Credentials | HttpClient.HttpClient>;
export type DescribeArchiveError = InternalException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about an archive.
 */
export declare const describeArchive: API.OperationMethod<DescribeArchiveRequest & RegionInput, DescribeArchiveResponse, DescribeArchiveError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectionError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about a connection.
 */
export declare const describeConnection: API.OperationMethod<DescribeConnectionRequest & RegionInput, DescribeConnectionResponse, DescribeConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeEventBusError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Displays details about an event bus in your account. This can include the external Amazon Web Services
 * accounts that are permitted to write events to your default event bus, and the associated
 * policy. For custom event buses and partner event buses, it displays the name, ARN, policy,
 * state, and creation time.
 *
 * To enable your account to receive events from other accounts on its default event bus,
 * use PutPermission.
 *
 * For more information about partner event buses, see CreateEventBus.
 */
export declare const describeEventBus: API.OperationMethod<DescribeEventBusRequest & RegionInput, DescribeEventBusResponse, DescribeEventBusError, Credentials | HttpClient.HttpClient>;
export type DescribeEventSourceError = InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * This operation lists details about a partner event source that is shared with your
 * account.
 */
export declare const describeEventSource: API.OperationMethod<DescribeEventSourceRequest & RegionInput, DescribeEventSourceResponse, DescribeEventSourceError, Credentials | HttpClient.HttpClient>;
export type DescribePartnerEventSourceError = InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * An SaaS partner can use this operation to list details about a partner event source that
 * they have created. Amazon Web Services customers do not use this operation. Instead, Amazon Web Services customers can use DescribeEventSource
 * to see details about a partner event source that is
 * shared with them.
 */
export declare const describePartnerEventSource: API.OperationMethod<DescribePartnerEventSourceRequest & RegionInput, DescribePartnerEventSourceResponse, DescribePartnerEventSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeReplayError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves details about a replay. Use `DescribeReplay` to determine the
 * progress of a running replay. A replay processes events to replay based on the time in the
 * event, and replays them using 1 minute intervals. If you use `StartReplay` and
 * specify an `EventStartTime` and an `EventEndTime` that covers a 20
 * minute time range, the events are replayed from the first minute of that 20 minute range
 * first. Then the events from the second minute are replayed. You can use
 * `DescribeReplay` to determine the progress of a replay. The value returned for
 * `EventLastReplayedTime` indicates the time within the specified time range
 * associated with the last event replayed.
 */
export declare const describeReplay: API.OperationMethod<DescribeReplayRequest & RegionInput, DescribeReplayResponse, DescribeReplayError, Credentials | HttpClient.HttpClient>;
export type DescribeRuleError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Describes the specified rule.
 *
 * DescribeRule does not list the targets of a rule. To see the targets associated with a
 * rule, use ListTargetsByRule.
 */
export declare const describeRule: API.OperationMethod<DescribeRuleRequest & RegionInput, DescribeRuleResponse, DescribeRuleError, Credentials | HttpClient.HttpClient>;
export type DisableRuleError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Disables the specified rule. A disabled rule won't match any events, and won't
 * self-trigger if it has a schedule expression.
 *
 * When you disable a rule, incoming events might continue to match to the disabled rule.
 * Allow a short period of time for changes to take effect.
 */
export declare const disableRule: API.OperationMethod<DisableRuleRequest & RegionInput, DisableRuleResponse, DisableRuleError, Credentials | HttpClient.HttpClient>;
export type EnableRuleError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Enables the specified rule. If the rule does not exist, the operation fails.
 *
 * When you enable a rule, incoming events might not immediately start matching to a newly
 * enabled rule. Allow a short period of time for changes to take effect.
 */
export declare const enableRule: API.OperationMethod<EnableRuleRequest & RegionInput, EnableRuleResponse, EnableRuleError, Credentials | HttpClient.HttpClient>;
export type ListApiDestinationsError = InternalException | CommonErrors;
/**
 * Retrieves a list of API destination in the account in the current Region.
 */
export declare const listApiDestinations: API.OperationMethod<ListApiDestinationsRequest & RegionInput, ListApiDestinationsResponse, ListApiDestinationsError, Credentials | HttpClient.HttpClient>;
export type ListArchivesError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists your archives. You can either list all the archives or you can provide a prefix to
 * match to the archive names. Filter parameters are exclusive.
 */
export declare const listArchives: API.OperationMethod<ListArchivesRequest & RegionInput, ListArchivesResponse, ListArchivesError, Credentials | HttpClient.HttpClient>;
export type ListConnectionsError = InternalException | CommonErrors;
/**
 * Retrieves a list of connections from the account.
 */
export declare const listConnections: API.OperationMethod<ListConnectionsRequest & RegionInput, ListConnectionsResponse, ListConnectionsError, Credentials | HttpClient.HttpClient>;
export type ListEventBusesError = InternalException | CommonErrors;
/**
 * Lists all the event buses in your account, including the default event bus, custom event
 * buses, and partner event buses.
 */
export declare const listEventBuses: API.OperationMethod<ListEventBusesRequest & RegionInput, ListEventBusesResponse, ListEventBusesError, Credentials | HttpClient.HttpClient>;
export type ListEventSourcesError = InternalException | OperationDisabledException | CommonErrors;
/**
 * You can use this to see all the partner event sources that have been shared with your Amazon Web Services
 * account. For more information about partner event sources, see CreateEventBus.
 */
export declare const listEventSources: API.OperationMethod<ListEventSourcesRequest & RegionInput, ListEventSourcesResponse, ListEventSourcesError, Credentials | HttpClient.HttpClient>;
export type ListPartnerEventSourceAccountsError = InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * An SaaS partner can use this operation to display the Amazon Web Services account ID that a particular
 * partner event source name is associated with. This operation is not used by Amazon Web Services
 * customers.
 */
export declare const listPartnerEventSourceAccounts: API.OperationMethod<ListPartnerEventSourceAccountsRequest & RegionInput, ListPartnerEventSourceAccountsResponse, ListPartnerEventSourceAccountsError, Credentials | HttpClient.HttpClient>;
export type ListPartnerEventSourcesError = InternalException | OperationDisabledException | CommonErrors;
/**
 * An SaaS partner can use this operation to list all the partner event source names that
 * they have created. This operation is not used by Amazon Web Services customers.
 */
export declare const listPartnerEventSources: API.OperationMethod<ListPartnerEventSourcesRequest & RegionInput, ListPartnerEventSourcesResponse, ListPartnerEventSourcesError, Credentials | HttpClient.HttpClient>;
export type ListReplaysError = InternalException | CommonErrors;
/**
 * Lists your replays. You can either list all the replays or you can provide a prefix to
 * match to the replay names. Filter parameters are exclusive.
 */
export declare const listReplays: API.OperationMethod<ListReplaysRequest & RegionInput, ListReplaysResponse, ListReplaysError, Credentials | HttpClient.HttpClient>;
export type ListRuleNamesByTargetError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the rules for the specified target. You can see which of the rules in Amazon
 * EventBridge can invoke a specific target in your account.
 */
export declare const listRuleNamesByTarget: API.OperationMethod<ListRuleNamesByTargetRequest & RegionInput, ListRuleNamesByTargetResponse, ListRuleNamesByTargetError, Credentials | HttpClient.HttpClient>;
export type ListRulesError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists your Amazon EventBridge rules. You can either list all the rules or you can provide
 * a prefix to match to the rule names.
 *
 * ListRules does not list the targets of a rule. To see the targets associated with a rule,
 * use ListTargetsByRule.
 */
export declare const listRules: API.OperationMethod<ListRulesRequest & RegionInput, ListRulesResponse, ListRulesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Displays the tags associated with an EventBridge resource. In EventBridge, rules and event
 * buses can be tagged.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTargetsByRuleError = InternalException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the targets assigned to the specified rule.
 */
export declare const listTargetsByRule: API.OperationMethod<ListTargetsByRuleRequest & RegionInput, ListTargetsByRuleResponse, ListTargetsByRuleError, Credentials | HttpClient.HttpClient>;
export type PutEventsError = InternalException | CommonErrors;
/**
 * Sends custom events to Amazon EventBridge so that they can be matched to rules.
 */
export declare const putEvents: API.OperationMethod<PutEventsRequest & RegionInput, PutEventsResponse, PutEventsError, Credentials | HttpClient.HttpClient>;
export type PutPartnerEventsError = InternalException | OperationDisabledException | CommonErrors;
/**
 * This is used by SaaS partners to write events to a customer's partner event bus. Amazon Web Services
 * customers do not use this operation.
 */
export declare const putPartnerEvents: API.OperationMethod<PutPartnerEventsRequest & RegionInput, PutPartnerEventsResponse, PutPartnerEventsError, Credentials | HttpClient.HttpClient>;
export type PutPermissionError = ConcurrentModificationException | InternalException | OperationDisabledException | PolicyLengthExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Running `PutPermission` permits the specified Amazon Web Services account or Amazon Web Services organization
 * to put events to the specified *event bus*. Amazon EventBridge (CloudWatch
 * Events) rules in your account are triggered by these events arriving to an event bus in your
 * account.
 *
 * For another account to send events to your account, that external account must have an
 * EventBridge rule with your account's event bus as a target.
 *
 * To enable multiple Amazon Web Services accounts to put events to your event bus, run
 * `PutPermission` once for each of these accounts. Or, if all the accounts are
 * members of the same Amazon Web Services organization, you can run `PutPermission` once specifying
 * `Principal` as "*" and specifying the Amazon Web Services organization ID in
 * `Condition`, to grant permissions to all accounts in that organization.
 *
 * If you grant permissions using an organization, then accounts in that organization must
 * specify a `RoleArn` with proper permissions when they use `PutTarget` to
 * add your account's event bus as a target. For more information, see Sending and
 * Receiving Events Between Amazon Web Services Accounts in the Amazon EventBridge User
 * Guide.
 *
 * The permission policy on the event bus cannot exceed 10 KB in size.
 */
export declare const putPermission: API.OperationMethod<PutPermissionRequest & RegionInput, PutPermissionResponse, PutPermissionError, Credentials | HttpClient.HttpClient>;
export type PutRuleError = ConcurrentModificationException | InternalException | InvalidEventPatternException | LimitExceededException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Creates or updates the specified rule. Rules are enabled by default, or based on value of
 * the state. You can disable a rule using DisableRule.
 *
 * A single rule watches for events from a single event bus. Events generated by Amazon Web Services services
 * go to your account's default event bus. Events generated by SaaS partner services or
 * applications go to the matching partner event bus. If you have custom applications or
 * services, you can specify whether their events go to your default event bus or a custom event
 * bus that you have created. For more information, see CreateEventBus.
 *
 * If you are updating an existing rule, the rule is replaced with what you specify in this
 * `PutRule` command. If you omit arguments in `PutRule`, the old values
 * for those arguments are not kept. Instead, they are replaced with null values.
 *
 * When you create or update a rule, incoming events might not immediately start matching to
 * new or updated rules. Allow a short period of time for changes to take effect.
 *
 * A rule must contain at least an EventPattern or ScheduleExpression. Rules with
 * EventPatterns are triggered when a matching event is observed. Rules with ScheduleExpressions
 * self-trigger based on the given schedule. A rule can have both an EventPattern and a
 * ScheduleExpression, in which case the rule triggers on matching events as well as on a
 * schedule.
 *
 * When you initially create a rule, you can optionally assign one or more tags to the rule.
 * Tags can help you organize and categorize your resources. You can also use them to scope user
 * permissions, by granting a user permission to access or change only rules with certain tag
 * values. To use the `PutRule` operation and assign tags, you must have both the
 * `events:PutRule` and `events:TagResource` permissions.
 *
 * If you are updating an existing rule, any tags you specify in the `PutRule`
 * operation are ignored. To update the tags of an existing rule, use TagResource and UntagResource.
 *
 * Most services in Amazon Web Services treat : or / as the same character in Amazon Resource Names (ARNs).
 * However, EventBridge uses an exact match in event patterns and rules. Be sure to use the
 * correct ARN characters when creating event patterns so that they match the ARN syntax in the
 * event you want to match.
 *
 * In EventBridge, it is possible to create rules that lead to infinite loops, where a rule
 * is fired repeatedly. For example, a rule might detect that ACLs have changed on an S3 bucket,
 * and trigger software to change them to the desired state. If the rule is not written
 * carefully, the subsequent change to the ACLs fires the rule again, creating an infinite
 * loop.
 *
 * To prevent this, write the rules so that the triggered actions do not re-fire the same
 * rule. For example, your rule could fire only if ACLs are found to be in a bad state, instead
 * of after any change.
 *
 * An infinite loop can quickly cause higher than expected charges. We recommend that you use
 * budgeting, which alerts you when charges exceed your specified limit. For more information,
 * see Managing Your Costs with
 * Budgets.
 */
export declare const putRule: API.OperationMethod<PutRuleRequest & RegionInput, PutRuleResponse, PutRuleError, Credentials | HttpClient.HttpClient>;
export type PutTargetsError = ConcurrentModificationException | InternalException | LimitExceededException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Adds the specified targets to the specified rule, or updates the targets if they are
 * already associated with the rule.
 *
 * Targets are the resources that are invoked when a rule is triggered.
 *
 * You can configure the following as targets for Events:
 *
 * - API
 * destination
 *
 * - Amazon API Gateway REST API endpoints
 *
 * - API Gateway
 *
 * - Batch job queue
 *
 * - CloudWatch Logs group
 *
 * - CodeBuild project
 *
 * - CodePipeline
 *
 * - Amazon EC2 `CreateSnapshot` API call
 *
 * - Amazon EC2 `RebootInstances` API call
 *
 * - Amazon EC2 `StopInstances` API call
 *
 * - Amazon EC2 `TerminateInstances` API call
 *
 * - Amazon ECS tasks
 *
 * - Event bus in a different Amazon Web Services account or Region.
 *
 * You can use an event bus in the US East (N. Virginia) us-east-1, US West (Oregon)
 * us-west-2, or Europe (Ireland) eu-west-1 Regions as a target for a rule.
 *
 * - Firehose delivery stream (Firehose)
 *
 * - Inspector assessment template (Amazon Inspector)
 *
 * - Kinesis stream (Kinesis Data Stream)
 *
 * - Lambda function
 *
 * - Redshift clusters (Data API statement execution)
 *
 * - Amazon SNS topic
 *
 * - Amazon SQS queues (includes FIFO queues
 *
 * - SSM Automation
 *
 * - SSM OpsItem
 *
 * - SSM Run Command
 *
 * - Step Functions state machines
 *
 * Creating rules with built-in targets is supported only in the Amazon Web Services Management Console. The
 * built-in targets are `EC2 CreateSnapshot API call`, EC2 RebootInstances API
 * call, `EC2 StopInstances API call`, and EC2 TerminateInstances API
 * call.
 *
 * For some target types, `PutTargets` provides target-specific parameters. If the
 * target is a Kinesis data stream, you can optionally specify which shard the event goes to by
 * using the `KinesisParameters` argument. To invoke a command on multiple EC2
 * instances with one rule, you can use the `RunCommandParameters` field.
 *
 * To be able to make API calls against the resources that you own, Amazon EventBridge
 * needs the appropriate permissions. For Lambda and Amazon SNS
 * resources, EventBridge relies on resource-based policies. For EC2 instances, Kinesis Data Streams,
 * Step Functions state machines and API Gateway REST APIs, EventBridge relies on
 * IAM roles that you specify in the `RoleARN` argument in `PutTargets`.
 * For more information, see Authentication
 * and Access Control in the *Amazon EventBridge User Guide*.
 *
 * If another Amazon Web Services account is in the same region and has granted you permission (using
 * `PutPermission`), you can send events to that account. Set that account's event
 * bus as a target of the rules in your account. To send the matched events to the other account,
 * specify that account's event bus as the `Arn` value when you run
 * `PutTargets`. If your account sends events to another account, your account is
 * charged for each sent event. Each event sent to another account is charged as a custom event.
 * The account receiving the event is not charged. For more information, see Amazon EventBridge
 * Pricing.
 *
 * `Input`, `InputPath`, and `InputTransformer` are not
 * available with `PutTarget` if the target is an event bus of a different Amazon Web Services
 * account.
 *
 * If you are setting the event bus of another account as the target, and that account
 * granted permission to your account through an organization instead of directly by the account
 * ID, then you must specify a `RoleArn` with proper permissions in the
 * `Target` structure. For more information, see Sending and
 * Receiving Events Between Amazon Web Services Accounts in the Amazon EventBridge User
 * Guide.
 *
 * For more information about enabling cross-account events, see PutPermission.
 *
 * **Input**, **InputPath**, and
 * **InputTransformer** are mutually exclusive and optional
 * parameters of a target. When a rule is triggered due to a matched event:
 *
 * - If none of the following arguments are specified for a target, then the entire event
 * is passed to the target in JSON format (unless the target is Amazon EC2 Run Command or
 * Amazon ECS task, in which case nothing from the event is passed to the target).
 *
 * - If **Input** is specified in the form of valid JSON, then
 * the matched event is overridden with this constant.
 *
 * - If **InputPath** is specified in the form of JSONPath
 * (for example, `$.detail`), then only the part of the event specified in the
 * path is passed to the target (for example, only the detail part of the event is
 * passed).
 *
 * - If **InputTransformer** is specified, then one or more
 * specified JSONPaths are extracted from the event and used as values in a template that you
 * specify as the input to the target.
 *
 * When you specify `InputPath` or `InputTransformer`, you must use
 * JSON dot notation, not bracket notation.
 *
 * When you add targets to a rule and the associated rule triggers soon after, new or updated
 * targets might not be immediately invoked. Allow a short period of time for changes to take
 * effect.
 *
 * This action can partially fail if too many requests are made at the same time. If that
 * happens, `FailedEntryCount` is non-zero in the response and each entry in
 * `FailedEntries` provides the ID of the failed target and the error code.
 */
export declare const putTargets: API.OperationMethod<PutTargetsRequest & RegionInput, PutTargetsResponse, PutTargetsError, Credentials | HttpClient.HttpClient>;
export type RemovePermissionError = ConcurrentModificationException | InternalException | OperationDisabledException | ResourceNotFoundException | CommonErrors;
/**
 * Revokes the permission of another Amazon Web Services account to be able to put events to the specified
 * event bus. Specify the account to revoke by the `StatementId` value that you
 * associated with the account when you granted it permission with `PutPermission`.
 * You can find the `StatementId` by using DescribeEventBus.
 */
export declare const removePermission: API.OperationMethod<RemovePermissionRequest & RegionInput, RemovePermissionResponse, RemovePermissionError, Credentials | HttpClient.HttpClient>;
export type RemoveTargetsError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Removes the specified targets from the specified rule. When the rule is triggered, those
 * targets are no longer be invoked.
 *
 * When you remove a target, when the associated rule triggers, removed targets might
 * continue to be invoked. Allow a short period of time for changes to take effect.
 *
 * This action can partially fail if too many requests are made at the same time. If that
 * happens, `FailedEntryCount` is non-zero in the response and each entry in
 * `FailedEntries` provides the ID of the failed target and the error code.
 */
export declare const removeTargets: API.OperationMethod<RemoveTargetsRequest & RegionInput, RemoveTargetsResponse, RemoveTargetsError, Credentials | HttpClient.HttpClient>;
export type StartReplayError = InternalException | InvalidEventPatternException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | CommonErrors;
/**
 * Starts the specified replay. Events are not necessarily replayed in the exact same order
 * that they were added to the archive. A replay processes events to replay based on the time in
 * the event, and replays them using 1 minute intervals. If you specify an
 * `EventStartTime` and an `EventEndTime` that covers a 20 minute time
 * range, the events are replayed from the first minute of that 20 minute range first. Then the
 * events from the second minute are replayed. You can use `DescribeReplay` to
 * determine the progress of a replay. The value returned for `EventLastReplayedTime`
 * indicates the time within the specified time range associated with the last event
 * replayed.
 */
export declare const startReplay: API.OperationMethod<StartReplayRequest & RegionInput, StartReplayResponse, StartReplayError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified EventBridge resource. Tags can
 * help you organize and categorize your resources. You can also use them to scope user
 * permissions by granting a user permission to access or change only resources with certain tag
 * values. In EventBridge, rules and event buses can be tagged.
 *
 * Tags don't have any semantic meaning to Amazon Web Services and are interpreted strictly as strings of
 * characters.
 *
 * You can use the `TagResource` action with a resource that already has tags. If
 * you specify a new tag key, this tag is appended to the list of tags associated with the
 * resource. If you specify a tag key that is already associated with the resource, the new tag
 * value that you specify replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestEventPatternError = InternalException | InvalidEventPatternException | CommonErrors;
/**
 * Tests whether the specified event pattern matches the provided event.
 *
 * Most services in Amazon Web Services treat : or / as the same character in Amazon Resource Names (ARNs).
 * However, EventBridge uses an exact match in event patterns and rules. Be sure to use the
 * correct ARN characters when creating event patterns so that they match the ARN syntax in the
 * event you want to match.
 */
export declare const testEventPattern: API.OperationMethod<TestEventPatternRequest & RegionInput, TestEventPatternResponse, TestEventPatternError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConcurrentModificationException | InternalException | ManagedRuleException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from the specified EventBridge resource. In Amazon EventBridge
 * (CloudWatch Events), rules and event buses can be tagged.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiDestinationError = ConcurrentModificationException | InternalException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates an API destination.
 */
export declare const updateApiDestination: API.OperationMethod<UpdateApiDestinationRequest & RegionInput, UpdateApiDestinationResponse, UpdateApiDestinationError, Credentials | HttpClient.HttpClient>;
export type UpdateArchiveError = ConcurrentModificationException | InternalException | InvalidEventPatternException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the specified archive.
 */
export declare const updateArchive: API.OperationMethod<UpdateArchiveRequest & RegionInput, UpdateArchiveResponse, UpdateArchiveError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectionError = ConcurrentModificationException | InternalException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates settings for a connection.
 */
export declare const updateConnection: API.OperationMethod<UpdateConnectionRequest & RegionInput, UpdateConnectionResponse, UpdateConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=cloudwatch-events.d.ts.map