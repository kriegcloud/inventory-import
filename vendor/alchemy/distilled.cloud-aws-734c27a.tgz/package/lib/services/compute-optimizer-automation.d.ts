import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ForbiddenException_base: S.TaggedErrorClass<"ForbiddenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class ForbiddenException extends /*@__PURE__*/ ForbiddenException_base {
}
declare const IdempotencyTokenInUseException_base: S.TaggedErrorClass<"IdempotencyTokenInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotencyTokenInUseException extends /*@__PURE__*/ IdempotencyTokenInUseException_base {
}
declare const IdempotentParameterMismatchException_base: S.TaggedErrorClass<"IdempotentParameterMismatchException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class IdempotentParameterMismatchException extends /*@__PURE__*/ IdempotentParameterMismatchException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const NotManagementAccountException_base: S.TaggedErrorClass<"NotManagementAccountException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotManagementAccountException extends /*@__PURE__*/ NotManagementAccountException_base {
}
declare const OptInRequiredException_base: S.TaggedErrorClass<"OptInRequiredException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class OptInRequiredException extends /*@__PURE__*/ OptInRequiredException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type AccountId = string;
export type AccountIdList = string[];
export type ClientToken = string;
export interface AssociateAccountsRequest {
    accountIds: string[];
    clientToken?: string | undefined;
}
export type StringList = string[];
export interface AssociateAccountsResponse {
    accountIds?: string[] | undefined;
    errors?: string[] | undefined;
}
export type RuleName = string;
export type RuleDescription = string;
export type RuleType = "OrganizationRule" | "AccountRule" | (string & {});
export type RuleApplyOrder = "BeforeAccountRules" | "AfterAccountRules" | (string & {});
export type OrganizationConfigurationAccountIds = string[];
export interface OrganizationConfiguration {
    ruleApplyOrder?: RuleApplyOrder | undefined;
    accountIds?: string[] | undefined;
}
export type RecommendedActionType = "SnapshotAndDeleteUnattachedEbsVolume" | "UpgradeEbsVolumeType" | (string & {});
export type RecommendedActionTypeList = RecommendedActionType[];
export type ComparisonOperator = "StringEquals" | "StringNotEquals" | "StringEqualsIgnoreCase" | "StringNotEqualsIgnoreCase" | "StringLike" | "StringNotLike" | "NumericEquals" | "NumericNotEquals" | "NumericLessThan" | "NumericLessThanEquals" | "NumericGreaterThan" | "NumericGreaterThanEquals" | "StringEqualsIfExists" | "StringNotEqualsIfExists" | "StringEqualsIgnoreCaseIfExists" | "StringNotEqualsIgnoreCaseIfExists" | "StringLikeIfExists" | "StringNotLikeIfExists" | "NumericEqualsIfExists" | "NumericNotEqualsIfExists" | "NumericLessThanIfExists" | "NumericLessThanEqualsIfExists" | "NumericGreaterThanIfExists" | "NumericGreaterThanEqualsIfExists" | (string & {});
export type StringCriteriaValue = string;
export type StringCriteriaValues = string[];
export interface StringCriteriaCondition {
    comparison?: ComparisonOperator | undefined;
    values?: string[] | undefined;
}
export type StringCriteriaConditionList = StringCriteriaCondition[];
export type IntegerList = number[];
export interface IntegerCriteriaCondition {
    comparison?: ComparisonOperator | undefined;
    values?: number[] | undefined;
}
export type IntegerCriteriaConditionList = IntegerCriteriaCondition[];
export type DoubleList = number[];
export interface DoubleCriteriaCondition {
    comparison?: ComparisonOperator | undefined;
    values?: number[] | undefined;
}
export type DoubleCriteriaConditionList = DoubleCriteriaCondition[];
export interface ResourceTagsCriteriaCondition {
    comparison?: ComparisonOperator | undefined;
    key?: string | undefined;
    values?: string[] | undefined;
}
export type ResourceTagsCriteriaConditionList = ResourceTagsCriteriaCondition[];
export interface Criteria {
    region?: StringCriteriaCondition[] | undefined;
    resourceArn?: StringCriteriaCondition[] | undefined;
    ebsVolumeType?: StringCriteriaCondition[] | undefined;
    ebsVolumeSizeInGib?: IntegerCriteriaCondition[] | undefined;
    estimatedMonthlySavings?: DoubleCriteriaCondition[] | undefined;
    resourceTag?: ResourceTagsCriteriaCondition[] | undefined;
    lookBackPeriodInDays?: IntegerCriteriaCondition[] | undefined;
    restartNeeded?: StringCriteriaCondition[] | undefined;
}
export interface Schedule {
    scheduleExpression?: string | undefined;
    scheduleExpressionTimezone?: string | undefined;
    executionWindowInMinutes?: number | undefined;
}
export type RuleStatus = "Active" | "Inactive" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    key: string;
    value: string;
}
export type TagList = Tag[];
export interface CreateAutomationRuleRequest {
    name: string;
    description?: string | undefined;
    ruleType: RuleType;
    organizationConfiguration?: OrganizationConfiguration | undefined;
    priority?: string | undefined;
    recommendedActionTypes: RecommendedActionType[];
    criteria?: Criteria | undefined;
    schedule: Schedule;
    status: RuleStatus;
    tags?: Tag[] | undefined;
    clientToken?: string | undefined;
}
export type RuleArn = string;
export type RuleId = string;
export interface CreateAutomationRuleResponse {
    ruleArn?: string | undefined;
    ruleId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    ruleType?: RuleType | undefined;
    ruleRevision?: number | undefined;
    organizationConfiguration?: OrganizationConfiguration | undefined;
    priority?: string | undefined;
    recommendedActionTypes?: RecommendedActionType[] | undefined;
    criteria?: Criteria | undefined;
    schedule?: Schedule | undefined;
    status?: RuleStatus | undefined;
    tags?: Tag[] | undefined;
    createdTimestamp?: Date | undefined;
}
export interface DeleteAutomationRuleRequest {
    ruleArn: string;
    ruleRevision: number;
    clientToken?: string | undefined;
}
export interface DeleteAutomationRuleResponse {
}
export interface DisassociateAccountsRequest {
    accountIds: string[];
    clientToken?: string | undefined;
}
export interface DisassociateAccountsResponse {
    accountIds?: string[] | undefined;
    errors?: string[] | undefined;
}
export type EventId = string;
export interface GetAutomationEventRequest {
    eventId: string;
}
export type EventType = "SnapshotAndDeleteUnattachedEbsVolume" | "UpgradeEbsVolumeType" | (string & {});
export type EventStatus = "Ready" | "InProgress" | "Complete" | "Failed" | "Cancelled" | "RollbackReady" | "RollbackInProgress" | "RollbackComplete" | "RollbackFailed" | (string & {});
export type ResourceArn = string;
export type ResourceId = string;
export type RecommendedActionId = string;
export type ResourceType = "EbsVolume" | (string & {});
export type SavingsEstimationMode = "BeforeDiscount" | "AfterDiscount" | (string & {});
export interface EstimatedMonthlySavings {
    currency: string;
    beforeDiscountSavings: number;
    afterDiscountSavings: number;
    savingsEstimationMode: SavingsEstimationMode;
}
export interface GetAutomationEventResponse {
    eventId?: string | undefined;
    eventDescription?: string | undefined;
    eventType?: EventType | undefined;
    eventStatus?: EventStatus | undefined;
    eventStatusReason?: string | undefined;
    resourceArn?: string | undefined;
    resourceId?: string | undefined;
    recommendedActionId?: string | undefined;
    accountId?: string | undefined;
    region?: string | undefined;
    ruleId?: string | undefined;
    resourceType?: ResourceType | undefined;
    createdTimestamp?: Date | undefined;
    completedTimestamp?: Date | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
}
export interface GetAutomationRuleRequest {
    ruleArn: string;
}
export interface GetAutomationRuleResponse {
    ruleArn?: string | undefined;
    ruleId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    ruleType?: RuleType | undefined;
    ruleRevision?: number | undefined;
    accountId?: string | undefined;
    organizationConfiguration?: OrganizationConfiguration | undefined;
    priority?: string | undefined;
    recommendedActionTypes?: RecommendedActionType[] | undefined;
    criteria?: Criteria | undefined;
    schedule?: Schedule | undefined;
    status?: RuleStatus | undefined;
    tags?: Tag[] | undefined;
    createdTimestamp?: Date | undefined;
    lastUpdatedTimestamp?: Date | undefined;
}
export interface GetEnrollmentConfigurationRequest {
}
export type EnrollmentStatus = "Active" | "Inactive" | "Pending" | "Failed" | (string & {});
export type OrganizationRuleMode = "AnyAllowed" | "NoneAllowed" | (string & {});
export interface GetEnrollmentConfigurationResponse {
    status: EnrollmentStatus;
    statusReason?: string | undefined;
    organizationRuleMode?: OrganizationRuleMode | undefined;
    lastUpdatedTimestamp?: Date | undefined;
}
export type NextToken = string;
export interface ListAccountsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AccountInfo {
    accountId: string;
    status: EnrollmentStatus;
    organizationRuleMode: OrganizationRuleMode;
    statusReason?: string | undefined;
    lastUpdatedTimestamp: Date;
}
export type AccountInfoList = AccountInfo[];
export interface ListAccountsResponse {
    accounts: AccountInfo[];
    nextToken?: string | undefined;
}
export type AutomationEventFilterName = string;
export type FilterValue = string;
export type FilterValues = string[];
export interface AutomationEventFilter {
    name: string;
    values: string[];
}
export type AutomationEventFilterList = AutomationEventFilter[];
export interface ListAutomationEventsRequest {
    filters?: AutomationEventFilter[] | undefined;
    startTimeInclusive?: Date | undefined;
    endTimeExclusive?: Date | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AutomationEvent {
    eventId?: string | undefined;
    eventDescription?: string | undefined;
    eventType?: EventType | undefined;
    eventStatus?: EventStatus | undefined;
    eventStatusReason?: string | undefined;
    resourceArn?: string | undefined;
    resourceId?: string | undefined;
    recommendedActionId?: string | undefined;
    accountId?: string | undefined;
    region?: string | undefined;
    ruleId?: string | undefined;
    resourceType?: ResourceType | undefined;
    createdTimestamp?: Date | undefined;
    completedTimestamp?: Date | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
}
export type AutomationEvents = AutomationEvent[];
export interface ListAutomationEventsResponse {
    automationEvents?: AutomationEvent[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAutomationEventStepsRequest {
    eventId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type StepId = string;
export type StepType = "CreateEbsSnapshot" | "DeleteEbsVolume" | "ModifyEbsVolume" | "CreateEbsVolume" | (string & {});
export type StepStatus = "Ready" | "InProgress" | "Complete" | "Failed" | (string & {});
export interface AutomationEventStep {
    eventId?: string | undefined;
    stepId?: string | undefined;
    stepType?: StepType | undefined;
    stepStatus?: StepStatus | undefined;
    resourceId?: string | undefined;
    startTimestamp?: Date | undefined;
    completedTimestamp?: Date | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
}
export type AutomationEventSteps = AutomationEventStep[];
export interface ListAutomationEventStepsResponse {
    automationEventSteps?: AutomationEventStep[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAutomationEventSummariesRequest {
    filters?: AutomationEventFilter[] | undefined;
    startDateInclusive?: string | undefined;
    endDateExclusive?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type SummaryDimensionKey = string;
export interface SummaryDimension {
    key: string;
    value: string;
}
export type SummaryDimensions = SummaryDimension[];
export interface TimePeriod {
    startTimeInclusive?: Date | undefined;
    endTimeExclusive?: Date | undefined;
}
export interface SummaryTotals {
    automationEventCount?: number | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
}
export interface AutomationEventSummary {
    key?: string | undefined;
    dimensions?: SummaryDimension[] | undefined;
    timePeriod?: TimePeriod | undefined;
    total?: SummaryTotals | undefined;
}
export type AutomationEventSummaryList = AutomationEventSummary[];
export interface ListAutomationEventSummariesResponse {
    automationEventSummaries?: AutomationEventSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface OrganizationScope {
    accountIds?: string[] | undefined;
}
export interface ListAutomationRulePreviewRequest {
    ruleType: RuleType;
    organizationScope?: OrganizationScope | undefined;
    recommendedActionTypes: RecommendedActionType[];
    criteria?: Criteria | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface EbsVolumeConfiguration {
    type?: string | undefined;
    sizeInGib?: number | undefined;
    iops?: number | undefined;
    throughput?: number | undefined;
}
export interface EbsVolume {
    configuration?: EbsVolumeConfiguration | undefined;
}
export type ResourceDetails = {
    ebsVolume: EbsVolume;
};
export interface PreviewResult {
    recommendedActionId?: string | undefined;
    resourceArn?: string | undefined;
    resourceId?: string | undefined;
    accountId?: string | undefined;
    region?: string | undefined;
    resourceType?: ResourceType | undefined;
    lookBackPeriodInDays?: number | undefined;
    recommendedActionType?: RecommendedActionType | undefined;
    currentResourceSummary?: string | undefined;
    currentResourceDetails?: ResourceDetails | undefined;
    recommendedResourceSummary?: string | undefined;
    recommendedResourceDetails?: ResourceDetails | undefined;
    restartNeeded?: boolean | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
    resourceTags?: Tag[] | undefined;
}
export type PreviewResults = PreviewResult[];
export interface ListAutomationRulePreviewResponse {
    previewResults?: PreviewResult[] | undefined;
    nextToken?: string | undefined;
}
export interface ListAutomationRulePreviewSummariesRequest {
    ruleType: RuleType;
    organizationScope?: OrganizationScope | undefined;
    recommendedActionTypes: RecommendedActionType[];
    criteria?: Criteria | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RulePreviewTotal {
    recommendedActionCount: number;
    estimatedMonthlySavings: EstimatedMonthlySavings;
}
export interface PreviewResultSummary {
    key: string;
    total: RulePreviewTotal;
}
export type PreviewResultSummaries = PreviewResultSummary[];
export interface ListAutomationRulePreviewSummariesResponse {
    previewResultSummaries?: PreviewResultSummary[] | undefined;
    nextToken?: string | undefined;
}
export type AutomationRuleFilterName = string;
export interface Filter {
    name: string;
    values: string[];
}
export type FilterList = Filter[];
export interface ListAutomationRulesRequest {
    filters?: Filter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AutomationRule {
    ruleArn?: string | undefined;
    ruleId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    ruleType?: RuleType | undefined;
    ruleRevision?: number | undefined;
    accountId?: string | undefined;
    organizationConfiguration?: OrganizationConfiguration | undefined;
    priority?: string | undefined;
    recommendedActionTypes?: RecommendedActionType[] | undefined;
    schedule?: Schedule | undefined;
    status?: RuleStatus | undefined;
    createdTimestamp?: Date | undefined;
    lastUpdatedTimestamp?: Date | undefined;
}
export type AutomationRules = AutomationRule[];
export interface ListAutomationRulesResponse {
    automationRules?: AutomationRule[] | undefined;
    nextToken?: string | undefined;
}
export type RecommendedActionFilterName = string;
export interface RecommendedActionFilter {
    name: string;
    values: string[];
}
export type RecommendedActionFilterList = RecommendedActionFilter[];
export interface ListRecommendedActionsRequest {
    filters?: RecommendedActionFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RecommendedAction {
    recommendedActionId?: string | undefined;
    resourceArn?: string | undefined;
    resourceId?: string | undefined;
    accountId?: string | undefined;
    region?: string | undefined;
    resourceType?: ResourceType | undefined;
    lookBackPeriodInDays?: number | undefined;
    recommendedActionType?: RecommendedActionType | undefined;
    currentResourceSummary?: string | undefined;
    currentResourceDetails?: ResourceDetails | undefined;
    recommendedResourceSummary?: string | undefined;
    recommendedResourceDetails?: ResourceDetails | undefined;
    restartNeeded?: boolean | undefined;
    estimatedMonthlySavings?: EstimatedMonthlySavings | undefined;
    resourceTags?: Tag[] | undefined;
}
export type RecommendedActions = RecommendedAction[];
export interface ListRecommendedActionsResponse {
    recommendedActions?: RecommendedAction[] | undefined;
    nextToken?: string | undefined;
}
export interface ListRecommendedActionSummariesRequest {
    filters?: RecommendedActionFilter[] | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface RecommendedActionTotal {
    recommendedActionCount: number;
    estimatedMonthlySavings: EstimatedMonthlySavings;
}
export interface RecommendedActionSummary {
    key: string;
    total: RecommendedActionTotal;
}
export type RecommendedActionSummaries = RecommendedActionSummary[];
export interface ListRecommendedActionSummariesResponse {
    recommendedActionSummaries?: RecommendedActionSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: Tag[] | undefined;
}
export interface RollbackAutomationEventRequest {
    eventId: string;
    clientToken?: string | undefined;
}
export interface RollbackAutomationEventResponse {
    eventId?: string | undefined;
    eventStatus?: EventStatus | undefined;
}
export interface StartAutomationEventRequest {
    recommendedActionId: string;
    clientToken?: string | undefined;
}
export interface StartAutomationEventResponse {
    recommendedActionId?: string | undefined;
    eventId?: string | undefined;
    eventStatus?: EventStatus | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    ruleRevision: number;
    tags: Tag[];
    clientToken?: string | undefined;
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    ruleRevision: number;
    tagKeys: string[];
    clientToken?: string | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateAutomationRuleRequest {
    ruleArn: string;
    ruleRevision: number;
    name?: string | undefined;
    description?: string | undefined;
    ruleType?: RuleType | undefined;
    organizationConfiguration?: OrganizationConfiguration | undefined;
    priority?: string | undefined;
    recommendedActionTypes?: RecommendedActionType[] | undefined;
    criteria?: Criteria | undefined;
    schedule?: Schedule | undefined;
    status?: RuleStatus | undefined;
    clientToken?: string | undefined;
}
export interface UpdateAutomationRuleResponse {
    ruleArn?: string | undefined;
    ruleRevision?: number | undefined;
    name?: string | undefined;
    description?: string | undefined;
    ruleType?: RuleType | undefined;
    organizationConfiguration?: OrganizationConfiguration | undefined;
    priority?: string | undefined;
    recommendedActionTypes?: RecommendedActionType[] | undefined;
    criteria?: Criteria | undefined;
    schedule?: Schedule | undefined;
    status?: RuleStatus | undefined;
    createdTimestamp?: Date | undefined;
    lastUpdatedTimestamp?: Date | undefined;
}
export interface UpdateEnrollmentConfigurationRequest {
    status: EnrollmentStatus;
    clientToken?: string | undefined;
}
export interface UpdateEnrollmentConfigurationResponse {
    status: EnrollmentStatus;
    statusReason?: string | undefined;
    lastUpdatedTimestamp: Date;
}
export type AssociateAccountsError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Associates one or more member accounts with your organization's management account, enabling centralized implementation of optimization actions across those accounts. Once associated, the management account (or a delegated administrator) can apply recommended actions to the member account. When you associate a member account, its organization rule mode is automatically set to "Any allowed," which permits the management account to create Automation rules that automatically apply actions to that account. If the member account has not previously enabled the Automation feature, the association process automatically enables it.
 *
 * Only the management account or a delegated administrator can perform this action.
 */
export declare const associateAccounts: API.OperationMethod<AssociateAccountsRequest & RegionInput, AssociateAccountsResponse, AssociateAccountsError, Credentials | HttpClient.HttpClient>;
export type CreateAutomationRuleError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a new automation rule to apply recommended actions to resources based on specified criteria.
 */
export declare const createAutomationRule: API.OperationMethod<CreateAutomationRuleRequest & RegionInput, CreateAutomationRuleResponse, CreateAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type DeleteAutomationRuleError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing automation rule.
 */
export declare const deleteAutomationRule: API.OperationMethod<DeleteAutomationRuleRequest & RegionInput, DeleteAutomationRuleResponse, DeleteAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type DisassociateAccountsError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Disassociates member accounts from your organization's management account, removing centralized automation capabilities. Once disassociated, organization rules no longer apply to the member account, and the management account (or delegated administrator) cannot create Automation rules for that account.
 *
 * Only the management account or a delegated administrator can perform this action.
 */
export declare const disassociateAccounts: API.OperationMethod<DisassociateAccountsRequest & RegionInput, DisassociateAccountsResponse, DisassociateAccountsError, Credentials | HttpClient.HttpClient>;
export type GetAutomationEventError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about a specific automation event.
 */
export declare const getAutomationEvent: API.OperationMethod<GetAutomationEventRequest & RegionInput, GetAutomationEventResponse, GetAutomationEventError, Credentials | HttpClient.HttpClient>;
export type GetAutomationRuleError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about a specific automation rule.
 */
export declare const getAutomationRule: API.OperationMethod<GetAutomationRuleRequest & RegionInput, GetAutomationRuleResponse, GetAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type GetEnrollmentConfigurationError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves the current enrollment configuration for Compute Optimizer Automation.
 */
export declare const getEnrollmentConfiguration: API.OperationMethod<GetEnrollmentConfigurationRequest & RegionInput, GetEnrollmentConfigurationResponse, GetEnrollmentConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAccountsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the accounts in your organization that are enrolled in Compute Optimizer and whether they have enabled Automation.
 *
 * Only the management account or a delegated administrator can perform this action.
 */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest & RegionInput, ListAccountsResponse, ListAccountsError, Credentials | HttpClient.HttpClient, AccountInfo>;
export type ListAutomationEventsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists automation events based on specified filters. You can retrieve events that were created within the past year.
 */
export declare const listAutomationEvents: API.PaginatedOperationMethod<ListAutomationEventsRequest & RegionInput, ListAutomationEventsResponse, ListAutomationEventsError, Credentials | HttpClient.HttpClient, AutomationEvent>;
export type ListAutomationEventStepsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the steps for a specific automation event. You can only list steps for events created within the past year.
 */
export declare const listAutomationEventSteps: API.PaginatedOperationMethod<ListAutomationEventStepsRequest & RegionInput, ListAutomationEventStepsResponse, ListAutomationEventStepsError, Credentials | HttpClient.HttpClient, AutomationEventStep>;
export type ListAutomationEventSummariesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Provides a summary of automation events based on specified filters. Only events created within the past year will be included in the summary.
 */
export declare const listAutomationEventSummaries: API.PaginatedOperationMethod<ListAutomationEventSummariesRequest & RegionInput, ListAutomationEventSummariesResponse, ListAutomationEventSummariesError, Credentials | HttpClient.HttpClient, AutomationEventSummary>;
export type ListAutomationRulePreviewError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a preview of the recommended actions that match your Automation rule's configuration and criteria.
 */
export declare const listAutomationRulePreview: API.PaginatedOperationMethod<ListAutomationRulePreviewRequest & RegionInput, ListAutomationRulePreviewResponse, ListAutomationRulePreviewError, Credentials | HttpClient.HttpClient, PreviewResult>;
export type ListAutomationRulePreviewSummariesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a summary of the recommended actions that match your rule preview configuration and criteria.
 */
export declare const listAutomationRulePreviewSummaries: API.PaginatedOperationMethod<ListAutomationRulePreviewSummariesRequest & RegionInput, ListAutomationRulePreviewSummariesResponse, ListAutomationRulePreviewSummariesError, Credentials | HttpClient.HttpClient, PreviewResultSummary>;
export type ListAutomationRulesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the automation rules that match specified filters.
 */
export declare const listAutomationRules: API.PaginatedOperationMethod<ListAutomationRulesRequest & RegionInput, ListAutomationRulesResponse, ListAutomationRulesError, Credentials | HttpClient.HttpClient, AutomationRule>;
export type ListRecommendedActionsError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the recommended actions based that match specified filters.
 *
 * Management accounts and delegated administrators can retrieve recommended actions that include associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const listRecommendedActions: API.PaginatedOperationMethod<ListRecommendedActionsRequest & RegionInput, ListRecommendedActionsResponse, ListRecommendedActionsError, Credentials | HttpClient.HttpClient, RecommendedAction>;
export type ListRecommendedActionSummariesError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Provides a summary of recommended actions based on specified filters.
 *
 * Management accounts and delegated administrators can retrieve recommended actions that include associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const listRecommendedActionSummaries: API.PaginatedOperationMethod<ListRecommendedActionSummariesRequest & RegionInput, ListRecommendedActionSummariesResponse, ListRecommendedActionSummariesError, Credentials | HttpClient.HttpClient, RecommendedActionSummary>;
export type ListTagsForResourceError = AccessDeniedException | ForbiddenException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the tags for a specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RollbackAutomationEventError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Initiates a rollback for a completed automation event.
 *
 * Management accounts and delegated administrators can only initiate a rollback for events belonging to associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const rollbackAutomationEvent: API.OperationMethod<RollbackAutomationEventRequest & RegionInput, RollbackAutomationEventResponse, RollbackAutomationEventError, Credentials | HttpClient.HttpClient>;
export type StartAutomationEventError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceQuotaExceededException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Initiates a one-time, on-demand automation for the specified recommended action.
 *
 * Management accounts and delegated administrators can only initiate recommended actions for associated member accounts. You can associate a member account using `AssociateAccounts`.
 */
export declare const startAutomationEvent: API.OperationMethod<StartAutomationEventRequest & RegionInput, StartAutomationEventResponse, StartAutomationEventError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Adds tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Removes tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAutomationRuleError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an existing automation rule.
 */
export declare const updateAutomationRule: API.OperationMethod<UpdateAutomationRuleRequest & RegionInput, UpdateAutomationRuleResponse, UpdateAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type UpdateEnrollmentConfigurationError = AccessDeniedException | ForbiddenException | IdempotencyTokenInUseException | IdempotentParameterMismatchException | InternalServerException | InvalidParameterValueException | NotManagementAccountException | OptInRequiredException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates your account's Compute Optimizer Automation enrollment configuration.
 */
export declare const updateEnrollmentConfiguration: API.OperationMethod<UpdateEnrollmentConfigurationRequest & RegionInput, UpdateEnrollmentConfigurationResponse, UpdateEnrollmentConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=compute-optimizer-automation.d.ts.map