/** @jsxRuntime automatic */
/** @jsxImportSource @alchemy.run/sigil */
import * as Effect from "effect/Effect";
import { type Event } from "../../../Events.ts";
import { Interaction } from "../../../Interaction.ts";
import type { Result as NukeResult, Target } from "../../../Nuke.ts";
import type { ProviderMode } from "../../../ProviderMode.ts";
import { LiveStore } from "../ui/index.ts";
import type { PlanTreeData } from "./PlanTree.ts";
interface NukeProgressState {
    readonly total: number;
    readonly completed: number;
    readonly resources: number;
    readonly inFlight: ReadonlyArray<string>;
}
export declare class NukeProgressStore extends LiveStore<NukeProgressState> {
    constructor();
    emit(event: Event): void;
}
export declare function NukeProgress({ store }: {
    store: NukeProgressStore;
}): import("react").JSX.Element;
export declare const renderNukeScan: () => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R | Interaction | import("effect/Scope").Scope>;
/** Drive the same resource rows used by the preview through their deletion lifecycle. */
export declare const renderNukeDelete: (targets: ReadonlyArray<Pick<Target, "key" | "providerId" | "displayName">>, mode: ProviderMode) => <A extends NukeResult, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R | Interaction | import("effect/Scope").Scope>;
/** Cloud inventory rows carry display identity only, never fabricated stack state. */
export declare const nukePlan: (targets: ReadonlyArray<Pick<Target, "key" | "providerId" | "displayName">>, options: {
    mode: ProviderMode;
}) => PlanTreeData;
export declare const reviewNuke: (targets: readonly Pick<Target, "displayName" | "key" | "providerId">[], options: {
    mode: ProviderMode;
    yes: boolean;
    dryRun: boolean;
}) => Effect.Effect<boolean, import("../types.ts").InteractionError, Interaction>;
export {};
//# sourceMappingURL=Nuke.d.ts.map