import * as Cause from "effect/Cause";
import * as Context from "effect/Context";
import type * as SecureRandom from "effect/crypto/SecureRandom";
import type * as DateTime from "effect/DateTime";
import type * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import type { Annotations } from "./Annotations.ts";
import type * as Command from "./Command.ts";
import type * as Event from "./Event.ts";
import { targetId as internalTargetId } from "./internal.ts";
import * as RequestContext from "./RequestContext.ts";
import type * as Telemetry from "./Telemetry.ts";
/**
 * The instance type of a class: `InstanceOf<typeof NotOwner>` is `NotOwner`.
 * Distributes over a union of classes.
 */
export type InstanceOf<C> = C extends abstract new (...args: any[]) => infer I ? I : never;
/**
 * Context passed to every `decide` handler.
 */
export interface DecideContext<Id> {
    /** The id of the aggregate instance handling the command. */
    readonly id: Id;
    /** The id the command was sent with; its events' envelopes carry it too. */
    readonly commandId: string;
    /** The stream the command's events commit to, e.g. `Account/a-1`. */
    readonly stream: string;
    /** The stream's version before this decision: `0` for a new instance. */
    readonly version: number;
    /** The time the command is being handled. Controlled by stories via `clock`. */
    readonly now: DateTime.Utc;
}
/**
 * Metadata recorded with every committed event. Its schema is what Api clients
 * decode, so the wire carries every field.
 */
export declare const Envelope: Schema.Struct<{
    /** The id of the aggregate instance that committed the event. */
    readonly id: Schema.String;
    /** The stream the event belongs to, e.g. `Account/a-1`. */
    readonly stream: Schema.String;
    /** The event's sequence number within its stream, starting at 1. */
    readonly seq: Schema.Number;
    /** The commit time. */
    readonly at: Schema.DateTimeUtc;
    /** The id of the command that produced the event. */
    readonly commandId: Schema.String;
    /**
     * The id of the first command in the chain that led here: the same for a
     * command, the events it records, and every reaction and command they cause.
     */
    readonly correlationId: Schema.String;
}>;
/** An {@link Envelope} whose `id` is the aggregate's (branded) id. */
export type Envelope<Id = string> = typeof Envelope.Type & {
    readonly id: Id;
};
/**
 * The outcome of a successfully handled command.
 */
export interface Receipt<Ev = unknown, Reply = unknown> {
    /** The stream the command was applied to, e.g. `Account/a-1`. */
    readonly stream: string;
    /** The stream's version (last sequence number) after the command. */
    readonly version: number;
    /** The events committed by the command (empty for an accepted no-op). */
    readonly events: ReadonlyArray<Ev>;
    /** The command's reply, if it declares one. */
    readonly reply: Reply;
    /**
     * Every stream the command committed to: this one, for a command an
     * aggregate implements; each instance a `Domain.Decision` read, for one it
     * implements (and `stream` and `version` are then the first of them).
     */
    readonly commits: ReadonlyArray<{
        readonly stream: string;
        readonly version: number;
    }>;
}
/**
 * What {@link Client.schedule} returns: the scheduled command's id, to
 * `unschedule` it by, and when it is due.
 */
export interface ScheduleReceipt {
    /** The command id: the one passed in `options`, or the one derived for it. */
    readonly commandId: string;
    /** When the command is due, on the platform's clock. */
    readonly at: DateTime.Utc;
}
type ByTag<U, T> = Extract<U, {
    readonly tag: T;
}>;
type ReplyTags<C extends Command.Any> = C extends {
    readonly reply: Schema.Top;
    readonly tag: infer T extends string;
} ? T : never;
type IdSchema = Schema.Top & {
    readonly Type: string;
    readonly Encoded: string;
};
/**
 * What `decide` returns for a command: events, a rejection, or an Effect of
 * either. The Effect may read what the command's middleware provides.
 */
export type Decision<C extends Command.Any> = ReadonlyArray<InstanceOf<C["events"][number]>> | InstanceOf<C["rejects"][number]> | Effect.Effect<ReadonlyArray<InstanceOf<C["events"][number]>>, InstanceOf<C["rejects"][number]>, Command.ContextOf<C>>;
/** One step of an aggregate: what a transition is given. */
export interface Transition<State, Cmd, Ev> {
    /** The state the command met. */
    readonly before: State;
    /** The state its events left. */
    readonly after: State;
    readonly command: Cmd;
    /** The events the command recorded, in order. */
    readonly events: ReadonlyArray<Ev>;
}
/** The event classes a set of commands may record. */
export type EventsOf<C extends ReadonlyArray<Command.Any>> = C[number]["events"][number];
/**
 * The pure definition of an aggregate: identity, state, the commands it
 * decides and the events it folds. Its events are those its commands declare.
 */
export interface Definition<Id extends IdSchema, S extends Schema.Top, C extends ReadonlyArray<Command.Any>, X extends ReadonlyArray<Event.Any> = readonly [], E extends Event.Any = EventsOf<C> | X[number]> {
    /** Schema of the aggregate id (a string or branded string). */
    readonly id: Id;
    /** Schema of the aggregate's state. Used to persist snapshots. */
    readonly state: S;
    /** The state of an instance that has never committed an event. */
    readonly initial: S["Type"];
    /**
     * Rules that hold for every state the aggregate can reach, each named and
     * given the state: `true` while the rule holds. They say what must never
     * happen; `decide` and `evolve` say what does. `Prove.invariants` proves
     * that no command can break one.
     */
    readonly invariants?: {
        readonly [name: string]: (state: S["Type"]) => boolean;
    };
    /**
     * Rules that hold for every step the aggregate can take, each named and
     * given the state before a command, the command, the events it recorded
     * and the state after: `true` while the rule holds. Where an invariant
     * says what no state may be, a transition says what no command may do. One
     * may be an `Effect.fn` that reads the context its commands' middleware
     * provides, as `decide` does. `Prove.invariants` proves that no command
     * can break one.
     */
    readonly transitions?: {
        readonly [name: string]: (step: Transition<S["Type"], InstanceOf<C[number]>, InstanceOf<E>>) => boolean | Effect.Effect<boolean, never, Command.ContextOf<C[number]>>;
    };
    /**
     * Every command this aggregate handles, each declaring the events it
     * records. Leave it out, with `decide`, for an aggregate that only folds
     * what `Domain.Decision`s record on it.
     */
    readonly commands?: C;
    /**
     * The id of the instance a command is for, read from the command's input.
     * Each of the aggregate's commands is routed to that one instance.
     */
    readonly keyOf?: (command: InstanceOf<C[number]>) => Id["Type"];
    /**
     * Events it folds but none of its own commands records: what a
     * `Domain.Decision` records on it. `evolve` has a handler for each.
     */
    readonly events?: X;
    /**
     * One handler per command, given the instance's current state, the command
     * and the decision's context: returns the events to commit (from the
     * command's declared events), an empty array for an accepted no-op, or one
     * of the command's declared rejections. A handler may be an `Effect.fn`
     * that reads the context its command's middleware provides (e.g.
     * `yield* CurrentActor`) and fails with a rejection; it may require
     * nothing else.
     */
    readonly decide?: {
        readonly [T in C[number]["tag"]]: (state: S["Type"], command: InstanceOf<ByTag<C[number], T>>, ctx: DecideContext<Id["Type"]>) => Decision<ByTag<C[number], T>>;
    };
    /**
     * One handler per event: folds a committed event into state. It covers
     * every state and never fails: `decide` refuses a command with a rejection
     * before it records an event, so a handler keeps a state its event can't
     * follow.
     */
    readonly evolve: {
        readonly [T in E["tag"]]: (state: S["Type"], event: InstanceOf<ByTag<E, T>>, envelope: Envelope<Id["Type"]>) => S["Type"];
    };
    /**
     * One handler per command that declares a reply: computes it from the
     * updated state and the committed events. Like `evolve`, it covers every
     * state and never fails.
     */
    readonly reply?: {
        readonly [T in ReplyTags<C[number]>]: (state: S["Type"], events: ReadonlyArray<InstanceOf<E>>) => NonNullable<ByTag<C[number], T>["reply"]>["Type"];
    };
}
/**
 * Type-level identity of an aggregate in an Effect's requirements.
 */
export interface Key<Name extends string> {
    readonly "~alchemy/Domain/Aggregate": Name;
}
/**
 * Options for {@link Client.send}.
 */
export interface SendOptions {
    /** Idempotency key. A command with an already-seen id returns the original receipt. */
    readonly commandId?: string;
}
declare const AlreadyExecuted_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "AlreadyExecuted";
} & Readonly<A>;
/**
 * The command scheduled with this id already ran, so it can no longer be
 * cancelled: a deadline that fired before it was cancelled.
 */
export declare class AlreadyExecuted extends AlreadyExecuted_base<{
    readonly aggregate: string;
    readonly id: string;
    readonly commandId: string;
}> {
}
declare const AlreadyCancelled_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "AlreadyCancelled";
} & Readonly<A>;
/** The scheduled command with this id was already cancelled. */
export declare class AlreadyCancelled extends AlreadyCancelled_base<{
    readonly aggregate: string;
    readonly id: string;
    readonly commandId: string;
}> {
}
declare const NotScheduled_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "NotScheduled";
} & Readonly<A>;
/** No command was ever scheduled with this id on the instance. */
export declare class NotScheduled extends NotScheduled_base<{
    readonly aggregate: string;
    readonly id: string;
    readonly commandId: string;
}> {
}
declare const UnexpectedVersion_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "UnexpectedVersion";
} & Readonly<A>;
/**
 * The instance was not at the version an import expected: it already has
 * events, or other events were committed since the previous import.
 */
export declare class UnexpectedVersion extends UnexpectedVersion_base<{
    readonly aggregate: string;
    readonly id: string;
    readonly commandId: string;
    /** The version the import expected. */
    readonly expected: number;
    /** The instance's version. */
    readonly version: number;
}> {
}
declare const ImportOutOfOrder_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "ImportOutOfOrder";
} & Readonly<A>;
/**
 * An imported event's commit time came before the event ahead of it (the
 * instance's latest event, for the first), or after the platform's clock.
 * Views rebuild their history in commit-time order, so an import commits
 * its events in that order or not at all.
 */
export declare class ImportOutOfOrder extends ImportOutOfOrder_base<{
    readonly aggregate: string;
    readonly id: string;
    readonly commandId: string;
    /** The position of the first event out of order. */
    readonly index: number;
    /** Its commit time. */
    readonly at: DateTime.Utc;
    /** The time it may not precede, or the platform's clock it may not pass. */
    readonly after: DateTime.Utc;
}> {
}
/**
 * One event for {@link Client.import}: the event alone, stamped with the
 * platform's current time, or the event with the time it was originally
 * committed, which its envelope's `at` keeps.
 */
export type Imported<Ev> = Ev | {
    readonly event: Ev;
    readonly at: DateTime.Utc;
};
/**
 * Options for {@link Client.import}.
 */
export interface ImportOptions {
    /**
     * Names the import on its instance. An import retried with an id the
     * instance has already seen commits nothing and returns the original
     * receipt.
     */
    readonly commandId: string;
    /**
     * The version the instance must be at: `0` (no events yet) by default.
     * Import a long history in batches by passing the previous receipt's
     * `version`.
     */
    readonly expectedVersion?: number;
}
/**
 * Options for {@link Client.schedule}: when to send, absolutely or after a
 * delay, and the command id that names it.
 */
export type ScheduleOptions = {
    /**
     * Names the scheduled command on its instance, to replace or `unschedule`
     * it by, e.g. `stall:<ticketId>`. Scheduling under the same id replaces
     * the earlier command, pending or already run. Defaults to an id derived
     * like a send's.
     */
    readonly commandId?: string;
} & ({
    readonly at: DateTime.Utc;
    readonly after?: never;
} | {
    readonly after: Duration.Input;
    readonly at?: never;
});
/**
 * When a scheduled command is due: an epoch-millisecond time, or a delay the
 * platform measures on its own clock (stories control it with `clock`).
 */
export type Due = {
    readonly at: number;
} | {
    readonly afterMillis: number;
};
/**
 * Metadata a platform receives with every command.
 */
export interface SendMeta {
    readonly commandId: string;
    /** The command context services the sender provided, encoded. */
    readonly context: RequestContext.Json;
    /** The flow the command belongs to (see {@link Envelope.correlationId}). */
    readonly correlationId?: string;
    /** The span that sent the command, so the aggregate's span continues its trace. */
    readonly trace?: Telemetry.TraceJson;
    /** Link to `trace` instead of continuing it: the command runs later (scheduled). */
    readonly link?: boolean;
}
type AnyHandlers = {
    readonly [tag: string]: (...args: never[]) => unknown;
};
/**
 * The widened shape of every {@link Definition}.
 */
export interface AnyDefinition {
    readonly id: IdSchema;
    readonly state: Schema.Top;
    readonly initial: unknown;
    readonly invariants?: AnyHandlers;
    readonly transitions?: AnyHandlers;
    readonly commands: ReadonlyArray<Command.Any>;
    readonly keyOf: ((command: never) => string) | undefined;
    readonly events: ReadonlyArray<Event.Any>;
    readonly decide: AnyHandlers;
    readonly evolve: AnyHandlers;
    readonly reply?: AnyHandlers;
}
/** An aggregate instance to address: its id, or a ref carrying it. */
export type Target<Def extends AnyDefinition> = Def["id"]["Type"] | {
    readonly id: Def["id"]["Type"];
};
type CommandClassOf<Def extends AnyDefinition, Cmd> = ByTag<Def["commands"][number], Cmd extends {
    readonly _tag: infer T;
} ? T : never>;
type ReplyOf<C> = C extends {
    readonly reply: infer R;
} ? R extends Schema.Top ? R["Type"] : void : void;
/**
 * The runtime API of an aggregate, obtained with `yield* MyAggregate`. Resolve
 * it once while building a policy or an operation, then call it per event or
 * request; its methods require nothing.
 *
 * **Example:** Sending a command
 * ```typescript
 * const accounts = yield* Account;
 * const { reply } = yield* accounts.send(new WithdrawMoney({ accountId, amount: 30 }));
 * ```
 */
export interface Client<Def extends AnyDefinition> {
    /**
     * Send a command. Succeeds with a {@link Receipt} once the resulting events
     * are committed, or fails with one of the command's declared rejections.
     * Requires the context the command's middleware provides (e.g. the current
     * actor): an Api's middleware provides it, other senders provide it.
     */
    readonly send: <Cmd extends InstanceOf<Def["commands"][number]>>(command: Cmd, options?: SendOptions) => Effect.Effect<Receipt<InstanceOf<Def["events"][number]>, ReplyOf<CommandClassOf<Def, Cmd>>>, InstanceOf<CommandClassOf<Def, Cmd>["rejects"][number]>, Command.ContextOf<CommandClassOf<Def, Cmd>>>;
    /**
     * Send a command later, durably: a deadline or a reminder. Only commands
     * that never reject can be scheduled, since nobody is waiting to handle a
     * rejection when it fires; such a command reports a fact ("the approval
     * window closed") and records nothing when it no longer applies.
     * Scheduling again with the same command id replaces the earlier one,
     * pending or already run, so a deadline can be armed again. A policy or
     * saga step that runs again for the same trigger schedules nothing new.
     * Returns the command id to `unschedule` it by, and when it is due.
     */
    readonly schedule: <Cmd extends InstanceOf<Schedulable<Def>>>(command: Cmd, options: ScheduleOptions) => Effect.Effect<ScheduleReceipt, never, Command.ContextOf<CommandClassOf<Def, Cmd>>>;
    /**
     * Cancel a pending scheduled command by the command id it was scheduled
     * with. Once it succeeds, the command never runs. Fails with
     * `AlreadyExecuted` when the command ran first, `AlreadyCancelled` when it
     * was cancelled before, and `NotScheduled` when nothing was scheduled with
     * that id.
     */
    readonly unschedule: (target: Target<Def>, commandId: string) => Effect.Effect<void, AlreadyExecuted | AlreadyCancelled | NotScheduled>;
    /**
     * Append events that were decided elsewhere, such as history moved from
     * another system, without running `decide`. `evolve` folds them into the
     * state; views and projections apply them like any other events, while
     * policies and sagas never react to them. All of them are committed at
     * once under `commandId`. Each is stamped with the platform's current
     * time, or with its original commit time when passed as `{ event, at }`.
     * Wait for a projection with `Projection.caughtUp(receipt)`.
     *
     * Fails with `UnexpectedVersion` when the instance is not at
     * `expectedVersion` (`0` by default, so an instance with events refuses
     * an import), and with `ImportOutOfOrder` when an event's time comes
     * before the event ahead of it (the instance's latest, for the first) or
     * after the platform's clock. Retrying with the same `commandId` returns
     * the original receipt.
     */
    readonly import: (target: Target<Def>, events: ReadonlyArray<Imported<InstanceOf<Def["events"][number]>>>, options: ImportOptions) => Effect.Effect<Receipt<InstanceOf<Def["events"][number]>, void>, UnexpectedVersion | ImportOutOfOrder>;
    /**
     * Read the current state of an instance, as of its latest commit: `initial`
     * for one that has never committed.
     */
    readonly get: (target: Target<Def>) => Effect.Effect<Def["state"]["Type"]>;
}
/** The commands of a definition that never reject, so can be scheduled. */
export type Schedulable<Def extends AnyDefinition> = Extract<Def["commands"][number], {
    readonly rejects: readonly [];
}>;
/**
 * The untyped form of {@link Client} the framework implements.
 *
 * @internal
 */
export interface ClientImpl {
    readonly send: (command: {
        readonly _tag: string;
    }, options?: SendOptions) => Effect.Effect<Receipt, unknown>;
    readonly schedule: (command: {
        readonly _tag: string;
    }, options: ScheduleOptions) => Effect.Effect<ScheduleReceipt>;
    readonly unschedule: (target: unknown, commandId: string) => Effect.Effect<void, AlreadyExecuted | AlreadyCancelled | NotScheduled>;
    readonly import: (target: unknown, events: ReadonlyArray<Imported<{
        readonly _tag: string;
    }>>, options: ImportOptions) => Effect.Effect<Receipt, UnexpectedVersion | ImportOutOfOrder>;
    readonly get: (target: unknown) => Effect.Effect<unknown>;
}
/**
 * Structural constraint satisfied by every aggregate class.
 */
export interface Any extends Context.Key<unknown, unknown> {
    readonly kind: "Aggregate";
    readonly annotations: Annotations;
    readonly aggregateName: string;
    readonly definition: AnyDefinition;
}
/** The id type of an aggregate class. */
export type IdOf<A extends Any> = A["definition"]["id"]["Type"];
/** The state type of an aggregate class. */
export type StateOf<A extends Any> = A["definition"]["state"]["Type"];
/** The event instance types of an aggregate class. */
export type EventOf<A extends Any> = InstanceOf<A["definition"]["events"][number]>;
/** The command instance types of an aggregate class. */
export type CommandOf<A extends Any> = InstanceOf<A["definition"]["commands"][number]>;
/** The requirement identifier of an aggregate class. */
export type Identifier<A extends Any> = A extends Context.Key<infer I, unknown> ? I : never;
/**
 * Options for {@link predict}: what the server would give `decide`. A command
 * with middleware needs `context`: what its middleware provides, from a
 * client-side Layer of the same services.
 */
export type PredictOptions<R = never> = PredictBase & ([R] extends [never] ? {
    readonly context?: Context.Context<never>;
} : {
    readonly context: Context.Context<R>;
});
interface PredictBase {
    /** The time the command is decided at (the server stamps commands with its clock). */
    readonly now: DateTime.Utc;
    /** The state's version: `decide` sees it, and predicted envelopes continue from it. Defaults to `0`. */
    readonly version?: number;
    /** The id the command will be sent with, for `decide` and the predicted envelopes. Defaults to `""`. */
    readonly commandId?: string;
    /** Defaults to the command id. */
    readonly correlationId?: string;
}
/**
 * What the aggregate would do with a command, decided locally: the events it
 * would record and the state after them, the rejection it would return, or
 * `Unpredictable` when only the server can tell. `cause` says why: `decide`
 * waited on something asynchronous (the server awaits it; `predict` is
 * synchronous), died, or broke its command's declaration through a cast (a
 * `DefinitionError`, which the server dies on).
 */
export type Prediction<State, Ev, Rej, Id = string> = {
    readonly _tag: "Accepted";
    readonly events: ReadonlyArray<Ev>;
    /** One envelope per event, as the server would stamp it (`seq` from `version`). */
    readonly envelopes: ReadonlyArray<Envelope<Id>>;
    readonly state: State;
} | {
    readonly _tag: "Rejected";
    readonly rejection: Rej;
} | {
    readonly _tag: "Unpredictable";
    readonly cause: Cause.Cause<unknown>;
};
/**
 * Run an aggregate's own `decide` and `evolve` for one command, without a
 * platform: the same events and state, or the same rejection, as the server
 * for the same state, id and time. Use it to show a command's outcome before
 * the server answers.
 *
 * An effectful decision runs here synchronously, as the kernel runs it: a
 * rejection fails with itself, and a `decide` that suspends or dies gives
 * `Unpredictable`. `predict` never throws.
 */
/**
 * One decision for one command, as the kernel and `predict` run it: the
 * command's handler, given the instance's state. `undefined` when `decide`
 * has no handler for the command.
 *
 * @internal
 */
export declare const decisionOf: (aggregate: Any, state: unknown, command: {
    readonly _tag: string;
}, ctx: DecideContext<unknown>) => unknown;
export declare const predict: (aggregate: Any, state: unknown, command: {
    readonly _tag: string;
}, options: PredictOptions) => Prediction<unknown, {
    readonly _tag: string;
}, {
    readonly _tag: string;
}>;
declare const RefClass: unique symbol;
/**
 * A typed address of one aggregate instance: aggregate type plus id.
 */
export interface Ref<A extends Any = Any> {
    readonly aggregate: A["aggregateName"];
    readonly id: IdOf<A>;
    readonly [RefClass]: A;
}
/** @internal */
export declare const refClass: <A extends Any>(ref: Ref<A>) => A;
/**
 * One entity that decides, such as a bank account: a consistency boundary.
 * It takes a command, checks it against its current state, and records events
 * or returns a rejection. Each instance handles one command at a time, and
 * its events, new state and reply commit together.
 *
 * ### Deciding and evolving
 * **Example:** An account that refuses overdrafts
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Schema from "effect/Schema";
 *
 * export const AccountId = Schema.String.pipe(Schema.brand("AccountId"));
 *
 * export class MoneyWithdrawn extends Domain.Event("MoneyWithdrawn", {
 *   amount: Schema.Int,
 *   balanceAfter: Schema.Int,
 * }) {}
 *
 * export class InsufficientFunds extends Domain.Rejection("InsufficientFunds", {
 *   balance: Schema.Int,
 *   requested: Schema.Int,
 * }) {}
 *
 * export class WithdrawMoney extends Domain.Command("WithdrawMoney", {
 *   input: { accountId: AccountId, amount: Schema.Int },
 *   events: [MoneyWithdrawn],
 *   rejects: [InsufficientFunds],
 *   reply: { balance: Schema.Int },
 * }) {}
 *
 * export class Account extends Domain.Aggregate("Account", {
 *   id: AccountId,
 *   state: Schema.Struct({ balance: Schema.Int }),
 *   initial: { balance: 0 },
 *   commands: [WithdrawMoney],
 *   keyOf: (cmd) => cmd.accountId,
 *   decide: {
 *     WithdrawMoney: (account, cmd) =>
 *       cmd.amount > account.balance
 *         ? new InsufficientFunds({ balance: account.balance, requested: cmd.amount })
 *         : [new MoneyWithdrawn({ amount: cmd.amount, balanceAfter: account.balance - cmd.amount })],
 *   },
 *   evolve: {
 *     MoneyWithdrawn: (_, e) => ({ balance: e.balanceAfter }),
 *   },
 *   reply: {
 *     WithdrawMoney: (s) => ({ balance: s.balance }),
 *   },
 * }) {}
 * ```
 *
 * ### Authorizing in decide
 * A handler can be an `Effect.fn` that reads what its command's middleware
 * provides.
 *
 * **Example:** Only the owner may withdraw
 * ```typescript
 * decide: {
 *   WithdrawMoney: Effect.fn(function* (account, cmd) {
 *     const actor = yield* CurrentActor;
 *     if (actor.customerId !== account.owner) return yield* new NotOwner();
 *     return [new MoneyWithdrawn({ amount: cmd.amount, balanceAfter: account.balance - cmd.amount })];
 *   }),
 * },
 * ```
 *
 * ### Sending and scheduling
 * **Example:** From a policy or your own code
 * ```typescript
 * const accounts = yield* Account;
 * const { reply } = yield* accounts.send(new WithdrawMoney({ accountId, amount: 30 }));
 * yield* accounts.schedule(new SendStatement({ accountId }), { after: "30 days", commandId: "statement" });
 * yield* accounts.unschedule(accountId, "statement"); // cancel it while it is pending
 * ```
 *
 * ### Folding what decisions record
 * A `Domain.Decision` records events on the instances it reads. List them in
 * `events`, with an `evolve` handler for each. An aggregate that only takes
 * part in decisions leaves out `commands`, `keyOf` and `decide`.
 *
 * **Example:** A username, claimed by a registration
 * ```typescript
 * export class UsernameClaim extends Domain.Aggregate("UsernameClaim", {
 *   id: Username,
 *   state: Schema.Union([
 *     Schema.TaggedStruct("Free", {}),
 *     Schema.TaggedStruct("Claimed", { customerId: CustomerId }),
 *   ]),
 *   initial: { _tag: "Free" },
 *   events: [UsernameClaimed],
 *   evolve: {
 *     UsernameClaimed: (_, e) => ({ _tag: "Claimed" as const, customerId: e.customerId }),
 *   },
 * }) {}
 * ```
 *
 * ### Annotating aggregates
 * The last argument is its annotations: data for what is built on the
 * model, read back as `X.annotations`. Add your own keys by augmenting
 * `Domain.Annotations`.
 *
 * **Example:** A description
 * ```typescript
 * export class Account extends Domain.Aggregate(
 *   "Account",
 *   {
 *     id: AccountId,
 *     state: Schema.Struct({ balance: Schema.Int }),
 *     initial: { balance: 0 },
 *     commands: [DepositMoney],
 *     keyOf: (cmd) => cmd.accountId,
 *     decide: { DepositMoney: (account, cmd) => [new MoneyDeposited({ balanceAfter: account.balance + cmd.amount })] },
 *     evolve: { MoneyDeposited: (_, e) => ({ balance: e.balanceAfter }) },
 *   },
 *   { description: "A bank account, which keeps its own balance." },
 * ) {}
 * ```
 *
 * @primitive
 */
export declare const makeRef: <A extends Any>(aggregate: A, id: IdOf<A>) => Ref<A>;
/** The stream id of a ref, e.g. `Account/a-1`. */
export declare const streamOf: (ref: {
    readonly aggregate: string;
    readonly id: string;
}) => string;
/** The id addressed by a {@link Target}. @internal */
export declare const targetId: typeof internalTargetId;
declare const PolicyRun_base: Context.ServiceClass<PolicyRun, "alchemy/Domain/PolicyRun", {
    readonly next: () => string;
}>;
/**
 * Deterministic command ids for sends made while a policy handles a trigger,
 * so a re-run of the same trigger is deduplicated by the target aggregate.
 *
 * @internal
 */
export declare class PolicyRun extends PolicyRun_base {
}
/**
 * The command id for a send: the caller's; inside a saga step, the step's
 * next id, so a step that runs again sends the same commands; the policy
 * run's next deterministic id; or a fresh one.
 *
 * @internal
 */
export declare const commandIdFor: (options: SendOptions | undefined, random: SecureRandom.SecureRandom["Service"]) => Effect.Effect<string>;
/**
 * Declare an aggregate: a consistency boundary keyed by id that decides
 * commands against its current state and records events.
 *
 * The class is also a service tag: `yield* Customer` gives its {@link Client}
 * (`send`, `state`), provided by the Domain's Layer.
 *
 * **Example:** Declaring an aggregate
 * ```typescript
 * export class Customer extends Domain.Aggregate("Customer", {
 *   id: CustomerId,
 *   state: CustomerState,
 *   initial: { _tag: "New" },
 *   commands: [Register], // declares events: [CustomerRegistered]
 *   keyOf: (cmd) => cmd.customerId,
 *   decide: {
 *     Register: (customer, cmd) =>
 *       customer._tag === "Registered" ? new AlreadyRegistered() : [new CustomerRegistered({ name: cmd.name })],
 *   },
 *   evolve: {
 *     CustomerRegistered: (_, e) => ({ _tag: "Registered", name: e.name }),
 *   },
 * }) {}
 *
 * const customers = yield* Customer;
 * yield* customers.send(new Register({ customerId: "c-1", name: "sam" }));
 * ```
 */
export declare const make: <const Name extends string, Id extends IdSchema, S extends Schema.Top, const C extends ReadonlyArray<Command.Any> = readonly [], const X extends ReadonlyArray<Event.Any> = readonly []>(name: Name, definition: Definition<Id, S, C, X> & Decides<C>, annotations?: Annotations) => AggregateClass<Name, Resolved<Id, S, C, X>>;
/** An aggregate with commands says which instance each is for, and decides each. */
export type Decides<C extends ReadonlyArray<Command.Any>> = [C[number]] extends [never] ? unknown : {
    readonly commands: C;
    readonly keyOf: Function;
    readonly decide: object;
};
/**
 * The id of the instance a command is for, from the aggregate's `keyOf`;
 * `undefined` when the aggregate doesn't handle the command.
 *
 * @internal
 */
export declare const targetOf: (aggregate: Any, command: {
    readonly _tag: string;
}) => string | undefined;
/** A definition with its events collected from its commands. */
export type Resolved<Id extends IdSchema, S extends Schema.Top, C extends ReadonlyArray<Command.Any>, X extends ReadonlyArray<Event.Any> = readonly []> = Omit<Definition<Id, S, C, X>, "events" | "commands" | "decide" | "keyOf"> & Required<Pick<Definition<Id, S, C, X>, "commands" | "decide">> & {
    /** Absent on an aggregate with no commands of its own. */
    readonly keyOf: ((command: InstanceOf<C[number]>) => Id["Type"]) | undefined;
    readonly events: ReadonlyArray<EventsOf<C> | X[number]>;
};
/**
 * The class type returned by {@link make}.
 */
export interface AggregateClass<Name extends string, Def extends AnyDefinition> extends Context.ServiceClass<Key<Name>, string, Client<Def>> {
    readonly kind: "Aggregate";
    readonly annotations: Annotations;
    readonly aggregateName: Name;
    readonly definition: Def;
    /** Address one instance of this aggregate. */
    ref<Self extends Any>(this: Self, id: Self["definition"]["id"]["Encoded"]): Ref<Self>;
    /**
     * Decide a command locally, with this aggregate's own `decide` and
     * `evolve`: the events and state, or the rejection, the server would give
     * for the same state, id and time. A command with middleware needs
     * `context`: what its middleware provides, from a client-side Layer. See
     * {@link predict}.
     *
     * **Example:** Show a withdrawal before the bank answers
     * ```typescript
     * const context = yield* Layer.build(Layer.succeed(CurrentActor, actor));
     * const outcome = Account.predict(state, new WithdrawMoney({ accountId, amount: 30 }), { now, context });
     * if (outcome._tag === "Rejected") showError(outcome.rejection); // InsufficientFunds
     * if (outcome._tag === "Accepted") showPending(outcome.state);
     * ```
     */
    predict<Self extends Any, Cmd extends CommandOf<Self>>(this: Self, state: StateOf<Self>, command: Cmd, options: PredictOptions<Command.ContextOf<CommandClassOf<Self["definition"], Cmd>>>): Prediction<StateOf<Self>, InstanceOf<CommandClassOf<Self["definition"], Cmd>["events"][number]>, InstanceOf<CommandClassOf<Self["definition"], Cmd>["rejects"][number]>, IdOf<Self>>;
}
export {};
//# sourceMappingURL=Aggregate.d.ts.map