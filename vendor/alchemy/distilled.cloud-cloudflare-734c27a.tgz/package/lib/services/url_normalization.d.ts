import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
export interface DeleteUrlNormalizationRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export interface DeleteUrlNormalizationResponse {
}
export interface GetUrlNormalizationRequest {
    /** The unique ID of the zone. */
    zoneId: string;
}
export type GetResultScope = "incoming" | "both" | "none";
export type GetResultType = "cloudflare" | "rfc3986";
export interface GetResult {
    /** The scope of the URL normalization. */
    scope: GetResultScope;
    /** The type of URL normalization performed by Cloudflare. */
    type: GetResultType;
}
export type GetUrlNormalizationResponse = GetResult;
export type UpdateRequestScope = "incoming" | "both" | "none";
export type UpdateRequestType = "cloudflare" | "rfc3986";
export interface PutUrlNormalizationRequest {
    /** The unique ID of the zone. */
    zoneId: string;
    /** The scope of the URL normalization. */
    scope: UpdateRequestScope | (string & {});
    /** The type of URL normalization performed by Cloudflare. */
    type: UpdateRequestType | (string & {});
}
export type UpdateResultScope = "incoming" | "both" | "none";
export type UpdateResultType = "cloudflare" | "rfc3986";
export interface UpdateResult {
    /** The scope of the URL normalization. */
    scope: UpdateResultScope;
    /** The type of URL normalization performed by Cloudflare. */
    type: UpdateResultType;
}
export type PutUrlNormalizationResponse = UpdateResult;
export type DeleteUrlNormalizationError = Forbidden | CloudflareOpError;
/** Deletes the URL Normalization settings. */
export declare const deleteUrlNormalization: API.OperationMethod<DeleteUrlNormalizationRequest, DeleteUrlNormalizationResponse, DeleteUrlNormalizationError, CloudflareOpContext>;
export type GetUrlNormalizationError = Forbidden | CloudflareOpError;
/** Fetches the current URL Normalization settings. */
export declare const getUrlNormalization: API.OperationMethod<GetUrlNormalizationRequest, GetUrlNormalizationResponse, GetUrlNormalizationError, CloudflareOpContext>;
export type PutUrlNormalizationError = Forbidden | CloudflareOpError;
/** Updates the URL Normalization settings. */
export declare const putUrlNormalization: API.OperationMethod<PutUrlNormalizationRequest, PutUrlNormalizationResponse, PutUrlNormalizationError, CloudflareOpContext>;
//# sourceMappingURL=url_normalization.d.ts.map