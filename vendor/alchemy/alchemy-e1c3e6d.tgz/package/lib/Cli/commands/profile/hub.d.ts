import * as Effect from "effect/Effect";
import * as Option from "effect/Option";
export declare const profileHub: (options: {
    envFile: Option.Option<string>;
    main: string;
}) => Effect.Effect<void, import("../../../Interaction.ts").NonInteractiveTerminal | import("effect/PlatformError").PlatformError | import("../../../Auth/Profile.ts").ProfileError, import("../../../Alchemist/AuthRegistry.ts").CollectAuthProvidersServices>;
//# sourceMappingURL=hub.d.ts.map