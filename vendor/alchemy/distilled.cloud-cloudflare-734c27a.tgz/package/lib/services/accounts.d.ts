import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const AccountCreationForbidden_base: S.TaggedErrorClass<"AccountCreationForbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AccountCreationForbidden extends /*@__PURE__*/ AccountCreationForbidden_base {
}
declare const AccountMemberAlreadyExists_base: S.TaggedErrorClass<"AccountMemberAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AccountMemberAlreadyExists extends /*@__PURE__*/ AccountMemberAlreadyExists_base {
}
declare const AccountNameTooLong_base: S.TaggedErrorClass<"AccountNameTooLong", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class AccountNameTooLong extends /*@__PURE__*/ AccountNameTooLong_base {
}
declare const BadRequest_base: S.TaggedErrorClass<"BadRequest", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class BadRequest extends /*@__PURE__*/ BadRequest_base {
}
declare const EndpointNotFound_base: S.TaggedErrorClass<"EndpointNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class EndpointNotFound extends /*@__PURE__*/ EndpointNotFound_base {
}
declare const InvalidAccountName_base: S.TaggedErrorClass<"InvalidAccountName", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidAccountName extends /*@__PURE__*/ InvalidAccountName_base {
}
declare const InvalidRoute_base: S.TaggedErrorClass<"InvalidRoute", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidRoute extends /*@__PURE__*/ InvalidRoute_base {
}
declare const InvalidTokenName_base: S.TaggedErrorClass<"InvalidTokenName", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class InvalidTokenName extends /*@__PURE__*/ InvalidTokenName_base {
}
declare const JsonDecodeFailure_base: S.TaggedErrorClass<"JsonDecodeFailure", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class JsonDecodeFailure extends /*@__PURE__*/ JsonDecodeFailure_base {
}
declare const MemberNotFound_base: S.TaggedErrorClass<"MemberNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MemberNotFound extends /*@__PURE__*/ MemberNotFound_base {
}
declare const MethodNotAllowed_base: S.TaggedErrorClass<"MethodNotAllowed", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MethodNotAllowed extends /*@__PURE__*/ MethodNotAllowed_base {
}
declare const MissingAuthenticationToken_base: S.TaggedErrorClass<"MissingAuthenticationToken", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MissingAuthenticationToken extends /*@__PURE__*/ MissingAuthenticationToken_base {
}
declare const MissingName_base: S.TaggedErrorClass<"MissingName", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class MissingName extends /*@__PURE__*/ MissingName_base {
}
declare const PermissionGroupNotFound_base: S.TaggedErrorClass<"PermissionGroupNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class PermissionGroupNotFound extends /*@__PURE__*/ PermissionGroupNotFound_base {
}
declare const TokenManagedByCloudflare_base: S.TaggedErrorClass<"TokenManagedByCloudflare", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TokenManagedByCloudflare extends /*@__PURE__*/ TokenManagedByCloudflare_base {
}
declare const TokenNotFound_base: S.TaggedErrorClass<"TokenNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TokenNotFound extends /*@__PURE__*/ TokenNotFound_base {
}
declare const UpdateAccountTypeNotSupported_base: S.TaggedErrorClass<"UpdateAccountTypeNotSupported", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class UpdateAccountTypeNotSupported extends /*@__PURE__*/ UpdateAccountTypeNotSupported_base {
}
declare const ValidationError_base: S.TaggedErrorClass<"ValidationError", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class ValidationError extends /*@__PURE__*/ ValidationError_base {
}
export type CreateRequestType = "standard" | "enterprise";
export interface CreateRequestUnit {
    /** Tenant unit ID */
    id?: string | undefined;
}
export interface CreateAccountRequest {
    idempotencyKey?: string | undefined;
    /** Account name, limited to 65 UTF-8 bytes. */
    name: string;
    /** Set to `true` and omit `unit` to create a standalone Free Account. If provided, this field must be `true`. */
    standalone?: boolean | undefined;
    /** The 'type' field should no longer be set through the API. */
    type?: CreateRequestType | (string & {}) | undefined;
    /** Information related to the tenant unit. Provide its ID and omit `standalone` to create the Account within an Organization. See https://developers.cloudflare.com/tenant/how-to/manage-accounts/. */
    unit?: CreateRequestUnit | undefined;
}
export type CreateResponseType = "standard" | "enterprise";
export interface CreateResponseLegacyFlagsEnterpriseZoneQuota {
    /** Number of additional Enterprise zones available. Returns 0 if the quota is not allocated or is exhausted. */
    available?: number | null | undefined;
    /** Current number of Enterprise zones. */
    current?: number | null | undefined;
    /** Maximum number of Enterprise zones allowed. */
    maximum?: number | null | undefined;
}
export interface CreateResponseLegacyFlags {
    /** Enterprise zone quota for standard and enterprise accounts. Accounts without a quota have a maximum of 0. */
    enterpriseZoneQuota?: CreateResponseLegacyFlagsEnterpriseZoneQuota | null | undefined;
}
export interface CreateResponseManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | null | undefined;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | null | undefined;
    /** ID of the root Organization, if one exists */
    rootOrgId?: string | null | undefined;
    /** Indicates whether the parent Organization hierarchy should be displayed */
    shouldDisplayParentOrgs?: boolean | null | undefined;
}
export interface CreateResponseSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | null | undefined;
    /** Indicates whether membership in this account requires that Two-Factor Authentication is enabled */
    enforceTwofactor?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: CreateResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: CreateResponseLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null | undefined;
    /** Account settings */
    settings?: CreateResponseSettings | null | undefined;
}
export interface CreateAccountOrganizationRequest {
    accountId: string;
    /** The ID of the organization to move the account into. */
    destinationOrganizationId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateAccountOrganizationResponse {
    accountId: string;
    destinationOrganizationId: string;
    /** Empty string when the account did not belong to an organization before the move. */
    sourceOrganizationId: string;
}
export interface CreateClientSecretRequest {
    /** Identifier */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateClientSecretResponse {
    /** The Stripe client secret for frontend payment confirmation. */
    clientSecret?: string | null | undefined;
}
export type MembersCreateRequestRolesList = Array<string>;
export type MembersCreateRequestStatus = "accepted" | "pending";
export type MembersCreateRequestPoliciesItemAccess = "allow" | "deny";
export interface MembersCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the group. */
    id: string;
}
export type MembersCreateRequestPoliciesItemPermissionGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersCreateRequestPoliciesItemResourceGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export type MembersCreateRequestPoliciesItemResourceGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export interface MembersCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    access: MembersCreateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: MembersCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource groups that the policy applies to. */
    resourceGroups: MembersCreateRequestPoliciesItemResourceGroupsList;
}
export type MembersCreateRequestPoliciesList = Array<MembersCreateRequestPoliciesItem>;
export interface CreateMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** The contact email address of the user. */
    email: string;
    /** Array of roles associated with this member. */
    roles?: MembersCreateRequestRolesList | undefined;
    /** Status of the member invitation. If not provided during creation, defaults to 'pending'. Changing from 'accepted' back to 'pending' will trigger a replacement of the member resource in Terraform. */
    status?: MembersCreateRequestStatus | (string & {}) | undefined;
    /** Array of policies associated with this member. */
    policies?: MembersCreateRequestPoliciesList | undefined;
}
export type MembersCreateResponsePoliciesItemAccess = "allow" | "deny";
export interface MembersCreateResponsePoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | null | undefined;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | null | undefined;
    /** Additional information about the permission group. */
    description?: string | null | undefined;
    /** Indicates whether the permission group can be edited. */
    editable?: string | null | undefined;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | null | undefined;
    /** A label identifying the permission group. */
    label?: string | null | undefined;
    /** The scope associated with the permission group. */
    scopes?: string | null | undefined;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | null | undefined;
}
export interface MembersCreateResponsePoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: MembersCreateResponsePoliciesItemPermissionGroupsItemMeta | null | undefined;
    /** Name of the permission group. */
    name?: string | null | undefined;
}
export type MembersCreateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem {
    /** This is a combination of pre-defined resource name and identifier (like Zone ID etc.) */
    key: string;
}
export type MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersCreateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export interface MembersCreateResponsePoliciesItemResourceGroupsItemMeta {
    key?: string | null | undefined;
    value?: string | null | undefined;
}
export interface MembersCreateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersCreateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null | undefined;
    /** Name of the resource group. */
    name?: string | null | undefined;
}
export type MembersCreateResponsePoliciesItemResourceGroupsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItem>;
export interface MembersCreateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null | undefined;
    /** Allow or deny operations against the resources. */
    access?: MembersCreateResponsePoliciesItemAccess | null | undefined;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersCreateResponsePoliciesItemPermissionGroupsList | null | undefined;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersCreateResponsePoliciesItemResourceGroupsList | null | undefined;
}
export type MembersCreateResponsePoliciesList = Array<MembersCreateResponsePoliciesItem>;
export interface MembersCreateResponseRolesItemPermissionsAnalytics {
    read?: boolean | null | undefined;
    write?: boolean | null | undefined;
}
export type MembersCreateResponseRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersCreateResponseRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export interface MembersCreateResponseRolesItemPermissions {
    analytics?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    billing?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    cachePurge?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    dns?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    dnsRecords?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    lb?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    logs?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    organization?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    ssl?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    waf?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    zoneSettings?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
    zones?: MembersCreateResponseRolesItemPermissionsAnalytics | null | undefined;
}
export interface MembersCreateResponseRolesItem {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description: string;
    /** Role name. */
    name: string;
    permissions: MembersCreateResponseRolesItemPermissions;
}
export type MembersCreateResponseRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersCreateResponseStatus = "accepted" | "pending";
export interface MembersCreateResponseUser {
    /** The contact email address of the user. */
    email: string;
    /** Identifier */
    id?: string | null | undefined;
    /** User's first name */
    firstName?: string | null | undefined;
    /** User's last name */
    lastName?: string | null | undefined;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateMemberResponse {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    /** The contact email address of the user. */
    email?: string | null | undefined;
    /** Access policy for the membership */
    policies?: MembersCreateResponsePoliciesList | null | undefined;
    /** Roles assigned to this Member. */
    roles?: MembersCreateResponseRolesList | null | undefined;
    /** A member's status in the account. */
    status?: MembersCreateResponseStatus | null | undefined;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null | undefined;
}
export interface CreatePayBadDebtRequest {
    /** Identifier */
    accountId: string;
    /** The payment method to use. If omitted, the default payment method is used. */
    paymentMethodId?: string | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePayBadDebtResponse {
    /** The Stripe client secret for frontend payment confirmation. */
    clientSecret?: string | null | undefined;
}
export interface CreatePayInvoiceRequest {
    /** Identifier */
    accountId: string;
    /** The identifier of the invoice to pay. */
    invoiceId?: string | undefined;
    /** The payment method to use. If omitted, the default payment method is used. */
    paymentMethodId?: string | undefined;
    /** Whether to validate the payment method before processing. */
    validatePaymentMethod?: boolean | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePayInvoiceResponse {
    /** The Stripe client secret for frontend payment confirmation. */
    clientSecret?: string | null | undefined;
}
export type CreatePaymentMethodRequestType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
export interface CreatePaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Billing address line 1. */
    address?: string | undefined;
    /** Billing address line 2. */
    address2?: string | undefined;
    /** Bank account type. */
    bankAccountType?: string | undefined;
    /** Bank code. */
    bankCode?: string | undefined;
    /** Bank country. */
    bankCountry?: string | undefined;
    /** Bank name for bank-based payment methods. */
    bankName?: string | undefined;
    /** Bank routing number. */
    bankRoutingNumber?: string | undefined;
    /** Cash App cash tag. */
    cashappCashTag?: string | undefined;
    /** Billing city. */
    city?: string | undefined;
    /** Billing country. */
    country?: string | undefined;
    /** Whether this is the default payment method. */
    default?: boolean | undefined;
    /** Device data for fraud prevention. */
    deviceData?: string | undefined;
    /** Billing first name. */
    firstName?: string | undefined;
    /** Billing last name. */
    lastName?: string | undefined;
    /** A nickname for the payment method. */
    nickName?: string | undefined;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | undefined;
    /** Payment email address. */
    paymentEmail?: string | undefined;
    /** The payment gateway used. */
    paymentGateway?: string | undefined;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | undefined;
    /** Billing state. */
    state?: string | undefined;
    /** The payment method type. */
    type?: CreatePaymentMethodRequestType | (string & {}) | undefined;
    /** Billing zip code. */
    zipcode?: string | undefined;
}
export type CreatePaymentMethodResponseType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePaymentMethodResponse {
    /** Payment method identifier. */
    id?: string | null | undefined;
    /** Billing address line 1. */
    address?: string | null | undefined;
    /** Billing address line 2. */
    address2?: string | null | undefined;
    /** Bank account type. */
    bankAccountType?: string | null | undefined;
    /** Bank code. */
    bankCode?: string | null | undefined;
    /** Bank country. */
    bankCountry?: string | null | undefined;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null | undefined;
    /** Bank routing number. */
    bankRoutingNumber?: string | null | undefined;
    /** Cash App cash tag. */
    cashappCashTag?: string | null | undefined;
    /** Billing city. */
    city?: string | null | undefined;
    /** Billing country. */
    country?: string | null | undefined;
    /** Whether this is the default payment method. */
    default?: boolean | null | undefined;
    /** Device data for fraud prevention. */
    deviceData?: string | null | undefined;
    /** Card expiration date. */
    expirationDate?: string | null | undefined;
    /** Billing first name. */
    firstName?: string | null | undefined;
    /** Last four digits of the card number. */
    lastFour?: string | null | undefined;
    /** Billing last name. */
    lastName?: string | null | undefined;
    /** A nickname for the payment method. */
    nickName?: string | null | undefined;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null | undefined;
    /** Payment email address. */
    paymentEmail?: string | null | undefined;
    /** The payment gateway used. */
    paymentGateway?: string | null | undefined;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null | undefined;
    /** Billing state. */
    state?: string | null | undefined;
    /** The payment method type. */
    type?: CreatePaymentMethodResponseType | null | undefined;
    /** Billing zip code. */
    zipcode?: string | null | undefined;
}
export type SubscriptionsCreateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsCreateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsCreateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsCreateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateRequestRatePlanId | (string & {}) | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | undefined;
    /** The full name of the rate plan. */
    publicName?: string | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateRequestRatePlanSetsList | undefined;
}
export interface CreateSubscriptionRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateRequestFrequency | (string & {}) | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateRequestRatePlan | undefined;
}
export type SubscriptionsCreateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsCreateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsCreateResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsCreateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsCreateResponseRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsCreateResponseRatePlanSetsList | null | undefined;
}
export type SubscriptionsCreateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsCreateResponseFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsCreateResponseRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsCreateResponseState | null | undefined;
}
export type TokensCreateRequestPoliciesItemEffect = "allow" | "deny";
export interface TokensCreateRequestPoliciesItemPermissionGroupsItemMeta {
    /** A category used to group permission groups. */
    category?: string | undefined;
    /** Indicates whether the permission group is deprecated. */
    deprecated?: string | undefined;
    /** Additional information about the permission group. */
    description?: string | undefined;
    /** Indicates whether the permission group can be edited. */
    editable?: string | undefined;
    /** The planned end-of-life date and time, when provided. */
    eolAt?: string | undefined;
    /** A label identifying the permission group. */
    label?: string | undefined;
    /** The scope associated with the permission group. */
    scopes?: string | undefined;
    /** Indicates the permission group's availability or visibility. */
    visibility?: string | undefined;
}
export interface TokensCreateRequestPoliciesItemPermissionGroupsItem {
    /** Identifier of the permission group. */
    id: string;
    /** Attributes associated to the permission group. */
    meta?: TokensCreateRequestPoliciesItemPermissionGroupsItemMeta | undefined;
    /** Name of the permission group. */
    name?: string | undefined;
}
export type TokensCreateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateRequestPoliciesItemResourcesValue = string | TokensCreateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensCreateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensCreateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensCreateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateRequestPoliciesItemResourcesMap;
}
export type TokensCreateRequestPoliciesList = Array<TokensCreateRequestPoliciesItem>;
export type TokensCreateRequestConditionRequestIpInList = Array<string>;
export type TokensCreateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensCreateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateRequestConditionRequestIpInList | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateRequestConditionRequestIpNotInList | undefined;
}
export interface TokensCreateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateRequestConditionRequestIp | undefined;
}
export interface CreateTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensCreateRequestPoliciesList;
    condition?: TokensCreateRequestCondition | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | undefined;
}
export type TokensCreateResponseConditionRequestIpInList = Array<string>;
export type TokensCreateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensCreateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensCreateResponseConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensCreateResponseConditionRequestIpNotInList | null | undefined;
}
export interface TokensCreateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensCreateResponseConditionRequestIp | null | undefined;
}
export type TokensCreateResponsePoliciesItemEffect = "allow" | "deny";
export type TokensCreateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensCreateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensCreateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensCreateResponsePoliciesItemResourcesValue = string | TokensCreateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensCreateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensCreateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensCreateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensCreateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensCreateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensCreateResponsePoliciesItemResourcesMap;
}
export type TokensCreateResponsePoliciesList = Array<TokensCreateResponsePoliciesItem>;
export type TokensCreateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateTokenResponse {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensCreateResponseCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensCreateResponsePoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensCreateResponseStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
    /** The token value. */
    value?: string | null | undefined;
}
export interface DeleteAccountRequest {
    /** The account ID of the account to be deleted */
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteAccountResponse {
    /** Identifier */
    id: string;
}
export interface DeleteMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteMemberResponse {
    /** Identifier */
    id: string;
}
export interface DeletePaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
}
export type DeletePaymentMethodResponse = unknown;
export interface DeleteSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteSubscriptionResponse {
    /** Subscription identifier tag. */
    subscriptionId?: string | null | undefined;
}
export interface DeleteTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteTokenResponse {
    /** Identifier */
    id: string;
}
export interface EditInvoiceRequest {
    /** Identifier */
    accountId: string;
    /** Whether to enable or disable PDF invoice generation. */
    toggle?: boolean | undefined;
}
export type EditInvoiceResponse = unknown;
export interface GetAccountRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type GetResponseType = "standard" | "enterprise";
export type GetResponseLegacyFlagsEnterpriseZoneQuota = CreateResponseLegacyFlagsEnterpriseZoneQuota;
export type GetResponseLegacyFlags = CreateResponseLegacyFlags;
export type GetResponseManagedBy = CreateResponseManagedBy;
export type GetResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: GetResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: CreateResponseLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null | undefined;
    /** Account settings */
    settings?: CreateResponseSettings | null | undefined;
}
export interface GetAccountProfileRequest {
    accountId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetAccountProfileResponse {
    businessAddress: string;
    businessEmail: string;
    businessName: string;
    businessPhone: string;
    externalMetadata: string;
}
export interface GetMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
}
export type MembersGetResponsePoliciesItemAccess = "allow" | "deny";
export type MembersGetResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type MembersGetResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type MembersGetResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type MembersGetResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersGetResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersGetResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type MembersGetResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemResourceGroupsItemMeta;
export interface MembersGetResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersGetResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null | undefined;
    /** Name of the resource group. */
    name?: string | null | undefined;
}
export type MembersGetResponsePoliciesItemResourceGroupsList = Array<MembersGetResponsePoliciesItemResourceGroupsItem>;
export interface MembersGetResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null | undefined;
    /** Allow or deny operations against the resources. */
    access?: MembersGetResponsePoliciesItemAccess | null | undefined;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersGetResponsePoliciesItemPermissionGroupsList | null | undefined;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersGetResponsePoliciesItemResourceGroupsList | null | undefined;
}
export type MembersGetResponsePoliciesList = Array<MembersGetResponsePoliciesItem>;
export type MembersGetResponseRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersGetResponseRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export type MembersGetResponseRolesItem = MembersCreateResponseRolesItem;
export type MembersGetResponseRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersGetResponseStatus = "accepted" | "pending";
export type MembersGetResponseUser = MembersCreateResponseUser;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetMemberResponse {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    /** The contact email address of the user. */
    email?: string | null | undefined;
    /** Access policy for the membership */
    policies?: MembersGetResponsePoliciesList | null | undefined;
    /** Roles assigned to this Member. */
    roles?: MembersGetResponseRolesList | null | undefined;
    /** A member's status in the account. */
    status?: MembersGetResponseStatus | null | undefined;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null | undefined;
}
export interface GetPaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
}
export type GetPaymentMethodResponseType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPaymentMethodResponse {
    /** Payment method identifier. */
    id?: string | null | undefined;
    /** Billing address line 1. */
    address?: string | null | undefined;
    /** Billing address line 2. */
    address2?: string | null | undefined;
    /** Bank account type. */
    bankAccountType?: string | null | undefined;
    /** Bank code. */
    bankCode?: string | null | undefined;
    /** Bank country. */
    bankCountry?: string | null | undefined;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null | undefined;
    /** Bank routing number. */
    bankRoutingNumber?: string | null | undefined;
    /** Cash App cash tag. */
    cashappCashTag?: string | null | undefined;
    /** Billing city. */
    city?: string | null | undefined;
    /** Billing country. */
    country?: string | null | undefined;
    /** Whether this is the default payment method. */
    default?: boolean | null | undefined;
    /** Device data for fraud prevention. */
    deviceData?: string | null | undefined;
    /** Card expiration date. */
    expirationDate?: string | null | undefined;
    /** Billing first name. */
    firstName?: string | null | undefined;
    /** Last four digits of the card number. */
    lastFour?: string | null | undefined;
    /** Billing last name. */
    lastName?: string | null | undefined;
    /** A nickname for the payment method. */
    nickName?: string | null | undefined;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null | undefined;
    /** Payment email address. */
    paymentEmail?: string | null | undefined;
    /** The payment gateway used. */
    paymentGateway?: string | null | undefined;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null | undefined;
    /** Billing state. */
    state?: string | null | undefined;
    /** The payment method type. */
    type?: GetPaymentMethodResponseType | null | undefined;
    /** Billing zip code. */
    zipcode?: string | null | undefined;
}
export interface GetRoleRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Role identifier tag. */
    roleId: string;
}
export type RolesGetResponsePermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesGetResponsePermissions = MembersCreateResponseRolesItemPermissions;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRoleResponse {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description: string;
    /** Role name. */
    name: string;
    permissions: MembersCreateResponseRolesItemPermissions;
}
export interface GetSpeedSettingsTransformationRequest {
    /** Identifier. */
    accountId: string;
}
export interface GetSpeedSettingsTransformationResultItem {
    /** Feature identifier. */
    id?: string | null | undefined;
    /** Zone tag identifier. */
    cfZoneTag?: string | null | undefined;
    /** Whether this setting can be modified. */
    editable?: boolean | null | undefined;
    /** When this setting was last modified. */
    modifiedOn?: string | null | undefined;
    /** Current value of the feature setting. */
    value?: string | null | undefined;
}
export type GetSpeedSettingsTransformationResultList = Array<GetSpeedSettingsTransformationResultItem>;
export type GetSpeedSettingsTransformationResponse = GetSpeedSettingsTransformationResultList;
export interface GetSubscriptionRequest {
    /** The Account ID to use for this endpoint. Mutually exclusive with the Zone ID. */
    accountId: string;
}
export type SubscriptionsGetResultItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsGetResultItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetResultItemRatePlanSetsList = Array<string>;
export interface SubscriptionsGetResultItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetResultItemRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetResultItemRatePlanSetsList | null | undefined;
}
export type SubscriptionsGetResultItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsGetResultItem {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetResultItemFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetResultItemRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetResultItemState | null | undefined;
}
export type SubscriptionsGetResultList = Array<SubscriptionsGetResultItem>;
export interface GetSubscriptionResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: SubscriptionsGetResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface GetTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export type TokensGetResponseConditionRequestIpInList = Array<string>;
export type TokensGetResponseConditionRequestIpNotInList = Array<string>;
export interface TokensGetResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensGetResponseConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensGetResponseConditionRequestIpNotInList | null | undefined;
}
export interface TokensGetResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensGetResponseConditionRequestIp | null | undefined;
}
export type TokensGetResponsePoliciesItemEffect = "allow" | "deny";
export type TokensGetResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensGetResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensGetResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensGetResponsePoliciesItemResourcesValue = string | TokensGetResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensGetResponsePoliciesItemResourcesMap = {
    [key: string]: TokensGetResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensGetResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensGetResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensGetResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensGetResponsePoliciesItemResourcesMap;
}
export type TokensGetResponsePoliciesList = Array<TokensGetResponsePoliciesItem>;
export type TokensGetResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetTokenResponse {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensGetResponseCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensGetResponsePoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensGetResponseStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
}
export interface GetTokenPermissionGroupRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Filter by the name of the permission group. The value must be URL-encoded. */
    name?: string | undefined;
    /** Filter by the scope of the permission group. The value must be URL-encoded. */
    scope?: string | undefined;
}
export type TokensPermissionGroupsGetResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export type TokensPermissionGroupsGetResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export type TokensPermissionGroupsGetResultItemScopesList = Array<TokensPermissionGroupsGetResultItemScopesItem>;
export interface TokensPermissionGroupsGetResultItem {
    /** Public ID. */
    id?: string | null | undefined;
    /** Product category that this permission group belongs to. */
    category?: TokensPermissionGroupsGetResultItemCategory | null | undefined;
    /** Whether the caller can select this permission group when creating a token. */
    isSelectable?: boolean | null | undefined;
    /** Permission Group Name */
    name?: string | null | undefined;
    /** Resources to which the Permission Group is scoped */
    scopes?: TokensPermissionGroupsGetResultItemScopesList | null | undefined;
}
export type TokensPermissionGroupsGetResultList = Array<TokensPermissionGroupsGetResultItem>;
export type GetTokenPermissionGroupResponse = TokensPermissionGroupsGetResultList;
export type ListRequestDirection = "asc" | "desc";
export interface ListAccountsRequest {
    /** Direction to order results. */
    direction?: ListRequestDirection | (string & {}) | undefined;
    /** Name of the account. */
    name?: string | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Maximum number of results per page. */
    perPage?: number | undefined;
}
export type ListResultItemType = "standard" | "enterprise";
export type ListResultItemLegacyFlagsEnterpriseZoneQuota = CreateResponseLegacyFlagsEnterpriseZoneQuota;
export type ListResultItemLegacyFlags = CreateResponseLegacyFlags;
export type ListResultItemManagedBy = CreateResponseManagedBy;
export type ListResultItemSettings = CreateResponseSettings;
export interface ListResultItem {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: ListResultItemType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: CreateResponseLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null | undefined;
    /** Account settings */
    settings?: CreateResponseSettings | null | undefined;
}
export type ListResultList = Array<ListResultItem>;
export interface ListAccountsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: ListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListEntitlementsRequest {
    /** Identifier tag. */
    accountId: string;
}
export type ListEntitlementsResultItemAllocationType = "bool" | "max_count" | "enum_number" | "range" | "string";
export type ListEntitlementsResultItemAllocationValueCase3List = Array<number>;
export interface ListEntitlementsResultItemAllocationValueCase4 {
    max: number;
    min: number;
}
export type ListEntitlementsResultItemAllocationValue = string | number | boolean | ListEntitlementsResultItemAllocationValueCase3List | ListEntitlementsResultItemAllocationValueCase4;
export interface ListEntitlementsResultItemAllocation {
    /** Allocation type discriminator. */
    type: ListEntitlementsResultItemAllocationType;
    /** Contains the allocation value whose concrete type the `type` field determines: bool yields a boolean, max_count yields an integer, enum_number yields an array of numbers, range yields an object with `min` and `max`, and string yields a string. */
    value: ListEntitlementsResultItemAllocationValue;
}
export interface ListEntitlementsResultItemFeature {
    /** Numeric identifier of the feature. */
    id: number;
    /** The logical grouping (set) this feature belongs to. */
    featureSet: string;
    /** Unique string key for the feature. */
    key: string;
    /** Human-readable name of the feature. */
    name: string;
}
export interface ListEntitlementsResultItem {
    /** Entitlement identifier -- equal to the feature key. */
    id: string;
    /** Represents the allocation value for an entitlement. The shape of `value` depends on `type`: `bool` uses a boolean, `max_count` uses an integer, `enum_number` uses an array of numbers, `range` uses an object with `min` and `max` integer fields, and `string` uses a string. */
    allocation: ListEntitlementsResultItemAllocation;
    /** ISO 8601 timestamp (microsecond precision, no timezone offset) when the entitlement was created. Format: `YYYY-MM-DDTHH:MM:SS.ffffff`. */
    createdDate: string;
    /** ISO 8601 timestamp when the entitlement was deleted, or empty string if not deleted. */
    deletedDate: string;
    /** ISO 8601 timestamp (microsecond precision, no timezone offset) when the entitlement was last edited. */
    editedDate: string;
    /** Describes a product feature associated with an entitlement. */
    feature: ListEntitlementsResultItemFeature;
}
export type ListEntitlementsResultList = Array<ListEntitlementsResultItem>;
export type ListEntitlementsResponse = ListEntitlementsResultList;
export type LogsAuditListRequestIdNotList = Array<string>;
export interface LogsAuditListRequestId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestIdNotList | undefined;
}
export type LogsAuditListRequestAccountNameNotList = Array<string>;
export interface LogsAuditListRequestAccountName {
    /** Filters out audit logs by the account name. */
    not?: LogsAuditListRequestAccountNameNotList | undefined;
}
export type LogsAuditListRequestActionResultNotItem = "success" | "failure";
export type LogsAuditListRequestActionResultNotList = Array<LogsAuditListRequestActionResultNotItem | (string & {})>;
export interface LogsAuditListRequestActionResult {
    /** Filters out audit logs by whether the action was successful or not. */
    not?: LogsAuditListRequestActionResultNotList | undefined;
}
export type LogsAuditListRequestActionTypeNotItem = "create" | "delete" | "view" | "update";
export type LogsAuditListRequestActionTypeNotList = Array<LogsAuditListRequestActionTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActionType {
    /** Filters out audit logs by the action type. */
    not?: LogsAuditListRequestActionTypeNotList | undefined;
}
export type LogsAuditListRequestActorContextNotItem = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListRequestActorContextNotList = Array<LogsAuditListRequestActorContextNotItem | (string & {})>;
export interface LogsAuditListRequestActorContext {
    /** Filters out audit logs by the actor context. */
    not?: LogsAuditListRequestActorContextNotList | undefined;
}
export type LogsAuditListRequestActorEmailNotList = Array<string>;
export interface LogsAuditListRequestActorEmail {
    /** Filters out audit logs by the actor's email address. */
    not?: LogsAuditListRequestActorEmailNotList | undefined;
}
export type LogsAuditListRequestActorIdNotList = Array<string>;
export interface LogsAuditListRequestActorId {
    /** Filters out audit logs by the actor ID. This can be either the Account ID or User ID. */
    not?: LogsAuditListRequestActorIdNotList | undefined;
}
export type LogsAuditListRequestActorIpAddressNotList = Array<string>;
export interface LogsAuditListRequestActorIpAddress {
    /** Filters out audit logs IP address where the action was initiated. */
    not?: LogsAuditListRequestActorIpAddressNotList | undefined;
}
export type LogsAuditListRequestActorTokenIdNotList = Array<string>;
export interface LogsAuditListRequestActorTokenId {
    /** Filters out audit logs by the API token ID when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenIdNotList | undefined;
}
export type LogsAuditListRequestActorTokenNameNotList = Array<string>;
export interface LogsAuditListRequestActorTokenName {
    /** Filters out audit logs by the API token name when the actor context is an api_token or oauth. */
    not?: LogsAuditListRequestActorTokenNameNotList | undefined;
}
export type LogsAuditListRequestActorTypeNotItem = "account" | "cloudflare_admin" | "delegated_service" | "system" | "user";
export type LogsAuditListRequestActorTypeNotList = Array<LogsAuditListRequestActorTypeNotItem | (string & {})>;
export interface LogsAuditListRequestActorType {
    /** Filters out audit logs by the actor type. */
    not?: LogsAuditListRequestActorTypeNotList | undefined;
}
export type LogsAuditListRequestAuditLogIdNotList = Array<string>;
export interface LogsAuditListRequestAuditLogId {
    /** Filters out audit logs by their IDs. */
    not?: LogsAuditListRequestAuditLogIdNotList | undefined;
}
export type LogsAuditListRequestDirection = "desc" | "asc";
export type LogsAuditListRequestProductCategoryList = Array<string>;
export type LogsAuditListRequestRawCfRayIdNotList = Array<string>;
export interface LogsAuditListRequestRawCfRayId {
    /** Filters out audit logs by the response CF Ray ID. */
    not?: LogsAuditListRequestRawCfRayIdNotList | undefined;
}
export type LogsAuditListRequestRawMethodNotList = Array<string>;
export interface LogsAuditListRequestRawMethod {
    /** Filters out audit logs by the HTTP method for the API call. */
    not?: LogsAuditListRequestRawMethodNotList | undefined;
}
export type LogsAuditListRequestRawStatusCodeNotList = Array<number>;
export interface LogsAuditListRequestRawStatusCode {
    /** Filters out audit logs by the response status code that was returned. */
    not?: LogsAuditListRequestRawStatusCodeNotList | undefined;
}
export type LogsAuditListRequestRawUriNotList = Array<string>;
export interface LogsAuditListRequestRawUri {
    /** Filters out audit logs by the request URI. */
    not?: LogsAuditListRequestRawUriNotList | undefined;
}
export type LogsAuditListRequestResourceIdNotList = Array<string>;
export interface LogsAuditListRequestResourceId {
    /** Filters out audit logs by the resource ID. */
    not?: LogsAuditListRequestResourceIdNotList | undefined;
}
export type LogsAuditListRequestResourceProductNotList = Array<string>;
export interface LogsAuditListRequestResourceProduct {
    /** Filters out audit logs by the Cloudflare product associated with the changed resource. */
    not?: LogsAuditListRequestResourceProductNotList | undefined;
}
export type LogsAuditListRequestResourceScopeNotItem = "accounts" | "user" | "zones" | "memberships";
export type LogsAuditListRequestResourceScopeNotList = Array<LogsAuditListRequestResourceScopeNotItem | (string & {})>;
export interface LogsAuditListRequestResourceScope {
    /** Filters out audit logs by the resource scope, specifying whether the resource is associated with an user, an account, a zone, or a membership. */
    not?: LogsAuditListRequestResourceScopeNotList | undefined;
}
export type LogsAuditListRequestResourceTypeNotList = Array<string>;
export interface LogsAuditListRequestResourceType {
    /** Filters out audit logs based on the unique type of resource changed by the action. */
    not?: LogsAuditListRequestResourceTypeNotList | undefined;
}
export type LogsAuditListRequestZoneIdNotList = Array<string>;
export interface LogsAuditListRequestZoneId {
    /** Filters out audit logs by the zone ID. */
    not?: LogsAuditListRequestZoneIdNotList | undefined;
}
export type LogsAuditListRequestZoneNameNotList = Array<string>;
export interface LogsAuditListRequestZoneName {
    /** Filters out audit logs by the zone name associated with the change. */
    not?: LogsAuditListRequestZoneNameNotList | undefined;
}
export interface ListLogAuditsRequest {
    /** The unique id that identifies the account. */
    accountId: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    id?: LogsAuditListRequestId | undefined;
    accountName?: LogsAuditListRequestAccountName | undefined;
    actionResult?: LogsAuditListRequestActionResult | undefined;
    actionType?: LogsAuditListRequestActionType | undefined;
    actorContext?: LogsAuditListRequestActorContext | undefined;
    actorEmail?: LogsAuditListRequestActorEmail | undefined;
    actorId?: LogsAuditListRequestActorId | undefined;
    actorIpAddress?: LogsAuditListRequestActorIpAddress | undefined;
    actorTokenId?: LogsAuditListRequestActorTokenId | undefined;
    actorTokenName?: LogsAuditListRequestActorTokenName | undefined;
    actorType?: LogsAuditListRequestActorType | undefined;
    auditLogId?: LogsAuditListRequestAuditLogId | undefined;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string | undefined;
    /** Sets sorting order. */
    direction?: LogsAuditListRequestDirection | (string & {}) | undefined;
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number | undefined;
    /** Filters audit logs by one or more predefined product categories. Each product category expands into a curated set of resource_product values and is unioned with any explicit resource_product filter. Matched case-insensitively; unknown product categories return 400. Repeatable. Use the audit log product categories endpoint to discover the available values. */
    productCategory?: LogsAuditListRequestProductCategoryList | undefined;
    rawCfRayId?: LogsAuditListRequestRawCfRayId | undefined;
    rawMethod?: LogsAuditListRequestRawMethod | undefined;
    rawStatusCode?: LogsAuditListRequestRawStatusCode | undefined;
    rawUri?: LogsAuditListRequestRawUri | undefined;
    resourceId?: LogsAuditListRequestResourceId | undefined;
    resourceProduct?: LogsAuditListRequestResourceProduct | undefined;
    resourceScope?: LogsAuditListRequestResourceScope | undefined;
    resourceType?: LogsAuditListRequestResourceType | undefined;
    zoneId?: LogsAuditListRequestZoneId | undefined;
    zoneName?: LogsAuditListRequestZoneName | undefined;
}
export interface LogsAuditListResultItemAccount {
    /** A unique identifier for the account. */
    id?: string | null | undefined;
    /** A string that identifies the account name. */
    name?: string | null | undefined;
}
export interface LogsAuditListResultItemAction {
    /** A short description of the action performed. */
    description?: string | null | undefined;
    /** The result of the action, indicating success or failure. */
    result?: string | null | undefined;
    /** A timestamp indicating when the action was logged. */
    time?: string | null | undefined;
    /** A short string that describes the action that was performed. */
    type?: string | null | undefined;
}
export type LogsAuditListResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditListResultItemActorType = "account" | "cloudflare_admin" | "delegated_service" | "system" | "user";
export interface LogsAuditListResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null | undefined;
    /** The context in which the action was initiated. */
    context?: LogsAuditListResultItemActorContext | null | undefined;
    /** The email of the actor who performed the action. */
    email?: string | null | undefined;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null | undefined;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null | undefined;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null | undefined;
    /** The type of actor. */
    type?: LogsAuditListResultItemActorType | null | undefined;
}
export interface LogsAuditListResultItemRaw {
    /** The Cloudflare Ray ID for the request. */
    cfRayId?: string | null | undefined;
    /** The HTTP method of the request. */
    method?: string | null | undefined;
    /** The HTTP response status code returned by the API. */
    statusCode?: number | null | undefined;
    /** The URI of the request. */
    uri?: string | null | undefined;
    /** The client's user agent string sent with the request. */
    userAgent?: string | null | undefined;
}
export interface LogsAuditListResultItemResource {
    /** The unique identifier for the affected resource. */
    id?: string | null | undefined;
    /** The Cloudflare product associated with the resource. */
    product?: string | null | undefined;
    request?: unknown | null | undefined;
    response?: unknown | null | undefined;
    /** The scope of the resource. */
    scope?: unknown | null | undefined;
    /** The type of the resource. */
    type?: string | null | undefined;
}
export interface LogsAuditListResultItemZone {
    /** A string that identifies the zone id. */
    id?: string | null | undefined;
    /** A string that identifies the zone name. */
    name?: string | null | undefined;
}
export interface LogsAuditListResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null | undefined;
    /** Contains account related information. */
    account?: LogsAuditListResultItemAccount | null | undefined;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null | undefined;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditListResultItemActor | null | undefined;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null | undefined;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null | undefined;
    /** Provides details about the zone affected by the action. */
    zone?: LogsAuditListResultItemZone | null | undefined;
}
export type LogsAuditListResultList = Array<LogsAuditListResultItem>;
export interface ListLogAuditsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: LogsAuditListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type MembersListRequestDirection = "asc" | "desc";
export type MembersListRequestOrder = "user.first_name" | "user.last_name" | "user.email" | "status";
export type MembersListRequestStatus = "accepted" | "pending" | "rejected";
export interface ListMembersRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Direction to order results. */
    direction?: MembersListRequestDirection | (string & {}) | undefined;
    /** Field to order results by. */
    order?: MembersListRequestOrder | (string & {}) | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Maximum number of results per page. */
    perPage?: number | undefined;
    /** A member's status in the account. */
    status?: MembersListRequestStatus | (string & {}) | undefined;
}
export type MembersListResultItemPoliciesItemAccess = "allow" | "deny";
export type MembersListResultItemPoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type MembersListResultItemPoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type MembersListResultItemPoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type MembersListResultItemPoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersListResultItemPoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersListResultItemPoliciesItemResourceGroupsItemScopeObjectsList;
}
export type MembersListResultItemPoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemResourceGroupsItemMeta;
export interface MembersListResultItemPoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersListResultItemPoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null | undefined;
    /** Name of the resource group. */
    name?: string | null | undefined;
}
export type MembersListResultItemPoliciesItemResourceGroupsList = Array<MembersListResultItemPoliciesItemResourceGroupsItem>;
export interface MembersListResultItemPoliciesItem {
    /** Policy identifier. */
    id?: string | null | undefined;
    /** Allow or deny operations against the resources. */
    access?: MembersListResultItemPoliciesItemAccess | null | undefined;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersListResultItemPoliciesItemPermissionGroupsList | null | undefined;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersListResultItemPoliciesItemResourceGroupsList | null | undefined;
}
export type MembersListResultItemPoliciesList = Array<MembersListResultItemPoliciesItem>;
export type MembersListResultItemRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersListResultItemRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export type MembersListResultItemRolesItem = MembersCreateResponseRolesItem;
export type MembersListResultItemRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersListResultItemStatus = "accepted" | "pending";
export type MembersListResultItemUser = MembersCreateResponseUser;
export interface MembersListResultItem {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    /** The contact email address of the user. */
    email?: string | null | undefined;
    /** Access policy for the membership */
    policies?: MembersListResultItemPoliciesList | null | undefined;
    /** Roles assigned to this Member. */
    roles?: MembersListResultItemRolesList | null | undefined;
    /** A member's status in the account. */
    status?: MembersListResultItemStatus | null | undefined;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null | undefined;
}
export type MembersListResultList = Array<MembersListResultItem>;
export interface ListMembersResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: MembersListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListPaymentMethodsRequest {
    /** Identifier */
    accountId: string;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of items per page. */
    perPage?: number | undefined;
}
export type ListPaymentMethodsResultItemType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
export interface ListPaymentMethodsResultItem {
    /** Payment method identifier. */
    id?: string | null | undefined;
    /** Billing address line 1. */
    address?: string | null | undefined;
    /** Billing address line 2. */
    address2?: string | null | undefined;
    /** Bank account type. */
    bankAccountType?: string | null | undefined;
    /** Bank code. */
    bankCode?: string | null | undefined;
    /** Bank country. */
    bankCountry?: string | null | undefined;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null | undefined;
    /** Bank routing number. */
    bankRoutingNumber?: string | null | undefined;
    /** Cash App cash tag. */
    cashappCashTag?: string | null | undefined;
    /** Billing city. */
    city?: string | null | undefined;
    /** Billing country. */
    country?: string | null | undefined;
    /** Whether this is the default payment method. */
    default?: boolean | null | undefined;
    /** Device data for fraud prevention. */
    deviceData?: string | null | undefined;
    /** Card expiration date. */
    expirationDate?: string | null | undefined;
    /** Billing first name. */
    firstName?: string | null | undefined;
    /** Last four digits of the card number. */
    lastFour?: string | null | undefined;
    /** Billing last name. */
    lastName?: string | null | undefined;
    /** A nickname for the payment method. */
    nickName?: string | null | undefined;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null | undefined;
    /** Payment email address. */
    paymentEmail?: string | null | undefined;
    /** The payment gateway used. */
    paymentGateway?: string | null | undefined;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null | undefined;
    /** Billing state. */
    state?: string | null | undefined;
    /** The payment method type. */
    type?: ListPaymentMethodsResultItemType | null | undefined;
    /** Billing zip code. */
    zipcode?: string | null | undefined;
}
export type ListPaymentMethodsResultList = Array<ListPaymentMethodsResultItem>;
export type ListPaymentMethodsResponse = ListPaymentMethodsResultList;
export interface ListRolesRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Number of roles per page. */
    perPage?: number | undefined;
}
export type RolesListResultItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type RolesListResultItemPermissions = MembersCreateResponseRolesItemPermissions;
export type RolesListResultItem = MembersCreateResponseRolesItem;
export type RolesListResultList = Array<MembersCreateResponseRolesItem>;
export interface ListRolesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RolesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type TokensListRequestDirection = "asc" | "desc";
export interface ListTokensRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Direction to order results. */
    direction?: TokensListRequestDirection | (string & {}) | undefined;
    /** When true, includes recently-expired tokens in the response. */
    includeExpired?: boolean | undefined;
    /** Page number of paginated results. */
    page?: number | undefined;
    /** Maximum number of results per page. */
    perPage?: number | undefined;
}
export type TokensListResultItemConditionRequestIpInList = Array<string>;
export type TokensListResultItemConditionRequestIpNotInList = Array<string>;
export interface TokensListResultItemConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensListResultItemConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensListResultItemConditionRequestIpNotInList | null | undefined;
}
export interface TokensListResultItemCondition {
    /** Client IP restrictions. */
    requestIp?: TokensListResultItemConditionRequestIp | null | undefined;
}
export type TokensListResultItemPoliciesItemEffect = "allow" | "deny";
export type TokensListResultItemPoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensListResultItemPoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensListResultItemPoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensListResultItemPoliciesItemResourcesValue = string | TokensListResultItemPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensListResultItemPoliciesItemResourcesMap = {
    [key: string]: TokensListResultItemPoliciesItemResourcesValue | undefined;
};
export interface TokensListResultItemPoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensListResultItemPoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensListResultItemPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensListResultItemPoliciesItemResourcesMap;
}
export type TokensListResultItemPoliciesList = Array<TokensListResultItemPoliciesItem>;
export type TokensListResultItemStatus = "active" | "disabled" | "expired";
export interface TokensListResultItem {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensListResultItemCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensListResultItemPoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensListResultItemStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
}
export type TokensListResultList = Array<TokensListResultItem>;
export interface ListTokensResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: TokensListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface ListTokensPermissionGroupsRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Filter by the name of the permission group. The value must be URL-encoded. */
    name?: string | undefined;
    /** Filter by the scope of the permission group. The value must be URL-encoded. */
    scope?: string | undefined;
}
export type ListTokensPermissionGroupsResultItemCategory = "developer_platform" | "ai_and_machine_learning" | "dns_and_zones" | "app_security" | "rules_and_configuration" | "cloudflare_one_and_zero_trust" | "analytics_and_logs" | "network_services" | "media" | "email_and_messaging" | "cache_and_performance" | "account_and_billing" | "other";
export type ListTokensPermissionGroupsResultItemScopesItem = "com.cloudflare.api.account" | "com.cloudflare.api.account.zone" | "com.cloudflare.api.user" | "com.cloudflare.edge.r2.bucket";
export type ListTokensPermissionGroupsResultItemScopesList = Array<ListTokensPermissionGroupsResultItemScopesItem>;
export interface ListTokensPermissionGroupsResultItem {
    /** Public ID. */
    id?: string | null | undefined;
    /** Product category that this permission group belongs to. */
    category?: ListTokensPermissionGroupsResultItemCategory | null | undefined;
    /** Whether the caller can select this permission group when creating a token. */
    isSelectable?: boolean | null | undefined;
    /** Permission Group Name */
    name?: string | null | undefined;
    /** Resources to which the Permission Group is scoped */
    scopes?: ListTokensPermissionGroupsResultItemScopesList | null | undefined;
}
export type ListTokensPermissionGroupsResultList = Array<ListTokensPermissionGroupsResultItem>;
export type ListTokensPermissionGroupsResponse = ListTokensPermissionGroupsResultList;
export type LogsAuditHistoryRequestDirection = "desc" | "asc";
export interface LogsAuditHistoryRequest {
    /** The unique ID that identifies the account. */
    accountId: string;
    /** The ID of the audit log to fetch resource history for. */
    id: string;
    /** RFC3339 timestamp of the source audit log entry's action time. Used to narrow the source-entry lookup window. Provide the `action.time` value from the audit log identified by `id`. */
    actionTime: string;
    /** Limits the returned results to logs older than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    before: string;
    /** Limits the returned results to logs newer than the specified date. This can be a date string 2019-04-30 (interpreted in UTC) or an absolute timestamp that conforms to RFC3339. */
    since: string;
    /** The cursor is an opaque token used to paginate through large sets of records. It indicates the position from which to continue when requesting the next set of records. A valid cursor value can be obtained from the cursor object in the result_info structure of a previous response. */
    cursor?: string | undefined;
    /** Sets sorting order. */
    direction?: LogsAuditHistoryRequestDirection | (string & {}) | undefined;
    /** The number limits the objects to return. The cursor attribute may be used to iterate over the next batch of objects if there are more than the limit. */
    limit?: number | undefined;
}
export type LogsAuditHistoryResultItemAccount = LogsAuditListResultItemAccount;
export type LogsAuditHistoryResultItemAction = LogsAuditListResultItemAction;
export type LogsAuditHistoryResultItemActorContext = "api" | "api_key" | "api_token" | "dash" | "oauth" | "origin_ca_key";
export type LogsAuditHistoryResultItemActorType = "account" | "cloudflare_admin" | "delegated_service" | "system" | "user";
export interface LogsAuditHistoryResultItemActor {
    /** The ID of the actor who performed the action. If a user performed the action, this will be their User ID. */
    id?: string | null | undefined;
    /** The context in which the action was initiated. */
    context?: LogsAuditHistoryResultItemActorContext | null | undefined;
    /** The email of the actor who performed the action. */
    email?: string | null | undefined;
    /** The IP address of the request that performed the action. */
    ipAddress?: string | null | undefined;
    /** The API token ID when the actor context is an api_token or oauth. */
    tokenId?: string | null | undefined;
    /** The API token name when the actor context is an api_token or oauth. */
    tokenName?: string | null | undefined;
    /** The type of actor. */
    type?: LogsAuditHistoryResultItemActorType | null | undefined;
}
export type LogsAuditHistoryResultItemRaw = LogsAuditListResultItemRaw;
export type LogsAuditHistoryResultItemResource = LogsAuditListResultItemResource;
export type LogsAuditHistoryResultItemZone = LogsAuditListResultItemZone;
export interface LogsAuditHistoryResultItem {
    /** A unique identifier for the audit log entry. */
    id?: string | null | undefined;
    /** Contains account related information. */
    account?: LogsAuditListResultItemAccount | null | undefined;
    /** Provides information about the action performed. */
    action?: LogsAuditListResultItemAction | null | undefined;
    /** Provides details about the actor who performed the action. */
    actor?: LogsAuditHistoryResultItemActor | null | undefined;
    /** Provides raw information about the request and response. */
    raw?: LogsAuditListResultItemRaw | null | undefined;
    /** Provides details about the affected resource. */
    resource?: LogsAuditListResultItemResource | null | undefined;
    /** Provides details about the zone affected by the action. */
    zone?: LogsAuditListResultItemZone | null | undefined;
}
export type LogsAuditHistoryResultList = Array<LogsAuditHistoryResultItem>;
export type LogsAuditHistoryResponse = LogsAuditHistoryResultList;
export interface LogsAuditProductCategoriesRequest {
    /** The unique id that identifies the account. */
    accountId: string;
}
export interface LogsAuditProductCategoriesResultItemProductsItem {
    /** A human-readable label for the product. */
    label?: string | null | undefined;
    /** The resource_product value that the product category expands to. */
    value?: string | null | undefined;
}
export type LogsAuditProductCategoriesResultItemProductsList = Array<LogsAuditProductCategoriesResultItemProductsItem>;
export interface LogsAuditProductCategoriesResultItem {
    /** A human-readable label for the product category. */
    label?: string | null | undefined;
    /** The resource products that the product category expands to. */
    products?: LogsAuditProductCategoriesResultItemProductsList | null | undefined;
    /** The product category identifier used with the product_category filter. */
    value?: string | null | undefined;
}
export type LogsAuditProductCategoriesResultList = Array<LogsAuditProductCategoriesResultItem>;
export type LogsAuditProductCategoriesResponse = LogsAuditProductCategoriesResultList;
export interface PaymentMethodsSetAsDefaultRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
}
export type PaymentMethodsSetAsDefaultResponse = unknown;
export interface PutTokenValueRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
}
export type PutTokenValueResponse = unknown;
export interface ReceiptsPdfRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    receiptId: string;
    /** The document type to generate. */
    doctype?: string | undefined;
}
export interface ReceiptsPdfResponse {
}
export type SubscriptionsActionsAppendRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsActionsAppendRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsActionsAppendRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsActionsAppendRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsActionsAppendRequestRatePlanId | (string & {}) | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | undefined;
    /** The full name of the rate plan. */
    publicName?: string | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsActionsAppendRequestRatePlanSetsList | undefined;
}
export interface SubscriptionsActionsAppendRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsActionsAppendRequestFrequency | (string & {}) | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsActionsAppendRequestRatePlan | undefined;
}
export type SubscriptionsActionsAppendResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsActionsAppendResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsActionsAppendResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsActionsAppendResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsActionsAppendResponseRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsActionsAppendResponseRatePlanSetsList | null | undefined;
}
export type SubscriptionsActionsAppendResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsActionsAppendResponse {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsActionsAppendResponseFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsActionsAppendResponseRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsActionsAppendResponseState | null | undefined;
}
export type SubscriptionsBulkCreateRequestSubscriptionsItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanSetsList = Array<string>;
export interface SubscriptionsBulkCreateRequestSubscriptionsItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanId | (string & {}) | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | undefined;
    /** The full name of the rate plan. */
    publicName?: string | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsBulkCreateRequestSubscriptionsItemRatePlanSetsList | undefined;
}
export type SubscriptionsBulkCreateRequestSubscriptionsItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsBulkCreateRequestSubscriptionsItem {
    /** Subscription identifier tag. */
    id?: string | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsBulkCreateRequestSubscriptionsItemFrequency | (string & {}) | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsBulkCreateRequestSubscriptionsItemRatePlan | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsBulkCreateRequestSubscriptionsItemState | (string & {}) | undefined;
}
export type SubscriptionsBulkCreateRequestSubscriptionsList = Array<SubscriptionsBulkCreateRequestSubscriptionsItem>;
export interface SubscriptionsBulkCreateRequest {
    /** Identifier */
    accountId: string;
    idempKey?: string | undefined;
    couponCode?: string | undefined;
    paymentHoldId?: number | undefined;
    subscriptions?: SubscriptionsBulkCreateRequestSubscriptionsList | undefined;
    userIsOnSession?: boolean | undefined;
}
export type SubscriptionsBulkCreateResponseClientSecretsList = Array<string>;
export type SubscriptionsBulkCreateResponseSubscriptionsItemFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsBulkCreateResponseSubscriptionsItemRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsBulkCreateResponseSubscriptionsItemRatePlanSetsList = Array<string>;
export interface SubscriptionsBulkCreateResponseSubscriptionsItemRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsBulkCreateResponseSubscriptionsItemRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsBulkCreateResponseSubscriptionsItemRatePlanSetsList | null | undefined;
}
export type SubscriptionsBulkCreateResponseSubscriptionsItemState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
export interface SubscriptionsBulkCreateResponseSubscriptionsItem {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsBulkCreateResponseSubscriptionsItemFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsBulkCreateResponseSubscriptionsItemRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsBulkCreateResponseSubscriptionsItemState | null | undefined;
}
export type SubscriptionsBulkCreateResponseSubscriptionsList = Array<SubscriptionsBulkCreateResponseSubscriptionsItem>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsBulkCreateResponse {
    clientSecrets?: SubscriptionsBulkCreateResponseClientSecretsList | null | undefined;
    subscriptions?: SubscriptionsBulkCreateResponseSubscriptionsList | null | undefined;
}
export type SubscriptionsCancelDowngradeRequestSubscriptionIdsList = Array<string>;
export interface SubscriptionsCancelDowngradeRequest {
    /** Identifier */
    accountId: string;
    /** List of subscription identifiers to cancel downgrades for. */
    subscriptionIds?: SubscriptionsCancelDowngradeRequestSubscriptionIdsList | undefined;
}
export type SubscriptionsCancelDowngradeResponse = unknown;
export type SubscriptionsCancelReasonCreateRequestReasonCodeList = Array<string>;
export interface SubscriptionsCancelReasonCreateRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** Additional cancellation details. */
    other?: string | undefined;
    /** The cancellation reason codes. */
    reasonCode?: SubscriptionsCancelReasonCreateRequestReasonCodeList | undefined;
}
export type SubscriptionsCancelReasonCreateResponseReasonCodeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsCancelReasonCreateResponse {
    /** The cancel reason identifier. */
    id?: string | null | undefined;
    /** Additional cancellation details. */
    other?: string | null | undefined;
    /** The cancellation reason codes. */
    reasonCode?: SubscriptionsCancelReasonCreateResponseReasonCodeList | null | undefined;
    /** When the cancel reason was submitted. */
    submitted?: string | null | undefined;
    /** The subscription identifier. */
    subscriptionId?: string | null | undefined;
}
export interface SubscriptionsCancelReasonGetRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
export type SubscriptionsCancelReasonGetResponseReasonCodeList = Array<string>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsCancelReasonGetResponse {
    /** The cancel reason identifier. */
    id?: string | null | undefined;
    /** Additional cancellation details. */
    other?: string | null | undefined;
    /** The cancellation reason codes. */
    reasonCode?: SubscriptionsCancelReasonGetResponseReasonCodeList | null | undefined;
    /** When the cancel reason was submitted. */
    submitted?: string | null | undefined;
    /** The subscription identifier. */
    subscriptionId?: string | null | undefined;
}
export interface SubscriptionsGetByIdentifierRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
}
export type SubscriptionsGetByIdentifierResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsGetByIdentifierResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsGetByIdentifierResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsGetByIdentifierResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsGetByIdentifierResponseRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsGetByIdentifierResponseRatePlanSetsList | null | undefined;
}
export type SubscriptionsGetByIdentifierResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface SubscriptionsGetByIdentifierResponse {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsGetByIdentifierResponseFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsGetByIdentifierResponseRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsGetByIdentifierResponseState | null | undefined;
}
export interface UpdateRequestManagedBy {
    /** ID of the parent Organization, if one exists */
    parentOrgId?: string | undefined;
    /** Name of the parent Organization, if one exists */
    parentOrgName?: string | undefined;
    /** ID of the root Organization, if one exists */
    rootOrgId?: string | undefined;
    /** Indicates whether the parent Organization hierarchy should be displayed */
    shouldDisplayParentOrgs?: boolean | undefined;
}
export interface UpdateRequestSettings {
    /** Sets an abuse contact email to notify for abuse reports. */
    abuseContactEmail?: string | undefined;
    /** Indicates whether membership in this account requires that Two-Factor Authentication is enabled */
    enforceTwofactor?: boolean | undefined;
}
export interface UpdateAccountRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Identifier */
    id: string;
    /** Account name, limited to 65 UTF-8 bytes. */
    name: string;
    /** Parent container details */
    managedBy?: UpdateRequestManagedBy | undefined;
    /** Account settings */
    settings?: UpdateRequestSettings | undefined;
}
export type UpdateResponseType = "standard" | "enterprise";
export type UpdateResponseLegacyFlagsEnterpriseZoneQuota = CreateResponseLegacyFlagsEnterpriseZoneQuota;
export type UpdateResponseLegacyFlags = CreateResponseLegacyFlags;
export type UpdateResponseManagedBy = CreateResponseManagedBy;
export type UpdateResponseSettings = CreateResponseSettings;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateAccountResponse {
    /** Identifier */
    id: string;
    /** Account name */
    name: string;
    type: UpdateResponseType;
    /** Timestamp for the creation of the account */
    createdOn?: string | null | undefined;
    /** Legacy account flags. */
    legacyFlags?: CreateResponseLegacyFlags | null | undefined;
    /** Parent container details */
    managedBy?: CreateResponseManagedBy | null | undefined;
    /** Account settings */
    settings?: CreateResponseSettings | null | undefined;
}
export interface UpdateAccountProfileRequest {
    accountId: string;
    businessAddress?: string | undefined;
    businessEmail?: string | undefined;
    businessName?: string | undefined;
    businessPhone?: string | undefined;
    externalMetadata?: string | undefined;
}
export interface UpdateAccountProfileResponse {
}
export interface MembersUpdateRequestRolesItemPermissionsAnalytics {
    read?: boolean | undefined;
    write?: boolean | undefined;
}
export type MembersUpdateRequestRolesItemPermissionsBilling = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsCachePurge = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsDns = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsDnsRecords = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsLb = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsLogs = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsOrganization = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsSsl = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsWaf = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsZoneSettings = MembersUpdateRequestRolesItemPermissionsAnalytics;
export type MembersUpdateRequestRolesItemPermissionsZones = MembersUpdateRequestRolesItemPermissionsAnalytics;
export interface MembersUpdateRequestRolesItemPermissions {
    analytics?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    billing?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    cachePurge?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    dns?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    dnsRecords?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    lb?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    logs?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    organization?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    ssl?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    waf?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    zoneSettings?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
    zones?: MembersUpdateRequestRolesItemPermissionsAnalytics | undefined;
}
export interface MembersUpdateRequestRolesItem {
    /** Role identifier tag. */
    id: string;
    /** Description of role's permissions. */
    description?: string | undefined;
    /** Role name. */
    name?: string | undefined;
    permissions?: MembersUpdateRequestRolesItemPermissions | undefined;
}
export type MembersUpdateRequestRolesList = Array<MembersUpdateRequestRolesItem>;
export type MembersUpdateRequestStatus = "accepted" | "pending";
export interface MembersUpdateRequestUser {
    /** The contact email address of the user. */
    email: string;
    /** Identifier */
    id?: string | undefined;
    /** User's first name */
    firstName?: string | undefined;
    /** User's last name */
    lastName?: string | undefined;
    /** Indicates whether two-factor authentication is enabled for the user account. Does not apply to API authentication. */
    twoFactorAuthenticationEnabled?: boolean | undefined;
}
export type MembersUpdateRequestPoliciesItemAccess = "allow" | "deny";
export type MembersUpdateRequestPoliciesItemPermissionGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export type MembersUpdateRequestPoliciesItemPermissionGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export type MembersUpdateRequestPoliciesItemResourceGroupsItem = MembersCreateRequestPoliciesItemPermissionGroupsItem;
export type MembersUpdateRequestPoliciesItemResourceGroupsList = Array<MembersCreateRequestPoliciesItemPermissionGroupsItem>;
export interface MembersUpdateRequestPoliciesItem {
    /** Policy identifier. */
    id?: string | undefined;
    /** Allow or deny operations against the resources. */
    access: MembersUpdateRequestPoliciesItemAccess | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: MembersUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource groups that the policy applies to. */
    resourceGroups: MembersUpdateRequestPoliciesItemResourceGroupsList;
}
export type MembersUpdateRequestPoliciesList = Array<MembersUpdateRequestPoliciesItem>;
export interface UpdateMemberRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Membership identifier tag. */
    memberId: string;
    /** Membership identifier tag. */
    id?: string | undefined;
    /** Roles assigned to this member. */
    roles?: MembersUpdateRequestRolesList | undefined;
    /** A member's status in the account. */
    status?: MembersUpdateRequestStatus | (string & {}) | undefined;
    /** Details of the user associated to the membership. */
    user?: MembersUpdateRequestUser | undefined;
    /** Array of policies associated with this member. */
    policies?: MembersUpdateRequestPoliciesList | undefined;
}
export type MembersUpdateResponsePoliciesItemAccess = "allow" | "deny";
export type MembersUpdateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type MembersUpdateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type MembersUpdateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsItem = MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem;
export type MembersUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList = Array<MembersCreateResponsePoliciesItemResourceGroupsItemScopeObjectsItem>;
export interface MembersUpdateResponsePoliciesItemResourceGroupsItemScope {
    /** This is a combination of pre-defined resource name and identifier (like Account ID etc.) */
    key: string;
    /** A list of scope objects for additional context. */
    objects: MembersUpdateResponsePoliciesItemResourceGroupsItemScopeObjectsList;
}
export type MembersUpdateResponsePoliciesItemResourceGroupsItemMeta = MembersCreateResponsePoliciesItemResourceGroupsItemMeta;
export interface MembersUpdateResponsePoliciesItemResourceGroupsItem {
    /** Identifier of the resource group. */
    id: string;
    /** The scope associated to the resource group */
    scope: MembersUpdateResponsePoliciesItemResourceGroupsItemScope;
    /** Attributes associated to the resource group. */
    meta?: MembersCreateResponsePoliciesItemResourceGroupsItemMeta | null | undefined;
    /** Name of the resource group. */
    name?: string | null | undefined;
}
export type MembersUpdateResponsePoliciesItemResourceGroupsList = Array<MembersUpdateResponsePoliciesItemResourceGroupsItem>;
export interface MembersUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id?: string | null | undefined;
    /** Allow or deny operations against the resources. */
    access?: MembersUpdateResponsePoliciesItemAccess | null | undefined;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups?: MembersUpdateResponsePoliciesItemPermissionGroupsList | null | undefined;
    /** A list of resource groups that the policy applies to. */
    resourceGroups?: MembersUpdateResponsePoliciesItemResourceGroupsList | null | undefined;
}
export type MembersUpdateResponsePoliciesList = Array<MembersUpdateResponsePoliciesItem>;
export type MembersUpdateResponseRolesItemPermissionsAnalytics = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsBilling = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsCachePurge = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsDns = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsDnsRecords = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsLb = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsLogs = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsOrganization = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsSsl = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsWaf = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsZoneSettings = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissionsZones = MembersCreateResponseRolesItemPermissionsAnalytics;
export type MembersUpdateResponseRolesItemPermissions = MembersCreateResponseRolesItemPermissions;
export type MembersUpdateResponseRolesItem = MembersCreateResponseRolesItem;
export type MembersUpdateResponseRolesList = Array<MembersCreateResponseRolesItem>;
export type MembersUpdateResponseStatus = "accepted" | "pending";
export type MembersUpdateResponseUser = MembersCreateResponseUser;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateMemberResponse {
    /** Membership identifier tag. */
    id?: string | null | undefined;
    /** The contact email address of the user. */
    email?: string | null | undefined;
    /** Access policy for the membership */
    policies?: MembersUpdateResponsePoliciesList | null | undefined;
    /** Roles assigned to this Member. */
    roles?: MembersUpdateResponseRolesList | null | undefined;
    /** A member's status in the account. */
    status?: MembersUpdateResponseStatus | null | undefined;
    /** Details of the user associated to the membership. */
    user?: MembersCreateResponseUser | null | undefined;
}
export type UpdatePaymentMethodRequestType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
export interface UpdatePaymentMethodRequest {
    /** Identifier */
    accountId: string;
    /** Identifier */
    paymentMethodId: string;
    /** Billing address line 1. */
    address?: string | undefined;
    /** Billing address line 2. */
    address2?: string | undefined;
    /** Bank account type. */
    bankAccountType?: string | undefined;
    /** Bank code. */
    bankCode?: string | undefined;
    /** Bank country. */
    bankCountry?: string | undefined;
    /** Bank name for bank-based payment methods. */
    bankName?: string | undefined;
    /** Bank routing number. */
    bankRoutingNumber?: string | undefined;
    /** Cash App cash tag. */
    cashappCashTag?: string | undefined;
    /** Billing city. */
    city?: string | undefined;
    /** Billing country. */
    country?: string | undefined;
    /** Whether this is the default payment method. */
    default?: boolean | undefined;
    /** Device data for fraud prevention. */
    deviceData?: string | undefined;
    /** Billing first name. */
    firstName?: string | undefined;
    /** Billing last name. */
    lastName?: string | undefined;
    /** A nickname for the payment method. */
    nickName?: string | undefined;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | undefined;
    /** Payment email address. */
    paymentEmail?: string | undefined;
    /** The payment gateway used. */
    paymentGateway?: string | undefined;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | undefined;
    /** Billing state. */
    state?: string | undefined;
    /** The payment method type. */
    type?: UpdatePaymentMethodRequestType | (string & {}) | undefined;
    /** Billing zip code. */
    zipcode?: string | undefined;
}
export type UpdatePaymentMethodResponseType = "CREDIT_CARD" | "PAYPAL" | "CASHAPP" | "SEPA_DEBIT" | "LINK" | "ACH_DIRECT_DEBIT";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdatePaymentMethodResponse {
    /** Payment method identifier. */
    id?: string | null | undefined;
    /** Billing address line 1. */
    address?: string | null | undefined;
    /** Billing address line 2. */
    address2?: string | null | undefined;
    /** Bank account type. */
    bankAccountType?: string | null | undefined;
    /** Bank code. */
    bankCode?: string | null | undefined;
    /** Bank country. */
    bankCountry?: string | null | undefined;
    /** Bank name for bank-based payment methods. */
    bankName?: string | null | undefined;
    /** Bank routing number. */
    bankRoutingNumber?: string | null | undefined;
    /** Cash App cash tag. */
    cashappCashTag?: string | null | undefined;
    /** Billing city. */
    city?: string | null | undefined;
    /** Billing country. */
    country?: string | null | undefined;
    /** Whether this is the default payment method. */
    default?: boolean | null | undefined;
    /** Device data for fraud prevention. */
    deviceData?: string | null | undefined;
    /** Card expiration date. */
    expirationDate?: string | null | undefined;
    /** Billing first name. */
    firstName?: string | null | undefined;
    /** Last four digits of the card number. */
    lastFour?: string | null | undefined;
    /** Billing last name. */
    lastName?: string | null | undefined;
    /** A nickname for the payment method. */
    nickName?: string | null | undefined;
    /** Email associated with the payment account. */
    paymentAccountEmail?: string | null | undefined;
    /** Payment email address. */
    paymentEmail?: string | null | undefined;
    /** The payment gateway used. */
    paymentGateway?: string | null | undefined;
    /** Payment nonce for tokenized payments. */
    paymentNonce?: string | null | undefined;
    /** Billing state. */
    state?: string | null | undefined;
    /** The payment method type. */
    type?: UpdatePaymentMethodResponseType | null | undefined;
    /** Billing zip code. */
    zipcode?: string | null | undefined;
}
export type SubscriptionsUpdateRequestFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateRequestRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateRequestRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateRequestRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateRequestRatePlanId | (string & {}) | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | undefined;
    /** The full name of the rate plan. */
    publicName?: string | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateRequestRatePlanSetsList | undefined;
}
export interface UpdateSubscriptionRequest {
    /** Identifier */
    accountId: string;
    /** Subscription identifier tag. */
    subscriptionIdentifier: string;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateRequestFrequency | (string & {}) | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateRequestRatePlan | undefined;
}
export type SubscriptionsUpdateResponseFrequency = "weekly" | "monthly" | "quarterly" | "yearly";
export type SubscriptionsUpdateResponseRatePlanId = "free" | "lite" | "pro" | "pro_plus" | "business" | "enterprise" | "partners_free" | "partners_pro" | "partners_business" | "partners_enterprise";
export type SubscriptionsUpdateResponseRatePlanSetsList = Array<string>;
export interface SubscriptionsUpdateResponseRatePlan {
    /** The ID of the rate plan. */
    id?: SubscriptionsUpdateResponseRatePlanId | null | undefined;
    /** The currency applied to the rate plan subscription. */
    currency?: string | null | undefined;
    /** Whether this rate plan is managed externally from Cloudflare. */
    externallyManaged?: boolean | null | undefined;
    /** Whether a rate plan is enterprise-based (or newly adopted term contract). */
    isContract?: boolean | null | undefined;
    /** The full name of the rate plan. */
    publicName?: string | null | undefined;
    /** The scope that this rate plan applies to. */
    scope?: string | null | undefined;
    /** The list of sets this rate plan applies to. Returns array of strings. */
    sets?: SubscriptionsUpdateResponseRatePlanSetsList | null | undefined;
}
export type SubscriptionsUpdateResponseState = "Trial" | "Provisioned" | "Paid" | "AwaitingPayment" | "Cancelled" | "Failed" | "Expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateSubscriptionResponse {
    /** Subscription identifier tag. */
    id?: string | null | undefined;
    /** The monetary unit in which pricing information is displayed. */
    currency?: string | null | undefined;
    /** The end of the current period and also when the next billing is due. */
    currentPeriodEnd?: string | null | undefined;
    /** When the current billing period started. May match initial_period_start if this is the first period. */
    currentPeriodStart?: string | null | undefined;
    /** How often the subscription is renewed automatically. */
    frequency?: SubscriptionsUpdateResponseFrequency | null | undefined;
    /** The price of the subscription that will be billed, in US dollars. */
    price?: number | null | undefined;
    /** The rate plan applied to the subscription. */
    ratePlan?: SubscriptionsUpdateResponseRatePlan | null | undefined;
    /** The state that the subscription is in. */
    state?: SubscriptionsUpdateResponseState | null | undefined;
}
export type TokensUpdateRequestPoliciesItemEffect = "allow" | "deny";
export type TokensUpdateRequestPoliciesItemPermissionGroupsItemMeta = TokensCreateRequestPoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateRequestPoliciesItemPermissionGroupsItem = TokensCreateRequestPoliciesItemPermissionGroupsItem;
export type TokensUpdateRequestPoliciesItemPermissionGroupsList = Array<TokensCreateRequestPoliciesItemPermissionGroupsItem>;
export type TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateRequestPoliciesItemResourcesValue = string | TokensUpdateRequestPoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateRequestPoliciesItemResourcesMap = {
    [key: string]: TokensUpdateRequestPoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateRequestPoliciesItem {
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateRequestPoliciesItemEffect | (string & {});
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateRequestPoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateRequestPoliciesItemResourcesMap;
}
export type TokensUpdateRequestPoliciesList = Array<TokensUpdateRequestPoliciesItem>;
export type TokensUpdateRequestConditionRequestIpInList = Array<string>;
export type TokensUpdateRequestConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateRequestConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateRequestConditionRequestIpInList | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateRequestConditionRequestIpNotInList | undefined;
}
export interface TokensUpdateRequestCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateRequestConditionRequestIp | undefined;
}
export type TokensUpdateRequestStatus = "active" | "disabled" | "expired";
export interface UpdateTokenRequest {
    /** Account identifier tag. */
    accountId: string;
    /** Token identifier tag. */
    tokenId: string;
    /** Token name. */
    name: string;
    /** List of access policies assigned to the token. */
    policies: TokensUpdateRequestPoliciesList;
    condition?: TokensUpdateRequestCondition | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | undefined;
    /** Status of the token. */
    status?: TokensUpdateRequestStatus | (string & {}) | undefined;
}
export type TokensUpdateResponseConditionRequestIpInList = Array<string>;
export type TokensUpdateResponseConditionRequestIpNotInList = Array<string>;
export interface TokensUpdateResponseConditionRequestIp {
    /** List of IPv4/IPv6 CIDR addresses. */
    in?: TokensUpdateResponseConditionRequestIpInList | null | undefined;
    /** List of IPv4/IPv6 CIDR addresses. */
    notIn?: TokensUpdateResponseConditionRequestIpNotInList | null | undefined;
}
export interface TokensUpdateResponseCondition {
    /** Client IP restrictions. */
    requestIp?: TokensUpdateResponseConditionRequestIp | null | undefined;
}
export type TokensUpdateResponsePoliciesItemEffect = "allow" | "deny";
export type TokensUpdateResponsePoliciesItemPermissionGroupsItemMeta = MembersCreateResponsePoliciesItemPermissionGroupsItemMeta;
export type TokensUpdateResponsePoliciesItemPermissionGroupsItem = MembersCreateResponsePoliciesItemPermissionGroupsItem;
export type TokensUpdateResponsePoliciesItemPermissionGroupsList = Array<MembersCreateResponsePoliciesItemPermissionGroupsItem>;
export type TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap = {
    [key: string]: string | undefined;
};
export type TokensUpdateResponsePoliciesItemResourcesValue = string | TokensUpdateResponsePoliciesItemResourcesIAMResourcesTypeObjectNestedValueMap;
export type TokensUpdateResponsePoliciesItemResourcesMap = {
    [key: string]: TokensUpdateResponsePoliciesItemResourcesValue | undefined;
};
export interface TokensUpdateResponsePoliciesItem {
    /** Policy identifier. */
    id: string;
    /** Allow or deny operations against the resources. */
    effect: TokensUpdateResponsePoliciesItemEffect;
    /** A set of permission groups that are specified to the policy. */
    permissionGroups: TokensUpdateResponsePoliciesItemPermissionGroupsList;
    /** A list of resource names that the policy applies to. */
    resources: TokensUpdateResponsePoliciesItemResourcesMap;
}
export type TokensUpdateResponsePoliciesList = Array<TokensUpdateResponsePoliciesItem>;
export type TokensUpdateResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface UpdateTokenResponse {
    /** Token identifier tag. */
    id?: string | null | undefined;
    condition?: TokensUpdateResponseCondition | null | undefined;
    /** The email address of the user who created the token at the time of creation. Only present for Account Owned API Tokens when a creator email was available. */
    creatorEmailAtCreation?: string | null | undefined;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time on which the token was created. */
    issuedOn?: string | null | undefined;
    /** Last time the token was used. */
    lastUsedOn?: string | null | undefined;
    /** Last time the token was modified. */
    modifiedOn?: string | null | undefined;
    /** Token name. */
    name?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
    /** List of access policies assigned to the token. */
    policies?: TokensUpdateResponsePoliciesList | null | undefined;
    /** The identifier of the service that provisioned the token. For an OAuth-provisioned token, this is the OAuth client identifier. Present when `provisioner_type` is present and null when the identifier is unavailable. */
    provisionerId?: string | null | undefined;
    /** The type of service that provisioned the token. Only present for provisioned Account Owned API Tokens. */
    provisionerType?: string | null | undefined;
    /** Status of the token. */
    status?: TokensUpdateResponseStatus | null | undefined;
    /** The prefix of the token value, before the first underscore. Use it with `token_suffix` to identify a token. Only present for tokens created or rolled after this field was added. */
    tokenPrefix?: string | null | undefined;
    /** The last 4 characters of the token value. Use it with `token_prefix` to identify a token. It is not unique. Only present for tokens created or rolled after this field was added. */
    tokenSuffix?: string | null | undefined;
}
export interface VerifyTokenRequest {
    /** Account identifier tag. */
    accountId: string;
}
export type TokensVerifyResponseStatus = "active" | "disabled" | "expired";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface VerifyTokenResponse {
    /** Token identifier tag. */
    id: string;
    /** Status of the token. */
    status: TokensVerifyResponseStatus;
    /** The expiration time on or after which the JWT MUST NOT be accepted for processing. */
    expiresOn?: string | null | undefined;
    /** The time before which the token MUST NOT be accepted for processing. */
    notBefore?: string | null | undefined;
}
export type CreateAccountError = AccountCreationForbidden | MissingName | CloudflareOpError;
/** Create an Account. To create the Account within an Organization, provide `unit.id` and omit `standalone`. To create a standalone Free Account, provide `standalone: true` and omit `unit`. Providing both fields is invalid. If you omit both fields, Cloudflare can determine the destination only when the User is an administrator of exactly one Organization. Cloudflare creates the Account in that Organization; otherwise, the request returns an error. Account names are limited to 65 UTF-8 bytes. */
export declare const createAccount: API.OperationMethod<CreateAccountRequest, CreateAccountResponse, CreateAccountError, CloudflareOpContext>;
export type CreateAccountOrganizationError = CloudflareOpError;
/** Move an account into a destination organization, either assigning a standalone account to an organization or moving it between organizations in the same hierarchy. Availability depends on the organization's capabilities. */
export declare const createAccountOrganization: API.OperationMethod<CreateAccountOrganizationRequest, CreateAccountOrganizationResponse, CreateAccountOrganizationError, CloudflareOpContext>;
export type CreateClientSecretError = CloudflareOpError;
/** Creates a Stripe setup intent for adding a payment method to an account. Returns a client secret for frontend payment method collection. */
export declare const createClientSecret: API.OperationMethod<CreateClientSecretRequest, CreateClientSecretResponse, CreateClientSecretError, CloudflareOpContext>;
export type CreateMemberError = InvalidRoute | ValidationError | AccountMemberAlreadyExists | CloudflareOpError;
/** Add a user to the list of members for this account. */
export declare const createMember: API.OperationMethod<CreateMemberRequest, CreateMemberResponse, CreateMemberError, CloudflareOpContext>;
export type CreatePayBadDebtError = CloudflareOpError;
/** Pays outstanding bad debt for an account. Discovers all debt automatically and handles invoice deduplication. */
export declare const createPayBadDebt: API.OperationMethod<CreatePayBadDebtRequest, CreatePayBadDebtResponse, CreatePayBadDebtError, CloudflareOpContext>;
export type CreatePayInvoiceError = CloudflareOpError;
/** Pays an outstanding invoice for an account. Returns a Stripe client secret when Strong Customer Authentication (SCA) is required to complete the payment. */
export declare const createPayInvoice: API.OperationMethod<CreatePayInvoiceRequest, CreatePayInvoiceResponse, CreatePayInvoiceError, CloudflareOpContext>;
export type CreatePaymentMethodError = CloudflareOpError;
/** Creates a new payment method for an account. */
export declare const createPaymentMethod: API.OperationMethod<CreatePaymentMethodRequest, CreatePaymentMethodResponse, CreatePaymentMethodError, CloudflareOpContext>;
export type CreateSubscriptionError = JsonDecodeFailure | InvalidRoute | CloudflareOpError;
/** Creates an account or zone subscription. */
export declare const createSubscription: API.OperationMethod<CreateSubscriptionRequest, CreateSubscriptionResponse, CreateSubscriptionError, CloudflareOpContext>;
export type CreateTokenError = InvalidRoute | InvalidTokenName | PermissionGroupNotFound | CloudflareOpError;
/** Create a new Account Owned API token. */
export declare const createToken: API.OperationMethod<CreateTokenRequest, CreateTokenResponse, CreateTokenError, CloudflareOpContext>;
export type DeleteAccountError = InvalidRoute | MethodNotAllowed | CloudflareOpError;
/** Delete a specific account (only available for tenant admins at this time). This is a permanent operation that will delete any zones or other resources under the account */
export declare const deleteAccount: API.OperationMethod<DeleteAccountRequest, DeleteAccountResponse, DeleteAccountError, CloudflareOpContext>;
export type DeleteMemberError = MemberNotFound | InvalidRoute | CloudflareOpError;
/** Remove a member from an account. */
export declare const deleteMember: API.OperationMethod<DeleteMemberRequest, DeleteMemberResponse, DeleteMemberError, CloudflareOpContext>;
export type DeletePaymentMethodError = CloudflareOpError;
/** Deletes a payment method from an account. */
export declare const deletePaymentMethod: API.OperationMethod<DeletePaymentMethodRequest, DeletePaymentMethodResponse, DeletePaymentMethodError, CloudflareOpContext>;
export type DeleteSubscriptionError = InvalidRoute | EndpointNotFound | CloudflareOpError;
/** Deletes an account's subscription. */
export declare const deleteSubscription: API.OperationMethod<DeleteSubscriptionRequest, DeleteSubscriptionResponse, DeleteSubscriptionError, CloudflareOpContext>;
export type DeleteTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | TokenManagedByCloudflare | CloudflareOpError;
/** Destroy an Account Owned API token. */
export declare const deleteToken: API.OperationMethod<DeleteTokenRequest, DeleteTokenResponse, DeleteTokenError, CloudflareOpContext>;
export type EditInvoiceError = CloudflareOpError;
/** Toggles PDF invoice generation for an account. */
export declare const editInvoice: API.OperationMethod<EditInvoiceRequest, EditInvoiceResponse, EditInvoiceError, CloudflareOpContext>;
export type GetAccountError = InvalidRoute | CloudflareOpError;
/** Get information about a specific account that you are a member of. */
export declare const getAccount: API.OperationMethod<GetAccountRequest, GetAccountResponse, GetAccountError, CloudflareOpContext>;
export type GetAccountProfileError = CloudflareOpError;
/** Retrieves the business profile (name, email, phone, address, and external metadata) associated with this account's customer record. Profiles can be shared across accounts and organizations. Only available to members of an organization that contains the account. */
export declare const getAccountProfile: API.OperationMethod<GetAccountProfileRequest, GetAccountProfileResponse, GetAccountProfileError, CloudflareOpContext>;
export type GetMemberError = MemberNotFound | InvalidRoute | CloudflareOpError;
/** Get information about a specific member of an account. */
export declare const getMember: API.OperationMethod<GetMemberRequest, GetMemberResponse, GetMemberError, CloudflareOpContext>;
export type GetPaymentMethodError = CloudflareOpError;
/** Gets a specific payment method for an account. */
export declare const getPaymentMethod: API.OperationMethod<GetPaymentMethodRequest, GetPaymentMethodResponse, GetPaymentMethodError, CloudflareOpContext>;
export type GetRoleError = InvalidRoute | CloudflareOpError;
/** Get information about a specific role for an account. */
export declare const getRole: API.OperationMethod<GetRoleRequest, GetRoleResponse, GetRoleError, CloudflareOpContext>;
export type GetSpeedSettingsTransformationError = CloudflareOpError;
/** Returns a list of Image Resizing configurations across all zones for the account. This endpoint is useful for retrieving the transformations (image_resizing) state for all zones belonging to an account. */
export declare const getSpeedSettingsTransformation: API.OperationMethod<GetSpeedSettingsTransformationRequest, GetSpeedSettingsTransformationResponse, GetSpeedSettingsTransformationError, CloudflareOpContext>;
export type GetSubscriptionError = CloudflareOpError;
/** Lists all of an account or zone's subscriptions. */
export declare const getSubscription: API.PaginatedOperationMethod<GetSubscriptionRequest, GetSubscriptionResponse, GetSubscriptionError, CloudflareOpContext, SubscriptionsGetResultItem>;
export type GetTokenError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Get information about a specific Account Owned API token. */
export declare const getToken: API.OperationMethod<GetTokenRequest, GetTokenResponse, GetTokenError, CloudflareOpContext>;
export type GetTokenPermissionGroupError = InvalidRoute | CloudflareOpError;
/** Find all available permission groups for Account Owned API Tokens. Each permission group indicates whether the caller can select it when creating a token. Token creation performs the authoritative permission check. */
export declare const getTokenPermissionGroup: API.OperationMethod<GetTokenPermissionGroupRequest, GetTokenPermissionGroupResponse, GetTokenPermissionGroupError, CloudflareOpContext>;
export type ListAccountsError = CloudflareOpError;
/** List all accounts you have ownership or verified access to. */
export declare const listAccounts: API.PaginatedOperationMethod<ListAccountsRequest, ListAccountsResponse, ListAccountsError, CloudflareOpContext, ListResultItem>;
export type ListEntitlementsError = CloudflareOpError;
/** Returns the list of entitlements (features and their allocations) for a given account. Each entitlement describes a product feature the account is permitted to use and the allocation value (boolean, count, range, enum, or string) that governs its behaviour. */
export declare const listEntitlements: API.OperationMethod<ListEntitlementsRequest, ListEntitlementsResponse, ListEntitlementsError, CloudflareOpContext>;
export type ListLogAuditsError = CloudflareOpError;
/** Gets a list of audit logs for an account. */
export declare const listLogAudits: API.PaginatedOperationMethod<ListLogAuditsRequest, ListLogAuditsResponse, ListLogAuditsError, CloudflareOpContext, LogsAuditListResultItem>;
export type ListMembersError = CloudflareOpError;
/** List all members of an account. */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest, ListMembersResponse, ListMembersError, CloudflareOpContext, MembersListResultItem>;
export type ListPaymentMethodsError = CloudflareOpError;
/** Lists all payment methods for an account. */
export declare const listPaymentMethods: API.OperationMethod<ListPaymentMethodsRequest, ListPaymentMethodsResponse, ListPaymentMethodsError, CloudflareOpContext>;
export type ListRolesError = CloudflareOpError;
/** Get all available roles for an account. */
export declare const listRoles: API.PaginatedOperationMethod<ListRolesRequest, ListRolesResponse, ListRolesError, CloudflareOpContext, MembersCreateResponseRolesItem>;
export type ListTokensError = CloudflareOpError;
/** List Account Owned API tokens created for this account. Callers with `com.cloudflare.api.account.token.list_self` permission only receive tokens they created. Results include active, disabled, and recently-expired tokens when `include_expired` is set to true. */
export declare const listTokens: API.PaginatedOperationMethod<ListTokensRequest, ListTokensResponse, ListTokensError, CloudflareOpContext, TokensListResultItem>;
export type ListTokensPermissionGroupsError = InvalidRoute | CloudflareOpError;
/** Find all available permission groups for Account Owned API Tokens. Each permission group indicates whether the caller can select it when creating a token. Token creation performs the authoritative permission check. */
export declare const listTokensPermissionGroups: API.OperationMethod<ListTokensPermissionGroupsRequest, ListTokensPermissionGroupsResponse, ListTokensPermissionGroupsError, CloudflareOpContext>;
export type LogsAuditHistoryError = CloudflareOpError;
/** Returns the chronological change history for the resource identified by the given audit log entry. The endpoint first locates the source audit log entry by `id` (using `action_time` to narrow the lookup window), derives identifying filters from that entry, and then returns matching audit logs within the `since`/`before` window. The `result_info.history_status` field indicates the quality of the resource identification used: - `exact`: Resource was identified by the resource URI. - `approximate`: Resource was identified without the resource URI. - `unavailable`: The source audit log entry did not contain enough information to identify the resource; an empty result is returned. */
export declare const logsAuditHistory: API.OperationMethod<LogsAuditHistoryRequest, LogsAuditHistoryResponse, LogsAuditHistoryError, CloudflareOpContext>;
export type LogsAuditProductCategoriesError = CloudflareOpError;
/** Lists the available audit log product categories and the resource products each one expands to. Use these values with the product_category filter on the account audit logs endpoint. */
export declare const logsAuditProductCategories: API.OperationMethod<LogsAuditProductCategoriesRequest, LogsAuditProductCategoriesResponse, LogsAuditProductCategoriesError, CloudflareOpContext>;
export type PaymentMethodsSetAsDefaultError = CloudflareOpError;
/** Sets a payment method as the default for an account. */
export declare const paymentMethodsSetAsDefault: API.OperationMethod<PaymentMethodsSetAsDefaultRequest, PaymentMethodsSetAsDefaultResponse, PaymentMethodsSetAsDefaultError, CloudflareOpContext>;
export type PutTokenValueError = InvalidRoute | TokenNotFound | CloudflareOpError;
/** Roll the Account Owned API token secret. */
export declare const putTokenValue: API.OperationMethod<PutTokenValueRequest, PutTokenValueResponse, PutTokenValueError, CloudflareOpContext>;
export type ReceiptsPdfError = CloudflareOpError;
/** Downloads a receipt as a PDF document. */
export declare const receiptsPdf: API.OperationMethod<ReceiptsPdfRequest, ReceiptsPdfResponse, ReceiptsPdfError, CloudflareOpContext>;
export type SubscriptionsActionsAppendError = CloudflareOpError;
/** Smartly applies the incoming subscription into the lifecycle of the subscription. */
export declare const subscriptionsActionsAppend: API.OperationMethod<SubscriptionsActionsAppendRequest, SubscriptionsActionsAppendResponse, SubscriptionsActionsAppendError, CloudflareOpContext>;
export type SubscriptionsBulkCreateError = CloudflareOpError;
/** Creates multiple subscriptions for an account in a single request. */
export declare const subscriptionsBulkCreate: API.OperationMethod<SubscriptionsBulkCreateRequest, SubscriptionsBulkCreateResponse, SubscriptionsBulkCreateError, CloudflareOpContext>;
export type SubscriptionsCancelDowngradeError = CloudflareOpError;
/** Cancels pending delayed downgrades for the specified subscriptions. */
export declare const subscriptionsCancelDowngrade: API.OperationMethod<SubscriptionsCancelDowngradeRequest, SubscriptionsCancelDowngradeResponse, SubscriptionsCancelDowngradeError, CloudflareOpContext>;
export type SubscriptionsCancelReasonCreateError = CloudflareOpError;
/** Records a cancellation reason for an account subscription. */
export declare const subscriptionsCancelReasonCreate: API.OperationMethod<SubscriptionsCancelReasonCreateRequest, SubscriptionsCancelReasonCreateResponse, SubscriptionsCancelReasonCreateError, CloudflareOpContext>;
export type SubscriptionsCancelReasonGetError = CloudflareOpError;
/** Gets the cancellation reason for an account subscription. */
export declare const subscriptionsCancelReasonGet: API.OperationMethod<SubscriptionsCancelReasonGetRequest, SubscriptionsCancelReasonGetResponse, SubscriptionsCancelReasonGetError, CloudflareOpContext>;
export type SubscriptionsGetByIdentifierError = CloudflareOpError;
/** Gets an account subscription by identifier. */
export declare const subscriptionsGetByIdentifier: API.OperationMethod<SubscriptionsGetByIdentifierRequest, SubscriptionsGetByIdentifierResponse, SubscriptionsGetByIdentifierError, CloudflareOpContext>;
export type UpdateAccountError = InvalidAccountName | AccountNameTooLong | UpdateAccountTypeNotSupported | InvalidRoute | MethodNotAllowed | CloudflareOpError;
/** Update an existing account. Account names are limited to 65 UTF-8 bytes. */
export declare const updateAccount: API.OperationMethod<UpdateAccountRequest, UpdateAccountResponse, UpdateAccountError, CloudflareOpContext>;
export type UpdateAccountProfileError = CloudflareOpError;
/** Partially updates the business profile (name, email, phone, address, and external metadata) associated with this account's parent organization customer record, creating the profile if it does not exist. Changes apply to every account and organization sharing that profile. Omitted, empty, or null fields are left unchanged. Each profile field is limited to 1,000 UTF-8 bytes. Only available to members of an organization that contains the account. */
export declare const updateAccountProfile: API.OperationMethod<UpdateAccountProfileRequest, UpdateAccountProfileResponse, UpdateAccountProfileError, CloudflareOpContext>;
export type UpdateMemberError = MemberNotFound | InvalidRoute | BadRequest | MethodNotAllowed | CloudflareOpError;
/** Modify an account member. */
export declare const updateMember: API.OperationMethod<UpdateMemberRequest, UpdateMemberResponse, UpdateMemberError, CloudflareOpContext>;
export type UpdatePaymentMethodError = CloudflareOpError;
/** Updates a payment method for an account. */
export declare const updatePaymentMethod: API.OperationMethod<UpdatePaymentMethodRequest, UpdatePaymentMethodResponse, UpdatePaymentMethodError, CloudflareOpContext>;
export type UpdateSubscriptionError = JsonDecodeFailure | InvalidRoute | EndpointNotFound | CloudflareOpError;
/** Updates an account subscription. */
export declare const updateSubscription: API.OperationMethod<UpdateSubscriptionRequest, UpdateSubscriptionResponse, UpdateSubscriptionError, CloudflareOpContext>;
export type UpdateTokenError = InvalidRoute | MethodNotAllowed | TokenNotFound | PermissionGroupNotFound | CloudflareOpError;
/** Update an existing token. */
export declare const updateToken: API.OperationMethod<UpdateTokenRequest, UpdateTokenResponse, UpdateTokenError, CloudflareOpContext>;
export type VerifyTokenError = MissingAuthenticationToken | InvalidRoute | CloudflareOpError;
/** Test whether a token works. */
export declare const verifyToken: API.OperationMethod<VerifyTokenRequest, VerifyTokenResponse, VerifyTokenError, CloudflareOpContext>;
export declare const listTokenPermissionGroups: API.OperationMethod<GetTokenPermissionGroupRequest, TokensPermissionGroupsGetResultList, GetTokenPermissionGroupError, CloudflareOpContext>;
export type ListTokenPermissionGroupsRequest = GetTokenPermissionGroupRequest;
export type ListTokenPermissionGroupsResponse = GetTokenPermissionGroupResponse;
export type ListTokenPermissionGroupsError = GetTokenPermissionGroupError;
//# sourceMappingURL=accounts.d.ts.map