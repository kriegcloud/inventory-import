import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServiceError_base: S.TaggedErrorClass<"InternalServiceError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServiceError extends /*@__PURE__*/ InternalServiceError_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const ResourceExistsException_base: S.TaggedErrorClass<"ResourceExistsException", {
    readonly message: any;
    readonly Resource: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceExistsException extends /*@__PURE__*/ ResourceExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Resource: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceUnavailableException_base: S.TaggedErrorClass<"ServiceUnavailableException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ServiceUnavailableException extends /*@__PURE__*/ ServiceUnavailableException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly RetryAfterSeconds: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
export type HomeDirectory = string;
export type HomeDirectoryType = "PATH" | "LOGICAL" | (string & {});
export type MapEntry = string;
export type MapTarget = string;
export type MapType = "FILE" | "DIRECTORY" | (string & {});
export interface HomeDirectoryMapEntry {
    Entry: string;
    Target: string;
    Type?: MapType | undefined;
}
export type HomeDirectoryMappings = HomeDirectoryMapEntry[];
export type Policy = string;
export type PosixId = number;
export type SecondaryGids = number[];
export interface PosixProfile {
    Uid: number;
    Gid: number;
    SecondaryGids?: number[] | undefined;
}
export type Role = string;
export type ServerId = string;
export type ExternalId = string;
export interface CreateAccessRequest {
    HomeDirectory?: string | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    HomeDirectoryMappings?: HomeDirectoryMapEntry[] | undefined;
    Policy?: string | undefined;
    PosixProfile?: PosixProfile | undefined;
    Role: string;
    ServerId: string;
    ExternalId: string;
}
export interface CreateAccessResponse {
    ServerId: string;
    ExternalId: string;
}
export type Description = string;
export type ProfileId = string;
export type AgreementStatusType = "ACTIVE" | "INACTIVE" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type Tags = Tag[];
export type PreserveFilenameType = "ENABLED" | "DISABLED" | (string & {});
export type EnforceMessageSigningType = "ENABLED" | "DISABLED" | (string & {});
export interface CustomDirectoriesType {
    FailedFilesDirectory: string;
    MdnFilesDirectory: string;
    PayloadFilesDirectory: string;
    StatusFilesDirectory: string;
    TemporaryFilesDirectory: string;
}
export interface CreateAgreementRequest {
    Description?: string | undefined;
    ServerId: string;
    LocalProfileId: string;
    PartnerProfileId: string;
    BaseDirectory?: string | undefined;
    AccessRole: string;
    Status?: AgreementStatusType | undefined;
    Tags?: Tag[] | undefined;
    PreserveFilename?: PreserveFilenameType | undefined;
    EnforceMessageSigning?: EnforceMessageSigningType | undefined;
    CustomDirectories?: CustomDirectoriesType | undefined;
}
export type AgreementId = string;
export interface CreateAgreementResponse {
    AgreementId: string;
}
export type Url = string;
export type MessageSubject = string | redacted.Redacted<string>;
export type CompressionEnum = "ZLIB" | "DISABLED" | (string & {});
export type EncryptionAlg = "AES128_CBC" | "AES192_CBC" | "AES256_CBC" | "DES_EDE3_CBC" | "NONE" | (string & {});
export type SigningAlg = "SHA256" | "SHA384" | "SHA512" | "SHA1" | "NONE" | (string & {});
export type MdnSigningAlg = "SHA256" | "SHA384" | "SHA512" | "SHA1" | "NONE" | "DEFAULT" | (string & {});
export type MdnResponse = "SYNC" | "NONE" | "ASYNC" | (string & {});
export type As2ConnectorSecretId = string;
export type PreserveContentType = "ENABLED" | "DISABLED" | (string & {});
export type As2AsyncMdnServerIds = string[];
export interface As2AsyncMdnConnectorConfig {
    Url?: string | undefined;
    ServerIds?: string[] | undefined;
}
export interface As2ConnectorConfig {
    LocalProfileId?: string | undefined;
    PartnerProfileId?: string | undefined;
    MessageSubject?: string | redacted.Redacted<string> | undefined;
    Compression?: CompressionEnum | undefined;
    EncryptionAlgorithm?: EncryptionAlg | undefined;
    SigningAlgorithm?: SigningAlg | undefined;
    MdnSigningAlgorithm?: MdnSigningAlg | undefined;
    MdnResponse?: MdnResponse | undefined;
    BasicAuthSecretId?: string | undefined;
    PreserveContentType?: PreserveContentType | undefined;
    AsyncMdnConfig?: As2AsyncMdnConnectorConfig | undefined;
}
export type SecretId = string;
export type SftpConnectorTrustedHostKey = string;
export type SftpConnectorTrustedHostKeyList = string[];
export type MaxConcurrentConnections = number;
export type SecretVersionStage = string;
export type SecretVersionStageList = string[];
export interface SftpConnectorConfig {
    UserSecretId?: string | undefined;
    TrustedHostKeys?: string[] | undefined;
    MaxConcurrentConnections?: number | undefined;
    OrderedUserSecretVersionStages?: string[] | undefined;
}
export type ConnectorSecurityPolicyName = string;
export type VpcLatticeResourceConfigurationArn = string;
export type SftpPort = number;
export interface ConnectorVpcLatticeEgressConfig {
    ResourceConfigurationArn: string;
    PortNumber?: number | undefined;
}
export type ConnectorEgressConfig = {
    VpcLattice: ConnectorVpcLatticeEgressConfig;
};
export type ConnectorsIpAddressType = "IPV4" | "DUALSTACK" | (string & {});
export interface CreateConnectorRequest {
    Url?: string | undefined;
    As2Config?: As2ConnectorConfig | undefined;
    AccessRole: string;
    LoggingRole?: string | undefined;
    Tags?: Tag[] | undefined;
    SftpConfig?: SftpConnectorConfig | undefined;
    SecurityPolicyName?: string | undefined;
    EgressConfig?: ConnectorEgressConfig | undefined;
    IpAddressType?: ConnectorsIpAddressType | undefined;
}
export type ConnectorId = string;
export interface CreateConnectorResponse {
    ConnectorId: string;
}
export type As2Id = string;
export type ProfileType = "LOCAL" | "PARTNER" | (string & {});
export type CertificateId = string;
export type CertificateIds = string[];
export interface CreateProfileRequest {
    As2Id: string;
    ProfileType: ProfileType;
    CertificateIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateProfileResponse {
    ProfileId: string;
}
export type Certificate = string;
export type Domain = "S3" | "EFS" | (string & {});
export type AddressAllocationId = string;
export type AddressAllocationIds = string[];
export type SubnetId = string;
export type SubnetIds = string[];
export type VpcEndpointId = string;
export type VpcId = string;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export interface EndpointDetails {
    AddressAllocationIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    VpcEndpointId?: string | undefined;
    VpcId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export type EndpointType = "PUBLIC" | "VPC" | "VPC_ENDPOINT" | (string & {});
export type HostKey = string | redacted.Redacted<string>;
export type DirectoryId = string;
export type SftpAuthenticationMethods = "PASSWORD" | "PUBLIC_KEY" | "PUBLIC_KEY_OR_PASSWORD" | "PUBLIC_KEY_AND_PASSWORD" | (string & {});
export interface IdentityProviderDetails {
    Url?: string | undefined;
    InvocationRole?: string | undefined;
    DirectoryId?: string | undefined;
    Function?: string | undefined;
    SftpAuthenticationMethods?: SftpAuthenticationMethods | undefined;
}
export type IdentityProviderType = "SERVICE_MANAGED" | "API_GATEWAY" | "AWS_DIRECTORY_SERVICE" | "AWS_LAMBDA" | (string & {});
export type NullableRole = string;
export type PostAuthenticationLoginBanner = string;
export type PreAuthenticationLoginBanner = string;
export type Protocol = "SFTP" | "FTP" | "FTPS" | "AS2" | (string & {});
export type Protocols = Protocol[];
export type PassiveIp = string;
export type TlsSessionResumptionMode = "DISABLED" | "ENABLED" | "ENFORCED" | (string & {});
export type SetStatOption = "DEFAULT" | "ENABLE_NO_OP" | (string & {});
export type CommunicationMode = "CLIENT_TALK_FIRST" | "SERVER_TALK_FIRST" | (string & {});
export interface SftpPortWithOptions {
    SftpPort: number;
    CommunicationMode?: CommunicationMode | undefined;
}
export type SftpPorts = SftpPortWithOptions[];
export type As2Transport = "HTTP" | (string & {});
export type As2Transports = As2Transport[];
export type ProxyMode = "NONE" | "PROXY_PROTOCOL_V2_ENFORCED" | (string & {});
export interface ProxyConfig {
    SftpMode?: ProxyMode | undefined;
}
export interface ProtocolDetails {
    PassiveIp?: string | undefined;
    TlsSessionResumptionMode?: TlsSessionResumptionMode | undefined;
    SetStatOption?: SetStatOption | undefined;
    SftpPorts?: SftpPortWithOptions[] | undefined;
    As2Transports?: As2Transport[] | undefined;
    ProxyConfig?: ProxyConfig | undefined;
}
export type SecurityPolicyName = string;
export type WorkflowId = string;
export interface WorkflowDetail {
    WorkflowId: string;
    ExecutionRole: string;
}
export type OnUploadWorkflowDetails = WorkflowDetail[];
export type OnPartialUploadWorkflowDetails = WorkflowDetail[];
export interface WorkflowDetails {
    OnUpload?: WorkflowDetail[] | undefined;
    OnPartialUpload?: WorkflowDetail[] | undefined;
}
export type Arn = string;
export type StructuredLogDestinations = string[];
export type DirectoryListingOptimization = "ENABLED" | "DISABLED" | (string & {});
export interface S3StorageOptions {
    DirectoryListingOptimization?: DirectoryListingOptimization | undefined;
}
export type IpAddressType = "IPV4" | "DUALSTACK" | (string & {});
export type HostKeyStorageType = "SERVICE_MANAGED" | "SECRETS_MANAGER" | (string & {});
export interface CreateServerRequest {
    Certificate?: string | undefined;
    Domain?: Domain | undefined;
    EndpointDetails?: EndpointDetails | undefined;
    EndpointType?: EndpointType | undefined;
    HostKey?: string | redacted.Redacted<string> | undefined;
    IdentityProviderDetails?: IdentityProviderDetails | undefined;
    IdentityProviderType?: IdentityProviderType | undefined;
    LoggingRole?: string | undefined;
    PostAuthenticationLoginBanner?: string | undefined;
    PreAuthenticationLoginBanner?: string | undefined;
    Protocols?: Protocol[] | undefined;
    ProtocolDetails?: ProtocolDetails | undefined;
    SecurityPolicyName?: string | undefined;
    Tags?: Tag[] | undefined;
    WorkflowDetails?: WorkflowDetails | undefined;
    StructuredLogDestinations?: string[] | undefined;
    S3StorageOptions?: S3StorageOptions | undefined;
    IpAddressType?: IpAddressType | undefined;
    HostKeyStorageType?: HostKeyStorageType | undefined;
}
export interface CreateServerResponse {
    ServerId: string;
}
export type SshPublicKeyBody = string;
export type UserName = string;
export interface CreateUserRequest {
    HomeDirectory?: string | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    HomeDirectoryMappings?: HomeDirectoryMapEntry[] | undefined;
    Policy?: string | undefined;
    PosixProfile?: PosixProfile | undefined;
    Role: string;
    ServerId: string;
    SshPublicKeyBody?: string | undefined;
    Tags?: Tag[] | undefined;
    UserName: string;
}
export interface CreateUserResponse {
    ServerId: string;
    UserName: string;
}
export type IdentityCenterInstanceArn = string;
export interface IdentityCenterConfig {
    InstanceArn?: string | undefined;
    Role?: string | undefined;
}
export type WebAppIdentityProviderDetails = {
    IdentityCenterConfig: IdentityCenterConfig;
};
export type WebAppAccessEndpoint = string;
export type WebAppUnitCount = number;
export type WebAppUnits = {
    Provisioned: number;
};
export type WebAppEndpointPolicy = "FIPS" | "STANDARD" | (string & {});
export type WebAppVpcEndpointIpAddressType = "IPV4" | "DUALSTACK" | (string & {});
export interface WebAppVpcConfig {
    SubnetIds?: string[] | undefined;
    VpcId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    IpAddressType?: WebAppVpcEndpointIpAddressType | undefined;
}
export type WebAppEndpointDetails = {
    Vpc: WebAppVpcConfig;
};
export interface CreateWebAppRequest {
    IdentityProviderDetails: WebAppIdentityProviderDetails;
    AccessEndpoint?: string | undefined;
    WebAppUnits?: WebAppUnits | undefined;
    Tags?: Tag[] | undefined;
    WebAppEndpointPolicy?: WebAppEndpointPolicy | undefined;
    EndpointDetails?: WebAppEndpointDetails | undefined;
}
export type WebAppId = string;
export interface CreateWebAppResponse {
    WebAppId: string;
}
export type WorkflowDescription = string;
export type WorkflowStepType = "COPY" | "CUSTOM" | "TAG" | "DELETE" | "DECRYPT" | (string & {});
export type WorkflowStepName = string;
export type S3Bucket = string;
export type S3Key = string;
export interface S3InputFileLocation {
    Bucket?: string | undefined;
    Key?: string | undefined;
}
export type EfsFileSystemId = string;
export type EfsPath = string;
export interface EfsFileLocation {
    FileSystemId?: string | undefined;
    Path?: string | undefined;
}
export interface InputFileLocation {
    S3FileLocation?: S3InputFileLocation | undefined;
    EfsFileLocation?: EfsFileLocation | undefined;
}
export type OverwriteExisting = "TRUE" | "FALSE" | (string & {});
export type SourceFileLocation = string;
export interface CopyStepDetails {
    Name?: string | undefined;
    DestinationFileLocation?: InputFileLocation | undefined;
    OverwriteExisting?: OverwriteExisting | undefined;
    SourceFileLocation?: string | undefined;
}
export type CustomStepTarget = string;
export type CustomStepTimeoutSeconds = number;
export interface CustomStepDetails {
    Name?: string | undefined;
    Target?: string | undefined;
    TimeoutSeconds?: number | undefined;
    SourceFileLocation?: string | undefined;
}
export interface DeleteStepDetails {
    Name?: string | undefined;
    SourceFileLocation?: string | undefined;
}
export type S3TagKey = string;
export type S3TagValue = string;
export interface S3Tag {
    Key: string;
    Value: string;
}
export type S3Tags = S3Tag[];
export interface TagStepDetails {
    Name?: string | undefined;
    Tags?: S3Tag[] | undefined;
    SourceFileLocation?: string | undefined;
}
export type EncryptionType = "PGP" | (string & {});
export interface DecryptStepDetails {
    Name?: string | undefined;
    Type: EncryptionType;
    SourceFileLocation?: string | undefined;
    OverwriteExisting?: OverwriteExisting | undefined;
    DestinationFileLocation: InputFileLocation;
}
export interface WorkflowStep {
    Type?: WorkflowStepType | undefined;
    CopyStepDetails?: CopyStepDetails | undefined;
    CustomStepDetails?: CustomStepDetails | undefined;
    DeleteStepDetails?: DeleteStepDetails | undefined;
    TagStepDetails?: TagStepDetails | undefined;
    DecryptStepDetails?: DecryptStepDetails | undefined;
}
export type WorkflowSteps = WorkflowStep[];
export interface CreateWorkflowRequest {
    Description?: string | undefined;
    Steps: WorkflowStep[];
    OnExceptionSteps?: WorkflowStep[] | undefined;
    Tags?: Tag[] | undefined;
    StructuredLogDestinations?: string[] | undefined;
}
export interface CreateWorkflowResponse {
    WorkflowId: string;
}
export interface DeleteAccessRequest {
    ServerId: string;
    ExternalId: string;
}
export interface DeleteAccessResponse {
}
export interface DeleteAgreementRequest {
    AgreementId: string;
    ServerId: string;
}
export interface DeleteAgreementResponse {
}
export interface DeleteCertificateRequest {
    CertificateId: string;
}
export interface DeleteCertificateResponse {
}
export interface DeleteConnectorRequest {
    ConnectorId: string;
}
export interface DeleteConnectorResponse {
}
export type HostKeyId = string;
export interface DeleteHostKeyRequest {
    ServerId: string;
    HostKeyId: string;
}
export interface DeleteHostKeyResponse {
}
export interface DeleteProfileRequest {
    ProfileId: string;
}
export interface DeleteProfileResponse {
}
export interface DeleteServerRequest {
    ServerId: string;
}
export interface DeleteServerResponse {
}
export type SshPublicKeyId = string;
export interface DeleteSshPublicKeyRequest {
    ServerId: string;
    SshPublicKeyId: string;
    UserName: string;
}
export interface DeleteSshPublicKeyResponse {
}
export interface DeleteUserRequest {
    ServerId: string;
    UserName: string;
}
export interface DeleteUserResponse {
}
export interface DeleteWebAppRequest {
    WebAppId: string;
}
export interface DeleteWebAppResponse {
}
export interface DeleteWebAppCustomizationRequest {
    WebAppId: string;
}
export interface DeleteWebAppCustomizationResponse {
}
export interface DeleteWorkflowRequest {
    WorkflowId: string;
}
export interface DeleteWorkflowResponse {
}
export interface DescribeAccessRequest {
    ServerId: string;
    ExternalId: string;
}
export interface DescribedAccess {
    HomeDirectory?: string | undefined;
    HomeDirectoryMappings?: HomeDirectoryMapEntry[] | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    Policy?: string | undefined;
    PosixProfile?: PosixProfile | undefined;
    Role?: string | undefined;
    ExternalId?: string | undefined;
}
export interface DescribeAccessResponse {
    ServerId: string;
    Access: DescribedAccess;
}
export interface DescribeAgreementRequest {
    AgreementId: string;
    ServerId: string;
}
export interface DescribedAgreement {
    Arn: string;
    AgreementId?: string | undefined;
    Description?: string | undefined;
    Status?: AgreementStatusType | undefined;
    ServerId?: string | undefined;
    LocalProfileId?: string | undefined;
    PartnerProfileId?: string | undefined;
    BaseDirectory?: string | undefined;
    AccessRole?: string | undefined;
    Tags?: Tag[] | undefined;
    PreserveFilename?: PreserveFilenameType | undefined;
    EnforceMessageSigning?: EnforceMessageSigningType | undefined;
    CustomDirectories?: CustomDirectoriesType | undefined;
}
export interface DescribeAgreementResponse {
    Agreement: DescribedAgreement;
}
export interface DescribeCertificateRequest {
    CertificateId: string;
}
export type CertificateUsageType = "SIGNING" | "ENCRYPTION" | "TLS" | (string & {});
export type CertificateStatusType = "ACTIVE" | "PENDING_ROTATION" | "INACTIVE" | (string & {});
export type CertificateBodyType = string | redacted.Redacted<string>;
export type CertificateChainType = string | redacted.Redacted<string>;
export type CertDate = Date;
export type CertSerial = string;
export type CertificateType = "CERTIFICATE" | "CERTIFICATE_WITH_PRIVATE_KEY" | (string & {});
export interface DescribedCertificate {
    Arn: string;
    CertificateId?: string | undefined;
    Usage?: CertificateUsageType | undefined;
    Status?: CertificateStatusType | undefined;
    Certificate?: string | redacted.Redacted<string> | undefined;
    CertificateChain?: string | redacted.Redacted<string> | undefined;
    ActiveDate?: Date | undefined;
    InactiveDate?: Date | undefined;
    Serial?: string | undefined;
    NotBeforeDate?: Date | undefined;
    NotAfterDate?: Date | undefined;
    Type?: CertificateType | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribeCertificateResponse {
    Certificate: DescribedCertificate;
}
export interface DescribeConnectorRequest {
    ConnectorId: string;
}
export type ServiceManagedEgressIpAddress = string;
export type ServiceManagedEgressIpAddresses = string[];
export interface DescribedConnectorVpcLatticeEgressConfig {
    ResourceConfigurationArn: string;
    PortNumber?: number | undefined;
}
export type DescribedConnectorEgressConfig = {
    VpcLattice: DescribedConnectorVpcLatticeEgressConfig;
};
export type ConnectorEgressType = "SERVICE_MANAGED" | "VPC_LATTICE" | (string & {});
export type ConnectorErrorMessage = string;
export type ConnectorStatus = "ACTIVE" | "ERRORED" | "PENDING" | (string & {});
export interface DescribedConnector {
    Arn: string;
    ConnectorId?: string | undefined;
    Url?: string | undefined;
    As2Config?: As2ConnectorConfig | undefined;
    AccessRole?: string | undefined;
    LoggingRole?: string | undefined;
    Tags?: Tag[] | undefined;
    SftpConfig?: SftpConnectorConfig | undefined;
    ServiceManagedEgressIpAddresses?: string[] | undefined;
    SecurityPolicyName?: string | undefined;
    EgressConfig?: DescribedConnectorEgressConfig | undefined;
    EgressType: ConnectorEgressType;
    ErrorMessage?: string | undefined;
    Status: ConnectorStatus;
    IpAddressType?: ConnectorsIpAddressType | undefined;
}
export interface DescribeConnectorResponse {
    Connector: DescribedConnector;
}
export type ExecutionId = string;
export interface DescribeExecutionRequest {
    ExecutionId: string;
    WorkflowId: string;
}
export type S3VersionId = string;
export type S3Etag = string;
export interface S3FileLocation {
    Bucket?: string | undefined;
    Key?: string | undefined;
    VersionId?: string | undefined;
    Etag?: string | undefined;
}
export interface FileLocation {
    S3FileLocation?: S3FileLocation | undefined;
    EfsFileLocation?: EfsFileLocation | undefined;
}
export type SessionId = string;
export interface UserDetails {
    UserName: string;
    ServerId: string;
    SessionId?: string | undefined;
}
export interface ServiceMetadata {
    UserDetails: UserDetails;
}
export type LogGroupName = string;
export interface LoggingConfiguration {
    LoggingRole?: string | undefined;
    LogGroupName?: string | undefined;
}
export type ExecutionStatus = "IN_PROGRESS" | "COMPLETED" | "EXCEPTION" | "HANDLING_EXCEPTION" | (string & {});
export type StepResultOutputsJson = string;
export type ExecutionErrorType = "PERMISSION_DENIED" | "CUSTOM_STEP_FAILED" | "THROTTLED" | "ALREADY_EXISTS" | "NOT_FOUND" | "BAD_REQUEST" | "TIMEOUT" | "INTERNAL_SERVER_ERROR" | (string & {});
export type ExecutionErrorMessage = string;
export interface ExecutionError {
    Type: ExecutionErrorType;
    Message: string;
}
export interface ExecutionStepResult {
    StepType?: WorkflowStepType | undefined;
    Outputs?: string | undefined;
    Error?: ExecutionError | undefined;
}
export type ExecutionStepResults = ExecutionStepResult[];
export interface ExecutionResults {
    Steps?: ExecutionStepResult[] | undefined;
    OnExceptionSteps?: ExecutionStepResult[] | undefined;
}
export interface DescribedExecution {
    ExecutionId?: string | undefined;
    InitialFileLocation?: FileLocation | undefined;
    ServiceMetadata?: ServiceMetadata | undefined;
    ExecutionRole?: string | undefined;
    LoggingConfiguration?: LoggingConfiguration | undefined;
    PosixProfile?: PosixProfile | undefined;
    Status?: ExecutionStatus | undefined;
    Results?: ExecutionResults | undefined;
}
export interface DescribeExecutionResponse {
    WorkflowId: string;
    Execution: DescribedExecution;
}
export interface DescribeHostKeyRequest {
    ServerId: string;
    HostKeyId: string;
}
export type HostKeyFingerprint = string;
export type HostKeyDescription = string;
export type HostKeyType = string;
export type DateImported = Date;
export interface DescribedHostKey {
    Arn: string;
    HostKeyId?: string | undefined;
    HostKeyFingerprint?: string | undefined;
    Description?: string | undefined;
    Type?: string | undefined;
    DateImported?: Date | undefined;
    Tags?: Tag[] | undefined;
    StorageType?: HostKeyStorageType | undefined;
    SecretId?: string | undefined;
}
export interface DescribeHostKeyResponse {
    HostKey: DescribedHostKey;
}
export interface DescribeProfileRequest {
    ProfileId: string;
}
export interface DescribedProfile {
    Arn: string;
    ProfileId?: string | undefined;
    ProfileType?: ProfileType | undefined;
    As2Id?: string | undefined;
    CertificateIds?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribeProfileResponse {
    Profile: DescribedProfile;
}
export interface DescribeSecurityPolicyRequest {
    SecurityPolicyName: string;
}
export type Fips = boolean;
export type SecurityPolicyOption = string;
export type SecurityPolicyOptions = string[];
export type SecurityPolicyResourceType = "SERVER" | "CONNECTOR" | (string & {});
export type SecurityPolicyProtocol = "SFTP" | "FTPS" | (string & {});
export type SecurityPolicyProtocols = SecurityPolicyProtocol[];
export interface DescribedSecurityPolicy {
    Fips?: boolean | undefined;
    SecurityPolicyName: string;
    SshCiphers?: string[] | undefined;
    SshKexs?: string[] | undefined;
    SshMacs?: string[] | undefined;
    TlsCiphers?: string[] | undefined;
    SshHostKeyAlgorithms?: string[] | undefined;
    Type?: SecurityPolicyResourceType | undefined;
    Protocols?: SecurityPolicyProtocol[] | undefined;
}
export interface DescribeSecurityPolicyResponse {
    SecurityPolicy: DescribedSecurityPolicy;
}
export interface DescribeServerRequest {
    ServerId: string;
}
export type State = "OFFLINE" | "ONLINE" | "STARTING" | "STOPPING" | "START_FAILED" | "STOP_FAILED" | (string & {});
export type UserCount = number;
export interface DescribedServer {
    Arn: string;
    Certificate?: string | undefined;
    ProtocolDetails?: ProtocolDetails | undefined;
    Domain?: Domain | undefined;
    EndpointDetails?: EndpointDetails | undefined;
    EndpointType?: EndpointType | undefined;
    HostKeyFingerprint?: string | undefined;
    IdentityProviderDetails?: IdentityProviderDetails | undefined;
    IdentityProviderType?: IdentityProviderType | undefined;
    LoggingRole?: string | undefined;
    PostAuthenticationLoginBanner?: string | undefined;
    PreAuthenticationLoginBanner?: string | undefined;
    Protocols?: Protocol[] | undefined;
    SecurityPolicyName?: string | undefined;
    ServerId?: string | undefined;
    State?: State | undefined;
    Tags?: Tag[] | undefined;
    UserCount?: number | undefined;
    WorkflowDetails?: WorkflowDetails | undefined;
    StructuredLogDestinations?: string[] | undefined;
    S3StorageOptions?: S3StorageOptions | undefined;
    As2ServiceManagedEgressIpAddresses?: string[] | undefined;
    IpAddressType?: IpAddressType | undefined;
}
export interface DescribeServerResponse {
    Server: DescribedServer;
}
export interface DescribeUserRequest {
    ServerId: string;
    UserName: string;
}
export interface SshPublicKey {
    DateImported: Date;
    SshPublicKeyBody: string;
    SshPublicKeyId: string;
}
export type SshPublicKeys = SshPublicKey[];
export interface DescribedUser {
    Arn: string;
    HomeDirectory?: string | undefined;
    HomeDirectoryMappings?: HomeDirectoryMapEntry[] | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    Policy?: string | undefined;
    PosixProfile?: PosixProfile | undefined;
    Role?: string | undefined;
    SshPublicKeys?: SshPublicKey[] | undefined;
    Tags?: Tag[] | undefined;
    UserName?: string | undefined;
}
export interface DescribeUserResponse {
    ServerId: string;
    User: DescribedUser;
}
export interface DescribeWebAppRequest {
    WebAppId: string;
}
export type IdentityCenterApplicationArn = string;
export interface DescribedIdentityCenterConfig {
    ApplicationArn?: string | undefined;
    InstanceArn?: string | undefined;
    Role?: string | undefined;
}
export type DescribedWebAppIdentityProviderDetails = {
    IdentityCenterConfig: DescribedIdentityCenterConfig;
};
export type WebAppEndpoint = string;
export type WebAppEndpointType = "PUBLIC" | "VPC" | (string & {});
export interface DescribedWebAppVpcConfig {
    SubnetIds?: string[] | undefined;
    VpcId?: string | undefined;
    VpcEndpointId?: string | undefined;
}
export type DescribedWebAppEndpointDetails = {
    Vpc: DescribedWebAppVpcConfig;
};
export interface DescribedWebApp {
    Arn: string;
    WebAppId: string;
    DescribedIdentityProviderDetails?: DescribedWebAppIdentityProviderDetails | undefined;
    AccessEndpoint?: string | undefined;
    WebAppEndpoint?: string | undefined;
    WebAppUnits?: WebAppUnits | undefined;
    Tags?: Tag[] | undefined;
    WebAppEndpointPolicy?: WebAppEndpointPolicy | undefined;
    EndpointType?: WebAppEndpointType | undefined;
    DescribedEndpointDetails?: DescribedWebAppEndpointDetails | undefined;
}
export interface DescribeWebAppResponse {
    WebApp: DescribedWebApp;
}
export interface DescribeWebAppCustomizationRequest {
    WebAppId: string;
}
export type WebAppTitle = string;
export type WebAppLogoFile = Uint8Array | redacted.Redacted<Uint8Array>;
export type WebAppFaviconFile = Uint8Array | redacted.Redacted<Uint8Array>;
export interface DescribedWebAppCustomization {
    Arn: string;
    WebAppId: string;
    Title?: string | undefined;
    LogoFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    FaviconFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export interface DescribeWebAppCustomizationResponse {
    WebAppCustomization: DescribedWebAppCustomization;
}
export interface DescribeWorkflowRequest {
    WorkflowId: string;
}
export interface DescribedWorkflow {
    Arn: string;
    Description?: string | undefined;
    Steps?: WorkflowStep[] | undefined;
    OnExceptionSteps?: WorkflowStep[] | undefined;
    WorkflowId?: string | undefined;
    Tags?: Tag[] | undefined;
    StructuredLogDestinations?: string[] | undefined;
}
export interface DescribeWorkflowResponse {
    Workflow: DescribedWorkflow;
}
export type PrivateKeyType = string | redacted.Redacted<string>;
export interface ImportCertificateRequest {
    Usage: CertificateUsageType;
    Certificate: string | redacted.Redacted<string>;
    CertificateChain?: string | redacted.Redacted<string> | undefined;
    PrivateKey?: string | redacted.Redacted<string> | undefined;
    ActiveDate?: Date | undefined;
    InactiveDate?: Date | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ImportCertificateResponse {
    CertificateId: string;
}
export type KmsKey = string;
export interface ImportHostKeyRequest {
    ServerId: string;
    HostKeyBody: string | redacted.Redacted<string>;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    StorageType?: HostKeyStorageType | undefined;
    KmsKey?: string | undefined;
}
export interface ImportHostKeyResponse {
    ServerId: string;
    HostKeyId: string;
}
export interface ImportSshPublicKeyRequest {
    ServerId: string;
    SshPublicKeyBody: string;
    UserName: string;
}
export interface ImportSshPublicKeyResponse {
    ServerId: string;
    SshPublicKeyId: string;
    UserName: string;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListAccessesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ServerId: string;
}
export interface ListedAccess {
    HomeDirectory?: string | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    Role?: string | undefined;
    ExternalId?: string | undefined;
}
export type ListedAccesses = ListedAccess[];
export interface ListAccessesResponse {
    NextToken?: string | undefined;
    ServerId: string;
    Accesses: ListedAccess[];
}
export interface ListAgreementsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ServerId: string;
}
export interface ListedAgreement {
    Arn?: string | undefined;
    AgreementId?: string | undefined;
    Description?: string | undefined;
    Status?: AgreementStatusType | undefined;
    ServerId?: string | undefined;
    LocalProfileId?: string | undefined;
    PartnerProfileId?: string | undefined;
}
export type ListedAgreements = ListedAgreement[];
export interface ListAgreementsResponse {
    NextToken?: string | undefined;
    Agreements: ListedAgreement[];
}
export interface ListCertificatesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedCertificate {
    Arn?: string | undefined;
    CertificateId?: string | undefined;
    Usage?: CertificateUsageType | undefined;
    Status?: CertificateStatusType | undefined;
    ActiveDate?: Date | undefined;
    InactiveDate?: Date | undefined;
    Type?: CertificateType | undefined;
    Description?: string | undefined;
}
export type ListedCertificates = ListedCertificate[];
export interface ListCertificatesResponse {
    NextToken?: string | undefined;
    Certificates: ListedCertificate[];
}
export interface ListConnectorsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedConnector {
    Arn?: string | undefined;
    ConnectorId?: string | undefined;
    Url?: string | undefined;
}
export type ListedConnectors = ListedConnector[];
export interface ListConnectorsResponse {
    NextToken?: string | undefined;
    Connectors: ListedConnector[];
}
export interface ListExecutionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    WorkflowId: string;
}
export interface ListedExecution {
    ExecutionId?: string | undefined;
    InitialFileLocation?: FileLocation | undefined;
    ServiceMetadata?: ServiceMetadata | undefined;
    Status?: ExecutionStatus | undefined;
}
export type ListedExecutions = ListedExecution[];
export interface ListExecutionsResponse {
    NextToken?: string | undefined;
    WorkflowId: string;
    Executions: ListedExecution[];
}
export type TransferId = string;
export interface ListFileTransferResultsRequest {
    ConnectorId: string;
    TransferId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type FilePath = string;
export type TransferTableStatus = "QUEUED" | "IN_PROGRESS" | "COMPLETED" | "FAILED" | (string & {});
export type FailureCode = string;
export type Message = string;
export interface ConnectorFileTransferResult {
    FilePath: string;
    StatusCode: TransferTableStatus;
    FailureCode?: string | undefined;
    FailureMessage?: string | undefined;
}
export type ConnectorFileTransferResults = ConnectorFileTransferResult[];
export interface ListFileTransferResultsResponse {
    FileTransferResults: ConnectorFileTransferResult[];
    NextToken?: string | undefined;
}
export interface ListHostKeysRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ServerId: string;
}
export interface ListedHostKey {
    Arn: string;
    HostKeyId?: string | undefined;
    Fingerprint?: string | undefined;
    Description?: string | undefined;
    Type?: string | undefined;
    DateImported?: Date | undefined;
    StorageType?: HostKeyStorageType | undefined;
    SecretId?: string | undefined;
}
export type ListedHostKeys = ListedHostKey[];
export interface ListHostKeysResponse {
    NextToken?: string | undefined;
    ServerId: string;
    HostKeys: ListedHostKey[];
}
export interface ListProfilesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ProfileType?: ProfileType | undefined;
}
export interface ListedProfile {
    Arn?: string | undefined;
    ProfileId?: string | undefined;
    As2Id?: string | undefined;
    ProfileType?: ProfileType | undefined;
}
export type ListedProfiles = ListedProfile[];
export interface ListProfilesResponse {
    NextToken?: string | undefined;
    Profiles: ListedProfile[];
}
export interface ListSecurityPoliciesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type SecurityPolicyNames = string[];
export interface ListSecurityPoliciesResponse {
    NextToken?: string | undefined;
    SecurityPolicyNames: string[];
}
export interface ListServersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedServer {
    Arn: string;
    Domain?: Domain | undefined;
    IdentityProviderType?: IdentityProviderType | undefined;
    EndpointType?: EndpointType | undefined;
    LoggingRole?: string | undefined;
    ServerId?: string | undefined;
    State?: State | undefined;
    UserCount?: number | undefined;
}
export type ListedServers = ListedServer[];
export interface ListServersResponse {
    NextToken?: string | undefined;
    Servers: ListedServer[];
}
export interface ListTagsForResourceRequest {
    Arn: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListTagsForResourceResponse {
    Arn?: string | undefined;
    NextToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ListUsersRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ServerId: string;
}
export type SshPublicKeyCount = number;
export interface ListedUser {
    Arn: string;
    HomeDirectory?: string | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    Role?: string | undefined;
    SshPublicKeyCount?: number | undefined;
    UserName?: string | undefined;
}
export type ListedUsers = ListedUser[];
export interface ListUsersResponse {
    NextToken?: string | undefined;
    ServerId: string;
    Users: ListedUser[];
}
export interface ListWebAppsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedWebApp {
    Arn: string;
    WebAppId: string;
    AccessEndpoint?: string | undefined;
    WebAppEndpoint?: string | undefined;
    EndpointType?: WebAppEndpointType | undefined;
}
export type ListedWebApps = ListedWebApp[];
export interface ListWebAppsResponse {
    NextToken?: string | undefined;
    WebApps: ListedWebApp[];
}
export interface ListWorkflowsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListedWorkflow {
    WorkflowId?: string | undefined;
    Description?: string | undefined;
    Arn?: string | undefined;
}
export type ListedWorkflows = ListedWorkflow[];
export interface ListWorkflowsResponse {
    NextToken?: string | undefined;
    Workflows: ListedWorkflow[];
}
export type CallbackToken = string;
export type CustomStepStatus = "SUCCESS" | "FAILURE" | (string & {});
export interface SendWorkflowStepStateRequest {
    WorkflowId: string;
    ExecutionId: string;
    Token: string;
    Status: CustomStepStatus;
}
export interface SendWorkflowStepStateResponse {
}
export type MaxItems = number;
export interface StartDirectoryListingRequest {
    ConnectorId: string;
    RemoteDirectoryPath: string;
    MaxItems?: number | undefined;
    OutputDirectoryPath: string;
}
export type ListingId = string;
export type OutputFileName = string;
export interface StartDirectoryListingResponse {
    ListingId: string;
    OutputFileName: string;
}
export type FilePaths = string[];
export type CustomHttpHeaderKeyType = string | redacted.Redacted<string>;
export type CustomHttpHeaderValueType = string | redacted.Redacted<string>;
export interface CustomHttpHeader {
    Key?: string | redacted.Redacted<string> | undefined;
    Value?: string | redacted.Redacted<string> | undefined;
}
export type CustomHttpHeaders = CustomHttpHeader[];
export interface StartFileTransferRequest {
    ConnectorId: string;
    SendFilePaths?: string[] | undefined;
    RetrieveFilePaths?: string[] | undefined;
    LocalDirectoryPath?: string | undefined;
    RemoteDirectoryPath?: string | undefined;
    CustomHttpHeaders?: CustomHttpHeader[] | undefined;
}
export interface StartFileTransferResponse {
    TransferId: string;
}
export interface StartRemoteDeleteRequest {
    ConnectorId: string;
    DeletePath: string;
}
export type DeleteId = string;
export interface StartRemoteDeleteResponse {
    DeleteId: string;
}
export interface StartRemoteMoveRequest {
    ConnectorId: string;
    SourcePath: string;
    TargetPath: string;
}
export type MoveId = string;
export interface StartRemoteMoveResponse {
    MoveId: string;
}
export interface StartServerRequest {
    ServerId: string;
}
export interface StartServerResponse {
}
export interface StopServerRequest {
    ServerId: string;
}
export interface StopServerResponse {
}
export interface TagResourceRequest {
    Arn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export interface TestConnectionRequest {
    ConnectorId: string;
}
export type Status = string;
export type SftpConnectorHostKey = string;
export interface SftpConnectorConnectionDetails {
    HostKey?: string | undefined;
}
export interface TestConnectionResponse {
    ConnectorId?: string | undefined;
    Status?: string | undefined;
    StatusMessage?: string | undefined;
    SftpConnectionDetails?: SftpConnectorConnectionDetails | undefined;
}
export type SourceIp = string;
export type UserPassword = string | redacted.Redacted<string>;
export interface TestIdentityProviderRequest {
    ServerId: string;
    ServerProtocol?: Protocol | undefined;
    SourceIp?: string | undefined;
    UserName: string;
    UserPassword?: string | redacted.Redacted<string> | undefined;
}
export type Response = string;
export type StatusCode = number;
export interface TestIdentityProviderResponse {
    Response?: string | undefined;
    StatusCode: number;
    Message?: string | undefined;
    Url: string;
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    Arn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateAccessRequest {
    HomeDirectory?: string | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    HomeDirectoryMappings?: HomeDirectoryMapEntry[] | undefined;
    Policy?: string | undefined;
    PosixProfile?: PosixProfile | undefined;
    Role?: string | undefined;
    ServerId: string;
    ExternalId: string;
}
export interface UpdateAccessResponse {
    ServerId: string;
    ExternalId: string;
}
export interface UpdateAgreementRequest {
    AgreementId: string;
    ServerId: string;
    Description?: string | undefined;
    Status?: AgreementStatusType | undefined;
    LocalProfileId?: string | undefined;
    PartnerProfileId?: string | undefined;
    BaseDirectory?: string | undefined;
    AccessRole?: string | undefined;
    PreserveFilename?: PreserveFilenameType | undefined;
    EnforceMessageSigning?: EnforceMessageSigningType | undefined;
    CustomDirectories?: CustomDirectoriesType | undefined;
}
export interface UpdateAgreementResponse {
    AgreementId: string;
}
export interface UpdateCertificateRequest {
    CertificateId: string;
    ActiveDate?: Date | undefined;
    InactiveDate?: Date | undefined;
    Description?: string | undefined;
}
export interface UpdateCertificateResponse {
    CertificateId: string;
}
export interface UpdateConnectorVpcLatticeEgressConfig {
    ResourceConfigurationArn?: string | undefined;
    PortNumber?: number | undefined;
}
export type UpdateConnectorEgressConfig = {
    VpcLattice: UpdateConnectorVpcLatticeEgressConfig;
};
export interface UpdateConnectorRequest {
    ConnectorId: string;
    Url?: string | undefined;
    As2Config?: As2ConnectorConfig | undefined;
    AccessRole?: string | undefined;
    LoggingRole?: string | undefined;
    SftpConfig?: SftpConnectorConfig | undefined;
    SecurityPolicyName?: string | undefined;
    EgressConfig?: UpdateConnectorEgressConfig | undefined;
    IpAddressType?: ConnectorsIpAddressType | undefined;
}
export interface UpdateConnectorResponse {
    ConnectorId: string;
}
export interface UpdateHostKeyRequest {
    ServerId: string;
    HostKeyId: string;
    Description?: string | undefined;
    StorageType?: HostKeyStorageType | undefined;
    KmsKey?: string | undefined;
}
export interface UpdateHostKeyResponse {
    ServerId: string;
    HostKeyId: string;
}
export interface UpdateProfileRequest {
    ProfileId: string;
    CertificateIds?: string[] | undefined;
}
export interface UpdateProfileResponse {
    ProfileId: string;
}
export interface UpdateServerRequest {
    Certificate?: string | undefined;
    ProtocolDetails?: ProtocolDetails | undefined;
    EndpointDetails?: EndpointDetails | undefined;
    EndpointType?: EndpointType | undefined;
    HostKey?: string | redacted.Redacted<string> | undefined;
    IdentityProviderDetails?: IdentityProviderDetails | undefined;
    LoggingRole?: string | undefined;
    PostAuthenticationLoginBanner?: string | undefined;
    PreAuthenticationLoginBanner?: string | undefined;
    Protocols?: Protocol[] | undefined;
    SecurityPolicyName?: string | undefined;
    ServerId: string;
    WorkflowDetails?: WorkflowDetails | undefined;
    StructuredLogDestinations?: string[] | undefined;
    S3StorageOptions?: S3StorageOptions | undefined;
    IpAddressType?: IpAddressType | undefined;
    IdentityProviderType?: IdentityProviderType | undefined;
}
export interface UpdateServerResponse {
    ServerId: string;
}
export interface UpdateUserRequest {
    HomeDirectory?: string | undefined;
    HomeDirectoryType?: HomeDirectoryType | undefined;
    HomeDirectoryMappings?: HomeDirectoryMapEntry[] | undefined;
    Policy?: string | undefined;
    PosixProfile?: PosixProfile | undefined;
    Role?: string | undefined;
    ServerId: string;
    UserName: string;
}
export interface UpdateUserResponse {
    ServerId: string;
    UserName: string;
}
export interface UpdateWebAppIdentityCenterConfig {
    Role?: string | undefined;
}
export type UpdateWebAppIdentityProviderDetails = {
    IdentityCenterConfig: UpdateWebAppIdentityCenterConfig;
};
export interface UpdateWebAppVpcConfig {
    SubnetIds?: string[] | undefined;
    IpAddressType?: WebAppVpcEndpointIpAddressType | undefined;
}
export type UpdateWebAppEndpointDetails = {
    Vpc: UpdateWebAppVpcConfig;
};
export interface UpdateWebAppRequest {
    WebAppId: string;
    IdentityProviderDetails?: UpdateWebAppIdentityProviderDetails | undefined;
    AccessEndpoint?: string | undefined;
    WebAppUnits?: WebAppUnits | undefined;
    EndpointDetails?: UpdateWebAppEndpointDetails | undefined;
}
export interface UpdateWebAppResponse {
    WebAppId: string;
}
export interface UpdateWebAppCustomizationRequest {
    WebAppId: string;
    Title?: string | undefined;
    LogoFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    FaviconFile?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
}
export interface UpdateWebAppCustomizationResponse {
    WebAppId: string;
}
export type Resource = string;
export type ResourceType = string;
export type ServiceErrorMessage = string;
export type RetryAfterSeconds = string;
export type CreateAccessError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Used by administrators to choose which groups in the directory should have access to upload and download files over the enabled protocols using Transfer Family. For example, a Microsoft Active Directory might contain 50,000 users, but only a small fraction might need the ability to transfer files to the server. An administrator can use `CreateAccess` to limit the access to the correct set of users who need this ability.
 */
export declare const createAccess: API.OperationMethod<CreateAccessRequest & RegionInput, CreateAccessResponse, CreateAccessError, Credentials | HttpClient.HttpClient>;
export type CreateAgreementError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an agreement. An agreement is a bilateral trading partner agreement, or partnership, between an Transfer Family server and an AS2 process. The agreement defines the file and message transfer relationship between the server and the AS2 process. To define an agreement, Transfer Family combines a server, local profile, partner profile, certificate, and other attributes.
 *
 * The partner is identified with the `PartnerProfileId`, and the AS2 process is identified with the `LocalProfileId`.
 *
 * Specify *either* `BaseDirectory` or `CustomDirectories`, but not both. Specifying both causes the command to fail.
 */
export declare const createAgreement: API.OperationMethod<CreateAgreementRequest & RegionInput, CreateAgreementResponse, CreateAgreementError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates the connector, which captures the parameters for a connection for the AS2 or SFTP protocol. For AS2, the connector is required for sending files to an externally hosted AS2 server. For SFTP, the connector is required when sending files to an SFTP server or receiving files from an SFTP server. For more details about connectors, see Configure AS2 connectors and Create SFTP connectors.
 *
 * You must specify exactly one configuration object: either for AS2 (`As2Config`) or SFTP (`SftpConfig`).
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest & RegionInput, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateProfileError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates the local or partner profile to use for AS2 transfers.
 */
export declare const createProfile: API.OperationMethod<CreateProfileRequest & RegionInput, CreateProfileResponse, CreateProfileError, Credentials | HttpClient.HttpClient>;
export type CreateServerError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Instantiates an auto-scaling virtual server based on the selected file transfer protocol in Amazon Web Services. When you make updates to your file transfer protocol-enabled server or when you work with users, use the service-generated `ServerId` property that is assigned to the newly created server.
 */
export declare const createServer: API.OperationMethod<CreateServerRequest & RegionInput, CreateServerResponse, CreateServerError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Creates a user and associates them with an existing file transfer protocol-enabled server. You can only create and associate users with servers that have the `IdentityProviderType` set to `SERVICE_MANAGED`. Using parameters for `CreateUser`, you can specify the user name, set the home directory, store the user's public key, and assign the user's Identity and Access Management (IAM) role. You can also optionally add a session policy, and assign metadata with tags that can be used to group and search for users.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type CreateWebAppError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a web app based on specified parameters, and returns the ID for the new web app. You can configure the web app to be publicly accessible or hosted within a VPC.
 *
 * For more information about using VPC endpoints with Transfer Family, see Create a Transfer Family web app in a VPC.
 */
export declare const createWebApp: API.OperationMethod<CreateWebAppRequest & RegionInput, CreateWebAppResponse, CreateWebAppError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceExistsException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Allows you to create a workflow with specified steps and step details the workflow invokes after file transfer completes. After creating a workflow, you can associate the workflow created with any transfer servers by specifying the `workflow-details` field in `CreateServer` and `UpdateServer` operations.
 */
export declare const createWorkflow: API.OperationMethod<CreateWorkflowRequest & RegionInput, CreateWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Allows you to delete the access specified in the `ServerID` and `ExternalID` parameters.
 */
export declare const deleteAccess: API.OperationMethod<DeleteAccessRequest & RegionInput, DeleteAccessResponse, DeleteAccessError, Credentials | HttpClient.HttpClient>;
export type DeleteAgreementError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Delete the agreement that's specified in the provided `AgreementId`.
 */
export declare const deleteAgreement: API.OperationMethod<DeleteAgreementRequest & RegionInput, DeleteAgreementResponse, DeleteAgreementError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the certificate that's specified in the `CertificateId` parameter.
 */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateRequest & RegionInput, DeleteCertificateResponse, DeleteCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the connector that's specified in the provided `ConnectorId`.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest & RegionInput, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteHostKeyError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes the host key that's specified in the `HostKeyId` parameter.
 */
export declare const deleteHostKey: API.OperationMethod<DeleteHostKeyRequest & RegionInput, DeleteHostKeyResponse, DeleteHostKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteProfileError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the profile that's specified in the `ProfileId` parameter.
 */
export declare const deleteProfile: API.OperationMethod<DeleteProfileRequest & RegionInput, DeleteProfileResponse, DeleteProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteServerError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the file transfer protocol-enabled server that you specify.
 *
 * No response returns from this operation.
 */
export declare const deleteServer: API.OperationMethod<DeleteServerRequest & RegionInput, DeleteServerResponse, DeleteServerError, Credentials | HttpClient.HttpClient>;
export type DeleteSshPublicKeyError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a user's Secure Shell (SSH) public key.
 */
export declare const deleteSshPublicKey: API.OperationMethod<DeleteSshPublicKeyRequest & RegionInput, DeleteSshPublicKeyResponse, DeleteSshPublicKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the user belonging to a file transfer protocol-enabled server you specify.
 *
 * No response returns from this operation.
 *
 * When you delete a user from a server, the user's information is lost.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteWebAppError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the specified web app.
 */
export declare const deleteWebApp: API.OperationMethod<DeleteWebAppRequest & RegionInput, DeleteWebAppResponse, DeleteWebAppError, Credentials | HttpClient.HttpClient>;
export type DeleteWebAppCustomizationError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the `WebAppCustomization` object that corresponds to the web app ID specified.
 */
export declare const deleteWebAppCustomization: API.OperationMethod<DeleteWebAppCustomizationRequest & RegionInput, DeleteWebAppCustomizationResponse, DeleteWebAppCustomizationError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Deletes the specified workflow.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteWorkflowRequest & RegionInput, DeleteWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DescribeAccessError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the access that is assigned to the specific file transfer protocol-enabled server, as identified by its `ServerId` property and its `ExternalId`.
 *
 * The response from this call returns the properties of the access that is associated with the `ServerId` value that was specified.
 */
export declare const describeAccess: API.OperationMethod<DescribeAccessRequest & RegionInput, DescribeAccessResponse, DescribeAccessError, Credentials | HttpClient.HttpClient>;
export type DescribeAgreementError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the agreement that's identified by the `AgreementId`.
 */
export declare const describeAgreement: API.OperationMethod<DescribeAgreementRequest & RegionInput, DescribeAgreementResponse, DescribeAgreementError, Credentials | HttpClient.HttpClient>;
export type DescribeCertificateError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the certificate that's identified by the `CertificateId`.
 *
 * Transfer Family automatically publishes a Amazon CloudWatch metric called `DaysUntilExpiry` for imported certificates. This metric tracks the number of days until the certificate expires based on the `InactiveDate`. The metric is available in the `AWS/Transfer` namespace and includes the `CertificateId` as a dimension.
 */
export declare const describeCertificate: API.OperationMethod<DescribeCertificateRequest & RegionInput, DescribeCertificateResponse, DescribeCertificateError, Credentials | HttpClient.HttpClient>;
export type DescribeConnectorError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the connector that's identified by the `ConnectorId.`
 */
export declare const describeConnector: API.OperationMethod<DescribeConnectorRequest & RegionInput, DescribeConnectorResponse, DescribeConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeExecutionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * You can use `DescribeExecution` to check the details of the execution of the specified workflow.
 *
 * This API call only returns details for in-progress workflows.
 *
 * If you provide an ID for an execution that is not in progress, or if the execution doesn't match the specified workflow ID, you receive a `ResourceNotFound` exception.
 */
export declare const describeExecution: API.OperationMethod<DescribeExecutionRequest & RegionInput, DescribeExecutionResponse, DescribeExecutionError, Credentials | HttpClient.HttpClient>;
export type DescribeHostKeyError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the details of the host key that's specified by the `HostKeyId` and `ServerId`.
 */
export declare const describeHostKey: API.OperationMethod<DescribeHostKeyRequest & RegionInput, DescribeHostKeyResponse, DescribeHostKeyError, Credentials | HttpClient.HttpClient>;
export type DescribeProfileError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns the details of the profile that's specified by the `ProfileId`.
 */
export declare const describeProfile: API.OperationMethod<DescribeProfileRequest & RegionInput, DescribeProfileResponse, DescribeProfileError, Credentials | HttpClient.HttpClient>;
export type DescribeSecurityPolicyError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the security policy that is attached to your server or SFTP connector. The response contains a description of the security policy's properties. For more information about security policies, see Working with security policies for servers or Working with security policies for SFTP connectors.
 */
export declare const describeSecurityPolicy: API.OperationMethod<DescribeSecurityPolicyRequest & RegionInput, DescribeSecurityPolicyResponse, DescribeSecurityPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeServerError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes a file transfer protocol-enabled server that you specify by passing the `ServerId` parameter.
 *
 * The response contains a description of a server's properties. When you set `EndpointType` to VPC, the response will contain the `EndpointDetails`.
 */
export declare const describeServer: API.OperationMethod<DescribeServerRequest & RegionInput, DescribeServerResponse, DescribeServerError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the user assigned to the specific file transfer protocol-enabled server, as identified by its `ServerId` property.
 *
 * The response from this call returns the properties of the user associated with the `ServerId` value that was specified.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest & RegionInput, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type DescribeWebAppError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the web app that's identified by `WebAppId`. The response includes endpoint configuration details such as whether the web app is publicly accessible or VPC hosted.
 *
 * For more information about using VPC endpoints with Transfer Family, see Create a Transfer Family web app in a VPC.
 */
export declare const describeWebApp: API.OperationMethod<DescribeWebAppRequest & RegionInput, DescribeWebAppResponse, DescribeWebAppError, Credentials | HttpClient.HttpClient>;
export type DescribeWebAppCustomizationError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the web app customization object that's identified by `WebAppId`.
 */
export declare const describeWebAppCustomization: API.OperationMethod<DescribeWebAppCustomizationRequest & RegionInput, DescribeWebAppCustomizationResponse, DescribeWebAppCustomizationError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkflowError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Describes the specified workflow.
 */
export declare const describeWorkflow: API.OperationMethod<DescribeWorkflowRequest & RegionInput, DescribeWorkflowResponse, DescribeWorkflowError, Credentials | HttpClient.HttpClient>;
export type ImportCertificateError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Imports the signing and encryption certificates that you need to create local (AS2) profiles and partner profiles.
 *
 * You can import both the certificate and its chain in the `Certificate` parameter.
 *
 * After importing a certificate, Transfer Family automatically creates a Amazon CloudWatch metric called `DaysUntilExpiry` that tracks the number of days until the certificate expires. The metric is based on the `InactiveDate` parameter and is published daily in the `AWS/Transfer` namespace.
 *
 * It can take up to a full day after importing a certificate for Transfer Family to emit the `DaysUntilExpiry` metric to your account.
 *
 * If you use the `Certificate` parameter to upload both the certificate and its chain, don't use the `CertificateChain` parameter.
 *
 * **CloudWatch monitoring**
 *
 * The `DaysUntilExpiry` metric includes the following specifications:
 *
 * - **Units:** Count (days)
 *
 * - **Dimensions:** `CertificateId` (always present), `Description` (if provided during certificate import)
 *
 * - **Statistics:** Minimum, Maximum, Average
 *
 * - **Frequency:** Published daily
 */
export declare const importCertificate: API.OperationMethod<ImportCertificateRequest & RegionInput, ImportCertificateResponse, ImportCertificateError, Credentials | HttpClient.HttpClient>;
export type ImportHostKeyError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Adds a host key to the server that's specified by the `ServerId` parameter.
 */
export declare const importHostKey: API.OperationMethod<ImportHostKeyRequest & RegionInput, ImportHostKeyResponse, ImportHostKeyError, Credentials | HttpClient.HttpClient>;
export type ImportSshPublicKeyError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Adds a Secure Shell (SSH) public key to a Transfer Family user identified by a `UserName` value assigned to the specific file transfer protocol-enabled server, identified by `ServerId`.
 *
 * The response returns the `UserName` value, the `ServerId` value, and the name of the `SshPublicKeyId`.
 */
export declare const importSshPublicKey: API.OperationMethod<ImportSshPublicKeyRequest & RegionInput, ImportSshPublicKeyResponse, ImportSshPublicKeyError, Credentials | HttpClient.HttpClient>;
export type ListAccessesError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the details for all the accesses you have on your server.
 */
export declare const listAccesses: API.PaginatedOperationMethod<ListAccessesRequest & RegionInput, ListAccessesResponse, ListAccessesError, Credentials | HttpClient.HttpClient, ListedAccess>;
export type ListAgreementsError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of the agreements for the server that's identified by the `ServerId` that you supply. If you want to limit the results to a certain number, supply a value for the `MaxResults` parameter. If you ran the command previously and received a value for `NextToken`, you can supply that value to continue listing agreements from where you left off.
 */
export declare const listAgreements: API.PaginatedOperationMethod<ListAgreementsRequest & RegionInput, ListAgreementsResponse, ListAgreementsError, Credentials | HttpClient.HttpClient, ListedAgreement>;
export type ListCertificatesError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of the current certificates that have been imported into Transfer Family. If you want to limit the results to a certain number, supply a value for the `MaxResults` parameter. If you ran the command previously and received a value for the `NextToken` parameter, you can supply that value to continue listing certificates from where you left off.
 */
export declare const listCertificates: API.PaginatedOperationMethod<ListCertificatesRequest & RegionInput, ListCertificatesResponse, ListCertificatesError, Credentials | HttpClient.HttpClient, ListedCertificate>;
export type ListConnectorsError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the connectors for the specified Region.
 */
export declare const listConnectors: API.PaginatedOperationMethod<ListConnectorsRequest & RegionInput, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient, ListedConnector>;
export type ListExecutionsError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all in-progress executions for the specified workflow.
 *
 * If the specified workflow ID cannot be found, `ListExecutions` returns a `ResourceNotFound` exception.
 */
export declare const listExecutions: API.PaginatedOperationMethod<ListExecutionsRequest & RegionInput, ListExecutionsResponse, ListExecutionsError, Credentials | HttpClient.HttpClient, ListedExecution>;
export type ListFileTransferResultsError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns real-time updates and detailed information on the status of each individual file being transferred in a specific file transfer operation. You specify the file transfer by providing its `ConnectorId` and its `TransferId`.
 *
 * File transfer results are available up to 7 days after an operation has been requested.
 */
export declare const listFileTransferResults: API.PaginatedOperationMethod<ListFileTransferResultsRequest & RegionInput, ListFileTransferResultsResponse, ListFileTransferResultsError, Credentials | HttpClient.HttpClient, ConnectorFileTransferResult>;
export type ListHostKeysError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of host keys for the server that's specified by the `ServerId` parameter.
 */
export declare const listHostKeys: API.OperationMethod<ListHostKeysRequest & RegionInput, ListHostKeysResponse, ListHostKeysError, Credentials | HttpClient.HttpClient>;
export type ListProfilesError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Returns a list of the profiles for your system. If you want to limit the results to a certain number, supply a value for the `MaxResults` parameter. If you ran the command previously and received a value for `NextToken`, you can supply that value to continue listing profiles from where you left off.
 */
export declare const listProfiles: API.PaginatedOperationMethod<ListProfilesRequest & RegionInput, ListProfilesResponse, ListProfilesError, Credentials | HttpClient.HttpClient, ListedProfile>;
export type ListSecurityPoliciesError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the security policies that are attached to your servers and SFTP connectors. For more information about security policies, see Working with security policies for servers or Working with security policies for SFTP connectors.
 */
export declare const listSecurityPolicies: API.PaginatedOperationMethod<ListSecurityPoliciesRequest & RegionInput, ListSecurityPoliciesResponse, ListSecurityPoliciesError, Credentials | HttpClient.HttpClient, SecurityPolicyName>;
export type ListServersError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the file transfer protocol-enabled servers that are associated with your Amazon Web Services account.
 */
export declare const listServers: API.PaginatedOperationMethod<ListServersRequest & RegionInput, ListServersResponse, ListServersError, Credentials | HttpClient.HttpClient, ListedServer>;
export type ListTagsForResourceError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all of the tags associated with the Amazon Resource Name (ARN) that you specify. The resource can be a user, server, or role.
 */
export declare const listTagsForResource: API.PaginatedOperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient, Tag>;
export type ListUsersError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Lists the users for a file transfer protocol-enabled server that you specify by passing the `ServerId` parameter.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, ListedUser>;
export type ListWebAppsError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists all web apps associated with your Amazon Web Services account for your current region. The response includes the endpoint type for each web app, showing whether it is publicly accessible or VPC hosted.
 *
 * For more information about using VPC endpoints with Transfer Family, see Create a Transfer Family web app in a VPC.
 */
export declare const listWebApps: API.PaginatedOperationMethod<ListWebAppsRequest & RegionInput, ListWebAppsResponse, ListWebAppsError, Credentials | HttpClient.HttpClient, ListedWebApp>;
export type ListWorkflowsError = InternalServiceError | InvalidNextTokenException | InvalidRequestException | ServiceUnavailableException | CommonErrors;
/**
 * Lists all workflows associated with your Amazon Web Services account for your current region.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest & RegionInput, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, ListedWorkflow>;
export type SendWorkflowStepStateError = AccessDeniedException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Sends a callback for asynchronous custom steps.
 *
 * The `ExecutionId`, `WorkflowId`, and `Token` are passed to the target resource during execution of a custom step of a workflow. You must include those with their callback as well as providing a status.
 */
export declare const sendWorkflowStepState: API.OperationMethod<SendWorkflowStepStateRequest & RegionInput, SendWorkflowStepStateResponse, SendWorkflowStepStateError, Credentials | HttpClient.HttpClient>;
export type StartDirectoryListingError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Retrieves a list of the contents of a directory from a remote SFTP server. You specify the connector ID, the output path, and the remote directory path. You can also specify the optional `MaxItems` value to control the maximum number of items that are listed from the remote directory. This API returns a list of all files and directories in the remote directory (up to the maximum value), but does not return files or folders in sub-directories. That is, it only returns a list of files and directories one-level deep.
 *
 * After you receive the listing file, you can provide the files that you want to transfer to the `RetrieveFilePaths` parameter of the `StartFileTransfer` API call.
 *
 * The naming convention for the output file is ` *connector-ID*-*listing-ID*.json`. The output file contains the following information:
 *
 * - `filePath`: the complete path of a remote file, relative to the directory of the listing request for your SFTP connector on the remote server.
 *
 * - `modifiedTimestamp`: the last time the file was modified, in UTC time format. This field is optional. If the remote file attributes don't contain a timestamp, it is omitted from the file listing.
 *
 * - `size`: the size of the file, in bytes. This field is optional. If the remote file attributes don't contain a file size, it is omitted from the file listing.
 *
 * - `path`: the complete path of a remote directory, relative to the directory of the listing request for your SFTP connector on the remote server.
 *
 * - `truncated`: a flag indicating whether the list output contains all of the items contained in the remote directory or not. If your `Truncated` output value is true, you can increase the value provided in the optional `max-items` input attribute to be able to list more items (up to the maximum allowed list size of 200,000 items).
 */
export declare const startDirectoryListing: API.OperationMethod<StartDirectoryListingRequest & RegionInput, StartDirectoryListingResponse, StartDirectoryListingError, Credentials | HttpClient.HttpClient>;
export type StartFileTransferError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Begins a file transfer between local Amazon Web Services storage and a remote AS2 or SFTP server.
 *
 * - For an AS2 connector, you specify the `ConnectorId` and one or more `SendFilePaths` to identify the files you want to transfer.
 *
 * - For an SFTP connector, the file transfer can be either outbound or inbound. In both cases, you specify the `ConnectorId`. Depending on the direction of the transfer, you also specify the following items:
 *
 * - If you are transferring file from a partner's SFTP server to Amazon Web Services storage, you specify one or more `RetrieveFilePaths` to identify the files you want to transfer, and a `LocalDirectoryPath` to specify the destination folder.
 *
 * - If you are transferring file to a partner's SFTP server from Amazon Web Services storage, you specify one or more `SendFilePaths` to identify the files you want to transfer, and a `RemoteDirectoryPath` to specify the destination folder.
 */
export declare const startFileTransfer: API.OperationMethod<StartFileTransferRequest & RegionInput, StartFileTransferResponse, StartFileTransferError, Credentials | HttpClient.HttpClient>;
export type StartRemoteDeleteError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a file or directory on the remote SFTP server.
 */
export declare const startRemoteDelete: API.OperationMethod<StartRemoteDeleteRequest & RegionInput, StartRemoteDeleteResponse, StartRemoteDeleteError, Credentials | HttpClient.HttpClient>;
export type StartRemoteMoveError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Moves or renames a file or directory on the remote SFTP server.
 */
export declare const startRemoteMove: API.OperationMethod<StartRemoteMoveRequest & RegionInput, StartRemoteMoveResponse, StartRemoteMoveError, Credentials | HttpClient.HttpClient>;
export type StartServerError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Changes the state of a file transfer protocol-enabled server from `OFFLINE` to `ONLINE`. It has no impact on a server that is already `ONLINE`. An `ONLINE` server can accept and process file transfer jobs.
 *
 * The state of `STARTING` indicates that the server is in an intermediate state, either not fully able to respond, or not fully online. The values of `START_FAILED` can indicate an error condition.
 *
 * No response is returned from this call.
 */
export declare const startServer: API.OperationMethod<StartServerRequest & RegionInput, StartServerResponse, StartServerError, Credentials | HttpClient.HttpClient>;
export type StopServerError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Changes the state of a file transfer protocol-enabled server from `ONLINE` to `OFFLINE`. An `OFFLINE` server cannot accept and process file transfer jobs. Information tied to your server, such as server and user properties, are not affected by stopping your server.
 *
 * Stopping the server does not reduce or impact your file transfer protocol endpoint billing; you must delete the server to stop being billed.
 *
 * The state of `STOPPING` indicates that the server is in an intermediate state, either not fully able to respond, or not fully offline. The values of `STOP_FAILED` can indicate an error condition.
 *
 * No response is returned from this call.
 */
export declare const stopServer: API.OperationMethod<StopServerRequest & RegionInput, StopServerResponse, StopServerError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Attaches a key-value pair to a resource, as identified by its Amazon Resource Name (ARN). Resources are users, servers, roles, and other entities.
 *
 * There is no response returned from this call.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type TestConnectionError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Tests whether your SFTP connector is set up successfully. We highly recommend that you call this operation to test your ability to transfer files between local Amazon Web Services storage and a trading partner's SFTP server.
 */
export declare const testConnection: API.OperationMethod<TestConnectionRequest & RegionInput, TestConnectionResponse, TestConnectionError, Credentials | HttpClient.HttpClient>;
export type TestIdentityProviderError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * If the `IdentityProviderType` of a file transfer protocol-enabled server is `AWS_DIRECTORY_SERVICE` or `API_Gateway`, tests whether your identity provider is set up successfully. We highly recommend that you call this operation to test your authentication method as soon as you create your server. By doing so, you can troubleshoot issues with the identity provider integration to ensure that your users can successfully use the service.
 *
 * The `ServerId` and `UserName` parameters are required. The `ServerProtocol`, `SourceIp`, and `UserPassword` are all optional.
 *
 * Note the following:
 *
 * - You cannot use `TestIdentityProvider` if the `IdentityProviderType` of your server is `SERVICE_MANAGED`.
 *
 * - `TestIdentityProvider` does not work with keys: it only accepts passwords.
 *
 * - `TestIdentityProvider` can test the password operation for a custom Identity Provider that handles keys and passwords.
 *
 * - If you provide any incorrect values for any parameters, the `Response` field is empty.
 *
 * - If you provide a server ID for a server that uses service-managed users, you get an error:
 *
 * ` An error occurred (InvalidRequestException) when calling the TestIdentityProvider operation: s-*server-ID* not configured for external auth `
 *
 * - If you enter a Server ID for the `--server-id` parameter that does not identify an actual Transfer server, you receive the following error:
 *
 * `An error occurred (ResourceNotFoundException) when calling the TestIdentityProvider operation: Unknown server`.
 *
 * It is possible your sever is in a different region. You can specify a region by adding the following: `--region region-code`, such as `--region us-east-2` to specify a server in **US East (Ohio)**.
 */
export declare const testIdentityProvider: API.OperationMethod<TestIdentityProviderRequest & RegionInput, TestIdentityProviderResponse, TestIdentityProviderError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | CommonErrors;
/**
 * Detaches a key-value pair from a resource, as identified by its Amazon Resource Name (ARN). Resources are users, servers, roles, and other entities.
 *
 * No response is returned from this call.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccessError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Allows you to update parameters for the access specified in the `ServerID` and `ExternalID` parameters.
 */
export declare const updateAccess: API.OperationMethod<UpdateAccessRequest & RegionInput, UpdateAccessResponse, UpdateAccessError, Credentials | HttpClient.HttpClient>;
export type UpdateAgreementError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates some of the parameters for an existing agreement. Provide the `AgreementId` and the `ServerId` for the agreement that you want to update, along with the new values for the parameters to update.
 *
 * Specify *either* `BaseDirectory` or `CustomDirectories`, but not both. Specifying both causes the command to fail.
 *
 * If you update an agreement from using base directory to custom directories, the base directory is no longer used. Similarly, if you change from custom directories to a base directory, the custom directories are no longer used.
 */
export declare const updateAgreement: API.OperationMethod<UpdateAgreementRequest & RegionInput, UpdateAgreementResponse, UpdateAgreementError, Credentials | HttpClient.HttpClient>;
export type UpdateCertificateError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the active and inactive dates for a certificate.
 */
export declare const updateCertificate: API.OperationMethod<UpdateCertificateRequest & RegionInput, UpdateCertificateResponse, UpdateCertificateError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates some of the parameters for an existing connector. Provide the `ConnectorId` for the connector that you want to update, along with the new values for the parameters to update.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest & RegionInput, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateHostKeyError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the host key that's specified by the `ServerId` and `HostKeyId` parameters. You can update the description of the host key, change where the host key is stored by specifying the `StorageType`, and specify the KMS key used to encrypt the host key when it's stored in Secrets Manager.
 *
 * To change a host key's storage type from `SERVICE_MANAGED` to `SECRETS_MANAGER`, you must have the `transfer:ExportHostKey` permission. `transfer:ExportHostKey` is a permission-only action that has no corresponding API operation.
 */
export declare const updateHostKey: API.OperationMethod<UpdateHostKeyRequest & RegionInput, UpdateHostKeyResponse, UpdateHostKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateProfileError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates some of the parameters for an existing profile. Provide the `ProfileId` for the profile that you want to update, along with the new values for the parameters to update.
 */
export declare const updateProfile: API.OperationMethod<UpdateProfileRequest & RegionInput, UpdateProfileResponse, UpdateProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateServerError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceExistsException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the file transfer protocol-enabled server's properties after that server has been created.
 *
 * The `UpdateServer` call returns the `ServerId` of the server you updated.
 */
export declare const updateServer: API.OperationMethod<UpdateServerRequest & RegionInput, UpdateServerResponse, UpdateServerError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = InternalServiceError | InvalidRequestException | ResourceNotFoundException | ServiceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Assigns new properties to a user. Parameters you pass modify any or all of the following: the home directory, role, and policy for the `UserName` and `ServerId` you specify.
 *
 * The response returns the `ServerId` and the `UserName` for the updated user.
 *
 * In the console, you can select *Restricted* when you create or update a user. This ensures that the user can't access anything outside of their home directory. The programmatic way to configure this behavior is to update the user. Set their `HomeDirectoryType` to `LOGICAL`, and specify `HomeDirectoryMappings` with `Entry` as root (`/`) and `Target` as their home directory.
 *
 * For example, if the user's home directory is `/test/admin-user`, the following command updates the user so that their configuration in the console shows the *Restricted* flag as selected.
 *
 * ` aws transfer update-user --server-id <server-id> --user-name admin-user --home-directory-type LOGICAL --home-directory-mappings "[{\"Entry\":\"/\", \"Target\":\"/test/admin-user\"}]"`
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export type UpdateWebAppError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns new properties to a web app. You can modify the access point, identity provider details, endpoint configuration, and the web app units.
 *
 * For more information about using VPC endpoints with Transfer Family, see Create a Transfer Family web app in a VPC.
 */
export declare const updateWebApp: API.OperationMethod<UpdateWebAppRequest & RegionInput, UpdateWebAppResponse, UpdateWebAppError, Credentials | HttpClient.HttpClient>;
export type UpdateWebAppCustomizationError = AccessDeniedException | ConflictException | InternalServiceError | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns new customization properties to a web app. You can modify the icon file, logo file, and title.
 */
export declare const updateWebAppCustomization: API.OperationMethod<UpdateWebAppCustomizationRequest & RegionInput, UpdateWebAppCustomizationResponse, UpdateWebAppCustomizationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=transfer.d.ts.map