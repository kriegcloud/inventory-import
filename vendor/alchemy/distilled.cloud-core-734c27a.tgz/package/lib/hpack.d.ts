/**
 * HPACK (RFC 7541), the header compression of HTTP/2, for a client that
 * speaks HTTP/2 without a platform implementation
 * (`grpc-transport-cloudflare-http2`).
 *
 * {@link makeDecoder} reads everything a server may send: the static and
 * dynamic tables, every literal form, and Huffman-coded strings.
 * {@link encode} writes the simplest valid form, each field as a literal
 * with no indexing and no Huffman coding, so a connection keeps no encoder
 * state.
 */
/** A header block that breaks RFC 7541. HTTP/2 treats it as a connection error. */
export declare class HpackError extends Error {
}
/** A header field: a lowercase name and its value. */
export type HeaderField = readonly [name: string, value: string];
/** Decode a Huffman-coded string (RFC 7541 section 5.2). */
export declare const huffmanDecode: (bytes: Uint8Array) => Uint8Array;
/** Reads the header blocks of one connection, in the order they arrive. */
export interface HpackDecoder {
    /** The fields of one complete header block. */
    decode(block: Uint8Array): HeaderField[];
}
/**
 * A decoder for one connection. `maxTableSize` is the dynamic table size
 * this end allows (`SETTINGS_HEADER_TABLE_SIZE`, 4096 unless set).
 */
export declare const makeDecoder: (maxTableSize?: number) => HpackDecoder;
/**
 * A header block for `fields`, each a literal without indexing (RFC 7541
 * section 6.2.2). Names must be lowercase, pseudo-headers first.
 */
export declare const encode: (fields: ReadonlyArray<HeaderField>) => Uint8Array;
//# sourceMappingURL=hpack.d.ts.map