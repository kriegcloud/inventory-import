import type { Request } from "@distilled.cloud/s3/client/request";
import { CryptoError } from "@distilled.cloud/s3/SigV4";
/**
 * Legacy Signature Version 2 request signing, used by SimpleDB only. It is
 * reached through the `AwsAuthSigv2` trait, so programs that do not use
 * SimpleDB do not bundle it.
 */
import * as Effect from "effect/Effect";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import type { ResolvedCredentials } from "./credentials-service.ts";
/**
 * Legacy Signature Version 2 (SimpleDB is the sole remaining SigV2-only
 * service). The signature is an HMAC-SHA256 over the sorted,
 * RFC3986-encoded form parameters and travels IN the form-encoded body --
 * there is no Authorization header. The classic endpoint rejects SigV4
 * with `AuthFailure: access credentials are missing`.
 */
export declare const signV2: (resolvedRequest: Request, endpoint: string, fullPath: string, credentials: ResolvedCredentials) => Effect.Effect<HttpClientRequest.HttpClientRequest, CryptoError>;
//# sourceMappingURL=sigv2.d.ts.map