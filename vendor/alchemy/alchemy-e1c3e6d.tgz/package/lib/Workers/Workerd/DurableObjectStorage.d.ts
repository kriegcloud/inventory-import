import type * as cf from "@cloudflare/workers-types";
import * as Effect from "effect/Effect";
import * as Stream from "effect/Stream";
import type { RuntimeContext } from "../../RuntimeContext.ts";
declare const DurableObjectStorageError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DurableObjectStorageError";
} & Readonly<A>;
/** A native transaction failure or invalid use of a transaction's owner. */
export declare class DurableObjectStorageError extends DurableObjectStorageError_base<{
    readonly operation: string;
    readonly message: string;
    readonly cause?: unknown;
}> {
}
export type SqlStorageValue = cf.SqlStorageValue;
export interface SqlCursor<T extends Record<string, SqlStorageValue>> extends Stream.Stream<T> {
    next(): Effect.Effect<{
        done?: false;
        value: T;
    } | {
        done: true;
        value?: never;
    }, never, RuntimeContext>;
    toArray(): Effect.Effect<T[], never, RuntimeContext>;
    one(): Effect.Effect<T, never, RuntimeContext>;
    raw<U extends SqlStorageValue[]>(): Stream.Stream<U, never, RuntimeContext>;
    readonly columnNames: string[];
    readonly rowsRead: Effect.Effect<number, never, RuntimeContext>;
    readonly rowsWritten: Effect.Effect<number, never, RuntimeContext>;
}
export interface SqlStorage {
    /**
     * The raw underlying Cloudflare SqlStorage binding.
     *
     * Use this when you need direct access for libraries that already support
     * Cloudflare Durable Object SQLite storage.
     */
    readonly raw: cf.SqlStorage;
    exec<T extends Record<string, SqlStorageValue>>(query: string, ...bindings: any[]): Effect.Effect<SqlCursor<T>, never, RuntimeContext>;
    readonly databaseSize: number;
}
export interface DurableObjectTransaction {
    get<T = unknown>(key: string, options?: cf.DurableObjectGetOptions): Effect.Effect<T | undefined, never, RuntimeContext>;
    get<T = unknown>(keys: string[], options?: cf.DurableObjectGetOptions): Effect.Effect<Map<string, T>, never, RuntimeContext>;
    list<T = unknown>(options?: cf.DurableObjectListOptions): Effect.Effect<Map<string, T>, never, RuntimeContext>;
    put<T>(key: string, value: T, options?: cf.DurableObjectPutOptions): Effect.Effect<void, never, RuntimeContext>;
    put<T>(entries: Record<string, T>, options?: cf.DurableObjectPutOptions): Effect.Effect<void, never, RuntimeContext>;
    delete(key: string, options?: cf.DurableObjectPutOptions): Effect.Effect<boolean, never, RuntimeContext>;
    delete(keys: string[], options?: cf.DurableObjectPutOptions): Effect.Effect<number, never, RuntimeContext>;
    rollback(): Effect.Effect<void, never, RuntimeContext>;
    getAlarm(options?: cf.DurableObjectGetAlarmOptions): Effect.Effect<number | null, never, RuntimeContext>;
    setAlarm(scheduledTime: number | Date, options?: cf.DurableObjectSetAlarmOptions): Effect.Effect<void, never, RuntimeContext>;
    deleteAlarm(options?: cf.DurableObjectSetAlarmOptions): Effect.Effect<void, never, RuntimeContext>;
}
export interface DurableObjectStorage {
    get<T = unknown>(key: string, options?: cf.DurableObjectGetOptions): Effect.Effect<T | undefined, never, RuntimeContext>;
    get<T = unknown>(keys: string[], options?: cf.DurableObjectGetOptions): Effect.Effect<Map<string, T>, never, RuntimeContext>;
    list<T = unknown>(options?: cf.DurableObjectListOptions): Effect.Effect<Map<string, T>, never, RuntimeContext>;
    put<T>(key: string, value: T, options?: cf.DurableObjectPutOptions): Effect.Effect<void, never, RuntimeContext>;
    put<T>(entries: Record<string, T>, options?: cf.DurableObjectPutOptions): Effect.Effect<void, never, RuntimeContext>;
    delete(key: string, options?: cf.DurableObjectPutOptions): Effect.Effect<boolean, never, RuntimeContext>;
    delete(keys: string[], options?: cf.DurableObjectPutOptions): Effect.Effect<number, never, RuntimeContext>;
    deleteAll(options?: cf.DurableObjectPutOptions): Effect.Effect<void, never, RuntimeContext>;
    /**
     * Run an Effect inside a native storage transaction with the caller's context.
     * On SQLite-backed storage, SQL, KV, and alarm writes to this storage commit
     * together. Typed failures, defects, and interruption roll back the transaction.
     * Interruption waits for the callback fiber and native rollback to finish.
     * A call inside another transaction starts a nested one: if it fails or rolls
     * back, only its own writes are undone, and the outer transaction continues.
     * Transaction handles cannot be used by another fiber or after the callback
     * finishes.
     */
    transaction<A, E = never, R = never>(effect: Effect.Effect<A, E, R>): Effect.Effect<A, E | DurableObjectStorageError, R | RuntimeContext>;
    transaction<A, E = never, R = never>(closure: (txn: DurableObjectTransaction) => Effect.Effect<A, E, R>): Effect.Effect<A, E | DurableObjectStorageError, R | RuntimeContext>;
    getAlarm(options?: cf.DurableObjectGetAlarmOptions): Effect.Effect<number | null, never, RuntimeContext>;
    setAlarm(scheduledTime: number | Date, options?: cf.DurableObjectSetAlarmOptions): Effect.Effect<void, never, RuntimeContext>;
    deleteAlarm(options?: cf.DurableObjectSetAlarmOptions): Effect.Effect<void, never, RuntimeContext>;
    sync(): Effect.Effect<void, never, RuntimeContext>;
    sql: SqlStorage;
    kv: cf.SyncKvStorage;
    getCurrentBookmark(): Effect.Effect<string, never, RuntimeContext>;
    getBookmarkForTime(timestamp: number | Date): Effect.Effect<string, never, RuntimeContext>;
    onNextSessionRestoreBookmark(bookmark: string): Effect.Effect<string, never, RuntimeContext>;
}
export declare const fromDurableObjectTransaction: (txn: cf.DurableObjectTransaction) => DurableObjectTransaction;
export declare const fromDurableObjectStorage: (storage: cf.DurableObjectStorage) => DurableObjectStorage;
export {};
//# sourceMappingURL=DurableObjectStorage.d.ts.map