import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly RequestId: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly ResourceType: any;
    readonly ResourceId: any;
    readonly Reason: any;
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly RequestId: any;
    readonly RetryAfterSeconds: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly RequestId: any;
    readonly Reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type IdentityStoreId = string;
export type GroupDisplayName = string | redacted.Redacted<string>;
export type SensitiveStringType = string | redacted.Redacted<string>;
export interface CreateGroupRequest {
    IdentityStoreId: string;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export type ResourceId = string;
export type ResourceArn = string;
export type ResourceRevision = string;
export interface CreateGroupResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
}
export type MemberId = {
    UserId: string;
};
export interface CreateGroupMembershipRequest {
    IdentityStoreId: string;
    GroupId: string;
    MemberId: MemberId;
}
export interface CreateGroupMembershipResponse {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
}
export type UserName = string | redacted.Redacted<string>;
export interface Name {
    Formatted?: string | redacted.Redacted<string> | undefined;
    FamilyName?: string | redacted.Redacted<string> | undefined;
    GivenName?: string | redacted.Redacted<string> | undefined;
    MiddleName?: string | redacted.Redacted<string> | undefined;
    HonorificPrefix?: string | redacted.Redacted<string> | undefined;
    HonorificSuffix?: string | redacted.Redacted<string> | undefined;
}
export interface Email {
    Value?: string | redacted.Redacted<string> | undefined;
    Type?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type Emails = Email[];
export interface Address {
    StreetAddress?: string | redacted.Redacted<string> | undefined;
    Locality?: string | redacted.Redacted<string> | undefined;
    Region?: string | redacted.Redacted<string> | undefined;
    PostalCode?: string | redacted.Redacted<string> | undefined;
    Country?: string | redacted.Redacted<string> | undefined;
    Formatted?: string | redacted.Redacted<string> | undefined;
    Type?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type Addresses = Address[];
export interface PhoneNumber {
    Value?: string | redacted.Redacted<string> | undefined;
    Type?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type PhoneNumbers = PhoneNumber[];
export interface Photo {
    Value: string | redacted.Redacted<string>;
    Type?: string | redacted.Redacted<string> | undefined;
    Display?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type Photos = Photo[];
export interface Role {
    Value?: string | redacted.Redacted<string> | undefined;
    Type?: string | redacted.Redacted<string> | undefined;
    Primary?: boolean | undefined;
}
export type Roles = Role[];
export type ExtensionName = string;
export type AttributeValue = unknown;
export type Extensions = {
    [key: string]: any | undefined;
};
export interface CreateUserRequest {
    IdentityStoreId: string;
    UserName?: string | redacted.Redacted<string> | undefined;
    Name?: Name | undefined;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    NickName?: string | redacted.Redacted<string> | undefined;
    ProfileUrl?: string | redacted.Redacted<string> | undefined;
    Emails?: Email[] | undefined;
    Addresses?: Address[] | undefined;
    PhoneNumbers?: PhoneNumber[] | undefined;
    UserType?: string | redacted.Redacted<string> | undefined;
    Title?: string | redacted.Redacted<string> | undefined;
    PreferredLanguage?: string | redacted.Redacted<string> | undefined;
    Locale?: string | redacted.Redacted<string> | undefined;
    Timezone?: string | redacted.Redacted<string> | undefined;
    Photos?: Photo[] | undefined;
    Website?: string | redacted.Redacted<string> | undefined;
    Birthdate?: string | redacted.Redacted<string> | undefined;
    Roles?: Role[] | undefined;
    Extensions?: {
        [key: string]: any | undefined;
    } | undefined;
}
export interface CreateUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
}
export interface DeleteGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
    Revision?: string | undefined;
}
export interface DeleteGroupResponse {
}
export interface DeleteGroupMembershipRequest {
    IdentityStoreId: string;
    MembershipId: string;
}
export interface DeleteGroupMembershipResponse {
}
export interface DeleteUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Revision?: string | undefined;
}
export interface DeleteUserResponse {
}
export interface DescribeGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
}
export type ExternalIdIssuer = string | redacted.Redacted<string>;
export type ExternalIdIdentifier = string | redacted.Redacted<string>;
export interface ExternalId {
    Issuer: string | redacted.Redacted<string>;
    Id: string | redacted.Redacted<string>;
}
export type ExternalIds = ExternalId[];
export type StringType = string;
export interface DescribeGroupResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    ExternalIds?: ExternalId[] | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    UpdatedBy?: string | undefined;
}
export interface DescribeGroupMembershipRequest {
    IdentityStoreId: string;
    MembershipId: string;
}
export interface DescribeGroupMembershipResponse {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
    GroupId: string;
    MemberId: MemberId;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    UpdatedBy?: string | undefined;
}
export interface DescribeIdentityStoreRequest {
    IdentityStoreId: string;
}
export type IdentityStoreArn = string;
export type VpcArn = string;
export type VpcArnList = string[];
export type IpCidrType = string;
export type IpCidrList = string[];
export interface NetworkConfigurationDetails {
    VpceAccessRequired: boolean;
    ApiRestrictSourceVpcs?: string[] | undefined;
    ApiAllowSourceIps?: string[] | undefined;
    ScimAllowSourceIps?: string[] | undefined;
}
export interface DescribeIdentityStoreResponse {
    IdentityStoreId: string;
    IdentityStoreArn: string;
    NetworkConfiguration?: NetworkConfigurationDetails | undefined;
}
export type ExtensionNames = string[];
export interface DescribeUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Extensions?: string[] | undefined;
}
export type UserStatus = "ENABLED" | "DISABLED" | (string & {});
export interface DescribeUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
    UserName?: string | redacted.Redacted<string> | undefined;
    ExternalIds?: ExternalId[] | undefined;
    Name?: Name | undefined;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    NickName?: string | redacted.Redacted<string> | undefined;
    ProfileUrl?: string | redacted.Redacted<string> | undefined;
    Emails?: Email[] | undefined;
    Addresses?: Address[] | undefined;
    PhoneNumbers?: PhoneNumber[] | undefined;
    UserType?: string | redacted.Redacted<string> | undefined;
    Title?: string | redacted.Redacted<string> | undefined;
    PreferredLanguage?: string | redacted.Redacted<string> | undefined;
    Locale?: string | redacted.Redacted<string> | undefined;
    Timezone?: string | redacted.Redacted<string> | undefined;
    UserStatus?: UserStatus | undefined;
    Photos?: Photo[] | undefined;
    Website?: string | redacted.Redacted<string> | undefined;
    Birthdate?: string | redacted.Redacted<string> | undefined;
    Roles?: Role[] | undefined;
    CreatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    UpdatedAt?: Date | undefined;
    UpdatedBy?: string | undefined;
    Extensions?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type AttributePath = string;
export interface UniqueAttribute {
    AttributePath: string;
    AttributeValue: any;
}
export type AlternateIdentifier = {
    ExternalId: ExternalId;
    UniqueAttribute?: undefined;
} | {
    ExternalId?: undefined;
    UniqueAttribute: UniqueAttribute;
};
export interface GetGroupIdRequest {
    IdentityStoreId: string;
    AlternateIdentifier: AlternateIdentifier;
}
export interface GetGroupIdResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
}
export interface GetGroupMembershipIdRequest {
    IdentityStoreId: string;
    GroupId: string;
    MemberId: MemberId;
}
export interface GetGroupMembershipIdResponse {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
}
export interface GetUserIdRequest {
    IdentityStoreId: string;
    AlternateIdentifier: AlternateIdentifier;
}
export interface GetUserIdResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
}
export type GroupIds = string[];
export interface IsMemberInGroupsRequest {
    IdentityStoreId: string;
    MemberId: MemberId;
    GroupIds: string[];
}
export interface GroupMembershipExistenceResult {
    GroupId?: string | undefined;
    MemberId?: MemberId | undefined;
    MembershipExists?: boolean | undefined;
}
export type GroupMembershipExistenceResults = GroupMembershipExistenceResult[];
export interface IsMemberInGroupsResponse {
    Results: GroupMembershipExistenceResult[];
}
export type MaxResults = number;
export type NextToken = string;
export interface ListGroupMembershipsRequest {
    IdentityStoreId: string;
    GroupId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface GroupMembership {
    IdentityStoreId: string;
    MembershipId: string;
    MembershipArn: string;
    GroupId?: string | undefined;
    MemberId?: MemberId | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    UpdatedBy?: string | undefined;
}
export type GroupMemberships = GroupMembership[];
export interface ListGroupMembershipsResponse {
    GroupMemberships: GroupMembership[];
    NextToken?: string | undefined;
}
export interface ListGroupMembershipsForMemberRequest {
    IdentityStoreId: string;
    MemberId: MemberId;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListGroupMembershipsForMemberResponse {
    GroupMemberships: GroupMembership[];
    NextToken?: string | undefined;
}
export interface Filter {
    AttributePath: string;
    AttributeValue: string | redacted.Redacted<string>;
}
export type Filters = Filter[];
export interface ListGroupsRequest {
    IdentityStoreId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface Group {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    ExternalIds?: ExternalId[] | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    UpdatedBy?: string | undefined;
}
export type Groups = Group[];
export interface ListGroupsResponse {
    Groups: Group[];
    NextToken?: string | undefined;
}
export interface ListIdentityStoresRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface IdentityStore {
    IdentityStoreId: string;
    IdentityStoreArn: string;
}
export type IdentityStores = IdentityStore[];
export interface ListIdentityStoresResponse {
    IdentityStores: IdentityStore[];
    NextToken?: string | undefined;
}
export interface ListUsersRequest {
    IdentityStoreId: string;
    Extensions?: string[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface User {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
    UserName?: string | redacted.Redacted<string> | undefined;
    ExternalIds?: ExternalId[] | undefined;
    Name?: Name | undefined;
    DisplayName?: string | redacted.Redacted<string> | undefined;
    NickName?: string | redacted.Redacted<string> | undefined;
    ProfileUrl?: string | redacted.Redacted<string> | undefined;
    Emails?: Email[] | undefined;
    Addresses?: Address[] | undefined;
    PhoneNumbers?: PhoneNumber[] | undefined;
    UserType?: string | redacted.Redacted<string> | undefined;
    Title?: string | redacted.Redacted<string> | undefined;
    PreferredLanguage?: string | redacted.Redacted<string> | undefined;
    Locale?: string | redacted.Redacted<string> | undefined;
    Timezone?: string | redacted.Redacted<string> | undefined;
    UserStatus?: UserStatus | undefined;
    Photos?: Photo[] | undefined;
    Website?: string | redacted.Redacted<string> | undefined;
    Birthdate?: string | redacted.Redacted<string> | undefined;
    Roles?: Role[] | undefined;
    CreatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    UpdatedAt?: Date | undefined;
    UpdatedBy?: string | undefined;
    Extensions?: {
        [key: string]: any | undefined;
    } | undefined;
}
export type Users = User[];
export interface ListUsersResponse {
    Users: User[];
    NextToken?: string | undefined;
}
export interface AttributeOperation {
    AttributePath: string;
    AttributeValue?: any | undefined;
}
export type AttributeOperations = AttributeOperation[];
export interface UpdateGroupRequest {
    IdentityStoreId: string;
    GroupId: string;
    Operations: AttributeOperation[];
    Revision?: string | undefined;
}
export interface UpdateGroupResponse {
    IdentityStoreId: string;
    GroupId: string;
    GroupArn: string;
    Revision: string;
}
export interface NetworkConfiguration {
    VpceAccessRequired: boolean;
    ApiRestrictSourceVpcs?: string[] | undefined;
    ApiAllowSourceIps?: string[] | undefined;
    ScimAllowSourceIps?: string[] | undefined;
}
export interface UpdateIdentityStoreRequest {
    IdentityStoreId: string;
    NetworkConfiguration?: NetworkConfiguration | undefined;
}
export interface UpdateIdentityStoreResponse {
    IdentityStoreId: string;
    IdentityStoreArn: string;
}
export interface UpdateUserRequest {
    IdentityStoreId: string;
    UserId: string;
    Operations: AttributeOperation[];
    Revision?: string | undefined;
}
export interface UpdateUserResponse {
    IdentityStoreId: string;
    UserId: string;
    UserArn: string;
    Revision: string;
}
export type ExceptionMessage = string;
export type RequestId = string;
export type ConflictExceptionReason = "UNIQUENESS_CONSTRAINT_VIOLATION" | "CONCURRENT_MODIFICATION" | (string & {});
export type ResourceType = "GROUP" | "USER" | "IDENTITY_STORE" | "GROUP_MEMBERSHIP" | "RESOURCE_POLICY" | (string & {});
export type ResourceNotFoundExceptionReason = "KMS_KEY_NOT_FOUND" | (string & {});
export type ValidationExceptionReason = "KMS_INVALID_ARN" | "KMS_INVALID_KEY_USAGE" | "KMS_INVALID_STATE" | "KMS_DISABLED" | (string & {});
export type AccessDeniedExceptionReason = "KMS_ACCESS_DENIED" | (string & {});
export type RetryAfterSeconds = number;
export type ThrottlingExceptionReason = "KMS_THROTTLING" | (string & {});
export type CreateGroupError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Creates a group within the specified identity store.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGroupMembershipError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Creates a relationship between a member and a group. The following identifiers must be specified: `GroupId`, `IdentityStoreId`, and `MemberId`.
 */
export declare const createGroupMembership: API.OperationMethod<CreateGroupMembershipRequest & RegionInput, CreateGroupMembershipResponse, CreateGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateUserError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Creates a user within the specified identity store.
 */
export declare const createUser: API.OperationMethod<CreateUserRequest & RegionInput, CreateUserResponse, CreateUserError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = ConflictException | ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Delete a group within an identity store given `GroupId`.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupMembershipError = ConflictException | ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Delete a membership within a group given `MembershipId`.
 */
export declare const deleteGroupMembership: API.OperationMethod<DeleteGroupMembershipRequest & RegionInput, DeleteGroupMembershipResponse, DeleteGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = ConflictException | ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Deletes a user within an identity store given `UserId`.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves the group metadata and attributes from `GroupId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest & RegionInput, DescribeGroupResponse, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupMembershipError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves membership metadata and attributes from `MembershipId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeGroupMembership: API.OperationMethod<DescribeGroupMembershipRequest & RegionInput, DescribeGroupMembershipResponse, DescribeGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DescribeIdentityStoreError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves details about the specified identity store, including its Amazon Resource Name (ARN) and network configuration.
 */
export declare const describeIdentityStore: API.OperationMethod<DescribeIdentityStoreRequest & RegionInput, DescribeIdentityStoreResponse, DescribeIdentityStoreError, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves the user metadata and attributes from the `UserId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest & RegionInput, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type GetGroupIdError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves `GroupId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getGroupId: API.OperationMethod<GetGroupIdRequest & RegionInput, GetGroupIdResponse, GetGroupIdError, Credentials | HttpClient.HttpClient>;
export type GetGroupMembershipIdError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves the `MembershipId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getGroupMembershipId: API.OperationMethod<GetGroupMembershipIdRequest & RegionInput, GetGroupMembershipIdResponse, GetGroupMembershipIdError, Credentials | HttpClient.HttpClient>;
export type GetUserIdError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Retrieves the `UserId` in an identity store.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const getUserId: API.OperationMethod<GetUserIdRequest & RegionInput, GetUserIdResponse, GetUserIdError, Credentials | HttpClient.HttpClient>;
export type IsMemberInGroupsError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Checks the user's membership in all requested groups and returns if the member exists in all queried groups.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const isMemberInGroups: API.OperationMethod<IsMemberInGroupsRequest & RegionInput, IsMemberInGroupsResponse, IsMemberInGroupsError, Credentials | HttpClient.HttpClient>;
export type ListGroupMembershipsError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * For the specified group in the specified identity store, returns the list of all ` GroupMembership` objects and returns results in paginated form.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroupMemberships: API.PaginatedOperationMethod<ListGroupMembershipsRequest & RegionInput, ListGroupMembershipsResponse, ListGroupMembershipsError, Credentials | HttpClient.HttpClient, GroupMembership>;
export type ListGroupMembershipsForMemberError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * For the specified member in the specified identity store, returns the list of all ` GroupMembership` objects and returns results in paginated form.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroupMembershipsForMember: API.PaginatedOperationMethod<ListGroupMembershipsForMemberRequest & RegionInput, ListGroupMembershipsForMemberResponse, ListGroupMembershipsForMemberError, Credentials | HttpClient.HttpClient, GroupMembership>;
export type ListGroupsError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Lists all groups in the identity store. Returns a paginated list of complete `Group` objects. Filtering for a `Group` by the `DisplayName` attribute is deprecated. Instead, use the `GetGroupId` API action.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type ListIdentityStoresError = ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Lists the identity stores that you have access to. This operation returns only the identity store ID and Amazon Resource Name (ARN) of each identity store. To obtain additional information about an identity store, call `DescribeIdentityStore`.
 *
 * This operation returns results in paginated form. Use the `NextToken` parameter to retrieve additional pages of results.
 */
export declare const listIdentityStores: API.PaginatedOperationMethod<ListIdentityStoresRequest & RegionInput, ListIdentityStoresResponse, ListIdentityStoresError, Credentials | HttpClient.HttpClient, IdentityStore>;
export type ListUsersError = ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Lists all users in the identity store. Returns a paginated list of complete `User` objects. Filtering for a `User` by the `UserName` attribute is deprecated. Instead, use the `GetUserId` API action.
 *
 * If you have access to a member account, you can use this API operation from the member account. For more information, see Limiting access to the identity store from member accounts in the * IAM Identity Center User Guide*.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, User>;
export type UpdateGroupError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Updates the specified group metadata and attributes in the specified identity store.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityStoreError = ConflictException | ResourceNotFoundException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Updates the configuration of the specified identity store, including its network configuration.
 */
export declare const updateIdentityStore: API.OperationMethod<UpdateIdentityStoreRequest & RegionInput, UpdateIdentityStoreResponse, UpdateIdentityStoreError, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * Updates the specified user metadata and attributes in the specified identity store.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=identitystore.d.ts.map