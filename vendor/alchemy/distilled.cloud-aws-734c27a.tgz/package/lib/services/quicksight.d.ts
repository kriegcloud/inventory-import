import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConcurrentUpdatingException_base: S.TaggedErrorClass<"ConcurrentUpdatingException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConcurrentUpdatingException extends /*@__PURE__*/ ConcurrentUpdatingException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const CustomerManagedKeyUnavailableException_base: S.TaggedErrorClass<"CustomerManagedKeyUnavailableException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CustomerManagedKeyUnavailableException extends /*@__PURE__*/ CustomerManagedKeyUnavailableException_base {
}
declare const DomainNotWhitelistedException_base: S.TaggedErrorClass<"DomainNotWhitelistedException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class DomainNotWhitelistedException extends /*@__PURE__*/ DomainNotWhitelistedException_base {
}
declare const IdentityTypeNotSupportedException_base: S.TaggedErrorClass<"IdentityTypeNotSupportedException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class IdentityTypeNotSupportedException extends /*@__PURE__*/ IdentityTypeNotSupportedException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidDataSetParameterValueException_base: S.TaggedErrorClass<"InvalidDataSetParameterValueException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidDataSetParameterValueException extends /*@__PURE__*/ InvalidDataSetParameterValueException_base {
}
declare const InvalidNextTokenException_base: S.TaggedErrorClass<"InvalidNextTokenException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidNextTokenException extends /*@__PURE__*/ InvalidNextTokenException_base {
}
declare const InvalidParameterException_base: S.TaggedErrorClass<"InvalidParameterException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterException extends /*@__PURE__*/ InvalidParameterException_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const PreconditionNotMetException_base: S.TaggedErrorClass<"PreconditionNotMetException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class PreconditionNotMetException extends /*@__PURE__*/ PreconditionNotMetException_base {
}
declare const QuickSightSubscriptionRequired_base: S.TaggedErrorClass<"QuickSightSubscriptionRequired", {
    readonly message: any;
    readonly ResourceType: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class QuickSightSubscriptionRequired extends /*@__PURE__*/ QuickSightSubscriptionRequired_base {
}
declare const QuickSightUserNotFoundException_base: S.TaggedErrorClass<"QuickSightUserNotFoundException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class QuickSightUserNotFoundException extends /*@__PURE__*/ QuickSightUserNotFoundException_base {
}
declare const ResourceExistsException_base: S.TaggedErrorClass<"ResourceExistsException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceExistsException extends /*@__PURE__*/ ResourceExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ResourceUnavailableException_base: S.TaggedErrorClass<"ResourceUnavailableException", {
    readonly message: any;
    readonly ResourceType: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ResourceUnavailableException extends /*@__PURE__*/ ResourceUnavailableException_base {
}
declare const SessionLifetimeInMinutesInvalidException_base: S.TaggedErrorClass<"SessionLifetimeInMinutesInvalidException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class SessionLifetimeInMinutesInvalidException extends /*@__PURE__*/ SessionLifetimeInMinutesInvalidException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const UnsupportedPricingPlanException_base: S.TaggedErrorClass<"UnsupportedPricingPlanException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnsupportedPricingPlanException extends /*@__PURE__*/ UnsupportedPricingPlanException_base {
}
declare const UnsupportedUserEditionException_base: S.TaggedErrorClass<"UnsupportedUserEditionException", {
    readonly message: any;
    readonly RequestId: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnsupportedUserEditionException extends /*@__PURE__*/ UnsupportedUserEditionException_base {
}
export type AwsAccountId = string;
export type TopicId = string;
export type AnswerId = string;
export type Arn = string;
export type LimitedSensitiveString = string | redacted.Redacted<string>;
export type LimitedString = string;
export interface Identifier {
    Identity: string;
}
export type AggType = "SUM" | "MIN" | "MAX" | "COUNT" | "AVERAGE" | "DISTINCT_COUNT" | "STDEV" | "STDEVP" | "VAR" | "VARP" | "PERCENTILE" | "MEDIAN" | "PTD_SUM" | "PTD_MIN" | "PTD_MAX" | "PTD_COUNT" | "PTD_DISTINCT_COUNT" | "PTD_AVERAGE" | "COLUMN" | "CUSTOM" | (string & {});
export type AggFunctionParamKey = string;
export type AggFunctionParamValue = string;
export type AggFunctionParamMap = {
    [key: string]: string | undefined;
};
export type TopicTimeGranularity = "SECOND" | "MINUTE" | "HOUR" | "DAY" | "WEEK" | "MONTH" | "QUARTER" | "YEAR" | (string & {});
export interface AggFunction {
    Aggregation?: AggType | undefined;
    AggregationFunctionParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    Period?: TopicTimeGranularity | undefined;
    PeriodField?: string | undefined;
}
export type OperandList = Identifier[];
export type ComparisonMethodType = "DIFF" | "PERC_DIFF" | "DIFF_AS_PERC" | "POP_CURRENT_DIFF_AS_PERC" | "POP_CURRENT_DIFF" | "POP_OVERTIME_DIFF_AS_PERC" | "POP_OVERTIME_DIFF" | "PERCENT_OF_TOTAL" | "RUNNING_SUM" | "MOVING_AVERAGE" | (string & {});
export interface TopicIRComparisonMethod {
    Type?: ComparisonMethodType | undefined;
    Period?: TopicTimeGranularity | undefined;
    WindowSize?: number | undefined;
}
export type Expression = string | redacted.Redacted<string>;
export type CalculatedFieldReferenceList = Identifier[];
export type DisplayFormat = "AUTO" | "PERCENT" | "CURRENCY" | "NUMBER" | "DATE" | "STRING" | (string & {});
export type TopicNumericSeparatorSymbol = "COMMA" | "DOT" | (string & {});
export type NumberScale = "NONE" | "AUTO" | "THOUSANDS" | "MILLIONS" | "BILLIONS" | "TRILLIONS" | "LAKHS" | "CRORES" | (string & {});
export interface NegativeFormat {
    Prefix?: string | undefined;
    Suffix?: string | undefined;
}
export interface DisplayFormatOptions {
    UseBlankCellFormat?: boolean | undefined;
    BlankCellFormat?: string | undefined;
    DateFormat?: string | undefined;
    DecimalSeparator?: TopicNumericSeparatorSymbol | undefined;
    GroupingSeparator?: string | undefined;
    UseGrouping?: boolean | undefined;
    FractionDigits?: number | undefined;
    Prefix?: string | undefined;
    Suffix?: string | undefined;
    UnitScaler?: NumberScale | undefined;
    NegativeFormat?: NegativeFormat | undefined;
    CurrencySymbol?: string | undefined;
}
export interface NamedEntityRef {
    NamedEntityName?: string | undefined;
}
export interface TopicIRMetric {
    MetricId?: Identifier | undefined;
    Function?: AggFunction | undefined;
    Operands?: Identifier[] | undefined;
    ComparisonMethod?: TopicIRComparisonMethod | undefined;
    Expression?: string | redacted.Redacted<string> | undefined;
    CalculatedFieldReferences?: Identifier[] | undefined;
    DisplayFormat?: DisplayFormat | undefined;
    DisplayFormatOptions?: DisplayFormatOptions | undefined;
    NamedEntity?: NamedEntityRef | undefined;
}
export type TopicIRMetricList = TopicIRMetric[];
export type TopicSortDirection = "ASCENDING" | "DESCENDING" | (string & {});
export interface TopicSortClause {
    Operand?: Identifier | undefined;
    SortDirection?: TopicSortDirection | undefined;
}
export interface TopicIRGroupBy {
    FieldName?: Identifier | undefined;
    TimeGranularity?: TopicTimeGranularity | undefined;
    Sort?: TopicSortClause | undefined;
    DisplayFormat?: DisplayFormat | undefined;
    DisplayFormatOptions?: DisplayFormatOptions | undefined;
    NamedEntity?: NamedEntityRef | undefined;
}
export type TopicIRGroupByList = TopicIRGroupBy[];
export type TopicIRFilterType = "CATEGORY_FILTER" | "NUMERIC_EQUALITY_FILTER" | "NUMERIC_RANGE_FILTER" | "DATE_RANGE_FILTER" | "RELATIVE_DATE_FILTER" | "TOP_BOTTOM_FILTER" | "EQUALS" | "RANK_LIMIT_FILTER" | "ACCEPT_ALL_FILTER" | (string & {});
export type FilterClass = "ENFORCED_VALUE_FILTER" | "CONDITIONAL_VALUE_FILTER" | "NAMED_VALUE_FILTER" | "DASHBOARD_DEFAULT_FILTER" | (string & {});
export type TopicIRFilterFunction = "CONTAINS" | "EXACT" | "STARTS_WITH" | "ENDS_WITH" | "CONTAINS_STRING" | "PREVIOUS" | "THIS" | "LAST" | "NEXT" | "NOW" | (string & {});
export type ConstantType = "SINGULAR" | "RANGE" | "COLLECTIVE" | (string & {});
export type ConstantValueString = string;
export interface CollectiveConstantEntry {
    ConstantType?: ConstantType | undefined;
    Value?: string | undefined;
}
export type CollectiveConstantEntryList = CollectiveConstantEntry[];
export interface TopicConstantValue {
    ConstantType?: ConstantType | undefined;
    Value?: string | undefined;
    Minimum?: string | undefined;
    Maximum?: string | undefined;
    ValueList?: CollectiveConstantEntry[] | undefined;
}
export type NullFilterOption = "ALL_VALUES" | "NON_NULLS_ONLY" | "NULLS_ONLY" | (string & {});
export type TimeGranularity = "YEAR" | "QUARTER" | "MONTH" | "WEEK" | "DAY" | "HOUR" | "MINUTE" | "SECOND" | "MILLISECOND" | (string & {});
export interface AggregationPartitionBy {
    FieldName?: string | undefined;
    TimeGranularity?: TimeGranularity | undefined;
}
export type AggregationPartitionByList = AggregationPartitionBy[];
export interface FilterAggMetrics {
    MetricOperand?: Identifier | undefined;
    Function?: AggType | undefined;
    SortDirection?: TopicSortDirection | undefined;
}
export type FilterAggMetricsList = FilterAggMetrics[];
export type AnchorType = "TODAY" | (string & {});
export interface Anchor {
    AnchorType?: AnchorType | undefined;
    TimeGranularity?: TimeGranularity | undefined;
    Offset?: number | undefined;
}
export interface TopicIRFilterOption {
    FilterType?: TopicIRFilterType | undefined;
    FilterClass?: FilterClass | undefined;
    OperandField?: Identifier | undefined;
    Function?: TopicIRFilterFunction | undefined;
    Constant?: TopicConstantValue | undefined;
    Inverse?: boolean | undefined;
    NullFilter?: NullFilterOption | undefined;
    Aggregation?: AggType | undefined;
    AggregationFunctionParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    AggregationPartitionBy?: AggregationPartitionBy[] | undefined;
    Range?: TopicConstantValue | undefined;
    Inclusive?: boolean | undefined;
    TimeGranularity?: TimeGranularity | undefined;
    LastNextOffset?: TopicConstantValue | undefined;
    AggMetrics?: FilterAggMetrics[] | undefined;
    TopBottomLimit?: TopicConstantValue | undefined;
    SortDirection?: TopicSortDirection | undefined;
    Anchor?: Anchor | undefined;
}
export type TopicIRFilterEntry = TopicIRFilterOption[];
export type TopicIRFilterList = TopicIRFilterOption[][];
export interface ContributionAnalysisFactor {
    FieldName?: string | undefined;
}
export type ContributionAnalysisFactorsList = ContributionAnalysisFactor[];
export interface ContributionAnalysisTimeRanges {
    StartRange?: TopicIRFilterOption | undefined;
    EndRange?: TopicIRFilterOption | undefined;
}
export type ContributionAnalysisDirection = "INCREASE" | "DECREASE" | "NEUTRAL" | (string & {});
export type ContributionAnalysisSortType = "ABSOLUTE_DIFFERENCE" | "CONTRIBUTION_PERCENTAGE" | "DEVIATION_FROM_EXPECTED" | "PERCENTAGE_DIFFERENCE" | (string & {});
export interface TopicIRContributionAnalysis {
    Factors?: ContributionAnalysisFactor[] | undefined;
    TimeRanges?: ContributionAnalysisTimeRanges | undefined;
    Direction?: ContributionAnalysisDirection | undefined;
    SortType?: ContributionAnalysisSortType | undefined;
}
export interface VisualOptions {
    type?: string | undefined;
}
export interface TopicIR {
    Metrics?: TopicIRMetric[] | undefined;
    GroupByList?: TopicIRGroupBy[] | undefined;
    Filters?: TopicIRFilterOption[][] | undefined;
    Sort?: TopicSortClause | undefined;
    ContributionAnalysis?: TopicIRContributionAnalysis | undefined;
    Visual?: VisualOptions | undefined;
}
export type VisualRole = "PRIMARY" | "COMPLIMENTARY" | "MULTI_INTENT" | "FALLBACK" | "FRAGMENT" | (string & {});
export type TopicVisuals = TopicVisual[];
export interface TopicVisual {
    VisualId?: string | undefined;
    Role?: VisualRole | undefined;
    Ir?: TopicIR | undefined;
    SupportingVisuals?: TopicVisual[] | undefined;
}
export interface Slot {
    SlotId?: string | undefined;
    VisualId?: string | undefined;
}
export type Slots = Slot[];
export interface TopicTemplate {
    TemplateType?: string | undefined;
    Slots?: Slot[] | undefined;
}
export interface CreateTopicReviewedAnswer {
    AnswerId: string;
    DatasetArn: string;
    Question: string | redacted.Redacted<string>;
    Mir?: TopicIR | undefined;
    PrimaryVisual?: TopicVisual | undefined;
    Template?: TopicTemplate | undefined;
}
export type CreateTopicReviewedAnswers = CreateTopicReviewedAnswer[];
export interface BatchCreateTopicReviewedAnswerRequest {
    AwsAccountId: string;
    TopicId: string;
    Answers: CreateTopicReviewedAnswer[];
}
export interface SucceededTopicReviewedAnswer {
    AnswerId?: string | undefined;
}
export type SucceededTopicReviewedAnswers = SucceededTopicReviewedAnswer[];
export type ReviewedAnswerErrorCode = "INTERNAL_ERROR" | "MISSING_ANSWER" | "DATASET_DOES_NOT_EXIST" | "INVALID_DATASET_ARN" | "DUPLICATED_ANSWER" | "INVALID_DATA" | "MISSING_REQUIRED_FIELDS" | (string & {});
export interface InvalidTopicReviewedAnswer {
    AnswerId?: string | undefined;
    Error?: ReviewedAnswerErrorCode | undefined;
}
export type InvalidTopicReviewedAnswers = InvalidTopicReviewedAnswer[];
export type StatusCode = number;
export interface BatchCreateTopicReviewedAnswerResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    SucceededAnswers?: SucceededTopicReviewedAnswer[] | undefined;
    InvalidAnswers?: InvalidTopicReviewedAnswer[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type KbAwsAccountId = string;
export type KnowledgeBaseId = string;
export type BatchDeleteKnowledgeBaseRequestKnowledgeBaseIdsList = string[];
export interface BatchDeleteKnowledgeBaseRequest {
    AwsAccountId: string;
    KnowledgeBaseIds: string[];
}
export type KnowledgeBaseArn = string;
export interface BatchDeleteKnowledgeBaseSuccess {
    KnowledgeBaseId: string;
    KnowledgeBaseArn: string;
}
export type BatchDeleteKnowledgeBaseSuccessList = BatchDeleteKnowledgeBaseSuccess[];
export interface BatchDeleteKnowledgeBaseFailure {
    KnowledgeBaseId: string;
    ErrorCode: string;
    ErrorMessage: string;
}
export type BatchDeleteKnowledgeBaseFailureList = BatchDeleteKnowledgeBaseFailure[];
export interface BatchDeleteKnowledgeBaseResponse {
    Deleted: BatchDeleteKnowledgeBaseSuccess[];
    Errors: BatchDeleteKnowledgeBaseFailure[];
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type AnswerIds = string[];
export interface BatchDeleteTopicReviewedAnswerRequest {
    AwsAccountId: string;
    TopicId: string;
    AnswerIds?: string[] | undefined;
}
export interface BatchDeleteTopicReviewedAnswerResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    SucceededAnswers?: SucceededTopicReviewedAnswer[] | undefined;
    InvalidAnswers?: InvalidTopicReviewedAnswer[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UserLimitsEntry {
    userName: string;
    namespace: string;
}
export type BatchDescribeUserLimitsRequestUsersList = UserLimitsEntry[];
export type ResourceType = "INDEX_STORAGE" | "AGENT_HOURS" | (string & {});
export type ResourceTypeList = ResourceType[];
export interface BatchDescribeUserLimitsRequest {
    accountId: string;
    users?: UserLimitsEntry[] | undefined;
    resourceTypes?: ResourceType[] | undefined;
}
export type EffectiveLimitLimitValueLong = number;
export type LimitUnit = "MB" | "GB" | "HOURS" | "DAYS" | (string & {});
export type LimitSource = "DIRECT_USER" | "GROUP" | "ROLE" | "ACCOUNT" | "SYSTEM_DEFAULT" | (string & {});
export type ProfileId = string;
export interface EffectiveLimit {
    resourceType: ResourceType;
    limitValue: number;
    limitUnit: LimitUnit;
    source: LimitSource;
    profileId: string;
}
export type EffectiveLimitList = EffectiveLimit[];
export interface UserLimits {
    userName: string;
    namespace: string;
    effectiveLimits: EffectiveLimit[];
}
export type UserLimitsList = UserLimits[];
export interface BatchDescribeUserLimitsError_ {
    userName?: string | undefined;
    namespace?: string | undefined;
    userArn?: string | undefined;
    errorCode: string;
    message: string;
}
export type BatchDescribeUserLimitsErrorList = BatchDescribeUserLimitsError_[];
export interface BatchDescribeUserLimitsResponse {
    userLimits: UserLimits[];
    errors: BatchDescribeUserLimitsError_[];
}
export type IngestionId = string;
export interface CancelIngestionRequest {
    AwsAccountId: string;
    DataSetId: string;
    IngestionId: string;
}
export interface CancelIngestionResponse {
    Arn?: string | undefined;
    IngestionId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type Namespace = string;
export interface AccountCustomization {
    DefaultTheme?: string | undefined;
    DefaultEmailCustomizationTemplate?: string | undefined;
}
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateAccountCustomizationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
    AccountCustomization: AccountCustomization;
    Tags?: Tag[] | undefined;
}
export interface CreateAccountCustomizationResponse {
    Arn?: string | undefined;
    AwsAccountId?: string | undefined;
    Namespace?: string | undefined;
    AccountCustomization?: AccountCustomization | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type Edition = "STANDARD" | "ENTERPRISE" | "ENTERPRISE_AND_Q" | (string & {});
export type AuthenticationMethodOption = "IAM_AND_QUICKSIGHT" | "IAM_ONLY" | "ACTIVE_DIRECTORY" | "IAM_IDENTITY_CENTER" | (string & {});
export type AccountName = string;
export type GroupsList = string[];
export interface CreateAccountSubscriptionRequest {
    Edition?: Edition | undefined;
    AuthenticationMethod: AuthenticationMethodOption;
    AwsAccountId: string;
    AccountName: string;
    NotificationEmail: string;
    ActiveDirectoryName?: string | undefined;
    Realm?: string | undefined;
    DirectoryId?: string | undefined;
    AdminGroup?: string[] | undefined;
    AuthorGroup?: string[] | undefined;
    ReaderGroup?: string[] | undefined;
    AdminProGroup?: string[] | undefined;
    AuthorProGroup?: string[] | undefined;
    ReaderProGroup?: string[] | undefined;
    FirstName?: string | undefined;
    LastName?: string | undefined;
    EmailAddress?: string | undefined;
    ContactNumber?: string | undefined;
    IAMIdentityCenterInstanceArn?: string | undefined;
}
export interface SignupResponse {
    IAMUser?: boolean | undefined;
    userLoginName?: string | undefined;
    accountName?: string | undefined;
    directoryType?: string | undefined;
}
export interface CreateAccountSubscriptionResponse {
    SignupResponse?: SignupResponse | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type ShortRestrictiveResourceId = string;
export type ActionConnectorName = string | redacted.Redacted<string>;
export type ActionConnectorType = "GENERIC_HTTP" | "SERVICENOW_NOW_PLATFORM" | "SALESFORCE_CRM" | "MICROSOFT_OUTLOOK" | "PAGERDUTY_ADVANCE" | "JIRA_CLOUD" | "ATLASSIAN_CONFLUENCE" | "AMAZON_S3" | "AMAZON_BEDROCK_AGENT_RUNTIME" | "AMAZON_BEDROCK_RUNTIME" | "AMAZON_BEDROCK_DATA_AUTOMATION_RUNTIME" | "AMAZON_TEXTRACT" | "AMAZON_COMPREHEND" | "AMAZON_COMPREHEND_MEDICAL" | "MICROSOFT_ONEDRIVE" | "MICROSOFT_SHAREPOINT" | "MICROSOFT_TEAMS" | "SAP_BUSINESSPARTNER" | "SAP_PRODUCTMASTERDATA" | "SAP_PHYSICALINVENTORY" | "SAP_BILLOFMATERIALS" | "SAP_MATERIALSTOCK" | "ZENDESK_SUITE" | "SMARTSHEET" | "SLACK" | "ASANA" | "BAMBOO_HR" | (string & {});
export type ConnectionAuthType = "BASIC" | "API_KEY" | "OAUTH2_CLIENT_CREDENTIALS" | "NONE" | "IAM" | "OAUTH2_AUTHORIZATION_CODE" | (string & {});
export type Endpoint = string;
export type AuthorizationCodeGrantCredentialsSource = "PLAIN_CREDENTIALS" | (string & {});
export type ClientId = string;
export type ClientSecret = string | redacted.Redacted<string>;
export interface AuthorizationCodeGrantDetails {
    ClientId: string;
    ClientSecret: string | redacted.Redacted<string>;
    TokenEndpoint: string;
    AuthorizationEndpoint: string;
}
export type AuthorizationCodeGrantCredentialsDetails = {
    AuthorizationCodeGrantDetails: AuthorizationCodeGrantDetails;
};
export interface AuthorizationCodeGrantMetadata {
    BaseEndpoint: string;
    RedirectUrl: string;
    AuthorizationCodeGrantCredentialsSource?: AuthorizationCodeGrantCredentialsSource | undefined;
    AuthorizationCodeGrantCredentialsDetails?: AuthorizationCodeGrantCredentialsDetails | undefined;
}
export type ClientCredentialsSource = "PLAIN_CREDENTIALS" | (string & {});
export interface ClientCredentialsGrantDetails {
    ClientId: string;
    ClientSecret: string | redacted.Redacted<string>;
    TokenEndpoint: string;
}
export type ClientCredentialsDetails = {
    ClientCredentialsGrantDetails: ClientCredentialsGrantDetails;
};
export interface ClientCredentialsGrantMetadata {
    BaseEndpoint: string;
    ClientCredentialsSource?: ClientCredentialsSource | undefined;
    ClientCredentialsDetails?: ClientCredentialsDetails | undefined;
}
export type ActionUserName = string | redacted.Redacted<string>;
export type ActionPassword = string | redacted.Redacted<string>;
export interface BasicAuthConnectionMetadata {
    BaseEndpoint: string;
    Username: string | redacted.Redacted<string>;
    Password: string | redacted.Redacted<string>;
}
export type APIKey = string | redacted.Redacted<string>;
export type Email = string | redacted.Redacted<string>;
export interface APIKeyConnectionMetadata {
    BaseEndpoint: string;
    ApiKey: string | redacted.Redacted<string>;
    Email?: string | redacted.Redacted<string> | undefined;
}
export interface NoneConnectionMetadata {
    BaseEndpoint: string;
}
export type RoleArn = string;
export interface IAMConnectionMetadata {
    RoleArn: string;
}
export type AuthenticationMetadata = {
    AuthorizationCodeGrantMetadata: AuthorizationCodeGrantMetadata;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata: ClientCredentialsGrantMetadata;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata: BasicAuthConnectionMetadata;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata: APIKeyConnectionMetadata;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata: NoneConnectionMetadata;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata: IAMConnectionMetadata;
};
export interface AuthConfig {
    AuthenticationType: ConnectionAuthType;
    AuthenticationMetadata: AuthenticationMetadata;
}
export type ActionConnectorDescription = string | redacted.Redacted<string>;
export type Principal = string;
export type ActionList = string[];
export interface ResourcePermission {
    Principal: string;
    Actions: string[];
}
export type ResourcePermissionList = ResourcePermission[];
export interface CreateActionConnectorRequest {
    AwsAccountId: string;
    ActionConnectorId: string;
    Name: string | redacted.Redacted<string>;
    Type: ActionConnectorType;
    AuthenticationConfig: AuthConfig;
    Description?: string | redacted.Redacted<string> | undefined;
    Permissions?: ResourcePermission[] | undefined;
    VpcConnectionArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type ResourceStatus = "CREATION_IN_PROGRESS" | "CREATION_SUCCESSFUL" | "CREATION_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_SUCCESSFUL" | "UPDATE_FAILED" | "DELETED" | (string & {});
export interface CreateActionConnectorResponse {
    Arn?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    ActionConnectorId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type CreateAgentRequestSpacesList = string[];
export type CreateAgentRequestActionConnectorsList = string[];
export type AgentId = string;
export type AgentName = string;
export type AgentDescription = string;
export type IconId = string;
export type StarterPrompt = string;
export type StarterPromptList = string[];
export type WelcomeMessage = string | redacted.Redacted<string>;
export type AgentLifecycle = "PREVIEW" | "PUBLISHED" | (string & {});
export type ModelProfileId = string;
export type SubscriptionId = string;
export type QbsAwsAccountId = string;
export interface CustomPromptProfile {
    ModelProfileId: string;
    SubscriptionId: string;
    QbsAwsAccountId: string;
}
export type StyleDescription = string | redacted.Redacted<string>;
export interface CustomPromptInputParameters {
    ResponseLength?: string | redacted.Redacted<string> | undefined;
    OutputStyle?: string | redacted.Redacted<string> | undefined;
    Identity?: string | redacted.Redacted<string> | undefined;
    Tone?: string | redacted.Redacted<string> | undefined;
    CustomInstructions?: string | redacted.Redacted<string> | undefined;
}
export type CustomPromptInput = {
    ExistingPrompt: CustomPromptProfile;
    NewPrompt?: undefined;
} | {
    ExistingPrompt?: undefined;
    NewPrompt: CustomPromptInputParameters;
};
export interface CreateAgentRequest {
    Spaces?: string[] | undefined;
    ActionConnectors?: string[] | undefined;
    AwsAccountId: string;
    AgentId: string;
    Name: string;
    Description?: string | undefined;
    IconId?: string | undefined;
    StarterPrompts?: string[] | undefined;
    WelcomeMessage?: string | redacted.Redacted<string> | undefined;
    AgentLifecycle?: AgentLifecycle | undefined;
    CustomPromptInput?: CustomPromptInput | undefined;
}
export type AgentArn = string;
export type AgentStatus = "ACTIVE" | "UPDATING" | "FAILED" | "CREATING" | (string & {});
export interface CreateAgentResponse {
    Arn: string;
    AgentId: string;
    AgentStatus: AgentStatus;
    AgentName: string;
    RequestId?: string | undefined;
}
export type AnalysisName = string;
export type NonEmptyString = string;
export type SensitiveString = string | redacted.Redacted<string>;
export type SensitiveStringList = (string | redacted.Redacted<string>)[];
export interface StringParameter {
    Name: string;
    Values: (string | redacted.Redacted<string>)[];
}
export type StringParameterList = StringParameter[];
export type SensitiveLong = number;
export type SensitiveLongList = number[];
export interface IntegerParameter {
    Name: string;
    Values: number[];
}
export type IntegerParameterList = IntegerParameter[];
export type SensitiveDouble = number;
export type SensitiveDoubleList = number[];
export interface DecimalParameter {
    Name: string;
    Values: number[];
}
export type DecimalParameterList = DecimalParameter[];
export type SensitiveTimestamp = Date;
export type SensitiveTimestampList = Date[];
export interface DateTimeParameter {
    Name: string;
    Values: Date[];
}
export type DateTimeParameterList = DateTimeParameter[];
export interface Parameters {
    StringParameters?: StringParameter[] | undefined;
    IntegerParameters?: IntegerParameter[] | undefined;
    DecimalParameters?: DecimalParameter[] | undefined;
    DateTimeParameters?: DateTimeParameter[] | undefined;
}
export interface DataSetReference {
    DataSetPlaceholder: string;
    DataSetArn: string;
}
export type DataSetReferenceList = DataSetReference[];
export type TopicIdentifier = string;
export interface TopicReference {
    TopicPlaceholder: string;
    TopicArn: string;
}
export type TopicReferenceList = TopicReference[];
export interface AnalysisSourceTemplate {
    DataSetReferences: DataSetReference[];
    TopicReferences?: TopicReference[] | undefined;
    Arn: string;
}
export interface AnalysisSourceEntity {
    SourceTemplate?: AnalysisSourceTemplate | undefined;
}
export type DataSetIdentifier = string;
export interface DataSetIdentifierDeclaration {
    Identifier: string;
    DataSetArn: string;
}
export type DataSetIdentifierDeclarationList = DataSetIdentifierDeclaration[];
export interface TopicIdentifierDeclaration {
    Identifier: string;
    TopicArn: string;
}
export type TopicIdentifierDeclarationList = TopicIdentifierDeclaration[];
export type SheetTitle = string;
export type SheetDescription = string;
export type SheetName = string;
export type SheetControlTitle = string;
export type ParameterName = string;
export type Visibility = "HIDDEN" | "VISIBLE" | (string & {});
export type RelativeFontSize = "EXTRA_SMALL" | "SMALL" | "MEDIUM" | "LARGE" | "EXTRA_LARGE" | (string & {});
export type PixelLength = string;
export interface FontSize {
    Relative?: RelativeFontSize | undefined;
    Absolute?: string | undefined;
}
export type FontDecoration = "UNDERLINE" | "NONE" | (string & {});
export type HexColor = string;
export type FontWeightName = "NORMAL" | "BOLD" | (string & {});
export interface FontWeight {
    Name?: FontWeightName | undefined;
}
export type FontStyle = "NORMAL" | "ITALIC" | (string & {});
export interface FontConfiguration {
    FontSize?: FontSize | undefined;
    FontDecoration?: FontDecoration | undefined;
    FontColor?: string | undefined;
    FontWeight?: FontWeight | undefined;
    FontStyle?: FontStyle | undefined;
    FontFamily?: string | undefined;
}
export interface LabelOptions {
    Visibility?: Visibility | undefined;
    FontConfiguration?: FontConfiguration | undefined;
    CustomLabel?: string | undefined;
}
export type DateTimeFormat = string;
export type SheetControlInfoIconText = string;
export interface SheetControlInfoIconLabelOptions {
    Visibility?: Visibility | undefined;
    InfoIconText?: string | undefined;
}
export interface DateTimePickerControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    DateTimeFormat?: string | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
    HelperTextVisibility?: Visibility | undefined;
    DateIconVisibility?: Visibility | undefined;
}
export type ControlTitlePlainText = string;
export type ControlTitleRichText = string;
export interface ControlTitleFormatText {
    PlainText?: string | undefined;
    RichText?: string | undefined;
}
export interface ParameterDateTimePickerControl {
    ParameterControlId: string;
    Title?: string | undefined;
    SourceParameterName: string;
    DisplayOptions?: DateTimePickerControlDisplayOptions | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface ListControlSearchOptions {
    Visibility?: Visibility | undefined;
}
export interface ListControlSelectAllOptions {
    Visibility?: Visibility | undefined;
}
export interface ListControlDisplayOptions {
    SearchOptions?: ListControlSearchOptions | undefined;
    SelectAllOptions?: ListControlSelectAllOptions | undefined;
    TitleOptions?: LabelOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export type SheetControlListType = "MULTI_SELECT" | "SINGLE_SELECT" | (string & {});
export type ParameterSelectableValueList = string[];
export type ColumnName = string;
export interface ColumnIdentifier {
    DataSetIdentifier?: string | undefined;
    TopicIdentifier?: string | undefined;
    ColumnName: string;
}
export interface ParameterSelectableValues {
    Values?: string[] | undefined;
    LinkToDataSetColumn?: ColumnIdentifier | undefined;
}
export interface CascadingControlSource {
    SourceSheetControlId?: string | undefined;
    ColumnToMatch?: ColumnIdentifier | undefined;
}
export type CascadingControlSourceList = CascadingControlSource[];
export interface CascadingControlConfiguration {
    SourceControls?: CascadingControlSource[] | undefined;
}
export type ControlSortDirection = "ASC" | "DESC" | "USER_DEFINED_ORDER" | (string & {});
export interface SelectableValuesSort {
    Direction: ControlSortDirection;
}
export type SortDirection = "ASC" | "DESC" | (string & {});
export type SimpleNumericalAggregationFunction = "SUM" | "AVERAGE" | "MIN" | "MAX" | "COUNT" | "DISTINCT_COUNT" | "VAR" | "VARP" | "STDEV" | "STDEVP" | "MEDIAN" | (string & {});
export type PercentileValue = number;
export interface PercentileAggregation {
    PercentileValue?: number | undefined;
}
export interface NumericalAggregationFunction {
    SimpleNumericalAggregation?: SimpleNumericalAggregationFunction | undefined;
    PercentileAggregation?: PercentileAggregation | undefined;
}
export type CategoricalAggregationFunction = "COUNT" | "DISTINCT_COUNT" | (string & {});
export type DateAggregationFunction = "COUNT" | "DISTINCT_COUNT" | "MIN" | "MAX" | (string & {});
export type SimpleAttributeAggregationFunction = "UNIQUE_VALUE" | (string & {});
export interface AttributeAggregationFunction {
    SimpleAttributeAggregation?: SimpleAttributeAggregationFunction | undefined;
    ValueForMultipleValues?: string | undefined;
}
export interface AggregationFunction {
    NumericalAggregationFunction?: NumericalAggregationFunction | undefined;
    CategoricalAggregationFunction?: CategoricalAggregationFunction | undefined;
    DateAggregationFunction?: DateAggregationFunction | undefined;
    AttributeAggregationFunction?: AttributeAggregationFunction | undefined;
}
export interface AggregationSortConfiguration {
    Column: ColumnIdentifier;
    SortDirection: SortDirection;
    AggregationFunction?: AggregationFunction | undefined;
}
export interface ControlSortConfiguration {
    SelectableValuesSort?: SelectableValuesSort | undefined;
    ControlColumnSort?: AggregationSortConfiguration | undefined;
}
export type ControlSortConfigurationList = ControlSortConfiguration[];
export interface ParameterListControl {
    ParameterControlId: string;
    Title?: string | undefined;
    SourceParameterName: string;
    DisplayOptions?: ListControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    SelectableValues?: ParameterSelectableValues | undefined;
    CascadingControlConfiguration?: CascadingControlConfiguration | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface DropDownControlDisplayOptions {
    SelectAllOptions?: ListControlSelectAllOptions | undefined;
    TitleOptions?: LabelOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export type CommitMode = "AUTO" | "MANUAL" | (string & {});
export interface ParameterDropDownControl {
    ParameterControlId: string;
    Title?: string | undefined;
    SourceParameterName: string;
    DisplayOptions?: DropDownControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    SelectableValues?: ParameterSelectableValues | undefined;
    CascadingControlConfiguration?: CascadingControlConfiguration | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface TextControlPlaceholderOptions {
    Visibility?: Visibility | undefined;
}
export interface TextFieldControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    PlaceholderOptions?: TextControlPlaceholderOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export interface ParameterTextFieldControl {
    ParameterControlId: string;
    Title?: string | undefined;
    SourceParameterName: string;
    DisplayOptions?: TextFieldControlDisplayOptions | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export type TextAreaControlDelimiter = string;
export interface TextAreaControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    PlaceholderOptions?: TextControlPlaceholderOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export interface ParameterTextAreaControl {
    ParameterControlId: string;
    Title?: string | undefined;
    SourceParameterName: string;
    Delimiter?: string | undefined;
    DisplayOptions?: TextAreaControlDisplayOptions | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface SliderControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export interface ParameterSliderControl {
    ParameterControlId: string;
    Title?: string | undefined;
    SourceParameterName: string;
    DisplayOptions?: SliderControlDisplayOptions | undefined;
    MaximumValue: number;
    MinimumValue: number;
    StepSize: number;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface ParameterControl {
    DateTimePicker?: ParameterDateTimePickerControl | undefined;
    List?: ParameterListControl | undefined;
    Dropdown?: ParameterDropDownControl | undefined;
    TextField?: ParameterTextFieldControl | undefined;
    TextArea?: ParameterTextAreaControl | undefined;
    Slider?: ParameterSliderControl | undefined;
}
export type ParameterControlList = ParameterControl[];
export type SheetControlDateTimePickerType = "SINGLE_VALUED" | "DATE_RANGE" | (string & {});
export interface FilterDateTimePickerControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    DisplayOptions?: DateTimePickerControlDisplayOptions | undefined;
    Type?: SheetControlDateTimePickerType | undefined;
    CommitMode?: CommitMode | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface FilterSelectableValues {
    Values?: string[] | undefined;
}
export interface FilterListControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    DisplayOptions?: ListControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    SelectableValues?: FilterSelectableValues | undefined;
    CascadingControlConfiguration?: CascadingControlConfiguration | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface FilterDropDownControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    DisplayOptions?: DropDownControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    SelectableValues?: FilterSelectableValues | undefined;
    CascadingControlConfiguration?: CascadingControlConfiguration | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface FilterTextFieldControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    DisplayOptions?: TextFieldControlDisplayOptions | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface FilterTextAreaControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    Delimiter?: string | undefined;
    DisplayOptions?: TextAreaControlDisplayOptions | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export type SheetControlSliderType = "SINGLE_POINT" | "RANGE" | (string & {});
export interface FilterSliderControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    DisplayOptions?: SliderControlDisplayOptions | undefined;
    Type?: SheetControlSliderType | undefined;
    MaximumValue: number;
    MinimumValue: number;
    StepSize: number;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface RelativeDateTimeControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    DateTimeFormat?: string | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export interface FilterRelativeDateTimeControl {
    FilterControlId: string;
    Title?: string | undefined;
    SourceFilterId: string;
    DisplayOptions?: RelativeDateTimeControlDisplayOptions | undefined;
    CommitMode?: CommitMode | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface FilterCrossSheetControl {
    FilterControlId: string;
    SourceFilterId: string;
    CascadingControlConfiguration?: CascadingControlConfiguration | undefined;
}
export interface HierarchyFilterListControlSearchOptions {
    Visibility?: Visibility | undefined;
}
export interface HierarchyFilterListControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
    SearchOptions?: HierarchyFilterListControlSearchOptions | undefined;
}
export interface HierarchyFilterListControl {
    FilterControlId: string;
    SourceFilterId: string;
    Title?: string | undefined;
    DisplayOptions?: HierarchyFilterListControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface HierarchyFilterDropDownControlDisplayOptions {
    TitleOptions?: LabelOptions | undefined;
    InfoIconLabelOptions?: SheetControlInfoIconLabelOptions | undefined;
}
export interface HierarchyFilterDropDownControl {
    FilterControlId: string;
    SourceFilterId: string;
    Title?: string | undefined;
    DisplayOptions?: HierarchyFilterDropDownControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface FilterControl {
    DateTimePicker?: FilterDateTimePickerControl | undefined;
    List?: FilterListControl | undefined;
    Dropdown?: FilterDropDownControl | undefined;
    TextField?: FilterTextFieldControl | undefined;
    TextArea?: FilterTextAreaControl | undefined;
    Slider?: FilterSliderControl | undefined;
    RelativeDateTime?: FilterRelativeDateTimeControl | undefined;
    CrossSheet?: FilterCrossSheetControl | undefined;
    HierarchyList?: HierarchyFilterListControl | undefined;
    HierarchyDropdown?: HierarchyFilterDropDownControl | undefined;
}
export type FilterControlList = FilterControl[];
export type ShortPlainText = string;
export type ShortRichText = string;
export interface ShortFormatText {
    PlainText?: string | undefined;
    RichText?: string | undefined;
}
export interface VisualTitleLabelOptions {
    Visibility?: Visibility | undefined;
    FormatText?: ShortFormatText | undefined;
}
export type LongPlainText = string;
export type LongRichText = string;
export interface LongFormatText {
    PlainText?: string | undefined;
    RichText?: string | undefined;
}
export interface VisualSubtitleLabelOptions {
    Visibility?: Visibility | undefined;
    FormatText?: LongFormatText | undefined;
}
export type FieldId = string;
export type HierarchyId = string;
export type Prefix = string | redacted.Redacted<string>;
export type Suffix = string | redacted.Redacted<string>;
export type NumericSeparatorSymbol = "COMMA" | "DOT" | "SPACE" | (string & {});
export type DigitGroupingStyle = "DEFAULT" | "LAKHS" | (string & {});
export interface ThousandSeparatorOptions {
    Symbol?: NumericSeparatorSymbol | undefined;
    Visibility?: Visibility | undefined;
    GroupingStyle?: DigitGroupingStyle | undefined;
}
export interface NumericSeparatorConfiguration {
    DecimalSeparator?: NumericSeparatorSymbol | undefined;
    ThousandsSeparator?: ThousandSeparatorOptions | undefined;
}
export type DecimalPlaces = number;
export interface DecimalPlacesConfiguration {
    DecimalPlaces: number;
}
export type NegativeValueDisplayMode = "POSITIVE" | "NEGATIVE" | (string & {});
export interface NegativeValueConfiguration {
    DisplayMode: NegativeValueDisplayMode;
}
export type NullString = string | redacted.Redacted<string>;
export interface NullValueFormatConfiguration {
    NullString: string | redacted.Redacted<string>;
}
export interface NumberDisplayFormatConfiguration {
    Prefix?: string | redacted.Redacted<string> | undefined;
    Suffix?: string | redacted.Redacted<string> | undefined;
    SeparatorConfiguration?: NumericSeparatorConfiguration | undefined;
    DecimalPlacesConfiguration?: DecimalPlacesConfiguration | undefined;
    NumberScale?: NumberScale | undefined;
    NegativeValueConfiguration?: NegativeValueConfiguration | undefined;
    NullValueFormatConfiguration?: NullValueFormatConfiguration | undefined;
}
export type CurrencyCode = string;
export interface CurrencyDisplayFormatConfiguration {
    Prefix?: string | redacted.Redacted<string> | undefined;
    Suffix?: string | redacted.Redacted<string> | undefined;
    SeparatorConfiguration?: NumericSeparatorConfiguration | undefined;
    Symbol?: string | undefined;
    DecimalPlacesConfiguration?: DecimalPlacesConfiguration | undefined;
    NumberScale?: NumberScale | undefined;
    NegativeValueConfiguration?: NegativeValueConfiguration | undefined;
    NullValueFormatConfiguration?: NullValueFormatConfiguration | undefined;
}
export interface PercentageDisplayFormatConfiguration {
    Prefix?: string | redacted.Redacted<string> | undefined;
    Suffix?: string | redacted.Redacted<string> | undefined;
    SeparatorConfiguration?: NumericSeparatorConfiguration | undefined;
    DecimalPlacesConfiguration?: DecimalPlacesConfiguration | undefined;
    NegativeValueConfiguration?: NegativeValueConfiguration | undefined;
    NullValueFormatConfiguration?: NullValueFormatConfiguration | undefined;
}
export interface NumericFormatConfiguration {
    NumberDisplayFormatConfiguration?: NumberDisplayFormatConfiguration | undefined;
    CurrencyDisplayFormatConfiguration?: CurrencyDisplayFormatConfiguration | undefined;
    PercentageDisplayFormatConfiguration?: PercentageDisplayFormatConfiguration | undefined;
}
export interface NumberFormatConfiguration {
    FormatConfiguration?: NumericFormatConfiguration | undefined;
}
export interface NumericalDimensionField {
    FieldId: string;
    Column: ColumnIdentifier;
    HierarchyId?: string | undefined;
    FormatConfiguration?: NumberFormatConfiguration | undefined;
}
export interface StringFormatConfiguration {
    NullValueFormatConfiguration?: NullValueFormatConfiguration | undefined;
    NumericFormatConfiguration?: NumericFormatConfiguration | undefined;
}
export interface CategoricalDimensionField {
    FieldId: string;
    Column: ColumnIdentifier;
    HierarchyId?: string | undefined;
    FormatConfiguration?: StringFormatConfiguration | undefined;
}
export interface DateTimeFormatConfiguration {
    DateTimeFormat?: string | undefined;
    NullValueFormatConfiguration?: NullValueFormatConfiguration | undefined;
    NumericFormatConfiguration?: NumericFormatConfiguration | undefined;
}
export interface DateDimensionField {
    FieldId: string;
    Column: ColumnIdentifier;
    DateGranularity?: TimeGranularity | undefined;
    HierarchyId?: string | undefined;
    FormatConfiguration?: DateTimeFormatConfiguration | undefined;
}
export interface DimensionField {
    NumericalDimensionField?: NumericalDimensionField | undefined;
    CategoricalDimensionField?: CategoricalDimensionField | undefined;
    DateDimensionField?: DateDimensionField | undefined;
}
export type DimensionFieldList = DimensionField[];
export interface NumericalMeasureField {
    FieldId: string;
    Column: ColumnIdentifier;
    AggregationFunction?: NumericalAggregationFunction | undefined;
    FormatConfiguration?: NumberFormatConfiguration | undefined;
}
export interface CategoricalMeasureField {
    FieldId: string;
    Column: ColumnIdentifier;
    AggregationFunction?: CategoricalAggregationFunction | undefined;
    FormatConfiguration?: StringFormatConfiguration | undefined;
}
export interface DateMeasureField {
    FieldId: string;
    Column: ColumnIdentifier;
    AggregationFunction?: DateAggregationFunction | undefined;
    FormatConfiguration?: DateTimeFormatConfiguration | undefined;
}
export interface CalculatedMeasureField {
    FieldId: string;
    Expression: string | redacted.Redacted<string>;
}
export interface MeasureField {
    NumericalMeasureField?: NumericalMeasureField | undefined;
    CategoricalMeasureField?: CategoricalMeasureField | undefined;
    DateMeasureField?: DateMeasureField | undefined;
    CalculatedMeasureField?: CalculatedMeasureField | undefined;
}
export type MeasureFieldList = MeasureField[];
export interface TableAggregatedFieldWells {
    GroupBy?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface FormatConfiguration {
    StringFormatConfiguration?: StringFormatConfiguration | undefined;
    NumberFormatConfiguration?: NumberFormatConfiguration | undefined;
    DateTimeFormatConfiguration?: DateTimeFormatConfiguration | undefined;
}
export interface UnaggregatedField {
    FieldId: string;
    Column: ColumnIdentifier;
    FormatConfiguration?: FormatConfiguration | undefined;
}
export type TableUnaggregatedFieldList = UnaggregatedField[];
export interface TableUnaggregatedFieldWells {
    Values?: UnaggregatedField[] | undefined;
}
export interface TableFieldWells {
    TableAggregatedFieldWells?: TableAggregatedFieldWells | undefined;
    TableUnaggregatedFieldWells?: TableUnaggregatedFieldWells | undefined;
}
export interface FieldSort {
    FieldId: string;
    Direction: SortDirection;
}
export interface ColumnSort {
    SortBy: ColumnIdentifier;
    Direction: SortDirection;
    AggregationFunction?: AggregationFunction | undefined;
}
export interface FieldSortOptions {
    FieldSort?: FieldSort | undefined;
    ColumnSort?: ColumnSort | undefined;
}
export type RowSortList = FieldSortOptions[];
export type PageNumber = number;
export interface PaginationConfiguration {
    PageSize: number;
    PageNumber: number;
}
export interface TableSortConfiguration {
    RowSort?: FieldSortOptions[] | undefined;
    PaginationConfiguration?: PaginationConfiguration | undefined;
}
export type TableOrientation = "VERTICAL" | "HORIZONTAL" | (string & {});
export type TextWrap = "NONE" | "WRAP" | (string & {});
export type HorizontalTextAlignment = "LEFT" | "CENTER" | "RIGHT" | "AUTO" | (string & {});
export type VerticalTextAlignment = "TOP" | "MIDDLE" | "BOTTOM" | "AUTO" | (string & {});
export type TableFieldHeight = number;
export type TableBorderThickness = number;
export type TableBorderStyle = "NONE" | "SOLID" | (string & {});
export interface TableBorderOptions {
    Color?: string | undefined;
    Thickness?: number | undefined;
    Style?: TableBorderStyle | undefined;
}
export interface TableSideBorderOptions {
    InnerVertical?: TableBorderOptions | undefined;
    InnerHorizontal?: TableBorderOptions | undefined;
    Left?: TableBorderOptions | undefined;
    Right?: TableBorderOptions | undefined;
    Top?: TableBorderOptions | undefined;
    Bottom?: TableBorderOptions | undefined;
}
export interface GlobalTableBorderOptions {
    UniformBorder?: TableBorderOptions | undefined;
    SideSpecificBorder?: TableSideBorderOptions | undefined;
}
export interface TableCellStyle {
    Visibility?: Visibility | undefined;
    FontConfiguration?: FontConfiguration | undefined;
    TextWrap?: TextWrap | undefined;
    HorizontalTextAlignment?: HorizontalTextAlignment | undefined;
    VerticalTextAlignment?: VerticalTextAlignment | undefined;
    BackgroundColor?: string | undefined;
    Height?: number | undefined;
    Border?: GlobalTableBorderOptions | undefined;
}
export type WidgetStatus = "ENABLED" | "DISABLED" | (string & {});
export type RowAlternateColorList = string[];
export interface RowAlternateColorOptions {
    Status?: WidgetStatus | undefined;
    RowAlternateColors?: string[] | undefined;
    UsePrimaryBackgroundColor?: WidgetStatus | undefined;
}
export interface TableOptions {
    Orientation?: TableOrientation | undefined;
    HeaderStyle?: TableCellStyle | undefined;
    CellStyle?: TableCellStyle | undefined;
    RowAlternateColorOptions?: RowAlternateColorOptions | undefined;
}
export type TableTotalsPlacement = "START" | "END" | "AUTO" | (string & {});
export type TableTotalsScrollStatus = "PINNED" | "SCROLLED" | (string & {});
export type SimpleTotalAggregationFunction = "DEFAULT" | "SUM" | "AVERAGE" | "MIN" | "MAX" | "NONE" | (string & {});
export interface TotalAggregationFunction {
    SimpleTotalAggregationFunction?: SimpleTotalAggregationFunction | undefined;
}
export interface TotalAggregationOption {
    FieldId: string;
    TotalAggregationFunction: TotalAggregationFunction;
}
export type TotalAggregationOptionList = TotalAggregationOption[];
export interface TotalOptions {
    TotalsVisibility?: Visibility | undefined;
    Placement?: TableTotalsPlacement | undefined;
    ScrollStatus?: TableTotalsScrollStatus | undefined;
    CustomLabel?: string | undefined;
    TotalCellStyle?: TableCellStyle | undefined;
    TotalAggregationOptions?: TotalAggregationOption[] | undefined;
}
export type CustomLabel = string;
export type URLTargetConfiguration = "NEW_TAB" | "NEW_WINDOW" | "SAME_TAB" | (string & {});
export interface TableFieldCustomTextContent {
    Value?: string | undefined;
    FontConfiguration: FontConfiguration;
}
export type TableFieldIconSetType = "LINK" | (string & {});
export interface TableFieldCustomIconContent {
    Icon?: TableFieldIconSetType | undefined;
}
export interface TableFieldLinkContentConfiguration {
    CustomTextContent?: TableFieldCustomTextContent | undefined;
    CustomIconContent?: TableFieldCustomIconContent | undefined;
}
export interface TableFieldLinkConfiguration {
    Target: URLTargetConfiguration;
    Content: TableFieldLinkContentConfiguration;
}
export type TableCellImageScalingConfiguration = "FIT_TO_CELL_HEIGHT" | "FIT_TO_CELL_WIDTH" | "DO_NOT_SCALE" | (string & {});
export interface TableCellImageSizingConfiguration {
    TableCellImageScalingConfiguration?: TableCellImageScalingConfiguration | undefined;
}
export interface TableFieldImageConfiguration {
    SizingOptions?: TableCellImageSizingConfiguration | undefined;
}
export interface TableFieldURLConfiguration {
    LinkConfiguration?: TableFieldLinkConfiguration | undefined;
    ImageConfiguration?: TableFieldImageConfiguration | undefined;
}
export interface TableFieldOption {
    FieldId: string;
    Width?: string | undefined;
    CustomLabel?: string | undefined;
    Visibility?: Visibility | undefined;
    URLStyling?: TableFieldURLConfiguration | undefined;
}
export type TableFieldOptionList = TableFieldOption[];
export type FieldOrderList = string[];
export type TableFieldOrderList = string[];
export interface TablePinnedFieldOptions {
    PinnedLeftFields?: string[] | undefined;
}
export type TransposedColumnIndex = number;
export type TransposedColumnType = "ROW_HEADER_COLUMN" | "VALUE_COLUMN" | (string & {});
export interface TransposedTableOption {
    ColumnIndex?: number | undefined;
    ColumnWidth?: string | undefined;
    ColumnType: TransposedColumnType;
}
export type TransposedTableOptionList = TransposedTableOption[];
export interface TableFieldOptions {
    SelectedFieldOptions?: TableFieldOption[] | undefined;
    Order?: string[] | undefined;
    PinnedFieldOptions?: TablePinnedFieldOptions | undefined;
    TransposedTableOptions?: TransposedTableOption[] | undefined;
}
export interface TablePaginatedReportOptions {
    VerticalOverflowVisibility?: Visibility | undefined;
    OverflowColumnHeaderVisibility?: Visibility | undefined;
}
export interface DataBarsOptions {
    FieldId: string;
    PositiveColor?: string | undefined;
    NegativeColor?: string | undefined;
}
export type SparklineAxisBehavior = "SHARED" | "INDEPENDENT" | (string & {});
export type SparklineVisualType = "LINE" | "AREA_LINE" | (string & {});
export type LineInterpolation = "LINEAR" | "SMOOTH" | "STEPPED" | (string & {});
export type LineChartMarkerShape = "CIRCLE" | "TRIANGLE" | "SQUARE" | "DIAMOND" | "ROUNDED_SQUARE" | (string & {});
export interface LineChartMarkerStyleSettings {
    MarkerVisibility?: Visibility | undefined;
    MarkerShape?: LineChartMarkerShape | undefined;
    MarkerSize?: string | undefined;
    MarkerColor?: string | undefined;
}
export interface SparklinesOptions {
    FieldId: string;
    XAxisField: DimensionField;
    YAxisBehavior?: SparklineAxisBehavior | undefined;
    VisualType?: SparklineVisualType | undefined;
    LineColor?: string | undefined;
    LineInterpolation?: LineInterpolation | undefined;
    AllPointsMarker?: LineChartMarkerStyleSettings | undefined;
    MaxValueMarker?: LineChartMarkerStyleSettings | undefined;
    MinValueMarker?: LineChartMarkerStyleSettings | undefined;
}
export interface TableInlineVisualization {
    DataBars?: DataBarsOptions | undefined;
    Sparklines?: SparklinesOptions | undefined;
}
export type TableInlineVisualizationList = TableInlineVisualization[];
export type SelectedTooltipType = "BASIC" | "DETAILED" | "SHEET" | (string & {});
export type TooltipTitleType = "NONE" | "PRIMARY_VALUE" | (string & {});
export type TooltipTarget = "BOTH" | "BAR" | "LINE" | (string & {});
export interface FieldTooltipItem {
    FieldId: string;
    Label?: string | undefined;
    Visibility?: Visibility | undefined;
    TooltipTarget?: TooltipTarget | undefined;
}
export interface ColumnTooltipItem {
    Column: ColumnIdentifier;
    Label?: string | undefined;
    Visibility?: Visibility | undefined;
    Aggregation?: AggregationFunction | undefined;
    TooltipTarget?: TooltipTarget | undefined;
}
export interface TooltipItem {
    FieldTooltipItem?: FieldTooltipItem | undefined;
    ColumnTooltipItem?: ColumnTooltipItem | undefined;
}
export type TooltipItemList = TooltipItem[];
export interface FieldBasedTooltip {
    AggregationVisibility?: Visibility | undefined;
    TooltipTitleType?: TooltipTitleType | undefined;
    TooltipFields?: TooltipItem[] | undefined;
}
export interface SheetTooltip {
    SheetId?: string | undefined;
}
export interface TooltipOptions {
    TooltipVisibility?: Visibility | undefined;
    SelectedTooltipType?: SelectedTooltipType | undefined;
    FieldBasedTooltip?: FieldBasedTooltip | undefined;
    SheetTooltip?: SheetTooltip | undefined;
}
export type DashboardCustomizationStatus = "ENABLED" | "DISABLED" | (string & {});
export type VisualCustomizationAdditionalFieldsList = ColumnIdentifier[];
export interface VisualCustomizationFieldsConfiguration {
    Status?: DashboardCustomizationStatus | undefined;
    AdditionalFields?: ColumnIdentifier[] | undefined;
}
export interface DashboardCustomizationVisualOptions {
    FieldsConfiguration?: VisualCustomizationFieldsConfiguration | undefined;
}
export type DashboardBehavior = "ENABLED" | "DISABLED" | (string & {});
export interface VisualMenuOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface ContextMenuOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface VisualInteractionOptions {
    VisualMenuOption?: VisualMenuOption | undefined;
    ContextMenuOption?: ContextMenuOption | undefined;
}
export interface TableConfiguration {
    FieldWells?: TableFieldWells | undefined;
    SortConfiguration?: TableSortConfiguration | undefined;
    TableOptions?: TableOptions | undefined;
    TotalOptions?: TotalOptions | undefined;
    FieldOptions?: TableFieldOptions | undefined;
    PaginatedReportOptions?: TablePaginatedReportOptions | undefined;
    TableInlineVisualizations?: TableInlineVisualization[] | undefined;
    Tooltip?: TooltipOptions | undefined;
    DashboardCustomizationVisualOptions?: DashboardCustomizationVisualOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface ConditionalFormattingSolidColor {
    Expression: string | redacted.Redacted<string>;
    Color?: string | undefined;
}
export interface GradientStop {
    GradientOffset: number;
    DataValue?: number | undefined;
    Color?: string | undefined;
}
export type GradientStopList = GradientStop[];
export interface GradientColor {
    Stops?: GradientStop[] | undefined;
}
export interface ConditionalFormattingGradientColor {
    Expression: string | redacted.Redacted<string>;
    Color: GradientColor;
}
export interface ConditionalFormattingColor {
    Solid?: ConditionalFormattingSolidColor | undefined;
    Gradient?: ConditionalFormattingGradientColor | undefined;
}
export type ConditionalFormattingIconSetType = "PLUS_MINUS" | "CHECK_X" | "THREE_COLOR_ARROW" | "THREE_GRAY_ARROW" | "CARET_UP_MINUS_DOWN" | "THREE_SHAPE" | "THREE_CIRCLE" | "FLAGS" | "BARS" | "FOUR_COLOR_ARROW" | "FOUR_GRAY_ARROW" | (string & {});
export interface ConditionalFormattingIconSet {
    Expression: string | redacted.Redacted<string>;
    IconSetType?: ConditionalFormattingIconSetType | undefined;
}
export type Icon = "CARET_UP" | "CARET_DOWN" | "PLUS" | "MINUS" | "ARROW_UP" | "ARROW_DOWN" | "ARROW_LEFT" | "ARROW_UP_LEFT" | "ARROW_DOWN_LEFT" | "ARROW_RIGHT" | "ARROW_UP_RIGHT" | "ARROW_DOWN_RIGHT" | "FACE_UP" | "FACE_DOWN" | "FACE_FLAT" | "ONE_BAR" | "TWO_BAR" | "THREE_BAR" | "CIRCLE" | "TRIANGLE" | "SQUARE" | "FLAG" | "THUMBS_UP" | "THUMBS_DOWN" | "CHECKMARK" | "X" | (string & {});
export type UnicodeIcon = string;
export interface ConditionalFormattingCustomIconOptions {
    Icon?: Icon | undefined;
    UnicodeIcon?: string | undefined;
}
export type ConditionalFormattingIconDisplayOption = "ICON_ONLY" | (string & {});
export interface ConditionalFormattingIconDisplayConfiguration {
    IconDisplayOption?: ConditionalFormattingIconDisplayOption | undefined;
}
export interface ConditionalFormattingCustomIconCondition {
    Expression: string | redacted.Redacted<string>;
    IconOptions: ConditionalFormattingCustomIconOptions;
    Color?: string | undefined;
    DisplayConfiguration?: ConditionalFormattingIconDisplayConfiguration | undefined;
}
export interface ConditionalFormattingIcon {
    IconSet?: ConditionalFormattingIconSet | undefined;
    CustomCondition?: ConditionalFormattingCustomIconCondition | undefined;
}
export interface TextConditionalFormat {
    BackgroundColor?: ConditionalFormattingColor | undefined;
    TextColor?: ConditionalFormattingColor | undefined;
    Icon?: ConditionalFormattingIcon | undefined;
}
export interface TableCellConditionalFormatting {
    FieldId: string;
    TextFormat?: TextConditionalFormat | undefined;
}
export interface TableRowConditionalFormatting {
    BackgroundColor?: ConditionalFormattingColor | undefined;
    TextColor?: ConditionalFormattingColor | undefined;
}
export interface TableConditionalFormattingOption {
    Cell?: TableCellConditionalFormatting | undefined;
    Row?: TableRowConditionalFormatting | undefined;
}
export type TableConditionalFormattingOptionList = TableConditionalFormattingOption[];
export interface TableConditionalFormatting {
    ConditionalFormattingOptions?: TableConditionalFormattingOption[] | undefined;
}
export type VisualCustomActionName = string;
export type VisualCustomActionTrigger = "DATA_POINT_CLICK" | "DATA_POINT_MENU" | (string & {});
export type SelectedFieldList = string[];
export type SelectedFieldOptions = "ALL_FIELDS" | (string & {});
export type CustomActionColumnList = ColumnIdentifier[];
export interface FilterOperationSelectedFieldsConfiguration {
    SelectedFields?: string[] | undefined;
    SelectedFieldOptions?: SelectedFieldOptions | undefined;
    SelectedColumns?: ColumnIdentifier[] | undefined;
}
export type TargetVisualList = string[];
export type TargetVisualOptions = "ALL_VISUALS" | (string & {});
export interface SameSheetTargetVisualConfiguration {
    TargetVisuals?: string[] | undefined;
    TargetVisualOptions?: TargetVisualOptions | undefined;
}
export interface FilterOperationTargetVisualsConfiguration {
    SameSheetTargetVisualConfiguration?: SameSheetTargetVisualConfiguration | undefined;
}
export interface CustomActionFilterOperation {
    SelectedFieldsConfiguration: FilterOperationSelectedFieldsConfiguration;
    TargetVisualsConfiguration: FilterOperationTargetVisualsConfiguration;
}
export interface LocalNavigationConfiguration {
    TargetSheetId: string;
}
export interface CustomActionNavigationOperation {
    LocalNavigationConfiguration?: LocalNavigationConfiguration | undefined;
}
export type URLOperationTemplate = string;
export interface CustomActionURLOperation {
    URLTemplate: string;
    URLTarget: URLTargetConfiguration;
}
export type SensitiveStringObject = string | redacted.Redacted<string>;
export type StringDefaultValueList = (string | redacted.Redacted<string>)[];
export type SensitiveLongObject = number;
export type IntegerDefaultValueList = number[];
export type SensitiveDoubleObject = number;
export type DecimalDefaultValueList = number[];
export type DateTimeDefaultValueList = Date[];
export interface CustomParameterValues {
    StringValues?: (string | redacted.Redacted<string>)[] | undefined;
    IntegerValues?: number[] | undefined;
    DecimalValues?: number[] | undefined;
    DateTimeValues?: Date[] | undefined;
}
export interface CustomValuesConfiguration {
    IncludeNullValue?: boolean | undefined;
    CustomValues: CustomParameterValues;
}
export type SelectAllValueOptions = "ALL_VALUES" | (string & {});
export interface DestinationParameterValueConfiguration {
    CustomValuesConfiguration?: CustomValuesConfiguration | undefined;
    SelectAllValueOptions?: SelectAllValueOptions | undefined;
    SourceParameterName?: string | undefined;
    SourceField?: string | undefined;
    SourceColumn?: ColumnIdentifier | undefined;
}
export interface SetParameterValueConfiguration {
    DestinationParameterName: string;
    Value: DestinationParameterValueConfiguration;
}
export type SetParameterValueConfigurationList = SetParameterValueConfiguration[];
export interface CustomActionSetParametersOperation {
    ParameterValueConfigurations: SetParameterValueConfiguration[];
}
export interface VisualCustomActionOperation {
    FilterOperation?: CustomActionFilterOperation | undefined;
    NavigationOperation?: CustomActionNavigationOperation | undefined;
    URLOperation?: CustomActionURLOperation | undefined;
    SetParametersOperation?: CustomActionSetParametersOperation | undefined;
}
export type VisualCustomActionOperationList = VisualCustomActionOperation[];
export interface VisualCustomAction {
    CustomActionId: string;
    Name: string;
    Status?: WidgetStatus | undefined;
    Trigger: VisualCustomActionTrigger;
    ActionOperations: VisualCustomActionOperation[];
}
export type VisualCustomActionList = VisualCustomAction[];
export interface TableVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: TableConfiguration | undefined;
    ConditionalFormatting?: TableConditionalFormatting | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type PivotTableDimensionList = DimensionField[];
export type PivotMeasureFieldList = MeasureField[];
export interface PivotTableAggregatedFieldWells {
    Rows?: DimensionField[] | undefined;
    Columns?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface PivotTableFieldWells {
    PivotTableAggregatedFieldWells?: PivotTableAggregatedFieldWells | undefined;
}
export type FieldValue = string | redacted.Redacted<string>;
export type PivotTableDataPathType = "HIERARCHY_ROWS_LAYOUT_COLUMN" | "MULTIPLE_ROW_METRICS_COLUMN" | "EMPTY_COLUMN_HEADER" | "COUNT_METRIC_COLUMN" | (string & {});
export interface DataPathType {
    PivotTableDataPathType?: PivotTableDataPathType | undefined;
}
export interface DataPathValue {
    FieldId?: string | undefined;
    FieldValue?: string | redacted.Redacted<string> | undefined;
    DataPathType?: DataPathType | undefined;
}
export type DataPathValueList = DataPathValue[];
export interface DataPathSort {
    Direction: SortDirection;
    SortPaths: DataPathValue[];
}
export interface PivotTableSortBy {
    Field?: FieldSort | undefined;
    Column?: ColumnSort | undefined;
    DataPath?: DataPathSort | undefined;
}
export interface PivotFieldSortOptions {
    FieldId: string;
    SortBy: PivotTableSortBy;
}
export type PivotFieldSortOptionsList = PivotFieldSortOptions[];
export interface PivotTableSortConfiguration {
    FieldSortOptions?: PivotFieldSortOptions[] | undefined;
}
export type PivotTableMetricPlacement = "ROW" | "COLUMN" | (string & {});
export type PivotTableRowsLayout = "TABULAR" | "HIERARCHY" | (string & {});
export type PivotTableRowsLabelText = string;
export interface PivotTableRowsLabelOptions {
    Visibility?: Visibility | undefined;
    CustomLabel?: string | undefined;
}
export interface PivotTableOptions {
    MetricPlacement?: PivotTableMetricPlacement | undefined;
    SingleMetricVisibility?: Visibility | undefined;
    ColumnNamesVisibility?: Visibility | undefined;
    ToggleButtonsVisibility?: Visibility | undefined;
    ColumnHeaderStyle?: TableCellStyle | undefined;
    RowHeaderStyle?: TableCellStyle | undefined;
    CellStyle?: TableCellStyle | undefined;
    RowFieldNamesStyle?: TableCellStyle | undefined;
    RowAlternateColorOptions?: RowAlternateColorOptions | undefined;
    CollapsedRowDimensionsVisibility?: Visibility | undefined;
    RowsLayout?: PivotTableRowsLayout | undefined;
    RowsLabelOptions?: PivotTableRowsLabelOptions | undefined;
    DefaultCellWidth?: string | undefined;
}
export type PivotTableSubtotalLevel = "ALL" | "CUSTOM" | "LAST" | (string & {});
export interface PivotTableFieldSubtotalOptions {
    FieldId?: string | undefined;
}
export type PivotTableFieldSubtotalOptionsList = PivotTableFieldSubtotalOptions[];
export type StyledCellType = "TOTAL" | "METRIC_HEADER" | "VALUE" | (string & {});
export interface TableStyleTarget {
    CellType: StyledCellType;
}
export type TableStyleTargetList = TableStyleTarget[];
export interface SubtotalOptions {
    TotalsVisibility?: Visibility | undefined;
    CustomLabel?: string | undefined;
    FieldLevel?: PivotTableSubtotalLevel | undefined;
    FieldLevelOptions?: PivotTableFieldSubtotalOptions[] | undefined;
    TotalCellStyle?: TableCellStyle | undefined;
    ValueCellStyle?: TableCellStyle | undefined;
    MetricHeaderCellStyle?: TableCellStyle | undefined;
    StyleTargets?: TableStyleTarget[] | undefined;
}
export interface PivotTotalOptions {
    TotalsVisibility?: Visibility | undefined;
    Placement?: TableTotalsPlacement | undefined;
    ScrollStatus?: TableTotalsScrollStatus | undefined;
    CustomLabel?: string | undefined;
    TotalCellStyle?: TableCellStyle | undefined;
    ValueCellStyle?: TableCellStyle | undefined;
    MetricHeaderCellStyle?: TableCellStyle | undefined;
    TotalAggregationOptions?: TotalAggregationOption[] | undefined;
}
export interface PivotTableTotalOptions {
    RowSubtotalOptions?: SubtotalOptions | undefined;
    ColumnSubtotalOptions?: SubtotalOptions | undefined;
    RowTotalOptions?: PivotTotalOptions | undefined;
    ColumnTotalOptions?: PivotTotalOptions | undefined;
}
export interface PivotTableFieldOption {
    FieldId: string;
    CustomLabel?: string | undefined;
    Visibility?: Visibility | undefined;
}
export type PivotTableFieldOptionList = PivotTableFieldOption[];
export interface PivotTableDataPathOption {
    DataPathList: DataPathValue[];
    Width?: string | undefined;
}
export type PivotTableDataPathOptionList = PivotTableDataPathOption[];
export interface PivotTableFieldCollapseStateTarget {
    FieldId?: string | undefined;
    FieldDataPathValues?: DataPathValue[] | undefined;
}
export type PivotTableFieldCollapseState = "COLLAPSED" | "EXPANDED" | (string & {});
export interface PivotTableFieldCollapseStateOption {
    Target: PivotTableFieldCollapseStateTarget;
    State?: PivotTableFieldCollapseState | undefined;
}
export type PivotTableFieldCollapseStateOptionList = PivotTableFieldCollapseStateOption[];
export interface PivotTableFieldOptions {
    SelectedFieldOptions?: PivotTableFieldOption[] | undefined;
    DataPathOptions?: PivotTableDataPathOption[] | undefined;
    CollapseStateOptions?: PivotTableFieldCollapseStateOption[] | undefined;
}
export interface PivotTablePaginatedReportOptions {
    VerticalOverflowVisibility?: Visibility | undefined;
    OverflowColumnHeaderVisibility?: Visibility | undefined;
}
export interface PivotTableConfiguration {
    FieldWells?: PivotTableFieldWells | undefined;
    SortConfiguration?: PivotTableSortConfiguration | undefined;
    TableOptions?: PivotTableOptions | undefined;
    TotalOptions?: PivotTableTotalOptions | undefined;
    FieldOptions?: PivotTableFieldOptions | undefined;
    PaginatedReportOptions?: PivotTablePaginatedReportOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    DashboardCustomizationVisualOptions?: DashboardCustomizationVisualOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export type PivotTableConditionalFormattingScopeRole = "FIELD" | "FIELD_TOTAL" | "GRAND_TOTAL" | (string & {});
export interface PivotTableConditionalFormattingScope {
    Role?: PivotTableConditionalFormattingScopeRole | undefined;
}
export type PivotTableConditionalFormattingScopeList = PivotTableConditionalFormattingScope[];
export interface PivotTableCellConditionalFormatting {
    FieldId: string;
    TextFormat?: TextConditionalFormat | undefined;
    Scope?: PivotTableConditionalFormattingScope | undefined;
    Scopes?: PivotTableConditionalFormattingScope[] | undefined;
}
export interface PivotTableConditionalFormattingOption {
    Cell?: PivotTableCellConditionalFormatting | undefined;
}
export type PivotTableConditionalFormattingOptionList = PivotTableConditionalFormattingOption[];
export interface PivotTableConditionalFormatting {
    ConditionalFormattingOptions?: PivotTableConditionalFormattingOption[] | undefined;
}
export interface PivotTableVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: PivotTableConfiguration | undefined;
    ConditionalFormatting?: PivotTableConditionalFormatting | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type SmallMultiplesDimensionFieldList = DimensionField[];
export interface BarChartAggregatedFieldWells {
    Category?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
    Colors?: DimensionField[] | undefined;
    SmallMultiples?: DimensionField[] | undefined;
}
export interface BarChartFieldWells {
    BarChartAggregatedFieldWells?: BarChartAggregatedFieldWells | undefined;
}
export type FieldSortOptionsList = FieldSortOptions[];
export type OtherCategories = "INCLUDE" | "EXCLUDE" | (string & {});
export interface ItemsLimitConfiguration {
    ItemsLimit?: number | undefined;
    OtherCategories?: OtherCategories | undefined;
}
export interface BarChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    CategoryItemsLimit?: ItemsLimitConfiguration | undefined;
    ColorSort?: FieldSortOptions[] | undefined;
    ColorItemsLimit?: ItemsLimitConfiguration | undefined;
    SmallMultiplesSort?: FieldSortOptions[] | undefined;
    SmallMultiplesLimitConfiguration?: ItemsLimitConfiguration | undefined;
}
export type BarChartOrientation = "HORIZONTAL" | "VERTICAL" | (string & {});
export type BarsArrangement = "CLUSTERED" | "STACKED" | "STACKED_PERCENT" | (string & {});
export interface DataPathColor {
    Element: DataPathValue;
    Color: string;
    TimeGranularity?: TimeGranularity | undefined;
}
export type DataPathColorList = DataPathColor[];
export interface VisualPalette {
    ChartColor?: string | undefined;
    ColorMap?: DataPathColor[] | undefined;
}
export type VisiblePanelRows = number;
export type VisiblePanelColumns = number;
export interface PanelTitleOptions {
    Visibility?: Visibility | undefined;
    FontConfiguration?: FontConfiguration | undefined;
    HorizontalTextAlignment?: HorizontalTextAlignment | undefined;
}
export type PanelBorderStyle = "SOLID" | "DASHED" | "DOTTED" | (string & {});
export type HexColorWithTransparency = string;
export interface PanelConfiguration {
    Title?: PanelTitleOptions | undefined;
    BorderVisibility?: Visibility | undefined;
    BorderThickness?: string | undefined;
    BorderStyle?: PanelBorderStyle | undefined;
    BorderColor?: string | undefined;
    GutterVisibility?: Visibility | undefined;
    GutterSpacing?: string | undefined;
    BackgroundVisibility?: Visibility | undefined;
    BackgroundColor?: string | undefined;
}
export type SmallMultiplesAxisScale = "SHARED" | "INDEPENDENT" | (string & {});
export type SmallMultiplesAxisPlacement = "OUTSIDE" | "INSIDE" | (string & {});
export interface SmallMultiplesAxisProperties {
    Scale?: SmallMultiplesAxisScale | undefined;
    Placement?: SmallMultiplesAxisPlacement | undefined;
}
export interface SmallMultiplesOptions {
    MaxVisibleRows?: number | undefined;
    MaxVisibleColumns?: number | undefined;
    PanelConfiguration?: PanelConfiguration | undefined;
    XAxis?: SmallMultiplesAxisProperties | undefined;
    YAxis?: SmallMultiplesAxisProperties | undefined;
}
export interface AxisTickLabelOptions {
    LabelOptions?: LabelOptions | undefined;
    RotationAngle?: number | undefined;
}
export interface AxisLinearScale {
    StepCount?: number | undefined;
    StepSize?: number | undefined;
}
export interface AxisLogarithmicScale {
    Base?: number | undefined;
}
export interface AxisScale {
    Linear?: AxisLinearScale | undefined;
    Logarithmic?: AxisLogarithmicScale | undefined;
}
export interface AxisDisplayMinMaxRange {
    Minimum?: number | undefined;
    Maximum?: number | undefined;
}
export interface AxisDisplayDataDrivenRange {
}
export interface AxisDisplayRange {
    MinMax?: AxisDisplayMinMaxRange | undefined;
    DataDriven?: AxisDisplayDataDrivenRange | undefined;
}
export interface NumericAxisOptions {
    Scale?: AxisScale | undefined;
    Range?: AxisDisplayRange | undefined;
}
export interface DateAxisOptions {
    MissingDateVisibility?: Visibility | undefined;
}
export interface AxisDataOptions {
    NumericAxisOptions?: NumericAxisOptions | undefined;
    DateAxisOptions?: DateAxisOptions | undefined;
}
export type PercentNumber = number;
export interface PercentVisibleRange {
    From?: number | undefined;
    To?: number | undefined;
}
export interface VisibleRangeOptions {
    PercentRange?: PercentVisibleRange | undefined;
}
export interface ScrollBarOptions {
    Visibility?: Visibility | undefined;
    VisibleRange?: VisibleRangeOptions | undefined;
}
export interface AxisDisplayOptions {
    TickLabelOptions?: AxisTickLabelOptions | undefined;
    AxisLineVisibility?: Visibility | undefined;
    GridLineVisibility?: Visibility | undefined;
    DataOptions?: AxisDataOptions | undefined;
    ScrollbarOptions?: ScrollBarOptions | undefined;
    AxisOffset?: string | undefined;
}
export interface AxisLabelReferenceOptions {
    FieldId: string;
    Column: ColumnIdentifier;
}
export interface AxisLabelOptions {
    FontConfiguration?: FontConfiguration | undefined;
    CustomLabel?: string | undefined;
    ApplyTo?: AxisLabelReferenceOptions | undefined;
}
export type AxisLabelOptionsList = AxisLabelOptions[];
export interface ChartAxisLabelOptions {
    Visibility?: Visibility | undefined;
    SortIconVisibility?: Visibility | undefined;
    AxisLabelOptions?: AxisLabelOptions[] | undefined;
}
export type ElementValue = string;
export type DecalPatternType = "SOLID" | "DIAGONAL_MEDIUM" | "CIRCLE_MEDIUM" | "DIAMOND_GRID_MEDIUM" | "CHECKERBOARD_MEDIUM" | "TRIANGLE_MEDIUM" | "DIAGONAL_OPPOSITE_MEDIUM" | "DIAMOND_MEDIUM" | "DIAGONAL_LARGE" | "CIRCLE_LARGE" | "DIAMOND_GRID_LARGE" | "CHECKERBOARD_LARGE" | "TRIANGLE_LARGE" | "DIAGONAL_OPPOSITE_LARGE" | "DIAMOND_LARGE" | "DIAGONAL_SMALL" | "CIRCLE_SMALL" | "DIAMOND_GRID_SMALL" | "CHECKERBOARD_SMALL" | "TRIANGLE_SMALL" | "DIAGONAL_OPPOSITE_SMALL" | "DIAMOND_SMALL" | (string & {});
export type DecalStyleType = "Manual" | "Auto" | (string & {});
export interface DecalSettings {
    ElementValue?: string | undefined;
    DecalVisibility?: Visibility | undefined;
    DecalColor?: string | undefined;
    DecalPatternType?: DecalPatternType | undefined;
    DecalStyleType?: DecalStyleType | undefined;
}
export interface BorderSettings {
    BorderVisibility?: Visibility | undefined;
    BorderWidth?: string | undefined;
    BorderColor?: string | undefined;
}
export interface BarChartDefaultSeriesSettings {
    DecalSettings?: DecalSettings | undefined;
    BorderSettings?: BorderSettings | undefined;
}
export interface BarChartSeriesSettings {
    DecalSettings?: DecalSettings | undefined;
    BorderSettings?: BorderSettings | undefined;
}
export interface FieldBarSeriesItem {
    FieldId: string;
    Settings?: BarChartSeriesSettings | undefined;
}
export interface DataFieldBarSeriesItem {
    FieldId: string;
    FieldValue?: string | redacted.Redacted<string> | undefined;
    Settings?: BarChartSeriesSettings | undefined;
}
export interface BarSeriesItem {
    FieldBarSeriesItem?: FieldBarSeriesItem | undefined;
    DataFieldBarSeriesItem?: DataFieldBarSeriesItem | undefined;
}
export type BarSeriesItemList = BarSeriesItem[];
export type LegendPosition = "AUTO" | "RIGHT" | "BOTTOM" | "TOP" | (string & {});
export interface LegendOptions {
    Visibility?: Visibility | undefined;
    Title?: LabelOptions | undefined;
    Position?: LegendPosition | undefined;
    Width?: string | undefined;
    Height?: string | undefined;
    ValueFontConfiguration?: FontConfiguration | undefined;
}
export interface FieldLabelType {
    FieldId?: string | undefined;
    Visibility?: Visibility | undefined;
}
export interface DataPathLabelType {
    FieldId?: string | undefined;
    FieldValue?: string | redacted.Redacted<string> | undefined;
    Visibility?: Visibility | undefined;
}
export interface RangeEndsLabelType {
    Visibility?: Visibility | undefined;
}
export interface MinimumLabelType {
    Visibility?: Visibility | undefined;
}
export interface MaximumLabelType {
    Visibility?: Visibility | undefined;
}
export interface DataLabelType {
    FieldLabelType?: FieldLabelType | undefined;
    DataPathLabelType?: DataPathLabelType | undefined;
    RangeEndsLabelType?: RangeEndsLabelType | undefined;
    MinimumLabelType?: MinimumLabelType | undefined;
    MaximumLabelType?: MaximumLabelType | undefined;
}
export type DataLabelTypes = DataLabelType[];
export type DataLabelPosition = "INSIDE" | "OUTSIDE" | "LEFT" | "TOP" | "BOTTOM" | "RIGHT" | (string & {});
export type DataLabelContent = "VALUE" | "PERCENT" | "VALUE_AND_PERCENT" | (string & {});
export type DataLabelOverlap = "DISABLE_OVERLAP" | "ENABLE_OVERLAP" | (string & {});
export interface DataLabelOptions {
    Visibility?: Visibility | undefined;
    CategoryLabelVisibility?: Visibility | undefined;
    MeasureLabelVisibility?: Visibility | undefined;
    DataLabelTypes?: DataLabelType[] | undefined;
    Position?: DataLabelPosition | undefined;
    LabelContent?: DataLabelContent | undefined;
    LabelFontConfiguration?: FontConfiguration | undefined;
    LabelColor?: string | undefined;
    Overlap?: DataLabelOverlap | undefined;
    TotalsVisibility?: Visibility | undefined;
}
export interface ReferenceLineStaticDataConfiguration {
    Value: number;
}
export interface ReferenceLineDynamicDataConfiguration {
    Column: ColumnIdentifier;
    MeasureAggregationFunction?: AggregationFunction | undefined;
    Calculation: NumericalAggregationFunction;
}
export type AxisBinding = "PRIMARY_YAXIS" | "SECONDARY_YAXIS" | (string & {});
export type ReferenceLineSeriesType = "BAR" | "LINE" | (string & {});
export interface ReferenceLineDataConfiguration {
    StaticConfiguration?: ReferenceLineStaticDataConfiguration | undefined;
    DynamicConfiguration?: ReferenceLineDynamicDataConfiguration | undefined;
    AxisBinding?: AxisBinding | undefined;
    SeriesType?: ReferenceLineSeriesType | undefined;
}
export type ReferenceLinePatternType = "SOLID" | "DASHED" | "DOTTED" | (string & {});
export interface ReferenceLineStyleConfiguration {
    Pattern?: ReferenceLinePatternType | undefined;
    Color?: string | undefined;
}
export type ReferenceLineValueLabelRelativePosition = "BEFORE_CUSTOM_LABEL" | "AFTER_CUSTOM_LABEL" | (string & {});
export interface ReferenceLineValueLabelConfiguration {
    RelativePosition?: ReferenceLineValueLabelRelativePosition | undefined;
    FormatConfiguration?: NumericFormatConfiguration | undefined;
}
export interface ReferenceLineCustomLabelConfiguration {
    CustomLabel: string;
}
export type ReferenceLineLabelHorizontalPosition = "LEFT" | "CENTER" | "RIGHT" | (string & {});
export type ReferenceLineLabelVerticalPosition = "ABOVE" | "BELOW" | (string & {});
export interface ReferenceLineLabelConfiguration {
    ValueLabelConfiguration?: ReferenceLineValueLabelConfiguration | undefined;
    CustomLabelConfiguration?: ReferenceLineCustomLabelConfiguration | undefined;
    FontConfiguration?: FontConfiguration | undefined;
    FontColor?: string | undefined;
    HorizontalPosition?: ReferenceLineLabelHorizontalPosition | undefined;
    VerticalPosition?: ReferenceLineLabelVerticalPosition | undefined;
}
export interface ReferenceLine {
    Status?: WidgetStatus | undefined;
    DataConfiguration: ReferenceLineDataConfiguration;
    StyleConfiguration?: ReferenceLineStyleConfiguration | undefined;
    LabelConfiguration?: ReferenceLineLabelConfiguration | undefined;
}
export type ReferenceLineList = ReferenceLine[];
export type ContributorDimensionList = ColumnIdentifier[];
export interface ContributionAnalysisDefault {
    MeasureFieldId: string;
    ContributorDimensions: ColumnIdentifier[];
}
export type ContributionAnalysisDefaultList = ContributionAnalysisDefault[];
export interface BarChartConfiguration {
    FieldWells?: BarChartFieldWells | undefined;
    SortConfiguration?: BarChartSortConfiguration | undefined;
    Orientation?: BarChartOrientation | undefined;
    BarsArrangement?: BarsArrangement | undefined;
    VisualPalette?: VisualPalette | undefined;
    SmallMultiplesOptions?: SmallMultiplesOptions | undefined;
    CategoryAxis?: AxisDisplayOptions | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    ValueAxis?: AxisDisplayOptions | undefined;
    ValueLabelOptions?: ChartAxisLabelOptions | undefined;
    ColorLabelOptions?: ChartAxisLabelOptions | undefined;
    DefaultSeriesSettings?: BarChartDefaultSeriesSettings | undefined;
    Series?: BarSeriesItem[] | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    ReferenceLines?: ReferenceLine[] | undefined;
    ContributionAnalysisDefaults?: ContributionAnalysisDefault[] | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export type ExplicitHierarchyColumnList = ColumnIdentifier[];
export interface NumericEqualityDrillDownFilter {
    Column: ColumnIdentifier;
    Value: number;
}
export type CategoryValue = string;
export type CategoryValueList = string[];
export interface CategoryDrillDownFilter {
    Column: ColumnIdentifier;
    CategoryValues: string[];
}
export interface TimeRangeDrillDownFilter {
    Column: ColumnIdentifier;
    RangeMinimum: Date;
    RangeMaximum: Date;
    TimeGranularity: TimeGranularity;
}
export interface DrillDownFilter {
    NumericEqualityFilter?: NumericEqualityDrillDownFilter | undefined;
    CategoryFilter?: CategoryDrillDownFilter | undefined;
    TimeRangeFilter?: TimeRangeDrillDownFilter | undefined;
}
export type DrillDownFilterList = DrillDownFilter[];
export interface ExplicitHierarchy {
    HierarchyId: string;
    Columns: ColumnIdentifier[];
    DrillDownFilters?: DrillDownFilter[] | undefined;
}
export interface DateTimeHierarchy {
    HierarchyId: string;
    DrillDownFilters?: DrillDownFilter[] | undefined;
}
export type PredefinedHierarchyColumnList = ColumnIdentifier[];
export interface PredefinedHierarchy {
    HierarchyId: string;
    Columns: ColumnIdentifier[];
    DrillDownFilters?: DrillDownFilter[] | undefined;
}
export interface ColumnHierarchy {
    ExplicitHierarchy?: ExplicitHierarchy | undefined;
    DateTimeHierarchy?: DateTimeHierarchy | undefined;
    PredefinedHierarchy?: PredefinedHierarchy | undefined;
}
export type ColumnHierarchyList = ColumnHierarchy[];
export interface BarChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: BarChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface KPIFieldWells {
    Values?: MeasureField[] | undefined;
    TargetValues?: MeasureField[] | undefined;
    TrendGroups?: DimensionField[] | undefined;
}
export interface KPISortConfiguration {
    TrendGroupSort?: FieldSortOptions[] | undefined;
}
export interface ProgressBarOptions {
    Visibility?: Visibility | undefined;
}
export interface TrendArrowOptions {
    Visibility?: Visibility | undefined;
}
export interface SecondaryValueOptions {
    Visibility?: Visibility | undefined;
}
export type ComparisonMethod = "DIFFERENCE" | "PERCENT_DIFFERENCE" | "PERCENT" | (string & {});
export interface ComparisonFormatConfiguration {
    NumberDisplayFormatConfiguration?: NumberDisplayFormatConfiguration | undefined;
    PercentageDisplayFormatConfiguration?: PercentageDisplayFormatConfiguration | undefined;
}
export interface ComparisonConfiguration {
    ComparisonMethod?: ComparisonMethod | undefined;
    ComparisonFormat?: ComparisonFormatConfiguration | undefined;
}
export type PrimaryValueDisplayType = "HIDDEN" | "COMPARISON" | "ACTUAL" | (string & {});
export type KPISparklineType = "LINE" | "AREA" | (string & {});
export interface KPISparklineOptions {
    Visibility?: Visibility | undefined;
    Type: KPISparklineType;
    Color?: string | undefined;
    TooltipVisibility?: Visibility | undefined;
}
export type KPIVisualStandardLayoutType = "CLASSIC" | "VERTICAL" | (string & {});
export interface KPIVisualStandardLayout {
    Type: KPIVisualStandardLayoutType;
}
export interface KPIVisualLayoutOptions {
    StandardLayout?: KPIVisualStandardLayout | undefined;
}
export interface KPIOptions {
    ProgressBar?: ProgressBarOptions | undefined;
    TrendArrows?: TrendArrowOptions | undefined;
    SecondaryValue?: SecondaryValueOptions | undefined;
    Comparison?: ComparisonConfiguration | undefined;
    PrimaryValueDisplayType?: PrimaryValueDisplayType | undefined;
    PrimaryValueFontConfiguration?: FontConfiguration | undefined;
    SecondaryValueFontConfiguration?: FontConfiguration | undefined;
    Sparkline?: KPISparklineOptions | undefined;
    VisualLayoutOptions?: KPIVisualLayoutOptions | undefined;
}
export interface KPIConfiguration {
    FieldWells?: KPIFieldWells | undefined;
    SortConfiguration?: KPISortConfiguration | undefined;
    KPIOptions?: KPIOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface KPIPrimaryValueConditionalFormatting {
    TextColor?: ConditionalFormattingColor | undefined;
    Icon?: ConditionalFormattingIcon | undefined;
}
export interface KPIProgressBarConditionalFormatting {
    ForegroundColor?: ConditionalFormattingColor | undefined;
}
export interface KPIActualValueConditionalFormatting {
    TextColor?: ConditionalFormattingColor | undefined;
    Icon?: ConditionalFormattingIcon | undefined;
}
export interface KPIComparisonValueConditionalFormatting {
    TextColor?: ConditionalFormattingColor | undefined;
    Icon?: ConditionalFormattingIcon | undefined;
}
export interface KPIConditionalFormattingOption {
    PrimaryValue?: KPIPrimaryValueConditionalFormatting | undefined;
    ProgressBar?: KPIProgressBarConditionalFormatting | undefined;
    ActualValue?: KPIActualValueConditionalFormatting | undefined;
    ComparisonValue?: KPIComparisonValueConditionalFormatting | undefined;
}
export type KPIConditionalFormattingOptionList = KPIConditionalFormattingOption[];
export interface KPIConditionalFormatting {
    ConditionalFormattingOptions?: KPIConditionalFormattingOption[] | undefined;
}
export interface KPIVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: KPIConfiguration | undefined;
    ConditionalFormatting?: KPIConditionalFormatting | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface PieChartAggregatedFieldWells {
    Category?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
    SmallMultiples?: DimensionField[] | undefined;
}
export interface PieChartFieldWells {
    PieChartAggregatedFieldWells?: PieChartAggregatedFieldWells | undefined;
}
export interface PieChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    CategoryItemsLimit?: ItemsLimitConfiguration | undefined;
    SmallMultiplesSort?: FieldSortOptions[] | undefined;
    SmallMultiplesLimitConfiguration?: ItemsLimitConfiguration | undefined;
}
export type ArcThickness = "SMALL" | "MEDIUM" | "LARGE" | "WHOLE" | (string & {});
export interface ArcOptions {
    ArcThickness?: ArcThickness | undefined;
}
export interface DonutCenterOptions {
    LabelVisibility?: Visibility | undefined;
}
export interface DonutOptions {
    ArcOptions?: ArcOptions | undefined;
    DonutCenterOptions?: DonutCenterOptions | undefined;
}
export interface PieChartConfiguration {
    FieldWells?: PieChartFieldWells | undefined;
    SortConfiguration?: PieChartSortConfiguration | undefined;
    DonutOptions?: DonutOptions | undefined;
    SmallMultiplesOptions?: SmallMultiplesOptions | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    ValueLabelOptions?: ChartAxisLabelOptions | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    ContributionAnalysisDefaults?: ContributionAnalysisDefault[] | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface PieChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: PieChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface GaugeChartFieldWells {
    Values?: MeasureField[] | undefined;
    TargetValues?: MeasureField[] | undefined;
}
export interface ArcAxisDisplayRange {
    Min?: number | undefined;
    Max?: number | undefined;
}
export interface ArcAxisConfiguration {
    Range?: ArcAxisDisplayRange | undefined;
    ReserveRange?: number | undefined;
}
export type ArcThicknessOptions = "SMALL" | "MEDIUM" | "LARGE" | (string & {});
export interface ArcConfiguration {
    ArcAngle?: number | undefined;
    ArcThickness?: ArcThicknessOptions | undefined;
}
export interface GaugeChartOptions {
    PrimaryValueDisplayType?: PrimaryValueDisplayType | undefined;
    Comparison?: ComparisonConfiguration | undefined;
    ArcAxis?: ArcAxisConfiguration | undefined;
    Arc?: ArcConfiguration | undefined;
    PrimaryValueFontConfiguration?: FontConfiguration | undefined;
}
export interface GaugeChartColorConfiguration {
    ForegroundColor?: string | undefined;
    BackgroundColor?: string | undefined;
}
export interface GaugeChartConfiguration {
    FieldWells?: GaugeChartFieldWells | undefined;
    GaugeChartOptions?: GaugeChartOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    TooltipOptions?: TooltipOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    ColorConfiguration?: GaugeChartColorConfiguration | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface GaugeChartPrimaryValueConditionalFormatting {
    TextColor?: ConditionalFormattingColor | undefined;
    Icon?: ConditionalFormattingIcon | undefined;
}
export interface GaugeChartArcConditionalFormatting {
    ForegroundColor?: ConditionalFormattingColor | undefined;
}
export interface GaugeChartConditionalFormattingOption {
    PrimaryValue?: GaugeChartPrimaryValueConditionalFormatting | undefined;
    Arc?: GaugeChartArcConditionalFormatting | undefined;
}
export type GaugeChartConditionalFormattingOptionList = GaugeChartConditionalFormattingOption[];
export interface GaugeChartConditionalFormatting {
    ConditionalFormattingOptions?: GaugeChartConditionalFormattingOption[] | undefined;
}
export interface GaugeChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: GaugeChartConfiguration | undefined;
    ConditionalFormatting?: GaugeChartConditionalFormatting | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface LineChartAggregatedFieldWells {
    Category?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
    Colors?: DimensionField[] | undefined;
    SmallMultiples?: DimensionField[] | undefined;
}
export interface LineChartFieldWells {
    LineChartAggregatedFieldWells?: LineChartAggregatedFieldWells | undefined;
}
export interface LineChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    CategoryItemsLimitConfiguration?: ItemsLimitConfiguration | undefined;
    ColorItemsLimitConfiguration?: ItemsLimitConfiguration | undefined;
    SmallMultiplesSort?: FieldSortOptions[] | undefined;
    SmallMultiplesLimitConfiguration?: ItemsLimitConfiguration | undefined;
}
export type PeriodsForward = number;
export type PeriodsBackward = number;
export type PredictionInterval = number;
export type Seasonality = number;
export interface TimeBasedForecastProperties {
    PeriodsForward?: number | undefined;
    PeriodsBackward?: number | undefined;
    UpperBoundary?: number | undefined;
    LowerBoundary?: number | undefined;
    PredictionInterval?: number | undefined;
    Seasonality?: number | undefined;
}
export interface WhatIfPointScenario {
    Date: Date;
    Value: number;
}
export interface WhatIfRangeScenario {
    StartDate: Date;
    EndDate: Date;
    Value: number;
}
export interface ForecastScenario {
    WhatIfPointScenario?: WhatIfPointScenario | undefined;
    WhatIfRangeScenario?: WhatIfRangeScenario | undefined;
}
export interface ForecastConfiguration {
    ForecastProperties?: TimeBasedForecastProperties | undefined;
    Scenario?: ForecastScenario | undefined;
}
export type ForecastConfigurationList = ForecastConfiguration[];
export type LineChartType = "LINE" | "AREA" | "STACKED_AREA" | (string & {});
export type MissingDataTreatmentOption = "INTERPOLATE" | "SHOW_AS_ZERO" | "SHOW_AS_BLANK" | (string & {});
export interface MissingDataConfiguration {
    TreatmentOption?: MissingDataTreatmentOption | undefined;
}
export type MissingDataConfigurationList = MissingDataConfiguration[];
export interface LineSeriesAxisDisplayOptions {
    AxisOptions?: AxisDisplayOptions | undefined;
    MissingDataConfigurations?: MissingDataConfiguration[] | undefined;
}
export type SingleYAxisOption = "PRIMARY_Y_AXIS" | (string & {});
export interface YAxisOptions {
    YAxis: SingleYAxisOption;
}
export interface SingleAxisOptions {
    YAxisOptions?: YAxisOptions | undefined;
}
export type LineChartLineStyle = "SOLID" | "DOTTED" | "DASHED" | (string & {});
export interface LineChartLineStyleSettings {
    LineVisibility?: Visibility | undefined;
    LineInterpolation?: LineInterpolation | undefined;
    LineStyle?: LineChartLineStyle | undefined;
    LineWidth?: string | undefined;
}
export interface LineChartDefaultSeriesSettings {
    AxisBinding?: AxisBinding | undefined;
    LineStyleSettings?: LineChartLineStyleSettings | undefined;
    MarkerStyleSettings?: LineChartMarkerStyleSettings | undefined;
    DecalSettings?: DecalSettings | undefined;
}
export interface LineChartSeriesSettings {
    LineStyleSettings?: LineChartLineStyleSettings | undefined;
    MarkerStyleSettings?: LineChartMarkerStyleSettings | undefined;
    DecalSettings?: DecalSettings | undefined;
}
export interface FieldSeriesItem {
    FieldId: string;
    AxisBinding: AxisBinding;
    Settings?: LineChartSeriesSettings | undefined;
}
export interface DataFieldSeriesItem {
    FieldId: string;
    FieldValue?: string | redacted.Redacted<string> | undefined;
    AxisBinding: AxisBinding;
    Settings?: LineChartSeriesSettings | undefined;
}
export interface SeriesItem {
    FieldSeriesItem?: FieldSeriesItem | undefined;
    DataFieldSeriesItem?: DataFieldSeriesItem | undefined;
}
export type SeriesItemList = SeriesItem[];
export interface LineChartConfiguration {
    FieldWells?: LineChartFieldWells | undefined;
    SortConfiguration?: LineChartSortConfiguration | undefined;
    ForecastConfigurations?: ForecastConfiguration[] | undefined;
    Type?: LineChartType | undefined;
    SmallMultiplesOptions?: SmallMultiplesOptions | undefined;
    XAxisDisplayOptions?: AxisDisplayOptions | undefined;
    XAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    PrimaryYAxisDisplayOptions?: LineSeriesAxisDisplayOptions | undefined;
    PrimaryYAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    SecondaryYAxisDisplayOptions?: LineSeriesAxisDisplayOptions | undefined;
    SecondaryYAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    SingleAxisOptions?: SingleAxisOptions | undefined;
    DefaultSeriesSettings?: LineChartDefaultSeriesSettings | undefined;
    Series?: SeriesItem[] | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    ReferenceLines?: ReferenceLine[] | undefined;
    Tooltip?: TooltipOptions | undefined;
    ContributionAnalysisDefaults?: ContributionAnalysisDefault[] | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface LineChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: LineChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type HeatMapDimensionFieldList = DimensionField[];
export type HeatMapMeasureFieldList = MeasureField[];
export interface HeatMapAggregatedFieldWells {
    Rows?: DimensionField[] | undefined;
    Columns?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface HeatMapFieldWells {
    HeatMapAggregatedFieldWells?: HeatMapAggregatedFieldWells | undefined;
}
export interface HeatMapSortConfiguration {
    HeatMapRowSort?: FieldSortOptions[] | undefined;
    HeatMapColumnSort?: FieldSortOptions[] | undefined;
    HeatMapRowItemsLimitConfiguration?: ItemsLimitConfiguration | undefined;
    HeatMapColumnItemsLimitConfiguration?: ItemsLimitConfiguration | undefined;
}
export interface DataColor {
    Color?: string | undefined;
    DataValue?: number | undefined;
}
export type ColorScaleColorList = DataColor[];
export type ColorFillType = "DISCRETE" | "GRADIENT" | (string & {});
export interface ColorScale {
    Colors: DataColor[];
    ColorFillType: ColorFillType;
    NullValueColor?: DataColor | undefined;
}
export interface HeatMapConfiguration {
    FieldWells?: HeatMapFieldWells | undefined;
    SortConfiguration?: HeatMapSortConfiguration | undefined;
    RowAxisDisplayOptions?: AxisDisplayOptions | undefined;
    RowLabelOptions?: ChartAxisLabelOptions | undefined;
    ColumnAxisDisplayOptions?: AxisDisplayOptions | undefined;
    ColumnLabelOptions?: ChartAxisLabelOptions | undefined;
    ColorScale?: ColorScale | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface HeatMapVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: HeatMapConfiguration | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type TreeMapDimensionFieldList = DimensionField[];
export type TreeMapMeasureFieldList = MeasureField[];
export interface TreeMapAggregatedFieldWells {
    Groups?: DimensionField[] | undefined;
    Sizes?: MeasureField[] | undefined;
    Colors?: MeasureField[] | undefined;
}
export interface TreeMapFieldWells {
    TreeMapAggregatedFieldWells?: TreeMapAggregatedFieldWells | undefined;
}
export interface TreeMapSortConfiguration {
    TreeMapSort?: FieldSortOptions[] | undefined;
    TreeMapGroupItemsLimitConfiguration?: ItemsLimitConfiguration | undefined;
}
export interface TreeMapConfiguration {
    FieldWells?: TreeMapFieldWells | undefined;
    SortConfiguration?: TreeMapSortConfiguration | undefined;
    GroupLabelOptions?: ChartAxisLabelOptions | undefined;
    SizeLabelOptions?: ChartAxisLabelOptions | undefined;
    ColorLabelOptions?: ChartAxisLabelOptions | undefined;
    ColorScale?: ColorScale | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface TreeMapVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: TreeMapConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface GeospatialMapAggregatedFieldWells {
    Geospatial?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
    Colors?: DimensionField[] | undefined;
}
export interface GeospatialMapFieldWells {
    GeospatialMapAggregatedFieldWells?: GeospatialMapAggregatedFieldWells | undefined;
}
export type Latitude = number;
export type Longitude = number;
export interface GeospatialCoordinateBounds {
    North: number;
    South: number;
    West: number;
    East: number;
}
export type MapZoomMode = "AUTO" | "MANUAL" | (string & {});
export interface GeospatialWindowOptions {
    Bounds?: GeospatialCoordinateBounds | undefined;
    MapZoomMode?: MapZoomMode | undefined;
}
export type BaseMapStyleType = "LIGHT_GRAY" | "DARK_GRAY" | "STREET" | "IMAGERY" | (string & {});
export interface GeospatialMapStyleOptions {
    BaseMapStyle?: BaseMapStyleType | undefined;
}
export type GeospatialSelectedPointStyle = "POINT" | "CLUSTER" | "HEATMAP" | (string & {});
export interface SimpleClusterMarker {
    Color?: string | undefined;
}
export interface ClusterMarker {
    SimpleClusterMarker?: SimpleClusterMarker | undefined;
}
export interface ClusterMarkerConfiguration {
    ClusterMarker?: ClusterMarker | undefined;
}
export interface GeospatialHeatmapDataColor {
    Color: string;
}
export type GeospatialHeatmapDataColorList = GeospatialHeatmapDataColor[];
export interface GeospatialHeatmapColorScale {
    Colors?: GeospatialHeatmapDataColor[] | undefined;
}
export interface GeospatialHeatmapConfiguration {
    HeatmapColor?: GeospatialHeatmapColorScale | undefined;
}
export interface GeospatialPointStyleOptions {
    SelectedPointStyle?: GeospatialSelectedPointStyle | undefined;
    ClusterMarkerConfiguration?: ClusterMarkerConfiguration | undefined;
    HeatmapConfiguration?: GeospatialHeatmapConfiguration | undefined;
}
export interface GeospatialMapConfiguration {
    FieldWells?: GeospatialMapFieldWells | undefined;
    Legend?: LegendOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    WindowOptions?: GeospatialWindowOptions | undefined;
    MapStyleOptions?: GeospatialMapStyleOptions | undefined;
    PointStyleOptions?: GeospatialPointStyleOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export type GeocoderHierarchyCountryString = string;
export type GeocoderHierarchyStateString = string;
export type GeocoderHierarchyCountyString = string;
export type GeocoderHierarchyCityString = string;
export type GeocoderHierarchyPostCodeString = string;
export interface GeocoderHierarchy {
    Country?: string | undefined;
    State?: string | undefined;
    County?: string | undefined;
    City?: string | undefined;
    PostCode?: string | undefined;
}
export type CoordinateLatitudeDouble = number;
export type CoordinateLongitudeDouble = number;
export interface Coordinate {
    Latitude: number;
    Longitude: number;
}
export type GeocodePreferenceValue = {
    GeocoderHierarchy: GeocoderHierarchy;
    Coordinate?: undefined;
} | {
    GeocoderHierarchy?: undefined;
    Coordinate: Coordinate;
};
export interface GeocodePreference {
    RequestKey: GeocoderHierarchy;
    Preference: GeocodePreferenceValue;
}
export type GeocodePreferenceList = GeocodePreference[];
export interface GeospatialMapVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: GeospatialMapConfiguration | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
    GeocodingPreferences?: GeocodePreference[] | undefined;
}
export type FilledMapDimensionFieldList = DimensionField[];
export type FilledMapMeasureFieldList = MeasureField[];
export interface FilledMapAggregatedFieldWells {
    Geospatial?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface FilledMapFieldWells {
    FilledMapAggregatedFieldWells?: FilledMapAggregatedFieldWells | undefined;
}
export interface FilledMapSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
}
export interface FilledMapConfiguration {
    FieldWells?: FilledMapFieldWells | undefined;
    SortConfiguration?: FilledMapSortConfiguration | undefined;
    Legend?: LegendOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    WindowOptions?: GeospatialWindowOptions | undefined;
    MapStyleOptions?: GeospatialMapStyleOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface ShapeConditionalFormat {
    BackgroundColor: ConditionalFormattingColor;
}
export interface FilledMapShapeConditionalFormatting {
    FieldId: string;
    Format?: ShapeConditionalFormat | undefined;
}
export interface FilledMapConditionalFormattingOption {
    Shape: FilledMapShapeConditionalFormatting;
}
export type FilledMapConditionalFormattingOptionList = FilledMapConditionalFormattingOption[];
export interface FilledMapConditionalFormatting {
    ConditionalFormattingOptions: FilledMapConditionalFormattingOption[];
}
export interface FilledMapVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: FilledMapConfiguration | undefined;
    ConditionalFormatting?: FilledMapConditionalFormatting | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
    GeocodingPreferences?: GeocodePreference[] | undefined;
}
export type GeospatialLayerType = "POINT" | "LINE" | "POLYGON" | (string & {});
export interface GeospatialStaticFileSource {
    StaticFileId: string;
}
export interface GeospatialDataSourceItem {
    StaticFileDataSource?: GeospatialStaticFileSource | undefined;
}
export type GeospatialColorState = "ENABLED" | "DISABLED" | (string & {});
export interface GeospatialSolidColor {
    Color: string;
    State?: GeospatialColorState | undefined;
}
export interface GeospatialGradientStepColor {
    Color: string;
    DataValue: number;
}
export type GeospatialGradientStepColorList = GeospatialGradientStepColor[];
export type GeospatialWidth = number;
export interface GeospatialNullSymbolStyle {
    FillColor?: string | undefined;
    StrokeColor?: string | undefined;
    StrokeWidth?: number | undefined;
}
export interface GeospatialNullDataSettings {
    SymbolStyle: GeospatialNullSymbolStyle;
}
export type Opacity = number;
export interface GeospatialGradientColor {
    StepColors: GeospatialGradientStepColor[];
    NullDataVisibility?: Visibility | undefined;
    NullDataSettings?: GeospatialNullDataSettings | undefined;
    DefaultOpacity?: number | undefined;
}
export interface GeospatialCategoricalDataColor {
    Color: string;
    DataValue: string;
}
export type GeospatialCategoricalDataColorList = GeospatialCategoricalDataColor[];
export interface GeospatialCategoricalColor {
    CategoryDataColors: GeospatialCategoricalDataColor[];
    NullDataVisibility?: Visibility | undefined;
    NullDataSettings?: GeospatialNullDataSettings | undefined;
    DefaultOpacity?: number | undefined;
}
export interface GeospatialColor {
    Solid?: GeospatialSolidColor | undefined;
    Gradient?: GeospatialGradientColor | undefined;
    Categorical?: GeospatialCategoricalColor | undefined;
}
export interface GeospatialLineWidth {
    LineWidth?: number | undefined;
}
export type GeospatialRadius = number;
export interface GeospatialCircleRadius {
    Radius?: number | undefined;
}
export interface GeospatialCircleSymbolStyle {
    FillColor?: GeospatialColor | undefined;
    StrokeColor?: GeospatialColor | undefined;
    StrokeWidth?: GeospatialLineWidth | undefined;
    CircleRadius?: GeospatialCircleRadius | undefined;
}
export interface GeospatialPointStyle {
    CircleSymbolStyle?: GeospatialCircleSymbolStyle | undefined;
}
export interface GeospatialPointLayer {
    Style: GeospatialPointStyle;
}
export interface GeospatialLineSymbolStyle {
    FillColor?: GeospatialColor | undefined;
    LineWidth?: GeospatialLineWidth | undefined;
}
export interface GeospatialLineStyle {
    LineSymbolStyle?: GeospatialLineSymbolStyle | undefined;
}
export interface GeospatialLineLayer {
    Style: GeospatialLineStyle;
}
export interface GeospatialPolygonSymbolStyle {
    FillColor?: GeospatialColor | undefined;
    StrokeColor?: GeospatialColor | undefined;
    StrokeWidth?: GeospatialLineWidth | undefined;
}
export interface GeospatialPolygonStyle {
    PolygonSymbolStyle?: GeospatialPolygonSymbolStyle | undefined;
}
export interface GeospatialPolygonLayer {
    Style: GeospatialPolygonStyle;
}
export interface GeospatialLayerDefinition {
    PointLayer?: GeospatialPointLayer | undefined;
    LineLayer?: GeospatialLineLayer | undefined;
    PolygonLayer?: GeospatialPolygonLayer | undefined;
}
export type GeospatialLayerDimensionFieldList = DimensionField[];
export type GeospatialLayerMeasureFieldList = MeasureField[];
export interface GeospatialLayerColorField {
    ColorDimensionsFields?: DimensionField[] | undefined;
    ColorValuesFields?: MeasureField[] | undefined;
}
export interface GeospatialLayerJoinDefinition {
    ShapeKeyField?: string | undefined;
    DatasetKeyField?: UnaggregatedField | undefined;
    ColorField?: GeospatialLayerColorField | undefined;
}
export type LayerCustomActionName = string;
export type LayerCustomActionTrigger = "DATA_POINT_CLICK" | "DATA_POINT_MENU" | (string & {});
export interface LayerCustomActionOperation {
    FilterOperation?: CustomActionFilterOperation | undefined;
    NavigationOperation?: CustomActionNavigationOperation | undefined;
    URLOperation?: CustomActionURLOperation | undefined;
    SetParametersOperation?: CustomActionSetParametersOperation | undefined;
}
export type LayerCustomActionOperationList = LayerCustomActionOperation[];
export interface LayerCustomAction {
    CustomActionId: string;
    Name: string;
    Status?: WidgetStatus | undefined;
    Trigger: LayerCustomActionTrigger;
    ActionOperations: LayerCustomActionOperation[];
}
export type LayerCustomActionList = LayerCustomAction[];
export interface GeospatialLayerItem {
    LayerId: string;
    LayerType?: GeospatialLayerType | undefined;
    DataSource?: GeospatialDataSourceItem | undefined;
    Label?: string | undefined;
    Visibility?: Visibility | undefined;
    LayerDefinition?: GeospatialLayerDefinition | undefined;
    Tooltip?: TooltipOptions | undefined;
    JoinDefinition?: GeospatialLayerJoinDefinition | undefined;
    Actions?: LayerCustomAction[] | undefined;
}
export type GeospatialMapLayerList = GeospatialLayerItem[];
export type GeospatialMapNavigation = "ENABLED" | "DISABLED" | (string & {});
export interface GeospatialMapState {
    Bounds?: GeospatialCoordinateBounds | undefined;
    MapNavigation?: GeospatialMapNavigation | undefined;
}
export interface GeospatialMapStyle {
    BaseMapStyle?: BaseMapStyleType | undefined;
    BackgroundColor?: string | undefined;
    BaseMapVisibility?: Visibility | undefined;
}
export interface GeospatialLayerMapConfiguration {
    Legend?: LegendOptions | undefined;
    MapLayers?: GeospatialLayerItem[] | undefined;
    MapState?: GeospatialMapState | undefined;
    MapStyle?: GeospatialMapStyle | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface LayerMapVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: GeospatialLayerMapConfiguration | undefined;
    DataSetIdentifier?: string | undefined;
    TopicIdentifier?: string | undefined;
    VisualContentAltText?: string | undefined;
}
export type FunnelChartDimensionFieldList = DimensionField[];
export type FunnelChartMeasureFieldList = MeasureField[];
export interface FunnelChartAggregatedFieldWells {
    Category?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface FunnelChartFieldWells {
    FunnelChartAggregatedFieldWells?: FunnelChartAggregatedFieldWells | undefined;
}
export interface FunnelChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    CategoryItemsLimit?: ItemsLimitConfiguration | undefined;
}
export type FunnelChartMeasureDataLabelStyle = "VALUE_ONLY" | "PERCENTAGE_BY_FIRST_STAGE" | "PERCENTAGE_BY_PREVIOUS_STAGE" | "VALUE_AND_PERCENTAGE_BY_FIRST_STAGE" | "VALUE_AND_PERCENTAGE_BY_PREVIOUS_STAGE" | (string & {});
export interface FunnelChartDataLabelOptions {
    Visibility?: Visibility | undefined;
    CategoryLabelVisibility?: Visibility | undefined;
    MeasureLabelVisibility?: Visibility | undefined;
    Position?: DataLabelPosition | undefined;
    LabelFontConfiguration?: FontConfiguration | undefined;
    LabelColor?: string | undefined;
    MeasureDataLabelStyle?: FunnelChartMeasureDataLabelStyle | undefined;
}
export interface FunnelChartConfiguration {
    FieldWells?: FunnelChartFieldWells | undefined;
    SortConfiguration?: FunnelChartSortConfiguration | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    ValueLabelOptions?: ChartAxisLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    DataLabelOptions?: FunnelChartDataLabelOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface FunnelChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: FunnelChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface ScatterPlotCategoricallyAggregatedFieldWells {
    XAxis?: MeasureField[] | undefined;
    YAxis?: MeasureField[] | undefined;
    Category?: DimensionField[] | undefined;
    Size?: MeasureField[] | undefined;
    Label?: DimensionField[] | undefined;
}
export interface ScatterPlotUnaggregatedFieldWells {
    XAxis?: DimensionField[] | undefined;
    YAxis?: DimensionField[] | undefined;
    Size?: MeasureField[] | undefined;
    Category?: DimensionField[] | undefined;
    Label?: DimensionField[] | undefined;
}
export interface ScatterPlotFieldWells {
    ScatterPlotCategoricallyAggregatedFieldWells?: ScatterPlotCategoricallyAggregatedFieldWells | undefined;
    ScatterPlotUnaggregatedFieldWells?: ScatterPlotUnaggregatedFieldWells | undefined;
}
export interface ScatterPlotSortConfiguration {
    ScatterPlotLimitConfiguration?: ItemsLimitConfiguration | undefined;
}
export interface ScatterPlotConfiguration {
    FieldWells?: ScatterPlotFieldWells | undefined;
    SortConfiguration?: ScatterPlotSortConfiguration | undefined;
    XAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    XAxisDisplayOptions?: AxisDisplayOptions | undefined;
    YAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    YAxisDisplayOptions?: AxisDisplayOptions | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface ScatterPlotVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: ScatterPlotConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface ComboChartAggregatedFieldWells {
    Category?: DimensionField[] | undefined;
    BarValues?: MeasureField[] | undefined;
    Colors?: DimensionField[] | undefined;
    LineValues?: MeasureField[] | undefined;
}
export interface ComboChartFieldWells {
    ComboChartAggregatedFieldWells?: ComboChartAggregatedFieldWells | undefined;
}
export interface ComboChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    CategoryItemsLimit?: ItemsLimitConfiguration | undefined;
    ColorSort?: FieldSortOptions[] | undefined;
    ColorItemsLimit?: ItemsLimitConfiguration | undefined;
}
export interface ComboChartDefaultSeriesSettings {
    LineStyleSettings?: LineChartLineStyleSettings | undefined;
    MarkerStyleSettings?: LineChartMarkerStyleSettings | undefined;
    DecalSettings?: DecalSettings | undefined;
    BorderSettings?: BorderSettings | undefined;
}
export interface ComboChartSeriesSettings {
    LineStyleSettings?: LineChartLineStyleSettings | undefined;
    MarkerStyleSettings?: LineChartMarkerStyleSettings | undefined;
    DecalSettings?: DecalSettings | undefined;
    BorderSettings?: BorderSettings | undefined;
}
export interface FieldComboSeriesItem {
    FieldId: string;
    Settings?: ComboChartSeriesSettings | undefined;
}
export interface DataFieldComboSeriesItem {
    FieldId: string;
    FieldValue?: string | redacted.Redacted<string> | undefined;
    Settings?: ComboChartSeriesSettings | undefined;
}
export interface ComboSeriesItem {
    FieldComboSeriesItem?: FieldComboSeriesItem | undefined;
    DataFieldComboSeriesItem?: DataFieldComboSeriesItem | undefined;
}
export type ComboSeriesItemList = ComboSeriesItem[];
export interface ComboChartConfiguration {
    FieldWells?: ComboChartFieldWells | undefined;
    SortConfiguration?: ComboChartSortConfiguration | undefined;
    BarsArrangement?: BarsArrangement | undefined;
    CategoryAxis?: AxisDisplayOptions | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    PrimaryYAxisDisplayOptions?: AxisDisplayOptions | undefined;
    PrimaryYAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    SecondaryYAxisDisplayOptions?: AxisDisplayOptions | undefined;
    SecondaryYAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    SingleAxisOptions?: SingleAxisOptions | undefined;
    ColorLabelOptions?: ChartAxisLabelOptions | undefined;
    DefaultSeriesSettings?: ComboChartDefaultSeriesSettings | undefined;
    Series?: ComboSeriesItem[] | undefined;
    Legend?: LegendOptions | undefined;
    BarDataLabels?: DataLabelOptions | undefined;
    LineDataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    ReferenceLines?: ReferenceLine[] | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface ComboChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: ComboChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type BoxPlotDimensionFieldList = DimensionField[];
export type BoxPlotMeasureFieldList = MeasureField[];
export interface BoxPlotAggregatedFieldWells {
    GroupBy?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface BoxPlotFieldWells {
    BoxPlotAggregatedFieldWells?: BoxPlotAggregatedFieldWells | undefined;
}
export interface BoxPlotSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    PaginationConfiguration?: PaginationConfiguration | undefined;
}
export type BoxPlotFillStyle = "SOLID" | "TRANSPARENT" | (string & {});
export interface BoxPlotStyleOptions {
    FillStyle?: BoxPlotFillStyle | undefined;
}
export interface BoxPlotOptions {
    StyleOptions?: BoxPlotStyleOptions | undefined;
    OutlierVisibility?: Visibility | undefined;
    AllDataPointsVisibility?: Visibility | undefined;
}
export interface BoxPlotChartConfiguration {
    FieldWells?: BoxPlotFieldWells | undefined;
    SortConfiguration?: BoxPlotSortConfiguration | undefined;
    BoxPlotOptions?: BoxPlotOptions | undefined;
    CategoryAxis?: AxisDisplayOptions | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    PrimaryYAxisDisplayOptions?: AxisDisplayOptions | undefined;
    PrimaryYAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    Legend?: LegendOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    ReferenceLines?: ReferenceLine[] | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface BoxPlotVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: BoxPlotChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface WaterfallChartAggregatedFieldWells {
    Categories?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
    Breakdowns?: DimensionField[] | undefined;
}
export interface WaterfallChartFieldWells {
    WaterfallChartAggregatedFieldWells?: WaterfallChartAggregatedFieldWells | undefined;
}
export interface WaterfallChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    BreakdownItemsLimit?: ItemsLimitConfiguration | undefined;
}
export interface WaterfallChartOptions {
    TotalBarLabel?: string | undefined;
}
export interface WaterfallChartGroupColorConfiguration {
    PositiveBarColor?: string | undefined;
    NegativeBarColor?: string | undefined;
    TotalBarColor?: string | undefined;
}
export interface WaterfallChartColorConfiguration {
    GroupColorConfiguration?: WaterfallChartGroupColorConfiguration | undefined;
}
export interface WaterfallChartConfiguration {
    FieldWells?: WaterfallChartFieldWells | undefined;
    SortConfiguration?: WaterfallChartSortConfiguration | undefined;
    WaterfallChartOptions?: WaterfallChartOptions | undefined;
    CategoryAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    CategoryAxisDisplayOptions?: AxisDisplayOptions | undefined;
    PrimaryYAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    PrimaryYAxisDisplayOptions?: AxisDisplayOptions | undefined;
    Legend?: LegendOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    ColorConfiguration?: WaterfallChartColorConfiguration | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface WaterfallVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: WaterfallChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type HistogramMeasureFieldList = MeasureField[];
export interface HistogramAggregatedFieldWells {
    Values?: MeasureField[] | undefined;
}
export interface HistogramFieldWells {
    HistogramAggregatedFieldWells?: HistogramAggregatedFieldWells | undefined;
}
export type HistogramBinType = "BIN_COUNT" | "BIN_WIDTH" | (string & {});
export type BinCountValue = number;
export interface BinCountOptions {
    Value?: number | undefined;
}
export type BinWidthValue = number;
export type BinCountLimit = number;
export interface BinWidthOptions {
    Value?: number | undefined;
    BinCountLimit?: number | undefined;
}
export interface HistogramBinOptions {
    SelectedBinType?: HistogramBinType | undefined;
    BinCount?: BinCountOptions | undefined;
    BinWidth?: BinWidthOptions | undefined;
    StartValue?: number | undefined;
}
export interface HistogramConfiguration {
    FieldWells?: HistogramFieldWells | undefined;
    XAxisDisplayOptions?: AxisDisplayOptions | undefined;
    XAxisLabelOptions?: ChartAxisLabelOptions | undefined;
    YAxisDisplayOptions?: AxisDisplayOptions | undefined;
    BinOptions?: HistogramBinOptions | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Tooltip?: TooltipOptions | undefined;
    VisualPalette?: VisualPalette | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface HistogramVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: HistogramConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type WordCloudDimensionFieldList = DimensionField[];
export type WordCloudMeasureFieldList = MeasureField[];
export interface WordCloudAggregatedFieldWells {
    GroupBy?: DimensionField[] | undefined;
    Size?: MeasureField[] | undefined;
}
export interface WordCloudFieldWells {
    WordCloudAggregatedFieldWells?: WordCloudAggregatedFieldWells | undefined;
}
export interface WordCloudSortConfiguration {
    CategoryItemsLimit?: ItemsLimitConfiguration | undefined;
    CategorySort?: FieldSortOptions[] | undefined;
}
export type WordCloudWordOrientation = "HORIZONTAL" | "HORIZONTAL_AND_VERTICAL" | (string & {});
export type WordCloudWordScaling = "EMPHASIZE" | "NORMAL" | (string & {});
export type WordCloudCloudLayout = "FLUID" | "NORMAL" | (string & {});
export type WordCloudWordCasing = "LOWER_CASE" | "EXISTING_CASE" | (string & {});
export type WordCloudWordPadding = "NONE" | "SMALL" | "MEDIUM" | "LARGE" | (string & {});
export type WordCloudMaximumStringLength = number;
export interface WordCloudOptions {
    WordOrientation?: WordCloudWordOrientation | undefined;
    WordScaling?: WordCloudWordScaling | undefined;
    CloudLayout?: WordCloudCloudLayout | undefined;
    WordCasing?: WordCloudWordCasing | undefined;
    WordPadding?: WordCloudWordPadding | undefined;
    MaximumStringLength?: number | undefined;
}
export interface WordCloudChartConfiguration {
    FieldWells?: WordCloudFieldWells | undefined;
    SortConfiguration?: WordCloudSortConfiguration | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    WordCloudOptions?: WordCloudOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface WordCloudVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: WordCloudChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type TopBottomRankedComputationResultSize = number;
export type TopBottomComputationType = "TOP" | "BOTTOM" | (string & {});
export interface TopBottomRankedComputation {
    ComputationId: string;
    Name?: string | undefined;
    Category?: DimensionField | undefined;
    Value?: MeasureField | undefined;
    ResultSize?: number | undefined;
    Type: TopBottomComputationType;
}
export type TopBottomMoversComputationMoverSize = number;
export type TopBottomSortOrder = "PERCENT_DIFFERENCE" | "ABSOLUTE_DIFFERENCE" | (string & {});
export interface TopBottomMoversComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    Category?: DimensionField | undefined;
    Value?: MeasureField | undefined;
    MoverSize?: number | undefined;
    SortOrder?: TopBottomSortOrder | undefined;
    Type: TopBottomComputationType;
}
export interface TotalAggregationComputation {
    ComputationId: string;
    Name?: string | undefined;
    Value?: MeasureField | undefined;
}
export type MaximumMinimumComputationType = "MAXIMUM" | "MINIMUM" | (string & {});
export interface MaximumMinimumComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    Value?: MeasureField | undefined;
    Type: MaximumMinimumComputationType;
}
export interface MetricComparisonComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    FromValue?: MeasureField | undefined;
    TargetValue?: MeasureField | undefined;
}
export interface PeriodOverPeriodComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    Value?: MeasureField | undefined;
}
export interface PeriodToDateComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    Value?: MeasureField | undefined;
    PeriodTimeGranularity?: TimeGranularity | undefined;
}
export type GrowthRatePeriodSize = number;
export interface GrowthRateComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    Value?: MeasureField | undefined;
    PeriodSize?: number | undefined;
}
export interface UniqueValuesComputation {
    ComputationId: string;
    Name?: string | undefined;
    Category?: DimensionField | undefined;
}
export type ForecastComputationSeasonality = "AUTOMATIC" | "CUSTOM" | (string & {});
export type ForecastComputationCustomSeasonalityValue = number;
export interface ForecastComputation {
    ComputationId: string;
    Name?: string | undefined;
    Time?: DimensionField | undefined;
    Value?: MeasureField | undefined;
    PeriodsForward?: number | undefined;
    PeriodsBackward?: number | undefined;
    UpperBoundary?: number | undefined;
    LowerBoundary?: number | undefined;
    PredictionInterval?: number | undefined;
    Seasonality?: ForecastComputationSeasonality | undefined;
    CustomSeasonalityValue?: number | undefined;
}
export interface Computation {
    TopBottomRanked?: TopBottomRankedComputation | undefined;
    TopBottomMovers?: TopBottomMoversComputation | undefined;
    TotalAggregation?: TotalAggregationComputation | undefined;
    MaximumMinimum?: MaximumMinimumComputation | undefined;
    MetricComparison?: MetricComparisonComputation | undefined;
    PeriodOverPeriod?: PeriodOverPeriodComputation | undefined;
    PeriodToDate?: PeriodToDateComputation | undefined;
    GrowthRate?: GrowthRateComputation | undefined;
    UniqueValues?: UniqueValuesComputation | undefined;
    Forecast?: ForecastComputation | undefined;
}
export type ComputationList = Computation[];
export type NarrativeString = string;
export interface CustomNarrativeOptions {
    Narrative: string;
}
export interface InsightConfiguration {
    Computations?: Computation[] | undefined;
    CustomNarrative?: CustomNarrativeOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface InsightVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    InsightConfiguration?: InsightConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    DataSetIdentifier?: string | undefined;
    TopicIdentifier?: string | undefined;
    VisualContentAltText?: string | undefined;
}
export interface SankeyDiagramAggregatedFieldWells {
    Source?: DimensionField[] | undefined;
    Destination?: DimensionField[] | undefined;
    Weight?: MeasureField[] | undefined;
}
export interface SankeyDiagramFieldWells {
    SankeyDiagramAggregatedFieldWells?: SankeyDiagramAggregatedFieldWells | undefined;
}
export interface SankeyDiagramSortConfiguration {
    WeightSort?: FieldSortOptions[] | undefined;
    SourceItemsLimit?: ItemsLimitConfiguration | undefined;
    DestinationItemsLimit?: ItemsLimitConfiguration | undefined;
}
export interface SankeyDiagramChartConfiguration {
    FieldWells?: SankeyDiagramFieldWells | undefined;
    SortConfiguration?: SankeyDiagramSortConfiguration | undefined;
    DataLabels?: DataLabelOptions | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface SankeyDiagramVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: SankeyDiagramChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type CustomContentType = "IMAGE" | "OTHER_EMBEDDED_CONTENT" | (string & {});
export type CustomContentImageScalingConfiguration = "FIT_TO_HEIGHT" | "FIT_TO_WIDTH" | "DO_NOT_SCALE" | "SCALE_TO_VISUAL" | (string & {});
export interface CustomContentConfiguration {
    ContentUrl?: string | undefined;
    ContentType?: CustomContentType | undefined;
    ImageScaling?: CustomContentImageScalingConfiguration | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface CustomContentVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: CustomContentConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    DataSetIdentifier?: string | undefined;
    TopicIdentifier?: string | undefined;
    VisualContentAltText?: string | undefined;
}
export interface EmptyVisual {
    VisualId: string;
    DataSetIdentifier?: string | undefined;
    TopicIdentifier?: string | undefined;
    Actions?: VisualCustomAction[] | undefined;
}
export type RadarChartCategoryFieldList = DimensionField[];
export type RadarChartColorFieldList = DimensionField[];
export type RadarChartValuesFieldList = MeasureField[];
export interface RadarChartAggregatedFieldWells {
    Category?: DimensionField[] | undefined;
    Color?: DimensionField[] | undefined;
    Values?: MeasureField[] | undefined;
}
export interface RadarChartFieldWells {
    RadarChartAggregatedFieldWells?: RadarChartAggregatedFieldWells | undefined;
}
export interface RadarChartSortConfiguration {
    CategorySort?: FieldSortOptions[] | undefined;
    CategoryItemsLimit?: ItemsLimitConfiguration | undefined;
    ColorSort?: FieldSortOptions[] | undefined;
    ColorItemsLimit?: ItemsLimitConfiguration | undefined;
}
export type RadarChartShape = "CIRCLE" | "POLYGON" | (string & {});
export interface RadarChartAreaStyleSettings {
    Visibility?: Visibility | undefined;
}
export interface RadarChartSeriesSettings {
    AreaStyleSettings?: RadarChartAreaStyleSettings | undefined;
}
export type RadarChartStartAngle = number;
export type RadarChartAxesRangeScale = "AUTO" | "INDEPENDENT" | "SHARED" | (string & {});
export interface RadarChartConfiguration {
    FieldWells?: RadarChartFieldWells | undefined;
    SortConfiguration?: RadarChartSortConfiguration | undefined;
    Shape?: RadarChartShape | undefined;
    BaseSeriesSettings?: RadarChartSeriesSettings | undefined;
    StartAngle?: number | undefined;
    VisualPalette?: VisualPalette | undefined;
    AlternateBandColorsVisibility?: Visibility | undefined;
    AlternateBandEvenColor?: string | undefined;
    AlternateBandOddColor?: string | undefined;
    CategoryAxis?: AxisDisplayOptions | undefined;
    CategoryLabelOptions?: ChartAxisLabelOptions | undefined;
    ColorAxis?: AxisDisplayOptions | undefined;
    ColorLabelOptions?: ChartAxisLabelOptions | undefined;
    Legend?: LegendOptions | undefined;
    AxesRangeScale?: RadarChartAxesRangeScale | undefined;
    Interactions?: VisualInteractionOptions | undefined;
}
export interface RadarChartVisual {
    VisualId: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: RadarChartConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    ColumnHierarchies?: ColumnHierarchy[] | undefined;
    VisualContentAltText?: string | undefined;
}
export type PluginVisualAxisName = "GROUP_BY" | "VALUE" | (string & {});
export type UnaggregatedFieldList = UnaggregatedField[];
export interface PluginVisualFieldWell {
    AxisName?: PluginVisualAxisName | undefined;
    Dimensions?: DimensionField[] | undefined;
    Measures?: MeasureField[] | undefined;
    Unaggregated?: UnaggregatedField[] | undefined;
}
export type PluginVisualFieldWells = PluginVisualFieldWell[];
export interface PluginVisualProperty {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type PluginVisualPropertiesList = PluginVisualProperty[];
export interface PluginVisualOptions {
    VisualProperties?: PluginVisualProperty[] | undefined;
}
export interface PluginVisualItemsLimitConfiguration {
    ItemsLimit?: number | undefined;
}
export interface PluginVisualTableQuerySort {
    RowSort?: FieldSortOptions[] | undefined;
    ItemsLimitConfiguration?: PluginVisualItemsLimitConfiguration | undefined;
}
export interface PluginVisualSortConfiguration {
    PluginVisualTableQuerySort?: PluginVisualTableQuerySort | undefined;
}
export interface PluginVisualConfiguration {
    FieldWells?: PluginVisualFieldWell[] | undefined;
    VisualOptions?: PluginVisualOptions | undefined;
    SortConfiguration?: PluginVisualSortConfiguration | undefined;
}
export interface PluginVisual {
    VisualId: string;
    PluginArn: string;
    Title?: VisualTitleLabelOptions | undefined;
    Subtitle?: VisualSubtitleLabelOptions | undefined;
    ChartConfiguration?: PluginVisualConfiguration | undefined;
    Actions?: VisualCustomAction[] | undefined;
    VisualContentAltText?: string | undefined;
}
export interface Visual {
    TableVisual?: TableVisual | undefined;
    PivotTableVisual?: PivotTableVisual | undefined;
    BarChartVisual?: BarChartVisual | undefined;
    KPIVisual?: KPIVisual | undefined;
    PieChartVisual?: PieChartVisual | undefined;
    GaugeChartVisual?: GaugeChartVisual | undefined;
    LineChartVisual?: LineChartVisual | undefined;
    HeatMapVisual?: HeatMapVisual | undefined;
    TreeMapVisual?: TreeMapVisual | undefined;
    GeospatialMapVisual?: GeospatialMapVisual | undefined;
    FilledMapVisual?: FilledMapVisual | undefined;
    LayerMapVisual?: LayerMapVisual | undefined;
    FunnelChartVisual?: FunnelChartVisual | undefined;
    ScatterPlotVisual?: ScatterPlotVisual | undefined;
    ComboChartVisual?: ComboChartVisual | undefined;
    BoxPlotVisual?: BoxPlotVisual | undefined;
    WaterfallVisual?: WaterfallVisual | undefined;
    HistogramVisual?: HistogramVisual | undefined;
    WordCloudVisual?: WordCloudVisual | undefined;
    InsightVisual?: InsightVisual | undefined;
    SankeyDiagramVisual?: SankeyDiagramVisual | undefined;
    CustomContentVisual?: CustomContentVisual | undefined;
    EmptyVisual?: EmptyVisual | undefined;
    RadarChartVisual?: RadarChartVisual | undefined;
    PluginVisual?: PluginVisual | undefined;
}
export type VisualList = Visual[];
export type SheetTextBoxContent = string;
export interface TextBoxMenuOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface TextBoxInteractionOptions {
    TextBoxMenuOption?: TextBoxMenuOption | undefined;
}
export interface SheetTextBox {
    SheetTextBoxId: string;
    Content?: string | undefined;
    Interactions?: TextBoxInteractionOptions | undefined;
}
export type SheetTextBoxList = SheetTextBox[];
export interface SheetImageStaticFileSource {
    StaticFileId: string;
}
export interface SheetImageSource {
    SheetImageStaticFileSource?: SheetImageStaticFileSource | undefined;
}
export type SheetImageScalingType = "SCALE_TO_WIDTH" | "SCALE_TO_HEIGHT" | "SCALE_TO_CONTAINER" | "SCALE_NONE" | (string & {});
export interface SheetImageScalingConfiguration {
    ScalingType?: SheetImageScalingType | undefined;
}
export interface SheetImageTooltipText {
    PlainText?: string | undefined;
}
export interface SheetImageTooltipConfiguration {
    TooltipText?: SheetImageTooltipText | undefined;
    Visibility?: Visibility | undefined;
}
export interface ImageMenuOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface ImageInteractionOptions {
    ImageMenuOption?: ImageMenuOption | undefined;
}
export type ImageCustomActionName = string;
export type ImageCustomActionTrigger = "CLICK" | "MENU" | (string & {});
export interface ImageCustomActionOperation {
    NavigationOperation?: CustomActionNavigationOperation | undefined;
    URLOperation?: CustomActionURLOperation | undefined;
    SetParametersOperation?: CustomActionSetParametersOperation | undefined;
}
export type ImageCustomActionOperationList = ImageCustomActionOperation[];
export interface ImageCustomAction {
    CustomActionId: string;
    Name: string;
    Status?: WidgetStatus | undefined;
    Trigger: ImageCustomActionTrigger;
    ActionOperations: ImageCustomActionOperation[];
}
export type ImageCustomActionList = ImageCustomAction[];
export interface SheetImage {
    SheetImageId: string;
    Source: SheetImageSource;
    Scaling?: SheetImageScalingConfiguration | undefined;
    Tooltip?: SheetImageTooltipConfiguration | undefined;
    ImageContentAltText?: string | undefined;
    Interactions?: ImageInteractionOptions | undefined;
    Actions?: ImageCustomAction[] | undefined;
}
export type SheetImageList = SheetImage[];
export type LayoutElementType = "VISUAL" | "FILTER_CONTROL" | "PARAMETER_CONTROL" | "TEXT_BOX" | "IMAGE" | (string & {});
export type GridLayoutElementColumnIndex = number;
export type GridLayoutElementColumnSpan = number;
export type GridLayoutElementRowIndex = number;
export type GridLayoutElementRowSpan = number;
export type Width = string;
export interface GridLayoutElementBorderStyle {
    Visibility?: Visibility | undefined;
    Color?: string | undefined;
    Width?: string | undefined;
}
export interface GridLayoutElementBackgroundStyle {
    Visibility?: Visibility | undefined;
    Color?: string | undefined;
}
export interface LoadingAnimation {
    Visibility?: Visibility | undefined;
}
export type BorderRadius = string;
export type Padding = string;
export interface GridLayoutElement {
    ElementId: string;
    ElementType: LayoutElementType;
    ColumnIndex?: number | undefined;
    ColumnSpan: number;
    RowIndex?: number | undefined;
    RowSpan: number;
    BorderStyle?: GridLayoutElementBorderStyle | undefined;
    SelectedBorderStyle?: GridLayoutElementBorderStyle | undefined;
    BackgroundStyle?: GridLayoutElementBackgroundStyle | undefined;
    LoadingAnimation?: LoadingAnimation | undefined;
    BorderRadius?: string | undefined;
    Padding?: string | undefined;
}
export type GridLayoutElementList = GridLayoutElement[];
export type ResizeOption = "FIXED" | "RESPONSIVE" | (string & {});
export interface GridLayoutScreenCanvasSizeOptions {
    ResizeOption: ResizeOption;
    OptimizedViewPortWidth?: string | undefined;
}
export interface GridLayoutCanvasSizeOptions {
    ScreenCanvasSizeOptions?: GridLayoutScreenCanvasSizeOptions | undefined;
}
export interface GridLayoutConfiguration {
    Elements: GridLayoutElement[];
    CanvasSizeOptions?: GridLayoutCanvasSizeOptions | undefined;
}
export type UnlimitedPixelLength = string;
export interface SheetElementConfigurationOverrides {
    Visibility?: Visibility | undefined;
}
export interface SheetElementRenderingRule {
    Expression: string | redacted.Redacted<string>;
    ConfigurationOverrides: SheetElementConfigurationOverrides;
}
export type SheetElementRenderingRuleList = SheetElementRenderingRule[];
export interface FreeFormLayoutElementBorderStyle {
    Visibility?: Visibility | undefined;
    Color?: string | undefined;
    Width?: string | undefined;
}
export interface FreeFormLayoutElementBackgroundStyle {
    Visibility?: Visibility | undefined;
    Color?: string | undefined;
}
export interface FreeFormLayoutElement {
    ElementId: string;
    ElementType: LayoutElementType;
    XAxisLocation: string;
    YAxisLocation: string;
    Width: string;
    Height: string;
    Visibility?: Visibility | undefined;
    RenderingRules?: SheetElementRenderingRule[] | undefined;
    BorderStyle?: FreeFormLayoutElementBorderStyle | undefined;
    SelectedBorderStyle?: FreeFormLayoutElementBorderStyle | undefined;
    BackgroundStyle?: FreeFormLayoutElementBackgroundStyle | undefined;
    LoadingAnimation?: LoadingAnimation | undefined;
    BorderRadius?: string | undefined;
    Padding?: string | undefined;
}
export type FreeFromLayoutElementList = FreeFormLayoutElement[];
export interface FreeFormLayoutScreenCanvasSizeOptions {
    OptimizedViewPortWidth: string;
}
export interface FreeFormLayoutCanvasSizeOptions {
    ScreenCanvasSizeOptions?: FreeFormLayoutScreenCanvasSizeOptions | undefined;
}
export type SheetLayoutGroupMemberType = "ELEMENT" | "GROUP" | (string & {});
export interface SheetLayoutGroupMember {
    Id: string;
    Type: SheetLayoutGroupMemberType;
}
export type SheetLayoutGroupMemberList = SheetLayoutGroupMember[];
export interface SheetLayoutGroup {
    Id: string;
    Members: SheetLayoutGroupMember[];
}
export type SheetLayoutGroupList = SheetLayoutGroup[];
export interface FreeFormLayoutConfiguration {
    Elements: FreeFormLayoutElement[];
    CanvasSizeOptions?: FreeFormLayoutCanvasSizeOptions | undefined;
    Groups?: SheetLayoutGroup[] | undefined;
}
export interface FreeFormSectionLayoutConfiguration {
    Elements: FreeFormLayoutElement[];
}
export interface SectionLayoutConfiguration {
    FreeFormLayout: FreeFormSectionLayoutConfiguration;
}
export type Length = string;
export interface Spacing {
    Top?: string | undefined;
    Bottom?: string | undefined;
    Left?: string | undefined;
    Right?: string | undefined;
}
export interface SectionStyle {
    Height?: string | undefined;
    Padding?: Spacing | undefined;
}
export interface HeaderFooterSectionConfiguration {
    SectionId: string;
    Layout: SectionLayoutConfiguration;
    Style?: SectionStyle | undefined;
}
export type HeaderFooterSectionConfigurationList = HeaderFooterSectionConfiguration[];
export interface BodySectionContent {
    Layout?: SectionLayoutConfiguration | undefined;
}
export type SectionPageBreakStatus = "ENABLED" | "DISABLED" | (string & {});
export interface SectionAfterPageBreak {
    Status?: SectionPageBreakStatus | undefined;
}
export interface SectionPageBreakConfiguration {
    After?: SectionAfterPageBreak | undefined;
}
export type BodySectionDynamicDimensionLimit = number;
export type BodySectionDynamicDimensionSortConfigurationList = ColumnSort[];
export interface BodySectionDynamicCategoryDimensionConfiguration {
    Column: ColumnIdentifier;
    Limit?: number | undefined;
    SortByMetrics?: ColumnSort[] | undefined;
}
export interface BodySectionDynamicNumericDimensionConfiguration {
    Column: ColumnIdentifier;
    Limit?: number | undefined;
    SortByMetrics?: ColumnSort[] | undefined;
}
export interface BodySectionRepeatDimensionConfiguration {
    DynamicCategoryDimensionConfiguration?: BodySectionDynamicCategoryDimensionConfiguration | undefined;
    DynamicNumericDimensionConfiguration?: BodySectionDynamicNumericDimensionConfiguration | undefined;
}
export type BodySectionRepeatDimensionConfigurationList = BodySectionRepeatDimensionConfiguration[];
export interface BodySectionRepeatPageBreakConfiguration {
    After?: SectionAfterPageBreak | undefined;
}
export type NonRepeatingVisualsList = string[];
export interface BodySectionRepeatConfiguration {
    DimensionConfigurations?: BodySectionRepeatDimensionConfiguration[] | undefined;
    PageBreakConfiguration?: BodySectionRepeatPageBreakConfiguration | undefined;
    NonRepeatingVisuals?: string[] | undefined;
}
export interface BodySectionConfiguration {
    SectionId: string;
    Content: BodySectionContent;
    Style?: SectionStyle | undefined;
    PageBreakConfiguration?: SectionPageBreakConfiguration | undefined;
    RepeatConfiguration?: BodySectionRepeatConfiguration | undefined;
}
export type BodySectionConfigurationList = BodySectionConfiguration[];
export type PaperSize = "US_LETTER" | "US_LEGAL" | "US_TABLOID_LEDGER" | "A0" | "A1" | "A2" | "A3" | "A4" | "A5" | "JIS_B4" | "JIS_B5" | (string & {});
export type PaperOrientation = "PORTRAIT" | "LANDSCAPE" | (string & {});
export interface SectionBasedLayoutPaperCanvasSizeOptions {
    PaperSize?: PaperSize | undefined;
    PaperOrientation?: PaperOrientation | undefined;
    PaperMargin?: Spacing | undefined;
}
export interface SectionBasedLayoutCanvasSizeOptions {
    PaperCanvasSizeOptions?: SectionBasedLayoutPaperCanvasSizeOptions | undefined;
}
export interface SectionBasedLayoutConfiguration {
    HeaderSections: HeaderFooterSectionConfiguration[];
    BodySections: BodySectionConfiguration[];
    FooterSections: HeaderFooterSectionConfiguration[];
    CanvasSizeOptions: SectionBasedLayoutCanvasSizeOptions;
}
export interface LayoutConfiguration {
    GridLayout?: GridLayoutConfiguration | undefined;
    FreeFormLayout?: FreeFormLayoutConfiguration | undefined;
    SectionBasedLayout?: SectionBasedLayoutConfiguration | undefined;
}
export interface Layout {
    Configuration: LayoutConfiguration;
}
export type LayoutList = Layout[];
export interface SheetControlLayoutConfiguration {
    GridLayout?: GridLayoutConfiguration | undefined;
}
export interface SheetControlLayout {
    Configuration: SheetControlLayoutConfiguration;
}
export type SheetControlLayoutList = SheetControlLayout[];
export type SheetContentType = "PAGINATED" | "INTERACTIVE" | (string & {});
export type VisualHighlightTrigger = "DATA_POINT_CLICK" | "DATA_POINT_HOVER" | "NONE" | (string & {});
export interface VisualHighlightOperation {
    Trigger: VisualHighlightTrigger;
}
export interface VisualCustomActionDefaults {
    highlightOperation?: VisualHighlightOperation | undefined;
}
export interface SheetDefinition {
    SheetId: string;
    Title?: string | undefined;
    Description?: string | undefined;
    Name?: string | undefined;
    ParameterControls?: ParameterControl[] | undefined;
    FilterControls?: FilterControl[] | undefined;
    Visuals?: Visual[] | undefined;
    TextBoxes?: SheetTextBox[] | undefined;
    Images?: SheetImage[] | undefined;
    Layouts?: Layout[] | undefined;
    SheetControlLayouts?: SheetControlLayout[] | undefined;
    ContentType?: SheetContentType | undefined;
    CustomActionDefaults?: VisualCustomActionDefaults | undefined;
}
export type SheetDefinitionList = SheetDefinition[];
export type TooltipSheetVisualList = Visual[];
export type TooltipSheetTextBoxList = SheetTextBox[];
export type TooltipSheetImageList = SheetImage[];
export interface TooltipSheetDefinition {
    SheetId: string;
    Name?: string | undefined;
    Visuals?: Visual[] | undefined;
    TextBoxes?: SheetTextBox[] | undefined;
    Images?: SheetImage[] | undefined;
    Layouts?: Layout[] | undefined;
}
export type TooltipSheetDefinitionList = TooltipSheetDefinition[];
export type CalculatedFieldExpression = string | redacted.Redacted<string>;
export interface CalculatedField {
    DataSetIdentifier?: string | undefined;
    TopicIdentifier?: string | undefined;
    Name: string;
    Expression: string | redacted.Redacted<string>;
}
export type CalculatedFields = CalculatedField[];
export type ParameterValueType = "MULTI_VALUED" | "SINGLE_VALUED" | (string & {});
export interface DynamicDefaultValue {
    UserNameColumn?: ColumnIdentifier | undefined;
    GroupNameColumn?: ColumnIdentifier | undefined;
    DefaultValueColumn: ColumnIdentifier;
}
export interface StringDefaultValues {
    DynamicValue?: DynamicDefaultValue | undefined;
    StaticValues?: (string | redacted.Redacted<string>)[] | undefined;
}
export type ValueWhenUnsetOption = "RECOMMENDED_VALUE" | "NULL" | (string & {});
export interface StringValueWhenUnsetConfiguration {
    ValueWhenUnsetOption?: ValueWhenUnsetOption | undefined;
    CustomValue?: string | redacted.Redacted<string> | undefined;
}
export interface MappedDataSetParameter {
    DataSetIdentifier: string;
    DataSetParameterName: string;
}
export type MappedDataSetParameters = MappedDataSetParameter[];
export interface StringParameterDeclaration {
    ParameterValueType: ParameterValueType;
    Name: string;
    DefaultValues?: StringDefaultValues | undefined;
    ValueWhenUnset?: StringValueWhenUnsetConfiguration | undefined;
    MappedDataSetParameters?: MappedDataSetParameter[] | undefined;
}
export interface DecimalDefaultValues {
    DynamicValue?: DynamicDefaultValue | undefined;
    StaticValues?: number[] | undefined;
}
export interface DecimalValueWhenUnsetConfiguration {
    ValueWhenUnsetOption?: ValueWhenUnsetOption | undefined;
    CustomValue?: number | undefined;
}
export interface DecimalParameterDeclaration {
    ParameterValueType: ParameterValueType;
    Name: string;
    DefaultValues?: DecimalDefaultValues | undefined;
    ValueWhenUnset?: DecimalValueWhenUnsetConfiguration | undefined;
    MappedDataSetParameters?: MappedDataSetParameter[] | undefined;
}
export interface IntegerDefaultValues {
    DynamicValue?: DynamicDefaultValue | undefined;
    StaticValues?: number[] | undefined;
}
export interface IntegerValueWhenUnsetConfiguration {
    ValueWhenUnsetOption?: ValueWhenUnsetOption | undefined;
    CustomValue?: number | undefined;
}
export interface IntegerParameterDeclaration {
    ParameterValueType: ParameterValueType;
    Name: string;
    DefaultValues?: IntegerDefaultValues | undefined;
    ValueWhenUnset?: IntegerValueWhenUnsetConfiguration | undefined;
    MappedDataSetParameters?: MappedDataSetParameter[] | undefined;
}
export interface RollingDateConfiguration {
    DataSetIdentifier?: string | undefined;
    Expression: string | redacted.Redacted<string>;
}
export interface DateTimeDefaultValues {
    DynamicValue?: DynamicDefaultValue | undefined;
    StaticValues?: Date[] | undefined;
    RollingDate?: RollingDateConfiguration | undefined;
}
export interface DateTimeValueWhenUnsetConfiguration {
    ValueWhenUnsetOption?: ValueWhenUnsetOption | undefined;
    CustomValue?: Date | undefined;
}
export interface DateTimeParameterDeclaration {
    Name: string;
    DefaultValues?: DateTimeDefaultValues | undefined;
    TimeGranularity?: TimeGranularity | undefined;
    ValueWhenUnset?: DateTimeValueWhenUnsetConfiguration | undefined;
    MappedDataSetParameters?: MappedDataSetParameter[] | undefined;
}
export interface ParameterDeclaration {
    StringParameterDeclaration?: StringParameterDeclaration | undefined;
    DecimalParameterDeclaration?: DecimalParameterDeclaration | undefined;
    IntegerParameterDeclaration?: IntegerParameterDeclaration | undefined;
    DateTimeParameterDeclaration?: DateTimeParameterDeclaration | undefined;
}
export type ParameterDeclarationList = ParameterDeclaration[];
export type CategoryFilterMatchOperator = "EQUALS" | "DOES_NOT_EQUAL" | "CONTAINS" | "DOES_NOT_CONTAIN" | "STARTS_WITH" | "ENDS_WITH" | (string & {});
export type CategoryFilterSelectAllOptions = "FILTER_ALL_VALUES" | (string & {});
export type FilterNullOption = "ALL_VALUES" | "NULLS_ONLY" | "NON_NULLS_ONLY" | (string & {});
export interface FilterListConfiguration {
    MatchOperator: CategoryFilterMatchOperator;
    CategoryValues?: string[] | undefined;
    SelectAllOptions?: CategoryFilterSelectAllOptions | undefined;
    NullOption?: FilterNullOption | undefined;
}
export interface CustomFilterListConfiguration {
    MatchOperator: CategoryFilterMatchOperator;
    CategoryValues?: string[] | undefined;
    SelectAllOptions?: CategoryFilterSelectAllOptions | undefined;
    NullOption: FilterNullOption;
}
export interface CustomFilterConfiguration {
    MatchOperator: CategoryFilterMatchOperator;
    CategoryValue?: string | undefined;
    SelectAllOptions?: CategoryFilterSelectAllOptions | undefined;
    ParameterName?: string | undefined;
    NullOption: FilterNullOption;
}
export interface CategoryFilterConfiguration {
    FilterListConfiguration?: FilterListConfiguration | undefined;
    CustomFilterListConfiguration?: CustomFilterListConfiguration | undefined;
    CustomFilterConfiguration?: CustomFilterConfiguration | undefined;
}
export interface DefaultDateTimePickerControlOptions {
    Type?: SheetControlDateTimePickerType | undefined;
    DisplayOptions?: DateTimePickerControlDisplayOptions | undefined;
    CommitMode?: CommitMode | undefined;
}
export interface DefaultFilterListControlOptions {
    DisplayOptions?: ListControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    SelectableValues?: FilterSelectableValues | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
}
export interface DefaultFilterDropDownControlOptions {
    DisplayOptions?: DropDownControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    SelectableValues?: FilterSelectableValues | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
}
export interface DefaultTextFieldControlOptions {
    DisplayOptions?: TextFieldControlDisplayOptions | undefined;
}
export interface DefaultTextAreaControlOptions {
    Delimiter?: string | undefined;
    DisplayOptions?: TextAreaControlDisplayOptions | undefined;
}
export interface DefaultSliderControlOptions {
    DisplayOptions?: SliderControlDisplayOptions | undefined;
    Type?: SheetControlSliderType | undefined;
    MaximumValue: number;
    MinimumValue: number;
    StepSize: number;
}
export interface DefaultRelativeDateTimeControlOptions {
    DisplayOptions?: RelativeDateTimeControlDisplayOptions | undefined;
    CommitMode?: CommitMode | undefined;
}
export interface DefaultHierarchyFilterListControlOptions {
    DisplayOptions?: HierarchyFilterListControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface DefaultHierarchyFilterDropDownControlOptions {
    DisplayOptions?: HierarchyFilterDropDownControlDisplayOptions | undefined;
    Type?: SheetControlListType | undefined;
    CommitMode?: CommitMode | undefined;
    ControlSortConfigurations?: ControlSortConfiguration[] | undefined;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface DefaultFilterControlOptions {
    DefaultDateTimePickerOptions?: DefaultDateTimePickerControlOptions | undefined;
    DefaultListOptions?: DefaultFilterListControlOptions | undefined;
    DefaultDropdownOptions?: DefaultFilterDropDownControlOptions | undefined;
    DefaultTextFieldOptions?: DefaultTextFieldControlOptions | undefined;
    DefaultTextAreaOptions?: DefaultTextAreaControlOptions | undefined;
    DefaultSliderOptions?: DefaultSliderControlOptions | undefined;
    DefaultRelativeDateTimeOptions?: DefaultRelativeDateTimeControlOptions | undefined;
    DefaultHierarchyList?: DefaultHierarchyFilterListControlOptions | undefined;
    DefaultHierarchyDropdown?: DefaultHierarchyFilterDropDownControlOptions | undefined;
}
export interface DefaultFilterControlConfiguration {
    Title?: string | undefined;
    ControlOptions: DefaultFilterControlOptions;
    ControlTitleFormatText?: ControlTitleFormatText | undefined;
}
export interface CategoryFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    Configuration: CategoryFilterConfiguration;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export interface NumericRangeFilterValue {
    StaticValue?: number | undefined;
    Parameter?: string | undefined;
}
export type NumericFilterSelectAllOptions = "FILTER_ALL_VALUES" | (string & {});
export interface NumericRangeFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    IncludeMinimum?: boolean | undefined;
    IncludeMaximum?: boolean | undefined;
    RangeMinimum?: NumericRangeFilterValue | undefined;
    RangeMaximum?: NumericRangeFilterValue | undefined;
    SelectAllOptions?: NumericFilterSelectAllOptions | undefined;
    AggregationFunction?: AggregationFunction | undefined;
    NullOption: FilterNullOption;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export type NumericEqualityMatchOperator = "EQUALS" | "DOES_NOT_EQUAL" | (string & {});
export interface NumericEqualityFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    Value?: number | undefined;
    SelectAllOptions?: NumericFilterSelectAllOptions | undefined;
    MatchOperator: NumericEqualityMatchOperator;
    AggregationFunction?: AggregationFunction | undefined;
    ParameterName?: string | undefined;
    NullOption: FilterNullOption;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export interface TimeEqualityFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    Value?: Date | undefined;
    ParameterName?: string | undefined;
    TimeGranularity?: TimeGranularity | undefined;
    RollingDate?: RollingDateConfiguration | undefined;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export interface TimeRangeFilterValue {
    StaticValue?: Date | undefined;
    RollingDate?: RollingDateConfiguration | undefined;
    Parameter?: string | undefined;
}
export interface ExcludePeriodConfiguration {
    Amount: number;
    Granularity: TimeGranularity;
    Status?: WidgetStatus | undefined;
}
export interface TimeRangeFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    IncludeMinimum?: boolean | undefined;
    IncludeMaximum?: boolean | undefined;
    RangeMinimumValue?: TimeRangeFilterValue | undefined;
    RangeMaximumValue?: TimeRangeFilterValue | undefined;
    NullOption: FilterNullOption;
    ExcludePeriodConfiguration?: ExcludePeriodConfiguration | undefined;
    TimeGranularity?: TimeGranularity | undefined;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export type AnchorOption = "NOW" | (string & {});
export interface AnchorDateConfiguration {
    AnchorOption?: AnchorOption | undefined;
    ParameterName?: string | undefined;
}
export type RelativeDateType = "PREVIOUS" | "THIS" | "LAST" | "NOW" | "NEXT" | (string & {});
export interface RelativeDatesFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    AnchorDateConfiguration: AnchorDateConfiguration;
    MinimumGranularity?: TimeGranularity | undefined;
    TimeGranularity: TimeGranularity;
    RelativeDateType: RelativeDateType;
    RelativeDateValue?: number | undefined;
    ParameterName?: string | undefined;
    NullOption: FilterNullOption;
    ExcludePeriodConfiguration?: ExcludePeriodConfiguration | undefined;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export type AggregationSortConfigurationList = AggregationSortConfiguration[];
export interface TopBottomFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    Limit?: number | undefined;
    AggregationSortConfigurations: AggregationSortConfiguration[];
    TimeGranularity?: TimeGranularity | undefined;
    ParameterName?: string | undefined;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export interface CategoryInnerFilter {
    Column: ColumnIdentifier;
    Configuration: CategoryFilterConfiguration;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export interface InnerFilter {
    CategoryInnerFilter?: CategoryInnerFilter | undefined;
}
export interface NestedFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    IncludeInnerSet: boolean;
    InnerFilter: InnerFilter;
}
export interface HierarchyFilterLevel {
    Column: ColumnIdentifier;
}
export type HierarchyFilterLevelList = HierarchyFilterLevel[];
export type HierarchyFilterValue = string | redacted.Redacted<string>;
export type HierarchyValuesList = (string | redacted.Redacted<string>)[];
export type HierarchyFilterNodeList = HierarchyFilterNode[];
export interface HierarchyFilterNode {
    Column: ColumnIdentifier;
    ParentValue?: string | redacted.Redacted<string> | undefined;
    HierarchyValues?: (string | redacted.Redacted<string>)[] | undefined;
    Children?: HierarchyFilterNode[] | undefined;
}
export type HierarchyFilterMatchOperator = "INCLUDE" | "EXCLUDE" | (string & {});
export interface HierarchyFilter {
    FilterId: string;
    Column: ColumnIdentifier;
    HierarchyLevels: HierarchyFilterLevel[];
    HierarchyTree?: HierarchyFilterNode | undefined;
    NullOption: FilterNullOption;
    MatchOperator: HierarchyFilterMatchOperator;
    DefaultFilterControlConfiguration?: DefaultFilterControlConfiguration | undefined;
}
export interface Filter {
    CategoryFilter?: CategoryFilter | undefined;
    NumericRangeFilter?: NumericRangeFilter | undefined;
    NumericEqualityFilter?: NumericEqualityFilter | undefined;
    TimeEqualityFilter?: TimeEqualityFilter | undefined;
    TimeRangeFilter?: TimeRangeFilter | undefined;
    RelativeDatesFilter?: RelativeDatesFilter | undefined;
    TopBottomFilter?: TopBottomFilter | undefined;
    NestedFilter?: NestedFilter | undefined;
    HierarchyFilter?: HierarchyFilter | undefined;
}
export type FilterList = Filter[];
export type FilterVisualScope = "ALL_VISUALS" | "SELECTED_VISUALS" | (string & {});
export type FilteredVisualsList = string[];
export interface SheetVisualScopingConfiguration {
    SheetId: string;
    Scope: FilterVisualScope;
    VisualIds?: string[] | undefined;
}
export type SheetVisualScopingConfigurations = SheetVisualScopingConfiguration[];
export interface SelectedSheetsFilterScopeConfiguration {
    SheetVisualScopingConfigurations?: SheetVisualScopingConfiguration[] | undefined;
}
export interface AllSheetsFilterScopeConfiguration {
}
export interface FilterScopeConfiguration {
    SelectedSheets?: SelectedSheetsFilterScopeConfiguration | undefined;
    AllSheets?: AllSheetsFilterScopeConfiguration | undefined;
}
export type CrossDatasetTypes = "ALL_DATASETS" | "SINGLE_DATASET" | (string & {});
export interface FilterGroup {
    FilterGroupId: string;
    Filters: Filter[];
    ScopeConfiguration: FilterScopeConfiguration;
    Status?: WidgetStatus | undefined;
    CrossDataset: CrossDatasetTypes;
}
export type FilterGroupList = FilterGroup[];
export type ColumnRole = "DIMENSION" | "MEASURE" | (string & {});
export type SpecialValue = "EMPTY" | "NULL" | "OTHER" | (string & {});
export interface CustomColor {
    FieldValue?: string | redacted.Redacted<string> | undefined;
    Color: string;
    SpecialValue?: SpecialValue | undefined;
}
export type CustomColorsList = CustomColor[];
export interface ColorsConfiguration {
    CustomColors?: CustomColor[] | undefined;
}
export type DecalSettingsList = DecalSettings[];
export interface DecalSettingsConfiguration {
    CustomDecalSettings?: DecalSettings[] | undefined;
}
export interface ColumnConfiguration {
    Column: ColumnIdentifier;
    FormatConfiguration?: FormatConfiguration | undefined;
    Role?: ColumnRole | undefined;
    ColorsConfiguration?: ColorsConfiguration | undefined;
    DecalSettingsConfiguration?: DecalSettingsConfiguration | undefined;
}
export type ColumnConfigurationList = ColumnConfiguration[];
export interface DefaultGridLayoutConfiguration {
    CanvasSizeOptions: GridLayoutCanvasSizeOptions;
}
export interface DefaultFreeFormLayoutConfiguration {
    CanvasSizeOptions: FreeFormLayoutCanvasSizeOptions;
}
export interface DefaultInteractiveLayoutConfiguration {
    Grid?: DefaultGridLayoutConfiguration | undefined;
    FreeForm?: DefaultFreeFormLayoutConfiguration | undefined;
}
export interface DefaultSectionBasedLayoutConfiguration {
    CanvasSizeOptions: SectionBasedLayoutCanvasSizeOptions;
}
export interface DefaultPaginatedLayoutConfiguration {
    SectionBased?: DefaultSectionBasedLayoutConfiguration | undefined;
}
export interface DefaultNewSheetConfiguration {
    InteractiveLayoutConfiguration?: DefaultInteractiveLayoutConfiguration | undefined;
    PaginatedLayoutConfiguration?: DefaultPaginatedLayoutConfiguration | undefined;
    SheetContentType?: SheetContentType | undefined;
}
export interface AnalysisDefaults {
    DefaultNewSheetConfiguration: DefaultNewSheetConfiguration;
}
export type DayOfTheWeek = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export type QBusinessInsightsStatus = "ENABLED" | "DISABLED" | (string & {});
export type DataSetArnsList = string[];
export type VisualMessageText = string;
export type VisualMessageLinkUrl = string;
export interface VisualMessageConfiguration {
    Enabled?: boolean | undefined;
    Title?: string | undefined;
    TitleVisibility?: Visibility | undefined;
    Description?: string | undefined;
    DescriptionVisibility?: Visibility | undefined;
    LinkText?: string | undefined;
    LinkUrl?: string | undefined;
    LinkVisibility?: Visibility | undefined;
}
export interface VisualMessages {
    NoDataMessage?: VisualMessageConfiguration | undefined;
}
export interface AssetOptions {
    Timezone?: string | undefined;
    WeekStart?: DayOfTheWeek | undefined;
    QBusinessInsightsStatus?: QBusinessInsightsStatus | undefined;
    ExcludedDataSetArns?: string[] | undefined;
    CustomActionDefaults?: VisualCustomActionDefaults | undefined;
    VisualMessages?: VisualMessages | undefined;
}
export type QueryExecutionMode = "AUTO" | "MANUAL" | (string & {});
export interface QueryExecutionOptions {
    QueryExecutionMode?: QueryExecutionMode | undefined;
}
export interface StaticFileUrlSourceOptions {
    Url: string;
}
export interface StaticFileS3SourceOptions {
    BucketName: string;
    ObjectKey: string;
    Region: string;
}
export interface StaticFileSource {
    UrlOptions?: StaticFileUrlSourceOptions | undefined;
    S3Options?: StaticFileS3SourceOptions | undefined;
}
export interface ImageStaticFile {
    StaticFileId: string;
    Source?: StaticFileSource | undefined;
}
export interface SpatialStaticFile {
    StaticFileId: string;
    Source?: StaticFileSource | undefined;
}
export interface StaticFile {
    ImageStaticFile?: ImageStaticFile | undefined;
    SpatialStaticFile?: SpatialStaticFile | undefined;
}
export type StaticFileList = StaticFile[];
export interface AnalysisDefinition {
    DataSetIdentifierDeclarations: DataSetIdentifierDeclaration[];
    TopicIdentifierDeclarations?: TopicIdentifierDeclaration[] | undefined;
    Sheets?: SheetDefinition[] | undefined;
    TooltipSheets?: TooltipSheetDefinition[] | undefined;
    CalculatedFields?: CalculatedField[] | undefined;
    ParameterDeclarations?: ParameterDeclaration[] | undefined;
    FilterGroups?: FilterGroup[] | undefined;
    ColumnConfigurations?: ColumnConfiguration[] | undefined;
    AnalysisDefaults?: AnalysisDefaults | undefined;
    Options?: AssetOptions | undefined;
    QueryExecutionOptions?: QueryExecutionOptions | undefined;
    StaticFiles?: StaticFile[] | undefined;
}
export type ValidationStrategyMode = "STRICT" | "LENIENT" | (string & {});
export interface ValidationStrategy {
    Mode: ValidationStrategyMode;
}
export type FolderArnList = string[];
export interface CreateAnalysisRequest {
    AwsAccountId: string;
    AnalysisId: string;
    Name: string;
    Parameters?: Parameters | undefined;
    Permissions?: ResourcePermission[] | undefined;
    SourceEntity?: AnalysisSourceEntity | undefined;
    ThemeArn?: string | undefined;
    Tags?: Tag[] | undefined;
    Definition?: AnalysisDefinition | undefined;
    ValidationStrategy?: ValidationStrategy | undefined;
    FolderArns?: string[] | undefined;
}
export interface CreateAnalysisResponse {
    Arn?: string | undefined;
    AnalysisId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type PolicyId = string;
export type PolicyName = string;
export type PolicyDescription = string;
export type GovernedAction = "SHARE" | (string & {});
export type GovernedActionList = GovernedAction[];
export type AssetType = "AGENT" | "SPACE" | "KNOWLEDGE_BASE" | (string & {});
export type AssetTypeList = AssetType[];
export type ApplicableToType = "GROUP" | (string & {});
export type GroupArnList = string[];
export interface ApplicableTo {
    Type: ApplicableToType;
    GroupArns?: string[] | undefined;
}
export type ApprovalGroupList = string[];
export interface CreateApprovalPolicyRequest {
    PolicyId: string;
    Name: string;
    Description?: string | undefined;
    Actions: GovernedAction[];
    AssetTypes: AssetType[];
    ApplicableTo: ApplicableTo;
    ApprovalGroups: string[];
}
export interface ApprovalPolicy {
    PolicyId: string;
    PolicyArn: string;
    Name: string;
    Description?: string | undefined;
    Actions: GovernedAction[];
    AssetTypes: AssetType[];
    ApplicableTo: ApplicableTo;
    ApprovalGroups: string[];
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface CreateApprovalPolicyResponse {
    Policy: ApprovalPolicy;
}
export type Name = string;
export type Description = string;
export interface Palette {
    Foreground?: string | undefined;
    Background?: string | undefined;
}
export interface BrandColorPalette {
    Primary?: Palette | undefined;
    Secondary?: Palette | undefined;
    Accent?: Palette | undefined;
    Measure?: Palette | undefined;
    Dimension?: Palette | undefined;
    Success?: Palette | undefined;
    Info?: Palette | undefined;
    Warning?: Palette | undefined;
    Danger?: Palette | undefined;
}
export interface ContextualAccentPalette {
    Connection?: Palette | undefined;
    Visualization?: Palette | undefined;
    Insight?: Palette | undefined;
    Automation?: Palette | undefined;
}
export interface NavbarStyle {
    GlobalNavbar?: Palette | undefined;
    ContextualNavbar?: Palette | undefined;
}
export interface BrandElementStyle {
    NavbarStyle?: NavbarStyle | undefined;
}
export interface ApplicationTheme {
    BrandColorPalette?: BrandColorPalette | undefined;
    ContextualAccentPalette?: ContextualAccentPalette | undefined;
    BrandElementStyle?: BrandElementStyle | undefined;
}
export type ImageSource = {
    PublicUrl: string;
    S3Uri?: undefined;
} | {
    PublicUrl?: undefined;
    S3Uri: string;
};
export interface ImageConfiguration {
    Source?: ImageSource | undefined;
}
export interface ImageSetConfiguration {
    Original: ImageConfiguration;
}
export interface LogoSetConfiguration {
    Primary: ImageSetConfiguration;
    Favicon?: ImageSetConfiguration | undefined;
}
export interface LogoConfiguration {
    AltText: string;
    LogoSet: LogoSetConfiguration;
}
export interface BrandDefinition {
    BrandName: string;
    Description?: string | undefined;
    ApplicationTheme?: ApplicationTheme | undefined;
    LogoConfiguration?: LogoConfiguration | undefined;
}
export interface CreateBrandRequest {
    AwsAccountId: string;
    BrandId: string;
    BrandDefinition?: BrandDefinition | undefined;
    Tags?: Tag[] | undefined;
}
export type BrandStatus = "CREATE_IN_PROGRESS" | "CREATE_SUCCEEDED" | "CREATE_FAILED" | "DELETE_IN_PROGRESS" | "DELETE_FAILED" | (string & {});
export type BrandVersionStatus = "CREATE_IN_PROGRESS" | "CREATE_SUCCEEDED" | "CREATE_FAILED" | (string & {});
export type ErrorMessage = string;
export type ErrorList = string[];
export type AltText = string;
export interface Image {
    Source?: ImageSource | undefined;
    GeneratedImageUrl?: string | undefined;
}
export interface ImageSet {
    Original: Image;
    Height64?: Image | undefined;
    Height32?: Image | undefined;
}
export interface LogoSet {
    Primary: ImageSet;
    Favicon?: ImageSet | undefined;
}
export interface Logo {
    AltText: string;
    LogoSet: LogoSet;
}
export interface BrandDetail {
    BrandId: string;
    Arn?: string | undefined;
    BrandStatus?: BrandStatus | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    VersionId?: string | undefined;
    VersionStatus?: BrandVersionStatus | undefined;
    Errors?: string[] | undefined;
    Logo?: Logo | undefined;
}
export interface CreateBrandResponse {
    RequestId?: string | undefined;
    BrandDetail?: BrandDetail | undefined;
    BrandDefinition?: BrandDefinition | undefined;
}
export type CustomPermissionsName = string;
export type CapabilityState = "DENY" | "ALLOW" | (string & {});
export interface Capabilities {
    ExportToCsv?: CapabilityState | undefined;
    ExportToExcel?: CapabilityState | undefined;
    ExportToPdf?: CapabilityState | undefined;
    PrintReports?: CapabilityState | undefined;
    CreateAndUpdateThemes?: CapabilityState | undefined;
    AddOrRunAnomalyDetectionForAnalyses?: CapabilityState | undefined;
    ShareAnalyses?: CapabilityState | undefined;
    CreateAndUpdateDatasets?: CapabilityState | undefined;
    ShareDatasets?: CapabilityState | undefined;
    SubscribeDashboardEmailReports?: CapabilityState | undefined;
    CreateAndUpdateDashboardEmailReports?: CapabilityState | undefined;
    ShareDashboards?: CapabilityState | undefined;
    CreateAndUpdateThresholdAlerts?: CapabilityState | undefined;
    RenameSharedFolders?: CapabilityState | undefined;
    CreateSharedFolders?: CapabilityState | undefined;
    CreateAndUpdateDataSources?: CapabilityState | undefined;
    ShareDataSources?: CapabilityState | undefined;
    ViewAccountSPICECapacity?: CapabilityState | undefined;
    CreateSPICEDataset?: CapabilityState | undefined;
    ExportToPdfInScheduledReports?: CapabilityState | undefined;
    ExportToCsvInScheduledReports?: CapabilityState | undefined;
    ExportToExcelInScheduledReports?: CapabilityState | undefined;
    IncludeContentInScheduledReportsEmail?: CapabilityState | undefined;
    Dashboard?: CapabilityState | undefined;
    Analysis?: CapabilityState | undefined;
    Automate?: CapabilityState | undefined;
    Flow?: CapabilityState | undefined;
    Apps?: CapabilityState | undefined;
    CreateAndUpdateApps?: CapabilityState | undefined;
    ShareApps?: CapabilityState | undefined;
    InvokeAppsAIInference?: CapabilityState | undefined;
    AccessAppsNativeDataStore?: CapabilityState | undefined;
    PublishWithoutApproval?: CapabilityState | undefined;
    UseBedrockModels?: CapabilityState | undefined;
    PerformFlowUiTask?: CapabilityState | undefined;
    ApproveFlowShareRequests?: CapabilityState | undefined;
    UseAgentWebSearch?: CapabilityState | undefined;
    KnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateKnowledgeBases?: CapabilityState | undefined;
    ShareKnowledgeBases?: CapabilityState | undefined;
    SharePointKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateSharePointKnowledgeBase?: CapabilityState | undefined;
    ShareSharePointKnowledgeBase?: CapabilityState | undefined;
    UseSharePointKnowledgeBase?: CapabilityState | undefined;
    GoogleDriveKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateGoogleDriveKnowledgeBase?: CapabilityState | undefined;
    ShareGoogleDriveKnowledgeBase?: CapabilityState | undefined;
    UseGoogleDriveKnowledgeBase?: CapabilityState | undefined;
    WebCrawlerKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateWebCrawlerKnowledgeBase?: CapabilityState | undefined;
    ShareWebCrawlerKnowledgeBase?: CapabilityState | undefined;
    UseWebCrawlerKnowledgeBase?: CapabilityState | undefined;
    S3KnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateS3KnowledgeBase?: CapabilityState | undefined;
    ShareS3KnowledgeBase?: CapabilityState | undefined;
    UseS3KnowledgeBase?: CapabilityState | undefined;
    ConfluenceKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateConfluenceKnowledgeBase?: CapabilityState | undefined;
    ShareConfluenceKnowledgeBase?: CapabilityState | undefined;
    UseConfluenceKnowledgeBase?: CapabilityState | undefined;
    OneDriveKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateOneDriveKnowledgeBase?: CapabilityState | undefined;
    ShareOneDriveKnowledgeBase?: CapabilityState | undefined;
    UseOneDriveKnowledgeBase?: CapabilityState | undefined;
    QBusinessKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateQBusinessKnowledgeBase?: CapabilityState | undefined;
    ShareQBusinessKnowledgeBase?: CapabilityState | undefined;
    UseQBusinessKnowledgeBase?: CapabilityState | undefined;
    BedrockManagedKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateBedrockManagedKnowledgeBase?: CapabilityState | undefined;
    ShareBedrockManagedKnowledgeBase?: CapabilityState | undefined;
    UseBedrockManagedKnowledgeBase?: CapabilityState | undefined;
    BoxKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateBoxKnowledgeBase?: CapabilityState | undefined;
    ShareBoxKnowledgeBase?: CapabilityState | undefined;
    UseBoxKnowledgeBase?: CapabilityState | undefined;
    IDCKnowledgeBase?: CapabilityState | undefined;
    CreateAndUpdateIDCKnowledgeBase?: CapabilityState | undefined;
    ShareIDCKnowledgeBase?: CapabilityState | undefined;
    UseIDCKnowledgeBase?: CapabilityState | undefined;
    Action?: CapabilityState | undefined;
    GenericHTTPAction?: CapabilityState | undefined;
    CreateAndUpdateGenericHTTPAction?: CapabilityState | undefined;
    ShareGenericHTTPAction?: CapabilityState | undefined;
    UseGenericHTTPAction?: CapabilityState | undefined;
    AsanaAction?: CapabilityState | undefined;
    CreateAndUpdateAsanaAction?: CapabilityState | undefined;
    ShareAsanaAction?: CapabilityState | undefined;
    UseAsanaAction?: CapabilityState | undefined;
    SlackAction?: CapabilityState | undefined;
    CreateAndUpdateSlackAction?: CapabilityState | undefined;
    ShareSlackAction?: CapabilityState | undefined;
    UseSlackAction?: CapabilityState | undefined;
    ServiceNowAction?: CapabilityState | undefined;
    CreateAndUpdateServiceNowAction?: CapabilityState | undefined;
    ShareServiceNowAction?: CapabilityState | undefined;
    UseServiceNowAction?: CapabilityState | undefined;
    SalesforceAction?: CapabilityState | undefined;
    CreateAndUpdateSalesforceAction?: CapabilityState | undefined;
    ShareSalesforceAction?: CapabilityState | undefined;
    UseSalesforceAction?: CapabilityState | undefined;
    MSExchangeAction?: CapabilityState | undefined;
    CreateAndUpdateMSExchangeAction?: CapabilityState | undefined;
    ShareMSExchangeAction?: CapabilityState | undefined;
    UseMSExchangeAction?: CapabilityState | undefined;
    PagerDutyAction?: CapabilityState | undefined;
    CreateAndUpdatePagerDutyAction?: CapabilityState | undefined;
    SharePagerDutyAction?: CapabilityState | undefined;
    UsePagerDutyAction?: CapabilityState | undefined;
    JiraAction?: CapabilityState | undefined;
    CreateAndUpdateJiraAction?: CapabilityState | undefined;
    ShareJiraAction?: CapabilityState | undefined;
    UseJiraAction?: CapabilityState | undefined;
    ConfluenceAction?: CapabilityState | undefined;
    CreateAndUpdateConfluenceAction?: CapabilityState | undefined;
    ShareConfluenceAction?: CapabilityState | undefined;
    UseConfluenceAction?: CapabilityState | undefined;
    OneDriveAction?: CapabilityState | undefined;
    CreateAndUpdateOneDriveAction?: CapabilityState | undefined;
    ShareOneDriveAction?: CapabilityState | undefined;
    UseOneDriveAction?: CapabilityState | undefined;
    SharePointAction?: CapabilityState | undefined;
    CreateAndUpdateSharePointAction?: CapabilityState | undefined;
    ShareSharePointAction?: CapabilityState | undefined;
    UseSharePointAction?: CapabilityState | undefined;
    MSTeamsAction?: CapabilityState | undefined;
    CreateAndUpdateMSTeamsAction?: CapabilityState | undefined;
    ShareMSTeamsAction?: CapabilityState | undefined;
    UseMSTeamsAction?: CapabilityState | undefined;
    GoogleCalendarAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleCalendarAction?: CapabilityState | undefined;
    ShareGoogleCalendarAction?: CapabilityState | undefined;
    UseGoogleCalendarAction?: CapabilityState | undefined;
    ZendeskAction?: CapabilityState | undefined;
    CreateAndUpdateZendeskAction?: CapabilityState | undefined;
    ShareZendeskAction?: CapabilityState | undefined;
    UseZendeskAction?: CapabilityState | undefined;
    SmartsheetAction?: CapabilityState | undefined;
    CreateAndUpdateSmartsheetAction?: CapabilityState | undefined;
    ShareSmartsheetAction?: CapabilityState | undefined;
    UseSmartsheetAction?: CapabilityState | undefined;
    SAPBusinessPartnerAction?: CapabilityState | undefined;
    CreateAndUpdateSAPBusinessPartnerAction?: CapabilityState | undefined;
    ShareSAPBusinessPartnerAction?: CapabilityState | undefined;
    UseSAPBusinessPartnerAction?: CapabilityState | undefined;
    SAPProductMasterDataAction?: CapabilityState | undefined;
    CreateAndUpdateSAPProductMasterDataAction?: CapabilityState | undefined;
    ShareSAPProductMasterDataAction?: CapabilityState | undefined;
    UseSAPProductMasterDataAction?: CapabilityState | undefined;
    SAPPhysicalInventoryAction?: CapabilityState | undefined;
    CreateAndUpdateSAPPhysicalInventoryAction?: CapabilityState | undefined;
    ShareSAPPhysicalInventoryAction?: CapabilityState | undefined;
    UseSAPPhysicalInventoryAction?: CapabilityState | undefined;
    SAPBillOfMaterialAction?: CapabilityState | undefined;
    CreateAndUpdateSAPBillOfMaterialAction?: CapabilityState | undefined;
    ShareSAPBillOfMaterialAction?: CapabilityState | undefined;
    UseSAPBillOfMaterialAction?: CapabilityState | undefined;
    SAPMaterialStockAction?: CapabilityState | undefined;
    CreateAndUpdateSAPMaterialStockAction?: CapabilityState | undefined;
    ShareSAPMaterialStockAction?: CapabilityState | undefined;
    UseSAPMaterialStockAction?: CapabilityState | undefined;
    FactSetAction?: CapabilityState | undefined;
    CreateAndUpdateFactSetAction?: CapabilityState | undefined;
    ShareFactSetAction?: CapabilityState | undefined;
    UseFactSetAction?: CapabilityState | undefined;
    AmazonSThreeAction?: CapabilityState | undefined;
    CreateAndUpdateAmazonSThreeAction?: CapabilityState | undefined;
    ShareAmazonSThreeAction?: CapabilityState | undefined;
    UseAmazonSThreeAction?: CapabilityState | undefined;
    TextractAction?: CapabilityState | undefined;
    CreateAndUpdateTextractAction?: CapabilityState | undefined;
    ShareTextractAction?: CapabilityState | undefined;
    UseTextractAction?: CapabilityState | undefined;
    ComprehendAction?: CapabilityState | undefined;
    CreateAndUpdateComprehendAction?: CapabilityState | undefined;
    ShareComprehendAction?: CapabilityState | undefined;
    UseComprehendAction?: CapabilityState | undefined;
    ComprehendMedicalAction?: CapabilityState | undefined;
    CreateAndUpdateComprehendMedicalAction?: CapabilityState | undefined;
    ShareComprehendMedicalAction?: CapabilityState | undefined;
    UseComprehendMedicalAction?: CapabilityState | undefined;
    AmazonBedrockARSAction?: CapabilityState | undefined;
    CreateAndUpdateAmazonBedrockARSAction?: CapabilityState | undefined;
    ShareAmazonBedrockARSAction?: CapabilityState | undefined;
    UseAmazonBedrockARSAction?: CapabilityState | undefined;
    AmazonBedrockFSAction?: CapabilityState | undefined;
    CreateAndUpdateAmazonBedrockFSAction?: CapabilityState | undefined;
    ShareAmazonBedrockFSAction?: CapabilityState | undefined;
    UseAmazonBedrockFSAction?: CapabilityState | undefined;
    AmazonBedrockKRSAction?: CapabilityState | undefined;
    CreateAndUpdateAmazonBedrockKRSAction?: CapabilityState | undefined;
    ShareAmazonBedrockKRSAction?: CapabilityState | undefined;
    UseAmazonBedrockKRSAction?: CapabilityState | undefined;
    MCPAction?: CapabilityState | undefined;
    CreateAndUpdateMCPAction?: CapabilityState | undefined;
    ShareMCPAction?: CapabilityState | undefined;
    UseMCPAction?: CapabilityState | undefined;
    OpenAPIAction?: CapabilityState | undefined;
    CreateAndUpdateOpenAPIAction?: CapabilityState | undefined;
    ShareOpenAPIAction?: CapabilityState | undefined;
    UseOpenAPIAction?: CapabilityState | undefined;
    SandPGMIAction?: CapabilityState | undefined;
    CreateAndUpdateSandPGMIAction?: CapabilityState | undefined;
    ShareSandPGMIAction?: CapabilityState | undefined;
    UseSandPGMIAction?: CapabilityState | undefined;
    SandPGlobalEnergyAction?: CapabilityState | undefined;
    CreateAndUpdateSandPGlobalEnergyAction?: CapabilityState | undefined;
    ShareSandPGlobalEnergyAction?: CapabilityState | undefined;
    UseSandPGlobalEnergyAction?: CapabilityState | undefined;
    BambooHRAction?: CapabilityState | undefined;
    CreateAndUpdateBambooHRAction?: CapabilityState | undefined;
    ShareBambooHRAction?: CapabilityState | undefined;
    UseBambooHRAction?: CapabilityState | undefined;
    BoxAgentAction?: CapabilityState | undefined;
    CreateAndUpdateBoxAgentAction?: CapabilityState | undefined;
    ShareBoxAgentAction?: CapabilityState | undefined;
    UseBoxAgentAction?: CapabilityState | undefined;
    CanvaAgentAction?: CapabilityState | undefined;
    CreateAndUpdateCanvaAgentAction?: CapabilityState | undefined;
    ShareCanvaAgentAction?: CapabilityState | undefined;
    UseCanvaAgentAction?: CapabilityState | undefined;
    GithubAction?: CapabilityState | undefined;
    CreateAndUpdateGithubAction?: CapabilityState | undefined;
    ShareGithubAction?: CapabilityState | undefined;
    UseGithubAction?: CapabilityState | undefined;
    NotionAction?: CapabilityState | undefined;
    CreateAndUpdateNotionAction?: CapabilityState | undefined;
    ShareNotionAction?: CapabilityState | undefined;
    UseNotionAction?: CapabilityState | undefined;
    LinearAction?: CapabilityState | undefined;
    CreateAndUpdateLinearAction?: CapabilityState | undefined;
    ShareLinearAction?: CapabilityState | undefined;
    UseLinearAction?: CapabilityState | undefined;
    HuggingFaceAction?: CapabilityState | undefined;
    CreateAndUpdateHuggingFaceAction?: CapabilityState | undefined;
    ShareHuggingFaceAction?: CapabilityState | undefined;
    UseHuggingFaceAction?: CapabilityState | undefined;
    MondayAction?: CapabilityState | undefined;
    CreateAndUpdateMondayAction?: CapabilityState | undefined;
    ShareMondayAction?: CapabilityState | undefined;
    UseMondayAction?: CapabilityState | undefined;
    HubspotAction?: CapabilityState | undefined;
    CreateAndUpdateHubspotAction?: CapabilityState | undefined;
    ShareHubspotAction?: CapabilityState | undefined;
    UseHubspotAction?: CapabilityState | undefined;
    IntercomAction?: CapabilityState | undefined;
    CreateAndUpdateIntercomAction?: CapabilityState | undefined;
    ShareIntercomAction?: CapabilityState | undefined;
    UseIntercomAction?: CapabilityState | undefined;
    NewRelicAction?: CapabilityState | undefined;
    CreateAndUpdateNewRelicAction?: CapabilityState | undefined;
    ShareNewRelicAction?: CapabilityState | undefined;
    UseNewRelicAction?: CapabilityState | undefined;
    PagerDutyAgentAction?: CapabilityState | undefined;
    CreateAndUpdatePagerDutyAgentAction?: CapabilityState | undefined;
    SharePagerDutyAgentAction?: CapabilityState | undefined;
    UsePagerDutyAgentAction?: CapabilityState | undefined;
    VisierAgentAction?: CapabilityState | undefined;
    CreateAndUpdateVisierAgentAction?: CapabilityState | undefined;
    ShareVisierAgentAction?: CapabilityState | undefined;
    UseVisierAgentAction?: CapabilityState | undefined;
    ZoomAction?: CapabilityState | undefined;
    CreateAndUpdateZoomAction?: CapabilityState | undefined;
    ShareZoomAction?: CapabilityState | undefined;
    UseZoomAction?: CapabilityState | undefined;
    SnowFlakeAction?: CapabilityState | undefined;
    CreateAndUpdateSnowFlakeAction?: CapabilityState | undefined;
    ShareSnowFlakeAction?: CapabilityState | undefined;
    UseSnowFlakeAction?: CapabilityState | undefined;
    ZapierAction?: CapabilityState | undefined;
    CreateAndUpdateZapierAction?: CapabilityState | undefined;
    ShareZapierAction?: CapabilityState | undefined;
    UseZapierAction?: CapabilityState | undefined;
    AirtableAction?: CapabilityState | undefined;
    CreateAndUpdateAirtableAction?: CapabilityState | undefined;
    ShareAirtableAction?: CapabilityState | undefined;
    UseAirtableAction?: CapabilityState | undefined;
    DropboxAction?: CapabilityState | undefined;
    CreateAndUpdateDropboxAction?: CapabilityState | undefined;
    ShareDropboxAction?: CapabilityState | undefined;
    UseDropboxAction?: CapabilityState | undefined;
    GmailAction?: CapabilityState | undefined;
    CreateAndUpdateGmailAction?: CapabilityState | undefined;
    ShareGmailAction?: CapabilityState | undefined;
    UseGmailAction?: CapabilityState | undefined;
    GoogleAnalyticsAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleAnalyticsAction?: CapabilityState | undefined;
    ShareGoogleAnalyticsAction?: CapabilityState | undefined;
    UseGoogleAnalyticsAction?: CapabilityState | undefined;
    GoogleDocsAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleDocsAction?: CapabilityState | undefined;
    ShareGoogleDocsAction?: CapabilityState | undefined;
    UseGoogleDocsAction?: CapabilityState | undefined;
    GoogleDriveAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleDriveAction?: CapabilityState | undefined;
    ShareGoogleDriveAction?: CapabilityState | undefined;
    UseGoogleDriveAction?: CapabilityState | undefined;
    GoogleMeetAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleMeetAction?: CapabilityState | undefined;
    ShareGoogleMeetAction?: CapabilityState | undefined;
    UseGoogleMeetAction?: CapabilityState | undefined;
    GoogleSheetsAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleSheetsAction?: CapabilityState | undefined;
    ShareGoogleSheetsAction?: CapabilityState | undefined;
    UseGoogleSheetsAction?: CapabilityState | undefined;
    GoogleSlidesAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleSlidesAction?: CapabilityState | undefined;
    ShareGoogleSlidesAction?: CapabilityState | undefined;
    UseGoogleSlidesAction?: CapabilityState | undefined;
    QuickBooksAction?: CapabilityState | undefined;
    CreateAndUpdateQuickBooksAction?: CapabilityState | undefined;
    ShareQuickBooksAction?: CapabilityState | undefined;
    UseQuickBooksAction?: CapabilityState | undefined;
    FigmaAction?: CapabilityState | undefined;
    CreateAndUpdateFigmaAction?: CapabilityState | undefined;
    ShareFigmaAction?: CapabilityState | undefined;
    UseFigmaAction?: CapabilityState | undefined;
    WhatsAppAction?: CapabilityState | undefined;
    CreateAndUpdateWhatsAppAction?: CapabilityState | undefined;
    ShareWhatsAppAction?: CapabilityState | undefined;
    UseWhatsAppAction?: CapabilityState | undefined;
    GoogleChatAction?: CapabilityState | undefined;
    CreateAndUpdateGoogleChatAction?: CapabilityState | undefined;
    ShareGoogleChatAction?: CapabilityState | undefined;
    UseGoogleChatAction?: CapabilityState | undefined;
    OneNoteAction?: CapabilityState | undefined;
    CreateAndUpdateOneNoteAction?: CapabilityState | undefined;
    ShareOneNoteAction?: CapabilityState | undefined;
    UseOneNoteAction?: CapabilityState | undefined;
    ShopifyAction?: CapabilityState | undefined;
    CreateAndUpdateShopifyAction?: CapabilityState | undefined;
    ShareShopifyAction?: CapabilityState | undefined;
    UseShopifyAction?: CapabilityState | undefined;
    AdobeAction?: CapabilityState | undefined;
    CreateAndUpdateAdobeAction?: CapabilityState | undefined;
    ShareAdobeAction?: CapabilityState | undefined;
    UseAdobeAction?: CapabilityState | undefined;
    CiscoWebexVidcastAction?: CapabilityState | undefined;
    CreateAndUpdateCiscoWebexVidcastAction?: CapabilityState | undefined;
    ShareCiscoWebexVidcastAction?: CapabilityState | undefined;
    UseCiscoWebexVidcastAction?: CapabilityState | undefined;
    CiscoWebexMeetingsAction?: CapabilityState | undefined;
    CreateAndUpdateCiscoWebexMeetingsAction?: CapabilityState | undefined;
    ShareCiscoWebexMeetingsAction?: CapabilityState | undefined;
    UseCiscoWebexMeetingsAction?: CapabilityState | undefined;
    DunAndBradstreetAction?: CapabilityState | undefined;
    CreateAndUpdateDunAndBradstreetAction?: CapabilityState | undefined;
    ShareDunAndBradstreetAction?: CapabilityState | undefined;
    UseDunAndBradstreetAction?: CapabilityState | undefined;
    HGInsightsAction?: CapabilityState | undefined;
    CreateAndUpdateHGInsightsAction?: CapabilityState | undefined;
    ShareHGInsightsAction?: CapabilityState | undefined;
    UseHGInsightsAction?: CapabilityState | undefined;
    ZoomInfoAction?: CapabilityState | undefined;
    CreateAndUpdateZoomInfoAction?: CapabilityState | undefined;
    ShareZoomInfoAction?: CapabilityState | undefined;
    UseZoomInfoAction?: CapabilityState | undefined;
    MoodysAction?: CapabilityState | undefined;
    CreateAndUpdateMoodysAction?: CapabilityState | undefined;
    ShareMoodysAction?: CapabilityState | undefined;
    UseMoodysAction?: CapabilityState | undefined;
    BeeAction?: CapabilityState | undefined;
    CreateAndUpdateBeeAction?: CapabilityState | undefined;
    ShareBeeAction?: CapabilityState | undefined;
    UseBeeAction?: CapabilityState | undefined;
    GongAction?: CapabilityState | undefined;
    CreateAndUpdateGongAction?: CapabilityState | undefined;
    ShareGongAction?: CapabilityState | undefined;
    UseGongAction?: CapabilityState | undefined;
    Topic?: CapabilityState | undefined;
    EditVisualWithQ?: CapabilityState | undefined;
    BuildCalculatedFieldWithQ?: CapabilityState | undefined;
    CreateDashboardExecutiveSummaryWithQ?: CapabilityState | undefined;
    Space?: CapabilityState | undefined;
    CreateSpaces?: CapabilityState | undefined;
    ShareSpaces?: CapabilityState | undefined;
    ChatAgent?: CapabilityState | undefined;
    CreateChatAgents?: CapabilityState | undefined;
    ShareChatAgents?: CapabilityState | undefined;
    Research?: CapabilityState | undefined;
    SelfUpgradeUserRole?: CapabilityState | undefined;
    Extension?: CapabilityState | undefined;
    UseBrowserExtension?: CapabilityState | undefined;
    UseWordAddInExtension?: CapabilityState | undefined;
    UseOutlookAddInExtension?: CapabilityState | undefined;
    UseExcelAddInExtension?: CapabilityState | undefined;
    UsePowerpointAddInExtension?: CapabilityState | undefined;
    ManageSharedFolders?: CapabilityState | undefined;
    GenerateAnalyses?: CapabilityState | undefined;
    Story?: CapabilityState | undefined;
    Scenario?: CapabilityState | undefined;
    Trigger?: CapabilityState | undefined;
    ScheduleTrigger?: CapabilityState | undefined;
    InboundEmailTrigger?: CapabilityState | undefined;
    QuickEventTrigger?: CapabilityState | undefined;
    FileDataSource?: CapabilityState | undefined;
    CreateFileDataSource?: CapabilityState | undefined;
    UpdateFileDataSource?: CapabilityState | undefined;
    ShareFileDataSource?: CapabilityState | undefined;
    S3DataSource?: CapabilityState | undefined;
    CreateS3DataSource?: CapabilityState | undefined;
    UpdateS3DataSource?: CapabilityState | undefined;
    ShareS3DataSource?: CapabilityState | undefined;
    S3AnalyticsDataSource?: CapabilityState | undefined;
    CreateS3AnalyticsDataSource?: CapabilityState | undefined;
    UpdateS3AnalyticsDataSource?: CapabilityState | undefined;
    ShareS3AnalyticsDataSource?: CapabilityState | undefined;
    S3TablesDataSource?: CapabilityState | undefined;
    CreateS3TablesDataSource?: CapabilityState | undefined;
    UpdateS3TablesDataSource?: CapabilityState | undefined;
    ShareS3TablesDataSource?: CapabilityState | undefined;
    AthenaDataSource?: CapabilityState | undefined;
    CreateAthenaDataSource?: CapabilityState | undefined;
    UpdateAthenaDataSource?: CapabilityState | undefined;
    ShareAthenaDataSource?: CapabilityState | undefined;
    RdsDataSource?: CapabilityState | undefined;
    CreateRdsDataSource?: CapabilityState | undefined;
    UpdateRdsDataSource?: CapabilityState | undefined;
    ShareRdsDataSource?: CapabilityState | undefined;
    RedshiftAutoDiscoveredDataSource?: CapabilityState | undefined;
    CreateRedshiftAutoDiscoveredDataSource?: CapabilityState | undefined;
    UpdateRedshiftAutoDiscoveredDataSource?: CapabilityState | undefined;
    ShareRedshiftAutoDiscoveredDataSource?: CapabilityState | undefined;
    RedshiftManualDataSource?: CapabilityState | undefined;
    CreateRedshiftManualDataSource?: CapabilityState | undefined;
    UpdateRedshiftManualDataSource?: CapabilityState | undefined;
    ShareRedshiftManualDataSource?: CapabilityState | undefined;
    OpenSearchDataSource?: CapabilityState | undefined;
    CreateOpenSearchDataSource?: CapabilityState | undefined;
    UpdateOpenSearchDataSource?: CapabilityState | undefined;
    ShareOpenSearchDataSource?: CapabilityState | undefined;
    TimestreamDataSource?: CapabilityState | undefined;
    CreateTimestreamDataSource?: CapabilityState | undefined;
    UpdateTimestreamDataSource?: CapabilityState | undefined;
    ShareTimestreamDataSource?: CapabilityState | undefined;
    AuroraDataSource?: CapabilityState | undefined;
    CreateAuroraDataSource?: CapabilityState | undefined;
    UpdateAuroraDataSource?: CapabilityState | undefined;
    ShareAuroraDataSource?: CapabilityState | undefined;
    MySqlDataSource?: CapabilityState | undefined;
    CreateMySqlDataSource?: CapabilityState | undefined;
    UpdateMySqlDataSource?: CapabilityState | undefined;
    ShareMySqlDataSource?: CapabilityState | undefined;
    PostgreSqlDataSource?: CapabilityState | undefined;
    CreatePostgreSqlDataSource?: CapabilityState | undefined;
    UpdatePostgreSqlDataSource?: CapabilityState | undefined;
    SharePostgreSqlDataSource?: CapabilityState | undefined;
    OracleDataSource?: CapabilityState | undefined;
    CreateOracleDataSource?: CapabilityState | undefined;
    UpdateOracleDataSource?: CapabilityState | undefined;
    ShareOracleDataSource?: CapabilityState | undefined;
    SqlServerDataSource?: CapabilityState | undefined;
    CreateSqlServerDataSource?: CapabilityState | undefined;
    UpdateSqlServerDataSource?: CapabilityState | undefined;
    ShareSqlServerDataSource?: CapabilityState | undefined;
    MariaDbDataSource?: CapabilityState | undefined;
    CreateMariaDbDataSource?: CapabilityState | undefined;
    UpdateMariaDbDataSource?: CapabilityState | undefined;
    ShareMariaDbDataSource?: CapabilityState | undefined;
    SnowflakeDataSource?: CapabilityState | undefined;
    CreateSnowflakeDataSource?: CapabilityState | undefined;
    UpdateSnowflakeDataSource?: CapabilityState | undefined;
    ShareSnowflakeDataSource?: CapabilityState | undefined;
    GoogleBigQueryDataSource?: CapabilityState | undefined;
    CreateGoogleBigQueryDataSource?: CapabilityState | undefined;
    UpdateGoogleBigQueryDataSource?: CapabilityState | undefined;
    ShareGoogleBigQueryDataSource?: CapabilityState | undefined;
    DatabricksDataSource?: CapabilityState | undefined;
    CreateDatabricksDataSource?: CapabilityState | undefined;
    UpdateDatabricksDataSource?: CapabilityState | undefined;
    ShareDatabricksDataSource?: CapabilityState | undefined;
    StarburstDataSource?: CapabilityState | undefined;
    CreateStarburstDataSource?: CapabilityState | undefined;
    UpdateStarburstDataSource?: CapabilityState | undefined;
    ShareStarburstDataSource?: CapabilityState | undefined;
    TrinoDataSource?: CapabilityState | undefined;
    CreateTrinoDataSource?: CapabilityState | undefined;
    UpdateTrinoDataSource?: CapabilityState | undefined;
    ShareTrinoDataSource?: CapabilityState | undefined;
    ImpalaDataSource?: CapabilityState | undefined;
    CreateImpalaDataSource?: CapabilityState | undefined;
    UpdateImpalaDataSource?: CapabilityState | undefined;
    ShareImpalaDataSource?: CapabilityState | undefined;
    TeradataDataSource?: CapabilityState | undefined;
    CreateTeradataDataSource?: CapabilityState | undefined;
    UpdateTeradataDataSource?: CapabilityState | undefined;
    ShareTeradataDataSource?: CapabilityState | undefined;
    PrestoDataSource?: CapabilityState | undefined;
    CreatePrestoDataSource?: CapabilityState | undefined;
    UpdatePrestoDataSource?: CapabilityState | undefined;
    SharePrestoDataSource?: CapabilityState | undefined;
    SparkDataSource?: CapabilityState | undefined;
    CreateSparkDataSource?: CapabilityState | undefined;
    UpdateSparkDataSource?: CapabilityState | undefined;
    ShareSparkDataSource?: CapabilityState | undefined;
    ExasolDataSource?: CapabilityState | undefined;
    CreateExasolDataSource?: CapabilityState | undefined;
    UpdateExasolDataSource?: CapabilityState | undefined;
    ShareExasolDataSource?: CapabilityState | undefined;
    Db2DataSource?: CapabilityState | undefined;
    CreateDb2DataSource?: CapabilityState | undefined;
    UpdateDb2DataSource?: CapabilityState | undefined;
    ShareDb2DataSource?: CapabilityState | undefined;
    SapHanaDataSource?: CapabilityState | undefined;
    CreateSapHanaDataSource?: CapabilityState | undefined;
    UpdateSapHanaDataSource?: CapabilityState | undefined;
    ShareSapHanaDataSource?: CapabilityState | undefined;
    DenodoDataSource?: CapabilityState | undefined;
    CreateDenodoDataSource?: CapabilityState | undefined;
    UpdateDenodoDataSource?: CapabilityState | undefined;
    ShareDenodoDataSource?: CapabilityState | undefined;
    DremioDataSource?: CapabilityState | undefined;
    CreateDremioDataSource?: CapabilityState | undefined;
    UpdateDremioDataSource?: CapabilityState | undefined;
    ShareDremioDataSource?: CapabilityState | undefined;
    SalesforceDataSource?: CapabilityState | undefined;
    CreateSalesforceDataSource?: CapabilityState | undefined;
    UpdateSalesforceDataSource?: CapabilityState | undefined;
    ShareSalesforceDataSource?: CapabilityState | undefined;
    RadiantDataSource?: CapabilityState | undefined;
    CreateRadiantDataSource?: CapabilityState | undefined;
    UpdateRadiantDataSource?: CapabilityState | undefined;
    ShareRadiantDataSource?: CapabilityState | undefined;
    PayPalDataSource?: CapabilityState | undefined;
    CreatePayPalDataSource?: CapabilityState | undefined;
    UpdatePayPalDataSource?: CapabilityState | undefined;
    SharePayPalDataSource?: CapabilityState | undefined;
    SquareDataSource?: CapabilityState | undefined;
    CreateSquareDataSource?: CapabilityState | undefined;
    UpdateSquareDataSource?: CapabilityState | undefined;
    ShareSquareDataSource?: CapabilityState | undefined;
    GitHubDataSource?: CapabilityState | undefined;
    CreateGitHubDataSource?: CapabilityState | undefined;
    UpdateGitHubDataSource?: CapabilityState | undefined;
    ShareGitHubDataSource?: CapabilityState | undefined;
    TwitterDataSource?: CapabilityState | undefined;
    CreateTwitterDataSource?: CapabilityState | undefined;
    UpdateTwitterDataSource?: CapabilityState | undefined;
    ShareTwitterDataSource?: CapabilityState | undefined;
    JiraDataSource?: CapabilityState | undefined;
    CreateJiraDataSource?: CapabilityState | undefined;
    UpdateJiraDataSource?: CapabilityState | undefined;
    ShareJiraDataSource?: CapabilityState | undefined;
    ServiceNowDataSource?: CapabilityState | undefined;
    CreateServiceNowDataSource?: CapabilityState | undefined;
    UpdateServiceNowDataSource?: CapabilityState | undefined;
    ShareServiceNowDataSource?: CapabilityState | undefined;
    AdobeAnalyticsDataSource?: CapabilityState | undefined;
    CreateAdobeAnalyticsDataSource?: CapabilityState | undefined;
    UpdateAdobeAnalyticsDataSource?: CapabilityState | undefined;
    ShareAdobeAnalyticsDataSource?: CapabilityState | undefined;
    GoogleAnalyticsDataSource?: CapabilityState | undefined;
    CreateGoogleAnalyticsDataSource?: CapabilityState | undefined;
    UpdateGoogleAnalyticsDataSource?: CapabilityState | undefined;
    ShareGoogleAnalyticsDataSource?: CapabilityState | undefined;
    GoogleSheetsDataSource?: CapabilityState | undefined;
    CreateGoogleSheetsDataSource?: CapabilityState | undefined;
    UpdateGoogleSheetsDataSource?: CapabilityState | undefined;
    ShareGoogleSheetsDataSource?: CapabilityState | undefined;
    DocumentDbDataSource?: CapabilityState | undefined;
    CreateDocumentDbDataSource?: CapabilityState | undefined;
    UpdateDocumentDbDataSource?: CapabilityState | undefined;
    ShareDocumentDbDataSource?: CapabilityState | undefined;
    MongoDbDataSource?: CapabilityState | undefined;
    CreateMongoDbDataSource?: CapabilityState | undefined;
    UpdateMongoDbDataSource?: CapabilityState | undefined;
    ShareMongoDbDataSource?: CapabilityState | undefined;
    MongoAtlasDataSource?: CapabilityState | undefined;
    CreateMongoAtlasDataSource?: CapabilityState | undefined;
    UpdateMongoAtlasDataSource?: CapabilityState | undefined;
    ShareMongoAtlasDataSource?: CapabilityState | undefined;
    DynamoDbDataSource?: CapabilityState | undefined;
    CreateDynamoDbDataSource?: CapabilityState | undefined;
    UpdateDynamoDbDataSource?: CapabilityState | undefined;
    ShareDynamoDbDataSource?: CapabilityState | undefined;
}
export type GovernanceCategoryName = string;
export type DefaultCategoryEffect = "DENY_BY_DEFAULT" | (string & {});
export type DefaultCategoryEffectsMap = {
    [key: string]: DefaultCategoryEffect | undefined;
};
export interface Governance {
    DefaultCategoryEffects?: {
        [key: string]: DefaultCategoryEffect | undefined;
    } | undefined;
}
export interface CreateCustomPermissionsRequest {
    AwsAccountId: string;
    CustomPermissionsName: string;
    Capabilities?: Capabilities | undefined;
    Governance?: Governance | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateCustomPermissionsResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    RequestId?: string | undefined;
}
export type DashboardName = string;
export interface DashboardSourceTemplate {
    DataSetReferences: DataSetReference[];
    TopicReferences?: TopicReference[] | undefined;
    Arn: string;
}
export interface DashboardSourceEntity {
    SourceTemplate?: DashboardSourceTemplate | undefined;
}
export type VersionDescription = string;
export interface AdHocFilteringOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface ExportToCSVOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export type DashboardUIState = "EXPANDED" | "COLLAPSED" | (string & {});
export interface SheetControlsOption {
    VisibilityState?: DashboardUIState | undefined;
}
export interface ExportHiddenFieldsOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DashboardVisualPublishOptions {
    ExportHiddenFieldsOption?: ExportHiddenFieldsOption | undefined;
}
export interface SheetLayoutElementMaximizationOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface VisualAxisSortOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface ExportWithHiddenFieldsOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DataPointDrillUpDownOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DataPointMenuLabelOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DataPointTooltipOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DataQAEnabledOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface QuickSuiteActionsOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface ExecutiveSummaryOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DataStoriesSharingOption {
    AvailabilityStatus?: DashboardBehavior | undefined;
}
export interface DashboardPublishOptions {
    AdHocFilteringOption?: AdHocFilteringOption | undefined;
    ExportToCSVOption?: ExportToCSVOption | undefined;
    SheetControlsOption?: SheetControlsOption | undefined;
    VisualPublishOptions?: DashboardVisualPublishOptions | undefined;
    SheetLayoutElementMaximizationOption?: SheetLayoutElementMaximizationOption | undefined;
    VisualMenuOption?: VisualMenuOption | undefined;
    VisualAxisSortOption?: VisualAxisSortOption | undefined;
    ExportWithHiddenFieldsOption?: ExportWithHiddenFieldsOption | undefined;
    DataPointDrillUpDownOption?: DataPointDrillUpDownOption | undefined;
    DataPointMenuLabelOption?: DataPointMenuLabelOption | undefined;
    DataPointTooltipOption?: DataPointTooltipOption | undefined;
    DataQAEnabledOption?: DataQAEnabledOption | undefined;
    QuickSuiteActionsOption?: QuickSuiteActionsOption | undefined;
    ExecutiveSummaryOption?: ExecutiveSummaryOption | undefined;
    DataStoriesSharingOption?: DataStoriesSharingOption | undefined;
}
export interface DashboardVersionDefinition {
    DataSetIdentifierDeclarations: DataSetIdentifierDeclaration[];
    TopicIdentifierDeclarations?: TopicIdentifierDeclaration[] | undefined;
    Sheets?: SheetDefinition[] | undefined;
    TooltipSheets?: TooltipSheetDefinition[] | undefined;
    CalculatedFields?: CalculatedField[] | undefined;
    ParameterDeclarations?: ParameterDeclaration[] | undefined;
    FilterGroups?: FilterGroup[] | undefined;
    ColumnConfigurations?: ColumnConfiguration[] | undefined;
    AnalysisDefaults?: AnalysisDefaults | undefined;
    Options?: AssetOptions | undefined;
    StaticFiles?: StaticFile[] | undefined;
}
export interface LinkSharingConfiguration {
    Permissions?: ResourcePermission[] | undefined;
}
export type LinkEntityArn = string;
export type LinkEntityArnList = string[];
export interface CreateDashboardRequest {
    AwsAccountId: string;
    DashboardId: string;
    Name: string;
    Parameters?: Parameters | undefined;
    Permissions?: ResourcePermission[] | undefined;
    SourceEntity?: DashboardSourceEntity | undefined;
    Tags?: Tag[] | undefined;
    VersionDescription?: string | undefined;
    DashboardPublishOptions?: DashboardPublishOptions | undefined;
    ThemeArn?: string | undefined;
    Definition?: DashboardVersionDefinition | undefined;
    ValidationStrategy?: ValidationStrategy | undefined;
    FolderArns?: string[] | undefined;
    LinkSharingConfiguration?: LinkSharingConfiguration | undefined;
    LinkEntities?: string[] | undefined;
}
export interface CreateDashboardResponse {
    Arn?: string | undefined;
    VersionArn?: string | undefined;
    DashboardId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type ResourceId = string;
export type ResourceName = string;
export type PhysicalTableId = string;
export type RelationalTableCatalog = string;
export type RelationalTableSchema = string;
export type RelationalTableName = string;
export type ColumnId = string;
export type InputColumnDataType = "STRING" | "INTEGER" | "DECIMAL" | "DATETIME" | "BIT" | "BOOLEAN" | "JSON" | "SEMISTRUCT" | (string & {});
export type ColumnDataSubType = "FLOAT" | "FIXED" | (string & {});
export interface InputColumn {
    Name: string;
    Id?: string | undefined;
    Type: InputColumnDataType;
    SubType?: ColumnDataSubType | undefined;
}
export type InputColumnList = InputColumn[];
export interface RelationalTable {
    DataSourceArn: string;
    Catalog?: string | undefined;
    Schema?: string | undefined;
    Name: string;
    InputColumns: InputColumn[];
}
export type CustomSqlName = string;
export type SqlQuery = string | redacted.Redacted<string>;
export interface CustomSql {
    DataSourceArn: string;
    Name: string;
    SqlQuery: string | redacted.Redacted<string>;
    Columns?: InputColumn[] | undefined;
}
export type FileFormat = "CSV" | "TSV" | "CLF" | "ELF" | "XLSX" | "JSON" | (string & {});
export type PositiveInteger = number;
export type TextQualifier = "DOUBLE_QUOTE" | "SINGLE_QUOTE" | (string & {});
export type Delimiter = string;
export interface UploadSettings {
    Format?: FileFormat | undefined;
    StartFromRow?: number | undefined;
    ContainsHeader?: boolean | undefined;
    TextQualifier?: TextQualifier | undefined;
    Delimiter?: string | undefined;
    CustomCellAddressRange?: string | undefined;
}
export interface S3Source {
    DataSourceArn: string;
    UploadSettings?: UploadSettings | undefined;
    InputColumns: InputColumn[];
}
export type TablePathElementName = string;
export type TablePathElementId = string;
export interface TablePathElement {
    Name?: string | undefined;
    Id?: string | undefined;
}
export type TablePathElementList = TablePathElement[];
export interface SaaSTable {
    DataSourceArn: string;
    TablePath: TablePathElement[];
    InputColumns: InputColumn[];
}
export interface FileSource {
    DataSourceArn: string;
    UploadSettings?: UploadSettings | undefined;
    SheetIndex: number;
    InputColumns: InputColumn[];
}
export type PhysicalTable = {
    RelationalTable: RelationalTable;
    CustomSql?: undefined;
    S3Source?: undefined;
    SaaSTable?: undefined;
    FileSource?: undefined;
} | {
    RelationalTable?: undefined;
    CustomSql: CustomSql;
    S3Source?: undefined;
    SaaSTable?: undefined;
    FileSource?: undefined;
} | {
    RelationalTable?: undefined;
    CustomSql?: undefined;
    S3Source: S3Source;
    SaaSTable?: undefined;
    FileSource?: undefined;
} | {
    RelationalTable?: undefined;
    CustomSql?: undefined;
    S3Source?: undefined;
    SaaSTable: SaaSTable;
    FileSource?: undefined;
} | {
    RelationalTable?: undefined;
    CustomSql?: undefined;
    S3Source?: undefined;
    SaaSTable?: undefined;
    FileSource: FileSource;
};
export type PhysicalTableMap = {
    [key: string]: PhysicalTable | undefined;
};
export type LogicalTableId = string;
export type LogicalTableAlias = string;
export type TransformOperationAlias = string;
export type DataSetEntityResourceId = string;
export interface DataSetColumnIdMapping {
    SourceColumnId: string;
    TargetColumnId: string;
}
export type DataSetColumnIdMappingList = DataSetColumnIdMapping[];
export interface TransformOperationSource {
    TransformOperationId: string;
    ColumnIdMappings?: DataSetColumnIdMapping[] | undefined;
}
export type ProjectedColumnNameList = string[];
export interface ProjectOperation {
    Alias?: string | undefined;
    Source?: TransformOperationSource | undefined;
    ProjectedColumns: string[];
}
export type DataSetStringComparisonFilterOperator = "EQUALS" | "DOES_NOT_EQUAL" | "CONTAINS" | "DOES_NOT_CONTAIN" | "STARTS_WITH" | "ENDS_WITH" | (string & {});
export type DataSetStringFilterStaticValue = string | redacted.Redacted<string>;
export interface DataSetStringFilterValue {
    StaticValue?: string | redacted.Redacted<string> | undefined;
}
export interface DataSetStringComparisonFilterCondition {
    Operator: DataSetStringComparisonFilterOperator;
    Value?: DataSetStringFilterValue | undefined;
}
export type DataSetStringListFilterOperator = "INCLUDE" | "EXCLUDE" | (string & {});
export type DataSetStringFilterStaticValueList = (string | redacted.Redacted<string>)[];
export interface DataSetStringListFilterValue {
    StaticValues?: (string | redacted.Redacted<string>)[] | undefined;
}
export interface DataSetStringListFilterCondition {
    Operator: DataSetStringListFilterOperator;
    Values?: DataSetStringListFilterValue | undefined;
}
export interface DataSetStringFilterCondition {
    ColumnName?: string | undefined;
    ComparisonFilterCondition?: DataSetStringComparisonFilterCondition | undefined;
    ListFilterCondition?: DataSetStringListFilterCondition | undefined;
}
export type DataSetNumericComparisonFilterOperator = "EQUALS" | "DOES_NOT_EQUAL" | "GREATER_THAN" | "GREATER_THAN_OR_EQUALS_TO" | "LESS_THAN" | "LESS_THAN_OR_EQUALS_TO" | (string & {});
export interface DataSetNumericFilterValue {
    StaticValue?: number | undefined;
}
export interface DataSetNumericComparisonFilterCondition {
    Operator: DataSetNumericComparisonFilterOperator;
    Value?: DataSetNumericFilterValue | undefined;
}
export interface DataSetNumericRangeFilterCondition {
    RangeMinimum?: DataSetNumericFilterValue | undefined;
    RangeMaximum?: DataSetNumericFilterValue | undefined;
    IncludeMinimum?: boolean | undefined;
    IncludeMaximum?: boolean | undefined;
}
export interface DataSetNumericFilterCondition {
    ColumnName?: string | undefined;
    ComparisonFilterCondition?: DataSetNumericComparisonFilterCondition | undefined;
    RangeFilterCondition?: DataSetNumericRangeFilterCondition | undefined;
}
export type DataSetDateComparisonFilterOperator = "BEFORE" | "BEFORE_OR_EQUALS_TO" | "AFTER" | "AFTER_OR_EQUALS_TO" | (string & {});
export interface DataSetDateFilterValue {
    StaticValue?: Date | undefined;
}
export interface DataSetDateComparisonFilterCondition {
    Operator: DataSetDateComparisonFilterOperator;
    Value?: DataSetDateFilterValue | undefined;
}
export interface DataSetDateRangeFilterCondition {
    RangeMinimum?: DataSetDateFilterValue | undefined;
    RangeMaximum?: DataSetDateFilterValue | undefined;
    IncludeMinimum?: boolean | undefined;
    IncludeMaximum?: boolean | undefined;
}
export interface DataSetDateFilterCondition {
    ColumnName?: string | undefined;
    ComparisonFilterCondition?: DataSetDateComparisonFilterCondition | undefined;
    RangeFilterCondition?: DataSetDateRangeFilterCondition | undefined;
}
export interface FilterOperation {
    ConditionExpression?: string | redacted.Redacted<string> | undefined;
    StringFilterCondition?: DataSetStringFilterCondition | undefined;
    NumericFilterCondition?: DataSetNumericFilterCondition | undefined;
    DateFilterCondition?: DataSetDateFilterCondition | undefined;
}
export type DataSetCalculatedFieldExpression = string | redacted.Redacted<string>;
export interface CalculatedColumn {
    ColumnName: string;
    ColumnId: string;
    Expression: string | redacted.Redacted<string>;
}
export type CalculatedColumnList = CalculatedColumn[];
export interface CreateColumnsOperation {
    Alias?: string | undefined;
    Source?: TransformOperationSource | undefined;
    Columns: CalculatedColumn[];
}
export interface RenameColumnOperation {
    ColumnName: string;
    NewColumnName: string;
}
export type ColumnDataType = "STRING" | "INTEGER" | "DECIMAL" | "DATETIME" | (string & {});
export type TypeCastFormat = string;
export interface CastColumnTypeOperation {
    ColumnName: string;
    NewColumnType: ColumnDataType;
    SubType?: ColumnDataSubType | undefined;
    Format?: string | undefined;
}
export type GeoSpatialDataRole = "COUNTRY" | "STATE" | "COUNTY" | "CITY" | "POSTCODE" | "LONGITUDE" | "LATITUDE" | (string & {});
export type ColumnDescriptiveText = string | redacted.Redacted<string>;
export interface ColumnDescription {
    Text?: string | redacted.Redacted<string> | undefined;
}
export interface ColumnTag {
    ColumnGeographicRole?: GeoSpatialDataRole | undefined;
    ColumnDescription?: ColumnDescription | undefined;
}
export type ColumnTagList = ColumnTag[];
export interface TagColumnOperation {
    ColumnName: string;
    Tags: ColumnTag[];
}
export type ColumnTagName = "COLUMN_GEOGRAPHIC_ROLE" | "COLUMN_DESCRIPTION" | (string & {});
export type ColumnTagNames = ColumnTagName[];
export interface UntagColumnOperation {
    ColumnName: string;
    TagNames: ColumnTagName[];
}
export type DatasetParameterName = string;
export type StringDatasetParameterDefaultValue = string;
export type StringDatasetParameterValueList = string[];
export type DecimalDatasetParameterDefaultValue = number;
export type DecimalDatasetParameterValueList = number[];
export type DateTimeDatasetParameterDefaultValue = Date;
export type DateTimeDatasetParameterValueList = Date[];
export type IntegerDatasetParameterDefaultValue = number;
export type IntegerDatasetParameterValueList = number[];
export interface NewDefaultValues {
    StringStaticValues?: string[] | undefined;
    DecimalStaticValues?: number[] | undefined;
    DateTimeStaticValues?: Date[] | undefined;
    IntegerStaticValues?: number[] | undefined;
}
export interface OverrideDatasetParameterOperation {
    ParameterName: string;
    NewParameterName?: string | undefined;
    NewDefaultValues?: NewDefaultValues | undefined;
}
export type TransformOperation = {
    ProjectOperation: ProjectOperation;
    FilterOperation?: undefined;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation?: undefined;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation: FilterOperation;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation?: undefined;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation?: undefined;
    CreateColumnsOperation: CreateColumnsOperation;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation?: undefined;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation?: undefined;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation: RenameColumnOperation;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation?: undefined;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation?: undefined;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation: CastColumnTypeOperation;
    TagColumnOperation?: undefined;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation?: undefined;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation: TagColumnOperation;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation?: undefined;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation?: undefined;
    UntagColumnOperation: UntagColumnOperation;
    OverrideDatasetParameterOperation?: undefined;
} | {
    ProjectOperation?: undefined;
    FilterOperation?: undefined;
    CreateColumnsOperation?: undefined;
    RenameColumnOperation?: undefined;
    CastColumnTypeOperation?: undefined;
    TagColumnOperation?: undefined;
    UntagColumnOperation?: undefined;
    OverrideDatasetParameterOperation: OverrideDatasetParameterOperation;
};
export type TransformOperationList = TransformOperation[];
export interface JoinKeyProperties {
    UniqueKey?: boolean | undefined;
}
export type JoinType = "INNER" | "OUTER" | "LEFT" | "RIGHT" | (string & {});
export type OnClause = string;
export interface JoinInstruction {
    LeftOperand: string;
    RightOperand: string;
    LeftJoinKeyProperties?: JoinKeyProperties | undefined;
    RightJoinKeyProperties?: JoinKeyProperties | undefined;
    Type: JoinType;
    OnClause: string;
}
export interface LogicalTableSource {
    JoinInstruction?: JoinInstruction | undefined;
    PhysicalTableId?: string | undefined;
    DataSetArn?: string | undefined;
}
export interface LogicalTable {
    Alias: string;
    DataTransforms?: TransformOperation[] | undefined;
    Source: LogicalTableSource;
}
export type LogicalTableMap = {
    [key: string]: LogicalTable | undefined;
};
export type DataSetImportMode = "SPICE" | "DIRECT_QUERY" | (string & {});
export type ColumnGroupName = string;
export type GeoSpatialCountryCode = "US" | (string & {});
export type ColumnList = string[];
export interface GeoSpatialColumnGroup {
    Name: string;
    CountryCode?: GeoSpatialCountryCode | undefined;
    Columns: string[];
}
export interface ColumnGroup {
    GeoSpatialColumnGroup?: GeoSpatialColumnGroup | undefined;
}
export type ColumnGroupList = ColumnGroup[];
export type FieldFolderPath = string;
export type FieldFolderDescription = string;
export type FolderColumnList = string[];
export interface FieldFolder {
    description?: string | undefined;
    columns?: string[] | undefined;
}
export type FieldFolderMap = {
    [key: string]: FieldFolder | undefined;
};
export type RowLevelPermissionPolicy = "GRANT_ACCESS" | "DENY_ACCESS" | (string & {});
export type RowLevelPermissionFormatVersion = "VERSION_1" | "VERSION_2" | (string & {});
export type Status = "ENABLED" | "DISABLED" | (string & {});
export interface RowLevelPermissionDataSet {
    Namespace?: string | undefined;
    Arn: string;
    PermissionPolicy: RowLevelPermissionPolicy;
    FormatVersion?: RowLevelPermissionFormatVersion | undefined;
    Status?: Status | undefined;
}
export type SessionTagKey = string;
export type RowLevelPermissionTagDelimiter = string;
export type SessionTagValue = string | redacted.Redacted<string>;
export interface RowLevelPermissionTagRule {
    TagKey: string;
    ColumnName: string;
    TagMultiValueDelimiter?: string | undefined;
    MatchAllValue?: string | redacted.Redacted<string> | undefined;
}
export type RowLevelPermissionTagRuleList = RowLevelPermissionTagRule[];
export type RowLevelPermissionTagRuleConfiguration = string[];
export type RowLevelPermissionTagRuleConfigurationList = string[][];
export interface RowLevelPermissionTagConfiguration {
    Status?: Status | undefined;
    TagRules: RowLevelPermissionTagRule[];
    TagRuleConfigurations?: string[][] | undefined;
}
export type PrincipalList = string[];
export type ColumnLevelPermissionRuleColumnNameList = string[];
export interface ColumnLevelPermissionRule {
    Principals?: string[] | undefined;
    ColumnNames?: string[] | undefined;
}
export type ColumnLevelPermissionRuleList = ColumnLevelPermissionRule[];
export interface DataSetUsageConfiguration {
    DisableUseAsDirectQuerySource?: boolean | undefined;
    DisableUseAsImportedSource?: boolean | undefined;
}
export type DatasetParameterId = string;
export type DatasetParameterValueType = "MULTI_VALUED" | "SINGLE_VALUED" | (string & {});
export interface StringDatasetParameterDefaultValues {
    StaticValues?: string[] | undefined;
}
export interface StringDatasetParameter {
    Id: string;
    Name: string;
    ValueType: DatasetParameterValueType;
    DefaultValues?: StringDatasetParameterDefaultValues | undefined;
}
export interface DecimalDatasetParameterDefaultValues {
    StaticValues?: number[] | undefined;
}
export interface DecimalDatasetParameter {
    Id: string;
    Name: string;
    ValueType: DatasetParameterValueType;
    DefaultValues?: DecimalDatasetParameterDefaultValues | undefined;
}
export interface IntegerDatasetParameterDefaultValues {
    StaticValues?: number[] | undefined;
}
export interface IntegerDatasetParameter {
    Id: string;
    Name: string;
    ValueType: DatasetParameterValueType;
    DefaultValues?: IntegerDatasetParameterDefaultValues | undefined;
}
export interface DateTimeDatasetParameterDefaultValues {
    StaticValues?: Date[] | undefined;
}
export interface DateTimeDatasetParameter {
    Id: string;
    Name: string;
    ValueType: DatasetParameterValueType;
    TimeGranularity?: TimeGranularity | undefined;
    DefaultValues?: DateTimeDatasetParameterDefaultValues | undefined;
}
export interface DatasetParameter {
    StringDatasetParameter?: StringDatasetParameter | undefined;
    DecimalDatasetParameter?: DecimalDatasetParameter | undefined;
    IntegerDatasetParameter?: IntegerDatasetParameter | undefined;
    DateTimeDatasetParameter?: DateTimeDatasetParameter | undefined;
}
export type DatasetParameterList = DatasetParameter[];
export type UniqueKeyColumnNameList = string[];
export interface UniqueKey {
    ColumnNames: string[];
}
export type UniqueKeyList = UniqueKey[];
export interface PerformanceConfiguration {
    UniqueKeys?: UniqueKey[] | undefined;
}
export type DataSetUseAs = "RLS_RULES" | (string & {});
export interface ParentDataSet {
    DataSetArn: string;
    InputColumns: InputColumn[];
}
export interface SourceTable {
    PhysicalTableId?: string | undefined;
    DataSet?: ParentDataSet | undefined;
}
export type SourceTableMap = {
    [key: string]: SourceTable | undefined;
};
export interface ImportTableOperationSource {
    SourceTableId: string;
    ColumnIdMappings?: DataSetColumnIdMapping[] | undefined;
}
export interface ImportTableOperation {
    Alias: string;
    Source: ImportTableOperationSource;
}
export type FilterOperationList = FilterOperation[];
export interface FiltersOperation {
    Alias: string;
    Source: TransformOperationSource;
    FilterOperations: FilterOperation[];
}
export type RenameColumnOperationList = RenameColumnOperation[];
export interface RenameColumnsOperation {
    Alias: string;
    Source: TransformOperationSource;
    RenameColumnOperations: RenameColumnOperation[];
}
export type CastColumnTypeOperationList = CastColumnTypeOperation[];
export interface CastColumnTypesOperation {
    Alias: string;
    Source: TransformOperationSource;
    CastColumnTypeOperations: CastColumnTypeOperation[];
}
export type JoinOperationType = "INNER" | "OUTER" | "LEFT" | "RIGHT" | (string & {});
export type JoinOperationOnClause = string | redacted.Redacted<string>;
export interface OutputColumnNameOverride {
    SourceColumnName?: string | undefined;
    OutputColumnName: string;
}
export type OutputColumnNameOverrideList = OutputColumnNameOverride[];
export interface JoinOperandProperties {
    OutputColumnNameOverrides: OutputColumnNameOverride[];
}
export interface JoinOperation {
    Alias: string;
    LeftOperand: TransformOperationSource;
    RightOperand: TransformOperationSource;
    Type: JoinOperationType;
    OnClause: string | redacted.Redacted<string>;
    LeftOperandProperties?: JoinOperandProperties | undefined;
    RightOperandProperties?: JoinOperandProperties | undefined;
}
export type GroupByColumnNameList = string[];
export type DataPrepSimpleAggregationFunctionType = "COUNT" | "DISTINCT_COUNT" | "SUM" | "AVERAGE" | "MAX" | "MIN" | (string & {});
export interface DataPrepSimpleAggregationFunction {
    InputColumnName?: string | undefined;
    FunctionType: DataPrepSimpleAggregationFunctionType;
}
export type Separator = string;
export interface DataPrepListAggregationFunction {
    InputColumnName?: string | undefined;
    Separator: string;
    Distinct: boolean;
}
export interface DataPrepAggregationFunction {
    SimpleAggregation?: DataPrepSimpleAggregationFunction | undefined;
    ListAggregation?: DataPrepListAggregationFunction | undefined;
}
export interface Aggregation {
    AggregationFunction: DataPrepAggregationFunction;
    NewColumnName: string;
    NewColumnId: string;
}
export type AggregationList = Aggregation[];
export interface AggregateOperation {
    Alias: string;
    Source: TransformOperationSource;
    GroupByColumnNames?: string[] | undefined;
    Aggregations: Aggregation[];
}
export type PivotGroupByColumnNameList = string[];
export interface ValueColumnConfiguration {
    AggregationFunction?: DataPrepAggregationFunction | undefined;
}
export type CellValue = string;
export interface PivotedLabel {
    LabelName: string;
    NewColumnName: string;
    NewColumnId: string;
}
export type PivotedLabelList = PivotedLabel[];
export interface PivotConfiguration {
    LabelColumnName?: string | undefined;
    PivotedLabels: PivotedLabel[];
}
export interface PivotOperation {
    Alias: string;
    Source: TransformOperationSource;
    GroupByColumnNames?: string[] | undefined;
    ValueColumnConfiguration: ValueColumnConfiguration;
    PivotConfiguration: PivotConfiguration;
}
export interface ColumnToUnpivot {
    ColumnName?: string | undefined;
    NewValue?: string | undefined;
}
export type ColumnToUnpivotList = ColumnToUnpivot[];
export interface UnpivotOperation {
    Alias: string;
    Source: TransformOperationSource;
    ColumnsToUnpivot: ColumnToUnpivot[];
    UnpivotedLabelColumnName: string;
    UnpivotedLabelColumnId: string;
    UnpivotedValueColumnName: string;
    UnpivotedValueColumnId: string;
}
export interface AppendedColumn {
    ColumnName: string;
    NewColumnId: string;
}
export type AppendedColumnList = AppendedColumn[];
export interface AppendOperation {
    Alias: string;
    FirstSource?: TransformOperationSource | undefined;
    SecondSource?: TransformOperationSource | undefined;
    AppendedColumns: AppendedColumn[];
}
export interface TransformStep {
    ImportTableStep?: ImportTableOperation | undefined;
    ProjectStep?: ProjectOperation | undefined;
    FiltersStep?: FiltersOperation | undefined;
    CreateColumnsStep?: CreateColumnsOperation | undefined;
    RenameColumnsStep?: RenameColumnsOperation | undefined;
    CastColumnTypesStep?: CastColumnTypesOperation | undefined;
    JoinStep?: JoinOperation | undefined;
    AggregateStep?: AggregateOperation | undefined;
    PivotStep?: PivotOperation | undefined;
    UnpivotStep?: UnpivotOperation | undefined;
    AppendStep?: AppendOperation | undefined;
}
export type TransformStepMap = {
    [key: string]: TransformStep | undefined;
};
export type DestinationTableAlias = string;
export interface DestinationTableSource {
    TransformOperationId: string;
}
export interface DestinationTable {
    Alias: string;
    Source: DestinationTableSource;
}
export type DestinationTableMap = {
    [key: string]: DestinationTable | undefined;
};
export interface DataPrepConfiguration {
    SourceTableMap: {
        [key: string]: SourceTable | undefined;
    };
    TransformStepMap: {
        [key: string]: TransformStep | undefined;
    };
    DestinationTableMap: {
        [key: string]: DestinationTable | undefined;
    };
}
export type SemanticTableAlias = string;
export interface RowLevelPermissionConfiguration {
    TagConfiguration?: RowLevelPermissionTagConfiguration | undefined;
    RowLevelPermissionDataSet?: RowLevelPermissionDataSet | undefined;
}
export type ColumnNameList = string[];
export type AdditionalNotesText = string | redacted.Redacted<string>;
export interface AdditionalNotes {
    Text?: string | redacted.Redacted<string> | undefined;
}
export interface ColumnSemanticType {
    GeographicalRole?: GeoSpatialDataRole | undefined;
}
export interface ColumnSemanticProperty {
    Description?: ColumnDescription | undefined;
    AdditionalNotes?: AdditionalNotes | undefined;
    SemanticType?: ColumnSemanticType | undefined;
}
export type ColumnSemanticPropertyList = ColumnSemanticProperty[];
export interface SharedColumnSemanticMetadata {
    ColumnNames?: string[] | undefined;
    ColumnProperties: ColumnSemanticProperty[];
}
export type SharedColumnSemanticMetadataList = SharedColumnSemanticMetadata[];
export interface TableSemanticMetadata {
    ColumnMetadata?: SharedColumnSemanticMetadata[] | undefined;
}
export interface SemanticTable {
    Alias: string;
    DestinationTableId: string;
    RowLevelPermissionConfiguration?: RowLevelPermissionConfiguration | undefined;
    SemanticMetadata?: TableSemanticMetadata | undefined;
}
export type SemanticTableMap = {
    [key: string]: SemanticTable | undefined;
};
export type DataSetDescriptiveText = string | redacted.Redacted<string>;
export interface DataSetSemanticDescription {
    Text: string | redacted.Redacted<string>;
}
export type InlineCustomInstructionText = string | redacted.Redacted<string>;
export type UploadedDocumentName = string;
export interface UploadedDocumentMetadata {
    Name?: string | undefined;
}
export interface InlineCustomInstruction {
    InstructionText: string | redacted.Redacted<string>;
    UploadedDocumentMetadata?: UploadedDocumentMetadata | undefined;
}
export interface CustomInstruction {
    InlineCustomInstruction?: InlineCustomInstruction | undefined;
}
export type CustomInstructionList = CustomInstruction[];
export interface DataSetSemanticMetadata {
    Description?: DataSetSemanticDescription | undefined;
    CustomInstructions?: CustomInstruction[] | undefined;
}
export type DataSetSemanticMetadataList = DataSetSemanticMetadata[];
export interface SemanticModelConfiguration {
    TableMap?: {
        [key: string]: SemanticTable | undefined;
    } | undefined;
    SemanticMetadata?: DataSetSemanticMetadata[] | undefined;
}
export interface CreateDataSetRequest {
    AwsAccountId: string;
    DataSetId: string;
    Name: string;
    PhysicalTableMap: {
        [key: string]: PhysicalTable | undefined;
    };
    LogicalTableMap?: {
        [key: string]: LogicalTable | undefined;
    } | undefined;
    ImportMode: DataSetImportMode;
    ColumnGroups?: ColumnGroup[] | undefined;
    FieldFolders?: {
        [key: string]: FieldFolder | undefined;
    } | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RowLevelPermissionDataSet?: RowLevelPermissionDataSet | undefined;
    RowLevelPermissionTagConfiguration?: RowLevelPermissionTagConfiguration | undefined;
    ColumnLevelPermissionRules?: ColumnLevelPermissionRule[] | undefined;
    Tags?: Tag[] | undefined;
    DataSetUsageConfiguration?: DataSetUsageConfiguration | undefined;
    DatasetParameters?: DatasetParameter[] | undefined;
    FolderArns?: string[] | undefined;
    PerformanceConfiguration?: PerformanceConfiguration | undefined;
    UseAs?: DataSetUseAs | undefined;
    DataPrepConfiguration?: DataPrepConfiguration | undefined;
    SemanticModelConfiguration?: SemanticModelConfiguration | undefined;
}
export interface CreateDataSetResponse {
    Arn?: string | undefined;
    DataSetId?: string | undefined;
    IngestionArn?: string | undefined;
    IngestionId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type DataSourceType = "ADOBE_ANALYTICS" | "AMAZON_ELASTICSEARCH" | "ATHENA" | "AURORA" | "AURORA_POSTGRESQL" | "AWS_IOT_ANALYTICS" | "GITHUB" | "JIRA" | "MARIADB" | "MYSQL" | "ORACLE" | "POSTGRESQL" | "PRESTO" | "REDSHIFT" | "S3" | "S3_TABLES" | "SALESFORCE" | "SERVICENOW" | "SNOWFLAKE" | "SPARK" | "SQLSERVER" | "TERADATA" | "TWITTER" | "TIMESTREAM" | "AMAZON_OPENSEARCH" | "EXASOL" | "DATABRICKS" | "STARBURST" | "TRINO" | "BIGQUERY" | "GOOGLESHEETS" | "GOOGLE_DRIVE" | "CONFLUENCE" | "SHAREPOINT" | "ONE_DRIVE" | "WEB_CRAWLER" | "S3_KNOWLEDGE_BASE" | "QBUSINESS" | (string & {});
export type Domain = string;
export interface AmazonElasticsearchParameters {
    Domain: string;
}
export type WorkGroup = string;
export interface IdentityCenterConfiguration {
    EnableIdentityPropagation?: boolean | undefined;
}
export interface AthenaParameters {
    WorkGroup?: string | undefined;
    RoleArn?: string | undefined;
    ConsumerAccountRoleArn?: string | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
}
export type Host = string;
export type Port = number;
export type Database = string;
export interface AuroraParameters {
    Host: string;
    Port: number;
    Database: string;
}
export interface AuroraPostgreSqlParameters {
    Host: string;
    Port: number;
    Database: string;
}
export type DataSetName = string;
export interface AwsIotAnalyticsParameters {
    DataSetName: string;
}
export type SiteBaseUrl = string;
export interface JiraParameters {
    SiteBaseUrl: string;
}
export interface MariaDbParameters {
    Host: string;
    Port: number;
    Database: string;
}
export interface MySqlParameters {
    Host: string;
    Port: number;
    Database: string;
}
export interface OracleParameters {
    Host: string;
    Port: number;
    Database: string;
    UseServiceName?: boolean | undefined;
}
export interface PostgreSqlParameters {
    Host: string;
    Port: number;
    Database: string;
}
export type Catalog = string;
export interface PrestoParameters {
    Host: string;
    Port: number;
    Catalog: string;
}
export type InstanceId = string;
export interface RdsParameters {
    InstanceId: string;
    Database: string;
}
export type OptionalPort = number;
export type ClusterId = string;
export type DatabaseUser = string;
export type DatabaseGroup = string;
export type DatabaseGroupList = string[];
export interface RedshiftIAMParameters {
    RoleArn: string;
    DatabaseUser?: string | undefined;
    DatabaseGroups?: string[] | undefined;
    AutoCreateDatabaseUser?: boolean | undefined;
}
export interface RedshiftParameters {
    Host?: string | undefined;
    Port?: number | undefined;
    Database: string;
    ClusterId?: string | undefined;
    IAMParameters?: RedshiftIAMParameters | undefined;
    IdentityCenterConfiguration?: IdentityCenterConfiguration | undefined;
}
export type S3Bucket = string;
export type S3Key = string;
export interface ManifestFileLocation {
    Bucket: string;
    Key: string;
}
export interface S3Parameters {
    ManifestFileLocation: ManifestFileLocation;
    RoleArn?: string | undefined;
}
export type S3TableBucketArn = string;
export interface S3TablesParameters {
    TableBucketArn?: string | undefined;
}
export type MetadataFilesLocation = string;
export interface S3KnowledgeBaseParameters {
    RoleArn?: string | undefined;
    BucketUrl: string;
    MetadataFilesLocation?: string | undefined;
}
export interface ServiceNowParameters {
    SiteBaseUrl: string;
}
export type Warehouse = string;
export type AuthenticationType = "PASSWORD" | "KEYPAIR" | "TOKEN" | "X509" | (string & {});
export type DatabaseAccessControlRole = string;
export type TokenProviderUrl = string;
export type OAuthScope = string;
export interface VpcConnectionProperties {
    VpcConnectionArn: string;
}
export type IdentityProviderResourceUri = string;
export type CACertificatesBundleS3Uri = string;
export interface OAuthParameters {
    TokenProviderUrl: string;
    OAuthScope?: string | undefined;
    IdentityProviderVpcConnectionProperties?: VpcConnectionProperties | undefined;
    IdentityProviderResourceUri?: string | undefined;
    IdentityProviderCACertificatesBundleS3Uri?: string | undefined;
}
export interface SnowflakeParameters {
    Host: string;
    Database: string;
    Warehouse: string;
    AuthenticationType?: AuthenticationType | undefined;
    DatabaseAccessControlRole?: string | undefined;
    OAuthParameters?: OAuthParameters | undefined;
}
export interface SparkParameters {
    Host: string;
    Port: number;
}
export interface SqlServerParameters {
    Host: string;
    Port: number;
    Database: string;
}
export interface TeradataParameters {
    Host: string;
    Port: number;
    Database: string;
}
export type Query = string;
export interface TwitterParameters {
    Query: string;
    MaxRows: number;
}
export interface AmazonOpenSearchParameters {
    Domain: string;
}
export interface ExasolParameters {
    Host: string;
    Port: number;
}
export type SqlEndpointPath = string;
export interface DatabricksParameters {
    Host: string;
    Port: number;
    SqlEndpointPath: string;
    AuthenticationType?: AuthenticationType | undefined;
    OAuthParameters?: OAuthParameters | undefined;
}
export type StarburstProductType = "GALAXY" | "ENTERPRISE" | (string & {});
export interface StarburstParameters {
    Host: string;
    Port: number;
    Catalog: string;
    ProductType?: StarburstProductType | undefined;
    DatabaseAccessControlRole?: string | undefined;
    AuthenticationType?: AuthenticationType | undefined;
    OAuthParameters?: OAuthParameters | undefined;
}
export interface TrinoParameters {
    Host: string;
    Port: number;
    Catalog: string;
}
export type ProjectId = string;
export type DataSetRegion = string;
export interface BigQueryParameters {
    ProjectId: string;
    DataSetRegion?: string | undefined;
}
export interface ImpalaParameters {
    Host: string;
    Port: number;
    Database?: string | undefined;
    SqlEndpointPath: string;
}
export interface CustomConnectionParameters {
    ConnectionType?: string | undefined;
}
export type WebCrawlerAuthType = "NO_AUTH" | "BASIC_AUTH" | "FORM" | "SAML" | (string & {});
export type XpathFields = string;
export interface WebCrawlerParameters {
    WebCrawlerAuthType: WebCrawlerAuthType;
    UsernameFieldXpath?: string | undefined;
    PasswordFieldXpath?: string | undefined;
    UsernameButtonXpath?: string | undefined;
    PasswordButtonXpath?: string | undefined;
    LoginPageUrl?: string | undefined;
    WebProxyHostName?: string | undefined;
    WebProxyPortNumber?: number | undefined;
}
export interface ConfluenceParameters {
    ConfluenceUrl: string;
}
export type ApplicationArn = string;
export interface QBusinessParameters {
    ApplicationArn: string;
}
export type SharePointDomain = string;
export type SharePointTenantId = string;
export type SharePointClientId = string;
export type AuthType = "THREE_LEGGED_OAUTH" | "TWO_LEGGED_OAUTH" | "SERVICE_ACCOUNT" | (string & {});
export interface SharePointParameters {
    SharePointDomain: string;
    TenantId?: string | undefined;
    ClientId?: string | undefined;
    AuthType?: AuthType | undefined;
}
export interface GoogleDriveParameters {
    AuthType?: AuthType | undefined;
}
export type OneDriveTenantId = string;
export type OneDriveClientId = string;
export interface OneDriveParameters {
    TenantId?: string | undefined;
    ClientId?: string | undefined;
    AuthType?: AuthType | undefined;
}
export type FMKBKnowledgeBaseArn = string;
export type LinkedDataSourceId = string;
export type LinkedDataSourceIds = string[];
export interface FMKBParameters {
    KnowledgeBaseArn: string;
    LinkedDataSourceIds?: string[] | undefined;
}
export type DataSourceParameters = {
    AmazonElasticsearchParameters: AmazonElasticsearchParameters;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters: AthenaParameters;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters: AuroraParameters;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters: AuroraPostgreSqlParameters;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters: AwsIotAnalyticsParameters;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters: JiraParameters;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters: MariaDbParameters;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters: MySqlParameters;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters: OracleParameters;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters: PostgreSqlParameters;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters: PrestoParameters;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters: RdsParameters;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters: RedshiftParameters;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters: S3Parameters;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters: S3TablesParameters;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters: S3KnowledgeBaseParameters;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters: ServiceNowParameters;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters: SnowflakeParameters;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters: SparkParameters;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters: SqlServerParameters;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters: TeradataParameters;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters: TwitterParameters;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters: AmazonOpenSearchParameters;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters: ExasolParameters;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters: DatabricksParameters;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters: StarburstParameters;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters: TrinoParameters;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters: BigQueryParameters;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters: ImpalaParameters;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters: CustomConnectionParameters;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters: WebCrawlerParameters;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters: ConfluenceParameters;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters: QBusinessParameters;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters: SharePointParameters;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters: GoogleDriveParameters;
    OneDriveParameters?: undefined;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters: OneDriveParameters;
    FMKBParameters?: undefined;
} | {
    AmazonElasticsearchParameters?: undefined;
    AthenaParameters?: undefined;
    AuroraParameters?: undefined;
    AuroraPostgreSqlParameters?: undefined;
    AwsIotAnalyticsParameters?: undefined;
    JiraParameters?: undefined;
    MariaDbParameters?: undefined;
    MySqlParameters?: undefined;
    OracleParameters?: undefined;
    PostgreSqlParameters?: undefined;
    PrestoParameters?: undefined;
    RdsParameters?: undefined;
    RedshiftParameters?: undefined;
    S3Parameters?: undefined;
    S3TablesParameters?: undefined;
    S3KnowledgeBaseParameters?: undefined;
    ServiceNowParameters?: undefined;
    SnowflakeParameters?: undefined;
    SparkParameters?: undefined;
    SqlServerParameters?: undefined;
    TeradataParameters?: undefined;
    TwitterParameters?: undefined;
    AmazonOpenSearchParameters?: undefined;
    ExasolParameters?: undefined;
    DatabricksParameters?: undefined;
    StarburstParameters?: undefined;
    TrinoParameters?: undefined;
    BigQueryParameters?: undefined;
    ImpalaParameters?: undefined;
    CustomConnectionParameters?: undefined;
    WebCrawlerParameters?: undefined;
    ConfluenceParameters?: undefined;
    QBusinessParameters?: undefined;
    SharePointParameters?: undefined;
    GoogleDriveParameters?: undefined;
    OneDriveParameters?: undefined;
    FMKBParameters: FMKBParameters;
};
export type DbUsername = string;
export type Password = string;
export type DataSourceParametersList = DataSourceParameters[];
export interface CredentialPair {
    Username: string;
    Password: string | redacted.Redacted<string>;
    AlternateDataSourceParameters?: DataSourceParameters[] | undefined;
}
export type CopySourceArn = string;
export type SecretArn = string;
export type PrivateKey = string | redacted.Redacted<string>;
export type PrivateKeyPassphrase = string | redacted.Redacted<string>;
export interface KeyPairCredentials {
    KeyPairUsername: string;
    PrivateKey: string | redacted.Redacted<string>;
    PrivateKeyPassphrase?: string | redacted.Redacted<string> | undefined;
}
export interface WebProxyCredentials {
    WebProxyUsername: string;
    WebProxyPassword: string | redacted.Redacted<string>;
}
export type OAuthClientId = string | redacted.Redacted<string>;
export type OAuthClientSecret = string | redacted.Redacted<string>;
export type OAuthUsername = string | redacted.Redacted<string>;
export interface OAuthClientCredentials {
    ClientId?: string | redacted.Redacted<string> | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    Username?: string | redacted.Redacted<string> | undefined;
}
export type AdminAccountEmail = string;
export type ClientEmail = string;
export interface ServiceAccountCredentials {
    AdminAccountEmail: string;
    ServiceAccountPrivateKey: string | redacted.Redacted<string>;
    ClientEmail: string;
}
export type DataSourceKmsKeyArn = string | redacted.Redacted<string>;
export type DataSourceCertThumbprint = string | redacted.Redacted<string>;
export interface SharePointClientCredentials {
    KmsKeyArn: string | redacted.Redacted<string>;
    CertThumbprint: string | redacted.Redacted<string>;
}
export interface OneDriveClientCredentials {
    KmsKeyArn: string | redacted.Redacted<string>;
    CertThumbprint: string | redacted.Redacted<string>;
}
export interface DataSourceCredentials {
    CredentialPair?: CredentialPair | undefined;
    CopySourceArn?: string | undefined;
    SecretArn?: string | undefined;
    KeyPairCredentials?: KeyPairCredentials | undefined;
    WebProxyCredentials?: WebProxyCredentials | undefined;
    OAuthClientCredentials?: OAuthClientCredentials | undefined;
    ServiceAccountCredentials?: ServiceAccountCredentials | undefined;
    SharePointClientCredentials?: SharePointClientCredentials | undefined;
    OneDriveClientCredentials?: OneDriveClientCredentials | undefined;
}
export interface SslProperties {
    DisableSsl?: boolean | undefined;
}
export interface CreateDataSourceRequest {
    AwsAccountId: string;
    DataSourceId: string;
    Name: string;
    Type: DataSourceType;
    DataSourceParameters?: DataSourceParameters | undefined;
    Credentials?: DataSourceCredentials | undefined;
    Permissions?: ResourcePermission[] | undefined;
    VpcConnectionProperties?: VpcConnectionProperties | undefined;
    SslProperties?: SslProperties | undefined;
    Tags?: Tag[] | undefined;
    FolderArns?: string[] | undefined;
}
export interface CreateDataSourceResponse {
    Arn?: string | undefined;
    DataSourceId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type DlpSettingId = string;
export type DlpSettingName = string;
export type DlpProviderType = "MICROSOFT_PURVIEW" | (string & {});
export type SecretManagerArn = string;
export interface MicrosoftPurviewCredentials {
    SecretArn: string;
}
export type LabelId = string;
export type LabelName = string;
export type DlpAction = "ALLOW" | "WARN" | "BLOCK" | (string & {});
export interface LabelActionMapping {
    LabelId: string;
    LabelName: string;
    Action: DlpAction;
}
export type LabelActionMappingList = LabelActionMapping[];
export interface MicrosoftPurviewProviderConfig {
    Credentials: MicrosoftPurviewCredentials;
    LabelActionMappings: LabelActionMapping[];
    UnmappedAction: DlpAction;
}
export type ProviderConfig = {
    MicrosoftPurview: MicrosoftPurviewProviderConfig;
};
export interface CreateDlpSettingRequest {
    AwsAccountId: string;
    DlpSettingId: string;
    Name: string;
    ProviderType: DlpProviderType;
    ProviderConfig: ProviderConfig;
    ProviderOutageAction: DlpAction;
    Enabled: boolean;
    Tags?: Tag[] | undefined;
}
export interface CreateDlpSettingResponse {
    Arn: string;
    DlpSettingId: string;
    RequestId?: string | undefined;
}
export type AccountId = string;
export type TitleInput = string;
export type FlowDescriptionInput = string;
export type SensitiveDocument = unknown;
export type ActionsListMemberString = string;
export type ActionsList = string[];
export type PermissionPrincipalString = string;
export interface Permission {
    Actions: string[];
    Principal: string;
}
export type PermissionsList = Permission[];
export type CreateFlowRequestClientTokenString = string;
export interface CreateFlowRequest {
    AwsAccountId: string;
    Name: string;
    Description?: string | undefined;
    FlowDefinition: any;
    Permissions?: Permission[] | undefined;
    ClientToken?: string | undefined;
}
export type FlowId = string;
export interface CreateFlowResponse {
    Arn: string;
    FlowId: string;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type RestrictiveResourceId = string;
export type FolderName = string;
export type FolderType = "SHARED" | "RESTRICTED" | (string & {});
export type SharingModel = "ACCOUNT" | "NAMESPACE" | (string & {});
export interface CreateFolderRequest {
    AwsAccountId: string;
    FolderId: string;
    Name?: string | undefined;
    FolderType?: FolderType | undefined;
    ParentFolderArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Tags?: Tag[] | undefined;
    SharingModel?: SharingModel | undefined;
}
export interface CreateFolderResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    FolderId?: string | undefined;
    RequestId?: string | undefined;
}
export type MemberType = "DASHBOARD" | "ANALYSIS" | "DATASET" | "DATASOURCE" | "TOPIC" | (string & {});
export interface CreateFolderMembershipRequest {
    AwsAccountId: string;
    FolderId: string;
    MemberId: string;
    MemberType: MemberType;
}
export interface FolderMember {
    MemberId?: string | undefined;
    MemberType?: MemberType | undefined;
}
export interface CreateFolderMembershipResponse {
    Status?: number | undefined;
    FolderMember?: FolderMember | undefined;
    RequestId?: string | undefined;
}
export type GroupName = string;
export type GroupDescription = string;
export interface CreateGroupRequest {
    GroupName: string;
    Description?: string | undefined;
    AwsAccountId: string;
    Namespace: string;
}
export interface Group {
    Arn?: string | undefined;
    GroupName?: string | undefined;
    Description?: string | undefined;
    PrincipalId?: string | undefined;
}
export interface CreateGroupResponse {
    Group?: Group | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type GroupMemberName = string;
export interface CreateGroupMembershipRequest {
    MemberName: string;
    GroupName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface GroupMember {
    Arn?: string | undefined;
    MemberName?: string | undefined;
}
export interface CreateGroupMembershipResponse {
    GroupMember?: GroupMember | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type IAMPolicyAssignmentName = string;
export type AssignmentStatus = "ENABLED" | "DRAFT" | "DISABLED" | (string & {});
export type IdentityName = string;
export type IdentityNameList = string[];
export type IdentityMap = {
    [key: string]: string[] | undefined;
};
export interface CreateIAMPolicyAssignmentRequest {
    AwsAccountId: string;
    AssignmentName: string;
    AssignmentStatus: AssignmentStatus;
    PolicyArn?: string | undefined;
    Identities?: {
        [key: string]: string[] | undefined;
    } | undefined;
    Namespace: string;
}
export interface CreateIAMPolicyAssignmentResponse {
    AssignmentName?: string | undefined;
    AssignmentId?: string | undefined;
    AssignmentStatus?: AssignmentStatus | undefined;
    PolicyArn?: string | undefined;
    Identities?: {
        [key: string]: string[] | undefined;
    } | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type IngestionType = "INCREMENTAL_REFRESH" | "FULL_REFRESH" | (string & {});
export interface CreateIngestionRequest {
    DataSetId: string;
    IngestionId: string;
    AwsAccountId: string;
    IngestionType?: IngestionType | undefined;
}
export type IngestionStatus = "INITIALIZED" | "QUEUED" | "RUNNING" | "FAILED" | "COMPLETED" | "CANCELLED" | (string & {});
export interface CreateIngestionResponse {
    Arn?: string | undefined;
    IngestionId?: string | undefined;
    IngestionStatus?: IngestionStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type KnowledgeBaseName = string;
export type DataSourceArn = string;
export type KbTemplate = unknown;
export interface KbTemplateConfiguration {
    template?: any | undefined;
}
export interface KnowledgeBaseConfiguration {
    templateConfiguration?: KbTemplateConfiguration | undefined;
}
export type KnowledgeBaseDescription = string;
export type ImageExtractionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface ImageExtractionConfiguration {
    imageExtractionStatus: ImageExtractionStatus;
}
export type AudioExtractionStatus = "ENABLED" | "DISABLED" | (string & {});
export interface AudioExtractionConfiguration {
    audioExtractionStatus: AudioExtractionStatus;
}
export type VideoExtractionStatus = "ENABLED" | "DISABLED" | (string & {});
export type VideoExtractionType = "AUDIO_TRANSCRIPTION_ONLY" | "VISUAL_CONTENT_AND_AUDIO_TRANSCRIPTION" | (string & {});
export interface VideoExtractionConfiguration {
    videoExtractionStatus: VideoExtractionStatus;
    videoExtractionType?: VideoExtractionType | undefined;
}
export interface MediaExtractionConfiguration {
    imageExtractionConfiguration?: ImageExtractionConfiguration | undefined;
    audioExtractionConfiguration?: AudioExtractionConfiguration | undefined;
    videoExtractionConfiguration?: VideoExtractionConfiguration | undefined;
}
export interface AccessControlConfiguration {
    isACLEnabled?: boolean | undefined;
}
export interface CreateKnowledgeBaseRequest {
    AwsAccountId: string;
    KnowledgeBaseId: string;
    Name: string;
    DataSourceArn: string;
    KnowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    Description?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    MediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
    AccessControlConfiguration?: AccessControlConfiguration | undefined;
    PrimaryOwnerArn?: string | undefined;
    Tags?: Tag[] | undefined;
}
export type DataSetStatus = "CREATING" | "UPDATING" | "ACTIVE" | "FAILED" | "DELETING" | (string & {});
export interface CreateKnowledgeBaseResponse {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    CreationStatus: DataSetStatus;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type ProfileName = string;
export type ProfileDescription = string;
export type ProfileLimitValueMaxValueLong = number;
export interface ProfileLimitValue {
    maxValue: number;
    unit: LimitUnit;
}
export type CreateLimitsProfileRequestResourceLimitsMap = {
    [key in ResourceType]?: ProfileLimitValue | undefined;
};
export type CreateLimitsProfileRequestClientTokenString = string;
export interface CreateLimitsProfileRequest {
    accountId: string;
    profileName: string;
    description?: string | undefined;
    resourceLimits: {
        [key: string]: ProfileLimitValue | undefined;
    };
    clientToken: string;
}
export type ResourceArn = string;
export interface CreateLimitsProfileResponse {
    arn: string;
    profileId: string;
}
export type IdentityStore = "QUICKSIGHT" | (string & {});
export interface CreateNamespaceRequest {
    AwsAccountId: string;
    Namespace: string;
    IdentityStore: IdentityStore;
    Tags?: Tag[] | undefined;
}
export type NamespaceStatus = "CREATED" | "CREATING" | "DELETING" | "RETRYABLE_FAILURE" | "NON_RETRYABLE_FAILURE" | (string & {});
export interface CreateNamespaceResponse {
    Arn?: string | undefined;
    Name?: string | undefined;
    CapacityRegion?: string | undefined;
    CreationStatus?: NamespaceStatus | undefined;
    IdentityStore?: IdentityStore | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type OAuthClientApplicationId = string;
export type OAuthClientAuthenticationType = "TOKEN" | (string & {});
export type OAuthTokenEndpointUrl = string | redacted.Redacted<string>;
export type OAuthAuthorizationEndpointUrl = string | redacted.Redacted<string>;
export type OAuthScopesString = string;
export interface CreateOAuthClientApplicationRequest {
    AwsAccountId: string;
    OAuthClientApplicationId: string;
    Name: string;
    OAuthClientAuthenticationType: OAuthClientAuthenticationType;
    ClientId: string | redacted.Redacted<string>;
    ClientSecret: string | redacted.Redacted<string>;
    OAuthTokenEndpointUrl: string | redacted.Redacted<string>;
    OAuthAuthorizationEndpointUrl?: string | redacted.Redacted<string> | undefined;
    OAuthScopes?: string | undefined;
    DataSourceType?: DataSourceType | undefined;
    IdentityProviderVpcConnectionProperties?: VpcConnectionProperties | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateOAuthClientApplicationResponse {
    Arn?: string | undefined;
    OAuthClientApplicationId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type RefreshInterval = "MINUTE15" | "MINUTE30" | "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | (string & {});
export type DayOfWeek = "SUNDAY" | "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | (string & {});
export type DayOfMonth = string;
export interface ScheduleRefreshOnEntity {
    DayOfWeek?: DayOfWeek | undefined;
    DayOfMonth?: string | undefined;
}
export interface RefreshFrequency {
    Interval: RefreshInterval;
    RefreshOnDay?: ScheduleRefreshOnEntity | undefined;
    Timezone?: string | undefined;
    TimeOfTheDay?: string | undefined;
}
export interface RefreshSchedule {
    ScheduleId: string;
    ScheduleFrequency: RefreshFrequency;
    StartAfterDateTime?: Date | undefined;
    RefreshType: IngestionType;
    Arn?: string | undefined;
}
export interface CreateRefreshScheduleRequest {
    DataSetId: string;
    AwsAccountId: string;
    Schedule: RefreshSchedule;
}
export interface CreateRefreshScheduleResponse {
    Status?: number | undefined;
    RequestId?: string | undefined;
    ScheduleId?: string | undefined;
    Arn?: string | undefined;
}
export type Role = "ADMIN" | "AUTHOR" | "READER" | "ADMIN_PRO" | "AUTHOR_PRO" | "READER_PRO" | (string & {});
export interface CreateRoleMembershipRequest {
    MemberName: string;
    AwsAccountId: string;
    Namespace: string;
    Role: Role;
}
export interface CreateRoleMembershipResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type PublicSpaceId = string;
export type SpaceName = string;
export type SpaceDescription = string | redacted.Redacted<string>;
export interface CreateSpaceRequest {
    AwsAccountId: string;
    SpaceId: string;
    Name: string;
    Description?: string | redacted.Redacted<string> | undefined;
}
export type PublicSpaceArn = string;
export interface CreateSpaceResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    RequestId?: string | undefined;
}
export type TemplateName = string;
export interface TemplateSourceAnalysis {
    Arn: string;
    DataSetReferences: DataSetReference[];
    TopicReferences?: TopicReference[] | undefined;
}
export interface TemplateSourceTemplate {
    Arn: string;
}
export interface TemplateSourceEntity {
    SourceAnalysis?: TemplateSourceAnalysis | undefined;
    SourceTemplate?: TemplateSourceTemplate | undefined;
}
export interface ColumnSchema {
    Name?: string | undefined;
    DataType?: string | undefined;
    GeographicRole?: string | undefined;
}
export type ColumnSchemaList = ColumnSchema[];
export interface DataSetSchema {
    ColumnSchemaList?: ColumnSchema[] | undefined;
}
export interface ColumnGroupColumnSchema {
    Name?: string | undefined;
}
export type ColumnGroupColumnSchemaList = ColumnGroupColumnSchema[];
export interface ColumnGroupSchema {
    Name?: string | undefined;
    ColumnGroupColumnSchemaList?: ColumnGroupColumnSchema[] | undefined;
}
export type ColumnGroupSchemaList = ColumnGroupSchema[];
export interface DataSetConfiguration {
    Placeholder?: string | undefined;
    DataSetSchema?: DataSetSchema | undefined;
    ColumnGroupSchemaList?: ColumnGroupSchema[] | undefined;
}
export type DataSetConfigurationList = DataSetConfiguration[];
export interface TopicConfiguration {
    Placeholder?: string | undefined;
    DataSetSchema?: DataSetSchema | undefined;
    ColumnGroupSchemaList?: ColumnGroupSchema[] | undefined;
}
export type TopicConfigurationList = TopicConfiguration[];
export interface TemplateVersionDefinition {
    DataSetConfigurations: DataSetConfiguration[];
    TopicConfigurations?: TopicConfiguration[] | undefined;
    Sheets?: SheetDefinition[] | undefined;
    TooltipSheets?: TooltipSheetDefinition[] | undefined;
    CalculatedFields?: CalculatedField[] | undefined;
    ParameterDeclarations?: ParameterDeclaration[] | undefined;
    FilterGroups?: FilterGroup[] | undefined;
    ColumnConfigurations?: ColumnConfiguration[] | undefined;
    AnalysisDefaults?: AnalysisDefaults | undefined;
    Options?: AssetOptions | undefined;
    QueryExecutionOptions?: QueryExecutionOptions | undefined;
    StaticFiles?: StaticFile[] | undefined;
}
export interface CreateTemplateRequest {
    AwsAccountId: string;
    TemplateId: string;
    Name?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    SourceEntity?: TemplateSourceEntity | undefined;
    Tags?: Tag[] | undefined;
    VersionDescription?: string | undefined;
    Definition?: TemplateVersionDefinition | undefined;
    ValidationStrategy?: ValidationStrategy | undefined;
}
export interface CreateTemplateResponse {
    Arn?: string | undefined;
    VersionArn?: string | undefined;
    TemplateId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type AliasName = string;
export type VersionNumber = number;
export interface CreateTemplateAliasRequest {
    AwsAccountId: string;
    TemplateId: string;
    AliasName: string;
    TemplateVersionNumber: number;
}
export interface TemplateAlias {
    AliasName?: string | undefined;
    Arn?: string | undefined;
    TemplateVersionNumber?: number | undefined;
}
export interface CreateTemplateAliasResponse {
    TemplateAlias?: TemplateAlias | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type ThemeName = string;
export type ColorList = string[];
export interface DataColorPalette {
    Colors?: string[] | undefined;
    MinMaxGradient?: string[] | undefined;
    EmptyFillColor?: string | undefined;
}
export interface UIColorPalette {
    PrimaryForeground?: string | undefined;
    PrimaryBackground?: string | undefined;
    SecondaryForeground?: string | undefined;
    SecondaryBackground?: string | undefined;
    Accent?: string | undefined;
    AccentForeground?: string | undefined;
    Danger?: string | undefined;
    DangerForeground?: string | undefined;
    Warning?: string | undefined;
    WarningForeground?: string | undefined;
    Success?: string | undefined;
    SuccessForeground?: string | undefined;
    Dimension?: string | undefined;
    DimensionForeground?: string | undefined;
    Measure?: string | undefined;
    MeasureForeground?: string | undefined;
}
export type Color = string;
export interface BorderStyle {
    Color?: string | undefined;
    Show?: boolean | undefined;
    Width?: string | undefined;
}
export interface TileStyle {
    BackgroundColor?: string | undefined;
    Border?: BorderStyle | undefined;
    BorderRadius?: string | undefined;
    Padding?: string | undefined;
}
export interface GutterStyle {
    Show?: boolean | undefined;
}
export interface MarginStyle {
    Show?: boolean | undefined;
}
export interface TileLayoutStyle {
    Gutter?: GutterStyle | undefined;
    Margin?: MarginStyle | undefined;
}
export interface SheetBackgroundStyle {
    Color?: string | undefined;
    Gradient?: string | undefined;
}
export interface SheetStyle {
    Tile?: TileStyle | undefined;
    TileLayout?: TileLayoutStyle | undefined;
    Background?: SheetBackgroundStyle | undefined;
}
export interface Font {
    FontFamily?: string | undefined;
}
export type FontList = Font[];
export type TextTransform = "CAPITALIZE" | (string & {});
export interface VisualTitleFontConfiguration {
    FontConfiguration?: FontConfiguration | undefined;
    TextAlignment?: HorizontalTextAlignment | undefined;
    TextTransform?: TextTransform | undefined;
}
export interface VisualSubtitleFontConfiguration {
    FontConfiguration?: FontConfiguration | undefined;
    TextAlignment?: HorizontalTextAlignment | undefined;
    TextTransform?: TextTransform | undefined;
}
export interface ControlTitleFontConfiguration {
    FontConfiguration?: FontConfiguration | undefined;
    TextAlignment?: HorizontalTextAlignment | undefined;
}
export interface Typography {
    FontFamilies?: Font[] | undefined;
    AxisTitleFontConfiguration?: FontConfiguration | undefined;
    AxisLabelFontConfiguration?: FontConfiguration | undefined;
    LegendTitleFontConfiguration?: FontConfiguration | undefined;
    LegendValueFontConfiguration?: FontConfiguration | undefined;
    DataLabelFontConfiguration?: FontConfiguration | undefined;
    VisualTitleFontConfiguration?: VisualTitleFontConfiguration | undefined;
    VisualSubtitleFontConfiguration?: VisualSubtitleFontConfiguration | undefined;
    ControlTitleFontConfiguration?: ControlTitleFontConfiguration | undefined;
}
export interface ThemeConfiguration {
    DataColorPalette?: DataColorPalette | undefined;
    UIColorPalette?: UIColorPalette | undefined;
    Sheet?: SheetStyle | undefined;
    Typography?: Typography | undefined;
}
export interface CreateThemeRequest {
    AwsAccountId: string;
    ThemeId: string;
    Name: string;
    BaseThemeId: string;
    VersionDescription?: string | undefined;
    Configuration: ThemeConfiguration;
    Permissions?: ResourcePermission[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface CreateThemeResponse {
    Arn?: string | undefined;
    VersionArn?: string | undefined;
    ThemeId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface CreateThemeAliasRequest {
    AwsAccountId: string;
    ThemeId: string;
    AliasName: string;
    ThemeVersionNumber: number;
}
export interface ThemeAlias {
    Arn?: string | undefined;
    AliasName?: string | undefined;
    ThemeVersionNumber?: number | undefined;
}
export interface CreateThemeAliasResponse {
    ThemeAlias?: ThemeAlias | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type TopicUserExperienceVersion = "LEGACY" | "NEW_READER_EXPERIENCE" | (string & {});
export interface DataAggregation {
    DatasetRowDateGranularity?: TopicTimeGranularity | undefined;
    DefaultDateColumnName?: string | undefined;
}
export type DescriptionSensitiveString = string | redacted.Redacted<string>;
export type SynonymString = string | redacted.Redacted<string>;
export type Synonyms = (string | redacted.Redacted<string>)[];
export type NamedFilterType = "CATEGORY_FILTER" | "NUMERIC_EQUALITY_FILTER" | "NUMERIC_RANGE_FILTER" | "DATE_RANGE_FILTER" | "RELATIVE_DATE_FILTER" | "NULL_FILTER" | (string & {});
export type CategoryFilterFunction = "EXACT" | "CONTAINS" | (string & {});
export type CategoryFilterType = "CUSTOM_FILTER" | "CUSTOM_FILTER_LIST" | "FILTER_LIST" | (string & {});
export type StringList = string[];
export interface CollectiveConstant {
    ValueList?: string[] | undefined;
}
export interface TopicCategoryFilterConstant {
    ConstantType?: ConstantType | undefined;
    SingularConstant?: string | redacted.Redacted<string> | undefined;
    CollectiveConstant?: CollectiveConstant | undefined;
}
export type NullFilterType = "ALL_VALUES" | "NON_NULLS_ONLY" | "NULLS_ONLY" | (string & {});
export interface TopicCategoryFilter {
    CategoryFilterFunction?: CategoryFilterFunction | undefined;
    CategoryFilterType?: CategoryFilterType | undefined;
    Constant?: TopicCategoryFilterConstant | undefined;
    Inverse?: boolean | undefined;
    NullFilter?: NullFilterType | undefined;
}
export interface TopicSingularFilterConstant {
    ConstantType?: ConstantType | undefined;
    SingularConstant?: string | redacted.Redacted<string> | undefined;
}
export type NamedFilterAggType = "NO_AGGREGATION" | "SUM" | "AVERAGE" | "COUNT" | "DISTINCT_COUNT" | "MAX" | "MEDIAN" | "MIN" | "STDEV" | "STDEVP" | "VAR" | "VARP" | (string & {});
export interface TopicNumericEqualityFilter {
    Constant?: TopicSingularFilterConstant | undefined;
    Aggregation?: NamedFilterAggType | undefined;
    Inverse?: boolean | undefined;
    NullFilter?: NullFilterType | undefined;
}
export interface RangeConstant {
    Minimum?: string | redacted.Redacted<string> | undefined;
    Maximum?: string | redacted.Redacted<string> | undefined;
}
export interface TopicRangeFilterConstant {
    ConstantType?: ConstantType | undefined;
    RangeConstant?: RangeConstant | undefined;
}
export interface TopicNumericRangeFilter {
    Inclusive?: boolean | undefined;
    Constant?: TopicRangeFilterConstant | undefined;
    Aggregation?: NamedFilterAggType | undefined;
    Inverse?: boolean | undefined;
    NullFilter?: NullFilterType | undefined;
}
export interface TopicDateRangeFilter {
    Inclusive?: boolean | undefined;
    Constant?: TopicRangeFilterConstant | undefined;
    NullFilter?: NullFilterType | undefined;
}
export type TopicRelativeDateFilterFunction = "PREVIOUS" | "THIS" | "LAST" | "NEXT" | "NOW" | (string & {});
export interface TopicRelativeDateFilter {
    TimeGranularity?: TopicTimeGranularity | undefined;
    RelativeDateFilterFunction?: TopicRelativeDateFilterFunction | undefined;
    Constant?: TopicSingularFilterConstant | undefined;
    NullFilter?: NullFilterType | undefined;
}
export interface TopicNullFilter {
    NullFilterType?: NullFilterType | undefined;
    Constant?: TopicSingularFilterConstant | undefined;
    Inverse?: boolean | undefined;
}
export interface TopicFilter {
    FilterDescription?: string | redacted.Redacted<string> | undefined;
    FilterClass?: FilterClass | undefined;
    FilterName: string;
    FilterSynonyms?: (string | redacted.Redacted<string>)[] | undefined;
    OperandFieldName: string;
    FilterType?: NamedFilterType | undefined;
    CategoryFilter?: TopicCategoryFilter | undefined;
    NumericEqualityFilter?: TopicNumericEqualityFilter | undefined;
    NumericRangeFilter?: TopicNumericRangeFilter | undefined;
    DateRangeFilter?: TopicDateRangeFilter | undefined;
    RelativeDateFilter?: TopicRelativeDateFilter | undefined;
    NullFilter?: TopicNullFilter | undefined;
}
export type TopicFilters = TopicFilter[];
export type ColumnDataRole = "DIMENSION" | "MEASURE" | (string & {});
export type DefaultAggregation = "SUM" | "MAX" | "MIN" | "COUNT" | "DISTINCT_COUNT" | "AVERAGE" | "MEDIAN" | "STDEV" | "STDEVP" | "VAR" | "VARP" | (string & {});
export type ColumnOrderingType = "GREATER_IS_BETTER" | "LESSER_IS_BETTER" | "SPECIFIED" | (string & {});
export type UndefinedSpecifiedValueType = "LEAST" | "MOST" | (string & {});
export interface ComparativeOrder {
    UseOrdering?: ColumnOrderingType | undefined;
    SpecifedOrder?: string[] | undefined;
    TreatUndefinedSpecifiedValues?: UndefinedSpecifiedValueType | undefined;
}
export type TypeParameters = {
    [key: string]: string | undefined;
};
export interface SemanticType {
    TypeName?: string | undefined;
    SubTypeName?: string | undefined;
    TypeParameters?: {
        [key: string]: string | undefined;
    } | undefined;
    TruthyCellValue?: string | redacted.Redacted<string> | undefined;
    TruthyCellValueSynonyms?: (string | redacted.Redacted<string>)[] | undefined;
    FalseyCellValue?: string | redacted.Redacted<string> | undefined;
    FalseyCellValueSynonyms?: (string | redacted.Redacted<string>)[] | undefined;
}
export type AuthorSpecifiedAggregation = "COUNT" | "DISTINCT_COUNT" | "MIN" | "MAX" | "MEDIAN" | "SUM" | "AVERAGE" | "STDEV" | "STDEVP" | "VAR" | "VARP" | "PERCENTILE" | (string & {});
export type AuthorSpecifiedAggregations = AuthorSpecifiedAggregation[];
export interface DefaultFormatting {
    DisplayFormat?: DisplayFormat | undefined;
    DisplayFormatOptions?: DisplayFormatOptions | undefined;
}
export interface CellValueSynonym {
    CellValue?: string | redacted.Redacted<string> | undefined;
    Synonyms?: (string | redacted.Redacted<string>)[] | undefined;
}
export type CellValueSynonyms = CellValueSynonym[];
export interface TopicColumn {
    ColumnName: string;
    ColumnFriendlyName?: string | redacted.Redacted<string> | undefined;
    ColumnDescription?: string | redacted.Redacted<string> | undefined;
    ColumnSynonyms?: (string | redacted.Redacted<string>)[] | undefined;
    ColumnDataRole?: ColumnDataRole | undefined;
    Aggregation?: DefaultAggregation | undefined;
    IsIncludedInTopic?: boolean | undefined;
    DisableIndexing?: boolean | undefined;
    ComparativeOrder?: ComparativeOrder | undefined;
    SemanticType?: SemanticType | undefined;
    TimeGranularity?: TopicTimeGranularity | undefined;
    AllowedAggregations?: AuthorSpecifiedAggregation[] | undefined;
    NotAllowedAggregations?: AuthorSpecifiedAggregation[] | undefined;
    DefaultFormatting?: DefaultFormatting | undefined;
    NeverAggregateInFilter?: boolean | undefined;
    CellValueSynonyms?: CellValueSynonym[] | undefined;
    NonAdditive?: boolean | undefined;
}
export type TopicColumns = TopicColumn[];
export interface TopicCalculatedField {
    CalculatedFieldName: string | redacted.Redacted<string>;
    CalculatedFieldDescription?: string | redacted.Redacted<string> | undefined;
    Expression: string | redacted.Redacted<string>;
    CalculatedFieldSynonyms?: (string | redacted.Redacted<string>)[] | undefined;
    IsIncludedInTopic?: boolean | undefined;
    DisableIndexing?: boolean | undefined;
    ColumnDataRole?: ColumnDataRole | undefined;
    TimeGranularity?: TopicTimeGranularity | undefined;
    DefaultFormatting?: DefaultFormatting | undefined;
    Aggregation?: DefaultAggregation | undefined;
    ComparativeOrder?: ComparativeOrder | undefined;
    SemanticType?: SemanticType | undefined;
    AllowedAggregations?: AuthorSpecifiedAggregation[] | undefined;
    NotAllowedAggregations?: AuthorSpecifiedAggregation[] | undefined;
    NeverAggregateInFilter?: boolean | undefined;
    CellValueSynonyms?: CellValueSynonym[] | undefined;
    NonAdditive?: boolean | undefined;
}
export type TopicCalculatedFields = TopicCalculatedField[];
export interface SemanticEntityType {
    TypeName?: string | undefined;
    SubTypeName?: string | undefined;
    TypeParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type PropertyRole = "PRIMARY" | "ID" | (string & {});
export type PropertyUsage = "INHERIT" | "DIMENSION" | "MEASURE" | (string & {});
export type NamedEntityAggType = "SUM" | "MIN" | "MAX" | "COUNT" | "AVERAGE" | "DISTINCT_COUNT" | "STDEV" | "STDEVP" | "VAR" | "VARP" | "PERCENTILE" | "MEDIAN" | "CUSTOM" | (string & {});
export type AggregationFunctionParameters = {
    [key: string]: string | undefined;
};
export interface NamedEntityDefinitionMetric {
    Aggregation?: NamedEntityAggType | undefined;
    AggregationFunctionParameters?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface NamedEntityDefinition {
    FieldName?: string | undefined;
    PropertyName?: string | undefined;
    PropertyRole?: PropertyRole | undefined;
    PropertyUsage?: PropertyUsage | undefined;
    Metric?: NamedEntityDefinitionMetric | undefined;
    RankOrder?: number | undefined;
    PresentationOrder?: number | undefined;
    IsHidden?: boolean | undefined;
}
export type NamedEntityDefinitions = NamedEntityDefinition[];
export interface NamedEntitySort {
    FieldName: string;
    Direction: TopicSortDirection;
}
export type NamedEntitySortList = NamedEntitySort[];
export interface TopicNamedEntity {
    EntityName: string;
    EntityDescription?: string | redacted.Redacted<string> | undefined;
    EntitySynonyms?: (string | redacted.Redacted<string>)[] | undefined;
    SemanticEntityType?: SemanticEntityType | undefined;
    Definition?: NamedEntityDefinition[] | undefined;
    Sort?: NamedEntitySort[] | undefined;
    RankOrder?: number | undefined;
    PresentationOrder?: number | undefined;
}
export type TopicNamedEntities = TopicNamedEntity[];
export interface DatasetMetadata {
    DatasetArn: string;
    DatasetName?: string | undefined;
    DatasetDescription?: string | undefined;
    DataAggregation?: DataAggregation | undefined;
    Filters?: TopicFilter[] | undefined;
    Columns?: TopicColumn[] | undefined;
    CalculatedFields?: TopicCalculatedField[] | undefined;
    NamedEntities?: TopicNamedEntity[] | undefined;
}
export type Datasets = DatasetMetadata[];
export interface TopicConfigOptions {
    QBusinessInsightsEnabled?: boolean | undefined;
}
export interface TopicDetails {
    Name?: string | undefined;
    Description?: string | undefined;
    UserExperienceVersion?: TopicUserExperienceVersion | undefined;
    DataSets?: DatasetMetadata[] | undefined;
    ConfigOptions?: TopicConfigOptions | undefined;
}
export type CustomInstructionsString = string | redacted.Redacted<string>;
export interface CustomInstructions {
    CustomInstructionsString: string | redacted.Redacted<string>;
}
export interface CreateTopicRequest {
    AwsAccountId: string;
    TopicId: string;
    Topic: TopicDetails;
    Tags?: Tag[] | undefined;
    FolderArns?: string[] | undefined;
    CustomInstructions?: CustomInstructions | undefined;
}
export interface CreateTopicResponse {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    RefreshArn?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type TopicScheduleType = "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | (string & {});
export interface TopicRefreshSchedule {
    IsEnabled: boolean;
    BasedOnSpiceSchedule: boolean;
    StartingAt?: Date | undefined;
    Timezone?: string | undefined;
    RepeatAt?: string | undefined;
    TopicScheduleType?: TopicScheduleType | undefined;
}
export interface CreateTopicRefreshScheduleRequest {
    AwsAccountId: string;
    TopicId: string;
    DatasetArn: string;
    DatasetName?: string | undefined;
    RefreshSchedule: TopicRefreshSchedule;
}
export interface CreateTopicRefreshScheduleResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface TopicV2DataSetReference {
    DataSetArn: string;
    DataSetName?: string | undefined;
}
export type TopicV2DataSetReferences = TopicV2DataSetReference[];
export type TopicV2DataSetRelationColumnNames = string[];
export interface TopicV2DataSetRelationEndpoint {
    DataSetArn: string;
    ColumnNames: string[];
}
export interface TopicV2DataSetRelation {
    Left: TopicV2DataSetRelationEndpoint;
    Right: TopicV2DataSetRelationEndpoint;
}
export type TopicV2DataSetRelationList = TopicV2DataSetRelation[];
export interface TopicV2Details {
    Name: string;
    Description?: string | undefined;
    DataSets?: TopicV2DataSetReference[] | undefined;
    DataSetRelations?: TopicV2DataSetRelation[] | undefined;
}
export interface CreateTopicV2Request {
    AwsAccountId: string;
    TopicId: string;
    Topic: TopicV2Details;
    Tags?: Tag[] | undefined;
    FolderArns?: string[] | undefined;
    CustomInstructions?: CustomInstructions | undefined;
}
export interface CreateTopicV2Response {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type VPCConnectionResourceIdRestricted = string;
export type SubnetId = string;
export type SubnetIdList = string[];
export type SecurityGroupId = string;
export type SecurityGroupIdList = string[];
export type IPv4Address = string;
export type DnsResolverList = string[];
export interface CreateVPCConnectionRequest {
    AwsAccountId: string;
    VPCConnectionId: string;
    Name: string;
    SubnetIds: string[];
    SecurityGroupIds: string[];
    DnsResolvers?: string[] | undefined;
    RoleArn: string;
    Tags?: Tag[] | undefined;
}
export type VPCConnectionResourceStatus = "CREATION_IN_PROGRESS" | "CREATION_SUCCESSFUL" | "CREATION_FAILED" | "UPDATE_IN_PROGRESS" | "UPDATE_SUCCESSFUL" | "UPDATE_FAILED" | "DELETION_IN_PROGRESS" | "DELETION_FAILED" | "DELETED" | (string & {});
export type VPCConnectionAvailabilityStatus = "AVAILABLE" | "UNAVAILABLE" | "PARTIALLY_AVAILABLE" | (string & {});
export interface CreateVPCConnectionResponse {
    Arn?: string | undefined;
    VPCConnectionId?: string | undefined;
    CreationStatus?: VPCConnectionResourceStatus | undefined;
    AvailabilityStatus?: VPCConnectionAvailabilityStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteAccountCustomizationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
}
export interface DeleteAccountCustomizationResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteAccountCustomPermissionRequest {
    AwsAccountId: string;
}
export interface DeleteAccountCustomPermissionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteAccountSubscriptionRequest {
    AwsAccountId: string;
}
export interface DeleteAccountSubscriptionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteActionConnectorRequest {
    AwsAccountId: string;
    ActionConnectorId: string;
}
export interface DeleteActionConnectorResponse {
    Arn?: string | undefined;
    ActionConnectorId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteAgentRequest {
    AgentId: string;
    AwsAccountId: string;
}
export interface DeleteAgentResponse {
    RequestId?: string | undefined;
}
export type RecoveryWindowInDays = number;
export interface DeleteAnalysisRequest {
    AwsAccountId: string;
    AnalysisId: string;
    RecoveryWindowInDays?: number | undefined;
    ForceDeleteWithoutRecovery?: boolean | undefined;
}
export interface DeleteAnalysisResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    AnalysisId?: string | undefined;
    DeletionTime?: Date | undefined;
    RequestId?: string | undefined;
}
export type AppId = string;
export interface DeleteAppRequest {
    AwsAccountId: string;
    AppId: string;
}
export interface DeleteAppResponse {
    RequestId?: string | undefined;
}
export interface DeleteApprovalPolicyRequest {
    PolicyId: string;
}
export interface DeleteApprovalPolicyResponse {
}
export interface DeleteBrandRequest {
    AwsAccountId: string;
    BrandId: string;
}
export interface DeleteBrandResponse {
    RequestId?: string | undefined;
}
export interface DeleteBrandAssignmentRequest {
    AwsAccountId: string;
}
export interface DeleteBrandAssignmentResponse {
    RequestId?: string | undefined;
}
export interface DeleteCustomPermissionsRequest {
    AwsAccountId: string;
    CustomPermissionsName: string;
}
export interface DeleteCustomPermissionsResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    RequestId?: string | undefined;
}
export interface DeleteDashboardRequest {
    AwsAccountId: string;
    DashboardId: string;
    VersionNumber?: number | undefined;
}
export interface DeleteDashboardResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    DashboardId?: string | undefined;
    RequestId?: string | undefined;
}
export interface DeleteDataSetRequest {
    AwsAccountId: string;
    DataSetId: string;
}
export interface DeleteDataSetResponse {
    Arn?: string | undefined;
    DataSetId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteDataSetRefreshPropertiesRequest {
    AwsAccountId: string;
    DataSetId: string;
}
export interface DeleteDataSetRefreshPropertiesResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteDataSourceRequest {
    AwsAccountId: string;
    DataSourceId: string;
}
export interface DeleteDataSourceResponse {
    Arn?: string | undefined;
    DataSourceId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteDefaultQBusinessApplicationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
}
export interface DeleteDefaultQBusinessApplicationResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteDlpSettingRequest {
    AwsAccountId: string;
    DlpSettingId: string;
}
export interface DeleteDlpSettingResponse {
    Arn: string;
    DlpSettingId: string;
    RequestId?: string | undefined;
}
export interface DeleteFlowRequest {
    AwsAccountId: string;
    FlowId: string;
}
export interface DeleteFlowResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteFolderRequest {
    AwsAccountId: string;
    FolderId: string;
}
export interface DeleteFolderResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    FolderId?: string | undefined;
    RequestId?: string | undefined;
}
export interface DeleteFolderMembershipRequest {
    AwsAccountId: string;
    FolderId: string;
    MemberId: string;
    MemberType: MemberType;
}
export interface DeleteFolderMembershipResponse {
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DeleteGroupRequest {
    GroupName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteGroupResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteGroupMembershipRequest {
    MemberName: string;
    GroupName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteGroupMembershipResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteIAMPolicyAssignmentRequest {
    AwsAccountId: string;
    AssignmentName: string;
    Namespace: string;
}
export interface DeleteIAMPolicyAssignmentResponse {
    AssignmentName?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type ServiceType = "REDSHIFT" | "QBUSINESS" | "ATHENA" | "GLUE_DATA_CATALOG" | (string & {});
export interface DeleteIdentityPropagationConfigRequest {
    AwsAccountId: string;
    Service: ServiceType;
}
export interface DeleteIdentityPropagationConfigResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteKnowledgeBaseRequest {
    AwsAccountId: string;
    KnowledgeBaseId: string;
}
export interface DeleteKnowledgeBaseResponse {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteLimitsProfileRequest {
    profileId: string;
    accountId: string;
}
export interface DeleteLimitsProfileResponse {
    arn: string;
}
export interface DeleteNamespaceRequest {
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteNamespaceResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteOAuthClientApplicationRequest {
    AwsAccountId: string;
    OAuthClientApplicationId: string;
}
export interface DeleteOAuthClientApplicationResponse {
    Arn?: string | undefined;
    OAuthClientApplicationId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteRefreshScheduleRequest {
    DataSetId: string;
    AwsAccountId: string;
    ScheduleId: string;
}
export interface DeleteRefreshScheduleResponse {
    Status?: number | undefined;
    RequestId?: string | undefined;
    ScheduleId?: string | undefined;
    Arn?: string | undefined;
}
export interface DeleteRoleCustomPermissionRequest {
    Role: Role;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteRoleCustomPermissionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteRoleMembershipRequest {
    MemberName: string;
    Role: Role;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteRoleMembershipResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteSpaceRequest {
    AwsAccountId: string;
    SpaceId: string;
}
export interface DeleteSpaceResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    RequestId?: string | undefined;
}
export interface DeleteTemplateRequest {
    AwsAccountId: string;
    TemplateId: string;
    VersionNumber?: number | undefined;
}
export interface DeleteTemplateResponse {
    RequestId?: string | undefined;
    Arn?: string | undefined;
    TemplateId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteTemplateAliasRequest {
    AwsAccountId: string;
    TemplateId: string;
    AliasName: string;
}
export interface DeleteTemplateAliasResponse {
    Status?: number | undefined;
    TemplateId?: string | undefined;
    AliasName?: string | undefined;
    Arn?: string | undefined;
    RequestId?: string | undefined;
}
export interface DeleteThemeRequest {
    AwsAccountId: string;
    ThemeId: string;
    VersionNumber?: number | undefined;
}
export interface DeleteThemeResponse {
    Arn?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    ThemeId?: string | undefined;
}
export interface DeleteThemeAliasRequest {
    AwsAccountId: string;
    ThemeId: string;
    AliasName: string;
}
export interface DeleteThemeAliasResponse {
    AliasName?: string | undefined;
    Arn?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    ThemeId?: string | undefined;
}
export interface DeleteTopicRequest {
    AwsAccountId: string;
    TopicId: string;
}
export interface DeleteTopicResponse {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteTopicRefreshScheduleRequest {
    AwsAccountId: string;
    TopicId: string;
    DatasetId: string;
}
export interface DeleteTopicRefreshScheduleResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DeleteTopicV2Request {
    AwsAccountId: string;
    TopicId: string;
}
export interface DeleteTopicV2Response {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type UserName = string;
export interface DeleteUserRequest {
    UserName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteUserResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteUserByPrincipalIdRequest {
    PrincipalId: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteUserByPrincipalIdResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DeleteUserCustomPermissionRequest {
    UserName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DeleteUserCustomPermissionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type VPCConnectionResourceIdUnrestricted = string;
export interface DeleteVPCConnectionRequest {
    AwsAccountId: string;
    VPCConnectionId: string;
}
export interface DeleteVPCConnectionResponse {
    Arn?: string | undefined;
    VPCConnectionId?: string | undefined;
    DeletionStatus?: VPCConnectionResourceStatus | undefined;
    AvailabilityStatus?: VPCConnectionAvailabilityStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeAccountCustomizationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
    Resolved?: boolean | undefined;
}
export interface DescribeAccountCustomizationResponse {
    Arn?: string | undefined;
    AwsAccountId?: string | undefined;
    Namespace?: string | undefined;
    AccountCustomization?: AccountCustomization | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeAccountCustomPermissionRequest {
    AwsAccountId: string;
}
export interface DescribeAccountCustomPermissionResponse {
    CustomPermissionsName?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeAccountSettingsRequest {
    AwsAccountId: string;
}
export interface AccountSettings {
    AccountName?: string | undefined;
    Edition?: Edition | undefined;
    DefaultNamespace?: string | undefined;
    NotificationEmail?: string | undefined;
    PublicSharingEnabled?: boolean | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
}
export interface DescribeAccountSettingsResponse {
    AccountSettings?: AccountSettings | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeAccountSubscriptionRequest {
    AwsAccountId: string;
}
export interface AccountInfo {
    AccountName?: string | undefined;
    Edition?: Edition | undefined;
    NotificationEmail?: string | undefined;
    AuthenticationType?: string | undefined;
    AccountSubscriptionStatus?: string | undefined;
    IAMIdentityCenterInstanceArn?: string | undefined;
}
export interface DescribeAccountSubscriptionResponse {
    AccountInfo?: AccountInfo | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeActionConnectorRequest {
    AwsAccountId: string;
    ActionConnectorId: string;
}
export type ActionConnectorErrorType = "INTERNAL_FAILURE" | (string & {});
export interface ActionConnectorError {
    Message?: string | undefined;
    Type?: ActionConnectorErrorType | undefined;
}
export interface ReadAuthorizationCodeGrantDetails {
    ClientId: string;
    TokenEndpoint: string;
    AuthorizationEndpoint: string;
}
export type ReadAuthorizationCodeGrantCredentialsDetails = {
    ReadAuthorizationCodeGrantDetails: ReadAuthorizationCodeGrantDetails;
};
export interface ReadAuthorizationCodeGrantMetadata {
    BaseEndpoint: string;
    RedirectUrl: string;
    ReadAuthorizationCodeGrantCredentialsDetails?: ReadAuthorizationCodeGrantCredentialsDetails | undefined;
    AuthorizationCodeGrantCredentialsSource?: AuthorizationCodeGrantCredentialsSource | undefined;
}
export interface ReadClientCredentialsGrantDetails {
    ClientId: string;
    TokenEndpoint: string;
}
export type ReadClientCredentialsDetails = {
    ReadClientCredentialsGrantDetails: ReadClientCredentialsGrantDetails;
};
export interface ReadClientCredentialsGrantMetadata {
    BaseEndpoint: string;
    ReadClientCredentialsDetails?: ReadClientCredentialsDetails | undefined;
    ClientCredentialsSource?: ClientCredentialsSource | undefined;
}
export interface ReadBasicAuthConnectionMetadata {
    BaseEndpoint: string;
    Username: string | redacted.Redacted<string>;
}
export interface ReadAPIKeyConnectionMetadata {
    BaseEndpoint: string;
    Email?: string | redacted.Redacted<string> | undefined;
}
export interface ReadNoneConnectionMetadata {
    BaseEndpoint: string;
}
export interface ReadIamConnectionMetadata {
    RoleArn: string;
    SourceArn: string;
}
export type ReadAuthenticationMetadata = {
    AuthorizationCodeGrantMetadata: ReadAuthorizationCodeGrantMetadata;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata: ReadClientCredentialsGrantMetadata;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata: ReadBasicAuthConnectionMetadata;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata: ReadAPIKeyConnectionMetadata;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata: ReadNoneConnectionMetadata;
    IamConnectionMetadata?: undefined;
} | {
    AuthorizationCodeGrantMetadata?: undefined;
    ClientCredentialsGrantMetadata?: undefined;
    BasicAuthConnectionMetadata?: undefined;
    ApiKeyConnectionMetadata?: undefined;
    NoneConnectionMetadata?: undefined;
    IamConnectionMetadata: ReadIamConnectionMetadata;
};
export interface ReadAuthConfig {
    AuthenticationType: ConnectionAuthType;
    AuthenticationMetadata: ReadAuthenticationMetadata;
}
export type ActionId = string;
export type ActionIdList = string[];
export interface ActionConnector {
    Arn: string;
    ActionConnectorId: string;
    Type: ActionConnectorType;
    Name: string | redacted.Redacted<string>;
    CreatedTime?: Date | undefined;
    LastUpdatedTime: Date;
    Status?: ResourceStatus | undefined;
    Error?: ActionConnectorError | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    AuthenticationConfig?: ReadAuthConfig | undefined;
    EnabledActions?: string[] | undefined;
    VpcConnectionArn?: string | undefined;
}
export interface DescribeActionConnectorResponse {
    ActionConnector?: ActionConnector | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeActionConnectorPermissionsRequest {
    AwsAccountId: string;
    ActionConnectorId: string;
}
export interface DescribeActionConnectorPermissionsResponse {
    Arn?: string | undefined;
    ActionConnectorId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeAgentRequest {
    AgentId: string;
    AwsAccountId: string;
}
export type AgentSpacesList = string[];
export type AgentActionConnectorsList = string[];
export type SensitiveText = string | redacted.Redacted<string>;
export interface CustomPromptInterface {
    ModelProfileId: string;
    SubscriptionId: string;
    QbsAwsAccountId: string;
    ResponseLength?: string | redacted.Redacted<string> | undefined;
    OutputStyle?: string | redacted.Redacted<string> | undefined;
    Identity?: string | redacted.Redacted<string> | undefined;
    Tone?: string | redacted.Redacted<string> | undefined;
    CustomInstructions?: string | redacted.Redacted<string> | undefined;
    promptSummary?: string | redacted.Redacted<string> | undefined;
}
export interface Agent {
    Spaces?: string[] | undefined;
    ActionConnectors?: string[] | undefined;
    Description?: string | undefined;
    IconId?: string | undefined;
    Name: string;
    StarterPrompts?: string[] | undefined;
    WelcomeMessage?: string | redacted.Redacted<string> | undefined;
    Arn: string;
    AgentId: string;
    AgentLifecycle: AgentLifecycle;
    AgentStatus: AgentStatus;
    CreatedAt: Date;
    Creator: string;
    CustomPromptInterface?: CustomPromptInterface | undefined;
    ErrorMessage?: string | undefined;
    UpdatedAt: Date;
}
export interface DescribeAgentResponse {
    Agent: Agent;
    RequestId?: string | undefined;
}
export interface DescribeAgentPermissionsRequest {
    AgentId: string;
    AwsAccountId: string;
}
export interface DescribeAgentPermissionsResponse {
    Arn: string;
    AgentId: string;
    Permissions: ResourcePermission[];
    RequestId: string;
}
export interface DescribeAnalysisRequest {
    AwsAccountId: string;
    AnalysisId: string;
}
export type AnalysisErrorType = "ACCESS_DENIED" | "SOURCE_NOT_FOUND" | "DATA_SET_NOT_FOUND" | "INTERNAL_FAILURE" | "PARAMETER_VALUE_INCOMPATIBLE" | "PARAMETER_TYPE_INVALID" | "PARAMETER_NOT_FOUND" | "COLUMN_TYPE_MISMATCH" | "COLUMN_GEOGRAPHIC_ROLE_MISMATCH" | "COLUMN_REPLACEMENT_MISSING" | (string & {});
export interface Entity {
    Path?: string | undefined;
}
export type EntityList = Entity[];
export interface AnalysisError {
    Type?: AnalysisErrorType | undefined;
    Message?: string | undefined;
    ViolatedEntities?: Entity[] | undefined;
}
export type AnalysisErrorList = AnalysisError[];
export type TopicArnsList = string[];
export interface Sheet {
    SheetId?: string | undefined;
    Name?: string | undefined;
    Images?: SheetImage[] | undefined;
}
export type SheetList = Sheet[];
export interface Analysis {
    AnalysisId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    Status?: ResourceStatus | undefined;
    Errors?: AnalysisError[] | undefined;
    DataSetArns?: string[] | undefined;
    TopicArns?: string[] | undefined;
    ThemeArn?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Sheets?: Sheet[] | undefined;
}
export interface DescribeAnalysisResponse {
    Analysis?: Analysis | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeAnalysisDefinitionRequest {
    AwsAccountId: string;
    AnalysisId: string;
}
export interface DescribeAnalysisDefinitionResponse {
    AnalysisId?: string | undefined;
    Name?: string | undefined;
    Errors?: AnalysisError[] | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ThemeArn?: string | undefined;
    Definition?: AnalysisDefinition | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeAnalysisPermissionsRequest {
    AwsAccountId: string;
    AnalysisId: string;
}
export type UpdateResourcePermissionList = ResourcePermission[];
export interface DescribeAnalysisPermissionsResponse {
    AnalysisId?: string | undefined;
    AnalysisArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeAppRequest {
    AwsAccountId: string;
    AppId: string;
}
export type AppName = string;
export type AppVisibility = "PRIVATE" | "PUBLIC" | (string & {});
export interface AppSummary {
    AppId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Visibility?: AppVisibility | undefined;
}
export interface DescribeAppResponse {
    App: AppSummary;
    RequestId?: string | undefined;
}
export interface DescribeAppPermissionsRequest {
    AwsAccountId: string;
    AppId: string;
}
export interface DescribeAppPermissionsResponse {
    AppId?: string | undefined;
    Arn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
}
export interface DescribeApprovalPolicyRequest {
    PolicyId: string;
}
export interface DescribeApprovalPolicyResponse {
    Policy: ApprovalPolicy;
}
export interface DescribeAssetBundleExportJobRequest {
    AwsAccountId: string;
    AssetBundleExportJobId: string;
}
export type AssetBundleExportJobStatus = "QUEUED_FOR_IMMEDIATE_EXECUTION" | "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | (string & {});
export type SensitiveS3Uri = string | redacted.Redacted<string>;
export interface AssetBundleExportJobError {
    Arn?: string | undefined;
    Type?: string | undefined;
    Message?: string | undefined;
}
export type AssetBundleExportJobErrorList = AssetBundleExportJobError[];
export type AssetBundleResourceArns = string[];
export type AssetBundleExportFormat = "CLOUDFORMATION_JSON" | "QUICKSIGHT_JSON" | (string & {});
export interface AssetBundleExportJobResourceIdOverrideConfiguration {
    PrefixForAllResources?: boolean | undefined;
}
export type AssetBundleExportJobVPCConnectionPropertyToOverride = "Name" | "DnsResolvers" | "RoleArn" | (string & {});
export type AssetBundleExportJobVPCConnectionPropertyToOverrideList = AssetBundleExportJobVPCConnectionPropertyToOverride[];
export interface AssetBundleExportJobVPCConnectionOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobVPCConnectionPropertyToOverride[];
}
export type AssetBundleExportJobVPCConnectionOverridePropertiesList = AssetBundleExportJobVPCConnectionOverrideProperties[];
export type AssetBundleExportJobRefreshSchedulePropertyToOverride = "StartAfterDateTime" | (string & {});
export type AssetBundleExportJobRefreshSchedulePropertyToOverrideList = AssetBundleExportJobRefreshSchedulePropertyToOverride[];
export interface AssetBundleExportJobRefreshScheduleOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobRefreshSchedulePropertyToOverride[];
}
export type AssetBundleExportJobRefreshScheduleOverridePropertiesList = AssetBundleExportJobRefreshScheduleOverrideProperties[];
export type AssetBundleExportJobDataSourcePropertyToOverride = "Name" | "DisableSsl" | "SecretArn" | "Username" | "Password" | "Domain" | "WorkGroup" | "Host" | "Port" | "Database" | "DataSetName" | "Catalog" | "InstanceId" | "ClusterId" | "ManifestFileLocation" | "Warehouse" | "RoleArn" | "ProductType" | (string & {});
export type AssetBundleExportJobDataSourcePropertyToOverrideList = AssetBundleExportJobDataSourcePropertyToOverride[];
export interface AssetBundleExportJobDataSourceOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobDataSourcePropertyToOverride[];
}
export type AssetBundleExportJobDataSourceOverridePropertiesList = AssetBundleExportJobDataSourceOverrideProperties[];
export type AssetBundleExportJobDataSetPropertyToOverride = "Name" | "RefreshFailureEmailAlertStatus" | (string & {});
export type AssetBundleExportJobDataSetPropertyToOverrideList = AssetBundleExportJobDataSetPropertyToOverride[];
export interface AssetBundleExportJobDataSetOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobDataSetPropertyToOverride[];
}
export type AssetBundleExportJobDataSetOverridePropertiesList = AssetBundleExportJobDataSetOverrideProperties[];
export type AssetBundleExportJobThemePropertyToOverride = "Name" | (string & {});
export type AssetBundleExportJobThemePropertyToOverrideList = AssetBundleExportJobThemePropertyToOverride[];
export interface AssetBundleExportJobThemeOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobThemePropertyToOverride[];
}
export type AssetBundleExportJobThemeOverridePropertiesList = AssetBundleExportJobThemeOverrideProperties[];
export type AssetBundleExportJobAnalysisPropertyToOverride = "Name" | (string & {});
export type AssetBundleExportJobAnalysisPropertyToOverrideList = AssetBundleExportJobAnalysisPropertyToOverride[];
export interface AssetBundleExportJobAnalysisOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobAnalysisPropertyToOverride[];
}
export type AssetBundleExportJobAnalysisOverridePropertiesList = AssetBundleExportJobAnalysisOverrideProperties[];
export type AssetBundleExportJobDashboardPropertyToOverride = "Name" | (string & {});
export type AssetBundleExportJobDashboardPropertyToOverrideList = AssetBundleExportJobDashboardPropertyToOverride[];
export interface AssetBundleExportJobDashboardOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobDashboardPropertyToOverride[];
}
export type AssetBundleExportJobDashboardOverridePropertiesList = AssetBundleExportJobDashboardOverrideProperties[];
export type AssetBundleExportJobFolderPropertyToOverride = "Name" | "ParentFolderArn" | (string & {});
export type AssetBundleExportJobFolderPropertyToOverrideList = AssetBundleExportJobFolderPropertyToOverride[];
export interface AssetBundleExportJobFolderOverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobFolderPropertyToOverride[];
}
export type AssetBundleExportJobFolderOverridePropertiesList = AssetBundleExportJobFolderOverrideProperties[];
export type AssetBundleExportJobTopicV2PropertyToOverride = "Name" | "Description" | (string & {});
export type AssetBundleExportJobTopicV2PropertyToOverrideList = AssetBundleExportJobTopicV2PropertyToOverride[];
export interface AssetBundleExportJobTopicV2OverrideProperties {
    Arn: string;
    Properties: AssetBundleExportJobTopicV2PropertyToOverride[];
}
export type AssetBundleExportJobTopicV2OverridePropertiesList = AssetBundleExportJobTopicV2OverrideProperties[];
export interface AssetBundleCloudFormationOverridePropertyConfiguration {
    ResourceIdOverrideConfiguration?: AssetBundleExportJobResourceIdOverrideConfiguration | undefined;
    VPCConnections?: AssetBundleExportJobVPCConnectionOverrideProperties[] | undefined;
    RefreshSchedules?: AssetBundleExportJobRefreshScheduleOverrideProperties[] | undefined;
    DataSources?: AssetBundleExportJobDataSourceOverrideProperties[] | undefined;
    DataSets?: AssetBundleExportJobDataSetOverrideProperties[] | undefined;
    Themes?: AssetBundleExportJobThemeOverrideProperties[] | undefined;
    Analyses?: AssetBundleExportJobAnalysisOverrideProperties[] | undefined;
    Dashboards?: AssetBundleExportJobDashboardOverrideProperties[] | undefined;
    Folders?: AssetBundleExportJobFolderOverrideProperties[] | undefined;
    TopicsV2?: AssetBundleExportJobTopicV2OverrideProperties[] | undefined;
}
export interface AssetBundleExportJobValidationStrategy {
    StrictModeForAllResources?: boolean | undefined;
}
export interface AssetBundleExportJobWarning {
    Arn?: string | undefined;
    Message?: string | undefined;
}
export type AssetBundleExportJobWarningList = AssetBundleExportJobWarning[];
export type IncludeFolderMembers = "RECURSE" | "ONE_LEVEL" | "NONE" | (string & {});
export interface DescribeAssetBundleExportJobResponse {
    JobStatus?: AssetBundleExportJobStatus | undefined;
    DownloadUrl?: string | redacted.Redacted<string> | undefined;
    Errors?: AssetBundleExportJobError[] | undefined;
    Arn?: string | undefined;
    CreatedTime?: Date | undefined;
    AssetBundleExportJobId?: string | undefined;
    AwsAccountId?: string | undefined;
    ResourceArns?: string[] | undefined;
    IncludeAllDependencies?: boolean | undefined;
    ExportFormat?: AssetBundleExportFormat | undefined;
    CloudFormationOverridePropertyConfiguration?: AssetBundleCloudFormationOverridePropertyConfiguration | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    IncludePermissions?: boolean | undefined;
    IncludeTags?: boolean | undefined;
    ValidationStrategy?: AssetBundleExportJobValidationStrategy | undefined;
    Warnings?: AssetBundleExportJobWarning[] | undefined;
    IncludeFolderMemberships?: boolean | undefined;
    IncludeFolderMembers?: IncludeFolderMembers | undefined;
}
export interface DescribeAssetBundleImportJobRequest {
    AwsAccountId: string;
    AssetBundleImportJobId: string;
}
export type AssetBundleImportJobStatus = "QUEUED_FOR_IMMEDIATE_EXECUTION" | "IN_PROGRESS" | "SUCCESSFUL" | "FAILED" | "FAILED_ROLLBACK_IN_PROGRESS" | "FAILED_ROLLBACK_COMPLETED" | "FAILED_ROLLBACK_ERROR" | (string & {});
export interface AssetBundleImportJobError {
    Arn?: string | undefined;
    Type?: string | undefined;
    Message?: string | undefined;
}
export type AssetBundleImportJobErrorList = AssetBundleImportJobError[];
export type S3Uri = string;
export interface AssetBundleImportSourceDescription {
    Body?: string | redacted.Redacted<string> | undefined;
    S3Uri?: string | undefined;
}
export interface AssetBundleImportJobResourceIdOverrideConfiguration {
    PrefixForAllResources?: string | undefined;
}
export interface AssetBundleImportJobVPCConnectionOverrideParameters {
    VPCConnectionId: string;
    Name?: string | undefined;
    SubnetIds?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    DnsResolvers?: string[] | undefined;
    RoleArn?: string | undefined;
}
export type AssetBundleImportJobVPCConnectionOverrideParametersList = AssetBundleImportJobVPCConnectionOverrideParameters[];
export interface AssetBundleImportJobRefreshScheduleOverrideParameters {
    DataSetId: string;
    ScheduleId: string;
    StartAfterDateTime?: Date | undefined;
}
export type AssetBundleImportJobRefreshScheduleOverrideParametersList = AssetBundleImportJobRefreshScheduleOverrideParameters[];
export interface AssetBundleImportJobDataSourceCredentialPair {
    Username: string;
    Password: string | redacted.Redacted<string>;
}
export interface AssetBundleImportJobDataSourceCredentials {
    CredentialPair?: AssetBundleImportJobDataSourceCredentialPair | undefined;
    SecretArn?: string | undefined;
}
export interface AssetBundleImportJobDataSourceOverrideParameters {
    DataSourceId: string;
    Name?: string | undefined;
    DataSourceParameters?: DataSourceParameters | undefined;
    VpcConnectionProperties?: VpcConnectionProperties | undefined;
    SslProperties?: SslProperties | undefined;
    Credentials?: AssetBundleImportJobDataSourceCredentials | undefined;
}
export type AssetBundleImportJobDataSourceOverrideParametersList = AssetBundleImportJobDataSourceOverrideParameters[];
export type PositiveLong = number;
export type LookbackWindowSizeUnit = "HOUR" | "DAY" | "WEEK" | (string & {});
export interface LookbackWindow {
    ColumnName: string;
    Size: number;
    SizeUnit: LookbackWindowSizeUnit;
}
export interface IncrementalRefresh {
    LookbackWindow: LookbackWindow;
}
export interface RefreshConfiguration {
    IncrementalRefresh: IncrementalRefresh;
}
export type RefreshFailureAlertStatus = "ENABLED" | "DISABLED" | (string & {});
export interface RefreshFailureEmailAlert {
    AlertStatus?: RefreshFailureAlertStatus | undefined;
}
export interface RefreshFailureConfiguration {
    EmailAlert?: RefreshFailureEmailAlert | undefined;
}
export interface DataSetRefreshProperties {
    RefreshConfiguration?: RefreshConfiguration | undefined;
    FailureConfiguration?: RefreshFailureConfiguration | undefined;
}
export interface AssetBundleImportJobDataSetOverrideParameters {
    DataSetId: string;
    Name?: string | undefined;
    DataSetRefreshProperties?: DataSetRefreshProperties | undefined;
}
export type AssetBundleImportJobDataSetOverrideParametersList = AssetBundleImportJobDataSetOverrideParameters[];
export interface AssetBundleImportJobThemeOverrideParameters {
    ThemeId: string;
    Name?: string | undefined;
}
export type AssetBundleImportJobThemeOverrideParametersList = AssetBundleImportJobThemeOverrideParameters[];
export interface AssetBundleImportJobAnalysisOverrideParameters {
    AnalysisId: string;
    Name?: string | undefined;
}
export type AssetBundleImportJobAnalysisOverrideParametersList = AssetBundleImportJobAnalysisOverrideParameters[];
export interface AssetBundleImportJobDashboardOverrideParameters {
    DashboardId: string;
    Name?: string | undefined;
}
export type AssetBundleImportJobDashboardOverrideParametersList = AssetBundleImportJobDashboardOverrideParameters[];
export interface AssetBundleImportJobFolderOverrideParameters {
    FolderId: string;
    Name?: string | undefined;
    ParentFolderArn?: string | undefined;
}
export type AssetBundleImportJobFolderOverrideParametersList = AssetBundleImportJobFolderOverrideParameters[];
export type TopicDescription = string;
export interface AssetBundleImportJobTopicV2OverrideParameters {
    TopicId: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type AssetBundleImportJobTopicV2OverrideParametersList = AssetBundleImportJobTopicV2OverrideParameters[];
export interface AssetBundleImportJobOverrideParameters {
    ResourceIdOverrideConfiguration?: AssetBundleImportJobResourceIdOverrideConfiguration | undefined;
    VPCConnections?: AssetBundleImportJobVPCConnectionOverrideParameters[] | undefined;
    RefreshSchedules?: AssetBundleImportJobRefreshScheduleOverrideParameters[] | undefined;
    DataSources?: AssetBundleImportJobDataSourceOverrideParameters[] | undefined;
    DataSets?: AssetBundleImportJobDataSetOverrideParameters[] | undefined;
    Themes?: AssetBundleImportJobThemeOverrideParameters[] | undefined;
    Analyses?: AssetBundleImportJobAnalysisOverrideParameters[] | undefined;
    Dashboards?: AssetBundleImportJobDashboardOverrideParameters[] | undefined;
    Folders?: AssetBundleImportJobFolderOverrideParameters[] | undefined;
    TopicsV2?: AssetBundleImportJobTopicV2OverrideParameters[] | undefined;
}
export type AssetBundleImportFailureAction = "DO_NOTHING" | "ROLLBACK" | (string & {});
export type AssetBundleRestrictiveResourceId = string;
export type AssetBundleRestrictiveResourceIdList = string[];
export type AssetBundlePrincipalList = string[];
export interface AssetBundleResourcePermissions {
    Principals: string[];
    Actions: string[];
}
export interface AssetBundleImportJobDataSourceOverridePermissions {
    DataSourceIds: string[];
    Permissions: AssetBundleResourcePermissions;
}
export type AssetBundleImportJobDataSourceOverridePermissionsList = AssetBundleImportJobDataSourceOverridePermissions[];
export interface AssetBundleImportJobDataSetOverridePermissions {
    DataSetIds: string[];
    Permissions: AssetBundleResourcePermissions;
}
export type AssetBundleImportJobDataSetOverridePermissionsList = AssetBundleImportJobDataSetOverridePermissions[];
export interface AssetBundleImportJobThemeOverridePermissions {
    ThemeIds: string[];
    Permissions: AssetBundleResourcePermissions;
}
export type AssetBundleImportJobThemeOverridePermissionsList = AssetBundleImportJobThemeOverridePermissions[];
export interface AssetBundleImportJobAnalysisOverridePermissions {
    AnalysisIds: string[];
    Permissions: AssetBundleResourcePermissions;
}
export type AssetBundleImportJobAnalysisOverridePermissionsList = AssetBundleImportJobAnalysisOverridePermissions[];
export interface AssetBundleResourceLinkSharingConfiguration {
    Permissions?: AssetBundleResourcePermissions | undefined;
}
export interface AssetBundleImportJobDashboardOverridePermissions {
    DashboardIds: string[];
    Permissions?: AssetBundleResourcePermissions | undefined;
    LinkSharingConfiguration?: AssetBundleResourceLinkSharingConfiguration | undefined;
}
export type AssetBundleImportJobDashboardOverridePermissionsList = AssetBundleImportJobDashboardOverridePermissions[];
export interface AssetBundleImportJobFolderOverridePermissions {
    FolderIds: string[];
    Permissions?: AssetBundleResourcePermissions | undefined;
}
export type AssetBundleImportJobFolderOverridePermissionsList = AssetBundleImportJobFolderOverridePermissions[];
export interface AssetBundleImportJobTopicV2OverridePermissions {
    TopicIds: string[];
    Permissions: AssetBundleResourcePermissions;
}
export type AssetBundleImportJobTopicV2OverridePermissionsList = AssetBundleImportJobTopicV2OverridePermissions[];
export interface AssetBundleImportJobOverridePermissions {
    DataSources?: AssetBundleImportJobDataSourceOverridePermissions[] | undefined;
    DataSets?: AssetBundleImportJobDataSetOverridePermissions[] | undefined;
    Themes?: AssetBundleImportJobThemeOverridePermissions[] | undefined;
    Analyses?: AssetBundleImportJobAnalysisOverridePermissions[] | undefined;
    Dashboards?: AssetBundleImportJobDashboardOverridePermissions[] | undefined;
    Folders?: AssetBundleImportJobFolderOverridePermissions[] | undefined;
    TopicsV2?: AssetBundleImportJobTopicV2OverridePermissions[] | undefined;
}
export interface AssetBundleImportJobVPCConnectionOverrideTags {
    VPCConnectionIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobVPCConnectionOverrideTagsList = AssetBundleImportJobVPCConnectionOverrideTags[];
export interface AssetBundleImportJobDataSourceOverrideTags {
    DataSourceIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobDataSourceOverrideTagsList = AssetBundleImportJobDataSourceOverrideTags[];
export interface AssetBundleImportJobDataSetOverrideTags {
    DataSetIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobDataSetOverrideTagsList = AssetBundleImportJobDataSetOverrideTags[];
export interface AssetBundleImportJobThemeOverrideTags {
    ThemeIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobThemeOverrideTagsList = AssetBundleImportJobThemeOverrideTags[];
export interface AssetBundleImportJobAnalysisOverrideTags {
    AnalysisIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobAnalysisOverrideTagsList = AssetBundleImportJobAnalysisOverrideTags[];
export interface AssetBundleImportJobDashboardOverrideTags {
    DashboardIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobDashboardOverrideTagsList = AssetBundleImportJobDashboardOverrideTags[];
export interface AssetBundleImportJobFolderOverrideTags {
    FolderIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobFolderOverrideTagsList = AssetBundleImportJobFolderOverrideTags[];
export interface AssetBundleImportJobTopicV2OverrideTags {
    TopicIds: string[];
    Tags: Tag[];
}
export type AssetBundleImportJobTopicV2OverrideTagsList = AssetBundleImportJobTopicV2OverrideTags[];
export interface AssetBundleImportJobOverrideTags {
    VPCConnections?: AssetBundleImportJobVPCConnectionOverrideTags[] | undefined;
    DataSources?: AssetBundleImportJobDataSourceOverrideTags[] | undefined;
    DataSets?: AssetBundleImportJobDataSetOverrideTags[] | undefined;
    Themes?: AssetBundleImportJobThemeOverrideTags[] | undefined;
    Analyses?: AssetBundleImportJobAnalysisOverrideTags[] | undefined;
    Dashboards?: AssetBundleImportJobDashboardOverrideTags[] | undefined;
    Folders?: AssetBundleImportJobFolderOverrideTags[] | undefined;
    TopicsV2?: AssetBundleImportJobTopicV2OverrideTags[] | undefined;
}
export interface AssetBundleImportJobOverrideValidationStrategy {
    StrictModeForAllResources?: boolean | undefined;
}
export interface AssetBundleImportJobWarning {
    Arn?: string | undefined;
    Message?: string | undefined;
}
export type AssetBundleImportJobWarningList = AssetBundleImportJobWarning[];
export interface DescribeAssetBundleImportJobResponse {
    JobStatus?: AssetBundleImportJobStatus | undefined;
    Errors?: AssetBundleImportJobError[] | undefined;
    RollbackErrors?: AssetBundleImportJobError[] | undefined;
    Arn?: string | undefined;
    CreatedTime?: Date | undefined;
    AssetBundleImportJobId?: string | undefined;
    AwsAccountId?: string | undefined;
    AssetBundleImportSource?: AssetBundleImportSourceDescription | undefined;
    OverrideParameters?: AssetBundleImportJobOverrideParameters | undefined;
    FailureAction?: AssetBundleImportFailureAction | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    OverridePermissions?: AssetBundleImportJobOverridePermissions | undefined;
    OverrideTags?: AssetBundleImportJobOverrideTags | undefined;
    OverrideValidationStrategy?: AssetBundleImportJobOverrideValidationStrategy | undefined;
    Warnings?: AssetBundleImportJobWarning[] | undefined;
}
export type AutomateId = string;
export interface DescribeAutomationJobRequest {
    AwsAccountId: string;
    AutomationGroupId: string;
    AutomationId: string;
    IncludeInputPayload?: boolean | undefined;
    IncludeOutputPayload?: boolean | undefined;
    JobId: string;
}
export type AutomationJobStatus = "FAILED" | "RUNNING" | "SUCCEEDED" | "QUEUED" | "STOPPED" | (string & {});
export type SensitiveIOPayload = string | redacted.Redacted<string>;
export interface DescribeAutomationJobResponse {
    Arn: string;
    CreatedAt?: Date | undefined;
    StartedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    JobStatus: AutomationJobStatus;
    InputPayload?: string | redacted.Redacted<string> | undefined;
    OutputPayload?: string | redacted.Redacted<string> | undefined;
    RequestId?: string | undefined;
}
export interface DescribeBrandRequest {
    AwsAccountId: string;
    BrandId: string;
    VersionId?: string | undefined;
}
export interface DescribeBrandResponse {
    RequestId?: string | undefined;
    BrandDetail?: BrandDetail | undefined;
    BrandDefinition?: BrandDefinition | undefined;
}
export interface DescribeBrandAssignmentRequest {
    AwsAccountId: string;
}
export interface DescribeBrandAssignmentResponse {
    RequestId?: string | undefined;
    BrandArn?: string | undefined;
}
export interface DescribeBrandPublishedVersionRequest {
    AwsAccountId: string;
    BrandId: string;
}
export interface DescribeBrandPublishedVersionResponse {
    RequestId?: string | undefined;
    BrandDetail?: BrandDetail | undefined;
    BrandDefinition?: BrandDefinition | undefined;
}
export interface DescribeCustomPermissionsRequest {
    AwsAccountId: string;
    CustomPermissionsName: string;
}
export interface CustomPermissions {
    Arn?: string | undefined;
    CustomPermissionsName?: string | undefined;
    Capabilities?: Capabilities | undefined;
    Governance?: Governance | undefined;
}
export interface DescribeCustomPermissionsResponse {
    Status?: number | undefined;
    CustomPermissions?: CustomPermissions | undefined;
    RequestId?: string | undefined;
}
export interface DescribeDashboardRequest {
    AwsAccountId: string;
    DashboardId: string;
    VersionNumber?: number | undefined;
    AliasName?: string | undefined;
}
export type DashboardErrorType = "ACCESS_DENIED" | "SOURCE_NOT_FOUND" | "DATA_SET_NOT_FOUND" | "INTERNAL_FAILURE" | "PARAMETER_VALUE_INCOMPATIBLE" | "PARAMETER_TYPE_INVALID" | "PARAMETER_NOT_FOUND" | "COLUMN_TYPE_MISMATCH" | "COLUMN_GEOGRAPHIC_ROLE_MISMATCH" | "COLUMN_REPLACEMENT_MISSING" | (string & {});
export interface DashboardError {
    Type?: DashboardErrorType | undefined;
    Message?: string | undefined;
    ViolatedEntities?: Entity[] | undefined;
}
export type DashboardErrorList = DashboardError[];
export interface DashboardVersion {
    CreatedTime?: Date | undefined;
    Errors?: DashboardError[] | undefined;
    VersionNumber?: number | undefined;
    Status?: ResourceStatus | undefined;
    Arn?: string | undefined;
    SourceEntityArn?: string | undefined;
    DataSetArns?: string[] | undefined;
    TopicArns?: string[] | undefined;
    Description?: string | undefined;
    ThemeArn?: string | undefined;
    Sheets?: Sheet[] | undefined;
}
export interface Dashboard {
    DashboardId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    Version?: DashboardVersion | undefined;
    CreatedTime?: Date | undefined;
    LastPublishedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    LinkEntities?: string[] | undefined;
}
export interface DescribeDashboardResponse {
    Dashboard?: Dashboard | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeDashboardDefinitionRequest {
    AwsAccountId: string;
    DashboardId: string;
    VersionNumber?: number | undefined;
    AliasName?: string | undefined;
}
export interface DescribeDashboardDefinitionResponse {
    DashboardId?: string | undefined;
    Errors?: DashboardError[] | undefined;
    Name?: string | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ThemeArn?: string | undefined;
    Definition?: DashboardVersionDefinition | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
    DashboardPublishOptions?: DashboardPublishOptions | undefined;
}
export interface DescribeDashboardPermissionsRequest {
    AwsAccountId: string;
    DashboardId: string;
}
export interface DescribeDashboardPermissionsResponse {
    DashboardId?: string | undefined;
    DashboardArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
    LinkSharingConfiguration?: LinkSharingConfiguration | undefined;
}
export interface DescribeDashboardSnapshotJobRequest {
    AwsAccountId: string;
    DashboardId: string;
    SnapshotJobId: string;
}
export type SessionTagKeyList = string[];
export interface SnapshotAnonymousUserRedacted {
    RowLevelPermissionTagKeys?: string[] | undefined;
}
export type SnapshotAnonymousUserRedactedList = SnapshotAnonymousUserRedacted[];
export interface SnapshotUserConfigurationRedacted {
    AnonymousUsers?: SnapshotAnonymousUserRedacted[] | undefined;
}
export type SnapshotFileSheetSelectionScope = "ALL_VISUALS" | "SELECTED_VISUALS" | (string & {});
export type SnapshotFileSheetSelectionVisualIdList = string[];
export interface SnapshotFileSheetSelection {
    SheetId: string;
    SelectionScope: SnapshotFileSheetSelectionScope;
    VisualIds?: string[] | undefined;
}
export type SnapshotFileSheetSelectionList = SnapshotFileSheetSelection[];
export type SnapshotFileFormatType = "CSV" | "PDF" | "EXCEL" | (string & {});
export interface SnapshotFile {
    SheetSelections: SnapshotFileSheetSelection[];
    FormatType: SnapshotFileFormatType;
}
export type SnapshotFileList = SnapshotFile[];
export interface SnapshotFileGroup {
    Files?: SnapshotFile[] | undefined;
}
export type SnapshotFileGroupList = SnapshotFileGroup[];
export interface S3BucketConfiguration {
    BucketName: string;
    BucketPrefix: string;
    BucketRegion: string;
}
export interface SnapshotS3DestinationConfiguration {
    BucketConfiguration: S3BucketConfiguration;
}
export type SnapshotS3DestinationConfigurationList = SnapshotS3DestinationConfiguration[];
export interface SnapshotDestinationConfiguration {
    S3Destinations?: SnapshotS3DestinationConfiguration[] | undefined;
}
export interface SnapshotConfiguration {
    FileGroups: SnapshotFileGroup[];
    DestinationConfiguration?: SnapshotDestinationConfiguration | undefined;
    Parameters?: Parameters | undefined;
}
export type SnapshotJobStatus = "QUEUED" | "RUNNING" | "COMPLETED" | "FAILED" | (string & {});
export interface DescribeDashboardSnapshotJobResponse {
    AwsAccountId?: string | undefined;
    DashboardId?: string | undefined;
    SnapshotJobId?: string | undefined;
    UserConfiguration?: SnapshotUserConfigurationRedacted | undefined;
    SnapshotConfiguration?: SnapshotConfiguration | undefined;
    Arn?: string | undefined;
    JobStatus?: SnapshotJobStatus | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDashboardSnapshotJobResultRequest {
    AwsAccountId: string;
    DashboardId: string;
    SnapshotJobId: string;
}
export interface SnapshotJobResultErrorInfo {
    ErrorMessage?: string | undefined;
    ErrorType?: string | undefined;
}
export type SnapshotJobResultErrorInfoList = SnapshotJobResultErrorInfo[];
export interface SnapshotJobS3Result {
    S3DestinationConfiguration?: SnapshotS3DestinationConfiguration | undefined;
    S3Uri?: string | redacted.Redacted<string> | undefined;
    ErrorInfo?: SnapshotJobResultErrorInfo[] | undefined;
}
export type SnapshotJobS3ResultList = SnapshotJobS3Result[];
export interface SnapshotJobResultFileGroup {
    Files?: SnapshotFile[] | undefined;
    S3Results?: SnapshotJobS3Result[] | undefined;
}
export type SnapshotJobResultFileGroupList = SnapshotJobResultFileGroup[];
export interface AnonymousUserSnapshotJobResult {
    FileGroups?: SnapshotJobResultFileGroup[] | undefined;
}
export type AnonymousUserSnapshotJobResultList = AnonymousUserSnapshotJobResult[];
export interface RegisteredUserSnapshotJobResult {
    FileGroups?: SnapshotJobResultFileGroup[] | undefined;
}
export type RegisteredUserSnapshotJobResultList = RegisteredUserSnapshotJobResult[];
export interface SnapshotJobResult {
    AnonymousUsers?: AnonymousUserSnapshotJobResult[] | undefined;
    RegisteredUsers?: RegisteredUserSnapshotJobResult[] | undefined;
}
export interface SnapshotJobErrorInfo {
    ErrorMessage?: string | undefined;
    ErrorType?: string | undefined;
}
export interface DescribeDashboardSnapshotJobResultResponse {
    Arn?: string | undefined;
    JobStatus?: SnapshotJobStatus | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Result?: SnapshotJobResult | undefined;
    ErrorInfo?: SnapshotJobErrorInfo | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDashboardsQAConfigurationRequest {
    AwsAccountId: string;
}
export type DashboardsQAStatus = "ENABLED" | "DISABLED" | (string & {});
export interface DescribeDashboardsQAConfigurationResponse {
    DashboardsQAStatus?: DashboardsQAStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDataSetRequest {
    AwsAccountId: string;
    DataSetId: string;
}
export interface OutputColumn {
    Name?: string | undefined;
    Id?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
    Type?: ColumnDataType | undefined;
    SubType?: ColumnDataSubType | undefined;
}
export type OutputColumnList = OutputColumn[];
export interface DataSet {
    Arn?: string | undefined;
    DataSetId?: string | undefined;
    Name?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    PhysicalTableMap?: {
        [key: string]: PhysicalTable | undefined;
    } | undefined;
    LogicalTableMap?: {
        [key: string]: LogicalTable | undefined;
    } | undefined;
    OutputColumns?: OutputColumn[] | undefined;
    ImportMode?: DataSetImportMode | undefined;
    ConsumedSpiceCapacityInBytes?: number | undefined;
    ColumnGroups?: ColumnGroup[] | undefined;
    FieldFolders?: {
        [key: string]: FieldFolder | undefined;
    } | undefined;
    RowLevelPermissionDataSet?: RowLevelPermissionDataSet | undefined;
    RowLevelPermissionTagConfiguration?: RowLevelPermissionTagConfiguration | undefined;
    ColumnLevelPermissionRules?: ColumnLevelPermissionRule[] | undefined;
    DataSetUsageConfiguration?: DataSetUsageConfiguration | undefined;
    DatasetParameters?: DatasetParameter[] | undefined;
    PerformanceConfiguration?: PerformanceConfiguration | undefined;
    UseAs?: DataSetUseAs | undefined;
    DataPrepConfiguration?: DataPrepConfiguration | undefined;
    SemanticModelConfiguration?: SemanticModelConfiguration | undefined;
}
export interface DescribeDataSetResponse {
    DataSet?: DataSet | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDataSetPermissionsRequest {
    AwsAccountId: string;
    DataSetId: string;
}
export interface DescribeDataSetPermissionsResponse {
    DataSetArn?: string | undefined;
    DataSetId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDataSetRefreshPropertiesRequest {
    AwsAccountId: string;
    DataSetId: string;
}
export interface DescribeDataSetRefreshPropertiesResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
    DataSetRefreshProperties?: DataSetRefreshProperties | undefined;
}
export interface DescribeDataSourceRequest {
    AwsAccountId: string;
    DataSourceId: string;
}
export type DataSourceErrorInfoType = "ACCESS_DENIED" | "COPY_SOURCE_NOT_FOUND" | "TIMEOUT" | "ENGINE_VERSION_NOT_SUPPORTED" | "UNKNOWN_HOST" | "GENERIC_SQL_FAILURE" | "CONFLICT" | "UNKNOWN" | (string & {});
export interface DataSourceErrorInfo {
    Type?: DataSourceErrorInfoType | undefined;
    Message?: string | undefined;
}
export type CredentialStatus = "CONNECTED" | "AUTH_FAILED" | "NOT_VERIFIED" | (string & {});
export interface DataSource {
    Arn: string;
    DataSourceId: string;
    Name: string;
    Type: DataSourceType;
    Status: ResourceStatus;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    DataSourceParameters?: DataSourceParameters | undefined;
    AlternateDataSourceParameters?: DataSourceParameters[] | undefined;
    VpcConnectionProperties?: VpcConnectionProperties | undefined;
    SslProperties?: SslProperties | undefined;
    ErrorInfo?: DataSourceErrorInfo | undefined;
    SecretArn?: string | undefined;
    CredentialStatus?: CredentialStatus | undefined;
    LastCredentialVerifiedAt?: Date | undefined;
}
export interface DescribeDataSourceResponse {
    DataSource?: DataSource | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDataSourcePermissionsRequest {
    AwsAccountId: string;
    DataSourceId: string;
}
export interface DescribeDataSourcePermissionsResponse {
    DataSourceArn?: string | undefined;
    DataSourceId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeDefaultQBusinessApplicationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
}
export interface DescribeDefaultQBusinessApplicationResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
    ApplicationId?: string | undefined;
}
export interface DescribeDlpSettingRequest {
    AwsAccountId: string;
    DlpSettingId: string;
}
export type DlpSettingStatus = "ACTIVE" | "INACTIVE" | (string & {});
export interface DlpSettingDetails {
    DlpSettingId: string;
    Name: string;
    Arn: string;
    Status: DlpSettingStatus;
    ProviderType: DlpProviderType;
    ProviderConfig: ProviderConfig;
    ProviderOutageAction: DlpAction;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export interface DescribeDlpSettingResponse {
    DlpSetting: DlpSettingDetails;
    RequestId?: string | undefined;
}
export type FlowPublishState = "PUBLISHED" | "DRAFT" | "PENDING_APPROVAL" | (string & {});
export interface DescribeFlowRequest {
    AwsAccountId: string;
    FlowId: string;
    PublishState: FlowPublishState;
}
export type Title = string;
export type FlowDescription = string;
export type StepId = string;
export interface StepAliasMapping {
    StepId: string;
    StepAlias: string;
}
export type StepAliasList = StepAliasMapping[];
export interface FlowDetail {
    Arn: string;
    FlowId: string;
    Name: string;
    Description?: string | undefined;
    PublishState: FlowPublishState;
    CreatedTime: Date;
    CreatedBy?: string | undefined;
    LastUpdatedTime?: Date | undefined;
    LastUpdatedBy?: string | undefined;
    FlowDefinition: any;
    StepAliases?: StepAliasMapping[] | undefined;
}
export interface DescribeFlowResponse {
    Flow: FlowDetail;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeFolderRequest {
    AwsAccountId: string;
    FolderId: string;
}
export type Path = string[];
export interface Folder {
    FolderId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    FolderType?: FolderType | undefined;
    FolderPath?: string[] | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    SharingModel?: SharingModel | undefined;
}
export interface DescribeFolderResponse {
    Status?: number | undefined;
    Folder?: Folder | undefined;
    RequestId?: string | undefined;
}
export type MaxResults = number;
export interface DescribeFolderPermissionsRequest {
    AwsAccountId: string;
    FolderId: string;
    Namespace?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFolderPermissionsResponse {
    Status?: number | undefined;
    FolderId?: string | undefined;
    Arn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFolderResolvedPermissionsRequest {
    AwsAccountId: string;
    FolderId: string;
    Namespace?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFolderResolvedPermissionsResponse {
    Status?: number | undefined;
    FolderId?: string | undefined;
    Arn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    NextToken?: string | undefined;
}
export interface DescribeGroupRequest {
    GroupName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DescribeGroupResponse {
    Group?: Group | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeGroupMembershipRequest {
    MemberName: string;
    GroupName: string;
    AwsAccountId: string;
    Namespace: string;
}
export interface DescribeGroupMembershipResponse {
    GroupMember?: GroupMember | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeIAMPolicyAssignmentRequest {
    AwsAccountId: string;
    AssignmentName: string;
    Namespace: string;
}
export interface IAMPolicyAssignment {
    AwsAccountId?: string | undefined;
    AssignmentId?: string | undefined;
    AssignmentName?: string | undefined;
    PolicyArn?: string | undefined;
    Identities?: {
        [key: string]: string[] | undefined;
    } | undefined;
    AssignmentStatus?: AssignmentStatus | undefined;
}
export interface DescribeIAMPolicyAssignmentResponse {
    IAMPolicyAssignment?: IAMPolicyAssignment | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeIngestionRequest {
    AwsAccountId: string;
    DataSetId: string;
    IngestionId: string;
}
export type IngestionErrorType = "FAILURE_TO_ASSUME_ROLE" | "INGESTION_SUPERSEDED" | "INGESTION_CANCELED" | "DATA_SET_DELETED" | "DATA_SET_NOT_SPICE" | "S3_UPLOADED_FILE_DELETED" | "S3_MANIFEST_ERROR" | "DATA_TOLERANCE_EXCEPTION" | "SPICE_TABLE_NOT_FOUND" | "DATA_SET_SIZE_LIMIT_EXCEEDED" | "ROW_SIZE_LIMIT_EXCEEDED" | "ACCOUNT_CAPACITY_LIMIT_EXCEEDED" | "CUSTOMER_ERROR" | "DATA_SOURCE_NOT_FOUND" | "IAM_ROLE_NOT_AVAILABLE" | "CONNECTION_FAILURE" | "SQL_TABLE_NOT_FOUND" | "PERMISSION_DENIED" | "SSL_CERTIFICATE_VALIDATION_FAILURE" | "OAUTH_TOKEN_FAILURE" | "SOURCE_API_LIMIT_EXCEEDED_FAILURE" | "PASSWORD_AUTHENTICATION_FAILURE" | "SQL_SCHEMA_MISMATCH_ERROR" | "INVALID_DATE_FORMAT" | "INVALID_DATAPREP_SYNTAX" | "SOURCE_RESOURCE_LIMIT_EXCEEDED" | "SQL_INVALID_PARAMETER_VALUE" | "QUERY_TIMEOUT" | "SQL_NUMERIC_OVERFLOW" | "UNRESOLVABLE_HOST" | "UNROUTABLE_HOST" | "SQL_EXCEPTION" | "S3_FILE_INACCESSIBLE" | "IOT_FILE_NOT_FOUND" | "IOT_DATA_SET_FILE_EMPTY" | "INVALID_DATA_SOURCE_CONFIG" | "DATA_SOURCE_AUTH_FAILED" | "DATA_SOURCE_CONNECTION_FAILED" | "FAILURE_TO_PROCESS_JSON_FILE" | "INTERNAL_SERVICE_ERROR" | "REFRESH_SUPPRESSED_BY_EDIT" | "PERMISSION_NOT_FOUND" | "ELASTICSEARCH_CURSOR_NOT_ENABLED" | "CURSOR_NOT_ENABLED" | "DUPLICATE_COLUMN_NAMES_FOUND" | (string & {});
export interface ErrorInfo {
    Type?: IngestionErrorType | undefined;
    Message?: string | undefined;
}
export interface RowInfo {
    RowsIngested?: number | undefined;
    RowsDropped?: number | undefined;
    TotalRowsInDataset?: number | undefined;
}
export interface QueueInfo {
    WaitingOnIngestion: string;
    QueuedIngestion: string;
}
export type IngestionRequestSource = "MANUAL" | "SCHEDULED" | (string & {});
export type IngestionRequestType = "INITIAL_INGESTION" | "EDIT" | "INCREMENTAL_REFRESH" | "FULL_REFRESH" | (string & {});
export interface Ingestion {
    Arn: string;
    IngestionId?: string | undefined;
    IngestionStatus: IngestionStatus;
    ErrorInfo?: ErrorInfo | undefined;
    RowInfo?: RowInfo | undefined;
    QueueInfo?: QueueInfo | undefined;
    CreatedTime: Date;
    IngestionTimeInSeconds?: number | undefined;
    IngestionSizeInBytes?: number | undefined;
    RequestSource?: IngestionRequestSource | undefined;
    RequestType?: IngestionRequestType | undefined;
}
export interface DescribeIngestionResponse {
    Ingestion?: Ingestion | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeIpRestrictionRequest {
    AwsAccountId: string;
}
export type CIDR = string;
export type IpRestrictionRuleDescription = string;
export type IpRestrictionRuleMap = {
    [key: string]: string | undefined;
};
export type VpcId = string;
export type VpcIdRestrictionRuleDescription = string;
export type VpcIdRestrictionRuleMap = {
    [key: string]: string | undefined;
};
export type VpcEndpointId = string;
export type VpcEndpointIdRestrictionRuleDescription = string;
export type VpcEndpointIdRestrictionRuleMap = {
    [key: string]: string | undefined;
};
export interface DescribeIpRestrictionResponse {
    AwsAccountId?: string | undefined;
    IpRestrictionRuleMap?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcIdRestrictionRuleMap?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcEndpointIdRestrictionRuleMap?: {
        [key: string]: string | undefined;
    } | undefined;
    Enabled?: boolean | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeKeyRegistrationRequest {
    AwsAccountId: string;
    DefaultKeyOnly?: boolean | undefined;
}
export interface RegisteredCustomerManagedKey {
    KeyArn?: string | undefined;
    DefaultKey?: boolean | undefined;
}
export type KeyRegistration = RegisteredCustomerManagedKey[];
export type QDataKeyType = "AWS_OWNED" | "CMK" | (string & {});
export interface QDataKey {
    QDataKeyArn?: string | undefined;
    QDataKeyType?: QDataKeyType | undefined;
}
export interface DescribeKeyRegistrationResponse {
    AwsAccountId?: string | undefined;
    KeyRegistration?: RegisteredCustomerManagedKey[] | undefined;
    QDataKey?: QDataKey | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeKnowledgeBaseRequest {
    AwsAccountId: string;
    KnowledgeBaseId: string;
}
export type KbIngestionId = string;
export type KbIngestionStatus = "QUEUED" | "RUNNING" | "FAILED" | "COMPLETED" | "INCOMPLETE" | "CANCELLED" | "CANCELLING" | "TIMEOUT" | (string & {});
export interface KnowledgeBaseIngestionSummary {
    IngestionId: string;
    IngestionStatus: KbIngestionStatus;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
}
export interface KnowledgeBase {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    Name: string;
    Status: DataSetStatus;
    DataSourceArn: string;
    KnowledgeBaseConfiguration: KnowledgeBaseConfiguration;
    MediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
    AccessControlConfiguration?: AccessControlConfiguration | undefined;
    Type?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    Description?: string | undefined;
    IsEmailNotificationOptedForIngestionFailures?: boolean | undefined;
    FirstCompletedIngestionSummary?: KnowledgeBaseIngestionSummary | undefined;
    FirstIncompleteIngestionSummary?: KnowledgeBaseIngestionSummary | undefined;
    LatestIngestionSummary?: KnowledgeBaseIngestionSummary | undefined;
    KnowledgeBaseSizeBytes?: number | undefined;
    DocumentCount?: number | undefined;
    PrimaryOwnerArn?: string | undefined;
    PrimaryOwnerUsername?: string | redacted.Redacted<string> | undefined;
}
export interface DescribeKnowledgeBaseResponse {
    KnowledgeBase: KnowledgeBase;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeKnowledgeBasePermissionsRequest {
    AwsAccountId: string;
    KnowledgeBaseId: string;
}
export interface DescribeKnowledgeBasePermissionsResponse {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeLimitsProfileRequest {
    profileId: string;
    accountId: string;
}
export type ResourceLimitsMap = {
    [key in ResourceType]?: ProfileLimitValue | undefined;
};
export interface LimitsProfile {
    profileId: string;
    arn: string;
    accountId: string;
    profileName: string;
    description?: string | undefined;
    resourceLimits: {
        [key: string]: ProfileLimitValue | undefined;
    };
    createdAt: Date;
    updatedAt: Date;
}
export interface DescribeLimitsProfileResponse {
    profile: LimitsProfile;
}
export interface DescribeNamespaceRequest {
    AwsAccountId: string;
    Namespace: string;
}
export type NamespaceErrorType = "PERMISSION_DENIED" | "INTERNAL_SERVICE_ERROR" | (string & {});
export interface NamespaceError {
    Type?: NamespaceErrorType | undefined;
    Message?: string | undefined;
}
export interface NamespaceInfoV2 {
    Name?: string | undefined;
    Arn?: string | undefined;
    CapacityRegion?: string | undefined;
    CreationStatus?: NamespaceStatus | undefined;
    IdentityStore?: IdentityStore | undefined;
    NamespaceError?: NamespaceError | undefined;
    IamIdentityCenterApplicationArn?: string | undefined;
    IamIdentityCenterInstanceArn?: string | undefined;
}
export interface DescribeNamespaceResponse {
    Namespace?: NamespaceInfoV2 | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeOAuthClientApplicationRequest {
    AwsAccountId: string;
    OAuthClientApplicationId: string;
}
export interface OAuthClientApplication {
    OAuthClientApplicationId?: string | undefined;
    Name?: string | undefined;
    OAuthClientAuthenticationType?: OAuthClientAuthenticationType | undefined;
    OAuthTokenEndpointUrl?: string | redacted.Redacted<string> | undefined;
    OAuthAuthorizationEndpointUrl?: string | redacted.Redacted<string> | undefined;
    OAuthScopes?: string | undefined;
    DataSourceType?: DataSourceType | undefined;
    IdentityProviderVpcConnectionProperties?: VpcConnectionProperties | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Arn?: string | undefined;
}
export interface DescribeOAuthClientApplicationResponse {
    OAuthClientApplication?: OAuthClientApplication | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeQPersonalizationConfigurationRequest {
    AwsAccountId: string;
}
export type PersonalizationMode = "ENABLED" | "DISABLED" | (string & {});
export interface DescribeQPersonalizationConfigurationResponse {
    PersonalizationMode?: PersonalizationMode | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeQuickSightQSearchConfigurationRequest {
    AwsAccountId: string;
}
export type QSearchStatus = "ENABLED" | "DISABLED" | (string & {});
export interface DescribeQuickSightQSearchConfigurationResponse {
    QSearchStatus?: QSearchStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeRefreshScheduleRequest {
    AwsAccountId: string;
    DataSetId: string;
    ScheduleId: string;
}
export interface DescribeRefreshScheduleResponse {
    RefreshSchedule?: RefreshSchedule | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
    Arn?: string | undefined;
}
export interface DescribeResourcePermissionsRequest {
    AwsAccountId: string;
}
export type ServiceRoleType = "QUICKSIGHT_MANAGED" | "CUSTOMER_MANAGED" | (string & {});
export interface DescribeResourcePermissionsResponse {
    RoleType?: ServiceRoleType | undefined;
    CustomerManagedRoleArn?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeRoleCustomPermissionRequest {
    Role: Role;
    AwsAccountId: string;
    Namespace: string;
}
export type RoleName = string;
export interface DescribeRoleCustomPermissionResponse {
    CustomPermissionsName?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeSelfUpgradeConfigurationRequest {
    AwsAccountId: string;
    Namespace: string;
}
export type SelfUpgradeStatus = "AUTO_APPROVAL" | "ADMIN_APPROVAL" | (string & {});
export interface SelfUpgradeConfiguration {
    SelfUpgradeStatus?: SelfUpgradeStatus | undefined;
}
export interface DescribeSelfUpgradeConfigurationResponse {
    SelfUpgradeConfiguration?: SelfUpgradeConfiguration | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type MaxContributors = number;
export interface DescribeSpaceRequest {
    AwsAccountId: string;
    SpaceId: string;
    MaxContributors?: number | undefined;
}
export type SpaceQuickSightResourceType = "TOPIC" | "DASHBOARD" | "KNOWLEDGE_BASE" | "ACTION_CONNECTOR" | "DATA_SET" | (string & {});
export type SpaceQuickSightResourceDetails = {
    resourceArn: string;
};
export interface SpaceQuickSightResource {
    resourceType: SpaceQuickSightResourceType;
    resourceDetails: SpaceQuickSightResourceDetails;
}
export type SpaceQuickSightResources = SpaceQuickSightResource[];
export interface SpaceDetails {
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    resources?: SpaceQuickSightResource[] | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    consumedSourceSize?: number | undefined;
    consumedSourceDocCount?: number | undefined;
    createdBy?: string | undefined;
    createdByArn?: string | undefined;
}
export interface SpaceContributor {
    userName?: string | undefined;
    rawFileSizeBytes: number;
    percentage?: number | undefined;
}
export type SpaceContributorList = SpaceContributor[];
export interface DescribeSpaceResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    Space: SpaceDetails;
    Contributors?: SpaceContributor[] | undefined;
    RequestId?: string | undefined;
}
export interface DescribeSpacePermissionsRequest {
    AwsAccountId: string;
    SpaceId: string;
}
export interface DescribeSpacePermissionsResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTemplateRequest {
    AwsAccountId: string;
    TemplateId: string;
    VersionNumber?: number | undefined;
    AliasName?: string | undefined;
}
export type TemplateErrorType = "SOURCE_NOT_FOUND" | "DATA_SET_NOT_FOUND" | "INTERNAL_FAILURE" | "ACCESS_DENIED" | (string & {});
export interface TemplateError {
    Type?: TemplateErrorType | undefined;
    Message?: string | undefined;
    ViolatedEntities?: Entity[] | undefined;
}
export type TemplateErrorList = TemplateError[];
export interface TemplateVersion {
    CreatedTime?: Date | undefined;
    Errors?: TemplateError[] | undefined;
    VersionNumber?: number | undefined;
    Status?: ResourceStatus | undefined;
    DataSetConfigurations?: DataSetConfiguration[] | undefined;
    TopicConfigurations?: TopicConfiguration[] | undefined;
    Description?: string | undefined;
    SourceEntityArn?: string | undefined;
    ThemeArn?: string | undefined;
    Sheets?: Sheet[] | undefined;
}
export interface Template {
    Arn?: string | undefined;
    Name?: string | undefined;
    Version?: TemplateVersion | undefined;
    TemplateId?: string | undefined;
    LastUpdatedTime?: Date | undefined;
    CreatedTime?: Date | undefined;
}
export interface DescribeTemplateResponse {
    Template?: Template | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTemplateAliasRequest {
    AwsAccountId: string;
    TemplateId: string;
    AliasName: string;
}
export interface DescribeTemplateAliasResponse {
    TemplateAlias?: TemplateAlias | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTemplateDefinitionRequest {
    AwsAccountId: string;
    TemplateId: string;
    VersionNumber?: number | undefined;
    AliasName?: string | undefined;
}
export interface DescribeTemplateDefinitionResponse {
    Name?: string | undefined;
    TemplateId?: string | undefined;
    Errors?: TemplateError[] | undefined;
    ResourceStatus?: ResourceStatus | undefined;
    ThemeArn?: string | undefined;
    Definition?: TemplateVersionDefinition | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTemplatePermissionsRequest {
    AwsAccountId: string;
    TemplateId: string;
}
export interface DescribeTemplatePermissionsResponse {
    TemplateId?: string | undefined;
    TemplateArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type AwsAndAccountId = string;
export interface DescribeThemeRequest {
    AwsAccountId: string;
    ThemeId: string;
    VersionNumber?: number | undefined;
    AliasName?: string | undefined;
}
export type ThemeErrorType = "INTERNAL_FAILURE" | (string & {});
export interface ThemeError {
    Type?: ThemeErrorType | undefined;
    Message?: string | undefined;
}
export type ThemeErrorList = ThemeError[];
export interface ThemeVersion {
    VersionNumber?: number | undefined;
    Arn?: string | undefined;
    Description?: string | undefined;
    BaseThemeId?: string | undefined;
    CreatedTime?: Date | undefined;
    Configuration?: ThemeConfiguration | undefined;
    Errors?: ThemeError[] | undefined;
    Status?: ResourceStatus | undefined;
}
export type ThemeType = "QUICKSIGHT" | "CUSTOM" | "ALL" | (string & {});
export interface Theme {
    Arn?: string | undefined;
    Name?: string | undefined;
    ThemeId?: string | undefined;
    Version?: ThemeVersion | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Type?: ThemeType | undefined;
}
export interface DescribeThemeResponse {
    Theme?: Theme | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeThemeAliasRequest {
    AwsAccountId: string;
    ThemeId: string;
    AliasName: string;
}
export interface DescribeThemeAliasResponse {
    ThemeAlias?: ThemeAlias | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeThemePermissionsRequest {
    AwsAccountId: string;
    ThemeId: string;
}
export interface DescribeThemePermissionsResponse {
    ThemeId?: string | undefined;
    ThemeArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeTopicRequest {
    AwsAccountId: string;
    TopicId: string;
}
export interface DescribeTopicResponse {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    Topic?: TopicDetails | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    CustomInstructions?: CustomInstructions | undefined;
}
export interface DescribeTopicPermissionsRequest {
    AwsAccountId: string;
    TopicId: string;
}
export interface DescribeTopicPermissionsResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTopicPermissionsV2Request {
    AwsAccountId: string;
    TopicId: string;
}
export interface DescribeTopicPermissionsV2Response {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTopicRefreshRequest {
    AwsAccountId: string;
    TopicId: string;
    RefreshId: string;
}
export type TopicRefreshStatus = "INITIALIZED" | "RUNNING" | "FAILED" | "COMPLETED" | "CANCELLED" | (string & {});
export interface TopicRefreshDetails {
    RefreshArn?: string | undefined;
    RefreshId?: string | undefined;
    RefreshStatus?: TopicRefreshStatus | undefined;
}
export interface DescribeTopicRefreshResponse {
    RefreshDetails?: TopicRefreshDetails | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeTopicRefreshScheduleRequest {
    AwsAccountId: string;
    TopicId: string;
    DatasetId: string;
}
export interface DescribeTopicRefreshScheduleResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    DatasetArn?: string | undefined;
    RefreshSchedule?: TopicRefreshSchedule | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeTopicV2Request {
    AwsAccountId: string;
    TopicId: string;
}
export interface DescribeTopicV2Response {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    Topic?: TopicV2Details | undefined;
    CustomInstructions?: CustomInstructions | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface DescribeUserRequest {
    UserName: string;
    AwsAccountId: string;
    Namespace: string;
}
export type UserRole = "ADMIN" | "AUTHOR" | "READER" | "RESTRICTED_AUTHOR" | "RESTRICTED_READER" | "ADMIN_PRO" | "AUTHOR_PRO" | "READER_PRO" | (string & {});
export type IdentityType = "IAM" | "QUICKSIGHT" | "IAM_IDENTITY_CENTER" | (string & {});
export interface User {
    Arn?: string | undefined;
    UserName?: string | undefined;
    Email?: string | undefined;
    Role?: UserRole | undefined;
    IdentityType?: IdentityType | undefined;
    Active?: boolean | undefined;
    PrincipalId?: string | undefined;
    CustomPermissionsName?: string | undefined;
    ExternalLoginFederationProviderType?: string | undefined;
    ExternalLoginFederationProviderUrl?: string | undefined;
    ExternalLoginId?: string | undefined;
}
export interface DescribeUserResponse {
    User?: User | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface DescribeVPCConnectionRequest {
    AwsAccountId: string;
    VPCConnectionId: string;
}
export type NetworkInterfaceStatus = "CREATING" | "AVAILABLE" | "CREATION_FAILED" | "UPDATING" | "UPDATE_FAILED" | "DELETING" | "DELETED" | "DELETION_FAILED" | "DELETION_SCHEDULED" | "ATTACHMENT_FAILED_ROLLBACK_FAILED" | (string & {});
export type NetworkInterfaceId = string;
export interface NetworkInterface {
    SubnetId?: string | undefined;
    AvailabilityZone?: string | undefined;
    ErrorMessage?: string | undefined;
    Status?: NetworkInterfaceStatus | undefined;
    NetworkInterfaceId?: string | undefined;
}
export type NetworkInterfaceList = NetworkInterface[];
export interface VPCConnection {
    VPCConnectionId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    VPCId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    DnsResolvers?: string[] | undefined;
    Status?: VPCConnectionResourceStatus | undefined;
    AvailabilityStatus?: VPCConnectionAvailabilityStatus | undefined;
    NetworkInterfaces?: NetworkInterface[] | undefined;
    RoleArn?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export interface DescribeVPCConnectionResponse {
    VPCConnection?: VPCConnection | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type SessionLifetimeInMinutes = number;
export interface SessionTag {
    Key: string;
    Value: string | redacted.Redacted<string>;
}
export type SessionTagList = SessionTag[];
export type ArnList = string[];
export type AnonymousUserDashboardEmbeddingConfigurationEnabledFeature = "SHARED_VIEW" | (string & {});
export type AnonymousUserDashboardEmbeddingConfigurationEnabledFeatures = AnonymousUserDashboardEmbeddingConfigurationEnabledFeature[];
export type AnonymousUserDashboardEmbeddingConfigurationDisabledFeature = "SHARED_VIEW" | (string & {});
export type AnonymousUserDashboardEmbeddingConfigurationDisabledFeatures = AnonymousUserDashboardEmbeddingConfigurationDisabledFeature[];
export interface SharedViewConfigurations {
    Enabled: boolean;
}
export interface AnonymousUserDashboardFeatureConfigurations {
    SharedView?: SharedViewConfigurations | undefined;
}
export interface AnonymousUserDashboardEmbeddingConfiguration {
    InitialDashboardId: string;
    EnabledFeatures?: AnonymousUserDashboardEmbeddingConfigurationEnabledFeature[] | undefined;
    DisabledFeatures?: AnonymousUserDashboardEmbeddingConfigurationDisabledFeature[] | undefined;
    FeatureConfigurations?: AnonymousUserDashboardFeatureConfigurations | undefined;
}
export interface DashboardVisualId {
    DashboardId: string;
    SheetId: string;
    VisualId: string;
}
export interface AnonymousUserDashboardVisualEmbeddingConfiguration {
    InitialDashboardVisualId: DashboardVisualId;
}
export interface AnonymousUserQSearchBarEmbeddingConfiguration {
    InitialTopicId: string;
}
export interface AnonymousUserGenerativeQnAEmbeddingConfiguration {
    InitialTopicId: string;
}
export interface AnonymousUserEmbeddingExperienceConfiguration {
    Dashboard?: AnonymousUserDashboardEmbeddingConfiguration | undefined;
    DashboardVisual?: AnonymousUserDashboardVisualEmbeddingConfiguration | undefined;
    QSearchBar?: AnonymousUserQSearchBarEmbeddingConfiguration | undefined;
    GenerativeQnA?: AnonymousUserGenerativeQnAEmbeddingConfiguration | undefined;
}
export interface GenerateEmbedUrlForAnonymousUserRequest {
    AwsAccountId: string;
    SessionLifetimeInMinutes?: number | undefined;
    Namespace: string;
    SessionTags?: SessionTag[] | undefined;
    AuthorizedResourceArns: string[];
    ExperienceConfiguration: AnonymousUserEmbeddingExperienceConfiguration;
    AllowedDomains?: string[] | undefined;
}
export type EmbeddingUrl = string | redacted.Redacted<string>;
export interface GenerateEmbedUrlForAnonymousUserResponse {
    EmbedUrl: string | redacted.Redacted<string>;
    Status: number;
    RequestId: string;
    AnonymousUserArn: string;
}
export interface StatePersistenceConfigurations {
    Enabled: boolean;
}
export interface BookmarksConfigurations {
    Enabled: boolean;
}
export interface ExecutiveSummaryConfigurations {
    Enabled: boolean;
}
export interface AmazonQInQuickSightDashboardConfigurations {
    ExecutiveSummary?: ExecutiveSummaryConfigurations | undefined;
}
export interface SchedulesConfigurations {
    Enabled: boolean;
}
export interface RecentSnapshotsConfigurations {
    Enabled: boolean;
}
export interface ThresholdAlertsConfigurations {
    Enabled: boolean;
}
export interface DashboardCustomizationSummaryConfigurations {
    Enabled: boolean;
}
export interface RegisteredUserDashboardFeatureConfigurations {
    StatePersistence?: StatePersistenceConfigurations | undefined;
    Bookmarks?: BookmarksConfigurations | undefined;
    SharedView?: SharedViewConfigurations | undefined;
    AmazonQInQuickSight?: AmazonQInQuickSightDashboardConfigurations | undefined;
    Schedules?: SchedulesConfigurations | undefined;
    RecentSnapshots?: RecentSnapshotsConfigurations | undefined;
    ThresholdAlerts?: ThresholdAlertsConfigurations | undefined;
    DashboardCustomizationSummary?: DashboardCustomizationSummaryConfigurations | undefined;
}
export interface RegisteredUserDashboardEmbeddingConfiguration {
    InitialDashboardId: string;
    FeatureConfigurations?: RegisteredUserDashboardFeatureConfigurations | undefined;
}
export type EntryPath = string;
export interface DataQnAConfigurations {
    Enabled: boolean;
}
export interface GenerativeAuthoringConfigurations {
    Enabled: boolean;
}
export interface DataStoriesConfigurations {
    Enabled: boolean;
}
export interface AmazonQInQuickSightConsoleConfigurations {
    DataQnA?: DataQnAConfigurations | undefined;
    GenerativeAuthoring?: GenerativeAuthoringConfigurations | undefined;
    ExecutiveSummary?: ExecutiveSummaryConfigurations | undefined;
    DataStories?: DataStoriesConfigurations | undefined;
}
export interface RegisteredUserConsoleFeatureConfigurations {
    StatePersistence?: StatePersistenceConfigurations | undefined;
    SharedView?: SharedViewConfigurations | undefined;
    AmazonQInQuickSight?: AmazonQInQuickSightConsoleConfigurations | undefined;
    Schedules?: SchedulesConfigurations | undefined;
    RecentSnapshots?: RecentSnapshotsConfigurations | undefined;
    ThresholdAlerts?: ThresholdAlertsConfigurations | undefined;
    DashboardCustomizationSummary?: DashboardCustomizationSummaryConfigurations | undefined;
}
export interface RegisteredUserQuickSightConsoleEmbeddingConfiguration {
    InitialPath?: string | undefined;
    FeatureConfigurations?: RegisteredUserConsoleFeatureConfigurations | undefined;
}
export interface RegisteredUserQSearchBarEmbeddingConfiguration {
    InitialTopicId?: string | undefined;
}
export interface RegisteredUserDashboardVisualEmbeddingConfiguration {
    InitialDashboardVisualId: DashboardVisualId;
}
export interface RegisteredUserGenerativeQnAEmbeddingConfiguration {
    InitialTopicId?: string | undefined;
}
export interface RegisteredUserQuickChatEmbeddingConfiguration {
}
export interface RegisteredUserEmbeddingExperienceConfiguration {
    Dashboard?: RegisteredUserDashboardEmbeddingConfiguration | undefined;
    QuickSightConsole?: RegisteredUserQuickSightConsoleEmbeddingConfiguration | undefined;
    QSearchBar?: RegisteredUserQSearchBarEmbeddingConfiguration | undefined;
    DashboardVisual?: RegisteredUserDashboardVisualEmbeddingConfiguration | undefined;
    GenerativeQnA?: RegisteredUserGenerativeQnAEmbeddingConfiguration | undefined;
    QuickChat?: RegisteredUserQuickChatEmbeddingConfiguration | undefined;
}
export interface GenerateEmbedUrlForRegisteredUserRequest {
    AwsAccountId: string;
    SessionLifetimeInMinutes?: number | undefined;
    UserArn: string;
    ExperienceConfiguration: RegisteredUserEmbeddingExperienceConfiguration;
    AllowedDomains?: string[] | undefined;
}
export interface GenerateEmbedUrlForRegisteredUserResponse {
    EmbedUrl: string | redacted.Redacted<string>;
    Status: number;
    RequestId: string;
}
export interface GenerateEmbedUrlForRegisteredUserWithIdentityRequest {
    AwsAccountId: string;
    SessionLifetimeInMinutes?: number | undefined;
    ExperienceConfiguration: RegisteredUserEmbeddingExperienceConfiguration;
    AllowedDomains?: string[] | undefined;
}
export interface GenerateEmbedUrlForRegisteredUserWithIdentityResponse {
    EmbedUrl: string | redacted.Redacted<string>;
    Status: number;
    RequestId: string;
}
export type EmbeddingIdentityType = "IAM" | "QUICKSIGHT" | "ANONYMOUS" | (string & {});
export type AdditionalDashboardIdList = string[];
export interface GetDashboardEmbedUrlRequest {
    AwsAccountId: string;
    DashboardId: string;
    IdentityType: EmbeddingIdentityType;
    SessionLifetimeInMinutes?: number | undefined;
    UndoRedoDisabled?: boolean | undefined;
    ResetDisabled?: boolean | undefined;
    StatePersistenceEnabled?: boolean | undefined;
    UserArn?: string | undefined;
    Namespace?: string | undefined;
    AdditionalDashboardIds?: string[] | undefined;
}
export interface GetDashboardEmbedUrlResponse {
    EmbedUrl?: string | redacted.Redacted<string> | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface GetFlowMetadataInput {
    AwsAccountId: string;
    FlowId: string;
}
export interface GetFlowMetadataOutput {
    Arn: string;
    FlowId: string;
    Name: string;
    Description?: string | undefined;
    PublishState?: FlowPublishState | undefined;
    UserCount?: number | undefined;
    RunCount?: number | undefined;
    CreatedTime: Date;
    LastUpdatedTime?: Date | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface GetFlowPermissionsInput {
    AwsAccountId: string;
    FlowId: string;
}
export interface GetFlowPermissionsOutput {
    Arn: string;
    FlowId: string;
    Permissions: Permission[];
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type UserIdentifier = {
    UserName: string | redacted.Redacted<string>;
    Email?: undefined;
    UserArn?: undefined;
} | {
    UserName?: undefined;
    Email: string | redacted.Redacted<string>;
    UserArn?: undefined;
} | {
    UserName?: undefined;
    Email?: undefined;
    UserArn: string;
};
export type Region = string;
export interface GetIdentityContextRequest {
    AwsAccountId: string;
    UserIdentifier: UserIdentifier;
    Namespace?: string | undefined;
    SessionExpiresAt?: Date | undefined;
    ContextRegion?: string | undefined;
}
export type StatusCode2 = number;
export interface GetIdentityContextResponse {
    Status: number;
    RequestId: string;
    Context?: string | undefined;
}
export type EntryPoint = string;
export interface GetSessionEmbedUrlRequest {
    AwsAccountId: string;
    EntryPoint?: string | undefined;
    SessionLifetimeInMinutes?: number | undefined;
    UserArn?: string | undefined;
}
export interface GetSessionEmbedUrlResponse {
    EmbedUrl?: string | redacted.Redacted<string> | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListActionConnectorsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ActionConnectorSummary {
    Arn: string;
    ActionConnectorId: string;
    Type: ActionConnectorType;
    Name: string | redacted.Redacted<string>;
    CreatedTime?: Date | undefined;
    LastUpdatedTime: Date;
    Status?: ResourceStatus | undefined;
    Error?: ActionConnectorError | undefined;
}
export type ActionConnectorSummaryList = ActionConnectorSummary[];
export interface ListActionConnectorsResponse {
    ActionConnectorSummaries: ActionConnectorSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type ListAgentsRequestMaxResultsInteger = number;
export interface ListAgentsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface AgentSummary {
    Arn: string;
    AgentId: string;
    Name: string;
    Description?: string | undefined;
    CreatedAt: Date;
    UpdatedAt: Date;
    IconId?: string | undefined;
}
export type AgentSummaries = AgentSummary[];
export interface ListAgentsResponse {
    RequestId?: string | undefined;
    AgentSummaries: AgentSummary[];
    NextToken?: string | undefined;
}
export interface ListAnalysesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AnalysisSummary {
    Arn?: string | undefined;
    AnalysisId?: string | undefined;
    Name?: string | undefined;
    Status?: ResourceStatus | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type AnalysisSummaryList = AnalysisSummary[];
export interface ListAnalysesResponse {
    AnalysisSummaryList?: AnalysisSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type PaginationToken = string;
export interface ListApprovalPoliciesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ApprovalPolicyList = ApprovalPolicy[];
export interface ListApprovalPoliciesResponse {
    Policies: ApprovalPolicy[];
    NextToken?: string | undefined;
}
export type NextToken = string;
export interface ListAppsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AppSummaryList = AppSummary[];
export interface ListAppsResponse {
    AppSummaryList: AppSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export interface ListAssetBundleExportJobsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AssetBundleExportJobSummary {
    JobStatus?: AssetBundleExportJobStatus | undefined;
    Arn?: string | undefined;
    CreatedTime?: Date | undefined;
    AssetBundleExportJobId?: string | undefined;
    IncludeAllDependencies?: boolean | undefined;
    ExportFormat?: AssetBundleExportFormat | undefined;
    IncludePermissions?: boolean | undefined;
    IncludeTags?: boolean | undefined;
}
export type AssetBundleExportJobSummaryList = AssetBundleExportJobSummary[];
export interface ListAssetBundleExportJobsResponse {
    AssetBundleExportJobSummaryList?: AssetBundleExportJobSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListAssetBundleImportJobsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AssetBundleImportJobSummary {
    JobStatus?: AssetBundleImportJobStatus | undefined;
    Arn?: string | undefined;
    CreatedTime?: Date | undefined;
    AssetBundleImportJobId?: string | undefined;
    FailureAction?: AssetBundleImportFailureAction | undefined;
}
export type AssetBundleImportJobSummaryList = AssetBundleImportJobSummary[];
export interface ListAssetBundleImportJobsResponse {
    AssetBundleImportJobSummaryList?: AssetBundleImportJobSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListBrandsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface BrandSummary {
    Arn?: string | undefined;
    BrandId?: string | undefined;
    BrandName?: string | undefined;
    Description?: string | undefined;
    BrandStatus?: BrandStatus | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type BrandSummaryList = BrandSummary[];
export interface ListBrandsResponse {
    NextToken?: string | undefined;
    Brands?: BrandSummary[] | undefined;
}
export interface ListCustomPermissionsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type CustomPermissionsList = CustomPermissions[];
export interface ListCustomPermissionsResponse {
    Status?: number | undefined;
    CustomPermissionsList?: CustomPermissions[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export interface ListDashboardsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DashboardSummary {
    Arn?: string | undefined;
    DashboardId?: string | undefined;
    Name?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    PublishedVersionNumber?: number | undefined;
    LastPublishedTime?: Date | undefined;
}
export type DashboardSummaryList = DashboardSummary[];
export interface ListDashboardsResponse {
    DashboardSummaryList?: DashboardSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListDashboardVersionsRequest {
    AwsAccountId: string;
    DashboardId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DashboardVersionSummary {
    Arn?: string | undefined;
    CreatedTime?: Date | undefined;
    VersionNumber?: number | undefined;
    Status?: ResourceStatus | undefined;
    SourceEntityArn?: string | undefined;
    Description?: string | undefined;
}
export type DashboardVersionSummaryList = DashboardVersionSummary[];
export interface ListDashboardVersionsResponse {
    DashboardVersionSummaryList?: DashboardVersionSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListDataSetsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type RowLevelPermissionDataSetMap = {
    [key: string]: RowLevelPermissionDataSet | undefined;
};
export interface DataSetSummary {
    Arn?: string | undefined;
    DataSetId?: string | undefined;
    Name?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    ImportMode?: DataSetImportMode | undefined;
    RowLevelPermissionDataSet?: RowLevelPermissionDataSet | undefined;
    RowLevelPermissionDataSetMap?: {
        [key: string]: RowLevelPermissionDataSet | undefined;
    } | undefined;
    RowLevelPermissionTagConfigurationApplied?: boolean | undefined;
    ColumnLevelPermissionRulesApplied?: boolean | undefined;
    UseAs?: DataSetUseAs | undefined;
}
export type DataSetSummaryList = DataSetSummary[];
export interface ListDataSetsResponse {
    DataSetSummaries?: DataSetSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListDataSourcesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type DataSourceList = DataSource[];
export interface ListDataSourcesResponse {
    DataSources?: DataSource[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListDlpSettingsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DlpSettingSummary {
    DlpSettingId: string;
    Name: string;
    Arn: string;
    Status: DlpSettingStatus;
    ProviderType: DlpProviderType;
    CreatedAt: Date;
    UpdatedAt: Date;
}
export type DlpSettingSummaryList = DlpSettingSummary[];
export interface ListDlpSettingsResponse {
    DlpSettingSummaries: DlpSettingSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export type FlowMaxResults = number;
export interface ListFlowsInput {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FlowSummary {
    Arn: string;
    FlowId: string;
    Name: string;
    Description?: string | undefined;
    CreatedTime: Date;
    CreatedBy?: string | undefined;
    LastUpdatedTime?: Date | undefined;
    LastUpdatedBy?: string | undefined;
    PublishState?: FlowPublishState | undefined;
    RunCount?: number | undefined;
    UserCount?: number | undefined;
    LastPublishedBy?: string | undefined;
    LastPublishedAt?: Date | undefined;
}
export type FlowSummaryList = FlowSummary[];
export interface ListFlowsOutput {
    FlowSummaryList?: FlowSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListFolderMembersRequest {
    AwsAccountId: string;
    FolderId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface MemberIdArnPair {
    MemberId?: string | undefined;
    MemberArn?: string | undefined;
}
export type FolderMemberList = MemberIdArnPair[];
export interface ListFolderMembersResponse {
    Status?: number | undefined;
    FolderMemberList?: MemberIdArnPair[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export interface ListFoldersRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FolderSummary {
    Arn?: string | undefined;
    FolderId?: string | undefined;
    Name?: string | undefined;
    FolderType?: FolderType | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    SharingModel?: SharingModel | undefined;
}
export type FolderSummaryList = FolderSummary[];
export interface ListFoldersResponse {
    Status?: number | undefined;
    FolderSummaryList?: FolderSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export interface ListFoldersForResourceRequest {
    AwsAccountId: string;
    ResourceArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type FoldersForResourceArnList = string[];
export interface ListFoldersForResourceResponse {
    Status?: number | undefined;
    Folders?: string[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export interface ListGroupMembershipsRequest {
    GroupName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AwsAccountId: string;
    Namespace: string;
}
export type GroupMemberList = GroupMember[];
export interface ListGroupMembershipsResponse {
    GroupMemberList?: GroupMember[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListGroupsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Namespace: string;
}
export type GroupList = Group[];
export interface ListGroupsResponse {
    GroupList?: Group[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListIAMPolicyAssignmentsRequest {
    AwsAccountId: string;
    AssignmentStatus?: AssignmentStatus | undefined;
    Namespace: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface IAMPolicyAssignmentSummary {
    AssignmentName?: string | undefined;
    AssignmentStatus?: AssignmentStatus | undefined;
}
export type IAMPolicyAssignmentSummaryList = IAMPolicyAssignmentSummary[];
export interface ListIAMPolicyAssignmentsResponse {
    IAMPolicyAssignments?: IAMPolicyAssignmentSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListIAMPolicyAssignmentsForUserRequest {
    AwsAccountId: string;
    UserName: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Namespace: string;
}
export interface ActiveIAMPolicyAssignment {
    AssignmentName?: string | undefined;
    PolicyArn?: string | undefined;
}
export type ActiveIAMPolicyAssignmentList = ActiveIAMPolicyAssignment[];
export interface ListIAMPolicyAssignmentsForUserResponse {
    ActiveAssignments?: ActiveIAMPolicyAssignment[] | undefined;
    RequestId?: string | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
}
export type ListIdentityPropagationMaxResults = number;
export interface ListIdentityPropagationConfigsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AuthorizedTargetsList = string[];
export interface AuthorizedTargetsByService {
    Service?: ServiceType | undefined;
    AuthorizedTargets?: string[] | undefined;
}
export type AuthorizedTargetsByServices = AuthorizedTargetsByService[];
export interface ListIdentityPropagationConfigsResponse {
    Services?: AuthorizedTargetsByService[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type IngestionMaxResults = number;
export interface ListIngestionsRequest {
    DataSetId: string;
    NextToken?: string | undefined;
    AwsAccountId: string;
    MaxResults?: number | undefined;
}
export type Ingestions = Ingestion[];
export interface ListIngestionsResponse {
    Ingestions?: Ingestion[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListKnowledgeBasesRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface KnowledgeBaseSummary {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    Name: string;
    Status: DataSetStatus;
    DataSourceArn: string;
    Type?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    KnowledgeBaseSizeBytes?: number | undefined;
    DocumentCount?: number | undefined;
    PrimaryOwnerArn?: string | undefined;
    PrimaryOwnerUsername?: string | redacted.Redacted<string> | undefined;
}
export type KnowledgeBaseSummaries = KnowledgeBaseSummary[];
export interface ListKnowledgeBasesResponse {
    KnowledgeBaseSummaries: KnowledgeBaseSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type ListLimitsProfilesRequestMaxResultsInteger = number;
export interface ListLimitsProfilesRequest {
    accountId: string;
    resourceType?: ResourceType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type LimitsProfileList = LimitsProfile[];
export interface ListLimitsProfilesResponse {
    profiles: LimitsProfile[];
    nextToken?: string | undefined;
}
export interface ListNamespacesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type Namespaces = NamespaceInfoV2[];
export interface ListNamespacesResponse {
    Namespaces?: NamespaceInfoV2[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListOAuthClientApplicationsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface OAuthClientApplicationSummary {
    OAuthClientApplicationId?: string | undefined;
    Name?: string | undefined;
    OAuthClientAuthenticationType?: OAuthClientAuthenticationType | undefined;
    DataSourceType?: DataSourceType | undefined;
    IdentityProviderVpcConnectionProperties?: VpcConnectionProperties | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
    Arn?: string | undefined;
}
export type OAuthClientApplicationSummaryList = OAuthClientApplicationSummary[];
export interface ListOAuthClientApplicationsResponse {
    OAuthClientApplications?: OAuthClientApplicationSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListRefreshSchedulesRequest {
    AwsAccountId: string;
    DataSetId: string;
}
export type RefreshSchedules = RefreshSchedule[];
export interface ListRefreshSchedulesResponse {
    RefreshSchedules?: RefreshSchedule[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListRoleMembershipsRequest {
    Role: Role;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    AwsAccountId: string;
    Namespace: string;
}
export interface ListRoleMembershipsResponse {
    MembersList?: string[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListSelfUpgradesRequest {
    AwsAccountId: string;
    Namespace: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type SelfUpgradeRequestStatus = "PENDING" | "APPROVED" | "DENIED" | "UPDATE_FAILED" | "VERIFY_FAILED" | (string & {});
export interface SelfUpgradeRequestDetail {
    UpgradeRequestId?: string | undefined;
    UserName?: string | undefined;
    OriginalRole?: UserRole | undefined;
    RequestedRole?: UserRole | undefined;
    RequestNote?: string | undefined;
    CreationTime?: number | undefined;
    RequestStatus?: SelfUpgradeRequestStatus | undefined;
    lastUpdateAttemptTime?: number | undefined;
    lastUpdateFailureReason?: string | undefined;
}
export type SelfUpgradeRequestDetailList = SelfUpgradeRequestDetail[];
export interface ListSelfUpgradesResponse {
    SelfUpgradeRequestDetails?: SelfUpgradeRequestDetail[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListSpaceResourcesRequest {
    AwsAccountId: string;
    SpaceId: string;
}
export interface SpaceResourceSummary {
    ResourceType: SpaceQuickSightResourceType;
    ResourceDetails: SpaceQuickSightResourceDetails;
    ResourceName?: string | undefined;
    UpdatedAt?: Date | undefined;
}
export type SpaceResourceSummaries = SpaceResourceSummary[];
export interface ListSpaceResourcesResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    SpaceResources: SpaceResourceSummary[];
    RequestId?: string | undefined;
}
export type SpacesMaxResults = number;
export interface ListSpacesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SpaceSummary {
    spaceId: string;
    spaceArn?: string | undefined;
    name?: string | undefined;
    description?: string | redacted.Redacted<string> | undefined;
    updatedAt?: Date | undefined;
    consumedSourceSize?: number | undefined;
    consumedSourceDocCount?: number | undefined;
    createdAt?: Date | undefined;
    createdBy?: string | undefined;
    createdByArn?: string | undefined;
    resourcesCount?: number | undefined;
}
export type SpaceSummaries = SpaceSummary[];
export interface ListSpacesResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    SpaceSummaries: SpaceSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListTemplateAliasesRequest {
    AwsAccountId: string;
    TemplateId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type TemplateAliasList = TemplateAlias[];
export interface ListTemplateAliasesResponse {
    TemplateAliasList?: TemplateAlias[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListTemplatesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TemplateSummary {
    Arn?: string | undefined;
    TemplateId?: string | undefined;
    Name?: string | undefined;
    LatestVersionNumber?: number | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListTemplatesResponse {
    TemplateSummaryList?: TemplateSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListTemplateVersionsRequest {
    AwsAccountId: string;
    TemplateId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TemplateVersionSummary {
    Arn?: string | undefined;
    VersionNumber?: number | undefined;
    CreatedTime?: Date | undefined;
    Status?: ResourceStatus | undefined;
    Description?: string | undefined;
}
export type TemplateVersionSummaryList = TemplateVersionSummary[];
export interface ListTemplateVersionsResponse {
    TemplateVersionSummaryList?: TemplateVersionSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListThemeAliasesRequest {
    AwsAccountId: string;
    ThemeId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ThemeAliasList = ThemeAlias[];
export interface ListThemeAliasesResponse {
    ThemeAliasList?: ThemeAlias[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
    NextToken?: string | undefined;
}
export interface ListThemesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Type?: ThemeType | undefined;
}
export interface ThemeSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
    ThemeId?: string | undefined;
    LatestVersionNumber?: number | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type ThemeSummaryList = ThemeSummary[];
export interface ListThemesResponse {
    ThemeSummaryList?: ThemeSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListThemeVersionsRequest {
    AwsAccountId: string;
    ThemeId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ThemeVersionSummary {
    VersionNumber?: number | undefined;
    Arn?: string | undefined;
    Description?: string | undefined;
    CreatedTime?: Date | undefined;
    Status?: ResourceStatus | undefined;
}
export type ThemeVersionSummaryList = ThemeVersionSummary[];
export interface ListThemeVersionsResponse {
    ThemeVersionSummaryList?: ThemeVersionSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListTopicRefreshSchedulesRequest {
    AwsAccountId: string;
    TopicId: string;
}
export interface TopicRefreshScheduleSummary {
    DatasetId?: string | undefined;
    DatasetArn?: string | undefined;
    DatasetName?: string | undefined;
    RefreshSchedule?: TopicRefreshSchedule | undefined;
}
export type TopicRefreshScheduleSummaries = TopicRefreshScheduleSummary[];
export interface ListTopicRefreshSchedulesResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    RefreshSchedules?: TopicRefreshScheduleSummary[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListTopicReviewedAnswersRequest {
    AwsAccountId: string;
    TopicId: string;
}
export interface TopicReviewedAnswer {
    Arn?: string | undefined;
    AnswerId: string;
    DatasetArn: string;
    Question: string | redacted.Redacted<string>;
    Mir?: TopicIR | undefined;
    PrimaryVisual?: TopicVisual | undefined;
    Template?: TopicTemplate | undefined;
}
export type TopicReviewedAnswers = TopicReviewedAnswer[];
export interface ListTopicReviewedAnswersResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    Answers?: TopicReviewedAnswer[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface ListTopicsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TopicSummary {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    Name?: string | undefined;
    UserExperienceVersion?: TopicUserExperienceVersion | undefined;
}
export type TopicSummaries = TopicSummary[];
export interface ListTopicsResponse {
    TopicsSummaries?: TopicSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListTopicsV2Request {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TopicV2Summary {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    Name?: string | undefined;
}
export type TopicV2Summaries = TopicV2Summary[];
export interface ListTopicsV2Response {
    TopicSummaryList?: TopicV2Summary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListUserGroupsRequest {
    UserName: string;
    AwsAccountId: string;
    Namespace: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListUserGroupsResponse {
    GroupList?: Group[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface ListUsersRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Namespace: string;
}
export type UserList = User[];
export interface ListUsersResponse {
    UserList?: User[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type FilterValue = string;
export interface UserNameOrEmailFilter {
    prefix: string;
}
export type CapacityBytesRangeFilterMinBytesLong = number;
export type CapacityBytesRangeFilterMaxBytesLong = number;
export interface CapacityBytesRangeFilter {
    minBytes?: number | undefined;
    maxBytes?: number | undefined;
}
export type UserIndexCapacityFilter = {
    userNameOrEmail: UserNameOrEmailFilter;
    totalCapacityBytes?: undefined;
} | {
    userNameOrEmail?: undefined;
    totalCapacityBytes: CapacityBytesRangeFilter;
};
export type UserIndexCapacityFilters = UserIndexCapacityFilter[];
export type UserIndexCapacitySortBy = "TOTAL_CAPACITY_BYTES" | (string & {});
export type UserIndexCapacitySortOrder = "ASC" | "DESC" | (string & {});
export type ListUsersIndexCapacityRequestMaxResultsInteger = number;
export interface ListUsersIndexCapacityRequest {
    awsAccountId: string;
    namespace?: string | undefined;
    filters?: UserIndexCapacityFilter[] | undefined;
    sortBy?: UserIndexCapacitySortBy | undefined;
    sortOrder?: UserIndexCapacitySortOrder | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type LongValue = number;
export type IntegerValue = number;
export interface UserIndexCapacity {
    userArn?: string | undefined;
    userName?: string | undefined;
    email?: string | undefined;
    role?: string | undefined;
    totalCapacityBytes?: number | undefined;
    totalKBCapacityBytes?: number | undefined;
    totalSpaceCapacityBytes?: number | undefined;
    kbCount?: number | undefined;
    spaceCount?: number | undefined;
}
export type UserIndexCapacityList = UserIndexCapacity[];
export interface ListUsersIndexCapacityResponse {
    users?: UserIndexCapacity[] | undefined;
    nextToken?: string | undefined;
    requestId?: string | undefined;
}
export interface ListVPCConnectionsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface VPCConnectionSummary {
    VPCConnectionId?: string | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    VPCId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    DnsResolvers?: string[] | undefined;
    Status?: VPCConnectionResourceStatus | undefined;
    AvailabilityStatus?: VPCConnectionAvailabilityStatus | undefined;
    NetworkInterfaces?: NetworkInterface[] | undefined;
    RoleArn?: string | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type VPCConnectionSummaryList = VPCConnectionSummary[];
export interface ListVPCConnectionsResponse {
    VPCConnectionSummaries?: VPCConnectionSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type QAQueryText = string | redacted.Redacted<string>;
export type IncludeQuickSightQIndex = "INCLUDE" | "EXCLUDE" | (string & {});
export type IncludeGeneratedAnswer = "INCLUDE" | "EXCLUDE" | (string & {});
export type MaxTopicsToConsider = number;
export interface PredictQAResultsRequest {
    AwsAccountId: string;
    QueryText: string | redacted.Redacted<string>;
    IncludeQuickSightQIndex?: IncludeQuickSightQIndex | undefined;
    IncludeGeneratedAnswer?: IncludeGeneratedAnswer | undefined;
    MaxTopicsToConsider?: number | undefined;
}
export type QAResultType = "DASHBOARD_VISUAL" | "GENERATED_ANSWER" | "NO_ANSWER" | (string & {});
export type VisualTitle = string;
export type VisualSubtitle = string;
export type QAUrl = string;
export interface DashboardVisualResult {
    DashboardId?: string | undefined;
    DashboardName?: string | undefined;
    SheetId?: string | undefined;
    SheetName?: string | undefined;
    VisualId?: string | undefined;
    VisualTitle?: string | undefined;
    VisualSubtitle?: string | undefined;
    DashboardUrl?: string | undefined;
}
export type GeneratedAnswerStatus = "ANSWER_GENERATED" | "ANSWER_RETRIEVED" | "ANSWER_DOWNGRADE" | (string & {});
export type QuestionId = string;
export interface GeneratedAnswerResult {
    QuestionText?: string | redacted.Redacted<string> | undefined;
    AnswerStatus?: GeneratedAnswerStatus | undefined;
    TopicId?: string | undefined;
    TopicName?: string | undefined;
    Restatement?: string | redacted.Redacted<string> | undefined;
    QuestionId?: string | undefined;
    AnswerId?: string | undefined;
    QuestionUrl?: string | undefined;
}
export interface QAResult {
    ResultType?: QAResultType | undefined;
    DashboardVisual?: DashboardVisualResult | undefined;
    GeneratedAnswer?: GeneratedAnswerResult | undefined;
}
export type QAResults = QAResult[];
export interface PredictQAResultsResponse {
    PrimaryResult?: QAResult | undefined;
    AdditionalResults?: QAResult[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface PutDataSetRefreshPropertiesRequest {
    AwsAccountId: string;
    DataSetId: string;
    DataSetRefreshProperties: DataSetRefreshProperties;
}
export interface PutDataSetRefreshPropertiesResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type RoleSessionName = string;
export interface RegisterUserRequest {
    IdentityType: IdentityType;
    Email: string;
    UserRole: UserRole;
    IamArn?: string | undefined;
    SessionName?: string | undefined;
    AwsAccountId: string;
    Namespace: string;
    UserName?: string | undefined;
    CustomPermissionsName?: string | undefined;
    ExternalLoginFederationProviderType?: string | undefined;
    CustomFederationProviderUrl?: string | undefined;
    ExternalLoginId?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface RegisterUserResponse {
    User?: User | undefined;
    UserInvitationUrl?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface RestoreAnalysisRequest {
    AwsAccountId: string;
    AnalysisId: string;
    RestoreToFolders?: boolean | undefined;
}
export interface RestoreAnalysisResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    AnalysisId?: string | undefined;
    RequestId?: string | undefined;
    RestorationFailedFolderArns?: string[] | undefined;
}
export type SearchActionConnectorsRequestMaxResultsInteger = number;
export type ActionConnectorSearchFilterNameEnum = "ACTION_CONNECTOR_NAME" | "ACTION_CONNECTOR_TYPE" | "QUICKSIGHT_OWNER" | "QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | (string & {});
export type FilterOperator = "StringEquals" | "StringLike" | (string & {});
export interface ActionConnectorSearchFilter {
    Name: ActionConnectorSearchFilterNameEnum;
    Operator: FilterOperator;
    Value: string;
}
export type ActionConnectorSearchFilterList = ActionConnectorSearchFilter[];
export interface SearchActionConnectorsRequest {
    AwsAccountId: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Filters: ActionConnectorSearchFilter[];
}
export interface SearchActionConnectorsResponse {
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    ActionConnectorSummaries?: ActionConnectorSummary[] | undefined;
}
export type AgentOwnershipFilterAttribute = "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "AGENT_NAME" | (string & {});
export type ComparisonOperator = "StringEquals" | "StringLike" | (string & {});
export interface AgentSearchFilter {
    Name?: AgentOwnershipFilterAttribute | undefined;
    Operator?: ComparisonOperator | undefined;
    Value?: string | undefined;
}
export type AgentSearchFilterList = AgentSearchFilter[];
export type AgentsMaxResults = number;
export interface SearchAgentsRequest {
    AwsAccountId: string;
    Filters: AgentSearchFilter[];
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type AgentSummaryList = AgentSummary[];
export interface SearchAgentsResponse {
    AgentSummaries?: AgentSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export type AnalysisFilterAttribute = "QUICKSIGHT_USER" | "QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "ANALYSIS_NAME" | (string & {});
export interface AnalysisSearchFilter {
    Operator?: FilterOperator | undefined;
    Name?: AnalysisFilterAttribute | undefined;
    Value?: string | undefined;
}
export type AnalysisSearchFilterList = AnalysisSearchFilter[];
export interface SearchAnalysesRequest {
    AwsAccountId: string;
    Filters: AnalysisSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchAnalysesResponse {
    AnalysisSummaryList?: AnalysisSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type SearchAppsFilterName = "APP_ID" | "APP_NAME" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | (string & {});
export interface SearchAppsFilter {
    Name: SearchAppsFilterName;
    Operator: FilterOperator;
    Value: string;
}
export type SearchAppsFilterList = SearchAppsFilter[];
export interface SearchAppsRequest {
    AwsAccountId: string;
    Filters: SearchAppsFilter[];
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface SearchAppsResponse {
    AppSummaryList: AppSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export type DashboardFilterAttribute = "QUICKSIGHT_USER" | "QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "DASHBOARD_NAME" | (string & {});
export interface DashboardSearchFilter {
    Operator: FilterOperator;
    Name?: DashboardFilterAttribute | undefined;
    Value?: string | undefined;
}
export type DashboardSearchFilterList = DashboardSearchFilter[];
export interface SearchDashboardsRequest {
    AwsAccountId: string;
    Filters: DashboardSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchDashboardsResponse {
    DashboardSummaryList?: DashboardSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type DataSetFilterAttribute = "QUICKSIGHT_VIEWER_OR_OWNER" | "QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "DATASET_NAME" | (string & {});
export interface DataSetSearchFilter {
    Operator: FilterOperator;
    Name: DataSetFilterAttribute;
    Value: string;
}
export type DataSetSearchFilterList = DataSetSearchFilter[];
export interface SearchDataSetsRequest {
    AwsAccountId: string;
    Filters: DataSetSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchDataSetsResponse {
    DataSetSummaries?: DataSetSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type DataSourceFilterAttribute = "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "DATASOURCE_NAME" | (string & {});
export interface DataSourceSearchFilter {
    Operator: FilterOperator;
    Name: DataSourceFilterAttribute;
    Value: string;
}
export type DataSourceSearchFilterList = DataSourceSearchFilter[];
export interface SearchDataSourcesRequest {
    AwsAccountId: string;
    Filters: DataSourceSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface DataSourceSummary {
    Arn?: string | undefined;
    DataSourceId?: string | undefined;
    Name?: string | undefined;
    Type?: DataSourceType | undefined;
    CreatedTime?: Date | undefined;
    LastUpdatedTime?: Date | undefined;
}
export type DataSourceSummaryList = DataSourceSummary[];
export interface SearchDataSourcesResponse {
    DataSourceSummaries?: DataSourceSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type FieldName = "assetName" | "assetDescription" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | (string & {});
export type SearchFilterOperator = "StringEquals" | "StringLike" | (string & {});
export interface SearchFlowsFilter {
    Name: FieldName;
    Operator: SearchFilterOperator;
    Value: string;
}
export type SearchFlowsFilterList = SearchFlowsFilter[];
export interface SearchFlowsInput {
    AwsAccountId: string;
    Filters: SearchFlowsFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchFlowsOutput {
    FlowSummaryList: FlowSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type FolderFilterAttribute = "PARENT_FOLDER_ARN" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "QUICKSIGHT_OWNER" | "QUICKSIGHT_VIEWER_OR_OWNER" | "FOLDER_NAME" | (string & {});
export interface FolderSearchFilter {
    Operator?: FilterOperator | undefined;
    Name?: FolderFilterAttribute | undefined;
    Value?: string | undefined;
}
export type FolderSearchFilterList = FolderSearchFilter[];
export interface SearchFoldersRequest {
    AwsAccountId: string;
    Filters: FolderSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchFoldersResponse {
    Status?: number | undefined;
    FolderSummaryList?: FolderSummary[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export type GroupFilterOperator = "StartsWith" | (string & {});
export type GroupFilterAttribute = "GROUP_NAME" | (string & {});
export interface GroupSearchFilter {
    Operator: GroupFilterOperator;
    Name: GroupFilterAttribute;
    Value: string;
}
export type GroupSearchFilterList = GroupSearchFilter[];
export interface SearchGroupsRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Namespace: string;
    Filters: GroupSearchFilter[];
}
export interface SearchGroupsResponse {
    GroupList?: Group[] | undefined;
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type KnowledgeBaseSearchFilterName = "KNOWLEDGE_BASE_ID" | "KNOWLEDGE_BASE_NAME" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "KNOWLEDGE_BASE_SIZE_BYTES" | "PRIMARY_OWNER" | "DATASOURCE_ARN" | (string & {});
export type KnowledgeBaseSearchOperator = "STRING_EQUALS" | "STRING_LIKE" | "GREATER_THAN_OR_EQUALS" | "LESS_THAN_OR_EQUALS" | (string & {});
export interface KnowledgeBaseSearchFilter {
    name: KnowledgeBaseSearchFilterName;
    operator: KnowledgeBaseSearchOperator;
    value: string;
}
export type KnowledgeBaseSearchFilters = KnowledgeBaseSearchFilter[];
export type KnowledgeBaseSortByField = "KNOWLEDGE_BASE_SIZE_BYTES" | "CREATED_AT" | (string & {});
export type SortOrder = "ASC" | "DESC" | (string & {});
export interface KnowledgeBaseSortBy {
    sortByField: KnowledgeBaseSortByField;
    sortOrder: SortOrder;
}
export interface SearchKnowledgeBasesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: KnowledgeBaseSearchFilter[] | undefined;
    SortBy?: KnowledgeBaseSortBy | undefined;
}
export interface SearchKnowledgeBasesResponse {
    KnowledgeBaseSummaries: KnowledgeBaseSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type SpaceQuickSightSearchFilterName = "SPACE_ID" | "SPACE_NAME" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "CONTRIBUTED_BY" | "CONSUMED_SOURCE_SIZE" | "CREATED_BY" | (string & {});
export type SpaceSearchOperator = "STRING_EQUALS" | "STRING_LIKE" | "NUMBER_RANGE" | (string & {});
export interface SpaceQuicksightSearchFilter {
    name: SpaceQuickSightSearchFilterName;
    operator: SpaceSearchOperator;
    value: string;
}
export type SpaceQuicksightSearchFilters = SpaceQuicksightSearchFilter[];
export interface SearchSpacesRequest {
    AwsAccountId: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters: SpaceQuicksightSearchFilter[];
}
export interface SearchSpacesResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    SpaceSummaries: SpaceSummary[];
    NextToken?: string | undefined;
    RequestId?: string | undefined;
}
export type TopicFilterOperator = "StringEquals" | "StringLike" | (string & {});
export type TopicFilterAttribute = "QUICKSIGHT_USER" | "QUICKSIGHT_VIEWER_OR_OWNER" | "DIRECT_QUICKSIGHT_VIEWER_OR_OWNER" | "QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_OWNER" | "DIRECT_QUICKSIGHT_SOLE_OWNER" | "TOPIC_NAME" | (string & {});
export interface TopicSearchFilter {
    Operator: TopicFilterOperator;
    Name: TopicFilterAttribute;
    Value: string | redacted.Redacted<string>;
}
export type TopicSearchFilterList = TopicSearchFilter[];
export interface SearchTopicsRequest {
    AwsAccountId: string;
    Filters: TopicSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchTopicsResponse {
    TopicSummaryList?: TopicSummary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface SearchTopicsV2Request {
    AwsAccountId: string;
    Filters: TopicSearchFilter[];
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SearchTopicsV2Response {
    TopicSummaryList?: TopicV2Summary[] | undefined;
    NextToken?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface StartAssetBundleExportJobRequest {
    AwsAccountId: string;
    AssetBundleExportJobId: string;
    ResourceArns: string[];
    IncludeAllDependencies?: boolean | undefined;
    ExportFormat: AssetBundleExportFormat;
    CloudFormationOverridePropertyConfiguration?: AssetBundleCloudFormationOverridePropertyConfiguration | undefined;
    IncludePermissions?: boolean | undefined;
    IncludeTags?: boolean | undefined;
    ValidationStrategy?: AssetBundleExportJobValidationStrategy | undefined;
    IncludeFolderMemberships?: boolean | undefined;
    IncludeFolderMembers?: IncludeFolderMembers | undefined;
}
export interface StartAssetBundleExportJobResponse {
    Arn?: string | undefined;
    AssetBundleExportJobId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type AssetBundleImportBodyBlob = Uint8Array | redacted.Redacted<Uint8Array>;
export interface AssetBundleImportSource {
    Body?: Uint8Array | redacted.Redacted<Uint8Array> | undefined;
    S3Uri?: string | undefined;
}
export interface StartAssetBundleImportJobRequest {
    AwsAccountId: string;
    AssetBundleImportJobId: string;
    AssetBundleImportSource: AssetBundleImportSource;
    OverrideParameters?: AssetBundleImportJobOverrideParameters | undefined;
    FailureAction?: AssetBundleImportFailureAction | undefined;
    OverridePermissions?: AssetBundleImportJobOverridePermissions | undefined;
    OverrideTags?: AssetBundleImportJobOverrideTags | undefined;
    OverrideValidationStrategy?: AssetBundleImportJobOverrideValidationStrategy | undefined;
}
export interface StartAssetBundleImportJobResponse {
    Arn?: string | undefined;
    AssetBundleImportJobId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface StartAutomationJobRequest {
    AwsAccountId: string;
    AutomationGroupId: string;
    AutomationId: string;
    InputPayload?: string | redacted.Redacted<string> | undefined;
}
export interface StartAutomationJobResponse {
    Arn: string;
    JobId: string;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface SnapshotAnonymousUser {
    RowLevelPermissionTags?: SessionTag[] | undefined;
}
export type SnapshotAnonymousUserList = SnapshotAnonymousUser[];
export interface SnapshotUserConfiguration {
    AnonymousUsers?: SnapshotAnonymousUser[] | undefined;
}
export interface StartDashboardSnapshotJobRequest {
    AwsAccountId: string;
    DashboardId: string;
    SnapshotJobId: string;
    UserConfiguration?: SnapshotUserConfiguration | undefined;
    SnapshotConfiguration: SnapshotConfiguration;
}
export interface StartDashboardSnapshotJobResponse {
    Arn?: string | undefined;
    SnapshotJobId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface StartDashboardSnapshotJobScheduleRequest {
    AwsAccountId: string;
    DashboardId: string;
    ScheduleId: string;
}
export interface StartDashboardSnapshotJobScheduleResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateAccountCustomizationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
    AccountCustomization: AccountCustomization;
}
export interface UpdateAccountCustomizationResponse {
    Arn?: string | undefined;
    AwsAccountId?: string | undefined;
    Namespace?: string | undefined;
    AccountCustomization?: AccountCustomization | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateAccountCustomPermissionRequest {
    CustomPermissionsName: string;
    AwsAccountId: string;
}
export interface UpdateAccountCustomPermissionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateAccountSettingsRequest {
    AwsAccountId: string;
    DefaultNamespace: string;
    NotificationEmail?: string | undefined;
    TerminationProtectionEnabled?: boolean | undefined;
}
export interface UpdateAccountSettingsResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateActionConnectorRequest {
    AwsAccountId: string;
    ActionConnectorId: string;
    Name: string | redacted.Redacted<string>;
    AuthenticationConfig: AuthConfig;
    Description?: string | redacted.Redacted<string> | undefined;
    VpcConnectionArn?: string | undefined;
}
export interface UpdateActionConnectorResponse {
    Arn?: string | undefined;
    ActionConnectorId?: string | undefined;
    RequestId?: string | undefined;
    UpdateStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
}
export interface UpdateActionConnectorPermissionsRequest {
    AwsAccountId: string;
    ActionConnectorId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateActionConnectorPermissionsResponse {
    Arn?: string | undefined;
    ActionConnectorId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    Permissions?: ResourcePermission[] | undefined;
}
export type UpdateAgentRequestSpacesToAddList = string[];
export type UpdateAgentRequestSpacesToRemoveList = string[];
export type UpdateAgentRequestActionConnectorsToAddList = string[];
export type UpdateAgentRequestActionConnectorsToRemoveList = string[];
export interface UpdateAgentRequest {
    AgentId: string;
    AwsAccountId: string;
    Name: string;
    Description?: string | undefined;
    IconId?: string | undefined;
    StarterPrompts?: string[] | undefined;
    WelcomeMessage?: string | redacted.Redacted<string> | undefined;
    CustomPromptInput?: CustomPromptInput | undefined;
    SpacesToAdd?: string[] | undefined;
    SpacesToRemove?: string[] | undefined;
    ActionConnectorsToAdd?: string[] | undefined;
    ActionConnectorsToRemove?: string[] | undefined;
}
export interface FailedToUpdateAssociation {
    Arn?: string | undefined;
    ErrorMessage?: string | undefined;
    ErrorCode?: string | undefined;
}
export type FailedToUpdateAssociationList = FailedToUpdateAssociation[];
export interface UpdateAgentResponse {
    Arn: string;
    AgentId: string;
    AgentStatus: AgentStatus;
    FailedToAddSpaces?: FailedToUpdateAssociation[] | undefined;
    FailedToRemoveSpaces?: FailedToUpdateAssociation[] | undefined;
    FailedToAddActionConnectors?: FailedToUpdateAssociation[] | undefined;
    FailedToRemoveActionConnectors?: FailedToUpdateAssociation[] | undefined;
    RequestId?: string | undefined;
}
export type UpdateAgentPermissionsRequestGrantPermissionsList = ResourcePermission[];
export type UpdateAgentPermissionsRequestRevokePermissionsList = ResourcePermission[];
export interface UpdateAgentPermissionsRequest {
    AgentId: string;
    AwsAccountId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateAgentPermissionsResponse {
    Arn: string;
    AgentId: string;
    RequestId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
}
export interface UpdateAnalysisRequest {
    AwsAccountId: string;
    AnalysisId: string;
    Name: string;
    Parameters?: Parameters | undefined;
    SourceEntity?: AnalysisSourceEntity | undefined;
    ThemeArn?: string | undefined;
    Definition?: AnalysisDefinition | undefined;
    ValidationStrategy?: ValidationStrategy | undefined;
}
export interface UpdateAnalysisResponse {
    Arn?: string | undefined;
    AnalysisId?: string | undefined;
    UpdateStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateAnalysisPermissionsRequest {
    AwsAccountId: string;
    AnalysisId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateAnalysisPermissionsResponse {
    AnalysisArn?: string | undefined;
    AnalysisId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateApplicationWithTokenExchangeGrantRequest {
    AwsAccountId: string;
    Namespace: string;
}
export interface UpdateApplicationWithTokenExchangeGrantResponse {
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateAppPermissionsRequest {
    AwsAccountId: string;
    AppId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
    Visibility?: AppVisibility | undefined;
}
export interface UpdateAppPermissionsResponse {
    Arn?: string | undefined;
    AppId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Visibility?: AppVisibility | undefined;
    RequestId?: string | undefined;
}
export interface UpdateApprovalPolicyRequest {
    PolicyId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    Actions?: GovernedAction[] | undefined;
    AssetTypes?: AssetType[] | undefined;
    ApplicableTo?: ApplicableTo | undefined;
    ApprovalGroups?: string[] | undefined;
}
export interface UpdateApprovalPolicyResponse {
    Policy: ApprovalPolicy;
}
export interface UpdateBrandRequest {
    AwsAccountId: string;
    BrandId: string;
    BrandDefinition?: BrandDefinition | undefined;
}
export interface UpdateBrandResponse {
    RequestId?: string | undefined;
    BrandDetail?: BrandDetail | undefined;
    BrandDefinition?: BrandDefinition | undefined;
}
export interface UpdateBrandAssignmentRequest {
    AwsAccountId: string;
    BrandArn: string;
}
export interface UpdateBrandAssignmentResponse {
    RequestId?: string | undefined;
    BrandArn?: string | undefined;
}
export interface UpdateBrandPublishedVersionRequest {
    AwsAccountId: string;
    BrandId: string;
    VersionId: string;
}
export interface UpdateBrandPublishedVersionResponse {
    RequestId?: string | undefined;
    VersionId?: string | undefined;
}
export interface UpdateCustomPermissionsRequest {
    AwsAccountId: string;
    CustomPermissionsName: string;
    Capabilities?: Capabilities | undefined;
    Governance?: Governance | undefined;
}
export interface UpdateCustomPermissionsResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    RequestId?: string | undefined;
}
export interface UpdateDashboardRequest {
    AwsAccountId: string;
    DashboardId: string;
    Name: string;
    SourceEntity?: DashboardSourceEntity | undefined;
    Parameters?: Parameters | undefined;
    VersionDescription?: string | undefined;
    DashboardPublishOptions?: DashboardPublishOptions | undefined;
    ThemeArn?: string | undefined;
    Definition?: DashboardVersionDefinition | undefined;
    ValidationStrategy?: ValidationStrategy | undefined;
}
export interface UpdateDashboardResponse {
    Arn?: string | undefined;
    VersionArn?: string | undefined;
    DashboardId?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateDashboardLinksRequest {
    AwsAccountId: string;
    DashboardId: string;
    LinkEntities: string[];
}
export interface UpdateDashboardLinksResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
    DashboardArn?: string | undefined;
    LinkEntities?: string[] | undefined;
}
export type UpdateLinkPermissionList = ResourcePermission[];
export interface UpdateDashboardPermissionsRequest {
    AwsAccountId: string;
    DashboardId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
    GrantLinkPermissions?: ResourcePermission[] | undefined;
    RevokeLinkPermissions?: ResourcePermission[] | undefined;
}
export interface UpdateDashboardPermissionsResponse {
    DashboardArn?: string | undefined;
    DashboardId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
    LinkSharingConfiguration?: LinkSharingConfiguration | undefined;
}
export interface UpdateDashboardPublishedVersionRequest {
    AwsAccountId: string;
    DashboardId: string;
    VersionNumber: number;
}
export interface UpdateDashboardPublishedVersionResponse {
    DashboardId?: string | undefined;
    DashboardArn?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateDashboardsQAConfigurationRequest {
    AwsAccountId: string;
    DashboardsQAStatus: DashboardsQAStatus;
}
export interface UpdateDashboardsQAConfigurationResponse {
    DashboardsQAStatus?: DashboardsQAStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateDataSetRequest {
    AwsAccountId: string;
    DataSetId: string;
    Name: string;
    PhysicalTableMap: {
        [key: string]: PhysicalTable | undefined;
    };
    LogicalTableMap?: {
        [key: string]: LogicalTable | undefined;
    } | undefined;
    ImportMode: DataSetImportMode;
    ColumnGroups?: ColumnGroup[] | undefined;
    FieldFolders?: {
        [key: string]: FieldFolder | undefined;
    } | undefined;
    RowLevelPermissionDataSet?: RowLevelPermissionDataSet | undefined;
    RowLevelPermissionTagConfiguration?: RowLevelPermissionTagConfiguration | undefined;
    ColumnLevelPermissionRules?: ColumnLevelPermissionRule[] | undefined;
    DataSetUsageConfiguration?: DataSetUsageConfiguration | undefined;
    DatasetParameters?: DatasetParameter[] | undefined;
    PerformanceConfiguration?: PerformanceConfiguration | undefined;
    DataPrepConfiguration?: DataPrepConfiguration | undefined;
    SemanticModelConfiguration?: SemanticModelConfiguration | undefined;
}
export interface UpdateDataSetResponse {
    Arn?: string | undefined;
    DataSetId?: string | undefined;
    IngestionArn?: string | undefined;
    IngestionId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateDataSetPermissionsRequest {
    AwsAccountId: string;
    DataSetId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateDataSetPermissionsResponse {
    DataSetArn?: string | undefined;
    DataSetId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateDataSourceRequest {
    AwsAccountId: string;
    DataSourceId: string;
    Name: string;
    DataSourceParameters?: DataSourceParameters | undefined;
    Credentials?: DataSourceCredentials | undefined;
    VpcConnectionProperties?: VpcConnectionProperties | undefined;
    SslProperties?: SslProperties | undefined;
}
export interface UpdateDataSourceResponse {
    Arn?: string | undefined;
    DataSourceId?: string | undefined;
    UpdateStatus?: ResourceStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateDataSourcePermissionsRequest {
    AwsAccountId: string;
    DataSourceId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateDataSourcePermissionsResponse {
    DataSourceArn?: string | undefined;
    DataSourceId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateDefaultQBusinessApplicationRequest {
    AwsAccountId: string;
    Namespace?: string | undefined;
    ApplicationId: string;
}
export interface UpdateDefaultQBusinessApplicationResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateDlpSettingRequest {
    AwsAccountId: string;
    DlpSettingId: string;
    Name?: string | undefined;
    ProviderType?: DlpProviderType | undefined;
    ProviderConfig?: ProviderConfig | undefined;
    ProviderOutageAction?: DlpAction | undefined;
    Enabled?: boolean | undefined;
}
export interface UpdateDlpSettingResponse {
    Arn: string;
    DlpSettingId: string;
    RequestId?: string | undefined;
}
export type UpdateFlowRequestClientTokenString = string;
export interface UpdateFlowRequest {
    AwsAccountId: string;
    FlowId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    FlowDefinition?: any | undefined;
    ClientToken?: string | undefined;
}
export interface UpdateFlowResponse {
    Arn: string;
    FlowId: string;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type UpdateFlowPermissionsInputGrantPermissionsList = Permission[];
export type UpdateFlowPermissionsInputRevokePermissionsList = Permission[];
export interface UpdateFlowPermissionsInput {
    AwsAccountId: string;
    FlowId: string;
    GrantPermissions?: Permission[] | undefined;
    RevokePermissions?: Permission[] | undefined;
}
export interface UpdateFlowPermissionsOutput {
    Status?: number | undefined;
    Arn: string;
    Permissions: Permission[];
    RequestId: string;
    FlowId: string;
}
export interface UpdateFolderRequest {
    AwsAccountId: string;
    FolderId: string;
    Name: string;
}
export interface UpdateFolderResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    FolderId?: string | undefined;
    RequestId?: string | undefined;
}
export interface UpdateFolderPermissionsRequest {
    AwsAccountId: string;
    FolderId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateFolderPermissionsResponse {
    Status?: number | undefined;
    Arn?: string | undefined;
    FolderId?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
}
export interface UpdateGroupRequest {
    GroupName: string;
    Description?: string | undefined;
    AwsAccountId: string;
    Namespace: string;
}
export interface UpdateGroupResponse {
    Group?: Group | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateIAMPolicyAssignmentRequest {
    AwsAccountId: string;
    AssignmentName: string;
    Namespace: string;
    AssignmentStatus?: AssignmentStatus | undefined;
    PolicyArn?: string | undefined;
    Identities?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface UpdateIAMPolicyAssignmentResponse {
    AssignmentName?: string | undefined;
    AssignmentId?: string | undefined;
    PolicyArn?: string | undefined;
    Identities?: {
        [key: string]: string[] | undefined;
    } | undefined;
    AssignmentStatus?: AssignmentStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateIdentityPropagationConfigRequest {
    AwsAccountId: string;
    Service: ServiceType;
    AuthorizedTargets?: string[] | undefined;
}
export interface UpdateIdentityPropagationConfigResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateIpRestrictionRequest {
    AwsAccountId: string;
    IpRestrictionRuleMap?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcIdRestrictionRuleMap?: {
        [key: string]: string | undefined;
    } | undefined;
    VpcEndpointIdRestrictionRuleMap?: {
        [key: string]: string | undefined;
    } | undefined;
    Enabled?: boolean | undefined;
}
export interface UpdateIpRestrictionResponse {
    AwsAccountId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateKeyRegistrationRequest {
    AwsAccountId: string;
    KeyRegistration: RegisteredCustomerManagedKey[];
}
export interface FailedKeyRegistrationEntry {
    KeyArn?: string | undefined;
    Message: string;
    StatusCode: number;
    SenderFault: boolean;
}
export type FailedKeyRegistrationEntries = FailedKeyRegistrationEntry[];
export interface SuccessfulKeyRegistrationEntry {
    KeyArn: string;
    StatusCode: number;
}
export type SuccessfulKeyRegistrationEntries = SuccessfulKeyRegistrationEntry[];
export interface UpdateKeyRegistrationResponse {
    FailedKeyRegistration?: FailedKeyRegistrationEntry[] | undefined;
    SuccessfulKeyRegistration?: SuccessfulKeyRegistrationEntry[] | undefined;
    RequestId?: string | undefined;
}
export interface UpdateKnowledgeBaseRequest {
    AwsAccountId: string;
    KnowledgeBaseId: string;
    Name?: string | undefined;
    Description?: string | undefined;
    KnowledgeBaseConfiguration?: KnowledgeBaseConfiguration | undefined;
    MediaExtractionConfiguration?: MediaExtractionConfiguration | undefined;
    IsEmailNotificationOptedForIngestionFailures?: boolean | undefined;
    AccessControlConfiguration?: AccessControlConfiguration | undefined;
}
export interface UpdateKnowledgeBaseResponse {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateKnowledgeBasePermissionsRequest {
    AwsAccountId: string;
    KnowledgeBaseId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateKnowledgeBasePermissionsResponse {
    KnowledgeBaseArn: string;
    KnowledgeBaseId: string;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateLimitsProfileRequest {
    profileId: string;
    accountId: string;
    profileName?: string | undefined;
    description?: string | undefined;
    resourceLimits?: {
        [key: string]: ProfileLimitValue | undefined;
    } | undefined;
}
export interface UpdateLimitsProfileResponse {
    arn: string;
}
export interface UpdateOAuthClientApplicationRequest {
    AwsAccountId: string;
    OAuthClientApplicationId: string;
    Name: string;
    ClientId?: string | redacted.Redacted<string> | undefined;
    ClientSecret?: string | redacted.Redacted<string> | undefined;
    OAuthTokenEndpointUrl?: string | redacted.Redacted<string> | undefined;
    OAuthAuthorizationEndpointUrl?: string | redacted.Redacted<string> | undefined;
    OAuthScopes?: string | undefined;
    DataSourceType?: DataSourceType | undefined;
    IdentityProviderVpcConnectionProperties?: VpcConnectionProperties | undefined;
}
export interface UpdateOAuthClientApplicationResponse {
    Arn?: string | undefined;
    OAuthClientApplicationId?: string | undefined;
    UpdateStatus?: ResourceStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdatePublicSharingSettingsRequest {
    AwsAccountId: string;
    PublicSharingEnabled?: boolean | undefined;
}
export interface UpdatePublicSharingSettingsResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateQPersonalizationConfigurationRequest {
    AwsAccountId: string;
    PersonalizationMode: PersonalizationMode;
}
export interface UpdateQPersonalizationConfigurationResponse {
    PersonalizationMode?: PersonalizationMode | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateQuickSightQSearchConfigurationRequest {
    AwsAccountId: string;
    QSearchStatus: QSearchStatus;
}
export interface UpdateQuickSightQSearchConfigurationResponse {
    QSearchStatus?: QSearchStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateRefreshScheduleRequest {
    DataSetId: string;
    AwsAccountId: string;
    Schedule: RefreshSchedule;
}
export interface UpdateRefreshScheduleResponse {
    Status?: number | undefined;
    RequestId?: string | undefined;
    ScheduleId?: string | undefined;
    Arn?: string | undefined;
}
export interface UpdateResourcePermissionsRequest {
    AwsAccountId: string;
    RoleType: ServiceRoleType;
    CustomerManagedRoleArn: string;
}
export interface UpdateResourcePermissionsResponse {
    RoleType?: ServiceRoleType | undefined;
    CustomerManagedRoleArn?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateRoleCustomPermissionRequest {
    CustomPermissionsName: string;
    Role: Role;
    AwsAccountId: string;
    Namespace: string;
}
export interface UpdateRoleCustomPermissionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type SelfUpgradeAdminAction = "APPROVE" | "DENY" | "VERIFY" | (string & {});
export interface UpdateSelfUpgradeRequest {
    AwsAccountId: string;
    Namespace: string;
    UpgradeRequestId: string;
    Action: SelfUpgradeAdminAction;
}
export interface UpdateSelfUpgradeResponse {
    SelfUpgradeRequestDetail?: SelfUpgradeRequestDetail | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateSelfUpgradeConfigurationRequest {
    AwsAccountId: string;
    Namespace: string;
    SelfUpgradeStatus: SelfUpgradeStatus;
}
export interface UpdateSelfUpgradeConfigurationResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateSpaceRequest {
    AwsAccountId: string;
    SpaceId: string;
    Name?: string | undefined;
    Description?: string | redacted.Redacted<string> | undefined;
}
export interface UpdateSpaceResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    RequestId?: string | undefined;
}
export interface UpdateSpacePermissionsRequest {
    AwsAccountId: string;
    SpaceId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateSpacePermissionsResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    permissions?: ResourcePermission[] | undefined;
    requestId?: string | undefined;
}
export interface SpaceResourceOperation {
    ResourceType: SpaceQuickSightResourceType;
    ResourceDetails: SpaceQuickSightResourceDetails;
}
export type SpaceResourceOperations = SpaceResourceOperation[];
export interface UpdateSpaceResourcesRequest {
    AwsAccountId: string;
    SpaceId: string;
    AddResources?: SpaceResourceOperation[] | undefined;
    RemoveResources?: SpaceResourceOperation[] | undefined;
}
export interface FailedSpaceResourceOperation {
    ResourceType: SpaceQuickSightResourceType;
    ResourceDetails?: SpaceQuickSightResourceDetails | undefined;
    ErrorMessage: string;
}
export type FailedSpaceResourceOperations = FailedSpaceResourceOperation[];
export interface UpdateSpaceResourcesResponse {
    spaceId: string;
    spaceArn?: string | undefined;
    FailedResourceOperations?: FailedSpaceResourceOperation[] | undefined;
    RequestId?: string | undefined;
}
export type PurchaseMode = "MANUAL" | "AUTO_PURCHASE" | (string & {});
export interface UpdateSPICECapacityConfigurationRequest {
    AwsAccountId: string;
    PurchaseMode: PurchaseMode;
}
export interface UpdateSPICECapacityConfigurationResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateTemplateRequest {
    AwsAccountId: string;
    TemplateId: string;
    SourceEntity?: TemplateSourceEntity | undefined;
    VersionDescription?: string | undefined;
    Name?: string | undefined;
    Definition?: TemplateVersionDefinition | undefined;
    ValidationStrategy?: ValidationStrategy | undefined;
}
export interface UpdateTemplateResponse {
    TemplateId?: string | undefined;
    Arn?: string | undefined;
    VersionArn?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateTemplateAliasRequest {
    AwsAccountId: string;
    TemplateId: string;
    AliasName: string;
    TemplateVersionNumber: number;
}
export interface UpdateTemplateAliasResponse {
    TemplateAlias?: TemplateAlias | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateTemplatePermissionsRequest {
    AwsAccountId: string;
    TemplateId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateTemplatePermissionsResponse {
    TemplateId?: string | undefined;
    TemplateArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateThemeRequest {
    AwsAccountId: string;
    ThemeId: string;
    Name?: string | undefined;
    BaseThemeId: string;
    VersionDescription?: string | undefined;
    Configuration?: ThemeConfiguration | undefined;
}
export interface UpdateThemeResponse {
    ThemeId?: string | undefined;
    Arn?: string | undefined;
    VersionArn?: string | undefined;
    CreationStatus?: ResourceStatus | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateThemeAliasRequest {
    AwsAccountId: string;
    ThemeId: string;
    AliasName: string;
    ThemeVersionNumber: number;
}
export interface UpdateThemeAliasResponse {
    ThemeAlias?: ThemeAlias | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateThemePermissionsRequest {
    AwsAccountId: string;
    ThemeId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateThemePermissionsResponse {
    ThemeId?: string | undefined;
    ThemeArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateTopicRequest {
    AwsAccountId: string;
    TopicId: string;
    Topic: TopicDetails;
    CustomInstructions?: CustomInstructions | undefined;
}
export interface UpdateTopicResponse {
    TopicId?: string | undefined;
    Arn?: string | undefined;
    RefreshArn?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateTopicPermissionsRequest {
    AwsAccountId: string;
    TopicId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateTopicPermissionsResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateTopicPermissionsV2Request {
    AwsAccountId: string;
    TopicId: string;
    GrantPermissions?: ResourcePermission[] | undefined;
    RevokePermissions?: ResourcePermission[] | undefined;
}
export interface UpdateTopicPermissionsV2Response {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    Permissions?: ResourcePermission[] | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export interface UpdateTopicRefreshScheduleRequest {
    AwsAccountId: string;
    TopicId: string;
    DatasetId: string;
    RefreshSchedule: TopicRefreshSchedule;
}
export interface UpdateTopicRefreshScheduleResponse {
    TopicId?: string | undefined;
    TopicArn?: string | undefined;
    DatasetArn?: string | undefined;
    Status?: number | undefined;
    RequestId?: string | undefined;
}
export type TopicV2PublishOption = "DRAFT" | "PUBLISH" | (string & {});
export interface UpdateTopicV2Request {
    AwsAccountId: string;
    TopicId: string;
    Topic: TopicV2Details;
    CustomInstructions?: CustomInstructions | undefined;
    PublishOption?: TopicV2PublishOption | undefined;
}
export interface UpdateTopicV2Response {
    Arn?: string | undefined;
    TopicId?: string | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateUserRequest {
    UserName: string;
    AwsAccountId: string;
    Namespace: string;
    Email: string;
    Role: UserRole;
    CustomPermissionsName?: string | undefined;
    UnapplyCustomPermissions?: boolean | undefined;
    ExternalLoginFederationProviderType?: string | undefined;
    CustomFederationProviderUrl?: string | undefined;
    ExternalLoginId?: string | undefined;
}
export interface UpdateUserResponse {
    User?: User | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateUserCustomPermissionRequest {
    UserName: string;
    AwsAccountId: string;
    Namespace: string;
    CustomPermissionsName: string;
}
export interface UpdateUserCustomPermissionResponse {
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export interface UpdateVPCConnectionRequest {
    AwsAccountId: string;
    VPCConnectionId: string;
    Name: string;
    SubnetIds: string[];
    SecurityGroupIds: string[];
    DnsResolvers?: string[] | undefined;
    RoleArn: string;
}
export interface UpdateVPCConnectionResponse {
    Arn?: string | undefined;
    VPCConnectionId?: string | undefined;
    UpdateStatus?: VPCConnectionResourceStatus | undefined;
    AvailabilityStatus?: VPCConnectionAvailabilityStatus | undefined;
    RequestId?: string | undefined;
    Status?: number | undefined;
}
export type ExceptionResourceType = "USER" | "GROUP" | "NAMESPACE" | "ACCOUNT_SETTINGS" | "IAMPOLICY_ASSIGNMENT" | "DATA_SOURCE" | "DATA_SET" | "VPC_CONNECTION" | "INGESTION" | (string & {});
export type BatchCreateTopicReviewedAnswerError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates new reviewed answers for a Q Topic.
 */
export declare const batchCreateTopicReviewedAnswer: API.OperationMethod<BatchCreateTopicReviewedAnswerRequest & RegionInput, BatchCreateTopicReviewedAnswerResponse, BatchCreateTopicReviewedAnswerError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteKnowledgeBaseError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ThrottlingException | CommonErrors;
/**
 * Deletes one or more knowledge bases.
 */
export declare const batchDeleteKnowledgeBase: API.OperationMethod<BatchDeleteKnowledgeBaseRequest & RegionInput, BatchDeleteKnowledgeBaseResponse, BatchDeleteKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteTopicReviewedAnswerError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes reviewed answers for Q Topic.
 */
export declare const batchDeleteTopicReviewedAnswer: API.OperationMethod<BatchDeleteTopicReviewedAnswerRequest & RegionInput, BatchDeleteTopicReviewedAnswerResponse, BatchDeleteTopicReviewedAnswerError, Credentials | HttpClient.HttpClient>;
export type BatchDescribeUserLimitsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Describes the effective resource limits for one or more Amazon Quick Sight users, including the limits that apply to each user based on their profile assignments.
 */
export declare const batchDescribeUserLimits: API.OperationMethod<BatchDescribeUserLimitsRequest & RegionInput, BatchDescribeUserLimitsResponse, BatchDescribeUserLimitsError, Credentials | HttpClient.HttpClient>;
export type CancelIngestionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Cancels an ongoing ingestion of data into SPICE.
 */
export declare const cancelIngestion: API.OperationMethod<CancelIngestionRequest & RegionInput, CancelIngestionResponse, CancelIngestionError, Credentials | HttpClient.HttpClient>;
export type CreateAccountCustomizationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates Amazon Quick Sight customizations. Currently, you can add a custom default theme by using the
 * `CreateAccountCustomization` or `UpdateAccountCustomization`
 * API operation. To further customize Amazon Quick Sight by removing Amazon Quick Sight
 * sample assets and videos for all new users, see Customizing Quick Sight in the *Amazon Quick Sight User Guide.*
 *
 * You can create customizations for your Amazon Web Services account or, if you specify a namespace, for
 * a Quick Sight namespace instead. Customizations that apply to a namespace always override
 * customizations that apply to an Amazon Web Services account. To find out which customizations apply, use
 * the `DescribeAccountCustomization` API operation.
 *
 * Before you use the `CreateAccountCustomization` API operation to add a theme
 * as the namespace default, make sure that you first share the theme with the namespace.
 * If you don't share it with the namespace, the theme isn't visible to your users
 * even if you make it the default theme.
 * To check if the theme is shared, view the current permissions by using the
 *
 * DescribeThemePermissions
 *
 * API operation.
 * To share the theme, grant permissions by using the
 *
 * UpdateThemePermissions
 *
 * API operation.
 */
export declare const createAccountCustomization: API.OperationMethod<CreateAccountCustomizationRequest & RegionInput, CreateAccountCustomizationResponse, CreateAccountCustomizationError, Credentials | HttpClient.HttpClient>;
export type CreateAccountSubscriptionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an Amazon Quick Sight account, or subscribes to Amazon Quick Sight Q.
 *
 * The Amazon Web Services Region for the account is derived from what is configured in the
 * CLI or SDK.
 *
 * Before you use this operation, make sure that you can connect to an existing Amazon Web Services account. If you don't have an Amazon Web Services account, see Sign
 * up for Amazon Web Services in the Amazon Quick Sight User
 * Guide. The person who signs up for Amazon Quick Sight needs to have the
 * correct Identity and Access Management (IAM) permissions. For more information,
 * see IAM Policy Examples for Amazon Quick Sight in the
 * *Amazon Quick Sight User Guide*.
 *
 * If your IAM policy includes both the `Subscribe` and
 * `CreateAccountSubscription` actions, make sure that both actions are set
 * to `Allow`. If either action is set to `Deny`, the
 * `Deny` action prevails and your API call fails.
 *
 * You can't pass an existing IAM role to access other Amazon Web Services services using this API operation. To pass your existing IAM role to
 * Amazon Quick Sight, see Passing IAM roles to Amazon Quick Sight in the
 * *Amazon Quick Sight User Guide*.
 *
 * You can't set default resource access on the new account from the Amazon Quick Sight
 * API. Instead, add default resource access from the Amazon Quick Sight console. For more
 * information about setting default resource access to Amazon Web Services services, see
 * Setting default resource
 * access to Amazon Web Services services in the Amazon Quick Sight
 * User Guide.
 */
export declare const createAccountSubscription: API.OperationMethod<CreateAccountSubscriptionRequest & RegionInput, CreateAccountSubscriptionResponse, CreateAccountSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateActionConnectorError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ThrottlingException | CommonErrors;
/**
 * Creates an action connector that enables Amazon Quick Sight to connect to external services and perform actions.
 * Action connectors support various authentication methods and can be configured with specific actions from supported connector types
 * like Amazon S3, Salesforce, JIRA.
 */
export declare const createActionConnector: API.OperationMethod<CreateActionConnectorRequest & RegionInput, CreateActionConnectorResponse, CreateActionConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateAgentError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ThrottlingException | CommonErrors;
/**
 * Creates an agent in Amazon QuickSight.
 */
export declare const createAgent: API.OperationMethod<CreateAgentRequest & RegionInput, CreateAgentResponse, CreateAgentError, Credentials | HttpClient.HttpClient>;
export type CreateAnalysisError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | QuickSightSubscriptionRequired | CommonErrors;
/**
 * Creates an analysis in Amazon Quick Sight. Analyses can be created either from a template or from an `AnalysisDefinition`.
 */
export declare const createAnalysis: API.OperationMethod<CreateAnalysisRequest & RegionInput, CreateAnalysisResponse, CreateAnalysisError, Credentials | HttpClient.HttpClient>;
export type CreateApprovalPolicyError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an approval policy in Quick Sight.
 */
export declare const createApprovalPolicy: API.OperationMethod<CreateApprovalPolicyRequest & RegionInput, CreateApprovalPolicyResponse, CreateApprovalPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateBrandError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates an Quick Sight brand.
 */
export declare const createBrand: API.OperationMethod<CreateBrandRequest & RegionInput, CreateBrandResponse, CreateBrandError, Credentials | HttpClient.HttpClient>;
export type CreateCustomPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates a custom permissions profile.
 */
export declare const createCustomPermissions: API.OperationMethod<CreateCustomPermissionsRequest & RegionInput, CreateCustomPermissionsResponse, CreateCustomPermissionsError, Credentials | HttpClient.HttpClient>;
export type CreateDashboardError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | QuickSightSubscriptionRequired | CommonErrors;
/**
 * Creates a dashboard from either a template or directly with a
 * `DashboardDefinition`. To first create a template, see the
 * CreateTemplate
 * API operation.
 *
 * A dashboard is an entity in Amazon Quick Sight that identifies Amazon Quick Sight
 * reports, created from analyses. You can share Amazon Quick Sight dashboards. With the
 * right permissions, you can create scheduled email reports from them. If you have the
 * correct permissions, you can create a dashboard from a template that exists in a
 * different Amazon Web Services account.
 */
export declare const createDashboard: API.OperationMethod<CreateDashboardRequest & RegionInput, CreateDashboardResponse, CreateDashboardError, Credentials | HttpClient.HttpClient>;
export type CreateDataSetError = AccessDeniedException | ConflictException | InternalFailureException | InvalidDataSetParameterValueException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | QuickSightSubscriptionRequired | CommonErrors;
/**
 * Creates a dataset.
 */
export declare const createDataSet: API.OperationMethod<CreateDataSetRequest & RegionInput, CreateDataSetResponse, CreateDataSetError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = AccessDeniedException | ConflictException | CustomerManagedKeyUnavailableException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | QuickSightSubscriptionRequired | CommonErrors;
/**
 * Creates a data source.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest & RegionInput, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateDlpSettingError = AccessDeniedException | ConflictException | InternalFailureException | InvalidRequestException | LimitExceededException | ResourceExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a data loss prevention (DLP) setting configuration for an Amazon Web Services account. A DLP setting defines the DLP provider, the enforcement behavior, and the Quick capabilities that the setting applies to.
 */
export declare const createDlpSetting: API.OperationMethod<CreateDlpSettingRequest & RegionInput, CreateDlpSettingResponse, CreateDlpSettingError, Credentials | HttpClient.HttpClient>;
export type CreateFlowError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new flow in the specified Amazon Web Services account. Creates both a DRAFT and PUBLISHED (auto-published) version.
 *
 * This operation is idempotent. Supply a `ClientToken` to safely retry without creating duplicate resources.
 */
export declare const createFlow: API.OperationMethod<CreateFlowRequest & RegionInput, CreateFlowResponse, CreateFlowError, Credentials | HttpClient.HttpClient>;
export type CreateFolderError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Creates an empty shared folder.
 */
export declare const createFolder: API.OperationMethod<CreateFolderRequest & RegionInput, CreateFolderResponse, CreateFolderError, Credentials | HttpClient.HttpClient>;
export type CreateFolderMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Adds an asset, such as a dashboard, analysis, or dataset into a folder.
 */
export declare const createFolderMembership: API.OperationMethod<CreateFolderMembershipRequest & RegionInput, CreateFolderMembershipResponse, CreateFolderMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateGroupError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Use the `CreateGroup` operation to create a group in Quick Sight. You can create up to 10,000 groups in a namespace. If you want to create more than 10,000 groups in a namespace, contact Amazon Web Services Support.
 *
 * The permissions resource is
 * arn:aws:quicksight::**:group/default/**
 * .
 *
 * The response is a group object.
 */
export declare const createGroup: API.OperationMethod<CreateGroupRequest & RegionInput, CreateGroupResponse, CreateGroupError, Credentials | HttpClient.HttpClient>;
export type CreateGroupMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Adds an Amazon Quick Sight user to an Amazon Quick Sight group.
 */
export declare const createGroupMembership: API.OperationMethod<CreateGroupMembershipRequest & RegionInput, CreateGroupMembershipResponse, CreateGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateIAMPolicyAssignmentError = AccessDeniedException | ConcurrentUpdatingException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an assignment with one specified IAM policy, identified by its
 * Amazon Resource Name (ARN). This policy assignment is attached to the specified groups
 * or users of Amazon Quick Sight. Assignment names are unique per Amazon Web Services
 * account. To avoid overwriting rules in other namespaces, use assignment names that are
 * unique.
 */
export declare const createIAMPolicyAssignment: API.OperationMethod<CreateIAMPolicyAssignmentRequest & RegionInput, CreateIAMPolicyAssignmentResponse, CreateIAMPolicyAssignmentError, Credentials | HttpClient.HttpClient>;
export type CreateIngestionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates and starts a new SPICE ingestion for a dataset. You can manually refresh datasets in
 * an Enterprise edition account 32 times in a 24-hour period. You can manually refresh
 * datasets in a Standard edition account 8 times in a 24-hour period. Each 24-hour period
 * is measured starting 24 hours before the current date and time.
 *
 * Any ingestions operating on tagged datasets inherit the same tags automatically for use in
 * access control. For an example, see How do I create an IAM policy to control access to Amazon EC2 resources using
 * tags? in the Amazon Web Services Knowledge Center. Tags are visible on the tagged dataset, but not on the ingestion resource.
 */
export declare const createIngestion: API.OperationMethod<CreateIngestionRequest & RegionInput, CreateIngestionResponse, CreateIngestionError, Credentials | HttpClient.HttpClient>;
export type CreateKnowledgeBaseError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a knowledge base from a specified data source. Supported data source connector types include:
 *
 * - `S3_KNOWLEDGE_BASE` - Uses an Amazon S3 bucket as the data source.
 *
 * - `WEB_CRAWLER` - Uses web pages indexed by the built-in web crawler as the data source.
 *
 * - `GOOGLE_DRIVE` - Uses Google Drive as the data source. Supports service account authentication only.
 *
 * - `SHAREPOINT` - Uses SharePoint as the data source. Supports two-legged OAuth only.
 *
 * - `ONE_DRIVE` - Uses OneDrive as the data source. Supports two-legged OAuth only.
 */
export declare const createKnowledgeBase: API.OperationMethod<CreateKnowledgeBaseRequest & RegionInput, CreateKnowledgeBaseResponse, CreateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type CreateLimitsProfileError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ThrottlingException | CommonErrors;
/**
 * Creates a limits profile that defines resource usage limits for Amazon Quick Sight users.
 */
export declare const createLimitsProfile: API.OperationMethod<CreateLimitsProfileRequest & RegionInput, CreateLimitsProfileResponse, CreateLimitsProfileError, Credentials | HttpClient.HttpClient>;
export type CreateNamespaceError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * (Enterprise edition only) Creates a new namespace for you to use with Amazon Quick Sight.
 *
 * A namespace allows you to isolate the Quick Sight users and groups that are registered
 * for that namespace. Users that access the namespace can share assets only with other
 * users or groups in the same namespace. They can't see users and groups in other
 * namespaces. You can create a namespace after your Amazon Web Services account is subscribed to
 * Quick Sight. The namespace must be unique within the Amazon Web Services account. By default, there is a
 * limit of 100 namespaces per Amazon Web Services account. To increase your limit, create a ticket with
 * Amazon Web Services Support.
 */
export declare const createNamespace: API.OperationMethod<CreateNamespaceRequest & RegionInput, CreateNamespaceResponse, CreateNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateOAuthClientApplicationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates an OAuthClientApplication.
 */
export declare const createOAuthClientApplication: API.OperationMethod<CreateOAuthClientApplicationRequest & RegionInput, CreateOAuthClientApplicationResponse, CreateOAuthClientApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateRefreshScheduleError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a refresh schedule for a dataset. You can create up to 5 different schedules for a single dataset.
 */
export declare const createRefreshSchedule: API.OperationMethod<CreateRefreshScheduleRequest & RegionInput, CreateRefreshScheduleResponse, CreateRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type CreateRoleMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Use `CreateRoleMembership` to add an existing Quick Sight group to an existing role.
 */
export declare const createRoleMembership: API.OperationMethod<CreateRoleMembershipRequest & RegionInput, CreateRoleMembershipResponse, CreateRoleMembershipError, Credentials | HttpClient.HttpClient>;
export type CreateSpaceError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ThrottlingException | CommonErrors;
/**
 * Creates a new Amazon QuickSight space. A space is a collection of resources that can be used to organize and manage QuickSight assets.
 */
export declare const createSpace: API.OperationMethod<CreateSpaceRequest & RegionInput, CreateSpaceResponse, CreateSpaceError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Creates a template either from a `TemplateDefinition` or from an existing Quick Sight analysis or template. You can use the resulting
 * template to create additional dashboards, templates, or analyses.
 *
 * A *template* is an entity in Quick Sight that encapsulates the metadata
 * required to create an analysis and that you can use to create s dashboard. A template adds
 * a layer of abstraction by using placeholders to replace the dataset associated with the
 * analysis. You can use templates to create dashboards by replacing dataset placeholders
 * with datasets that follow the same schema that was used to create the source analysis
 * and template.
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest & RegionInput, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateTemplateAliasError = ConflictException | InternalFailureException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Creates a template alias for a template.
 */
export declare const createTemplateAlias: API.OperationMethod<CreateTemplateAliasRequest & RegionInput, CreateTemplateAliasResponse, CreateTemplateAliasError, Credentials | HttpClient.HttpClient>;
export type CreateThemeError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Creates a theme.
 *
 * A *theme* is set of configuration options for color and layout.
 * Themes apply to analyses and dashboards. For more information, see Using
 * Themes in Amazon Quick Sight in the *Amazon Quick Sight User Guide*.
 */
export declare const createTheme: API.OperationMethod<CreateThemeRequest & RegionInput, CreateThemeResponse, CreateThemeError, Credentials | HttpClient.HttpClient>;
export type CreateThemeAliasError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Creates a theme alias for a theme.
 */
export declare const createThemeAlias: API.OperationMethod<CreateThemeAliasRequest & RegionInput, CreateThemeAliasResponse, CreateThemeAliasError, Credentials | HttpClient.HttpClient>;
export type CreateTopicError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new Q topic.
 */
export declare const createTopic: API.OperationMethod<CreateTopicRequest & RegionInput, CreateTopicResponse, CreateTopicError, Credentials | HttpClient.HttpClient>;
export type CreateTopicRefreshScheduleError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a topic refresh schedule.
 */
export declare const createTopicRefreshSchedule: API.OperationMethod<CreateTopicRefreshScheduleRequest & RegionInput, CreateTopicRefreshScheduleResponse, CreateTopicRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type CreateTopicV2Error = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates a new Q topic.
 */
export declare const createTopicV2: API.OperationMethod<CreateTopicV2Request & RegionInput, CreateTopicV2Response, CreateTopicV2Error, Credentials | HttpClient.HttpClient>;
export type CreateVPCConnectionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Creates a new VPC connection.
 */
export declare const createVPCConnection: API.OperationMethod<CreateVPCConnectionRequest & RegionInput, CreateVPCConnectionResponse, CreateVPCConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountCustomizationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * This API permanently deletes all Quick Sight customizations for the specified Amazon Web Services account and namespace. When you delete account customizations:
 *
 * - All customizations are removed including themes, branding, and visual settings
 *
 * - This action cannot be undone through the API
 *
 * - Users will see default Quick Sight styling after customizations are deleted
 *
 * **Before proceeding:** Ensure you have backups of any custom themes or branding elements you may want to recreate.
 *
 * Deletes all Amazon Quick Sight customizations for the specified Amazon Web Services account and Quick Sight namespace.
 */
export declare const deleteAccountCustomization: API.OperationMethod<DeleteAccountCustomizationRequest & RegionInput, DeleteAccountCustomizationResponse, DeleteAccountCustomizationError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountCustomPermissionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Unapplies a custom permissions profile from an account.
 */
export declare const deleteAccountCustomPermission: API.OperationMethod<DeleteAccountCustomPermissionRequest & RegionInput, DeleteAccountCustomPermissionResponse, DeleteAccountCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type DeleteAccountSubscriptionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deleting your Quick Sight account subscription has permanent, irreversible consequences across all Amazon Web Services regions:
 *
 * - Global deletion - Running this operation from any single region will delete your Quick Sight account and all data in every Amazon Web Services region where you have Quick Sight resources.
 *
 * - Complete data loss - All dashboards, analyses, datasets, data sources, and custom visuals will be permanently deleted across all regions.
 *
 * - Embedded content failure - All embedded dashboards and visuals in your applications will immediately stop working and display errors to end users.
 *
 * - Shared resources removed - All shared dashboards, folders, and resources will become inaccessible to other users and external recipients.
 *
 * - User access terminated - All Quick Sight users in your account will lose access immediately, including authors, readers, and administrators.
 *
 * - **No recovery possible** - Once deleted, your Quick Sight account and all associated data cannot be restored.
 *
 * Consider exporting critical dashboards and data before proceeding with account deletion.
 *
 * Use the `DeleteAccountSubscription` operation to delete an Quick Sight account. This operation will result in an error message if you have configured your account termination protection settings to `True`. To change this setting and delete your account, call the `UpdateAccountSettings` API and set the value of the `TerminationProtectionEnabled` parameter to `False`, then make another call to the `DeleteAccountSubscription` API.
 */
export declare const deleteAccountSubscription: API.OperationMethod<DeleteAccountSubscriptionRequest & RegionInput, DeleteAccountSubscriptionResponse, DeleteAccountSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteActionConnectorError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Hard deletes an action connector, making it unrecoverable. This operation removes the connector and all its associated configurations. Any resources currently using this action connector will no longer be able to perform actions through it.
 */
export declare const deleteActionConnector: API.OperationMethod<DeleteActionConnectorRequest & RegionInput, DeleteActionConnectorResponse, DeleteActionConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteAgentError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an agent.
 */
export declare const deleteAgent: API.OperationMethod<DeleteAgentRequest & RegionInput, DeleteAgentResponse, DeleteAgentError, Credentials | HttpClient.HttpClient>;
export type DeleteAnalysisError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes an analysis from Amazon Quick Sight. You can optionally include a recovery window during
 * which you can restore the analysis. If you don't specify a recovery window value, the
 * operation defaults to 30 days. Amazon Quick Sight attaches a `DeletionTime` stamp to
 * the response that specifies the end of the recovery window. At the end of the recovery
 * window, Amazon Quick Sight deletes the analysis permanently.
 *
 * At any time before recovery window ends, you can use the `RestoreAnalysis`
 * API operation to remove the `DeletionTime` stamp and cancel the deletion of
 * the analysis. The analysis remains visible in the API until it's deleted, so you can
 * describe it but you can't make a template from it.
 *
 * An analysis that's scheduled for deletion isn't accessible in the Amazon Quick Sight console.
 * To access it in the console, restore it. Deleting an analysis doesn't delete the
 * dashboards that you publish from it.
 */
export declare const deleteAnalysis: API.OperationMethod<DeleteAnalysisRequest & RegionInput, DeleteAnalysisResponse, DeleteAnalysisError, Credentials | HttpClient.HttpClient>;
export type DeleteAppError = AccessDeniedException | InternalFailureException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an app.
 */
export declare const deleteApp: API.OperationMethod<DeleteAppRequest & RegionInput, DeleteAppResponse, DeleteAppError, Credentials | HttpClient.HttpClient>;
export type DeleteApprovalPolicyError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an approval policy in Quick Sight.
 */
export declare const deleteApprovalPolicy: API.OperationMethod<DeleteApprovalPolicyRequest & RegionInput, DeleteApprovalPolicyResponse, DeleteApprovalPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteBrandError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * This API permanently deletes the specified Quick Sight brand. When you delete a brand:
 *
 * - The brand and all its associated branding elements are permanently removed
 *
 * - Any applications or dashboards using this brand will revert to default styling
 *
 * - This action cannot be undone through the API
 *
 * **Before proceeding:** Verify that the brand is no longer needed and consider the impact on any applications currently using this brand.
 *
 * Deletes an Quick Sight brand.
 */
export declare const deleteBrand: API.OperationMethod<DeleteBrandRequest & RegionInput, DeleteBrandResponse, DeleteBrandError, Credentials | HttpClient.HttpClient>;
export type DeleteBrandAssignmentError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a brand assignment.
 */
export declare const deleteBrandAssignment: API.OperationMethod<DeleteBrandAssignmentRequest & RegionInput, DeleteBrandAssignmentResponse, DeleteBrandAssignmentError, Credentials | HttpClient.HttpClient>;
export type DeleteCustomPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a custom permissions profile.
 */
export declare const deleteCustomPermissions: API.OperationMethod<DeleteCustomPermissionsRequest & RegionInput, DeleteCustomPermissionsResponse, DeleteCustomPermissionsError, Credentials | HttpClient.HttpClient>;
export type DeleteDashboardError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes a dashboard.
 */
export declare const deleteDashboard: API.OperationMethod<DeleteDashboardRequest & RegionInput, DeleteDashboardResponse, DeleteDashboardError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSetError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a dataset.
 */
export declare const deleteDataSet: API.OperationMethod<DeleteDataSetRequest & RegionInput, DeleteDataSetResponse, DeleteDataSetError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSetRefreshPropertiesError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the dataset refresh properties of the dataset.
 */
export declare const deleteDataSetRefreshProperties: API.OperationMethod<DeleteDataSetRefreshPropertiesRequest & RegionInput, DeleteDataSetRefreshPropertiesResponse, DeleteDataSetRefreshPropertiesError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes the data source permanently. This operation breaks all the datasets that
 * reference the deleted data source.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest & RegionInput, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDefaultQBusinessApplicationError = AccessDeniedException | ConflictException | InternalFailureException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a linked Amazon Q Business application from an Quick Sight account
 */
export declare const deleteDefaultQBusinessApplication: API.OperationMethod<DeleteDefaultQBusinessApplicationRequest & RegionInput, DeleteDefaultQBusinessApplicationResponse, DeleteDefaultQBusinessApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteDlpSettingError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a DLP setting configuration from an Amazon Web Services account.
 */
export declare const deleteDlpSetting: API.OperationMethod<DeleteDlpSettingRequest & RegionInput, DeleteDlpSettingResponse, DeleteDlpSettingError, Credentials | HttpClient.HttpClient>;
export type DeleteFlowError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Permanently deletes a flow from the specified Amazon Web Services account. This operation cannot be undone.
 */
export declare const deleteFlow: API.OperationMethod<DeleteFlowRequest & RegionInput, DeleteFlowResponse, DeleteFlowError, Credentials | HttpClient.HttpClient>;
export type DeleteFolderError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes an empty folder.
 */
export declare const deleteFolder: API.OperationMethod<DeleteFolderRequest & RegionInput, DeleteFolderResponse, DeleteFolderError, Credentials | HttpClient.HttpClient>;
export type DeleteFolderMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Removes an asset, such as a dashboard, analysis, or dataset, from a folder.
 */
export declare const deleteFolderMembership: API.OperationMethod<DeleteFolderMembershipRequest & RegionInput, DeleteFolderMembershipResponse, DeleteFolderMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Removes a user group from Amazon Quick Sight.
 */
export declare const deleteGroup: API.OperationMethod<DeleteGroupRequest & RegionInput, DeleteGroupResponse, DeleteGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteGroupMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Removes a user from a group so that the user is no longer a member of the group.
 */
export declare const deleteGroupMembership: API.OperationMethod<DeleteGroupMembershipRequest & RegionInput, DeleteGroupMembershipResponse, DeleteGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteIAMPolicyAssignmentError = AccessDeniedException | ConcurrentUpdatingException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an existing IAM policy assignment.
 */
export declare const deleteIAMPolicyAssignment: API.OperationMethod<DeleteIAMPolicyAssignmentRequest & RegionInput, DeleteIAMPolicyAssignmentResponse, DeleteIAMPolicyAssignmentError, Credentials | HttpClient.HttpClient>;
export type DeleteIdentityPropagationConfigError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes all access scopes and authorized targets that are associated with a service from the Quick Sight IAM Identity Center application.
 *
 * This operation is only supported for Quick Sight accounts that use IAM Identity Center.
 */
export declare const deleteIdentityPropagationConfig: API.OperationMethod<DeleteIdentityPropagationConfigRequest & RegionInput, DeleteIdentityPropagationConfigResponse, DeleteIdentityPropagationConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteKnowledgeBaseError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a knowledge base.
 */
export declare const deleteKnowledgeBase: API.OperationMethod<DeleteKnowledgeBaseRequest & RegionInput, DeleteKnowledgeBaseResponse, DeleteKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type DeleteLimitsProfileError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a limits profile.
 */
export declare const deleteLimitsProfile: API.OperationMethod<DeleteLimitsProfileRequest & RegionInput, DeleteLimitsProfileResponse, DeleteLimitsProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteNamespaceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a namespace and the users and groups that are associated with the namespace.
 * This is an asynchronous process. Assets including dashboards, analyses, datasets and data sources are not
 * deleted. To delete these assets, you use the API operations for the relevant asset.
 */
export declare const deleteNamespace: API.OperationMethod<DeleteNamespaceRequest & RegionInput, DeleteNamespaceResponse, DeleteNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteOAuthClientApplicationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an OAuthClientApplication.
 */
export declare const deleteOAuthClientApplication: API.OperationMethod<DeleteOAuthClientApplicationRequest & RegionInput, DeleteOAuthClientApplicationResponse, DeleteOAuthClientApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteRefreshScheduleError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a refresh schedule from a dataset.
 */
export declare const deleteRefreshSchedule: API.OperationMethod<DeleteRefreshScheduleRequest & RegionInput, DeleteRefreshScheduleResponse, DeleteRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteRoleCustomPermissionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Removes custom permissions from the role.
 */
export declare const deleteRoleCustomPermission: API.OperationMethod<DeleteRoleCustomPermissionRequest & RegionInput, DeleteRoleCustomPermissionResponse, DeleteRoleCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type DeleteRoleMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Removes a group from a role.
 */
export declare const deleteRoleMembership: API.OperationMethod<DeleteRoleMembershipRequest & RegionInput, DeleteRoleMembershipResponse, DeleteRoleMembershipError, Credentials | HttpClient.HttpClient>;
export type DeleteSpaceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes an Amazon QuickSight space.
 */
export declare const deleteSpace: API.OperationMethod<DeleteSpaceRequest & RegionInput, DeleteSpaceResponse, DeleteSpaceError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes a template.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest & RegionInput, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateAliasError = ConflictException | InternalFailureException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes the item that the specified template alias points to. If you provide a specific
 * alias, you delete the version of the template that the alias points to.
 */
export declare const deleteTemplateAlias: API.OperationMethod<DeleteTemplateAliasRequest & RegionInput, DeleteTemplateAliasResponse, DeleteTemplateAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteThemeError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes a theme.
 */
export declare const deleteTheme: API.OperationMethod<DeleteThemeRequest & RegionInput, DeleteThemeResponse, DeleteThemeError, Credentials | HttpClient.HttpClient>;
export type DeleteThemeAliasError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes the version of the theme that the specified theme alias points to.
 * If you provide a specific alias, you delete the version of the theme
 * that the alias points to.
 */
export declare const deleteThemeAlias: API.OperationMethod<DeleteThemeAliasRequest & RegionInput, DeleteThemeAliasResponse, DeleteThemeAliasError, Credentials | HttpClient.HttpClient>;
export type DeleteTopicError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a topic.
 */
export declare const deleteTopic: API.OperationMethod<DeleteTopicRequest & RegionInput, DeleteTopicResponse, DeleteTopicError, Credentials | HttpClient.HttpClient>;
export type DeleteTopicRefreshScheduleError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a topic refresh schedule.
 */
export declare const deleteTopicRefreshSchedule: API.OperationMethod<DeleteTopicRefreshScheduleRequest & RegionInput, DeleteTopicRefreshScheduleResponse, DeleteTopicRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteTopicV2Error = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a Q topic.
 */
export declare const deleteTopicV2: API.OperationMethod<DeleteTopicV2Request & RegionInput, DeleteTopicV2Response, DeleteTopicV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteUserError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes the Amazon Quick Sight user that is associated with the identity of the
 * IAM user or role that's making the call. The IAM user
 * isn't deleted as a result of this call.
 */
export declare const deleteUser: API.OperationMethod<DeleteUserRequest & RegionInput, DeleteUserResponse, DeleteUserError, Credentials | HttpClient.HttpClient>;
export type DeleteUserByPrincipalIdError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a user identified by its principal ID.
 */
export declare const deleteUserByPrincipalId: API.OperationMethod<DeleteUserByPrincipalIdRequest & RegionInput, DeleteUserByPrincipalIdResponse, DeleteUserByPrincipalIdError, Credentials | HttpClient.HttpClient>;
export type DeleteUserCustomPermissionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Deletes a custom permissions profile from a user.
 */
export declare const deleteUserCustomPermission: API.OperationMethod<DeleteUserCustomPermissionRequest & RegionInput, DeleteUserCustomPermissionResponse, DeleteUserCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type DeleteVPCConnectionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Deletes a VPC connection.
 */
export declare const deleteVPCConnection: API.OperationMethod<DeleteVPCConnectionRequest & RegionInput, DeleteVPCConnectionResponse, DeleteVPCConnectionError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountCustomizationError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes the customizations associated with the provided Amazon Web Services account and Amazon
 * Quick Sight namespace. The Quick Sight console evaluates which
 * customizations to apply by running this API operation with the `Resolved` flag
 * included.
 *
 * To determine what customizations display when you run this command, it can help to
 * visualize the relationship of the entities involved.
 *
 * - `Amazon Web Services account` - The Amazon Web Services account exists at the top of the hierarchy.
 * It has the potential to use all of the Amazon Web Services Regions and Amazon Web Services Services. When you
 * subscribe to Quick Sight, you choose one Amazon Web Services Region to use as your home Region.
 * That's where your free SPICE capacity is located. You can use Quick Sight in any
 * supported Amazon Web Services Region.
 *
 * - `Amazon Web Services Region` - You can sign in to Quick Sight in any Amazon Web Services Region. If
 * you have a user directory, it resides in us-east-1, which is US East (N.
 * Virginia). Generally speaking, these users have access to Quick Sight in any
 * Amazon Web Services Region, unless they are constrained to a namespace.
 *
 * To run the command in a different Amazon Web Services Region, you change your Region settings.
 * If you're using the CLI, you can use one of the following options:
 *
 * - Use command line options.
 *
 * - Use named profiles.
 *
 * - Run `aws configure` to change your default Amazon Web Services Region. Use
 * Enter to key the same settings for your keys. For more information, see
 * Configuring the CLI.
 *
 * - `Namespace` - A Quick Sight namespace is a partition that contains
 * users and assets (data sources, datasets, dashboards, and so on). To access
 * assets that are in a specific namespace, users and groups must also be part of
 * the same namespace. People who share a namespace are completely isolated from
 * users and assets in other namespaces, even if they are in the same Amazon Web Services account
 * and Amazon Web Services Region.
 *
 * - `Applied customizations` - Quick Sight customizations can apply to an Amazon Web Services account or to a namespace.
 * Settings that you apply to a namespace override settings that you apply to an
 * Amazon Web Services account.
 */
export declare const describeAccountCustomization: API.OperationMethod<DescribeAccountCustomizationRequest & RegionInput, DescribeAccountCustomizationResponse, DescribeAccountCustomizationError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountCustomPermissionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the custom permissions profile that is applied to an account.
 */
export declare const describeAccountCustomPermission: API.OperationMethod<DescribeAccountCustomPermissionRequest & RegionInput, DescribeAccountCustomPermissionResponse, DescribeAccountCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountSettingsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes the settings that were used when your Quick Sight subscription was first
 * created in this Amazon Web Services account.
 */
export declare const describeAccountSettings: API.OperationMethod<DescribeAccountSettingsRequest & RegionInput, DescribeAccountSettingsResponse, DescribeAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountSubscriptionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Use the DescribeAccountSubscription operation to receive a description of an Quick Sight account's subscription. A successful API call returns an `AccountInfo` object that includes an account's name, subscription status, authentication type, edition, and notification email address.
 */
export declare const describeAccountSubscription: API.OperationMethod<DescribeAccountSubscriptionRequest & RegionInput, DescribeAccountSubscriptionResponse, DescribeAccountSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DescribeActionConnectorError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves detailed information about an action connector, including its configuration, authentication settings, enabled actions, and current status.
 */
export declare const describeActionConnector: API.OperationMethod<DescribeActionConnectorRequest & RegionInput, DescribeActionConnectorResponse, DescribeActionConnectorError, Credentials | HttpClient.HttpClient>;
export type DescribeActionConnectorPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the permissions configuration for an action connector, showing which users, groups, and namespaces have access and what operations they can perform.
 */
export declare const describeActionConnectorPermissions: API.OperationMethod<DescribeActionConnectorPermissionsRequest & RegionInput, DescribeActionConnectorPermissionsResponse, DescribeActionConnectorPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeAgentError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an agent.
 */
export declare const describeAgent: API.OperationMethod<DescribeAgentRequest & RegionInput, DescribeAgentResponse, DescribeAgentError, Credentials | HttpClient.HttpClient>;
export type DescribeAgentPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the resource permissions for an agent.
 */
export declare const describeAgentPermissions: API.OperationMethod<DescribeAgentPermissionsRequest & RegionInput, DescribeAgentPermissionsResponse, DescribeAgentPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeAnalysisError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Provides a summary of the metadata for an analysis.
 */
export declare const describeAnalysis: API.OperationMethod<DescribeAnalysisRequest & RegionInput, DescribeAnalysisResponse, DescribeAnalysisError, Credentials | HttpClient.HttpClient>;
export type DescribeAnalysisDefinitionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Provides a detailed description of the definition of an analysis.
 *
 * If you do not need to know details about the content of an Analysis, for instance if you
 * are trying to check the status of a recently created or updated Analysis, use the
 *
 * `DescribeAnalysis`
 * instead.
 */
export declare const describeAnalysisDefinition: API.OperationMethod<DescribeAnalysisDefinitionRequest & RegionInput, DescribeAnalysisDefinitionResponse, DescribeAnalysisDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeAnalysisPermissionsError = InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Provides the read and write permissions for an analysis.
 */
export declare const describeAnalysisPermissions: API.OperationMethod<DescribeAnalysisPermissionsRequest & RegionInput, DescribeAnalysisPermissionsResponse, DescribeAnalysisPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeAppError = AccessDeniedException | InternalFailureException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an app.
 */
export declare const describeApp: API.OperationMethod<DescribeAppRequest & RegionInput, DescribeAppResponse, DescribeAppError, Credentials | HttpClient.HttpClient>;
export type DescribeAppPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the resource permissions for an app.
 */
export declare const describeAppPermissions: API.OperationMethod<DescribeAppPermissionsRequest & RegionInput, DescribeAppPermissionsResponse, DescribeAppPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeApprovalPolicyError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an approval policy in Quick Sight.
 */
export declare const describeApprovalPolicy: API.OperationMethod<DescribeApprovalPolicyRequest & RegionInput, DescribeApprovalPolicyResponse, DescribeApprovalPolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetBundleExportJobError = ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes an existing export job.
 *
 * Poll job descriptions after a job starts to know the status of the job. When a job
 * succeeds, a URL is provided to download the exported assets' data from. Download URLs
 * are valid for five minutes after they are generated. You can call the
 * `DescribeAssetBundleExportJob` API for a new download URL as needed.
 *
 * Job descriptions are available for 14 days after the job starts.
 */
export declare const describeAssetBundleExportJob: API.OperationMethod<DescribeAssetBundleExportJobRequest & RegionInput, DescribeAssetBundleExportJobResponse, DescribeAssetBundleExportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeAssetBundleImportJobError = ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes an existing import job.
 *
 * Poll job descriptions after starting a job to know when it has succeeded or failed. Job
 * descriptions are available for 14 days after job starts.
 */
export declare const describeAssetBundleImportJob: API.OperationMethod<DescribeAssetBundleImportJobRequest & RegionInput, DescribeAssetBundleImportJobResponse, DescribeAssetBundleImportJobError, Credentials | HttpClient.HttpClient>;
export type DescribeAutomationJobError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the status and details of a specified automation job, including its status and outputs.
 */
export declare const describeAutomationJob: API.OperationMethod<DescribeAutomationJobRequest & RegionInput, DescribeAutomationJobResponse, DescribeAutomationJobError, Credentials | HttpClient.HttpClient>;
export type DescribeBrandError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a brand.
 */
export declare const describeBrand: API.OperationMethod<DescribeBrandRequest & RegionInput, DescribeBrandResponse, DescribeBrandError, Credentials | HttpClient.HttpClient>;
export type DescribeBrandAssignmentError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a brand assignment.
 */
export declare const describeBrandAssignment: API.OperationMethod<DescribeBrandAssignmentRequest & RegionInput, DescribeBrandAssignmentResponse, DescribeBrandAssignmentError, Credentials | HttpClient.HttpClient>;
export type DescribeBrandPublishedVersionError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the published version of the brand.
 */
export declare const describeBrandPublishedVersion: API.OperationMethod<DescribeBrandPublishedVersionRequest & RegionInput, DescribeBrandPublishedVersionResponse, DescribeBrandPublishedVersionError, Credentials | HttpClient.HttpClient>;
export type DescribeCustomPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes a custom permissions profile.
 */
export declare const describeCustomPermissions: API.OperationMethod<DescribeCustomPermissionsRequest & RegionInput, DescribeCustomPermissionsResponse, DescribeCustomPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Provides a summary for a dashboard.
 */
export declare const describeDashboard: API.OperationMethod<DescribeDashboardRequest & RegionInput, DescribeDashboardResponse, DescribeDashboardError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardDefinitionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Provides a detailed description of the definition of a dashboard.
 *
 * If you do not need to know details about the content of a dashboard, for instance
 * if you are trying to check the status of a recently created or updated dashboard,
 * use the
 * `DescribeDashboard`
 * instead.
 */
export declare const describeDashboardDefinition: API.OperationMethod<DescribeDashboardDefinitionRequest & RegionInput, DescribeDashboardDefinitionResponse, DescribeDashboardDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardPermissionsError = InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes read and write permissions for a dashboard.
 */
export declare const describeDashboardPermissions: API.OperationMethod<DescribeDashboardPermissionsRequest & RegionInput, DescribeDashboardPermissionsResponse, DescribeDashboardPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardSnapshotJobError = AccessDeniedException | InternalFailureException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes an existing snapshot job.
 *
 * Poll job descriptions after a job starts to know the status of the job. For information on available status codes, see `JobStatus`.
 *
 * **Registered user support**
 *
 * This API can be called as before to get status of a job started by the same Quick Sight user.
 *
 * **Possible error scenarios**
 *
 * Request will fail with an Access Denied error in the following scenarios:
 *
 * - The credentials have expired.
 *
 * - Job has been started by a different user.
 *
 * - Impersonated Quick Sight user doesn't have access to the specified dashboard in the job.
 */
export declare const describeDashboardSnapshotJob: API.OperationMethod<DescribeDashboardSnapshotJobRequest & RegionInput, DescribeDashboardSnapshotJobResponse, DescribeDashboardSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardSnapshotJobResultError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes the result of an existing snapshot job that has finished running.
 *
 * A finished snapshot job will return a `COMPLETED` or `FAILED` status when you poll the job with a `DescribeDashboardSnapshotJob` API call.
 *
 * If the job has not finished running, this operation returns a message that says `Dashboard Snapshot Job with id has not reached a terminal state.`.
 *
 * **Registered user support**
 *
 * This API can be called as before to get the result of a job started by the same Quick Sight user. The result for the user will be returned in `RegisteredUsers` response attribute. The attribute will contain a list with at most one object in it.
 *
 * **Possible error scenarios**
 *
 * The request fails with an Access Denied error in the following scenarios:
 *
 * - The credentials have expired.
 *
 * - The job was started by a different user.
 *
 * - The registered user doesn't have access to the specified dashboard.
 *
 * The request succeeds but the job fails in the following scenarios:
 *
 * - `DASHBOARD_ACCESS_DENIED` - The registered user lost access to the dashboard.
 *
 * - `CAPABILITY_RESTRICTED` - The registered user is restricted from exporting data in **all** selected formats.
 *
 * The request succeeds but the response contains an error code in the following scenarios:
 *
 * - `CAPABILITY_RESTRICTED` - The registered user is restricted from exporting data in **some** selected formats.
 *
 * - `RLS_CHANGED` - Row-level security settings have changed. Re-run the job with current settings.
 *
 * - `CLS_CHANGED` - Column-level security settings have changed. Re-run the job with current settings.
 *
 * - `DATASET_DELETED` - The dataset has been deleted. Verify the dataset exists before re-running the job.
 */
export declare const describeDashboardSnapshotJobResult: API.OperationMethod<DescribeDashboardSnapshotJobResultRequest & RegionInput, DescribeDashboardSnapshotJobResultResponse, DescribeDashboardSnapshotJobResultError, Credentials | HttpClient.HttpClient>;
export type DescribeDashboardsQAConfigurationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an existing dashboard QA configuration.
 */
export declare const describeDashboardsQAConfiguration: API.OperationMethod<DescribeDashboardsQAConfigurationRequest & RegionInput, DescribeDashboardsQAConfigurationResponse, DescribeDashboardsQAConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSetError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a dataset.
 */
export declare const describeDataSet: API.OperationMethod<DescribeDataSetRequest & RegionInput, DescribeDataSetResponse, DescribeDataSetError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSetPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the permissions on a dataset.
 *
 * The permissions resource is
 * `arn:aws:quicksight:region:aws-account-id:dataset/data-set-id`.
 */
export declare const describeDataSetPermissions: API.OperationMethod<DescribeDataSetPermissionsRequest & RegionInput, DescribeDataSetPermissionsResponse, DescribeDataSetPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSetRefreshPropertiesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the refresh properties of a dataset.
 */
export declare const describeDataSetRefreshProperties: API.OperationMethod<DescribeDataSetRefreshPropertiesRequest & RegionInput, DescribeDataSetRefreshPropertiesResponse, DescribeDataSetRefreshPropertiesError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSourceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a data source.
 */
export declare const describeDataSource: API.OperationMethod<DescribeDataSourceRequest & RegionInput, DescribeDataSourceResponse, DescribeDataSourceError, Credentials | HttpClient.HttpClient>;
export type DescribeDataSourcePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the resource permissions for a data source.
 */
export declare const describeDataSourcePermissions: API.OperationMethod<DescribeDataSourcePermissionsRequest & RegionInput, DescribeDataSourcePermissionsResponse, DescribeDataSourcePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeDefaultQBusinessApplicationError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a Amazon Q Business application that is linked to an Quick Sight account.
 */
export declare const describeDefaultQBusinessApplication: API.OperationMethod<DescribeDefaultQBusinessApplicationRequest & RegionInput, DescribeDefaultQBusinessApplicationResponse, DescribeDefaultQBusinessApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeDlpSettingError = AccessDeniedException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the full configuration of a DLP setting in an Amazon Web Services account.
 */
export declare const describeDlpSetting: API.OperationMethod<DescribeDlpSettingRequest & RegionInput, DescribeDlpSettingResponse, DescribeDlpSettingError, Credentials | HttpClient.HttpClient>;
export type DescribeFlowError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Returns the full details of a flow for the latest version of the requested publish state.
 */
export declare const describeFlow: API.OperationMethod<DescribeFlowRequest & RegionInput, DescribeFlowResponse, DescribeFlowError, Credentials | HttpClient.HttpClient>;
export type DescribeFolderError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes a folder.
 */
export declare const describeFolder: API.OperationMethod<DescribeFolderRequest & RegionInput, DescribeFolderResponse, DescribeFolderError, Credentials | HttpClient.HttpClient>;
export type DescribeFolderPermissionsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes permissions for a folder.
 */
export declare const describeFolderPermissions: API.PaginatedOperationMethod<DescribeFolderPermissionsRequest & RegionInput, DescribeFolderPermissionsResponse, DescribeFolderPermissionsError, Credentials | HttpClient.HttpClient, ResourcePermission>;
export type DescribeFolderResolvedPermissionsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes the folder resolved permissions. Permissions consists of both folder direct permissions and the inherited permissions from the ancestor folders.
 */
export declare const describeFolderResolvedPermissions: API.PaginatedOperationMethod<DescribeFolderResolvedPermissionsRequest & RegionInput, DescribeFolderResolvedPermissionsResponse, DescribeFolderResolvedPermissionsError, Credentials | HttpClient.HttpClient, ResourcePermission>;
export type DescribeGroupError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns an Amazon Quick Sight group's description and Amazon Resource Name (ARN).
 */
export declare const describeGroup: API.OperationMethod<DescribeGroupRequest & RegionInput, DescribeGroupResponse, DescribeGroupError, Credentials | HttpClient.HttpClient>;
export type DescribeGroupMembershipError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Use the `DescribeGroupMembership` operation to determine if a user is a
 * member of the specified group. If the user exists and is a member of the specified
 * group, an associated `GroupMember` object is returned.
 */
export declare const describeGroupMembership: API.OperationMethod<DescribeGroupMembershipRequest & RegionInput, DescribeGroupMembershipResponse, DescribeGroupMembershipError, Credentials | HttpClient.HttpClient>;
export type DescribeIAMPolicyAssignmentError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an existing IAM policy assignment, as specified by the
 * assignment name.
 */
export declare const describeIAMPolicyAssignment: API.OperationMethod<DescribeIAMPolicyAssignmentRequest & RegionInput, DescribeIAMPolicyAssignmentResponse, DescribeIAMPolicyAssignmentError, Credentials | HttpClient.HttpClient>;
export type DescribeIngestionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a SPICE ingestion.
 */
export declare const describeIngestion: API.OperationMethod<DescribeIngestionRequest & RegionInput, DescribeIngestionResponse, DescribeIngestionError, Credentials | HttpClient.HttpClient>;
export type DescribeIpRestrictionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a summary and status of IP rules.
 */
export declare const describeIpRestriction: API.OperationMethod<DescribeIpRestrictionRequest & RegionInput, DescribeIpRestrictionResponse, DescribeIpRestrictionError, Credentials | HttpClient.HttpClient>;
export type DescribeKeyRegistrationError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Describes all customer managed key registrations in a Quick Sight account.
 */
export declare const describeKeyRegistration: API.OperationMethod<DescribeKeyRegistrationRequest & RegionInput, DescribeKeyRegistrationResponse, DescribeKeyRegistrationError, Credentials | HttpClient.HttpClient>;
export type DescribeKnowledgeBaseError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a knowledge base.
 */
export declare const describeKnowledgeBase: API.OperationMethod<DescribeKnowledgeBaseRequest & RegionInput, DescribeKnowledgeBaseResponse, DescribeKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type DescribeKnowledgeBasePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the resource permissions for a knowledge base.
 */
export declare const describeKnowledgeBasePermissions: API.OperationMethod<DescribeKnowledgeBasePermissionsRequest & RegionInput, DescribeKnowledgeBasePermissionsResponse, DescribeKnowledgeBasePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeLimitsProfileError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the properties of an existing limits profile.
 */
export declare const describeLimitsProfile: API.OperationMethod<DescribeLimitsProfileRequest & RegionInput, DescribeLimitsProfileResponse, DescribeLimitsProfileError, Credentials | HttpClient.HttpClient>;
export type DescribeNamespaceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes the current namespace.
 */
export declare const describeNamespace: API.OperationMethod<DescribeNamespaceRequest & RegionInput, DescribeNamespaceResponse, DescribeNamespaceError, Credentials | HttpClient.HttpClient>;
export type DescribeOAuthClientApplicationError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an OAuthClientApplication.
 */
export declare const describeOAuthClientApplication: API.OperationMethod<DescribeOAuthClientApplicationRequest & RegionInput, DescribeOAuthClientApplicationResponse, DescribeOAuthClientApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeQPersonalizationConfigurationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a personalization configuration.
 */
export declare const describeQPersonalizationConfiguration: API.OperationMethod<DescribeQPersonalizationConfigurationRequest & RegionInput, DescribeQPersonalizationConfigurationResponse, DescribeQPersonalizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeQuickSightQSearchConfigurationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the state of a Quick Sight Q Search configuration.
 */
export declare const describeQuickSightQSearchConfiguration: API.OperationMethod<DescribeQuickSightQSearchConfigurationRequest & RegionInput, DescribeQuickSightQSearchConfigurationResponse, DescribeQuickSightQSearchConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeRefreshScheduleError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Provides a summary of a refresh schedule.
 */
export declare const describeRefreshSchedule: API.OperationMethod<DescribeRefreshScheduleRequest & RegionInput, DescribeRefreshScheduleResponse, DescribeRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the service role configuration for your Amazon Quick Sight account.
 *
 * Call this operation in the Amazon Web Services Region where your Amazon Quick Sight account is
 * registered (the home Region).
 */
export declare const describeResourcePermissions: API.OperationMethod<DescribeResourcePermissionsRequest & RegionInput, DescribeResourcePermissionsResponse, DescribeResourcePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeRoleCustomPermissionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes all custom permissions that are mapped to a role.
 */
export declare const describeRoleCustomPermission: API.OperationMethod<DescribeRoleCustomPermissionRequest & RegionInput, DescribeRoleCustomPermissionResponse, DescribeRoleCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type DescribeSelfUpgradeConfigurationError = AccessDeniedException | InternalFailureException | InvalidParameterException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Describes the self-upgrade configuration for a Quick account.
 */
export declare const describeSelfUpgradeConfiguration: API.OperationMethod<DescribeSelfUpgradeConfigurationRequest & RegionInput, DescribeSelfUpgradeConfigurationResponse, DescribeSelfUpgradeConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeSpaceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes an Amazon QuickSight space.
 */
export declare const describeSpace: API.OperationMethod<DescribeSpaceRequest & RegionInput, DescribeSpaceResponse, DescribeSpaceError, Credentials | HttpClient.HttpClient>;
export type DescribeSpacePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the permissions for an Amazon QuickSight space.
 */
export declare const describeSpacePermissions: API.OperationMethod<DescribeSpacePermissionsRequest & RegionInput, DescribeSpacePermissionsResponse, DescribeSpacePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeTemplateError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes a template's metadata.
 */
export declare const describeTemplate: API.OperationMethod<DescribeTemplateRequest & RegionInput, DescribeTemplateResponse, DescribeTemplateError, Credentials | HttpClient.HttpClient>;
export type DescribeTemplateAliasError = InternalFailureException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes the template alias for a template.
 */
export declare const describeTemplateAlias: API.OperationMethod<DescribeTemplateAliasRequest & RegionInput, DescribeTemplateAliasResponse, DescribeTemplateAliasError, Credentials | HttpClient.HttpClient>;
export type DescribeTemplateDefinitionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Provides a detailed description of the definition of a template.
 *
 * If you do not need to know details about the content of a template, for instance if you
 * are trying to check the status of a recently created or updated template, use the
 *
 * `DescribeTemplate`
 * instead.
 */
export declare const describeTemplateDefinition: API.OperationMethod<DescribeTemplateDefinitionRequest & RegionInput, DescribeTemplateDefinitionResponse, DescribeTemplateDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeTemplatePermissionsError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes read and write permissions on a template.
 */
export declare const describeTemplatePermissions: API.OperationMethod<DescribeTemplatePermissionsRequest & RegionInput, DescribeTemplatePermissionsResponse, DescribeTemplatePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeThemeError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes a theme.
 */
export declare const describeTheme: API.OperationMethod<DescribeThemeRequest & RegionInput, DescribeThemeResponse, DescribeThemeError, Credentials | HttpClient.HttpClient>;
export type DescribeThemeAliasError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes the alias for a theme.
 */
export declare const describeThemeAlias: API.OperationMethod<DescribeThemeAliasRequest & RegionInput, DescribeThemeAliasResponse, DescribeThemeAliasError, Credentials | HttpClient.HttpClient>;
export type DescribeThemePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes the read and write permissions for a theme.
 */
export declare const describeThemePermissions: API.OperationMethod<DescribeThemePermissionsRequest & RegionInput, DescribeThemePermissionsResponse, DescribeThemePermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a topic.
 */
export declare const describeTopic: API.OperationMethod<DescribeTopicRequest & RegionInput, DescribeTopicResponse, DescribeTopicError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the permissions of a topic.
 */
export declare const describeTopicPermissions: API.OperationMethod<DescribeTopicPermissionsRequest & RegionInput, DescribeTopicPermissionsResponse, DescribeTopicPermissionsError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicPermissionsV2Error = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the permissions of a topic.
 */
export declare const describeTopicPermissionsV2: API.OperationMethod<DescribeTopicPermissionsV2Request & RegionInput, DescribeTopicPermissionsV2Response, DescribeTopicPermissionsV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeTopicRefreshError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes the status of a topic refresh.
 */
export declare const describeTopicRefresh: API.OperationMethod<DescribeTopicRefreshRequest & RegionInput, DescribeTopicRefreshResponse, DescribeTopicRefreshError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicRefreshScheduleError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Deletes a topic refresh schedule.
 */
export declare const describeTopicRefreshSchedule: API.OperationMethod<DescribeTopicRefreshScheduleRequest & RegionInput, DescribeTopicRefreshScheduleResponse, DescribeTopicRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type DescribeTopicV2Error = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Describes a Q topic.
 */
export declare const describeTopicV2: API.OperationMethod<DescribeTopicV2Request & RegionInput, DescribeTopicV2Response, DescribeTopicV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeUserError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns information about a user, given the user name.
 */
export declare const describeUser: API.OperationMethod<DescribeUserRequest & RegionInput, DescribeUserResponse, DescribeUserError, Credentials | HttpClient.HttpClient>;
export type DescribeVPCConnectionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Describes a VPC connection.
 */
export declare const describeVPCConnection: API.OperationMethod<DescribeVPCConnectionRequest & RegionInput, DescribeVPCConnectionResponse, DescribeVPCConnectionError, Credentials | HttpClient.HttpClient>;
export type GenerateEmbedUrlForAnonymousUserError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | SessionLifetimeInMinutesInvalidException | ThrottlingException | UnsupportedPricingPlanException | UnsupportedUserEditionException | CommonErrors;
/**
 * Generates an embed URL that you can use to embed an Amazon Quick dashboard or
 * visual in your website, without having to register any reader users. Before you use this
 * action, make sure that you have configured the dashboards and permissions.
 *
 * The following rules apply to the generated URL:
 *
 * - It contains a temporary bearer token. It is valid for 5 minutes after it is
 * generated. Once redeemed within this period, it cannot be re-used again.
 *
 * - The URL validity period should not be confused with the actual session
 * lifetime that can be customized using the
 * SessionLifetimeInMinutes
 * parameter. The resulting user
 * session is valid for 15 minutes (minimum) to 10 hours (maximum). The default
 * session duration is 10 hours.
 *
 * - You are charged only when the URL is used or there is interaction with Amazon Quick.
 *
 * For more information, see Embedded Analytics in
 * the *Amazon Quick User Guide*.
 *
 * For more information about the high-level steps for embedding and for an interactive
 * demo of the ways you can customize embedding, visit the Amazon Quick
 * Developer Portal.
 */
export declare const generateEmbedUrlForAnonymousUser: API.OperationMethod<GenerateEmbedUrlForAnonymousUserRequest & RegionInput, GenerateEmbedUrlForAnonymousUserResponse, GenerateEmbedUrlForAnonymousUserError, Credentials | HttpClient.HttpClient>;
export type GenerateEmbedUrlForRegisteredUserError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | QuickSightUserNotFoundException | ResourceNotFoundException | SessionLifetimeInMinutesInvalidException | ThrottlingException | UnsupportedPricingPlanException | UnsupportedUserEditionException | CommonErrors;
/**
 * Generates an embed URL that you can use to embed an Amazon Quick experience
 * in your website. This action can be used for any type of user registered in an Amazon Quick account. Before you use this action, make sure that you have
 * configured the relevant Amazon Quick resource and permissions.
 *
 * The following rules apply to the generated URL:
 *
 * - It contains a temporary bearer token. It is valid for 5 minutes after it is
 * generated. Once redeemed within this period, it cannot be re-used again.
 *
 * - The URL validity period should not be confused with the actual session
 * lifetime that can be customized using the
 * SessionLifetimeInMinutes
 * parameter.
 *
 * The resulting user session is valid for 15 minutes (minimum) to 10 hours
 * (maximum). The default session duration is 10 hours.
 *
 * - You are charged only when the URL is used or there is interaction with Amazon Quick.
 *
 * For more information, see Embedded Analytics in
 * the *Amazon Quick User Guide*.
 *
 * For more information about the high-level steps for embedding and for an interactive
 * demo of the ways you can customize embedding, visit the Amazon Quick
 * Developer Portal.
 */
export declare const generateEmbedUrlForRegisteredUser: API.OperationMethod<GenerateEmbedUrlForRegisteredUserRequest & RegionInput, GenerateEmbedUrlForRegisteredUserResponse, GenerateEmbedUrlForRegisteredUserError, Credentials | HttpClient.HttpClient>;
export type GenerateEmbedUrlForRegisteredUserWithIdentityError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | QuickSightUserNotFoundException | ResourceNotFoundException | SessionLifetimeInMinutesInvalidException | ThrottlingException | UnsupportedPricingPlanException | UnsupportedUserEditionException | CommonErrors;
/**
 * Generates an embed URL that you can use to embed an Amazon Quick Sight experience in
 * your website. This action can be used for any type of user that is registered in an
 * Amazon Quick Sight account that uses IAM Identity Center for authentication. This API
 * requires identity-enhanced IAM Role sessions for the authenticated
 * user that the API call is being made for.
 *
 * This API uses trusted identity
 * propagation to ensure that an end user is authenticated and receives the
 * embed URL that is specific to that user. The IAM Identity Center application that the
 * user has logged into needs to have trusted Identity Propagation enabled for Amazon Quick Sight with the scope
 * value set to `quicksight:read`. Before you use this action, make sure that
 * you have configured the relevant Amazon Quick Sight resource and permissions.
 */
export declare const generateEmbedUrlForRegisteredUserWithIdentity: API.OperationMethod<GenerateEmbedUrlForRegisteredUserWithIdentityRequest & RegionInput, GenerateEmbedUrlForRegisteredUserWithIdentityResponse, GenerateEmbedUrlForRegisteredUserWithIdentityError, Credentials | HttpClient.HttpClient>;
export type GetDashboardEmbedUrlError = AccessDeniedException | DomainNotWhitelistedException | IdentityTypeNotSupportedException | InternalFailureException | InvalidParameterValueException | QuickSightUserNotFoundException | ResourceExistsException | ResourceNotFoundException | SessionLifetimeInMinutesInvalidException | ThrottlingException | UnsupportedPricingPlanException | UnsupportedUserEditionException | CommonErrors;
/**
 * Generates a temporary session URL and authorization code(bearer token) that you can
 * use to embed an Amazon Quick Sight read-only dashboard in your website or application.
 * Before you use this command, make sure that you have configured the dashboards and
 * permissions.
 *
 * Currently, you can use `GetDashboardEmbedURL` only from the server, not
 * from the user's browser. The following rules apply to the generated URL:
 *
 * - They must be used together.
 *
 * - They can be used one time only.
 *
 * - They are valid for 5 minutes after you run this command.
 *
 * - You are charged only when the URL is used or there is interaction with Quick.
 *
 * - The resulting user session is valid for 15 minutes (default) up to 10 hours
 * (maximum). You can use the optional `SessionLifetimeInMinutes`
 * parameter to customize session duration.
 *
 * For more information, see Embedding Analytics
 * Using GetDashboardEmbedUrl in the Amazon Quick User
 * Guide.
 *
 * For more information about the high-level steps for embedding and for an interactive
 * demo of the ways you can customize embedding, visit the Amazon Quick
 * Developer Portal.
 */
export declare const getDashboardEmbedUrl: API.OperationMethod<GetDashboardEmbedUrlRequest & RegionInput, GetDashboardEmbedUrlResponse, GetDashboardEmbedUrlError, Credentials | HttpClient.HttpClient>;
export type GetFlowMetadataError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Retrieves the metadata of a flow, not including its definition specifying the steps.
 */
export declare const getFlowMetadata: API.OperationMethod<GetFlowMetadataInput & RegionInput, GetFlowMetadataOutput, GetFlowMetadataError, Credentials | HttpClient.HttpClient>;
export type GetFlowPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Get permissions for a flow.
 */
export declare const getFlowPermissions: API.OperationMethod<GetFlowPermissionsInput & RegionInput, GetFlowPermissionsOutput, GetFlowPermissionsError, Credentials | HttpClient.HttpClient>;
export type GetIdentityContextError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retrieves the identity context for a Quick Sight user in a specified namespace, allowing you to obtain identity tokens that can be used with identity-enhanced IAM role sessions to call identity-aware APIs.
 *
 * Currently, you can call the following APIs with identity-enhanced Credentials
 *
 * - StartDashboardSnapshotJob
 *
 * - DescribeDashboardSnapshotJob
 *
 * - DescribeDashboardSnapshotJobResult
 *
 * **Supported Authentication Methods**
 *
 * This API supports Quick Sight native users, IAM federated users, and Active Directory users. For Quick Sight users authenticated by Amazon Web Services Identity Center, see Identity Center documentation on identity-enhanced IAM role sessions.
 *
 * **Supported Regions**
 *
 * The GetIdentityContext API works only in regions that support at least one of these identity types:
 *
 * - Amazon Quick Sight native identity
 *
 * - IAM federated identity
 *
 * - Active Directory
 *
 * To use this API successfully, call it in the same region where your user's identity resides. For example, if your user's identity is in us-east-1, make the API call in us-east-1. For more information about managing identities in Amazon Quick Sight, see Identity and access management in Amazon Quick Sight in the Amazon Quick Sight User Guide.
 *
 * **Getting Identity-Enhanced Credentials**
 *
 * To obtain identity-enhanced credentials, follow these steps:
 *
 * - Call the GetIdentityContext API to retrieve an identity token for the specified user.
 *
 * - Use the identity token with the STS AssumeRole API to obtain identity-enhanced IAM role session credentials.
 *
 * **Usage with STS AssumeRole**
 *
 * The identity token returned by this API should be used with the STS AssumeRole API to obtain credentials for an identity-enhanced IAM role session. When calling AssumeRole, include the identity token in the `ProvidedContexts` parameter with `ProviderArn` set to `arn:aws:iam::aws:contextProvider/QuickSight` and `ContextAssertion` set to the identity token received from this API.
 *
 * The assumed role must allow the `sts:SetContext` action in addition to `sts:AssumeRole` in its trust relationship policy. The trust policy should include both actions for the principal that will be assuming the role.
 */
export declare const getIdentityContext: API.OperationMethod<GetIdentityContextRequest & RegionInput, GetIdentityContextResponse, GetIdentityContextError, Credentials | HttpClient.HttpClient>;
export type GetSessionEmbedUrlError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | QuickSightUserNotFoundException | ResourceExistsException | ResourceNotFoundException | SessionLifetimeInMinutesInvalidException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Generates a session URL and authorization code that you can use to embed the Amazon
 * Amazon Quick Sight console in your web server code. Use
 * `GetSessionEmbedUrl` where you want to provide an authoring portal that
 * allows users to create data sources, datasets, analyses, and dashboards. The users who
 * access an embedded Amazon Quick Sight console need belong to the author or admin security
 * cohort. If you want to restrict permissions to some of these features, add a custom
 * permissions profile to the user with the
 * UpdateUser
 * API operation. Use
 * RegisterUser
 * API operation to add a new user with a custom
 * permission profile attached. For more information, see the following sections in the
 * *Amazon Quick User Guide*:
 *
 * - Embedding
 * Analytics
 *
 * - Customizing Access to the Amazon Quick Console
 */
export declare const getSessionEmbedUrl: API.OperationMethod<GetSessionEmbedUrlRequest & RegionInput, GetSessionEmbedUrlResponse, GetSessionEmbedUrlError, Credentials | HttpClient.HttpClient>;
export type ListActionConnectorsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists all action connectors in the specified Amazon Web Services account. Returns summary information for each connector including its name, type, creation time, and status.
 */
export declare const listActionConnectors: API.PaginatedOperationMethod<ListActionConnectorsRequest & RegionInput, ListActionConnectorsResponse, ListActionConnectorsError, Credentials | HttpClient.HttpClient, ActionConnectorSummary>;
export type ListAgentsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all agents in an Amazon QuickSight account.
 */
export declare const listAgents: API.OperationMethod<ListAgentsRequest & RegionInput, ListAgentsResponse, ListAgentsError, Credentials | HttpClient.HttpClient>;
export type ListAnalysesError = InternalFailureException | InvalidNextTokenException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists Amazon Quick Sight analyses that exist in the specified Amazon Web Services account.
 */
export declare const listAnalyses: API.PaginatedOperationMethod<ListAnalysesRequest & RegionInput, ListAnalysesResponse, ListAnalysesError, Credentials | HttpClient.HttpClient, AnalysisSummary>;
export type ListApprovalPoliciesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all approval policies in the specified Quick Sight account. The results are paginated. If the
 * response includes a `NextToken` value, pass it in a subsequent call to retrieve the next
 * set of results.
 */
export declare const listApprovalPolicies: API.PaginatedOperationMethod<ListApprovalPoliciesRequest & RegionInput, ListApprovalPoliciesResponse, ListApprovalPoliciesError, Credentials | HttpClient.HttpClient, ApprovalPolicy>;
export type ListAppsError = AccessDeniedException | InternalFailureException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Lists the apps in an Amazon Web Services account. Results are paginated; use the `NextToken` parameter to retrieve additional results.
 */
export declare const listApps: API.PaginatedOperationMethod<ListAppsRequest & RegionInput, ListAppsResponse, ListAppsError, Credentials | HttpClient.HttpClient, AppSummary>;
export type ListAssetBundleExportJobsError = AccessDeniedException | InvalidNextTokenException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all asset bundle export jobs that have been taken place in the last 14 days. Jobs
 * created more than 14 days ago are deleted forever and are not returned. If you are using
 * the same job ID for multiple jobs, `ListAssetBundleExportJobs` only returns the
 * most recent job that uses the repeated job ID.
 */
export declare const listAssetBundleExportJobs: API.PaginatedOperationMethod<ListAssetBundleExportJobsRequest & RegionInput, ListAssetBundleExportJobsResponse, ListAssetBundleExportJobsError, Credentials | HttpClient.HttpClient, AssetBundleExportJobSummary>;
export type ListAssetBundleImportJobsError = AccessDeniedException | InvalidNextTokenException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all asset bundle import jobs that have taken place in the last 14 days. Jobs
 * created more than 14 days ago are deleted forever and are not returned. If you are using
 * the same job ID for multiple jobs, `ListAssetBundleImportJobs` only returns the
 * most recent job that uses the repeated job ID.
 */
export declare const listAssetBundleImportJobs: API.PaginatedOperationMethod<ListAssetBundleImportJobsRequest & RegionInput, ListAssetBundleImportJobsResponse, ListAssetBundleImportJobsError, Credentials | HttpClient.HttpClient, AssetBundleImportJobSummary>;
export type ListBrandsError = AccessDeniedException | InternalServerException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists all brands in an Quick Sight account.
 */
export declare const listBrands: API.PaginatedOperationMethod<ListBrandsRequest & RegionInput, ListBrandsResponse, ListBrandsError, Credentials | HttpClient.HttpClient, BrandSummary>;
export type ListCustomPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all the custom permissions profiles.
 */
export declare const listCustomPermissions: API.PaginatedOperationMethod<ListCustomPermissionsRequest & RegionInput, ListCustomPermissionsResponse, ListCustomPermissionsError, Credentials | HttpClient.HttpClient, CustomPermissions>;
export type ListDashboardsError = InternalFailureException | InvalidNextTokenException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists dashboards in an Amazon Web Services account.
 */
export declare const listDashboards: API.PaginatedOperationMethod<ListDashboardsRequest & RegionInput, ListDashboardsResponse, ListDashboardsError, Credentials | HttpClient.HttpClient, DashboardSummary>;
export type ListDashboardVersionsError = InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the versions of the dashboards in the Amazon Quick Sight subscription.
 */
export declare const listDashboardVersions: API.PaginatedOperationMethod<ListDashboardVersionsRequest & RegionInput, ListDashboardVersionsResponse, ListDashboardVersionsError, Credentials | HttpClient.HttpClient, DashboardVersionSummary>;
export type ListDataSetsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists all of the datasets belonging to the current Amazon Web Services account in an
 * Amazon Web Services Region.
 *
 * The permissions resource is
 * `arn:aws:quicksight:region:aws-account-id:dataset/*`.
 */
export declare const listDataSets: API.PaginatedOperationMethod<ListDataSetsRequest & RegionInput, ListDataSetsResponse, ListDataSetsError, Credentials | HttpClient.HttpClient, DataSetSummary>;
export type ListDataSourcesError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists data sources in current Amazon Web Services Region that belong to this Amazon Web Services account.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest & RegionInput, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSource>;
export type ListDlpSettingsError = AccessDeniedException | InternalFailureException | InvalidRequestException | ThrottlingException | CommonErrors;
/**
 * Lists all DLP settings in an Amazon Web Services account.
 */
export declare const listDlpSettings: API.PaginatedOperationMethod<ListDlpSettingsRequest & RegionInput, ListDlpSettingsResponse, ListDlpSettingsError, Credentials | HttpClient.HttpClient, DlpSettingSummary>;
export type ListFlowsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists flows in an Amazon Web Services account.
 */
export declare const listFlows: API.PaginatedOperationMethod<ListFlowsInput & RegionInput, ListFlowsOutput, ListFlowsError, Credentials | HttpClient.HttpClient, FlowSummary>;
export type ListFolderMembersError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * List all assets (`DASHBOARD`, `ANALYSIS`, and `DATASET`) in a folder.
 */
export declare const listFolderMembers: API.PaginatedOperationMethod<ListFolderMembersRequest & RegionInput, ListFolderMembersResponse, ListFolderMembersError, Credentials | HttpClient.HttpClient, MemberIdArnPair>;
export type ListFoldersError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all folders in an account.
 */
export declare const listFolders: API.PaginatedOperationMethod<ListFoldersRequest & RegionInput, ListFoldersResponse, ListFoldersError, Credentials | HttpClient.HttpClient, FolderSummary>;
export type ListFoldersForResourceError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * List all folders that a resource is a member of.
 */
export declare const listFoldersForResource: API.PaginatedOperationMethod<ListFoldersForResourceRequest & RegionInput, ListFoldersForResourceResponse, ListFoldersForResourceError, Credentials | HttpClient.HttpClient, Arn>;
export type ListGroupMembershipsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists member users in a group.
 */
export declare const listGroupMemberships: API.PaginatedOperationMethod<ListGroupMembershipsRequest & RegionInput, ListGroupMembershipsResponse, ListGroupMembershipsError, Credentials | HttpClient.HttpClient, GroupMember>;
export type ListGroupsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all user groups in Amazon Quick Sight.
 */
export declare const listGroups: API.PaginatedOperationMethod<ListGroupsRequest & RegionInput, ListGroupsResponse, ListGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type ListIAMPolicyAssignmentsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the
 * IAM policy assignments in the current Amazon Quick Sight
 * account.
 */
export declare const listIAMPolicyAssignments: API.PaginatedOperationMethod<ListIAMPolicyAssignmentsRequest & RegionInput, ListIAMPolicyAssignmentsResponse, ListIAMPolicyAssignmentsError, Credentials | HttpClient.HttpClient, IAMPolicyAssignmentSummary>;
export type ListIAMPolicyAssignmentsForUserError = AccessDeniedException | ConcurrentUpdatingException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of
 * the IAM policy assignments, including the Amazon
 * Resource Names
 * (ARNs),
 * for the IAM policies assigned to the specified user and
 * group,
 * or groups that the user belongs to.
 */
export declare const listIAMPolicyAssignmentsForUser: API.PaginatedOperationMethod<ListIAMPolicyAssignmentsForUserRequest & RegionInput, ListIAMPolicyAssignmentsForUserResponse, ListIAMPolicyAssignmentsForUserError, Credentials | HttpClient.HttpClient, ActiveIAMPolicyAssignment>;
export type ListIdentityPropagationConfigsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all services and authorized targets that the Quick Sight IAM Identity Center application can access.
 *
 * This operation is only supported for Quick Sight accounts that use IAM Identity Center.
 */
export declare const listIdentityPropagationConfigs: API.OperationMethod<ListIdentityPropagationConfigsRequest & RegionInput, ListIdentityPropagationConfigsResponse, ListIdentityPropagationConfigsError, Credentials | HttpClient.HttpClient>;
export type ListIngestionsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the history of SPICE ingestions for a dataset. Limited to 5 TPS per user and 25 TPS per account.
 */
export declare const listIngestions: API.PaginatedOperationMethod<ListIngestionsRequest & RegionInput, ListIngestionsResponse, ListIngestionsError, Credentials | HttpClient.HttpClient, Ingestion>;
export type ListKnowledgeBasesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | PreconditionNotMetException | ThrottlingException | CommonErrors;
/**
 * Lists all knowledge bases in an Amazon QuickSight account.
 */
export declare const listKnowledgeBases: API.PaginatedOperationMethod<ListKnowledgeBasesRequest & RegionInput, ListKnowledgeBasesResponse, ListKnowledgeBasesError, Credentials | HttpClient.HttpClient, KnowledgeBaseSummary>;
export type ListLimitsProfilesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists all limits profiles in an Amazon Quick Sight account. Results are paginated. Use the `maxResults` parameter to limit the number of results returned in a single call, and use the `nextToken` parameter to retrieve the next page of results.
 */
export declare const listLimitsProfiles: API.PaginatedOperationMethod<ListLimitsProfilesRequest & RegionInput, ListLimitsProfilesResponse, ListLimitsProfilesError, Credentials | HttpClient.HttpClient, LimitsProfile>;
export type ListNamespacesError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the namespaces for the specified Amazon Web Services account. This operation doesn't list deleted namespaces.
 */
export declare const listNamespaces: API.PaginatedOperationMethod<ListNamespacesRequest & RegionInput, ListNamespacesResponse, ListNamespacesError, Credentials | HttpClient.HttpClient, NamespaceInfoV2>;
export type ListOAuthClientApplicationsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all OAuthClientApplications in the current Amazon Web Services Region that belong to this Amazon Web Services account.
 */
export declare const listOAuthClientApplications: API.PaginatedOperationMethod<ListOAuthClientApplicationsRequest & RegionInput, ListOAuthClientApplicationsResponse, ListOAuthClientApplicationsError, Credentials | HttpClient.HttpClient, OAuthClientApplicationSummary>;
export type ListRefreshSchedulesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the refresh schedules of a dataset. Each dataset can have up to 5 schedules.
 */
export declare const listRefreshSchedules: API.OperationMethod<ListRefreshSchedulesRequest & RegionInput, ListRefreshSchedulesResponse, ListRefreshSchedulesError, Credentials | HttpClient.HttpClient>;
export type ListRoleMembershipsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all groups that are associated with a role.
 */
export declare const listRoleMemberships: API.PaginatedOperationMethod<ListRoleMembershipsRequest & RegionInput, ListRoleMembershipsResponse, ListRoleMembershipsError, Credentials | HttpClient.HttpClient, string>;
export type ListSelfUpgradesError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists all self-upgrade requests for a Quick account.
 */
export declare const listSelfUpgrades: API.OperationMethod<ListSelfUpgradesRequest & RegionInput, ListSelfUpgradesResponse, ListSelfUpgradesError, Credentials | HttpClient.HttpClient>;
export type ListSpaceResourcesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the resources in an Amazon QuickSight space.
 */
export declare const listSpaceResources: API.OperationMethod<ListSpaceResourcesRequest & RegionInput, ListSpaceResourcesResponse, ListSpaceResourcesError, Credentials | HttpClient.HttpClient>;
export type ListSpacesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all Amazon QuickSight spaces in an Amazon Web Services account.
 */
export declare const listSpaces: API.OperationMethod<ListSpacesRequest & RegionInput, ListSpacesResponse, ListSpacesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists the tags assigned to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplateAliasesError = InternalFailureException | InvalidNextTokenException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the aliases of a template.
 */
export declare const listTemplateAliases: API.PaginatedOperationMethod<ListTemplateAliasesRequest & RegionInput, ListTemplateAliasesResponse, ListTemplateAliasesError, Credentials | HttpClient.HttpClient, TemplateAlias>;
export type ListTemplatesError = InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the templates in the current Amazon Quick Sight account.
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListTemplatesRequest & RegionInput, ListTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListTemplateVersionsError = InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the versions of the templates in the current Amazon Quick Sight account.
 */
export declare const listTemplateVersions: API.PaginatedOperationMethod<ListTemplateVersionsRequest & RegionInput, ListTemplateVersionsResponse, ListTemplateVersionsError, Credentials | HttpClient.HttpClient, TemplateVersionSummary>;
export type ListThemeAliasesError = ConflictException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the aliases of a theme.
 */
export declare const listThemeAliases: API.OperationMethod<ListThemeAliasesRequest & RegionInput, ListThemeAliasesResponse, ListThemeAliasesError, Credentials | HttpClient.HttpClient>;
export type ListThemesError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the themes in the current Amazon Web Services account.
 */
export declare const listThemes: API.PaginatedOperationMethod<ListThemesRequest & RegionInput, ListThemesResponse, ListThemesError, Credentials | HttpClient.HttpClient, ThemeSummary>;
export type ListThemeVersionsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all the versions of the themes in the current Amazon Web Services account.
 */
export declare const listThemeVersions: API.PaginatedOperationMethod<ListThemeVersionsRequest & RegionInput, ListThemeVersionsResponse, ListThemeVersionsError, Credentials | HttpClient.HttpClient, ThemeVersionSummary>;
export type ListTopicRefreshSchedulesError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all of the refresh schedules for a topic.
 */
export declare const listTopicRefreshSchedules: API.OperationMethod<ListTopicRefreshSchedulesRequest & RegionInput, ListTopicRefreshSchedulesResponse, ListTopicRefreshSchedulesError, Credentials | HttpClient.HttpClient>;
export type ListTopicReviewedAnswersError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists all reviewed answers for a Q Topic.
 */
export declare const listTopicReviewedAnswers: API.OperationMethod<ListTopicReviewedAnswersRequest & RegionInput, ListTopicReviewedAnswersResponse, ListTopicReviewedAnswersError, Credentials | HttpClient.HttpClient>;
export type ListTopicsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists all of the topics within an account.
 */
export declare const listTopics: API.PaginatedOperationMethod<ListTopicsRequest & RegionInput, ListTopicsResponse, ListTopicsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTopicsV2Error = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Lists all of the Q topics in the specified Amazon Web Services account in an Amazon Web Services Region.
 */
export declare const listTopicsV2: API.PaginatedOperationMethod<ListTopicsV2Request & RegionInput, ListTopicsV2Response, ListTopicsV2Error, Credentials | HttpClient.HttpClient, TopicV2Summary>;
export type ListUserGroupsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Lists the Amazon Quick Sight groups that an Amazon Quick Sight user is a member of.
 */
export declare const listUserGroups: API.PaginatedOperationMethod<ListUserGroupsRequest & RegionInput, ListUserGroupsResponse, ListUserGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type ListUsersError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Returns a list of all of the Amazon Quick Sight users belonging to this account.
 */
export declare const listUsers: API.PaginatedOperationMethod<ListUsersRequest & RegionInput, ListUsersResponse, ListUsersError, Credentials | HttpClient.HttpClient, User>;
export type ListUsersIndexCapacityError = AccessDeniedException | InternalFailureException | InvalidRequestException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Lists per-user index capacity consumption for an account.
 */
export declare const listUsersIndexCapacity: API.OperationMethod<ListUsersIndexCapacityRequest & RegionInput, ListUsersIndexCapacityResponse, ListUsersIndexCapacityError, Credentials | HttpClient.HttpClient>;
export type ListVPCConnectionsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Lists all of the VPC connections in the current set Amazon Web Services Region of an
 * Amazon Web Services account.
 */
export declare const listVPCConnections: API.PaginatedOperationMethod<ListVPCConnectionsRequest & RegionInput, ListVPCConnectionsResponse, ListVPCConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type PredictQAResultsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Predicts existing visuals or generates new visuals to answer a given query.
 *
 * This API uses trusted identity propagation to ensure that an end user is authenticated and receives the embed URL that is specific to that user. The IAM Identity Center application that the user has logged into needs to have trusted Identity Propagation enabled for Quick with the scope value set to `quicksight:read`. Before you use this action, make sure that you have configured the relevant Quick resource and permissions.
 *
 * We recommend enabling the `QSearchStatus` API to unlock the full potential of `PredictQnA`. When `QSearchStatus` is enabled, it first checks the specified dashboard for any existing visuals that match the question. If no matching visuals are found, `PredictQnA` uses generative Q&A to provide an answer. To update the `QSearchStatus`, see UpdateQuickSightQSearchConfiguration.
 */
export declare const predictQAResults: API.OperationMethod<PredictQAResultsRequest & RegionInput, PredictQAResultsResponse, PredictQAResultsError, Credentials | HttpClient.HttpClient>;
export type PutDataSetRefreshPropertiesError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Creates or updates the dataset refresh properties for the dataset.
 */
export declare const putDataSetRefreshProperties: API.OperationMethod<PutDataSetRefreshPropertiesRequest & RegionInput, PutDataSetRefreshPropertiesResponse, PutDataSetRefreshPropertiesError, Credentials | HttpClient.HttpClient>;
export type RegisterUserError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceExistsException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Creates an Amazon Quick Sight user whose identity is associated with the Identity and Access Management (IAM) identity or role specified in the request. When you register a new user from the Quick Sight API, Quick Sight generates a registration URL. The user accesses this registration URL to create their account. Quick Sight doesn't send a registration email to users who are registered from the Quick Sight API. If you want new users to receive a registration email, then add those users in the Quick Sight console. For more information on registering a new user in the Quick Sight console, see Inviting users to access Quick Sight.
 */
export declare const registerUser: API.OperationMethod<RegisterUserRequest & RegionInput, RegisterUserResponse, RegisterUserError, Credentials | HttpClient.HttpClient>;
export type RestoreAnalysisError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Restores an analysis.
 */
export declare const restoreAnalysis: API.OperationMethod<RestoreAnalysisRequest & RegionInput, RestoreAnalysisResponse, RestoreAnalysisError, Credentials | HttpClient.HttpClient>;
export type SearchActionConnectorsError = AccessDeniedException | InvalidNextTokenException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Searches for action connectors in the specified Amazon Web Services account using filters. You can search by connector name, type, or user permissions.
 */
export declare const searchActionConnectors: API.PaginatedOperationMethod<SearchActionConnectorsRequest & RegionInput, SearchActionConnectorsResponse, SearchActionConnectorsError, Credentials | HttpClient.HttpClient, ActionConnectorSummary>;
export type SearchAgentsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceExistsException | ThrottlingException | CommonErrors;
/**
 * Searches for agents based on specified filters.
 */
export declare const searchAgents: API.OperationMethod<SearchAgentsRequest & RegionInput, SearchAgentsResponse, SearchAgentsError, Credentials | HttpClient.HttpClient>;
export type SearchAnalysesError = InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Searches for analyses that belong to the user specified in the filter.
 *
 * This operation is eventually consistent. The results are best effort and may not reflect very recent updates and changes.
 */
export declare const searchAnalyses: API.PaginatedOperationMethod<SearchAnalysesRequest & RegionInput, SearchAnalysesResponse, SearchAnalysesError, Credentials | HttpClient.HttpClient, AnalysisSummary>;
export type SearchAppsError = AccessDeniedException | InternalFailureException | InvalidParameterException | ThrottlingException | CommonErrors;
/**
 * Searches for apps in an Amazon Web Services account using the specified filters. This operation is eventually consistent; the results might not reflect very recent updates. Results are paginated; use the `NextToken` parameter to retrieve additional results.
 */
export declare const searchApps: API.PaginatedOperationMethod<SearchAppsRequest & RegionInput, SearchAppsResponse, SearchAppsError, Credentials | HttpClient.HttpClient, AppSummary>;
export type SearchDashboardsError = InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Searches for dashboards that belong to a user.
 *
 * This operation is eventually consistent. The results are best effort and may not
 * reflect very recent updates and changes.
 */
export declare const searchDashboards: API.PaginatedOperationMethod<SearchDashboardsRequest & RegionInput, SearchDashboardsResponse, SearchDashboardsError, Credentials | HttpClient.HttpClient, DashboardSummary>;
export type SearchDataSetsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Use the `SearchDataSets` operation to search for datasets that belong to an
 * account.
 */
export declare const searchDataSets: API.PaginatedOperationMethod<SearchDataSetsRequest & RegionInput, SearchDataSetsResponse, SearchDataSetsError, Credentials | HttpClient.HttpClient, DataSetSummary>;
export type SearchDataSourcesError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Use the `SearchDataSources` operation to search for data sources that
 * belong to an account.
 */
export declare const searchDataSources: API.PaginatedOperationMethod<SearchDataSourcesRequest & RegionInput, SearchDataSourcesResponse, SearchDataSourcesError, Credentials | HttpClient.HttpClient, DataSourceSummary>;
export type SearchFlowsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Search for the flows in an Amazon Web Services account.
 */
export declare const searchFlows: API.PaginatedOperationMethod<SearchFlowsInput & RegionInput, SearchFlowsOutput, SearchFlowsError, Credentials | HttpClient.HttpClient, FlowSummary>;
export type SearchFoldersError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Searches the subfolders in a folder.
 */
export declare const searchFolders: API.PaginatedOperationMethod<SearchFoldersRequest & RegionInput, SearchFoldersResponse, SearchFoldersError, Credentials | HttpClient.HttpClient, FolderSummary>;
export type SearchGroupsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Use the `SearchGroups` operation to search groups in a specified Quick Sight namespace using the supplied filters.
 */
export declare const searchGroups: API.PaginatedOperationMethod<SearchGroupsRequest & RegionInput, SearchGroupsResponse, SearchGroupsError, Credentials | HttpClient.HttpClient, Group>;
export type SearchKnowledgeBasesError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for a subset of knowledge bases based on specified filters.
 */
export declare const searchKnowledgeBases: API.PaginatedOperationMethod<SearchKnowledgeBasesRequest & RegionInput, SearchKnowledgeBasesResponse, SearchKnowledgeBasesError, Credentials | HttpClient.HttpClient, KnowledgeBaseSummary>;
export type SearchSpacesError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for Amazon QuickSight spaces that match the specified filters.
 */
export declare const searchSpaces: API.OperationMethod<SearchSpacesRequest & RegionInput, SearchSpacesResponse, SearchSpacesError, Credentials | HttpClient.HttpClient>;
export type SearchTopicsError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Searches for any Q topic that exists in an Quick account.
 */
export declare const searchTopics: API.PaginatedOperationMethod<SearchTopicsRequest & RegionInput, SearchTopicsResponse, SearchTopicsError, Credentials | HttpClient.HttpClient, TopicSummary>;
export type SearchTopicsV2Error = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Searches for any Q topic that exists in an Amazon Web Services account.
 */
export declare const searchTopicsV2: API.PaginatedOperationMethod<SearchTopicsV2Request & RegionInput, SearchTopicsV2Response, SearchTopicsV2Error, Credentials | HttpClient.HttpClient, TopicV2Summary>;
export type StartAssetBundleExportJobError = AccessDeniedException | ConflictException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Starts an Asset Bundle export job.
 *
 * An Asset Bundle export job exports specified Amazon Quick Sight assets. You can also choose to
 * export any asset dependencies in the same job. Export jobs run asynchronously and can be
 * polled with a `DescribeAssetBundleExportJob` API call. When a job is
 * successfully completed, a download URL that contains the exported assets is returned. The
 * URL is valid for 5 minutes and can be refreshed with a
 * `DescribeAssetBundleExportJob` API call. Each Amazon Quick Sight account can
 * run up to 5 export jobs concurrently.
 *
 * The API caller must have the necessary permissions in their IAM role to
 * access each resource before the resources can be exported.
 */
export declare const startAssetBundleExportJob: API.OperationMethod<StartAssetBundleExportJobRequest & RegionInput, StartAssetBundleExportJobResponse, StartAssetBundleExportJobError, Credentials | HttpClient.HttpClient>;
export type StartAssetBundleImportJobError = AccessDeniedException | ConflictException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Starts an Asset Bundle import job.
 *
 * An Asset Bundle import job imports specified Amazon Quick Sight assets into an Amazon Quick
 * Sight account. You can also choose to import a naming prefix and specified configuration
 * overrides. The assets that are contained in the bundle file that you provide are used to
 * create or update a new or existing asset in your Amazon Quick Sight account. Each Amazon
 * Quick Sight account can run up to 5 import jobs concurrently.
 *
 * The API caller must have the necessary `"create"`, `"describe"`,
 * and `"update"` permissions in their IAM role to access each
 * resource type that is contained in the bundle file before the resources can be
 * imported.
 */
export declare const startAssetBundleImportJob: API.OperationMethod<StartAssetBundleImportJobRequest & RegionInput, StartAssetBundleImportJobResponse, StartAssetBundleImportJobError, Credentials | HttpClient.HttpClient>;
export type StartAutomationJobError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Starts a new job for a specified automation. The job runs the automation with the provided input payload.
 */
export declare const startAutomationJob: API.OperationMethod<StartAutomationJobRequest & RegionInput, StartAutomationJobResponse, StartAutomationJobError, Credentials | HttpClient.HttpClient>;
export type StartDashboardSnapshotJobError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedPricingPlanException | UnsupportedUserEditionException | CommonErrors;
/**
 * Starts an asynchronous job that generates a snapshot of a dashboard's output. You can request one or several of the following format configurations in each API call.
 *
 * - 1 PDF
 *
 * - 1 Excel workbook that includes up to 5 table or pivot table visuals
 *
 * - 5 CSVs from table or pivot table visuals
 *
 * Exporting CSV, Excel, or Pixel Perfect PDF reports requires Pixel Perfect Report Add-on.
 *
 * The status of a submitted job can be polled with the `DescribeDashboardSnapshotJob` API. When you call the `DescribeDashboardSnapshotJob` API, check the `JobStatus` field in the response. Once the job reaches a `COMPLETED` or `FAILED` status, use the `DescribeDashboardSnapshotJobResult` API to obtain the URLs for the generated files. If the job fails, the `DescribeDashboardSnapshotJobResult` API returns detailed information about the error that occurred.
 *
 * **StartDashboardSnapshotJob API throttling**
 *
 * Quick Sight utilizes API throttling to create a more consistent user experience within a time span for customers when they call the `StartDashboardSnapshotJob`. By default, 12 jobs can run simlutaneously in one Amazon Web Services account and users can submit up 10 API requests per second before an account is throttled. If an overwhelming number of API requests are made by the same user in a short period of time, Quick Sight throttles the API calls to maintin an optimal experience and reliability for all Quick Sight users.
 *
 * **Common throttling scenarios**
 *
 * The following list provides information about the most commin throttling scenarios that can occur.
 *
 * - **A large number of `SnapshotExport` API jobs are running simultaneously on an Amazon Web Services account.** When a new `StartDashboardSnapshotJob` is created and there are already 12 jobs with the `RUNNING` status, the new job request fails and returns a `LimitExceededException` error. Wait for a current job to comlpete before you resubmit the new job.
 *
 * - **A large number of API requests are submitted on an Amazon Web Services account.** When a user makes more than 10 API calls to the Quick Sight API in one second, a `ThrottlingException` is returned.
 *
 * If your use case requires a higher throttling limit, contact your account admin or Amazon Web ServicesSupport to explore options to tailor a more optimal expereince for your account.
 *
 * **Best practices to handle throttling**
 *
 * If your use case projects high levels of API traffic, try to reduce the degree of frequency and parallelism of API calls as much as you can to avoid throttling. You can also perform a timing test to calculate an estimate for the total processing time of your projected load that stays within the throttling limits of the Quick Sight APIs. For example, if your projected traffic is 100 snapshot jobs before 12:00 PM per day, start 12 jobs in parallel and measure the amount of time it takes to proccess all 12 jobs. Once you obtain the result, multiply the duration by 9, for example `(12 minutes * 9 = 108 minutes)`. Use the new result to determine the latest time at which the jobs need to be started to meet your target deadline.
 *
 * The time that it takes to process a job can be impacted by the following factors:
 *
 * - The dataset type (Direct Query or SPICE).
 *
 * - The size of the dataset.
 *
 * - The complexity of the calculated fields that are used in the dashboard.
 *
 * - The number of visuals that are on a sheet.
 *
 * - The types of visuals that are on the sheet.
 *
 * - The number of formats and snapshots that are requested in the job configuration.
 *
 * - The size of the generated snapshots.
 *
 * **Registered user support**
 *
 * You can generate snapshots for registered Quick Sight users by using the Snapshot Job APIs with identity-enhanced IAM role session credentials. This approach allows you to create snapshots on behalf of specific Quick Sight users while respecting their row-level security (RLS), column-level security (CLS), dynamic default parameters and dashboard parameter/filter settings.
 *
 * To generate snapshots for registered Quick Sight users, you need to:
 *
 * - Obtain identity-enhanced IAM role session credentials from Amazon Web Services Security Token Service (STS).
 *
 * - Use these credentials to call the Snapshot Job APIs.
 *
 * Identity-enhanced credentials are credentials that contain information about the end user (e.g., registered Quick Sight user).
 *
 * If your Quick Sight users are backed by Amazon Web Services Identity Center, then you need to set up a trusted token issuer. Then, getting identity-enhanced IAM credentials for a Quick Sight user will look like the following:
 *
 * - Authenticate user with your OIDC compliant Identity Provider. You should get auth tokens back.
 *
 * - Use the OIDC API, CreateTokenWithIAM, to exchange auth tokens to IAM tokens. One of the resulted tokens will be identity token.
 *
 * - Call STS AssumeRole API as you normally would, but provide an extra `ProvidedContexts` parameter in the API request. The list of contexts must have a single trusted context assertion. The `ProviderArn` should be `arn:aws:iam::aws:contextProvider/IdentityCenter` while `ContextAssertion` will be the identity token you received in response from CreateTokenWithIAM
 *
 * For more details, see IdC documentation on Identity-enhanced IAM role sessions.
 *
 * To obtain Identity-enhanced credentials for Quick Sight native users, IAM federated users, or Active Directory users, follow the steps below:
 *
 * - Call Quick Sight GetIdentityContext API to get identity token.
 *
 * - Call STS AssumeRole API as you normally would, but provide extra `ProvidedContexts` parameter in the API request. The list of contexts must have a single trusted context assertion. The `ProviderArn` should be `arn:aws:iam::aws:contextProvider/QuickSight` while `ContextAssertion` will be the identity token you received in response from GetIdentityContext
 *
 * After obtaining the identity-enhanced IAM role session credentials, you can use them to start a job, describe the job and describe job result. You can use the same credentials as long as they haven't expired. All API requests made with these credentials are considered to be made by the impersonated Quick Sight user.
 *
 * When using identity-enhanced session credentials, set the UserConfiguration request attribute to null. Otherwise, the request will be invalid.
 *
 * **Possible error scenarios**
 *
 * The request fails with an Access Denied error in the following scenarios:
 *
 * - The credentials have expired.
 *
 * - The impersonated Quick Sight user doesn't have access to the specified dashboard.
 *
 * - The impersonated Quick Sight user is restricted from exporting data in the selected formats. For more information about export restrictions, see Customizing access to Amazon Quick Sight capabilities.
 */
export declare const startDashboardSnapshotJob: API.OperationMethod<StartDashboardSnapshotJobRequest & RegionInput, StartDashboardSnapshotJobResponse, StartDashboardSnapshotJobError, Credentials | HttpClient.HttpClient>;
export type StartDashboardSnapshotJobScheduleError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Starts an asynchronous job that runs an existing dashboard schedule and sends the dashboard snapshot through email.
 *
 * Only one job can run simultaneously in a given schedule. Repeated requests are skipped with a `202` HTTP status code.
 *
 * For more information, see Scheduling and sending Amazon Quick Sight reports by email and Configuring email report settings for a Amazon Quick Sight dashboard in the *Amazon Quick Sight User Guide*.
 */
export declare const startDashboardSnapshotJobSchedule: API.OperationMethod<StartDashboardSnapshotJobScheduleRequest & RegionInput, StartDashboardSnapshotJobScheduleResponse, StartDashboardSnapshotJobScheduleError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified Amazon Quick Sight
 * resource.
 *
 * Tags can help you organize and categorize your resources. You can also use them to
 * scope user permissions, by granting a user permission to access or change only resources
 * with certain tag values. You can use the `TagResource` operation with a
 * resource that already has tags. If you specify a new tag key for the resource, this tag
 * is appended to the list of tags associated with the resource. If you specify a tag key
 * that is already associated with the resource, the new tag value that you specify
 * replaces the previous value for that tag.
 *
 * You can associate as many as 50 tags with a resource. Amazon Quick Sight supports
 * tagging on data set, data source, dashboard, template, topic, and user.
 *
 * Tagging for Amazon Quick Sight works in a similar way to tagging for other Amazon Web Services services, except for the following:
 *
 * - Tags are used to track costs for users in Amazon Quick Sight. You can't
 * tag other resources that Amazon Quick Sight costs are based on, such as storage
 * capacoty (SPICE), session usage, alert consumption, or reporting units.
 *
 * - Amazon Quick Sight doesn't currently support the tag editor for Resource Groups.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Removes a tag or tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountCustomizationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates Amazon Quick Sight customizations. Currently, the only customization that you can use is a theme.
 *
 * You can use customizations for your Amazon Web Services account or, if you specify a namespace, for a
 * Quick Sight namespace instead. Customizations that apply to a namespace override
 * customizations that apply to an Amazon Web Services account. To find out which customizations apply, use
 * the `DescribeAccountCustomization` API operation.
 */
export declare const updateAccountCustomization: API.OperationMethod<UpdateAccountCustomizationRequest & RegionInput, UpdateAccountCustomizationResponse, UpdateAccountCustomizationError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountCustomPermissionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Applies a custom permissions profile to an account.
 */
export declare const updateAccountCustomPermission: API.OperationMethod<UpdateAccountCustomPermissionRequest & RegionInput, UpdateAccountCustomPermissionResponse, UpdateAccountCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type UpdateAccountSettingsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the Amazon Quick Sight settings in your Amazon Web Services account.
 */
export declare const updateAccountSettings: API.OperationMethod<UpdateAccountSettingsRequest & RegionInput, UpdateAccountSettingsResponse, UpdateAccountSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateActionConnectorError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing action connector with new configuration details, authentication settings, or enabled actions.
 * You can modify the connector's name, description, authentication configuration, and which actions are enabled. For more information,
 * https://docs.aws.amazon.com/quicksuite/latest/userguide/quick-action-auth.html.
 */
export declare const updateActionConnector: API.OperationMethod<UpdateActionConnectorRequest & RegionInput, UpdateActionConnectorResponse, UpdateActionConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateActionConnectorPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the permissions for an action connector by granting or revoking access for specific users and groups. You can control who can view, use, or manage the action connector.
 */
export declare const updateActionConnectorPermissions: API.OperationMethod<UpdateActionConnectorPermissionsRequest & RegionInput, UpdateActionConnectorPermissionsResponse, UpdateActionConnectorPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing agent.
 */
export declare const updateAgent: API.OperationMethod<UpdateAgentRequest & RegionInput, UpdateAgentResponse, UpdateAgentError, Credentials | HttpClient.HttpClient>;
export type UpdateAgentPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the resource permissions for an agent.
 */
export declare const updateAgentPermissions: API.OperationMethod<UpdateAgentPermissionsRequest & RegionInput, UpdateAgentPermissionsResponse, UpdateAgentPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateAnalysisError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates an analysis in Amazon Quick Sight
 */
export declare const updateAnalysis: API.OperationMethod<UpdateAnalysisRequest & RegionInput, UpdateAnalysisResponse, UpdateAnalysisError, Credentials | HttpClient.HttpClient>;
export type UpdateAnalysisPermissionsError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the read and write permissions for an analysis.
 */
export declare const updateAnalysisPermissions: API.OperationMethod<UpdateAnalysisPermissionsRequest & RegionInput, UpdateAnalysisPermissionsResponse, UpdateAnalysisPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationWithTokenExchangeGrantError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an Quick application with a token exchange grant. This operation only supports Quick applications that are registered with IAM Identity Center.
 */
export declare const updateApplicationWithTokenExchangeGrant: API.OperationMethod<UpdateApplicationWithTokenExchangeGrantRequest & RegionInput, UpdateApplicationWithTokenExchangeGrantResponse, UpdateApplicationWithTokenExchangeGrantError, Credentials | HttpClient.HttpClient>;
export type UpdateAppPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the resource permissions for an app. You can grant or revoke permissions and, optionally, change the app's visibility.
 */
export declare const updateAppPermissions: API.OperationMethod<UpdateAppPermissionsRequest & RegionInput, UpdateAppPermissionsResponse, UpdateAppPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateApprovalPolicyError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an approval policy in Quick Sight.
 */
export declare const updateApprovalPolicy: API.OperationMethod<UpdateApprovalPolicyRequest & RegionInput, UpdateApprovalPolicyResponse, UpdateApprovalPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateBrandError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a brand.
 */
export declare const updateBrand: API.OperationMethod<UpdateBrandRequest & RegionInput, UpdateBrandResponse, UpdateBrandError, Credentials | HttpClient.HttpClient>;
export type UpdateBrandAssignmentError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a brand assignment.
 */
export declare const updateBrandAssignment: API.OperationMethod<UpdateBrandAssignmentRequest & RegionInput, UpdateBrandAssignmentResponse, UpdateBrandAssignmentError, Credentials | HttpClient.HttpClient>;
export type UpdateBrandPublishedVersionError = AccessDeniedException | ConflictException | InternalServerException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the published version of a brand.
 */
export declare const updateBrandPublishedVersion: API.OperationMethod<UpdateBrandPublishedVersionRequest & RegionInput, UpdateBrandPublishedVersionResponse, UpdateBrandPublishedVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateCustomPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates a custom permissions profile.
 */
export declare const updateCustomPermissions: API.OperationMethod<UpdateCustomPermissionsRequest & RegionInput, UpdateCustomPermissionsResponse, UpdateCustomPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates a dashboard in an Amazon Web Services account.
 *
 * Updating a Dashboard creates a new dashboard version but does not immediately
 * publish the new version. You can update the published version of a dashboard by
 * using the
 * UpdateDashboardPublishedVersion
 * API operation.
 */
export declare const updateDashboard: API.OperationMethod<UpdateDashboardRequest & RegionInput, UpdateDashboardResponse, UpdateDashboardError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardLinksError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the linked analyses on a dashboard.
 */
export declare const updateDashboardLinks: API.OperationMethod<UpdateDashboardLinksRequest & RegionInput, UpdateDashboardLinksResponse, UpdateDashboardLinksError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardPermissionsError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates read and write permissions on a dashboard.
 */
export declare const updateDashboardPermissions: API.OperationMethod<UpdateDashboardPermissionsRequest & RegionInput, UpdateDashboardPermissionsResponse, UpdateDashboardPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardPublishedVersionError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the published version of a dashboard.
 */
export declare const updateDashboardPublishedVersion: API.OperationMethod<UpdateDashboardPublishedVersionRequest & RegionInput, UpdateDashboardPublishedVersionResponse, UpdateDashboardPublishedVersionError, Credentials | HttpClient.HttpClient>;
export type UpdateDashboardsQAConfigurationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a Dashboard QA configuration.
 */
export declare const updateDashboardsQAConfiguration: API.OperationMethod<UpdateDashboardsQAConfigurationRequest & RegionInput, UpdateDashboardsQAConfigurationResponse, UpdateDashboardsQAConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSetError = AccessDeniedException | ConflictException | InternalFailureException | InvalidDataSetParameterValueException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates a dataset. Partial updates are not supported by this operation.
 */
export declare const updateDataSet: API.OperationMethod<UpdateDataSetRequest & RegionInput, UpdateDataSetResponse, UpdateDataSetError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSetPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the permissions on a dataset.
 *
 * The permissions resource is
 * `arn:aws:quicksight:region:aws-account-id:dataset/data-set-id`.
 */
export declare const updateDataSetPermissions: API.OperationMethod<UpdateDataSetPermissionsRequest & RegionInput, UpdateDataSetPermissionsResponse, UpdateDataSetPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = AccessDeniedException | ConflictException | CustomerManagedKeyUnavailableException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a data source.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest & RegionInput, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourcePermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the permissions to a data source.
 */
export declare const updateDataSourcePermissions: API.OperationMethod<UpdateDataSourcePermissionsRequest & RegionInput, UpdateDataSourcePermissionsResponse, UpdateDataSourcePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateDefaultQBusinessApplicationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a Amazon Q Business application that is linked to a Quick Sight account.
 */
export declare const updateDefaultQBusinessApplication: API.OperationMethod<UpdateDefaultQBusinessApplicationRequest & RegionInput, UpdateDefaultQBusinessApplicationResponse, UpdateDefaultQBusinessApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateDlpSettingError = AccessDeniedException | ConflictException | InternalFailureException | InvalidRequestException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing DLP setting configuration in an Amazon Web Services account. Fields that are omitted from the request retain their current values.
 */
export declare const updateDlpSetting: API.OperationMethod<UpdateDlpSettingRequest & RegionInput, UpdateDlpSettingResponse, UpdateDlpSettingError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing flow. Supply only the fields you want to change. Updates both DRAFT and PUBLISHED versions. When `FlowDefinition` is provided, all existing steps are replaced with the new definition.
 */
export declare const updateFlow: API.OperationMethod<UpdateFlowRequest & RegionInput, UpdateFlowResponse, UpdateFlowError, Credentials | HttpClient.HttpClient>;
export type UpdateFlowPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Updates permissions against principals on a flow.
 */
export declare const updateFlowPermissions: API.OperationMethod<UpdateFlowPermissionsInput & RegionInput, UpdateFlowPermissionsOutput, UpdateFlowPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateFolderError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the name of a folder.
 */
export declare const updateFolder: API.OperationMethod<UpdateFolderRequest & RegionInput, UpdateFolderResponse, UpdateFolderError, Credentials | HttpClient.HttpClient>;
export type UpdateFolderPermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates permissions of a folder.
 */
export declare const updateFolderPermissions: API.OperationMethod<UpdateFolderPermissionsRequest & RegionInput, UpdateFolderPermissionsResponse, UpdateFolderPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateGroupError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Changes a group description.
 */
export declare const updateGroup: API.OperationMethod<UpdateGroupRequest & RegionInput, UpdateGroupResponse, UpdateGroupError, Credentials | HttpClient.HttpClient>;
export type UpdateIAMPolicyAssignmentError = AccessDeniedException | ConcurrentUpdatingException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an existing IAM policy assignment. This operation updates only
 * the optional parameter or parameters that are specified in the request. This overwrites
 * all of the users included in `Identities`.
 */
export declare const updateIAMPolicyAssignment: API.OperationMethod<UpdateIAMPolicyAssignmentRequest & RegionInput, UpdateIAMPolicyAssignmentResponse, UpdateIAMPolicyAssignmentError, Credentials | HttpClient.HttpClient>;
export type UpdateIdentityPropagationConfigError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds or updates services and authorized targets to configure what the Quick Sight IAM Identity Center application can access.
 *
 * This operation is only supported for Quick Sight accounts using IAM Identity Center
 */
export declare const updateIdentityPropagationConfig: API.OperationMethod<UpdateIdentityPropagationConfigRequest & RegionInput, UpdateIdentityPropagationConfigResponse, UpdateIdentityPropagationConfigError, Credentials | HttpClient.HttpClient>;
export type UpdateIpRestrictionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the content and status of IP rules. Traffic from a source is allowed when the source satisfies either the `IpRestrictionRule`, `VpcIdRestrictionRule`, or `VpcEndpointIdRestrictionRule`. To use this operation, you must provide the entire map of rules. You can use the `DescribeIpRestriction` operation to get the current rule map.
 */
export declare const updateIpRestriction: API.OperationMethod<UpdateIpRestrictionRequest & RegionInput, UpdateIpRestrictionResponse, UpdateIpRestrictionError, Credentials | HttpClient.HttpClient>;
export type UpdateKeyRegistrationError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ThrottlingException | CommonErrors;
/**
 * Updates a customer managed key in a Quick Sight account.
 */
export declare const updateKeyRegistration: API.OperationMethod<UpdateKeyRegistrationRequest & RegionInput, UpdateKeyRegistrationResponse, UpdateKeyRegistrationError, Credentials | HttpClient.HttpClient>;
export type UpdateKnowledgeBaseError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of an existing knowledge base.
 */
export declare const updateKnowledgeBase: API.OperationMethod<UpdateKnowledgeBaseRequest & RegionInput, UpdateKnowledgeBaseResponse, UpdateKnowledgeBaseError, Credentials | HttpClient.HttpClient>;
export type UpdateKnowledgeBasePermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | InvalidRequestException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the resource permissions for a knowledge base.
 */
export declare const updateKnowledgeBasePermissions: API.OperationMethod<UpdateKnowledgeBasePermissionsRequest & RegionInput, UpdateKnowledgeBasePermissionsResponse, UpdateKnowledgeBasePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateLimitsProfileError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the properties of an existing limits profile.
 */
export declare const updateLimitsProfile: API.OperationMethod<UpdateLimitsProfileRequest & RegionInput, UpdateLimitsProfileResponse, UpdateLimitsProfileError, Credentials | HttpClient.HttpClient>;
export type UpdateOAuthClientApplicationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates an OAuthClientApplication.
 */
export declare const updateOAuthClientApplication: API.OperationMethod<UpdateOAuthClientApplicationRequest & RegionInput, UpdateOAuthClientApplicationResponse, UpdateOAuthClientApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdatePublicSharingSettingsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | UnsupportedPricingPlanException | CommonErrors;
/**
 * This API controls public sharing settings for your entire Quick Sight account, affecting
 * data security and access. When you enable public sharing:
 *
 * - Dashboards can be shared publicly
 *
 * - This setting affects your entire Amazon Web Services account and all Quick Sight
 * users
 *
 * **Before proceeding:** Ensure you understand the
 * security implications and have proper IAM permissions
 * configured.
 *
 * Use the `UpdatePublicSharingSettings` operation to turn on or turn off the
 * public sharing settings of an Amazon Quick Sight dashboard.
 *
 * To use this operation, turn on session capacity pricing for your Amazon Quick Sight
 * account.
 *
 * Before you can turn on public sharing on your account, make sure to give public
 * sharing permissions to an administrative user in the Identity and Access Management (IAM) console. For more information on using IAM with Amazon
 * Quick Sight, see Using Quick with IAM in the Amazon Quick Sight
 * User Guide.
 */
export declare const updatePublicSharingSettings: API.OperationMethod<UpdatePublicSharingSettingsRequest & RegionInput, UpdatePublicSharingSettingsResponse, UpdatePublicSharingSettingsError, Credentials | HttpClient.HttpClient>;
export type UpdateQPersonalizationConfigurationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates a personalization configuration.
 */
export declare const updateQPersonalizationConfiguration: API.OperationMethod<UpdateQPersonalizationConfigurationRequest & RegionInput, UpdateQPersonalizationConfigurationResponse, UpdateQPersonalizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateQuickSightQSearchConfigurationError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the state of a Quick Sight Q Search configuration.
 */
export declare const updateQuickSightQSearchConfiguration: API.OperationMethod<UpdateQuickSightQSearchConfigurationRequest & RegionInput, UpdateQuickSightQSearchConfigurationResponse, UpdateQuickSightQSearchConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateRefreshScheduleError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a refresh schedule for a dataset.
 */
export declare const updateRefreshSchedule: API.OperationMethod<UpdateRefreshScheduleRequest & RegionInput, UpdateRefreshScheduleResponse, UpdateRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateResourcePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the service role configuration that Amazon Quick Sight uses to access resources in your
 * Amazon Web Services account. To use this operation, you must have the
 * `quicksight:UpdateResourcePermissions` and `iam:PassRole`
 * permissions.
 *
 * Call this operation in the Amazon Web Services Region where your Amazon Quick Sight account is
 * registered (the home Region). You can switch from a role managed by Amazon Quick Sight to a
 * customer-managed role, or replace one customer-managed role with another. You can't use
 * this operation to switch back to a role managed by Amazon Quick Sight.
 */
export declare const updateResourcePermissions: API.OperationMethod<UpdateResourcePermissionsRequest & RegionInput, UpdateResourcePermissionsResponse, UpdateResourcePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateRoleCustomPermissionError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the custom permissions that are associated with a role.
 */
export declare const updateRoleCustomPermission: API.OperationMethod<UpdateRoleCustomPermissionRequest & RegionInput, UpdateRoleCustomPermissionResponse, UpdateRoleCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type UpdateSelfUpgradeError = AccessDeniedException | InternalFailureException | InvalidNextTokenException | InvalidParameterValueException | LimitExceededException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates a self-upgrade request for a Quick user by approving, denying, or verifying the request.
 */
export declare const updateSelfUpgrade: API.OperationMethod<UpdateSelfUpgradeRequest & RegionInput, UpdateSelfUpgradeResponse, UpdateSelfUpgradeError, Credentials | HttpClient.HttpClient>;
export type UpdateSelfUpgradeConfigurationError = AccessDeniedException | InternalFailureException | InvalidParameterException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates the self-upgrade configuration for a Quick account.
 */
export declare const updateSelfUpgradeConfiguration: API.OperationMethod<UpdateSelfUpgradeConfigurationRequest & RegionInput, UpdateSelfUpgradeConfigurationResponse, UpdateSelfUpgradeConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSpaceError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the metadata of an Amazon QuickSight space.
 */
export declare const updateSpace: API.OperationMethod<UpdateSpaceRequest & RegionInput, UpdateSpaceResponse, UpdateSpaceError, Credentials | HttpClient.HttpClient>;
export type UpdateSpacePermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the permissions for an Amazon QuickSight space.
 */
export declare const updateSpacePermissions: API.OperationMethod<UpdateSpacePermissionsRequest & RegionInput, UpdateSpacePermissionsResponse, UpdateSpacePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateSpaceResourcesError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Adds or removes resources from an Amazon QuickSight space.
 */
export declare const updateSpaceResources: API.OperationMethod<UpdateSpaceResourcesRequest & RegionInput, UpdateSpaceResourcesResponse, UpdateSpaceResourcesError, Credentials | HttpClient.HttpClient>;
export type UpdateSPICECapacityConfigurationError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the SPICE capacity configuration for a Quick Sight account.
 */
export declare const updateSPICECapacityConfiguration: API.OperationMethod<UpdateSPICECapacityConfigurationRequest & RegionInput, UpdateSPICECapacityConfigurationResponse, UpdateSPICECapacityConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates a template from an existing Amazon Quick Sight analysis or another template.
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest & RegionInput, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateAliasError = ConflictException | InternalFailureException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the template alias of a template.
 */
export declare const updateTemplateAlias: API.OperationMethod<UpdateTemplateAliasRequest & RegionInput, UpdateTemplateAliasResponse, UpdateTemplateAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplatePermissionsError = ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the resource permissions for a template.
 */
export declare const updateTemplatePermissions: API.OperationMethod<UpdateTemplatePermissionsRequest & RegionInput, UpdateTemplatePermissionsResponse, UpdateTemplatePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateThemeError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates a theme.
 */
export declare const updateTheme: API.OperationMethod<UpdateThemeRequest & RegionInput, UpdateThemeResponse, UpdateThemeError, Credentials | HttpClient.HttpClient>;
export type UpdateThemeAliasError = ConflictException | InternalFailureException | InvalidParameterValueException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates an alias of a theme.
 */
export declare const updateThemeAlias: API.OperationMethod<UpdateThemeAliasRequest & RegionInput, UpdateThemeAliasResponse, UpdateThemeAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateThemePermissionsError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the resource permissions for a theme. Permissions apply to the action to grant or
 * revoke permissions on, for example `"quicksight:DescribeTheme"`.
 *
 * Theme permissions apply in groupings. Valid groupings include the following for the three
 * levels of permissions, which are user, owner, or no permissions:
 *
 * - User
 *
 * - `"quicksight:DescribeTheme"`
 *
 * - `"quicksight:DescribeThemeAlias"`
 *
 * - `"quicksight:ListThemeAliases"`
 *
 * - `"quicksight:ListThemeVersions"`
 *
 * - Owner
 *
 * - `"quicksight:DescribeTheme"`
 *
 * - `"quicksight:DescribeThemeAlias"`
 *
 * - `"quicksight:ListThemeAliases"`
 *
 * - `"quicksight:ListThemeVersions"`
 *
 * - `"quicksight:DeleteTheme"`
 *
 * - `"quicksight:UpdateTheme"`
 *
 * - `"quicksight:CreateThemeAlias"`
 *
 * - `"quicksight:DeleteThemeAlias"`
 *
 * - `"quicksight:UpdateThemeAlias"`
 *
 * - `"quicksight:UpdateThemePermissions"`
 *
 * - `"quicksight:DescribeThemePermissions"`
 *
 * - To specify no permissions, omit the permissions list.
 */
export declare const updateThemePermissions: API.OperationMethod<UpdateThemePermissionsRequest & RegionInput, UpdateThemePermissionsResponse, UpdateThemePermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a topic.
 */
export declare const updateTopic: API.OperationMethod<UpdateTopicRequest & RegionInput, UpdateTopicResponse, UpdateTopicError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicPermissionsError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the permissions of a topic.
 */
export declare const updateTopicPermissions: API.OperationMethod<UpdateTopicPermissionsRequest & RegionInput, UpdateTopicPermissionsResponse, UpdateTopicPermissionsError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicPermissionsV2Error = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates the permissions of a topic.
 */
export declare const updateTopicPermissionsV2: API.OperationMethod<UpdateTopicPermissionsV2Request & RegionInput, UpdateTopicPermissionsV2Response, UpdateTopicPermissionsV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateTopicRefreshScheduleError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates a topic refresh schedule.
 */
export declare const updateTopicRefreshSchedule: API.OperationMethod<UpdateTopicRefreshScheduleRequest & RegionInput, UpdateTopicRefreshScheduleResponse, UpdateTopicRefreshScheduleError, Credentials | HttpClient.HttpClient>;
export type UpdateTopicV2Error = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceExistsException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Updates the definition of a Q topic.
 */
export declare const updateTopicV2: API.OperationMethod<UpdateTopicV2Request & RegionInput, UpdateTopicV2Response, UpdateTopicV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateUserError = AccessDeniedException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates an Amazon Quick Sight user.
 */
export declare const updateUser: API.OperationMethod<UpdateUserRequest & RegionInput, UpdateUserResponse, UpdateUserError, Credentials | HttpClient.HttpClient>;
export type UpdateUserCustomPermissionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | PreconditionNotMetException | ResourceNotFoundException | ResourceUnavailableException | ThrottlingException | CommonErrors;
/**
 * Updates a custom permissions profile for a user.
 */
export declare const updateUserCustomPermission: API.OperationMethod<UpdateUserCustomPermissionRequest & RegionInput, UpdateUserCustomPermissionResponse, UpdateUserCustomPermissionError, Credentials | HttpClient.HttpClient>;
export type UpdateVPCConnectionError = AccessDeniedException | ConflictException | InternalFailureException | InvalidParameterValueException | LimitExceededException | ResourceNotFoundException | ThrottlingException | UnsupportedUserEditionException | CommonErrors;
/**
 * Updates a VPC connection.
 */
export declare const updateVPCConnection: API.OperationMethod<UpdateVPCConnectionRequest & RegionInput, UpdateVPCConnectionResponse, UpdateVPCConnectionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=quicksight.d.ts.map