import type * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as EngineDrift from "../Drift.ts";
import type { Plan } from "../Plan.ts";
import type { ConfiguredStack } from "../Stack.ts";
import type { State } from "../State/State.ts";
import { type BuildOptions, type PlanSummary } from "./Operations.ts";
export interface DriftedResource {
    readonly fqn: string;
    readonly logicalId: string;
    readonly resourceType: string;
    /** `skipped`: not checked (no `read`, or an interrupted deploy); see `reason`. */
    readonly status: "in-sync" | "drifted" | "missing" | "skipped";
    readonly reason?: string | undefined;
    /**
     * Set for `skipped`: `unstable` is an interrupted deploy that `deploy` must
     * recover; `unreadable` is a provider with no `read`, which drift can never check.
     */
    readonly skip?: "unstable" | "unreadable" | undefined;
    readonly actual?: unknown;
}
/** A drift check and the repair it proposes; only {@link execute} runs it. */
export interface DriftScan {
    readonly stack: {
        readonly name: string;
        readonly stage: string;
    };
    readonly resources: ReadonlyArray<DriftedResource>;
    /** What the repair would change. */
    readonly summary: PlanSummary;
    /**
     * The repair as an engine plan, for renderers.
     * @internal its shape may change.
     */
    readonly native: Plan;
    /**
     * The stack services drift was checked under.
     * @internal {@link execute} runs in them.
     */
    readonly context: Context.Context<State>;
}
export interface ScanOptions extends BuildOptions {
    readonly stack: ConfiguredStack<unknown, unknown>;
}
/** Whether the drift check found anything worth repairing. */
export declare const hasDrift: (scan: DriftScan) => boolean;
/**
 * Whether the drift check left out a resource that an interrupted deploy left
 * mid-flight, so a clean result does not cover it. Resources whose provider
 * has no `read` are not counted: drift can never check them.
 */
export declare const hasUnchecked: (scan: DriftScan) => boolean;
/**
 * Compare deployed state against the real cloud and plan the repair. Drift
 * reads state and providers only, so the stack's program never runs.
 */
export declare const scan: (input: ScanOptions) => Effect.Effect<{
    stack: {
        name: string;
        stage: string;
    };
    resources: {
        fqn: string;
        logicalId: string;
        resourceType: string;
        status: "drifted" | "in-sync" | "missing" | "skipped";
        reason: string | undefined;
        skip: "unreadable" | "unstable" | undefined;
        actual: any;
    }[];
    summary: PlanSummary;
    native: Plan;
    context: Context.Context<import("../AdoptPolicy.ts").AdoptPolicy | import("../AlchemyContext.ts").AlchemyContext | import("../Artifacts.ts").ArtifactStore | import("../index.ts").AuthProviders | import("../Stack.ts").Stack | import("../Stage.ts").Stage | State>;
}, import("effect/Config").ConfigError | import("effect/PlatformError").PlatformError | import("../State/State.ts").StateStoreError, import("../AlchemyContext.ts").AlchemyContext | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("../Auth/Credentials.ts").CredentialsStore | import("effect/crypto/Digest").Digest | import("effect/FileSystem").FileSystem | import("effect/http/HttpClient").HttpClient | import("../Interaction.ts").Interaction | import("effect/Path").Path | import("../Auth/Profile.ts").ProfileStore | import("effect/Scope").Scope | import("effect/crypto/SecureRandom").SecureRandom>;
/**
 * Repair the drift `scan` found: reconcile each drifted or missing resource
 * back to its last-deployed desired state. Only those resources are touched;
 * they are re-read first, so one that is back in sync is left alone, and
 * drift that appeared after the scan waits for the next one.
 */
export declare const execute: (scan: DriftScan) => Effect.Effect<EngineDrift.DriftResult, import("../State/State.ts").StateStoreError, never>;
//# sourceMappingURL=Drift.d.ts.map