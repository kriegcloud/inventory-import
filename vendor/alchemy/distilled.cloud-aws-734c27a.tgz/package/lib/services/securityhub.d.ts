import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalException_base: S.TaggedErrorClass<"InternalException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalException extends /*@__PURE__*/ InternalException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidAccessException_base: S.TaggedErrorClass<"InvalidAccessException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class InvalidAccessException extends /*@__PURE__*/ InvalidAccessException_base {
}
declare const InvalidInputException_base: S.TaggedErrorClass<"InvalidInputException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidInputException extends /*@__PURE__*/ InvalidInputException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const OrganizationalUnitNotFoundException_base: S.TaggedErrorClass<"OrganizationalUnitNotFoundException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationalUnitNotFoundException extends /*@__PURE__*/ OrganizationalUnitNotFoundException_base {
}
declare const OrganizationNotFoundException_base: S.TaggedErrorClass<"OrganizationNotFoundException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class OrganizationNotFoundException extends /*@__PURE__*/ OrganizationNotFoundException_base {
}
declare const ResourceConflictException_base: S.TaggedErrorClass<"ResourceConflictException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ResourceConflictException extends /*@__PURE__*/ ResourceConflictException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Code: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type NonEmptyString = string;
export interface AcceptAdministratorInvitationRequest {
    AdministratorId?: string | undefined;
    InvitationId?: string | undefined;
}
export interface AcceptAdministratorInvitationResponse {
}
export interface AcceptInvitationRequest {
    MasterId?: string | undefined;
    InvitationId?: string | undefined;
}
export interface AcceptInvitationResponse {
}
export type AutomationRulesArnsList = string[];
export interface BatchDeleteAutomationRulesRequest {
    AutomationRulesArns?: string[] | undefined;
}
export interface UnprocessedAutomationRule {
    RuleArn?: string | undefined;
    ErrorCode?: number | undefined;
    ErrorMessage?: string | undefined;
}
export type UnprocessedAutomationRulesList = UnprocessedAutomationRule[];
export interface BatchDeleteAutomationRulesResponse {
    ProcessedAutomationRules?: string[] | undefined;
    UnprocessedAutomationRules?: UnprocessedAutomationRule[] | undefined;
}
export type StandardsSubscriptionArns = string[];
export interface BatchDisableStandardsRequest {
    StandardsSubscriptionArns?: string[] | undefined;
}
export type StandardsInputParameterMap = {
    [key: string]: string | undefined;
};
export type StandardsStatus = "PENDING" | "READY" | "FAILED" | "DELETING" | "INCOMPLETE" | (string & {});
export type StandardsControlsUpdatable = "READY_FOR_UPDATES" | "NOT_READY_FOR_UPDATES" | (string & {});
export type StatusReasonCode = "NO_AVAILABLE_CONFIGURATION_RECORDER" | "MAXIMUM_NUMBER_OF_CONFIG_RULES_EXCEEDED" | "NO_AVAILABLE_MULTICLOUD_CONNECTOR" | "INTERNAL_ERROR" | (string & {});
export interface StandardsStatusReason {
    StatusReasonCode?: StatusReasonCode | undefined;
}
export type StandardsProvider = "AWS" | "Azure" | (string & {});
export interface StandardsSubscription {
    StandardsSubscriptionArn?: string | undefined;
    StandardsArn?: string | undefined;
    StandardsInput?: {
        [key: string]: string | undefined;
    } | undefined;
    StandardsStatus?: StandardsStatus | undefined;
    StandardsControlsUpdatable?: StandardsControlsUpdatable | undefined;
    StandardsStatusReason?: StandardsStatusReason | undefined;
    Provider?: StandardsProvider | undefined;
}
export type StandardsSubscriptions = StandardsSubscription[];
export interface BatchDisableStandardsResponse {
    StandardsSubscriptions?: (StandardsSubscription & {
        StandardsSubscriptionArn: NonEmptyString;
        StandardsArn: NonEmptyString;
        StandardsInput: StandardsInputParameterMap;
        StandardsStatus: StandardsStatus;
        StandardsStatusReason: StandardsStatusReason & {
            StatusReasonCode: StatusReasonCode;
        };
    })[] | undefined;
}
export interface StandardsSubscriptionRequest {
    StandardsArn?: string | undefined;
    StandardsInput?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StandardsSubscriptionRequests = StandardsSubscriptionRequest[];
export interface BatchEnableStandardsRequest {
    StandardsSubscriptionRequests?: StandardsSubscriptionRequest[] | undefined;
}
export interface BatchEnableStandardsResponse {
    StandardsSubscriptions?: (StandardsSubscription & {
        StandardsSubscriptionArn: NonEmptyString;
        StandardsArn: NonEmptyString;
        StandardsInput: StandardsInputParameterMap;
        StandardsStatus: StandardsStatus;
        StandardsStatusReason: StandardsStatusReason & {
            StatusReasonCode: StatusReasonCode;
        };
    })[] | undefined;
}
export interface BatchGetAutomationRulesRequest {
    AutomationRulesArns?: string[] | undefined;
}
export type RuleStatus = "ENABLED" | "DISABLED" | (string & {});
export type RuleOrderValue = number;
export type StringFilterComparison = "EQUALS" | "PREFIX" | "NOT_EQUALS" | "PREFIX_NOT_EQUALS" | "CONTAINS" | "NOT_CONTAINS" | "CONTAINS_WORD" | (string & {});
export interface StringFilter {
    Value?: string | undefined;
    Comparison?: StringFilterComparison | undefined;
}
export type StringFilterList = StringFilter[];
export type DateRangeUnit = "DAYS" | (string & {});
export type DateRangeComparison = "WITHIN" | "OLDER_THAN" | (string & {});
export interface DateRange {
    Value?: number | undefined;
    Unit?: DateRangeUnit | undefined;
    Comparison?: DateRangeComparison | undefined;
}
export interface DateFilter {
    Start?: string | undefined;
    End?: string | undefined;
    DateRange?: DateRange | undefined;
}
export type DateFilterList = DateFilter[];
export interface NumberFilter {
    Gte?: number | undefined;
    Lte?: number | undefined;
    Eq?: number | undefined;
    Gt?: number | undefined;
    Lt?: number | undefined;
}
export type NumberFilterList = NumberFilter[];
export type MapFilterComparison = "EQUALS" | "NOT_EQUALS" | "CONTAINS" | "NOT_CONTAINS" | (string & {});
export interface MapFilter {
    Key?: string | undefined;
    Value?: string | undefined;
    Comparison?: MapFilterComparison | undefined;
}
export type MapFilterList = MapFilter[];
export interface AutomationRulesFindingFilters {
    ProductArn?: StringFilter[] | undefined;
    AwsAccountId?: StringFilter[] | undefined;
    Id?: StringFilter[] | undefined;
    GeneratorId?: StringFilter[] | undefined;
    Type?: StringFilter[] | undefined;
    FirstObservedAt?: DateFilter[] | undefined;
    LastObservedAt?: DateFilter[] | undefined;
    CreatedAt?: DateFilter[] | undefined;
    UpdatedAt?: DateFilter[] | undefined;
    Confidence?: NumberFilter[] | undefined;
    Criticality?: NumberFilter[] | undefined;
    Title?: StringFilter[] | undefined;
    Description?: StringFilter[] | undefined;
    SourceUrl?: StringFilter[] | undefined;
    ProductName?: StringFilter[] | undefined;
    CompanyName?: StringFilter[] | undefined;
    SeverityLabel?: StringFilter[] | undefined;
    ResourceType?: StringFilter[] | undefined;
    ResourceId?: StringFilter[] | undefined;
    ResourcePartition?: StringFilter[] | undefined;
    ResourceRegion?: StringFilter[] | undefined;
    ResourceTags?: MapFilter[] | undefined;
    ResourceDetailsOther?: MapFilter[] | undefined;
    ComplianceStatus?: StringFilter[] | undefined;
    ComplianceSecurityControlId?: StringFilter[] | undefined;
    ComplianceAssociatedStandardsId?: StringFilter[] | undefined;
    VerificationState?: StringFilter[] | undefined;
    WorkflowStatus?: StringFilter[] | undefined;
    RecordState?: StringFilter[] | undefined;
    RelatedFindingsProductArn?: StringFilter[] | undefined;
    RelatedFindingsId?: StringFilter[] | undefined;
    NoteText?: StringFilter[] | undefined;
    NoteUpdatedAt?: DateFilter[] | undefined;
    NoteUpdatedBy?: StringFilter[] | undefined;
    UserDefinedFields?: MapFilter[] | undefined;
    ResourceApplicationArn?: StringFilter[] | undefined;
    ResourceApplicationName?: StringFilter[] | undefined;
    AwsAccountName?: StringFilter[] | undefined;
    ResourceProvider?: StringFilter[] | undefined;
    ResourceOwnerAccountId?: StringFilter[] | undefined;
    ResourceOwnerOrgId?: StringFilter[] | undefined;
}
export type AutomationRulesActionType = "FINDING_FIELDS_UPDATE" | (string & {});
export interface NoteUpdate {
    Text?: string | undefined;
    UpdatedBy?: string | undefined;
}
export type RatioScale = number;
export type SeverityLabel = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export interface SeverityUpdate {
    Normalized?: number | undefined;
    Product?: number | undefined;
    Label?: SeverityLabel | undefined;
}
export type VerificationState = "UNKNOWN" | "TRUE_POSITIVE" | "FALSE_POSITIVE" | "BENIGN_POSITIVE" | (string & {});
export type TypeList = string[];
export type FieldMap = {
    [key: string]: string | undefined;
};
export type WorkflowStatus = "NEW" | "NOTIFIED" | "RESOLVED" | "SUPPRESSED" | (string & {});
export interface WorkflowUpdate {
    Status?: WorkflowStatus | undefined;
}
export interface RelatedFinding {
    ProductArn?: string | undefined;
    Id?: string | undefined;
}
export type RelatedFindingList = RelatedFinding[];
export interface AutomationRulesFindingFieldsUpdate {
    Note?: NoteUpdate | undefined;
    Severity?: SeverityUpdate | undefined;
    VerificationState?: VerificationState | undefined;
    Confidence?: number | undefined;
    Criticality?: number | undefined;
    Types?: string[] | undefined;
    UserDefinedFields?: {
        [key: string]: string | undefined;
    } | undefined;
    Workflow?: WorkflowUpdate | undefined;
    RelatedFindings?: RelatedFinding[] | undefined;
}
export interface AutomationRulesAction {
    Type?: AutomationRulesActionType | undefined;
    FindingFieldsUpdate?: AutomationRulesFindingFieldsUpdate | undefined;
}
export type ActionList = AutomationRulesAction[];
export interface AutomationRulesConfig {
    RuleArn?: string | undefined;
    RuleStatus?: RuleStatus | undefined;
    RuleOrder?: number | undefined;
    RuleName?: string | undefined;
    Description?: string | undefined;
    IsTerminal?: boolean | undefined;
    Criteria?: AutomationRulesFindingFilters | undefined;
    Actions?: AutomationRulesAction[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
}
export type AutomationRulesConfigList = AutomationRulesConfig[];
export interface BatchGetAutomationRulesResponse {
    Rules?: (AutomationRulesConfig & {
        Actions: (AutomationRulesAction & {
            FindingFieldsUpdate: AutomationRulesFindingFieldsUpdate & {
                Note: NoteUpdate & {
                    Text: NonEmptyString;
                    UpdatedBy: NonEmptyString;
                };
                RelatedFindings: (RelatedFinding & {
                    ProductArn: NonEmptyString;
                    Id: NonEmptyString;
                })[];
            };
        })[];
    })[] | undefined;
    UnprocessedAutomationRules?: UnprocessedAutomationRule[] | undefined;
}
export type Target = {
    AccountId: string;
    OrganizationalUnitId?: undefined;
    RootId?: undefined;
} | {
    AccountId?: undefined;
    OrganizationalUnitId: string;
    RootId?: undefined;
} | {
    AccountId?: undefined;
    OrganizationalUnitId?: undefined;
    RootId: string;
};
export interface ConfigurationPolicyAssociation {
    Target?: Target | undefined;
}
export type ConfigurationPolicyAssociationsList = ConfigurationPolicyAssociation[];
export interface BatchGetConfigurationPolicyAssociationsRequest {
    ConfigurationPolicyAssociationIdentifiers?: ConfigurationPolicyAssociation[] | undefined;
}
export type TargetType = "ACCOUNT" | "ORGANIZATIONAL_UNIT" | "ROOT" | (string & {});
export type AssociationType = "INHERITED" | "APPLIED" | (string & {});
export type ConfigurationPolicyAssociationStatus = "PENDING" | "SUCCESS" | "FAILED" | "DISABLED" | (string & {});
export interface ConfigurationPolicyAssociationSummary {
    ConfigurationPolicyId?: string | undefined;
    TargetId?: string | undefined;
    TargetType?: TargetType | undefined;
    AssociationType?: AssociationType | undefined;
    UpdatedAt?: Date | undefined;
    AssociationStatus?: ConfigurationPolicyAssociationStatus | undefined;
    AssociationStatusMessage?: string | undefined;
}
export type ConfigurationPolicyAssociationList = ConfigurationPolicyAssociationSummary[];
export interface UnprocessedConfigurationPolicyAssociation {
    ConfigurationPolicyAssociationIdentifiers?: ConfigurationPolicyAssociation | undefined;
    ErrorCode?: string | undefined;
    ErrorReason?: string | undefined;
}
export type UnprocessedConfigurationPolicyAssociationList = UnprocessedConfigurationPolicyAssociation[];
export interface BatchGetConfigurationPolicyAssociationsResponse {
    ConfigurationPolicyAssociations?: ConfigurationPolicyAssociationSummary[] | undefined;
    UnprocessedConfigurationPolicyAssociations?: UnprocessedConfigurationPolicyAssociation[] | undefined;
}
export type StringList = string[];
export interface BatchGetSecurityControlsRequest {
    SecurityControlIds?: string[] | undefined;
}
export type SeverityRating = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" | (string & {});
export type ControlStatus = "ENABLED" | "DISABLED" | (string & {});
export type UpdateStatus = "READY" | "UPDATING" | (string & {});
export type ParameterValueType = "DEFAULT" | "CUSTOM" | (string & {});
export type IntegerList = number[];
export type ParameterValue = {
    Integer: number;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList: number[];
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double: number;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String: string;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList: string[];
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean: boolean;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum: string;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList: string[];
};
export interface ParameterConfiguration {
    ValueType?: ParameterValueType | undefined;
    Value?: ParameterValue | undefined;
}
export type Parameters = {
    [key: string]: ParameterConfiguration | undefined;
};
export type AlphaNumericNonEmptyString = string;
export type SecurityControlsProvider = "AWS" | "Azure" | (string & {});
export interface SecurityControl {
    SecurityControlId?: string | undefined;
    SecurityControlArn?: string | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    RemediationUrl?: string | undefined;
    SeverityRating?: SeverityRating | undefined;
    SecurityControlStatus?: ControlStatus | undefined;
    UpdateStatus?: UpdateStatus | undefined;
    Parameters?: {
        [key: string]: ParameterConfiguration | undefined;
    } | undefined;
    LastUpdateReason?: string | undefined;
    Provider?: SecurityControlsProvider | undefined;
}
export type SecurityControls = SecurityControl[];
export type UnprocessedErrorCode = "INVALID_INPUT" | "ACCESS_DENIED" | "NOT_FOUND" | "RESOURCE_NOT_FOUND" | "LIMIT_EXCEEDED" | (string & {});
export interface UnprocessedSecurityControl {
    SecurityControlId?: string | undefined;
    ErrorCode?: UnprocessedErrorCode | undefined;
    ErrorReason?: string | undefined;
}
export type UnprocessedSecurityControls = UnprocessedSecurityControl[];
export interface BatchGetSecurityControlsResponse {
    SecurityControls: (SecurityControl & {
        SecurityControlId: NonEmptyString;
        SecurityControlArn: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        RemediationUrl: NonEmptyString;
        SeverityRating: SeverityRating;
        SecurityControlStatus: ControlStatus;
        Parameters: {
            [key: string]: (ParameterConfiguration & {
                ValueType: ParameterValueType;
            }) | undefined;
        };
    })[];
    UnprocessedIds?: (UnprocessedSecurityControl & {
        SecurityControlId: NonEmptyString;
        ErrorCode: UnprocessedErrorCode;
    })[] | undefined;
}
export interface StandardsControlAssociationId {
    SecurityControlId?: string | undefined;
    StandardsArn?: string | undefined;
}
export type StandardsControlAssociationIds = StandardsControlAssociationId[];
export interface BatchGetStandardsControlAssociationsRequest {
    StandardsControlAssociationIds?: StandardsControlAssociationId[] | undefined;
}
export type AssociationStatus = "ENABLED" | "DISABLED" | (string & {});
export type RelatedRequirementsList = string[];
export type StandardsControlArnList = string[];
export interface StandardsControlAssociationDetail {
    StandardsArn?: string | undefined;
    SecurityControlId?: string | undefined;
    SecurityControlArn?: string | undefined;
    AssociationStatus?: AssociationStatus | undefined;
    RelatedRequirements?: string[] | undefined;
    UpdatedAt?: Date | undefined;
    UpdatedReason?: string | undefined;
    StandardsControlTitle?: string | undefined;
    StandardsControlDescription?: string | undefined;
    StandardsControlArns?: string[] | undefined;
}
export type StandardsControlAssociationDetails = StandardsControlAssociationDetail[];
export interface UnprocessedStandardsControlAssociation {
    StandardsControlAssociationId?: StandardsControlAssociationId | undefined;
    ErrorCode?: UnprocessedErrorCode | undefined;
    ErrorReason?: string | undefined;
}
export type UnprocessedStandardsControlAssociations = UnprocessedStandardsControlAssociation[];
export interface BatchGetStandardsControlAssociationsResponse {
    StandardsControlAssociationDetails: (StandardsControlAssociationDetail & {
        StandardsArn: NonEmptyString;
        SecurityControlId: NonEmptyString;
        SecurityControlArn: NonEmptyString;
        AssociationStatus: AssociationStatus;
    })[];
    UnprocessedAssociations?: (UnprocessedStandardsControlAssociation & {
        StandardsControlAssociationId: StandardsControlAssociationId & {
            SecurityControlId: NonEmptyString;
            StandardsArn: NonEmptyString;
        };
        ErrorCode: UnprocessedErrorCode;
    })[] | undefined;
}
export interface Severity {
    Product?: number | undefined;
    Label?: SeverityLabel | undefined;
    Normalized?: number | undefined;
    Original?: string | undefined;
}
export interface Recommendation {
    Text?: string | undefined;
    Url?: string | undefined;
}
export interface Remediation {
    Recommendation?: Recommendation | undefined;
}
export type MalwareType = "ADWARE" | "BLENDED_THREAT" | "BOTNET_AGENT" | "COIN_MINER" | "EXPLOIT_KIT" | "KEYLOGGER" | "MACRO" | "POTENTIALLY_UNWANTED" | "SPYWARE" | "RANSOMWARE" | "REMOTE_ACCESS" | "ROOTKIT" | "TROJAN" | "VIRUS" | "WORM" | (string & {});
export type MalwareState = "OBSERVED" | "REMOVAL_FAILED" | "REMOVED" | (string & {});
export interface Malware {
    Name?: string | undefined;
    Type?: MalwareType | undefined;
    Path?: string | undefined;
    State?: MalwareState | undefined;
}
export type MalwareList = Malware[];
export type NetworkDirection = "IN" | "OUT" | (string & {});
export interface PortRange {
    Begin?: number | undefined;
    End?: number | undefined;
}
export interface Network {
    Direction?: NetworkDirection | undefined;
    Protocol?: string | undefined;
    OpenPortRange?: PortRange | undefined;
    SourceIpV4?: string | undefined;
    SourceIpV6?: string | undefined;
    SourcePort?: number | undefined;
    SourceDomain?: string | undefined;
    SourceMac?: string | undefined;
    DestinationIpV4?: string | undefined;
    DestinationIpV6?: string | undefined;
    DestinationPort?: number | undefined;
    DestinationDomain?: string | undefined;
}
export type PortRangeList = PortRange[];
export interface NetworkPathComponentDetails {
    Address?: string[] | undefined;
    PortRanges?: PortRange[] | undefined;
}
export interface NetworkHeader {
    Protocol?: string | undefined;
    Destination?: NetworkPathComponentDetails | undefined;
    Source?: NetworkPathComponentDetails | undefined;
}
export interface NetworkPathComponent {
    ComponentId?: string | undefined;
    ComponentType?: string | undefined;
    Egress?: NetworkHeader | undefined;
    Ingress?: NetworkHeader | undefined;
}
export type NetworkPathList = NetworkPathComponent[];
export interface ProcessDetails {
    Name?: string | undefined;
    Path?: string | undefined;
    Pid?: number | undefined;
    ParentPid?: number | undefined;
    LaunchedAt?: string | undefined;
    TerminatedAt?: string | undefined;
}
export interface FilePaths {
    FilePath?: string | undefined;
    FileName?: string | undefined;
    ResourceId?: string | undefined;
    Hash?: string | undefined;
}
export type FilePathList = FilePaths[];
export interface Threat {
    Name?: string | undefined;
    Severity?: string | undefined;
    ItemCount?: number | undefined;
    FilePaths?: FilePaths[] | undefined;
}
export type ThreatList = Threat[];
export type ThreatIntelIndicatorType = "DOMAIN" | "EMAIL_ADDRESS" | "HASH_MD5" | "HASH_SHA1" | "HASH_SHA256" | "HASH_SHA512" | "IPV4_ADDRESS" | "IPV6_ADDRESS" | "MUTEX" | "PROCESS" | "URL" | (string & {});
export type ThreatIntelIndicatorCategory = "BACKDOOR" | "CARD_STEALER" | "COMMAND_AND_CONTROL" | "DROP_SITE" | "EXPLOIT_SITE" | "KEYLOGGER" | (string & {});
export interface ThreatIntelIndicator {
    Type?: ThreatIntelIndicatorType | undefined;
    Value?: string | undefined;
    Category?: ThreatIntelIndicatorCategory | undefined;
    LastObservedAt?: string | undefined;
    Source?: string | undefined;
    SourceUrl?: string | undefined;
}
export type ThreatIntelIndicatorList = ThreatIntelIndicator[];
export type Partition = "aws" | "aws-cn" | "aws-us-gov" | "aws-us-iso" | "aws-us-iso-b" | "AzureCloud" | (string & {});
export type CloudProviderName = "Azure" | "AWS" | (string & {});
export interface ResourceOwnerAccount {
    Id?: string | undefined;
}
export interface ResourceOwnerOrg {
    Id?: string | undefined;
}
export interface ResourceOwner {
    Account?: ResourceOwnerAccount | undefined;
    Org?: ResourceOwnerOrg | undefined;
}
export interface ClassificationStatus {
    Code?: string | undefined;
    Reason?: string | undefined;
}
export interface Range {
    Start?: number | undefined;
    End?: number | undefined;
    StartColumn?: number | undefined;
}
export type Ranges = Range[];
export interface Page {
    PageNumber?: number | undefined;
    LineRange?: Range | undefined;
    OffsetRange?: Range | undefined;
}
export type Pages = Page[];
export interface Record {
    JsonPath?: string | undefined;
    RecordIndex?: number | undefined;
}
export type Records = Record[];
export interface Cell {
    Column?: number | undefined;
    Row?: number | undefined;
    ColumnName?: string | undefined;
    CellReference?: string | undefined;
}
export type Cells = Cell[];
export interface Occurrences {
    LineRanges?: Range[] | undefined;
    OffsetRanges?: Range[] | undefined;
    Pages?: Page[] | undefined;
    Records?: Record[] | undefined;
    Cells?: Cell[] | undefined;
}
export interface SensitiveDataDetections {
    Count?: number | undefined;
    Type?: string | undefined;
    Occurrences?: Occurrences | undefined;
}
export type SensitiveDataDetectionsList = SensitiveDataDetections[];
export interface SensitiveDataResult {
    Category?: string | undefined;
    Detections?: SensitiveDataDetections[] | undefined;
    TotalCount?: number | undefined;
}
export type SensitiveDataResultList = SensitiveDataResult[];
export interface CustomDataIdentifiersDetections {
    Count?: number | undefined;
    Arn?: string | undefined;
    Name?: string | undefined;
    Occurrences?: Occurrences | undefined;
}
export type CustomDataIdentifiersDetectionsList = CustomDataIdentifiersDetections[];
export interface CustomDataIdentifiersResult {
    Detections?: CustomDataIdentifiersDetections[] | undefined;
    TotalCount?: number | undefined;
}
export interface ClassificationResult {
    MimeType?: string | undefined;
    SizeClassified?: number | undefined;
    AdditionalOccurrences?: boolean | undefined;
    Status?: ClassificationStatus | undefined;
    SensitiveData?: SensitiveDataResult[] | undefined;
    CustomDataIdentifiers?: CustomDataIdentifiersResult | undefined;
}
export interface DataClassificationDetails {
    DetailedResultsLocation?: string | undefined;
    Result?: ClassificationResult | undefined;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDetails {
    OnDemandAllocationStrategy?: string | undefined;
    OnDemandBaseCapacity?: number | undefined;
    OnDemandPercentageAboveBaseCapacity?: number | undefined;
    SpotAllocationStrategy?: string | undefined;
    SpotInstancePools?: number | undefined;
    SpotMaxPrice?: string | undefined;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification {
    LaunchTemplateId?: string | undefined;
    LaunchTemplateName?: string | undefined;
    Version?: string | undefined;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesListDetails {
    InstanceType?: string | undefined;
    WeightedCapacity?: string | undefined;
}
export type AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesList = AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesListDetails[];
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateDetails {
    LaunchTemplateSpecification?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecification | undefined;
    Overrides?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateOverridesListDetails[] | undefined;
}
export interface AwsAutoScalingAutoScalingGroupMixedInstancesPolicyDetails {
    InstancesDistribution?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyInstancesDistributionDetails | undefined;
    LaunchTemplate?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyLaunchTemplateDetails | undefined;
}
export interface AwsAutoScalingAutoScalingGroupAvailabilityZonesListDetails {
    Value?: string | undefined;
}
export type AwsAutoScalingAutoScalingGroupAvailabilityZonesList = AwsAutoScalingAutoScalingGroupAvailabilityZonesListDetails[];
export interface AwsAutoScalingAutoScalingGroupLaunchTemplateLaunchTemplateSpecification {
    LaunchTemplateId?: string | undefined;
    LaunchTemplateName?: string | undefined;
    Version?: string | undefined;
}
export interface AwsAutoScalingAutoScalingGroupDetails {
    LaunchConfigurationName?: string | undefined;
    LoadBalancerNames?: string[] | undefined;
    HealthCheckType?: string | undefined;
    HealthCheckGracePeriod?: number | undefined;
    CreatedTime?: string | undefined;
    MixedInstancesPolicy?: AwsAutoScalingAutoScalingGroupMixedInstancesPolicyDetails | undefined;
    AvailabilityZones?: AwsAutoScalingAutoScalingGroupAvailabilityZonesListDetails[] | undefined;
    LaunchTemplate?: AwsAutoScalingAutoScalingGroupLaunchTemplateLaunchTemplateSpecification | undefined;
    CapacityRebalance?: boolean | undefined;
}
export interface AwsCodeBuildProjectArtifactsDetails {
    ArtifactIdentifier?: string | undefined;
    EncryptionDisabled?: boolean | undefined;
    Location?: string | undefined;
    Name?: string | undefined;
    NamespaceType?: string | undefined;
    OverrideArtifactName?: boolean | undefined;
    Packaging?: string | undefined;
    Path?: string | undefined;
    Type?: string | undefined;
}
export type AwsCodeBuildProjectArtifactsList = AwsCodeBuildProjectArtifactsDetails[];
export interface AwsCodeBuildProjectEnvironmentEnvironmentVariablesDetails {
    Name?: string | undefined;
    Type?: string | undefined;
    Value?: string | undefined;
}
export type AwsCodeBuildProjectEnvironmentEnvironmentVariablesList = AwsCodeBuildProjectEnvironmentEnvironmentVariablesDetails[];
export interface AwsCodeBuildProjectEnvironmentRegistryCredential {
    Credential?: string | undefined;
    CredentialProvider?: string | undefined;
}
export interface AwsCodeBuildProjectEnvironment {
    Certificate?: string | undefined;
    EnvironmentVariables?: AwsCodeBuildProjectEnvironmentEnvironmentVariablesDetails[] | undefined;
    PrivilegedMode?: boolean | undefined;
    ImagePullCredentialsType?: string | undefined;
    RegistryCredential?: AwsCodeBuildProjectEnvironmentRegistryCredential | undefined;
    Type?: string | undefined;
}
export interface AwsCodeBuildProjectSource {
    Type?: string | undefined;
    Location?: string | undefined;
    GitCloneDepth?: number | undefined;
    InsecureSsl?: boolean | undefined;
}
export interface AwsCodeBuildProjectLogsConfigCloudWatchLogsDetails {
    GroupName?: string | undefined;
    Status?: string | undefined;
    StreamName?: string | undefined;
}
export interface AwsCodeBuildProjectLogsConfigS3LogsDetails {
    EncryptionDisabled?: boolean | undefined;
    Location?: string | undefined;
    Status?: string | undefined;
}
export interface AwsCodeBuildProjectLogsConfigDetails {
    CloudWatchLogs?: AwsCodeBuildProjectLogsConfigCloudWatchLogsDetails | undefined;
    S3Logs?: AwsCodeBuildProjectLogsConfigS3LogsDetails | undefined;
}
export type NonEmptyStringList = string[];
export interface AwsCodeBuildProjectVpcConfig {
    VpcId?: string | undefined;
    Subnets?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
}
export interface AwsCodeBuildProjectDetails {
    EncryptionKey?: string | undefined;
    Artifacts?: AwsCodeBuildProjectArtifactsDetails[] | undefined;
    Environment?: AwsCodeBuildProjectEnvironment | undefined;
    Name?: string | undefined;
    Source?: AwsCodeBuildProjectSource | undefined;
    ServiceRole?: string | undefined;
    LogsConfig?: AwsCodeBuildProjectLogsConfigDetails | undefined;
    VpcConfig?: AwsCodeBuildProjectVpcConfig | undefined;
    SecondaryArtifacts?: AwsCodeBuildProjectArtifactsDetails[] | undefined;
}
export interface AwsCloudFrontDistributionCacheBehavior {
    ViewerProtocolPolicy?: string | undefined;
}
export type AwsCloudFrontDistributionCacheBehaviorsItemList = AwsCloudFrontDistributionCacheBehavior[];
export interface AwsCloudFrontDistributionCacheBehaviors {
    Items?: AwsCloudFrontDistributionCacheBehavior[] | undefined;
}
export interface AwsCloudFrontDistributionDefaultCacheBehavior {
    ViewerProtocolPolicy?: string | undefined;
}
export interface AwsCloudFrontDistributionLogging {
    Bucket?: string | undefined;
    Enabled?: boolean | undefined;
    IncludeCookies?: boolean | undefined;
    Prefix?: string | undefined;
}
export interface AwsCloudFrontDistributionOriginS3OriginConfig {
    OriginAccessIdentity?: string | undefined;
}
export interface AwsCloudFrontDistributionOriginSslProtocols {
    Items?: string[] | undefined;
    Quantity?: number | undefined;
}
export interface AwsCloudFrontDistributionOriginCustomOriginConfig {
    HttpPort?: number | undefined;
    HttpsPort?: number | undefined;
    OriginKeepaliveTimeout?: number | undefined;
    OriginProtocolPolicy?: string | undefined;
    OriginReadTimeout?: number | undefined;
    OriginSslProtocols?: AwsCloudFrontDistributionOriginSslProtocols | undefined;
}
export interface AwsCloudFrontDistributionOriginItem {
    DomainName?: string | undefined;
    Id?: string | undefined;
    OriginPath?: string | undefined;
    S3OriginConfig?: AwsCloudFrontDistributionOriginS3OriginConfig | undefined;
    CustomOriginConfig?: AwsCloudFrontDistributionOriginCustomOriginConfig | undefined;
}
export type AwsCloudFrontDistributionOriginItemList = AwsCloudFrontDistributionOriginItem[];
export interface AwsCloudFrontDistributionOrigins {
    Items?: AwsCloudFrontDistributionOriginItem[] | undefined;
}
export type AwsCloudFrontDistributionOriginGroupFailoverStatusCodesItemList = number[];
export interface AwsCloudFrontDistributionOriginGroupFailoverStatusCodes {
    Items?: number[] | undefined;
    Quantity?: number | undefined;
}
export interface AwsCloudFrontDistributionOriginGroupFailover {
    StatusCodes?: AwsCloudFrontDistributionOriginGroupFailoverStatusCodes | undefined;
}
export interface AwsCloudFrontDistributionOriginGroup {
    FailoverCriteria?: AwsCloudFrontDistributionOriginGroupFailover | undefined;
}
export type AwsCloudFrontDistributionOriginGroupsItemList = AwsCloudFrontDistributionOriginGroup[];
export interface AwsCloudFrontDistributionOriginGroups {
    Items?: AwsCloudFrontDistributionOriginGroup[] | undefined;
}
export interface AwsCloudFrontDistributionViewerCertificate {
    AcmCertificateArn?: string | undefined;
    Certificate?: string | undefined;
    CertificateSource?: string | undefined;
    CloudFrontDefaultCertificate?: boolean | undefined;
    IamCertificateId?: string | undefined;
    MinimumProtocolVersion?: string | undefined;
    SslSupportMethod?: string | undefined;
}
export interface AwsCloudFrontDistributionDetails {
    CacheBehaviors?: AwsCloudFrontDistributionCacheBehaviors | undefined;
    DefaultCacheBehavior?: AwsCloudFrontDistributionDefaultCacheBehavior | undefined;
    DefaultRootObject?: string | undefined;
    DomainName?: string | undefined;
    ETag?: string | undefined;
    LastModifiedTime?: string | undefined;
    Logging?: AwsCloudFrontDistributionLogging | undefined;
    Origins?: AwsCloudFrontDistributionOrigins | undefined;
    OriginGroups?: AwsCloudFrontDistributionOriginGroups | undefined;
    ViewerCertificate?: AwsCloudFrontDistributionViewerCertificate | undefined;
    Status?: string | undefined;
    WebAclId?: string | undefined;
}
export interface AwsEc2InstanceNetworkInterfacesDetails {
    NetworkInterfaceId?: string | undefined;
}
export type AwsEc2InstanceNetworkInterfacesList = AwsEc2InstanceNetworkInterfacesDetails[];
export interface AwsEc2InstanceMetadataOptions {
    HttpEndpoint?: string | undefined;
    HttpProtocolIpv6?: string | undefined;
    HttpPutResponseHopLimit?: number | undefined;
    HttpTokens?: string | undefined;
    InstanceMetadataTags?: string | undefined;
}
export interface AwsEc2InstanceMonitoringDetails {
    State?: string | undefined;
}
export interface AwsEc2InstanceDetails {
    Type?: string | undefined;
    ImageId?: string | undefined;
    IpV4Addresses?: string[] | undefined;
    IpV6Addresses?: string[] | undefined;
    KeyName?: string | undefined;
    IamInstanceProfileArn?: string | undefined;
    VpcId?: string | undefined;
    SubnetId?: string | undefined;
    LaunchedAt?: string | undefined;
    NetworkInterfaces?: AwsEc2InstanceNetworkInterfacesDetails[] | undefined;
    VirtualizationType?: string | undefined;
    MetadataOptions?: AwsEc2InstanceMetadataOptions | undefined;
    Monitoring?: AwsEc2InstanceMonitoringDetails | undefined;
}
export interface AwsEc2NetworkInterfaceAttachment {
    AttachTime?: string | undefined;
    AttachmentId?: string | undefined;
    DeleteOnTermination?: boolean | undefined;
    DeviceIndex?: number | undefined;
    InstanceId?: string | undefined;
    InstanceOwnerId?: string | undefined;
    Status?: string | undefined;
}
export interface AwsEc2NetworkInterfaceSecurityGroup {
    GroupName?: string | undefined;
    GroupId?: string | undefined;
}
export type AwsEc2NetworkInterfaceSecurityGroupList = AwsEc2NetworkInterfaceSecurityGroup[];
export interface AwsEc2NetworkInterfaceIpV6AddressDetail {
    IpV6Address?: string | undefined;
}
export type AwsEc2NetworkInterfaceIpV6AddressList = AwsEc2NetworkInterfaceIpV6AddressDetail[];
export interface AwsEc2NetworkInterfacePrivateIpAddressDetail {
    PrivateIpAddress?: string | undefined;
    PrivateDnsName?: string | undefined;
}
export type AwsEc2NetworkInterfacePrivateIpAddressList = AwsEc2NetworkInterfacePrivateIpAddressDetail[];
export interface AwsEc2NetworkInterfaceDetails {
    Attachment?: AwsEc2NetworkInterfaceAttachment | undefined;
    NetworkInterfaceId?: string | undefined;
    SecurityGroups?: AwsEc2NetworkInterfaceSecurityGroup[] | undefined;
    SourceDestCheck?: boolean | undefined;
    IpV6Addresses?: AwsEc2NetworkInterfaceIpV6AddressDetail[] | undefined;
    PrivateIpAddresses?: AwsEc2NetworkInterfacePrivateIpAddressDetail[] | undefined;
    PublicDnsName?: string | undefined;
    PublicIp?: string | undefined;
}
export interface AwsEc2SecurityGroupUserIdGroupPair {
    GroupId?: string | undefined;
    GroupName?: string | undefined;
    PeeringStatus?: string | undefined;
    UserId?: string | undefined;
    VpcId?: string | undefined;
    VpcPeeringConnectionId?: string | undefined;
}
export type AwsEc2SecurityGroupUserIdGroupPairList = AwsEc2SecurityGroupUserIdGroupPair[];
export interface AwsEc2SecurityGroupIpRange {
    CidrIp?: string | undefined;
}
export type AwsEc2SecurityGroupIpRangeList = AwsEc2SecurityGroupIpRange[];
export interface AwsEc2SecurityGroupIpv6Range {
    CidrIpv6?: string | undefined;
}
export type AwsEc2SecurityGroupIpv6RangeList = AwsEc2SecurityGroupIpv6Range[];
export interface AwsEc2SecurityGroupPrefixListId {
    PrefixListId?: string | undefined;
}
export type AwsEc2SecurityGroupPrefixListIdList = AwsEc2SecurityGroupPrefixListId[];
export interface AwsEc2SecurityGroupIpPermission {
    IpProtocol?: string | undefined;
    FromPort?: number | undefined;
    ToPort?: number | undefined;
    UserIdGroupPairs?: AwsEc2SecurityGroupUserIdGroupPair[] | undefined;
    IpRanges?: AwsEc2SecurityGroupIpRange[] | undefined;
    Ipv6Ranges?: AwsEc2SecurityGroupIpv6Range[] | undefined;
    PrefixListIds?: AwsEc2SecurityGroupPrefixListId[] | undefined;
}
export type AwsEc2SecurityGroupIpPermissionList = AwsEc2SecurityGroupIpPermission[];
export interface AwsEc2SecurityGroupDetails {
    GroupName?: string | undefined;
    GroupId?: string | undefined;
    OwnerId?: string | undefined;
    VpcId?: string | undefined;
    IpPermissions?: AwsEc2SecurityGroupIpPermission[] | undefined;
    IpPermissionsEgress?: AwsEc2SecurityGroupIpPermission[] | undefined;
}
export interface AwsEc2VolumeAttachment {
    AttachTime?: string | undefined;
    DeleteOnTermination?: boolean | undefined;
    InstanceId?: string | undefined;
    Status?: string | undefined;
}
export type AwsEc2VolumeAttachmentList = AwsEc2VolumeAttachment[];
export interface AwsEc2VolumeDetails {
    CreateTime?: string | undefined;
    DeviceName?: string | undefined;
    Encrypted?: boolean | undefined;
    Size?: number | undefined;
    SnapshotId?: string | undefined;
    Status?: string | undefined;
    KmsKeyId?: string | undefined;
    Attachments?: AwsEc2VolumeAttachment[] | undefined;
    VolumeId?: string | undefined;
    VolumeType?: string | undefined;
    VolumeScanStatus?: string | undefined;
}
export interface CidrBlockAssociation {
    AssociationId?: string | undefined;
    CidrBlock?: string | undefined;
    CidrBlockState?: string | undefined;
}
export type CidrBlockAssociationList = CidrBlockAssociation[];
export interface Ipv6CidrBlockAssociation {
    AssociationId?: string | undefined;
    Ipv6CidrBlock?: string | undefined;
    CidrBlockState?: string | undefined;
}
export type Ipv6CidrBlockAssociationList = Ipv6CidrBlockAssociation[];
export interface AwsEc2VpcDetails {
    CidrBlockAssociationSet?: CidrBlockAssociation[] | undefined;
    Ipv6CidrBlockAssociationSet?: Ipv6CidrBlockAssociation[] | undefined;
    DhcpOptionsId?: string | undefined;
    State?: string | undefined;
}
export interface AwsEc2EipDetails {
    InstanceId?: string | undefined;
    PublicIp?: string | undefined;
    AllocationId?: string | undefined;
    AssociationId?: string | undefined;
    Domain?: string | undefined;
    PublicIpv4Pool?: string | undefined;
    NetworkBorderGroup?: string | undefined;
    NetworkInterfaceId?: string | undefined;
    NetworkInterfaceOwnerId?: string | undefined;
    PrivateIpAddress?: string | undefined;
}
export interface AwsEc2SubnetDetails {
    AssignIpv6AddressOnCreation?: boolean | undefined;
    AvailabilityZone?: string | undefined;
    AvailabilityZoneId?: string | undefined;
    AvailableIpAddressCount?: number | undefined;
    CidrBlock?: string | undefined;
    DefaultForAz?: boolean | undefined;
    MapPublicIpOnLaunch?: boolean | undefined;
    OwnerId?: string | undefined;
    State?: string | undefined;
    SubnetArn?: string | undefined;
    SubnetId?: string | undefined;
    VpcId?: string | undefined;
    Ipv6CidrBlockAssociationSet?: Ipv6CidrBlockAssociation[] | undefined;
}
export interface AwsEc2NetworkAclAssociation {
    NetworkAclAssociationId?: string | undefined;
    NetworkAclId?: string | undefined;
    SubnetId?: string | undefined;
}
export type AwsEc2NetworkAclAssociationList = AwsEc2NetworkAclAssociation[];
export interface IcmpTypeCode {
    Code?: number | undefined;
    Type?: number | undefined;
}
export interface PortRangeFromTo {
    From?: number | undefined;
    To?: number | undefined;
}
export interface AwsEc2NetworkAclEntry {
    CidrBlock?: string | undefined;
    Egress?: boolean | undefined;
    IcmpTypeCode?: IcmpTypeCode | undefined;
    Ipv6CidrBlock?: string | undefined;
    PortRange?: PortRangeFromTo | undefined;
    Protocol?: string | undefined;
    RuleAction?: string | undefined;
    RuleNumber?: number | undefined;
}
export type AwsEc2NetworkAclEntryList = AwsEc2NetworkAclEntry[];
export interface AwsEc2NetworkAclDetails {
    IsDefault?: boolean | undefined;
    NetworkAclId?: string | undefined;
    OwnerId?: string | undefined;
    VpcId?: string | undefined;
    Associations?: AwsEc2NetworkAclAssociation[] | undefined;
    Entries?: AwsEc2NetworkAclEntry[] | undefined;
}
export interface AvailabilityZone {
    ZoneName?: string | undefined;
    SubnetId?: string | undefined;
}
export type AvailabilityZones = AvailabilityZone[];
export type SecurityGroups = string[];
export interface LoadBalancerState {
    Code?: string | undefined;
    Reason?: string | undefined;
}
export interface AwsElbv2LoadBalancerAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type AwsElbv2LoadBalancerAttributes = AwsElbv2LoadBalancerAttribute[];
export interface AwsElbv2LoadBalancerDetails {
    AvailabilityZones?: AvailabilityZone[] | undefined;
    CanonicalHostedZoneId?: string | undefined;
    CreatedTime?: string | undefined;
    DNSName?: string | undefined;
    IpAddressType?: string | undefined;
    Scheme?: string | undefined;
    SecurityGroups?: string[] | undefined;
    State?: LoadBalancerState | undefined;
    Type?: string | undefined;
    VpcId?: string | undefined;
    LoadBalancerAttributes?: AwsElbv2LoadBalancerAttribute[] | undefined;
}
export interface AwsElasticBeanstalkEnvironmentEnvironmentLink {
    EnvironmentName?: string | undefined;
    LinkName?: string | undefined;
}
export type AwsElasticBeanstalkEnvironmentEnvironmentLinks = AwsElasticBeanstalkEnvironmentEnvironmentLink[];
export interface AwsElasticBeanstalkEnvironmentOptionSetting {
    Namespace?: string | undefined;
    OptionName?: string | undefined;
    ResourceName?: string | undefined;
    Value?: string | undefined;
}
export type AwsElasticBeanstalkEnvironmentOptionSettings = AwsElasticBeanstalkEnvironmentOptionSetting[];
export interface AwsElasticBeanstalkEnvironmentTier {
    Name?: string | undefined;
    Type?: string | undefined;
    Version?: string | undefined;
}
export interface AwsElasticBeanstalkEnvironmentDetails {
    ApplicationName?: string | undefined;
    Cname?: string | undefined;
    DateCreated?: string | undefined;
    DateUpdated?: string | undefined;
    Description?: string | undefined;
    EndpointUrl?: string | undefined;
    EnvironmentArn?: string | undefined;
    EnvironmentId?: string | undefined;
    EnvironmentLinks?: AwsElasticBeanstalkEnvironmentEnvironmentLink[] | undefined;
    EnvironmentName?: string | undefined;
    OptionSettings?: AwsElasticBeanstalkEnvironmentOptionSetting[] | undefined;
    PlatformArn?: string | undefined;
    SolutionStackName?: string | undefined;
    Status?: string | undefined;
    Tier?: AwsElasticBeanstalkEnvironmentTier | undefined;
    VersionLabel?: string | undefined;
}
export interface AwsElasticsearchDomainDomainEndpointOptions {
    EnforceHTTPS?: boolean | undefined;
    TLSSecurityPolicy?: string | undefined;
}
export interface AwsElasticsearchDomainElasticsearchClusterConfigZoneAwarenessConfigDetails {
    AvailabilityZoneCount?: number | undefined;
}
export interface AwsElasticsearchDomainElasticsearchClusterConfigDetails {
    DedicatedMasterCount?: number | undefined;
    DedicatedMasterEnabled?: boolean | undefined;
    DedicatedMasterType?: string | undefined;
    InstanceCount?: number | undefined;
    InstanceType?: string | undefined;
    ZoneAwarenessConfig?: AwsElasticsearchDomainElasticsearchClusterConfigZoneAwarenessConfigDetails | undefined;
    ZoneAwarenessEnabled?: boolean | undefined;
}
export interface AwsElasticsearchDomainEncryptionAtRestOptions {
    Enabled?: boolean | undefined;
    KmsKeyId?: string | undefined;
}
export interface AwsElasticsearchDomainLogPublishingOptionsLogConfig {
    CloudWatchLogsLogGroupArn?: string | undefined;
    Enabled?: boolean | undefined;
}
export interface AwsElasticsearchDomainLogPublishingOptions {
    IndexSlowLogs?: AwsElasticsearchDomainLogPublishingOptionsLogConfig | undefined;
    SearchSlowLogs?: AwsElasticsearchDomainLogPublishingOptionsLogConfig | undefined;
    AuditLogs?: AwsElasticsearchDomainLogPublishingOptionsLogConfig | undefined;
}
export interface AwsElasticsearchDomainNodeToNodeEncryptionOptions {
    Enabled?: boolean | undefined;
}
export interface AwsElasticsearchDomainServiceSoftwareOptions {
    AutomatedUpdateDate?: string | undefined;
    Cancellable?: boolean | undefined;
    CurrentVersion?: string | undefined;
    Description?: string | undefined;
    NewVersion?: string | undefined;
    UpdateAvailable?: boolean | undefined;
    UpdateStatus?: string | undefined;
}
export interface AwsElasticsearchDomainVPCOptions {
    AvailabilityZones?: string[] | undefined;
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    VPCId?: string | undefined;
}
export interface AwsElasticsearchDomainDetails {
    AccessPolicies?: string | undefined;
    DomainEndpointOptions?: AwsElasticsearchDomainDomainEndpointOptions | undefined;
    DomainId?: string | undefined;
    DomainName?: string | undefined;
    Endpoint?: string | undefined;
    Endpoints?: {
        [key: string]: string | undefined;
    } | undefined;
    ElasticsearchVersion?: string | undefined;
    ElasticsearchClusterConfig?: AwsElasticsearchDomainElasticsearchClusterConfigDetails | undefined;
    EncryptionAtRestOptions?: AwsElasticsearchDomainEncryptionAtRestOptions | undefined;
    LogPublishingOptions?: AwsElasticsearchDomainLogPublishingOptions | undefined;
    NodeToNodeEncryptionOptions?: AwsElasticsearchDomainNodeToNodeEncryptionOptions | undefined;
    ServiceSoftwareOptions?: AwsElasticsearchDomainServiceSoftwareOptions | undefined;
    VPCOptions?: AwsElasticsearchDomainVPCOptions | undefined;
}
export interface AwsS3BucketServerSideEncryptionByDefault {
    SSEAlgorithm?: string | undefined;
    KMSMasterKeyID?: string | undefined;
}
export interface AwsS3BucketServerSideEncryptionRule {
    ApplyServerSideEncryptionByDefault?: AwsS3BucketServerSideEncryptionByDefault | undefined;
}
export type AwsS3BucketServerSideEncryptionRules = AwsS3BucketServerSideEncryptionRule[];
export interface AwsS3BucketServerSideEncryptionConfiguration {
    Rules?: AwsS3BucketServerSideEncryptionRule[] | undefined;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesAbortIncompleteMultipartUploadDetails {
    DaysAfterInitiation?: number | undefined;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsTagDetails {
    Key?: string | undefined;
    Value?: string | undefined;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsDetails {
    Prefix?: string | undefined;
    Tag?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsTagDetails | undefined;
    Type?: string | undefined;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsList = AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateTagDetails {
    Key?: string | undefined;
    Value?: string | undefined;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateDetails {
    Operands?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateOperandsDetails[] | undefined;
    Prefix?: string | undefined;
    Tag?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateTagDetails | undefined;
    Type?: string | undefined;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesFilterDetails {
    Predicate?: AwsS3BucketBucketLifecycleConfigurationRulesFilterPredicateDetails | undefined;
}
export interface AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsDetails {
    Days?: number | undefined;
    StorageClass?: string | undefined;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsList = AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationRulesTransitionsDetails {
    Date?: string | undefined;
    Days?: number | undefined;
    StorageClass?: string | undefined;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesTransitionsList = AwsS3BucketBucketLifecycleConfigurationRulesTransitionsDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationRulesDetails {
    AbortIncompleteMultipartUpload?: AwsS3BucketBucketLifecycleConfigurationRulesAbortIncompleteMultipartUploadDetails | undefined;
    ExpirationDate?: string | undefined;
    ExpirationInDays?: number | undefined;
    ExpiredObjectDeleteMarker?: boolean | undefined;
    Filter?: AwsS3BucketBucketLifecycleConfigurationRulesFilterDetails | undefined;
    ID?: string | undefined;
    NoncurrentVersionExpirationInDays?: number | undefined;
    NoncurrentVersionTransitions?: AwsS3BucketBucketLifecycleConfigurationRulesNoncurrentVersionTransitionsDetails[] | undefined;
    Prefix?: string | undefined;
    Status?: string | undefined;
    Transitions?: AwsS3BucketBucketLifecycleConfigurationRulesTransitionsDetails[] | undefined;
}
export type AwsS3BucketBucketLifecycleConfigurationRulesList = AwsS3BucketBucketLifecycleConfigurationRulesDetails[];
export interface AwsS3BucketBucketLifecycleConfigurationDetails {
    Rules?: AwsS3BucketBucketLifecycleConfigurationRulesDetails[] | undefined;
}
export interface AwsS3AccountPublicAccessBlockDetails {
    BlockPublicAcls?: boolean | undefined;
    BlockPublicPolicy?: boolean | undefined;
    IgnorePublicAcls?: boolean | undefined;
    RestrictPublicBuckets?: boolean | undefined;
}
export interface AwsS3BucketLoggingConfiguration {
    DestinationBucketName?: string | undefined;
    LogFilePrefix?: string | undefined;
}
export interface AwsS3BucketWebsiteConfigurationRedirectTo {
    Hostname?: string | undefined;
    Protocol?: string | undefined;
}
export interface AwsS3BucketWebsiteConfigurationRoutingRuleCondition {
    HttpErrorCodeReturnedEquals?: string | undefined;
    KeyPrefixEquals?: string | undefined;
}
export interface AwsS3BucketWebsiteConfigurationRoutingRuleRedirect {
    Hostname?: string | undefined;
    HttpRedirectCode?: string | undefined;
    Protocol?: string | undefined;
    ReplaceKeyPrefixWith?: string | undefined;
    ReplaceKeyWith?: string | undefined;
}
export interface AwsS3BucketWebsiteConfigurationRoutingRule {
    Condition?: AwsS3BucketWebsiteConfigurationRoutingRuleCondition | undefined;
    Redirect?: AwsS3BucketWebsiteConfigurationRoutingRuleRedirect | undefined;
}
export type AwsS3BucketWebsiteConfigurationRoutingRules = AwsS3BucketWebsiteConfigurationRoutingRule[];
export interface AwsS3BucketWebsiteConfiguration {
    ErrorDocument?: string | undefined;
    IndexDocumentSuffix?: string | undefined;
    RedirectAllRequestsTo?: AwsS3BucketWebsiteConfigurationRedirectTo | undefined;
    RoutingRules?: AwsS3BucketWebsiteConfigurationRoutingRule[] | undefined;
}
export type AwsS3BucketNotificationConfigurationEvents = string[];
export type AwsS3BucketNotificationConfigurationS3KeyFilterRuleName = "Prefix" | "Suffix" | (string & {});
export interface AwsS3BucketNotificationConfigurationS3KeyFilterRule {
    Name?: AwsS3BucketNotificationConfigurationS3KeyFilterRuleName | undefined;
    Value?: string | undefined;
}
export type AwsS3BucketNotificationConfigurationS3KeyFilterRules = AwsS3BucketNotificationConfigurationS3KeyFilterRule[];
export interface AwsS3BucketNotificationConfigurationS3KeyFilter {
    FilterRules?: AwsS3BucketNotificationConfigurationS3KeyFilterRule[] | undefined;
}
export interface AwsS3BucketNotificationConfigurationFilter {
    S3KeyFilter?: AwsS3BucketNotificationConfigurationS3KeyFilter | undefined;
}
export interface AwsS3BucketNotificationConfigurationDetail {
    Events?: string[] | undefined;
    Filter?: AwsS3BucketNotificationConfigurationFilter | undefined;
    Destination?: string | undefined;
    Type?: string | undefined;
}
export type AwsS3BucketNotificationConfigurationDetails = AwsS3BucketNotificationConfigurationDetail[];
export interface AwsS3BucketNotificationConfiguration {
    Configurations?: AwsS3BucketNotificationConfigurationDetail[] | undefined;
}
export interface AwsS3BucketBucketVersioningConfiguration {
    IsMfaDeleteEnabled?: boolean | undefined;
    Status?: string | undefined;
}
export interface AwsS3BucketObjectLockConfigurationRuleDefaultRetentionDetails {
    Days?: number | undefined;
    Mode?: string | undefined;
    Years?: number | undefined;
}
export interface AwsS3BucketObjectLockConfigurationRuleDetails {
    DefaultRetention?: AwsS3BucketObjectLockConfigurationRuleDefaultRetentionDetails | undefined;
}
export interface AwsS3BucketObjectLockConfiguration {
    ObjectLockEnabled?: string | undefined;
    Rule?: AwsS3BucketObjectLockConfigurationRuleDetails | undefined;
}
export interface AwsS3BucketDetails {
    OwnerId?: string | undefined;
    OwnerName?: string | undefined;
    OwnerAccountId?: string | undefined;
    CreatedAt?: string | undefined;
    ServerSideEncryptionConfiguration?: AwsS3BucketServerSideEncryptionConfiguration | undefined;
    BucketLifecycleConfiguration?: AwsS3BucketBucketLifecycleConfigurationDetails | undefined;
    PublicAccessBlockConfiguration?: AwsS3AccountPublicAccessBlockDetails | undefined;
    AccessControlList?: string | undefined;
    BucketLoggingConfiguration?: AwsS3BucketLoggingConfiguration | undefined;
    BucketWebsiteConfiguration?: AwsS3BucketWebsiteConfiguration | undefined;
    BucketNotificationConfiguration?: AwsS3BucketNotificationConfiguration | undefined;
    BucketVersioningConfiguration?: AwsS3BucketBucketVersioningConfiguration | undefined;
    ObjectLockConfiguration?: AwsS3BucketObjectLockConfiguration | undefined;
    Name?: string | undefined;
}
export interface AwsS3ObjectDetails {
    LastModified?: string | undefined;
    ETag?: string | undefined;
    VersionId?: string | undefined;
    ContentType?: string | undefined;
    ServerSideEncryption?: string | undefined;
    SSEKMSKeyId?: string | undefined;
}
export interface AwsSecretsManagerSecretRotationRules {
    AutomaticallyAfterDays?: number | undefined;
}
export interface AwsSecretsManagerSecretDetails {
    RotationRules?: AwsSecretsManagerSecretRotationRules | undefined;
    RotationOccurredWithinFrequency?: boolean | undefined;
    KmsKeyId?: string | undefined;
    RotationEnabled?: boolean | undefined;
    RotationLambdaArn?: string | undefined;
    Deleted?: boolean | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type AwsIamAccessKeyStatus = "Active" | "Inactive" | (string & {});
export interface AwsIamAccessKeySessionContextAttributes {
    MfaAuthenticated?: boolean | undefined;
    CreationDate?: string | undefined;
}
export interface AwsIamAccessKeySessionContextSessionIssuer {
    Type?: string | undefined;
    PrincipalId?: string | undefined;
    Arn?: string | undefined;
    AccountId?: string | undefined;
    UserName?: string | undefined;
}
export interface AwsIamAccessKeySessionContext {
    Attributes?: AwsIamAccessKeySessionContextAttributes | undefined;
    SessionIssuer?: AwsIamAccessKeySessionContextSessionIssuer | undefined;
}
export interface AwsIamAccessKeyDetails {
    UserName?: string | undefined;
    Status?: AwsIamAccessKeyStatus | undefined;
    CreatedAt?: string | undefined;
    PrincipalId?: string | undefined;
    PrincipalType?: string | undefined;
    PrincipalName?: string | undefined;
    AccountId?: string | undefined;
    AccessKeyId?: string | undefined;
    SessionContext?: AwsIamAccessKeySessionContext | undefined;
}
export interface AwsIamAttachedManagedPolicy {
    PolicyName?: string | undefined;
    PolicyArn?: string | undefined;
}
export type AwsIamAttachedManagedPolicyList = AwsIamAttachedManagedPolicy[];
export interface AwsIamPermissionsBoundary {
    PermissionsBoundaryArn?: string | undefined;
    PermissionsBoundaryType?: string | undefined;
}
export interface AwsIamUserPolicy {
    PolicyName?: string | undefined;
}
export type AwsIamUserPolicyList = AwsIamUserPolicy[];
export interface AwsIamUserDetails {
    AttachedManagedPolicies?: AwsIamAttachedManagedPolicy[] | undefined;
    CreateDate?: string | undefined;
    GroupList?: string[] | undefined;
    Path?: string | undefined;
    PermissionsBoundary?: AwsIamPermissionsBoundary | undefined;
    UserId?: string | undefined;
    UserName?: string | undefined;
    UserPolicyList?: AwsIamUserPolicy[] | undefined;
}
export interface AwsIamPolicyVersion {
    VersionId?: string | undefined;
    IsDefaultVersion?: boolean | undefined;
    CreateDate?: string | undefined;
}
export type AwsIamPolicyVersionList = AwsIamPolicyVersion[];
export interface AwsIamPolicyDetails {
    AttachmentCount?: number | undefined;
    CreateDate?: string | undefined;
    DefaultVersionId?: string | undefined;
    Description?: string | undefined;
    IsAttachable?: boolean | undefined;
    Path?: string | undefined;
    PermissionsBoundaryUsageCount?: number | undefined;
    PolicyId?: string | undefined;
    PolicyName?: string | undefined;
    PolicyVersionList?: AwsIamPolicyVersion[] | undefined;
    UpdateDate?: string | undefined;
}
export interface AwsApiGatewayV2RouteSettings {
    DetailedMetricsEnabled?: boolean | undefined;
    LoggingLevel?: string | undefined;
    DataTraceEnabled?: boolean | undefined;
    ThrottlingBurstLimit?: number | undefined;
    ThrottlingRateLimit?: number | undefined;
}
export interface AwsApiGatewayAccessLogSettings {
    Format?: string | undefined;
    DestinationArn?: string | undefined;
}
export interface AwsApiGatewayV2StageDetails {
    ClientCertificateId?: string | undefined;
    CreatedDate?: string | undefined;
    Description?: string | undefined;
    DefaultRouteSettings?: AwsApiGatewayV2RouteSettings | undefined;
    DeploymentId?: string | undefined;
    LastUpdatedDate?: string | undefined;
    RouteSettings?: AwsApiGatewayV2RouteSettings | undefined;
    StageName?: string | undefined;
    StageVariables?: {
        [key: string]: string | undefined;
    } | undefined;
    AccessLogSettings?: AwsApiGatewayAccessLogSettings | undefined;
    AutoDeploy?: boolean | undefined;
    LastDeploymentStatusMessage?: string | undefined;
    ApiGatewayManaged?: boolean | undefined;
}
export interface AwsCorsConfiguration {
    AllowOrigins?: string[] | undefined;
    AllowCredentials?: boolean | undefined;
    ExposeHeaders?: string[] | undefined;
    MaxAge?: number | undefined;
    AllowMethods?: string[] | undefined;
    AllowHeaders?: string[] | undefined;
}
export interface AwsApiGatewayV2ApiDetails {
    ApiEndpoint?: string | undefined;
    ApiId?: string | undefined;
    ApiKeySelectionExpression?: string | undefined;
    CreatedDate?: string | undefined;
    Description?: string | undefined;
    Version?: string | undefined;
    Name?: string | undefined;
    ProtocolType?: string | undefined;
    RouteSelectionExpression?: string | undefined;
    CorsConfiguration?: AwsCorsConfiguration | undefined;
}
export interface AwsDynamoDbTableAttributeDefinition {
    AttributeName?: string | undefined;
    AttributeType?: string | undefined;
}
export type AwsDynamoDbTableAttributeDefinitionList = AwsDynamoDbTableAttributeDefinition[];
export interface AwsDynamoDbTableBillingModeSummary {
    BillingMode?: string | undefined;
    LastUpdateToPayPerRequestDateTime?: string | undefined;
}
export type SizeBytes = number;
export interface AwsDynamoDbTableKeySchema {
    AttributeName?: string | undefined;
    KeyType?: string | undefined;
}
export type AwsDynamoDbTableKeySchemaList = AwsDynamoDbTableKeySchema[];
export interface AwsDynamoDbTableProjection {
    NonKeyAttributes?: string[] | undefined;
    ProjectionType?: string | undefined;
}
export interface AwsDynamoDbTableProvisionedThroughput {
    LastDecreaseDateTime?: string | undefined;
    LastIncreaseDateTime?: string | undefined;
    NumberOfDecreasesToday?: number | undefined;
    ReadCapacityUnits?: number | undefined;
    WriteCapacityUnits?: number | undefined;
}
export interface AwsDynamoDbTableGlobalSecondaryIndex {
    Backfilling?: boolean | undefined;
    IndexArn?: string | undefined;
    IndexName?: string | undefined;
    IndexSizeBytes?: number | undefined;
    IndexStatus?: string | undefined;
    ItemCount?: number | undefined;
    KeySchema?: AwsDynamoDbTableKeySchema[] | undefined;
    Projection?: AwsDynamoDbTableProjection | undefined;
    ProvisionedThroughput?: AwsDynamoDbTableProvisionedThroughput | undefined;
}
export type AwsDynamoDbTableGlobalSecondaryIndexList = AwsDynamoDbTableGlobalSecondaryIndex[];
export interface AwsDynamoDbTableLocalSecondaryIndex {
    IndexArn?: string | undefined;
    IndexName?: string | undefined;
    KeySchema?: AwsDynamoDbTableKeySchema[] | undefined;
    Projection?: AwsDynamoDbTableProjection | undefined;
}
export type AwsDynamoDbTableLocalSecondaryIndexList = AwsDynamoDbTableLocalSecondaryIndex[];
export interface AwsDynamoDbTableProvisionedThroughputOverride {
    ReadCapacityUnits?: number | undefined;
}
export interface AwsDynamoDbTableReplicaGlobalSecondaryIndex {
    IndexName?: string | undefined;
    ProvisionedThroughputOverride?: AwsDynamoDbTableProvisionedThroughputOverride | undefined;
}
export type AwsDynamoDbTableReplicaGlobalSecondaryIndexList = AwsDynamoDbTableReplicaGlobalSecondaryIndex[];
export interface AwsDynamoDbTableReplica {
    GlobalSecondaryIndexes?: AwsDynamoDbTableReplicaGlobalSecondaryIndex[] | undefined;
    KmsMasterKeyId?: string | undefined;
    ProvisionedThroughputOverride?: AwsDynamoDbTableProvisionedThroughputOverride | undefined;
    RegionName?: string | undefined;
    ReplicaStatus?: string | undefined;
    ReplicaStatusDescription?: string | undefined;
}
export type AwsDynamoDbTableReplicaList = AwsDynamoDbTableReplica[];
export interface AwsDynamoDbTableRestoreSummary {
    SourceBackupArn?: string | undefined;
    SourceTableArn?: string | undefined;
    RestoreDateTime?: string | undefined;
    RestoreInProgress?: boolean | undefined;
}
export interface AwsDynamoDbTableSseDescription {
    InaccessibleEncryptionDateTime?: string | undefined;
    Status?: string | undefined;
    SseType?: string | undefined;
    KmsMasterKeyArn?: string | undefined;
}
export interface AwsDynamoDbTableStreamSpecification {
    StreamEnabled?: boolean | undefined;
    StreamViewType?: string | undefined;
}
export interface AwsDynamoDbTableDetails {
    AttributeDefinitions?: AwsDynamoDbTableAttributeDefinition[] | undefined;
    BillingModeSummary?: AwsDynamoDbTableBillingModeSummary | undefined;
    CreationDateTime?: string | undefined;
    GlobalSecondaryIndexes?: AwsDynamoDbTableGlobalSecondaryIndex[] | undefined;
    GlobalTableVersion?: string | undefined;
    ItemCount?: number | undefined;
    KeySchema?: AwsDynamoDbTableKeySchema[] | undefined;
    LatestStreamArn?: string | undefined;
    LatestStreamLabel?: string | undefined;
    LocalSecondaryIndexes?: AwsDynamoDbTableLocalSecondaryIndex[] | undefined;
    ProvisionedThroughput?: AwsDynamoDbTableProvisionedThroughput | undefined;
    Replicas?: AwsDynamoDbTableReplica[] | undefined;
    RestoreSummary?: AwsDynamoDbTableRestoreSummary | undefined;
    SseDescription?: AwsDynamoDbTableSseDescription | undefined;
    StreamSpecification?: AwsDynamoDbTableStreamSpecification | undefined;
    TableId?: string | undefined;
    TableName?: string | undefined;
    TableSizeBytes?: number | undefined;
    TableStatus?: string | undefined;
    DeletionProtectionEnabled?: boolean | undefined;
}
export interface AwsApiGatewayMethodSettings {
    MetricsEnabled?: boolean | undefined;
    LoggingLevel?: string | undefined;
    DataTraceEnabled?: boolean | undefined;
    ThrottlingBurstLimit?: number | undefined;
    ThrottlingRateLimit?: number | undefined;
    CachingEnabled?: boolean | undefined;
    CacheTtlInSeconds?: number | undefined;
    CacheDataEncrypted?: boolean | undefined;
    RequireAuthorizationForCacheControl?: boolean | undefined;
    UnauthorizedCacheControlHeaderStrategy?: string | undefined;
    HttpMethod?: string | undefined;
    ResourcePath?: string | undefined;
}
export type AwsApiGatewayMethodSettingsList = AwsApiGatewayMethodSettings[];
export interface AwsApiGatewayCanarySettings {
    PercentTraffic?: number | undefined;
    DeploymentId?: string | undefined;
    StageVariableOverrides?: {
        [key: string]: string | undefined;
    } | undefined;
    UseStageCache?: boolean | undefined;
}
export interface AwsApiGatewayStageDetails {
    DeploymentId?: string | undefined;
    ClientCertificateId?: string | undefined;
    StageName?: string | undefined;
    Description?: string | undefined;
    CacheClusterEnabled?: boolean | undefined;
    CacheClusterSize?: string | undefined;
    CacheClusterStatus?: string | undefined;
    MethodSettings?: AwsApiGatewayMethodSettings[] | undefined;
    Variables?: {
        [key: string]: string | undefined;
    } | undefined;
    DocumentationVersion?: string | undefined;
    AccessLogSettings?: AwsApiGatewayAccessLogSettings | undefined;
    CanarySettings?: AwsApiGatewayCanarySettings | undefined;
    TracingEnabled?: boolean | undefined;
    CreatedDate?: string | undefined;
    LastUpdatedDate?: string | undefined;
    WebAclArn?: string | undefined;
}
export interface AwsApiGatewayEndpointConfiguration {
    Types?: string[] | undefined;
}
export interface AwsApiGatewayRestApiDetails {
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    CreatedDate?: string | undefined;
    Version?: string | undefined;
    BinaryMediaTypes?: string[] | undefined;
    MinimumCompressionSize?: number | undefined;
    ApiKeySource?: string | undefined;
    EndpointConfiguration?: AwsApiGatewayEndpointConfiguration | undefined;
}
export interface AwsCloudTrailTrailDetails {
    CloudWatchLogsLogGroupArn?: string | undefined;
    CloudWatchLogsRoleArn?: string | undefined;
    HasCustomEventSelectors?: boolean | undefined;
    HomeRegion?: string | undefined;
    IncludeGlobalServiceEvents?: boolean | undefined;
    IsMultiRegionTrail?: boolean | undefined;
    IsOrganizationTrail?: boolean | undefined;
    KmsKeyId?: string | undefined;
    LogFileValidationEnabled?: boolean | undefined;
    Name?: string | undefined;
    S3BucketName?: string | undefined;
    S3KeyPrefix?: string | undefined;
    SnsTopicArn?: string | undefined;
    SnsTopicName?: string | undefined;
    TrailArn?: string | undefined;
}
export interface AwsSsmComplianceSummary {
    Status?: string | undefined;
    CompliantCriticalCount?: number | undefined;
    CompliantHighCount?: number | undefined;
    CompliantMediumCount?: number | undefined;
    ExecutionType?: string | undefined;
    NonCompliantCriticalCount?: number | undefined;
    CompliantInformationalCount?: number | undefined;
    NonCompliantInformationalCount?: number | undefined;
    CompliantUnspecifiedCount?: number | undefined;
    NonCompliantLowCount?: number | undefined;
    NonCompliantHighCount?: number | undefined;
    CompliantLowCount?: number | undefined;
    ComplianceType?: string | undefined;
    PatchBaselineId?: string | undefined;
    OverallSeverity?: string | undefined;
    NonCompliantMediumCount?: number | undefined;
    NonCompliantUnspecifiedCount?: number | undefined;
    PatchGroup?: string | undefined;
}
export interface AwsSsmPatch {
    ComplianceSummary?: AwsSsmComplianceSummary | undefined;
}
export interface AwsSsmPatchComplianceDetails {
    Patch?: AwsSsmPatch | undefined;
}
export interface AwsCertificateManagerCertificateResourceRecord {
    Name?: string | undefined;
    Type?: string | undefined;
    Value?: string | undefined;
}
export interface AwsCertificateManagerCertificateDomainValidationOption {
    DomainName?: string | undefined;
    ResourceRecord?: AwsCertificateManagerCertificateResourceRecord | undefined;
    ValidationDomain?: string | undefined;
    ValidationEmails?: string[] | undefined;
    ValidationMethod?: string | undefined;
    ValidationStatus?: string | undefined;
}
export type AwsCertificateManagerCertificateDomainValidationOptions = AwsCertificateManagerCertificateDomainValidationOption[];
export interface AwsCertificateManagerCertificateExtendedKeyUsage {
    Name?: string | undefined;
    OId?: string | undefined;
}
export type AwsCertificateManagerCertificateExtendedKeyUsages = AwsCertificateManagerCertificateExtendedKeyUsage[];
export interface AwsCertificateManagerCertificateKeyUsage {
    Name?: string | undefined;
}
export type AwsCertificateManagerCertificateKeyUsages = AwsCertificateManagerCertificateKeyUsage[];
export interface AwsCertificateManagerCertificateOptions {
    CertificateTransparencyLoggingPreference?: string | undefined;
}
export interface AwsCertificateManagerCertificateRenewalSummary {
    DomainValidationOptions?: AwsCertificateManagerCertificateDomainValidationOption[] | undefined;
    RenewalStatus?: string | undefined;
    RenewalStatusReason?: string | undefined;
    UpdatedAt?: string | undefined;
}
export interface AwsCertificateManagerCertificateDetails {
    CertificateAuthorityArn?: string | undefined;
    CreatedAt?: string | undefined;
    DomainName?: string | undefined;
    DomainValidationOptions?: AwsCertificateManagerCertificateDomainValidationOption[] | undefined;
    ExtendedKeyUsages?: AwsCertificateManagerCertificateExtendedKeyUsage[] | undefined;
    FailureReason?: string | undefined;
    ImportedAt?: string | undefined;
    InUseBy?: string[] | undefined;
    IssuedAt?: string | undefined;
    Issuer?: string | undefined;
    KeyAlgorithm?: string | undefined;
    KeyUsages?: AwsCertificateManagerCertificateKeyUsage[] | undefined;
    NotAfter?: string | undefined;
    NotBefore?: string | undefined;
    Options?: AwsCertificateManagerCertificateOptions | undefined;
    RenewalEligibility?: string | undefined;
    RenewalSummary?: AwsCertificateManagerCertificateRenewalSummary | undefined;
    Serial?: string | undefined;
    SignatureAlgorithm?: string | undefined;
    Status?: string | undefined;
    Subject?: string | undefined;
    SubjectAlternativeNames?: string[] | undefined;
    Type?: string | undefined;
}
export interface AwsRedshiftClusterClusterNode {
    NodeRole?: string | undefined;
    PrivateIpAddress?: string | undefined;
    PublicIpAddress?: string | undefined;
}
export type AwsRedshiftClusterClusterNodes = AwsRedshiftClusterClusterNode[];
export interface AwsRedshiftClusterClusterParameterStatus {
    ParameterName?: string | undefined;
    ParameterApplyStatus?: string | undefined;
    ParameterApplyErrorDescription?: string | undefined;
}
export type AwsRedshiftClusterClusterParameterStatusList = AwsRedshiftClusterClusterParameterStatus[];
export interface AwsRedshiftClusterClusterParameterGroup {
    ClusterParameterStatusList?: AwsRedshiftClusterClusterParameterStatus[] | undefined;
    ParameterApplyStatus?: string | undefined;
    ParameterGroupName?: string | undefined;
}
export type AwsRedshiftClusterClusterParameterGroups = AwsRedshiftClusterClusterParameterGroup[];
export interface AwsRedshiftClusterClusterSecurityGroup {
    ClusterSecurityGroupName?: string | undefined;
    Status?: string | undefined;
}
export type AwsRedshiftClusterClusterSecurityGroups = AwsRedshiftClusterClusterSecurityGroup[];
export interface AwsRedshiftClusterClusterSnapshotCopyStatus {
    DestinationRegion?: string | undefined;
    ManualSnapshotRetentionPeriod?: number | undefined;
    RetentionPeriod?: number | undefined;
    SnapshotCopyGrantName?: string | undefined;
}
export interface AwsRedshiftClusterDeferredMaintenanceWindow {
    DeferMaintenanceEndTime?: string | undefined;
    DeferMaintenanceIdentifier?: string | undefined;
    DeferMaintenanceStartTime?: string | undefined;
}
export type AwsRedshiftClusterDeferredMaintenanceWindows = AwsRedshiftClusterDeferredMaintenanceWindow[];
export interface AwsRedshiftClusterElasticIpStatus {
    ElasticIp?: string | undefined;
    Status?: string | undefined;
}
export interface AwsRedshiftClusterEndpoint {
    Address?: string | undefined;
    Port?: number | undefined;
}
export interface AwsRedshiftClusterHsmStatus {
    HsmClientCertificateIdentifier?: string | undefined;
    HsmConfigurationIdentifier?: string | undefined;
    Status?: string | undefined;
}
export interface AwsRedshiftClusterIamRole {
    ApplyStatus?: string | undefined;
    IamRoleArn?: string | undefined;
}
export type AwsRedshiftClusterIamRoles = AwsRedshiftClusterIamRole[];
export interface AwsRedshiftClusterPendingModifiedValues {
    AutomatedSnapshotRetentionPeriod?: number | undefined;
    ClusterIdentifier?: string | undefined;
    ClusterType?: string | undefined;
    ClusterVersion?: string | undefined;
    EncryptionType?: string | undefined;
    EnhancedVpcRouting?: boolean | undefined;
    MaintenanceTrackName?: string | undefined;
    MasterUserPassword?: string | undefined;
    NodeType?: string | undefined;
    NumberOfNodes?: number | undefined;
    PubliclyAccessible?: boolean | undefined;
}
export interface AwsRedshiftClusterResizeInfo {
    AllowCancelResize?: boolean | undefined;
    ResizeType?: string | undefined;
}
export interface AwsRedshiftClusterRestoreStatus {
    CurrentRestoreRateInMegaBytesPerSecond?: number | undefined;
    ElapsedTimeInSeconds?: number | undefined;
    EstimatedTimeToCompletionInSeconds?: number | undefined;
    ProgressInMegaBytes?: number | undefined;
    SnapshotSizeInMegaBytes?: number | undefined;
    Status?: string | undefined;
}
export interface AwsRedshiftClusterVpcSecurityGroup {
    Status?: string | undefined;
    VpcSecurityGroupId?: string | undefined;
}
export type AwsRedshiftClusterVpcSecurityGroups = AwsRedshiftClusterVpcSecurityGroup[];
export interface AwsRedshiftClusterLoggingStatus {
    BucketName?: string | undefined;
    LastFailureMessage?: string | undefined;
    LastFailureTime?: string | undefined;
    LastSuccessfulDeliveryTime?: string | undefined;
    LoggingEnabled?: boolean | undefined;
    S3KeyPrefix?: string | undefined;
}
export interface AwsRedshiftClusterDetails {
    AllowVersionUpgrade?: boolean | undefined;
    AutomatedSnapshotRetentionPeriod?: number | undefined;
    AvailabilityZone?: string | undefined;
    ClusterAvailabilityStatus?: string | undefined;
    ClusterCreateTime?: string | undefined;
    ClusterIdentifier?: string | undefined;
    ClusterNodes?: AwsRedshiftClusterClusterNode[] | undefined;
    ClusterParameterGroups?: AwsRedshiftClusterClusterParameterGroup[] | undefined;
    ClusterPublicKey?: string | undefined;
    ClusterRevisionNumber?: string | undefined;
    ClusterSecurityGroups?: AwsRedshiftClusterClusterSecurityGroup[] | undefined;
    ClusterSnapshotCopyStatus?: AwsRedshiftClusterClusterSnapshotCopyStatus | undefined;
    ClusterStatus?: string | undefined;
    ClusterSubnetGroupName?: string | undefined;
    ClusterVersion?: string | undefined;
    DBName?: string | undefined;
    DeferredMaintenanceWindows?: AwsRedshiftClusterDeferredMaintenanceWindow[] | undefined;
    ElasticIpStatus?: AwsRedshiftClusterElasticIpStatus | undefined;
    ElasticResizeNumberOfNodeOptions?: string | undefined;
    Encrypted?: boolean | undefined;
    Endpoint?: AwsRedshiftClusterEndpoint | undefined;
    EnhancedVpcRouting?: boolean | undefined;
    ExpectedNextSnapshotScheduleTime?: string | undefined;
    ExpectedNextSnapshotScheduleTimeStatus?: string | undefined;
    HsmStatus?: AwsRedshiftClusterHsmStatus | undefined;
    IamRoles?: AwsRedshiftClusterIamRole[] | undefined;
    KmsKeyId?: string | undefined;
    MaintenanceTrackName?: string | undefined;
    ManualSnapshotRetentionPeriod?: number | undefined;
    MasterUsername?: string | undefined;
    NextMaintenanceWindowStartTime?: string | undefined;
    NodeType?: string | undefined;
    NumberOfNodes?: number | undefined;
    PendingActions?: string[] | undefined;
    PendingModifiedValues?: AwsRedshiftClusterPendingModifiedValues | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    ResizeInfo?: AwsRedshiftClusterResizeInfo | undefined;
    RestoreStatus?: AwsRedshiftClusterRestoreStatus | undefined;
    SnapshotScheduleIdentifier?: string | undefined;
    SnapshotScheduleState?: string | undefined;
    VpcId?: string | undefined;
    VpcSecurityGroups?: AwsRedshiftClusterVpcSecurityGroup[] | undefined;
    LoggingStatus?: AwsRedshiftClusterLoggingStatus | undefined;
}
export interface AwsElbLoadBalancerBackendServerDescription {
    InstancePort?: number | undefined;
    PolicyNames?: string[] | undefined;
}
export type AwsElbLoadBalancerBackendServerDescriptions = AwsElbLoadBalancerBackendServerDescription[];
export interface AwsElbLoadBalancerHealthCheck {
    HealthyThreshold?: number | undefined;
    Interval?: number | undefined;
    Target?: string | undefined;
    Timeout?: number | undefined;
    UnhealthyThreshold?: number | undefined;
}
export interface AwsElbLoadBalancerInstance {
    InstanceId?: string | undefined;
}
export type AwsElbLoadBalancerInstances = AwsElbLoadBalancerInstance[];
export interface AwsElbLoadBalancerListener {
    InstancePort?: number | undefined;
    InstanceProtocol?: string | undefined;
    LoadBalancerPort?: number | undefined;
    Protocol?: string | undefined;
    SslCertificateId?: string | undefined;
}
export interface AwsElbLoadBalancerListenerDescription {
    Listener?: AwsElbLoadBalancerListener | undefined;
    PolicyNames?: string[] | undefined;
}
export type AwsElbLoadBalancerListenerDescriptions = AwsElbLoadBalancerListenerDescription[];
export interface AwsElbLoadBalancerAccessLog {
    EmitInterval?: number | undefined;
    Enabled?: boolean | undefined;
    S3BucketName?: string | undefined;
    S3BucketPrefix?: string | undefined;
}
export interface AwsElbLoadBalancerConnectionDraining {
    Enabled?: boolean | undefined;
    Timeout?: number | undefined;
}
export interface AwsElbLoadBalancerConnectionSettings {
    IdleTimeout?: number | undefined;
}
export interface AwsElbLoadBalancerCrossZoneLoadBalancing {
    Enabled?: boolean | undefined;
}
export interface AwsElbLoadBalancerAdditionalAttribute {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type AwsElbLoadBalancerAdditionalAttributeList = AwsElbLoadBalancerAdditionalAttribute[];
export interface AwsElbLoadBalancerAttributes {
    AccessLog?: AwsElbLoadBalancerAccessLog | undefined;
    ConnectionDraining?: AwsElbLoadBalancerConnectionDraining | undefined;
    ConnectionSettings?: AwsElbLoadBalancerConnectionSettings | undefined;
    CrossZoneLoadBalancing?: AwsElbLoadBalancerCrossZoneLoadBalancing | undefined;
    AdditionalAttributes?: AwsElbLoadBalancerAdditionalAttribute[] | undefined;
}
export interface AwsElbAppCookieStickinessPolicy {
    CookieName?: string | undefined;
    PolicyName?: string | undefined;
}
export type AwsElbAppCookieStickinessPolicies = AwsElbAppCookieStickinessPolicy[];
export interface AwsElbLbCookieStickinessPolicy {
    CookieExpirationPeriod?: number | undefined;
    PolicyName?: string | undefined;
}
export type AwsElbLbCookieStickinessPolicies = AwsElbLbCookieStickinessPolicy[];
export interface AwsElbLoadBalancerPolicies {
    AppCookieStickinessPolicies?: AwsElbAppCookieStickinessPolicy[] | undefined;
    LbCookieStickinessPolicies?: AwsElbLbCookieStickinessPolicy[] | undefined;
    OtherPolicies?: string[] | undefined;
}
export interface AwsElbLoadBalancerSourceSecurityGroup {
    GroupName?: string | undefined;
    OwnerAlias?: string | undefined;
}
export interface AwsElbLoadBalancerDetails {
    AvailabilityZones?: string[] | undefined;
    BackendServerDescriptions?: AwsElbLoadBalancerBackendServerDescription[] | undefined;
    CanonicalHostedZoneName?: string | undefined;
    CanonicalHostedZoneNameID?: string | undefined;
    CreatedTime?: string | undefined;
    DnsName?: string | undefined;
    HealthCheck?: AwsElbLoadBalancerHealthCheck | undefined;
    Instances?: AwsElbLoadBalancerInstance[] | undefined;
    ListenerDescriptions?: AwsElbLoadBalancerListenerDescription[] | undefined;
    LoadBalancerAttributes?: AwsElbLoadBalancerAttributes | undefined;
    LoadBalancerName?: string | undefined;
    Policies?: AwsElbLoadBalancerPolicies | undefined;
    Scheme?: string | undefined;
    SecurityGroups?: string[] | undefined;
    SourceSecurityGroup?: AwsElbLoadBalancerSourceSecurityGroup | undefined;
    Subnets?: string[] | undefined;
    VpcId?: string | undefined;
}
export interface AwsIamGroupPolicy {
    PolicyName?: string | undefined;
}
export type AwsIamGroupPolicyList = AwsIamGroupPolicy[];
export interface AwsIamGroupDetails {
    AttachedManagedPolicies?: AwsIamAttachedManagedPolicy[] | undefined;
    CreateDate?: string | undefined;
    GroupId?: string | undefined;
    GroupName?: string | undefined;
    GroupPolicyList?: AwsIamGroupPolicy[] | undefined;
    Path?: string | undefined;
}
export type AwsIamRoleAssumeRolePolicyDocument = string;
export interface AwsIamInstanceProfileRole {
    Arn?: string | undefined;
    AssumeRolePolicyDocument?: string | undefined;
    CreateDate?: string | undefined;
    Path?: string | undefined;
    RoleId?: string | undefined;
    RoleName?: string | undefined;
}
export type AwsIamInstanceProfileRoles = AwsIamInstanceProfileRole[];
export interface AwsIamInstanceProfile {
    Arn?: string | undefined;
    CreateDate?: string | undefined;
    InstanceProfileId?: string | undefined;
    InstanceProfileName?: string | undefined;
    Path?: string | undefined;
    Roles?: AwsIamInstanceProfileRole[] | undefined;
}
export type AwsIamInstanceProfileList = AwsIamInstanceProfile[];
export interface AwsIamRolePolicy {
    PolicyName?: string | undefined;
}
export type AwsIamRolePolicyList = AwsIamRolePolicy[];
export interface AwsIamRoleDetails {
    AssumeRolePolicyDocument?: string | undefined;
    AttachedManagedPolicies?: AwsIamAttachedManagedPolicy[] | undefined;
    CreateDate?: string | undefined;
    InstanceProfileList?: AwsIamInstanceProfile[] | undefined;
    PermissionsBoundary?: AwsIamPermissionsBoundary | undefined;
    RoleId?: string | undefined;
    RoleName?: string | undefined;
    RolePolicyList?: AwsIamRolePolicy[] | undefined;
    MaxSessionDuration?: number | undefined;
    Path?: string | undefined;
}
export interface AwsKmsKeyDetails {
    AWSAccountId?: string | undefined;
    CreationDate?: number | undefined;
    KeyId?: string | undefined;
    KeyManager?: string | undefined;
    KeyState?: string | undefined;
    Origin?: string | undefined;
    Description?: string | undefined;
    KeyRotationStatus?: boolean | undefined;
}
export interface AwsLambdaFunctionCode {
    S3Bucket?: string | undefined;
    S3Key?: string | undefined;
    S3ObjectVersion?: string | undefined;
    ZipFile?: string | undefined;
}
export interface AwsLambdaFunctionDeadLetterConfig {
    TargetArn?: string | undefined;
}
export interface AwsLambdaFunctionEnvironmentError {
    ErrorCode?: string | undefined;
    Message?: string | undefined;
}
export interface AwsLambdaFunctionEnvironment {
    Variables?: {
        [key: string]: string | undefined;
    } | undefined;
    Error?: AwsLambdaFunctionEnvironmentError | undefined;
}
export interface AwsLambdaFunctionLayer {
    Arn?: string | undefined;
    CodeSize?: number | undefined;
}
export type AwsLambdaFunctionLayerList = AwsLambdaFunctionLayer[];
export interface AwsLambdaFunctionTracingConfig {
    Mode?: string | undefined;
}
export interface AwsLambdaFunctionVpcConfig {
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    VpcId?: string | undefined;
}
export interface AwsLambdaFunctionDetails {
    Code?: AwsLambdaFunctionCode | undefined;
    CodeSha256?: string | undefined;
    DeadLetterConfig?: AwsLambdaFunctionDeadLetterConfig | undefined;
    Environment?: AwsLambdaFunctionEnvironment | undefined;
    FunctionName?: string | undefined;
    Handler?: string | undefined;
    KmsKeyArn?: string | undefined;
    LastModified?: string | undefined;
    Layers?: AwsLambdaFunctionLayer[] | undefined;
    MasterArn?: string | undefined;
    MemorySize?: number | undefined;
    RevisionId?: string | undefined;
    Role?: string | undefined;
    Runtime?: string | undefined;
    Timeout?: number | undefined;
    TracingConfig?: AwsLambdaFunctionTracingConfig | undefined;
    VpcConfig?: AwsLambdaFunctionVpcConfig | undefined;
    Version?: string | undefined;
    Architectures?: string[] | undefined;
    PackageType?: string | undefined;
}
export type AwsLambdaLayerVersionNumber = number;
export interface AwsLambdaLayerVersionDetails {
    Version?: number | undefined;
    CompatibleRuntimes?: string[] | undefined;
    CreatedDate?: string | undefined;
}
export interface AwsRdsDbInstanceAssociatedRole {
    RoleArn?: string | undefined;
    FeatureName?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbInstanceAssociatedRoles = AwsRdsDbInstanceAssociatedRole[];
export interface AwsRdsDbInstanceEndpoint {
    Address?: string | undefined;
    Port?: number | undefined;
    HostedZoneId?: string | undefined;
}
export interface AwsRdsDbInstanceVpcSecurityGroup {
    VpcSecurityGroupId?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbInstanceVpcSecurityGroups = AwsRdsDbInstanceVpcSecurityGroup[];
export interface AwsRdsDbParameterGroup {
    DbParameterGroupName?: string | undefined;
    ParameterApplyStatus?: string | undefined;
}
export type AwsRdsDbParameterGroups = AwsRdsDbParameterGroup[];
export interface AwsRdsDbSubnetGroupSubnetAvailabilityZone {
    Name?: string | undefined;
}
export interface AwsRdsDbSubnetGroupSubnet {
    SubnetIdentifier?: string | undefined;
    SubnetAvailabilityZone?: AwsRdsDbSubnetGroupSubnetAvailabilityZone | undefined;
    SubnetStatus?: string | undefined;
}
export type AwsRdsDbSubnetGroupSubnets = AwsRdsDbSubnetGroupSubnet[];
export interface AwsRdsDbSubnetGroup {
    DbSubnetGroupName?: string | undefined;
    DbSubnetGroupDescription?: string | undefined;
    VpcId?: string | undefined;
    SubnetGroupStatus?: string | undefined;
    Subnets?: AwsRdsDbSubnetGroupSubnet[] | undefined;
    DbSubnetGroupArn?: string | undefined;
}
export interface AwsRdsPendingCloudWatchLogsExports {
    LogTypesToEnable?: string[] | undefined;
    LogTypesToDisable?: string[] | undefined;
}
export interface AwsRdsDbProcessorFeature {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type AwsRdsDbProcessorFeatures = AwsRdsDbProcessorFeature[];
export interface AwsRdsDbPendingModifiedValues {
    DbInstanceClass?: string | undefined;
    AllocatedStorage?: number | undefined;
    MasterUserPassword?: string | undefined;
    Port?: number | undefined;
    BackupRetentionPeriod?: number | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    DbInstanceIdentifier?: string | undefined;
    StorageType?: string | undefined;
    CaCertificateIdentifier?: string | undefined;
    DbSubnetGroupName?: string | undefined;
    PendingCloudWatchLogsExports?: AwsRdsPendingCloudWatchLogsExports | undefined;
    ProcessorFeatures?: AwsRdsDbProcessorFeature[] | undefined;
}
export interface AwsRdsDbOptionGroupMembership {
    OptionGroupName?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbOptionGroupMemberships = AwsRdsDbOptionGroupMembership[];
export interface AwsRdsDbStatusInfo {
    StatusType?: string | undefined;
    Normal?: boolean | undefined;
    Status?: string | undefined;
    Message?: string | undefined;
}
export type AwsRdsDbStatusInfos = AwsRdsDbStatusInfo[];
export interface AwsRdsDbDomainMembership {
    Domain?: string | undefined;
    Status?: string | undefined;
    Fqdn?: string | undefined;
    IamRoleName?: string | undefined;
}
export type AwsRdsDbDomainMemberships = AwsRdsDbDomainMembership[];
export interface AwsRdsDbInstanceDetails {
    AssociatedRoles?: AwsRdsDbInstanceAssociatedRole[] | undefined;
    CACertificateIdentifier?: string | undefined;
    DBClusterIdentifier?: string | undefined;
    DBInstanceIdentifier?: string | undefined;
    DBInstanceClass?: string | undefined;
    DbInstancePort?: number | undefined;
    DbiResourceId?: string | undefined;
    DBName?: string | undefined;
    DeletionProtection?: boolean | undefined;
    Endpoint?: AwsRdsDbInstanceEndpoint | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    IAMDatabaseAuthenticationEnabled?: boolean | undefined;
    InstanceCreateTime?: string | undefined;
    KmsKeyId?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    StorageEncrypted?: boolean | undefined;
    TdeCredentialArn?: string | undefined;
    VpcSecurityGroups?: AwsRdsDbInstanceVpcSecurityGroup[] | undefined;
    MultiAz?: boolean | undefined;
    EnhancedMonitoringResourceArn?: string | undefined;
    DbInstanceStatus?: string | undefined;
    MasterUsername?: string | undefined;
    AllocatedStorage?: number | undefined;
    PreferredBackupWindow?: string | undefined;
    BackupRetentionPeriod?: number | undefined;
    DbSecurityGroups?: string[] | undefined;
    DbParameterGroups?: AwsRdsDbParameterGroup[] | undefined;
    AvailabilityZone?: string | undefined;
    DbSubnetGroup?: AwsRdsDbSubnetGroup | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    PendingModifiedValues?: AwsRdsDbPendingModifiedValues | undefined;
    LatestRestorableTime?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    ReadReplicaSourceDBInstanceIdentifier?: string | undefined;
    ReadReplicaDBInstanceIdentifiers?: string[] | undefined;
    ReadReplicaDBClusterIdentifiers?: string[] | undefined;
    LicenseModel?: string | undefined;
    Iops?: number | undefined;
    OptionGroupMemberships?: AwsRdsDbOptionGroupMembership[] | undefined;
    CharacterSetName?: string | undefined;
    SecondaryAvailabilityZone?: string | undefined;
    StatusInfos?: AwsRdsDbStatusInfo[] | undefined;
    StorageType?: string | undefined;
    DomainMemberships?: AwsRdsDbDomainMembership[] | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    MonitoringInterval?: number | undefined;
    MonitoringRoleArn?: string | undefined;
    PromotionTier?: number | undefined;
    Timezone?: string | undefined;
    PerformanceInsightsEnabled?: boolean | undefined;
    PerformanceInsightsKmsKeyId?: string | undefined;
    PerformanceInsightsRetentionPeriod?: number | undefined;
    EnabledCloudWatchLogsExports?: string[] | undefined;
    ProcessorFeatures?: AwsRdsDbProcessorFeature[] | undefined;
    ListenerEndpoint?: AwsRdsDbInstanceEndpoint | undefined;
    MaxAllocatedStorage?: number | undefined;
}
export interface AwsSnsTopicSubscription {
    Endpoint?: string | undefined;
    Protocol?: string | undefined;
}
export type AwsSnsTopicSubscriptionList = AwsSnsTopicSubscription[];
export interface AwsSnsTopicDetails {
    KmsMasterKeyId?: string | undefined;
    Subscription?: AwsSnsTopicSubscription[] | undefined;
    TopicName?: string | undefined;
    Owner?: string | undefined;
    SqsSuccessFeedbackRoleArn?: string | undefined;
    SqsFailureFeedbackRoleArn?: string | undefined;
    ApplicationSuccessFeedbackRoleArn?: string | undefined;
    FirehoseSuccessFeedbackRoleArn?: string | undefined;
    FirehoseFailureFeedbackRoleArn?: string | undefined;
    HttpSuccessFeedbackRoleArn?: string | undefined;
    HttpFailureFeedbackRoleArn?: string | undefined;
}
export interface AwsSqsQueueDetails {
    KmsDataKeyReusePeriodSeconds?: number | undefined;
    KmsMasterKeyId?: string | undefined;
    QueueName?: string | undefined;
    DeadLetterTargetArn?: string | undefined;
}
export interface WafAction {
    Type?: string | undefined;
}
export interface WafExcludedRule {
    RuleId?: string | undefined;
}
export type WafExcludedRuleList = WafExcludedRule[];
export interface WafOverrideAction {
    Type?: string | undefined;
}
export interface AwsWafWebAclRule {
    Action?: WafAction | undefined;
    ExcludedRules?: WafExcludedRule[] | undefined;
    OverrideAction?: WafOverrideAction | undefined;
    Priority?: number | undefined;
    RuleId?: string | undefined;
    Type?: string | undefined;
}
export type AwsWafWebAclRuleList = AwsWafWebAclRule[];
export interface AwsWafWebAclDetails {
    Name?: string | undefined;
    DefaultAction?: string | undefined;
    Rules?: AwsWafWebAclRule[] | undefined;
    WebAclId?: string | undefined;
}
export interface AwsRdsDbSnapshotDetails {
    DbSnapshotIdentifier?: string | undefined;
    DbInstanceIdentifier?: string | undefined;
    SnapshotCreateTime?: string | undefined;
    Engine?: string | undefined;
    AllocatedStorage?: number | undefined;
    Status?: string | undefined;
    Port?: number | undefined;
    AvailabilityZone?: string | undefined;
    VpcId?: string | undefined;
    InstanceCreateTime?: string | undefined;
    MasterUsername?: string | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    SnapshotType?: string | undefined;
    Iops?: number | undefined;
    OptionGroupName?: string | undefined;
    PercentProgress?: number | undefined;
    SourceRegion?: string | undefined;
    SourceDbSnapshotIdentifier?: string | undefined;
    StorageType?: string | undefined;
    TdeCredentialArn?: string | undefined;
    Encrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    Timezone?: string | undefined;
    IamDatabaseAuthenticationEnabled?: boolean | undefined;
    ProcessorFeatures?: AwsRdsDbProcessorFeature[] | undefined;
    DbiResourceId?: string | undefined;
}
export interface AwsRdsDbClusterSnapshotDbClusterSnapshotAttribute {
    AttributeName?: string | undefined;
    AttributeValues?: string[] | undefined;
}
export type AwsRdsDbClusterSnapshotDbClusterSnapshotAttributes = AwsRdsDbClusterSnapshotDbClusterSnapshotAttribute[];
export interface AwsRdsDbClusterSnapshotDetails {
    AvailabilityZones?: string[] | undefined;
    SnapshotCreateTime?: string | undefined;
    Engine?: string | undefined;
    AllocatedStorage?: number | undefined;
    Status?: string | undefined;
    Port?: number | undefined;
    VpcId?: string | undefined;
    ClusterCreateTime?: string | undefined;
    MasterUsername?: string | undefined;
    EngineVersion?: string | undefined;
    LicenseModel?: string | undefined;
    SnapshotType?: string | undefined;
    PercentProgress?: number | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    DbClusterIdentifier?: string | undefined;
    DbClusterSnapshotIdentifier?: string | undefined;
    IamDatabaseAuthenticationEnabled?: boolean | undefined;
    DbClusterSnapshotAttributes?: AwsRdsDbClusterSnapshotDbClusterSnapshotAttribute[] | undefined;
}
export interface AwsRdsDbClusterAssociatedRole {
    RoleArn?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbClusterAssociatedRoles = AwsRdsDbClusterAssociatedRole[];
export interface AwsRdsDbClusterOptionGroupMembership {
    DbClusterOptionGroupName?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbClusterOptionGroupMemberships = AwsRdsDbClusterOptionGroupMembership[];
export interface AwsRdsDbClusterMember {
    IsClusterWriter?: boolean | undefined;
    PromotionTier?: number | undefined;
    DbInstanceIdentifier?: string | undefined;
    DbClusterParameterGroupStatus?: string | undefined;
}
export type AwsRdsDbClusterMembers = AwsRdsDbClusterMember[];
export interface AwsRdsDbClusterDetails {
    AllocatedStorage?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    BackupRetentionPeriod?: number | undefined;
    DatabaseName?: string | undefined;
    Status?: string | undefined;
    Endpoint?: string | undefined;
    ReaderEndpoint?: string | undefined;
    CustomEndpoints?: string[] | undefined;
    MultiAz?: boolean | undefined;
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    Port?: number | undefined;
    MasterUsername?: string | undefined;
    PreferredBackupWindow?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    ReadReplicaIdentifiers?: string[] | undefined;
    VpcSecurityGroups?: AwsRdsDbInstanceVpcSecurityGroup[] | undefined;
    HostedZoneId?: string | undefined;
    StorageEncrypted?: boolean | undefined;
    KmsKeyId?: string | undefined;
    DbClusterResourceId?: string | undefined;
    AssociatedRoles?: AwsRdsDbClusterAssociatedRole[] | undefined;
    ClusterCreateTime?: string | undefined;
    EnabledCloudWatchLogsExports?: string[] | undefined;
    EngineMode?: string | undefined;
    DeletionProtection?: boolean | undefined;
    HttpEndpointEnabled?: boolean | undefined;
    ActivityStreamStatus?: string | undefined;
    CopyTagsToSnapshot?: boolean | undefined;
    CrossAccountClone?: boolean | undefined;
    DomainMemberships?: AwsRdsDbDomainMembership[] | undefined;
    DbClusterParameterGroup?: string | undefined;
    DbSubnetGroup?: string | undefined;
    DbClusterOptionGroupMemberships?: AwsRdsDbClusterOptionGroupMembership[] | undefined;
    DbClusterIdentifier?: string | undefined;
    DbClusterMembers?: AwsRdsDbClusterMember[] | undefined;
    IamDatabaseAuthenticationEnabled?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
}
export interface AwsEcsClusterClusterSettingsDetails {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type AwsEcsClusterClusterSettingsList = AwsEcsClusterClusterSettingsDetails[];
export interface AwsEcsClusterConfigurationExecuteCommandConfigurationLogConfigurationDetails {
    CloudWatchEncryptionEnabled?: boolean | undefined;
    CloudWatchLogGroupName?: string | undefined;
    S3BucketName?: string | undefined;
    S3EncryptionEnabled?: boolean | undefined;
    S3KeyPrefix?: string | undefined;
}
export interface AwsEcsClusterConfigurationExecuteCommandConfigurationDetails {
    KmsKeyId?: string | undefined;
    LogConfiguration?: AwsEcsClusterConfigurationExecuteCommandConfigurationLogConfigurationDetails | undefined;
    Logging?: string | undefined;
}
export interface AwsEcsClusterConfigurationDetails {
    ExecuteCommandConfiguration?: AwsEcsClusterConfigurationExecuteCommandConfigurationDetails | undefined;
}
export interface AwsEcsClusterDefaultCapacityProviderStrategyDetails {
    Base?: number | undefined;
    CapacityProvider?: string | undefined;
    Weight?: number | undefined;
}
export type AwsEcsClusterDefaultCapacityProviderStrategyList = AwsEcsClusterDefaultCapacityProviderStrategyDetails[];
export interface AwsEcsClusterDetails {
    ClusterArn?: string | undefined;
    ActiveServicesCount?: number | undefined;
    CapacityProviders?: string[] | undefined;
    ClusterSettings?: AwsEcsClusterClusterSettingsDetails[] | undefined;
    Configuration?: AwsEcsClusterConfigurationDetails | undefined;
    DefaultCapacityProviderStrategy?: AwsEcsClusterDefaultCapacityProviderStrategyDetails[] | undefined;
    ClusterName?: string | undefined;
    RegisteredContainerInstancesCount?: number | undefined;
    RunningTasksCount?: number | undefined;
    Status?: string | undefined;
}
export interface AwsMountPoint {
    SourceVolume?: string | undefined;
    ContainerPath?: string | undefined;
}
export type AwsMountPointList = AwsMountPoint[];
export interface AwsEcsContainerDetails {
    Name?: string | undefined;
    Image?: string | undefined;
    MountPoints?: AwsMountPoint[] | undefined;
    Privileged?: boolean | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsDependsOnDetails {
    Condition?: string | undefined;
    ContainerName?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsDependsOnList = AwsEcsTaskDefinitionContainerDefinitionsDependsOnDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsEnvironmentDetails {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsEnvironmentList = AwsEcsTaskDefinitionContainerDefinitionsEnvironmentDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesDetails {
    Type?: string | undefined;
    Value?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesList = AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsExtraHostsDetails {
    Hostname?: string | undefined;
    IpAddress?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsExtraHostsList = AwsEcsTaskDefinitionContainerDefinitionsExtraHostsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsFirelensConfigurationDetails {
    Options?: {
        [key: string]: string | undefined;
    } | undefined;
    Type?: string | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsHealthCheckDetails {
    Command?: string[] | undefined;
    Interval?: number | undefined;
    Retries?: number | undefined;
    StartPeriod?: number | undefined;
    Timeout?: number | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersCapabilitiesDetails {
    Add?: string[] | undefined;
    Drop?: string[] | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesDetails {
    ContainerPath?: string | undefined;
    HostPath?: string | undefined;
    Permissions?: string[] | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesList = AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsDetails {
    ContainerPath?: string | undefined;
    MountOptions?: string[] | undefined;
    Size?: number | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsList = AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDetails {
    Capabilities?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersCapabilitiesDetails | undefined;
    Devices?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDevicesDetails[] | undefined;
    InitProcessEnabled?: boolean | undefined;
    MaxSwap?: number | undefined;
    SharedMemorySize?: number | undefined;
    Swappiness?: number | undefined;
    Tmpfs?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersTmpfsDetails[] | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsDetails {
    Name?: string | undefined;
    ValueFrom?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsList = AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationDetails {
    LogDriver?: string | undefined;
    Options?: {
        [key: string]: string | undefined;
    } | undefined;
    SecretOptions?: AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationSecretOptionsDetails[] | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsMountPointsDetails {
    ContainerPath?: string | undefined;
    ReadOnly?: boolean | undefined;
    SourceVolume?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsMountPointsList = AwsEcsTaskDefinitionContainerDefinitionsMountPointsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsPortMappingsDetails {
    ContainerPort?: number | undefined;
    HostPort?: number | undefined;
    Protocol?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsPortMappingsList = AwsEcsTaskDefinitionContainerDefinitionsPortMappingsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsRepositoryCredentialsDetails {
    CredentialsParameter?: string | undefined;
}
export interface AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsDetails {
    Type?: string | undefined;
    Value?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsList = AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsSecretsDetails {
    Name?: string | undefined;
    ValueFrom?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsSecretsList = AwsEcsTaskDefinitionContainerDefinitionsSecretsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsSystemControlsDetails {
    Namespace?: string | undefined;
    Value?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsSystemControlsList = AwsEcsTaskDefinitionContainerDefinitionsSystemControlsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsUlimitsDetails {
    HardLimit?: number | undefined;
    Name?: string | undefined;
    SoftLimit?: number | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsUlimitsList = AwsEcsTaskDefinitionContainerDefinitionsUlimitsDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsVolumesFromDetails {
    ReadOnly?: boolean | undefined;
    SourceContainer?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsVolumesFromList = AwsEcsTaskDefinitionContainerDefinitionsVolumesFromDetails[];
export interface AwsEcsTaskDefinitionContainerDefinitionsDetails {
    Command?: string[] | undefined;
    Cpu?: number | undefined;
    DependsOn?: AwsEcsTaskDefinitionContainerDefinitionsDependsOnDetails[] | undefined;
    DisableNetworking?: boolean | undefined;
    DnsSearchDomains?: string[] | undefined;
    DnsServers?: string[] | undefined;
    DockerLabels?: {
        [key: string]: string | undefined;
    } | undefined;
    DockerSecurityOptions?: string[] | undefined;
    EntryPoint?: string[] | undefined;
    Environment?: AwsEcsTaskDefinitionContainerDefinitionsEnvironmentDetails[] | undefined;
    EnvironmentFiles?: AwsEcsTaskDefinitionContainerDefinitionsEnvironmentFilesDetails[] | undefined;
    Essential?: boolean | undefined;
    ExtraHosts?: AwsEcsTaskDefinitionContainerDefinitionsExtraHostsDetails[] | undefined;
    FirelensConfiguration?: AwsEcsTaskDefinitionContainerDefinitionsFirelensConfigurationDetails | undefined;
    HealthCheck?: AwsEcsTaskDefinitionContainerDefinitionsHealthCheckDetails | undefined;
    Hostname?: string | undefined;
    Image?: string | undefined;
    Interactive?: boolean | undefined;
    Links?: string[] | undefined;
    LinuxParameters?: AwsEcsTaskDefinitionContainerDefinitionsLinuxParametersDetails | undefined;
    LogConfiguration?: AwsEcsTaskDefinitionContainerDefinitionsLogConfigurationDetails | undefined;
    Memory?: number | undefined;
    MemoryReservation?: number | undefined;
    MountPoints?: AwsEcsTaskDefinitionContainerDefinitionsMountPointsDetails[] | undefined;
    Name?: string | undefined;
    PortMappings?: AwsEcsTaskDefinitionContainerDefinitionsPortMappingsDetails[] | undefined;
    Privileged?: boolean | undefined;
    PseudoTerminal?: boolean | undefined;
    ReadonlyRootFilesystem?: boolean | undefined;
    RepositoryCredentials?: AwsEcsTaskDefinitionContainerDefinitionsRepositoryCredentialsDetails | undefined;
    ResourceRequirements?: AwsEcsTaskDefinitionContainerDefinitionsResourceRequirementsDetails[] | undefined;
    Secrets?: AwsEcsTaskDefinitionContainerDefinitionsSecretsDetails[] | undefined;
    StartTimeout?: number | undefined;
    StopTimeout?: number | undefined;
    SystemControls?: AwsEcsTaskDefinitionContainerDefinitionsSystemControlsDetails[] | undefined;
    Ulimits?: AwsEcsTaskDefinitionContainerDefinitionsUlimitsDetails[] | undefined;
    User?: string | undefined;
    VolumesFrom?: AwsEcsTaskDefinitionContainerDefinitionsVolumesFromDetails[] | undefined;
    WorkingDirectory?: string | undefined;
}
export type AwsEcsTaskDefinitionContainerDefinitionsList = AwsEcsTaskDefinitionContainerDefinitionsDetails[];
export interface AwsEcsTaskDefinitionInferenceAcceleratorsDetails {
    DeviceName?: string | undefined;
    DeviceType?: string | undefined;
}
export type AwsEcsTaskDefinitionInferenceAcceleratorsList = AwsEcsTaskDefinitionInferenceAcceleratorsDetails[];
export interface AwsEcsTaskDefinitionPlacementConstraintsDetails {
    Expression?: string | undefined;
    Type?: string | undefined;
}
export type AwsEcsTaskDefinitionPlacementConstraintsList = AwsEcsTaskDefinitionPlacementConstraintsDetails[];
export interface AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesDetails {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesList = AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesDetails[];
export interface AwsEcsTaskDefinitionProxyConfigurationDetails {
    ContainerName?: string | undefined;
    ProxyConfigurationProperties?: AwsEcsTaskDefinitionProxyConfigurationProxyConfigurationPropertiesDetails[] | undefined;
    Type?: string | undefined;
}
export interface AwsEcsTaskDefinitionVolumesDockerVolumeConfigurationDetails {
    Autoprovision?: boolean | undefined;
    Driver?: string | undefined;
    DriverOpts?: {
        [key: string]: string | undefined;
    } | undefined;
    Labels?: {
        [key: string]: string | undefined;
    } | undefined;
    Scope?: string | undefined;
}
export interface AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationAuthorizationConfigDetails {
    AccessPointId?: string | undefined;
    Iam?: string | undefined;
}
export interface AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationDetails {
    AuthorizationConfig?: AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationAuthorizationConfigDetails | undefined;
    FilesystemId?: string | undefined;
    RootDirectory?: string | undefined;
    TransitEncryption?: string | undefined;
    TransitEncryptionPort?: number | undefined;
}
export interface AwsEcsTaskDefinitionVolumesHostDetails {
    SourcePath?: string | undefined;
}
export interface AwsEcsTaskDefinitionVolumesDetails {
    DockerVolumeConfiguration?: AwsEcsTaskDefinitionVolumesDockerVolumeConfigurationDetails | undefined;
    EfsVolumeConfiguration?: AwsEcsTaskDefinitionVolumesEfsVolumeConfigurationDetails | undefined;
    Host?: AwsEcsTaskDefinitionVolumesHostDetails | undefined;
    Name?: string | undefined;
}
export type AwsEcsTaskDefinitionVolumesList = AwsEcsTaskDefinitionVolumesDetails[];
export interface AwsEcsTaskDefinitionDetails {
    ContainerDefinitions?: AwsEcsTaskDefinitionContainerDefinitionsDetails[] | undefined;
    Cpu?: string | undefined;
    ExecutionRoleArn?: string | undefined;
    Family?: string | undefined;
    InferenceAccelerators?: AwsEcsTaskDefinitionInferenceAcceleratorsDetails[] | undefined;
    IpcMode?: string | undefined;
    Memory?: string | undefined;
    NetworkMode?: string | undefined;
    PidMode?: string | undefined;
    PlacementConstraints?: AwsEcsTaskDefinitionPlacementConstraintsDetails[] | undefined;
    ProxyConfiguration?: AwsEcsTaskDefinitionProxyConfigurationDetails | undefined;
    RequiresCompatibilities?: string[] | undefined;
    TaskRoleArn?: string | undefined;
    Volumes?: AwsEcsTaskDefinitionVolumesDetails[] | undefined;
    Status?: string | undefined;
}
export interface VolumeMount {
    Name?: string | undefined;
    MountPath?: string | undefined;
}
export type VolumeMountList = VolumeMount[];
export interface ContainerDetails {
    ContainerRuntime?: string | undefined;
    Name?: string | undefined;
    ImageId?: string | undefined;
    ImageName?: string | undefined;
    LaunchedAt?: string | undefined;
    VolumeMounts?: VolumeMount[] | undefined;
    Privileged?: boolean | undefined;
}
export interface AwsRdsEventSubscriptionDetails {
    CustSubscriptionId?: string | undefined;
    CustomerAwsId?: string | undefined;
    Enabled?: boolean | undefined;
    EventCategoriesList?: string[] | undefined;
    EventSubscriptionArn?: string | undefined;
    SnsTopicArn?: string | undefined;
    SourceIdsList?: string[] | undefined;
    SourceType?: string | undefined;
    Status?: string | undefined;
    SubscriptionCreationTime?: string | undefined;
}
export interface AwsEcsServiceCapacityProviderStrategyDetails {
    Base?: number | undefined;
    CapacityProvider?: string | undefined;
    Weight?: number | undefined;
}
export type AwsEcsServiceCapacityProviderStrategyList = AwsEcsServiceCapacityProviderStrategyDetails[];
export interface AwsEcsServiceDeploymentConfigurationDeploymentCircuitBreakerDetails {
    Enable?: boolean | undefined;
    Rollback?: boolean | undefined;
}
export interface AwsEcsServiceDeploymentConfigurationDetails {
    DeploymentCircuitBreaker?: AwsEcsServiceDeploymentConfigurationDeploymentCircuitBreakerDetails | undefined;
    MaximumPercent?: number | undefined;
    MinimumHealthyPercent?: number | undefined;
}
export interface AwsEcsServiceDeploymentControllerDetails {
    Type?: string | undefined;
}
export interface AwsEcsServiceLoadBalancersDetails {
    ContainerName?: string | undefined;
    ContainerPort?: number | undefined;
    LoadBalancerName?: string | undefined;
    TargetGroupArn?: string | undefined;
}
export type AwsEcsServiceLoadBalancersList = AwsEcsServiceLoadBalancersDetails[];
export interface AwsEcsServiceNetworkConfigurationAwsVpcConfigurationDetails {
    AssignPublicIp?: string | undefined;
    SecurityGroups?: string[] | undefined;
    Subnets?: string[] | undefined;
}
export interface AwsEcsServiceNetworkConfigurationDetails {
    AwsVpcConfiguration?: AwsEcsServiceNetworkConfigurationAwsVpcConfigurationDetails | undefined;
}
export interface AwsEcsServicePlacementConstraintsDetails {
    Expression?: string | undefined;
    Type?: string | undefined;
}
export type AwsEcsServicePlacementConstraintsList = AwsEcsServicePlacementConstraintsDetails[];
export interface AwsEcsServicePlacementStrategiesDetails {
    Field?: string | undefined;
    Type?: string | undefined;
}
export type AwsEcsServicePlacementStrategiesList = AwsEcsServicePlacementStrategiesDetails[];
export interface AwsEcsServiceServiceRegistriesDetails {
    ContainerName?: string | undefined;
    ContainerPort?: number | undefined;
    Port?: number | undefined;
    RegistryArn?: string | undefined;
}
export type AwsEcsServiceServiceRegistriesList = AwsEcsServiceServiceRegistriesDetails[];
export interface AwsEcsServiceDetails {
    CapacityProviderStrategy?: AwsEcsServiceCapacityProviderStrategyDetails[] | undefined;
    Cluster?: string | undefined;
    DeploymentConfiguration?: AwsEcsServiceDeploymentConfigurationDetails | undefined;
    DeploymentController?: AwsEcsServiceDeploymentControllerDetails | undefined;
    DesiredCount?: number | undefined;
    EnableEcsManagedTags?: boolean | undefined;
    EnableExecuteCommand?: boolean | undefined;
    HealthCheckGracePeriodSeconds?: number | undefined;
    LaunchType?: string | undefined;
    LoadBalancers?: AwsEcsServiceLoadBalancersDetails[] | undefined;
    Name?: string | undefined;
    NetworkConfiguration?: AwsEcsServiceNetworkConfigurationDetails | undefined;
    PlacementConstraints?: AwsEcsServicePlacementConstraintsDetails[] | undefined;
    PlacementStrategies?: AwsEcsServicePlacementStrategiesDetails[] | undefined;
    PlatformVersion?: string | undefined;
    PropagateTags?: string | undefined;
    Role?: string | undefined;
    SchedulingStrategy?: string | undefined;
    ServiceArn?: string | undefined;
    ServiceName?: string | undefined;
    ServiceRegistries?: AwsEcsServiceServiceRegistriesDetails[] | undefined;
    TaskDefinition?: string | undefined;
}
export interface AwsAutoScalingLaunchConfigurationBlockDeviceMappingsEbsDetails {
    DeleteOnTermination?: boolean | undefined;
    Encrypted?: boolean | undefined;
    Iops?: number | undefined;
    SnapshotId?: string | undefined;
    VolumeSize?: number | undefined;
    VolumeType?: string | undefined;
}
export interface AwsAutoScalingLaunchConfigurationBlockDeviceMappingsDetails {
    DeviceName?: string | undefined;
    Ebs?: AwsAutoScalingLaunchConfigurationBlockDeviceMappingsEbsDetails | undefined;
    NoDevice?: boolean | undefined;
    VirtualName?: string | undefined;
}
export type AwsAutoScalingLaunchConfigurationBlockDeviceMappingsList = AwsAutoScalingLaunchConfigurationBlockDeviceMappingsDetails[];
export interface AwsAutoScalingLaunchConfigurationInstanceMonitoringDetails {
    Enabled?: boolean | undefined;
}
export interface AwsAutoScalingLaunchConfigurationMetadataOptions {
    HttpEndpoint?: string | undefined;
    HttpPutResponseHopLimit?: number | undefined;
    HttpTokens?: string | undefined;
}
export interface AwsAutoScalingLaunchConfigurationDetails {
    AssociatePublicIpAddress?: boolean | undefined;
    BlockDeviceMappings?: AwsAutoScalingLaunchConfigurationBlockDeviceMappingsDetails[] | undefined;
    ClassicLinkVpcId?: string | undefined;
    ClassicLinkVpcSecurityGroups?: string[] | undefined;
    CreatedTime?: string | undefined;
    EbsOptimized?: boolean | undefined;
    IamInstanceProfile?: string | undefined;
    ImageId?: string | undefined;
    InstanceMonitoring?: AwsAutoScalingLaunchConfigurationInstanceMonitoringDetails | undefined;
    InstanceType?: string | undefined;
    KernelId?: string | undefined;
    KeyName?: string | undefined;
    LaunchConfigurationName?: string | undefined;
    PlacementTenancy?: string | undefined;
    RamdiskId?: string | undefined;
    SecurityGroups?: string[] | undefined;
    SpotPrice?: string | undefined;
    UserData?: string | undefined;
    MetadataOptions?: AwsAutoScalingLaunchConfigurationMetadataOptions | undefined;
}
export interface AwsEc2VpnConnectionVgwTelemetryDetails {
    AcceptedRouteCount?: number | undefined;
    CertificateArn?: string | undefined;
    LastStatusChange?: string | undefined;
    OutsideIpAddress?: string | undefined;
    Status?: string | undefined;
    StatusMessage?: string | undefined;
}
export type AwsEc2VpnConnectionVgwTelemetryList = AwsEc2VpnConnectionVgwTelemetryDetails[];
export interface AwsEc2VpnConnectionOptionsTunnelOptionsDetails {
    DpdTimeoutSeconds?: number | undefined;
    IkeVersions?: string[] | undefined;
    OutsideIpAddress?: string | undefined;
    Phase1DhGroupNumbers?: number[] | undefined;
    Phase1EncryptionAlgorithms?: string[] | undefined;
    Phase1IntegrityAlgorithms?: string[] | undefined;
    Phase1LifetimeSeconds?: number | undefined;
    Phase2DhGroupNumbers?: number[] | undefined;
    Phase2EncryptionAlgorithms?: string[] | undefined;
    Phase2IntegrityAlgorithms?: string[] | undefined;
    Phase2LifetimeSeconds?: number | undefined;
    PreSharedKey?: string | undefined;
    RekeyFuzzPercentage?: number | undefined;
    RekeyMarginTimeSeconds?: number | undefined;
    ReplayWindowSize?: number | undefined;
    TunnelInsideCidr?: string | undefined;
}
export type AwsEc2VpnConnectionOptionsTunnelOptionsList = AwsEc2VpnConnectionOptionsTunnelOptionsDetails[];
export interface AwsEc2VpnConnectionOptionsDetails {
    StaticRoutesOnly?: boolean | undefined;
    TunnelOptions?: AwsEc2VpnConnectionOptionsTunnelOptionsDetails[] | undefined;
}
export interface AwsEc2VpnConnectionRoutesDetails {
    DestinationCidrBlock?: string | undefined;
    State?: string | undefined;
}
export type AwsEc2VpnConnectionRoutesList = AwsEc2VpnConnectionRoutesDetails[];
export interface AwsEc2VpnConnectionDetails {
    VpnConnectionId?: string | undefined;
    State?: string | undefined;
    CustomerGatewayId?: string | undefined;
    CustomerGatewayConfiguration?: string | undefined;
    Type?: string | undefined;
    VpnGatewayId?: string | undefined;
    Category?: string | undefined;
    VgwTelemetry?: AwsEc2VpnConnectionVgwTelemetryDetails[] | undefined;
    Options?: AwsEc2VpnConnectionOptionsDetails | undefined;
    Routes?: AwsEc2VpnConnectionRoutesDetails[] | undefined;
    TransitGatewayId?: string | undefined;
}
export interface AwsEcrContainerImageDetails {
    RegistryId?: string | undefined;
    RepositoryName?: string | undefined;
    Architecture?: string | undefined;
    ImageDigest?: string | undefined;
    ImageTags?: string[] | undefined;
    ImagePublishedAt?: string | undefined;
}
export interface AwsOpenSearchServiceDomainEncryptionAtRestOptionsDetails {
    Enabled?: boolean | undefined;
    KmsKeyId?: string | undefined;
}
export interface AwsOpenSearchServiceDomainNodeToNodeEncryptionOptionsDetails {
    Enabled?: boolean | undefined;
}
export interface AwsOpenSearchServiceDomainServiceSoftwareOptionsDetails {
    AutomatedUpdateDate?: string | undefined;
    Cancellable?: boolean | undefined;
    CurrentVersion?: string | undefined;
    Description?: string | undefined;
    NewVersion?: string | undefined;
    UpdateAvailable?: boolean | undefined;
    UpdateStatus?: string | undefined;
    OptionalDeployment?: boolean | undefined;
}
export interface AwsOpenSearchServiceDomainClusterConfigZoneAwarenessConfigDetails {
    AvailabilityZoneCount?: number | undefined;
}
export interface AwsOpenSearchServiceDomainClusterConfigDetails {
    InstanceCount?: number | undefined;
    WarmEnabled?: boolean | undefined;
    WarmCount?: number | undefined;
    DedicatedMasterEnabled?: boolean | undefined;
    ZoneAwarenessConfig?: AwsOpenSearchServiceDomainClusterConfigZoneAwarenessConfigDetails | undefined;
    DedicatedMasterCount?: number | undefined;
    InstanceType?: string | undefined;
    WarmType?: string | undefined;
    ZoneAwarenessEnabled?: boolean | undefined;
    DedicatedMasterType?: string | undefined;
}
export interface AwsOpenSearchServiceDomainDomainEndpointOptionsDetails {
    CustomEndpointCertificateArn?: string | undefined;
    CustomEndpointEnabled?: boolean | undefined;
    EnforceHTTPS?: boolean | undefined;
    CustomEndpoint?: string | undefined;
    TLSSecurityPolicy?: string | undefined;
}
export interface AwsOpenSearchServiceDomainVpcOptionsDetails {
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
}
export interface AwsOpenSearchServiceDomainLogPublishingOption {
    CloudWatchLogsLogGroupArn?: string | undefined;
    Enabled?: boolean | undefined;
}
export interface AwsOpenSearchServiceDomainLogPublishingOptionsDetails {
    IndexSlowLogs?: AwsOpenSearchServiceDomainLogPublishingOption | undefined;
    SearchSlowLogs?: AwsOpenSearchServiceDomainLogPublishingOption | undefined;
    AuditLogs?: AwsOpenSearchServiceDomainLogPublishingOption | undefined;
}
export interface AwsOpenSearchServiceDomainMasterUserOptionsDetails {
    MasterUserArn?: string | undefined;
    MasterUserName?: string | undefined;
    MasterUserPassword?: string | undefined;
}
export interface AwsOpenSearchServiceDomainAdvancedSecurityOptionsDetails {
    Enabled?: boolean | undefined;
    InternalUserDatabaseEnabled?: boolean | undefined;
    MasterUserOptions?: AwsOpenSearchServiceDomainMasterUserOptionsDetails | undefined;
}
export interface AwsOpenSearchServiceDomainDetails {
    Arn?: string | undefined;
    AccessPolicies?: string | undefined;
    DomainName?: string | undefined;
    Id?: string | undefined;
    DomainEndpoint?: string | undefined;
    EngineVersion?: string | undefined;
    EncryptionAtRestOptions?: AwsOpenSearchServiceDomainEncryptionAtRestOptionsDetails | undefined;
    NodeToNodeEncryptionOptions?: AwsOpenSearchServiceDomainNodeToNodeEncryptionOptionsDetails | undefined;
    ServiceSoftwareOptions?: AwsOpenSearchServiceDomainServiceSoftwareOptionsDetails | undefined;
    ClusterConfig?: AwsOpenSearchServiceDomainClusterConfigDetails | undefined;
    DomainEndpointOptions?: AwsOpenSearchServiceDomainDomainEndpointOptionsDetails | undefined;
    VpcOptions?: AwsOpenSearchServiceDomainVpcOptionsDetails | undefined;
    LogPublishingOptions?: AwsOpenSearchServiceDomainLogPublishingOptionsDetails | undefined;
    DomainEndpoints?: {
        [key: string]: string | undefined;
    } | undefined;
    AdvancedSecurityOptions?: AwsOpenSearchServiceDomainAdvancedSecurityOptionsDetails | undefined;
}
export interface AwsEc2VpcEndpointServiceServiceTypeDetails {
    ServiceType?: string | undefined;
}
export type AwsEc2VpcEndpointServiceServiceTypeList = AwsEc2VpcEndpointServiceServiceTypeDetails[];
export interface AwsEc2VpcEndpointServiceDetails {
    AcceptanceRequired?: boolean | undefined;
    AvailabilityZones?: string[] | undefined;
    BaseEndpointDnsNames?: string[] | undefined;
    ManagesVpcEndpoints?: boolean | undefined;
    GatewayLoadBalancerArns?: string[] | undefined;
    NetworkLoadBalancerArns?: string[] | undefined;
    PrivateDnsName?: string | undefined;
    ServiceId?: string | undefined;
    ServiceName?: string | undefined;
    ServiceState?: string | undefined;
    ServiceType?: AwsEc2VpcEndpointServiceServiceTypeDetails[] | undefined;
}
export interface AwsXrayEncryptionConfigDetails {
    KeyId?: string | undefined;
    Status?: string | undefined;
    Type?: string | undefined;
}
export interface AwsWafRateBasedRuleMatchPredicate {
    DataId?: string | undefined;
    Negated?: boolean | undefined;
    Type?: string | undefined;
}
export type AwsWafRateBasedRuleMatchPredicateList = AwsWafRateBasedRuleMatchPredicate[];
export interface AwsWafRateBasedRuleDetails {
    MetricName?: string | undefined;
    Name?: string | undefined;
    RateKey?: string | undefined;
    RateLimit?: number | undefined;
    RuleId?: string | undefined;
    MatchPredicates?: AwsWafRateBasedRuleMatchPredicate[] | undefined;
}
export interface AwsWafRegionalRateBasedRuleMatchPredicate {
    DataId?: string | undefined;
    Negated?: boolean | undefined;
    Type?: string | undefined;
}
export type AwsWafRegionalRateBasedRuleMatchPredicateList = AwsWafRegionalRateBasedRuleMatchPredicate[];
export interface AwsWafRegionalRateBasedRuleDetails {
    MetricName?: string | undefined;
    Name?: string | undefined;
    RateKey?: string | undefined;
    RateLimit?: number | undefined;
    RuleId?: string | undefined;
    MatchPredicates?: AwsWafRegionalRateBasedRuleMatchPredicate[] | undefined;
}
export interface AwsEcrRepositoryImageScanningConfigurationDetails {
    ScanOnPush?: boolean | undefined;
}
export interface AwsEcrRepositoryLifecyclePolicyDetails {
    LifecyclePolicyText?: string | undefined;
    RegistryId?: string | undefined;
}
export interface AwsEcrRepositoryDetails {
    Arn?: string | undefined;
    ImageScanningConfiguration?: AwsEcrRepositoryImageScanningConfigurationDetails | undefined;
    ImageTagMutability?: string | undefined;
    LifecyclePolicy?: AwsEcrRepositoryLifecyclePolicyDetails | undefined;
    RepositoryName?: string | undefined;
    RepositoryPolicyText?: string | undefined;
}
export interface AwsEksClusterResourcesVpcConfigDetails {
    SecurityGroupIds?: string[] | undefined;
    SubnetIds?: string[] | undefined;
    EndpointPublicAccess?: boolean | undefined;
}
export interface AwsEksClusterLoggingClusterLoggingDetails {
    Enabled?: boolean | undefined;
    Types?: string[] | undefined;
}
export type AwsEksClusterLoggingClusterLoggingList = AwsEksClusterLoggingClusterLoggingDetails[];
export interface AwsEksClusterLoggingDetails {
    ClusterLogging?: AwsEksClusterLoggingClusterLoggingDetails[] | undefined;
}
export interface AwsEksClusterDetails {
    Arn?: string | undefined;
    CertificateAuthorityData?: string | undefined;
    ClusterStatus?: string | undefined;
    Endpoint?: string | undefined;
    Name?: string | undefined;
    ResourcesVpcConfig?: AwsEksClusterResourcesVpcConfigDetails | undefined;
    RoleArn?: string | undefined;
    Version?: string | undefined;
    Logging?: AwsEksClusterLoggingDetails | undefined;
}
export interface FirewallPolicyStatefulRuleGroupReferencesDetails {
    ResourceArn?: string | undefined;
}
export type FirewallPolicyStatefulRuleGroupReferencesList = FirewallPolicyStatefulRuleGroupReferencesDetails[];
export interface StatelessCustomPublishMetricActionDimension {
    Value?: string | undefined;
}
export type StatelessCustomPublishMetricActionDimensionsList = StatelessCustomPublishMetricActionDimension[];
export interface StatelessCustomPublishMetricAction {
    Dimensions?: StatelessCustomPublishMetricActionDimension[] | undefined;
}
export interface StatelessCustomActionDefinition {
    PublishMetricAction?: StatelessCustomPublishMetricAction | undefined;
}
export interface FirewallPolicyStatelessCustomActionsDetails {
    ActionDefinition?: StatelessCustomActionDefinition | undefined;
    ActionName?: string | undefined;
}
export type FirewallPolicyStatelessCustomActionsList = FirewallPolicyStatelessCustomActionsDetails[];
export interface FirewallPolicyStatelessRuleGroupReferencesDetails {
    Priority?: number | undefined;
    ResourceArn?: string | undefined;
}
export type FirewallPolicyStatelessRuleGroupReferencesList = FirewallPolicyStatelessRuleGroupReferencesDetails[];
export interface FirewallPolicyDetails {
    StatefulRuleGroupReferences?: FirewallPolicyStatefulRuleGroupReferencesDetails[] | undefined;
    StatelessCustomActions?: FirewallPolicyStatelessCustomActionsDetails[] | undefined;
    StatelessDefaultActions?: string[] | undefined;
    StatelessFragmentDefaultActions?: string[] | undefined;
    StatelessRuleGroupReferences?: FirewallPolicyStatelessRuleGroupReferencesDetails[] | undefined;
}
export interface AwsNetworkFirewallFirewallPolicyDetails {
    FirewallPolicy?: FirewallPolicyDetails | undefined;
    FirewallPolicyArn?: string | undefined;
    FirewallPolicyId?: string | undefined;
    FirewallPolicyName?: string | undefined;
    Description?: string | undefined;
}
export interface AwsNetworkFirewallFirewallSubnetMappingsDetails {
    SubnetId?: string | undefined;
}
export type AwsNetworkFirewallFirewallSubnetMappingsList = AwsNetworkFirewallFirewallSubnetMappingsDetails[];
export interface AwsNetworkFirewallFirewallDetails {
    DeleteProtection?: boolean | undefined;
    Description?: string | undefined;
    FirewallArn?: string | undefined;
    FirewallId?: string | undefined;
    FirewallName?: string | undefined;
    FirewallPolicyArn?: string | undefined;
    FirewallPolicyChangeProtection?: boolean | undefined;
    SubnetChangeProtection?: boolean | undefined;
    SubnetMappings?: AwsNetworkFirewallFirewallSubnetMappingsDetails[] | undefined;
    VpcId?: string | undefined;
}
export interface RuleGroupVariablesIpSetsDetails {
    Definition?: string[] | undefined;
}
export interface RuleGroupVariablesPortSetsDetails {
    Definition?: string[] | undefined;
}
export interface RuleGroupVariables {
    IpSets?: RuleGroupVariablesIpSetsDetails | undefined;
    PortSets?: RuleGroupVariablesPortSetsDetails | undefined;
}
export interface RuleGroupSourceListDetails {
    GeneratedRulesType?: string | undefined;
    TargetTypes?: string[] | undefined;
    Targets?: string[] | undefined;
}
export interface RuleGroupSourceStatefulRulesHeaderDetails {
    Destination?: string | undefined;
    DestinationPort?: string | undefined;
    Direction?: string | undefined;
    Protocol?: string | undefined;
    Source?: string | undefined;
    SourcePort?: string | undefined;
}
export type RuleGroupSourceStatefulRulesRuleOptionsSettingsList = string[];
export interface RuleGroupSourceStatefulRulesOptionsDetails {
    Keyword?: string | undefined;
    Settings?: string[] | undefined;
}
export type RuleGroupSourceStatefulRulesOptionsList = RuleGroupSourceStatefulRulesOptionsDetails[];
export interface RuleGroupSourceStatefulRulesDetails {
    Action?: string | undefined;
    Header?: RuleGroupSourceStatefulRulesHeaderDetails | undefined;
    RuleOptions?: RuleGroupSourceStatefulRulesOptionsDetails[] | undefined;
}
export type RuleGroupSourceStatefulRulesList = RuleGroupSourceStatefulRulesDetails[];
export interface RuleGroupSourceCustomActionsDetails {
    ActionDefinition?: StatelessCustomActionDefinition | undefined;
    ActionName?: string | undefined;
}
export type RuleGroupSourceCustomActionsList = RuleGroupSourceCustomActionsDetails[];
export interface RuleGroupSourceStatelessRuleMatchAttributesDestinationPorts {
    FromPort?: number | undefined;
    ToPort?: number | undefined;
}
export type RuleGroupSourceStatelessRuleMatchAttributesDestinationPortsList = RuleGroupSourceStatelessRuleMatchAttributesDestinationPorts[];
export interface RuleGroupSourceStatelessRuleMatchAttributesDestinations {
    AddressDefinition?: string | undefined;
}
export type RuleGroupSourceStatelessRuleMatchAttributesDestinationsList = RuleGroupSourceStatelessRuleMatchAttributesDestinations[];
export type RuleGroupSourceStatelessRuleMatchAttributesProtocolsList = number[];
export interface RuleGroupSourceStatelessRuleMatchAttributesSourcePorts {
    FromPort?: number | undefined;
    ToPort?: number | undefined;
}
export type RuleGroupSourceStatelessRuleMatchAttributesSourcePortsList = RuleGroupSourceStatelessRuleMatchAttributesSourcePorts[];
export interface RuleGroupSourceStatelessRuleMatchAttributesSources {
    AddressDefinition?: string | undefined;
}
export type RuleGroupSourceStatelessRuleMatchAttributesSourcesList = RuleGroupSourceStatelessRuleMatchAttributesSources[];
export interface RuleGroupSourceStatelessRuleMatchAttributesTcpFlags {
    Flags?: string[] | undefined;
    Masks?: string[] | undefined;
}
export type RuleGroupSourceStatelessRuleMatchAttributesTcpFlagsList = RuleGroupSourceStatelessRuleMatchAttributesTcpFlags[];
export interface RuleGroupSourceStatelessRuleMatchAttributes {
    DestinationPorts?: RuleGroupSourceStatelessRuleMatchAttributesDestinationPorts[] | undefined;
    Destinations?: RuleGroupSourceStatelessRuleMatchAttributesDestinations[] | undefined;
    Protocols?: number[] | undefined;
    SourcePorts?: RuleGroupSourceStatelessRuleMatchAttributesSourcePorts[] | undefined;
    Sources?: RuleGroupSourceStatelessRuleMatchAttributesSources[] | undefined;
    TcpFlags?: RuleGroupSourceStatelessRuleMatchAttributesTcpFlags[] | undefined;
}
export interface RuleGroupSourceStatelessRuleDefinition {
    Actions?: string[] | undefined;
    MatchAttributes?: RuleGroupSourceStatelessRuleMatchAttributes | undefined;
}
export interface RuleGroupSourceStatelessRulesDetails {
    Priority?: number | undefined;
    RuleDefinition?: RuleGroupSourceStatelessRuleDefinition | undefined;
}
export type RuleGroupSourceStatelessRulesList = RuleGroupSourceStatelessRulesDetails[];
export interface RuleGroupSourceStatelessRulesAndCustomActionsDetails {
    CustomActions?: RuleGroupSourceCustomActionsDetails[] | undefined;
    StatelessRules?: RuleGroupSourceStatelessRulesDetails[] | undefined;
}
export interface RuleGroupSource {
    RulesSourceList?: RuleGroupSourceListDetails | undefined;
    RulesString?: string | undefined;
    StatefulRules?: RuleGroupSourceStatefulRulesDetails[] | undefined;
    StatelessRulesAndCustomActions?: RuleGroupSourceStatelessRulesAndCustomActionsDetails | undefined;
}
export interface RuleGroupDetails {
    RuleVariables?: RuleGroupVariables | undefined;
    RulesSource?: RuleGroupSource | undefined;
}
export interface AwsNetworkFirewallRuleGroupDetails {
    Capacity?: number | undefined;
    Description?: string | undefined;
    RuleGroup?: RuleGroupDetails | undefined;
    RuleGroupArn?: string | undefined;
    RuleGroupId?: string | undefined;
    RuleGroupName?: string | undefined;
    Type?: string | undefined;
}
export interface AwsRdsDbSecurityGroupEc2SecurityGroup {
    Ec2SecurityGroupId?: string | undefined;
    Ec2SecurityGroupName?: string | undefined;
    Ec2SecurityGroupOwnerId?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbSecurityGroupEc2SecurityGroups = AwsRdsDbSecurityGroupEc2SecurityGroup[];
export interface AwsRdsDbSecurityGroupIpRange {
    CidrIp?: string | undefined;
    Status?: string | undefined;
}
export type AwsRdsDbSecurityGroupIpRanges = AwsRdsDbSecurityGroupIpRange[];
export interface AwsRdsDbSecurityGroupDetails {
    DbSecurityGroupArn?: string | undefined;
    DbSecurityGroupDescription?: string | undefined;
    DbSecurityGroupName?: string | undefined;
    Ec2SecurityGroups?: AwsRdsDbSecurityGroupEc2SecurityGroup[] | undefined;
    IpRanges?: AwsRdsDbSecurityGroupIpRange[] | undefined;
    OwnerId?: string | undefined;
    VpcId?: string | undefined;
}
export interface AwsKinesisStreamStreamEncryptionDetails {
    EncryptionType?: string | undefined;
    KeyId?: string | undefined;
}
export interface AwsKinesisStreamDetails {
    Name?: string | undefined;
    Arn?: string | undefined;
    StreamEncryption?: AwsKinesisStreamStreamEncryptionDetails | undefined;
    ShardCount?: number | undefined;
    RetentionPeriodHours?: number | undefined;
}
export interface AwsEc2TransitGatewayDetails {
    Id?: string | undefined;
    Description?: string | undefined;
    DefaultRouteTablePropagation?: string | undefined;
    AutoAcceptSharedAttachments?: string | undefined;
    DefaultRouteTableAssociation?: string | undefined;
    TransitGatewayCidrBlocks?: string[] | undefined;
    AssociationDefaultRouteTableId?: string | undefined;
    PropagationDefaultRouteTableId?: string | undefined;
    VpnEcmpSupport?: string | undefined;
    DnsSupport?: string | undefined;
    MulticastSupport?: string | undefined;
    AmazonSideAsn?: number | undefined;
}
export interface AwsEfsAccessPointPosixUserDetails {
    Gid?: string | undefined;
    SecondaryGids?: string[] | undefined;
    Uid?: string | undefined;
}
export interface AwsEfsAccessPointRootDirectoryCreationInfoDetails {
    OwnerGid?: string | undefined;
    OwnerUid?: string | undefined;
    Permissions?: string | undefined;
}
export interface AwsEfsAccessPointRootDirectoryDetails {
    CreationInfo?: AwsEfsAccessPointRootDirectoryCreationInfoDetails | undefined;
    Path?: string | undefined;
}
export interface AwsEfsAccessPointDetails {
    AccessPointId?: string | undefined;
    Arn?: string | undefined;
    ClientToken?: string | undefined;
    FileSystemId?: string | undefined;
    PosixUser?: AwsEfsAccessPointPosixUserDetails | undefined;
    RootDirectory?: AwsEfsAccessPointRootDirectoryDetails | undefined;
}
export interface AwsCloudFormationStackDriftInformationDetails {
    StackDriftStatus?: string | undefined;
}
export interface AwsCloudFormationStackOutputsDetails {
    Description?: string | undefined;
    OutputKey?: string | undefined;
    OutputValue?: string | undefined;
}
export type AwsCloudFormationStackOutputsList = AwsCloudFormationStackOutputsDetails[];
export interface AwsCloudFormationStackDetails {
    Capabilities?: string[] | undefined;
    CreationTime?: string | undefined;
    Description?: string | undefined;
    DisableRollback?: boolean | undefined;
    DriftInformation?: AwsCloudFormationStackDriftInformationDetails | undefined;
    EnableTerminationProtection?: boolean | undefined;
    LastUpdatedTime?: string | undefined;
    NotificationArns?: string[] | undefined;
    Outputs?: AwsCloudFormationStackOutputsDetails[] | undefined;
    RoleArn?: string | undefined;
    StackId?: string | undefined;
    StackName?: string | undefined;
    StackStatus?: string | undefined;
    StackStatusReason?: string | undefined;
    TimeoutInMinutes?: number | undefined;
}
export interface AwsCloudWatchAlarmDimensionsDetails {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type AwsCloudWatchAlarmDimensionsList = AwsCloudWatchAlarmDimensionsDetails[];
export interface AwsCloudWatchAlarmDetails {
    ActionsEnabled?: boolean | undefined;
    AlarmActions?: string[] | undefined;
    AlarmArn?: string | undefined;
    AlarmConfigurationUpdatedTimestamp?: string | undefined;
    AlarmDescription?: string | undefined;
    AlarmName?: string | undefined;
    ComparisonOperator?: string | undefined;
    DatapointsToAlarm?: number | undefined;
    Dimensions?: AwsCloudWatchAlarmDimensionsDetails[] | undefined;
    EvaluateLowSampleCountPercentile?: string | undefined;
    EvaluationPeriods?: number | undefined;
    ExtendedStatistic?: string | undefined;
    InsufficientDataActions?: string[] | undefined;
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    OkActions?: string[] | undefined;
    Period?: number | undefined;
    Statistic?: string | undefined;
    Threshold?: number | undefined;
    ThresholdMetricId?: string | undefined;
    TreatMissingData?: string | undefined;
    Unit?: string | undefined;
}
export interface VpcInfoCidrBlockSetDetails {
    CidrBlock?: string | undefined;
}
export type VpcInfoCidrBlockSetList = VpcInfoCidrBlockSetDetails[];
export interface VpcInfoIpv6CidrBlockSetDetails {
    Ipv6CidrBlock?: string | undefined;
}
export type VpcInfoIpv6CidrBlockSetList = VpcInfoIpv6CidrBlockSetDetails[];
export interface VpcInfoPeeringOptionsDetails {
    AllowDnsResolutionFromRemoteVpc?: boolean | undefined;
    AllowEgressFromLocalClassicLinkToRemoteVpc?: boolean | undefined;
    AllowEgressFromLocalVpcToRemoteClassicLink?: boolean | undefined;
}
export interface AwsEc2VpcPeeringConnectionVpcInfoDetails {
    CidrBlock?: string | undefined;
    CidrBlockSet?: VpcInfoCidrBlockSetDetails[] | undefined;
    Ipv6CidrBlockSet?: VpcInfoIpv6CidrBlockSetDetails[] | undefined;
    OwnerId?: string | undefined;
    PeeringOptions?: VpcInfoPeeringOptionsDetails | undefined;
    Region?: string | undefined;
    VpcId?: string | undefined;
}
export interface AwsEc2VpcPeeringConnectionStatusDetails {
    Code?: string | undefined;
    Message?: string | undefined;
}
export interface AwsEc2VpcPeeringConnectionDetails {
    AccepterVpcInfo?: AwsEc2VpcPeeringConnectionVpcInfoDetails | undefined;
    ExpirationTime?: string | undefined;
    RequesterVpcInfo?: AwsEc2VpcPeeringConnectionVpcInfoDetails | undefined;
    Status?: AwsEc2VpcPeeringConnectionStatusDetails | undefined;
    VpcPeeringConnectionId?: string | undefined;
}
export interface AwsWafRegionalRuleGroupRulesActionDetails {
    Type?: string | undefined;
}
export interface AwsWafRegionalRuleGroupRulesDetails {
    Action?: AwsWafRegionalRuleGroupRulesActionDetails | undefined;
    Priority?: number | undefined;
    RuleId?: string | undefined;
    Type?: string | undefined;
}
export type AwsWafRegionalRuleGroupRulesList = AwsWafRegionalRuleGroupRulesDetails[];
export interface AwsWafRegionalRuleGroupDetails {
    MetricName?: string | undefined;
    Name?: string | undefined;
    RuleGroupId?: string | undefined;
    Rules?: AwsWafRegionalRuleGroupRulesDetails[] | undefined;
}
export interface AwsWafRegionalRulePredicateListDetails {
    DataId?: string | undefined;
    Negated?: boolean | undefined;
    Type?: string | undefined;
}
export type AwsWafRegionalRulePredicateList = AwsWafRegionalRulePredicateListDetails[];
export interface AwsWafRegionalRuleDetails {
    MetricName?: string | undefined;
    Name?: string | undefined;
    PredicateList?: AwsWafRegionalRulePredicateListDetails[] | undefined;
    RuleId?: string | undefined;
}
export interface AwsWafRegionalWebAclRulesListActionDetails {
    Type?: string | undefined;
}
export interface AwsWafRegionalWebAclRulesListOverrideActionDetails {
    Type?: string | undefined;
}
export interface AwsWafRegionalWebAclRulesListDetails {
    Action?: AwsWafRegionalWebAclRulesListActionDetails | undefined;
    OverrideAction?: AwsWafRegionalWebAclRulesListOverrideActionDetails | undefined;
    Priority?: number | undefined;
    RuleId?: string | undefined;
    Type?: string | undefined;
}
export type AwsWafRegionalWebAclRulesList = AwsWafRegionalWebAclRulesListDetails[];
export interface AwsWafRegionalWebAclDetails {
    DefaultAction?: string | undefined;
    MetricName?: string | undefined;
    Name?: string | undefined;
    RulesList?: AwsWafRegionalWebAclRulesListDetails[] | undefined;
    WebAclId?: string | undefined;
}
export interface AwsWafRulePredicateListDetails {
    DataId?: string | undefined;
    Negated?: boolean | undefined;
    Type?: string | undefined;
}
export type AwsWafRulePredicateList = AwsWafRulePredicateListDetails[];
export interface AwsWafRuleDetails {
    MetricName?: string | undefined;
    Name?: string | undefined;
    PredicateList?: AwsWafRulePredicateListDetails[] | undefined;
    RuleId?: string | undefined;
}
export interface AwsWafRuleGroupRulesActionDetails {
    Type?: string | undefined;
}
export interface AwsWafRuleGroupRulesDetails {
    Action?: AwsWafRuleGroupRulesActionDetails | undefined;
    Priority?: number | undefined;
    RuleId?: string | undefined;
    Type?: string | undefined;
}
export type AwsWafRuleGroupRulesList = AwsWafRuleGroupRulesDetails[];
export interface AwsWafRuleGroupDetails {
    MetricName?: string | undefined;
    Name?: string | undefined;
    RuleGroupId?: string | undefined;
    Rules?: AwsWafRuleGroupRulesDetails[] | undefined;
}
export interface AwsEcsTaskVolumeHostDetails {
    SourcePath?: string | undefined;
}
export interface AwsEcsTaskVolumeDetails {
    Name?: string | undefined;
    Host?: AwsEcsTaskVolumeHostDetails | undefined;
}
export type AwsEcsTaskVolumeDetailsList = AwsEcsTaskVolumeDetails[];
export type AwsEcsContainerDetailsList = AwsEcsContainerDetails[];
export interface AwsEcsTaskDetails {
    ClusterArn?: string | undefined;
    TaskDefinitionArn?: string | undefined;
    Version?: string | undefined;
    CreatedAt?: string | undefined;
    StartedAt?: string | undefined;
    StartedBy?: string | undefined;
    Group?: string | undefined;
    Volumes?: AwsEcsTaskVolumeDetails[] | undefined;
    Containers?: AwsEcsContainerDetails[] | undefined;
}
export interface AwsBackupBackupVaultNotificationsDetails {
    BackupVaultEvents?: string[] | undefined;
    SnsTopicArn?: string | undefined;
}
export interface AwsBackupBackupVaultDetails {
    BackupVaultArn?: string | undefined;
    BackupVaultName?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    Notifications?: AwsBackupBackupVaultNotificationsDetails | undefined;
    AccessPolicy?: string | undefined;
}
export interface AwsBackupBackupPlanAdvancedBackupSettingsDetails {
    BackupOptions?: {
        [key: string]: string | undefined;
    } | undefined;
    ResourceType?: string | undefined;
}
export type AwsBackupBackupPlanAdvancedBackupSettingsList = AwsBackupBackupPlanAdvancedBackupSettingsDetails[];
export interface AwsBackupBackupPlanLifecycleDetails {
    DeleteAfterDays?: number | undefined;
    MoveToColdStorageAfterDays?: number | undefined;
}
export interface AwsBackupBackupPlanRuleCopyActionsDetails {
    DestinationBackupVaultArn?: string | undefined;
    Lifecycle?: AwsBackupBackupPlanLifecycleDetails | undefined;
}
export type AwsBackupBackupPlanRuleCopyActionsList = AwsBackupBackupPlanRuleCopyActionsDetails[];
export interface AwsBackupBackupPlanRuleDetails {
    TargetBackupVault?: string | undefined;
    StartWindowMinutes?: number | undefined;
    ScheduleExpression?: string | undefined;
    RuleName?: string | undefined;
    RuleId?: string | undefined;
    EnableContinuousBackup?: boolean | undefined;
    CompletionWindowMinutes?: number | undefined;
    CopyActions?: AwsBackupBackupPlanRuleCopyActionsDetails[] | undefined;
    Lifecycle?: AwsBackupBackupPlanLifecycleDetails | undefined;
}
export type AwsBackupBackupPlanRuleList = AwsBackupBackupPlanRuleDetails[];
export interface AwsBackupBackupPlanBackupPlanDetails {
    BackupPlanName?: string | undefined;
    AdvancedBackupSettings?: AwsBackupBackupPlanAdvancedBackupSettingsDetails[] | undefined;
    BackupPlanRule?: AwsBackupBackupPlanRuleDetails[] | undefined;
}
export interface AwsBackupBackupPlanDetails {
    BackupPlan?: AwsBackupBackupPlanBackupPlanDetails | undefined;
    BackupPlanArn?: string | undefined;
    BackupPlanId?: string | undefined;
    VersionId?: string | undefined;
}
export interface AwsBackupRecoveryPointCalculatedLifecycleDetails {
    DeleteAt?: string | undefined;
    MoveToColdStorageAt?: string | undefined;
}
export interface AwsBackupRecoveryPointCreatedByDetails {
    BackupPlanArn?: string | undefined;
    BackupPlanId?: string | undefined;
    BackupPlanVersion?: string | undefined;
    BackupRuleId?: string | undefined;
}
export interface AwsBackupRecoveryPointLifecycleDetails {
    DeleteAfterDays?: number | undefined;
    MoveToColdStorageAfterDays?: number | undefined;
}
export interface AwsBackupRecoveryPointDetails {
    BackupSizeInBytes?: number | undefined;
    BackupVaultArn?: string | undefined;
    BackupVaultName?: string | undefined;
    CalculatedLifecycle?: AwsBackupRecoveryPointCalculatedLifecycleDetails | undefined;
    CompletionDate?: string | undefined;
    CreatedBy?: AwsBackupRecoveryPointCreatedByDetails | undefined;
    CreationDate?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    IamRoleArn?: string | undefined;
    IsEncrypted?: boolean | undefined;
    LastRestoreTime?: string | undefined;
    Lifecycle?: AwsBackupRecoveryPointLifecycleDetails | undefined;
    RecoveryPointArn?: string | undefined;
    ResourceArn?: string | undefined;
    ResourceType?: string | undefined;
    SourceBackupVaultArn?: string | undefined;
    Status?: string | undefined;
    StatusMessage?: string | undefined;
    StorageClass?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataBlockDeviceMappingSetEbsDetails {
    DeleteOnTermination?: boolean | undefined;
    Encrypted?: boolean | undefined;
    Iops?: number | undefined;
    KmsKeyId?: string | undefined;
    SnapshotId?: string | undefined;
    Throughput?: number | undefined;
    VolumeSize?: number | undefined;
    VolumeType?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataBlockDeviceMappingSetDetails {
    DeviceName?: string | undefined;
    Ebs?: AwsEc2LaunchTemplateDataBlockDeviceMappingSetEbsDetails | undefined;
    NoDevice?: string | undefined;
    VirtualName?: string | undefined;
}
export type AwsEc2LaunchTemplateDataBlockDeviceMappingSetList = AwsEc2LaunchTemplateDataBlockDeviceMappingSetDetails[];
export interface AwsEc2LaunchTemplateDataCapacityReservationSpecificationCapacityReservationTargetDetails {
    CapacityReservationId?: string | undefined;
    CapacityReservationResourceGroupArn?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataCapacityReservationSpecificationDetails {
    CapacityReservationPreference?: string | undefined;
    CapacityReservationTarget?: AwsEc2LaunchTemplateDataCapacityReservationSpecificationCapacityReservationTargetDetails | undefined;
}
export interface AwsEc2LaunchTemplateDataCpuOptionsDetails {
    CoreCount?: number | undefined;
    ThreadsPerCore?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataCreditSpecificationDetails {
    CpuCredits?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataElasticGpuSpecificationSetDetails {
    Type?: string | undefined;
}
export type AwsEc2LaunchTemplateDataElasticGpuSpecificationSetList = AwsEc2LaunchTemplateDataElasticGpuSpecificationSetDetails[];
export interface AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetDetails {
    Count?: number | undefined;
    Type?: string | undefined;
}
export type AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetList = AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetDetails[];
export interface AwsEc2LaunchTemplateDataEnclaveOptionsDetails {
    Enabled?: boolean | undefined;
}
export interface AwsEc2LaunchTemplateDataHibernationOptionsDetails {
    Configured?: boolean | undefined;
}
export interface AwsEc2LaunchTemplateDataIamInstanceProfileDetails {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceMarketOptionsSpotOptionsDetails {
    BlockDurationMinutes?: number | undefined;
    InstanceInterruptionBehavior?: string | undefined;
    MaxPrice?: string | undefined;
    SpotInstanceType?: string | undefined;
    ValidUntil?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceMarketOptionsDetails {
    MarketType?: string | undefined;
    SpotOptions?: AwsEc2LaunchTemplateDataInstanceMarketOptionsSpotOptionsDetails | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorCountDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorTotalMemoryMiBDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsBaselineEbsBandwidthMbpsDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsMemoryGiBPerVCpuDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsMemoryMiBDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsNetworkInterfaceCountDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsTotalLocalStorageGBDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsVCpuCountDetails {
    Max?: number | undefined;
    Min?: number | undefined;
}
export interface AwsEc2LaunchTemplateDataInstanceRequirementsDetails {
    AcceleratorCount?: AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorCountDetails | undefined;
    AcceleratorManufacturers?: string[] | undefined;
    AcceleratorNames?: string[] | undefined;
    AcceleratorTotalMemoryMiB?: AwsEc2LaunchTemplateDataInstanceRequirementsAcceleratorTotalMemoryMiBDetails | undefined;
    AcceleratorTypes?: string[] | undefined;
    BareMetal?: string | undefined;
    BaselineEbsBandwidthMbps?: AwsEc2LaunchTemplateDataInstanceRequirementsBaselineEbsBandwidthMbpsDetails | undefined;
    BurstablePerformance?: string | undefined;
    CpuManufacturers?: string[] | undefined;
    ExcludedInstanceTypes?: string[] | undefined;
    InstanceGenerations?: string[] | undefined;
    LocalStorage?: string | undefined;
    LocalStorageTypes?: string[] | undefined;
    MemoryGiBPerVCpu?: AwsEc2LaunchTemplateDataInstanceRequirementsMemoryGiBPerVCpuDetails | undefined;
    MemoryMiB?: AwsEc2LaunchTemplateDataInstanceRequirementsMemoryMiBDetails | undefined;
    NetworkInterfaceCount?: AwsEc2LaunchTemplateDataInstanceRequirementsNetworkInterfaceCountDetails | undefined;
    OnDemandMaxPricePercentageOverLowestPrice?: number | undefined;
    RequireHibernateSupport?: boolean | undefined;
    SpotMaxPricePercentageOverLowestPrice?: number | undefined;
    TotalLocalStorageGB?: AwsEc2LaunchTemplateDataInstanceRequirementsTotalLocalStorageGBDetails | undefined;
    VCpuCount?: AwsEc2LaunchTemplateDataInstanceRequirementsVCpuCountDetails | undefined;
}
export interface AwsEc2LaunchTemplateDataLicenseSetDetails {
    LicenseConfigurationArn?: string | undefined;
}
export type AwsEc2LaunchTemplateDataLicenseSetList = AwsEc2LaunchTemplateDataLicenseSetDetails[];
export interface AwsEc2LaunchTemplateDataMaintenanceOptionsDetails {
    AutoRecovery?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataMetadataOptionsDetails {
    HttpEndpoint?: string | undefined;
    HttpProtocolIpv6?: string | undefined;
    HttpTokens?: string | undefined;
    HttpPutResponseHopLimit?: number | undefined;
    InstanceMetadataTags?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataMonitoringDetails {
    Enabled?: boolean | undefined;
}
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesDetails {
    Ipv4Prefix?: string | undefined;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesDetails {
    Ipv6Address?: string | undefined;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesDetails {
    Ipv6Prefix?: string | undefined;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesDetails {
    Primary?: boolean | undefined;
    PrivateIpAddress?: string | undefined;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesList = AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesDetails[];
export interface AwsEc2LaunchTemplateDataNetworkInterfaceSetDetails {
    AssociateCarrierIpAddress?: boolean | undefined;
    AssociatePublicIpAddress?: boolean | undefined;
    DeleteOnTermination?: boolean | undefined;
    Description?: string | undefined;
    DeviceIndex?: number | undefined;
    Groups?: string[] | undefined;
    InterfaceType?: string | undefined;
    Ipv4PrefixCount?: number | undefined;
    Ipv4Prefixes?: AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv4PrefixesDetails[] | undefined;
    Ipv6AddressCount?: number | undefined;
    Ipv6Addresses?: AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6AddressesDetails[] | undefined;
    Ipv6PrefixCount?: number | undefined;
    Ipv6Prefixes?: AwsEc2LaunchTemplateDataNetworkInterfaceSetIpv6PrefixesDetails[] | undefined;
    NetworkCardIndex?: number | undefined;
    NetworkInterfaceId?: string | undefined;
    PrivateIpAddress?: string | undefined;
    PrivateIpAddresses?: AwsEc2LaunchTemplateDataNetworkInterfaceSetPrivateIpAddressesDetails[] | undefined;
    SecondaryPrivateIpAddressCount?: number | undefined;
    SubnetId?: string | undefined;
}
export type AwsEc2LaunchTemplateDataNetworkInterfaceSetList = AwsEc2LaunchTemplateDataNetworkInterfaceSetDetails[];
export interface AwsEc2LaunchTemplateDataPlacementDetails {
    Affinity?: string | undefined;
    AvailabilityZone?: string | undefined;
    GroupName?: string | undefined;
    HostId?: string | undefined;
    HostResourceGroupArn?: string | undefined;
    PartitionNumber?: number | undefined;
    SpreadDomain?: string | undefined;
    Tenancy?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataPrivateDnsNameOptionsDetails {
    EnableResourceNameDnsAAAARecord?: boolean | undefined;
    EnableResourceNameDnsARecord?: boolean | undefined;
    HostnameType?: string | undefined;
}
export interface AwsEc2LaunchTemplateDataDetails {
    BlockDeviceMappingSet?: AwsEc2LaunchTemplateDataBlockDeviceMappingSetDetails[] | undefined;
    CapacityReservationSpecification?: AwsEc2LaunchTemplateDataCapacityReservationSpecificationDetails | undefined;
    CpuOptions?: AwsEc2LaunchTemplateDataCpuOptionsDetails | undefined;
    CreditSpecification?: AwsEc2LaunchTemplateDataCreditSpecificationDetails | undefined;
    DisableApiStop?: boolean | undefined;
    DisableApiTermination?: boolean | undefined;
    EbsOptimized?: boolean | undefined;
    ElasticGpuSpecificationSet?: AwsEc2LaunchTemplateDataElasticGpuSpecificationSetDetails[] | undefined;
    ElasticInferenceAcceleratorSet?: AwsEc2LaunchTemplateDataElasticInferenceAcceleratorSetDetails[] | undefined;
    EnclaveOptions?: AwsEc2LaunchTemplateDataEnclaveOptionsDetails | undefined;
    HibernationOptions?: AwsEc2LaunchTemplateDataHibernationOptionsDetails | undefined;
    IamInstanceProfile?: AwsEc2LaunchTemplateDataIamInstanceProfileDetails | undefined;
    ImageId?: string | undefined;
    InstanceInitiatedShutdownBehavior?: string | undefined;
    InstanceMarketOptions?: AwsEc2LaunchTemplateDataInstanceMarketOptionsDetails | undefined;
    InstanceRequirements?: AwsEc2LaunchTemplateDataInstanceRequirementsDetails | undefined;
    InstanceType?: string | undefined;
    KernelId?: string | undefined;
    KeyName?: string | undefined;
    LicenseSet?: AwsEc2LaunchTemplateDataLicenseSetDetails[] | undefined;
    MaintenanceOptions?: AwsEc2LaunchTemplateDataMaintenanceOptionsDetails | undefined;
    MetadataOptions?: AwsEc2LaunchTemplateDataMetadataOptionsDetails | undefined;
    Monitoring?: AwsEc2LaunchTemplateDataMonitoringDetails | undefined;
    NetworkInterfaceSet?: AwsEc2LaunchTemplateDataNetworkInterfaceSetDetails[] | undefined;
    Placement?: AwsEc2LaunchTemplateDataPlacementDetails | undefined;
    PrivateDnsNameOptions?: AwsEc2LaunchTemplateDataPrivateDnsNameOptionsDetails | undefined;
    RamDiskId?: string | undefined;
    SecurityGroupIdSet?: string[] | undefined;
    SecurityGroupSet?: string[] | undefined;
    UserData?: string | undefined;
}
export interface AwsEc2LaunchTemplateDetails {
    LaunchTemplateName?: string | undefined;
    Id?: string | undefined;
    LaunchTemplateData?: AwsEc2LaunchTemplateDataDetails | undefined;
    DefaultVersionNumber?: number | undefined;
    LatestVersionNumber?: number | undefined;
}
export interface AwsSageMakerNotebookInstanceMetadataServiceConfigurationDetails {
    MinimumInstanceMetadataServiceVersion?: string | undefined;
}
export interface AwsSageMakerNotebookInstanceDetails {
    AcceleratorTypes?: string[] | undefined;
    AdditionalCodeRepositories?: string[] | undefined;
    DefaultCodeRepository?: string | undefined;
    DirectInternetAccess?: string | undefined;
    FailureReason?: string | undefined;
    InstanceMetadataServiceConfiguration?: AwsSageMakerNotebookInstanceMetadataServiceConfigurationDetails | undefined;
    InstanceType?: string | undefined;
    KmsKeyId?: string | undefined;
    NetworkInterfaceId?: string | undefined;
    NotebookInstanceArn?: string | undefined;
    NotebookInstanceLifecycleConfigName?: string | undefined;
    NotebookInstanceName?: string | undefined;
    NotebookInstanceStatus?: string | undefined;
    PlatformIdentifier?: string | undefined;
    RoleArn?: string | undefined;
    RootAccess?: string | undefined;
    SecurityGroups?: string[] | undefined;
    SubnetId?: string | undefined;
    Url?: string | undefined;
    VolumeSizeInGB?: number | undefined;
}
export interface AwsWafv2WebAclCaptchaConfigImmunityTimePropertyDetails {
    ImmunityTime?: number | undefined;
}
export interface AwsWafv2WebAclCaptchaConfigDetails {
    ImmunityTimeProperty?: AwsWafv2WebAclCaptchaConfigImmunityTimePropertyDetails | undefined;
}
export interface AwsWafv2CustomHttpHeader {
    Name?: string | undefined;
    Value?: string | undefined;
}
export type AwsWafv2InsertHeadersList = AwsWafv2CustomHttpHeader[];
export interface AwsWafv2CustomRequestHandlingDetails {
    InsertHeaders?: AwsWafv2CustomHttpHeader[] | undefined;
}
export interface AwsWafv2ActionAllowDetails {
    CustomRequestHandling?: AwsWafv2CustomRequestHandlingDetails | undefined;
}
export interface AwsWafv2CustomResponseDetails {
    CustomResponseBodyKey?: string | undefined;
    ResponseCode?: number | undefined;
    ResponseHeaders?: AwsWafv2CustomHttpHeader[] | undefined;
}
export interface AwsWafv2ActionBlockDetails {
    CustomResponse?: AwsWafv2CustomResponseDetails | undefined;
}
export interface AwsWafv2WebAclActionDetails {
    Allow?: AwsWafv2ActionAllowDetails | undefined;
    Block?: AwsWafv2ActionBlockDetails | undefined;
}
export interface AwsWafv2RulesActionCaptchaDetails {
    CustomRequestHandling?: AwsWafv2CustomRequestHandlingDetails | undefined;
}
export interface AwsWafv2RulesActionCountDetails {
    CustomRequestHandling?: AwsWafv2CustomRequestHandlingDetails | undefined;
}
export interface AwsWafv2RulesActionDetails {
    Allow?: AwsWafv2ActionAllowDetails | undefined;
    Block?: AwsWafv2ActionBlockDetails | undefined;
    Captcha?: AwsWafv2RulesActionCaptchaDetails | undefined;
    Count?: AwsWafv2RulesActionCountDetails | undefined;
}
export interface AwsWafv2VisibilityConfigDetails {
    CloudWatchMetricsEnabled?: boolean | undefined;
    MetricName?: string | undefined;
    SampledRequestsEnabled?: boolean | undefined;
}
export interface AwsWafv2RulesDetails {
    Action?: AwsWafv2RulesActionDetails | undefined;
    Name?: string | undefined;
    OverrideAction?: string | undefined;
    Priority?: number | undefined;
    VisibilityConfig?: AwsWafv2VisibilityConfigDetails | undefined;
}
export type AwsWafv2RulesList = AwsWafv2RulesDetails[];
export interface AwsWafv2WebAclDetails {
    Name?: string | undefined;
    Arn?: string | undefined;
    ManagedbyFirewallManager?: boolean | undefined;
    Id?: string | undefined;
    Capacity?: number | undefined;
    CaptchaConfig?: AwsWafv2WebAclCaptchaConfigDetails | undefined;
    DefaultAction?: AwsWafv2WebAclActionDetails | undefined;
    Description?: string | undefined;
    Rules?: AwsWafv2RulesDetails[] | undefined;
    VisibilityConfig?: AwsWafv2VisibilityConfigDetails | undefined;
}
export interface AwsWafv2RuleGroupDetails {
    Capacity?: number | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Arn?: string | undefined;
    Rules?: AwsWafv2RulesDetails[] | undefined;
    Scope?: string | undefined;
    VisibilityConfig?: AwsWafv2VisibilityConfigDetails | undefined;
}
export interface AssociationStateDetails {
    State?: string | undefined;
    StatusMessage?: string | undefined;
}
export interface AssociationSetDetails {
    AssociationState?: AssociationStateDetails | undefined;
    GatewayId?: string | undefined;
    Main?: boolean | undefined;
    RouteTableAssociationId?: string | undefined;
    RouteTableId?: string | undefined;
    SubnetId?: string | undefined;
}
export type AssociationSetList = AssociationSetDetails[];
export interface PropagatingVgwSetDetails {
    GatewayId?: string | undefined;
}
export type PropagatingVgwSetList = PropagatingVgwSetDetails[];
export interface RouteSetDetails {
    CarrierGatewayId?: string | undefined;
    CoreNetworkArn?: string | undefined;
    DestinationCidrBlock?: string | undefined;
    DestinationIpv6CidrBlock?: string | undefined;
    DestinationPrefixListId?: string | undefined;
    EgressOnlyInternetGatewayId?: string | undefined;
    GatewayId?: string | undefined;
    InstanceId?: string | undefined;
    InstanceOwnerId?: string | undefined;
    LocalGatewayId?: string | undefined;
    NatGatewayId?: string | undefined;
    NetworkInterfaceId?: string | undefined;
    Origin?: string | undefined;
    State?: string | undefined;
    TransitGatewayId?: string | undefined;
    VpcPeeringConnectionId?: string | undefined;
}
export type RouteSetList = RouteSetDetails[];
export interface AwsEc2RouteTableDetails {
    AssociationSet?: AssociationSetDetails[] | undefined;
    OwnerId?: string | undefined;
    PropagatingVgwSet?: PropagatingVgwSetDetails[] | undefined;
    RouteTableId?: string | undefined;
    RouteSet?: RouteSetDetails[] | undefined;
    VpcId?: string | undefined;
}
export interface AwsAmazonMqBrokerEncryptionOptionsDetails {
    KmsKeyId?: string | undefined;
    UseAwsOwnedKey?: boolean | undefined;
}
export interface AwsAmazonMqBrokerLdapServerMetadataDetails {
    Hosts?: string[] | undefined;
    RoleBase?: string | undefined;
    RoleName?: string | undefined;
    RoleSearchMatching?: string | undefined;
    RoleSearchSubtree?: boolean | undefined;
    ServiceAccountUsername?: string | undefined;
    UserBase?: string | undefined;
    UserRoleName?: string | undefined;
    UserSearchMatching?: string | undefined;
    UserSearchSubtree?: boolean | undefined;
}
export interface AwsAmazonMqBrokerLogsPendingDetails {
    Audit?: boolean | undefined;
    General?: boolean | undefined;
}
export interface AwsAmazonMqBrokerLogsDetails {
    Audit?: boolean | undefined;
    General?: boolean | undefined;
    AuditLogGroup?: string | undefined;
    GeneralLogGroup?: string | undefined;
    Pending?: AwsAmazonMqBrokerLogsPendingDetails | undefined;
}
export interface AwsAmazonMqBrokerMaintenanceWindowStartTimeDetails {
    DayOfWeek?: string | undefined;
    TimeOfDay?: string | undefined;
    TimeZone?: string | undefined;
}
export interface AwsAmazonMqBrokerUsersDetails {
    PendingChange?: string | undefined;
    Username?: string | undefined;
}
export type AwsAmazonMqBrokerUsersList = AwsAmazonMqBrokerUsersDetails[];
export interface AwsAmazonMqBrokerDetails {
    AuthenticationStrategy?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    BrokerArn?: string | undefined;
    BrokerName?: string | undefined;
    DeploymentMode?: string | undefined;
    EncryptionOptions?: AwsAmazonMqBrokerEncryptionOptionsDetails | undefined;
    EngineType?: string | undefined;
    EngineVersion?: string | undefined;
    HostInstanceType?: string | undefined;
    BrokerId?: string | undefined;
    LdapServerMetadata?: AwsAmazonMqBrokerLdapServerMetadataDetails | undefined;
    Logs?: AwsAmazonMqBrokerLogsDetails | undefined;
    MaintenanceWindowStartTime?: AwsAmazonMqBrokerMaintenanceWindowStartTimeDetails | undefined;
    PubliclyAccessible?: boolean | undefined;
    SecurityGroups?: string[] | undefined;
    StorageType?: string | undefined;
    SubnetIds?: string[] | undefined;
    Users?: AwsAmazonMqBrokerUsersDetails[] | undefined;
}
export interface AwsAppSyncGraphQlApiOpenIdConnectConfigDetails {
    AuthTtL?: number | undefined;
    ClientId?: string | undefined;
    IatTtL?: number | undefined;
    Issuer?: string | undefined;
}
export interface AwsAppSyncGraphQlApiLambdaAuthorizerConfigDetails {
    AuthorizerResultTtlInSeconds?: number | undefined;
    AuthorizerUri?: string | undefined;
    IdentityValidationExpression?: string | undefined;
}
export interface AwsAppSyncGraphQlApiUserPoolConfigDetails {
    AppIdClientRegex?: string | undefined;
    AwsRegion?: string | undefined;
    DefaultAction?: string | undefined;
    UserPoolId?: string | undefined;
}
export interface AwsAppSyncGraphQlApiLogConfigDetails {
    CloudWatchLogsRoleArn?: string | undefined;
    ExcludeVerboseContent?: boolean | undefined;
    FieldLogLevel?: string | undefined;
}
export interface AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersDetails {
    AuthenticationType?: string | undefined;
    LambdaAuthorizerConfig?: AwsAppSyncGraphQlApiLambdaAuthorizerConfigDetails | undefined;
    OpenIdConnectConfig?: AwsAppSyncGraphQlApiOpenIdConnectConfigDetails | undefined;
    UserPoolConfig?: AwsAppSyncGraphQlApiUserPoolConfigDetails | undefined;
}
export type AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersList = AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersDetails[];
export interface AwsAppSyncGraphQlApiDetails {
    ApiId?: string | undefined;
    Id?: string | undefined;
    OpenIdConnectConfig?: AwsAppSyncGraphQlApiOpenIdConnectConfigDetails | undefined;
    Name?: string | undefined;
    LambdaAuthorizerConfig?: AwsAppSyncGraphQlApiLambdaAuthorizerConfigDetails | undefined;
    XrayEnabled?: boolean | undefined;
    Arn?: string | undefined;
    UserPoolConfig?: AwsAppSyncGraphQlApiUserPoolConfigDetails | undefined;
    AuthenticationType?: string | undefined;
    LogConfig?: AwsAppSyncGraphQlApiLogConfigDetails | undefined;
    AdditionalAuthenticationProviders?: AwsAppSyncGraphQlApiAdditionalAuthenticationProvidersDetails[] | undefined;
    WafWebAclArn?: string | undefined;
}
export interface AwsEventSchemasRegistryDetails {
    Description?: string | undefined;
    RegistryArn?: string | undefined;
    RegistryName?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesCloudTrailDetails {
    Status?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesDnsLogsDetails {
    Status?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesFlowLogsDetails {
    Status?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesKubernetesAuditLogsDetails {
    Status?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesKubernetesDetails {
    AuditLogs?: AwsGuardDutyDetectorDataSourcesKubernetesAuditLogsDetails | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsEbsVolumesDetails {
    Reason?: string | undefined;
    Status?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsDetails {
    EbsVolumes?: AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsEbsVolumesDetails | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesMalwareProtectionDetails {
    ScanEc2InstanceWithFindings?: AwsGuardDutyDetectorDataSourcesMalwareProtectionScanEc2InstanceWithFindingsDetails | undefined;
    ServiceRole?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesS3LogsDetails {
    Status?: string | undefined;
}
export interface AwsGuardDutyDetectorDataSourcesDetails {
    CloudTrail?: AwsGuardDutyDetectorDataSourcesCloudTrailDetails | undefined;
    DnsLogs?: AwsGuardDutyDetectorDataSourcesDnsLogsDetails | undefined;
    FlowLogs?: AwsGuardDutyDetectorDataSourcesFlowLogsDetails | undefined;
    Kubernetes?: AwsGuardDutyDetectorDataSourcesKubernetesDetails | undefined;
    MalwareProtection?: AwsGuardDutyDetectorDataSourcesMalwareProtectionDetails | undefined;
    S3Logs?: AwsGuardDutyDetectorDataSourcesS3LogsDetails | undefined;
}
export interface AwsGuardDutyDetectorFeaturesDetails {
    Name?: string | undefined;
    Status?: string | undefined;
}
export type AwsGuardDutyDetectorFeaturesList = AwsGuardDutyDetectorFeaturesDetails[];
export interface AwsGuardDutyDetectorDetails {
    DataSources?: AwsGuardDutyDetectorDataSourcesDetails | undefined;
    Features?: AwsGuardDutyDetectorFeaturesDetails[] | undefined;
    FindingPublishingFrequency?: string | undefined;
    ServiceRole?: string | undefined;
    Status?: string | undefined;
}
export interface AwsStepFunctionStateMachineLoggingConfigurationDestinationsCloudWatchLogsLogGroupDetails {
    LogGroupArn?: string | undefined;
}
export interface AwsStepFunctionStateMachineLoggingConfigurationDestinationsDetails {
    CloudWatchLogsLogGroup?: AwsStepFunctionStateMachineLoggingConfigurationDestinationsCloudWatchLogsLogGroupDetails | undefined;
}
export type AwsStepFunctionStateMachineLoggingConfigurationDestinationsList = AwsStepFunctionStateMachineLoggingConfigurationDestinationsDetails[];
export interface AwsStepFunctionStateMachineLoggingConfigurationDetails {
    Destinations?: AwsStepFunctionStateMachineLoggingConfigurationDestinationsDetails[] | undefined;
    IncludeExecutionData?: boolean | undefined;
    Level?: string | undefined;
}
export interface AwsStepFunctionStateMachineTracingConfigurationDetails {
    Enabled?: boolean | undefined;
}
export interface AwsStepFunctionStateMachineDetails {
    Label?: string | undefined;
    LoggingConfiguration?: AwsStepFunctionStateMachineLoggingConfigurationDetails | undefined;
    Name?: string | undefined;
    RoleArn?: string | undefined;
    StateMachineArn?: string | undefined;
    Status?: string | undefined;
    TracingConfiguration?: AwsStepFunctionStateMachineTracingConfigurationDetails | undefined;
    Type?: string | undefined;
}
export interface AwsAthenaWorkGroupConfigurationResultConfigurationEncryptionConfigurationDetails {
    EncryptionOption?: string | undefined;
    KmsKey?: string | undefined;
}
export interface AwsAthenaWorkGroupConfigurationResultConfigurationDetails {
    EncryptionConfiguration?: AwsAthenaWorkGroupConfigurationResultConfigurationEncryptionConfigurationDetails | undefined;
}
export interface AwsAthenaWorkGroupConfigurationDetails {
    ResultConfiguration?: AwsAthenaWorkGroupConfigurationResultConfigurationDetails | undefined;
}
export interface AwsAthenaWorkGroupDetails {
    Name?: string | undefined;
    Description?: string | undefined;
    State?: string | undefined;
    Configuration?: AwsAthenaWorkGroupConfigurationDetails | undefined;
}
export interface AwsEventsEventbusDetails {
    Arn?: string | undefined;
    Name?: string | undefined;
    Policy?: string | undefined;
}
export interface AwsDmsEndpointDetails {
    CertificateArn?: string | undefined;
    DatabaseName?: string | undefined;
    EndpointArn?: string | undefined;
    EndpointIdentifier?: string | undefined;
    EndpointType?: string | undefined;
    EngineName?: string | undefined;
    ExternalId?: string | undefined;
    ExtraConnectionAttributes?: string | undefined;
    KmsKeyId?: string | undefined;
    Port?: number | undefined;
    ServerName?: string | undefined;
    SslMode?: string | undefined;
    Username?: string | undefined;
}
export interface AwsEventsEndpointEventBusesDetails {
    EventBusArn?: string | undefined;
}
export type AwsEventsEndpointEventBusesList = AwsEventsEndpointEventBusesDetails[];
export interface AwsEventsEndpointReplicationConfigDetails {
    State?: string | undefined;
}
export interface AwsEventsEndpointRoutingConfigFailoverConfigPrimaryDetails {
    HealthCheck?: string | undefined;
}
export interface AwsEventsEndpointRoutingConfigFailoverConfigSecondaryDetails {
    Route?: string | undefined;
}
export interface AwsEventsEndpointRoutingConfigFailoverConfigDetails {
    Primary?: AwsEventsEndpointRoutingConfigFailoverConfigPrimaryDetails | undefined;
    Secondary?: AwsEventsEndpointRoutingConfigFailoverConfigSecondaryDetails | undefined;
}
export interface AwsEventsEndpointRoutingConfigDetails {
    FailoverConfig?: AwsEventsEndpointRoutingConfigFailoverConfigDetails | undefined;
}
export interface AwsEventsEndpointDetails {
    Arn?: string | undefined;
    Description?: string | undefined;
    EndpointId?: string | undefined;
    EndpointUrl?: string | undefined;
    EventBuses?: AwsEventsEndpointEventBusesDetails[] | undefined;
    Name?: string | undefined;
    ReplicationConfig?: AwsEventsEndpointReplicationConfigDetails | undefined;
    RoleArn?: string | undefined;
    RoutingConfig?: AwsEventsEndpointRoutingConfigDetails | undefined;
    State?: string | undefined;
    StateReason?: string | undefined;
}
export interface AwsDmsReplicationTaskDetails {
    CdcStartPosition?: string | undefined;
    CdcStartTime?: string | undefined;
    CdcStopPosition?: string | undefined;
    MigrationType?: string | undefined;
    Id?: string | undefined;
    ResourceIdentifier?: string | undefined;
    ReplicationInstanceArn?: string | undefined;
    ReplicationTaskIdentifier?: string | undefined;
    ReplicationTaskSettings?: string | undefined;
    SourceEndpointArn?: string | undefined;
    TableMappings?: string | undefined;
    TargetEndpointArn?: string | undefined;
    TaskData?: string | undefined;
}
export interface AwsDmsReplicationInstanceReplicationSubnetGroupDetails {
    ReplicationSubnetGroupIdentifier?: string | undefined;
}
export interface AwsDmsReplicationInstanceVpcSecurityGroupsDetails {
    VpcSecurityGroupId?: string | undefined;
}
export type AwsDmsReplicationInstanceVpcSecurityGroupsList = AwsDmsReplicationInstanceVpcSecurityGroupsDetails[];
export interface AwsDmsReplicationInstanceDetails {
    AllocatedStorage?: number | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    AvailabilityZone?: string | undefined;
    EngineVersion?: string | undefined;
    KmsKeyId?: string | undefined;
    MultiAZ?: boolean | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    ReplicationInstanceClass?: string | undefined;
    ReplicationInstanceIdentifier?: string | undefined;
    ReplicationSubnetGroup?: AwsDmsReplicationInstanceReplicationSubnetGroupDetails | undefined;
    VpcSecurityGroups?: AwsDmsReplicationInstanceVpcSecurityGroupsDetails[] | undefined;
}
export interface AwsRoute53HostedZoneConfigDetails {
    Comment?: string | undefined;
}
export interface AwsRoute53HostedZoneObjectDetails {
    Id?: string | undefined;
    Name?: string | undefined;
    Config?: AwsRoute53HostedZoneConfigDetails | undefined;
}
export interface AwsRoute53HostedZoneVpcDetails {
    Id?: string | undefined;
    Region?: string | undefined;
}
export type AwsRoute53HostedZoneVpcsList = AwsRoute53HostedZoneVpcDetails[];
export type AwsRoute53HostedZoneNameServersList = string[];
export interface CloudWatchLogsLogGroupArnConfigDetails {
    CloudWatchLogsLogGroupArn?: string | undefined;
    HostedZoneId?: string | undefined;
    Id?: string | undefined;
}
export interface AwsRoute53QueryLoggingConfigDetails {
    CloudWatchLogsLogGroupArn?: CloudWatchLogsLogGroupArnConfigDetails | undefined;
}
export interface AwsRoute53HostedZoneDetails {
    HostedZone?: AwsRoute53HostedZoneObjectDetails | undefined;
    Vpcs?: AwsRoute53HostedZoneVpcDetails[] | undefined;
    NameServers?: string[] | undefined;
    QueryLoggingConfig?: AwsRoute53QueryLoggingConfigDetails | undefined;
}
export interface AwsMskClusterClusterInfoEncryptionInfoEncryptionInTransitDetails {
    InCluster?: boolean | undefined;
    ClientBroker?: string | undefined;
}
export interface AwsMskClusterClusterInfoEncryptionInfoEncryptionAtRestDetails {
    DataVolumeKMSKeyId?: string | undefined;
}
export interface AwsMskClusterClusterInfoEncryptionInfoDetails {
    EncryptionInTransit?: AwsMskClusterClusterInfoEncryptionInfoEncryptionInTransitDetails | undefined;
    EncryptionAtRest?: AwsMskClusterClusterInfoEncryptionInfoEncryptionAtRestDetails | undefined;
}
export interface AwsMskClusterClusterInfoClientAuthenticationSaslIamDetails {
    Enabled?: boolean | undefined;
}
export interface AwsMskClusterClusterInfoClientAuthenticationSaslScramDetails {
    Enabled?: boolean | undefined;
}
export interface AwsMskClusterClusterInfoClientAuthenticationSaslDetails {
    Iam?: AwsMskClusterClusterInfoClientAuthenticationSaslIamDetails | undefined;
    Scram?: AwsMskClusterClusterInfoClientAuthenticationSaslScramDetails | undefined;
}
export interface AwsMskClusterClusterInfoClientAuthenticationUnauthenticatedDetails {
    Enabled?: boolean | undefined;
}
export interface AwsMskClusterClusterInfoClientAuthenticationTlsDetails {
    CertificateAuthorityArnList?: string[] | undefined;
    Enabled?: boolean | undefined;
}
export interface AwsMskClusterClusterInfoClientAuthenticationDetails {
    Sasl?: AwsMskClusterClusterInfoClientAuthenticationSaslDetails | undefined;
    Unauthenticated?: AwsMskClusterClusterInfoClientAuthenticationUnauthenticatedDetails | undefined;
    Tls?: AwsMskClusterClusterInfoClientAuthenticationTlsDetails | undefined;
}
export interface AwsMskClusterClusterInfoDetails {
    EncryptionInfo?: AwsMskClusterClusterInfoEncryptionInfoDetails | undefined;
    CurrentVersion?: string | undefined;
    NumberOfBrokerNodes?: number | undefined;
    ClusterName?: string | undefined;
    ClientAuthentication?: AwsMskClusterClusterInfoClientAuthenticationDetails | undefined;
    EnhancedMonitoring?: string | undefined;
}
export interface AwsMskClusterDetails {
    ClusterInfo?: AwsMskClusterClusterInfoDetails | undefined;
}
export interface AwsS3AccessPointVpcConfigurationDetails {
    VpcId?: string | undefined;
}
export interface AwsS3AccessPointDetails {
    AccessPointArn?: string | undefined;
    Alias?: string | undefined;
    Bucket?: string | undefined;
    BucketAccountId?: string | undefined;
    Name?: string | undefined;
    NetworkOrigin?: string | undefined;
    PublicAccessBlockConfiguration?: AwsS3AccountPublicAccessBlockDetails | undefined;
    VpcConfiguration?: AwsS3AccessPointVpcConfigurationDetails | undefined;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsActiveDirectoryDetails {
    DirectoryId?: string | undefined;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsMutualAuthenticationDetails {
    ClientRootCertificateChain?: string | undefined;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsFederatedAuthenticationDetails {
    SamlProviderArn?: string | undefined;
    SelfServiceSamlProviderArn?: string | undefined;
}
export interface AwsEc2ClientVpnEndpointAuthenticationOptionsDetails {
    Type?: string | undefined;
    ActiveDirectory?: AwsEc2ClientVpnEndpointAuthenticationOptionsActiveDirectoryDetails | undefined;
    MutualAuthentication?: AwsEc2ClientVpnEndpointAuthenticationOptionsMutualAuthenticationDetails | undefined;
    FederatedAuthentication?: AwsEc2ClientVpnEndpointAuthenticationOptionsFederatedAuthenticationDetails | undefined;
}
export type AwsEc2ClientVpnEndpointAuthenticationOptionsList = AwsEc2ClientVpnEndpointAuthenticationOptionsDetails[];
export interface AwsEc2ClientVpnEndpointConnectionLogOptionsDetails {
    Enabled?: boolean | undefined;
    CloudwatchLogGroup?: string | undefined;
    CloudwatchLogStream?: string | undefined;
}
export interface AwsEc2ClientVpnEndpointClientConnectOptionsStatusDetails {
    Code?: string | undefined;
    Message?: string | undefined;
}
export interface AwsEc2ClientVpnEndpointClientConnectOptionsDetails {
    Enabled?: boolean | undefined;
    LambdaFunctionArn?: string | undefined;
    Status?: AwsEc2ClientVpnEndpointClientConnectOptionsStatusDetails | undefined;
}
export interface AwsEc2ClientVpnEndpointClientLoginBannerOptionsDetails {
    Enabled?: boolean | undefined;
    BannerText?: string | undefined;
}
export interface AwsEc2ClientVpnEndpointDetails {
    ClientVpnEndpointId?: string | undefined;
    Description?: string | undefined;
    ClientCidrBlock?: string | undefined;
    DnsServer?: string[] | undefined;
    SplitTunnel?: boolean | undefined;
    TransportProtocol?: string | undefined;
    VpnPort?: number | undefined;
    ServerCertificateArn?: string | undefined;
    AuthenticationOptions?: AwsEc2ClientVpnEndpointAuthenticationOptionsDetails[] | undefined;
    ConnectionLogOptions?: AwsEc2ClientVpnEndpointConnectionLogOptionsDetails | undefined;
    SecurityGroupIdSet?: string[] | undefined;
    VpcId?: string | undefined;
    SelfServicePortalUrl?: string | undefined;
    ClientConnectOptions?: AwsEc2ClientVpnEndpointClientConnectOptionsDetails | undefined;
    SessionTimeoutHours?: number | undefined;
    ClientLoginBannerOptions?: AwsEc2ClientVpnEndpointClientLoginBannerOptionsDetails | undefined;
}
export interface CodeRepositoryDetails {
    ProviderType?: string | undefined;
    ProjectName?: string | undefined;
    CodeSecurityIntegrationArn?: string | undefined;
}
export type AzureResourceDetails = unknown;
export interface ResourceDetails {
    AwsAutoScalingAutoScalingGroup?: AwsAutoScalingAutoScalingGroupDetails | undefined;
    AwsCodeBuildProject?: AwsCodeBuildProjectDetails | undefined;
    AwsCloudFrontDistribution?: AwsCloudFrontDistributionDetails | undefined;
    AwsEc2Instance?: AwsEc2InstanceDetails | undefined;
    AwsEc2NetworkInterface?: AwsEc2NetworkInterfaceDetails | undefined;
    AwsEc2SecurityGroup?: AwsEc2SecurityGroupDetails | undefined;
    AwsEc2Volume?: AwsEc2VolumeDetails | undefined;
    AwsEc2Vpc?: AwsEc2VpcDetails | undefined;
    AwsEc2Eip?: AwsEc2EipDetails | undefined;
    AwsEc2Subnet?: AwsEc2SubnetDetails | undefined;
    AwsEc2NetworkAcl?: AwsEc2NetworkAclDetails | undefined;
    AwsElbv2LoadBalancer?: AwsElbv2LoadBalancerDetails | undefined;
    AwsElasticBeanstalkEnvironment?: AwsElasticBeanstalkEnvironmentDetails | undefined;
    AwsElasticsearchDomain?: AwsElasticsearchDomainDetails | undefined;
    AwsS3Bucket?: AwsS3BucketDetails | undefined;
    AwsS3AccountPublicAccessBlock?: AwsS3AccountPublicAccessBlockDetails | undefined;
    AwsS3Object?: AwsS3ObjectDetails | undefined;
    AwsSecretsManagerSecret?: AwsSecretsManagerSecretDetails | undefined;
    AwsIamAccessKey?: AwsIamAccessKeyDetails | undefined;
    AwsIamUser?: AwsIamUserDetails | undefined;
    AwsIamPolicy?: AwsIamPolicyDetails | undefined;
    AwsApiGatewayV2Stage?: AwsApiGatewayV2StageDetails | undefined;
    AwsApiGatewayV2Api?: AwsApiGatewayV2ApiDetails | undefined;
    AwsDynamoDbTable?: AwsDynamoDbTableDetails | undefined;
    AwsApiGatewayStage?: AwsApiGatewayStageDetails | undefined;
    AwsApiGatewayRestApi?: AwsApiGatewayRestApiDetails | undefined;
    AwsCloudTrailTrail?: AwsCloudTrailTrailDetails | undefined;
    AwsSsmPatchCompliance?: AwsSsmPatchComplianceDetails | undefined;
    AwsCertificateManagerCertificate?: AwsCertificateManagerCertificateDetails | undefined;
    AwsRedshiftCluster?: AwsRedshiftClusterDetails | undefined;
    AwsElbLoadBalancer?: AwsElbLoadBalancerDetails | undefined;
    AwsIamGroup?: AwsIamGroupDetails | undefined;
    AwsIamRole?: AwsIamRoleDetails | undefined;
    AwsKmsKey?: AwsKmsKeyDetails | undefined;
    AwsLambdaFunction?: AwsLambdaFunctionDetails | undefined;
    AwsLambdaLayerVersion?: AwsLambdaLayerVersionDetails | undefined;
    AwsRdsDbInstance?: AwsRdsDbInstanceDetails | undefined;
    AwsSnsTopic?: AwsSnsTopicDetails | undefined;
    AwsSqsQueue?: AwsSqsQueueDetails | undefined;
    AwsWafWebAcl?: AwsWafWebAclDetails | undefined;
    AwsRdsDbSnapshot?: AwsRdsDbSnapshotDetails | undefined;
    AwsRdsDbClusterSnapshot?: AwsRdsDbClusterSnapshotDetails | undefined;
    AwsRdsDbCluster?: AwsRdsDbClusterDetails | undefined;
    AwsEcsCluster?: AwsEcsClusterDetails | undefined;
    AwsEcsContainer?: AwsEcsContainerDetails | undefined;
    AwsEcsTaskDefinition?: AwsEcsTaskDefinitionDetails | undefined;
    Container?: ContainerDetails | undefined;
    Other?: {
        [key: string]: string | undefined;
    } | undefined;
    AwsRdsEventSubscription?: AwsRdsEventSubscriptionDetails | undefined;
    AwsEcsService?: AwsEcsServiceDetails | undefined;
    AwsAutoScalingLaunchConfiguration?: AwsAutoScalingLaunchConfigurationDetails | undefined;
    AwsEc2VpnConnection?: AwsEc2VpnConnectionDetails | undefined;
    AwsEcrContainerImage?: AwsEcrContainerImageDetails | undefined;
    AwsOpenSearchServiceDomain?: AwsOpenSearchServiceDomainDetails | undefined;
    AwsEc2VpcEndpointService?: AwsEc2VpcEndpointServiceDetails | undefined;
    AwsXrayEncryptionConfig?: AwsXrayEncryptionConfigDetails | undefined;
    AwsWafRateBasedRule?: AwsWafRateBasedRuleDetails | undefined;
    AwsWafRegionalRateBasedRule?: AwsWafRegionalRateBasedRuleDetails | undefined;
    AwsEcrRepository?: AwsEcrRepositoryDetails | undefined;
    AwsEksCluster?: AwsEksClusterDetails | undefined;
    AwsNetworkFirewallFirewallPolicy?: AwsNetworkFirewallFirewallPolicyDetails | undefined;
    AwsNetworkFirewallFirewall?: AwsNetworkFirewallFirewallDetails | undefined;
    AwsNetworkFirewallRuleGroup?: AwsNetworkFirewallRuleGroupDetails | undefined;
    AwsRdsDbSecurityGroup?: AwsRdsDbSecurityGroupDetails | undefined;
    AwsKinesisStream?: AwsKinesisStreamDetails | undefined;
    AwsEc2TransitGateway?: AwsEc2TransitGatewayDetails | undefined;
    AwsEfsAccessPoint?: AwsEfsAccessPointDetails | undefined;
    AwsCloudFormationStack?: AwsCloudFormationStackDetails | undefined;
    AwsCloudWatchAlarm?: AwsCloudWatchAlarmDetails | undefined;
    AwsEc2VpcPeeringConnection?: AwsEc2VpcPeeringConnectionDetails | undefined;
    AwsWafRegionalRuleGroup?: AwsWafRegionalRuleGroupDetails | undefined;
    AwsWafRegionalRule?: AwsWafRegionalRuleDetails | undefined;
    AwsWafRegionalWebAcl?: AwsWafRegionalWebAclDetails | undefined;
    AwsWafRule?: AwsWafRuleDetails | undefined;
    AwsWafRuleGroup?: AwsWafRuleGroupDetails | undefined;
    AwsEcsTask?: AwsEcsTaskDetails | undefined;
    AwsBackupBackupVault?: AwsBackupBackupVaultDetails | undefined;
    AwsBackupBackupPlan?: AwsBackupBackupPlanDetails | undefined;
    AwsBackupRecoveryPoint?: AwsBackupRecoveryPointDetails | undefined;
    AwsEc2LaunchTemplate?: AwsEc2LaunchTemplateDetails | undefined;
    AwsSageMakerNotebookInstance?: AwsSageMakerNotebookInstanceDetails | undefined;
    AwsWafv2WebAcl?: AwsWafv2WebAclDetails | undefined;
    AwsWafv2RuleGroup?: AwsWafv2RuleGroupDetails | undefined;
    AwsEc2RouteTable?: AwsEc2RouteTableDetails | undefined;
    AwsAmazonMqBroker?: AwsAmazonMqBrokerDetails | undefined;
    AwsAppSyncGraphQlApi?: AwsAppSyncGraphQlApiDetails | undefined;
    AwsEventSchemasRegistry?: AwsEventSchemasRegistryDetails | undefined;
    AwsGuardDutyDetector?: AwsGuardDutyDetectorDetails | undefined;
    AwsStepFunctionStateMachine?: AwsStepFunctionStateMachineDetails | undefined;
    AwsAthenaWorkGroup?: AwsAthenaWorkGroupDetails | undefined;
    AwsEventsEventbus?: AwsEventsEventbusDetails | undefined;
    AwsDmsEndpoint?: AwsDmsEndpointDetails | undefined;
    AwsEventsEndpoint?: AwsEventsEndpointDetails | undefined;
    AwsDmsReplicationTask?: AwsDmsReplicationTaskDetails | undefined;
    AwsDmsReplicationInstance?: AwsDmsReplicationInstanceDetails | undefined;
    AwsRoute53HostedZone?: AwsRoute53HostedZoneDetails | undefined;
    AwsMskCluster?: AwsMskClusterDetails | undefined;
    AwsS3AccessPoint?: AwsS3AccessPointDetails | undefined;
    AwsEc2ClientVpnEndpoint?: AwsEc2ClientVpnEndpointDetails | undefined;
    CodeRepository?: CodeRepositoryDetails | undefined;
    AzureResource?: any | undefined;
}
export interface Resource {
    Type?: string | undefined;
    Id?: string | undefined;
    Partition?: Partition | undefined;
    Region?: string | undefined;
    Provider?: CloudProviderName | undefined;
    Owner?: ResourceOwner | undefined;
    ResourceRole?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    DataClassification?: DataClassificationDetails | undefined;
    Details?: ResourceDetails | undefined;
    ApplicationName?: string | undefined;
    ApplicationArn?: string | undefined;
}
export type ResourceList = Resource[];
export type ComplianceStatus = "PASSED" | "WARNING" | "FAILED" | "NOT_AVAILABLE" | (string & {});
export interface StatusReason {
    ReasonCode?: string | undefined;
    Description?: string | undefined;
}
export type StatusReasonsList = StatusReason[];
export interface AssociatedStandard {
    StandardsId?: string | undefined;
}
export type AssociatedStandardsList = AssociatedStandard[];
export interface SecurityControlParameter {
    Name?: string | undefined;
    Value?: string[] | undefined;
}
export type SecurityControlParametersList = SecurityControlParameter[];
export interface Compliance {
    Status?: ComplianceStatus | undefined;
    RelatedRequirements?: string[] | undefined;
    StatusReasons?: StatusReason[] | undefined;
    SecurityControlId?: string | undefined;
    AssociatedStandards?: AssociatedStandard[] | undefined;
    SecurityControlParameters?: SecurityControlParameter[] | undefined;
}
export type WorkflowState = "NEW" | "ASSIGNED" | "IN_PROGRESS" | "DEFERRED" | "RESOLVED" | (string & {});
export interface Workflow {
    Status?: WorkflowStatus | undefined;
}
export type RecordState = "ACTIVE" | "ARCHIVED" | (string & {});
export interface Note {
    Text?: string | undefined;
    UpdatedBy?: string | undefined;
    UpdatedAt?: string | undefined;
}
export interface SoftwarePackage {
    Name?: string | undefined;
    Version?: string | undefined;
    Epoch?: string | undefined;
    Release?: string | undefined;
    Architecture?: string | undefined;
    PackageManager?: string | undefined;
    FilePath?: string | undefined;
    FixedInVersion?: string | undefined;
    Remediation?: string | undefined;
    SourceLayerHash?: string | undefined;
    SourceLayerArn?: string | undefined;
}
export type SoftwarePackageList = SoftwarePackage[];
export interface Adjustment {
    Metric?: string | undefined;
    Reason?: string | undefined;
}
export type AdjustmentList = Adjustment[];
export interface Cvss {
    Version?: string | undefined;
    BaseScore?: number | undefined;
    BaseVector?: string | undefined;
    Source?: string | undefined;
    Adjustments?: Adjustment[] | undefined;
}
export type CvssList = Cvss[];
export interface VulnerabilityVendor {
    Name?: string | undefined;
    Url?: string | undefined;
    VendorSeverity?: string | undefined;
    VendorCreatedAt?: string | undefined;
    VendorUpdatedAt?: string | undefined;
}
export type VulnerabilityFixAvailable = "YES" | "NO" | "PARTIAL" | (string & {});
export type VulnerabilityExploitAvailable = "YES" | "NO" | (string & {});
export interface CodeVulnerabilitiesFilePath {
    EndLine?: number | undefined;
    FileName?: string | undefined;
    FilePath?: string | undefined;
    StartLine?: number | undefined;
}
export interface VulnerabilityCodeVulnerabilities {
    Cwes?: string[] | undefined;
    FilePath?: CodeVulnerabilitiesFilePath | undefined;
    SourceArn?: string | undefined;
}
export type VulnerabilityCodeVulnerabilitiesList = VulnerabilityCodeVulnerabilities[];
export interface Vulnerability {
    Id?: string | undefined;
    VulnerablePackages?: SoftwarePackage[] | undefined;
    Cvss?: Cvss[] | undefined;
    RelatedVulnerabilities?: string[] | undefined;
    Vendor?: VulnerabilityVendor | undefined;
    ReferenceUrls?: string[] | undefined;
    FixAvailable?: VulnerabilityFixAvailable | undefined;
    EpssScore?: number | undefined;
    ExploitAvailable?: VulnerabilityExploitAvailable | undefined;
    LastKnownExploitAt?: string | undefined;
    CodeVulnerabilities?: VulnerabilityCodeVulnerabilities[] | undefined;
}
export type VulnerabilityList = Vulnerability[];
export interface PatchSummary {
    Id?: string | undefined;
    InstalledCount?: number | undefined;
    MissingCount?: number | undefined;
    FailedCount?: number | undefined;
    InstalledOtherCount?: number | undefined;
    InstalledRejectedCount?: number | undefined;
    InstalledPendingReboot?: number | undefined;
    OperationStartTime?: string | undefined;
    OperationEndTime?: string | undefined;
    RebootOption?: string | undefined;
    Operation?: string | undefined;
}
export interface IpOrganizationDetails {
    Asn?: number | undefined;
    AsnOrg?: string | undefined;
    Isp?: string | undefined;
    Org?: string | undefined;
}
export interface Country {
    CountryCode?: string | undefined;
    CountryName?: string | undefined;
}
export interface City {
    CityName?: string | undefined;
}
export interface GeoLocation {
    Lon?: number | undefined;
    Lat?: number | undefined;
}
export interface ActionRemoteIpDetails {
    IpAddressV4?: string | undefined;
    Organization?: IpOrganizationDetails | undefined;
    Country?: Country | undefined;
    City?: City | undefined;
    GeoLocation?: GeoLocation | undefined;
}
export interface ActionRemotePortDetails {
    Port?: number | undefined;
    PortName?: string | undefined;
}
export interface ActionLocalPortDetails {
    Port?: number | undefined;
    PortName?: string | undefined;
}
export interface NetworkConnectionAction {
    ConnectionDirection?: string | undefined;
    RemoteIpDetails?: ActionRemoteIpDetails | undefined;
    RemotePortDetails?: ActionRemotePortDetails | undefined;
    LocalPortDetails?: ActionLocalPortDetails | undefined;
    Protocol?: string | undefined;
    Blocked?: boolean | undefined;
}
export interface AwsApiCallActionDomainDetails {
    Domain?: string | undefined;
}
export interface AwsApiCallAction {
    Api?: string | undefined;
    ServiceName?: string | undefined;
    CallerType?: string | undefined;
    RemoteIpDetails?: ActionRemoteIpDetails | undefined;
    DomainDetails?: AwsApiCallActionDomainDetails | undefined;
    AffectedResources?: {
        [key: string]: string | undefined;
    } | undefined;
    FirstSeen?: string | undefined;
    LastSeen?: string | undefined;
}
export interface DnsRequestAction {
    Domain?: string | undefined;
    Protocol?: string | undefined;
    Blocked?: boolean | undefined;
}
export interface ActionLocalIpDetails {
    IpAddressV4?: string | undefined;
}
export interface PortProbeDetail {
    LocalPortDetails?: ActionLocalPortDetails | undefined;
    LocalIpDetails?: ActionLocalIpDetails | undefined;
    RemoteIpDetails?: ActionRemoteIpDetails | undefined;
}
export type PortProbeDetailList = PortProbeDetail[];
export interface PortProbeAction {
    PortProbeDetails?: PortProbeDetail[] | undefined;
    Blocked?: boolean | undefined;
}
export interface Action {
    ActionType?: string | undefined;
    NetworkConnectionAction?: NetworkConnectionAction | undefined;
    AwsApiCallAction?: AwsApiCallAction | undefined;
    DnsRequestAction?: DnsRequestAction | undefined;
    PortProbeAction?: PortProbeAction | undefined;
}
export interface FindingProviderSeverity {
    Label?: SeverityLabel | undefined;
    Original?: string | undefined;
}
export interface FindingProviderFields {
    Confidence?: number | undefined;
    Criticality?: number | undefined;
    RelatedFindings?: RelatedFinding[] | undefined;
    Severity?: FindingProviderSeverity | undefined;
    Types?: string[] | undefined;
}
export interface GeneratorDetails {
    Name?: string | undefined;
    Description?: string | undefined;
    Labels?: string[] | undefined;
}
export interface UserAccount {
    Uid?: string | undefined;
    Name?: string | undefined;
}
export interface ActorUser {
    Name?: string | undefined;
    Uid?: string | undefined;
    Type?: string | undefined;
    CredentialUid?: string | undefined;
    Account?: UserAccount | undefined;
}
export type ActorSessionMfaStatus = "ENABLED" | "DISABLED" | (string & {});
export interface ActorSession {
    Uid?: string | undefined;
    MfaStatus?: ActorSessionMfaStatus | undefined;
    CreatedTime?: number | undefined;
    Issuer?: string | undefined;
}
export interface Actor {
    Id?: string | undefined;
    User?: ActorUser | undefined;
    Session?: ActorSession | undefined;
}
export type ActorsList = Actor[];
export interface NetworkGeoLocation {
    City?: string | undefined;
    Country?: string | undefined;
    Lat?: number | undefined;
    Lon?: number | undefined;
}
export interface NetworkAutonomousSystem {
    Name?: string | undefined;
    Number?: number | undefined;
}
export type ConnectionDirection = "INBOUND" | "OUTBOUND" | (string & {});
export interface NetworkConnection {
    Direction?: ConnectionDirection | undefined;
}
export interface NetworkEndpoint {
    Id?: string | undefined;
    Ip?: string | undefined;
    Domain?: string | undefined;
    Port?: number | undefined;
    Location?: NetworkGeoLocation | undefined;
    AutonomousSystem?: NetworkAutonomousSystem | undefined;
    Connection?: NetworkConnection | undefined;
}
export type NetworkEndpointsList = NetworkEndpoint[];
export interface Indicator {
    Key?: string | undefined;
    Values?: string[] | undefined;
    Title?: string | undefined;
    Type?: string | undefined;
}
export type IndicatorsList = Indicator[];
export interface Signal {
    Type?: string | undefined;
    Id?: string | undefined;
    Title?: string | undefined;
    ProductArn?: string | undefined;
    ResourceIds?: string[] | undefined;
    SignalIndicators?: Indicator[] | undefined;
    Name?: string | undefined;
    CreatedAt?: number | undefined;
    UpdatedAt?: number | undefined;
    FirstSeenAt?: number | undefined;
    LastSeenAt?: number | undefined;
    Severity?: number | undefined;
    Count?: number | undefined;
    ActorIds?: string[] | undefined;
    EndpointIds?: string[] | undefined;
}
export type SignalsList = Signal[];
export interface Sequence {
    Uid?: string | undefined;
    Actors?: Actor[] | undefined;
    Endpoints?: NetworkEndpoint[] | undefined;
    Signals?: Signal[] | undefined;
    SequenceIndicators?: Indicator[] | undefined;
}
export interface Detection {
    Sequence?: Sequence | undefined;
}
export interface AwsSecurityFinding {
    SchemaVersion?: string | undefined;
    Id?: string | undefined;
    ProductArn?: string | undefined;
    ProductName?: string | undefined;
    CompanyName?: string | undefined;
    Region?: string | undefined;
    GeneratorId?: string | undefined;
    AwsAccountId?: string | undefined;
    Types?: string[] | undefined;
    FirstObservedAt?: string | undefined;
    LastObservedAt?: string | undefined;
    CreatedAt?: string | undefined;
    UpdatedAt?: string | undefined;
    Severity?: Severity | undefined;
    Confidence?: number | undefined;
    Criticality?: number | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    Remediation?: Remediation | undefined;
    SourceUrl?: string | undefined;
    ProductFields?: {
        [key: string]: string | undefined;
    } | undefined;
    UserDefinedFields?: {
        [key: string]: string | undefined;
    } | undefined;
    Malware?: Malware[] | undefined;
    Network?: Network | undefined;
    NetworkPath?: NetworkPathComponent[] | undefined;
    Process?: ProcessDetails | undefined;
    Threats?: Threat[] | undefined;
    ThreatIntelIndicators?: ThreatIntelIndicator[] | undefined;
    Resources?: Resource[] | undefined;
    Compliance?: Compliance | undefined;
    VerificationState?: VerificationState | undefined;
    WorkflowState?: WorkflowState | undefined;
    Workflow?: Workflow | undefined;
    RecordState?: RecordState | undefined;
    RelatedFindings?: RelatedFinding[] | undefined;
    Note?: Note | undefined;
    Vulnerabilities?: Vulnerability[] | undefined;
    PatchSummary?: PatchSummary | undefined;
    Action?: Action | undefined;
    FindingProviderFields?: FindingProviderFields | undefined;
    Sample?: boolean | undefined;
    GeneratorDetails?: GeneratorDetails | undefined;
    ProcessedAt?: string | undefined;
    AwsAccountName?: string | undefined;
    Detection?: Detection | undefined;
}
export type BatchImportFindingsRequestFindingList = AwsSecurityFinding[];
export interface BatchImportFindingsRequest {
    Findings?: AwsSecurityFinding[] | undefined;
}
export interface ImportFindingsError {
    Id?: string | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type ImportFindingsErrorList = ImportFindingsError[];
export interface BatchImportFindingsResponse {
    FailedCount: number;
    SuccessCount: number;
    FailedFindings?: (ImportFindingsError & {
        Id: NonEmptyString;
        ErrorCode: NonEmptyString;
        ErrorMessage: NonEmptyString;
    })[] | undefined;
}
export interface UpdateAutomationRulesRequestItem {
    RuleArn?: string | undefined;
    RuleStatus?: RuleStatus | undefined;
    RuleOrder?: number | undefined;
    Description?: string | undefined;
    RuleName?: string | undefined;
    IsTerminal?: boolean | undefined;
    Criteria?: AutomationRulesFindingFilters | undefined;
    Actions?: AutomationRulesAction[] | undefined;
}
export type UpdateAutomationRulesRequestItemsList = UpdateAutomationRulesRequestItem[];
export interface BatchUpdateAutomationRulesRequest {
    UpdateAutomationRulesRequestItems?: UpdateAutomationRulesRequestItem[] | undefined;
}
export interface BatchUpdateAutomationRulesResponse {
    ProcessedAutomationRules?: string[] | undefined;
    UnprocessedAutomationRules?: UnprocessedAutomationRule[] | undefined;
}
export interface AwsSecurityFindingIdentifier {
    Id?: string | undefined;
    ProductArn?: string | undefined;
}
export type AwsSecurityFindingIdentifierList = AwsSecurityFindingIdentifier[];
export interface BatchUpdateFindingsRequest {
    FindingIdentifiers?: AwsSecurityFindingIdentifier[] | undefined;
    Note?: NoteUpdate | undefined;
    Severity?: SeverityUpdate | undefined;
    VerificationState?: VerificationState | undefined;
    Confidence?: number | undefined;
    Criticality?: number | undefined;
    Types?: string[] | undefined;
    UserDefinedFields?: {
        [key: string]: string | undefined;
    } | undefined;
    Workflow?: WorkflowUpdate | undefined;
    RelatedFindings?: RelatedFinding[] | undefined;
}
export interface BatchUpdateFindingsUnprocessedFinding {
    FindingIdentifier?: AwsSecurityFindingIdentifier | undefined;
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type BatchUpdateFindingsUnprocessedFindingsList = BatchUpdateFindingsUnprocessedFinding[];
export interface BatchUpdateFindingsResponse {
    ProcessedFindings: (AwsSecurityFindingIdentifier & {
        Id: NonEmptyString;
        ProductArn: NonEmptyString;
    })[];
    UnprocessedFindings: (BatchUpdateFindingsUnprocessedFinding & {
        FindingIdentifier: AwsSecurityFindingIdentifier & {
            Id: NonEmptyString;
            ProductArn: NonEmptyString;
        };
        ErrorCode: NonEmptyString;
        ErrorMessage: NonEmptyString;
    })[];
}
export type MetadataUidList = string[];
export interface OcsfFindingIdentifier {
    CloudAccountUid?: string | undefined;
    FindingInfoUid?: string | undefined;
    MetadataProductUid?: string | undefined;
}
export type OcsfFindingIdentifierList = OcsfFindingIdentifier[];
export interface BatchUpdateFindingsV2Request {
    MetadataUids?: string[] | undefined;
    FindingIdentifiers?: OcsfFindingIdentifier[] | undefined;
    Comment?: string | undefined;
    SeverityId?: number | undefined;
    StatusId?: number | undefined;
}
export interface BatchUpdateFindingsV2ProcessedFinding {
    FindingIdentifier?: OcsfFindingIdentifier | undefined;
    MetadataUid?: string | undefined;
}
export type BatchUpdateFindingsV2ProcessedFindingsList = BatchUpdateFindingsV2ProcessedFinding[];
export type BatchUpdateFindingsV2UnprocessedFindingErrorCode = "ResourceNotFoundException" | "ValidationException" | "InternalServerException" | "ConflictException" | (string & {});
export interface BatchUpdateFindingsV2UnprocessedFinding {
    FindingIdentifier?: OcsfFindingIdentifier | undefined;
    MetadataUid?: string | undefined;
    ErrorCode?: BatchUpdateFindingsV2UnprocessedFindingErrorCode | undefined;
    ErrorMessage?: string | undefined;
}
export type BatchUpdateFindingsV2UnprocessedFindingsList = BatchUpdateFindingsV2UnprocessedFinding[];
export interface BatchUpdateFindingsV2Response {
    ProcessedFindings: (BatchUpdateFindingsV2ProcessedFinding & {
        FindingIdentifier: OcsfFindingIdentifier & {
            CloudAccountUid: NonEmptyString;
            FindingInfoUid: NonEmptyString;
            MetadataProductUid: NonEmptyString;
        };
    })[];
    UnprocessedFindings: (BatchUpdateFindingsV2UnprocessedFinding & {
        FindingIdentifier: OcsfFindingIdentifier & {
            CloudAccountUid: NonEmptyString;
            FindingInfoUid: NonEmptyString;
            MetadataProductUid: NonEmptyString;
        };
    })[];
}
export interface StandardsControlAssociationUpdate {
    StandardsArn?: string | undefined;
    SecurityControlId?: string | undefined;
    AssociationStatus?: AssociationStatus | undefined;
    UpdatedReason?: string | undefined;
}
export type StandardsControlAssociationUpdates = StandardsControlAssociationUpdate[];
export interface BatchUpdateStandardsControlAssociationsRequest {
    StandardsControlAssociationUpdates?: StandardsControlAssociationUpdate[] | undefined;
}
export interface UnprocessedStandardsControlAssociationUpdate {
    StandardsControlAssociationUpdate?: StandardsControlAssociationUpdate | undefined;
    ErrorCode?: UnprocessedErrorCode | undefined;
    ErrorReason?: string | undefined;
}
export type UnprocessedStandardsControlAssociationUpdates = UnprocessedStandardsControlAssociationUpdate[];
export interface BatchUpdateStandardsControlAssociationsResponse {
    UnprocessedAssociationUpdates?: (UnprocessedStandardsControlAssociationUpdate & {
        StandardsControlAssociationUpdate: StandardsControlAssociationUpdate & {
            StandardsArn: NonEmptyString;
            SecurityControlId: NonEmptyString;
            AssociationStatus: AssociationStatus;
        };
        ErrorCode: UnprocessedErrorCode;
    })[] | undefined;
}
export type ExportJobId = string;
export interface CancelExportJobV2Request {
    ExportJobId: string;
}
export type ExportStatus = "RUNNING" | "SUCCEEDED" | "FAILED" | "CANCELLED" | (string & {});
export interface CancelExportJobV2Response {
    ExportJobId: string;
    Status: ExportStatus;
}
export interface CreateActionTargetRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    Id?: string | undefined;
}
export interface CreateActionTargetResponse {
    ActionTargetArn: string;
}
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type ClientToken = string;
export interface CreateAggregatorV2Request {
    RegionLinkingMode?: string | undefined;
    LinkedRegions?: string[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface CreateAggregatorV2Response {
    AggregatorV2Arn?: string | undefined;
    AggregationRegion?: string | undefined;
    RegionLinkingMode?: string | undefined;
    LinkedRegions?: string[] | undefined;
}
export interface CreateAutomationRuleRequest {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    RuleStatus?: RuleStatus | undefined;
    RuleOrder?: number | undefined;
    RuleName?: string | undefined;
    Description?: string | undefined;
    IsTerminal?: boolean | undefined;
    Criteria?: AutomationRulesFindingFilters | undefined;
    Actions?: AutomationRulesAction[] | undefined;
}
export interface CreateAutomationRuleResponse {
    RuleArn?: string | undefined;
}
export type RuleStatusV2 = "ENABLED" | "DISABLED" | (string & {});
export type RuleOrderValueV2 = number;
export type OcsfStringField = "metadata.uid" | "activity_name" | "cloud.account.uid" | "cloud.provider" | "cloud.region" | "compliance.assessments.category" | "compliance.assessments.name" | "compliance.control" | "compliance.status" | "compliance.standards" | "finding_info.desc" | "finding_info.src_url" | "finding_info.title" | "finding_info.types" | "finding_info.uid" | "finding_info.related_events.traits.category" | "finding_info.related_events.uid" | "finding_info.related_events.product.uid" | "finding_info.related_events.title" | "impact" | "likelihood" | "metadata.product.name" | "metadata.product.uid" | "metadata.product.vendor_name" | "remediation.desc" | "remediation.references" | "resources.cloud_partition" | "resources.criticality" | "resources.name" | "resources.owner.account.uid" | "resources.owner.org.uid" | "resources.owner.account.name" | "resources.provider" | "resources.region" | "resources.type" | "resources.uid" | "severity" | "status" | "comment" | "vulnerabilities.fix_coverage" | "class_name" | "databucket.encryption_details.algorithm" | "databucket.encryption_details.key_uid" | "databucket.file.data_classifications.classifier_details.type" | "evidences.actor.user.account.uid" | "evidences.api.operation" | "evidences.api.response.error_message" | "evidences.api.service.name" | "evidences.connection_info.direction" | "evidences.connection_info.protocol_name" | "evidences.dst_endpoint.autonomous_system.name" | "evidences.dst_endpoint.location.city" | "evidences.dst_endpoint.location.country" | "evidences.src_endpoint.autonomous_system.name" | "evidences.src_endpoint.hostname" | "evidences.src_endpoint.location.city" | "evidences.src_endpoint.location.country" | "finding_info.analytic.name" | "malware.name" | "malware_scan_info.uid" | "malware.severity" | "resources.cloud_function.layers.uid_alt" | "resources.cloud_function.runtime" | "resources.cloud_function.user.uid" | "resources.device.encryption_details.key_uid" | "resources.device.image.uid" | "resources.image.architecture" | "resources.image.registry_uid" | "resources.image.repository_name" | "resources.image.uid" | "resources.subnet_info.uid" | "resources.vpc_uid" | "vulnerabilities.affected_code.file.path" | "vulnerabilities.affected_packages.name" | "vulnerabilities.cve.epss.score" | "vulnerabilities.cve.uid" | "vulnerabilities.related_vulnerabilities" | "cloud.account.name" | "vendor_attributes.severity" | (string & {});
export interface OcsfStringFilter {
    FieldName?: OcsfStringField | undefined;
    Filter?: StringFilter | undefined;
}
export type OcsfStringFilterList = OcsfStringFilter[];
export type OcsfDateField = "finding_info.created_time_dt" | "finding_info.first_seen_time_dt" | "finding_info.last_seen_time_dt" | "finding_info.modified_time_dt" | "resources.image.created_time_dt" | "resources.image.last_used_time_dt" | "resources.modified_time_dt" | (string & {});
export interface OcsfDateFilter {
    FieldName?: OcsfDateField | undefined;
    Filter?: DateFilter | undefined;
}
export type OcsfDateFilterList = OcsfDateFilter[];
export type OcsfBooleanField = "compliance.assessments.meets_criteria" | "vulnerabilities.is_exploit_available" | "vulnerabilities.is_fix_available" | (string & {});
export interface BooleanFilter {
    Value?: boolean | undefined;
}
export interface OcsfBooleanFilter {
    FieldName?: OcsfBooleanField | undefined;
    Filter?: BooleanFilter | undefined;
}
export type OcsfBooleanFilterList = OcsfBooleanFilter[];
export type OcsfNumberField = "activity_id" | "compliance.status_id" | "confidence_score" | "severity_id" | "status_id" | "finding_info.related_events_count" | "evidences.api.response.code" | "evidences.dst_endpoint.autonomous_system.number" | "evidences.dst_endpoint.port" | "evidences.src_endpoint.autonomous_system.number" | "evidences.src_endpoint.port" | "resources.image.in_use_count" | "vulnerabilities.cve.cvss.base_score" | "vendor_attributes.severity_id" | (string & {});
export interface OcsfNumberFilter {
    FieldName?: OcsfNumberField | undefined;
    Filter?: NumberFilter | undefined;
}
export type OcsfNumberFilterList = OcsfNumberFilter[];
export type OcsfMapField = "resources.tags" | "compliance.control_parameters" | "databucket.tags" | "finding_info.tags" | (string & {});
export interface OcsfMapFilter {
    FieldName?: OcsfMapField | undefined;
    Filter?: MapFilter | undefined;
}
export type OcsfMapFilterList = OcsfMapFilter[];
export type OcsfIpField = "evidences.dst_endpoint.ip" | "evidences.src_endpoint.ip" | (string & {});
export interface IpFilter {
    Cidr?: string | undefined;
}
export interface OcsfIpFilter {
    FieldName?: OcsfIpField | undefined;
    Filter?: IpFilter | undefined;
}
export type OcsfIpFilterList = OcsfIpFilter[];
export type AllowedOperators = "AND" | "OR" | (string & {});
export interface CompositeFilter {
    StringFilters?: OcsfStringFilter[] | undefined;
    DateFilters?: OcsfDateFilter[] | undefined;
    BooleanFilters?: OcsfBooleanFilter[] | undefined;
    NumberFilters?: OcsfNumberFilter[] | undefined;
    MapFilters?: OcsfMapFilter[] | undefined;
    IpFilters?: OcsfIpFilter[] | undefined;
    NestedCompositeFilters?: CompositeFilter[] | undefined;
    Operator?: AllowedOperators | undefined;
}
export type CompositeFilterList = CompositeFilter[];
export interface OcsfFindingFilters {
    CompositeFilters?: CompositeFilter[] | undefined;
    CompositeOperator?: AllowedOperators | undefined;
}
export type ResourcesStringField = "ResourceGuid" | "ResourceId" | "AccountId" | "AccountName" | "Region" | "ResourceProvider" | "ResourceOwnerAccountId" | "ResourceOwnerOrgId" | "ResourceCloudPartition" | "ResourceRegion" | "ResourceCategory" | "ResourceType" | "ResourceName" | "FindingsSummary.FindingType" | "FindingsSummary.ProductName" | "ResourceSubCategory" | "DiscoveryType" | "ResourceInfo.AIDetails.HostResourceGuid" | "ResourceInfo.AIDetails.HostResourceType" | "ResourceInfo.AIDetails.CanonicalId" | "ResourceCriticality" | (string & {});
export interface ResourcesStringFilter {
    FieldName?: ResourcesStringField | undefined;
    Filter?: StringFilter | undefined;
}
export type ResourcesStringFilterList = ResourcesStringFilter[];
export type ResourcesDateField = "ResourceDetailCaptureTime" | "ResourceCreationTime" | (string & {});
export interface ResourcesDateFilter {
    FieldName?: ResourcesDateField | undefined;
    Filter?: DateFilter | undefined;
}
export type ResourcesDateFilterList = ResourcesDateFilter[];
export type ResourcesNumberField = "FindingsSummary.TotalFindings" | "FindingsSummary.Severities.Other" | "FindingsSummary.Severities.Fatal" | "FindingsSummary.Severities.Critical" | "FindingsSummary.Severities.High" | "FindingsSummary.Severities.Medium" | "FindingsSummary.Severities.Low" | "FindingsSummary.Severities.Informational" | "FindingsSummary.Severities.Unknown" | "ResourceInfo.AIDetails.SelfHostedAIModelResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIAgentResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIModelServingResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIExternalEndpointResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIDevelopmentResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIAgentFrameworkResourceCount" | "ResourceInfo.AIDetails.SelfHostedAIAgentToolsAndIdentityResourceCount" | "ResourceInfo.AIDetails.SelfHostedTotalAIResourceCount" | (string & {});
export interface ResourcesNumberFilter {
    FieldName?: ResourcesNumberField | undefined;
    Filter?: NumberFilter | undefined;
}
export type ResourcesNumberFilterList = ResourcesNumberFilter[];
export type ResourcesMapField = "ResourceTags" | (string & {});
export interface ResourcesMapFilter {
    FieldName?: ResourcesMapField | undefined;
    Filter?: MapFilter | undefined;
}
export type ResourcesMapFilterList = ResourcesMapFilter[];
export interface ResourcesCompositeFilter {
    StringFilters?: ResourcesStringFilter[] | undefined;
    DateFilters?: ResourcesDateFilter[] | undefined;
    NumberFilters?: ResourcesNumberFilter[] | undefined;
    MapFilters?: ResourcesMapFilter[] | undefined;
    NestedCompositeFilters?: ResourcesCompositeFilter[] | undefined;
    Operator?: AllowedOperators | undefined;
}
export type ResourcesCompositeFilterList = ResourcesCompositeFilter[];
export interface ResourcesFilters {
    CompositeFilters?: ResourcesCompositeFilter[] | undefined;
    CompositeOperator?: AllowedOperators | undefined;
}
export type Criteria = {
    OcsfFindingCriteria: OcsfFindingFilters;
    ResourceCriteria?: undefined;
} | {
    OcsfFindingCriteria?: undefined;
    ResourceCriteria: ResourcesFilters;
};
export type AutomationRulesActionTypeV2 = "FINDING_FIELDS_UPDATE" | "EXTERNAL_INTEGRATION" | "RESOURCE_FIELDS_UPDATE" | (string & {});
export interface AutomationRulesFindingFieldsUpdateV2 {
    SeverityId?: number | undefined;
    Comment?: string | undefined;
    StatusId?: number | undefined;
}
export interface ExternalIntegrationConfiguration {
    ConnectorArn?: string | undefined;
}
export type ResourceCriticality = "Very High" | "High" | "Medium" | "Low" | "Unknown" | (string & {});
export interface AutomationRulesResourceFieldsUpdateV2 {
    Criticality?: ResourceCriticality | undefined;
}
export interface AutomationRulesActionV2 {
    Type?: AutomationRulesActionTypeV2 | undefined;
    FindingFieldsUpdate?: AutomationRulesFindingFieldsUpdateV2 | undefined;
    ExternalIntegrationConfiguration?: ExternalIntegrationConfiguration | undefined;
    ResourceFieldsUpdate?: AutomationRulesResourceFieldsUpdateV2 | undefined;
}
export type AutomationRulesActionListV2 = AutomationRulesActionV2[];
export interface CreateAutomationRuleV2Request {
    RuleName?: string | undefined;
    RuleStatus?: RuleStatusV2 | undefined;
    Description?: string | undefined;
    RuleOrder?: number | undefined;
    Criteria?: Criteria | undefined;
    Actions?: AutomationRulesActionV2[] | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export interface CreateAutomationRuleV2Response {
    RuleArn?: string | undefined;
    RuleId?: string | undefined;
}
export type EnabledStandardIdentifierList = string[];
export type EnabledSecurityControlIdentifierList = string[];
export type DisabledSecurityControlIdentifierList = string[];
export interface SecurityControlCustomParameter {
    SecurityControlId?: string | undefined;
    Parameters?: {
        [key: string]: ParameterConfiguration | undefined;
    } | undefined;
}
export type SecurityControlCustomParametersList = SecurityControlCustomParameter[];
export interface SecurityControlsConfiguration {
    EnabledSecurityControlIdentifiers?: string[] | undefined;
    DisabledSecurityControlIdentifiers?: string[] | undefined;
    SecurityControlCustomParameters?: SecurityControlCustomParameter[] | undefined;
}
export interface SecurityHubPolicy {
    ServiceEnabled?: boolean | undefined;
    EnabledStandardIdentifiers?: string[] | undefined;
    SecurityControlsConfiguration?: SecurityControlsConfiguration | undefined;
}
export type Policy = {
    SecurityHub: SecurityHubPolicy;
};
export interface CreateConfigurationPolicyRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    ConfigurationPolicy?: Policy | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateConfigurationPolicyResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    UpdatedAt?: Date | undefined;
    CreatedAt?: Date | undefined;
    ConfigurationPolicy?: Policy | undefined;
}
export type ScopeType = "TENANT" | "SUBSCRIPTION" | (string & {});
export type ScopeValueList = string[];
export interface AzureScopeConfiguration {
    ScopeType?: ScopeType | undefined;
    ScopeValues?: string[] | undefined;
}
export type AzureRegionList = string[];
export interface AzureProviderConfiguration {
    AWSConfigConnectorArn?: string | undefined;
    ScopeConfiguration?: AzureScopeConfiguration | undefined;
    AzureRegions?: string[] | undefined;
}
export type CspmProviderConfiguration = {
    Azure: AzureProviderConfiguration;
};
export interface CreateConnectorRequest {
    Name?: string | undefined;
    Description?: string | undefined;
    Provider?: CspmProviderConfiguration | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export type CspmConnectorStatus = "CONNECTED" | "DEGRADED" | "FAILED_TO_CONNECT" | "UNKNOWN" | (string & {});
export type CspmEnablementStatus = "ENABLED" | "PENDING_ENABLEMENT" | "PENDING_UPDATE" | "PENDING_DELETION" | (string & {});
export interface CreateConnectorResponse {
    ConnectorArn: string;
    ConnectorId: string;
    ConnectorStatus?: CspmConnectorStatus | undefined;
    EnablementStatus?: CspmEnablementStatus | undefined;
}
export interface JiraCloudProviderConfiguration {
    ProjectKey?: string | undefined;
}
export interface ServiceNowProviderConfiguration {
    InstanceName?: string | undefined;
    SecretArn?: string | undefined;
}
export type ProviderConfiguration = {
    JiraCloud: JiraCloudProviderConfiguration;
    ServiceNow?: undefined;
    Azure?: undefined;
} | {
    JiraCloud?: undefined;
    ServiceNow: ServiceNowProviderConfiguration;
    Azure?: undefined;
} | {
    JiraCloud?: undefined;
    ServiceNow?: undefined;
    Azure: AzureProviderConfiguration;
};
export interface CreateConnectorV2Request {
    Name?: string | undefined;
    Description?: string | undefined;
    Provider?: ProviderConfiguration | undefined;
    KmsKeyArn?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    ClientToken?: string | undefined;
}
export type ConnectorStatus = "CONNECTED" | "DEGRADED" | "FAILED_TO_CONNECT" | "PENDING_AUTHORIZATION" | "PENDING_CONFIGURATION" | "UNKNOWN" | (string & {});
export type EnablementStatus = "ENABLED" | "PENDING_ENABLEMENT" | "FAILED_TO_ENABLE" | "PENDING_UPDATE" | "FAILED_TO_UPDATE" | "PENDING_DELETION" | "FAILED_TO_DELETE" | (string & {});
export interface CreateConnectorV2Response {
    ConnectorArn: string;
    ConnectorId: string;
    AuthUrl?: string | undefined;
    ConnectorStatus?: ConnectorStatus | undefined;
    EnablementStatus?: EnablementStatus | undefined;
}
export interface CreateFindingAggregatorRequest {
    RegionLinkingMode?: string | undefined;
    Regions?: string[] | undefined;
}
export interface CreateFindingAggregatorResponse {
    FindingAggregatorArn?: string | undefined;
    FindingAggregationRegion?: string | undefined;
    RegionLinkingMode?: string | undefined;
    Regions?: string[] | undefined;
}
export type IpFilterList = IpFilter[];
export interface KeywordFilter {
    Value?: string | undefined;
}
export type KeywordFilterList = KeywordFilter[];
export type BooleanFilterList = BooleanFilter[];
export interface AwsSecurityFindingFilters {
    ProductArn?: StringFilter[] | undefined;
    AwsAccountId?: StringFilter[] | undefined;
    Id?: StringFilter[] | undefined;
    GeneratorId?: StringFilter[] | undefined;
    Region?: StringFilter[] | undefined;
    Type?: StringFilter[] | undefined;
    FirstObservedAt?: DateFilter[] | undefined;
    LastObservedAt?: DateFilter[] | undefined;
    CreatedAt?: DateFilter[] | undefined;
    UpdatedAt?: DateFilter[] | undefined;
    SeverityProduct?: NumberFilter[] | undefined;
    SeverityNormalized?: NumberFilter[] | undefined;
    SeverityLabel?: StringFilter[] | undefined;
    Confidence?: NumberFilter[] | undefined;
    Criticality?: NumberFilter[] | undefined;
    Title?: StringFilter[] | undefined;
    Description?: StringFilter[] | undefined;
    RecommendationText?: StringFilter[] | undefined;
    SourceUrl?: StringFilter[] | undefined;
    ProductFields?: MapFilter[] | undefined;
    ProductName?: StringFilter[] | undefined;
    CompanyName?: StringFilter[] | undefined;
    UserDefinedFields?: MapFilter[] | undefined;
    MalwareName?: StringFilter[] | undefined;
    MalwareType?: StringFilter[] | undefined;
    MalwarePath?: StringFilter[] | undefined;
    MalwareState?: StringFilter[] | undefined;
    NetworkDirection?: StringFilter[] | undefined;
    NetworkProtocol?: StringFilter[] | undefined;
    NetworkSourceIpV4?: IpFilter[] | undefined;
    NetworkSourceIpV6?: IpFilter[] | undefined;
    NetworkSourcePort?: NumberFilter[] | undefined;
    NetworkSourceDomain?: StringFilter[] | undefined;
    NetworkSourceMac?: StringFilter[] | undefined;
    NetworkDestinationIpV4?: IpFilter[] | undefined;
    NetworkDestinationIpV6?: IpFilter[] | undefined;
    NetworkDestinationPort?: NumberFilter[] | undefined;
    NetworkDestinationDomain?: StringFilter[] | undefined;
    ProcessName?: StringFilter[] | undefined;
    ProcessPath?: StringFilter[] | undefined;
    ProcessPid?: NumberFilter[] | undefined;
    ProcessParentPid?: NumberFilter[] | undefined;
    ProcessLaunchedAt?: DateFilter[] | undefined;
    ProcessTerminatedAt?: DateFilter[] | undefined;
    ThreatIntelIndicatorType?: StringFilter[] | undefined;
    ThreatIntelIndicatorValue?: StringFilter[] | undefined;
    ThreatIntelIndicatorCategory?: StringFilter[] | undefined;
    ThreatIntelIndicatorLastObservedAt?: DateFilter[] | undefined;
    ThreatIntelIndicatorSource?: StringFilter[] | undefined;
    ThreatIntelIndicatorSourceUrl?: StringFilter[] | undefined;
    ResourceType?: StringFilter[] | undefined;
    ResourceId?: StringFilter[] | undefined;
    ResourcePartition?: StringFilter[] | undefined;
    ResourceRegion?: StringFilter[] | undefined;
    ResourceTags?: MapFilter[] | undefined;
    ResourceAwsEc2InstanceType?: StringFilter[] | undefined;
    ResourceAwsEc2InstanceImageId?: StringFilter[] | undefined;
    ResourceAwsEc2InstanceIpV4Addresses?: IpFilter[] | undefined;
    ResourceAwsEc2InstanceIpV6Addresses?: IpFilter[] | undefined;
    ResourceAwsEc2InstanceKeyName?: StringFilter[] | undefined;
    ResourceAwsEc2InstanceIamInstanceProfileArn?: StringFilter[] | undefined;
    ResourceAwsEc2InstanceVpcId?: StringFilter[] | undefined;
    ResourceAwsEc2InstanceSubnetId?: StringFilter[] | undefined;
    ResourceAwsEc2InstanceLaunchedAt?: DateFilter[] | undefined;
    ResourceAwsS3BucketOwnerId?: StringFilter[] | undefined;
    ResourceAwsS3BucketOwnerName?: StringFilter[] | undefined;
    ResourceAwsIamAccessKeyUserName?: StringFilter[] | undefined;
    ResourceAwsIamAccessKeyPrincipalName?: StringFilter[] | undefined;
    ResourceAwsIamAccessKeyStatus?: StringFilter[] | undefined;
    ResourceAwsIamAccessKeyCreatedAt?: DateFilter[] | undefined;
    ResourceAwsIamUserUserName?: StringFilter[] | undefined;
    ResourceContainerName?: StringFilter[] | undefined;
    ResourceContainerImageId?: StringFilter[] | undefined;
    ResourceContainerImageName?: StringFilter[] | undefined;
    ResourceContainerLaunchedAt?: DateFilter[] | undefined;
    ResourceDetailsOther?: MapFilter[] | undefined;
    ComplianceStatus?: StringFilter[] | undefined;
    VerificationState?: StringFilter[] | undefined;
    WorkflowState?: StringFilter[] | undefined;
    WorkflowStatus?: StringFilter[] | undefined;
    RecordState?: StringFilter[] | undefined;
    RelatedFindingsProductArn?: StringFilter[] | undefined;
    RelatedFindingsId?: StringFilter[] | undefined;
    NoteText?: StringFilter[] | undefined;
    NoteUpdatedAt?: DateFilter[] | undefined;
    NoteUpdatedBy?: StringFilter[] | undefined;
    Keyword?: KeywordFilter[] | undefined;
    FindingProviderFieldsConfidence?: NumberFilter[] | undefined;
    FindingProviderFieldsCriticality?: NumberFilter[] | undefined;
    FindingProviderFieldsRelatedFindingsId?: StringFilter[] | undefined;
    FindingProviderFieldsRelatedFindingsProductArn?: StringFilter[] | undefined;
    FindingProviderFieldsSeverityLabel?: StringFilter[] | undefined;
    FindingProviderFieldsSeverityOriginal?: StringFilter[] | undefined;
    FindingProviderFieldsTypes?: StringFilter[] | undefined;
    Sample?: BooleanFilter[] | undefined;
    ComplianceSecurityControlId?: StringFilter[] | undefined;
    ComplianceAssociatedStandardsId?: StringFilter[] | undefined;
    VulnerabilitiesExploitAvailable?: StringFilter[] | undefined;
    VulnerabilitiesFixAvailable?: StringFilter[] | undefined;
    ComplianceSecurityControlParametersName?: StringFilter[] | undefined;
    ComplianceSecurityControlParametersValue?: StringFilter[] | undefined;
    AwsAccountName?: StringFilter[] | undefined;
    ResourceApplicationName?: StringFilter[] | undefined;
    ResourceApplicationArn?: StringFilter[] | undefined;
    ResourceOwnerAccountId?: StringFilter[] | undefined;
    ResourceOwnerOrgId?: StringFilter[] | undefined;
    ResourceProvider?: StringFilter[] | undefined;
}
export interface CreateInsightRequest {
    Name?: string | undefined;
    Filters?: AwsSecurityFindingFilters | undefined;
    GroupByAttribute?: string | undefined;
}
export interface CreateInsightResponse {
    InsightArn: string;
}
export type AccountId = string;
export interface AccountDetails {
    AccountId?: string | undefined;
    Email?: string | undefined;
}
export type AccountDetailsList = AccountDetails[];
export interface CreateMembersRequest {
    AccountDetails?: AccountDetails[] | undefined;
}
export interface Result {
    AccountId?: string | undefined;
    ProcessingResult?: string | undefined;
}
export type ResultList = Result[];
export interface CreateMembersResponse {
    UnprocessedAccounts?: Result[] | undefined;
}
export type TicketCreationMode = "DRYRUN" | (string & {});
export interface CreateTicketV2Request {
    ConnectorId?: string | undefined;
    FindingMetadataUid?: string | undefined;
    ClientToken?: string | undefined;
    Mode?: TicketCreationMode | undefined;
}
export interface CreateTicketV2Response {
    TicketId: string;
    TicketSrcUrl?: string | undefined;
}
export type AccountIdList = string[];
export interface DeclineInvitationsRequest {
    AccountIds?: string[] | undefined;
}
export interface DeclineInvitationsResponse {
    UnprocessedAccounts?: Result[] | undefined;
}
export interface DeleteActionTargetRequest {
    ActionTargetArn: string;
}
export interface DeleteActionTargetResponse {
    ActionTargetArn: string;
}
export interface DeleteAggregatorV2Request {
    AggregatorV2Arn: string;
}
export interface DeleteAggregatorV2Response {
}
export interface DeleteAutomationRuleV2Request {
    Identifier: string;
}
export interface DeleteAutomationRuleV2Response {
}
export interface DeleteConfigurationPolicyRequest {
    Identifier: string;
}
export interface DeleteConfigurationPolicyResponse {
}
export interface DeleteConnectorRequest {
    ConnectorId: string;
}
export interface DeleteConnectorResponse {
    EnablementStatus?: CspmEnablementStatus | undefined;
}
export interface DeleteConnectorV2Request {
    ConnectorId: string;
}
export interface DeleteConnectorV2Response {
    EnablementStatus?: EnablementStatus | undefined;
}
export interface DeleteFindingAggregatorRequest {
    FindingAggregatorArn: string;
}
export interface DeleteFindingAggregatorResponse {
}
export interface DeleteInsightRequest {
    InsightArn: string;
}
export interface DeleteInsightResponse {
    InsightArn: string;
}
export interface DeleteInvitationsRequest {
    AccountIds?: string[] | undefined;
}
export interface DeleteInvitationsResponse {
    UnprocessedAccounts?: Result[] | undefined;
}
export interface DeleteMembersRequest {
    AccountIds?: string[] | undefined;
}
export interface DeleteMembersResponse {
    UnprocessedAccounts?: Result[] | undefined;
}
export type ArnList = string[];
export type NextToken = string;
export type MaxResults = number;
export interface DescribeActionTargetsRequest {
    ActionTargetArns?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ActionTarget {
    ActionTargetArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
}
export type ActionTargetList = ActionTarget[];
export interface DescribeActionTargetsResponse {
    ActionTargets: (ActionTarget & {
        ActionTargetArn: NonEmptyString;
        Name: NonEmptyString;
        Description: NonEmptyString;
    })[];
    NextToken?: string | undefined;
}
export interface DescribeHubRequest {
    HubArn?: string | undefined;
}
export type ControlFindingGenerator = "STANDARD_CONTROL" | "SECURITY_CONTROL" | (string & {});
export interface DescribeHubResponse {
    HubArn?: string | undefined;
    SubscribedAt?: string | undefined;
    AutoEnableControls?: boolean | undefined;
    ControlFindingGenerator?: ControlFindingGenerator | undefined;
}
export interface DescribeOrganizationConfigurationRequest {
}
export type AutoEnableStandards = "NONE" | "DEFAULT" | (string & {});
export type OrganizationConfigurationConfigurationType = "CENTRAL" | "LOCAL" | (string & {});
export type OrganizationConfigurationStatus = "PENDING" | "ENABLED" | "FAILED" | "DISABLED" | (string & {});
export interface OrganizationConfiguration {
    ConfigurationType?: OrganizationConfigurationConfigurationType | undefined;
    Status?: OrganizationConfigurationStatus | undefined;
    StatusMessage?: string | undefined;
}
export interface DescribeOrganizationConfigurationResponse {
    AutoEnable?: boolean | undefined;
    MemberAccountLimitReached?: boolean | undefined;
    AutoEnableStandards?: AutoEnableStandards | undefined;
    OrganizationConfiguration?: OrganizationConfiguration | undefined;
}
export interface DescribeProductsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ProductArn?: string | undefined;
}
export type CategoryList = string[];
export type IntegrationType = "SEND_FINDINGS_TO_SECURITY_HUB" | "RECEIVE_FINDINGS_FROM_SECURITY_HUB" | "UPDATE_FINDINGS_IN_SECURITY_HUB" | (string & {});
export type IntegrationTypeList = IntegrationType[];
export interface Product {
    ProductArn?: string | undefined;
    ProductName?: string | undefined;
    CompanyName?: string | undefined;
    Description?: string | undefined;
    Categories?: string[] | undefined;
    IntegrationTypes?: IntegrationType[] | undefined;
    MarketplaceUrl?: string | undefined;
    ActivationUrl?: string | undefined;
    ProductSubscriptionResourcePolicy?: string | undefined;
}
export type ProductsList = Product[];
export interface DescribeProductsResponse {
    Products: (Product & {
        ProductArn: NonEmptyString;
    })[];
    NextToken?: string | undefined;
}
export interface DescribeProductsV2Request {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type IntegrationV2Type = "SEND_FINDINGS_TO_SECURITY_HUB" | "RECEIVE_FINDINGS_FROM_SECURITY_HUB" | "UPDATE_FINDINGS_IN_SECURITY_HUB" | "EXTENDED_PLAN" | (string & {});
export type IntegrationV2TypeList = IntegrationV2Type[];
export interface ProductV2 {
    ProductV2Name?: string | undefined;
    CompanyName?: string | undefined;
    Description?: string | undefined;
    Categories?: string[] | undefined;
    IntegrationV2Types?: IntegrationV2Type[] | undefined;
    MarketplaceUrl?: string | undefined;
    ActivationUrl?: string | undefined;
    MarketplaceProductId?: string | undefined;
}
export type ProductsV2List = ProductV2[];
export interface DescribeProductsV2Response {
    ProductsV2: ProductV2[];
    NextToken?: string | undefined;
}
export interface DescribeSecurityHubV2Request {
}
export type IsoString = string;
export type FeatureNameKey = string;
export type FeatureStatus = "ENABLED" | "DISABLED" | (string & {});
export interface FeatureDetail {
    FeatureStatus?: FeatureStatus | undefined;
    UpdatedAt?: Date | undefined;
}
export type Features = {
    [key: string]: FeatureDetail | undefined;
};
export interface DescribeSecurityHubV2Response {
    HubV2Arn?: string | undefined;
    SubscribedAt?: string | undefined;
    Features?: {
        [key: string]: FeatureDetail | undefined;
    } | undefined;
}
export type StandardsProviders = StandardsProvider[];
export interface DescribeStandardsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Providers?: StandardsProvider[] | undefined;
}
export interface StandardsManagedBy {
    Company?: string | undefined;
    Product?: string | undefined;
}
export interface Standard {
    StandardsArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    EnabledByDefault?: boolean | undefined;
    Provider?: StandardsProvider | undefined;
    StandardsManagedBy?: StandardsManagedBy | undefined;
}
export type Standards = Standard[];
export interface DescribeStandardsResponse {
    Standards?: Standard[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeStandardsControlsRequest {
    StandardsSubscriptionArn: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface StandardsControl {
    StandardsControlArn?: string | undefined;
    ControlStatus?: ControlStatus | undefined;
    DisabledReason?: string | undefined;
    ControlStatusUpdatedAt?: Date | undefined;
    ControlId?: string | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    RemediationUrl?: string | undefined;
    SeverityRating?: SeverityRating | undefined;
    RelatedRequirements?: string[] | undefined;
}
export type StandardsControls = StandardsControl[];
export interface DescribeStandardsControlsResponse {
    Controls?: StandardsControl[] | undefined;
    NextToken?: string | undefined;
}
export interface DisableImportFindingsForProductRequest {
    ProductSubscriptionArn: string;
}
export interface DisableImportFindingsForProductResponse {
}
export type SecurityHubFeature = "SecurityHub" | "SecurityHubV2" | (string & {});
export interface DisableOrganizationAdminAccountRequest {
    AdminAccountId?: string | undefined;
    Feature?: SecurityHubFeature | undefined;
}
export interface DisableOrganizationAdminAccountResponse {
}
export interface DisableSecurityHubRequest {
}
export interface DisableSecurityHubResponse {
}
export type FeatureName = "NETWORK_SCANNING" | (string & {});
export interface DisableSecurityHubFeatureV2Request {
    FeatureName: FeatureName;
}
export interface DisableSecurityHubFeatureV2Response {
}
export interface DisableSecurityHubV2Request {
}
export interface DisableSecurityHubV2Response {
}
export interface DisassociateFromAdministratorAccountRequest {
}
export interface DisassociateFromAdministratorAccountResponse {
}
export interface DisassociateFromMasterAccountRequest {
}
export interface DisassociateFromMasterAccountResponse {
}
export interface DisassociateMembersRequest {
    AccountIds?: string[] | undefined;
}
export interface DisassociateMembersResponse {
}
export interface EnableImportFindingsForProductRequest {
    ProductArn?: string | undefined;
}
export interface EnableImportFindingsForProductResponse {
    ProductSubscriptionArn?: string | undefined;
}
export interface EnableOrganizationAdminAccountRequest {
    AdminAccountId?: string | undefined;
    Feature?: SecurityHubFeature | undefined;
}
export interface EnableOrganizationAdminAccountResponse {
    AdminAccountId?: string | undefined;
    Feature?: SecurityHubFeature | undefined;
}
export interface EnableSecurityHubRequest {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
    EnableDefaultStandards?: boolean | undefined;
    ControlFindingGenerator?: ControlFindingGenerator | undefined;
}
export interface EnableSecurityHubResponse {
}
export interface EnableSecurityHubFeatureV2Request {
    FeatureName: FeatureName;
}
export interface EnableSecurityHubFeatureV2Response {
}
export interface EnableSecurityHubV2Request {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface EnableSecurityHubV2Response {
    HubV2Arn?: string | undefined;
}
export interface GenerateRecommendedPolicyV2Request {
    MetadataUid: string;
}
export interface GenerateRecommendedPolicyV2Response {
}
export interface GetAdministratorAccountRequest {
}
export interface Invitation {
    AccountId?: string | undefined;
    InvitationId?: string | undefined;
    InvitedAt?: Date | undefined;
    MemberStatus?: string | undefined;
}
export interface GetAdministratorAccountResponse {
    Administrator?: Invitation | undefined;
}
export interface GetAggregatorV2Request {
    AggregatorV2Arn: string;
}
export interface GetAggregatorV2Response {
    AggregatorV2Arn?: string | undefined;
    AggregationRegion?: string | undefined;
    RegionLinkingMode?: string | undefined;
    LinkedRegions?: string[] | undefined;
}
export interface GetAutomationRuleV2Request {
    Identifier: string;
}
export interface GetAutomationRuleV2Response {
    RuleArn?: string | undefined;
    RuleId?: string | undefined;
    RuleOrder?: number | undefined;
    RuleName?: string | undefined;
    RuleStatus?: RuleStatusV2 | undefined;
    Description?: string | undefined;
    Criteria?: Criteria | undefined;
    Actions?: (AutomationRulesActionV2 & {
        Type: AutomationRulesActionTypeV2;
        ResourceFieldsUpdate: AutomationRulesResourceFieldsUpdateV2 & {
            Criticality: ResourceCriticality;
        };
    })[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export interface GetConfigurationPolicyRequest {
    Identifier: string;
}
export interface GetConfigurationPolicyResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    UpdatedAt?: Date | undefined;
    CreatedAt?: Date | undefined;
    ConfigurationPolicy?: Policy | undefined;
}
export interface GetConfigurationPolicyAssociationRequest {
    Target?: Target | undefined;
}
export interface GetConfigurationPolicyAssociationResponse {
    ConfigurationPolicyId?: string | undefined;
    TargetId?: string | undefined;
    TargetType?: TargetType | undefined;
    AssociationType?: AssociationType | undefined;
    UpdatedAt?: Date | undefined;
    AssociationStatus?: ConfigurationPolicyAssociationStatus | undefined;
    AssociationStatusMessage?: string | undefined;
}
export interface GetConnectorRequest {
    ConnectorId: string;
}
export type HealthIssueCode = "AUTHENTICATION_FAILURE" | "STREAM_AUTHORIZATION_FAILURE" | "DISCOVERY_FAILURE" | "STREAM_LIMIT_EXCEEDED" | "STREAM_DISCONNECTED" | "RECORDING_FAILURE" | "NO_HEALTH_DATA" | (string & {});
export interface HealthIssue {
    Code?: HealthIssueCode | undefined;
    Message?: string | undefined;
}
export type HealthIssueList = HealthIssue[];
export interface CspmHealthCheck {
    ConnectorStatus?: CspmConnectorStatus | undefined;
    Message?: string | undefined;
    LastCheckedAt?: Date | undefined;
    Issues?: HealthIssue[] | undefined;
}
export interface AzureDetail {
    AWSConfigConnectorArn?: string | undefined;
    ScopeConfiguration?: AzureScopeConfiguration | undefined;
    AzureRegions?: string[] | undefined;
}
export type CspmProviderDetail = {
    Azure: AzureDetail;
};
export interface GetConnectorResponse {
    ConnectorArn?: string | undefined;
    ConnectorId: string;
    Name: string;
    Description?: string | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Health: CspmHealthCheck & {
        ConnectorStatus: CspmConnectorStatus;
        LastCheckedAt: Date;
        Issues: (HealthIssue & {
            Code: HealthIssueCode;
            Message: NonEmptyString;
        })[];
    };
    ProviderDetail: CspmProviderDetail;
    CreatedBy?: string | undefined;
    EnablementStatus?: CspmEnablementStatus | undefined;
}
export interface GetConnectorV2Request {
    ConnectorId: string;
}
export interface HealthCheck {
    ConnectorStatus?: ConnectorStatus | undefined;
    Message?: string | undefined;
    LastCheckedAt?: Date | undefined;
    Issues?: HealthIssue[] | undefined;
}
export type ConnectorAuthStatus = "ACTIVE" | "FAILED" | (string & {});
export interface JiraCloudDetail {
    CloudId?: string | undefined;
    ProjectKey?: string | undefined;
    Domain?: string | undefined;
    AuthUrl?: string | undefined;
    AuthStatus?: ConnectorAuthStatus | undefined;
}
export interface ServiceNowDetail {
    InstanceName?: string | undefined;
    SecretArn?: string | undefined;
    AuthStatus?: ConnectorAuthStatus | undefined;
}
export type ProviderDetail = {
    JiraCloud: JiraCloudDetail;
    ServiceNow?: undefined;
    Azure?: undefined;
} | {
    JiraCloud?: undefined;
    ServiceNow: ServiceNowDetail;
    Azure?: undefined;
} | {
    JiraCloud?: undefined;
    ServiceNow?: undefined;
    Azure: AzureDetail;
};
export interface GetConnectorV2Response {
    ConnectorArn?: string | undefined;
    ConnectorId: string;
    Name: string;
    Description?: string | undefined;
    KmsKeyArn?: string | undefined;
    CreatedAt: Date;
    LastUpdatedAt: Date;
    Health: HealthCheck & {
        ConnectorStatus: ConnectorStatus;
        LastCheckedAt: Date;
        Issues: (HealthIssue & {
            Code: HealthIssueCode;
            Message: NonEmptyString;
        })[];
    };
    ProviderDetail: ProviderDetail;
    EnablementStatus?: EnablementStatus | undefined;
    EnablementStatusReason?: string | undefined;
}
export interface GetEnabledStandardsRequest {
    StandardsSubscriptionArns?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Providers?: StandardsProvider[] | undefined;
}
export interface GetEnabledStandardsResponse {
    StandardsSubscriptions?: (StandardsSubscription & {
        StandardsSubscriptionArn: NonEmptyString;
        StandardsArn: NonEmptyString;
        StandardsInput: StandardsInputParameterMap;
        StandardsStatus: StandardsStatus;
        StandardsStatusReason: StandardsStatusReason & {
            StatusReasonCode: StatusReasonCode;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export interface GetExportJobV2Request {
    ExportJobId: string;
}
export type ExportName = string;
export type ExportDataType = "FINDINGS" | (string & {});
export type FindingsExportFormat = "CSV" | "OCSF_JSON" | (string & {});
export type FindingsSelectableField = "metadata.uid" | "activity_name" | "cloud.account.name" | "cloud.account.uid" | "cloud.provider" | "cloud.region" | "compliance.assessments.category" | "compliance.assessments.name" | "compliance.control" | "compliance.status" | "compliance.standards" | "finding_info.desc" | "finding_info.src_url" | "finding_info.title" | "finding_info.types" | "finding_info.uid" | "finding_info.related_events.traits.category" | "finding_info.related_events.uid" | "finding_info.related_events.product.uid" | "finding_info.related_events.title" | "metadata.product.feature.uid" | "metadata.product.name" | "metadata.product.uid" | "metadata.product.vendor_name" | "remediation.desc" | "remediation.references" | "resources.cloud_partition" | "resources.name" | "resources.owner.account.uid" | "resources.owner.org.uid" | "resources.owner.account.name" | "resources.provider" | "resources.region" | "resources.type" | "resources.uid" | "severity" | "status" | "comment" | "vulnerabilities.fix_coverage" | "class_name" | "databucket.encryption_details.algorithm" | "databucket.encryption_details.key_uid" | "databucket.file.data_classifications.classifier_details.type" | "evidences.actor.user.account.uid" | "evidences.api.operation" | "evidences.api.response.error_message" | "evidences.api.service.name" | "evidences.connection_info.direction" | "evidences.connection_info.protocol_name" | "evidences.dst_endpoint.autonomous_system.name" | "evidences.dst_endpoint.location.city" | "evidences.dst_endpoint.location.country" | "evidences.src_endpoint.autonomous_system.name" | "evidences.src_endpoint.hostname" | "evidences.src_endpoint.location.city" | "evidences.src_endpoint.location.country" | "finding_info.analytic.name" | "malware.name" | "malware_scan_info.uid" | "malware.severity" | "resources.cloud_function.layers.uid_alt" | "resources.cloud_function.runtime" | "resources.cloud_function.user.uid" | "resources.device.encryption_details.key_uid" | "resources.device.image.uid" | "resources.image.architecture" | "resources.image.registry_uid" | "resources.image.repository_name" | "resources.image.uid" | "resources.subnet_info.uid" | "resources.vpc_uid" | "vulnerabilities.affected_code.file.path" | "vulnerabilities.affected_packages.name" | "vulnerabilities.cve.cvss.vendor_name" | "vulnerabilities.cve.cvss.version" | "vulnerabilities.cve.epss.score" | "vulnerabilities.cve.uid" | "vulnerabilities.related_vulnerabilities" | "vendor_attributes.severity" | "activity_id" | "compliance.status_id" | "confidence_score" | "severity_id" | "status_id" | "finding_info.related_events_count" | "evidences.api.response.code" | "evidences.dst_endpoint.autonomous_system.number" | "evidences.dst_endpoint.port" | "evidences.src_endpoint.autonomous_system.number" | "evidences.src_endpoint.port" | "resources.image.in_use_count" | "vulnerabilities.cve.cvss.base_score" | "vendor_attributes.severity_id" | "finding_info.created_time_dt" | "finding_info.first_seen_time_dt" | "finding_info.last_seen_time_dt" | "finding_info.modified_time_dt" | "resources.image.created_time_dt" | "resources.image.last_used_time_dt" | "resources.modified_time_dt" | "compliance.assessments.meets_criteria" | "vulnerabilities.is_exploit_available" | "vulnerabilities.is_fix_available" | "resources.tags" | "compliance.control_parameters" | "databucket.tags" | "finding_info.tags" | "evidences.dst_endpoint.ip" | "evidences.src_endpoint.ip" | (string & {});
export type FindingsSelectedFieldList = FindingsSelectableField[];
export interface FindingsOutput {
    Format?: FindingsExportFormat | undefined;
    Filters?: OcsfFindingFilters | undefined;
    SelectedFields?: FindingsSelectableField[] | undefined;
}
export type ExportOutput = {
    Findings: FindingsOutput;
};
export interface AwsOrganizationScope {
    OrganizationId?: string | undefined;
    OrganizationalUnitId?: string | undefined;
}
export type AwsOrganizationScopeList = AwsOrganizationScope[];
export interface ExportScopes {
    AwsOrganizations?: AwsOrganizationScope[] | undefined;
}
export type S3ObjectPrefix = string;
export interface S3ExportDestination {
    BucketArn?: string | undefined;
    KmsKeyArn?: string | undefined;
    ObjectPrefix?: string | undefined;
}
export type ExportDestination = {
    S3: S3ExportDestination;
};
export type ExportFailureCode = "ACCESS_DENIED" | "RESOURCE_NOT_FOUND" | "INTERNAL_ERROR" | (string & {});
export interface GetExportJobV2Response {
    ExportJobId: string;
    Name?: string | undefined;
    Status: ExportStatus;
    DataType: ExportDataType;
    OutputConfiguration?: ExportOutput | undefined;
    Scopes?: ExportScopes | undefined;
    Destination: ExportDestination;
    FailureCode?: ExportFailureCode | undefined;
    FailureMessage?: string | undefined;
    StartedAt: Date;
    EndedAt?: Date | undefined;
}
export interface GetFindingAggregatorRequest {
    FindingAggregatorArn: string;
}
export interface GetFindingAggregatorResponse {
    FindingAggregatorArn?: string | undefined;
    FindingAggregationRegion?: string | undefined;
    RegionLinkingMode?: string | undefined;
    Regions?: string[] | undefined;
}
export interface GetFindingHistoryRequest {
    FindingIdentifier?: AwsSecurityFindingIdentifier | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type FindingHistoryUpdateSourceType = "BATCH_UPDATE_FINDINGS" | "BATCH_IMPORT_FINDINGS" | (string & {});
export interface FindingHistoryUpdateSource {
    Type?: FindingHistoryUpdateSourceType | undefined;
    Identity?: string | undefined;
}
export interface FindingHistoryUpdate {
    UpdatedField?: string | undefined;
    OldValue?: string | undefined;
    NewValue?: string | undefined;
}
export type FindingHistoryUpdatesList = FindingHistoryUpdate[];
export interface FindingHistoryRecord {
    FindingIdentifier?: AwsSecurityFindingIdentifier | undefined;
    UpdateTime?: Date | undefined;
    FindingCreated?: boolean | undefined;
    UpdateSource?: FindingHistoryUpdateSource | undefined;
    Updates?: FindingHistoryUpdate[] | undefined;
    NextToken?: string | undefined;
}
export type FindingHistoryRecordList = FindingHistoryRecord[];
export interface GetFindingHistoryResponse {
    Records?: (FindingHistoryRecord & {
        FindingIdentifier: AwsSecurityFindingIdentifier & {
            Id: NonEmptyString;
            ProductArn: NonEmptyString;
        };
    })[] | undefined;
    NextToken?: string | undefined;
}
export type SortOrder = "asc" | "desc" | (string & {});
export interface SortCriterion {
    Field?: string | undefined;
    SortOrder?: SortOrder | undefined;
}
export type SortCriteria = SortCriterion[];
export interface GetFindingsRequest {
    Filters?: AwsSecurityFindingFilters | undefined;
    SortCriteria?: SortCriterion[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type AwsSecurityFindingList = AwsSecurityFinding[];
export interface GetFindingsResponse {
    Findings: (AwsSecurityFinding & {
        SchemaVersion: NonEmptyString;
        Id: NonEmptyString;
        ProductArn: NonEmptyString;
        GeneratorId: NonEmptyString;
        AwsAccountId: NonEmptyString;
        CreatedAt: NonEmptyString;
        UpdatedAt: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        Resources: (Resource & {
            Type: NonEmptyString;
            Id: NonEmptyString;
        })[];
        Malware: (Malware & {
            Name: NonEmptyString;
        })[];
        Compliance: Compliance & {
            StatusReasons: (StatusReason & {
                ReasonCode: NonEmptyString;
            })[];
        };
        RelatedFindings: (RelatedFinding & {
            ProductArn: NonEmptyString;
            Id: NonEmptyString;
        })[];
        Note: Note & {
            Text: NonEmptyString;
            UpdatedBy: NonEmptyString;
            UpdatedAt: NonEmptyString;
        };
        Vulnerabilities: (Vulnerability & {
            Id: NonEmptyString;
            Vendor: VulnerabilityVendor & {
                Name: NonEmptyString;
            };
        })[];
        PatchSummary: PatchSummary & {
            Id: NonEmptyString;
        };
        FindingProviderFields: FindingProviderFields & {
            RelatedFindings: (RelatedFinding & {
                ProductArn: NonEmptyString;
                Id: NonEmptyString;
            })[];
        };
    })[];
    NextToken?: string | undefined;
}
export type GroupByField = "activity_name" | "cloud.account.uid" | "cloud.provider" | "cloud.region" | "compliance.assessments.name" | "compliance.status" | "compliance.control" | "finding_info.title" | "finding_info.related_events.traits.category" | "finding_info.types" | "impact" | "likelihood" | "metadata.product.name" | "metadata.product.uid" | "resources.type" | "resources.cloud_partition" | "resources.criticality" | "resources.name" | "resources.owner.account.uid" | "resources.owner.org.uid" | "resources.owner.account.name" | "resources.provider" | "resources.region" | "resources.uid" | "severity" | "status" | "vulnerabilities.fix_coverage" | "class_name" | "vulnerabilities.affected_packages.name" | "finding_info.analytic.name" | "compliance.standards" | "cloud.account.name" | "vendor_attributes.severity" | "metadata.product.vendor_name" | (string & {});
export interface GroupByRule {
    Filters?: OcsfFindingFilters | undefined;
    GroupByField?: GroupByField | undefined;
}
export type GroupByRules = GroupByRule[];
export interface FindingScopes {
    AwsOrganizations?: AwsOrganizationScope[] | undefined;
}
export type MaxStatisticResults = number;
export interface GetFindingStatisticsV2Request {
    GroupByRules?: GroupByRule[] | undefined;
    Scopes?: FindingScopes | undefined;
    SortOrder?: SortOrder | undefined;
    MaxStatisticResults?: number | undefined;
}
export interface GroupByValue {
    FieldValue?: string | undefined;
    Count?: number | undefined;
}
export type GroupByValues = GroupByValue[];
export interface GroupByResult {
    GroupByField?: string | undefined;
    GroupByValues?: GroupByValue[] | undefined;
}
export type GroupByResults = GroupByResult[];
export interface GetFindingStatisticsV2Response {
    GroupByResults?: GroupByResult[] | undefined;
}
export type FindingsTrendsStringField = "account_id" | "region" | "finding_types" | "finding_status" | "finding_cve_ids" | "finding_compliance_status" | "finding_control_id" | "finding_class_name" | "finding_provider" | "finding_activity_name" | "resource_cloud_providers" | "resource_regions" | "resource_owner_ids" | "resource_owner_organization_ids" | (string & {});
export interface FindingsTrendsStringFilter {
    FieldName?: FindingsTrendsStringField | undefined;
    Filter?: StringFilter | undefined;
}
export type FindingsTrendsStringFilterList = FindingsTrendsStringFilter[];
export interface FindingsTrendsCompositeFilter {
    StringFilters?: FindingsTrendsStringFilter[] | undefined;
    NestedCompositeFilters?: FindingsTrendsCompositeFilter[] | undefined;
    Operator?: AllowedOperators | undefined;
}
export type FindingsTrendsCompositeFilterList = FindingsTrendsCompositeFilter[];
export interface FindingsTrendsFilters {
    CompositeFilters?: FindingsTrendsCompositeFilter[] | undefined;
    CompositeOperator?: AllowedOperators | undefined;
}
export interface GetFindingsTrendsV2Request {
    Filters?: FindingsTrendsFilters | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type GranularityField = "Daily" | "Weekly" | "Monthly" | (string & {});
export type TrendsValueCount = number;
export interface SeverityTrendsCount {
    Unknown?: number | undefined;
    Informational?: number | undefined;
    Low?: number | undefined;
    Medium?: number | undefined;
    High?: number | undefined;
    Critical?: number | undefined;
    Fatal?: number | undefined;
    Other?: number | undefined;
}
export interface TrendsValues {
    SeverityTrends?: SeverityTrendsCount | undefined;
}
export interface TrendsMetricsResult {
    Timestamp?: Date | undefined;
    TrendsValues?: TrendsValues | undefined;
}
export type TrendsMetrics = TrendsMetricsResult[];
export interface GetFindingsTrendsV2Response {
    Granularity: GranularityField;
    TrendsMetrics: (TrendsMetricsResult & {
        Timestamp: Date;
        TrendsValues: TrendsValues & {
            SeverityTrends: SeverityTrendsCount & {
                Unknown: TrendsValueCount;
                Informational: TrendsValueCount;
                Low: TrendsValueCount;
                Medium: TrendsValueCount;
                High: TrendsValueCount;
                Critical: TrendsValueCount;
                Fatal: TrendsValueCount;
                Other: TrendsValueCount;
            };
        };
    })[];
    NextToken?: string | undefined;
}
export interface GetFindingsV2Request {
    Filters?: OcsfFindingFilters | undefined;
    Scopes?: FindingScopes | undefined;
    SortCriteria?: SortCriterion[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type OcsfFinding = unknown;
export type OcsfFindingsList = any[];
export interface GetFindingsV2Response {
    Findings?: any[] | undefined;
    NextToken?: string | undefined;
}
export interface GetInsightResultsRequest {
    InsightArn: string;
}
export interface InsightResultValue {
    GroupByAttributeValue?: string | undefined;
    Count?: number | undefined;
}
export type InsightResultValueList = InsightResultValue[];
export interface InsightResults {
    InsightArn?: string | undefined;
    GroupByAttribute?: string | undefined;
    ResultValues?: InsightResultValue[] | undefined;
}
export interface GetInsightResultsResponse {
    InsightResults: InsightResults & {
        InsightArn: NonEmptyString;
        GroupByAttribute: NonEmptyString;
        ResultValues: (InsightResultValue & {
            GroupByAttributeValue: NonEmptyString;
            Count: number;
        })[];
    };
}
export interface GetInsightsRequest {
    InsightArns?: string[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface Insight {
    InsightArn?: string | undefined;
    Name?: string | undefined;
    Filters?: AwsSecurityFindingFilters | undefined;
    GroupByAttribute?: string | undefined;
}
export type InsightList = Insight[];
export interface GetInsightsResponse {
    Insights: (Insight & {
        InsightArn: NonEmptyString;
        Name: NonEmptyString;
        Filters: AwsSecurityFindingFilters;
        GroupByAttribute: NonEmptyString;
    })[];
    NextToken?: string | undefined;
}
export interface GetInvitationsCountRequest {
}
export interface GetInvitationsCountResponse {
    InvitationsCount?: number | undefined;
}
export interface GetMasterAccountRequest {
}
export interface GetMasterAccountResponse {
    Master?: Invitation | undefined;
}
export interface GetMembersRequest {
    AccountIds?: string[] | undefined;
}
export interface Member {
    AccountId?: string | undefined;
    Email?: string | undefined;
    MasterId?: string | undefined;
    AdministratorId?: string | undefined;
    MemberStatus?: string | undefined;
    InvitedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type MemberList = Member[];
export interface GetMembersResponse {
    Members?: Member[] | undefined;
    UnprocessedAccounts?: Result[] | undefined;
}
export interface GetRecommendedPolicyV2Request {
    MetadataUid: string;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type RecommendationType = "UNUSED_PERMISSION_RECOMMENDATION" | (string & {});
export interface UnusedPermissionsRecommendationStep {
    RecommendedAction?: string | undefined;
    ExistingPolicy?: string | undefined;
    ExistingPolicyId?: string | undefined;
    PolicyUpdatedAt?: Date | undefined;
    RecommendedPolicy?: string | undefined;
}
export type RecommendationStep = {
    UnusedPermissions: UnusedPermissionsRecommendationStep;
};
export type RecommendationSteps = RecommendationStep[];
export interface RecommendationError {
    Code?: string | undefined;
    Message?: string | undefined;
}
export type RecommendationStatus = "IN_PROGRESS" | "SUCCEEDED" | "FAILED" | (string & {});
export interface GetRecommendedPolicyV2Response {
    NextToken?: string | undefined;
    RecommendationType?: RecommendationType | undefined;
    RecommendationSteps?: RecommendationStep[] | undefined;
    Error?: RecommendationError | undefined;
    Status?: RecommendationStatus | undefined;
    ResourceArn?: string | undefined;
}
export type RemediationStringUid = string;
export type RemediationStringField = "Resource.Type" | "Priority" | "Status" | "Resource.Id" | "Resource.ResourceOwnerAccountId" | "Resource.CloudProvider" | (string & {});
export interface RemediationStringFilterCondition {
    Value?: string | undefined;
}
export interface RemediationStringFilter {
    FieldName?: RemediationStringField | undefined;
    Filter?: RemediationStringFilterCondition | undefined;
}
export type RemediationStringFilterList = RemediationStringFilter[];
export interface RemediationCompositeFilter {
    StringFilters?: RemediationStringFilter[] | undefined;
}
export type RemediationCompositeFilterList = RemediationCompositeFilter[];
export interface RemediationFilters {
    CompositeFilters?: RemediationCompositeFilter[] | undefined;
}
export type GuidanceFormat = "All" | "AwsCli" | "Cli" | "Python" | "Terraform" | "Cdk" | "CloudFormation" | "IaC" | "Template" | (string & {});
export interface GetRemediationsV2Request {
    TargetUid?: string | undefined;
    MetadataUid?: string | undefined;
    Filters?: RemediationFilters | undefined;
    ShowGuidance?: boolean | undefined;
    GuidanceFormat?: GuidanceFormat | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface RemediationOutcome {
    ResolvedFindingsCount?: number | undefined;
    SeverityReductionFindingsCount?: number | undefined;
    SeverityUnchangedCount?: number | undefined;
}
export type RemediationPriority = "Critical" | "High" | "Medium" | "Low" | (string & {});
export type RemediationStringList = string[];
export interface KbArticle {
    Title?: string | undefined;
    Url?: string | undefined;
}
export type KbArticleList = KbArticle[];
export interface RemediationSummaryDetail {
    Action?: string | undefined;
    Description?: string | undefined;
    IsImmediate?: boolean | undefined;
    PostRemediationSteps?: string[] | undefined;
    KbArticles?: KbArticle[] | undefined;
}
export interface RemediationResource {
    AccountId?: string | undefined;
    Region?: string | undefined;
    ResourceOwnerAccountId?: string | undefined;
    ResourceOwnerOrgId?: string | undefined;
    Type?: string | undefined;
    Name?: string | undefined;
    Id?: string | undefined;
    ResourceGuid?: string | undefined;
    ResourceRegion?: string | undefined;
    CloudProvider?: CloudProviderName | undefined;
}
export type RemediationStatus = "New" | "Updated" | "Resolved" | (string & {});
export interface RemediationTrait {
    Type?: string | undefined;
    Title?: string | undefined;
}
export interface RemediationGuidanceContext {
    ProblemStatement?: string | undefined;
    RiskAssessment?: string | undefined;
    AffectedScope?: string | undefined;
    Prerequisites?: string[] | undefined;
}
export interface RemediationParameter {
    Name?: string | undefined;
    Type?: string | undefined;
    Description?: string | undefined;
    Required?: boolean | undefined;
}
export type RemediationParameterList = RemediationParameter[];
export interface RemediationStep {
    Phase?: string | undefined;
    Description?: string | undefined;
    Service?: string | undefined;
    Action?: string | undefined;
    Logic?: string | undefined;
    Inverse?: string | undefined;
    VerifyAfter?: string | undefined;
}
export type RemediationStepList = RemediationStep[];
export interface RemediationGuidanceSpecification {
    Parameters?: RemediationParameter[] | undefined;
    Steps?: RemediationStep[] | undefined;
    ExpectedEndState?: string | undefined;
    RequiredPermissions?: string[] | undefined;
}
export interface RemediationGuidanceExamples {
    AwsCli?: string | undefined;
    Cli?: string | undefined;
    Python?: string | undefined;
    Terraform?: string | undefined;
    Cdk?: string | undefined;
    CloudFormation?: string | undefined;
    IaC?: string | undefined;
    Template?: string | undefined;
}
export interface RemediationGuidanceMetadata {
    ResourceType?: string | undefined;
    ExposureType?: string | undefined;
    TraitTitles?: string[] | undefined;
    Reversibility?: string | undefined;
    FixEffect?: string | undefined;
    RiskLevel?: string | undefined;
    AutomationLevel?: string | undefined;
    HumanReviewRequired?: boolean | undefined;
    GeneratedAt?: Date | undefined;
    VerificationStatus?: string | undefined;
}
export interface RemediationGuidance {
    TargetTypeName?: string | undefined;
    Pattern?: string | undefined;
    Version?: string | undefined;
    Context?: RemediationGuidanceContext | undefined;
    Specification?: RemediationGuidanceSpecification | undefined;
    Examples?: RemediationGuidanceExamples | undefined;
    Metadata?: RemediationGuidanceMetadata | undefined;
}
export interface RemediationV2Item {
    TargetUid?: string | undefined;
    Outcome?: RemediationOutcome | undefined;
    Priority?: RemediationPriority | undefined;
    RemediationSummary?: RemediationSummaryDetail | undefined;
    Resource?: RemediationResource | undefined;
    Status?: RemediationStatus | undefined;
    Trait?: RemediationTrait | undefined;
    Guidance?: RemediationGuidance | undefined;
    UpdatedAt?: Date | undefined;
}
export type RemediationV2ItemList = RemediationV2Item[];
export interface GetRemediationsV2Response {
    Items: (RemediationV2Item & {
        TargetUid: NonEmptyString;
        Outcome: RemediationOutcome & {
            ResolvedFindingsCount: number;
            SeverityReductionFindingsCount: number;
            SeverityUnchangedCount: number;
        };
        Priority: RemediationPriority;
        RemediationSummary: RemediationSummaryDetail & {
            Action: NonEmptyString;
            IsImmediate: boolean;
            KbArticles: (KbArticle & {
                Title: NonEmptyString;
                Url: NonEmptyString;
            })[];
        };
        Resource: RemediationResource & {
            AccountId: NonEmptyString;
            Region: NonEmptyString;
            Type: NonEmptyString;
            Id: NonEmptyString;
            ResourceRegion: NonEmptyString;
            CloudProvider: CloudProviderName;
        };
        Status: RemediationStatus;
        Trait: RemediationTrait & {
            Type: NonEmptyString;
            Title: NonEmptyString;
        };
        Guidance: RemediationGuidance & {
            TargetTypeName: NonEmptyString;
            Pattern: NonEmptyString;
            Version: NonEmptyString;
            Context: RemediationGuidanceContext;
            Specification: RemediationGuidanceSpecification & {
                Parameters: (RemediationParameter & {
                    Name: NonEmptyString;
                    Type: NonEmptyString;
                    Description: NonEmptyString;
                })[];
                Steps: (RemediationStep & {
                    Phase: NonEmptyString;
                    Description: NonEmptyString;
                    Service: NonEmptyString;
                    Action: NonEmptyString;
                })[];
            };
            Examples: RemediationGuidanceExamples;
            Metadata: RemediationGuidanceMetadata & {
                ResourceType: NonEmptyString;
                ExposureType: NonEmptyString;
                TraitTitles: RemediationStringList;
                Reversibility: NonEmptyString;
                FixEffect: NonEmptyString;
                RiskLevel: NonEmptyString;
            };
        };
    })[];
    NextToken?: string | undefined;
}
export type ResourceGroupByField = "AccountId" | "AccountName" | "Region" | "ResourceProvider" | "ResourceOwnerAccountId" | "ResourceOwnerOrgId" | "ResourceCloudPartition" | "ResourceRegion" | "ResourceCategory" | "ResourceType" | "ResourceName" | "FindingsSummary.FindingType" | "ResourceSubCategory" | "DiscoveryType" | "ResourceInfo.AIDetails.HostResourceType" | "ResourceInfo.AIDetails.CanonicalId" | "ResourceCriticality" | (string & {});
export interface ResourceGroupByRule {
    GroupByField?: ResourceGroupByField | undefined;
    Filters?: ResourcesFilters | undefined;
}
export type ResourceGroupByRules = ResourceGroupByRule[];
export interface ResourceScopes {
    AwsOrganizations?: AwsOrganizationScope[] | undefined;
}
export interface GetResourcesStatisticsV2Request {
    GroupByRules?: ResourceGroupByRule[] | undefined;
    Scopes?: ResourceScopes | undefined;
    SortOrder?: SortOrder | undefined;
    MaxStatisticResults?: number | undefined;
}
export interface GetResourcesStatisticsV2Response {
    GroupByResults: GroupByResult[];
}
export type ResourcesTrendsStringField = "account_id" | "region" | "resource_type" | "resource_category" | "resource_cloud_provider" | "resource_region" | "resource_owner_id" | "resource_owner_organization_id" | (string & {});
export interface ResourcesTrendsStringFilter {
    FieldName?: ResourcesTrendsStringField | undefined;
    Filter?: StringFilter | undefined;
}
export type ResourcesTrendsStringFilterList = ResourcesTrendsStringFilter[];
export interface ResourcesTrendsCompositeFilter {
    StringFilters?: ResourcesTrendsStringFilter[] | undefined;
    NestedCompositeFilters?: ResourcesTrendsCompositeFilter[] | undefined;
    Operator?: AllowedOperators | undefined;
}
export type ResourcesTrendsCompositeFilterList = ResourcesTrendsCompositeFilter[];
export interface ResourcesTrendsFilters {
    CompositeFilters?: ResourcesTrendsCompositeFilter[] | undefined;
    CompositeOperator?: AllowedOperators | undefined;
}
export interface GetResourcesTrendsV2Request {
    Filters?: ResourcesTrendsFilters | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ResourcesCount {
    AllResources?: number | undefined;
}
export interface ResourcesTrendsValues {
    ResourcesCount?: ResourcesCount | undefined;
}
export interface ResourcesTrendsMetricsResult {
    Timestamp?: Date | undefined;
    TrendsValues?: ResourcesTrendsValues | undefined;
}
export type ResourcesTrendsMetrics = ResourcesTrendsMetricsResult[];
export interface GetResourcesTrendsV2Response {
    Granularity: GranularityField;
    TrendsMetrics: (ResourcesTrendsMetricsResult & {
        Timestamp: Date;
        TrendsValues: ResourcesTrendsValues & {
            ResourcesCount: ResourcesCount & {
                AllResources: TrendsValueCount;
            };
        };
    })[];
    NextToken?: string | undefined;
}
export interface GetResourcesV2Request {
    Filters?: ResourcesFilters | undefined;
    Scopes?: ResourceScopes | undefined;
    SortCriteria?: SortCriterion[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ResourceCategory = "Compute" | "Database" | "Storage" | "Code" | "AI/ML" | "Identity" | "Network" | "Messaging" | "Other" | (string & {});
export interface ResourceSeverityBreakdown {
    Other?: number | undefined;
    Fatal?: number | undefined;
    Critical?: number | undefined;
    High?: number | undefined;
    Medium?: number | undefined;
    Low?: number | undefined;
    Informational?: number | undefined;
    Unknown?: number | undefined;
}
export interface ResourceFindingsSummary {
    FindingType?: string | undefined;
    ProductName?: string | undefined;
    TotalFindings?: number | undefined;
    Severities?: ResourceSeverityBreakdown | undefined;
}
export type ResourceFindingsSummaryList = ResourceFindingsSummary[];
export interface ResourceTag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type ResourceTagList = ResourceTag[];
export type ResourceConfig = unknown;
export type ResourceSubCategory = "Model" | "ModelServing" | "Agent" | "AgentFramework" | "AgentToolsAndIdentity" | "SafetyAndGuardrail" | "KnowledgeAndData" | "OrchestrationAndPipeline" | "ExternalEndpoint" | "Development" | "Other" | (string & {});
export type DiscoveryType = "Managed" | "SelfHosted" | (string & {});
export interface AIDetails {
    HostResourceGuid?: string | undefined;
    HostResourceType?: string | undefined;
    CanonicalId?: string | undefined;
    SelfHostedAIModelResourceCount?: number | undefined;
    SelfHostedAIAgentResourceCount?: number | undefined;
    SelfHostedAIModelServingResourceCount?: number | undefined;
    SelfHostedAIExternalEndpointResourceCount?: number | undefined;
    SelfHostedAIDevelopmentResourceCount?: number | undefined;
    SelfHostedAIAgentFrameworkResourceCount?: number | undefined;
    SelfHostedAIAgentToolsAndIdentityResourceCount?: number | undefined;
    SelfHostedTotalAIResourceCount?: number | undefined;
}
export interface ResourceInfo {
    AIDetails?: AIDetails | undefined;
}
export type CriticalitySourceType = "AutomationRule" | "ResourceName" | "TagInference" | (string & {});
export interface CriticalitySource {
    Source?: CriticalitySourceType | undefined;
    Reason?: string | undefined;
}
export type CriticalitySourceList = CriticalitySource[];
export interface ResourceResult {
    ResourceGuid?: string | undefined;
    ResourceId?: string | undefined;
    AccountId?: string | undefined;
    AccountName?: string | undefined;
    Region?: string | undefined;
    ResourceProvider?: string | undefined;
    ResourceOwnerAccountId?: string | undefined;
    ResourceOwnerOrgId?: string | undefined;
    ResourceCloudPartition?: string | undefined;
    ResourceRegion?: string | undefined;
    ResourceCategory?: ResourceCategory | undefined;
    ResourceType?: string | undefined;
    ResourceName?: string | undefined;
    ResourceCreationTimeDt?: string | undefined;
    ResourceDetailCaptureTimeDt?: string | undefined;
    FindingsSummary?: ResourceFindingsSummary[] | undefined;
    ResourceTags?: ResourceTag[] | undefined;
    ResourceConfig?: any | undefined;
    ResourceSubCategory?: ResourceSubCategory | undefined;
    DiscoveryType?: DiscoveryType | undefined;
    ResourceInfo?: ResourceInfo | undefined;
    ResourceCriticality?: ResourceCriticality | undefined;
    CriticalitySources?: CriticalitySource[] | undefined;
}
export type Resources = ResourceResult[];
export interface GetResourcesV2Response {
    Resources: (ResourceResult & {
        ResourceId: NonEmptyString;
        AccountId: NonEmptyString;
        Region: NonEmptyString;
        ResourceType: NonEmptyString;
        ResourceDetailCaptureTimeDt: NonEmptyString;
        ResourceConfig: ResourceConfig;
        FindingsSummary: (ResourceFindingsSummary & {
            FindingType: NonEmptyString;
            ProductName: NonEmptyString;
            TotalFindings: number;
        })[];
        ResourceTags: (ResourceTag & {
            Key: NonEmptyString;
            Value: NonEmptyString;
        })[];
        CriticalitySources: (CriticalitySource & {
            Source: CriticalitySourceType;
            Reason: NonEmptyString;
        })[];
    })[];
    NextToken?: string | undefined;
}
export interface GetSecurityControlDefinitionRequest {
    SecurityControlId?: string | undefined;
}
export type RegionAvailabilityStatus = "AVAILABLE" | "UNAVAILABLE" | (string & {});
export type SecurityControlProperty = "Parameters" | (string & {});
export type CustomizableProperties = SecurityControlProperty[];
export interface IntegerConfigurationOptions {
    DefaultValue?: number | undefined;
    Min?: number | undefined;
    Max?: number | undefined;
}
export interface IntegerListConfigurationOptions {
    DefaultValue?: number[] | undefined;
    Min?: number | undefined;
    Max?: number | undefined;
    MaxItems?: number | undefined;
}
export interface DoubleConfigurationOptions {
    DefaultValue?: number | undefined;
    Min?: number | undefined;
    Max?: number | undefined;
}
export interface StringConfigurationOptions {
    DefaultValue?: string | undefined;
    Re2Expression?: string | undefined;
    ExpressionDescription?: string | undefined;
}
export interface StringListConfigurationOptions {
    DefaultValue?: string[] | undefined;
    Re2Expression?: string | undefined;
    MaxItems?: number | undefined;
    ExpressionDescription?: string | undefined;
}
export interface BooleanConfigurationOptions {
    DefaultValue?: boolean | undefined;
}
export interface EnumConfigurationOptions {
    DefaultValue?: string | undefined;
    AllowedValues?: string[] | undefined;
}
export interface EnumListConfigurationOptions {
    DefaultValue?: string[] | undefined;
    MaxItems?: number | undefined;
    AllowedValues?: string[] | undefined;
}
export type ConfigurationOptions = {
    Integer: IntegerConfigurationOptions;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList: IntegerListConfigurationOptions;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double: DoubleConfigurationOptions;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String: StringConfigurationOptions;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList: StringListConfigurationOptions;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean: BooleanConfigurationOptions;
    Enum?: undefined;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum: EnumConfigurationOptions;
    EnumList?: undefined;
} | {
    Integer?: undefined;
    IntegerList?: undefined;
    Double?: undefined;
    String?: undefined;
    StringList?: undefined;
    Boolean?: undefined;
    Enum?: undefined;
    EnumList: EnumListConfigurationOptions;
};
export interface ParameterDefinition {
    Description?: string | undefined;
    ConfigurationOptions?: ConfigurationOptions | undefined;
}
export type ParameterDefinitions = {
    [key: string]: ParameterDefinition | undefined;
};
export interface SecurityControlDefinition {
    SecurityControlId?: string | undefined;
    Title?: string | undefined;
    Description?: string | undefined;
    RemediationUrl?: string | undefined;
    SeverityRating?: SeverityRating | undefined;
    CurrentRegionAvailability?: RegionAvailabilityStatus | undefined;
    CustomizableProperties?: SecurityControlProperty[] | undefined;
    ParameterDefinitions?: {
        [key: string]: ParameterDefinition | undefined;
    } | undefined;
    Provider?: SecurityControlsProvider | undefined;
}
export interface GetSecurityControlDefinitionResponse {
    SecurityControlDefinition: SecurityControlDefinition & {
        SecurityControlId: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        RemediationUrl: NonEmptyString;
        SeverityRating: SeverityRating;
        CurrentRegionAvailability: RegionAvailabilityStatus;
        ParameterDefinitions: {
            [key: string]: (ParameterDefinition & {
                Description: NonEmptyString;
                ConfigurationOptions: ConfigurationOptions;
            }) | undefined;
        };
    };
}
export type SoftwareStringField = "AccountId" | "PackageName" | "PackageVersion" | "PackageType" | "Region" | "ResourceRegion" | "ResourceType" | "ResourceId" | "ResourceProvider" | "ResourceOwnerAccountId" | "ResourceOwnerOrgId" | "ResourceCloudPartition" | (string & {});
export interface SoftwareStringFilter {
    FieldName?: SoftwareStringField | undefined;
    Filter?: StringFilter | undefined;
}
export type SoftwareStringFilterList = SoftwareStringFilter[];
export interface SoftwareCompositeFilter {
    StringFilters?: SoftwareStringFilter[] | undefined;
    NestedCompositeFilters?: SoftwareCompositeFilter[] | undefined;
    Operator?: AllowedOperators | undefined;
}
export type SoftwareCompositeFilterList = SoftwareCompositeFilter[];
export interface SoftwareFilters {
    CompositeFilters?: SoftwareCompositeFilter[] | undefined;
    CompositeOperator?: AllowedOperators | undefined;
}
export interface SoftwareScopes {
    AwsOrganizations?: AwsOrganizationScope[] | undefined;
}
export interface GetSoftwareResourcesV2Request {
    PackageName?: string | undefined;
    PackageType?: string | undefined;
    PackageVersion?: string | undefined;
    Filters?: SoftwareFilters | undefined;
    Scopes?: SoftwareScopes | undefined;
    SortCriteria?: SortCriterion[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SoftwareResourceResult {
    AccountId?: string | undefined;
    ResourceType?: string | undefined;
    Region?: string | undefined;
    ResourceId?: string | undefined;
    ResourceProvider?: string | undefined;
    ResourceOwnerOrgId?: string | undefined;
    ResourceOwnerAccountId?: string | undefined;
    ResourceCloudPartition?: string | undefined;
    ResourceRegion?: string | undefined;
}
export type SoftwareResourceResultList = SoftwareResourceResult[];
export interface GetSoftwareResourcesV2Response {
    SoftwareResources: (SoftwareResourceResult & {
        AccountId: NonEmptyString;
        ResourceType: NonEmptyString;
        Region: NonEmptyString;
        ResourceId: NonEmptyString;
    })[];
    NextToken?: string | undefined;
}
export type SoftwareGroupByField = "AccountId" | "PackageName" | "PackageVersion" | "PackageType" | "Region" | "ResourceRegion" | "ResourceType" | "ResourceId" | "ResourceProvider" | "ResourceOwnerAccountId" | "ResourceOwnerOrgId" | "ResourceCloudPartition" | (string & {});
export interface SoftwareGroupByRule {
    GroupByField?: SoftwareGroupByField | undefined;
    Filters?: SoftwareFilters | undefined;
}
export type SoftwareGroupByRules = SoftwareGroupByRule[];
export interface GetSoftwareStatisticsV2Request {
    GroupByRules?: SoftwareGroupByRule[] | undefined;
    Scopes?: SoftwareScopes | undefined;
    SortOrder?: SortOrder | undefined;
    MaxStatisticResults?: number | undefined;
}
export interface GetSoftwareStatisticsV2Response {
    GroupByResults: GroupByResult[];
}
export interface GetSoftwareV2Request {
    Filters?: SoftwareFilters | undefined;
    Scopes?: SoftwareScopes | undefined;
    SortCriteria?: SortCriterion[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SoftwareResult {
    PackageName?: string | undefined;
    PackageVersion?: string | undefined;
    PackageType?: string | undefined;
    ResourceCount?: number | undefined;
}
export type SoftwareList = SoftwareResult[];
export interface GetSoftwareV2Response {
    Software: (SoftwareResult & {
        PackageName: NonEmptyString;
        PackageType: NonEmptyString;
        ResourceCount: number;
    })[];
    NextToken?: string | undefined;
}
export interface InviteMembersRequest {
    AccountIds?: string[] | undefined;
}
export interface InviteMembersResponse {
    UnprocessedAccounts?: Result[] | undefined;
}
export interface ListAggregatorsV2Request {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AggregatorV2 {
    AggregatorV2Arn?: string | undefined;
}
export type AggregatorV2List = AggregatorV2[];
export interface ListAggregatorsV2Response {
    AggregatorsV2?: AggregatorV2[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAutomationRulesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AutomationRulesMetadata {
    RuleArn?: string | undefined;
    RuleStatus?: RuleStatus | undefined;
    RuleOrder?: number | undefined;
    RuleName?: string | undefined;
    Description?: string | undefined;
    IsTerminal?: boolean | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
}
export type AutomationRulesMetadataList = AutomationRulesMetadata[];
export interface ListAutomationRulesResponse {
    AutomationRulesMetadata?: AutomationRulesMetadata[] | undefined;
    NextToken?: string | undefined;
}
export interface ListAutomationRulesV2Request {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface AutomationRulesActionTypeObjectV2 {
    Type?: AutomationRulesActionTypeV2 | undefined;
}
export type AutomationRulesActionTypeListV2 = AutomationRulesActionTypeObjectV2[];
export interface AutomationRulesMetadataV2 {
    RuleArn?: string | undefined;
    RuleId?: string | undefined;
    RuleOrder?: number | undefined;
    RuleName?: string | undefined;
    RuleStatus?: RuleStatusV2 | undefined;
    Description?: string | undefined;
    Actions?: AutomationRulesActionTypeObjectV2[] | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
}
export type AutomationRulesMetadataListV2 = AutomationRulesMetadataV2[];
export interface ListAutomationRulesV2Response {
    Rules?: AutomationRulesMetadataV2[] | undefined;
    NextToken?: string | undefined;
}
export interface ListConfigurationPoliciesRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ConfigurationPolicySummary {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    UpdatedAt?: Date | undefined;
    ServiceEnabled?: boolean | undefined;
}
export type ConfigurationPolicySummaryList = ConfigurationPolicySummary[];
export interface ListConfigurationPoliciesResponse {
    ConfigurationPolicySummaries?: ConfigurationPolicySummary[] | undefined;
    NextToken?: string | undefined;
}
export interface AssociationFilters {
    ConfigurationPolicyId?: string | undefined;
    AssociationType?: AssociationType | undefined;
    AssociationStatus?: ConfigurationPolicyAssociationStatus | undefined;
}
export interface ListConfigurationPolicyAssociationsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Filters?: AssociationFilters | undefined;
}
export type ConfigurationPolicyAssociationSummaryList = ConfigurationPolicyAssociationSummary[];
export interface ListConfigurationPolicyAssociationsResponse {
    ConfigurationPolicyAssociationSummaries?: ConfigurationPolicyAssociationSummary[] | undefined;
    NextToken?: string | undefined;
}
export type CspmConnectorProviderName = "AZURE" | (string & {});
export interface ListConnectorsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ProviderName?: CspmConnectorProviderName | undefined;
    ConnectorStatus?: CspmConnectorStatus | undefined;
    EnablementStatus?: CspmEnablementStatus | undefined;
}
export interface CspmProviderSummary {
    ProviderName?: CspmConnectorProviderName | undefined;
    ConnectorStatus?: CspmConnectorStatus | undefined;
    ProviderConfiguration?: CspmProviderDetail | undefined;
}
export interface CspmConnectorSummary {
    ConnectorArn?: string | undefined;
    ConnectorId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ProviderSummary?: CspmProviderSummary | undefined;
    CreatedAt?: Date | undefined;
    CreatedBy?: string | undefined;
    EnablementStatus?: CspmEnablementStatus | undefined;
}
export type CspmConnectorSummaryList = CspmConnectorSummary[];
export interface ListConnectorsResponse {
    NextToken?: string | undefined;
    Connectors: CspmConnectorSummary[];
}
export type ConnectorProviderName = "JIRA_CLOUD" | "SERVICENOW" | "AZURE" | (string & {});
export interface ListConnectorsV2Request {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    ProviderName?: ConnectorProviderName | undefined;
    ConnectorStatus?: ConnectorStatus | undefined;
    EnablementStatus?: EnablementStatus | undefined;
}
export interface ProviderSummary {
    ProviderName?: ConnectorProviderName | undefined;
    ConnectorStatus?: ConnectorStatus | undefined;
    ProviderConfiguration?: ProviderDetail | undefined;
}
export interface ConnectorSummary {
    ConnectorArn?: string | undefined;
    ConnectorId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    ProviderSummary?: ProviderSummary | undefined;
    CreatedAt?: Date | undefined;
    EnablementStatus?: EnablementStatus | undefined;
    EnablementStatusReason?: string | undefined;
}
export type ConnectorSummaryList = ConnectorSummary[];
export interface ListConnectorsV2Response {
    NextToken?: string | undefined;
    Connectors: (ConnectorSummary & {
        ConnectorId: NonEmptyString;
        Name: NonEmptyString;
        ProviderSummary: ProviderSummary;
        CreatedAt: Date;
    })[];
}
export interface ListEnabledProductsForImportRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type ProductSubscriptionArnList = string[];
export interface ListEnabledProductsForImportResponse {
    ProductSubscriptions?: string[] | undefined;
    NextToken?: string | undefined;
}
export type ExportMaxResults = number;
export interface ListExportJobsV2Request {
    Status?: ExportStatus | undefined;
    DataType?: ExportDataType | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface FindingsOutputSummary {
    Format?: FindingsExportFormat | undefined;
}
export type ExportOutputSummary = {
    Findings: FindingsOutputSummary;
};
export interface ExportSummary {
    ExportJobId?: string | undefined;
    Name?: string | undefined;
    Status?: ExportStatus | undefined;
    DataType?: ExportDataType | undefined;
    OutputConfiguration?: ExportOutputSummary | undefined;
    Scopes?: ExportScopes | undefined;
    Destination?: ExportDestination | undefined;
    FailureCode?: ExportFailureCode | undefined;
    FailureMessage?: string | undefined;
    StartedAt?: Date | undefined;
    EndedAt?: Date | undefined;
}
export type ExportSummaryList = ExportSummary[];
export interface ListExportJobsV2Response {
    Items: (ExportSummary & {
        ExportJobId: ExportJobId;
        Status: ExportStatus;
        DataType: ExportDataType;
        Destination: ExportDestination;
        StartedAt: Date;
    })[];
    NextToken?: string | undefined;
}
export interface ListExposuresByRemediationV2Request {
    TargetUid?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type ExposureSeverity = "Informational" | "Low" | "Medium" | "High" | "Critical" | (string & {});
export type ExposureImpact = "Reduces" | "Resolves" | "Unchanged" | (string & {});
export interface ExposureFinding {
    MetadataUid?: string | undefined;
    Title?: string | undefined;
    PreviousSeverity?: ExposureSeverity | undefined;
    ProjectedSeverity?: ExposureSeverity | undefined;
    Impact?: ExposureImpact | undefined;
}
export type ExposureFindingItemsList = ExposureFinding[];
export interface ListExposuresByRemediationV2Response {
    Items: (ExposureFinding & {
        MetadataUid: NonEmptyString;
        Title: NonEmptyString;
        PreviousSeverity: ExposureSeverity;
        ProjectedSeverity: ExposureSeverity;
        Impact: ExposureImpact;
    })[];
    TargetUid: string;
    Resource: RemediationResource & {
        AccountId: NonEmptyString;
        Region: NonEmptyString;
        Type: NonEmptyString;
        Id: NonEmptyString;
        ResourceRegion: NonEmptyString;
        CloudProvider: CloudProviderName;
    };
    TotalCount: number;
    Trait: RemediationTrait & {
        Type: NonEmptyString;
        Title: NonEmptyString;
    };
    NextToken?: string | undefined;
}
export interface ListFindingAggregatorsRequest {
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface FindingAggregator {
    FindingAggregatorArn?: string | undefined;
}
export type FindingAggregatorList = FindingAggregator[];
export interface ListFindingAggregatorsResponse {
    FindingAggregators?: FindingAggregator[] | undefined;
    NextToken?: string | undefined;
}
export type FreeTrialAccountId = string;
export type FreeTrialAccountIdList = string[];
export type FreeTrialStatusValue = "ACTIVE" | "INACTIVE" | (string & {});
export type FreeTrialStatusValueList = FreeTrialStatusValue[];
export interface ListFreeTrialStatusesV2Request {
    AccountIds?: string[] | undefined;
    Statuses?: FreeTrialStatusValue[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type FreeTrialType = "SECURITY_HUB_V2" | "SECURITY_HUB_V2_MULTI_CLOUD_AZURE" | (string & {});
export interface FreeTrialStatus {
    FeatureType?: FreeTrialType | undefined;
    Status?: FreeTrialStatusValue | undefined;
    StartedAt?: Date | undefined;
    ExpiresAt?: Date | undefined;
}
export type FreeTrialStatusList = FreeTrialStatus[];
export interface AccountFreeTrialStatus {
    AccountId?: string | undefined;
    EvaluatedAt?: Date | undefined;
    FreeTrialStatuses?: FreeTrialStatus[] | undefined;
}
export type AccountFreeTrialStatusList = AccountFreeTrialStatus[];
export interface ListFreeTrialStatusesV2Response {
    AccountFreeTrialStatuses: (AccountFreeTrialStatus & {
        AccountId: FreeTrialAccountId;
        EvaluatedAt: Date;
        FreeTrialStatuses: (FreeTrialStatus & {
            FeatureType: FreeTrialType;
            Status: FreeTrialStatusValue;
            StartedAt: Date;
            ExpiresAt: Date;
        })[];
    })[];
    NextToken?: string | undefined;
}
export type CrossAccountMaxResults = number;
export interface ListInvitationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export type InvitationList = Invitation[];
export interface ListInvitationsResponse {
    Invitations?: Invitation[] | undefined;
    NextToken?: string | undefined;
}
export interface ListMembersRequest {
    OnlyAssociated?: boolean | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
}
export interface ListMembersResponse {
    Members?: Member[] | undefined;
    NextToken?: string | undefined;
}
export type AdminsMaxResults = number;
export interface ListOrganizationAdminAccountsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    Feature?: SecurityHubFeature | undefined;
}
export type AdminStatus = "ENABLED" | "DISABLE_IN_PROGRESS" | (string & {});
export interface AdminAccount {
    AccountId?: string | undefined;
    Status?: AdminStatus | undefined;
}
export type AdminAccounts = AdminAccount[];
export interface ListOrganizationAdminAccountsResponse {
    AdminAccounts?: AdminAccount[] | undefined;
    NextToken?: string | undefined;
    Feature?: SecurityHubFeature | undefined;
}
export type SecurityControlsProviders = SecurityControlsProvider[];
export interface ListSecurityControlDefinitionsRequest {
    StandardsArn?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
    Providers?: SecurityControlsProvider[] | undefined;
}
export type SecurityControlDefinitions = SecurityControlDefinition[];
export interface ListSecurityControlDefinitionsResponse {
    SecurityControlDefinitions: (SecurityControlDefinition & {
        SecurityControlId: NonEmptyString;
        Title: NonEmptyString;
        Description: NonEmptyString;
        RemediationUrl: NonEmptyString;
        SeverityRating: SeverityRating;
        CurrentRegionAvailability: RegionAvailabilityStatus;
        ParameterDefinitions: {
            [key: string]: (ParameterDefinition & {
                Description: NonEmptyString;
                ConfigurationOptions: ConfigurationOptions;
            }) | undefined;
        };
    })[];
    NextToken?: string | undefined;
}
export interface ListStandardsControlAssociationsRequest {
    SecurityControlId?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface StandardsControlAssociationSummary {
    StandardsArn?: string | undefined;
    SecurityControlId?: string | undefined;
    SecurityControlArn?: string | undefined;
    AssociationStatus?: AssociationStatus | undefined;
    RelatedRequirements?: string[] | undefined;
    UpdatedAt?: Date | undefined;
    UpdatedReason?: string | undefined;
    StandardsControlTitle?: string | undefined;
    StandardsControlDescription?: string | undefined;
}
export type StandardsControlAssociationSummaries = StandardsControlAssociationSummary[];
export interface ListStandardsControlAssociationsResponse {
    StandardsControlAssociationSummaries: (StandardsControlAssociationSummary & {
        StandardsArn: NonEmptyString;
        SecurityControlId: NonEmptyString;
        SecurityControlArn: NonEmptyString;
        AssociationStatus: AssociationStatus;
    })[];
    NextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    ResourceArn: string;
}
export interface ListTagsForResourceResponse {
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface RegisterConnectorV2Request {
    AuthCode?: string | undefined;
    AuthState?: string | undefined;
}
export interface RegisterConnectorV2Response {
    ConnectorArn?: string | undefined;
    ConnectorId: string;
}
export interface StartConfigurationPolicyAssociationRequest {
    ConfigurationPolicyIdentifier?: string | undefined;
    Target?: Target | undefined;
}
export interface StartConfigurationPolicyAssociationResponse {
    ConfigurationPolicyId?: string | undefined;
    TargetId?: string | undefined;
    TargetType?: TargetType | undefined;
    AssociationType?: AssociationType | undefined;
    UpdatedAt?: Date | undefined;
    AssociationStatus?: ConfigurationPolicyAssociationStatus | undefined;
    AssociationStatusMessage?: string | undefined;
}
export interface StartConfigurationPolicyDisassociationRequest {
    Target?: Target | undefined;
    ConfigurationPolicyIdentifier?: string | undefined;
}
export interface StartConfigurationPolicyDisassociationResponse {
}
export interface StartExportJobV2Request {
    Name?: string | undefined;
    Destination?: ExportDestination | undefined;
    OutputConfiguration?: ExportOutput | undefined;
    Scopes?: ExportScopes | undefined;
    ClientToken?: string | undefined;
}
export interface StartExportJobV2Response {
    ExportJobId: string;
}
export interface TagResourceRequest {
    ResourceArn: string;
    Tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceArn: string;
    TagKeys?: string[] | undefined;
}
export interface UntagResourceResponse {
}
export interface UpdateActionTargetRequest {
    ActionTargetArn: string;
    Name?: string | undefined;
    Description?: string | undefined;
}
export interface UpdateActionTargetResponse {
}
export interface UpdateAggregatorV2Request {
    AggregatorV2Arn: string;
    RegionLinkingMode?: string | undefined;
    LinkedRegions?: string[] | undefined;
}
export interface UpdateAggregatorV2Response {
    AggregatorV2Arn?: string | undefined;
    AggregationRegion?: string | undefined;
    RegionLinkingMode?: string | undefined;
    LinkedRegions?: string[] | undefined;
}
export interface UpdateAutomationRuleV2Request {
    Identifier: string;
    RuleStatus?: RuleStatusV2 | undefined;
    RuleOrder?: number | undefined;
    Description?: string | undefined;
    RuleName?: string | undefined;
    Criteria?: Criteria | undefined;
    Actions?: AutomationRulesActionV2[] | undefined;
}
export interface UpdateAutomationRuleV2Response {
}
export interface UpdateConfigurationPolicyRequest {
    Identifier: string;
    Name?: string | undefined;
    Description?: string | undefined;
    UpdatedReason?: string | undefined;
    ConfigurationPolicy?: Policy | undefined;
}
export interface UpdateConfigurationPolicyResponse {
    Arn?: string | undefined;
    Id?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    UpdatedAt?: Date | undefined;
    CreatedAt?: Date | undefined;
    ConfigurationPolicy?: Policy | undefined;
}
export interface AzureUpdateConfiguration {
    ScopeConfiguration?: AzureScopeConfiguration | undefined;
    AzureRegions?: string[] | undefined;
}
export type CspmProviderUpdateConfiguration = {
    Azure: AzureUpdateConfiguration;
};
export interface UpdateConnectorRequest {
    ConnectorId: string;
    Description?: string | undefined;
    Provider?: CspmProviderUpdateConfiguration | undefined;
}
export interface UpdateConnectorResponse {
    ConnectorStatus?: CspmConnectorStatus | undefined;
    EnablementStatus?: CspmEnablementStatus | undefined;
}
export interface JiraCloudUpdateConfiguration {
    ProjectKey?: string | undefined;
}
export interface ServiceNowUpdateConfiguration {
    SecretArn?: string | undefined;
}
export type ProviderUpdateConfiguration = {
    JiraCloud: JiraCloudUpdateConfiguration;
    ServiceNow?: undefined;
    Azure?: undefined;
} | {
    JiraCloud?: undefined;
    ServiceNow: ServiceNowUpdateConfiguration;
    Azure?: undefined;
} | {
    JiraCloud?: undefined;
    ServiceNow?: undefined;
    Azure: AzureUpdateConfiguration;
};
export interface UpdateConnectorV2Request {
    ConnectorId: string;
    Description?: string | undefined;
    Provider?: ProviderUpdateConfiguration | undefined;
}
export interface UpdateConnectorV2Response {
    ConnectorStatus?: ConnectorStatus | undefined;
    EnablementStatus?: EnablementStatus | undefined;
}
export interface UpdateFindingAggregatorRequest {
    FindingAggregatorArn?: string | undefined;
    RegionLinkingMode?: string | undefined;
    Regions?: string[] | undefined;
}
export interface UpdateFindingAggregatorResponse {
    FindingAggregatorArn?: string | undefined;
    FindingAggregationRegion?: string | undefined;
    RegionLinkingMode?: string | undefined;
    Regions?: string[] | undefined;
}
export interface UpdateFindingsRequest {
    Filters?: AwsSecurityFindingFilters | undefined;
    Note?: NoteUpdate | undefined;
    RecordState?: RecordState | undefined;
}
export interface UpdateFindingsResponse {
}
export interface UpdateInsightRequest {
    InsightArn: string;
    Name?: string | undefined;
    Filters?: AwsSecurityFindingFilters | undefined;
    GroupByAttribute?: string | undefined;
}
export interface UpdateInsightResponse {
}
export interface UpdateOrganizationConfigurationRequest {
    AutoEnable?: boolean | undefined;
    AutoEnableStandards?: AutoEnableStandards | undefined;
    OrganizationConfiguration?: OrganizationConfiguration | undefined;
}
export interface UpdateOrganizationConfigurationResponse {
}
export interface UpdateSecurityControlRequest {
    SecurityControlId?: string | undefined;
    Parameters?: {
        [key: string]: ParameterConfiguration | undefined;
    } | undefined;
    LastUpdateReason?: string | undefined;
}
export interface UpdateSecurityControlResponse {
}
export interface UpdateSecurityHubConfigurationRequest {
    AutoEnableControls?: boolean | undefined;
    ControlFindingGenerator?: ControlFindingGenerator | undefined;
}
export interface UpdateSecurityHubConfigurationResponse {
}
export interface UpdateStandardsControlRequest {
    StandardsControlArn: string;
    ControlStatus?: ControlStatus | undefined;
    DisabledReason?: string | undefined;
}
export interface UpdateStandardsControlResponse {
}
export type AcceptAdministratorInvitationError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Accepts the invitation to be a member account and be monitored by the Security Hub CSPM administrator
 * account that the invitation was sent from.
 *
 * This operation is only used by member accounts that are not added through
 * Organizations.
 *
 * When the member account accepts the invitation, permission is granted to the administrator
 * account to view findings generated in the member account.
 */
export declare const acceptAdministratorInvitation: API.OperationMethod<AcceptAdministratorInvitationRequest & RegionInput, AcceptAdministratorInvitationResponse, AcceptAdministratorInvitationError, Credentials | HttpClient.HttpClient>;
export type AcceptInvitationError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * This method is deprecated. Instead, use `AcceptAdministratorInvitation`.
 *
 * The Security Hub CSPM console continues to use `AcceptInvitation`. It will eventually change to use `AcceptAdministratorInvitation`. Any IAM policies that specifically control access to this function must continue to use `AcceptInvitation`. You should also add `AcceptAdministratorInvitation` to your policies to ensure that the correct permissions are in place after the console begins to use `AcceptAdministratorInvitation`.
 *
 * Accepts the invitation to be a member account and be monitored by the Security Hub CSPM administrator
 * account that the invitation was sent from.
 *
 * This operation is only used by member accounts that are not added through
 * Organizations.
 *
 * When the member account accepts the invitation, permission is granted to the administrator
 * account to view findings generated in the member account.
 */
export declare const acceptInvitation: API.OperationMethod<AcceptInvitationRequest & RegionInput, AcceptInvitationResponse, AcceptInvitationError, Credentials | HttpClient.HttpClient>;
export type BatchDeleteAutomationRulesError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes one or more automation rules.
 */
export declare const batchDeleteAutomationRules: API.OperationMethod<BatchDeleteAutomationRulesRequest & RegionInput, BatchDeleteAutomationRulesResponse, BatchDeleteAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type BatchDisableStandardsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Disables the standards specified by the provided
 * `StandardsSubscriptionArns`.
 *
 * For more information, see Security Standards section of the Security Hub CSPM User
 * Guide.
 */
export declare const batchDisableStandards: API.OperationMethod<BatchDisableStandardsRequest & RegionInput, BatchDisableStandardsResponse, BatchDisableStandardsError, Credentials | HttpClient.HttpClient>;
export type BatchEnableStandardsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Enables the standards specified by the provided `StandardsArn`. To obtain the
 * ARN for a standard, use the `DescribeStandards`
 * operation.
 *
 * For more information, see the Security Standards
 * section of the *Security Hub CSPM User Guide*.
 */
export declare const batchEnableStandards: API.OperationMethod<BatchEnableStandardsRequest & RegionInput, BatchEnableStandardsResponse, BatchEnableStandardsError, Credentials | HttpClient.HttpClient>;
export type BatchGetAutomationRulesError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves a list of details for automation rules based on rule Amazon Resource Names
 * (ARNs).
 */
export declare const batchGetAutomationRules: API.OperationMethod<BatchGetAutomationRulesRequest & RegionInput, BatchGetAutomationRulesResponse, BatchGetAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type BatchGetConfigurationPolicyAssociationsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns associations between an Security Hub CSPM configuration and a batch of target accounts, organizational units, or the root.
 * Only the Security Hub CSPM delegated administrator can invoke this operation from the home Region. A configuration
 * can refer to a configuration policy or to a self-managed configuration.
 */
export declare const batchGetConfigurationPolicyAssociations: API.OperationMethod<BatchGetConfigurationPolicyAssociationsRequest & RegionInput, BatchGetConfigurationPolicyAssociationsResponse, BatchGetConfigurationPolicyAssociationsError, Credentials | HttpClient.HttpClient>;
export type BatchGetSecurityControlsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Provides details about a batch of security controls for the current Amazon Web Services account and Amazon Web Services Region.
 */
export declare const batchGetSecurityControls: API.OperationMethod<BatchGetSecurityControlsRequest & RegionInput, BatchGetSecurityControlsResponse, BatchGetSecurityControlsError, Credentials | HttpClient.HttpClient>;
export type BatchGetStandardsControlAssociationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * For a batch of security controls and standards, identifies whether each control is currently enabled or disabled in a standard.
 *
 * Calls to this operation return a `RESOURCE_NOT_FOUND_EXCEPTION` error when the standard subscription for the association has a `NOT_READY_FOR_UPDATES` value for `StandardsControlsUpdatable`.
 */
export declare const batchGetStandardsControlAssociations: API.OperationMethod<BatchGetStandardsControlAssociationsRequest & RegionInput, BatchGetStandardsControlAssociationsResponse, BatchGetStandardsControlAssociationsError, Credentials | HttpClient.HttpClient>;
export type BatchImportFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Imports security findings generated by a finding provider into Security Hub CSPM.
 * This action is requested by the finding provider to import its findings into
 * Security Hub CSPM.
 *
 * `BatchImportFindings` must be called by one of the following:
 *
 * - The Amazon Web Services account that is associated with a finding if you are using
 * the default product ARN
 * or are a partner sending findings from within a customer's Amazon Web Services account.
 * In these cases, the identifier of the account that you are calling `BatchImportFindings`
 * from needs to be the same as the `AwsAccountId` attribute for the finding.
 *
 * - An Amazon Web Services account that Security Hub CSPM has allow-listed for an official partner
 * integration. In this case, you can call `BatchImportFindings` from the allow-listed
 * account and send findings from different customer accounts in the same batch.
 *
 * The maximum allowed size for a finding is 240 Kb. An error is returned for any finding
 * larger than 240 Kb.
 *
 * After a finding is created, `BatchImportFindings` cannot be used to update
 * the following finding fields and objects, which Security Hub CSPM customers use to manage their
 * investigation workflow.
 *
 * - `Note`
 *
 * - `UserDefinedFields`
 *
 * - `VerificationState`
 *
 * - `Workflow`
 *
 * Finding providers also should not use `BatchImportFindings` to update the following attributes.
 *
 * - `Confidence`
 *
 * - `Criticality`
 *
 * - `RelatedFindings`
 *
 * - `Severity`
 *
 * - `Types`
 *
 * Instead, finding providers use `FindingProviderFields` to provide values for these attributes.
 */
export declare const batchImportFindings: API.OperationMethod<BatchImportFindingsRequest & RegionInput, BatchImportFindingsResponse, BatchImportFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateAutomationRulesError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates one or more automation rules based on rule Amazon Resource Names (ARNs)
 * and input parameters.
 */
export declare const batchUpdateAutomationRules: API.OperationMethod<BatchUpdateAutomationRulesRequest & RegionInput, BatchUpdateAutomationRulesResponse, BatchUpdateAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Used by Security Hub CSPM customers to update information about their investigation into one or more findings.
 * Requested by administrator accounts or member accounts.
 * Administrator accounts can update findings for their account and their member accounts.
 * A member account can update findings only for their own account.
 * Administrator and member accounts can use this operation to update the following fields and objects for one or more findings:
 *
 * - `Confidence`
 *
 * - `Criticality`
 *
 * - `Note`
 *
 * - `RelatedFindings`
 *
 * - `Severity`
 *
 * - `Types`
 *
 * - `UserDefinedFields`
 *
 * - `VerificationState`
 *
 * - `Workflow`
 *
 * If you use this operation to update a finding, your updates don't affect the value for the `UpdatedAt` field of the finding.
 * Also note that it can take several minutes for Security Hub CSPM to process your request and update each finding specified in the request.
 *
 * You can configure IAM policies to restrict access to fields and field values.
 * For example, you might not want member accounts to be able to suppress findings or change the finding severity.
 * For more information see Configuring access to BatchUpdateFindings in the *Security Hub CSPM User Guide*.
 */
export declare const batchUpdateFindings: API.OperationMethod<BatchUpdateFindingsRequest & RegionInput, BatchUpdateFindingsResponse, BatchUpdateFindingsError, Credentials | HttpClient.HttpClient>;
export type BatchUpdateFindingsV2Error = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information about a customer's investigation into a finding. Delegated administrator accounts can update findings for their account and their member accounts. Member accounts can update findings for their own account.
 *
 * `BatchUpdateFindings` and `BatchUpdateFindingsV2` both use `securityhub:BatchUpdateFindings` in the `Action` element of an IAM policy statement.
 * You must have permission to perform the `securityhub:BatchUpdateFindings` action.
 * You can configure IAM policies to restrict access to specific finding fields or field values by using the `securityhub:OCSFSyntaxPath/` condition key, where `` is one of the following supported fields: `SeverityId`, `StatusId`, or `Comment`.
 *
 * To prevent a user from updating a specific field, use a `Null` condition with `securityhub:OCSFSyntaxPath/` set to `"false"`.
 * To prevent a user from setting a field to a specific value, use a `StringEquals` condition with `securityhub:OCSFSyntaxPath/` set to the disallowed value or list of values.
 *
 * Updates from `BatchUpdateFindingsV2` don't affect the value of `finding_info.modified_time`, `finding_info.modified_time_dt`, `time`, or `time_dt` for a finding.
 */
export declare const batchUpdateFindingsV2: API.OperationMethod<BatchUpdateFindingsV2Request & RegionInput, BatchUpdateFindingsV2Response, BatchUpdateFindingsV2Error, Credentials | HttpClient.HttpClient>;
export type BatchUpdateStandardsControlAssociationsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * For a batch of security controls and standards, this operation updates the enablement status of a control in a standard.
 */
export declare const batchUpdateStandardsControlAssociations: API.OperationMethod<BatchUpdateStandardsControlAssociationsRequest & RegionInput, BatchUpdateStandardsControlAssociationsResponse, BatchUpdateStandardsControlAssociationsError, Credentials | HttpClient.HttpClient>;
export type CancelExportJobV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Cancels a findings export job that is in progress. Security Hub transitions a running job to the `CANCELLED` state and returns the `ExportJobId` and its new `Status`. Canceling a job that is already in the `CANCELLED` state succeeds and returns the same result, so you can safely retry a cancel request.
 *
 * You can't cancel an export job that has already reached a terminal `SUCCEEDED` or `FAILED` state; in that case, this operation returns a `ConflictException`. If no export job matches the `ExportJobId` that you provide, this operation returns a `ResourceNotFoundException`.
 *
 * The `Status` value returned by this operation reflects the cancellation immediately, even though the job can take a short time to stop completely.
 */
export declare const cancelExportJobV2: API.OperationMethod<CancelExportJobV2Request & RegionInput, CancelExportJobV2Response, CancelExportJobV2Error, Credentials | HttpClient.HttpClient>;
export type CreateActionTargetError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a custom action target in Security Hub CSPM.
 *
 * You can use custom actions on findings and insights in Security Hub CSPM to trigger target actions
 * in Amazon CloudWatch Events.
 */
export declare const createActionTarget: API.OperationMethod<CreateActionTargetRequest & RegionInput, CreateActionTargetResponse, CreateActionTargetError, Credentials | HttpClient.HttpClient>;
export type CreateAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables aggregation across Amazon Web Services Regions.
 */
export declare const createAggregatorV2: API.OperationMethod<CreateAggregatorV2Request & RegionInput, CreateAggregatorV2Response, CreateAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type CreateAutomationRuleError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Creates an automation rule based on input parameters.
 */
export declare const createAutomationRule: API.OperationMethod<CreateAutomationRuleRequest & RegionInput, CreateAutomationRuleResponse, CreateAutomationRuleError, Credentials | HttpClient.HttpClient>;
export type CreateAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a V2 automation rule.
 */
export declare const createAutomationRuleV2: API.OperationMethod<CreateAutomationRuleV2Request & RegionInput, CreateAutomationRuleV2Response, CreateAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type CreateConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a configuration policy with the defined configuration. Only the Security Hub CSPM delegated administrator
 * can invoke this operation from the home Region.
 */
export declare const createConfigurationPolicy: API.OperationMethod<CreateConfigurationPolicyRequest & RegionInput, CreateConfigurationPolicyResponse, CreateConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a connector to a third-party cloud provider in Security Hub CSPM. A connector establishes a connection between Security Hub CSPM and a third-party cloud provider, enabling Security Hub CSPM to ingest security findings and resource data from the connected environment.
 */
export declare const createConnector: API.OperationMethod<CreateConnectorRequest & RegionInput, CreateConnectorResponse, CreateConnectorError, Credentials | HttpClient.HttpClient>;
export type CreateConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to create a connectorV2 based on input parameters.
 */
export declare const createConnectorV2: API.OperationMethod<CreateConnectorV2Request & RegionInput, CreateConnectorV2Response, CreateConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type CreateFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Used to enable cross-Region aggregation. This operation can be invoked from the home Region only.
 *
 * For information about how cross-Region aggregation works, see Understanding cross-Region aggregation in Security Hub CSPM in the *Security Hub CSPM User Guide*.
 */
export declare const createFindingAggregator: API.OperationMethod<CreateFindingAggregatorRequest & RegionInput, CreateFindingAggregatorResponse, CreateFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type CreateInsightError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a custom insight in Security Hub CSPM. An insight is a consolidation of findings that relate
 * to a security issue that requires attention or remediation.
 *
 * To group the related findings in the insight, use the
 * `GroupByAttribute`.
 */
export declare const createInsight: API.OperationMethod<CreateInsightRequest & RegionInput, CreateInsightResponse, CreateInsightError, Credentials | HttpClient.HttpClient>;
export type CreateMembersError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Creates a member association in Security Hub CSPM between the specified accounts and the account
 * used to make the request, which is the administrator account. If you are integrated with
 * Organizations, then the administrator account is designated by the organization management account.
 *
 * `CreateMembers` is always used to add accounts that are not organization
 * members.
 *
 * For accounts that are managed using Organizations, `CreateMembers` is only used
 * in the following cases:
 *
 * - Security Hub CSPM is not configured to automatically add new organization accounts.
 *
 * - The account was disassociated or deleted in Security Hub CSPM.
 *
 * This action can only be used by an account that has Security Hub CSPM enabled. To enable Security Hub CSPM, you
 * can use the `EnableSecurityHub` operation.
 *
 * For accounts that are not organization members, you create the account association and
 * then send an invitation to the member account. To send the invitation, you use the
 * `InviteMembers` operation. If the account owner accepts
 * the invitation, the account becomes a member account in Security Hub CSPM.
 *
 * Accounts that are managed using Organizations don't receive an invitation. They
 * automatically become a member account in Security Hub CSPM.
 *
 * - If the organization account does not have Security Hub CSPM enabled, then Security Hub CSPM and the default standards are automatically enabled. Note that Security Hub CSPM cannot be enabled automatically for the organization management account. The organization management account must enable Security Hub CSPM before the administrator account enables it as a member account.
 *
 * - For organization accounts that already have Security Hub CSPM enabled, Security Hub CSPM does not make any other changes to those accounts. It does not change their enabled standards or controls.
 *
 * A permissions policy is added that permits the administrator account to view the findings
 * generated in the member account.
 *
 * To remove the association between the administrator and member accounts, use the `DisassociateFromMasterAccount` or `DisassociateMembers` operation.
 */
export declare const createMembers: API.OperationMethod<CreateMembersRequest & RegionInput, CreateMembersResponse, CreateMembersError, Credentials | HttpClient.HttpClient>;
export type CreateTicketV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to create a ticket in the chosen ITSM based on finding information for the provided finding metadata UID.
 */
export declare const createTicketV2: API.OperationMethod<CreateTicketV2Request & RegionInput, CreateTicketV2Response, CreateTicketV2Error, Credentials | HttpClient.HttpClient>;
export type DeclineInvitationsError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Declines invitations to become a Security Hub CSPM member account.
 *
 * A prospective member account uses this operation to decline an invitation to become a member.
 *
 * Only member accounts that aren't part of an Amazon Web Services organization should use this operation.
 * Organization accounts don't receive invitations.
 */
export declare const declineInvitations: API.OperationMethod<DeclineInvitationsRequest & RegionInput, DeclineInvitationsResponse, DeclineInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteActionTargetError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a custom action target from Security Hub CSPM.
 *
 * Deleting a custom action target does not affect any findings or insights that were
 * already sent to Amazon CloudWatch Events using the custom action.
 */
export declare const deleteActionTarget: API.OperationMethod<DeleteActionTargetRequest & RegionInput, DeleteActionTargetResponse, DeleteActionTargetError, Credentials | HttpClient.HttpClient>;
export type DeleteAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the Aggregator V2.
 */
export declare const deleteAggregatorV2: API.OperationMethod<DeleteAggregatorV2Request & RegionInput, DeleteAggregatorV2Response, DeleteAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a V2 automation rule.
 */
export declare const deleteAutomationRuleV2: API.OperationMethod<DeleteAutomationRuleV2Request & RegionInput, DeleteAutomationRuleV2Response, DeleteAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes a configuration policy. Only the Security Hub CSPM delegated administrator can invoke this operation
 * from the home Region. For the deletion to succeed, you must first disassociate a configuration policy from target accounts,
 * organizational units, or the root by invoking the `StartConfigurationPolicyDisassociation` operation.
 */
export declare const deleteConfigurationPolicy: API.OperationMethod<DeleteConfigurationPolicyRequest & RegionInput, DeleteConfigurationPolicyResponse, DeleteConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a CSPM connector. When you delete a connector, Security Hub CSPM stops ingesting findings and resource data from the connected cloud provider environment.
 */
export declare const deleteConnector: API.OperationMethod<DeleteConnectorRequest & RegionInput, DeleteConnectorResponse, DeleteConnectorError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to delete a connectorV2.
 */
export declare const deleteConnectorV2: API.OperationMethod<DeleteConnectorV2Request & RegionInput, DeleteConnectorV2Response, DeleteConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type DeleteFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Deletes a finding aggregator. When you delete the finding aggregator, you stop cross-Region aggregation. Finding replication stops
 * occurring from the linked Regions to the home Region.
 *
 * When you stop cross-Region aggregation, findings that were already replicated and sent to the home Region are still visible from
 * the home Region. However, new findings and finding updates are no longer replicated and sent to the home Region.
 */
export declare const deleteFindingAggregator: API.OperationMethod<DeleteFindingAggregatorRequest & RegionInput, DeleteFindingAggregatorResponse, DeleteFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type DeleteInsightError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the insight specified by the `InsightArn`.
 */
export declare const deleteInsight: API.OperationMethod<DeleteInsightRequest & RegionInput, DeleteInsightResponse, DeleteInsightError, Credentials | HttpClient.HttpClient>;
export type DeleteInvitationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Deletes invitations to become a Security Hub CSPM member account.
 *
 * A Security Hub CSPM administrator account can use this operation to delete invitations sent to one or more prospective member accounts.
 *
 * This operation is only used to delete invitations that are sent to prospective member accounts that aren't part of an Amazon Web Services organization.
 * Organization accounts don't receive invitations.
 */
export declare const deleteInvitations: API.OperationMethod<DeleteInvitationsRequest & RegionInput, DeleteInvitationsResponse, DeleteInvitationsError, Credentials | HttpClient.HttpClient>;
export type DeleteMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Deletes the specified member accounts from Security Hub CSPM.
 *
 * You can invoke this API only to delete accounts that became members through invitation. You can't invoke this
 * API to delete accounts that belong to an Organizations organization.
 */
export declare const deleteMembers: API.OperationMethod<DeleteMembersRequest & RegionInput, DeleteMembersResponse, DeleteMembersError, Credentials | HttpClient.HttpClient>;
export type DescribeActionTargetsError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of the custom action targets in Security Hub CSPM in your account.
 */
export declare const describeActionTargets: API.PaginatedOperationMethod<DescribeActionTargetsRequest & RegionInput, DescribeActionTargetsResponse, DescribeActionTargetsError, Credentials | HttpClient.HttpClient, ActionTarget>;
export type DescribeHubError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns details about the Hub resource in your account, including the
 * `HubArn` and the time when you enabled Security Hub CSPM.
 */
export declare const describeHub: API.OperationMethod<DescribeHubRequest & RegionInput, DescribeHubResponse, DescribeHubError, Credentials | HttpClient.HttpClient>;
export type DescribeOrganizationConfigurationError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns information about the way your organization is configured in Security Hub CSPM. Only the
 * Security Hub CSPM administrator account can invoke this operation.
 */
export declare const describeOrganizationConfiguration: API.OperationMethod<DescribeOrganizationConfigurationRequest & RegionInput, DescribeOrganizationConfigurationResponse, DescribeOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeProductsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns information about product integrations in Security Hub CSPM.
 *
 * You can optionally provide an integration ARN. If you provide an integration ARN, then
 * the results only include that integration.
 *
 * If you don't provide an integration ARN, then the results include all of the available
 * product integrations.
 */
export declare const describeProducts: API.PaginatedOperationMethod<DescribeProductsRequest & RegionInput, DescribeProductsResponse, DescribeProductsError, Credentials | HttpClient.HttpClient, Product>;
export type DescribeProductsV2Error = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Gets information about the product integration.
 */
export declare const describeProductsV2: API.PaginatedOperationMethod<DescribeProductsV2Request & RegionInput, DescribeProductsV2Response, DescribeProductsV2Error, Credentials | HttpClient.HttpClient, ProductV2>;
export type DescribeSecurityHubV2Error = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns details about the service resource in your account.
 */
export declare const describeSecurityHubV2: API.OperationMethod<DescribeSecurityHubV2Request & RegionInput, DescribeSecurityHubV2Response, DescribeSecurityHubV2Error, Credentials | HttpClient.HttpClient>;
export type DescribeStandardsError = InternalException | InvalidAccessException | InvalidInputException | CommonErrors;
/**
 * Returns a list of the available standards in Security Hub CSPM.
 *
 * For each standard, the results include the standard ARN, the name, and a description.
 */
export declare const describeStandards: API.PaginatedOperationMethod<DescribeStandardsRequest & RegionInput, DescribeStandardsResponse, DescribeStandardsError, Credentials | HttpClient.HttpClient, Standard>;
export type DescribeStandardsControlsError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of security standards controls.
 *
 * For each control, the results include information about whether it is currently enabled,
 * the severity, and a link to remediation information.
 *
 * This operation returns an empty list for standard subscriptions where `StandardsControlsUpdatable` has value `NOT_READY_FOR_UPDATES`.
 */
export declare const describeStandardsControls: API.PaginatedOperationMethod<DescribeStandardsControlsRequest & RegionInput, DescribeStandardsControlsResponse, DescribeStandardsControlsError, Credentials | HttpClient.HttpClient, StandardsControl>;
export type DisableImportFindingsForProductError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disables the integration of the specified product with Security Hub CSPM. After the integration is
 * disabled, findings from that product are no longer sent to Security Hub CSPM.
 */
export declare const disableImportFindingsForProduct: API.OperationMethod<DisableImportFindingsForProductRequest & RegionInput, DisableImportFindingsForProductResponse, DisableImportFindingsForProductError, Credentials | HttpClient.HttpClient>;
export type DisableOrganizationAdminAccountError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Disables a Security Hub CSPM administrator account. Can only be called by the organization
 * management account.
 */
export declare const disableOrganizationAdminAccount: API.OperationMethod<DisableOrganizationAdminAccountRequest & RegionInput, DisableOrganizationAdminAccountResponse, DisableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type DisableSecurityHubError = AccessDeniedException | InternalException | InvalidAccessException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disables Security Hub CSPM in your account only in the current Amazon Web Services Region. To disable Security Hub CSPM in all
 * Regions, you must submit one request per Region where you have enabled Security Hub CSPM.
 *
 * You can't disable Security Hub CSPM in an account that is currently the Security Hub CSPM administrator.
 *
 * When you disable Security Hub CSPM, your existing findings and insights and any Security Hub CSPM configuration
 * settings are deleted after 90 days and cannot be recovered. Any standards that were enabled
 * are disabled, and your administrator and member account associations are removed.
 *
 * If you want to save your existing findings, you must export them before you disable
 * Security Hub CSPM.
 */
export declare const disableSecurityHub: API.OperationMethod<DisableSecurityHubRequest & RegionInput, DisableSecurityHubResponse, DisableSecurityHubError, Credentials | HttpClient.HttpClient>;
export type DisableSecurityHubFeatureV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disables an opt-in feature for the calling account in the current Amazon Web Services Region. The operation is idempotent. If the feature is already disabled, no changes are made. You cannot disable a feature that is managed by an organization policy.
 */
export declare const disableSecurityHubFeatureV2: API.OperationMethod<DisableSecurityHubFeatureV2Request & RegionInput, DisableSecurityHubFeatureV2Response, DisableSecurityHubFeatureV2Error, Credentials | HttpClient.HttpClient>;
export type DisableSecurityHubV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Disable the service for the current Amazon Web Services Region or specified Amazon Web Services Region. Disabling the service also disables all opt-in features that are currently enabled in that Region.
 */
export declare const disableSecurityHubV2: API.OperationMethod<DisableSecurityHubV2Request & RegionInput, DisableSecurityHubV2Response, DisableSecurityHubV2Error, Credentials | HttpClient.HttpClient>;
export type DisassociateFromAdministratorAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the current Security Hub CSPM member account from the associated administrator
 * account.
 *
 * This operation is only used by accounts that are not part of an organization. For
 * organization accounts, only the administrator account can
 * disassociate a member account.
 */
export declare const disassociateFromAdministratorAccount: API.OperationMethod<DisassociateFromAdministratorAccountRequest & RegionInput, DisassociateFromAdministratorAccountResponse, DisassociateFromAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateFromMasterAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * This method is deprecated. Instead, use `DisassociateFromAdministratorAccount`.
 *
 * The Security Hub CSPM console continues to use `DisassociateFromMasterAccount`. It will eventually change to use `DisassociateFromAdministratorAccount`. Any IAM policies that specifically control access to this function must continue to use `DisassociateFromMasterAccount`. You should also add `DisassociateFromAdministratorAccount` to your policies to ensure that the correct permissions are in place after the console begins to use `DisassociateFromAdministratorAccount`.
 *
 * Disassociates the current Security Hub CSPM member account from the associated administrator
 * account.
 *
 * This operation is only used by accounts that are not part of an organization. For
 * organization accounts, only the administrator account can
 * disassociate a member account.
 */
export declare const disassociateFromMasterAccount: API.OperationMethod<DisassociateFromMasterAccountRequest & RegionInput, DisassociateFromMasterAccountResponse, DisassociateFromMasterAccountError, Credentials | HttpClient.HttpClient>;
export type DisassociateMembersError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates the specified member accounts from the associated administrator account.
 *
 * Can be used to disassociate both accounts that are managed using Organizations and accounts that
 * were invited manually.
 */
export declare const disassociateMembers: API.OperationMethod<DisassociateMembersRequest & RegionInput, DisassociateMembersResponse, DisassociateMembersError, Credentials | HttpClient.HttpClient>;
export type EnableImportFindingsForProductError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Enables the integration of a partner product with Security Hub CSPM. Integrated products send
 * findings to Security Hub CSPM.
 *
 * When you enable a product integration, a permissions policy that grants permission for
 * the product to send findings to Security Hub CSPM is applied.
 */
export declare const enableImportFindingsForProduct: API.OperationMethod<EnableImportFindingsForProductRequest & RegionInput, EnableImportFindingsForProductResponse, EnableImportFindingsForProductError, Credentials | HttpClient.HttpClient>;
export type EnableOrganizationAdminAccountError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Designates the Security Hub CSPM administrator account for an organization. Can only be called by
 * the organization management account.
 */
export declare const enableOrganizationAdminAccount: API.OperationMethod<EnableOrganizationAdminAccountRequest & RegionInput, EnableOrganizationAdminAccountResponse, EnableOrganizationAdminAccountError, Credentials | HttpClient.HttpClient>;
export type EnableSecurityHubError = AccessDeniedException | InternalException | InvalidAccessException | LimitExceededException | ResourceConflictException | CommonErrors;
/**
 * Enables Security Hub CSPM for your account in the current Region or the Region you specify in the
 * request.
 *
 * When you enable Security Hub CSPM, you grant to Security Hub CSPM the permissions necessary to gather findings
 * from other services that are integrated with Security Hub CSPM.
 *
 * When you use the `EnableSecurityHub` operation to enable Security Hub CSPM, you also
 * automatically enable the following standards:
 *
 * - Center for Internet Security (CIS) Amazon Web Services Foundations Benchmark v1.2.0
 *
 * - Amazon Web Services Foundational Security Best Practices
 *
 * Other standards are not automatically enabled.
 *
 * To opt out of automatically enabled standards, set
 * `EnableDefaultStandards` to `false`.
 *
 * After you enable Security Hub CSPM, to enable a standard, use the `BatchEnableStandards` operation. To disable a standard, use the
 * `BatchDisableStandards` operation.
 *
 * To learn more, see the setup information in the *Security Hub CSPM User Guide*.
 */
export declare const enableSecurityHub: API.OperationMethod<EnableSecurityHubRequest & RegionInput, EnableSecurityHubResponse, EnableSecurityHubError, Credentials | HttpClient.HttpClient>;
export type EnableSecurityHubFeatureV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables an opt-in feature for the calling account in the current Amazon Web Services Region. The service must be enabled before you can enable a feature. The operation is idempotent. If the feature is already enabled, no changes are made. You cannot enable a feature that is managed by an organization policy.
 */
export declare const enableSecurityHubFeatureV2: API.OperationMethod<EnableSecurityHubFeatureV2Request & RegionInput, EnableSecurityHubFeatureV2Response, EnableSecurityHubFeatureV2Error, Credentials | HttpClient.HttpClient>;
export type EnableSecurityHubV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Enables the service in account for the current Amazon Web Services Region or specified Amazon Web Services Region.
 */
export declare const enableSecurityHubV2: API.OperationMethod<EnableSecurityHubV2Request & RegionInput, EnableSecurityHubV2Response, EnableSecurityHubV2Error, Credentials | HttpClient.HttpClient>;
export type GenerateRecommendedPolicyV2Error = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Begins the recommended policy generation to remediate a Security Hub finding.
 * `GenerateRecommendedPolicyV2` only supports findings for unused permissions.
 */
export declare const generateRecommendedPolicyV2: API.OperationMethod<GenerateRecommendedPolicyV2Request & RegionInput, GenerateRecommendedPolicyV2Response, GenerateRecommendedPolicyV2Error, Credentials | HttpClient.HttpClient>;
export type GetAdministratorAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Provides the details for the Security Hub CSPM administrator account for the current member account.
 *
 * Can be used by both member accounts that are managed using Organizations and accounts that were
 * invited manually.
 */
export declare const getAdministratorAccount: API.OperationMethod<GetAdministratorAccountRequest & RegionInput, GetAdministratorAccountResponse, GetAdministratorAccountError, Credentials | HttpClient.HttpClient>;
export type GetAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the configuration of the specified Aggregator V2.
 */
export declare const getAggregatorV2: API.OperationMethod<GetAggregatorV2Request & RegionInput, GetAggregatorV2Response, GetAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type GetAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns an automation rule for the V2 service.
 */
export declare const getAutomationRuleV2: API.OperationMethod<GetAutomationRuleV2Request & RegionInput, GetAutomationRuleV2Response, GetAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type GetConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Provides information about a configuration policy. Only the Security Hub CSPM delegated administrator can invoke
 * this operation from the home Region.
 */
export declare const getConfigurationPolicy: API.OperationMethod<GetConfigurationPolicyRequest & RegionInput, GetConfigurationPolicyResponse, GetConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type GetConfigurationPolicyAssociationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the association between a configuration and a target account, organizational unit, or the root. The
 * configuration can be a configuration policy or self-managed behavior. Only the Security Hub CSPM delegated administrator can
 * invoke this operation from the home Region.
 */
export declare const getConfigurationPolicyAssociation: API.OperationMethod<GetConfigurationPolicyAssociationRequest & RegionInput, GetConfigurationPolicyAssociationResponse, GetConfigurationPolicyAssociationError, Credentials | HttpClient.HttpClient>;
export type GetConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details for a CSPM connector based on the connector ID.
 */
export declare const getConnector: API.OperationMethod<GetConnectorRequest & RegionInput, GetConnectorResponse, GetConnectorError, Credentials | HttpClient.HttpClient>;
export type GetConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to retrieve details for a connectorV2 based on connector id.
 */
export declare const getConnectorV2: API.OperationMethod<GetConnectorV2Request & RegionInput, GetConnectorV2Response, GetConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type GetEnabledStandardsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns a list of the standards that are currently enabled.
 */
export declare const getEnabledStandards: API.PaginatedOperationMethod<GetEnabledStandardsRequest & RegionInput, GetEnabledStandardsResponse, GetEnabledStandardsError, Credentials | HttpClient.HttpClient, StandardsSubscription>;
export type GetExportJobV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the details of a single findings export job, including its current `Status`, the `Destination` it writes to, the `OutputConfiguration` it was started with, and its `StartedAt` and `EndedAt` timestamps. Use this operation to poll an export job that you started with `StartExportJobV2` until it reaches a terminal state (`SUCCEEDED`, `FAILED`, or `CANCELLED`).
 *
 * If the job failed, the response includes a `FailureCode` and `FailureMessage` that describe the reason. Input values such as `Scopes` and `Filters` are echoed back as they were submitted, with relative date ranges returned unresolved. If no export job matches the `ExportJobId` that you provide, this operation returns a `ResourceNotFoundException`.
 */
export declare const getExportJobV2: API.OperationMethod<GetExportJobV2Request & RegionInput, GetExportJobV2Response, GetExportJobV2Error, Credentials | HttpClient.HttpClient>;
export type GetFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Returns the current configuration in the calling account for cross-Region aggregation. A finding aggregator is a resource that establishes
 * the home Region and any linked Regions.
 */
export declare const getFindingAggregator: API.OperationMethod<GetFindingAggregatorRequest & RegionInput, GetFindingAggregatorResponse, GetFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type GetFindingHistoryError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns the history of a Security Hub CSPM finding. The history includes changes made to any fields in
 * the Amazon Web Services Security Finding Format (ASFF) except top-level timestamp fields, such as the `CreatedAt` and
 * `UpdatedAt` fields.
 *
 * This operation might return fewer results than the maximum number of results (`MaxResults`) specified in a request, even
 * when more results are available. If this occurs, the response includes a `NextToken` value, which you should use to retrieve
 * the next set of results in the response. The presence of a `NextToken` value in a response doesn't necessarily indicate
 * that the results are incomplete. However, you should continue to specify a `NextToken` value until you receive a
 * response that doesn't include this value.
 */
export declare const getFindingHistory: API.PaginatedOperationMethod<GetFindingHistoryRequest & RegionInput, GetFindingHistoryResponse, GetFindingHistoryError, Credentials | HttpClient.HttpClient, FindingHistoryRecord>;
export type GetFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Returns a list of findings that match the specified criteria.
 *
 * If cross-Region aggregation is enabled, then when you call `GetFindings` from the home Region, the results include all of the matching findings from both the home Region and linked Regions.
 */
export declare const getFindings: API.PaginatedOperationMethod<GetFindingsRequest & RegionInput, GetFindingsResponse, GetFindingsError, Credentials | HttpClient.HttpClient, AwsSecurityFinding>;
export type GetFindingStatisticsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns aggregated statistical data about findings.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you aggregate findings from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * `GetFindingStatisticsV2` uses `securityhub:GetAdhocInsightResults` in the `Action` element of an IAM policy statement.
 * You must have permission to perform the `securityhub:GetAdhocInsightResults` action.
 */
export declare const getFindingStatisticsV2: API.OperationMethod<GetFindingStatisticsV2Request & RegionInput, GetFindingStatisticsV2Response, GetFindingStatisticsV2Error, Credentials | HttpClient.HttpClient>;
export type GetFindingsTrendsV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns findings trend data based on the specified criteria. This operation helps you analyze patterns and changes in findings over time.
 */
export declare const getFindingsTrendsV2: API.PaginatedOperationMethod<GetFindingsTrendsV2Request & RegionInput, GetFindingsTrendsV2Response, GetFindingsTrendsV2Error, Credentials | HttpClient.HttpClient, TrendsMetricsResult>;
export type GetFindingsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of findings that match the specified criteria.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you retrieve findings from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * You can use the `Filters` parameter to refine results based on finding attributes. You can use `Scopes` and `Filters` independently or together. When both are provided, `Scopes` narrows the data set first, and then `Filters` refines results within that scoped data set.
 *
 * `GetFindings` and `GetFindingsV2` both use `securityhub:GetFindings` in the `Action` element of an IAM policy statement.
 * You must have permission to perform the `securityhub:GetFindings` action.
 */
export declare const getFindingsV2: API.PaginatedOperationMethod<GetFindingsV2Request & RegionInput, GetFindingsV2Response, GetFindingsV2Error, Credentials | HttpClient.HttpClient, unknown>;
export type GetInsightResultsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Lists the results of the Security Hub CSPM insight specified by the insight ARN.
 */
export declare const getInsightResults: API.OperationMethod<GetInsightResultsRequest & RegionInput, GetInsightResultsResponse, GetInsightResultsError, Credentials | HttpClient.HttpClient>;
export type GetInsightsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Lists and describes insights for the specified insight ARNs.
 */
export declare const getInsights: API.PaginatedOperationMethod<GetInsightsRequest & RegionInput, GetInsightsResponse, GetInsightsError, Credentials | HttpClient.HttpClient, Insight>;
export type GetInvitationsCountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Returns the count of all Security Hub CSPM membership invitations that were sent to the
 * calling member account, not including the currently accepted invitation.
 */
export declare const getInvitationsCount: API.OperationMethod<GetInvitationsCountRequest & RegionInput, GetInvitationsCountResponse, GetInvitationsCountError, Credentials | HttpClient.HttpClient>;
export type GetMasterAccountError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * This method is deprecated. Instead, use `GetAdministratorAccount`.
 *
 * The Security Hub CSPM console continues to use `GetMasterAccount`. It will eventually change to use `GetAdministratorAccount`. Any IAM policies that specifically control access to this function must continue to use `GetMasterAccount`. You should also add `GetAdministratorAccount` to your policies to ensure that the correct permissions are in place after the console begins to use `GetAdministratorAccount`.
 *
 * Provides the details for the Security Hub CSPM administrator account for the current member account.
 *
 * Can be used by both member accounts that are managed using Organizations and accounts that were
 * invited manually.
 */
export declare const getMasterAccount: API.OperationMethod<GetMasterAccountRequest & RegionInput, GetMasterAccountResponse, GetMasterAccountError, Credentials | HttpClient.HttpClient>;
export type GetMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Returns the details for the Security Hub CSPM member accounts for the specified account IDs.
 *
 * An administrator account can be either the delegated Security Hub CSPM administrator account for an
 * organization or an administrator account that enabled Security Hub CSPM manually.
 *
 * The results include both member accounts that are managed using Organizations and accounts that
 * were invited manually.
 */
export declare const getMembers: API.OperationMethod<GetMembersRequest & RegionInput, GetMembersResponse, GetMembersError, Credentials | HttpClient.HttpClient>;
export type GetRecommendedPolicyV2Error = AccessDeniedException | InternalServerException | InvalidInputException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the recommended policy to remediate a Security Hub finding.
 * `GetRecommendedPolicyV2` only supports findings for unused permissions.
 */
export declare const getRecommendedPolicyV2: API.PaginatedOperationMethod<GetRecommendedPolicyV2Request & RegionInput, GetRecommendedPolicyV2Response, GetRecommendedPolicyV2Error, Credentials | HttpClient.HttpClient, RecommendationStep>;
export type GetRemediationsV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves remediation targets for the account, or for all member accounts if the caller is
 * the delegated administrator. Results are sorted by priority, highest first, and are paginated.
 * Use `TargetUid` or `MetadataUid` to scope the request to a single target
 * or finding.
 */
export declare const getRemediationsV2: API.PaginatedOperationMethod<GetRemediationsV2Request & RegionInput, GetRemediationsV2Response, GetRemediationsV2Error, Credentials | HttpClient.HttpClient, RemediationV2Item>;
export type GetResourcesStatisticsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves statistical information about Amazon Web Services resources and their associated security findings.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you aggregate resources from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * If you set `GroupByField` to `ResourceSubCategory`, `ResourceInfo.AIDetails.HostResourceType`, or `ResourceInfo.AIDetails.CanonicalId`, you must include a `ResourceCategory` string filter with comparison set to `EQUALS` and value `AI/ML` in the corresponding `ResourceGroupByRule`.
 */
export declare const getResourcesStatisticsV2: API.OperationMethod<GetResourcesStatisticsV2Request & RegionInput, GetResourcesStatisticsV2Response, GetResourcesStatisticsV2Error, Credentials | HttpClient.HttpClient>;
export type GetResourcesTrendsV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns resource trend data based on the specified criteria. This operation helps you analyze patterns and changes in resource compliance over time.
 */
export declare const getResourcesTrendsV2: API.PaginatedOperationMethod<GetResourcesTrendsV2Request & RegionInput, GetResourcesTrendsV2Response, GetResourcesTrendsV2Error, Credentials | HttpClient.HttpClient, ResourcesTrendsMetricsResult>;
export type GetResourcesV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of resources.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`, which lets you retrieve resources from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * You can use the `Filters` parameter to refine results based on resource attributes. You can use `Scopes` and `Filters` independently or together. When both are provided, `Scopes` narrows the data set first, and then `Filters` refines results within that scoped data set.
 *
 * For AI/ML resources, the response includes the `ResourceSubCategory` field. For self-hosted AI resources and their host resources, the response also includes `ResourceInfo` with AI-specific details. Self-hosted AI resources use a `ResourceType` with the `SelfHosted::AI::` prefix, such as `SelfHosted::AI::Model`, `SelfHosted::AI::Agent`, `SelfHosted::AI::InferenceEndpoint`, and `SelfHosted::AI::ExternalEndpoint`.
 *
 * If you filter by `ResourceSubCategory`, you must also include a `ResourceCategory` string filter with comparison set to `EQUALS` and value `AI/ML` in the same request.
 */
export declare const getResourcesV2: API.PaginatedOperationMethod<GetResourcesV2Request & RegionInput, GetResourcesV2Response, GetResourcesV2Error, Credentials | HttpClient.HttpClient, ResourceResult>;
export type GetSecurityControlDefinitionError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Retrieves the definition of a security control. The definition includes the control title, description, Region availability, parameter definitions, and other details.
 */
export declare const getSecurityControlDefinition: API.OperationMethod<GetSecurityControlDefinitionRequest & RegionInput, GetSecurityControlDefinitionResponse, GetSecurityControlDefinitionError, Credentials | HttpClient.HttpClient>;
export type GetSoftwareResourcesV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of resources that contain a specific software package. You identify the package with `PackageName` and `PackageType`. To narrow the results to one version of the package, include `PackageVersion`.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`. With `AwsOrganizations`, you can retrieve resources from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * You can use the `Filters` parameter to further refine results based on resource attributes, such as `ResourceType` or `Region`.
 *
 * This operation returns paginated results. To retrieve additional results, use the `NextToken` value from the previous response.
 */
export declare const getSoftwareResourcesV2: API.PaginatedOperationMethod<GetSoftwareResourcesV2Request & RegionInput, GetSoftwareResourcesV2Response, GetSoftwareResourcesV2Error, Credentials | HttpClient.HttpClient, SoftwareResourceResult>;
export type GetSoftwareStatisticsV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves aggregated counts of software packages installed on your resources, grouped by a field that you specify. For example, you can return the most common package types or the accounts with the most installed packages.
 *
 * Each count is the number of package-to-resource pairs that match the grouping value. A package installed on three resources contributes three to the count.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`. With `AwsOrganizations`, you can aggregate software from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * This operation doesn't paginate. Use `MaxStatisticResults` to control how many grouping values are returned.
 */
export declare const getSoftwareStatisticsV2: API.OperationMethod<GetSoftwareStatisticsV2Request & RegionInput, GetSoftwareStatisticsV2Response, GetSoftwareStatisticsV2Error, Credentials | HttpClient.HttpClient>;
export type GetSoftwareV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of software packages installed on your resources. Each result identifies a package by name, version, and type, and includes the number of resources that contain that package.
 *
 * You can use the `Scopes` parameter to define the data boundary for the query. Currently, `Scopes` supports `AwsOrganizations`. With `AwsOrganizations`, you can retrieve software from your entire organization or from specific organizational units. Only the delegated administrator account can use `Scopes`.
 *
 * You can use the `Filters` parameter to refine results based on package and resource attributes. You can use `Scopes` and `Filters` independently or together. When both are provided, `Scopes` narrows the data set first, and then `Filters` refines results within that scoped data set.
 *
 * To list the resources that contain a specific package, use `GetSoftwareResourcesV2`. To get counts of software grouped by a field, use `GetSoftwareStatisticsV2`.
 *
 * This operation returns paginated results. To retrieve additional results, use the `NextToken` value from the previous response.
 */
export declare const getSoftwareV2: API.PaginatedOperationMethod<GetSoftwareV2Request & RegionInput, GetSoftwareV2Response, GetSoftwareV2Error, Credentials | HttpClient.HttpClient, SoftwareResult>;
export type InviteMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Invites other Amazon Web Services accounts to become member accounts for the Security Hub CSPM administrator account that
 * the invitation is sent from.
 *
 * This operation is only used to invite accounts that don't belong to an Amazon Web Services organization.
 * Organization accounts don't receive invitations.
 *
 * Before you can use this action to invite a member, you must first use the `CreateMembers` action to create the member account in Security Hub CSPM.
 *
 * When the account owner enables Security Hub CSPM and accepts the invitation to become a member
 * account, the administrator account can view the findings generated in the member account.
 */
export declare const inviteMembers: API.OperationMethod<InviteMembersRequest & RegionInput, InviteMembersResponse, InviteMembersError, Credentials | HttpClient.HttpClient>;
export type ListAggregatorsV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of V2 aggregators.
 */
export declare const listAggregatorsV2: API.PaginatedOperationMethod<ListAggregatorsV2Request & RegionInput, ListAggregatorsV2Response, ListAggregatorsV2Error, Credentials | HttpClient.HttpClient, AggregatorV2>;
export type ListAutomationRulesError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * A list of automation rules and their metadata for the calling account.
 */
export declare const listAutomationRules: API.OperationMethod<ListAutomationRulesRequest & RegionInput, ListAutomationRulesResponse, ListAutomationRulesError, Credentials | HttpClient.HttpClient>;
export type ListAutomationRulesV2Error = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of automation rules and metadata for the calling account.
 */
export declare const listAutomationRulesV2: API.OperationMethod<ListAutomationRulesV2Request & RegionInput, ListAutomationRulesV2Response, ListAutomationRulesV2Error, Credentials | HttpClient.HttpClient>;
export type ListConfigurationPoliciesError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists the configuration policies that the Security Hub CSPM delegated administrator has created for your
 * organization. Only the delegated administrator can invoke this operation from the home Region.
 */
export declare const listConfigurationPolicies: API.PaginatedOperationMethod<ListConfigurationPoliciesRequest & RegionInput, ListConfigurationPoliciesResponse, ListConfigurationPoliciesError, Credentials | HttpClient.HttpClient, ConfigurationPolicySummary>;
export type ListConfigurationPolicyAssociationsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Provides information about the associations for your configuration policies and self-managed behavior. Only the
 * Security Hub CSPM delegated administrator can invoke this operation from the home Region.
 */
export declare const listConfigurationPolicyAssociations: API.PaginatedOperationMethod<ListConfigurationPolicyAssociationsRequest & RegionInput, ListConfigurationPolicyAssociationsResponse, ListConfigurationPolicyAssociationsError, Credentials | HttpClient.HttpClient, ConfigurationPolicyAssociationSummary>;
export type ListConnectorsError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the CSPM connectors and their metadata for the calling account.
 */
export declare const listConnectors: API.OperationMethod<ListConnectorsRequest & RegionInput, ListConnectorsResponse, ListConnectorsError, Credentials | HttpClient.HttpClient>;
export type ListConnectorsV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to retrieve a list of connectorsV2 and their metadata for the calling account.
 */
export declare const listConnectorsV2: API.OperationMethod<ListConnectorsV2Request & RegionInput, ListConnectorsV2Response, ListConnectorsV2Error, Credentials | HttpClient.HttpClient>;
export type ListEnabledProductsForImportError = InternalException | InvalidAccessException | LimitExceededException | CommonErrors;
/**
 * Lists all findings-generating solutions (products) that you are subscribed to receive
 * findings from in Security Hub CSPM.
 */
export declare const listEnabledProductsForImport: API.PaginatedOperationMethod<ListEnabledProductsForImportRequest & RegionInput, ListEnabledProductsForImportResponse, ListEnabledProductsForImportError, Credentials | HttpClient.HttpClient, NonEmptyString>;
export type ListExportJobsV2Error = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns the findings export jobs in your account as a paginated list of `ExportSummary` objects. You can filter the results by job `Status` or `DataType`.
 *
 * To page through the results, use the `MaxResults` and `NextToken` parameters. If the response includes a `NextToken` value, pass it in a subsequent request to retrieve the next page of results.
 *
 * Each `ExportSummary` reports the output `Format` of the job but not its full `OutputConfiguration`. To retrieve the filters and selected fields that a job was started with, call `GetExportJobV2`.
 */
export declare const listExportJobsV2: API.PaginatedOperationMethod<ListExportJobsV2Request & RegionInput, ListExportJobsV2Response, ListExportJobsV2Error, Credentials | HttpClient.HttpClient, ExportSummary>;
export type ListExposuresByRemediationV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the exposure findings tied to a specific remediation target. Results are sorted by
 * previous severity, highest first, and are paginated.
 */
export declare const listExposuresByRemediationV2: API.PaginatedOperationMethod<ListExposuresByRemediationV2Request & RegionInput, ListExposuresByRemediationV2Response, ListExposuresByRemediationV2Error, Credentials | HttpClient.HttpClient, ExposureFinding>;
export type ListFindingAggregatorsError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * If cross-Region aggregation is enabled, then `ListFindingAggregators` returns the Amazon Resource Name (ARN)
 * of the finding aggregator. You can run this operation from any Amazon Web Services Region.
 */
export declare const listFindingAggregators: API.PaginatedOperationMethod<ListFindingAggregatorsRequest & RegionInput, ListFindingAggregatorsResponse, ListFindingAggregatorsError, Credentials | HttpClient.HttpClient, FindingAggregator>;
export type ListFreeTrialStatusesV2Error = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the free trial status of Security Hub features. A delegated Security Hub administrator can list the status for accounts in its organization. Any other account can list the status only for itself. Free trial status remains available after a feature is disabled.
 */
export declare const listFreeTrialStatusesV2: API.PaginatedOperationMethod<ListFreeTrialStatusesV2Request & RegionInput, ListFreeTrialStatusesV2Response, ListFreeTrialStatusesV2Error, Credentials | HttpClient.HttpClient, AccountFreeTrialStatus>;
export type ListInvitationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * We recommend using Organizations instead of Security Hub CSPM invitations to manage your member accounts.
 * For information, see Managing Security Hub CSPM administrator and member accounts with Organizations
 * in the *Security Hub CSPM User Guide*.
 *
 * Lists all Security Hub CSPM membership invitations that were sent to the calling account.
 *
 * Only accounts that are managed by invitation can use this operation.
 * Accounts that are managed using the integration with Organizations don't receive invitations.
 */
export declare const listInvitations: API.PaginatedOperationMethod<ListInvitationsRequest & RegionInput, ListInvitationsResponse, ListInvitationsError, Credentials | HttpClient.HttpClient, Invitation>;
export type ListMembersError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists details about all member accounts for the current Security Hub CSPM administrator
 * account.
 *
 * The results include both member accounts that belong to an organization and member
 * accounts that were invited manually.
 */
export declare const listMembers: API.PaginatedOperationMethod<ListMembersRequest & RegionInput, ListMembersResponse, ListMembersError, Credentials | HttpClient.HttpClient, Member>;
export type ListOrganizationAdminAccountsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists the Security Hub CSPM administrator accounts. Can only be called by the organization
 * management account.
 */
export declare const listOrganizationAdminAccounts: API.PaginatedOperationMethod<ListOrganizationAdminAccountsRequest & RegionInput, ListOrganizationAdminAccountsResponse, ListOrganizationAdminAccountsError, Credentials | HttpClient.HttpClient, AdminAccount>;
export type ListSecurityControlDefinitionsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Lists all of the security controls that apply to a specified standard.
 */
export declare const listSecurityControlDefinitions: API.PaginatedOperationMethod<ListSecurityControlDefinitionsRequest & RegionInput, ListSecurityControlDefinitionsResponse, ListSecurityControlDefinitionsError, Credentials | HttpClient.HttpClient, SecurityControlDefinition>;
export type ListStandardsControlAssociationsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | CommonErrors;
/**
 * Specifies whether a control is currently enabled or disabled in each enabled standard in the calling account.
 *
 * This operation omits standards control associations for standard subscriptions where `StandardsControlsUpdatable` has value `NOT_READY_FOR_UPDATES`.
 */
export declare const listStandardsControlAssociations: API.PaginatedOperationMethod<ListStandardsControlAssociationsRequest & RegionInput, ListStandardsControlAssociationsResponse, ListStandardsControlAssociationsError, Credentials | HttpClient.HttpClient, StandardsControlAssociationSummary>;
export type ListTagsForResourceError = InternalException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Returns a list of tags associated with a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RegisterConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to complete the authorization based on input parameters.
 */
export declare const registerConnectorV2: API.OperationMethod<RegisterConnectorV2Request & RegionInput, RegisterConnectorV2Response, RegisterConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type StartConfigurationPolicyAssociationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Associates a target account, organizational unit, or the root with a specified configuration. The target can be
 * associated with a configuration policy or self-managed behavior. Only the Security Hub CSPM delegated administrator can
 * invoke this operation from the home Region.
 */
export declare const startConfigurationPolicyAssociation: API.OperationMethod<StartConfigurationPolicyAssociationRequest & RegionInput, StartConfigurationPolicyAssociationResponse, StartConfigurationPolicyAssociationError, Credentials | HttpClient.HttpClient>;
export type StartConfigurationPolicyDisassociationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Disassociates a target account, organizational unit, or the root from a specified configuration. When you
 * disassociate a configuration from its target, the target inherits the configuration of the closest parent. If there's no
 * configuration to inherit, the target retains its settings but becomes a self-managed account. A target can be disassociated from
 * a configuration policy or self-managed behavior. Only the Security Hub CSPM delegated administrator can invoke this
 * operation from the home Region.
 */
export declare const startConfigurationPolicyDisassociation: API.OperationMethod<StartConfigurationPolicyDisassociationRequest & RegionInput, StartConfigurationPolicyDisassociationResponse, StartConfigurationPolicyDisassociationError, Credentials | HttpClient.HttpClient>;
export type StartExportJobV2Error = AccessDeniedException | ConflictException | InternalServerException | OrganizationalUnitNotFoundException | OrganizationNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts an ad hoc export job that writes Security Hub findings to an Amazon Simple Storage Service (Amazon S3) bucket that you own. Because the export runs asynchronously, this operation returns only the `ExportJobId` of the new job; it doesn't wait for the export to finish. Use `GetExportJobV2` to poll the job, and `ListExportJobsV2` to view the export jobs in your account.
 *
 * Security Hub allows only one export job in the `RUNNING` state per account at a time. If an export job is already running, this operation returns a `ServiceQuotaExceededException`. Wait for the running job to finish, or cancel it with `CancelExportJobV2`, before you start a new one.
 *
 * Specify the destination bucket and Amazon Web Services Key Management Service (Amazon Web Services KMS) key in the `Destination` parameter, and the output format (`CSV` or `OCSF_JSON`), optional filters, and field selection in the `OutputConfiguration` parameter. Before you call this operation, you must grant Security Hub permission to write to your bucket and use your Amazon Web Services KMS key by adding the bucket policy and key policy statements shown in the Examples section.
 *
 * Two identities use your Amazon Web Services KMS key, and each needs its own permission. Security Hub uses the key when it writes the export objects to your bucket. The IAM principal that calls `StartExportJobV2` must also have `kms:GenerateDataKey` and `kms:Decrypt` permissions on the key. The Examples section shows both grants.
 *
 * A delegated administrator can use the optional `Scopes` parameter to export findings for specific organizations or organizational units (OUs).
 *
 * To make the request idempotent, provide a `ClientToken`. If you retry a `StartExportJobV2` request with the same `ClientToken` and the same request parameters, Security Hub returns the `ExportJobId` of the original job instead of starting a new one. If you reuse a `ClientToken` with different request parameters, this operation returns a `ConflictException`.
 */
export declare const startExportJobV2: API.OperationMethod<StartExportJobV2Request & RegionInput, StartExportJobV2Response, StartExportJobV2Error, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Adds one or more tags to a resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Removes one or more tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateActionTargetError = InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the name and description of a custom action target in Security Hub CSPM.
 */
export declare const updateActionTarget: API.OperationMethod<UpdateActionTargetRequest & RegionInput, UpdateActionTargetResponse, UpdateActionTargetError, Credentials | HttpClient.HttpClient>;
export type UpdateAggregatorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Udpates the configuration for the Aggregator V2.
 */
export declare const updateAggregatorV2: API.OperationMethod<UpdateAggregatorV2Request & RegionInput, UpdateAggregatorV2Response, UpdateAggregatorV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateAutomationRuleV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a V2 automation rule.
 */
export declare const updateAutomationRuleV2: API.OperationMethod<UpdateAutomationRuleV2Request & RegionInput, UpdateAutomationRuleV2Response, UpdateAutomationRuleV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateConfigurationPolicyError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates a configuration policy. Only the Security Hub CSPM delegated
 * administrator can invoke this operation from the home Region.
 */
export declare const updateConfigurationPolicy: API.OperationMethod<UpdateConfigurationPolicyRequest & RegionInput, UpdateConfigurationPolicyResponse, UpdateConfigurationPolicyError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorError = AccessDeniedException | ConflictException | InternalServerException | InvalidAccessException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a CSPM connector's configuration, such as the scope or regions for the connected cloud provider.
 */
export declare const updateConnector: API.OperationMethod<UpdateConnectorRequest & RegionInput, UpdateConnectorResponse, UpdateConnectorError, Credentials | HttpClient.HttpClient>;
export type UpdateConnectorV2Error = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Grants permission to update a connectorV2 based on its id and input parameters.
 */
export declare const updateConnectorV2: API.OperationMethod<UpdateConnectorV2Request & RegionInput, UpdateConnectorV2Response, UpdateConnectorV2Error, Credentials | HttpClient.HttpClient>;
export type UpdateFindingAggregatorError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * The *aggregation Region* is now called the *home Region*.
 *
 * Updates cross-Region aggregation settings. You can use this operation to update the Region linking mode and the list
 * of included or excluded Amazon Web Services Regions. However, you can't use this operation to change the home Region.
 *
 * You can invoke this operation from the current home Region only.
 */
export declare const updateFindingAggregator: API.OperationMethod<UpdateFindingAggregatorRequest & RegionInput, UpdateFindingAggregatorResponse, UpdateFindingAggregatorError, Credentials | HttpClient.HttpClient>;
export type UpdateFindingsError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * `UpdateFindings` is a deprecated operation. Instead of `UpdateFindings`, use
 * the `BatchUpdateFindings` operation.
 *
 * The `UpdateFindings` operation updates the `Note` and `RecordState` of the Security Hub CSPM aggregated
 * findings that the filter attributes specify. Any member account that can view the finding
 * can also see the update to the finding.
 *
 * Finding updates made with `UpdateFindings` aren't persisted if the same finding is later updated by the
 * finding provider through the `BatchImportFindings` operation. In addition, Security Hub CSPM doesn't
 * record updates made with `UpdateFindings` in the finding history.
 */
export declare const updateFindings: API.OperationMethod<UpdateFindingsRequest & RegionInput, UpdateFindingsResponse, UpdateFindingsError, Credentials | HttpClient.HttpClient>;
export type UpdateInsightError = InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the Security Hub CSPM insight identified by the specified insight ARN.
 */
export declare const updateInsight: API.OperationMethod<UpdateInsightRequest & RegionInput, UpdateInsightResponse, UpdateInsightError, Credentials | HttpClient.HttpClient>;
export type UpdateOrganizationConfigurationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceConflictException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the configuration of your organization in Security Hub CSPM. Only the
 * Security Hub CSPM administrator account can invoke this operation.
 */
export declare const updateOrganizationConfiguration: API.OperationMethod<UpdateOrganizationConfigurationRequest & RegionInput, UpdateOrganizationConfigurationResponse, UpdateOrganizationConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityControlError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceInUseException | ResourceNotFoundException | CommonErrors;
/**
 * Updates the properties of a security control.
 */
export declare const updateSecurityControl: API.OperationMethod<UpdateSecurityControlRequest & RegionInput, UpdateSecurityControlResponse, UpdateSecurityControlError, Credentials | HttpClient.HttpClient>;
export type UpdateSecurityHubConfigurationError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | LimitExceededException | ResourceNotFoundException | CommonErrors;
/**
 * Updates configuration options for Security Hub CSPM.
 */
export declare const updateSecurityHubConfiguration: API.OperationMethod<UpdateSecurityHubConfigurationRequest & RegionInput, UpdateSecurityHubConfigurationResponse, UpdateSecurityHubConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateStandardsControlError = AccessDeniedException | InternalException | InvalidAccessException | InvalidInputException | ResourceNotFoundException | CommonErrors;
/**
 * Used to control whether an individual security standard control is enabled or
 * disabled.
 *
 * Calls to this operation return a `RESOURCE_NOT_FOUND_EXCEPTION` error when the standard subscription for the control has `StandardsControlsUpdatable` value `NOT_READY_FOR_UPDATES`.
 */
export declare const updateStandardsControl: API.OperationMethod<UpdateStandardsControlRequest & RegionInput, UpdateStandardsControlResponse, UpdateStandardsControlError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=securityhub.d.ts.map