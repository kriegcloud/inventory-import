import { AuthError } from "alchemy/Auth/AuthProvider";
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import * as Schema from "effect/Schema";
/** Service account token used for unattended access. */
export declare const OP_SERVICE_ACCOUNT_TOKEN_ENV = "OP_SERVICE_ACCOUNT_TOKEN";
/**
 * A stored 1Password profile entry: a desktop account selector (the desktop
 * app holds the authorization), or a service account token.
 */
export declare const OnePasswordAuthConfigSchema: Schema.Union<readonly [Schema.Struct<{
    readonly method: Schema.Literal<"desktop">;
    readonly account: Schema.NonEmptyString;
}>, Schema.Struct<{
    readonly method: Schema.Literal<"service-account">;
    readonly token: Schema.NonEmptyString;
}>]>;
export type OnePasswordAuthConfig = typeof OnePasswordAuthConfigSchema.Type;
export type OnePasswordResolvedCredentials = {
    readonly method: "service-account";
    readonly token: Redacted.Redacted<string>;
} | {
    readonly method: "desktop";
    readonly account: string;
};
/**
 * 1Password profile authentication: a desktop account selector (1Password
 * manages the authorization) or a stored service account token.
 */
export declare const OnePasswordAuth: import("effect/Layer").Layer<never, never, import("alchemy/Auth/Registry").AuthProviders | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("effect/crypto/SecureRandom").SecureRandom>;
/**
 * Resolve credentials independently of secrets loaded by earlier providers:
 * `OP_SERVICE_ACCOUNT_TOKEN` first, then an explicit desktop `account`, then
 * the selected profile.
 */
export declare const resolveCredentials: (account?: string) => Effect.Effect<OnePasswordResolvedCredentials, AuthError | Config.ConfigError | import("alchemy/Auth/Profile").MissingProviderConfig | import("alchemy/Auth/AuthProvider").NeedsReauth | import("effect/PlatformError").PlatformError | import("alchemy/Auth/Profile").ProfileError, import("alchemy/Auth/Registry").AuthProviders | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("alchemy/Auth/Profile").ProfileStore | import("effect/crypto/SecureRandom").SecureRandom>;
//# sourceMappingURL=AuthProvider.d.ts.map