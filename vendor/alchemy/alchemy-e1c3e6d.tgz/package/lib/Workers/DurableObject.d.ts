/**
 * Shared Durable Object registration and export mechanics: ONE
 * implementation of "register the class on its hosting worker and export
 * it", used by every engine whose workers host Durable Objects.
 * Binding registration, runtime-env namespace resolution, the
 * plan-time mock-state evaluation that discovers transitive bindings, and
 * the class export are engine-invariant; the binding data shape and the
 * stub flavor come from the engine.
 *
 * @internal
 */
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type { RpcErrorClass } from "../Rpc.ts";
/**
 * The lifecycle handlers a Durable Object instance may return. Erased only
 * at the heterogeneous export/dispatch boundary — each engine declares its
 * own precisely typed shape.
 */
export interface DurableObjectShape {
    fetch?: Effect.Effect<any, any, any>;
    alarm?: (...args: any[]) => Effect.Effect<any, any, any>;
    webSocketOpen?: (...args: any[]) => Effect.Effect<any, any, any>;
    webSocketMessage?: (...args: any[]) => Effect.Effect<any, any, any>;
    webSocketClose?: (...args: any[]) => Effect.Effect<any, any, any>;
    webSocketError?: (...args: any[]) => Effect.Effect<any, any, any>;
}
/** The export record a hosting worker publishes per Durable Object class. */
export interface DurableObjectExport<Shape = any> {
    readonly kind: "durableObject";
    /**
     * The class's two-phase constructor: the outer Effect resolves the
     * object's dependencies, the inner one builds each instance.
     */
    readonly constructor: Effect.Effect<Effect.Effect<Shape, never, any>, never, any>;
    /** The infrastructure services the constructor was declared with. */
    readonly services: Context.Context<never>;
}
export declare const isDurableObjectExport: (value: unknown) => value is DurableObjectExport;
/** The least a native namespace binding found in the runtime environment offers. */
export interface DurableObjectNamespaceLike {
    getByName(name: string, options?: unknown): unknown;
}
/**
 * A resource that can HOST Durable Objects: a worker resource whose
 * runtime context exposes `export` alongside the resource's `bind`.
 */
export interface DurableObjectHostLike {
    readonly bind: (template: TemplateStringsArray, ...args: any[]) => (data: any) => Effect.Effect<void, never, any>;
    readonly export: (name: string, value: any) => Effect.Effect<void, never, any>;
}
/**
 * Resolve the native namespace binding a class is registered under from
 * the runtime environment; `undefined` at plan time (there is nothing to
 * call yet).
 */
export declare const resolveDurableObjectNamespace: <Namespace extends DurableObjectNamespaceLike>(namespace: string) => Effect.Effect<Namespace | undefined>;
/**
 * Export a class's constructor on its hosting worker. At plan time the
 * constructor's outer Effect runs once against `planContext` (a mock
 * Durable Object state) so the transitive bindings the object depends on
 * are discovered and registered on the worker.
 */
export declare const exportDurableObjectClass: <Shape>(host: DurableObjectHostLike, namespace: string, constructor: DurableObjectExport<Shape>["constructor"], planContext: Context.Context<any>) => Effect.Effect<void, never, any>;
/** A Durable Object class declaration as registered on its hosting worker. */
export interface DurableObjectBindingDeclaration {
    /** Binding name — the Durable Object's logical id. */
    readonly name: string;
    /** The exported class name backing the binding. */
    readonly className: string;
}
/**
 * The least a native namespace stub offers the engine's stub flavor: an
 * HTTP entry (workerd-style stubs are fetchers).
 */
export interface DurableObjectStubLike {
    readonly fetch?: (input: string | URL | globalThis.Request, init?: RequestInit) => Promise<Response>;
}
/** Per-class options a host's stub flavor honors. */
export interface DurableObjectStubOptions {
    /**
     * Tagged-error classes the class's RPC methods can fail with: failures
     * crossing the RPC boundary are reconstructed as real instances (see
     * `RpcErrorClass` in `Rpc.ts`).
     */
    readonly errors?: ReadonlyArray<RpcErrorClass> | undefined;
}
/**
 * A worker resource that hosts Durable Objects through the shared
 * declaration mechanics: `bind`/`export` plus the engine's two variation
 * points, assigned by the engine's runtime context.
 */
export interface DurableObjectEngineHost extends DurableObjectHostLike {
    readonly Type: string;
    readonly LogicalId: string;
    /** Host-native binding data for a Durable Object class declaration. */
    readonly durableObjectBinding: (decl: DurableObjectBindingDeclaration) => unknown;
    /** The engine's stub flavor over a native instance stub. */
    readonly durableObjectStub: (nativeStub: DurableObjectStubLike, namespace: string, options: DurableObjectStubOptions) => unknown;
}
export declare const isDurableObjectHost: (value: unknown) => value is DurableObjectEngineHost;
/** Resolve the ambient hosting worker and reject cross-provider declarations. */
export declare const requireDurableObjectHost: (namespace: string, provider: string) => Effect.Effect<import("../Resource.ts").ResourceLike<string, any, object, any, any, any> & DurableObjectEngineHost, never, never>;
/** Planning may compose deferred state Effects, but cannot execute state operations. */
export declare const durableObjectPlanContext: <I, S>(tag: Context.Key<I, S>, effectProperties?: readonly (keyof S)[]) => Context.Context<I>;
/**
 * The class/layer mechanics of a Durable Object declaration for engines
 * whose namespaces are local to the hosting worker: the inline form
 * (`(name, impl)`), the class form with an inline impl
 * (`<Self>()(name, impl)`), and the modular class form
 * (`<Self, Shape>()(name, props?)` + `static make(impl)`).
 */
export declare const makeDurableObjectDeclaration: (scope: Context.Key<any, any>, options: {
    readonly kind: string;
    readonly provider: string;
    readonly planContext: Context.Context<any>;
}) => any;
//# sourceMappingURL=DurableObject.d.ts.map