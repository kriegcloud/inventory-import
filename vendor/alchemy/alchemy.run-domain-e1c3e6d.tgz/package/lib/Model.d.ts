import * as Context from "effect/Context";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as RpcMiddleware from "effect/rpc/RpcMiddleware";
import * as Aggregate from "./Aggregate.ts";
import type { Annotations } from "./Annotations.ts";
import type * as Command from "./Command.ts";
import * as Compaction from "./Compaction.ts";
import type * as Decision from "./Decision.ts";
import * as Kernel from "./Kernel.ts";
import * as Key from "./Key.ts";
import * as Mention from "./Mention.ts";
import type * as Middleware from "./Middleware.ts";
import { type AggregateStore, Platform, type StreamStore, type ViewStore } from "./Platform.ts";
import type * as Policy from "./Policy.ts";
import * as Projection from "./Projection.ts";
import * as Query from "./Query.ts";
import * as Read from "./Read.ts";
import type * as Relation from "./Relation.ts";
import * as Rewrite from "./Rewrite.ts";
import * as Saga from "./Saga.ts";
import type * as DomainStream from "./Stream.ts";
import * as Telemetry from "./Telemetry.ts";
import * as View from "./View.ts";
type Identifier<T> = T extends Context.Key<infer I, unknown> ? I : never;
declare const Internals_base: Context.ServiceClass<Internals, "alchemy/Domain/ModelInternals", {
    readonly kernel: Kernel.Kernel;
    readonly aggregates: ReadonlyMap<string, AggregateStore>;
    readonly views: ReadonlyMap<string, ViewStore>;
    readonly streams: ReadonlyMap<string, StreamStore>;
    /**
     * The client of what implements each command, by command tag: its
     * aggregate, or its decision as an aggregate client that takes no target.
     */
    readonly commands: ReadonlyMap<string, Aggregate.ClientImpl>;
    /** Each view's read API, by view name. */
    readonly viewHosts: ReadonlyMap<string, View.Host<unknown, Key.Any, unknown>>;
    /** Each stream's API, by stream name. */
    readonly streamHosts: ReadonlyMap<string, DomainStream.Host<Key.Any, unknown>>;
    /** Each query, hosted, by query name. */
    readonly queries: ReadonlyMap<string, Query.Host>;
    /** Each guarded view's and stream's `validate`, from its Layer, by name. */
    readonly validators: ReadonlyMap<string, Read.AnyValidate>;
    /**
     * Wait until a view or stream, by name, has applied a command's events on
     * the keys they reach: every one, or `key` alone for a view. A command
     * none of whose events reach it is not waited for.
     */
    readonly caughtUp: ReadonlyMap<string, Query.CaughtUp>;
    /**
     * Wait until every view a command's events reach has applied them, on
     * every key, through any views between. A view whose history has not all
     * reached it yet (one a deploy is still backfilling) is not waited for.
     *
     * "Applied" is what the view key's stored checkpoints say, so the
     * guarantee is only as strong as the platform's: see
     * `ViewSnapshot.checkpoints` for what a platform with read replicas owes.
     */
    readonly applied: (receipt: Aggregate.Receipt, options?: {
        readonly timeout?: Duration.Input;
    }) => Effect.Effect<void, View.ConsistencyTimeout>;
}>;
/**
 * Low-level access to a built Model's kernel and stores (story runner,
 * diagnostics).
 *
 * @internal
 */
export declare class Internals extends Internals_base {
}
/**
 * The entities that make up a Model.
 */
export interface Members<A extends ReadonlyArray<Aggregate.Any>, V extends ReadonlyArray<View.Any>, P extends ReadonlyArray<Policy.Any>, J extends ReadonlyArray<Projection.Any>, S extends ReadonlyArray<DomainStream.Any>, G extends ReadonlyArray<Saga.Any> = readonly [], Q extends ReadonlyArray<Query.Any> = readonly [], D extends ReadonlyArray<Decision.Any> = readonly [], C extends ReadonlyArray<Compaction.Any> = readonly []> {
    readonly aggregates: A;
    /**
     * The rewrites that may be run on the model's aggregates. A projection
     * given events one of them changes needs a `rewrite` handler in its Layer:
     * the model fails to build without it.
     */
    readonly rewrites?: ReadonlyArray<Rewrite.Any>;
    /** The compactions of the model's aggregates. `layer` requires each one's Layer. */
    readonly compactions?: C;
    /**
     * The decisions that implement commands across several aggregates. Each
     * command has one implementation: listing a decision for a command an
     * aggregate or another decision implements is a type error on its entry.
     */
    readonly decisions?: ImplementedOnce<A, D>;
    readonly views?: V;
    readonly policies?: P;
    readonly projections?: J;
    readonly streams?: S;
    readonly sagas?: G;
    /** The queries it answers, from the stores its projections write. */
    readonly queries?: Q;
    /**
     * Rules that hold across the model's aggregates whenever nothing is left to
     * react: every policy has handled the events it reacts to and every saga
     * has finished or waits. Each is named and given every instance, with its
     * state and the events it recorded, every key of the model's views with
     * its state, and what each projection was given: `true` while the rule holds. `Explore.check` looks for a
     * sequence of commands that breaks one.
     */
    readonly invariants?: {
        readonly [name: string]: (model: Instances<A> & Keys<V> & Fed<J>) => boolean;
    };
    /**
     * Rules that relate a few instances at all times, each made with
     * `Domain.Relation`. `Verify.model` proves one where every command and
     * every decision that records on its aggregates keeps it, and looks for a
     * sequence of commands that breaks one it cannot prove.
     */
    readonly relations?: {
        readonly [name: string]: Relation.Any;
    };
    /**
     * Rules that hold once everything has run its course: nothing is left to
     * react, and every scheduled command has come due and run. Where an
     * invariant says what is never true along the way, one of these says where
     * every sequence ends up. Each is named and given what an invariant is.
     * `Explore.check` runs every sequence it finds to its end and looks for
     * one that ends without it.
     */
    readonly eventually?: {
        readonly [name: string]: (model: Instances<A> & Keys<V> & Fed<J>) => boolean;
    };
    /**
     * What must be able to happen. Every other rule says what the model never
     * does, and a model that refuses every command keeps them all. Each of
     * these is named and given what an invariant is, and `Verify.model` looks
     * for a sequence of commands that makes it true: it fails when none does.
     */
    readonly sometimes?: {
        readonly [name: string]: (model: Instances<A> & Keys<V> & Fed<J>) => boolean;
    };
}
/**
 * What each of a model's projections has been given, by projection name,
 * oldest first: what a model invariant is given. A projection writes where
 * the model cannot see, so what it was told is what a rule can speak of.
 */
export type Fed<J extends ReadonlyArray<Projection.Any>> = {
    readonly [K in J[number] as K["projectionName"]]: ReadonlyArray<{
        /** The id of the key the event was given under. */
        readonly id: string;
        readonly event: Aggregate.InstanceOf<K["definition"]["on"][number]>;
    }>;
};
/** Every key of a model's views that has a state, by view name: what a model invariant is given. */
export type Keys<V extends ReadonlyArray<View.Any>> = {
    readonly [K in V[number] as K["viewName"]]: ReadonlyArray<{
        /** The id of the instance the key follows. */
        readonly id: string;
        readonly state: NonNullable<View.StateOf<K>>;
    }>;
};
/** Every instance of a model's aggregates, by aggregate name: what a model invariant is given. */
export type Instances<A extends ReadonlyArray<Aggregate.Any>> = {
    readonly [K in A[number] as K["aggregateName"]]: ReadonlyArray<{
        readonly id: Aggregate.IdOf<K>;
        readonly state: Aggregate.StateOf<K>;
        /** Every event the instance recorded, oldest first. */
        readonly events: ReadonlyArray<Aggregate.EventOf<K>>;
    }>;
};
/**
 * The class type returned by {@link make}.
 *
 * `Provided` is every aggregate, view, stream and projection-progress service
 * the Model provides; `Policies` is every policy, projection and query whose
 * implementation `layer` requires.
 */
export interface ModelClass<Name extends string, Provided, Policies, Parts extends Servable = Servable> {
    new (_: never): {};
    readonly kind: "Model";
    readonly annotations: Annotations;
    readonly modelName: Name;
    /** The model's aggregates, in order. */
    readonly aggregates: Parts["aggregates"];
    /** The model's decisions, in order. */
    readonly decisions: Parts["decisions"];
    /** Every command of the model's aggregates and decisions, each once. */
    readonly commands: Parts["commands"];
    /** The model's views, in order. */
    readonly views: Parts["views"];
    /** The model's streams, in order. */
    readonly streams: Parts["streams"];
    /** The model's queries, in order. */
    readonly queries: Parts["queries"];
    /** The model's own invariants, by name. */
    readonly invariants: {
        readonly [name: string]: (model: never) => boolean;
    };
    /** What holds once everything has run its course, by name. */
    readonly eventually: {
        readonly [name: string]: (model: never) => boolean;
    };
    /** What must be able to happen, by name. */
    readonly sometimes: {
        readonly [name: string]: (model: never) => boolean;
    };
    /** The model's relations, by name. */
    readonly relations: {
        readonly [name: string]: Relation.Any;
    };
    readonly definitions: Kernel.Definitions;
    /**
     * Host every entity on the ambient {@link Platform}. The policy and
     * projection Layers (`handlers`) are built after the aggregates, views and
     * streams exist, so a handler can resolve them while it is constructed.
     * `options` tune how it's hosted, such as what it records in traces.
     */
    layer<E = never, R = never>(handlers: Layer.Layer<Policies, E, R>, options?: LayerOptions<Parts["views"][number]["viewName"]>): Layer.Layer<Provided | Internals, E, Platform | SecureRandom.SecureRandom | Exclude<R, Provided>>;
}
/**
 * Structural constraint satisfied by every Model class.
 */
export interface Any extends Servable {
    readonly kind: "Model";
    readonly annotations: Annotations;
    readonly modelName: string;
    readonly definitions: Kernel.Definitions;
}
/**
 * What an Api over a model may serve, in the order the model lists them:
 * its aggregates, their commands, its views and its streams. An Api names
 * what it serves from these.
 */
export interface Servable {
    readonly aggregates: ReadonlyArray<Aggregate.Any>;
    readonly decisions: ReadonlyArray<Decision.Any>;
    /** Every command of the model's aggregates and decisions, each once. */
    readonly commands: ReadonlyArray<Command.Any>;
    readonly views: ReadonlyArray<View.Any>;
    readonly streams: ReadonlyArray<DomainStream.Any>;
    readonly queries: ReadonlyArray<Query.Any>;
}
/** The name of the aggregate, among `A`, that implements the command tagged `Tag`. */
type ImplementerOf<A extends ReadonlyArray<Aggregate.Any>, Tag> = A[number] extends infer Agg ? Agg extends Aggregate.Any ? string extends Agg["definition"]["commands"][number]["tag"] ? never : Tag extends Agg["definition"]["commands"][number]["tag"] ? Agg["aggregateName"] : never : never : never;
/** Every decision of `D` but the one at index `K`. */
type OtherDecisions<D extends ReadonlyArray<Decision.Any>, K> = {
    [J in keyof D]: J extends K ? never : D[J];
}[number];
/**
 * A model's decisions, each implementing a command nothing else in the
 * model implements, and reading only the model's aggregates. An entry whose
 * command an aggregate or another decision implements, or that reads an
 * aggregate the model leaves out, becomes a message naming it.
 */
export type ImplementedOnce<A extends ReadonlyArray<Aggregate.Any>, D extends ReadonlyArray<Decision.Any>> = {
    readonly [K in keyof D]: string extends D[K]["decisionName"] ? D[K] : [ImplementerOf<A, D[K]["decisionName"]>] extends [never] ? D[K]["decisionName"] extends OtherDecisions<D, K>["decisionName"] ? `${D[K]["decisionName"]} is already implemented by another decision` : [UnhostedRead<A, D[K]>] extends [never] ? D[K] : `${D[K]["decisionName"]} reads ${UnhostedRead<A, D[K]>}, which is not in the model's aggregates` : `${D[K]["decisionName"]} is already implemented by ${ImplementerOf<A, D[K]["decisionName"]>}`;
};
/** The names of the aggregates `D` reads that are not among `A`. */
type UnhostedRead<A extends ReadonlyArray<Aggregate.Any>, D extends Decision.Any> = Exclude<D["reads"][keyof D["reads"]]["aggregateName"], A[number]["aggregateName"]>;
/** What a model's members serve. */
export interface ServableBy<A extends ReadonlyArray<Aggregate.Any>, V extends ReadonlyArray<View.Any>, S extends ReadonlyArray<DomainStream.Any>, Q extends ReadonlyArray<Query.Any> = readonly [], D extends ReadonlyArray<Decision.Any> = readonly []> {
    readonly aggregates: A;
    readonly decisions: D;
    readonly commands: ReadonlyArray<A[number]["definition"]["commands"][number] | D[number]["command"]>;
    readonly views: V;
    readonly streams: S;
    readonly queries: Q;
}
type ProvidedBy<A extends ReadonlyArray<Aggregate.Any>, V extends ReadonlyArray<View.Any>, J extends ReadonlyArray<Projection.Any>, S extends ReadonlyArray<DomainStream.Any>, G extends ReadonlyArray<Saga.Any>, D extends ReadonlyArray<Decision.Any> = readonly []> = Identifier<A[number]> | Identifier<D[number]> | Identifier<V[number]> | Identifier<S[number]> | Saga.Identifier<G[number]> | Projection.ProgressIdentifier<J[number]>;
/** The middleware among `Ms` that checks something, where one that provides request context only says who is calling. */
type Checks<Ms extends Middleware.List> = Ms[number] extends infer M ? M extends RpcMiddleware.AnyService ? [RpcMiddleware.Provides<M["Identifier"]>] extends [never] ? M["Identifier"] : never : never : never;
/**
 * A mention of something behind the middleware `Ms`: running the process
 * requires the hosted model and a Layer for each middleware that checks
 * something, and a session is started as the request context the others
 * provide.
 */
type MentionBehind<Provided, Ms extends Middleware.List> = Mention.Mention<Provided | Checks<Ms>, Middleware.Provides<Ms>>;
/**
 * What an `AI.Process` mentions of a model, as members of its class: each
 * command by its tag, each aggregate by its name (every command it takes),
 * and each view by its name (its state for a key).
 */
export type Mentions<Provided, A extends ReadonlyArray<Aggregate.Any>, V extends ReadonlyArray<View.Any>, D extends ReadonlyArray<Decision.Any> = readonly []> = {
    readonly [C in A[number]["definition"]["commands"][number] | D[number]["command"] as Named<C["tag"]>]: MentionBehind<Provided, C["middleware"]>;
} & {
    readonly [K in A[number] as Named<K["aggregateName"]>]: MentionBehind<Provided, K["definition"]["commands"][number]["middleware"]>;
} & {
    readonly [K in V[number] as Named<K["viewName"]>]: MentionBehind<Provided, Read.MiddlewareOf<K["definition"]>>;
};
/**
 * A name known as one literal. A model whose members were widened, or
 * named by a pattern (`Balance\${number}`), has no member to mention for them.
 */
type Named<Name extends string> = {} extends Record<Name, unknown> ? never : Name;
/** How a model's `layer` hosts it: tuning that doesn't change what the model means. */
export interface LayerOptions<Views extends string = string> {
    /** What the hosted model records in traces. See {@link Telemetry.Options}. */
    readonly telemetry?: Telemetry.Options;
    /**
     * Before Domain version 0, models in one Worker that listed the same
     * aggregate, view or saga shared its Durable Object class, and so its data.
     * Each model now has classes of its own, and the first deploy renames the
     * shared class to the model's, keeping its data. When two models shared a
     * class, only one can keep it: set `false` on the others, which start
     * empty. The deploy fails while more than one would take it over.
     *
     * @default true
     */
    readonly legacyData?: boolean;
    /**
     * Views that fill lazily when they are added. A deploy that adds one waits
     * for nothing: each key reads its history the first time it is read (or when
     * its source next changes). Only for a view that reads one aggregate and is
     * keyed by it, so each key's history is its own instance's events. (Such a
     * view is always rebuilt this way when its `version` is bumped.)
     */
    readonly lazy?: ReadonlyArray<Views>;
}
/** Every implementation a model's `layer` requires: its policies, projections, sagas and queries. */
/** A guarded view's or stream's Layer, which provides its `validate`. */
type ValidatorOf<X> = X extends {
    readonly Validator: Context.Key<infer I, unknown>;
    readonly definition: infer D;
} ? unknown extends I ? never : Read.Guarded<D> extends true ? I : never : never;
type HandledBy<P extends ReadonlyArray<Policy.Any>, J extends ReadonlyArray<Projection.Any>, G extends ReadonlyArray<Saga.Any>, Q extends ReadonlyArray<Query.Any> = readonly [], V extends ReadonlyArray<View.Any> = readonly [], S extends ReadonlyArray<DomainStream.Any> = readonly [], C extends ReadonlyArray<Compaction.Any> = readonly []> = Identifier<P[number]> | Identifier<J[number]> | Compaction.Identifier<C[number]> | Saga.ImplementationIdentifier<G[number]> | Query.Identifier<Q[number]> | ValidatorOf<V[number]> | ValidatorOf<S[number]>;
/**
 * The aggregates, views and policies you host together. `layer(policies)`
 * builds them all on the Platform you provide, and provides each aggregate
 * and view as a service.
 *
 * ### Declaring and hosting a model
 * **Example:** In memory, with its policies and external systems
 * ```typescript
 * import * as Domain from "@alchemy.run/domain";
 * import * as Layer from "effect/Layer";
 * import { Account } from "./Account.ts";
 * import { AccountSummary } from "./AccountSummary.ts";
 * import { Customer } from "./Customer.ts";
 * import { MainAccountProvisioning, MainAccountProvisioningLive } from "./MainAccountProvisioning.ts";
 *
 * export class Bank extends Domain.Model("Bank", {
 *   aggregates: [Account, Customer],
 *   views: [AccountSummary],
 *   policies: [MainAccountProvisioning],
 * }) {}
 *
 * export const BankInMemory = Bank.layer(MainAccountProvisioningLive).pipe(
 *   Layer.provide(Domain.InMemory),
 * );
 * ```
 *
 * ### Checking the declaration
 * Building the Layer checks the definitions first: a view consuming a source
 * keyed by another aggregate without `keyOf`, a view with `state` but no
 * `initial`, a policy listening for an event no source emits, a stream with
 * two writers, a schema with no JSON form. It dies with a
 * `Domain.DefinitionError` for each problem, all in one Cause, so a test
 * that builds the Layer reports every one. Problems that depend on what a
 * handler returns, such as `decide` returning an event its command does not
 * declare, surface when the handler runs.
 *
 * **Example:** A unit test for the whole Model
 * ```typescript
 * import { it } from "@effect/vitest";
 * import * as Layer from "effect/Layer";
 * import { BankInMemory } from "./Bank.ts";
 *
 * it.effect("the model is well defined", () => Layer.build(BankInMemory));
 * ```
 *
 * ### Deciding across aggregates
 * List each `Domain.Decision` in `decisions`. Every command has one
 * implementation, an aggregate or a decision: a second is a type error on
 * its entry.
 *
 * **Example:** A model with a decision
 * ```typescript
 * export class Bank extends Domain.Model("Bank", {
 *   aggregates: [Account],
 *   decisions: [Transfer],
 * }) {}
 * ```
 *
 * ### Annotating models
 * The last argument is its annotations: data for what is built on the
 * model, read back as `X.annotations`. Add your own keys by augmenting
 * `Domain.Annotations`.
 *
 * A model lists its declarations, so tooling can walk them and read each
 * one's annotations.
 *
 * **Example:** A description
 * ```typescript
 * export class Bank extends Domain.Model(
 *   "Bank",
 *   { aggregates: [Account], views: [AccountSummary] },
 *   { description: "Accounts and their balances." },
 * ) {}
 *
 * const glossary = Bank.commands.map((command) => `${command.tag}: ${command.annotations.description}`);
 * ```
 *
 * @primitive
 */
export declare const make: <const Name extends string, const A extends ReadonlyArray<Aggregate.Any>, const V extends ReadonlyArray<View.Any> = readonly [], const P extends ReadonlyArray<Policy.Any> = readonly [], const J extends ReadonlyArray<Projection.Any> = readonly [], const S extends ReadonlyArray<DomainStream.Any> = readonly [], const G extends ReadonlyArray<Saga.Any> = readonly [], const Q extends ReadonlyArray<Query.Any> = readonly [], const D extends ReadonlyArray<Decision.Any> = readonly [], const C extends ReadonlyArray<Compaction.Any> = readonly []>(name: Name, members: Members<A, V, P, J, S, G, Q, D, C>, annotations?: Annotations) => ModelClass<Name, ProvidedBy<A, V, J, S, G, D>, HandledBy<P, J, G, Q, V, S, C>, ServableBy<A, V, S, Q, D>> & Mentions<ProvidedBy<A, V, J, S, G, D>, A, V, D>;
export {};
//# sourceMappingURL=Model.d.ts.map