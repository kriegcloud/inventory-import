import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceInUseException_base: S.TaggedErrorClass<"ResourceInUseException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceInUseException extends /*@__PURE__*/ ResourceInUseException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const TagsAlreadyExistException_base: S.TaggedErrorClass<"TagsAlreadyExistException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TagsAlreadyExistException extends /*@__PURE__*/ TagsAlreadyExistException_base {
}
declare const TooManyTagsException_base: S.TaggedErrorClass<"TooManyTagsException", {
    readonly message: any;
    readonly ResourceName: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class TooManyTagsException extends /*@__PURE__*/ TooManyTagsException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type ResourceGroupName = string;
export type ComponentName = string;
export type WorkloadName = string;
export type Tier = "CUSTOM" | "DEFAULT" | "DOT_NET_CORE" | "DOT_NET_WORKER" | "DOT_NET_WEB_TIER" | "DOT_NET_WEB" | "SQL_SERVER" | "SQL_SERVER_ALWAYSON_AVAILABILITY_GROUP" | "MYSQL" | "POSTGRESQL" | "JAVA_JMX" | "ORACLE" | "SAP_HANA_MULTI_NODE" | "SAP_HANA_SINGLE_NODE" | "SAP_HANA_HIGH_AVAILABILITY" | "SAP_ASE_SINGLE_NODE" | "SAP_ASE_HIGH_AVAILABILITY" | "SQL_SERVER_FAILOVER_CLUSTER_INSTANCE" | "SHAREPOINT" | "ACTIVE_DIRECTORY" | "SAP_NETWEAVER_STANDARD" | "SAP_NETWEAVER_DISTRIBUTED" | "SAP_NETWEAVER_HIGH_AVAILABILITY" | (string & {});
export type ComponentConfiguration = string;
export interface WorkloadConfiguration {
    WorkloadName?: string | undefined;
    Tier?: Tier | undefined;
    Configuration?: string | undefined;
}
export interface AddWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadConfiguration: WorkloadConfiguration;
}
export type WorkloadId = string;
export interface AddWorkloadResponse {
    WorkloadId?: string | undefined;
    WorkloadConfiguration?: WorkloadConfiguration | undefined;
}
export type OpsCenterEnabled = boolean;
export type CWEMonitorEnabled = boolean;
export type OpsItemSNSTopicArn = string;
export type SNSNotificationArn = string;
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export type AutoConfigEnabled = boolean;
export type AutoCreate = boolean;
export type GroupingType = "ACCOUNT_BASED" | (string & {});
export type AttachMissingPermission = boolean;
export interface CreateApplicationRequest {
    ResourceGroupName?: string | undefined;
    OpsCenterEnabled?: boolean | undefined;
    CWEMonitorEnabled?: boolean | undefined;
    OpsItemSNSTopicArn?: string | undefined;
    SNSNotificationArn?: string | undefined;
    Tags?: Tag[] | undefined;
    AutoConfigEnabled?: boolean | undefined;
    AutoCreate?: boolean | undefined;
    GroupingType?: GroupingType | undefined;
    AttachMissingPermission?: boolean | undefined;
}
export type AccountId = string;
export type LifeCycle = string;
export type Remarks = string;
export type DiscoveryType = "RESOURCE_GROUP_BASED" | "ACCOUNT_BASED" | (string & {});
export interface ApplicationInfo {
    AccountId?: string | undefined;
    ResourceGroupName?: string | undefined;
    LifeCycle?: string | undefined;
    OpsItemSNSTopicArn?: string | undefined;
    SNSNotificationArn?: string | undefined;
    OpsCenterEnabled?: boolean | undefined;
    CWEMonitorEnabled?: boolean | undefined;
    Remarks?: string | undefined;
    AutoConfigEnabled?: boolean | undefined;
    DiscoveryType?: DiscoveryType | undefined;
    AttachMissingPermission?: boolean | undefined;
}
export interface CreateApplicationResponse {
    ApplicationInfo?: ApplicationInfo | undefined;
}
export type CustomComponentName = string;
export type ResourceARN = string;
export type ResourceList = string[];
export interface CreateComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
    ResourceList: string[];
}
export interface CreateComponentResponse {
}
export type LogPatternSetName = string;
export type LogPatternName = string;
export type LogPatternRegex = string;
export type LogPatternRank = number;
export interface CreateLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
    Pattern: string;
    Rank: number;
}
export interface LogPattern {
    PatternSetName?: string | undefined;
    PatternName?: string | undefined;
    Pattern?: string | undefined;
    Rank?: number | undefined;
}
export interface CreateLogPatternResponse {
    LogPattern?: LogPattern | undefined;
    ResourceGroupName?: string | undefined;
}
export interface DeleteApplicationRequest {
    ResourceGroupName: string;
}
export interface DeleteApplicationResponse {
}
export interface DeleteComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
}
export interface DeleteComponentResponse {
}
export interface DeleteLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
}
export interface DeleteLogPatternResponse {
}
export interface DescribeApplicationRequest {
    ResourceGroupName: string;
    AccountId?: string | undefined;
}
export interface DescribeApplicationResponse {
    ApplicationInfo?: ApplicationInfo | undefined;
}
export interface DescribeComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
    AccountId?: string | undefined;
}
export type ResourceType = string;
export type OsType = "WINDOWS" | "LINUX" | (string & {});
export type Monitor = boolean;
export type MetaDataKey = string;
export type MetaDataValue = string;
export type WorkloadMetaData = {
    [key: string]: string | undefined;
};
export type DetectedWorkload = {
    [key in Tier]?: {
        [key: string]: string | undefined;
    } | undefined;
};
export interface ApplicationComponent {
    ComponentName?: string | undefined;
    ComponentRemarks?: string | undefined;
    ResourceType?: string | undefined;
    OsType?: OsType | undefined;
    Tier?: Tier | undefined;
    Monitor?: boolean | undefined;
    DetectedWorkload?: {
        [key: string]: {
            [key: string]: string | undefined;
        } | undefined;
    } | undefined;
}
export interface DescribeComponentResponse {
    ApplicationComponent?: ApplicationComponent | undefined;
    ResourceList?: string[] | undefined;
}
export interface DescribeComponentConfigurationRequest {
    ResourceGroupName: string;
    ComponentName: string;
    AccountId?: string | undefined;
}
export interface DescribeComponentConfigurationResponse {
    Monitor?: boolean | undefined;
    Tier?: Tier | undefined;
    ComponentConfiguration?: string | undefined;
}
export type RecommendationType = "INFRA_ONLY" | "WORKLOAD_ONLY" | "ALL" | (string & {});
export interface DescribeComponentConfigurationRecommendationRequest {
    ResourceGroupName: string;
    ComponentName: string;
    Tier: Tier;
    WorkloadName?: string | undefined;
    RecommendationType?: RecommendationType | undefined;
}
export interface DescribeComponentConfigurationRecommendationResponse {
    ComponentConfiguration?: string | undefined;
}
export interface DescribeLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
    AccountId?: string | undefined;
}
export interface DescribeLogPatternResponse {
    ResourceGroupName?: string | undefined;
    AccountId?: string | undefined;
    LogPattern?: LogPattern | undefined;
}
export type ObservationId = string;
export interface DescribeObservationRequest {
    ObservationId: string;
    AccountId?: string | undefined;
}
export type StartTime = Date;
export type EndTime = Date;
export type SourceType = string;
export type SourceARN = string;
export type LogGroup = string;
export type LineTime = Date;
export type LogText = string;
export type LogFilter = "ERROR" | "WARN" | "INFO" | (string & {});
export type MetricNamespace = string;
export type MetricName = string;
export type Unit = string;
export type Value = number;
export type CloudWatchEventId = string;
export type CloudWatchEventSource = "EC2" | "CODE_DEPLOY" | "HEALTH" | "RDS" | (string & {});
export type CloudWatchEventDetailType = string;
export type HealthEventArn = string;
export type HealthService = string;
export type HealthEventTypeCode = string;
export type HealthEventTypeCategory = string;
export type HealthEventDescription = string;
export type CodeDeployDeploymentId = string;
export type CodeDeployDeploymentGroup = string;
export type CodeDeployState = string;
export type CodeDeployApplication = string;
export type CodeDeployInstanceGroupId = string;
export type Ec2State = string;
export type RdsEventCategories = string;
export type RdsEventMessage = string;
export type S3EventName = string;
export type StatesExecutionArn = string;
export type StatesArn = string;
export type StatesStatus = string;
export type StatesInput = string;
export type EbsEvent = string;
export type EbsResult = string;
export type EbsCause = string;
export type EbsRequestId = string;
export type XRayFaultPercent = number;
export type XRayThrottlePercent = number;
export type XRayErrorPercent = number;
export type XRayRequestCount = number;
export type XRayRequestAverageLatency = number;
export type XRayNodeName = string;
export type XRayNodeType = string;
export interface Observation {
    Id?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    SourceType?: string | undefined;
    SourceARN?: string | undefined;
    LogGroup?: string | undefined;
    LineTime?: Date | undefined;
    LogText?: string | undefined;
    LogFilter?: LogFilter | undefined;
    MetricNamespace?: string | undefined;
    MetricName?: string | undefined;
    Unit?: string | undefined;
    Value?: number | undefined;
    CloudWatchEventId?: string | undefined;
    CloudWatchEventSource?: CloudWatchEventSource | undefined;
    CloudWatchEventDetailType?: string | undefined;
    HealthEventArn?: string | undefined;
    HealthService?: string | undefined;
    HealthEventTypeCode?: string | undefined;
    HealthEventTypeCategory?: string | undefined;
    HealthEventDescription?: string | undefined;
    CodeDeployDeploymentId?: string | undefined;
    CodeDeployDeploymentGroup?: string | undefined;
    CodeDeployState?: string | undefined;
    CodeDeployApplication?: string | undefined;
    CodeDeployInstanceGroupId?: string | undefined;
    Ec2State?: string | undefined;
    RdsEventCategories?: string | undefined;
    RdsEventMessage?: string | undefined;
    S3EventName?: string | undefined;
    StatesExecutionArn?: string | undefined;
    StatesArn?: string | undefined;
    StatesStatus?: string | undefined;
    StatesInput?: string | undefined;
    EbsEvent?: string | undefined;
    EbsResult?: string | undefined;
    EbsCause?: string | undefined;
    EbsRequestId?: string | undefined;
    XRayFaultPercent?: number | undefined;
    XRayThrottlePercent?: number | undefined;
    XRayErrorPercent?: number | undefined;
    XRayRequestCount?: number | undefined;
    XRayRequestAverageLatency?: number | undefined;
    XRayNodeName?: string | undefined;
    XRayNodeType?: string | undefined;
}
export interface DescribeObservationResponse {
    Observation?: Observation | undefined;
}
export type ProblemId = string;
export interface DescribeProblemRequest {
    ProblemId: string;
    AccountId?: string | undefined;
}
export type Title = string;
export type ShortName = string;
export type Insights = string;
export type Status = "IGNORE" | "RESOLVED" | "PENDING" | "RECURRING" | "RECOVERING" | (string & {});
export type AffectedResource = string;
export type SeverityLevel = "Informative" | "Low" | "Medium" | "High" | (string & {});
export type FeedbackKey = "INSIGHTS_FEEDBACK" | (string & {});
export type FeedbackValue = "NOT_SPECIFIED" | "USEFUL" | "NOT_USEFUL" | (string & {});
export type Feedback = {
    [key in FeedbackKey]?: FeedbackValue | undefined;
};
export type RecurringCount = number;
export type LastRecurrenceTime = Date;
export type Visibility = "IGNORED" | "VISIBLE" | (string & {});
export type ResolutionMethod = "MANUAL" | "AUTOMATIC" | "UNRESOLVED" | (string & {});
export interface Problem {
    Id?: string | undefined;
    Title?: string | undefined;
    ShortName?: string | undefined;
    Insights?: string | undefined;
    Status?: Status | undefined;
    AffectedResource?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    SeverityLevel?: SeverityLevel | undefined;
    AccountId?: string | undefined;
    ResourceGroupName?: string | undefined;
    Feedback?: {
        [key: string]: FeedbackValue | undefined;
    } | undefined;
    RecurringCount?: number | undefined;
    LastRecurrenceTime?: Date | undefined;
    Visibility?: Visibility | undefined;
    ResolutionMethod?: ResolutionMethod | undefined;
}
export interface DescribeProblemResponse {
    Problem?: Problem | undefined;
    SNSNotificationArn?: string | undefined;
}
export interface DescribeProblemObservationsRequest {
    ProblemId: string;
    AccountId?: string | undefined;
}
export type ObservationList = Observation[];
export interface RelatedObservations {
    ObservationList?: Observation[] | undefined;
}
export interface DescribeProblemObservationsResponse {
    RelatedObservations?: RelatedObservations | undefined;
}
export interface DescribeWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadId: string;
    AccountId?: string | undefined;
}
export interface DescribeWorkloadResponse {
    WorkloadId?: string | undefined;
    WorkloadRemarks?: string | undefined;
    WorkloadConfiguration?: WorkloadConfiguration | undefined;
}
export type MaxEntities = number;
export type PaginationToken = string;
export interface ListApplicationsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type ApplicationInfoList = ApplicationInfo[];
export interface ListApplicationsResponse {
    ApplicationInfoList?: ApplicationInfo[] | undefined;
    NextToken?: string | undefined;
}
export interface ListComponentsRequest {
    ResourceGroupName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type ApplicationComponentList = ApplicationComponent[];
export interface ListComponentsResponse {
    ApplicationComponentList?: ApplicationComponent[] | undefined;
    NextToken?: string | undefined;
}
export type ConfigurationEventStatus = "INFO" | "WARN" | "ERROR" | (string & {});
export interface ListConfigurationHistoryRequest {
    ResourceGroupName?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    EventStatus?: ConfigurationEventStatus | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type ConfigurationEventMonitoredResourceARN = string;
export type ConfigurationEventResourceType = "CLOUDWATCH_ALARM" | "CLOUDWATCH_LOG" | "CLOUDFORMATION" | "SSM_ASSOCIATION" | (string & {});
export type ConfigurationEventTime = Date;
export type ConfigurationEventDetail = string;
export type ConfigurationEventResourceName = string;
export interface ConfigurationEvent {
    ResourceGroupName?: string | undefined;
    AccountId?: string | undefined;
    MonitoredResourceARN?: string | undefined;
    EventStatus?: ConfigurationEventStatus | undefined;
    EventResourceType?: ConfigurationEventResourceType | undefined;
    EventTime?: Date | undefined;
    EventDetail?: string | undefined;
    EventResourceName?: string | undefined;
}
export type ConfigurationEventList = ConfigurationEvent[];
export interface ListConfigurationHistoryResponse {
    EventList?: ConfigurationEvent[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLogPatternsRequest {
    ResourceGroupName: string;
    PatternSetName?: string | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type LogPatternList = LogPattern[];
export interface ListLogPatternsResponse {
    ResourceGroupName?: string | undefined;
    AccountId?: string | undefined;
    LogPatterns?: LogPattern[] | undefined;
    NextToken?: string | undefined;
}
export interface ListLogPatternSetsRequest {
    ResourceGroupName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type LogPatternSetList = string[];
export interface ListLogPatternSetsResponse {
    ResourceGroupName?: string | undefined;
    AccountId?: string | undefined;
    LogPatternSets?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListProblemsRequest {
    AccountId?: string | undefined;
    ResourceGroupName?: string | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    ComponentName?: string | undefined;
    Visibility?: Visibility | undefined;
}
export type ProblemList = Problem[];
export interface ListProblemsResponse {
    ProblemList?: Problem[] | undefined;
    NextToken?: string | undefined;
    ResourceGroupName?: string | undefined;
    AccountId?: string | undefined;
}
export type AmazonResourceName = string;
export interface ListTagsForResourceRequest {
    ResourceARN: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export interface ListWorkloadsRequest {
    ResourceGroupName: string;
    ComponentName: string;
    MaxResults?: number | undefined;
    NextToken?: string | undefined;
    AccountId?: string | undefined;
}
export type MissingWorkloadConfig = boolean;
export interface Workload {
    WorkloadId?: string | undefined;
    ComponentName?: string | undefined;
    WorkloadName?: string | undefined;
    Tier?: Tier | undefined;
    WorkloadRemarks?: string | undefined;
    MissingWorkloadConfig?: boolean | undefined;
}
export type WorkloadList = Workload[];
export interface ListWorkloadsResponse {
    WorkloadList?: Workload[] | undefined;
    NextToken?: string | undefined;
}
export interface RemoveWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadId: string;
}
export interface RemoveWorkloadResponse {
}
export interface TagResourceRequest {
    ResourceARN: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    ResourceARN: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type RemoveSNSTopic = boolean;
export interface UpdateApplicationRequest {
    ResourceGroupName: string;
    OpsCenterEnabled?: boolean | undefined;
    CWEMonitorEnabled?: boolean | undefined;
    OpsItemSNSTopicArn?: string | undefined;
    SNSNotificationArn?: string | undefined;
    RemoveSNSTopic?: boolean | undefined;
    AutoConfigEnabled?: boolean | undefined;
    AttachMissingPermission?: boolean | undefined;
}
export interface UpdateApplicationResponse {
    ApplicationInfo?: ApplicationInfo | undefined;
}
export interface UpdateComponentRequest {
    ResourceGroupName: string;
    ComponentName: string;
    NewComponentName?: string | undefined;
    ResourceList?: string[] | undefined;
}
export interface UpdateComponentResponse {
}
export interface UpdateComponentConfigurationRequest {
    ResourceGroupName: string;
    ComponentName: string;
    Monitor?: boolean | undefined;
    Tier?: Tier | undefined;
    ComponentConfiguration?: string | undefined;
    AutoConfigEnabled?: boolean | undefined;
}
export interface UpdateComponentConfigurationResponse {
}
export interface UpdateLogPatternRequest {
    ResourceGroupName: string;
    PatternSetName: string;
    PatternName: string;
    Pattern?: string | undefined;
    Rank?: number | undefined;
}
export interface UpdateLogPatternResponse {
    ResourceGroupName?: string | undefined;
    LogPattern?: LogPattern | undefined;
}
export type UpdateStatus = "RESOLVED" | (string & {});
export interface UpdateProblemRequest {
    ProblemId: string;
    UpdateStatus?: UpdateStatus | undefined;
    Visibility?: Visibility | undefined;
}
export interface UpdateProblemResponse {
}
export interface UpdateWorkloadRequest {
    ResourceGroupName: string;
    ComponentName: string;
    WorkloadId?: string | undefined;
    WorkloadConfiguration: WorkloadConfiguration;
}
export interface UpdateWorkloadResponse {
    WorkloadId?: string | undefined;
    WorkloadConfiguration?: WorkloadConfiguration | undefined;
}
export type ErrorMsg = string;
export type ExceptionMessage = string;
export type AddWorkloadError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a workload to a component. Each component can have at most five workloads.
 */
export declare const addWorkload: API.OperationMethod<AddWorkloadRequest & RegionInput, AddWorkloadResponse, AddWorkloadError, Credentials | HttpClient.HttpClient>;
export type CreateApplicationError = AccessDeniedException | InternalServerException | ResourceInUseException | ResourceNotFoundException | TagsAlreadyExistException | ValidationException | CommonErrors;
/**
 * Adds an application that is created from a resource group.
 */
export declare const createApplication: API.OperationMethod<CreateApplicationRequest & RegionInput, CreateApplicationResponse, CreateApplicationError, Credentials | HttpClient.HttpClient>;
export type CreateComponentError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Creates a custom component by grouping similar standalone instances to monitor.
 */
export declare const createComponent: API.OperationMethod<CreateComponentRequest & RegionInput, CreateComponentResponse, CreateComponentError, Credentials | HttpClient.HttpClient>;
export type CreateLogPatternError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds an log pattern to a `LogPatternSet`.
 */
export declare const createLogPattern: API.OperationMethod<CreateLogPatternRequest & RegionInput, CreateLogPatternResponse, CreateLogPatternError, Credentials | HttpClient.HttpClient>;
export type DeleteApplicationError = BadRequestException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified application from monitoring. Does not delete the
 * application.
 */
export declare const deleteApplication: API.OperationMethod<DeleteApplicationRequest & RegionInput, DeleteApplicationResponse, DeleteApplicationError, Credentials | HttpClient.HttpClient>;
export type DeleteComponentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Ungroups a custom component. When you ungroup custom components, all applicable monitors
 * that are set up for the component are removed and the instances revert to their standalone
 * status.
 */
export declare const deleteComponent: API.OperationMethod<DeleteComponentRequest & RegionInput, DeleteComponentResponse, DeleteComponentError, Credentials | HttpClient.HttpClient>;
export type DeleteLogPatternError = BadRequestException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified log pattern from a `LogPatternSet`.
 */
export declare const deleteLogPattern: API.OperationMethod<DeleteLogPatternRequest & RegionInput, DeleteLogPatternResponse, DeleteLogPatternError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the application.
 */
export declare const describeApplication: API.OperationMethod<DescribeApplicationRequest & RegionInput, DescribeApplicationResponse, DescribeApplicationError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes a component and lists the resources that are grouped together in a
 * component.
 */
export declare const describeComponent: API.OperationMethod<DescribeComponentRequest & RegionInput, DescribeComponentResponse, DescribeComponentError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentConfigurationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the monitoring configuration of the component.
 */
export declare const describeComponentConfiguration: API.OperationMethod<DescribeComponentConfigurationRequest & RegionInput, DescribeComponentConfigurationResponse, DescribeComponentConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeComponentConfigurationRecommendationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the recommended monitoring configuration of the component.
 */
export declare const describeComponentConfigurationRecommendation: API.OperationMethod<DescribeComponentConfigurationRecommendationRequest & RegionInput, DescribeComponentConfigurationRecommendationResponse, DescribeComponentConfigurationRecommendationError, Credentials | HttpClient.HttpClient>;
export type DescribeLogPatternError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describe a specific log pattern from a `LogPatternSet`.
 */
export declare const describeLogPattern: API.OperationMethod<DescribeLogPatternRequest & RegionInput, DescribeLogPatternResponse, DescribeLogPatternError, Credentials | HttpClient.HttpClient>;
export type DescribeObservationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes an anomaly or error with the application.
 */
export declare const describeObservation: API.OperationMethod<DescribeObservationRequest & RegionInput, DescribeObservationResponse, DescribeObservationError, Credentials | HttpClient.HttpClient>;
export type DescribeProblemError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes an application problem.
 */
export declare const describeProblem: API.OperationMethod<DescribeProblemRequest & RegionInput, DescribeProblemResponse, DescribeProblemError, Credentials | HttpClient.HttpClient>;
export type DescribeProblemObservationsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the anomalies or errors associated with the problem.
 */
export declare const describeProblemObservations: API.OperationMethod<DescribeProblemObservationsRequest & RegionInput, DescribeProblemObservationsResponse, DescribeProblemObservationsError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes a workload and its configuration.
 */
export declare const describeWorkload: API.OperationMethod<DescribeWorkloadRequest & RegionInput, DescribeWorkloadResponse, DescribeWorkloadError, Credentials | HttpClient.HttpClient>;
export type ListApplicationsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Lists the IDs of the applications that you are monitoring.
 */
export declare const listApplications: API.PaginatedOperationMethod<ListApplicationsRequest & RegionInput, ListApplicationsResponse, ListApplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListComponentsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the auto-grouped, standalone, and custom components of the application.
 */
export declare const listComponents: API.PaginatedOperationMethod<ListComponentsRequest & RegionInput, ListComponentsResponse, ListComponentsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListConfigurationHistoryError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the INFO, WARN, and ERROR events for periodic configuration updates performed by
 * Application Insights. Examples of events represented are:
 *
 * - INFO: creating a new alarm or updating an alarm threshold.
 *
 * - WARN: alarm not created due to insufficient data points used to predict
 * thresholds.
 *
 * - ERROR: alarm not created due to permission errors or exceeding quotas.
 */
export declare const listConfigurationHistory: API.PaginatedOperationMethod<ListConfigurationHistoryRequest & RegionInput, ListConfigurationHistoryResponse, ListConfigurationHistoryError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLogPatternsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the log patterns in the specific log `LogPatternSet`.
 */
export declare const listLogPatterns: API.PaginatedOperationMethod<ListLogPatternsRequest & RegionInput, ListLogPatternsResponse, ListLogPatternsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListLogPatternSetsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the log pattern sets in the specific application.
 */
export declare const listLogPatternSets: API.PaginatedOperationMethod<ListLogPatternSetsRequest & RegionInput, ListLogPatternSetsResponse, ListLogPatternSetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListProblemsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the problems with your application.
 */
export declare const listProblems: API.PaginatedOperationMethod<ListProblemsRequest & RegionInput, ListProblemsResponse, ListProblemsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieve a list of the tags (keys and values) that are associated with a specified
 * application. A *tag* is a label that you optionally define and associate
 * with an application. Each tag consists of a required *tag key* and an
 * optional associated *tag value*. A tag key is a general label that acts
 * as a category for more specific tag values. A tag value acts as a descriptor within a tag
 * key.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkloadsError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the workloads that are configured on a given component.
 */
export declare const listWorkloads: API.PaginatedOperationMethod<ListWorkloadsRequest & RegionInput, ListWorkloadsResponse, ListWorkloadsError, Credentials | HttpClient.HttpClient, unknown>;
export type RemoveWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove workload from a component.
 */
export declare const removeWorkload: API.OperationMethod<RemoveWorkloadRequest & RegionInput, RemoveWorkloadResponse, RemoveWorkloadError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | TooManyTagsException | ValidationException | CommonErrors;
/**
 * Add one or more tags (keys and values) to a specified application. A
 * *tag* is a label that you optionally define and associate with an
 * application. Tags can help you categorize and manage application in different ways, such as
 * by purpose, owner, environment, or other criteria.
 *
 * Each tag consists of a required *tag key* and an associated
 * *tag value*, both of which you define. A tag key is a general label
 * that acts as a category for more specific tag values. A tag value acts as a descriptor
 * within a tag key.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Remove one or more tags (keys and values) from a specified application.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApplicationError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the application.
 */
export declare const updateApplication: API.OperationMethod<UpdateApplicationRequest & RegionInput, UpdateApplicationResponse, UpdateApplicationError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the custom component name and/or the list of resources that make up the
 * component.
 */
export declare const updateComponent: API.OperationMethod<UpdateComponentRequest & RegionInput, UpdateComponentResponse, UpdateComponentError, Credentials | HttpClient.HttpClient>;
export type UpdateComponentConfigurationError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the monitoring configurations for the component. The configuration input
 * parameter is an escaped JSON of the configuration and should match the schema of what is
 * returned by `DescribeComponentConfigurationRecommendation`.
 */
export declare const updateComponentConfiguration: API.OperationMethod<UpdateComponentConfigurationRequest & RegionInput, UpdateComponentConfigurationResponse, UpdateComponentConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateLogPatternError = InternalServerException | ResourceInUseException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a log pattern to a `LogPatternSet`.
 */
export declare const updateLogPattern: API.OperationMethod<UpdateLogPatternRequest & RegionInput, UpdateLogPatternResponse, UpdateLogPatternError, Credentials | HttpClient.HttpClient>;
export type UpdateProblemError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the visibility of the problem or specifies the problem as
 * `RESOLVED`.
 */
export declare const updateProblem: API.OperationMethod<UpdateProblemRequest & RegionInput, UpdateProblemResponse, UpdateProblemError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkloadError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Adds a workload to a component. Each component can have at most five workloads.
 */
export declare const updateWorkload: API.OperationMethod<UpdateWorkloadRequest & RegionInput, UpdateWorkloadResponse, UpdateWorkloadError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=application-insights.d.ts.map