import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EnvironmentName = string | redacted.Redacted<string>;
export type Arn = string;
export type DesktopEndpoint = string | redacted.Redacted<string>;
export type SoftwareSetUpdateSchedule = "USE_MAINTENANCE_WINDOW" | "APPLY_IMMEDIATELY" | (string & {});
export type MaintenanceWindowType = "SYSTEM" | "CUSTOM" | (string & {});
export type Hour = number;
export type Minute = number;
export type DayOfWeek = "MONDAY" | "TUESDAY" | "WEDNESDAY" | "THURSDAY" | "FRIDAY" | "SATURDAY" | "SUNDAY" | (string & {});
export type DayOfWeekList = DayOfWeek[];
export type ApplyTimeOf = "UTC" | "DEVICE" | (string & {});
export interface MaintenanceWindow {
    type: MaintenanceWindowType;
    startTimeHour?: number | undefined;
    startTimeMinute?: number | undefined;
    endTimeHour?: number | undefined;
    endTimeMinute?: number | undefined;
    daysOfTheWeek?: DayOfWeek[] | undefined;
    applyTimeOf?: ApplyTimeOf | undefined;
}
export type SoftwareSetUpdateMode = "USE_LATEST" | "USE_DESIRED" | (string & {});
export type SoftwareSetId = string;
export type KmsKeyArn = string;
export type ClientToken = string;
export type TagsMap = {
    [key: string]: string | undefined;
};
export type DeviceCreationTagKey = string;
export type DeviceCreationTagValue = string;
export type DeviceCreationTagsMap = {
    [key: string]: string | undefined;
};
export interface CreateEnvironmentRequest {
    name?: string | redacted.Redacted<string> | undefined;
    desktopArn: string;
    desktopEndpoint?: string | redacted.Redacted<string> | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    softwareSetUpdateMode?: SoftwareSetUpdateMode | undefined;
    desiredSoftwareSetId?: string | undefined;
    kmsKeyArn?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    deviceCreationTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EnvironmentId = string;
export type DesktopType = "workspaces" | "appstream" | "workspaces-web" | (string & {});
export type ActivationCode = string | redacted.Redacted<string>;
export interface EnvironmentSummary {
    id?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    desktopArn?: string | undefined;
    desktopEndpoint?: string | redacted.Redacted<string> | undefined;
    desktopType?: DesktopType | undefined;
    activationCode?: string | redacted.Redacted<string> | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    softwareSetUpdateMode?: SoftwareSetUpdateMode | undefined;
    desiredSoftwareSetId?: string | undefined;
    pendingSoftwareSetId?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    arn?: string | undefined;
}
export interface CreateEnvironmentResponse {
    environment?: EnvironmentSummary | undefined;
}
export type DeviceId = string;
export interface DeleteDeviceRequest {
    id: string;
    clientToken?: string | undefined;
}
export interface DeleteDeviceResponse {
}
export interface DeleteEnvironmentRequest {
    id: string;
    clientToken?: string | undefined;
}
export interface DeleteEnvironmentResponse {
}
export type TargetDeviceStatus = "DEREGISTERED" | "ARCHIVED" | (string & {});
export interface DeregisterDeviceRequest {
    id: string;
    targetDeviceStatus?: TargetDeviceStatus | undefined;
    clientToken?: string | undefined;
}
export interface DeregisterDeviceResponse {
}
export interface GetDeviceRequest {
    id: string;
}
export type DeviceName = string | redacted.Redacted<string>;
export type DeviceStatus = "REGISTERED" | "DEREGISTERING" | "DEREGISTERED" | "ARCHIVED" | (string & {});
export type DeviceSoftwareSetComplianceStatus = "NONE" | "COMPLIANT" | "NOT_COMPLIANT" | (string & {});
export type SoftwareSetUpdateStatus = "AVAILABLE" | "IN_PROGRESS" | "UP_TO_DATE" | (string & {});
export type UserId = string | redacted.Redacted<string>;
export interface Device {
    id?: string | undefined;
    serialNumber?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    model?: string | undefined;
    environmentId?: string | undefined;
    status?: DeviceStatus | undefined;
    currentSoftwareSetId?: string | undefined;
    currentSoftwareSetVersion?: string | undefined;
    desiredSoftwareSetId?: string | undefined;
    pendingSoftwareSetId?: string | undefined;
    pendingSoftwareSetVersion?: string | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
    softwareSetComplianceStatus?: DeviceSoftwareSetComplianceStatus | undefined;
    softwareSetUpdateStatus?: SoftwareSetUpdateStatus | undefined;
    lastConnectedAt?: Date | undefined;
    lastPostureAt?: Date | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    arn?: string | undefined;
    kmsKeyArn?: string | undefined;
    lastUserId?: string | redacted.Redacted<string> | undefined;
}
export interface GetDeviceResponse {
    device?: Device | undefined;
}
export interface GetEnvironmentRequest {
    id: string;
}
export type EnvironmentSoftwareSetComplianceStatus = "NO_REGISTERED_DEVICES" | "COMPLIANT" | "NOT_COMPLIANT" | (string & {});
export interface Environment {
    id?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    desktopArn?: string | undefined;
    desktopEndpoint?: string | redacted.Redacted<string> | undefined;
    desktopType?: DesktopType | undefined;
    activationCode?: string | redacted.Redacted<string> | undefined;
    registeredDevicesCount?: number | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    softwareSetUpdateMode?: SoftwareSetUpdateMode | undefined;
    desiredSoftwareSetId?: string | undefined;
    pendingSoftwareSetId?: string | undefined;
    pendingSoftwareSetVersion?: string | undefined;
    softwareSetComplianceStatus?: EnvironmentSoftwareSetComplianceStatus | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    arn?: string | undefined;
    kmsKeyArn?: string | undefined;
    deviceCreationTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetEnvironmentResponse {
    environment?: Environment | undefined;
}
export interface GetSoftwareSetRequest {
    id: string;
}
export type SoftwareSetValidationStatus = "VALIDATED" | "NOT_VALIDATED" | (string & {});
export interface Software {
    name?: string | undefined;
    version?: string | undefined;
}
export type SoftwareList = Software[];
export interface SoftwareSet {
    id?: string | undefined;
    version?: string | undefined;
    releasedAt?: Date | undefined;
    supportedUntil?: Date | undefined;
    validationStatus?: SoftwareSetValidationStatus | undefined;
    software?: Software[] | undefined;
    arn?: string | undefined;
}
export interface GetSoftwareSetResponse {
    softwareSet?: SoftwareSet | undefined;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface ListDevicesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DeviceSummary {
    id?: string | undefined;
    serialNumber?: string | undefined;
    name?: string | redacted.Redacted<string> | undefined;
    model?: string | undefined;
    environmentId?: string | undefined;
    status?: DeviceStatus | undefined;
    currentSoftwareSetId?: string | undefined;
    desiredSoftwareSetId?: string | undefined;
    pendingSoftwareSetId?: string | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
    lastConnectedAt?: Date | undefined;
    lastPostureAt?: Date | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    arn?: string | undefined;
    lastUserId?: string | redacted.Redacted<string> | undefined;
}
export type DeviceList = DeviceSummary[];
export interface ListDevicesResponse {
    devices?: DeviceSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListEnvironmentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type EnvironmentList = EnvironmentSummary[];
export interface ListEnvironmentsResponse {
    environments?: EnvironmentSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSoftwareSetsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SoftwareSetSummary {
    id?: string | undefined;
    version?: string | undefined;
    releasedAt?: Date | undefined;
    supportedUntil?: Date | undefined;
    validationStatus?: SoftwareSetValidationStatus | undefined;
    arn?: string | undefined;
}
export type SoftwareSetList = SoftwareSetSummary[];
export interface ListSoftwareSetsResponse {
    softwareSets?: SoftwareSetSummary[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDeviceRequest {
    id: string;
    name?: string | redacted.Redacted<string> | undefined;
    desiredSoftwareSetId?: string | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
}
export interface UpdateDeviceResponse {
    device?: DeviceSummary | undefined;
}
export type SoftwareSetIdOrEmptyString = string;
export interface UpdateEnvironmentRequest {
    id: string;
    name?: string | redacted.Redacted<string> | undefined;
    desktopArn?: string | undefined;
    desktopEndpoint?: string | redacted.Redacted<string> | undefined;
    softwareSetUpdateSchedule?: SoftwareSetUpdateSchedule | undefined;
    maintenanceWindow?: MaintenanceWindow | undefined;
    softwareSetUpdateMode?: SoftwareSetUpdateMode | undefined;
    desiredSoftwareSetId?: string | undefined;
    deviceCreationTags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateEnvironmentResponse {
    environment?: EnvironmentSummary | undefined;
}
export interface UpdateSoftwareSetRequest {
    id: string;
    validationStatus: SoftwareSetValidationStatus;
}
export interface UpdateSoftwareSetResponse {
}
export type ExceptionMessage = string;
export type ResourceId = string;
export type ResourceType = string;
export type RetryAfterSeconds = number;
export type ServiceCode = string;
export type QuotaCode = string;
export type ValidationExceptionReason = "unknownOperation" | "cannotParse" | "fieldValidationFailed" | "other" | (string & {});
export type FieldName = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an environment for your thin client devices.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest & RegionInput, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a thin client device.
 */
export declare const deleteDevice: API.OperationMethod<DeleteDeviceRequest & RegionInput, DeleteDeviceResponse, DeleteDeviceError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest & RegionInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeregisterDeviceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deregisters a thin client device.
 */
export declare const deregisterDevice: API.OperationMethod<DeregisterDeviceRequest & RegionInput, DeregisterDeviceResponse, DeregisterDeviceError, Credentials | HttpClient.HttpClient>;
export type GetDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information for a thin client device.
 */
export declare const getDevice: API.OperationMethod<GetDeviceRequest & RegionInput, GetDeviceResponse, GetDeviceError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information for an environment.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest & RegionInput, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetSoftwareSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information for a software set.
 */
export declare const getSoftwareSet: API.OperationMethod<GetSoftwareSetRequest & RegionInput, GetSoftwareSetResponse, GetSoftwareSetError, Credentials | HttpClient.HttpClient>;
export type ListDevicesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of thin client devices.
 */
export declare const listDevices: API.PaginatedOperationMethod<ListDevicesRequest & RegionInput, ListDevicesResponse, ListDevicesError, Credentials | HttpClient.HttpClient, DeviceSummary>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of environments.
 */
export declare const listEnvironments: API.PaginatedOperationMethod<ListEnvironmentsRequest & RegionInput, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient, EnvironmentSummary>;
export type ListSoftwareSetsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of software sets.
 */
export declare const listSoftwareSets: API.PaginatedOperationMethod<ListSoftwareSetsRequest & RegionInput, ListSoftwareSetsResponse, ListSoftwareSetsError, Credentials | HttpClient.HttpClient, SoftwareSetSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes a tag or tags from a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDeviceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a thin client device.
 */
export declare const updateDevice: API.OperationMethod<UpdateDeviceRequest & RegionInput, UpdateDeviceResponse, UpdateDeviceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest & RegionInput, UpdateEnvironmentResponse, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateSoftwareSetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a software set.
 */
export declare const updateSoftwareSet: API.OperationMethod<UpdateSoftwareSetRequest & RegionInput, UpdateSoftwareSetResponse, UpdateSoftwareSetError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workspaces-thin-client.d.ts.map