import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const ResourceAlreadyExistsException_base: S.TaggedErrorClass<"ResourceAlreadyExistsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsException extends /*@__PURE__*/ ResourceAlreadyExistsException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type EnvironmentName = string;
export type Description = string;
export type KmsKeyId = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type FederationMode = "FEDERATED" | "LOCAL" | (string & {});
export type SamlMetadataDocument = string;
export type Url = string;
export type Urn = string;
export type FederationProviderName = string;
export type FederationAttributeKey = string;
export type FederationAttributeValue = string;
export type AttributeMap = {
    [key: string]: string | undefined;
};
export interface FederationParameters {
    samlMetadataDocument?: string | undefined;
    samlMetadataURL?: string | undefined;
    applicationCallBackURL?: string | undefined;
    federationURN?: string | undefined;
    federationProviderName?: string | undefined;
    attributeMap?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type EmailId = string | redacted.Redacted<string>;
export type NameString = string;
export interface SuperuserParameters {
    emailAddress: string | redacted.Redacted<string>;
    firstName: string;
    lastName: string;
}
export type DataBundleArn = string;
export type DataBundleArns = string[];
export interface CreateEnvironmentRequest {
    name: string;
    description?: string | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    federationMode?: FederationMode | undefined;
    federationParameters?: FederationParameters | undefined;
    superuserParameters?: SuperuserParameters | undefined;
    dataBundles?: string[] | undefined;
}
export type IdType = string;
export type EnvironmentArn = string;
export interface CreateEnvironmentResponse {
    environmentId?: string | undefined;
    environmentArn?: string | undefined;
    environmentUrl?: string | undefined;
}
export type EnvironmentId = string;
export type DatabaseName = string;
export type ChangeType = "PUT" | "DELETE" | (string & {});
export type S3Path = string;
export type DbPath = string;
export interface ChangeRequest {
    changeType: ChangeType;
    s3Path?: string | undefined;
    dbPath: string;
}
export type ChangeRequests = ChangeRequest[];
export type ClientTokenString = string;
export interface CreateKxChangesetRequest {
    environmentId: string;
    databaseName: string;
    changeRequests: ChangeRequest[];
    clientToken: string;
}
export type ChangesetId = string;
export type ChangesetStatus = "PENDING" | "PROCESSING" | "FAILED" | "COMPLETED" | (string & {});
export type ErrorMessage = string;
export type ErrorDetails = "The inputs to this request are invalid." | "Service limits have been exceeded." | "Missing required permission to perform this request." | "One or more inputs to this request were not found." | "The system temporarily lacks sufficient resources to process the request." | "An internal error has occurred." | "Cancelled" | "A user recoverable error has occurred" | (string & {});
export interface ErrorInfo {
    errorMessage?: string | undefined;
    errorType?: ErrorDetails | undefined;
}
export interface CreateKxChangesetResponse {
    changesetId?: string | undefined;
    databaseName?: string | undefined;
    environmentId?: string | undefined;
    changeRequests?: ChangeRequest[] | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    status?: ChangesetStatus | undefined;
    errorInfo?: ErrorInfo | undefined;
}
export type ClientToken = string;
export type KxEnvironmentId = string;
export type KxClusterName = string;
export type KxClusterType = "HDB" | "RDB" | "GATEWAY" | "GP" | "TICKERPLANT" | (string & {});
export type VolumeName = string;
export type TickerplantLogVolumes = string[];
export interface TickerplantLogConfiguration {
    tickerplantLogVolumes?: string[] | undefined;
}
export type KxCacheStorageType = string;
export type DbPaths = string[];
export type KxDataviewName = string;
export interface KxDatabaseCacheConfiguration {
    cacheType: string;
    dbPaths: string[];
    dataviewName?: string | undefined;
}
export type KxDatabaseCacheConfigurations = KxDatabaseCacheConfiguration[];
export type VersionId = string;
export type SegmentConfigurationDbPathList = string[];
export type KxVolumeName = string;
export interface KxDataviewSegmentConfiguration {
    dbPaths: string[];
    volumeName: string;
    onDemand?: boolean | undefined;
}
export type KxDataviewSegmentConfigurationList = KxDataviewSegmentConfiguration[];
export interface KxDataviewConfiguration {
    dataviewName?: string | undefined;
    dataviewVersionId?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
}
export interface KxDatabaseConfiguration {
    databaseName: string;
    cacheConfigurations?: KxDatabaseCacheConfiguration[] | undefined;
    changesetId?: string | undefined;
    dataviewName?: string | undefined;
    dataviewConfiguration?: KxDataviewConfiguration | undefined;
}
export type KxDatabaseConfigurations = KxDatabaseConfiguration[];
export type KxCacheStorageSize = number;
export interface KxCacheStorageConfiguration {
    type: string;
    size: number;
}
export type KxCacheStorageConfigurations = KxCacheStorageConfiguration[];
export type NodeCount = number;
export type AutoScalingMetric = "CPU_UTILIZATION_PERCENTAGE" | (string & {});
export type AutoScalingMetricTarget = number;
export type CooldownTime = number;
export interface AutoScalingConfiguration {
    minNodeCount?: number | undefined;
    maxNodeCount?: number | undefined;
    autoScalingMetric?: AutoScalingMetric | undefined;
    metricTarget?: number | undefined;
    scaleInCooldownSeconds?: number | undefined;
    scaleOutCooldownSeconds?: number | undefined;
}
export type KxClusterDescription = string;
export type NodeType = string;
export interface CapacityConfiguration {
    nodeType?: string | undefined;
    nodeCount?: number | undefined;
}
export type ReleaseLabel = string;
export type VpcIdString = string;
export type SecurityGroupIdString = string;
export type SecurityGroupIdList = string[];
export type SubnetIdString = string;
export type SubnetIdList = string[];
export type IPAddressType = "IP_V4" | (string & {});
export interface VpcConfiguration {
    vpcId?: string | undefined;
    securityGroupIds?: string[] | undefined;
    subnetIds?: string[] | undefined;
    ipAddressType?: IPAddressType | undefined;
}
export type InitializationScriptFilePath = string;
export type KxCommandLineArgumentKey = string;
export type KxCommandLineArgumentValue = string;
export interface KxCommandLineArgument {
    key?: string | undefined;
    value?: string | undefined;
}
export type KxCommandLineArguments = KxCommandLineArgument[];
export type S3Bucket = string;
export type S3Key = string;
export type S3ObjectVersion = string;
export interface CodeConfiguration {
    s3Bucket?: string | undefined;
    s3Key?: string | undefined;
    s3ObjectVersion?: string | undefined;
}
export type ExecutionRoleArn = string;
export type KxSavedownStorageType = "SDS01" | (string & {});
export type KxSavedownStorageSize = number;
export interface KxSavedownStorageConfiguration {
    type?: KxSavedownStorageType | undefined;
    size?: number | undefined;
    volumeName?: string | undefined;
}
export type KxAzMode = "SINGLE" | "MULTI" | (string & {});
export type AvailabilityZoneId = string;
export type KxScalingGroupName = string;
export type MemoryMib = number;
export type ClusterNodeCount = number;
export type CpuCount = number;
export interface KxScalingGroupConfiguration {
    scalingGroupName: string;
    memoryLimit?: number | undefined;
    memoryReservation: number;
    nodeCount: number;
    cpu?: number | undefined;
}
export interface CreateKxClusterRequest {
    clientToken?: string | undefined;
    environmentId: string;
    clusterName: string;
    clusterType: KxClusterType;
    tickerplantLogConfiguration?: TickerplantLogConfiguration | undefined;
    databases?: KxDatabaseConfiguration[] | undefined;
    cacheStorageConfigurations?: KxCacheStorageConfiguration[] | undefined;
    autoScalingConfiguration?: AutoScalingConfiguration | undefined;
    clusterDescription?: string | undefined;
    capacityConfiguration?: CapacityConfiguration | undefined;
    releaseLabel: string;
    vpcConfiguration: VpcConfiguration;
    initializationScript?: string | undefined;
    commandLineArguments?: KxCommandLineArgument[] | undefined;
    code?: CodeConfiguration | undefined;
    executionRole?: string | undefined;
    savedownStorageConfiguration?: KxSavedownStorageConfiguration | undefined;
    azMode: KxAzMode;
    availabilityZoneId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    scalingGroupConfiguration?: KxScalingGroupConfiguration | undefined;
}
export type KxClusterStatus = "PENDING" | "CREATING" | "CREATE_FAILED" | "RUNNING" | "UPDATING" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export type KxClusterStatusReason = string;
export type VolumeType = "NAS_1" | (string & {});
export interface Volume {
    volumeName?: string | undefined;
    volumeType?: VolumeType | undefined;
}
export type Volumes = Volume[];
export interface CreateKxClusterResponse {
    environmentId?: string | undefined;
    status?: KxClusterStatus | undefined;
    statusReason?: string | undefined;
    clusterName?: string | undefined;
    clusterType?: KxClusterType | undefined;
    tickerplantLogConfiguration?: TickerplantLogConfiguration | undefined;
    volumes?: Volume[] | undefined;
    databases?: KxDatabaseConfiguration[] | undefined;
    cacheStorageConfigurations?: KxCacheStorageConfiguration[] | undefined;
    autoScalingConfiguration?: AutoScalingConfiguration | undefined;
    clusterDescription?: string | undefined;
    capacityConfiguration?: CapacityConfiguration | undefined;
    releaseLabel?: string | undefined;
    vpcConfiguration?: VpcConfiguration | undefined;
    initializationScript?: string | undefined;
    commandLineArguments?: KxCommandLineArgument[] | undefined;
    code?: CodeConfiguration | undefined;
    executionRole?: string | undefined;
    lastModifiedTimestamp?: Date | undefined;
    savedownStorageConfiguration?: KxSavedownStorageConfiguration | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    createdTimestamp?: Date | undefined;
    scalingGroupConfiguration?: KxScalingGroupConfiguration | undefined;
}
export interface CreateKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
}
export type DatabaseArn = string;
export interface CreateKxDatabaseResponse {
    databaseName?: string | undefined;
    databaseArn?: string | undefined;
    environmentId?: string | undefined;
    description?: string | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
}
export interface CreateKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
    azMode: KxAzMode;
    availabilityZoneId?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    autoUpdate?: boolean | undefined;
    readWrite?: boolean | undefined;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken: string;
}
export type KxDataviewStatus = "CREATING" | "ACTIVE" | "UPDATING" | "FAILED" | "DELETING" | (string & {});
export interface CreateKxDataviewResponse {
    dataviewName?: string | undefined;
    databaseName?: string | undefined;
    environmentId?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    description?: string | undefined;
    autoUpdate?: boolean | undefined;
    readWrite?: boolean | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    status?: KxDataviewStatus | undefined;
}
export type KxEnvironmentName = string;
export type KmsKeyARN = string;
export interface CreateKxEnvironmentRequest {
    name: string;
    description?: string | undefined;
    kmsKeyId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type EnvironmentStatus = "CREATE_REQUESTED" | "CREATING" | "CREATED" | "DELETE_REQUESTED" | "DELETING" | "DELETED" | "FAILED_CREATION" | "RETRY_DELETION" | "FAILED_DELETION" | "UPDATE_NETWORK_REQUESTED" | "UPDATING_NETWORK" | "FAILED_UPDATING_NETWORK" | "SUSPENDED" | (string & {});
export interface CreateKxEnvironmentResponse {
    name?: string | undefined;
    status?: EnvironmentStatus | undefined;
    environmentId?: string | undefined;
    description?: string | undefined;
    environmentArn?: string | undefined;
    kmsKeyId?: string | undefined;
    creationTimestamp?: Date | undefined;
}
export type KxHostType = string;
export interface CreateKxScalingGroupRequest {
    clientToken: string;
    environmentId: string;
    scalingGroupName: string;
    hostType: string;
    availabilityZoneId: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type KxScalingGroupStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export interface CreateKxScalingGroupResponse {
    environmentId?: string | undefined;
    scalingGroupName?: string | undefined;
    hostType?: string | undefined;
    availabilityZoneId?: string | undefined;
    status?: KxScalingGroupStatus | undefined;
    lastModifiedTimestamp?: Date | undefined;
    createdTimestamp?: Date | undefined;
}
export type KxUserNameString = string;
export type RoleArn = string;
export interface CreateKxUserRequest {
    environmentId: string;
    userName: string;
    iamRole: string;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export type KxUserArn = string;
export interface CreateKxUserResponse {
    userName?: string | undefined;
    userArn?: string | undefined;
    environmentId?: string | undefined;
    iamRole?: string | undefined;
}
export type KxVolumeType = "NAS_1" | (string & {});
export type KxNAS1Type = "SSD_1000" | "SSD_250" | "HDD_12" | (string & {});
export type KxNAS1Size = number;
export interface KxNAS1Configuration {
    type?: KxNAS1Type | undefined;
    size?: number | undefined;
}
export type AvailabilityZoneIds = string[];
export interface CreateKxVolumeRequest {
    clientToken?: string | undefined;
    environmentId: string;
    volumeType: KxVolumeType;
    volumeName: string;
    description?: string | undefined;
    nas1Configuration?: KxNAS1Configuration | undefined;
    azMode: KxAzMode;
    availabilityZoneIds: string[];
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type KxVolumeArn = string;
export type KxVolumeStatus = "CREATING" | "CREATE_FAILED" | "ACTIVE" | "UPDATING" | "UPDATED" | "UPDATE_FAILED" | "DELETING" | "DELETED" | "DELETE_FAILED" | (string & {});
export type KxVolumeStatusReason = string;
export interface CreateKxVolumeResponse {
    environmentId?: string | undefined;
    volumeName?: string | undefined;
    volumeType?: KxVolumeType | undefined;
    volumeArn?: string | undefined;
    nas1Configuration?: KxNAS1Configuration | undefined;
    status?: KxVolumeStatus | undefined;
    statusReason?: string | undefined;
    azMode?: KxAzMode | undefined;
    description?: string | undefined;
    availabilityZoneIds?: string[] | undefined;
    createdTimestamp?: Date | undefined;
}
export interface DeleteEnvironmentRequest {
    environmentId: string;
}
export interface DeleteEnvironmentResponse {
}
export interface DeleteKxClusterRequest {
    environmentId: string;
    clusterName: string;
    clientToken?: string | undefined;
}
export interface DeleteKxClusterResponse {
}
export type KxClusterNodeIdString = string;
export interface DeleteKxClusterNodeRequest {
    environmentId: string;
    clusterName: string;
    nodeId: string;
}
export interface DeleteKxClusterNodeResponse {
}
export interface DeleteKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
    clientToken: string;
}
export interface DeleteKxDatabaseResponse {
}
export interface DeleteKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
    clientToken: string;
}
export interface DeleteKxDataviewResponse {
}
export interface DeleteKxEnvironmentRequest {
    environmentId: string;
    clientToken?: string | undefined;
}
export interface DeleteKxEnvironmentResponse {
}
export interface DeleteKxScalingGroupRequest {
    environmentId: string;
    scalingGroupName: string;
    clientToken?: string | undefined;
}
export interface DeleteKxScalingGroupResponse {
}
export interface DeleteKxUserRequest {
    userName: string;
    environmentId: string;
    clientToken?: string | undefined;
}
export interface DeleteKxUserResponse {
}
export interface DeleteKxVolumeRequest {
    environmentId: string;
    volumeName: string;
    clientToken?: string | undefined;
}
export interface DeleteKxVolumeResponse {
}
export interface GetEnvironmentRequest {
    environmentId: string;
}
export type SmsDomainUrl = string;
export interface Environment {
    name?: string | undefined;
    environmentId?: string | undefined;
    awsAccountId?: string | undefined;
    status?: EnvironmentStatus | undefined;
    environmentUrl?: string | undefined;
    description?: string | undefined;
    environmentArn?: string | undefined;
    sageMakerStudioDomainUrl?: string | undefined;
    kmsKeyId?: string | undefined;
    dedicatedServiceAccountId?: string | undefined;
    federationMode?: FederationMode | undefined;
    federationParameters?: FederationParameters | undefined;
}
export interface GetEnvironmentResponse {
    environment?: Environment | undefined;
}
export interface GetKxChangesetRequest {
    environmentId: string;
    databaseName: string;
    changesetId: string;
}
export interface GetKxChangesetResponse {
    changesetId?: string | undefined;
    databaseName?: string | undefined;
    environmentId?: string | undefined;
    changeRequests?: ChangeRequest[] | undefined;
    createdTimestamp?: Date | undefined;
    activeFromTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    status?: ChangesetStatus | undefined;
    errorInfo?: ErrorInfo | undefined;
}
export interface GetKxClusterRequest {
    environmentId: string;
    clusterName: string;
}
export interface GetKxClusterResponse {
    status?: KxClusterStatus | undefined;
    statusReason?: string | undefined;
    clusterName?: string | undefined;
    clusterType?: KxClusterType | undefined;
    tickerplantLogConfiguration?: TickerplantLogConfiguration | undefined;
    volumes?: Volume[] | undefined;
    databases?: KxDatabaseConfiguration[] | undefined;
    cacheStorageConfigurations?: KxCacheStorageConfiguration[] | undefined;
    autoScalingConfiguration?: AutoScalingConfiguration | undefined;
    clusterDescription?: string | undefined;
    capacityConfiguration?: CapacityConfiguration | undefined;
    releaseLabel?: string | undefined;
    vpcConfiguration?: VpcConfiguration | undefined;
    initializationScript?: string | undefined;
    commandLineArguments?: KxCommandLineArgument[] | undefined;
    code?: CodeConfiguration | undefined;
    executionRole?: string | undefined;
    lastModifiedTimestamp?: Date | undefined;
    savedownStorageConfiguration?: KxSavedownStorageConfiguration | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    createdTimestamp?: Date | undefined;
    scalingGroupConfiguration?: KxScalingGroupConfiguration | undefined;
}
export interface GetKxConnectionStringRequest {
    userArn: string;
    environmentId: string;
    clusterName: string;
}
export type SignedKxConnectionString = string | redacted.Redacted<string>;
export interface GetKxConnectionStringResponse {
    signedConnectionString?: string | redacted.Redacted<string> | undefined;
}
export interface GetKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
}
export type NumBytes = number;
export type NumChangesets = number;
export type NumFiles = number;
export interface GetKxDatabaseResponse {
    databaseName?: string | undefined;
    databaseArn?: string | undefined;
    environmentId?: string | undefined;
    description?: string | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    lastCompletedChangesetId?: string | undefined;
    numBytes?: number | undefined;
    numChangesets?: number | undefined;
    numFiles?: number | undefined;
}
export interface GetKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
}
export type AttachedClusterList = string[];
export interface KxDataviewActiveVersion {
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    attachedClusters?: string[] | undefined;
    createdTimestamp?: Date | undefined;
    versionId?: string | undefined;
}
export type KxDataviewActiveVersionList = KxDataviewActiveVersion[];
export type KxDataviewStatusReason = string;
export interface GetKxDataviewResponse {
    databaseName?: string | undefined;
    dataviewName?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    activeVersions?: KxDataviewActiveVersion[] | undefined;
    description?: string | undefined;
    autoUpdate?: boolean | undefined;
    readWrite?: boolean | undefined;
    environmentId?: string | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    status?: KxDataviewStatus | undefined;
    statusReason?: string | undefined;
}
export interface GetKxEnvironmentRequest {
    environmentId: string;
}
export type TgwStatus = "NONE" | "UPDATE_REQUESTED" | "UPDATING" | "FAILED_UPDATE" | "SUCCESSFULLY_UPDATED" | (string & {});
export type DnsStatus = "NONE" | "UPDATE_REQUESTED" | "UPDATING" | "FAILED_UPDATE" | "SUCCESSFULLY_UPDATED" | (string & {});
export type EnvironmentErrorMessage = string;
export type TransitGatewayID = string;
export type ValidCIDRSpace = string;
export type RuleNumber = number;
export type Protocol = string;
export type RuleAction = "allow" | "deny" | (string & {});
export type Port = number;
export interface PortRange {
    from: number;
    to: number;
}
export type IcmpTypeOrCode = number;
export interface IcmpTypeCode {
    type: number;
    code: number;
}
export type ValidCIDRBlock = string;
export interface NetworkACLEntry {
    ruleNumber: number;
    protocol: string;
    ruleAction: RuleAction;
    portRange?: PortRange | undefined;
    icmpTypeCode?: IcmpTypeCode | undefined;
    cidrBlock: string;
}
export type NetworkACLConfiguration = NetworkACLEntry[];
export interface TransitGatewayConfiguration {
    transitGatewayID: string;
    routableCIDRSpace: string;
    attachmentNetworkAclConfiguration?: NetworkACLEntry[] | undefined;
}
export type ValidHostname = string;
export type ValidIPAddress = string;
export interface CustomDNSServer {
    customDNSServerName: string;
    customDNSServerIP: string;
}
export type CustomDNSConfiguration = CustomDNSServer[];
export type StringValueLength1to255 = string;
export interface GetKxEnvironmentResponse {
    name?: string | undefined;
    environmentId?: string | undefined;
    awsAccountId?: string | undefined;
    status?: EnvironmentStatus | undefined;
    tgwStatus?: TgwStatus | undefined;
    dnsStatus?: DnsStatus | undefined;
    errorMessage?: string | undefined;
    description?: string | undefined;
    environmentArn?: string | undefined;
    kmsKeyId?: string | undefined;
    dedicatedServiceAccountId?: string | undefined;
    transitGatewayConfiguration?: TransitGatewayConfiguration | undefined;
    customDNSConfiguration?: CustomDNSServer[] | undefined;
    creationTimestamp?: Date | undefined;
    updateTimestamp?: Date | undefined;
    availabilityZoneIds?: string[] | undefined;
    certificateAuthorityArn?: string | undefined;
}
export interface GetKxScalingGroupRequest {
    environmentId: string;
    scalingGroupName: string;
}
export type Arn = string;
export type KxClusterNameList = string[];
export interface GetKxScalingGroupResponse {
    scalingGroupName?: string | undefined;
    scalingGroupArn?: string | undefined;
    hostType?: string | undefined;
    clusters?: string[] | undefined;
    availabilityZoneId?: string | undefined;
    status?: KxScalingGroupStatus | undefined;
    statusReason?: string | undefined;
    lastModifiedTimestamp?: Date | undefined;
    createdTimestamp?: Date | undefined;
}
export interface GetKxUserRequest {
    userName: string;
    environmentId: string;
}
export interface GetKxUserResponse {
    userName?: string | undefined;
    userArn?: string | undefined;
    environmentId?: string | undefined;
    iamRole?: string | undefined;
}
export interface GetKxVolumeRequest {
    environmentId: string;
    volumeName: string;
}
export interface KxAttachedCluster {
    clusterName?: string | undefined;
    clusterType?: KxClusterType | undefined;
    clusterStatus?: KxClusterStatus | undefined;
}
export type KxAttachedClusters = KxAttachedCluster[];
export interface GetKxVolumeResponse {
    environmentId?: string | undefined;
    volumeName?: string | undefined;
    volumeType?: KxVolumeType | undefined;
    volumeArn?: string | undefined;
    nas1Configuration?: KxNAS1Configuration | undefined;
    status?: KxVolumeStatus | undefined;
    statusReason?: string | undefined;
    createdTimestamp?: Date | undefined;
    description?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneIds?: string[] | undefined;
    lastModifiedTimestamp?: Date | undefined;
    attachedClusters?: KxAttachedCluster[] | undefined;
}
export type PaginationToken = string;
export type ResultLimit = number;
export interface ListEnvironmentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type EnvironmentList = Environment[];
export interface ListEnvironmentsResponse {
    environments?: Environment[] | undefined;
    nextToken?: string | undefined;
}
export type MaxResults = number;
export interface ListKxChangesetsRequest {
    environmentId: string;
    databaseName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface KxChangesetListEntry {
    changesetId?: string | undefined;
    createdTimestamp?: Date | undefined;
    activeFromTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    status?: ChangesetStatus | undefined;
}
export type KxChangesets = KxChangesetListEntry[];
export interface ListKxChangesetsResponse {
    kxChangesets?: KxChangesetListEntry[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxClusterNodesRequest {
    environmentId: string;
    clusterName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type KxNodeStatus = "RUNNING" | "PROVISIONING" | (string & {});
export interface KxNode {
    nodeId?: string | undefined;
    availabilityZoneId?: string | undefined;
    launchTime?: Date | undefined;
    status?: KxNodeStatus | undefined;
}
export type KxNodeSummaries = KxNode[];
export interface ListKxClusterNodesResponse {
    nodes?: KxNode[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxClustersRequest {
    environmentId: string;
    clusterType?: KxClusterType | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface KxCluster {
    status?: KxClusterStatus | undefined;
    statusReason?: string | undefined;
    clusterName?: string | undefined;
    clusterType?: KxClusterType | undefined;
    clusterDescription?: string | undefined;
    releaseLabel?: string | undefined;
    volumes?: Volume[] | undefined;
    initializationScript?: string | undefined;
    executionRole?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    lastModifiedTimestamp?: Date | undefined;
    createdTimestamp?: Date | undefined;
}
export type KxClusters = KxCluster[];
export interface ListKxClustersResponse {
    kxClusterSummaries?: KxCluster[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxDatabasesRequest {
    environmentId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface KxDatabaseListEntry {
    databaseName?: string | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
}
export type KxDatabases = KxDatabaseListEntry[];
export interface ListKxDatabasesResponse {
    kxDatabases?: KxDatabaseListEntry[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxDataviewsRequest {
    environmentId: string;
    databaseName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface KxDataviewListEntry {
    environmentId?: string | undefined;
    databaseName?: string | undefined;
    dataviewName?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    activeVersions?: KxDataviewActiveVersion[] | undefined;
    status?: KxDataviewStatus | undefined;
    description?: string | undefined;
    autoUpdate?: boolean | undefined;
    readWrite?: boolean | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
    statusReason?: string | undefined;
}
export type KxDataviews = KxDataviewListEntry[];
export interface ListKxDataviewsResponse {
    kxDataviews?: KxDataviewListEntry[] | undefined;
    nextToken?: string | undefined;
}
export type BoxedInteger = number;
export interface ListKxEnvironmentsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface KxEnvironment {
    name?: string | undefined;
    environmentId?: string | undefined;
    awsAccountId?: string | undefined;
    status?: EnvironmentStatus | undefined;
    tgwStatus?: TgwStatus | undefined;
    dnsStatus?: DnsStatus | undefined;
    errorMessage?: string | undefined;
    description?: string | undefined;
    environmentArn?: string | undefined;
    kmsKeyId?: string | undefined;
    dedicatedServiceAccountId?: string | undefined;
    transitGatewayConfiguration?: TransitGatewayConfiguration | undefined;
    customDNSConfiguration?: CustomDNSServer[] | undefined;
    creationTimestamp?: Date | undefined;
    updateTimestamp?: Date | undefined;
    availabilityZoneIds?: string[] | undefined;
    certificateAuthorityArn?: string | undefined;
}
export type KxEnvironmentList = KxEnvironment[];
export interface ListKxEnvironmentsResponse {
    environments?: KxEnvironment[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxScalingGroupsRequest {
    environmentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface KxScalingGroup {
    scalingGroupName?: string | undefined;
    hostType?: string | undefined;
    clusters?: string[] | undefined;
    availabilityZoneId?: string | undefined;
    status?: KxScalingGroupStatus | undefined;
    statusReason?: string | undefined;
    lastModifiedTimestamp?: Date | undefined;
    createdTimestamp?: Date | undefined;
}
export type KxScalingGroupList = KxScalingGroup[];
export interface ListKxScalingGroupsResponse {
    scalingGroups?: KxScalingGroup[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxUsersRequest {
    environmentId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface KxUser {
    userArn?: string | undefined;
    userName?: string | undefined;
    iamRole?: string | undefined;
    createTimestamp?: Date | undefined;
    updateTimestamp?: Date | undefined;
}
export type KxUserList = KxUser[];
export interface ListKxUsersResponse {
    users?: KxUser[] | undefined;
    nextToken?: string | undefined;
}
export interface ListKxVolumesRequest {
    environmentId: string;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    volumeType?: KxVolumeType | undefined;
}
export interface KxVolume {
    volumeName?: string | undefined;
    volumeType?: KxVolumeType | undefined;
    status?: KxVolumeStatus | undefined;
    description?: string | undefined;
    statusReason?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneIds?: string[] | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
}
export type KxVolumes = KxVolume[];
export interface ListKxVolumesResponse {
    kxVolumeSummaries?: KxVolume[] | undefined;
    nextToken?: string | undefined;
}
export type FinSpaceTaggableArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateEnvironmentRequest {
    environmentId: string;
    name?: string | undefined;
    description?: string | undefined;
    federationMode?: FederationMode | undefined;
    federationParameters?: FederationParameters | undefined;
}
export interface UpdateEnvironmentResponse {
    environment?: Environment | undefined;
}
export type KxClusterCodeDeploymentStrategy = "NO_RESTART" | "ROLLING" | "FORCE" | (string & {});
export interface KxClusterCodeDeploymentConfiguration {
    deploymentStrategy: KxClusterCodeDeploymentStrategy;
}
export interface UpdateKxClusterCodeConfigurationRequest {
    environmentId: string;
    clusterName: string;
    clientToken?: string | undefined;
    code: CodeConfiguration;
    initializationScript?: string | undefined;
    commandLineArguments?: KxCommandLineArgument[] | undefined;
    deploymentConfiguration?: KxClusterCodeDeploymentConfiguration | undefined;
}
export interface UpdateKxClusterCodeConfigurationResponse {
}
export type KxDeploymentStrategy = "NO_RESTART" | "ROLLING" | (string & {});
export interface KxDeploymentConfiguration {
    deploymentStrategy: KxDeploymentStrategy;
}
export interface UpdateKxClusterDatabasesRequest {
    environmentId: string;
    clusterName: string;
    clientToken?: string | undefined;
    databases: KxDatabaseConfiguration[];
    deploymentConfiguration?: KxDeploymentConfiguration | undefined;
}
export interface UpdateKxClusterDatabasesResponse {
}
export interface UpdateKxDatabaseRequest {
    environmentId: string;
    databaseName: string;
    description?: string | undefined;
    clientToken: string;
}
export interface UpdateKxDatabaseResponse {
    databaseName?: string | undefined;
    environmentId?: string | undefined;
    description?: string | undefined;
    lastModifiedTimestamp?: Date | undefined;
}
export interface UpdateKxDataviewRequest {
    environmentId: string;
    databaseName: string;
    dataviewName: string;
    description?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    clientToken: string;
}
export interface UpdateKxDataviewResponse {
    environmentId?: string | undefined;
    databaseName?: string | undefined;
    dataviewName?: string | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneId?: string | undefined;
    changesetId?: string | undefined;
    segmentConfigurations?: KxDataviewSegmentConfiguration[] | undefined;
    activeVersions?: KxDataviewActiveVersion[] | undefined;
    status?: KxDataviewStatus | undefined;
    autoUpdate?: boolean | undefined;
    readWrite?: boolean | undefined;
    description?: string | undefined;
    createdTimestamp?: Date | undefined;
    lastModifiedTimestamp?: Date | undefined;
}
export interface UpdateKxEnvironmentRequest {
    environmentId: string;
    name?: string | undefined;
    description?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateKxEnvironmentResponse {
    name?: string | undefined;
    environmentId?: string | undefined;
    awsAccountId?: string | undefined;
    status?: EnvironmentStatus | undefined;
    tgwStatus?: TgwStatus | undefined;
    dnsStatus?: DnsStatus | undefined;
    errorMessage?: string | undefined;
    description?: string | undefined;
    environmentArn?: string | undefined;
    kmsKeyId?: string | undefined;
    dedicatedServiceAccountId?: string | undefined;
    transitGatewayConfiguration?: TransitGatewayConfiguration | undefined;
    customDNSConfiguration?: CustomDNSServer[] | undefined;
    creationTimestamp?: Date | undefined;
    updateTimestamp?: Date | undefined;
    availabilityZoneIds?: string[] | undefined;
}
export interface UpdateKxEnvironmentNetworkRequest {
    environmentId: string;
    transitGatewayConfiguration?: TransitGatewayConfiguration | undefined;
    customDNSConfiguration?: CustomDNSServer[] | undefined;
    clientToken?: string | undefined;
}
export interface UpdateKxEnvironmentNetworkResponse {
    name?: string | undefined;
    environmentId?: string | undefined;
    awsAccountId?: string | undefined;
    status?: EnvironmentStatus | undefined;
    tgwStatus?: TgwStatus | undefined;
    dnsStatus?: DnsStatus | undefined;
    errorMessage?: string | undefined;
    description?: string | undefined;
    environmentArn?: string | undefined;
    kmsKeyId?: string | undefined;
    dedicatedServiceAccountId?: string | undefined;
    transitGatewayConfiguration?: TransitGatewayConfiguration | undefined;
    customDNSConfiguration?: CustomDNSServer[] | undefined;
    creationTimestamp?: Date | undefined;
    updateTimestamp?: Date | undefined;
    availabilityZoneIds?: string[] | undefined;
}
export interface UpdateKxUserRequest {
    environmentId: string;
    userName: string;
    iamRole: string;
    clientToken?: string | undefined;
}
export interface UpdateKxUserResponse {
    userName?: string | undefined;
    userArn?: string | undefined;
    environmentId?: string | undefined;
    iamRole?: string | undefined;
}
export interface UpdateKxVolumeRequest {
    environmentId: string;
    volumeName: string;
    description?: string | undefined;
    clientToken?: string | undefined;
    nas1Configuration?: KxNAS1Configuration | undefined;
}
export interface UpdateKxVolumeResponse {
    environmentId?: string | undefined;
    volumeName?: string | undefined;
    volumeType?: KxVolumeType | undefined;
    volumeArn?: string | undefined;
    nas1Configuration?: KxNAS1Configuration | undefined;
    status?: KxVolumeStatus | undefined;
    description?: string | undefined;
    statusReason?: string | undefined;
    createdTimestamp?: Date | undefined;
    azMode?: KxAzMode | undefined;
    availabilityZoneIds?: string[] | undefined;
    lastModifiedTimestamp?: Date | undefined;
    attachedClusters?: KxAttachedCluster[] | undefined;
}
export type ErrorMessage2 = string;
export type CreateEnvironmentError = AccessDeniedException | InternalServerException | LimitExceededException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a new FinSpace environment.
 */
export declare const createEnvironment: API.OperationMethod<CreateEnvironmentRequest & RegionInput, CreateEnvironmentResponse, CreateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateKxChangesetError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a changeset for a kdb database. A changeset allows you to add and delete existing files by using an ordered list of change requests.
 */
export declare const createKxChangeset: API.OperationMethod<CreateKxChangesetRequest & RegionInput, CreateKxChangesetResponse, CreateKxChangesetError, Credentials | HttpClient.HttpClient>;
export type CreateKxClusterError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new kdb cluster.
 */
export declare const createKxCluster: API.OperationMethod<CreateKxClusterRequest & RegionInput, CreateKxClusterResponse, CreateKxClusterError, Credentials | HttpClient.HttpClient>;
export type CreateKxDatabaseError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new kdb database in the environment.
 */
export declare const createKxDatabase: API.OperationMethod<CreateKxDatabaseRequest & RegionInput, CreateKxDatabaseResponse, CreateKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type CreateKxDataviewError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a snapshot of kdb database with tiered storage capabilities and a pre-warmed cache, ready for mounting on kdb clusters. Dataviews are only available for clusters running on a scaling group. They are not supported on dedicated clusters.
 */
export declare const createKxDataview: API.OperationMethod<CreateKxDataviewRequest & RegionInput, CreateKxDataviewResponse, CreateKxDataviewError, Credentials | HttpClient.HttpClient>;
export type CreateKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a managed kdb environment for the account.
 */
export declare const createKxEnvironment: API.OperationMethod<CreateKxEnvironmentRequest & RegionInput, CreateKxEnvironmentResponse, CreateKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateKxScalingGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new scaling group.
 */
export declare const createKxScalingGroup: API.OperationMethod<CreateKxScalingGroupRequest & RegionInput, CreateKxScalingGroupResponse, CreateKxScalingGroupError, Credentials | HttpClient.HttpClient>;
export type CreateKxUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a user in FinSpace kdb environment with an associated IAM role.
 */
export declare const createKxUser: API.OperationMethod<CreateKxUserRequest & RegionInput, CreateKxUserResponse, CreateKxUserError, Credentials | HttpClient.HttpClient>;
export type CreateKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new volume with a specific amount of throughput and storage capacity.
 */
export declare const createKxVolume: API.OperationMethod<CreateKxVolumeRequest & RegionInput, CreateKxVolumeResponse, CreateKxVolumeError, Credentials | HttpClient.HttpClient>;
export type DeleteEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete an FinSpace environment.
 */
export declare const deleteEnvironment: API.OperationMethod<DeleteEnvironmentRequest & RegionInput, DeleteEnvironmentResponse, DeleteEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteKxClusterError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a kdb cluster.
 */
export declare const deleteKxCluster: API.OperationMethod<DeleteKxClusterRequest & RegionInput, DeleteKxClusterResponse, DeleteKxClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteKxClusterNodeError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified nodes from a cluster.
 */
export declare const deleteKxClusterNode: API.OperationMethod<DeleteKxClusterNodeRequest & RegionInput, DeleteKxClusterNodeResponse, DeleteKxClusterNodeError, Credentials | HttpClient.HttpClient>;
export type DeleteKxDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified database and all of its associated data. This action is irreversible. You must copy any data out of the database before deleting it if the data is to be retained.
 */
export declare const deleteKxDatabase: API.OperationMethod<DeleteKxDatabaseRequest & RegionInput, DeleteKxDatabaseResponse, DeleteKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type DeleteKxDataviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified dataview. Before deleting a dataview, make sure that it is not in use by any cluster.
 */
export declare const deleteKxDataview: API.OperationMethod<DeleteKxDataviewRequest & RegionInput, DeleteKxDataviewResponse, DeleteKxDataviewError, Credentials | HttpClient.HttpClient>;
export type DeleteKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the kdb environment. This action is irreversible. Deleting a kdb environment will remove all the associated data and any services running in it.
 */
export declare const deleteKxEnvironment: API.OperationMethod<DeleteKxEnvironmentRequest & RegionInput, DeleteKxEnvironmentResponse, DeleteKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteKxScalingGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified scaling group. This action is irreversible. You cannot delete a scaling group until all the clusters running on it have been deleted.
 */
export declare const deleteKxScalingGroup: API.OperationMethod<DeleteKxScalingGroupRequest & RegionInput, DeleteKxScalingGroupResponse, DeleteKxScalingGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteKxUserError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a user in the specified kdb environment.
 */
export declare const deleteKxUser: API.OperationMethod<DeleteKxUserRequest & RegionInput, DeleteKxUserResponse, DeleteKxUserError, Credentials | HttpClient.HttpClient>;
export type DeleteKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a volume. You can only delete a volume if it's not attached to a cluster or a dataview. When a volume is deleted, any data on the volume is lost. This action is irreversible.
 */
export declare const deleteKxVolume: API.OperationMethod<DeleteKxVolumeRequest & RegionInput, DeleteKxVolumeResponse, DeleteKxVolumeError, Credentials | HttpClient.HttpClient>;
export type GetEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns the FinSpace environment object.
 */
export declare const getEnvironment: API.OperationMethod<GetEnvironmentRequest & RegionInput, GetEnvironmentResponse, GetEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetKxChangesetError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a kdb changeset.
 */
export declare const getKxChangeset: API.OperationMethod<GetKxChangesetRequest & RegionInput, GetKxChangesetResponse, GetKxChangesetError, Credentials | HttpClient.HttpClient>;
export type GetKxClusterError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a kdb cluster.
 */
export declare const getKxCluster: API.OperationMethod<GetKxClusterRequest & RegionInput, GetKxClusterResponse, GetKxClusterError, Credentials | HttpClient.HttpClient>;
export type GetKxConnectionStringError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a connection string for a user to connect to a kdb cluster. You must call this API using the same role that you have defined while creating a user.
 */
export declare const getKxConnectionString: API.OperationMethod<GetKxConnectionStringRequest & RegionInput, GetKxConnectionStringResponse, GetKxConnectionStringError, Credentials | HttpClient.HttpClient>;
export type GetKxDatabaseError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns database information for the specified environment ID.
 */
export declare const getKxDatabase: API.OperationMethod<GetKxDatabaseRequest & RegionInput, GetKxDatabaseResponse, GetKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type GetKxDataviewError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of the dataview.
 */
export declare const getKxDataview: API.OperationMethod<GetKxDataviewRequest & RegionInput, GetKxDataviewResponse, GetKxDataviewError, Credentials | HttpClient.HttpClient>;
export type GetKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves all the information for the specified kdb environment.
 */
export declare const getKxEnvironment: API.OperationMethod<GetKxEnvironmentRequest & RegionInput, GetKxEnvironmentResponse, GetKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetKxScalingGroupError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves details of a scaling group.
 */
export declare const getKxScalingGroup: API.OperationMethod<GetKxScalingGroupRequest & RegionInput, GetKxScalingGroupResponse, GetKxScalingGroupError, Credentials | HttpClient.HttpClient>;
export type GetKxUserError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about the specified kdb user.
 */
export declare const getKxUser: API.OperationMethod<GetKxUserRequest & RegionInput, GetKxUserResponse, GetKxUserError, Credentials | HttpClient.HttpClient>;
export type GetKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the information about the volume.
 */
export declare const getKxVolume: API.OperationMethod<GetKxVolumeRequest & RegionInput, GetKxVolumeResponse, GetKxVolumeError, Credentials | HttpClient.HttpClient>;
export type ListEnvironmentsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * A list of all of your FinSpace environments.
 */
export declare const listEnvironments: API.OperationMethod<ListEnvironmentsRequest & RegionInput, ListEnvironmentsResponse, ListEnvironmentsError, Credentials | HttpClient.HttpClient>;
export type ListKxChangesetsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the changesets for a database.
 */
export declare const listKxChangesets: API.PaginatedOperationMethod<ListKxChangesetsRequest & RegionInput, ListKxChangesetsResponse, ListKxChangesetsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxClusterNodesError = AccessDeniedException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the nodes in a kdb cluster.
 */
export declare const listKxClusterNodes: API.PaginatedOperationMethod<ListKxClusterNodesRequest & RegionInput, ListKxClusterNodesResponse, ListKxClusterNodesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxClustersError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of clusters.
 */
export declare const listKxClusters: API.OperationMethod<ListKxClustersRequest & RegionInput, ListKxClustersResponse, ListKxClustersError, Credentials | HttpClient.HttpClient>;
export type ListKxDatabasesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the databases in the kdb environment.
 */
export declare const listKxDatabases: API.PaginatedOperationMethod<ListKxDatabasesRequest & RegionInput, ListKxDatabasesResponse, ListKxDatabasesError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxDataviewsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of all the dataviews in the database.
 */
export declare const listKxDataviews: API.PaginatedOperationMethod<ListKxDataviewsRequest & RegionInput, ListKxDataviewsResponse, ListKxDataviewsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxEnvironmentsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * Returns a list of kdb environments created in an account.
 */
export declare const listKxEnvironments: API.PaginatedOperationMethod<ListKxEnvironmentsRequest & RegionInput, ListKxEnvironmentsResponse, ListKxEnvironmentsError, Credentials | HttpClient.HttpClient, KxEnvironment>;
export type ListKxScalingGroupsError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of scaling groups in a kdb environment.
 */
export declare const listKxScalingGroups: API.PaginatedOperationMethod<ListKxScalingGroupsRequest & RegionInput, ListKxScalingGroupsResponse, ListKxScalingGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type ListKxUsersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the users in a kdb environment.
 */
export declare const listKxUsers: API.OperationMethod<ListKxUsersRequest & RegionInput, ListKxUsersResponse, ListKxUsersError, Credentials | HttpClient.HttpClient>;
export type ListKxVolumesError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all the volumes in a kdb environment.
 */
export declare const listKxVolumes: API.OperationMethod<ListKxVolumesRequest & RegionInput, ListKxVolumesResponse, ListKxVolumesError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * A list of all tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Adds metadata tags to a FinSpace resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | InvalidRequestException | ResourceNotFoundException | CommonErrors;
/**
 * Removes metadata tags from a FinSpace resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateEnvironmentError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update your FinSpace environment.
 */
export declare const updateEnvironment: API.OperationMethod<UpdateEnvironmentRequest & RegionInput, UpdateEnvironmentResponse, UpdateEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateKxClusterCodeConfigurationError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Allows you to update code configuration on a running cluster. By using this API you can update the code, the initialization script path, and the command line arguments for a specific cluster.
 * The configuration that you want to update will override any existing configurations on the cluster.
 */
export declare const updateKxClusterCodeConfiguration: API.OperationMethod<UpdateKxClusterCodeConfigurationRequest & RegionInput, UpdateKxClusterCodeConfigurationResponse, UpdateKxClusterCodeConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateKxClusterDatabasesError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the databases mounted on a kdb cluster, which includes the `changesetId` and all the dbPaths to be cached. This API does not allow you to change a database name or add a database if you created a cluster without one.
 *
 * Using this API you can point a cluster to a different changeset and modify a list of partitions being cached.
 */
export declare const updateKxClusterDatabases: API.OperationMethod<UpdateKxClusterDatabasesRequest & RegionInput, UpdateKxClusterDatabasesResponse, UpdateKxClusterDatabasesError, Credentials | HttpClient.HttpClient>;
export type UpdateKxDatabaseError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information for the given kdb database.
 */
export declare const updateKxDatabase: API.OperationMethod<UpdateKxDatabaseRequest & RegionInput, UpdateKxDatabaseResponse, UpdateKxDatabaseError, Credentials | HttpClient.HttpClient>;
export type UpdateKxDataviewError = AccessDeniedException | ConflictException | InternalServerException | ResourceAlreadyExistsException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the specified dataview. The dataviews get automatically updated when any new changesets are ingested. Each update of the dataview creates a new version, including changeset details and cache configurations
 */
export declare const updateKxDataview: API.OperationMethod<UpdateKxDataviewRequest & RegionInput, UpdateKxDataviewResponse, UpdateKxDataviewError, Credentials | HttpClient.HttpClient>;
export type UpdateKxEnvironmentError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates information for the given kdb environment.
 */
export declare const updateKxEnvironment: API.OperationMethod<UpdateKxEnvironmentRequest & RegionInput, UpdateKxEnvironmentResponse, UpdateKxEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateKxEnvironmentNetworkError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates environment network to connect to your internal network by using a transit gateway. This API supports request to create a transit gateway attachment from FinSpace VPC to your transit gateway ID and create a custom Route-53 outbound resolvers.
 *
 * Once you send a request to update a network, you cannot change it again. Network update might require termination of any clusters that are running in the existing network.
 */
export declare const updateKxEnvironmentNetwork: API.OperationMethod<UpdateKxEnvironmentNetworkRequest & RegionInput, UpdateKxEnvironmentNetworkResponse, UpdateKxEnvironmentNetworkError, Credentials | HttpClient.HttpClient>;
export type UpdateKxUserError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the user details. You can only update the IAM role associated with a user.
 */
export declare const updateKxUser: API.OperationMethod<UpdateKxUserRequest & RegionInput, UpdateKxUserResponse, UpdateKxUserError, Credentials | HttpClient.HttpClient>;
export type UpdateKxVolumeError = AccessDeniedException | ConflictException | InternalServerException | LimitExceededException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the throughput or capacity of a volume. During the update process, the filesystem
 * might be unavailable for a few minutes. You can retry any operations after the update is complete.
 */
export declare const updateKxVolume: API.OperationMethod<UpdateKxVolumeRequest & RegionInput, UpdateKxVolumeResponse, UpdateKxVolumeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=finspace.d.ts.map