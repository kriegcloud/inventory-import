import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Layer from "effect/Layer";
import type * as Scope from "effect/Scope";
import { WorkflowEngine } from "effect/workflow";
import { type Callbacks } from "../Callback.ts";
import type { RuntimeContext } from "../RuntimeContext.ts";
import type { DurableObjectStorage } from "./Workerd/DurableObjectStorage.ts";
/** What a provider supplies to host the engine's Durable Objects. */
export interface DurableObjectEngineHost<Host, State> {
    /** Declare a Durable Object class on the host Worker, during its init. */
    readonly declare: (name: string, impl: ObjectImpl<State>) => Effect.Effect<Namespace, never, Host>;
    /** The provider's per-instance Durable Object state. */
    readonly state: Context.Key<State, StateService>;
}
/** The part of a provider's Durable Object state the engine uses: SQL storage. */
type StateService = {
    readonly storage: {
        readonly sql: Pick<DurableObjectStorage["sql"], "exec">;
        readonly transaction: DurableObjectStorage["transaction"];
    };
};
/**
 * Effect's `WorkflowEngine` on Durable Objects, for any Workers runtime that
 * hosts them (Cloudflare today). Each workflow gets its own Durable Object
 * class on the host Worker, and each execution is one instance of it, named
 * by its execution id, with its journal in that instance's SQLite.
 *
 * A run replays the workflow from the top: finished activities return their
 * stored results, and the first unfinished one runs and is stored. A run that
 * waits on a `DurableClock` or `DurableDeferred` that isn't ready suspends,
 * and the clock firing or the deferred being completed runs it again. Every
 * run happens in one durable callback per execution, so runs never overlap,
 * and a run that fails or is cut short is retried.
 *
 * A `Workflows.OnResult` in the context the engine builds in is called from
 * the execution's object each time it stores a result, scheduled in the same
 * transaction as the result and retried until it succeeds.
 *
 * Providers supply how to declare a Durable Object class on their Worker and
 * the tag of their per-instance state.
 *
 * @internal
 */
export declare const makeDurableObjectEngine: <Host, State>(host: DurableObjectEngineHost<Host, State>) => Layer.Layer<WorkflowEngine.WorkflowEngine, never, Host>;
interface Stub {
    readonly [method: string]: (...args: ReadonlyArray<unknown>) => Effect.Effect<unknown, unknown>;
}
/** A declared Durable Object class: stubs by instance name. */
export interface Namespace {
    readonly getByName: (name: string) => Stub;
}
/** The two-stage implementation of an execution object. */
/**
 * Provide an engine object's instances with a host's `Callbacks`
 * implementation. Every host's `declare` does this with its own.
 */
export declare const provideCallbacks: <State, R>(impl: ObjectImpl<State>, callbacks: Layer.Layer<Callbacks, never, R>) => Effect.Effect<Effect.Effect<Record<string, unknown>, never, State | RuntimeContext | Scope.Scope | R>, never, State>;
export type ObjectImpl<State> = Effect.Effect<Effect.Effect<Record<string, unknown>, never, State | RuntimeContext | Callbacks | Scope.Scope>, never, State>;
export {};
//# sourceMappingURL=DurableObjectEngine.d.ts.map