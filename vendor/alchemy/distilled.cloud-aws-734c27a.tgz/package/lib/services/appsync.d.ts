import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
import * as T from "../traits.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ApiKeyLimitExceededException_base: S.TaggedErrorClass<"ApiKeyLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ApiKeyLimitExceededException extends /*@__PURE__*/ ApiKeyLimitExceededException_base {
}
declare const ApiKeyValidityOutOfBoundsException_base: S.TaggedErrorClass<"ApiKeyValidityOutOfBoundsException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ApiKeyValidityOutOfBoundsException extends /*@__PURE__*/ ApiKeyValidityOutOfBoundsException_base {
}
declare const ApiLimitExceededException_base: S.TaggedErrorClass<"ApiLimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ApiLimitExceededException extends /*@__PURE__*/ ApiLimitExceededException_base {
}
declare const BadRequestException_base: S.TaggedErrorClass<"BadRequestException", {
    readonly message: any;
    readonly reason: any;
    readonly detail: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class BadRequestException extends /*@__PURE__*/ BadRequestException_base {
}
declare const ConcurrentModificationException_base: S.TaggedErrorClass<"ConcurrentModificationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConcurrentModificationException extends /*@__PURE__*/ ConcurrentModificationException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const GraphQLSchemaException_base: S.TaggedErrorClass<"GraphQLSchemaException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class GraphQLSchemaException extends /*@__PURE__*/ GraphQLSchemaException_base {
}
declare const InternalFailureException_base: S.TaggedErrorClass<"InternalFailureException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalFailureException extends /*@__PURE__*/ InternalFailureException_base {
}
declare const LimitExceededException_base: S.TaggedErrorClass<"LimitExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class LimitExceededException extends /*@__PURE__*/ LimitExceededException_base {
}
declare const NotFoundException_base: S.TaggedErrorClass<"NotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class NotFoundException extends /*@__PURE__*/ NotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const UnauthorizedException_base: S.TaggedErrorClass<"UnauthorizedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class UnauthorizedException extends /*@__PURE__*/ UnauthorizedException_base {
}
export type DomainName = string;
export interface AssociateApiRequest {
    domainName: string;
    apiId: string;
}
export type AssociationStatus = "PROCESSING" | "FAILED" | "SUCCESS" | (string & {});
export interface ApiAssociation {
    domainName?: string | undefined;
    apiId?: string | undefined;
    associationStatus?: AssociationStatus | undefined;
    deploymentDetail?: string | undefined;
}
export interface AssociateApiResponse {
    apiAssociation?: ApiAssociation | undefined;
}
export type MergeType = "MANUAL_MERGE" | "AUTO_MERGE" | (string & {});
export interface SourceApiAssociationConfig {
    mergeType?: MergeType | undefined;
}
export interface AssociateMergedGraphqlApiRequest {
    sourceApiIdentifier: string;
    mergedApiIdentifier: string;
    description?: string | undefined;
    sourceApiAssociationConfig?: SourceApiAssociationConfig | undefined;
}
export type SourceApiAssociationStatus = "MERGE_SCHEDULED" | "MERGE_FAILED" | "MERGE_SUCCESS" | "MERGE_IN_PROGRESS" | "AUTO_MERGE_SCHEDULE_FAILED" | "DELETION_SCHEDULED" | "DELETION_IN_PROGRESS" | "DELETION_FAILED" | (string & {});
export interface SourceApiAssociation {
    associationId?: string | undefined;
    associationArn?: string | undefined;
    sourceApiId?: string | undefined;
    sourceApiArn?: string | undefined;
    mergedApiArn?: string | undefined;
    mergedApiId?: string | undefined;
    description?: string | undefined;
    sourceApiAssociationConfig?: SourceApiAssociationConfig | undefined;
    sourceApiAssociationStatus?: SourceApiAssociationStatus | undefined;
    sourceApiAssociationStatusDetail?: string | undefined;
    lastSuccessfulMergeDate?: Date | undefined;
}
export interface AssociateMergedGraphqlApiResponse {
    sourceApiAssociation?: SourceApiAssociation | undefined;
}
export interface AssociateSourceGraphqlApiRequest {
    mergedApiIdentifier: string;
    sourceApiIdentifier: string;
    description?: string | undefined;
    sourceApiAssociationConfig?: SourceApiAssociationConfig | undefined;
}
export interface AssociateSourceGraphqlApiResponse {
    sourceApiAssociation?: SourceApiAssociation | undefined;
}
export type ApiName = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type AuthenticationType = "API_KEY" | "AWS_IAM" | "AMAZON_COGNITO_USER_POOLS" | "OPENID_CONNECT" | "AWS_LAMBDA" | (string & {});
export interface CognitoConfig {
    userPoolId: string;
    awsRegion: string;
    appIdClientRegex?: string | undefined;
}
export interface OpenIDConnectConfig {
    issuer: string;
    clientId?: string | undefined;
    iatTTL?: number | undefined;
    authTTL?: number | undefined;
}
export type TTL = number;
export interface LambdaAuthorizerConfig {
    authorizerResultTtlInSeconds?: number | undefined;
    authorizerUri: string;
    identityValidationExpression?: string | undefined;
}
export interface AuthProvider {
    authType: AuthenticationType;
    cognitoConfig?: CognitoConfig | undefined;
    openIDConnectConfig?: OpenIDConnectConfig | undefined;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig | undefined;
}
export type AuthProviders = AuthProvider[];
export interface AuthMode {
    authType: AuthenticationType;
}
export type AuthModes = AuthMode[];
export type EventLogLevel = "NONE" | "ERROR" | "ALL" | "INFO" | "DEBUG" | (string & {});
export interface EventLogConfig {
    logLevel: EventLogLevel;
    cloudWatchLogsRoleArn: string;
}
export interface EventConfig {
    authProviders: AuthProvider[];
    connectionAuthModes: AuthMode[];
    defaultPublishAuthModes: AuthMode[];
    defaultSubscribeAuthModes: AuthMode[];
    logConfig?: EventLogConfig | undefined;
}
export interface CreateApiRequest {
    name: string;
    ownerContact?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    eventConfig: EventConfig;
}
export type OwnerContact = string;
export type MapOfStringToString = {
    [key: string]: string | undefined;
};
export interface Api {
    apiId?: string | undefined;
    name?: string | undefined;
    ownerContact?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    dns?: {
        [key: string]: string | undefined;
    } | undefined;
    apiArn?: string | undefined;
    created?: Date | undefined;
    xrayEnabled?: boolean | undefined;
    wafWebAclArn?: string | undefined;
    eventConfig?: EventConfig | undefined;
}
export interface CreateApiResponse {
    api?: Api | undefined;
}
export type ApiCachingBehavior = "FULL_REQUEST_CACHING" | "PER_RESOLVER_CACHING" | "OPERATION_LEVEL_CACHING" | (string & {});
export type ApiCacheType = "T2_SMALL" | "T2_MEDIUM" | "R4_LARGE" | "R4_XLARGE" | "R4_2XLARGE" | "R4_4XLARGE" | "R4_8XLARGE" | "SMALL" | "MEDIUM" | "LARGE" | "XLARGE" | "LARGE_2X" | "LARGE_4X" | "LARGE_8X" | "LARGE_12X" | (string & {});
export type CacheHealthMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export interface CreateApiCacheRequest {
    apiId: string;
    ttl: number;
    transitEncryptionEnabled?: boolean | undefined;
    atRestEncryptionEnabled?: boolean | undefined;
    apiCachingBehavior: ApiCachingBehavior;
    type: ApiCacheType;
    healthMetricsConfig?: CacheHealthMetricsConfig | undefined;
}
export type ApiCacheStatus = "AVAILABLE" | "CREATING" | "DELETING" | "MODIFYING" | "FAILED" | (string & {});
export interface ApiCache {
    ttl?: number | undefined;
    apiCachingBehavior?: ApiCachingBehavior | undefined;
    transitEncryptionEnabled?: boolean | undefined;
    atRestEncryptionEnabled?: boolean | undefined;
    type?: ApiCacheType | undefined;
    status?: ApiCacheStatus | undefined;
    healthMetricsConfig?: CacheHealthMetricsConfig | undefined;
}
export interface CreateApiCacheResponse {
    apiCache?: ApiCache | undefined;
}
export interface CreateApiKeyRequest {
    apiId: string;
    description?: string | undefined;
    expires?: number | undefined;
}
export interface ApiKey {
    id?: string | undefined;
    description?: string | undefined;
    expires?: number | undefined;
    deletes?: number | undefined;
}
export interface CreateApiKeyResponse {
    apiKey?: ApiKey | undefined;
}
export type Namespace = string;
export type Code = string;
export type HandlerBehavior = "CODE" | "DIRECT" | (string & {});
export type InvokeType = "REQUEST_RESPONSE" | "EVENT" | (string & {});
export interface LambdaConfig {
    invokeType?: InvokeType | undefined;
}
export interface Integration {
    dataSourceName: string;
    lambdaConfig?: LambdaConfig | undefined;
}
export interface HandlerConfig {
    behavior: HandlerBehavior;
    integration: Integration;
}
export interface HandlerConfigs {
    onPublish?: HandlerConfig | undefined;
    onSubscribe?: HandlerConfig | undefined;
}
export interface CreateChannelNamespaceRequest {
    apiId: string;
    name: string;
    subscribeAuthModes?: AuthMode[] | undefined;
    publishAuthModes?: AuthMode[] | undefined;
    codeHandlers?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    handlerConfigs?: HandlerConfigs | undefined;
}
export interface ChannelNamespace {
    apiId?: string | undefined;
    name?: string | undefined;
    subscribeAuthModes?: AuthMode[] | undefined;
    publishAuthModes?: AuthMode[] | undefined;
    codeHandlers?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    channelNamespaceArn?: string | undefined;
    created?: Date | undefined;
    lastModified?: Date | undefined;
    handlerConfigs?: HandlerConfigs | undefined;
}
export interface CreateChannelNamespaceResponse {
    channelNamespace?: ChannelNamespace | undefined;
}
export type ResourceName = string;
export type DataSourceType = "AWS_LAMBDA" | "AMAZON_DYNAMODB" | "AMAZON_ELASTICSEARCH" | "NONE" | "HTTP" | "RELATIONAL_DATABASE" | "AMAZON_OPENSEARCH_SERVICE" | "AMAZON_EVENTBRIDGE" | "AMAZON_BEDROCK_RUNTIME" | (string & {});
export interface DeltaSyncConfig {
    baseTableTTL?: number | undefined;
    deltaSyncTableName?: string | undefined;
    deltaSyncTableTTL?: number | undefined;
}
export interface DynamodbDataSourceConfig {
    tableName: string;
    awsRegion: string;
    useCallerCredentials?: boolean | undefined;
    deltaSyncConfig?: DeltaSyncConfig | undefined;
    versioned?: boolean | undefined;
}
export interface LambdaDataSourceConfig {
    lambdaFunctionArn: string;
}
export interface ElasticsearchDataSourceConfig {
    endpoint: string;
    awsRegion: string;
}
export interface OpenSearchServiceDataSourceConfig {
    endpoint: string;
    awsRegion: string;
}
export type AuthorizationType = "AWS_IAM" | (string & {});
export interface AwsIamConfig {
    signingRegion?: string | undefined;
    signingServiceName?: string | undefined;
}
export interface AuthorizationConfig {
    authorizationType: AuthorizationType;
    awsIamConfig?: AwsIamConfig | undefined;
}
export interface HttpDataSourceConfig {
    endpoint?: string | undefined;
    authorizationConfig?: AuthorizationConfig | undefined;
}
export type RelationalDatabaseSourceType = "RDS_HTTP_ENDPOINT" | (string & {});
export interface RdsHttpEndpointConfig {
    awsRegion?: string | undefined;
    dbClusterIdentifier?: string | undefined;
    databaseName?: string | undefined;
    schema?: string | undefined;
    awsSecretStoreArn?: string | undefined;
}
export interface RelationalDatabaseDataSourceConfig {
    relationalDatabaseSourceType?: RelationalDatabaseSourceType | undefined;
    rdsHttpEndpointConfig?: RdsHttpEndpointConfig | undefined;
}
export interface EventBridgeDataSourceConfig {
    eventBusArn: string;
}
export type DataSourceLevelMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export interface CreateDataSourceRequest {
    apiId: string;
    name: string;
    description?: string | undefined;
    type: DataSourceType;
    serviceRoleArn?: string | undefined;
    dynamodbConfig?: DynamodbDataSourceConfig | undefined;
    lambdaConfig?: LambdaDataSourceConfig | undefined;
    elasticsearchConfig?: ElasticsearchDataSourceConfig | undefined;
    openSearchServiceConfig?: OpenSearchServiceDataSourceConfig | undefined;
    httpConfig?: HttpDataSourceConfig | undefined;
    relationalDatabaseConfig?: RelationalDatabaseDataSourceConfig | undefined;
    eventBridgeConfig?: EventBridgeDataSourceConfig | undefined;
    metricsConfig?: DataSourceLevelMetricsConfig | undefined;
}
export interface DataSource {
    dataSourceArn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    type?: DataSourceType | undefined;
    serviceRoleArn?: string | undefined;
    dynamodbConfig?: DynamodbDataSourceConfig | undefined;
    lambdaConfig?: LambdaDataSourceConfig | undefined;
    elasticsearchConfig?: ElasticsearchDataSourceConfig | undefined;
    openSearchServiceConfig?: OpenSearchServiceDataSourceConfig | undefined;
    httpConfig?: HttpDataSourceConfig | undefined;
    relationalDatabaseConfig?: RelationalDatabaseDataSourceConfig | undefined;
    eventBridgeConfig?: EventBridgeDataSourceConfig | undefined;
    metricsConfig?: DataSourceLevelMetricsConfig | undefined;
}
export interface CreateDataSourceResponse {
    dataSource?: DataSource | undefined;
}
export type CertificateArn = string;
export type Description = string;
export interface CreateDomainNameRequest {
    domainName: string;
    certificateArn: string;
    description?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DomainNameConfig {
    domainName?: string | undefined;
    description?: string | undefined;
    certificateArn?: string | undefined;
    appsyncDomainName?: string | undefined;
    hostedZoneId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    domainNameArn?: string | undefined;
}
export interface CreateDomainNameResponse {
    domainNameConfig?: DomainNameConfig | undefined;
}
export type MappingTemplate = string;
export type ConflictHandlerType = "OPTIMISTIC_CONCURRENCY" | "LAMBDA" | "AUTOMERGE" | "NONE" | (string & {});
export type ConflictDetectionType = "VERSION" | "NONE" | (string & {});
export interface LambdaConflictHandlerConfig {
    lambdaConflictHandlerArn?: string | undefined;
}
export interface SyncConfig {
    conflictHandler?: ConflictHandlerType | undefined;
    conflictDetection?: ConflictDetectionType | undefined;
    lambdaConflictHandlerConfig?: LambdaConflictHandlerConfig | undefined;
}
export type MaxBatchSize = number;
export type RuntimeName = "APPSYNC_JS" | (string & {});
export interface AppSyncRuntime {
    name: RuntimeName;
    runtimeVersion: string;
}
export interface CreateFunctionRequest {
    apiId: string;
    name: string;
    description?: string | undefined;
    dataSourceName: string;
    requestMappingTemplate?: string | undefined;
    responseMappingTemplate?: string | undefined;
    functionVersion?: string | undefined;
    syncConfig?: SyncConfig | undefined;
    maxBatchSize?: number | undefined;
    runtime?: AppSyncRuntime | undefined;
    code?: string | undefined;
}
export interface FunctionConfiguration {
    functionId?: string | undefined;
    functionArn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    dataSourceName?: string | undefined;
    requestMappingTemplate?: string | undefined;
    responseMappingTemplate?: string | undefined;
    functionVersion?: string | undefined;
    syncConfig?: SyncConfig | undefined;
    maxBatchSize?: number | undefined;
    runtime?: AppSyncRuntime | undefined;
    code?: string | undefined;
}
export interface CreateFunctionResponse {
    functionConfiguration?: FunctionConfiguration | undefined;
}
export type FieldLogLevel = "NONE" | "ERROR" | "ALL" | "INFO" | "DEBUG" | (string & {});
export interface LogConfig {
    fieldLogLevel: FieldLogLevel;
    cloudWatchLogsRoleArn: string;
    excludeVerboseContent?: boolean | undefined;
}
export type DefaultAction = "ALLOW" | "DENY" | (string & {});
export interface UserPoolConfig {
    userPoolId: string;
    awsRegion: string;
    defaultAction: DefaultAction;
    appIdClientRegex?: string | undefined;
}
export interface CognitoUserPoolConfig {
    userPoolId: string;
    awsRegion: string;
    appIdClientRegex?: string | undefined;
}
export interface AdditionalAuthenticationProvider {
    authenticationType?: AuthenticationType | undefined;
    openIDConnectConfig?: OpenIDConnectConfig | undefined;
    userPoolConfig?: CognitoUserPoolConfig | undefined;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig | undefined;
}
export type AdditionalAuthenticationProviders = AdditionalAuthenticationProvider[];
export type GraphQLApiType = "GRAPHQL" | "MERGED" | (string & {});
export type GraphQLApiVisibility = "GLOBAL" | "PRIVATE" | (string & {});
export type GraphQLApiIntrospectionConfig = "ENABLED" | "DISABLED" | (string & {});
export type QueryDepthLimit = number;
export type ResolverCountLimit = number;
export type ResolverLevelMetricsBehavior = "FULL_REQUEST_RESOLVER_METRICS" | "PER_RESOLVER_METRICS" | (string & {});
export type DataSourceLevelMetricsBehavior = "FULL_REQUEST_DATA_SOURCE_METRICS" | "PER_DATA_SOURCE_METRICS" | (string & {});
export type OperationLevelMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export interface EnhancedMetricsConfig {
    resolverLevelMetricsBehavior: ResolverLevelMetricsBehavior;
    dataSourceLevelMetricsBehavior: DataSourceLevelMetricsBehavior;
    operationLevelMetricsConfig: OperationLevelMetricsConfig;
}
export interface CreateGraphqlApiRequest {
    name: string;
    logConfig?: LogConfig | undefined;
    authenticationType: AuthenticationType;
    userPoolConfig?: UserPoolConfig | undefined;
    openIDConnectConfig?: OpenIDConnectConfig | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    additionalAuthenticationProviders?: AdditionalAuthenticationProvider[] | undefined;
    xrayEnabled?: boolean | undefined;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig | undefined;
    apiType?: GraphQLApiType | undefined;
    mergedApiExecutionRoleArn?: string | undefined;
    visibility?: GraphQLApiVisibility | undefined;
    ownerContact?: string | undefined;
    introspectionConfig?: GraphQLApiIntrospectionConfig | undefined;
    queryDepthLimit?: number | undefined;
    resolverCountLimit?: number | undefined;
    enhancedMetricsConfig?: EnhancedMetricsConfig | undefined;
}
export interface GraphqlApi {
    name?: string | undefined;
    apiId?: string | undefined;
    authenticationType?: AuthenticationType | undefined;
    logConfig?: LogConfig | undefined;
    userPoolConfig?: UserPoolConfig | undefined;
    openIDConnectConfig?: OpenIDConnectConfig | undefined;
    arn?: string | undefined;
    uris?: {
        [key: string]: string | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    additionalAuthenticationProviders?: AdditionalAuthenticationProvider[] | undefined;
    xrayEnabled?: boolean | undefined;
    wafWebAclArn?: string | undefined;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig | undefined;
    dns?: {
        [key: string]: string | undefined;
    } | undefined;
    visibility?: GraphQLApiVisibility | undefined;
    apiType?: GraphQLApiType | undefined;
    mergedApiExecutionRoleArn?: string | undefined;
    owner?: string | undefined;
    ownerContact?: string | undefined;
    introspectionConfig?: GraphQLApiIntrospectionConfig | undefined;
    queryDepthLimit?: number | undefined;
    resolverCountLimit?: number | undefined;
    enhancedMetricsConfig?: EnhancedMetricsConfig | undefined;
}
export interface CreateGraphqlApiResponse {
    graphqlApi?: GraphqlApi | undefined;
}
export type ResolverKind = "UNIT" | "PIPELINE" | (string & {});
export type FunctionsIds = string[];
export interface PipelineConfig {
    functions?: string[] | undefined;
}
export type CachingKeys = string[];
export interface CachingConfig {
    ttl: number;
    cachingKeys?: string[] | undefined;
}
export type ResolverLevelMetricsConfig = "ENABLED" | "DISABLED" | (string & {});
export interface CreateResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
    dataSourceName?: string | undefined;
    requestMappingTemplate?: string | undefined;
    responseMappingTemplate?: string | undefined;
    kind?: ResolverKind | undefined;
    pipelineConfig?: PipelineConfig | undefined;
    syncConfig?: SyncConfig | undefined;
    cachingConfig?: CachingConfig | undefined;
    maxBatchSize?: number | undefined;
    runtime?: AppSyncRuntime | undefined;
    code?: string | undefined;
    metricsConfig?: ResolverLevelMetricsConfig | undefined;
}
export interface Resolver {
    typeName?: string | undefined;
    fieldName?: string | undefined;
    dataSourceName?: string | undefined;
    resolverArn?: string | undefined;
    requestMappingTemplate?: string | undefined;
    responseMappingTemplate?: string | undefined;
    kind?: ResolverKind | undefined;
    pipelineConfig?: PipelineConfig | undefined;
    syncConfig?: SyncConfig | undefined;
    cachingConfig?: CachingConfig | undefined;
    maxBatchSize?: number | undefined;
    runtime?: AppSyncRuntime | undefined;
    code?: string | undefined;
    metricsConfig?: ResolverLevelMetricsConfig | undefined;
}
export interface CreateResolverResponse {
    resolver?: Resolver | undefined;
}
export type TypeDefinitionFormat = "SDL" | "JSON" | (string & {});
export interface CreateTypeRequest {
    apiId: string;
    definition: string;
    format: TypeDefinitionFormat;
}
export interface Type {
    name?: string | undefined;
    description?: string | undefined;
    arn?: string | undefined;
    definition?: string | undefined;
    format?: TypeDefinitionFormat | undefined;
}
export interface CreateTypeResponse {
    type?: Type | undefined;
}
export interface DeleteApiRequest {
    apiId: string;
}
export interface DeleteApiResponse {
}
export interface DeleteApiCacheRequest {
    apiId: string;
}
export interface DeleteApiCacheResponse {
}
export interface DeleteApiKeyRequest {
    apiId: string;
    id: string;
}
export interface DeleteApiKeyResponse {
}
export interface DeleteChannelNamespaceRequest {
    apiId: string;
    name: string;
}
export interface DeleteChannelNamespaceResponse {
}
export interface DeleteDataSourceRequest {
    apiId: string;
    name: string;
}
export interface DeleteDataSourceResponse {
}
export interface DeleteDomainNameRequest {
    domainName: string;
}
export interface DeleteDomainNameResponse {
}
export interface DeleteFunctionRequest {
    apiId: string;
    functionId: string;
}
export interface DeleteFunctionResponse {
}
export interface DeleteGraphqlApiRequest {
    apiId: string;
}
export interface DeleteGraphqlApiResponse {
}
export interface DeleteResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
}
export interface DeleteResolverResponse {
}
export interface DeleteTypeRequest {
    apiId: string;
    typeName: string;
}
export interface DeleteTypeResponse {
}
export interface DisassociateApiRequest {
    domainName: string;
}
export interface DisassociateApiResponse {
}
export interface DisassociateMergedGraphqlApiRequest {
    sourceApiIdentifier: string;
    associationId: string;
}
export interface DisassociateMergedGraphqlApiResponse {
    sourceApiAssociationStatus?: SourceApiAssociationStatus | undefined;
}
export interface DisassociateSourceGraphqlApiRequest {
    mergedApiIdentifier: string;
    associationId: string;
}
export interface DisassociateSourceGraphqlApiResponse {
    sourceApiAssociationStatus?: SourceApiAssociationStatus | undefined;
}
export type Context = string;
export interface EvaluateCodeRequest {
    runtime: AppSyncRuntime;
    code: string;
    context: string;
    function?: string | undefined;
}
export type EvaluationResult = string;
export type ErrorMessage = string;
export type CodeErrorLine = number;
export type CodeErrorColumn = number;
export type CodeErrorSpan = number;
export interface CodeErrorLocation {
    line?: number | undefined;
    column?: number | undefined;
    span?: number | undefined;
}
export interface CodeError {
    errorType?: string | undefined;
    value?: string | undefined;
    location?: CodeErrorLocation | undefined;
}
export type CodeErrors = CodeError[];
export interface EvaluateCodeErrorDetail {
    message?: string | undefined;
    codeErrors?: CodeError[] | undefined;
}
export type Logs = string[];
export type Stash = string;
export type OutErrors = string;
export interface EvaluateCodeResponse {
    evaluationResult?: string | undefined;
    error?: EvaluateCodeErrorDetail | undefined;
    logs?: string[] | undefined;
    stash?: string | undefined;
    outErrors?: string | undefined;
}
export type Template = string;
export interface EvaluateMappingTemplateRequest {
    template: string;
    context: string;
}
export interface ErrorDetail {
    message?: string | undefined;
}
export interface EvaluateMappingTemplateResponse {
    evaluationResult?: string | undefined;
    error?: ErrorDetail | undefined;
    logs?: string[] | undefined;
    stash?: string | undefined;
    outErrors?: string | undefined;
}
export interface FlushApiCacheRequest {
    apiId: string;
}
export interface FlushApiCacheResponse {
}
export interface GetApiRequest {
    apiId: string;
}
export interface GetApiResponse {
    api?: Api | undefined;
}
export interface GetApiAssociationRequest {
    domainName: string;
}
export interface GetApiAssociationResponse {
    apiAssociation?: ApiAssociation | undefined;
}
export interface GetApiCacheRequest {
    apiId: string;
}
export interface GetApiCacheResponse {
    apiCache?: ApiCache | undefined;
}
export interface GetChannelNamespaceRequest {
    apiId: string;
    name: string;
}
export interface GetChannelNamespaceResponse {
    channelNamespace?: ChannelNamespace | undefined;
}
export interface GetDataSourceRequest {
    apiId: string;
    name: string;
}
export interface GetDataSourceResponse {
    dataSource?: DataSource | undefined;
}
export type PaginationToken = string;
export type MaxResults = number;
export interface GetDataSourceIntrospectionRequest {
    introspectionId: string;
    includeModelsSDL?: boolean | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type DataSourceIntrospectionStatus = "PROCESSING" | "FAILED" | "SUCCESS" | (string & {});
export type DataSourceIntrospectionModelFieldTypeValues = string[];
export interface DataSourceIntrospectionModelFieldType {
    kind?: string | undefined;
    name?: string | undefined;
    type?: DataSourceIntrospectionModelFieldType | undefined;
    values?: string[] | undefined;
}
export interface DataSourceIntrospectionModelField {
    name?: string | undefined;
    type?: DataSourceIntrospectionModelFieldType | undefined;
    length?: number | undefined;
}
export type DataSourceIntrospectionModelFields = DataSourceIntrospectionModelField[];
export type DataSourceIntrospectionModelIndexFields = string[];
export interface DataSourceIntrospectionModelIndex {
    name?: string | undefined;
    fields?: string[] | undefined;
}
export type DataSourceIntrospectionModelIndexes = DataSourceIntrospectionModelIndex[];
export interface DataSourceIntrospectionModel {
    name?: string | undefined;
    fields?: DataSourceIntrospectionModelField[] | undefined;
    primaryKey?: DataSourceIntrospectionModelIndex | undefined;
    indexes?: DataSourceIntrospectionModelIndex[] | undefined;
    sdl?: string | undefined;
}
export type DataSourceIntrospectionModels = DataSourceIntrospectionModel[];
export interface DataSourceIntrospectionResult {
    models?: DataSourceIntrospectionModel[] | undefined;
    nextToken?: string | undefined;
}
export interface GetDataSourceIntrospectionResponse {
    introspectionId?: string | undefined;
    introspectionStatus?: DataSourceIntrospectionStatus | undefined;
    introspectionStatusDetail?: string | undefined;
    introspectionResult?: DataSourceIntrospectionResult | undefined;
}
export interface GetDomainNameRequest {
    domainName: string;
}
export interface GetDomainNameResponse {
    domainNameConfig?: DomainNameConfig | undefined;
}
export interface GetFunctionRequest {
    apiId: string;
    functionId: string;
}
export interface GetFunctionResponse {
    functionConfiguration?: FunctionConfiguration | undefined;
}
export interface GetGraphqlApiRequest {
    apiId: string;
}
export interface GetGraphqlApiResponse {
    graphqlApi?: GraphqlApi | undefined;
}
export interface GetGraphqlApiEnvironmentVariablesRequest {
    apiId: string;
}
export type EnvironmentVariableKey = string;
export type EnvironmentVariableValue = string;
export type EnvironmentVariableMap = {
    [key: string]: string | undefined;
};
export interface GetGraphqlApiEnvironmentVariablesResponse {
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type OutputType = "SDL" | "JSON" | (string & {});
export interface GetIntrospectionSchemaRequest {
    apiId: string;
    format: OutputType;
    includeDirectives?: boolean | undefined;
}
export interface GetIntrospectionSchemaResponse {
    schema?: T.StreamingOutputBody | undefined;
}
export interface GetResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
}
export interface GetResolverResponse {
    resolver?: Resolver | undefined;
}
export interface GetSchemaCreationStatusRequest {
    apiId: string;
}
export type SchemaStatus = "PROCESSING" | "ACTIVE" | "DELETING" | "FAILED" | "SUCCESS" | "NOT_APPLICABLE" | (string & {});
export interface GetSchemaCreationStatusResponse {
    status?: SchemaStatus | undefined;
    details?: string | undefined;
}
export interface GetSourceApiAssociationRequest {
    mergedApiIdentifier: string;
    associationId: string;
}
export interface GetSourceApiAssociationResponse {
    sourceApiAssociation?: SourceApiAssociation | undefined;
}
export interface GetTypeRequest {
    apiId: string;
    typeName: string;
    format: TypeDefinitionFormat;
}
export interface GetTypeResponse {
    type?: Type | undefined;
}
export interface ListApiKeysRequest {
    apiId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ApiKeys = ApiKey[];
export interface ListApiKeysResponse {
    apiKeys?: ApiKey[] | undefined;
    nextToken?: string | undefined;
}
export interface ListApisRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Apis = Api[];
export interface ListApisResponse {
    apis?: Api[] | undefined;
    nextToken?: string | undefined;
}
export interface ListChannelNamespacesRequest {
    apiId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type ChannelNamespaces = ChannelNamespace[];
export interface ListChannelNamespacesResponse {
    channelNamespaces?: ChannelNamespace[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDataSourcesRequest {
    apiId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type DataSources = DataSource[];
export interface ListDataSourcesResponse {
    dataSources?: DataSource[] | undefined;
    nextToken?: string | undefined;
}
export interface ListDomainNamesRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type DomainNameConfigs = DomainNameConfig[];
export interface ListDomainNamesResponse {
    domainNameConfigs?: DomainNameConfig[] | undefined;
    nextToken?: string | undefined;
}
export interface ListFunctionsRequest {
    apiId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Functions = FunctionConfiguration[];
export interface ListFunctionsResponse {
    functions?: FunctionConfiguration[] | undefined;
    nextToken?: string | undefined;
}
export type Ownership = "CURRENT_ACCOUNT" | "OTHER_ACCOUNTS" | (string & {});
export interface ListGraphqlApisRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    apiType?: GraphQLApiType | undefined;
    owner?: Ownership | undefined;
}
export type GraphqlApis = GraphqlApi[];
export interface ListGraphqlApisResponse {
    graphqlApis?: GraphqlApi[] | undefined;
    nextToken?: string | undefined;
}
export interface ListResolversRequest {
    apiId: string;
    typeName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type Resolvers = Resolver[];
export interface ListResolversResponse {
    resolvers?: Resolver[] | undefined;
    nextToken?: string | undefined;
}
export interface ListResolversByFunctionRequest {
    apiId: string;
    functionId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListResolversByFunctionResponse {
    resolvers?: Resolver[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSourceApiAssociationsRequest {
    apiId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface SourceApiAssociationSummary {
    associationId?: string | undefined;
    associationArn?: string | undefined;
    sourceApiId?: string | undefined;
    sourceApiArn?: string | undefined;
    mergedApiId?: string | undefined;
    mergedApiArn?: string | undefined;
    description?: string | undefined;
}
export type SourceApiAssociationSummaryList = SourceApiAssociationSummary[];
export interface ListSourceApiAssociationsResponse {
    sourceApiAssociationSummaries?: SourceApiAssociationSummary[] | undefined;
    nextToken?: string | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListTypesRequest {
    apiId: string;
    format: TypeDefinitionFormat;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type TypeList = Type[];
export interface ListTypesResponse {
    types?: Type[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTypesByAssociationRequest {
    mergedApiIdentifier: string;
    associationId: string;
    format: TypeDefinitionFormat;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListTypesByAssociationResponse {
    types?: Type[] | undefined;
    nextToken?: string | undefined;
}
export interface PutGraphqlApiEnvironmentVariablesRequest {
    apiId: string;
    environmentVariables: {
        [key: string]: string | undefined;
    };
}
export interface PutGraphqlApiEnvironmentVariablesResponse {
    environmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RdsDataApiConfigResourceArn = string;
export type RdsDataApiConfigSecretArn = string;
export type RdsDataApiConfigDatabaseName = string;
export interface RdsDataApiConfig {
    resourceArn: string;
    secretArn: string;
    databaseName: string;
}
export interface StartDataSourceIntrospectionRequest {
    rdsDataApiConfig?: RdsDataApiConfig | undefined;
}
export interface StartDataSourceIntrospectionResponse {
    introspectionId?: string | undefined;
    introspectionStatus?: DataSourceIntrospectionStatus | undefined;
    introspectionStatusDetail?: string | undefined;
}
export interface StartSchemaCreationRequest {
    apiId: string;
    definition: Uint8Array;
}
export interface StartSchemaCreationResponse {
    status?: SchemaStatus | undefined;
}
export interface StartSchemaMergeRequest {
    associationId: string;
    mergedApiIdentifier: string;
}
export interface StartSchemaMergeResponse {
    sourceApiAssociationStatus?: SourceApiAssociationStatus | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateApiRequest {
    apiId: string;
    name: string;
    ownerContact?: string | undefined;
    eventConfig: EventConfig;
}
export interface UpdateApiResponse {
    api?: Api | undefined;
}
export interface UpdateApiCacheRequest {
    apiId: string;
    ttl: number;
    apiCachingBehavior: ApiCachingBehavior;
    type: ApiCacheType;
    healthMetricsConfig?: CacheHealthMetricsConfig | undefined;
}
export interface UpdateApiCacheResponse {
    apiCache?: ApiCache | undefined;
}
export interface UpdateApiKeyRequest {
    apiId: string;
    id: string;
    description?: string | undefined;
    expires?: number | undefined;
}
export interface UpdateApiKeyResponse {
    apiKey?: ApiKey | undefined;
}
export interface UpdateChannelNamespaceRequest {
    apiId: string;
    name: string;
    subscribeAuthModes?: AuthMode[] | undefined;
    publishAuthModes?: AuthMode[] | undefined;
    codeHandlers?: string | undefined;
    handlerConfigs?: HandlerConfigs | undefined;
}
export interface UpdateChannelNamespaceResponse {
    channelNamespace?: ChannelNamespace | undefined;
}
export interface UpdateDataSourceRequest {
    apiId: string;
    name: string;
    description?: string | undefined;
    type: DataSourceType;
    serviceRoleArn?: string | undefined;
    dynamodbConfig?: DynamodbDataSourceConfig | undefined;
    lambdaConfig?: LambdaDataSourceConfig | undefined;
    elasticsearchConfig?: ElasticsearchDataSourceConfig | undefined;
    openSearchServiceConfig?: OpenSearchServiceDataSourceConfig | undefined;
    httpConfig?: HttpDataSourceConfig | undefined;
    relationalDatabaseConfig?: RelationalDatabaseDataSourceConfig | undefined;
    eventBridgeConfig?: EventBridgeDataSourceConfig | undefined;
    metricsConfig?: DataSourceLevelMetricsConfig | undefined;
}
export interface UpdateDataSourceResponse {
    dataSource?: DataSource | undefined;
}
export interface UpdateDomainNameRequest {
    domainName: string;
    description?: string | undefined;
}
export interface UpdateDomainNameResponse {
    domainNameConfig?: DomainNameConfig | undefined;
}
export interface UpdateFunctionRequest {
    apiId: string;
    name: string;
    description?: string | undefined;
    functionId: string;
    dataSourceName: string;
    requestMappingTemplate?: string | undefined;
    responseMappingTemplate?: string | undefined;
    functionVersion?: string | undefined;
    syncConfig?: SyncConfig | undefined;
    maxBatchSize?: number | undefined;
    runtime?: AppSyncRuntime | undefined;
    code?: string | undefined;
}
export interface UpdateFunctionResponse {
    functionConfiguration?: FunctionConfiguration | undefined;
}
export interface UpdateGraphqlApiRequest {
    apiId: string;
    name: string;
    logConfig?: LogConfig | undefined;
    authenticationType: AuthenticationType;
    userPoolConfig?: UserPoolConfig | undefined;
    openIDConnectConfig?: OpenIDConnectConfig | undefined;
    additionalAuthenticationProviders?: AdditionalAuthenticationProvider[] | undefined;
    xrayEnabled?: boolean | undefined;
    lambdaAuthorizerConfig?: LambdaAuthorizerConfig | undefined;
    mergedApiExecutionRoleArn?: string | undefined;
    ownerContact?: string | undefined;
    introspectionConfig?: GraphQLApiIntrospectionConfig | undefined;
    queryDepthLimit?: number | undefined;
    resolverCountLimit?: number | undefined;
    enhancedMetricsConfig?: EnhancedMetricsConfig | undefined;
}
export interface UpdateGraphqlApiResponse {
    graphqlApi?: GraphqlApi | undefined;
}
export interface UpdateResolverRequest {
    apiId: string;
    typeName: string;
    fieldName: string;
    dataSourceName?: string | undefined;
    requestMappingTemplate?: string | undefined;
    responseMappingTemplate?: string | undefined;
    kind?: ResolverKind | undefined;
    pipelineConfig?: PipelineConfig | undefined;
    syncConfig?: SyncConfig | undefined;
    cachingConfig?: CachingConfig | undefined;
    maxBatchSize?: number | undefined;
    runtime?: AppSyncRuntime | undefined;
    code?: string | undefined;
    metricsConfig?: ResolverLevelMetricsConfig | undefined;
}
export interface UpdateResolverResponse {
    resolver?: Resolver | undefined;
}
export interface UpdateSourceApiAssociationRequest {
    associationId: string;
    mergedApiIdentifier: string;
    description?: string | undefined;
    sourceApiAssociationConfig?: SourceApiAssociationConfig | undefined;
}
export interface UpdateSourceApiAssociationResponse {
    sourceApiAssociation?: SourceApiAssociation | undefined;
}
export interface UpdateTypeRequest {
    apiId: string;
    typeName: string;
    definition?: string | undefined;
    format: TypeDefinitionFormat;
}
export interface UpdateTypeResponse {
    type?: Type | undefined;
}
export type BadRequestReason = "CODE_ERROR" | (string & {});
export interface BadRequestDetail {
    codeErrors?: CodeError[] | undefined;
}
export type AssociateApiError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Maps an endpoint to your custom domain.
 */
export declare const associateApi: API.OperationMethod<AssociateApiRequest & RegionInput, AssociateApiResponse, AssociateApiError, Credentials | HttpClient.HttpClient>;
export type AssociateMergedGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates an association between a Merged API and source API using the source API's
 * identifier.
 */
export declare const associateMergedGraphqlApi: API.OperationMethod<AssociateMergedGraphqlApiRequest & RegionInput, AssociateMergedGraphqlApiResponse, AssociateMergedGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type AssociateSourceGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates an association between a Merged API and source API using the Merged API's
 * identifier.
 */
export declare const associateSourceGraphqlApi: API.OperationMethod<AssociateSourceGraphqlApiRequest & RegionInput, AssociateSourceGraphqlApiResponse, AssociateSourceGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | ServiceQuotaExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates an `Api` object. Use this operation to create an AppSync
 * API with your preferred configuration, such as an Event API that provides real-time message
 * publishing and message subscriptions over WebSockets.
 */
export declare const createApi: API.OperationMethod<CreateApiRequest & RegionInput, CreateApiResponse, CreateApiError, Credentials | HttpClient.HttpClient>;
export type CreateApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a cache for the GraphQL API.
 */
export declare const createApiCache: API.OperationMethod<CreateApiCacheRequest & RegionInput, CreateApiCacheResponse, CreateApiCacheError, Credentials | HttpClient.HttpClient>;
export type CreateApiKeyError = ApiKeyLimitExceededException | ApiKeyValidityOutOfBoundsException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a unique key that you can distribute to clients who invoke your API.
 */
export declare const createApiKey: API.OperationMethod<CreateApiKeyRequest & RegionInput, CreateApiKeyResponse, CreateApiKeyError, Credentials | HttpClient.HttpClient>;
export type CreateChannelNamespaceError = BadRequestException | ConcurrentModificationException | ConflictException | InternalFailureException | NotFoundException | ServiceQuotaExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates a `ChannelNamespace` for an `Api`.
 */
export declare const createChannelNamespace: API.OperationMethod<CreateChannelNamespaceRequest & RegionInput, CreateChannelNamespaceResponse, CreateChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `DataSource` object.
 */
export declare const createDataSource: API.OperationMethod<CreateDataSourceRequest & RegionInput, CreateDataSourceResponse, CreateDataSourceError, Credentials | HttpClient.HttpClient>;
export type CreateDomainNameError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Creates a custom `DomainName` object.
 */
export declare const createDomainName: API.OperationMethod<CreateDomainNameRequest & RegionInput, CreateDomainNameResponse, CreateDomainNameError, Credentials | HttpClient.HttpClient>;
export type CreateFunctionError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `Function` object.
 *
 * A function is a reusable entity. You can use multiple functions to compose the resolver
 * logic.
 */
export declare const createFunction: API.OperationMethod<CreateFunctionRequest & RegionInput, CreateFunctionResponse, CreateFunctionError, Credentials | HttpClient.HttpClient>;
export type CreateGraphqlApiError = ApiLimitExceededException | BadRequestException | ConcurrentModificationException | InternalFailureException | LimitExceededException | UnauthorizedException | CommonErrors;
/**
 * Creates a `GraphqlApi` object.
 */
export declare const createGraphqlApi: API.OperationMethod<CreateGraphqlApiRequest & RegionInput, CreateGraphqlApiResponse, CreateGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type CreateResolverError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `Resolver` object.
 *
 * A resolver converts incoming requests into a format that a data source can understand,
 * and converts the data source's responses into GraphQL.
 */
export declare const createResolver: API.OperationMethod<CreateResolverRequest & RegionInput, CreateResolverResponse, CreateResolverError, Credentials | HttpClient.HttpClient>;
export type CreateTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a `Type` object.
 */
export declare const createType: API.OperationMethod<CreateTypeRequest & RegionInput, CreateTypeResponse, CreateTypeError, Credentials | HttpClient.HttpClient>;
export type DeleteApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an `Api` object
 */
export declare const deleteApi: API.OperationMethod<DeleteApiRequest & RegionInput, DeleteApiResponse, DeleteApiError, Credentials | HttpClient.HttpClient>;
export type DeleteApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an `ApiCache` object.
 */
export declare const deleteApiCache: API.OperationMethod<DeleteApiCacheRequest & RegionInput, DeleteApiCacheResponse, DeleteApiCacheError, Credentials | HttpClient.HttpClient>;
export type DeleteApiKeyError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an API key.
 */
export declare const deleteApiKey: API.OperationMethod<DeleteApiKeyRequest & RegionInput, DeleteApiKeyResponse, DeleteApiKeyError, Credentials | HttpClient.HttpClient>;
export type DeleteChannelNamespaceError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `ChannelNamespace`.
 */
export declare const deleteChannelNamespace: API.OperationMethod<DeleteChannelNamespaceRequest & RegionInput, DeleteChannelNamespaceResponse, DeleteChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `DataSource` object.
 */
export declare const deleteDataSource: API.OperationMethod<DeleteDataSourceRequest & RegionInput, DeleteDataSourceResponse, DeleteDataSourceError, Credentials | HttpClient.HttpClient>;
export type DeleteDomainNameError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Deletes a custom `DomainName` object.
 */
export declare const deleteDomainName: API.OperationMethod<DeleteDomainNameRequest & RegionInput, DeleteDomainNameResponse, DeleteDomainNameError, Credentials | HttpClient.HttpClient>;
export type DeleteFunctionError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `Function`.
 */
export declare const deleteFunction: API.OperationMethod<DeleteFunctionRequest & RegionInput, DeleteFunctionResponse, DeleteFunctionError, Credentials | HttpClient.HttpClient>;
export type DeleteGraphqlApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `GraphqlApi` object.
 */
export declare const deleteGraphqlApi: API.OperationMethod<DeleteGraphqlApiRequest & RegionInput, DeleteGraphqlApiResponse, DeleteGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type DeleteResolverError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `Resolver` object.
 */
export declare const deleteResolver: API.OperationMethod<DeleteResolverRequest & RegionInput, DeleteResolverResponse, DeleteResolverError, Credentials | HttpClient.HttpClient>;
export type DeleteTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes a `Type` object.
 */
export declare const deleteType: API.OperationMethod<DeleteTypeRequest & RegionInput, DeleteTypeResponse, DeleteTypeError, Credentials | HttpClient.HttpClient>;
export type DisassociateApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Removes an `ApiAssociation` object from a custom domain.
 */
export declare const disassociateApi: API.OperationMethod<DisassociateApiRequest & RegionInput, DisassociateApiResponse, DisassociateApiError, Credentials | HttpClient.HttpClient>;
export type DisassociateMergedGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an association between a Merged API and source API using the source API's
 * identifier and the association ID.
 */
export declare const disassociateMergedGraphqlApi: API.OperationMethod<DisassociateMergedGraphqlApiRequest & RegionInput, DisassociateMergedGraphqlApiResponse, DisassociateMergedGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type DisassociateSourceGraphqlApiError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Deletes an association between a Merged API and source API using the Merged API's
 * identifier and the association ID.
 */
export declare const disassociateSourceGraphqlApi: API.OperationMethod<DisassociateSourceGraphqlApiRequest & RegionInput, DisassociateSourceGraphqlApiResponse, DisassociateSourceGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type EvaluateCodeError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Evaluates the given code and returns the response. The code definition requirements
 * depend on the specified runtime. For `APPSYNC_JS` runtimes, the code defines the
 * request and response functions. The request function takes the incoming request after a
 * GraphQL operation is parsed and converts it into a request configuration for the selected
 * data source operation. The response function interprets responses from the data source and
 * maps it to the shape of the GraphQL field output type.
 */
export declare const evaluateCode: API.OperationMethod<EvaluateCodeRequest & RegionInput, EvaluateCodeResponse, EvaluateCodeError, Credentials | HttpClient.HttpClient>;
export type EvaluateMappingTemplateError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Evaluates a given template and returns the response. The mapping template can be a
 * request or response template.
 *
 * Request templates take the incoming request after a GraphQL operation is parsed and
 * convert it into a request configuration for the selected data source operation. Response
 * templates interpret responses from the data source and map it to the shape of the GraphQL
 * field output type.
 *
 * Mapping templates are written in the Apache Velocity Template Language (VTL).
 */
export declare const evaluateMappingTemplate: API.OperationMethod<EvaluateMappingTemplateRequest & RegionInput, EvaluateMappingTemplateResponse, EvaluateMappingTemplateError, Credentials | HttpClient.HttpClient>;
export type FlushApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Flushes an `ApiCache` object.
 */
export declare const flushApiCache: API.OperationMethod<FlushApiCacheRequest & RegionInput, FlushApiCacheResponse, FlushApiCacheError, Credentials | HttpClient.HttpClient>;
export type GetApiError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves an `Api` object.
 */
export declare const getApi: API.OperationMethod<GetApiRequest & RegionInput, GetApiResponse, GetApiError, Credentials | HttpClient.HttpClient>;
export type GetApiAssociationError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Retrieves an `ApiAssociation` object.
 */
export declare const getApiAssociation: API.OperationMethod<GetApiAssociationRequest & RegionInput, GetApiAssociationResponse, GetApiAssociationError, Credentials | HttpClient.HttpClient>;
export type GetApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves an `ApiCache` object.
 */
export declare const getApiCache: API.OperationMethod<GetApiCacheRequest & RegionInput, GetApiCacheResponse, GetApiCacheError, Credentials | HttpClient.HttpClient>;
export type GetChannelNamespaceError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the channel namespace for a specified `Api`.
 */
export declare const getChannelNamespace: API.OperationMethod<GetChannelNamespaceRequest & RegionInput, GetChannelNamespaceResponse, GetChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `DataSource` object.
 */
export declare const getDataSource: API.OperationMethod<GetDataSourceRequest & RegionInput, GetDataSourceResponse, GetDataSourceError, Credentials | HttpClient.HttpClient>;
export type GetDataSourceIntrospectionError = BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Retrieves the record of an existing introspection. If the retrieval is successful, the
 * result of the instrospection will also be returned. If the retrieval fails the operation,
 * an error message will be returned instead.
 */
export declare const getDataSourceIntrospection: API.OperationMethod<GetDataSourceIntrospectionRequest & RegionInput, GetDataSourceIntrospectionResponse, GetDataSourceIntrospectionError, Credentials | HttpClient.HttpClient>;
export type GetDomainNameError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Retrieves a custom `DomainName` object.
 */
export declare const getDomainName: API.OperationMethod<GetDomainNameRequest & RegionInput, GetDomainNameResponse, GetDomainNameError, Credentials | HttpClient.HttpClient>;
export type GetFunctionError = ConcurrentModificationException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Get a `Function`.
 */
export declare const getFunction: API.OperationMethod<GetFunctionRequest & RegionInput, GetFunctionResponse, GetFunctionError, Credentials | HttpClient.HttpClient>;
export type GetGraphqlApiError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `GraphqlApi` object.
 */
export declare const getGraphqlApi: API.OperationMethod<GetGraphqlApiRequest & RegionInput, GetGraphqlApiResponse, GetGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type GetGraphqlApiEnvironmentVariablesError = AccessDeniedException | BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the list of environmental variable key-value pairs associated with an API by
 * its ID value.
 */
export declare const getGraphqlApiEnvironmentVariables: API.OperationMethod<GetGraphqlApiEnvironmentVariablesRequest & RegionInput, GetGraphqlApiEnvironmentVariablesResponse, GetGraphqlApiEnvironmentVariablesError, Credentials | HttpClient.HttpClient>;
export type GetIntrospectionSchemaError = GraphQLSchemaException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the introspection schema for a GraphQL API.
 */
export declare const getIntrospectionSchema: API.OperationMethod<GetIntrospectionSchemaRequest & RegionInput, GetIntrospectionSchemaResponse, GetIntrospectionSchemaError, Credentials | HttpClient.HttpClient>;
export type GetResolverError = ConcurrentModificationException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `Resolver` object.
 */
export declare const getResolver: API.OperationMethod<GetResolverRequest & RegionInput, GetResolverResponse, GetResolverError, Credentials | HttpClient.HttpClient>;
export type GetSchemaCreationStatusError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves the current status of a schema creation operation.
 */
export declare const getSchemaCreationStatus: API.OperationMethod<GetSchemaCreationStatusRequest & RegionInput, GetSchemaCreationStatusResponse, GetSchemaCreationStatusError, Credentials | HttpClient.HttpClient>;
export type GetSourceApiAssociationError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `SourceApiAssociation` object.
 */
export declare const getSourceApiAssociation: API.OperationMethod<GetSourceApiAssociationRequest & RegionInput, GetSourceApiAssociationResponse, GetSourceApiAssociationError, Credentials | HttpClient.HttpClient>;
export type GetTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Retrieves a `Type` object.
 */
export declare const getType: API.OperationMethod<GetTypeRequest & RegionInput, GetTypeResponse, GetTypeError, Credentials | HttpClient.HttpClient>;
export type ListApiKeysError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the API keys for a given API.
 *
 * API keys are deleted automatically 60 days after they expire. However, they may still
 * be included in the response until they have actually been deleted. You can safely call
 * `DeleteApiKey` to manually delete a key before it's automatically
 * deleted.
 */
export declare const listApiKeys: API.PaginatedOperationMethod<ListApiKeysRequest & RegionInput, ListApiKeysResponse, ListApiKeysError, Credentials | HttpClient.HttpClient, ApiKey>;
export type ListApisError = BadRequestException | InternalFailureException | UnauthorizedException | CommonErrors;
/**
 * Lists the APIs in your AppSync account.
 *
 * `ListApis` returns only the high level API details. For more detailed
 * information about an API, use `GetApi`.
 */
export declare const listApis: API.PaginatedOperationMethod<ListApisRequest & RegionInput, ListApisResponse, ListApisError, Credentials | HttpClient.HttpClient, Api>;
export type ListChannelNamespacesError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the channel namespaces for a specified `Api`.
 *
 * `ListChannelNamespaces` returns only high level details for the channel
 * namespace. To retrieve code handlers, use `GetChannelNamespace`.
 */
export declare const listChannelNamespaces: API.PaginatedOperationMethod<ListChannelNamespacesRequest & RegionInput, ListChannelNamespacesResponse, ListChannelNamespacesError, Credentials | HttpClient.HttpClient, ChannelNamespace>;
export type ListDataSourcesError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the data sources for a given API.
 */
export declare const listDataSources: API.PaginatedOperationMethod<ListDataSourcesRequest & RegionInput, ListDataSourcesResponse, ListDataSourcesError, Credentials | HttpClient.HttpClient, DataSource>;
export type ListDomainNamesError = AccessDeniedException | BadRequestException | InternalFailureException | CommonErrors;
/**
 * Lists multiple custom domain names.
 */
export declare const listDomainNames: API.PaginatedOperationMethod<ListDomainNamesRequest & RegionInput, ListDomainNamesResponse, ListDomainNamesError, Credentials | HttpClient.HttpClient, DomainNameConfig>;
export type ListFunctionsError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * List multiple functions.
 */
export declare const listFunctions: API.PaginatedOperationMethod<ListFunctionsRequest & RegionInput, ListFunctionsResponse, ListFunctionsError, Credentials | HttpClient.HttpClient, FunctionConfiguration>;
export type ListGraphqlApisError = BadRequestException | InternalFailureException | UnauthorizedException | CommonErrors;
/**
 * Lists your GraphQL APIs.
 */
export declare const listGraphqlApis: API.PaginatedOperationMethod<ListGraphqlApisRequest & RegionInput, ListGraphqlApisResponse, ListGraphqlApisError, Credentials | HttpClient.HttpClient, GraphqlApi>;
export type ListResolversError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the resolvers for a given API and type.
 */
export declare const listResolvers: API.PaginatedOperationMethod<ListResolversRequest & RegionInput, ListResolversResponse, ListResolversError, Credentials | HttpClient.HttpClient, Resolver>;
export type ListResolversByFunctionError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * List the resolvers that are associated with a specific function.
 */
export declare const listResolversByFunction: API.PaginatedOperationMethod<ListResolversByFunctionRequest & RegionInput, ListResolversByFunctionResponse, ListResolversByFunctionError, Credentials | HttpClient.HttpClient, Resolver>;
export type ListSourceApiAssociationsError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the `SourceApiAssociationSummary` data.
 */
export declare const listSourceApiAssociations: API.PaginatedOperationMethod<ListSourceApiAssociationsRequest & RegionInput, ListSourceApiAssociationsResponse, ListSourceApiAssociationsError, Credentials | HttpClient.HttpClient, SourceApiAssociationSummary>;
export type ListTagsForResourceError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the tags for a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTypesError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists the types for a given API.
 */
export declare const listTypes: API.PaginatedOperationMethod<ListTypesRequest & RegionInput, ListTypesResponse, ListTypesError, Credentials | HttpClient.HttpClient, Type>;
export type ListTypesByAssociationError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Lists `Type` objects by the source API association ID.
 */
export declare const listTypesByAssociation: API.PaginatedOperationMethod<ListTypesByAssociationRequest & RegionInput, ListTypesByAssociationResponse, ListTypesByAssociationError, Credentials | HttpClient.HttpClient, Type>;
export type PutGraphqlApiEnvironmentVariablesError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a list of environmental variables in an API by its ID value.
 *
 * When creating an environmental variable, it must follow the constraints below:
 *
 * - Both JavaScript and VTL templates support environmental variables.
 *
 * - Environmental variables are not evaluated before function invocation.
 *
 * - Environmental variables only support string values.
 *
 * - Any defined value in an environmental variable is considered a string literal
 * and not expanded.
 *
 * - Variable evaluations should ideally be performed in the function
 * code.
 *
 * When creating an environmental variable key-value pair, it must follow the additional
 * constraints below:
 *
 * - Keys must begin with a letter.
 *
 * - Keys must be at least two characters long.
 *
 * - Keys can only contain letters, numbers, and the underscore character
 * (_).
 *
 * - Values can be up to 512 characters long.
 *
 * - You can configure up to 50 key-value pairs in a GraphQL API.
 *
 * You can create a list of environmental variables by adding it to the
 * `environmentVariables` payload as a list in the format
 * `{"key1":"value1","key2":"value2", ...}`. Note that each call of the
 * `PutGraphqlApiEnvironmentVariables` action will result in the overwriting of
 * the existing environmental variable list of that API. This means the existing environmental
 * variables will be lost. To avoid this, you must include all existing and new environmental
 * variables in the list each time you call this action.
 */
export declare const putGraphqlApiEnvironmentVariables: API.OperationMethod<PutGraphqlApiEnvironmentVariablesRequest & RegionInput, PutGraphqlApiEnvironmentVariablesResponse, PutGraphqlApiEnvironmentVariablesError, Credentials | HttpClient.HttpClient>;
export type StartDataSourceIntrospectionError = BadRequestException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Creates a new introspection. Returns the `introspectionId` of the new
 * introspection after its creation.
 */
export declare const startDataSourceIntrospection: API.OperationMethod<StartDataSourceIntrospectionRequest & RegionInput, StartDataSourceIntrospectionResponse, StartDataSourceIntrospectionError, Credentials | HttpClient.HttpClient>;
export type StartSchemaCreationError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Adds a new schema to your GraphQL API.
 *
 * This operation is asynchronous. Use to
 * determine when it has completed.
 */
export declare const startSchemaCreation: API.OperationMethod<StartSchemaCreationRequest & RegionInput, StartSchemaCreationResponse, StartSchemaCreationError, Credentials | HttpClient.HttpClient>;
export type StartSchemaMergeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Initiates a merge operation. Returns a status that shows the result of the merge
 * operation.
 */
export declare const startSchemaMerge: API.OperationMethod<StartSchemaMergeRequest & RegionInput, StartSchemaMergeResponse, StartSchemaMergeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Tags a resource with user-supplied tags.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Untags a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates an `Api`.
 */
export declare const updateApi: API.OperationMethod<UpdateApiRequest & RegionInput, UpdateApiResponse, UpdateApiError, Credentials | HttpClient.HttpClient>;
export type UpdateApiCacheError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates the cache for the GraphQL API.
 */
export declare const updateApiCache: API.OperationMethod<UpdateApiCacheRequest & RegionInput, UpdateApiCacheResponse, UpdateApiCacheError, Credentials | HttpClient.HttpClient>;
export type UpdateApiKeyError = ApiKeyValidityOutOfBoundsException | BadRequestException | InternalFailureException | LimitExceededException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates an API key. You can update the key as long as it's not deleted.
 */
export declare const updateApiKey: API.OperationMethod<UpdateApiKeyRequest & RegionInput, UpdateApiKeyResponse, UpdateApiKeyError, Credentials | HttpClient.HttpClient>;
export type UpdateChannelNamespaceError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `ChannelNamespace` associated with an `Api`.
 */
export declare const updateChannelNamespace: API.OperationMethod<UpdateChannelNamespaceRequest & RegionInput, UpdateChannelNamespaceResponse, UpdateChannelNamespaceError, Credentials | HttpClient.HttpClient>;
export type UpdateDataSourceError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `DataSource` object.
 */
export declare const updateDataSource: API.OperationMethod<UpdateDataSourceRequest & RegionInput, UpdateDataSourceResponse, UpdateDataSourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDomainNameError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | CommonErrors;
/**
 * Updates a custom `DomainName` object.
 */
export declare const updateDomainName: API.OperationMethod<UpdateDomainNameRequest & RegionInput, UpdateDomainNameResponse, UpdateDomainNameError, Credentials | HttpClient.HttpClient>;
export type UpdateFunctionError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `Function` object.
 */
export declare const updateFunction: API.OperationMethod<UpdateFunctionRequest & RegionInput, UpdateFunctionResponse, UpdateFunctionError, Credentials | HttpClient.HttpClient>;
export type UpdateGraphqlApiError = AccessDeniedException | BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `GraphqlApi` object.
 */
export declare const updateGraphqlApi: API.OperationMethod<UpdateGraphqlApiRequest & RegionInput, UpdateGraphqlApiResponse, UpdateGraphqlApiError, Credentials | HttpClient.HttpClient>;
export type UpdateResolverError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `Resolver` object.
 */
export declare const updateResolver: API.OperationMethod<UpdateResolverRequest & RegionInput, UpdateResolverResponse, UpdateResolverError, Credentials | HttpClient.HttpClient>;
export type UpdateSourceApiAssociationError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates some of the configuration choices of a particular source API association.
 */
export declare const updateSourceApiAssociation: API.OperationMethod<UpdateSourceApiAssociationRequest & RegionInput, UpdateSourceApiAssociationResponse, UpdateSourceApiAssociationError, Credentials | HttpClient.HttpClient>;
export type UpdateTypeError = BadRequestException | ConcurrentModificationException | InternalFailureException | NotFoundException | UnauthorizedException | CommonErrors;
/**
 * Updates a `Type` object.
 */
export declare const updateType: API.OperationMethod<UpdateTypeRequest & RegionInput, UpdateTypeResponse, UpdateTypeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=appsync.d.ts.map