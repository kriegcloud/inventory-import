export * from "@distilled.cloud/s3/Presign";
//# sourceMappingURL=presign.d.ts.map