/**
 * The rolldown bundler for Workers-style (workerd API) bundles, shared by
 * every engine that runs them (Cloudflare today). The engine supplies the
 * workerd compatibility plugins and the generated virtual entry.
 *
 * @internal
 */
import * as Effect from "effect/Effect";
import type * as FileSystem from "effect/FileSystem";
import type * as Path from "effect/Path";
import * as Stream from "effect/Stream";
import type * as rolldown from "rolldown";
import * as Bundle from "../../Bundle/Bundle.ts";
/**
 * Bundler options for a Worker: Rolldown input/output overrides and
 * {@link Bundle.BundleExtraOptions}, merged over Alchemy's defaults.
 */
export interface WorkerBuildOptions extends Bundle.BundleConfig {
    /**
     * Rolldown output options merged over Alchemy's defaults. Use this to
     * control chunking (`codeSplitting`), minification, etc.
     */
    output?: rolldown.OutputOptions;
    /**
     * Forwarded to rolldown's `preserveEntrySignatures` input option. Some
     * `output.codeSplitting` configurations require relaxing it (e.g.
     * `includeDependenciesRecursively: false` needs `"allow-extension"`).
     * Workers must keep their entry exports, so never pass `false`.
     */
    preserveEntrySignatures?: rolldown.InputOptions["preserveEntrySignatures"];
}
export interface WorkerBundleOptions {
    id: string;
    main: string;
    compatibility: {
        date: string;
        flags: string[];
    };
    /** How the entry is wrapped: kept as-is, or behind a generated virtual entry. */
    entry: {
        kind: string;
    };
    stack: {
        name: string;
        stage: string;
    };
    extraOptions: WorkerBuildOptions | undefined;
}
/** The engine half of a workerd bundler. */
export interface WorkerBundleEngine<Options extends WorkerBundleOptions, ModuleRule = never> {
    /**
     * The workerd compatibility (nodejs_compat) plugin factory, loaded lazily
     * so importing the engine never loads rolldown's native binding.
     */
    readonly loadCompatPlugins: () => Promise<(options: {
        compatibilityDate: string;
        compatibilityFlags: string[];
        moduleRules?: ModuleRule[] | undefined;
    }) => Array<rolldown.Plugin | null>>;
    /**
     * Module rules for the parent build's compatibility plugins: imports
     * emitted as modules of their own instead of being bundled, given the
     * resolved entry path. Nested `?worker` builds keep only their entry
     * chunk, so rules never apply to them.
     */
    readonly moduleRules?: (options: Options, main: string) => Effect.Effect<ModuleRule[] | undefined, never, FileSystem.FileSystem | Path.Path>;
    /** Rewrite a build failure, e.g. to point at the engine's own options. */
    readonly mapError?: (error: Bundle.BundleError) => Bundle.BundleError;
    /**
     * The generated entry wrapping the user's `main` (a function of the
     * real entry's import path), or `undefined` to bundle `main` as-is.
     */
    readonly virtualEntry: (options: Options) => ((importPath: string) => string) | undefined;
}
export declare const makeWorkerBundle: <Options extends WorkerBundleOptions, ModuleRule = never>(engine: WorkerBundleEngine<Options, ModuleRule>) => Effect.Effect<{
    build: (options: Options) => Effect.Effect<Bundle.BundleOutput, Bundle.BundleError, never>;
    watch: (options: Options) => Stream.Stream<Bundle.BundleWatchEvent.Start | Bundle.BundleWatchEvent.Success | {
        _tag: "Error";
        error: Bundle.BundleError;
    }, Bundle.BundleError, never>;
}, never, FileSystem.FileSystem | Path.Path>;
//# sourceMappingURL=Bundle.d.ts.map