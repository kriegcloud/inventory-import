import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type SavingsPlanOfferingId = string;
export type Amount = string;
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateSavingsPlanRequest {
    savingsPlanOfferingId: string;
    commitment: string;
    upfrontPaymentAmount?: string | undefined;
    purchaseTime?: Date | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type SavingsPlanId = string;
export interface CreateSavingsPlanResponse {
    savingsPlanId?: string | undefined;
}
export interface DeleteQueuedSavingsPlanRequest {
    savingsPlanId: string;
}
export interface DeleteQueuedSavingsPlanResponse {
}
export type SavingsPlanRateFilterName = "region" | "instanceType" | "productDescription" | "tenancy" | "productType" | "serviceCode" | "usageType" | "operation" | (string & {});
export type ListOfStrings = string[];
export interface SavingsPlanRateFilter {
    name?: SavingsPlanRateFilterName | undefined;
    values?: string[] | undefined;
}
export type SavingsPlanRateFilterList = SavingsPlanRateFilter[];
export type PaginationToken = string;
export type MaxResults = number;
export interface DescribeSavingsPlanRatesRequest {
    savingsPlanId: string;
    filters?: SavingsPlanRateFilter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type CurrencyCode = "CNY" | "USD" | "EUR" | (string & {});
export type SavingsPlanRateUnit = "Hrs" | "Lambda-GB-Second" | "Request" | "ACU-Hr" | "ReadRequestUnits" | "WriteRequestUnits" | "ReadCapacityUnit-Hrs" | "WriteCapacityUnit-Hrs" | "ReplicatedWriteRequestUnits" | "ReplicatedWriteCapacityUnit-Hrs" | "GB-Hours" | "DPU" | "ElastiCacheProcessingUnit" | "DCU-Hr" | "NCU-hr" | "OCU-hours" | "Jobs" | (string & {});
export type SavingsPlanProductType = "EC2" | "Fargate" | "Lambda" | "SageMaker" | "RDS" | "DSQL" | "DynamoDB" | "ElastiCache" | "DocDB" | "Neptune" | "Timestream" | "Keyspaces" | "DMS" | "OpenSearch" | (string & {});
export type SavingsPlanRateServiceCode = "AmazonEC2" | "AmazonECS" | "AmazonEKS" | "AWSLambda" | "AmazonSageMaker" | "AmazonRDS" | "AuroraDSQL" | "AmazonDynamoDB" | "AmazonElastiCache" | "AmazonDocDB" | "AmazonNeptune" | "AmazonTimestream" | "AmazonMCS" | "AWSDatabaseMigrationSvc" | "AmazonES" | (string & {});
export type SavingsPlanRateUsageType = string;
export type SavingsPlanRateOperation = string;
export type SavingsPlanRatePropertyKey = "region" | "instanceType" | "instanceFamily" | "productDescription" | "tenancy" | (string & {});
export type JsonSafeFilterValueString = string;
export interface SavingsPlanRateProperty {
    name?: SavingsPlanRatePropertyKey | undefined;
    value?: string | undefined;
}
export type SavingsPlanRatePropertyList = SavingsPlanRateProperty[];
export interface SavingsPlanRate {
    rate?: string | undefined;
    currency?: CurrencyCode | undefined;
    unit?: SavingsPlanRateUnit | undefined;
    productType?: SavingsPlanProductType | undefined;
    serviceCode?: SavingsPlanRateServiceCode | undefined;
    usageType?: string | undefined;
    operation?: string | undefined;
    properties?: SavingsPlanRateProperty[] | undefined;
}
export type SavingsPlanRateList = SavingsPlanRate[];
export interface DescribeSavingsPlanRatesResponse {
    savingsPlanId?: string | undefined;
    searchResults?: SavingsPlanRate[] | undefined;
    nextToken?: string | undefined;
}
export type SavingsPlanArn = string;
export type SavingsPlanArnList = string[];
export type SavingsPlanIdList = string[];
export type SavingsPlanState = "payment-pending" | "payment-failed" | "active" | "retired" | "queued" | "queued-deleted" | "pending-return" | "returned" | (string & {});
export type SavingsPlanStateList = SavingsPlanState[];
export type SavingsPlansFilterName = "region" | "ec2-instance-family" | "commitment" | "upfront" | "term" | "savings-plan-type" | "payment-option" | "start" | "end" | "instance-family" | (string & {});
export interface SavingsPlanFilter {
    name?: SavingsPlansFilterName | undefined;
    values?: string[] | undefined;
}
export type SavingsPlanFilterList = SavingsPlanFilter[];
export interface DescribeSavingsPlansRequest {
    savingsPlanArns?: string[] | undefined;
    savingsPlanIds?: string[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    states?: SavingsPlanState[] | undefined;
    filters?: SavingsPlanFilter[] | undefined;
}
export type Region = string;
export type EC2InstanceFamily = string;
export type SavingsPlanType = "Compute" | "EC2Instance" | "SageMaker" | "Database" | (string & {});
export type SavingsPlanPaymentOption = "All Upfront" | "Partial Upfront" | "No Upfront" | (string & {});
export type SavingsPlanProductTypeList = SavingsPlanProductType[];
export type TermDurationInSeconds = number;
export interface SavingsPlan {
    offeringId?: string | undefined;
    savingsPlanId?: string | undefined;
    savingsPlanArn?: string | undefined;
    description?: string | undefined;
    start?: string | undefined;
    end?: string | undefined;
    state?: SavingsPlanState | undefined;
    region?: string | undefined;
    ec2InstanceFamily?: string | undefined;
    savingsPlanType?: SavingsPlanType | undefined;
    paymentOption?: SavingsPlanPaymentOption | undefined;
    productTypes?: SavingsPlanProductType[] | undefined;
    currency?: CurrencyCode | undefined;
    commitment?: string | undefined;
    upfrontPaymentAmount?: string | undefined;
    recurringPaymentAmount?: string | undefined;
    termDurationInSeconds?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    returnableUntil?: string | undefined;
}
export type SavingsPlanList = SavingsPlan[];
export interface DescribeSavingsPlansResponse {
    savingsPlans?: SavingsPlan[] | undefined;
    nextToken?: string | undefined;
}
export type UUID = string;
export type UUIDs = string[];
export type SavingsPlanPaymentOptionList = SavingsPlanPaymentOption[];
export type SavingsPlanTypeList = SavingsPlanType[];
export type SavingsPlanRateServiceCodeList = SavingsPlanRateServiceCode[];
export type SavingsPlanRateUsageTypeList = string[];
export type SavingsPlanRateOperationList = string[];
export type SavingsPlanRateFilterAttribute = "region" | "instanceFamily" | "instanceType" | "productDescription" | "tenancy" | "productId" | (string & {});
export type FilterValuesList = string[];
export interface SavingsPlanOfferingRateFilterElement {
    name?: SavingsPlanRateFilterAttribute | undefined;
    values?: string[] | undefined;
}
export type SavingsPlanOfferingRateFiltersList = SavingsPlanOfferingRateFilterElement[];
export type PageSize = number;
export interface DescribeSavingsPlansOfferingRatesRequest {
    savingsPlanOfferingIds?: string[] | undefined;
    savingsPlanPaymentOptions?: SavingsPlanPaymentOption[] | undefined;
    savingsPlanTypes?: SavingsPlanType[] | undefined;
    products?: SavingsPlanProductType[] | undefined;
    serviceCodes?: SavingsPlanRateServiceCode[] | undefined;
    usageTypes?: string[] | undefined;
    operations?: string[] | undefined;
    filters?: SavingsPlanOfferingRateFilterElement[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SavingsPlansDuration = number;
export type SavingsPlanDescription = string;
export interface ParentSavingsPlanOffering {
    offeringId?: string | undefined;
    paymentOption?: SavingsPlanPaymentOption | undefined;
    planType?: SavingsPlanType | undefined;
    durationSeconds?: number | undefined;
    currency?: CurrencyCode | undefined;
    planDescription?: string | undefined;
}
export type SavingsPlanRatePricePerUnit = string;
export interface SavingsPlanOfferingRateProperty {
    name?: string | undefined;
    value?: string | undefined;
}
export type SavingsPlanOfferingRatePropertyList = SavingsPlanOfferingRateProperty[];
export interface SavingsPlanOfferingRate {
    savingsPlanOffering?: ParentSavingsPlanOffering | undefined;
    rate?: string | undefined;
    unit?: SavingsPlanRateUnit | undefined;
    productType?: SavingsPlanProductType | undefined;
    serviceCode?: SavingsPlanRateServiceCode | undefined;
    usageType?: string | undefined;
    operation?: string | undefined;
    properties?: SavingsPlanOfferingRateProperty[] | undefined;
}
export type SavingsPlanOfferingRatesList = SavingsPlanOfferingRate[];
export interface DescribeSavingsPlansOfferingRatesResponse {
    searchResults?: SavingsPlanOfferingRate[] | undefined;
    nextToken?: string | undefined;
}
export type DurationsList = number[];
export type CurrencyList = CurrencyCode[];
export type SavingsPlanDescriptionsList = string[];
export type SavingsPlanServiceCode = string;
export type SavingsPlanServiceCodeList = string[];
export type SavingsPlanUsageType = string;
export type SavingsPlanUsageTypeList = string[];
export type SavingsPlanOperation = string;
export type SavingsPlanOperationList = string[];
export type SavingsPlanOfferingFilterAttribute = "region" | "instanceFamily" | (string & {});
export interface SavingsPlanOfferingFilterElement {
    name?: SavingsPlanOfferingFilterAttribute | undefined;
    values?: string[] | undefined;
}
export type SavingsPlanOfferingFiltersList = SavingsPlanOfferingFilterElement[];
export interface DescribeSavingsPlansOfferingsRequest {
    offeringIds?: string[] | undefined;
    paymentOptions?: SavingsPlanPaymentOption[] | undefined;
    productType?: SavingsPlanProductType | undefined;
    planTypes?: SavingsPlanType[] | undefined;
    durations?: number[] | undefined;
    currencies?: CurrencyCode[] | undefined;
    descriptions?: string[] | undefined;
    serviceCodes?: string[] | undefined;
    usageTypes?: string[] | undefined;
    operations?: string[] | undefined;
    filters?: SavingsPlanOfferingFilterElement[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SavingsPlanOfferingPropertyKey = "region" | "instanceFamily" | (string & {});
export interface SavingsPlanOfferingProperty {
    name?: SavingsPlanOfferingPropertyKey | undefined;
    value?: string | undefined;
}
export type SavingsPlanOfferingPropertyList = SavingsPlanOfferingProperty[];
export interface SavingsPlanOffering {
    offeringId?: string | undefined;
    productTypes?: SavingsPlanProductType[] | undefined;
    planType?: SavingsPlanType | undefined;
    description?: string | undefined;
    paymentOption?: SavingsPlanPaymentOption | undefined;
    durationSeconds?: number | undefined;
    currency?: CurrencyCode | undefined;
    serviceCode?: string | undefined;
    usageType?: string | undefined;
    operation?: string | undefined;
    properties?: SavingsPlanOfferingProperty[] | undefined;
}
export type SavingsPlanOfferingsList = SavingsPlanOffering[];
export interface DescribeSavingsPlansOfferingsResponse {
    searchResults?: SavingsPlanOffering[] | undefined;
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ReturnSavingsPlanRequest {
    savingsPlanId: string;
    clientToken?: string | undefined;
}
export interface ReturnSavingsPlanResponse {
    savingsPlanId?: string | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export type CreateSavingsPlanError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Creates a Savings Plan.
 */
export declare const createSavingsPlan: API.OperationMethod<CreateSavingsPlanRequest & RegionInput, CreateSavingsPlanResponse, CreateSavingsPlanError, Credentials | HttpClient.HttpClient>;
export type DeleteQueuedSavingsPlanError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Deletes the queued purchase for the specified Savings Plan.
 */
export declare const deleteQueuedSavingsPlan: API.OperationMethod<DeleteQueuedSavingsPlanRequest & RegionInput, DeleteQueuedSavingsPlanResponse, DeleteQueuedSavingsPlanError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlanRatesError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the rates for a specific, existing Savings Plan.
 */
export declare const describeSavingsPlanRates: API.OperationMethod<DescribeSavingsPlanRatesRequest & RegionInput, DescribeSavingsPlanRatesResponse, DescribeSavingsPlanRatesError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlansError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the specified Savings Plans.
 */
export declare const describeSavingsPlans: API.OperationMethod<DescribeSavingsPlansRequest & RegionInput, DescribeSavingsPlansResponse, DescribeSavingsPlansError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlansOfferingRatesError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the offering rates for Savings Plans you might want to purchase.
 */
export declare const describeSavingsPlansOfferingRates: API.OperationMethod<DescribeSavingsPlansOfferingRatesRequest & RegionInput, DescribeSavingsPlansOfferingRatesResponse, DescribeSavingsPlansOfferingRatesError, Credentials | HttpClient.HttpClient>;
export type DescribeSavingsPlansOfferingsError = InternalServerException | ValidationException | CommonErrors;
/**
 * Describes the offerings for the specified Savings Plans.
 */
export declare const describeSavingsPlansOfferings: API.OperationMethod<DescribeSavingsPlansOfferingsRequest & RegionInput, DescribeSavingsPlansOfferingsResponse, DescribeSavingsPlansOfferingsError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Lists the tags for the specified resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ReturnSavingsPlanError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Returns the specified Savings Plan.
 */
export declare const returnSavingsPlan: API.OperationMethod<ReturnSavingsPlanRequest & RegionInput, ReturnSavingsPlanResponse, ReturnSavingsPlanError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ValidationException | CommonErrors;
/**
 * Adds the specified tags to the specified resource.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=savingsplans.d.ts.map