import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
    readonly ServiceCode: any;
    readonly QuotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly ServiceCode: any;
    readonly QuotaCode: any;
    readonly RetryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly Reason: any;
    readonly FieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
declare const VolumeModificationRateExceededException_base: S.TaggedErrorClass<"VolumeModificationRateExceededException", {
    readonly message: any;
    readonly ResourceId: any;
    readonly ResourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
});
export declare class VolumeModificationRateExceededException extends /*@__PURE__*/ VolumeModificationRateExceededException_base {
}
export type WorkspaceInstanceId = string;
export type VolumeId = string;
export type DeviceName = string;
export interface AssociateVolumeRequest {
    WorkspaceInstanceId: string;
    VolumeId: string;
    Device: string;
}
export interface AssociateVolumeResponse {
}
export type String64 = string;
export type ClientToken = string | redacted.Redacted<string>;
export type NonNegativeInteger = number;
export type KmsKeyId = string | redacted.Redacted<string>;
export type VolumeSizeInGB = number;
export type SnapshotId = string;
export type ResourceTypeEnum = "instance" | "volume" | "spot-instances-request" | "network-interface" | (string & {});
export type TagKey = string;
export type TagValue = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export interface TagSpecification {
    ResourceType?: ResourceTypeEnum | undefined;
    Tags?: Tag[] | undefined;
}
export type TagSpecifications = TagSpecification[];
export type VolumeTypeEnum = "standard" | "io1" | "io2" | "gp2" | "sc1" | "st1" | "gp3" | (string & {});
export interface CreateVolumeRequest {
    AvailabilityZone: string;
    ClientToken?: string | redacted.Redacted<string> | undefined;
    Encrypted?: boolean | undefined;
    Iops?: number | undefined;
    KmsKeyId?: string | redacted.Redacted<string> | undefined;
    SizeInGB?: number | undefined;
    SnapshotId?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    Throughput?: number | undefined;
    VolumeType?: VolumeTypeEnum | undefined;
}
export interface CreateVolumeResponse {
    VolumeId?: string | undefined;
}
export interface EbsBlockDevice {
    VolumeType?: VolumeTypeEnum | undefined;
    Encrypted?: boolean | undefined;
    KmsKeyId?: string | redacted.Redacted<string> | undefined;
    Iops?: number | undefined;
    Throughput?: number | undefined;
    VolumeSize?: number | undefined;
}
export type VirtualName = string;
export interface BlockDeviceMappingRequest {
    DeviceName?: string | undefined;
    Ebs?: EbsBlockDevice | undefined;
    NoDevice?: string | undefined;
    VirtualName?: string | undefined;
}
export type BlockDeviceMappings = BlockDeviceMappingRequest[];
export type CapacityReservationPreferenceEnum = "capacity-reservations-only" | "open" | "none" | (string & {});
export type String128 = string;
export type ARN = string;
export interface CapacityReservationTarget {
    CapacityReservationId?: string | undefined;
    CapacityReservationResourceGroupArn?: string | undefined;
}
export interface CapacityReservationSpecification {
    CapacityReservationPreference?: CapacityReservationPreferenceEnum | undefined;
    CapacityReservationTarget?: CapacityReservationTarget | undefined;
}
export type AmdSevSnpEnum = "enabled" | "disabled" | (string & {});
export type NestedVirtualizationEnum = "enabled" | "disabled" | (string & {});
export interface CpuOptionsRequest {
    AmdSevSnp?: AmdSevSnpEnum | undefined;
    CoreCount?: number | undefined;
    ThreadsPerCore?: number | undefined;
    NestedVirtualization?: NestedVirtualizationEnum | undefined;
}
export type CpuCreditsEnum = "standard" | "unlimited" | (string & {});
export interface CreditSpecificationRequest {
    CpuCredits?: CpuCreditsEnum | undefined;
}
export interface EnclaveOptionsRequest {
    Enabled?: boolean | undefined;
}
export interface HibernationOptionsRequest {
    Configured?: boolean | undefined;
}
export interface IamInstanceProfileSpecification {
    Arn?: string | undefined;
    Name?: string | undefined;
}
export type ImageId = string;
export type MarketTypeEnum = "spot" | "capacity-block" | (string & {});
export type InstanceInterruptionBehaviorEnum = "hibernate" | "stop" | (string & {});
export type SpotInstanceTypeEnum = "one-time" | "persistent" | (string & {});
export interface SpotMarketOptions {
    BlockDurationMinutes?: number | undefined;
    InstanceInterruptionBehavior?: InstanceInterruptionBehaviorEnum | undefined;
    MaxPrice?: string | undefined;
    SpotInstanceType?: SpotInstanceTypeEnum | undefined;
    ValidUntilUtc?: Date | undefined;
}
export interface InstanceMarketOptionsRequest {
    MarketType?: MarketTypeEnum | undefined;
    SpotOptions?: SpotMarketOptions | undefined;
}
export type InstanceType = string;
export type Ipv6Address = string | redacted.Redacted<string>;
export interface InstanceIpv6Address {
    Ipv6Address?: string | redacted.Redacted<string> | undefined;
    IsPrimaryIpv6?: boolean | undefined;
}
export type Ipv6Addresses = InstanceIpv6Address[];
export interface LicenseConfigurationRequest {
    LicenseConfigurationArn?: string | undefined;
}
export type LicenseSpecifications = LicenseConfigurationRequest[];
export type AutoRecoveryEnum = "disabled" | "default" | (string & {});
export interface InstanceMaintenanceOptionsRequest {
    AutoRecovery?: AutoRecoveryEnum | undefined;
}
export type HttpEndpointEnum = "enabled" | "disabled" | (string & {});
export type HttpProtocolIpv6Enum = "enabled" | "disabled" | (string & {});
export type HttpPutResponseHopLimit = number;
export type HttpTokensEnum = "optional" | "required" | (string & {});
export type InstanceMetadataTagsEnum = "enabled" | "disabled" | (string & {});
export interface InstanceMetadataOptionsRequest {
    HttpEndpoint?: HttpEndpointEnum | undefined;
    HttpProtocolIpv6?: HttpProtocolIpv6Enum | undefined;
    HttpPutResponseHopLimit?: number | undefined;
    HttpTokens?: HttpTokensEnum | undefined;
    InstanceMetadataTags?: InstanceMetadataTagsEnum | undefined;
}
export interface RunInstancesMonitoringEnabled {
    Enabled?: boolean | undefined;
}
export interface ConnectionTrackingSpecificationRequest {
    TcpEstablishedTimeout?: number | undefined;
    UdpStreamTimeout?: number | undefined;
    UdpTimeout?: number | undefined;
}
export type Description = string;
export interface EnaSrdUdpSpecificationRequest {
    EnaSrdUdpEnabled?: boolean | undefined;
}
export interface EnaSrdSpecificationRequest {
    EnaSrdEnabled?: boolean | undefined;
    EnaSrdUdpSpecification?: EnaSrdUdpSpecificationRequest | undefined;
}
export type InterfaceTypeEnum = "interface" | "efa" | "efa-only" | (string & {});
export type Ipv4Prefix = string;
export interface Ipv4PrefixSpecificationRequest {
    Ipv4Prefix?: string | undefined;
}
export type Ipv4Prefixes = Ipv4PrefixSpecificationRequest[];
export type Ipv6Prefix = string;
export interface Ipv6PrefixSpecificationRequest {
    Ipv6Prefix?: string | undefined;
}
export type Ipv6Prefixes = Ipv6PrefixSpecificationRequest[];
export type NetworkInterfaceId = string;
export type Ipv4Address = string | redacted.Redacted<string>;
export interface PrivateIpAddressSpecification {
    Primary?: boolean | undefined;
    PrivateIpAddress?: string | redacted.Redacted<string> | undefined;
}
export type PrivateIpAddresses = PrivateIpAddressSpecification[];
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type SubnetId = string;
export interface InstanceNetworkInterfaceSpecification {
    AssociateCarrierIpAddress?: boolean | undefined;
    AssociatePublicIpAddress?: boolean | undefined;
    ConnectionTrackingSpecification?: ConnectionTrackingSpecificationRequest | undefined;
    Description?: string | undefined;
    DeviceIndex?: number | undefined;
    EnaSrdSpecification?: EnaSrdSpecificationRequest | undefined;
    InterfaceType?: InterfaceTypeEnum | undefined;
    Ipv4Prefixes?: Ipv4PrefixSpecificationRequest[] | undefined;
    Ipv4PrefixCount?: number | undefined;
    Ipv6AddressCount?: number | undefined;
    Ipv6Addresses?: InstanceIpv6Address[] | undefined;
    Ipv6Prefixes?: Ipv6PrefixSpecificationRequest[] | undefined;
    Ipv6PrefixCount?: number | undefined;
    NetworkCardIndex?: number | undefined;
    NetworkInterfaceId?: string | undefined;
    PrimaryIpv6?: boolean | undefined;
    PrivateIpAddress?: string | redacted.Redacted<string> | undefined;
    PrivateIpAddresses?: PrivateIpAddressSpecification[] | undefined;
    SecondaryPrivateIpAddressCount?: number | undefined;
    Groups?: string[] | undefined;
    SubnetId?: string | undefined;
}
export type NetworkInterfaces = InstanceNetworkInterfaceSpecification[];
export type BandwidthWeightingEnum = "default" | "vpc-1" | "ebs-1" | (string & {});
export interface InstanceNetworkPerformanceOptionsRequest {
    BandwidthWeighting?: BandwidthWeightingEnum | undefined;
}
export type AvailabilityZone = string;
export type PlacementGroupId = string;
export type HostId = string;
export type TenancyEnum = "default" | "dedicated" | "host" | (string & {});
export interface Placement {
    Affinity?: string | undefined;
    AvailabilityZone?: string | undefined;
    GroupId?: string | undefined;
    GroupName?: string | undefined;
    HostId?: string | undefined;
    HostResourceGroupArn?: string | undefined;
    PartitionNumber?: number | undefined;
    Tenancy?: TenancyEnum | undefined;
}
export type HostnameTypeEnum = "ip-name" | "resource-name" | (string & {});
export interface PrivateDnsNameOptionsRequest {
    HostnameType?: HostnameTypeEnum | undefined;
    EnableResourceNameDnsARecord?: boolean | undefined;
    EnableResourceNameDnsAAAARecord?: boolean | undefined;
}
export type SecurityGroupName = string;
export type SecurityGroupNames = string[];
export type UserData = string | redacted.Redacted<string>;
export interface ManagedInstanceRequest {
    BlockDeviceMappings?: BlockDeviceMappingRequest[] | undefined;
    CapacityReservationSpecification?: CapacityReservationSpecification | undefined;
    CpuOptions?: CpuOptionsRequest | undefined;
    CreditSpecification?: CreditSpecificationRequest | undefined;
    DisableApiStop?: boolean | undefined;
    EbsOptimized?: boolean | undefined;
    EnablePrimaryIpv6?: boolean | undefined;
    EnclaveOptions?: EnclaveOptionsRequest | undefined;
    HibernationOptions?: HibernationOptionsRequest | undefined;
    IamInstanceProfile?: IamInstanceProfileSpecification | undefined;
    ImageId?: string | undefined;
    InstanceMarketOptions?: InstanceMarketOptionsRequest | undefined;
    InstanceType?: string | undefined;
    Ipv6Addresses?: InstanceIpv6Address[] | undefined;
    Ipv6AddressCount?: number | undefined;
    KernelId?: string | undefined;
    KeyName?: string | undefined;
    LicenseSpecifications?: LicenseConfigurationRequest[] | undefined;
    MaintenanceOptions?: InstanceMaintenanceOptionsRequest | undefined;
    MetadataOptions?: InstanceMetadataOptionsRequest | undefined;
    Monitoring?: RunInstancesMonitoringEnabled | undefined;
    NetworkInterfaces?: InstanceNetworkInterfaceSpecification[] | undefined;
    NetworkPerformanceOptions?: InstanceNetworkPerformanceOptionsRequest | undefined;
    Placement?: Placement | undefined;
    PrivateDnsNameOptions?: PrivateDnsNameOptionsRequest | undefined;
    PrivateIpAddress?: string | redacted.Redacted<string> | undefined;
    RamdiskId?: string | undefined;
    SecurityGroupIds?: string[] | undefined;
    SecurityGroups?: string[] | undefined;
    SubnetId?: string | undefined;
    TagSpecifications?: TagSpecification[] | undefined;
    UserData?: string | redacted.Redacted<string> | undefined;
}
export type BillingMode = "MONTHLY" | "HOURLY" | (string & {});
export interface BillingConfiguration {
    BillingMode: BillingMode;
}
export interface CreateWorkspaceInstanceRequest {
    ClientToken?: string | redacted.Redacted<string> | undefined;
    Tags?: Tag[] | undefined;
    ManagedInstance: ManagedInstanceRequest;
    BillingConfiguration?: BillingConfiguration | undefined;
}
export interface CreateWorkspaceInstanceResponse {
    WorkspaceInstanceId?: string | undefined;
}
export interface DeleteVolumeRequest {
    VolumeId: string;
}
export interface DeleteVolumeResponse {
}
export interface DeleteWorkspaceInstanceRequest {
    WorkspaceInstanceId: string;
}
export interface DeleteWorkspaceInstanceResponse {
}
export type DisassociateModeEnum = "FORCE" | "NO_FORCE" | (string & {});
export interface DisassociateVolumeRequest {
    WorkspaceInstanceId: string;
    VolumeId: string;
    Device?: string | undefined;
    DisassociateMode?: DisassociateModeEnum | undefined;
}
export interface DisassociateVolumeResponse {
}
export interface GetWorkspaceInstanceRequest {
    WorkspaceInstanceId: string;
}
export interface WorkspaceInstanceError {
    ErrorCode?: string | undefined;
    ErrorMessage?: string | undefined;
}
export type WorkspaceInstanceErrors = WorkspaceInstanceError[];
export interface EC2InstanceError {
    EC2ErrorCode?: string | undefined;
    EC2ExceptionType?: string | undefined;
    EC2ErrorMessage?: string | undefined;
}
export type EC2InstanceErrors = EC2InstanceError[];
export type ProvisionStateEnum = "ALLOCATING" | "ALLOCATED" | "DEALLOCATING" | "DEALLOCATED" | "ERROR_ALLOCATING" | "ERROR_DEALLOCATING" | (string & {});
export interface EC2ManagedInstance {
    InstanceId?: string | undefined;
}
export interface GetWorkspaceInstanceResponse {
    WorkspaceInstanceErrors?: WorkspaceInstanceError[] | undefined;
    EC2InstanceErrors?: EC2InstanceError[] | undefined;
    ProvisionState?: ProvisionStateEnum | undefined;
    WorkspaceInstanceId?: string | undefined;
    EC2ManagedInstance?: EC2ManagedInstance | undefined;
    BillingConfiguration?: BillingConfiguration | undefined;
}
export type ListInstanceTypesMaxResults = number;
export type NextToken = string | redacted.Redacted<string>;
export type PlatformTypeEnum = "Windows" | "Windows BYOL" | "Linux/UNIX" | "Ubuntu Pro Linux" | "Red Hat Enterprise Linux" | "Red Hat BYOL Linux" | "SUSE Linux" | (string & {});
export type InstanceConfigurationTenancyEnum = "SHARED" | "DEDICATED" | (string & {});
export interface InstanceConfigurationFilter {
    BillingMode: BillingMode;
    PlatformType: PlatformTypeEnum;
    Tenancy: InstanceConfigurationTenancyEnum;
}
export interface ListInstanceTypesRequest {
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
    InstanceConfigurationFilter?: InstanceConfigurationFilter | undefined;
}
export interface SupportedInstanceConfiguration {
    BillingMode?: BillingMode | undefined;
    PlatformType?: PlatformTypeEnum | undefined;
    Tenancy?: InstanceConfigurationTenancyEnum | undefined;
}
export type SupportedInstanceConfigurations = SupportedInstanceConfiguration[];
export interface InstanceTypeInfo {
    InstanceType?: string | undefined;
    SupportedInstanceConfigurations?: SupportedInstanceConfiguration[] | undefined;
}
export type InstanceTypes = InstanceTypeInfo[];
export interface ListInstanceTypesResponse {
    InstanceTypes: InstanceTypeInfo[];
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export type MaxResults = number;
export interface ListRegionsRequest {
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export type RegionName = string;
export interface Region {
    RegionName?: string | undefined;
}
export type RegionList = Region[];
export interface ListRegionsResponse {
    Regions: Region[];
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ListTagsForResourceRequest {
    WorkspaceInstanceId: string;
}
export interface ListTagsForResourceResponse {
    Tags?: Tag[] | undefined;
}
export type ProvisionStates = ProvisionStateEnum[];
export interface ListWorkspaceInstancesRequest {
    ProvisionStates?: ProvisionStateEnum[] | undefined;
    MaxResults?: number | undefined;
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface WorkspaceInstance {
    ProvisionState?: ProvisionStateEnum | undefined;
    WorkspaceInstanceId?: string | undefined;
    EC2ManagedInstance?: EC2ManagedInstance | undefined;
}
export type WorkspaceInstances = WorkspaceInstance[];
export interface ListWorkspaceInstancesResponse {
    WorkspaceInstances: WorkspaceInstance[];
    NextToken?: string | redacted.Redacted<string> | undefined;
}
export interface ModifyVolumeRequest {
    VolumeId: string;
    SizeInGB?: number | undefined;
    VolumeType?: VolumeTypeEnum | undefined;
    Iops?: number | undefined;
    Throughput?: number | undefined;
    ClientToken?: string | redacted.Redacted<string> | undefined;
}
export interface ModifyVolumeResponse {
    VolumeId?: string | undefined;
    TargetSize?: number | undefined;
    TargetVolumeType?: VolumeTypeEnum | undefined;
    TargetIops?: number | undefined;
    TargetThroughput?: number | undefined;
}
export interface TagResourceRequest {
    WorkspaceInstanceId: string;
    Tags: Tag[];
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    WorkspaceInstanceId: string;
    TagKeys: string[];
}
export interface UntagResourceResponse {
}
export type ValidationExceptionReason = "UNKNOWN_OPERATION" | "UNSUPPORTED_OPERATION" | "CANNOT_PARSE" | "FIELD_VALIDATION_FAILED" | "DEPENDENCY_FAILURE" | "OTHER" | (string & {});
export interface ValidationExceptionField {
    Name: string;
    Reason: string;
    Message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type AssociateVolumeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Attaches a volume to a WorkSpace Instance.
 */
export declare const associateVolume: API.OperationMethod<AssociateVolumeRequest & RegionInput, AssociateVolumeResponse, AssociateVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateVolumeError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new volume for WorkSpace Instances.
 */
export declare const createVolume: API.OperationMethod<CreateVolumeRequest & RegionInput, CreateVolumeResponse, CreateVolumeError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceInstanceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Launches a new WorkSpace Instance with specified configuration parameters, enabling programmatic workspace deployment.
 */
export declare const createWorkspaceInstance: API.OperationMethod<CreateWorkspaceInstanceRequest & RegionInput, CreateWorkspaceInstanceResponse, CreateWorkspaceInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteVolumeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified volume.
 */
export declare const deleteVolume: API.OperationMethod<DeleteVolumeRequest & RegionInput, DeleteVolumeResponse, DeleteVolumeError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified WorkSpace
 *
 * Usage of this API will result in deletion of the resource in question.
 */
export declare const deleteWorkspaceInstance: API.OperationMethod<DeleteWorkspaceInstanceRequest & RegionInput, DeleteWorkspaceInstanceResponse, DeleteWorkspaceInstanceError, Credentials | HttpClient.HttpClient>;
export type DisassociateVolumeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Detaches a volume from a WorkSpace Instance.
 */
export declare const disassociateVolume: API.OperationMethod<DisassociateVolumeRequest & RegionInput, DisassociateVolumeResponse, DisassociateVolumeError, Credentials | HttpClient.HttpClient>;
export type GetWorkspaceInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific WorkSpace Instance.
 */
export declare const getWorkspaceInstance: API.OperationMethod<GetWorkspaceInstanceRequest & RegionInput, GetWorkspaceInstanceResponse, GetWorkspaceInstanceError, Credentials | HttpClient.HttpClient>;
export type ListInstanceTypesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of instance types supported by Amazon WorkSpaces Instances, enabling precise workspace infrastructure configuration.
 */
export declare const listInstanceTypes: API.PaginatedOperationMethod<ListInstanceTypesRequest & RegionInput, ListInstanceTypesResponse, ListInstanceTypesError, Credentials | HttpClient.HttpClient, InstanceTypeInfo>;
export type ListRegionsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of AWS regions supported by Amazon WorkSpaces Instances, enabling region discovery for workspace deployments.
 */
export declare const listRegions: API.PaginatedOperationMethod<ListRegionsRequest & RegionInput, ListRegionsResponse, ListRegionsError, Credentials | HttpClient.HttpClient, Region>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves tags for a WorkSpace Instance.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkspaceInstancesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a collection of WorkSpaces Instances based on specified filters.
 */
export declare const listWorkspaceInstances: API.PaginatedOperationMethod<ListWorkspaceInstancesRequest & RegionInput, ListWorkspaceInstancesResponse, ListWorkspaceInstancesError, Credentials | HttpClient.HttpClient, WorkspaceInstance>;
export type ModifyVolumeError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | VolumeModificationRateExceededException | CommonErrors;
/**
 * Modifies the size, volume type, IOPS (input/output operations per second), or throughput of a volume. When you modify a volume, you must specify at least one of these parameters. You can modify a volume only after any previous modification for that volume has finished.
 *
 * To track the progress of a modification, use the Amazon EC2 DescribeVolumesModifications operation. For more information, see Monitor the progress of Amazon EBS volume modifications in the *Amazon EBS User Guide*.
 *
 * After you increase the size of a volume, you must extend the partition and file system to use the new storage capacity. For more information, see Extend the file system after resizing an Amazon EBS volume in the *Amazon EBS User Guide*, which covers both Linux and Windows instances.
 */
export declare const modifyVolume: API.OperationMethod<ModifyVolumeRequest & RegionInput, ModifyVolumeResponse, ModifyVolumeError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Adds tags to a WorkSpace Instance.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes tags from a WorkSpace Instance.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=workspaces-instances.d.ts.map