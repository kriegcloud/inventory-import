import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type MigrationWorkflowId = string;
export type TemplateSource = {
    workflowId: string;
};
export type ClientToken = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateTemplateRequest {
    templateName: string;
    templateDescription?: string | undefined;
    templateSource: TemplateSource;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StringMapKey = string;
export type StringMapValue = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export interface CreateTemplateResponse {
    templateId?: string | undefined;
    templateArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StepInputParametersKey = string;
export type StringValue = string;
export type StringListMember = string;
export type StringList = string[];
export type StepInput = {
    integerValue: number;
    stringValue?: undefined;
    listOfStringsValue?: undefined;
    mapOfStringValue?: undefined;
} | {
    integerValue?: undefined;
    stringValue: string;
    listOfStringsValue?: undefined;
    mapOfStringValue?: undefined;
} | {
    integerValue?: undefined;
    stringValue?: undefined;
    listOfStringsValue: string[];
    mapOfStringValue?: undefined;
} | {
    integerValue?: undefined;
    stringValue?: undefined;
    listOfStringsValue?: undefined;
    mapOfStringValue: {
        [key: string]: string | undefined;
    };
};
export type StepInputParameters = {
    [key: string]: StepInput | undefined;
};
export interface CreateMigrationWorkflowRequest {
    name: string;
    description?: string | undefined;
    templateId: string;
    applicationConfigurationId?: string | undefined;
    inputParameters: {
        [key: string]: StepInput | undefined;
    };
    stepTargets?: string[] | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MigrationWorkflowStatusEnum = string;
export interface CreateMigrationWorkflowResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    templateId?: string | undefined;
    adsApplicationConfigurationId?: string | undefined;
    workflowInputs?: {
        [key: string]: StepInput | undefined;
    } | undefined;
    stepTargets?: string[] | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type MigrationWorkflowName = string;
export type StepGroupId = string;
export type StepActionType = string;
export type MigrationWorkflowDescription = string;
export type S3Bucket = string;
export type S3Key = string;
export interface PlatformScriptKey {
    linux?: string | undefined;
    windows?: string | undefined;
}
export interface PlatformCommand {
    linux?: string | undefined;
    windows?: string | undefined;
}
export type RunEnvironment = string;
export type TargetType = string;
export interface WorkflowStepAutomationConfiguration {
    scriptLocationS3Bucket?: string | undefined;
    scriptLocationS3Key?: PlatformScriptKey | undefined;
    command?: PlatformCommand | undefined;
    runEnvironment?: string | undefined;
    targetType?: string | undefined;
}
export type WorkflowStepOutputName = string;
export type DataType = string;
export type MaxStringValue = string;
export type MaxStringList = string[];
export type WorkflowStepOutputUnion = {
    integerValue: number;
    stringValue?: undefined;
    listOfStringValue?: undefined;
} | {
    integerValue?: undefined;
    stringValue: string;
    listOfStringValue?: undefined;
} | {
    integerValue?: undefined;
    stringValue?: undefined;
    listOfStringValue: string[];
};
export interface WorkflowStepOutput {
    name?: string | undefined;
    dataType?: string | undefined;
    required?: boolean | undefined;
    value?: WorkflowStepOutputUnion | undefined;
}
export type WorkflowStepOutputList = WorkflowStepOutput[];
export interface CreateWorkflowStepRequest {
    name: string;
    stepGroupId: string;
    workflowId: string;
    stepActionType: string;
    description?: string | undefined;
    workflowStepAutomationConfiguration?: WorkflowStepAutomationConfiguration | undefined;
    stepTarget?: string[] | undefined;
    outputs?: WorkflowStepOutput[] | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
}
export interface CreateWorkflowStepResponse {
    id?: string | undefined;
    stepGroupId?: string | undefined;
    workflowId?: string | undefined;
    name?: string | undefined;
}
export type StepGroupName = string;
export type StepGroupDescription = string;
export interface CreateWorkflowStepGroupRequest {
    workflowId: string;
    name: string;
    description?: string | undefined;
    next?: string[] | undefined;
    previous?: string[] | undefined;
}
export interface Tool {
    name?: string | undefined;
    url?: string | undefined;
}
export type ToolsList = Tool[];
export interface CreateWorkflowStepGroupResponse {
    workflowId?: string | undefined;
    name?: string | undefined;
    id?: string | undefined;
    description?: string | undefined;
    tools?: Tool[] | undefined;
    next?: string[] | undefined;
    previous?: string[] | undefined;
    creationTime?: Date | undefined;
}
export type TemplateId = string;
export interface DeleteTemplateRequest {
    id: string;
}
export interface DeleteTemplateResponse {
}
export interface DeleteMigrationWorkflowRequest {
    id: string;
}
export interface DeleteMigrationWorkflowResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
}
export type StepId = string;
export interface DeleteWorkflowStepRequest {
    id: string;
    stepGroupId: string;
    workflowId: string;
}
export interface DeleteWorkflowStepResponse {
}
export interface DeleteWorkflowStepGroupRequest {
    workflowId: string;
    id: string;
}
export interface DeleteWorkflowStepGroupResponse {
}
export interface GetMigrationWorkflowTemplateRequest {
    id: string;
}
export type TemplateInputName = string;
export interface TemplateInput {
    inputName?: string | undefined;
    dataType?: string | undefined;
    required?: boolean | undefined;
}
export type TemplateInputList = TemplateInput[];
export type TemplateStatus = string;
export interface GetMigrationWorkflowTemplateResponse {
    id?: string | undefined;
    templateArn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    inputs?: TemplateInput[] | undefined;
    tools?: Tool[] | undefined;
    creationTime?: Date | undefined;
    owner?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    templateClass?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface GetTemplateStepRequest {
    id: string;
    templateId: string;
    stepGroupId: string;
}
export interface StepOutput {
    name?: string | undefined;
    dataType?: string | undefined;
    required?: boolean | undefined;
}
export type StepOutputList = StepOutput[];
export interface StepAutomationConfiguration {
    scriptLocationS3Bucket?: string | undefined;
    scriptLocationS3Key?: PlatformScriptKey | undefined;
    command?: PlatformCommand | undefined;
    runEnvironment?: string | undefined;
    targetType?: string | undefined;
}
export interface GetTemplateStepResponse {
    id?: string | undefined;
    stepGroupId?: string | undefined;
    templateId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    stepActionType?: string | undefined;
    creationTime?: string | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
    outputs?: StepOutput[] | undefined;
    stepAutomationConfiguration?: StepAutomationConfiguration | undefined;
}
export interface GetTemplateStepGroupRequest {
    templateId: string;
    id: string;
}
export type StepGroupStatus = string;
export interface GetTemplateStepGroupResponse {
    templateId?: string | undefined;
    id?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    tools?: Tool[] | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
}
export interface GetMigrationWorkflowRequest {
    id: string;
}
export interface GetMigrationWorkflowResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    templateId?: string | undefined;
    adsApplicationConfigurationId?: string | undefined;
    adsApplicationName?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    creationTime?: Date | undefined;
    lastStartTime?: Date | undefined;
    lastStopTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    tools?: Tool[] | undefined;
    totalSteps?: number | undefined;
    completedSteps?: number | undefined;
    workflowInputs?: {
        [key: string]: StepInput | undefined;
    } | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    workflowBucket?: string | undefined;
}
export interface GetWorkflowStepRequest {
    workflowId: string;
    stepGroupId: string;
    id: string;
}
export type Owner = string;
export type StepStatus = string;
export interface GetWorkflowStepResponse {
    name?: string | undefined;
    stepGroupId?: string | undefined;
    workflowId?: string | undefined;
    stepId?: string | undefined;
    description?: string | undefined;
    stepActionType?: string | undefined;
    owner?: string | undefined;
    workflowStepAutomationConfiguration?: WorkflowStepAutomationConfiguration | undefined;
    stepTarget?: string[] | undefined;
    outputs?: WorkflowStepOutput[] | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    scriptOutputLocation?: string | undefined;
    creationTime?: Date | undefined;
    lastStartTime?: Date | undefined;
    endTime?: Date | undefined;
    noOfSrvCompleted?: number | undefined;
    noOfSrvFailed?: number | undefined;
    totalNoOfSrv?: number | undefined;
}
export interface GetWorkflowStepGroupRequest {
    id: string;
    workflowId: string;
}
export interface GetWorkflowStepGroupResponse {
    id?: string | undefined;
    workflowId?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    status?: string | undefined;
    owner?: string | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    endTime?: Date | undefined;
    tools?: Tool[] | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
}
export type MaxResults = number;
export type NextToken = string;
export interface ListPluginsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export type PluginId = string;
export type PluginHealth = string;
export type IPAddress = string;
export type PluginVersion = string;
export interface PluginSummary {
    pluginId?: string | undefined;
    hostname?: string | undefined;
    status?: string | undefined;
    ipAddress?: string | undefined;
    version?: string | undefined;
    registeredTime?: string | undefined;
}
export type PluginSummaries = PluginSummary[];
export interface ListPluginsResponse {
    nextToken?: string | undefined;
    plugins?: PluginSummary[] | undefined;
}
export type ResourceArn = string;
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TemplateName = string;
export interface ListMigrationWorkflowTemplatesRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    name?: string | undefined;
}
export interface TemplateSummary {
    id?: string | undefined;
    name?: string | undefined;
    arn?: string | undefined;
    description?: string | undefined;
}
export type TemplateSummaryList = TemplateSummary[];
export interface ListMigrationWorkflowTemplatesResponse {
    nextToken?: string | undefined;
    templateSummary: TemplateSummary[];
}
export interface ListTemplateStepGroupsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    templateId: string;
}
export interface TemplateStepGroupSummary {
    id?: string | undefined;
    name?: string | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
}
export type TemplateStepGroupSummaryList = TemplateStepGroupSummary[];
export interface ListTemplateStepGroupsResponse {
    nextToken?: string | undefined;
    templateStepGroupSummary: TemplateStepGroupSummary[];
}
export interface ListTemplateStepsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    templateId: string;
    stepGroupId: string;
}
export interface TemplateStepSummary {
    id?: string | undefined;
    stepGroupId?: string | undefined;
    templateId?: string | undefined;
    name?: string | undefined;
    stepActionType?: string | undefined;
    targetType?: string | undefined;
    owner?: string | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
}
export type TemplateStepSummaryList = TemplateStepSummary[];
export interface ListTemplateStepsResponse {
    nextToken?: string | undefined;
    templateStepSummaryList?: TemplateStepSummary[] | undefined;
}
export type ApplicationConfigurationName = string;
export interface ListMigrationWorkflowsRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
    templateId?: string | undefined;
    adsApplicationConfigurationName?: string | undefined;
    status?: string | undefined;
    name?: string | undefined;
}
export interface MigrationWorkflowSummary {
    id?: string | undefined;
    name?: string | undefined;
    templateId?: string | undefined;
    adsApplicationConfigurationName?: string | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
    endTime?: Date | undefined;
    statusMessage?: string | undefined;
    completedSteps?: number | undefined;
    totalSteps?: number | undefined;
}
export type MigrationWorkflowSummaryList = MigrationWorkflowSummary[];
export interface ListMigrationWorkflowsResponse {
    nextToken?: string | undefined;
    migrationWorkflowSummary: MigrationWorkflowSummary[];
}
export interface ListWorkflowStepGroupsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    workflowId: string;
}
export interface WorkflowStepGroupSummary {
    id?: string | undefined;
    name?: string | undefined;
    owner?: string | undefined;
    status?: string | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
}
export type WorkflowStepGroupsSummaryList = WorkflowStepGroupSummary[];
export interface ListWorkflowStepGroupsResponse {
    nextToken?: string | undefined;
    workflowStepGroupsSummary: WorkflowStepGroupSummary[];
}
export interface ListWorkflowStepsRequest {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    workflowId: string;
    stepGroupId: string;
}
export interface WorkflowStepSummary {
    stepId?: string | undefined;
    name?: string | undefined;
    stepActionType?: string | undefined;
    owner?: string | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    noOfSrvCompleted?: number | undefined;
    noOfSrvFailed?: number | undefined;
    totalNoOfSrv?: number | undefined;
    description?: string | undefined;
    scriptLocation?: string | undefined;
}
export type WorkflowStepsSummaryList = WorkflowStepSummary[];
export interface ListWorkflowStepsResponse {
    nextToken?: string | undefined;
    workflowStepsSummary: WorkflowStepSummary[];
}
export interface RetryWorkflowStepRequest {
    workflowId: string;
    stepGroupId: string;
    id: string;
}
export interface RetryWorkflowStepResponse {
    stepGroupId?: string | undefined;
    workflowId?: string | undefined;
    id?: string | undefined;
    status?: string | undefined;
}
export interface StartMigrationWorkflowRequest {
    id: string;
}
export interface StartMigrationWorkflowResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    lastStartTime?: Date | undefined;
}
export interface StopMigrationWorkflowRequest {
    id: string;
}
export interface StopMigrationWorkflowResponse {
    id?: string | undefined;
    arn?: string | undefined;
    status?: string | undefined;
    statusMessage?: string | undefined;
    lastStopTime?: Date | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeyList = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateTemplateRequest {
    id: string;
    templateName?: string | undefined;
    templateDescription?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateTemplateResponse {
    templateId?: string | undefined;
    templateArn?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateMigrationWorkflowRequest {
    id: string;
    name?: string | undefined;
    description?: string | undefined;
    inputParameters?: {
        [key: string]: StepInput | undefined;
    } | undefined;
    stepTargets?: string[] | undefined;
}
export interface UpdateMigrationWorkflowResponse {
    id?: string | undefined;
    arn?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    templateId?: string | undefined;
    adsApplicationConfigurationId?: string | undefined;
    workflowInputs?: {
        [key: string]: StepInput | undefined;
    } | undefined;
    stepTargets?: string[] | undefined;
    status?: string | undefined;
    creationTime?: Date | undefined;
    lastModifiedTime?: Date | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type StepName = string;
export type StepDescription = string;
export interface UpdateWorkflowStepRequest {
    id: string;
    stepGroupId: string;
    workflowId: string;
    name?: string | undefined;
    description?: string | undefined;
    stepActionType?: string | undefined;
    workflowStepAutomationConfiguration?: WorkflowStepAutomationConfiguration | undefined;
    stepTarget?: string[] | undefined;
    outputs?: WorkflowStepOutput[] | undefined;
    previous?: string[] | undefined;
    next?: string[] | undefined;
    status?: string | undefined;
}
export interface UpdateWorkflowStepResponse {
    id?: string | undefined;
    stepGroupId?: string | undefined;
    workflowId?: string | undefined;
    name?: string | undefined;
}
export interface UpdateWorkflowStepGroupRequest {
    workflowId: string;
    id: string;
    name?: string | undefined;
    description?: string | undefined;
    next?: string[] | undefined;
    previous?: string[] | undefined;
}
export interface UpdateWorkflowStepGroupResponse {
    workflowId?: string | undefined;
    name?: string | undefined;
    id?: string | undefined;
    description?: string | undefined;
    tools?: Tool[] | undefined;
    next?: string[] | undefined;
    previous?: string[] | undefined;
    lastModifiedTime?: Date | undefined;
}
export type CreateTemplateError = AccessDeniedException | ConflictException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a migration workflow template.
 */
export declare const createTemplate: API.OperationMethod<CreateTemplateRequest & RegionInput, CreateTemplateResponse, CreateTemplateError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a workflow to orchestrate your migrations.
 */
export declare const createWorkflow: API.OperationMethod<CreateMigrationWorkflowRequest & RegionInput, CreateMigrationWorkflowResponse, CreateWorkflowError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowStepError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a step in the migration workflow.
 */
export declare const createWorkflowStep: API.OperationMethod<CreateWorkflowStepRequest & RegionInput, CreateWorkflowStepResponse, CreateWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type CreateWorkflowStepGroupError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Create a step group in a migration workflow.
 */
export declare const createWorkflowStepGroup: API.OperationMethod<CreateWorkflowStepGroupRequest & RegionInput, CreateWorkflowStepGroupResponse, CreateWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a migration workflow template.
 */
export declare const deleteTemplate: API.OperationMethod<DeleteTemplateRequest & RegionInput, DeleteTemplateResponse, DeleteTemplateError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a migration workflow. You must pause a running workflow in Migration Hub Orchestrator console to
 * delete it.
 */
export declare const deleteWorkflow: API.OperationMethod<DeleteMigrationWorkflowRequest & RegionInput, DeleteMigrationWorkflowResponse, DeleteWorkflowError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a step in a migration workflow. Pause the workflow to delete a running
 * step.
 */
export declare const deleteWorkflowStep: API.OperationMethod<DeleteWorkflowStepRequest & RegionInput, DeleteWorkflowStepResponse, DeleteWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkflowStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Delete a step group in a migration workflow.
 */
export declare const deleteWorkflowStepGroup: API.OperationMethod<DeleteWorkflowStepGroupRequest & RegionInput, DeleteWorkflowStepGroupResponse, DeleteWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export type GetTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get the template you want to use for creating a migration workflow.
 */
export declare const getTemplate: API.OperationMethod<GetMigrationWorkflowTemplateRequest & RegionInput, GetMigrationWorkflowTemplateResponse, GetTemplateError, Credentials | HttpClient.HttpClient>;
export type GetTemplateStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a specific step in a template.
 */
export declare const getTemplateStep: API.OperationMethod<GetTemplateStepRequest & RegionInput, GetTemplateStepResponse, GetTemplateStepError, Credentials | HttpClient.HttpClient>;
export type GetTemplateStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get a step group in a template.
 */
export declare const getTemplateStepGroup: API.OperationMethod<GetTemplateStepGroupRequest & RegionInput, GetTemplateStepGroupResponse, GetTemplateStepGroupError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get migration workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetMigrationWorkflowRequest & RegionInput, GetMigrationWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Get a step in the migration workflow.
 */
export declare const getWorkflowStep: API.OperationMethod<GetWorkflowStepRequest & RegionInput, GetWorkflowStepResponse, GetWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Get the step group of a migration workflow.
 */
export declare const getWorkflowStepGroup: API.OperationMethod<GetWorkflowStepGroupRequest & RegionInput, GetWorkflowStepGroupResponse, GetWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export type ListPluginsError = AccessDeniedException | InternalServerException | ValidationException | CommonErrors;
/**
 * List AWS Migration Hub Orchestrator plugins.
 */
export declare const listPlugins: API.PaginatedOperationMethod<ListPluginsRequest & RegionInput, ListPluginsResponse, ListPluginsError, Credentials | HttpClient.HttpClient, PluginSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * List the tags added to a resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListTemplatesError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * List the templates available in Migration Hub Orchestrator to create a migration workflow.
 */
export declare const listTemplates: API.PaginatedOperationMethod<ListMigrationWorkflowTemplatesRequest & RegionInput, ListMigrationWorkflowTemplatesResponse, ListTemplatesError, Credentials | HttpClient.HttpClient, TemplateSummary>;
export type ListTemplateStepGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * List the step groups in a template.
 */
export declare const listTemplateStepGroups: API.PaginatedOperationMethod<ListTemplateStepGroupsRequest & RegionInput, ListTemplateStepGroupsResponse, ListTemplateStepGroupsError, Credentials | HttpClient.HttpClient, TemplateStepGroupSummary>;
export type ListTemplateStepsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the steps in a template.
 */
export declare const listTemplateSteps: API.PaginatedOperationMethod<ListTemplateStepsRequest & RegionInput, ListTemplateStepsResponse, ListTemplateStepsError, Credentials | HttpClient.HttpClient, TemplateStepSummary>;
export type ListWorkflowsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the migration workflows.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListMigrationWorkflowsRequest & RegionInput, ListMigrationWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, MigrationWorkflowSummary>;
export type ListWorkflowStepGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the step groups in a migration workflow.
 */
export declare const listWorkflowStepGroups: API.PaginatedOperationMethod<ListWorkflowStepGroupsRequest & RegionInput, ListWorkflowStepGroupsResponse, ListWorkflowStepGroupsError, Credentials | HttpClient.HttpClient, WorkflowStepGroupSummary>;
export type ListWorkflowStepsError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * List the steps in a workflow.
 */
export declare const listWorkflowSteps: API.PaginatedOperationMethod<ListWorkflowStepsRequest & RegionInput, ListWorkflowStepsResponse, ListWorkflowStepsError, Credentials | HttpClient.HttpClient, WorkflowStepSummary>;
export type RetryWorkflowStepError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | CommonErrors;
/**
 * Retry a failed step in a migration workflow.
 */
export declare const retryWorkflowStep: API.OperationMethod<RetryWorkflowStepRequest & RegionInput, RetryWorkflowStepResponse, RetryWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Start a migration workflow.
 */
export declare const startWorkflow: API.OperationMethod<StartMigrationWorkflowRequest & RegionInput, StartMigrationWorkflowResponse, StartWorkflowError, Credentials | HttpClient.HttpClient>;
export type StopWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stop an ongoing migration workflow.
 */
export declare const stopWorkflow: API.OperationMethod<StopMigrationWorkflowRequest & RegionInput, StopMigrationWorkflowResponse, StopWorkflowError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Tag a resource by specifying its Amazon Resource Name (ARN).
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the tags for a resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateTemplateError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a migration workflow template.
 */
export declare const updateTemplate: API.OperationMethod<UpdateTemplateRequest & RegionInput, UpdateTemplateResponse, UpdateTemplateError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a migration workflow.
 */
export declare const updateWorkflow: API.OperationMethod<UpdateMigrationWorkflowRequest & RegionInput, UpdateMigrationWorkflowResponse, UpdateWorkflowError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowStepError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update a step in a migration workflow.
 */
export declare const updateWorkflowStep: API.OperationMethod<UpdateWorkflowStepRequest & RegionInput, UpdateWorkflowStepResponse, UpdateWorkflowStepError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkflowStepGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Update the step group in a migration workflow.
 */
export declare const updateWorkflowStepGroup: API.OperationMethod<UpdateWorkflowStepGroupRequest & RegionInput, UpdateWorkflowStepGroupResponse, UpdateWorkflowStepGroupError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=migrationhuborchestrator.d.ts.map