import * as API from "@distilled.cloud/core/api";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
export interface CreateRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** IP prefix in CIDR notation to bind. */
    cidr: string;
    /** The ID of the parent IP prefix that contains the CIDR. */
    prefixId: string;
    /** Region key from managed regions (e.g., "us", "eu"). */
    regionKey: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateRegionalServicePrefixBindingResponse {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export interface DeleteRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Unique identifier for the prefix binding. */
    bindingId: string;
}
export interface DeleteRegionalServicePrefixBindingResponse {
}
export interface GetRegionRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** UUID of the region (custom or managed) or region_key of a managed region. */
    regionId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionResponse {
    id: string;
    createdOn: string;
    modifiedOn: string;
    name: string;
    regionKey: string;
    version: number;
    versionCreatedOn: string;
}
export interface GetRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Unique identifier for the prefix binding. */
    bindingId: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetRegionalServicePrefixBindingResponse {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export interface ListRegionalServicePrefixBindingsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Opaque token for cursor-based pagination. Omit for the first page. Pass the value from a previous response to fetch the next page. */
    cursor?: string | undefined;
    perPage?: number | undefined;
}
export interface RegionalServicesPrefixBindingsListResultItem {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export type RegionalServicesPrefixBindingsListResultList = Array<RegionalServicesPrefixBindingsListResultItem>;
export interface ListRegionalServicePrefixBindingsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RegionalServicesPrefixBindingsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type RegionsListRequestType = "managed" | "custom";
export interface ListRegionsRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Opaque token for cursor-based pagination. Omit for the first page. Pass the value from a previous response to fetch the next page. */
    cursor?: string | undefined;
    perPage?: number | undefined;
    /** Filter regions by type. Omit to return all regions. */
    type?: RegionsListRequestType | (string & {}) | undefined;
}
export interface RegionsListResultItem {
    id: string;
    createdOn: string;
    modifiedOn: string;
    name: string;
    regionKey: string;
    version: number;
    versionCreatedOn: string;
}
export type RegionsListResultList = Array<RegionsListResultItem>;
export interface ListRegionsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: RegionsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export interface PatchRegionalServicePrefixBindingRequest {
    /** Identifier of a Cloudflare account. */
    accountId: string;
    /** Unique identifier for the prefix binding. */
    bindingId: string;
    /** New region key to assign (e.g., "us", "eu", "cfcanary"). */
    regionKey: string;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface PatchRegionalServicePrefixBindingResponse {
    /** The ID of the binding. */
    id: string;
    /** The CIDR that is bound. */
    cidr: string;
    /** The ID of the parent prefix. */
    prefixId: string;
    /** The region key used for the binding. */
    regionKey: string;
}
export type CreateRegionalServicePrefixBindingError = CloudflareOpError;
/** Bind a CIDR from a BYOIP prefix to a region. This requires the **IP Prefixes Write** permission in addition to **DLS Write**, because the binding is created against a BYOIP prefix in Addressing. */
export declare const createRegionalServicePrefixBinding: API.OperationMethod<CreateRegionalServicePrefixBindingRequest, CreateRegionalServicePrefixBindingResponse, CreateRegionalServicePrefixBindingError, CloudflareOpContext>;
export type DeleteRegionalServicePrefixBindingError = CloudflareOpError;
/** Delete a BYOIP prefix binding. Like creating a binding, this requires **IP Prefixes Write** in addition to **DLS Write**. */
export declare const deleteRegionalServicePrefixBinding: API.OperationMethod<DeleteRegionalServicePrefixBindingRequest, DeleteRegionalServicePrefixBindingResponse, DeleteRegionalServicePrefixBindingError, CloudflareOpContext>;
export type GetRegionError = CloudflareOpError;
/** Retrieve a single DLS region (managed or custom) by ID or region key. */
export declare const getRegion: API.OperationMethod<GetRegionRequest, GetRegionResponse, GetRegionError, CloudflareOpContext>;
export type GetRegionalServicePrefixBindingError = CloudflareOpError;
/** Retrieve a single BYOIP prefix binding by ID. */
export declare const getRegionalServicePrefixBinding: API.OperationMethod<GetRegionalServicePrefixBindingRequest, GetRegionalServicePrefixBindingResponse, GetRegionalServicePrefixBindingError, CloudflareOpContext>;
export type ListRegionalServicePrefixBindingsError = CloudflareOpError;
/** List the BYOIP prefix bindings configured for an account. */
export declare const listRegionalServicePrefixBindings: API.PaginatedOperationMethod<ListRegionalServicePrefixBindingsRequest, ListRegionalServicePrefixBindingsResponse, ListRegionalServicePrefixBindingsError, CloudflareOpContext, RegionalServicesPrefixBindingsListResultItem>;
export type ListRegionsError = CloudflareOpError;
/** List the DLS regions (managed and custom) available to an account. */
export declare const listRegions: API.PaginatedOperationMethod<ListRegionsRequest, ListRegionsResponse, ListRegionsError, CloudflareOpContext, RegionsListResultItem>;
export type PatchRegionalServicePrefixBindingError = CloudflareOpError;
/** Update the region of an existing BYOIP prefix binding. Like creating a binding, this requires **IP Prefixes Write** in addition to **DLS Write**. */
export declare const patchRegionalServicePrefixBinding: API.OperationMethod<PatchRegionalServicePrefixBindingRequest, PatchRegionalServicePrefixBindingResponse, PatchRegionalServicePrefixBindingError, CloudflareOpContext>;
//# sourceMappingURL=dls.d.ts.map