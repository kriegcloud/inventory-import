import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly serviceCode: any;
    readonly quotaCode: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
    readonly fieldList: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type WorkspaceId = string;
export type AlertManagerDefinitionData = Uint8Array;
export type IdempotencyToken = string;
export interface CreateAlertManagerDefinitionRequest {
    workspaceId: string;
    data: Uint8Array;
    clientToken?: string | undefined;
}
export type AlertManagerDefinitionStatusCode = string;
export interface AlertManagerDefinitionStatus {
    statusCode: string;
    statusReason?: string | undefined;
}
export interface CreateAlertManagerDefinitionResponse {
    status: AlertManagerDefinitionStatus;
}
export type AnomalyDetectorAlias = string;
export type AnomalyDetectorEvaluationInterval = number;
export type AnomalyDetectorMissingDataAction = {
    markAsAnomaly: boolean;
    skip?: undefined;
} | {
    markAsAnomaly?: undefined;
    skip: boolean;
};
export type RandomCutForestQuery = string;
export type IgnoreNearExpected = {
    amount: number;
    ratio?: undefined;
} | {
    amount?: undefined;
    ratio: number;
};
export interface RandomCutForestConfiguration {
    query: string;
    shingleSize?: number | undefined;
    sampleSize?: number | undefined;
    ignoreNearExpectedFromAbove?: IgnoreNearExpected | undefined;
    ignoreNearExpectedFromBelow?: IgnoreNearExpected | undefined;
}
export type AnomalyDetectorConfiguration = {
    randomCutForest: RandomCutForestConfiguration;
};
export type PrometheusMetricLabelKey = string;
export type PrometheusMetricLabelValue = string;
export type PrometheusMetricLabelMap = {
    [key: string]: string | undefined;
};
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export interface CreateAnomalyDetectorRequest {
    workspaceId: string;
    alias: string;
    evaluationIntervalInSeconds?: number | undefined;
    missingDataAction?: AnomalyDetectorMissingDataAction | undefined;
    configuration: AnomalyDetectorConfiguration;
    labels?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AnomalyDetectorId = string;
export type AnomalyDetectorArn = string;
export type AnomalyDetectorStatusCode = "CREATING" | "ACTIVE" | "UPDATING" | "DELETING" | "CREATION_FAILED" | "UPDATE_FAILED" | "DELETION_FAILED" | (string & {});
export interface AnomalyDetectorStatus {
    statusCode: AnomalyDetectorStatusCode;
    statusReason?: string | undefined;
}
export interface CreateAnomalyDetectorResponse {
    anomalyDetectorId: string;
    arn: string;
    status: AnomalyDetectorStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type LogGroupArn = string;
export interface CreateLoggingConfigurationRequest {
    workspaceId: string;
    logGroupArn: string;
    clientToken?: string | undefined;
}
export type LoggingConfigurationStatusCode = string;
export interface LoggingConfigurationStatus {
    statusCode: string;
    statusReason?: string | undefined;
}
export interface CreateLoggingConfigurationResponse {
    status: LoggingConfigurationStatus;
}
export interface CloudWatchLogDestination {
    logGroupArn: string;
}
export interface LoggingFilter {
    qspThreshold: number;
}
export interface LoggingDestination {
    cloudWatchLogs: CloudWatchLogDestination;
    filters: LoggingFilter;
}
export type LoggingDestinations = LoggingDestination[];
export interface CreateQueryLoggingConfigurationRequest {
    workspaceId: string;
    destinations: LoggingDestination[];
    clientToken?: string | undefined;
}
export type QueryLoggingConfigurationStatusCode = string;
export interface QueryLoggingConfigurationStatus {
    statusCode: string;
    statusReason?: string | undefined;
}
export interface CreateQueryLoggingConfigurationResponse {
    status: QueryLoggingConfigurationStatus;
}
export type RuleGroupsNamespaceName = string;
export type RuleGroupsNamespaceData = Uint8Array;
export interface CreateRuleGroupsNamespaceRequest {
    workspaceId: string;
    name: string;
    data: Uint8Array;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RuleGroupsNamespaceArn = string;
export type RuleGroupsNamespaceStatusCode = string;
export interface RuleGroupsNamespaceStatus {
    statusCode: string;
    statusReason?: string | undefined;
}
export interface CreateRuleGroupsNamespaceResponse {
    name: string;
    arn: string;
    status: RuleGroupsNamespaceStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ScraperAlias = string;
export type ScrapeConfiguration = {
    configurationBlob: Uint8Array;
};
export type ClusterArn = string;
export type SecurityGroupId = string;
export type SecurityGroupIds = string[];
export type SubnetId = string;
export type SubnetIds = string[];
export interface EksConfiguration {
    clusterArn: string;
    securityGroupIds?: string[] | undefined;
    subnetIds: string[];
}
export interface VpcConfiguration {
    securityGroupIds: string[];
    subnetIds: string[];
}
export type Source = {
    eksConfiguration: EksConfiguration;
    vpcConfiguration?: undefined;
} | {
    eksConfiguration?: undefined;
    vpcConfiguration: VpcConfiguration;
};
export type WorkspaceArn = string;
export interface AmpConfiguration {
    workspaceArn: string;
}
export type CloudWatchDatasetArn = string;
export interface CloudWatchConfiguration {
    datasetArn: string;
}
export type Destination = {
    ampConfiguration: AmpConfiguration;
    cloudWatchConfiguration?: undefined;
} | {
    ampConfiguration?: undefined;
    cloudWatchConfiguration: CloudWatchConfiguration;
};
export type IamRoleArn = string;
export interface RoleConfiguration {
    sourceRoleArn?: string | undefined;
    targetRoleArn?: string | undefined;
}
export type OpenSearchDomainArn = string;
export interface OpenSearchExporterConfiguration {
    domainArn: string;
}
export type MskClusterArn = string;
export type KafkaExporterFilter = string;
export interface KafkaExporterConfiguration {
    clusterArn: string;
    topicFilter?: string | undefined;
    consumerGroupFilter?: string | undefined;
}
export type ExporterConfiguration = {
    openSearchConfiguration: OpenSearchExporterConfiguration;
    kafkaConfiguration?: undefined;
} | {
    openSearchConfiguration?: undefined;
    kafkaConfiguration: KafkaExporterConfiguration;
};
export type ExporterList = ExporterConfiguration[];
export interface CreateScraperRequest {
    alias?: string | undefined;
    scrapeConfiguration: ScrapeConfiguration;
    source: Source;
    destination: Destination;
    roleConfiguration?: RoleConfiguration | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    exporters?: ExporterConfiguration[] | undefined;
}
export type ScraperId = string;
export type ScraperArn = string;
export type ScraperStatusCode = string;
export interface ScraperStatus {
    statusCode: string;
}
export interface CreateScraperResponse {
    scraperId: string;
    arn: string;
    status: ScraperStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type WorkspaceAlias = string;
export type KmsKeyArn = string;
export interface CreateWorkspaceRequest {
    alias?: string | undefined;
    clientToken?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
}
export type WorkspaceStatusCode = string;
export interface WorkspaceStatus {
    statusCode: string;
}
export interface CreateWorkspaceResponse {
    workspaceId: string;
    arn: string;
    status: WorkspaceStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
}
export interface DeleteAlertManagerDefinitionRequest {
    workspaceId: string;
    clientToken?: string | undefined;
}
export interface DeleteAlertManagerDefinitionResponse {
}
export interface DeleteAnomalyDetectorRequest {
    workspaceId: string;
    anomalyDetectorId: string;
    clientToken?: string | undefined;
}
export interface DeleteAnomalyDetectorResponse {
}
export interface DeleteLoggingConfigurationRequest {
    workspaceId: string;
    clientToken?: string | undefined;
}
export interface DeleteLoggingConfigurationResponse {
}
export interface DeleteQueryLoggingConfigurationRequest {
    workspaceId: string;
    clientToken?: string | undefined;
}
export interface DeleteQueryLoggingConfigurationResponse {
}
export interface DeleteResourcePolicyRequest {
    workspaceId: string;
    clientToken?: string | undefined;
    revisionId?: string | undefined;
}
export interface DeleteResourcePolicyResponse {
}
export interface DeleteRuleGroupsNamespaceRequest {
    workspaceId: string;
    name: string;
    clientToken?: string | undefined;
}
export interface DeleteRuleGroupsNamespaceResponse {
}
export interface DeleteScraperRequest {
    scraperId: string;
    clientToken?: string | undefined;
}
export interface DeleteScraperResponse {
    scraperId: string;
    status: ScraperStatus;
}
export interface DeleteScraperLoggingConfigurationRequest {
    scraperId: string;
    clientToken?: string | undefined;
}
export interface DeleteScraperLoggingConfigurationResponse {
}
export interface DeleteWorkspaceRequest {
    workspaceId: string;
    clientToken?: string | undefined;
}
export interface DeleteWorkspaceResponse {
}
export interface DescribeAlertManagerDefinitionRequest {
    workspaceId: string;
}
export interface AlertManagerDefinitionDescription {
    status: AlertManagerDefinitionStatus;
    data?: Uint8Array | undefined;
    createdAt: Date;
    modifiedAt: Date;
}
export interface DescribeAlertManagerDefinitionResponse {
    alertManagerDefinition: AlertManagerDefinitionDescription;
}
export interface DescribeAnomalyDetectorRequest {
    workspaceId: string;
    anomalyDetectorId: string;
}
export interface AnomalyDetectorDescription {
    arn: string;
    anomalyDetectorId: string;
    alias: string;
    evaluationIntervalInSeconds?: number | undefined;
    missingDataAction?: AnomalyDetectorMissingDataAction | undefined;
    configuration?: AnomalyDetectorConfiguration | undefined;
    labels?: {
        [key: string]: string | undefined;
    } | undefined;
    status: AnomalyDetectorStatus;
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeAnomalyDetectorResponse {
    anomalyDetector: AnomalyDetectorDescription;
}
export interface DescribeLoggingConfigurationRequest {
    workspaceId: string;
}
export interface LoggingConfigurationMetadata {
    status: LoggingConfigurationStatus;
    workspace: string;
    logGroupArn: string;
    createdAt: Date;
    modifiedAt: Date;
}
export interface DescribeLoggingConfigurationResponse {
    loggingConfiguration: LoggingConfigurationMetadata;
}
export interface DescribeQueryLoggingConfigurationRequest {
    workspaceId: string;
}
export interface QueryLoggingConfigurationMetadata {
    status: QueryLoggingConfigurationStatus;
    workspace: string;
    destinations: LoggingDestination[];
    createdAt: Date;
    modifiedAt: Date;
}
export interface DescribeQueryLoggingConfigurationResponse {
    queryLoggingConfiguration: QueryLoggingConfigurationMetadata;
}
export interface DescribeResourcePolicyRequest {
    workspaceId: string;
}
export type WorkspacePolicyStatusCode = string;
export interface DescribeResourcePolicyResponse {
    policyDocument: string;
    policyStatus: string;
    revisionId: string;
}
export interface DescribeRuleGroupsNamespaceRequest {
    workspaceId: string;
    name: string;
}
export interface RuleGroupsNamespaceDescription {
    arn: string;
    name: string;
    status: RuleGroupsNamespaceStatus;
    data?: Uint8Array | undefined;
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeRuleGroupsNamespaceResponse {
    ruleGroupsNamespace: RuleGroupsNamespaceDescription;
}
export interface DescribeScraperRequest {
    scraperId: string;
}
export type StatusReason = string;
export interface ScraperDescription {
    alias?: string | undefined;
    scraperId: string;
    arn: string;
    roleArn: string;
    status: ScraperStatus;
    createdAt: Date;
    lastModifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    statusReason?: string | undefined;
    scrapeConfiguration: ScrapeConfiguration;
    source: Source;
    destination: Destination;
    roleConfiguration?: RoleConfiguration | undefined;
    exporters?: ExporterConfiguration[] | undefined;
}
export interface DescribeScraperResponse {
    scraper: ScraperDescription;
}
export interface DescribeScraperLoggingConfigurationRequest {
    scraperId: string;
}
export type ScraperLoggingConfigurationStatusCode = string;
export interface ScraperLoggingConfigurationStatus {
    statusCode: string;
    statusReason?: string | undefined;
}
export type ScraperLoggingDestination = {
    cloudWatchLogs: CloudWatchLogDestination;
};
export type ScraperComponentType = string;
export type StringMap = {
    [key: string]: string | undefined;
};
export interface ComponentConfig {
    options?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ScraperComponent {
    type: string;
    config?: ComponentConfig | undefined;
}
export type ScraperComponents = ScraperComponent[];
export interface DescribeScraperLoggingConfigurationResponse {
    status: ScraperLoggingConfigurationStatus;
    scraperId: string;
    loggingDestination: ScraperLoggingDestination;
    scraperComponents: ScraperComponent[];
    modifiedAt: Date;
}
export interface DescribeWorkspaceRequest {
    workspaceId: string;
}
export type Uri = string;
export interface WorkspaceDescription {
    workspaceId: string;
    alias?: string | undefined;
    arn: string;
    status: WorkspaceStatus;
    prometheusEndpoint?: string | undefined;
    createdAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
}
export interface DescribeWorkspaceResponse {
    workspace: WorkspaceDescription;
}
export interface DescribeWorkspaceConfigurationRequest {
    workspaceId: string;
}
export type WorkspaceConfigurationStatusCode = string;
export interface WorkspaceConfigurationStatus {
    statusCode: string;
    statusReason?: string | undefined;
}
export interface LimitsPerLabelSetEntry {
    maxSeries?: number | undefined;
}
export type LabelName = string;
export type LabelValue = string;
export type LabelSet = {
    [key: string]: string | undefined;
};
export interface LimitsPerLabelSet {
    limits: LimitsPerLabelSetEntry;
    labelSet: {
        [key: string]: string | undefined;
    };
}
export type LimitsPerLabelSetList = LimitsPerLabelSet[];
export interface WorkspaceConfigurationDescription {
    status: WorkspaceConfigurationStatus;
    limitsPerLabelSet?: LimitsPerLabelSet[] | undefined;
    retentionPeriodInDays?: number | undefined;
    outOfOrderTimeWindowInSeconds?: number | undefined;
    ruleQueryOffsetInSeconds?: number | undefined;
}
export interface DescribeWorkspaceConfigurationResponse {
    workspaceConfiguration: WorkspaceConfigurationDescription;
}
export interface GetDefaultScraperConfigurationRequest {
}
export interface GetDefaultScraperConfigurationResponse {
    configuration: Uint8Array;
}
export type PaginationToken = string;
export interface ListAnomalyDetectorsRequest {
    workspaceId: string;
    alias?: string | undefined;
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AnomalyDetectorSummary {
    arn: string;
    anomalyDetectorId: string;
    alias: string;
    status: AnomalyDetectorStatus;
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type AnomalyDetectorSummaryList = AnomalyDetectorSummary[];
export interface ListAnomalyDetectorsResponse {
    anomalyDetectors: AnomalyDetectorSummary[];
    nextToken?: string | undefined;
}
export interface ListRuleGroupsNamespacesRequest {
    workspaceId: string;
    name?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface RuleGroupsNamespaceSummary {
    arn: string;
    name: string;
    status: RuleGroupsNamespaceStatus;
    createdAt: Date;
    modifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type RuleGroupsNamespaceSummaryList = RuleGroupsNamespaceSummary[];
export interface ListRuleGroupsNamespacesResponse {
    ruleGroupsNamespaces: RuleGroupsNamespaceSummary[];
    nextToken?: string | undefined;
}
export type FilterKey = string;
export type FilterValue = string;
export type FilterValues = string[];
export type ScraperFilters = {
    [key: string]: string[] | undefined;
};
export interface ListScrapersRequest {
    filters?: {
        [key: string]: string[] | undefined;
    } | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ScraperSummary {
    alias?: string | undefined;
    scraperId: string;
    arn: string;
    roleArn: string;
    status: ScraperStatus;
    createdAt: Date;
    lastModifiedAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    statusReason?: string | undefined;
    source: Source;
    destination: Destination;
    roleConfiguration?: RoleConfiguration | undefined;
    exporters?: ExporterConfiguration[] | undefined;
}
export type ScraperSummaryList = ScraperSummary[];
export interface ListScrapersResponse {
    scrapers: ScraperSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface ListWorkspacesRequest {
    nextToken?: string | undefined;
    alias?: string | undefined;
    maxResults?: number | undefined;
}
export interface WorkspaceSummary {
    workspaceId: string;
    alias?: string | undefined;
    arn: string;
    status: WorkspaceStatus;
    createdAt: Date;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    kmsKeyArn?: string | undefined;
}
export type WorkspaceSummaryList = WorkspaceSummary[];
export interface ListWorkspacesResponse {
    workspaces: WorkspaceSummary[];
    nextToken?: string | undefined;
}
export interface PutAlertManagerDefinitionRequest {
    workspaceId: string;
    data: Uint8Array;
    clientToken?: string | undefined;
}
export interface PutAlertManagerDefinitionResponse {
    status: AlertManagerDefinitionStatus;
}
export interface PutAnomalyDetectorRequest {
    workspaceId: string;
    anomalyDetectorId: string;
    evaluationIntervalInSeconds?: number | undefined;
    missingDataAction?: AnomalyDetectorMissingDataAction | undefined;
    configuration: AnomalyDetectorConfiguration;
    labels?: {
        [key: string]: string | undefined;
    } | undefined;
    clientToken?: string | undefined;
}
export interface PutAnomalyDetectorResponse {
    anomalyDetectorId: string;
    arn: string;
    status: AnomalyDetectorStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface PutResourcePolicyRequest {
    workspaceId: string;
    policyDocument: string;
    clientToken?: string | undefined;
    revisionId?: string | undefined;
}
export interface PutResourcePolicyResponse {
    policyStatus: string;
    revisionId: string;
}
export interface PutRuleGroupsNamespaceRequest {
    workspaceId: string;
    name: string;
    data: Uint8Array;
    clientToken?: string | undefined;
}
export interface PutRuleGroupsNamespaceResponse {
    name: string;
    arn: string;
    status: RuleGroupsNamespaceStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateLoggingConfigurationRequest {
    workspaceId: string;
    logGroupArn: string;
    clientToken?: string | undefined;
}
export interface UpdateLoggingConfigurationResponse {
    status: LoggingConfigurationStatus;
}
export interface UpdateQueryLoggingConfigurationRequest {
    workspaceId: string;
    destinations: LoggingDestination[];
    clientToken?: string | undefined;
}
export interface UpdateQueryLoggingConfigurationResponse {
    status: QueryLoggingConfigurationStatus;
}
export interface UpdateScraperRequest {
    scraperId: string;
    alias?: string | undefined;
    scrapeConfiguration?: ScrapeConfiguration | undefined;
    destination?: Destination | undefined;
    roleConfiguration?: RoleConfiguration | undefined;
    clientToken?: string | undefined;
    exporters?: ExporterConfiguration[] | undefined;
}
export interface UpdateScraperResponse {
    scraperId: string;
    arn: string;
    status: ScraperStatus;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface UpdateScraperLoggingConfigurationRequest {
    scraperId: string;
    loggingDestination: ScraperLoggingDestination;
    scraperComponents?: ScraperComponent[] | undefined;
}
export interface UpdateScraperLoggingConfigurationResponse {
    status: ScraperLoggingConfigurationStatus;
}
export interface UpdateWorkspaceAliasRequest {
    workspaceId: string;
    alias?: string | undefined;
    clientToken?: string | undefined;
}
export interface UpdateWorkspaceAliasResponse {
}
export interface UpdateWorkspaceConfigurationRequest {
    workspaceId: string;
    clientToken?: string | undefined;
    limitsPerLabelSet?: LimitsPerLabelSet[] | undefined;
    retentionPeriodInDays?: number | undefined;
    outOfOrderTimeWindowInSeconds?: number | undefined;
    ruleQueryOffsetInSeconds?: number | undefined;
}
export interface UpdateWorkspaceConfigurationResponse {
    status: WorkspaceConfigurationStatus;
}
export type ValidationExceptionReason = string;
export interface ValidationExceptionField {
    name: string;
    message: string;
}
export type ValidationExceptionFieldList = ValidationExceptionField[];
export type CreateAlertManagerDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `CreateAlertManagerDefinition` operation creates the alert manager definition in a workspace. If a workspace already has an alert manager definition, don't use this operation to update it. Instead, use `PutAlertManagerDefinition`.
 */
export declare const createAlertManagerDefinition: API.OperationMethod<CreateAlertManagerDefinitionRequest & RegionInput, CreateAlertManagerDefinitionResponse, CreateAlertManagerDefinitionError, Credentials | HttpClient.HttpClient>;
export type CreateAnomalyDetectorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an anomaly detector within a workspace using the Random Cut Forest algorithm for time-series analysis. The anomaly detector analyzes Amazon Managed Service for Prometheus metrics to identify unusual patterns and behaviors.
 */
export declare const createAnomalyDetector: API.OperationMethod<CreateAnomalyDetectorRequest & RegionInput, CreateAnomalyDetectorResponse, CreateAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type CreateLoggingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | CommonErrors;
/**
 * The `CreateLoggingConfiguration` operation creates rules and alerting logging configuration for the workspace. Use this operation to set the CloudWatch log group to which the logs will be published to.
 *
 * These logging configurations are only for rules and alerting logs.
 */
export declare const createLoggingConfiguration: API.OperationMethod<CreateLoggingConfigurationRequest & RegionInput, CreateLoggingConfigurationResponse, CreateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateQueryLoggingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | ConflictException | CommonErrors;
/**
 * Creates a query logging configuration for the specified workspace. This operation enables logging of queries that exceed the specified QSP threshold.
 */
export declare const createQueryLoggingConfiguration: API.OperationMethod<CreateQueryLoggingConfigurationRequest & RegionInput, CreateQueryLoggingConfigurationResponse, CreateQueryLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type CreateRuleGroupsNamespaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `CreateRuleGroupsNamespace` operation creates a rule groups namespace within a workspace. A rule groups namespace is associated with exactly one rules file. A workspace can have multiple rule groups namespaces.
 *
 * The combined length of a rule group namespace and a rule group name cannot exceed 721 UTF-8 bytes.
 *
 * Use this operation only to create new rule groups namespaces. To update an existing rule groups namespace, use `PutRuleGroupsNamespace`.
 */
export declare const createRuleGroupsNamespace: API.OperationMethod<CreateRuleGroupsNamespaceRequest & RegionInput, CreateRuleGroupsNamespaceResponse, CreateRuleGroupsNamespaceError, Credentials | HttpClient.HttpClient>;
export type CreateScraperError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a scraper to collect metrics from Prometheus-compatible sources. The scraper sends the collected metrics to Amazon Managed Service for Prometheus workspaces or CloudWatch datasets. You can configure scrapers to collect metrics from Amazon EKS clusters, Amazon MSK clusters, or from VPC-based sources that support DNS-based service discovery. Scrapers are flexible. You can configure a scraper to control which metrics to collect, the frequency of collection, which transformations to apply to the metrics, and more.
 *
 * An IAM role will be created for you that Amazon Managed Service for Prometheus uses to access the metrics in your source. You must configure this role with a policy that allows it to scrape metrics from your source. For Amazon EKS sources, see Configuring your Amazon EKS cluster in the *Amazon Managed Service for Prometheus User Guide*. For a Kafka exporter, grant this role access with a cluster policy on the Amazon MSK cluster instead. For details, see `KafkaExporterConfiguration`.
 *
 * The `scrapeConfiguration` parameter contains the base-64 encoded YAML configuration for the scraper.
 *
 * When creating a scraper, the service creates a `Network Interface` in each **Availability Zone** that are passed into `CreateScraper` through subnets. These network interfaces are used to connect to your source within the VPC for scraping metrics.
 *
 * For more information about collectors, including what metrics are collected, and how to configure the scraper, see Using an Amazon Web Services managed collector in the *Amazon Managed Service for Prometheus User Guide*.
 */
export declare const createScraper: API.OperationMethod<CreateScraperRequest & RegionInput, CreateScraperResponse, CreateScraperError, Credentials | HttpClient.HttpClient>;
export type CreateWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Prometheus workspace. A workspace is a logical space dedicated to the storage and querying of Prometheus metrics. You can have one or more workspaces in each Region in your account.
 */
export declare const createWorkspace: API.OperationMethod<CreateWorkspaceRequest & RegionInput, CreateWorkspaceResponse, CreateWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DeleteAlertManagerDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the alert manager definition from a workspace.
 */
export declare const deleteAlertManagerDefinition: API.OperationMethod<DeleteAlertManagerDefinitionRequest & RegionInput, DeleteAlertManagerDefinitionResponse, DeleteAlertManagerDefinitionError, Credentials | HttpClient.HttpClient>;
export type DeleteAnomalyDetectorError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes an anomaly detector from a workspace. This operation is idempotent.
 */
export declare const deleteAnomalyDetector: API.OperationMethod<DeleteAnomalyDetectorRequest & RegionInput, DeleteAnomalyDetectorResponse, DeleteAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type DeleteLoggingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the rules and alerting logging configuration for a workspace.
 *
 * These logging configurations are only for rules and alerting logs.
 */
export declare const deleteLoggingConfiguration: API.OperationMethod<DeleteLoggingConfigurationRequest & RegionInput, DeleteLoggingConfigurationResponse, DeleteLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteQueryLoggingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the query logging configuration for the specified workspace.
 */
export declare const deleteQueryLoggingConfiguration: API.OperationMethod<DeleteQueryLoggingConfigurationRequest & RegionInput, DeleteQueryLoggingConfigurationResponse, DeleteQueryLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the resource-based policy attached to an Amazon Managed Service for Prometheus workspace.
 */
export declare const deleteResourcePolicy: API.OperationMethod<DeleteResourcePolicyRequest & RegionInput, DeleteResourcePolicyResponse, DeleteResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DeleteRuleGroupsNamespaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes one rule groups namespace and its associated rule groups definition.
 */
export declare const deleteRuleGroupsNamespace: API.OperationMethod<DeleteRuleGroupsNamespaceRequest & RegionInput, DeleteRuleGroupsNamespaceResponse, DeleteRuleGroupsNamespaceError, Credentials | HttpClient.HttpClient>;
export type DeleteScraperError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `DeleteScraper` operation deletes one scraper, and stops any metrics collection that the scraper performs.
 */
export declare const deleteScraper: API.OperationMethod<DeleteScraperRequest & RegionInput, DeleteScraperResponse, DeleteScraperError, Credentials | HttpClient.HttpClient>;
export type DeleteScraperLoggingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Deletes the logging configuration for a Amazon Managed Service for Prometheus scraper.
 */
export declare const deleteScraperLoggingConfiguration: API.OperationMethod<DeleteScraperLoggingConfigurationRequest & RegionInput, DeleteScraperLoggingConfigurationResponse, DeleteScraperLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DeleteWorkspaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes an existing workspace.
 *
 * When you delete a workspace, the data that has been ingested into it is not immediately deleted. It will be permanently deleted within one month.
 */
export declare const deleteWorkspace: API.OperationMethod<DeleteWorkspaceRequest & RegionInput, DeleteWorkspaceResponse, DeleteWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DescribeAlertManagerDefinitionError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the full information about the alert manager definition for a workspace.
 */
export declare const describeAlertManagerDefinition: API.OperationMethod<DescribeAlertManagerDefinitionRequest & RegionInput, DescribeAlertManagerDefinitionResponse, DescribeAlertManagerDefinitionError, Credentials | HttpClient.HttpClient>;
export type DescribeAnomalyDetectorError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves detailed information about a specific anomaly detector, including its status and configuration.
 */
export declare const describeAnomalyDetector: API.OperationMethod<DescribeAnomalyDetectorRequest & RegionInput, DescribeAnomalyDetectorResponse, DescribeAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type DescribeLoggingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Returns complete information about the current rules and alerting logging configuration of the workspace.
 *
 * These logging configurations are only for rules and alerting logs.
 */
export declare const describeLoggingConfiguration: API.OperationMethod<DescribeLoggingConfigurationRequest & RegionInput, DescribeLoggingConfigurationResponse, DescribeLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeQueryLoggingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Retrieves the details of the query logging configuration for the specified workspace.
 */
export declare const describeQueryLoggingConfiguration: API.OperationMethod<DescribeQueryLoggingConfigurationRequest & RegionInput, DescribeQueryLoggingConfigurationResponse, DescribeQueryLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeResourcePolicyError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the resource-based policy attached to an Amazon Managed Service for Prometheus workspace.
 */
export declare const describeResourcePolicy: API.OperationMethod<DescribeResourcePolicyRequest & RegionInput, DescribeResourcePolicyResponse, DescribeResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type DescribeRuleGroupsNamespaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns complete information about one rule groups namespace. To retrieve a list of rule groups namespaces, use `ListRuleGroupsNamespaces`.
 */
export declare const describeRuleGroupsNamespace: API.OperationMethod<DescribeRuleGroupsNamespaceRequest & RegionInput, DescribeRuleGroupsNamespaceResponse, DescribeRuleGroupsNamespaceError, Credentials | HttpClient.HttpClient>;
export type DescribeScraperError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `DescribeScraper` operation displays information about an existing scraper.
 */
export declare const describeScraper: API.OperationMethod<DescribeScraperRequest & RegionInput, DescribeScraperResponse, DescribeScraperError, Credentials | HttpClient.HttpClient>;
export type DescribeScraperLoggingConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Describes the logging configuration for a Amazon Managed Service for Prometheus scraper.
 */
export declare const describeScraperLoggingConfiguration: API.OperationMethod<DescribeScraperLoggingConfigurationRequest & RegionInput, DescribeScraperLoggingConfigurationResponse, DescribeScraperLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an existing workspace.
 */
export declare const describeWorkspace: API.OperationMethod<DescribeWorkspaceRequest & RegionInput, DescribeWorkspaceResponse, DescribeWorkspaceError, Credentials | HttpClient.HttpClient>;
export type DescribeWorkspaceConfigurationError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to return information about the configuration of a workspace. The configuration details returned include workspace configuration status, label set limits, and retention period.
 */
export declare const describeWorkspaceConfiguration: API.OperationMethod<DescribeWorkspaceConfigurationRequest & RegionInput, DescribeWorkspaceConfigurationResponse, DescribeWorkspaceConfigurationError, Credentials | HttpClient.HttpClient>;
export type GetDefaultScraperConfigurationError = AccessDeniedException | InternalServerException | ThrottlingException | CommonErrors;
/**
 * The `GetDefaultScraperConfiguration` operation returns the default scraper configuration used when Amazon EKS creates a scraper for you.
 */
export declare const getDefaultScraperConfiguration: API.OperationMethod<GetDefaultScraperConfigurationRequest & RegionInput, GetDefaultScraperConfigurationResponse, GetDefaultScraperConfigurationError, Credentials | HttpClient.HttpClient>;
export type ListAnomalyDetectorsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of anomaly detectors for a workspace with optional filtering by alias.
 */
export declare const listAnomalyDetectors: API.PaginatedOperationMethod<ListAnomalyDetectorsRequest & RegionInput, ListAnomalyDetectorsResponse, ListAnomalyDetectorsError, Credentials | HttpClient.HttpClient, AnomalyDetectorSummary>;
export type ListRuleGroupsNamespacesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of rule groups namespaces in a workspace.
 */
export declare const listRuleGroupsNamespaces: API.PaginatedOperationMethod<ListRuleGroupsNamespacesRequest & RegionInput, ListRuleGroupsNamespacesResponse, ListRuleGroupsNamespacesError, Credentials | HttpClient.HttpClient, RuleGroupsNamespaceSummary>;
export type ListScrapersError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `ListScrapers` operation lists all of the scrapers in your account. This includes scrapers being created or deleted. You can optionally filter the returned list.
 */
export declare const listScrapers: API.PaginatedOperationMethod<ListScrapersRequest & RegionInput, ListScrapersResponse, ListScrapersError, Credentials | HttpClient.HttpClient, ScraperSummary>;
export type ListTagsForResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `ListTagsForResource` operation returns the tags that are associated with an Amazon Managed Service for Prometheus resource. Currently, the only resources that can be tagged are scrapers, workspaces, and rule groups namespaces.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ListWorkspacesError = AccessDeniedException | InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all of the Amazon Managed Service for Prometheus workspaces in your account. This includes workspaces being created or deleted.
 */
export declare const listWorkspaces: API.PaginatedOperationMethod<ListWorkspacesRequest & RegionInput, ListWorkspacesResponse, ListWorkspacesError, Credentials | HttpClient.HttpClient, WorkspaceSummary>;
export type PutAlertManagerDefinitionError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing alert manager definition in a workspace. If the workspace does not already have an alert manager definition, don't use this operation to create it. Instead, use `CreateAlertManagerDefinition`.
 */
export declare const putAlertManagerDefinition: API.OperationMethod<PutAlertManagerDefinitionRequest & RegionInput, PutAlertManagerDefinitionResponse, PutAlertManagerDefinitionError, Credentials | HttpClient.HttpClient>;
export type PutAnomalyDetectorError = AccessDeniedException | ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * When you call `PutAnomalyDetector`, the operation creates a new anomaly detector if one doesn't exist, or updates an existing one. Each call to this operation triggers a complete retraining of the detector, which includes querying the minimum required samples and backfilling the detector with historical data. This process occurs regardless of whether you're making a minor change like updating the evaluation interval or making more substantial modifications. The operation serves as the single method for creating, updating, and retraining anomaly detectors.
 */
export declare const putAnomalyDetector: API.OperationMethod<PutAnomalyDetectorRequest & RegionInput, PutAnomalyDetectorResponse, PutAnomalyDetectorError, Credentials | HttpClient.HttpClient>;
export type PutResourcePolicyError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates or updates a resource-based policy for an Amazon Managed Service for Prometheus workspace. Use resource-based policies to grant permissions to other AWS accounts or services to access your workspace.
 *
 * Only Prometheus-compatible APIs can be used for workspace sharing. You can add non-Prometheus-compatible APIs to the policy, but they will be ignored. For more information, see Prometheus-compatible APIs in the *Amazon Managed Service for Prometheus User Guide*.
 *
 * If your workspace uses customer-managed KMS keys for encryption, you must grant the principals in your resource-based policy access to those KMS keys. You can do this by creating KMS grants. For more information, see CreateGrant in the *AWS Key Management Service API Reference* and Encryption at rest in the *Amazon Managed Service for Prometheus User Guide*.
 *
 * For more information about working with IAM, see Using Amazon Managed Service for Prometheus with IAM in the *Amazon Managed Service for Prometheus User Guide*.
 */
export declare const putResourcePolicy: API.OperationMethod<PutResourcePolicyRequest & RegionInput, PutResourcePolicyResponse, PutResourcePolicyError, Credentials | HttpClient.HttpClient>;
export type PutRuleGroupsNamespaceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing rule groups namespace within a workspace. A rule groups namespace is associated with exactly one rules file. A workspace can have multiple rule groups namespaces.
 *
 * The combined length of a rule group namespace and a rule group name cannot exceed 721 UTF-8 bytes.
 *
 * Use this operation only to update existing rule groups namespaces. To create a new rule groups namespace, use `CreateRuleGroupsNamespace`.
 *
 * You can't use this operation to add tags to an existing rule groups namespace. Instead, use `TagResource`.
 */
export declare const putRuleGroupsNamespace: API.OperationMethod<PutRuleGroupsNamespaceRequest & RegionInput, PutRuleGroupsNamespaceResponse, PutRuleGroupsNamespaceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * The `TagResource` operation associates tags with an Amazon Managed Service for Prometheus resource. The only resources that can be tagged are rule groups namespaces, scrapers, and workspaces.
 *
 * If you specify a new tag key for the resource, this tag is appended to the list of tags associated with the resource. If you specify a tag key that is already associated with the resource, the new tag value that you specify replaces the previous value for that tag. To remove a tag, use `UntagResource`.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes the specified tags from an Amazon Managed Service for Prometheus resource. The only resources that can be tagged are rule groups namespaces, scrapers, and workspaces.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateLoggingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the log group ARN or the workspace ID of the current rules and alerting logging configuration.
 *
 * These logging configurations are only for rules and alerting logs.
 */
export declare const updateLoggingConfiguration: API.OperationMethod<UpdateLoggingConfigurationRequest & RegionInput, UpdateLoggingConfigurationResponse, UpdateLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateQueryLoggingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the query logging configuration for the specified workspace.
 */
export declare const updateQueryLoggingConfiguration: API.OperationMethod<UpdateQueryLoggingConfigurationRequest & RegionInput, UpdateQueryLoggingConfigurationResponse, UpdateQueryLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateScraperError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates an existing scraper.
 *
 * You can't use this function to update the source from which the scraper is collecting metrics. To change the source, delete the scraper and create a new one.
 */
export declare const updateScraper: API.OperationMethod<UpdateScraperRequest & RegionInput, UpdateScraperResponse, UpdateScraperError, Credentials | HttpClient.HttpClient>;
export type UpdateScraperLoggingConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ValidationException | CommonErrors;
/**
 * Updates the logging configuration for a Amazon Managed Service for Prometheus scraper.
 */
export declare const updateScraperLoggingConfiguration: API.OperationMethod<UpdateScraperLoggingConfigurationRequest & RegionInput, UpdateScraperLoggingConfigurationResponse, UpdateScraperLoggingConfigurationError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceAliasError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates the alias of an existing workspace.
 */
export declare const updateWorkspaceAlias: API.OperationMethod<UpdateWorkspaceAliasRequest & RegionInput, UpdateWorkspaceAliasResponse, UpdateWorkspaceAliasError, Credentials | HttpClient.HttpClient>;
export type UpdateWorkspaceConfigurationError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Use this operation to create or update the label sets, label set limits, and retention period of a workspace.
 *
 * You must specify at least one of `limitsPerLabelSet` or `retentionPeriodInDays` for the request to be valid.
 */
export declare const updateWorkspaceConfiguration: API.OperationMethod<UpdateWorkspaceConfigurationRequest & RegionInput, UpdateWorkspaceConfigurationResponse, UpdateWorkspaceConfigurationError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=amp.d.ts.map