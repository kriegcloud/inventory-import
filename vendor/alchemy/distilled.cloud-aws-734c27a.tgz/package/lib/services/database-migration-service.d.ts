import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedFault_base: S.TaggedErrorClass<"AccessDeniedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedFault extends /*@__PURE__*/ AccessDeniedFault_base {
}
declare const CollectorNotFoundFault_base: S.TaggedErrorClass<"CollectorNotFoundFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class CollectorNotFoundFault extends /*@__PURE__*/ CollectorNotFoundFault_base {
}
declare const FailedDependencyFault_base: S.TaggedErrorClass<"FailedDependencyFault", {
    readonly message: any;
}>;
export declare class FailedDependencyFault extends /*@__PURE__*/ FailedDependencyFault_base {
}
declare const InsufficientResourceCapacityFault_base: S.TaggedErrorClass<"InsufficientResourceCapacityFault", {
    readonly message: any;
}>;
export declare class InsufficientResourceCapacityFault extends /*@__PURE__*/ InsufficientResourceCapacityFault_base {
}
declare const InvalidCertificateFault_base: S.TaggedErrorClass<"InvalidCertificateFault", {
    readonly message: any;
}>;
export declare class InvalidCertificateFault extends /*@__PURE__*/ InvalidCertificateFault_base {
}
declare const InvalidOperationFault_base: S.TaggedErrorClass<"InvalidOperationFault", {
    readonly message: any;
}>;
export declare class InvalidOperationFault extends /*@__PURE__*/ InvalidOperationFault_base {
}
declare const InvalidParameterValueException_base: S.TaggedErrorClass<"InvalidParameterValueException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidParameterValueException extends /*@__PURE__*/ InvalidParameterValueException_base {
}
declare const InvalidReplicationInstanceClass_base: S.TaggedErrorClass<"InvalidReplicationInstanceClass", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class InvalidReplicationInstanceClass extends /*@__PURE__*/ InvalidReplicationInstanceClass_base {
}
declare const InvalidResourceStateFault_base: S.TaggedErrorClass<"InvalidResourceStateFault", {
    readonly message: any;
}>;
export declare class InvalidResourceStateFault extends /*@__PURE__*/ InvalidResourceStateFault_base {
}
declare const InvalidSubnet_base: S.TaggedErrorClass<"InvalidSubnet", {
    readonly message: any;
}>;
export declare class InvalidSubnet extends /*@__PURE__*/ InvalidSubnet_base {
}
declare const KMSAccessDeniedFault_base: S.TaggedErrorClass<"KMSAccessDeniedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class KMSAccessDeniedFault extends /*@__PURE__*/ KMSAccessDeniedFault_base {
}
declare const KMSDisabledFault_base: S.TaggedErrorClass<"KMSDisabledFault", {
    readonly message: any;
}>;
export declare class KMSDisabledFault extends /*@__PURE__*/ KMSDisabledFault_base {
}
declare const KMSFault_base: S.TaggedErrorClass<"KMSFault", {
    readonly message: any;
}>;
export declare class KMSFault extends /*@__PURE__*/ KMSFault_base {
}
declare const KMSInvalidStateFault_base: S.TaggedErrorClass<"KMSInvalidStateFault", {
    readonly message: any;
}>;
export declare class KMSInvalidStateFault extends /*@__PURE__*/ KMSInvalidStateFault_base {
}
declare const KMSKeyNotAccessibleFault_base: S.TaggedErrorClass<"KMSKeyNotAccessibleFault", {
    readonly message: any;
}>;
export declare class KMSKeyNotAccessibleFault extends /*@__PURE__*/ KMSKeyNotAccessibleFault_base {
}
declare const KMSNotFoundFault_base: S.TaggedErrorClass<"KMSNotFoundFault", {
    readonly message: any;
}>;
export declare class KMSNotFoundFault extends /*@__PURE__*/ KMSNotFoundFault_base {
}
declare const KMSThrottlingFault_base: S.TaggedErrorClass<"KMSThrottlingFault", {
    readonly message: any;
}>;
export declare class KMSThrottlingFault extends /*@__PURE__*/ KMSThrottlingFault_base {
}
declare const ReplicationSubnetGroupDoesNotCoverEnoughAZs_base: S.TaggedErrorClass<"ReplicationSubnetGroupDoesNotCoverEnoughAZs", {
    readonly message: any;
}>;
export declare class ReplicationSubnetGroupDoesNotCoverEnoughAZs extends /*@__PURE__*/ ReplicationSubnetGroupDoesNotCoverEnoughAZs_base {
}
declare const ResourceAlreadyExistsFault_base: S.TaggedErrorClass<"ResourceAlreadyExistsFault", {
    readonly message: any;
    readonly resourceArn: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
});
export declare class ResourceAlreadyExistsFault extends /*@__PURE__*/ ResourceAlreadyExistsFault_base {
}
declare const ResourceNotFoundFault_base: S.TaggedErrorClass<"ResourceNotFoundFault", {
    readonly message: any;
}>;
export declare class ResourceNotFoundFault extends /*@__PURE__*/ ResourceNotFoundFault_base {
}
declare const ResourceQuotaExceededFault_base: S.TaggedErrorClass<"ResourceQuotaExceededFault", {
    readonly message: any;
}>;
export declare class ResourceQuotaExceededFault extends /*@__PURE__*/ ResourceQuotaExceededFault_base {
}
declare const S3AccessDeniedFault_base: S.TaggedErrorClass<"S3AccessDeniedFault", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class S3AccessDeniedFault extends /*@__PURE__*/ S3AccessDeniedFault_base {
}
declare const S3ResourceNotFoundFault_base: S.TaggedErrorClass<"S3ResourceNotFoundFault", {
    readonly message: any;
}>;
export declare class S3ResourceNotFoundFault extends /*@__PURE__*/ S3ResourceNotFoundFault_base {
}
declare const SNSInvalidTopicFault_base: S.TaggedErrorClass<"SNSInvalidTopicFault", {
    readonly message: any;
}>;
export declare class SNSInvalidTopicFault extends /*@__PURE__*/ SNSInvalidTopicFault_base {
}
declare const SNSNoAuthorizationFault_base: S.TaggedErrorClass<"SNSNoAuthorizationFault", {
    readonly message: any;
}>;
export declare class SNSNoAuthorizationFault extends /*@__PURE__*/ SNSNoAuthorizationFault_base {
}
declare const StorageQuotaExceededFault_base: S.TaggedErrorClass<"StorageQuotaExceededFault", {
    readonly message: any;
}>;
export declare class StorageQuotaExceededFault extends /*@__PURE__*/ StorageQuotaExceededFault_base {
}
declare const SubnetAlreadyInUse_base: S.TaggedErrorClass<"SubnetAlreadyInUse", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        DependencyViolationError: true;
    };
});
export declare class SubnetAlreadyInUse extends /*@__PURE__*/ SubnetAlreadyInUse_base {
}
declare const UpgradeDependencyFailureFault_base: S.TaggedErrorClass<"UpgradeDependencyFailureFault", {
    readonly message: any;
}>;
export declare class UpgradeDependencyFailureFault extends /*@__PURE__*/ UpgradeDependencyFailureFault_base {
}
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
    ResourceArn?: string | undefined;
}
export type TagList = Tag[];
export interface AddTagsToResourceMessage {
    ResourceArn: string;
    Tags: Tag[];
}
export interface AddTagsToResourceResponse {
}
export interface ApplyPendingMaintenanceActionMessage {
    ReplicationInstanceArn: string;
    ApplyAction: string;
    OptInType: string;
}
export interface PendingMaintenanceAction {
    Action?: string | undefined;
    AutoAppliedAfterDate?: Date | undefined;
    ForcedApplyDate?: Date | undefined;
    OptInStatus?: string | undefined;
    CurrentApplyDate?: Date | undefined;
    Description?: string | undefined;
}
export type PendingMaintenanceActionDetails = PendingMaintenanceAction[];
export interface ResourcePendingMaintenanceActions {
    ResourceIdentifier?: string | undefined;
    PendingMaintenanceActionDetails?: PendingMaintenanceAction[] | undefined;
}
export interface ApplyPendingMaintenanceActionResponse {
    ResourcePendingMaintenanceActions?: ResourcePendingMaintenanceActions | undefined;
}
export interface RecommendationSettings {
    InstanceSizingType: string;
    WorkloadType: string;
}
export interface StartRecommendationsRequestEntry {
    DatabaseId: string;
    Settings: RecommendationSettings;
}
export type StartRecommendationsRequestEntryList = StartRecommendationsRequestEntry[];
export interface BatchStartRecommendationsRequest {
    Data?: StartRecommendationsRequestEntry[] | undefined;
}
export interface BatchStartRecommendationsErrorEntry {
    DatabaseId?: string | undefined;
    Message?: string | undefined;
    Code?: string | undefined;
}
export type BatchStartRecommendationsErrorEntryList = BatchStartRecommendationsErrorEntry[];
export interface BatchStartRecommendationsResponse {
    ErrorEntries?: BatchStartRecommendationsErrorEntry[] | undefined;
}
export type MigrationProjectIdentifier = string;
export interface CancelMetadataModelConversionMessage {
    MigrationProjectIdentifier: string;
    RequestIdentifier: string;
}
export interface DefaultErrorDetails {
    Message?: string | undefined;
}
export type ErrorDetails = {
    defaultErrorDetails: DefaultErrorDetails;
};
export interface ExportSqlDetails {
    S3ObjectKey?: string | undefined;
    ObjectURL?: string | undefined;
}
export interface ProcessedObject {
    Name?: string | undefined;
    Type?: string | undefined;
    EndpointType?: string | undefined;
}
export interface Progress {
    ProgressPercent?: number | undefined;
    TotalObjects?: number | undefined;
    ProgressStep?: string | undefined;
    ProcessedObject?: ProcessedObject | undefined;
}
export interface SchemaConversionRequest {
    Status?: string | undefined;
    RequestIdentifier?: string | undefined;
    MigrationProjectArn?: string | undefined;
    Error?: ErrorDetails | undefined;
    ExportSqlDetails?: ExportSqlDetails | undefined;
    Progress?: Progress | undefined;
}
export interface CancelMetadataModelConversionResponse {
    Request?: SchemaConversionRequest | undefined;
}
export interface CancelMetadataModelCreationMessage {
    MigrationProjectIdentifier: string;
    RequestIdentifier: string;
}
export interface CancelMetadataModelCreationResponse {
    Request?: SchemaConversionRequest | undefined;
}
export interface CancelReplicationTaskAssessmentRunMessage {
    ReplicationTaskAssessmentRunArn: string;
}
export interface ReplicationTaskAssessmentRunProgress {
    IndividualAssessmentCount?: number | undefined;
    IndividualAssessmentCompletedCount?: number | undefined;
}
export interface ReplicationTaskAssessmentRunResultStatistic {
    Passed?: number | undefined;
    Failed?: number | undefined;
    Error?: number | undefined;
    Warning?: number | undefined;
    Cancelled?: number | undefined;
    Skipped?: number | undefined;
}
export interface ReplicationTaskAssessmentRun {
    ReplicationTaskAssessmentRunArn?: string | undefined;
    ReplicationTaskArn?: string | undefined;
    Status?: string | undefined;
    ReplicationTaskAssessmentRunCreationDate?: Date | undefined;
    AssessmentProgress?: ReplicationTaskAssessmentRunProgress | undefined;
    LastFailureMessage?: string | undefined;
    ServiceAccessRoleArn?: string | undefined;
    ResultLocationBucket?: string | undefined;
    ResultLocationFolder?: string | undefined;
    ResultEncryptionMode?: string | undefined;
    ResultKmsKeyArn?: string | undefined;
    AssessmentRunName?: string | undefined;
    IsLatestTaskAssessmentRun?: boolean | undefined;
    ResultStatistic?: ReplicationTaskAssessmentRunResultStatistic | undefined;
}
export interface CancelReplicationTaskAssessmentRunResponse {
    ReplicationTaskAssessmentRun?: ReplicationTaskAssessmentRun | undefined;
}
export type MigrationTypeValue = "full-load" | "cdc" | "full-load-and-cdc" | (string & {});
export type Iso8601DateTime = Date;
export interface SourceDataSetting {
    CDCStartPosition?: string | undefined;
    CDCStartTime?: Date | undefined;
    CDCStopTime?: Date | undefined;
    SlotName?: string | undefined;
}
export type SourceDataSettings = SourceDataSetting[];
export type TablePreparationMode = "do-nothing" | "truncate" | "drop-tables-on-target" | (string & {});
export interface TargetDataSetting {
    TablePreparationMode?: TablePreparationMode | undefined;
}
export type TargetDataSettings = TargetDataSetting[];
export type SecretString = string | redacted.Redacted<string>;
export interface CreateDataMigrationMessage {
    DataMigrationName?: string | undefined;
    MigrationProjectIdentifier: string;
    DataMigrationType: MigrationTypeValue;
    ServiceAccessRoleArn: string;
    EnableCloudwatchLogs?: boolean | undefined;
    SourceDataSettings?: SourceDataSetting[] | undefined;
    TargetDataSettings?: TargetDataSetting[] | undefined;
    NumberOfJobs?: number | undefined;
    Tags?: Tag[] | undefined;
    SelectionRules?: string | redacted.Redacted<string> | undefined;
}
export interface DataMigrationSettings {
    NumberOfJobs?: number | undefined;
    CloudwatchLogsEnabled?: boolean | undefined;
    SelectionRules?: string | redacted.Redacted<string> | undefined;
}
export interface DataMigrationStatistics {
    TablesLoaded?: number | undefined;
    ElapsedTimeMillis?: number | undefined;
    TablesLoading?: number | undefined;
    FullLoadPercentage?: number | undefined;
    CDCLatency?: number | undefined;
    TablesQueued?: number | undefined;
    TablesErrored?: number | undefined;
    StartTime?: Date | undefined;
    StopTime?: Date | undefined;
}
export type PublicIpAddressList = string[];
export type DataMigrationCidrBlock = string[];
export interface DataMigration {
    DataMigrationName?: string | undefined;
    DataMigrationArn?: string | undefined;
    DataMigrationCreateTime?: Date | undefined;
    DataMigrationStartTime?: Date | undefined;
    DataMigrationEndTime?: Date | undefined;
    ServiceAccessRoleArn?: string | undefined;
    MigrationProjectArn?: string | undefined;
    DataMigrationType?: MigrationTypeValue | undefined;
    DataMigrationSettings?: DataMigrationSettings | undefined;
    SourceDataSettings?: SourceDataSetting[] | undefined;
    TargetDataSettings?: TargetDataSetting[] | undefined;
    DataMigrationStatistics?: DataMigrationStatistics | undefined;
    DataMigrationStatus?: string | undefined;
    PublicIpAddresses?: string[] | undefined;
    DataMigrationCidrBlocks?: string[] | undefined;
    LastFailureMessage?: string | undefined;
    StopReason?: string | undefined;
}
export interface CreateDataMigrationResponse {
    DataMigration?: DataMigration | undefined;
}
export interface RedshiftDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export type DmsSslModeValue = "none" | "require" | "verify-ca" | "verify-full" | (string & {});
export interface PostgreSqlDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export interface MySqlDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export interface OracleDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    AsmServer?: string | undefined;
    SecretsManagerOracleAsmSecretId?: string | undefined;
    SecretsManagerOracleAsmAccessRoleArn?: string | undefined;
    SecretsManagerSecurityDbEncryptionSecretId?: string | undefined;
    SecretsManagerSecurityDbEncryptionAccessRoleArn?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export interface SybaseAseDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    EncryptPassword?: boolean | undefined;
    CertificateArn?: string | undefined;
}
export interface MicrosoftSqlServerDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export interface DocDbDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
}
export interface MariaDbDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export interface IbmDb2LuwDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    EncryptionAlgorithm?: number | undefined;
    SecurityMechanism?: number | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export interface IbmDb2zOsDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    S3Path?: string | undefined;
    S3AccessRoleArn?: string | undefined;
}
export type AuthTypeValue = "no" | "password" | (string & {});
export type AuthMechanismValue = "default" | "mongodb_cr" | "scram_sha_1" | (string & {});
export interface MongoDbDataProviderSettings {
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    CertificateArn?: string | undefined;
    AuthType?: AuthTypeValue | undefined;
    AuthSource?: string | undefined;
    AuthMechanism?: AuthMechanismValue | undefined;
}
export type DataProviderSettings = {
    RedshiftSettings: RedshiftDataProviderSettings;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings: PostgreSqlDataProviderSettings;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings: MySqlDataProviderSettings;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings: OracleDataProviderSettings;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings: SybaseAseDataProviderSettings;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings: MicrosoftSqlServerDataProviderSettings;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings: DocDbDataProviderSettings;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings: MariaDbDataProviderSettings;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings: IbmDb2LuwDataProviderSettings;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings: IbmDb2zOsDataProviderSettings;
    MongoDbSettings?: undefined;
} | {
    RedshiftSettings?: undefined;
    PostgreSqlSettings?: undefined;
    MySqlSettings?: undefined;
    OracleSettings?: undefined;
    SybaseAseSettings?: undefined;
    MicrosoftSqlServerSettings?: undefined;
    DocDbSettings?: undefined;
    MariaDbSettings?: undefined;
    IbmDb2LuwSettings?: undefined;
    IbmDb2zOsSettings?: undefined;
    MongoDbSettings: MongoDbDataProviderSettings;
};
export interface CreateDataProviderMessage {
    DataProviderName?: string | undefined;
    Description?: string | undefined;
    Engine: string;
    Virtual?: boolean | undefined;
    Settings: DataProviderSettings;
    Tags?: Tag[] | undefined;
}
export interface DataProvider {
    DataProviderName?: string | undefined;
    DataProviderArn?: string | undefined;
    DataProviderCreationTime?: Date | undefined;
    Description?: string | undefined;
    Engine?: string | undefined;
    Virtual?: boolean | undefined;
    Settings?: DataProviderSettings | undefined;
}
export interface CreateDataProviderResponse {
    DataProvider?: DataProvider | undefined;
}
export type ReplicationEndpointTypeValue = "source" | "target" | (string & {});
export interface DynamoDbSettings {
    ServiceAccessRoleArn: string;
}
export type CompressionTypeValue = "none" | "gzip" | (string & {});
export type EncryptionModeValue = "sse-s3" | "sse-kms" | (string & {});
export type DataFormatValue = "csv" | "parquet" | (string & {});
export type EncodingTypeValue = "plain" | "plain-dictionary" | "rle-dictionary" | (string & {});
export type ParquetVersionValue = "parquet-1-0" | "parquet-2-0" | (string & {});
export type DatePartitionSequenceValue = "YYYYMMDD" | "YYYYMMDDHH" | "YYYYMM" | "MMYYYYDD" | "DDMMYYYY" | (string & {});
export type DatePartitionDelimiterValue = "SLASH" | "UNDERSCORE" | "DASH" | "NONE" | (string & {});
export type CannedAclForObjectsValue = "none" | "private" | "public-read" | "public-read-write" | "authenticated-read" | "aws-exec-read" | "bucket-owner-read" | "bucket-owner-full-control" | (string & {});
export interface S3Settings {
    ServiceAccessRoleArn?: string | undefined;
    ExternalTableDefinition?: string | undefined;
    CsvRowDelimiter?: string | undefined;
    CsvDelimiter?: string | undefined;
    BucketFolder?: string | undefined;
    BucketName?: string | undefined;
    CompressionType?: CompressionTypeValue | undefined;
    EncryptionMode?: EncryptionModeValue | undefined;
    ServerSideEncryptionKmsKeyId?: string | undefined;
    DataFormat?: DataFormatValue | undefined;
    EncodingType?: EncodingTypeValue | undefined;
    DictPageSizeLimit?: number | undefined;
    RowGroupLength?: number | undefined;
    DataPageSize?: number | undefined;
    ParquetVersion?: ParquetVersionValue | undefined;
    EnableStatistics?: boolean | undefined;
    IncludeOpForFullLoad?: boolean | undefined;
    CdcInsertsOnly?: boolean | undefined;
    TimestampColumnName?: string | undefined;
    ParquetTimestampInMillisecond?: boolean | undefined;
    CdcInsertsAndUpdates?: boolean | undefined;
    DatePartitionEnabled?: boolean | undefined;
    DatePartitionSequence?: DatePartitionSequenceValue | undefined;
    DatePartitionDelimiter?: DatePartitionDelimiterValue | undefined;
    UseCsvNoSupValue?: boolean | undefined;
    CsvNoSupValue?: string | undefined;
    PreserveTransactions?: boolean | undefined;
    CdcPath?: string | undefined;
    UseTaskStartTimeForFullLoadTimestamp?: boolean | undefined;
    CannedAclForObjects?: CannedAclForObjectsValue | undefined;
    AddColumnName?: boolean | undefined;
    CdcMaxBatchInterval?: number | undefined;
    CdcMinFileSize?: number | undefined;
    CsvNullValue?: string | undefined;
    IgnoreHeaderRows?: number | undefined;
    MaxFileSize?: number | undefined;
    Rfc4180?: boolean | undefined;
    DatePartitionTimezone?: string | undefined;
    AddTrailingPaddingCharacter?: boolean | undefined;
    ExpectedBucketOwner?: string | undefined;
    GlueCatalogGeneration?: boolean | undefined;
}
export interface DmsTransferSettings {
    ServiceAccessRoleArn?: string | undefined;
    BucketName?: string | undefined;
}
export type NestingLevelValue = "none" | "one" | (string & {});
export interface MongoDbSettings {
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    AuthType?: AuthTypeValue | undefined;
    AuthMechanism?: AuthMechanismValue | undefined;
    NestingLevel?: NestingLevelValue | undefined;
    ExtractDocId?: string | undefined;
    DocsToInvestigate?: string | undefined;
    AuthSource?: string | undefined;
    KmsKeyId?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    UseUpdateLookUp?: boolean | undefined;
    ReplicateShardCollections?: boolean | undefined;
}
export type MessageFormatValue = "json" | "json-unformatted" | (string & {});
export interface KinesisSettings {
    StreamArn?: string | undefined;
    MessageFormat?: MessageFormatValue | undefined;
    ServiceAccessRoleArn?: string | undefined;
    IncludeTransactionDetails?: boolean | undefined;
    IncludePartitionValue?: boolean | undefined;
    PartitionIncludeSchemaTable?: boolean | undefined;
    IncludeTableAlterOperations?: boolean | undefined;
    IncludeControlDetails?: boolean | undefined;
    IncludeNullAndEmpty?: boolean | undefined;
    NoHexPrefix?: boolean | undefined;
    UseLargeIntegerValue?: boolean | undefined;
}
export type KafkaSecurityProtocol = "plaintext" | "ssl-authentication" | "ssl-encryption" | "sasl-ssl" | (string & {});
export type KafkaSaslMechanism = "scram-sha-512" | "plain" | (string & {});
export type KafkaSslEndpointIdentificationAlgorithm = "none" | "https" | (string & {});
export interface KafkaSettings {
    Broker?: string | undefined;
    Topic?: string | undefined;
    MessageFormat?: MessageFormatValue | undefined;
    IncludeTransactionDetails?: boolean | undefined;
    IncludePartitionValue?: boolean | undefined;
    PartitionIncludeSchemaTable?: boolean | undefined;
    IncludeTableAlterOperations?: boolean | undefined;
    IncludeControlDetails?: boolean | undefined;
    MessageMaxBytes?: number | undefined;
    IncludeNullAndEmpty?: boolean | undefined;
    SecurityProtocol?: KafkaSecurityProtocol | undefined;
    SslClientCertificateArn?: string | undefined;
    SslClientKeyArn?: string | undefined;
    SslClientKeyPassword?: string | redacted.Redacted<string> | undefined;
    SslCaCertificateArn?: string | undefined;
    SaslUsername?: string | undefined;
    SaslPassword?: string | redacted.Redacted<string> | undefined;
    NoHexPrefix?: boolean | undefined;
    SaslMechanism?: KafkaSaslMechanism | undefined;
    SslEndpointIdentificationAlgorithm?: KafkaSslEndpointIdentificationAlgorithm | undefined;
    UseLargeIntegerValue?: boolean | undefined;
}
export interface ElasticsearchSettings {
    ServiceAccessRoleArn: string;
    EndpointUri: string;
    FullLoadErrorPercentage?: number | undefined;
    ErrorRetryDuration?: number | undefined;
    UseNewMappingType?: boolean | undefined;
}
export interface NeptuneSettings {
    ServiceAccessRoleArn?: string | undefined;
    S3BucketName: string;
    S3BucketFolder: string;
    ErrorRetryDuration?: number | undefined;
    MaxFileSize?: number | undefined;
    MaxRetryCount?: number | undefined;
    IamAuthEnabled?: boolean | undefined;
}
export interface RedshiftSettings {
    AcceptAnyDate?: boolean | undefined;
    AfterConnectScript?: string | undefined;
    BucketFolder?: string | undefined;
    BucketName?: string | undefined;
    CaseSensitiveNames?: boolean | undefined;
    CompUpdate?: boolean | undefined;
    ConnectionTimeout?: number | undefined;
    DatabaseName?: string | undefined;
    DateFormat?: string | undefined;
    EmptyAsNull?: boolean | undefined;
    EncryptionMode?: EncryptionModeValue | undefined;
    ExplicitIds?: boolean | undefined;
    FileTransferUploadStreams?: number | undefined;
    LoadTimeout?: number | undefined;
    MaxFileSize?: number | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    RemoveQuotes?: boolean | undefined;
    ReplaceInvalidChars?: string | undefined;
    ReplaceChars?: string | undefined;
    ServerName?: string | undefined;
    ServiceAccessRoleArn?: string | undefined;
    ServerSideEncryptionKmsKeyId?: string | undefined;
    TimeFormat?: string | undefined;
    TrimBlanks?: boolean | undefined;
    TruncateColumns?: boolean | undefined;
    Username?: string | undefined;
    WriteBufferSize?: number | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    MapBooleanAsBoolean?: boolean | undefined;
}
export type PluginNameValue = "no-preference" | "test-decoding" | "pglogical" | (string & {});
export type LongVarcharMappingType = "wstring" | "clob" | "nclob" | (string & {});
export type DatabaseMode = "default" | "babelfish" | (string & {});
export type PostgreSQLAuthenticationMethod = "password" | "iam" | (string & {});
export interface PostgreSQLSettings {
    AfterConnectScript?: string | undefined;
    CaptureDdls?: boolean | undefined;
    MaxFileSize?: number | undefined;
    DatabaseName?: string | undefined;
    DdlArtifactsSchema?: string | undefined;
    ExecuteTimeout?: number | undefined;
    FailTasksOnLobTruncation?: boolean | undefined;
    HeartbeatEnable?: boolean | undefined;
    HeartbeatSchema?: string | undefined;
    HeartbeatFrequency?: number | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    ServerName?: string | undefined;
    Username?: string | undefined;
    SlotName?: string | undefined;
    PluginName?: PluginNameValue | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    TrimSpaceInChar?: boolean | undefined;
    MapBooleanAsBoolean?: boolean | undefined;
    MapJsonbAsClob?: boolean | undefined;
    MapLongVarcharAs?: LongVarcharMappingType | undefined;
    DatabaseMode?: DatabaseMode | undefined;
    BabelfishDatabaseName?: string | undefined;
    DisableUnicodeSourceFilter?: boolean | undefined;
    ServiceAccessRoleArn?: string | undefined;
    AuthenticationMethod?: PostgreSQLAuthenticationMethod | undefined;
}
export type TargetDbType = "specific-database" | "multiple-databases" | (string & {});
export type MySQLAuthenticationMethod = "password" | "iam" | (string & {});
export interface MySQLSettings {
    AfterConnectScript?: string | undefined;
    CleanSourceMetadataOnMismatch?: boolean | undefined;
    DatabaseName?: string | undefined;
    EventsPollInterval?: number | undefined;
    TargetDbType?: TargetDbType | undefined;
    MaxFileSize?: number | undefined;
    ParallelLoadThreads?: number | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    ServerName?: string | undefined;
    ServerTimezone?: string | undefined;
    Username?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    ExecuteTimeout?: number | undefined;
    ServiceAccessRoleArn?: string | undefined;
    AuthenticationMethod?: MySQLAuthenticationMethod | undefined;
}
export type IntegerList = number[];
export type CharLengthSemantics = "default" | "char" | "byte" | (string & {});
export type OracleAuthenticationMethod = "password" | "kerberos" | (string & {});
export interface OracleSettings {
    AddSupplementalLogging?: boolean | undefined;
    ArchivedLogDestId?: number | undefined;
    AdditionalArchivedLogDestId?: number | undefined;
    ExtraArchivedLogDestIds?: number[] | undefined;
    AllowSelectNestedTables?: boolean | undefined;
    ParallelAsmReadThreads?: number | undefined;
    ReadAheadBlocks?: number | undefined;
    AccessAlternateDirectly?: boolean | undefined;
    UseAlternateFolderForOnline?: boolean | undefined;
    OraclePathPrefix?: string | undefined;
    UsePathPrefix?: string | undefined;
    ReplacePathPrefix?: boolean | undefined;
    EnableHomogenousTablespace?: boolean | undefined;
    DirectPathNoLog?: boolean | undefined;
    ArchivedLogsOnly?: boolean | undefined;
    AsmPassword?: string | redacted.Redacted<string> | undefined;
    AsmServer?: string | undefined;
    AsmUser?: string | undefined;
    CharLengthSemantics?: CharLengthSemantics | undefined;
    DatabaseName?: string | undefined;
    DirectPathParallelLoad?: boolean | undefined;
    FailTasksOnLobTruncation?: boolean | undefined;
    NumberDatatypeScale?: number | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    ReadTableSpaceName?: boolean | undefined;
    RetryInterval?: number | undefined;
    SecurityDbEncryption?: string | redacted.Redacted<string> | undefined;
    SecurityDbEncryptionName?: string | undefined;
    ServerName?: string | undefined;
    SpatialDataOptionToGeoJsonFunctionName?: string | undefined;
    StandbyDelayTime?: number | undefined;
    Username?: string | undefined;
    UseBFile?: boolean | undefined;
    UseDirectPathFullLoad?: boolean | undefined;
    UseLogminerReader?: boolean | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    SecretsManagerOracleAsmAccessRoleArn?: string | undefined;
    SecretsManagerOracleAsmSecretId?: string | undefined;
    TrimSpaceInChar?: boolean | undefined;
    ConvertTimestampWithZoneToUTC?: boolean | undefined;
    OpenTransactionWindow?: number | undefined;
    AuthenticationMethod?: OracleAuthenticationMethod | undefined;
}
export interface SybaseSettings {
    DatabaseName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    ServerName?: string | undefined;
    Username?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
}
export type SafeguardPolicy = "rely-on-sql-server-replication-agent" | "exclusive-automatic-truncation" | "shared-automatic-truncation" | (string & {});
export type TlogAccessMode = "BackupOnly" | "PreferBackup" | "PreferTlog" | "TlogOnly" | (string & {});
export type SqlServerAuthenticationMethod = "password" | "kerberos" | (string & {});
export interface MicrosoftSQLServerSettings {
    Port?: number | undefined;
    BcpPacketSize?: number | undefined;
    DatabaseName?: string | undefined;
    ControlTablesFileGroup?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    QuerySingleAlwaysOnNode?: boolean | undefined;
    ReadBackupOnly?: boolean | undefined;
    SafeguardPolicy?: SafeguardPolicy | undefined;
    ServerName?: string | undefined;
    Username?: string | undefined;
    UseBcpFullLoad?: boolean | undefined;
    UseThirdPartyBackupDevice?: boolean | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    TrimSpaceInChar?: boolean | undefined;
    TlogAccessMode?: TlogAccessMode | undefined;
    ForceLobLookup?: boolean | undefined;
    AuthenticationMethod?: SqlServerAuthenticationMethod | undefined;
}
export interface IBMDb2Settings {
    DatabaseName?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    ServerName?: string | undefined;
    SetDataCaptureChanges?: boolean | undefined;
    CurrentLsn?: string | undefined;
    MaxKBytesPerRead?: number | undefined;
    Username?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    LoadTimeout?: number | undefined;
    WriteBufferSize?: number | undefined;
    MaxFileSize?: number | undefined;
    KeepCsvFiles?: boolean | undefined;
}
export interface DocDbSettings {
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    NestingLevel?: NestingLevelValue | undefined;
    ExtractDocId?: boolean | undefined;
    DocsToInvestigate?: number | undefined;
    KmsKeyId?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
    UseUpdateLookUp?: boolean | undefined;
    ReplicateShardCollections?: boolean | undefined;
}
export type SslSecurityProtocolValue = "plaintext" | "ssl-encryption" | (string & {});
export type RedisAuthTypeValue = "none" | "auth-role" | "auth-token" | (string & {});
export interface RedisSettings {
    ServerName: string;
    Port: number;
    SslSecurityProtocol?: SslSecurityProtocolValue | undefined;
    AuthType?: RedisAuthTypeValue | undefined;
    AuthUserName?: string | undefined;
    AuthPassword?: string | redacted.Redacted<string> | undefined;
    SslCaCertificateArn?: string | undefined;
}
export interface GcpMySQLSettings {
    AfterConnectScript?: string | undefined;
    CleanSourceMetadataOnMismatch?: boolean | undefined;
    DatabaseName?: string | undefined;
    EventsPollInterval?: number | undefined;
    TargetDbType?: TargetDbType | undefined;
    MaxFileSize?: number | undefined;
    ParallelLoadThreads?: number | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    Port?: number | undefined;
    ServerName?: string | undefined;
    ServerTimezone?: string | undefined;
    Username?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    SecretsManagerSecretId?: string | undefined;
}
export interface TimestreamSettings {
    DatabaseName: string;
    MemoryDuration: number;
    MagneticDuration: number;
    CdcInsertsAndUpdates?: boolean | undefined;
    EnableMagneticStoreWrites?: boolean | undefined;
}
export interface CreateEndpointMessage {
    EndpointIdentifier: string;
    EndpointType: ReplicationEndpointTypeValue;
    EngineName: string;
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    ExtraConnectionAttributes?: string | undefined;
    KmsKeyId?: string | undefined;
    Tags?: Tag[] | undefined;
    CertificateArn?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    ServiceAccessRoleArn?: string | undefined;
    ExternalTableDefinition?: string | undefined;
    DynamoDbSettings?: DynamoDbSettings | undefined;
    S3Settings?: S3Settings | undefined;
    DmsTransferSettings?: DmsTransferSettings | undefined;
    MongoDbSettings?: MongoDbSettings | undefined;
    KinesisSettings?: KinesisSettings | undefined;
    KafkaSettings?: KafkaSettings | undefined;
    ElasticsearchSettings?: ElasticsearchSettings | undefined;
    NeptuneSettings?: NeptuneSettings | undefined;
    RedshiftSettings?: RedshiftSettings | undefined;
    PostgreSQLSettings?: PostgreSQLSettings | undefined;
    MySQLSettings?: MySQLSettings | undefined;
    OracleSettings?: OracleSettings | undefined;
    SybaseSettings?: SybaseSettings | undefined;
    MicrosoftSQLServerSettings?: MicrosoftSQLServerSettings | undefined;
    IBMDb2Settings?: IBMDb2Settings | undefined;
    ResourceIdentifier?: string | undefined;
    DocDbSettings?: DocDbSettings | undefined;
    RedisSettings?: RedisSettings | undefined;
    GcpMySQLSettings?: GcpMySQLSettings | undefined;
    TimestreamSettings?: TimestreamSettings | undefined;
}
export interface LakehouseSettings {
    Arn: string;
}
export interface Endpoint {
    EndpointIdentifier?: string | undefined;
    EndpointType?: ReplicationEndpointTypeValue | undefined;
    EngineName?: string | undefined;
    EngineDisplayName?: string | undefined;
    Username?: string | undefined;
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    ExtraConnectionAttributes?: string | undefined;
    Status?: string | undefined;
    KmsKeyId?: string | undefined;
    EndpointArn?: string | undefined;
    CertificateArn?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    ServiceAccessRoleArn?: string | undefined;
    ExternalTableDefinition?: string | undefined;
    ExternalId?: string | undefined;
    IsReadOnly?: boolean | undefined;
    DynamoDbSettings?: DynamoDbSettings | undefined;
    S3Settings?: S3Settings | undefined;
    DmsTransferSettings?: DmsTransferSettings | undefined;
    MongoDbSettings?: MongoDbSettings | undefined;
    KinesisSettings?: KinesisSettings | undefined;
    KafkaSettings?: KafkaSettings | undefined;
    ElasticsearchSettings?: ElasticsearchSettings | undefined;
    NeptuneSettings?: NeptuneSettings | undefined;
    RedshiftSettings?: RedshiftSettings | undefined;
    PostgreSQLSettings?: PostgreSQLSettings | undefined;
    MySQLSettings?: MySQLSettings | undefined;
    OracleSettings?: OracleSettings | undefined;
    SybaseSettings?: SybaseSettings | undefined;
    MicrosoftSQLServerSettings?: MicrosoftSQLServerSettings | undefined;
    IBMDb2Settings?: IBMDb2Settings | undefined;
    DocDbSettings?: DocDbSettings | undefined;
    RedisSettings?: RedisSettings | undefined;
    GcpMySQLSettings?: GcpMySQLSettings | undefined;
    TimestreamSettings?: TimestreamSettings | undefined;
    LakehouseSettings?: LakehouseSettings | undefined;
}
export interface CreateEndpointResponse {
    Endpoint?: Endpoint | undefined;
}
export type EventCategoriesList = string[];
export type SourceIdsList = string[];
export interface CreateEventSubscriptionMessage {
    SubscriptionName: string;
    SnsTopicArn: string;
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
    SourceIds?: string[] | undefined;
    Enabled?: boolean | undefined;
    Tags?: Tag[] | undefined;
}
export interface EventSubscription {
    CustomerAwsId?: string | undefined;
    CustSubscriptionId?: string | undefined;
    SnsTopicArn?: string | undefined;
    Status?: string | undefined;
    SubscriptionCreationTime?: string | undefined;
    SourceType?: string | undefined;
    SourceIdsList?: string[] | undefined;
    EventCategoriesList?: string[] | undefined;
    Enabled?: boolean | undefined;
}
export interface CreateEventSubscriptionResponse {
    EventSubscription?: EventSubscription | undefined;
}
export interface CreateFleetAdvisorCollectorRequest {
    CollectorName: string;
    Description?: string | undefined;
    ServiceAccessRoleArn: string;
    S3BucketName: string;
}
export interface CreateFleetAdvisorCollectorResponse {
    CollectorReferencedId?: string | undefined;
    CollectorName?: string | undefined;
    Description?: string | undefined;
    ServiceAccessRoleArn?: string | undefined;
    S3BucketName?: string | undefined;
}
export type StringList = string[];
export interface CreateInstanceProfileMessage {
    AvailabilityZone?: string | undefined;
    KmsKeyArn?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    Tags?: Tag[] | undefined;
    NetworkType?: string | undefined;
    InstanceProfileName?: string | undefined;
    Description?: string | undefined;
    SubnetGroupIdentifier?: string | undefined;
    VpcSecurityGroups?: string[] | undefined;
}
export interface InstanceProfile {
    InstanceProfileArn?: string | undefined;
    AvailabilityZone?: string | undefined;
    KmsKeyArn?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    NetworkType?: string | undefined;
    InstanceProfileName?: string | undefined;
    Description?: string | undefined;
    InstanceProfileCreationTime?: Date | undefined;
    SubnetGroupIdentifier?: string | undefined;
    VpcSecurityGroups?: string[] | undefined;
}
export interface CreateInstanceProfileResponse {
    InstanceProfile?: InstanceProfile | undefined;
}
export interface DataProviderDescriptorDefinition {
    DataProviderIdentifier: string;
    SecretsManagerSecretId?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
}
export type DataProviderDescriptorDefinitionList = DataProviderDescriptorDefinition[];
export interface SCApplicationAttributes {
    S3BucketPath?: string | undefined;
    S3BucketRoleArn?: string | undefined;
}
export interface CreateMigrationProjectMessage {
    MigrationProjectName?: string | undefined;
    SourceDataProviderDescriptors: DataProviderDescriptorDefinition[];
    TargetDataProviderDescriptors: DataProviderDescriptorDefinition[];
    InstanceProfileIdentifier: string;
    TransformationRules?: string | undefined;
    Description?: string | undefined;
    Tags?: Tag[] | undefined;
    SchemaConversionApplicationAttributes?: SCApplicationAttributes | undefined;
}
export interface DataProviderDescriptor {
    SecretsManagerSecretId?: string | undefined;
    SecretsManagerAccessRoleArn?: string | undefined;
    DataProviderName?: string | undefined;
    DataProviderArn?: string | undefined;
}
export type DataProviderDescriptorList = DataProviderDescriptor[];
export interface MigrationProject {
    MigrationProjectName?: string | undefined;
    MigrationProjectArn?: string | undefined;
    MigrationProjectCreationTime?: Date | undefined;
    SourceDataProviderDescriptors?: DataProviderDescriptor[] | undefined;
    TargetDataProviderDescriptors?: DataProviderDescriptor[] | undefined;
    InstanceProfileArn?: string | undefined;
    InstanceProfileName?: string | undefined;
    TransformationRules?: string | undefined;
    Description?: string | undefined;
    SchemaConversionApplicationAttributes?: SCApplicationAttributes | undefined;
}
export interface CreateMigrationProjectResponse {
    MigrationProject?: MigrationProject | undefined;
}
export interface ComputeConfig {
    AvailabilityZone?: string | undefined;
    DnsNameServers?: string | undefined;
    KmsKeyId?: string | undefined;
    MaxCapacityUnits?: number | undefined;
    MinCapacityUnits?: number | undefined;
    MultiAZ?: boolean | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    ReplicationSubnetGroupId?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
}
export interface CreateReplicationConfigMessage {
    ReplicationConfigIdentifier: string;
    SourceEndpointArn: string;
    TargetEndpointArn: string;
    ComputeConfig: ComputeConfig;
    ReplicationType: MigrationTypeValue;
    TableMappings: string;
    ReplicationSettings?: string | undefined;
    SupplementalSettings?: string | undefined;
    ResourceIdentifier?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface ReplicationConfig {
    ReplicationConfigIdentifier?: string | undefined;
    ReplicationConfigArn?: string | undefined;
    SourceEndpointArn?: string | undefined;
    TargetEndpointArn?: string | undefined;
    ReplicationType?: MigrationTypeValue | undefined;
    ComputeConfig?: ComputeConfig | undefined;
    ReplicationSettings?: string | undefined;
    SupplementalSettings?: string | undefined;
    TableMappings?: string | undefined;
    ReplicationConfigCreateTime?: Date | undefined;
    ReplicationConfigUpdateTime?: Date | undefined;
    IsReadOnly?: boolean | undefined;
}
export interface CreateReplicationConfigResponse {
    ReplicationConfig?: ReplicationConfig | undefined;
}
export type ReplicationInstanceClass = string;
export type VpcSecurityGroupIdList = string[];
export interface KerberosAuthenticationSettings {
    KeyCacheSecretId?: string | undefined;
    KeyCacheSecretIamArn?: string | undefined;
    Krb5FileContents?: string | undefined;
}
export interface CreateReplicationInstanceMessage {
    ReplicationInstanceIdentifier: string;
    AllocatedStorage?: number | undefined;
    ReplicationInstanceClass: string;
    VpcSecurityGroupIds?: string[] | undefined;
    AvailabilityZone?: string | undefined;
    ReplicationSubnetGroupIdentifier?: string | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    DnsNameServers?: string | undefined;
    ResourceIdentifier?: string | undefined;
    NetworkType?: string | undefined;
    KerberosAuthenticationSettings?: KerberosAuthenticationSettings | undefined;
}
export interface VpcSecurityGroupMembership {
    VpcSecurityGroupId?: string | undefined;
    Status?: string | undefined;
}
export type VpcSecurityGroupMembershipList = VpcSecurityGroupMembership[];
export interface AvailabilityZone {
    Name?: string | undefined;
}
export interface Subnet {
    SubnetIdentifier?: string | undefined;
    SubnetAvailabilityZone?: AvailabilityZone | undefined;
    SubnetStatus?: string | undefined;
}
export type SubnetList = Subnet[];
export interface ReplicationSubnetGroup {
    ReplicationSubnetGroupIdentifier?: string | undefined;
    ReplicationSubnetGroupDescription?: string | undefined;
    VpcId?: string | undefined;
    SubnetGroupStatus?: string | undefined;
    Subnets?: Subnet[] | undefined;
    SupportedNetworkTypes?: string[] | undefined;
    IsReadOnly?: boolean | undefined;
}
export interface ReplicationPendingModifiedValues {
    ReplicationInstanceClass?: string | undefined;
    AllocatedStorage?: number | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    NetworkType?: string | undefined;
}
export type ReplicationInstancePublicIpAddressList = string[];
export type ReplicationInstancePrivateIpAddressList = string[];
export type ReplicationInstanceIpv6AddressList = string[];
export interface ReplicationInstance {
    ReplicationInstanceIdentifier?: string | undefined;
    ReplicationInstanceClass?: string | undefined;
    ReplicationInstanceStatus?: string | undefined;
    AllocatedStorage?: number | undefined;
    InstanceCreateTime?: Date | undefined;
    VpcSecurityGroups?: VpcSecurityGroupMembership[] | undefined;
    AvailabilityZone?: string | undefined;
    ReplicationSubnetGroup?: ReplicationSubnetGroup | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    PendingModifiedValues?: ReplicationPendingModifiedValues | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    KmsKeyId?: string | undefined;
    ReplicationInstanceArn?: string | undefined;
    ReplicationInstancePublicIpAddress?: string | undefined;
    ReplicationInstancePrivateIpAddress?: string | undefined;
    ReplicationInstancePublicIpAddresses?: string[] | undefined;
    ReplicationInstancePrivateIpAddresses?: string[] | undefined;
    ReplicationInstanceIpv6Addresses?: string[] | undefined;
    PubliclyAccessible?: boolean | undefined;
    SecondaryAvailabilityZone?: string | undefined;
    FreeUntil?: Date | undefined;
    DnsNameServers?: string | undefined;
    NetworkType?: string | undefined;
    KerberosAuthenticationSettings?: KerberosAuthenticationSettings | undefined;
}
export interface CreateReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance | undefined;
}
export type SubnetIdentifierList = string[];
export interface CreateReplicationSubnetGroupMessage {
    ReplicationSubnetGroupIdentifier: string;
    ReplicationSubnetGroupDescription: string;
    SubnetIds: string[];
    Tags?: Tag[] | undefined;
}
export interface CreateReplicationSubnetGroupResponse {
    ReplicationSubnetGroup?: ReplicationSubnetGroup | undefined;
}
export interface CreateReplicationTaskMessage {
    ReplicationTaskIdentifier: string;
    SourceEndpointArn: string;
    TargetEndpointArn: string;
    ReplicationInstanceArn: string;
    MigrationType: MigrationTypeValue;
    TableMappings: string;
    ReplicationTaskSettings?: string | undefined;
    CdcStartTime?: Date | undefined;
    CdcStartPosition?: string | undefined;
    CdcStopPosition?: string | undefined;
    Tags?: Tag[] | undefined;
    TaskData?: string | undefined;
    ResourceIdentifier?: string | undefined;
}
export interface ReplicationTaskStats {
    FullLoadProgressPercent?: number | undefined;
    ElapsedTimeMillis?: number | undefined;
    TablesLoaded?: number | undefined;
    TablesLoading?: number | undefined;
    TablesQueued?: number | undefined;
    TablesErrored?: number | undefined;
    FreshStartDate?: Date | undefined;
    StartDate?: Date | undefined;
    StopDate?: Date | undefined;
    FullLoadStartDate?: Date | undefined;
    FullLoadFinishDate?: Date | undefined;
}
export interface ReplicationTask {
    ReplicationTaskIdentifier?: string | undefined;
    SourceEndpointArn?: string | undefined;
    TargetEndpointArn?: string | undefined;
    ReplicationInstanceArn?: string | undefined;
    MigrationType?: MigrationTypeValue | undefined;
    TableMappings?: string | undefined;
    ReplicationTaskSettings?: string | undefined;
    Status?: string | undefined;
    LastFailureMessage?: string | undefined;
    StopReason?: string | undefined;
    ReplicationTaskCreationDate?: Date | undefined;
    ReplicationTaskStartDate?: Date | undefined;
    CdcStartPosition?: string | undefined;
    CdcStopPosition?: string | undefined;
    RecoveryCheckpoint?: string | undefined;
    ReplicationTaskArn?: string | undefined;
    ReplicationTaskStats?: ReplicationTaskStats | undefined;
    TaskData?: string | undefined;
    TargetReplicationInstanceArn?: string | undefined;
}
export interface CreateReplicationTaskResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export interface DeleteCertificateMessage {
    CertificateArn: string;
}
export type CertificateWallet = Uint8Array;
export interface Certificate {
    CertificateIdentifier?: string | undefined;
    CertificateCreationDate?: Date | undefined;
    CertificatePem?: string | undefined;
    CertificateWallet?: Uint8Array | undefined;
    CertificateArn?: string | undefined;
    CertificateOwner?: string | undefined;
    ValidFromDate?: Date | undefined;
    ValidToDate?: Date | undefined;
    SigningAlgorithm?: string | undefined;
    KeyLength?: number | undefined;
    KmsKeyId?: string | undefined;
}
export interface DeleteCertificateResponse {
    Certificate?: Certificate | undefined;
}
export interface DeleteConnectionMessage {
    EndpointArn: string;
    ReplicationInstanceArn: string;
}
export interface Connection {
    ReplicationInstanceArn?: string | undefined;
    EndpointArn?: string | undefined;
    Status?: string | undefined;
    LastFailureMessage?: string | undefined;
    EndpointIdentifier?: string | undefined;
    ReplicationInstanceIdentifier?: string | undefined;
}
export interface DeleteConnectionResponse {
    Connection?: Connection | undefined;
}
export interface DeleteDataMigrationMessage {
    DataMigrationIdentifier: string;
}
export interface DeleteDataMigrationResponse {
    DataMigration?: DataMigration | undefined;
}
export interface DeleteDataProviderMessage {
    DataProviderIdentifier: string;
}
export interface DeleteDataProviderResponse {
    DataProvider?: DataProvider | undefined;
}
export interface DeleteEndpointMessage {
    EndpointArn: string;
}
export interface DeleteEndpointResponse {
    Endpoint?: Endpoint | undefined;
}
export interface DeleteEventSubscriptionMessage {
    SubscriptionName: string;
}
export interface DeleteEventSubscriptionResponse {
    EventSubscription?: EventSubscription | undefined;
}
export interface DeleteCollectorRequest {
    CollectorReferencedId: string;
}
export interface DeleteFleetAdvisorCollectorResponse {
}
export interface DeleteFleetAdvisorDatabasesRequest {
    DatabaseIds: string[];
}
export interface DeleteFleetAdvisorDatabasesResponse {
    DatabaseIds?: string[] | undefined;
}
export interface DeleteInstanceProfileMessage {
    InstanceProfileIdentifier: string;
}
export interface DeleteInstanceProfileResponse {
    InstanceProfile?: InstanceProfile | undefined;
}
export interface DeleteMigrationProjectMessage {
    MigrationProjectIdentifier: string;
}
export interface DeleteMigrationProjectResponse {
    MigrationProject?: MigrationProject | undefined;
}
export interface DeleteReplicationConfigMessage {
    ReplicationConfigArn: string;
}
export interface DeleteReplicationConfigResponse {
    ReplicationConfig?: ReplicationConfig | undefined;
}
export interface DeleteReplicationInstanceMessage {
    ReplicationInstanceArn: string;
}
export interface DeleteReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance | undefined;
}
export interface DeleteReplicationSubnetGroupMessage {
    ReplicationSubnetGroupIdentifier: string;
}
export interface DeleteReplicationSubnetGroupResponse {
}
export interface DeleteReplicationTaskMessage {
    ReplicationTaskArn: string;
}
export interface DeleteReplicationTaskResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export interface DeleteReplicationTaskAssessmentRunMessage {
    ReplicationTaskAssessmentRunArn: string;
}
export interface DeleteReplicationTaskAssessmentRunResponse {
    ReplicationTaskAssessmentRun?: ReplicationTaskAssessmentRun | undefined;
}
export interface DescribeAccountAttributesMessage {
}
export interface AccountQuota {
    AccountQuotaName?: string | undefined;
    Used?: number | undefined;
    Max?: number | undefined;
}
export type AccountQuotaList = AccountQuota[];
export interface DescribeAccountAttributesResponse {
    AccountQuotas?: AccountQuota[] | undefined;
    UniqueAccountIdentifier?: string | undefined;
}
export interface DescribeApplicableIndividualAssessmentsMessage {
    ReplicationTaskArn?: string | undefined;
    ReplicationInstanceArn?: string | undefined;
    ReplicationConfigArn?: string | undefined;
    SourceEngineName?: string | undefined;
    TargetEngineName?: string | undefined;
    MigrationType?: MigrationTypeValue | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type IndividualAssessmentNameList = string[];
export interface DescribeApplicableIndividualAssessmentsResponse {
    IndividualAssessmentNames?: string[] | undefined;
    Marker?: string | undefined;
}
export type FilterValueList = string[];
export interface Filter {
    Name: string;
    Values: string[];
}
export type FilterList = Filter[];
export interface DescribeCertificatesMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type CertificateList = Certificate[];
export interface DescribeCertificatesResponse {
    Marker?: string | undefined;
    Certificates?: Certificate[] | undefined;
}
export interface DescribeConnectionsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ConnectionList = Connection[];
export interface DescribeConnectionsResponse {
    Marker?: string | undefined;
    Connections?: Connection[] | undefined;
}
export interface DescribeConversionConfigurationMessage {
    MigrationProjectIdentifier: string;
}
export interface DescribeConversionConfigurationResponse {
    MigrationProjectIdentifier?: string | undefined;
    ConversionConfiguration?: string | undefined;
}
export type Marker = string;
export interface DescribeDataMigrationsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    WithoutSettings?: boolean | undefined;
    WithoutStatistics?: boolean | undefined;
}
export type DataMigrations = DataMigration[];
export interface DescribeDataMigrationsResponse {
    DataMigrations?: DataMigration[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeDataProvidersMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type DataProviderList = DataProvider[];
export interface DescribeDataProvidersResponse {
    Marker?: string | undefined;
    DataProviders?: DataProvider[] | undefined;
}
export interface DescribeEndpointsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type EndpointList = Endpoint[];
export interface DescribeEndpointsResponse {
    Marker?: string | undefined;
    Endpoints?: Endpoint[] | undefined;
}
export interface DescribeEndpointSettingsMessage {
    EngineName: string;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type EndpointSettingTypeValue = "string" | "boolean" | "integer" | "enum" | (string & {});
export type EndpointSettingEnumValues = string[];
export interface EndpointSetting {
    Name?: string | undefined;
    Type?: EndpointSettingTypeValue | undefined;
    EnumValues?: string[] | undefined;
    Sensitive?: boolean | undefined;
    Units?: string | undefined;
    Applicability?: string | undefined;
    IntValueMin?: number | undefined;
    IntValueMax?: number | undefined;
    DefaultValue?: string | undefined;
}
export type EndpointSettingsList = EndpointSetting[];
export interface DescribeEndpointSettingsResponse {
    Marker?: string | undefined;
    EndpointSettings?: EndpointSetting[] | undefined;
}
export interface DescribeEndpointTypesMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface SupportedEndpointType {
    EngineName?: string | undefined;
    SupportsCDC?: boolean | undefined;
    EndpointType?: ReplicationEndpointTypeValue | undefined;
    ReplicationInstanceEngineMinimumVersion?: string | undefined;
    EngineDisplayName?: string | undefined;
}
export type SupportedEndpointTypeList = SupportedEndpointType[];
export interface DescribeEndpointTypesResponse {
    Marker?: string | undefined;
    SupportedEndpointTypes?: SupportedEndpointType[] | undefined;
}
export interface DescribeEngineVersionsMessage {
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ReleaseStatusValues = "beta" | "prod" | (string & {});
export type AvailableUpgradesList = string[];
export interface EngineVersion {
    Version?: string | undefined;
    Lifecycle?: string | undefined;
    ReleaseStatus?: ReleaseStatusValues | undefined;
    LaunchDate?: Date | undefined;
    AutoUpgradeDate?: Date | undefined;
    DeprecationDate?: Date | undefined;
    ForceUpgradeDate?: Date | undefined;
    AvailableUpgrades?: string[] | undefined;
}
export type EngineVersionList = EngineVersion[];
export interface DescribeEngineVersionsResponse {
    EngineVersions?: EngineVersion[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeEventCategoriesMessage {
    SourceType?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface EventCategoryGroup {
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
}
export type EventCategoryGroupList = EventCategoryGroup[];
export interface DescribeEventCategoriesResponse {
    EventCategoryGroupList?: EventCategoryGroup[] | undefined;
}
export type SourceType = "replication-instance" | (string & {});
export interface DescribeEventsMessage {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Duration?: number | undefined;
    EventCategories?: string[] | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface Event {
    SourceIdentifier?: string | undefined;
    SourceType?: SourceType | undefined;
    Message?: string | undefined;
    EventCategories?: string[] | undefined;
    Date?: Date | undefined;
}
export type EventList = Event[];
export interface DescribeEventsResponse {
    Marker?: string | undefined;
    Events?: Event[] | undefined;
}
export interface DescribeEventSubscriptionsMessage {
    SubscriptionName?: string | undefined;
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type EventSubscriptionsList = EventSubscription[];
export interface DescribeEventSubscriptionsResponse {
    Marker?: string | undefined;
    EventSubscriptionsList?: EventSubscription[] | undefined;
}
export interface DescribeExtensionPackAssociationsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type SchemaConversionRequestList = SchemaConversionRequest[];
export interface DescribeExtensionPackAssociationsResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeFleetAdvisorCollectorsRequest {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export type VersionStatus = "UP_TO_DATE" | "OUTDATED" | "UNSUPPORTED" | (string & {});
export type CollectorStatus = "UNREGISTERED" | "ACTIVE" | (string & {});
export interface CollectorHealthCheck {
    CollectorStatus?: CollectorStatus | undefined;
    LocalCollectorS3Access?: boolean | undefined;
    WebCollectorS3Access?: boolean | undefined;
    WebCollectorGrantedRoleBasedAccess?: boolean | undefined;
}
export interface InventoryData {
    NumberOfDatabases?: number | undefined;
    NumberOfSchemas?: number | undefined;
}
export interface CollectorResponse {
    CollectorReferencedId?: string | undefined;
    CollectorName?: string | undefined;
    CollectorVersion?: string | undefined;
    VersionStatus?: VersionStatus | undefined;
    Description?: string | undefined;
    S3BucketName?: string | undefined;
    ServiceAccessRoleArn?: string | undefined;
    CollectorHealthCheck?: CollectorHealthCheck | undefined;
    LastDataReceived?: string | undefined;
    RegisteredDate?: string | undefined;
    CreatedDate?: string | undefined;
    ModifiedDate?: string | undefined;
    InventoryData?: InventoryData | undefined;
}
export type CollectorResponses = CollectorResponse[];
export interface DescribeFleetAdvisorCollectorsResponse {
    Collectors?: CollectorResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFleetAdvisorDatabasesRequest {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface ServerShortInfoResponse {
    ServerId?: string | undefined;
    IpAddress?: string | undefined;
    ServerName?: string | undefined;
}
export interface DatabaseInstanceSoftwareDetailsResponse {
    Engine?: string | undefined;
    EngineVersion?: string | undefined;
    EngineEdition?: string | undefined;
    ServicePack?: string | undefined;
    SupportLevel?: string | undefined;
    OsArchitecture?: number | undefined;
    Tooltip?: string | undefined;
}
export interface CollectorShortInfoResponse {
    CollectorReferencedId?: string | undefined;
    CollectorName?: string | undefined;
}
export type CollectorsList = CollectorShortInfoResponse[];
export interface DatabaseResponse {
    DatabaseId?: string | undefined;
    DatabaseName?: string | undefined;
    IpAddress?: string | undefined;
    NumberOfSchemas?: number | undefined;
    Server?: ServerShortInfoResponse | undefined;
    SoftwareDetails?: DatabaseInstanceSoftwareDetailsResponse | undefined;
    Collectors?: CollectorShortInfoResponse[] | undefined;
}
export type DatabaseList = DatabaseResponse[];
export interface DescribeFleetAdvisorDatabasesResponse {
    Databases?: DatabaseResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFleetAdvisorLsaAnalysisRequest {
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface FleetAdvisorLsaAnalysisResponse {
    LsaAnalysisId?: string | undefined;
    Status?: string | undefined;
}
export type FleetAdvisorLsaAnalysisResponseList = FleetAdvisorLsaAnalysisResponse[];
export interface DescribeFleetAdvisorLsaAnalysisResponse {
    Analysis?: FleetAdvisorLsaAnalysisResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFleetAdvisorSchemaObjectSummaryRequest {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface FleetAdvisorSchemaObjectResponse {
    SchemaId?: string | undefined;
    ObjectType?: string | undefined;
    NumberOfObjects?: number | undefined;
    CodeLineCount?: number | undefined;
    CodeSize?: number | undefined;
}
export type FleetAdvisorSchemaObjectList = FleetAdvisorSchemaObjectResponse[];
export interface DescribeFleetAdvisorSchemaObjectSummaryResponse {
    FleetAdvisorSchemaObjects?: FleetAdvisorSchemaObjectResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeFleetAdvisorSchemasRequest {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface DatabaseShortInfoResponse {
    DatabaseId?: string | undefined;
    DatabaseName?: string | undefined;
    DatabaseIpAddress?: string | undefined;
    DatabaseEngine?: string | undefined;
}
export interface SchemaShortInfoResponse {
    SchemaId?: string | undefined;
    SchemaName?: string | undefined;
    DatabaseId?: string | undefined;
    DatabaseName?: string | undefined;
    DatabaseIpAddress?: string | undefined;
}
export interface SchemaResponse {
    CodeLineCount?: number | undefined;
    CodeSize?: number | undefined;
    Complexity?: string | undefined;
    Server?: ServerShortInfoResponse | undefined;
    DatabaseInstance?: DatabaseShortInfoResponse | undefined;
    SchemaId?: string | undefined;
    SchemaName?: string | undefined;
    OriginalSchema?: SchemaShortInfoResponse | undefined;
    Similarity?: number | undefined;
}
export type FleetAdvisorSchemaList = SchemaResponse[];
export interface DescribeFleetAdvisorSchemasResponse {
    FleetAdvisorSchemas?: SchemaResponse[] | undefined;
    NextToken?: string | undefined;
}
export interface DescribeInstanceProfilesMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type InstanceProfileList = InstanceProfile[];
export interface DescribeInstanceProfilesResponse {
    Marker?: string | undefined;
    InstanceProfiles?: InstanceProfile[] | undefined;
}
export type OriginTypeValue = "SOURCE" | "TARGET" | (string & {});
export interface DescribeMetadataModelMessage {
    SelectionRules: string;
    MigrationProjectIdentifier: string;
    Origin: OriginTypeValue;
}
export interface MetadataModelReference {
    MetadataModelName?: string | undefined;
    SelectionRules?: string | undefined;
}
export type MetadataModelReferenceList = MetadataModelReference[];
export interface DescribeMetadataModelResponse {
    MetadataModelName?: string | undefined;
    MetadataModelType?: string | undefined;
    TargetMetadataModels?: MetadataModelReference[] | undefined;
    Definition?: string | undefined;
}
export interface DescribeMetadataModelAssessmentsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface DescribeMetadataModelAssessmentsResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeMetadataModelChildrenMessage {
    SelectionRules: string;
    MigrationProjectIdentifier: string;
    Origin: OriginTypeValue;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface DescribeMetadataModelChildrenResponse {
    Marker?: string | undefined;
    MetadataModelChildren?: MetadataModelReference[] | undefined;
}
export interface DescribeMetadataModelConversionsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface DescribeMetadataModelConversionsResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeMetadataModelCreationsMessage {
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
    MigrationProjectIdentifier: string;
}
export interface DescribeMetadataModelCreationsResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeMetadataModelExportsAsScriptMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface DescribeMetadataModelExportsAsScriptResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeMetadataModelExportsToTargetMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface DescribeMetadataModelExportsToTargetResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeMetadataModelImportsMessage {
    MigrationProjectIdentifier: string;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export interface DescribeMetadataModelImportsResponse {
    Marker?: string | undefined;
    Requests?: SchemaConversionRequest[] | undefined;
}
export interface DescribeMigrationProjectsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type MigrationProjectList = MigrationProject[];
export interface DescribeMigrationProjectsResponse {
    Marker?: string | undefined;
    MigrationProjects?: MigrationProject[] | undefined;
}
export interface DescribeOrderableReplicationInstancesMessage {
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type AvailabilityZonesList = string[];
export interface OrderableReplicationInstance {
    EngineVersion?: string | undefined;
    ReplicationInstanceClass?: string | undefined;
    StorageType?: string | undefined;
    MinAllocatedStorage?: number | undefined;
    MaxAllocatedStorage?: number | undefined;
    DefaultAllocatedStorage?: number | undefined;
    IncludedAllocatedStorage?: number | undefined;
    AvailabilityZones?: string[] | undefined;
    ReleaseStatus?: ReleaseStatusValues | undefined;
}
export type OrderableReplicationInstanceList = OrderableReplicationInstance[];
export interface DescribeOrderableReplicationInstancesResponse {
    OrderableReplicationInstances?: OrderableReplicationInstance[] | undefined;
    Marker?: string | undefined;
}
export interface DescribePendingMaintenanceActionsMessage {
    ReplicationInstanceArn?: string | undefined;
    Filters?: Filter[] | undefined;
    Marker?: string | undefined;
    MaxRecords?: number | undefined;
}
export type PendingMaintenanceActions = ResourcePendingMaintenanceActions[];
export interface DescribePendingMaintenanceActionsResponse {
    PendingMaintenanceActions?: ResourcePendingMaintenanceActions[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeRecommendationLimitationsRequest {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface Limitation {
    DatabaseId?: string | undefined;
    EngineName?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    Impact?: string | undefined;
    Type?: string | undefined;
}
export type LimitationList = Limitation[];
export interface DescribeRecommendationLimitationsResponse {
    NextToken?: string | undefined;
    Limitations?: Limitation[] | undefined;
}
export interface DescribeRecommendationsRequest {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    NextToken?: string | undefined;
}
export interface RdsRequirements {
    EngineEdition?: string | undefined;
    InstanceVcpu?: number | undefined;
    InstanceMemory?: number | undefined;
    StorageSize?: number | undefined;
    StorageIops?: number | undefined;
    DeploymentOption?: string | undefined;
    EngineVersion?: string | undefined;
}
export interface RdsConfiguration {
    EngineEdition?: string | undefined;
    InstanceType?: string | undefined;
    InstanceVcpu?: number | undefined;
    InstanceMemory?: number | undefined;
    StorageType?: string | undefined;
    StorageSize?: number | undefined;
    StorageIops?: number | undefined;
    DeploymentOption?: string | undefined;
    EngineVersion?: string | undefined;
}
export interface RdsRecommendation {
    RequirementsToTarget?: RdsRequirements | undefined;
    TargetConfiguration?: RdsConfiguration | undefined;
}
export interface RecommendationData {
    RdsEngine?: RdsRecommendation | undefined;
}
export interface Recommendation {
    DatabaseId?: string | undefined;
    EngineName?: string | undefined;
    CreatedDate?: string | undefined;
    Status?: string | undefined;
    Preferred?: boolean | undefined;
    Settings?: RecommendationSettings | undefined;
    Data?: RecommendationData | undefined;
}
export type RecommendationList = Recommendation[];
export interface DescribeRecommendationsResponse {
    NextToken?: string | undefined;
    Recommendations?: Recommendation[] | undefined;
}
export interface DescribeRefreshSchemasStatusMessage {
    EndpointArn: string;
}
export type RefreshSchemasStatusTypeValue = "successful" | "failed" | "refreshing" | (string & {});
export interface RefreshSchemasStatus {
    EndpointArn?: string | undefined;
    ReplicationInstanceArn?: string | undefined;
    Status?: RefreshSchemasStatusTypeValue | undefined;
    LastRefreshDate?: Date | undefined;
    LastFailureMessage?: string | undefined;
}
export interface DescribeRefreshSchemasStatusResponse {
    RefreshSchemasStatus?: RefreshSchemasStatus | undefined;
}
export interface DescribeReplicationConfigsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ReplicationConfigList = ReplicationConfig[];
export interface DescribeReplicationConfigsResponse {
    Marker?: string | undefined;
    ReplicationConfigs?: ReplicationConfig[] | undefined;
}
export interface DescribeReplicationInstancesMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ReplicationInstanceList = ReplicationInstance[];
export interface DescribeReplicationInstancesResponse {
    Marker?: string | undefined;
    ReplicationInstances?: ReplicationInstance[] | undefined;
}
export interface DescribeReplicationInstanceTaskLogsMessage {
    ReplicationInstanceArn: string;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ReplicationInstanceTaskLog {
    ReplicationTaskName?: string | undefined;
    ReplicationTaskArn?: string | undefined;
    ReplicationInstanceTaskLogSize?: number | undefined;
}
export type ReplicationInstanceTaskLogsList = ReplicationInstanceTaskLog[];
export interface DescribeReplicationInstanceTaskLogsResponse {
    ReplicationInstanceArn?: string | undefined;
    ReplicationInstanceTaskLogs?: ReplicationInstanceTaskLog[] | undefined;
    Marker?: string | undefined;
}
export interface DescribeReplicationsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ProvisionData {
    ProvisionState?: string | undefined;
    ProvisionedCapacityUnits?: number | undefined;
    DateProvisioned?: Date | undefined;
    IsNewProvisioningAvailable?: boolean | undefined;
    DateNewProvisioningDataAvailable?: Date | undefined;
    ReasonForNewProvisioningData?: string | undefined;
}
export interface PremigrationAssessmentStatus {
    PremigrationAssessmentRunArn?: string | undefined;
    FailOnAssessmentFailure?: boolean | undefined;
    Status?: string | undefined;
    PremigrationAssessmentRunCreationDate?: Date | undefined;
    AssessmentProgress?: ReplicationTaskAssessmentRunProgress | undefined;
    LastFailureMessage?: string | undefined;
    ResultLocationBucket?: string | undefined;
    ResultLocationFolder?: string | undefined;
    ResultEncryptionMode?: string | undefined;
    ResultKmsKeyArn?: string | undefined;
    ResultStatistic?: ReplicationTaskAssessmentRunResultStatistic | undefined;
}
export type PremigrationAssessmentStatusList = PremigrationAssessmentStatus[];
export interface ReplicationStats {
    FullLoadProgressPercent?: number | undefined;
    ElapsedTimeMillis?: number | undefined;
    TablesLoaded?: number | undefined;
    TablesLoading?: number | undefined;
    TablesQueued?: number | undefined;
    TablesErrored?: number | undefined;
    FreshStartDate?: Date | undefined;
    StartDate?: Date | undefined;
    StopDate?: Date | undefined;
    FullLoadStartDate?: Date | undefined;
    FullLoadFinishDate?: Date | undefined;
}
export interface Replication {
    ReplicationConfigIdentifier?: string | undefined;
    ReplicationConfigArn?: string | undefined;
    SourceEndpointArn?: string | undefined;
    TargetEndpointArn?: string | undefined;
    ReplicationType?: MigrationTypeValue | undefined;
    Status?: string | undefined;
    ProvisionData?: ProvisionData | undefined;
    PremigrationAssessmentStatuses?: PremigrationAssessmentStatus[] | undefined;
    StopReason?: string | undefined;
    FailureMessages?: string[] | undefined;
    ReplicationStats?: ReplicationStats | undefined;
    StartReplicationType?: string | undefined;
    CdcStartTime?: Date | undefined;
    CdcStartPosition?: string | undefined;
    CdcStopPosition?: string | undefined;
    RecoveryCheckpoint?: string | undefined;
    ReplicationCreateTime?: Date | undefined;
    ReplicationUpdateTime?: Date | undefined;
    ReplicationLastStopTime?: Date | undefined;
    ReplicationDeprovisionTime?: Date | undefined;
    IsReadOnly?: boolean | undefined;
}
export type ReplicationList = Replication[];
export interface DescribeReplicationsResponse {
    Marker?: string | undefined;
    Replications?: Replication[] | undefined;
}
export interface DescribeReplicationSubnetGroupsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ReplicationSubnetGroups = ReplicationSubnetGroup[];
export interface DescribeReplicationSubnetGroupsResponse {
    Marker?: string | undefined;
    ReplicationSubnetGroups?: ReplicationSubnetGroup[] | undefined;
}
export interface DescribeReplicationTableStatisticsMessage {
    ReplicationConfigArn: string;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    Filters?: Filter[] | undefined;
}
export interface TableStatistics {
    SchemaName?: string | undefined;
    TableName?: string | undefined;
    Inserts?: number | undefined;
    Deletes?: number | undefined;
    Updates?: number | undefined;
    Ddls?: number | undefined;
    AppliedInserts?: number | undefined;
    AppliedDeletes?: number | undefined;
    AppliedUpdates?: number | undefined;
    AppliedDdls?: number | undefined;
    FullLoadRows?: number | undefined;
    FullLoadCondtnlChkFailedRows?: number | undefined;
    FullLoadErrorRows?: number | undefined;
    FullLoadStartTime?: Date | undefined;
    FullLoadEndTime?: Date | undefined;
    FullLoadReloaded?: boolean | undefined;
    LastUpdateTime?: Date | undefined;
    TableState?: string | undefined;
    ValidationPendingRecords?: number | undefined;
    ValidationFailedRecords?: number | undefined;
    ValidationSuspendedRecords?: number | undefined;
    ValidationState?: string | undefined;
    ValidationStateDetails?: string | undefined;
    ResyncState?: string | undefined;
    ResyncRowsAttempted?: number | undefined;
    ResyncRowsSucceeded?: number | undefined;
    ResyncRowsFailed?: number | undefined;
    ResyncProgress?: number | undefined;
}
export type ReplicationTableStatisticsList = TableStatistics[];
export interface DescribeReplicationTableStatisticsResponse {
    ReplicationConfigArn?: string | undefined;
    Marker?: string | undefined;
    ReplicationTableStatistics?: TableStatistics[] | undefined;
}
export interface DescribeReplicationTaskAssessmentResultsMessage {
    ReplicationTaskArn?: string | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ReplicationTaskAssessmentResult {
    ReplicationTaskIdentifier?: string | undefined;
    ReplicationTaskArn?: string | undefined;
    ReplicationTaskLastAssessmentDate?: Date | undefined;
    AssessmentStatus?: string | undefined;
    AssessmentResultsFile?: string | undefined;
    AssessmentResults?: string | undefined;
    S3ObjectUrl?: string | redacted.Redacted<string> | undefined;
}
export type ReplicationTaskAssessmentResultList = ReplicationTaskAssessmentResult[];
export interface DescribeReplicationTaskAssessmentResultsResponse {
    Marker?: string | undefined;
    BucketName?: string | undefined;
    ReplicationTaskAssessmentResults?: ReplicationTaskAssessmentResult[] | undefined;
}
export interface DescribeReplicationTaskAssessmentRunsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type ReplicationTaskAssessmentRunList = ReplicationTaskAssessmentRun[];
export interface DescribeReplicationTaskAssessmentRunsResponse {
    Marker?: string | undefined;
    ReplicationTaskAssessmentRuns?: ReplicationTaskAssessmentRun[] | undefined;
}
export interface DescribeReplicationTaskIndividualAssessmentsMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export interface ReplicationTaskIndividualAssessment {
    ReplicationTaskIndividualAssessmentArn?: string | undefined;
    ReplicationTaskAssessmentRunArn?: string | undefined;
    IndividualAssessmentName?: string | undefined;
    Status?: string | undefined;
    ReplicationTaskIndividualAssessmentStartDate?: Date | undefined;
}
export type ReplicationTaskIndividualAssessmentList = ReplicationTaskIndividualAssessment[];
export interface DescribeReplicationTaskIndividualAssessmentsResponse {
    Marker?: string | undefined;
    ReplicationTaskIndividualAssessments?: ReplicationTaskIndividualAssessment[] | undefined;
}
export interface DescribeReplicationTasksMessage {
    Filters?: Filter[] | undefined;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    WithoutSettings?: boolean | undefined;
}
export type ReplicationTaskList = ReplicationTask[];
export interface DescribeReplicationTasksResponse {
    Marker?: string | undefined;
    ReplicationTasks?: ReplicationTask[] | undefined;
}
export interface DescribeSchemasMessage {
    EndpointArn: string;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
}
export type SchemaList = string[];
export interface DescribeSchemasResponse {
    Marker?: string | undefined;
    Schemas?: string[] | undefined;
}
export interface DescribeTableStatisticsMessage {
    ReplicationTaskArn: string;
    MaxRecords?: number | undefined;
    Marker?: string | undefined;
    Filters?: Filter[] | undefined;
}
export type TableStatisticsList = TableStatistics[];
export interface DescribeTableStatisticsResponse {
    ReplicationTaskArn?: string | undefined;
    TableStatistics?: TableStatistics[] | undefined;
    Marker?: string | undefined;
}
export type AssessmentReportType = "pdf" | "csv" | (string & {});
export type AssessmentReportTypesList = AssessmentReportType[];
export interface ExportMetadataModelAssessmentMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    FileName?: string | undefined;
    AssessmentReportTypes?: AssessmentReportType[] | undefined;
}
export interface ExportMetadataModelAssessmentResultEntry {
    S3ObjectKey?: string | undefined;
    ObjectURL?: string | undefined;
}
export interface ExportMetadataModelAssessmentResponse {
    PdfReport?: ExportMetadataModelAssessmentResultEntry | undefined;
    CsvReport?: ExportMetadataModelAssessmentResultEntry | undefined;
}
export interface GetTargetSelectionRulesMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
}
export interface GetTargetSelectionRulesResponse {
    TargetSelectionRules?: string | undefined;
}
export interface ImportCertificateMessage {
    CertificateIdentifier: string;
    CertificatePem?: string | redacted.Redacted<string> | undefined;
    CertificateWallet?: Uint8Array | undefined;
    Tags?: Tag[] | undefined;
    KmsKeyId?: string | undefined;
}
export interface ImportCertificateResponse {
    Certificate?: Certificate | undefined;
}
export type ArnList = string[];
export interface ListTagsForResourceMessage {
    ResourceArn?: string | undefined;
    ResourceArnList?: string[] | undefined;
}
export interface ListTagsForResourceResponse {
    TagList?: Tag[] | undefined;
}
export interface ModifyConversionConfigurationMessage {
    MigrationProjectIdentifier: string;
    ConversionConfiguration: string;
}
export interface ModifyConversionConfigurationResponse {
    MigrationProjectIdentifier?: string | undefined;
}
export interface ModifyDataMigrationMessage {
    DataMigrationIdentifier: string;
    DataMigrationName?: string | undefined;
    EnableCloudwatchLogs?: boolean | undefined;
    ServiceAccessRoleArn?: string | undefined;
    DataMigrationType?: MigrationTypeValue | undefined;
    SourceDataSettings?: SourceDataSetting[] | undefined;
    TargetDataSettings?: TargetDataSetting[] | undefined;
    NumberOfJobs?: number | undefined;
    SelectionRules?: string | redacted.Redacted<string> | undefined;
}
export interface ModifyDataMigrationResponse {
    DataMigration?: DataMigration | undefined;
}
export interface ModifyDataProviderMessage {
    DataProviderIdentifier: string;
    DataProviderName?: string | undefined;
    Description?: string | undefined;
    Engine?: string | undefined;
    Virtual?: boolean | undefined;
    ExactSettings?: boolean | undefined;
    Settings?: DataProviderSettings | undefined;
}
export interface ModifyDataProviderResponse {
    DataProvider?: DataProvider | undefined;
}
export interface ModifyEndpointMessage {
    EndpointArn: string;
    EndpointIdentifier?: string | undefined;
    EndpointType?: ReplicationEndpointTypeValue | undefined;
    EngineName?: string | undefined;
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
    ServerName?: string | undefined;
    Port?: number | undefined;
    DatabaseName?: string | undefined;
    ExtraConnectionAttributes?: string | undefined;
    CertificateArn?: string | undefined;
    SslMode?: DmsSslModeValue | undefined;
    ServiceAccessRoleArn?: string | undefined;
    ExternalTableDefinition?: string | undefined;
    DynamoDbSettings?: DynamoDbSettings | undefined;
    S3Settings?: S3Settings | undefined;
    DmsTransferSettings?: DmsTransferSettings | undefined;
    MongoDbSettings?: MongoDbSettings | undefined;
    KinesisSettings?: KinesisSettings | undefined;
    KafkaSettings?: KafkaSettings | undefined;
    ElasticsearchSettings?: ElasticsearchSettings | undefined;
    NeptuneSettings?: NeptuneSettings | undefined;
    RedshiftSettings?: RedshiftSettings | undefined;
    PostgreSQLSettings?: PostgreSQLSettings | undefined;
    MySQLSettings?: MySQLSettings | undefined;
    OracleSettings?: OracleSettings | undefined;
    SybaseSettings?: SybaseSettings | undefined;
    MicrosoftSQLServerSettings?: MicrosoftSQLServerSettings | undefined;
    IBMDb2Settings?: IBMDb2Settings | undefined;
    DocDbSettings?: DocDbSettings | undefined;
    RedisSettings?: RedisSettings | undefined;
    ExactSettings?: boolean | undefined;
    GcpMySQLSettings?: GcpMySQLSettings | undefined;
    TimestreamSettings?: TimestreamSettings | undefined;
}
export interface ModifyEndpointResponse {
    Endpoint?: Endpoint | undefined;
}
export interface ModifyEventSubscriptionMessage {
    SubscriptionName: string;
    SnsTopicArn?: string | undefined;
    SourceType?: string | undefined;
    EventCategories?: string[] | undefined;
    Enabled?: boolean | undefined;
}
export interface ModifyEventSubscriptionResponse {
    EventSubscription?: EventSubscription | undefined;
}
export interface ModifyInstanceProfileMessage {
    InstanceProfileIdentifier: string;
    AvailabilityZone?: string | undefined;
    KmsKeyArn?: string | undefined;
    PubliclyAccessible?: boolean | undefined;
    NetworkType?: string | undefined;
    InstanceProfileName?: string | undefined;
    Description?: string | undefined;
    SubnetGroupIdentifier?: string | undefined;
    VpcSecurityGroups?: string[] | undefined;
}
export interface ModifyInstanceProfileResponse {
    InstanceProfile?: InstanceProfile | undefined;
}
export interface ModifyMigrationProjectMessage {
    MigrationProjectIdentifier: string;
    MigrationProjectName?: string | undefined;
    SourceDataProviderDescriptors?: DataProviderDescriptorDefinition[] | undefined;
    TargetDataProviderDescriptors?: DataProviderDescriptorDefinition[] | undefined;
    InstanceProfileIdentifier?: string | undefined;
    TransformationRules?: string | undefined;
    Description?: string | undefined;
    SchemaConversionApplicationAttributes?: SCApplicationAttributes | undefined;
}
export interface ModifyMigrationProjectResponse {
    MigrationProject?: MigrationProject | undefined;
}
export interface ModifyReplicationConfigMessage {
    ReplicationConfigArn: string;
    ReplicationConfigIdentifier?: string | undefined;
    ReplicationType?: MigrationTypeValue | undefined;
    TableMappings?: string | undefined;
    ReplicationSettings?: string | undefined;
    SupplementalSettings?: string | undefined;
    ComputeConfig?: ComputeConfig | undefined;
    SourceEndpointArn?: string | undefined;
    TargetEndpointArn?: string | undefined;
}
export interface ModifyReplicationConfigResponse {
    ReplicationConfig?: ReplicationConfig | undefined;
}
export interface ModifyReplicationInstanceMessage {
    ReplicationInstanceArn: string;
    AllocatedStorage?: number | undefined;
    ApplyImmediately?: boolean | undefined;
    ReplicationInstanceClass?: string | undefined;
    VpcSecurityGroupIds?: string[] | undefined;
    PreferredMaintenanceWindow?: string | undefined;
    MultiAZ?: boolean | undefined;
    EngineVersion?: string | undefined;
    AllowMajorVersionUpgrade?: boolean | undefined;
    AutoMinorVersionUpgrade?: boolean | undefined;
    ReplicationInstanceIdentifier?: string | undefined;
    NetworkType?: string | undefined;
    KerberosAuthenticationSettings?: KerberosAuthenticationSettings | undefined;
}
export interface ModifyReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance | undefined;
}
export interface ModifyReplicationSubnetGroupMessage {
    ReplicationSubnetGroupIdentifier: string;
    ReplicationSubnetGroupDescription?: string | undefined;
    SubnetIds: string[];
}
export interface ModifyReplicationSubnetGroupResponse {
    ReplicationSubnetGroup?: ReplicationSubnetGroup | undefined;
}
export interface ModifyReplicationTaskMessage {
    ReplicationTaskArn: string;
    ReplicationTaskIdentifier?: string | undefined;
    MigrationType?: MigrationTypeValue | undefined;
    TableMappings?: string | undefined;
    ReplicationTaskSettings?: string | undefined;
    CdcStartTime?: Date | undefined;
    CdcStartPosition?: string | undefined;
    CdcStopPosition?: string | undefined;
    TaskData?: string | undefined;
}
export interface ModifyReplicationTaskResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export interface MoveReplicationTaskMessage {
    ReplicationTaskArn: string;
    TargetReplicationInstanceArn: string;
}
export interface MoveReplicationTaskResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export interface RebootReplicationInstanceMessage {
    ReplicationInstanceArn: string;
    ForceFailover?: boolean | undefined;
    ForcePlannedFailover?: boolean | undefined;
}
export interface RebootReplicationInstanceResponse {
    ReplicationInstance?: ReplicationInstance | undefined;
}
export interface RefreshSchemasMessage {
    EndpointArn: string;
    ReplicationInstanceArn: string;
}
export interface RefreshSchemasResponse {
    RefreshSchemasStatus?: RefreshSchemasStatus | undefined;
}
export interface TableToReload {
    SchemaName: string;
    TableName: string;
}
export type TableListToReload = TableToReload[];
export type ReloadOptionValue = "data-reload" | "validate-only" | (string & {});
export interface ReloadReplicationTablesMessage {
    ReplicationConfigArn: string;
    TablesToReload: TableToReload[];
    ReloadOption?: ReloadOptionValue | undefined;
}
export interface ReloadReplicationTablesResponse {
    ReplicationConfigArn?: string | undefined;
}
export interface ReloadTablesMessage {
    ReplicationTaskArn: string;
    TablesToReload: TableToReload[];
    ReloadOption?: ReloadOptionValue | undefined;
}
export interface ReloadTablesResponse {
    ReplicationTaskArn?: string | undefined;
}
export type KeyList = string[];
export interface RemoveTagsFromResourceMessage {
    ResourceArn: string;
    TagKeys: string[];
}
export interface RemoveTagsFromResourceResponse {
}
export interface RunFleetAdvisorLsaAnalysisRequest {
}
export interface RunFleetAdvisorLsaAnalysisResponse {
    LsaAnalysisId?: string | undefined;
    Status?: string | undefined;
}
export type StartReplicationMigrationTypeValue = "reload-target" | "resume-processing" | "start-replication" | (string & {});
export interface StartDataMigrationMessage {
    DataMigrationIdentifier: string;
    StartType: StartReplicationMigrationTypeValue;
}
export interface StartDataMigrationResponse {
    DataMigration?: DataMigration | undefined;
}
export interface StartExtensionPackAssociationMessage {
    MigrationProjectIdentifier: string;
}
export interface StartExtensionPackAssociationResponse {
    RequestIdentifier?: string | undefined;
}
export interface StartMetadataModelAssessmentMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
}
export interface StartMetadataModelAssessmentResponse {
    RequestIdentifier?: string | undefined;
}
export interface StartMetadataModelConversionMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
}
export interface StartMetadataModelConversionResponse {
    RequestIdentifier?: string | undefined;
}
export interface StatementProperties {
    Definition: string;
}
export type MetadataModelProperties = {
    StatementProperties: StatementProperties;
};
export interface StartMetadataModelCreationMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    MetadataModelName: string;
    Properties: MetadataModelProperties;
}
export interface StartMetadataModelCreationResponse {
    RequestIdentifier?: string | undefined;
}
export interface StartMetadataModelExportAsScriptMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    Origin: OriginTypeValue;
    FileName?: string | undefined;
}
export interface StartMetadataModelExportAsScriptResponse {
    RequestIdentifier?: string | undefined;
}
export interface StartMetadataModelExportToTargetMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    OverwriteExtensionPack?: boolean | undefined;
}
export interface StartMetadataModelExportToTargetResponse {
    RequestIdentifier?: string | undefined;
}
export interface StartMetadataModelImportMessage {
    MigrationProjectIdentifier: string;
    SelectionRules: string;
    Origin: OriginTypeValue;
    Refresh?: boolean | undefined;
}
export interface StartMetadataModelImportResponse {
    RequestIdentifier?: string | undefined;
}
export interface StartRecommendationsRequest {
    DatabaseId: string;
    Settings: RecommendationSettings;
}
export interface StartRecommendationsResponse {
}
export interface StartReplicationMessage {
    ReplicationConfigArn: string;
    StartReplicationType: string;
    PremigrationAssessmentSettings?: string | undefined;
    CdcStartTime?: Date | undefined;
    CdcStartPosition?: string | undefined;
    CdcStopPosition?: string | undefined;
}
export interface StartReplicationResponse {
    Replication?: Replication | undefined;
}
export type StartReplicationTaskTypeValue = "start-replication" | "resume-processing" | "reload-target" | (string & {});
export interface StartReplicationTaskMessage {
    ReplicationTaskArn: string;
    StartReplicationTaskType: StartReplicationTaskTypeValue;
    CdcStartTime?: Date | undefined;
    CdcStartPosition?: string | undefined;
    CdcStopPosition?: string | undefined;
}
export interface StartReplicationTaskResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export interface StartReplicationTaskAssessmentMessage {
    ReplicationTaskArn: string;
}
export interface StartReplicationTaskAssessmentResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export type IncludeTestList = string[];
export type ExcludeTestList = string[];
export interface StartReplicationTaskAssessmentRunMessage {
    ReplicationTaskArn: string;
    ServiceAccessRoleArn: string;
    ResultLocationBucket: string;
    ResultLocationFolder?: string | undefined;
    ResultEncryptionMode?: string | undefined;
    ResultKmsKeyArn?: string | undefined;
    AssessmentRunName: string;
    IncludeOnly?: string[] | undefined;
    Exclude?: string[] | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartReplicationTaskAssessmentRunResponse {
    ReplicationTaskAssessmentRun?: ReplicationTaskAssessmentRun | undefined;
}
export interface StopDataMigrationMessage {
    DataMigrationIdentifier: string;
}
export interface StopDataMigrationResponse {
    DataMigration?: DataMigration | undefined;
}
export interface StopReplicationMessage {
    ReplicationConfigArn: string;
}
export interface StopReplicationResponse {
    Replication?: Replication | undefined;
}
export interface StopReplicationTaskMessage {
    ReplicationTaskArn: string;
}
export interface StopReplicationTaskResponse {
    ReplicationTask?: ReplicationTask | undefined;
}
export interface TestConnectionMessage {
    ReplicationInstanceArn: string;
    EndpointArn: string;
}
export interface TestConnectionResponse {
    Connection?: Connection | undefined;
}
export interface UpdateSubscriptionsToEventBridgeMessage {
    ForceMove?: boolean | undefined;
}
export interface UpdateSubscriptionsToEventBridgeResponse {
    Result?: string | undefined;
}
export type ExceptionMessage = string;
export type ResourceArn = string;
export type AddTagsToResourceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Adds metadata tags to an DMS resource, including replication instance, endpoint,
 * subnet group, and migration task. These tags can also be used with cost allocation
 * reporting to track cost associated with DMS resources, or used in a Condition statement in
 * an IAM policy for DMS. For more information, see
 * `Tag`
 * data type
 * description.
 */
export declare const addTagsToResource: API.OperationMethod<AddTagsToResourceMessage & RegionInput, AddTagsToResourceResponse, AddTagsToResourceError, Credentials | HttpClient.HttpClient>;
export type ApplyPendingMaintenanceActionError = ResourceNotFoundFault | CommonErrors;
/**
 * Applies a pending maintenance action to a resource (for example, to a replication
 * instance).
 */
export declare const applyPendingMaintenanceAction: API.OperationMethod<ApplyPendingMaintenanceActionMessage & RegionInput, ApplyPendingMaintenanceActionResponse, ApplyPendingMaintenanceActionError, Credentials | HttpClient.HttpClient>;
export type BatchStartRecommendationsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Starts the analysis of up to 20 source databases to recommend target engines for each
 * source database. This is a batch version of StartRecommendations.
 *
 * The result of analysis of each source database is reported individually in the
 * response. Because the batch request can result in a combination of successful and
 * unsuccessful actions, you should check for batch errors even when the call returns an
 * HTTP status code of `200`.
 */
export declare const batchStartRecommendations: API.OperationMethod<BatchStartRecommendationsRequest & RegionInput, BatchStartRecommendationsResponse, BatchStartRecommendationsError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataModelConversionError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Cancels a single metadata model conversion operation that was started with `StartMetadataModelConversion`.
 *
 * **Required permissions:**
 * `dms:CancelMetadataModelConversion`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const cancelMetadataModelConversion: API.OperationMethod<CancelMetadataModelConversionMessage & RegionInput, CancelMetadataModelConversionResponse, CancelMetadataModelConversionError, Credentials | HttpClient.HttpClient>;
export type CancelMetadataModelCreationError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Cancels a single metadata model creation operation that was started with `StartMetadataModelCreation`.
 *
 * **Required permissions:**
 * `dms:CancelMetadataModelCreation`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const cancelMetadataModelCreation: API.OperationMethod<CancelMetadataModelCreationMessage & RegionInput, CancelMetadataModelCreationResponse, CancelMetadataModelCreationError, Credentials | HttpClient.HttpClient>;
export type CancelReplicationTaskAssessmentRunError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Cancels a single premigration assessment run.
 *
 * This operation prevents any individual assessments from running if they haven't started
 * running. It also attempts to cancel any individual assessments that are currently
 * running.
 */
export declare const cancelReplicationTaskAssessmentRun: API.OperationMethod<CancelReplicationTaskAssessmentRunMessage & RegionInput, CancelReplicationTaskAssessmentRunResponse, CancelReplicationTaskAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type CreateDataMigrationError = FailedDependencyFault | InvalidOperationFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a data migration using the provided settings.
 */
export declare const createDataMigration: API.OperationMethod<CreateDataMigrationMessage & RegionInput, CreateDataMigrationResponse, CreateDataMigrationError, Credentials | HttpClient.HttpClient>;
export type CreateDataProviderError = AccessDeniedFault | FailedDependencyFault | ResourceAlreadyExistsFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a data provider using the provided settings. A data provider stores a data store
 * type and location information about your database.
 *
 * **Required permissions:**
 * `dms:CreateDataProvider`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const createDataProvider: API.OperationMethod<CreateDataProviderMessage & RegionInput, CreateDataProviderResponse, CreateDataProviderError, Credentials | HttpClient.HttpClient>;
export type CreateEndpointError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | CommonErrors;
/**
 * Creates an endpoint using the provided settings.
 *
 * For a MySQL source or target endpoint, don't explicitly specify the database using
 * the `DatabaseName` request parameter on the `CreateEndpoint` API
 * call. Specifying `DatabaseName` when you create a MySQL endpoint replicates
 * all the task tables to this single database. For MySQL endpoints, you specify the
 * database only when you specify the schema in the table-mapping rules of the DMS
 * task.
 */
export declare const createEndpoint: API.OperationMethod<CreateEndpointMessage & RegionInput, CreateEndpointResponse, CreateEndpointError, Credentials | HttpClient.HttpClient>;
export type CreateEventSubscriptionError = KMSAccessDeniedFault | KMSDisabledFault | KMSInvalidStateFault | KMSNotFoundFault | KMSThrottlingFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | CommonErrors;
/**
 * Creates an DMS event notification subscription.
 *
 * You can specify the type of source (`SourceType`) you want to be notified of,
 * provide a list of DMS source IDs (`SourceIds`) that triggers the events, and
 * provide a list of event categories (`EventCategories`) for events you want to be
 * notified of. If you specify both the `SourceType` and `SourceIds`,
 * such as `SourceType = replication-instance` and SourceIdentifier =
 * my-replinstance, you will be notified of all the replication instance events for
 * the specified source. If you specify a `SourceType` but don't specify a
 * `SourceIdentifier`, you receive notice of the events for that source type for
 * all your DMS sources. If you don't specify either `SourceType` nor
 * `SourceIdentifier`, you will be notified of events generated from all DMS
 * sources belonging to your customer account.
 *
 * For more information about DMS events, see Working with Events and
 * Notifications in the *Database Migration Service User Guide.*
 */
export declare const createEventSubscription: API.OperationMethod<CreateEventSubscriptionMessage & RegionInput, CreateEventSubscriptionResponse, CreateEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type CreateFleetAdvisorCollectorError = AccessDeniedFault | InvalidResourceStateFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Creates a Fleet Advisor collector using the specified parameters.
 */
export declare const createFleetAdvisorCollector: API.OperationMethod<CreateFleetAdvisorCollectorRequest & RegionInput, CreateFleetAdvisorCollectorResponse, CreateFleetAdvisorCollectorError, Credentials | HttpClient.HttpClient>;
export type CreateInstanceProfileError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Creates the instance profile using the specified parameters.
 *
 * **Required permissions:**
 * `dms:CreateInstanceProfile`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const createInstanceProfile: API.OperationMethod<CreateInstanceProfileMessage & RegionInput, CreateInstanceProfileResponse, CreateInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type CreateMigrationProjectError = AccessDeniedFault | FailedDependencyFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Creates the migration project using the specified parameters.
 *
 * You can run this action only after you create an instance profile and data providers
 * using CreateInstanceProfile and CreateDataProvider.
 *
 * **Required permissions:**
 * `dms:CreateMigrationProject`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const createMigrationProject: API.OperationMethod<CreateMigrationProjectMessage & RegionInput, CreateMigrationProjectResponse, CreateMigrationProjectError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationConfigError = AccessDeniedFault | InvalidResourceStateFault | InvalidSubnet | KMSKeyNotAccessibleFault | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a configuration that you can later provide to configure and start an DMS
 * Serverless replication. You can also provide options to validate the configuration inputs
 * before you start the replication.
 */
export declare const createReplicationConfig: API.OperationMethod<CreateReplicationConfigMessage & RegionInput, CreateReplicationConfigResponse, CreateReplicationConfigError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationInstanceError = AccessDeniedFault | InsufficientResourceCapacityFault | InvalidResourceStateFault | InvalidSubnet | KMSKeyNotAccessibleFault | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | StorageQuotaExceededFault | InvalidParameterValueException | InvalidReplicationInstanceClass | CommonErrors;
/**
 * Creates the replication instance using the specified parameters.
 *
 * DMS requires that your account have certain roles with appropriate permissions before
 * you can create a replication instance. For information on the required roles, see Creating the IAM Roles to Use With the CLI and DMS API. For information on
 * the required permissions, see IAM
 * Permissions Needed to Use DMS.
 *
 * If you don't specify a version when creating a replication instance, DMS will
 * create the instance using the default engine version. For information about the default
 * engine version, see Release Notes.
 */
export declare const createReplicationInstance: API.OperationMethod<CreateReplicationInstanceMessage & RegionInput, CreateReplicationInstanceResponse, CreateReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationSubnetGroupError = AccessDeniedFault | InvalidSubnet | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a replication subnet group given a list of the subnet IDs in a VPC.
 *
 * The VPC needs to have at least one subnet in at least two availability zones in the
 * Amazon Web Services Region, otherwise the service will throw a
 * `ReplicationSubnetGroupDoesNotCoverEnoughAZs` exception.
 *
 * If a replication subnet group exists in your Amazon Web Services account, the
 * CreateReplicationSubnetGroup action returns the following error message: The Replication
 * Subnet Group already exists. In this case, delete the existing replication subnet group. To
 * do so, use the DeleteReplicationSubnetGroup action. Optionally, choose Subnet groups in the
 * DMS console, then choose your subnet group. Next, choose Delete from Actions.
 */
export declare const createReplicationSubnetGroup: API.OperationMethod<CreateReplicationSubnetGroupMessage & RegionInput, CreateReplicationSubnetGroupResponse, CreateReplicationSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type CreateReplicationTaskError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Creates a replication task using the specified parameters.
 */
export declare const createReplicationTask: API.OperationMethod<CreateReplicationTaskMessage & RegionInput, CreateReplicationTaskResponse, CreateReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteCertificateError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified certificate.
 */
export declare const deleteCertificate: API.OperationMethod<DeleteCertificateMessage & RegionInput, DeleteCertificateResponse, DeleteCertificateError, Credentials | HttpClient.HttpClient>;
export type DeleteConnectionError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the connection between a replication instance and an endpoint.
 */
export declare const deleteConnection: API.OperationMethod<DeleteConnectionMessage & RegionInput, DeleteConnectionResponse, DeleteConnectionError, Credentials | HttpClient.HttpClient>;
export type DeleteDataMigrationError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified data migration.
 */
export declare const deleteDataMigration: API.OperationMethod<DeleteDataMigrationMessage & RegionInput, DeleteDataMigrationResponse, DeleteDataMigrationError, Credentials | HttpClient.HttpClient>;
export type DeleteDataProviderError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified data provider.
 *
 * **Required permissions:**
 * `dms:DeleteDataProvider`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * All migration projects associated with the data provider must be deleted or modified
 * before you can delete the data provider.
 */
export declare const deleteDataProvider: API.OperationMethod<DeleteDataProviderMessage & RegionInput, DeleteDataProviderResponse, DeleteDataProviderError, Credentials | HttpClient.HttpClient>;
export type DeleteEndpointError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified endpoint.
 *
 * All tasks associated with the endpoint must be deleted before you can delete the
 * endpoint.
 */
export declare const deleteEndpoint: API.OperationMethod<DeleteEndpointMessage & RegionInput, DeleteEndpointResponse, DeleteEndpointError, Credentials | HttpClient.HttpClient>;
export type DeleteEventSubscriptionError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes an DMS event subscription.
 */
export declare const deleteEventSubscription: API.OperationMethod<DeleteEventSubscriptionMessage & RegionInput, DeleteEventSubscriptionResponse, DeleteEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetAdvisorCollectorError = AccessDeniedFault | CollectorNotFoundFault | InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Deletes the specified Fleet Advisor collector.
 */
export declare const deleteFleetAdvisorCollector: API.OperationMethod<DeleteCollectorRequest & RegionInput, DeleteFleetAdvisorCollectorResponse, DeleteFleetAdvisorCollectorError, Credentials | HttpClient.HttpClient>;
export type DeleteFleetAdvisorDatabasesError = AccessDeniedFault | InvalidOperationFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Deletes the specified Fleet Advisor collector databases.
 */
export declare const deleteFleetAdvisorDatabases: API.OperationMethod<DeleteFleetAdvisorDatabasesRequest & RegionInput, DeleteFleetAdvisorDatabasesResponse, DeleteFleetAdvisorDatabasesError, Credentials | HttpClient.HttpClient>;
export type DeleteInstanceProfileError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified instance profile.
 *
 * **Required permissions:**
 * `dms:DeleteInstanceProfile`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * All migration projects associated with the instance profile must be deleted or
 * modified before you can delete the instance profile.
 */
export declare const deleteInstanceProfile: API.OperationMethod<DeleteInstanceProfileMessage & RegionInput, DeleteInstanceProfileResponse, DeleteInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type DeleteMigrationProjectError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified migration project.
 *
 * **Required permissions:**
 * `dms:DeleteMigrationProject`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * The migration project must be closed before you can delete it.
 */
export declare const deleteMigrationProject: API.OperationMethod<DeleteMigrationProjectMessage & RegionInput, DeleteMigrationProjectResponse, DeleteMigrationProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationConfigError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes an DMS Serverless replication configuration. This effectively deprovisions any
 * and all replications that use this configuration. You can't delete the configuration for an
 * DMS Serverless replication that is ongoing. You can delete the configuration when the
 * replication is in a non-RUNNING and non-STARTING state.
 */
export declare const deleteReplicationConfig: API.OperationMethod<DeleteReplicationConfigMessage & RegionInput, DeleteReplicationConfigResponse, DeleteReplicationConfigError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationInstanceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified replication instance.
 *
 * You must delete any migration tasks that are associated with the replication instance
 * before you can delete it.
 */
export declare const deleteReplicationInstance: API.OperationMethod<DeleteReplicationInstanceMessage & RegionInput, DeleteReplicationInstanceResponse, DeleteReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationSubnetGroupError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes a subnet group.
 */
export declare const deleteReplicationSubnetGroup: API.OperationMethod<DeleteReplicationSubnetGroupMessage & RegionInput, DeleteReplicationSubnetGroupResponse, DeleteReplicationSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationTaskError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the specified replication task.
 */
export declare const deleteReplicationTask: API.OperationMethod<DeleteReplicationTaskMessage & RegionInput, DeleteReplicationTaskResponse, DeleteReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type DeleteReplicationTaskAssessmentRunError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Deletes the record of a single premigration assessment run.
 *
 * This operation removes all metadata that DMS maintains about this assessment run.
 * However, the operation leaves untouched all information about this assessment run that is
 * stored in your Amazon S3 bucket.
 */
export declare const deleteReplicationTaskAssessmentRun: API.OperationMethod<DeleteReplicationTaskAssessmentRunMessage & RegionInput, DeleteReplicationTaskAssessmentRunResponse, DeleteReplicationTaskAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type DescribeAccountAttributesError = CommonErrors;
/**
 * Lists all of the DMS attributes for a customer account. These attributes include DMS
 * quotas for the account and a unique account identifier in a particular DMS region. DMS
 * quotas include a list of resource quotas supported by the account, such as the number of
 * replication instances allowed. The description for each resource quota, includes the quota
 * name, current usage toward that quota, and the quota's maximum value. DMS uses the unique
 * account identifier to name each artifact used by DMS in the given region.
 *
 * This command does not take any parameters.
 */
export declare const describeAccountAttributes: API.OperationMethod<DescribeAccountAttributesMessage & RegionInput, DescribeAccountAttributesResponse, DescribeAccountAttributesError, Credentials | HttpClient.HttpClient>;
export type DescribeApplicableIndividualAssessmentsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Provides a list of individual assessments that you can specify for a new premigration
 * assessment run, given one or more parameters.
 *
 * If you specify an existing migration task, this operation provides the default
 * individual assessments you can specify for that task. Otherwise, the specified parameters
 * model elements of a possible migration task on which to base a premigration assessment
 * run.
 *
 * To use these migration task modeling parameters, you must specify an existing
 * replication instance, a source database engine, a target database engine, and a migration
 * type. This combination of parameters potentially limits the default individual assessments
 * available for an assessment run created for a corresponding migration task.
 *
 * If you specify no parameters, this operation provides a list of all possible individual
 * assessments that you can specify for an assessment run. If you specify any one of the task
 * modeling parameters, you must specify all of them or the operation cannot provide a list of
 * individual assessments. The only parameter that you can specify alone is for an existing
 * migration task. The specified task definition then determines the default list of
 * individual assessments that you can specify in an assessment run for the task.
 */
export declare const describeApplicableIndividualAssessments: API.PaginatedOperationMethod<DescribeApplicableIndividualAssessmentsMessage & RegionInput, DescribeApplicableIndividualAssessmentsResponse, DescribeApplicableIndividualAssessmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeCertificatesError = ResourceNotFoundFault | CommonErrors;
/**
 * Provides a description of the certificate.
 */
export declare const describeCertificates: API.PaginatedOperationMethod<DescribeCertificatesMessage & RegionInput, DescribeCertificatesResponse, DescribeCertificatesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConnectionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Describes the status of the connections that have been made between the replication
 * instance and an endpoint. Connections are created when you test an endpoint.
 */
export declare const describeConnections: API.PaginatedOperationMethod<DescribeConnectionsMessage & RegionInput, DescribeConnectionsResponse, DescribeConnectionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeConversionConfigurationError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns configuration parameters for a schema conversion project.
 *
 * **Required permissions:**
 * `dms:DescribeConversionConfiguration`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeConversionConfiguration: API.OperationMethod<DescribeConversionConfigurationMessage & RegionInput, DescribeConversionConfigurationResponse, DescribeConversionConfigurationError, Credentials | HttpClient.HttpClient>;
export type DescribeDataMigrationsError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about data migrations.
 */
export declare const describeDataMigrations: API.PaginatedOperationMethod<DescribeDataMigrationsMessage & RegionInput, DescribeDataMigrationsResponse, DescribeDataMigrationsError, Credentials | HttpClient.HttpClient, DataMigration>;
export type DescribeDataProvidersError = AccessDeniedFault | FailedDependencyFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of data providers for your account in the current
 * region.
 *
 * **Required permissions:**
 * `dms:ListDataProviders`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeDataProviders: API.PaginatedOperationMethod<DescribeDataProvidersMessage & RegionInput, DescribeDataProvidersResponse, DescribeDataProvidersError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the endpoints for your account in the current region.
 */
export declare const describeEndpoints: API.PaginatedOperationMethod<DescribeEndpointsMessage & RegionInput, DescribeEndpointsResponse, DescribeEndpointsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointSettingsError = CommonErrors;
/**
 * Returns information about the possible endpoint settings available when you create an
 * endpoint for a specific database engine.
 */
export declare const describeEndpointSettings: API.PaginatedOperationMethod<DescribeEndpointSettingsMessage & RegionInput, DescribeEndpointSettingsResponse, DescribeEndpointSettingsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEndpointTypesError = CommonErrors;
/**
 * Returns information about the type of endpoints available.
 */
export declare const describeEndpointTypes: API.PaginatedOperationMethod<DescribeEndpointTypesMessage & RegionInput, DescribeEndpointTypesResponse, DescribeEndpointTypesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEngineVersionsError = CommonErrors;
/**
 * Returns information about the replication instance versions used in the project.
 */
export declare const describeEngineVersions: API.PaginatedOperationMethod<DescribeEngineVersionsMessage & RegionInput, DescribeEngineVersionsResponse, DescribeEngineVersionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventCategoriesError = CommonErrors;
/**
 * Lists categories for all event source types, or, if specified, for a specified source
 * type. You can see a list of the event categories and source types in Working with Events
 * and Notifications in the *Database Migration Service User Guide.*
 */
export declare const describeEventCategories: API.OperationMethod<DescribeEventCategoriesMessage & RegionInput, DescribeEventCategoriesResponse, DescribeEventCategoriesError, Credentials | HttpClient.HttpClient>;
export type DescribeEventsError = CommonErrors;
/**
 * Lists events for a given source identifier and source type. You can also specify a
 * start and end time. For more information on DMS events, see Working with Events and
 * Notifications in the *Database Migration Service User Guide.*
 */
export declare const describeEvents: API.PaginatedOperationMethod<DescribeEventsMessage & RegionInput, DescribeEventsResponse, DescribeEventsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeEventSubscriptionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Lists all the event subscriptions for a customer account. The description of a
 * subscription includes `SubscriptionName`, `SNSTopicARN`,
 * `CustomerID`, `SourceType`, `SourceID`,
 * `CreationTime`, and `Status`.
 *
 * If you specify `SubscriptionName`, this action lists the description for that
 * subscription.
 */
export declare const describeEventSubscriptions: API.PaginatedOperationMethod<DescribeEventSubscriptionsMessage & RegionInput, DescribeEventSubscriptionsResponse, DescribeEventSubscriptionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeExtensionPackAssociationsError = CommonErrors;
/**
 * Returns a paginated list of extension pack installation requests for a migration
 * project, initiated by
 * StartExtensionPackAssociation.
 *
 * **Required permissions:**
 * `dms:ListExtensionPacks`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeExtensionPackAssociations: API.PaginatedOperationMethod<DescribeExtensionPackAssociationsMessage & RegionInput, DescribeExtensionPackAssociationsResponse, DescribeExtensionPackAssociationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorCollectorsError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a list of the Fleet Advisor collectors in your account.
 */
export declare const describeFleetAdvisorCollectors: API.PaginatedOperationMethod<DescribeFleetAdvisorCollectorsRequest & RegionInput, DescribeFleetAdvisorCollectorsResponse, DescribeFleetAdvisorCollectorsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorDatabasesError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a list of Fleet Advisor databases in your account.
 */
export declare const describeFleetAdvisorDatabases: API.PaginatedOperationMethod<DescribeFleetAdvisorDatabasesRequest & RegionInput, DescribeFleetAdvisorDatabasesResponse, DescribeFleetAdvisorDatabasesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorLsaAnalysisError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Provides descriptions of large-scale assessment (LSA) analyses produced by your Fleet
 * Advisor collectors.
 */
export declare const describeFleetAdvisorLsaAnalysis: API.PaginatedOperationMethod<DescribeFleetAdvisorLsaAnalysisRequest & RegionInput, DescribeFleetAdvisorLsaAnalysisResponse, DescribeFleetAdvisorLsaAnalysisError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorSchemaObjectSummaryError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Provides descriptions of the schemas discovered by your Fleet Advisor
 * collectors.
 */
export declare const describeFleetAdvisorSchemaObjectSummary: API.PaginatedOperationMethod<DescribeFleetAdvisorSchemaObjectSummaryRequest & RegionInput, DescribeFleetAdvisorSchemaObjectSummaryResponse, DescribeFleetAdvisorSchemaObjectSummaryError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeFleetAdvisorSchemasError = InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a list of schemas detected by Fleet Advisor Collectors in your account.
 */
export declare const describeFleetAdvisorSchemas: API.PaginatedOperationMethod<DescribeFleetAdvisorSchemasRequest & RegionInput, DescribeFleetAdvisorSchemasResponse, DescribeFleetAdvisorSchemasError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeInstanceProfilesError = AccessDeniedFault | FailedDependencyFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of instance profiles for your account in the current
 * region.
 *
 * **Required permissions:**
 * `dms:ListInstanceProfiles`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeInstanceProfiles: API.PaginatedOperationMethod<DescribeInstanceProfilesMessage & RegionInput, DescribeInstanceProfilesResponse, DescribeInstanceProfilesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelError = AccessDeniedFault | ResourceNotFoundFault | CommonErrors;
/**
 * Gets detailed information about the specified metadata model, including its definition and corresponding converted objects in the target database if applicable.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModel`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModel: API.OperationMethod<DescribeMetadataModelMessage & RegionInput, DescribeMetadataModelResponse, DescribeMetadataModelError, Credentials | HttpClient.HttpClient>;
export type DescribeMetadataModelAssessmentsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model assessment requests for a migration
 * project, initiated by
 * StartMetadataModelAssessment.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelAssessments`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelAssessments: API.PaginatedOperationMethod<DescribeMetadataModelAssessmentsMessage & RegionInput, DescribeMetadataModelAssessmentsResponse, DescribeMetadataModelAssessmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelChildrenError = AccessDeniedFault | ResourceNotFoundFault | CommonErrors;
/**
 * Gets a list of child metadata models for the specified metadata model in the database hierarchy.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModelChildren`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelChildren: API.PaginatedOperationMethod<DescribeMetadataModelChildrenMessage & RegionInput, DescribeMetadataModelChildrenResponse, DescribeMetadataModelChildrenError, Credentials | HttpClient.HttpClient, MetadataModelReference>;
export type DescribeMetadataModelConversionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model conversion requests for a migration
 * project, initiated by
 * StartMetadataModelConversion.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelConversion.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelConversions`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelConversions: API.PaginatedOperationMethod<DescribeMetadataModelConversionsMessage & RegionInput, DescribeMetadataModelConversionsResponse, DescribeMetadataModelConversionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelCreationsError = AccessDeniedFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model creation requests for a migration
 * project, initiated by
 * StartMetadataModelCreation.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelCreation.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModelCreations`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelCreations: API.PaginatedOperationMethod<DescribeMetadataModelCreationsMessage & RegionInput, DescribeMetadataModelCreationsResponse, DescribeMetadataModelCreationsError, Credentials | HttpClient.HttpClient, SchemaConversionRequest>;
export type DescribeMetadataModelExportsAsScriptError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model export requests for a migration
 * project, initiated by
 * StartMetadataModelExportAsScript.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelExports`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelExportsAsScript: API.PaginatedOperationMethod<DescribeMetadataModelExportsAsScriptMessage & RegionInput, DescribeMetadataModelExportsAsScriptResponse, DescribeMetadataModelExportsAsScriptError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelExportsToTargetError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model export requests for a migration
 * project, initiated by
 * StartMetadataModelExportToTarget.
 *
 * **Required permissions:**
 * `dms:ListMetadataModelExports`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelExportsToTarget: API.PaginatedOperationMethod<DescribeMetadataModelExportsToTargetMessage & RegionInput, DescribeMetadataModelExportsToTargetResponse, DescribeMetadataModelExportsToTargetError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMetadataModelImportsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of metadata model import requests for a migration
 * project, initiated by
 * StartMetadataModelImport.
 *
 * **Required permissions:**
 * `dms:DescribeMetadataModelImports`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMetadataModelImports: API.PaginatedOperationMethod<DescribeMetadataModelImportsMessage & RegionInput, DescribeMetadataModelImportsResponse, DescribeMetadataModelImportsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeMigrationProjectsError = AccessDeniedFault | FailedDependencyFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of migration projects for your account in the current
 * region.
 *
 * **Required permissions:**
 * `dms:ListMigrationProjects`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const describeMigrationProjects: API.PaginatedOperationMethod<DescribeMigrationProjectsMessage & RegionInput, DescribeMigrationProjectsResponse, DescribeMigrationProjectsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeOrderableReplicationInstancesError = CommonErrors;
/**
 * Returns information about the replication instance types that can be created in the
 * specified region.
 */
export declare const describeOrderableReplicationInstances: API.PaginatedOperationMethod<DescribeOrderableReplicationInstancesMessage & RegionInput, DescribeOrderableReplicationInstancesResponse, DescribeOrderableReplicationInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribePendingMaintenanceActionsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a list of upcoming maintenance events for replication instances in your account
 * in the current Region.
 */
export declare const describePendingMaintenanceActions: API.PaginatedOperationMethod<DescribePendingMaintenanceActionsMessage & RegionInput, DescribePendingMaintenanceActionsResponse, DescribePendingMaintenanceActionsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRecommendationLimitationsError = AccessDeniedFault | InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a paginated list of limitations for recommendations of target Amazon Web Services
 * engines.
 */
export declare const describeRecommendationLimitations: API.PaginatedOperationMethod<DescribeRecommendationLimitationsRequest & RegionInput, DescribeRecommendationLimitationsResponse, DescribeRecommendationLimitationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRecommendationsError = AccessDeniedFault | InvalidResourceStateFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Returns a paginated list of target engine recommendations for your source
 * databases.
 */
export declare const describeRecommendations: API.PaginatedOperationMethod<DescribeRecommendationsRequest & RegionInput, DescribeRecommendationsResponse, DescribeRecommendationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeRefreshSchemasStatusError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns the status of the RefreshSchemas operation.
 */
export declare const describeRefreshSchemasStatus: API.OperationMethod<DescribeRefreshSchemasStatusMessage & RegionInput, DescribeRefreshSchemasStatusResponse, DescribeRefreshSchemasStatusError, Credentials | HttpClient.HttpClient>;
export type DescribeReplicationConfigsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns one or more existing DMS Serverless replication configurations as a list of
 * structures.
 */
export declare const describeReplicationConfigs: API.PaginatedOperationMethod<DescribeReplicationConfigsMessage & RegionInput, DescribeReplicationConfigsResponse, DescribeReplicationConfigsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationInstancesError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about replication instances for your account in the current
 * region.
 */
export declare const describeReplicationInstances: API.PaginatedOperationMethod<DescribeReplicationInstancesMessage & RegionInput, DescribeReplicationInstancesResponse, DescribeReplicationInstancesError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationInstanceTaskLogsError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the task logs for the specified task.
 */
export declare const describeReplicationInstanceTaskLogs: API.PaginatedOperationMethod<DescribeReplicationInstanceTaskLogsMessage & RegionInput, DescribeReplicationInstanceTaskLogsResponse, DescribeReplicationInstanceTaskLogsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationsError = ResourceNotFoundFault | CommonErrors;
/**
 * Provides details on replication progress by returning status information for one or more
 * provisioned DMS Serverless replications.
 */
export declare const describeReplications: API.PaginatedOperationMethod<DescribeReplicationsMessage & RegionInput, DescribeReplicationsResponse, DescribeReplicationsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationSubnetGroupsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the replication subnet groups.
 */
export declare const describeReplicationSubnetGroups: API.PaginatedOperationMethod<DescribeReplicationSubnetGroupsMessage & RegionInput, DescribeReplicationSubnetGroupsResponse, DescribeReplicationSubnetGroupsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTableStatisticsError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns table and schema statistics for one or more provisioned replications that use a
 * given DMS Serverless replication configuration.
 */
export declare const describeReplicationTableStatistics: API.PaginatedOperationMethod<DescribeReplicationTableStatisticsMessage & RegionInput, DescribeReplicationTableStatisticsResponse, DescribeReplicationTableStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTaskAssessmentResultsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns the task assessment results from the Amazon S3 bucket that DMS creates in your
 * Amazon Web Services account. This action always returns the latest results.
 *
 * For more information about DMS task assessments, see Creating a task assessment
 * report in the *Database Migration Service User Guide*.
 */
export declare const describeReplicationTaskAssessmentResults: API.PaginatedOperationMethod<DescribeReplicationTaskAssessmentResultsMessage & RegionInput, DescribeReplicationTaskAssessmentResultsResponse, DescribeReplicationTaskAssessmentResultsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTaskAssessmentRunsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of premigration assessment runs based on filter
 * settings.
 *
 * These filter settings can specify a combination of premigration assessment runs,
 * migration tasks, replication instances, and assessment run status values.
 *
 * This operation doesn't return information about individual assessments. For this
 * information, see the `DescribeReplicationTaskIndividualAssessments`
 * operation.
 */
export declare const describeReplicationTaskAssessmentRuns: API.PaginatedOperationMethod<DescribeReplicationTaskAssessmentRunsMessage & RegionInput, DescribeReplicationTaskAssessmentRunsResponse, DescribeReplicationTaskAssessmentRunsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTaskIndividualAssessmentsError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns a paginated list of individual assessments based on filter settings.
 *
 * These filter settings can specify a combination of premigration assessment runs,
 * migration tasks, and assessment status values.
 */
export declare const describeReplicationTaskIndividualAssessments: API.PaginatedOperationMethod<DescribeReplicationTaskIndividualAssessmentsMessage & RegionInput, DescribeReplicationTaskIndividualAssessmentsResponse, DescribeReplicationTaskIndividualAssessmentsError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeReplicationTasksError = ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about replication tasks for your account in the current
 * region.
 */
export declare const describeReplicationTasks: API.PaginatedOperationMethod<DescribeReplicationTasksMessage & RegionInput, DescribeReplicationTasksResponse, DescribeReplicationTasksError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeSchemasError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns information about the schema for the specified endpoint.
 */
export declare const describeSchemas: API.PaginatedOperationMethod<DescribeSchemasMessage & RegionInput, DescribeSchemasResponse, DescribeSchemasError, Credentials | HttpClient.HttpClient, unknown>;
export type DescribeTableStatisticsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Returns table statistics on the database migration task, including table name, rows
 * inserted, rows updated, and rows deleted.
 *
 * Note that the "last updated" column the DMS console only indicates the time that DMS
 * last updated the table statistics record for a table. It does not indicate the time of the
 * last update to the table.
 */
export declare const describeTableStatistics: API.PaginatedOperationMethod<DescribeTableStatisticsMessage & RegionInput, DescribeTableStatisticsResponse, DescribeTableStatisticsError, Credentials | HttpClient.HttpClient, unknown>;
export type ExportMetadataModelAssessmentError = ResourceNotFoundFault | CommonErrors;
/**
 * Saves a copy of a database migration assessment report to your Amazon S3 bucket. DMS can
 * save your assessment report as a comma-separated value (CSV) or a PDF file.
 *
 * **Required permissions:**
 * `dms:ExportMetadataModelAssessment`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const exportMetadataModelAssessment: API.OperationMethod<ExportMetadataModelAssessmentMessage & RegionInput, ExportMetadataModelAssessmentResponse, ExportMetadataModelAssessmentError, Credentials | HttpClient.HttpClient>;
export type GetTargetSelectionRulesError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Converts source selection rules into their target counterparts for schema conversion operations.
 *
 * **Required permissions:**
 * `dms:GetTargetSelectionRules`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const getTargetSelectionRules: API.OperationMethod<GetTargetSelectionRulesMessage & RegionInput, GetTargetSelectionRulesResponse, GetTargetSelectionRulesError, Credentials | HttpClient.HttpClient>;
export type ImportCertificateError = InvalidCertificateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Uploads the specified certificate.
 */
export declare const importCertificate: API.OperationMethod<ImportCertificateMessage & RegionInput, ImportCertificateResponse, ImportCertificateError, Credentials | HttpClient.HttpClient>;
export type ListTagsForResourceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Lists all metadata tags attached to an DMS resource, including replication instance,
 * endpoint, subnet group, and migration task. For more information, see
 * `Tag`
 *
 * data type description.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceMessage & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type ModifyConversionConfigurationError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified schema conversion configuration using the provided parameters.
 *
 * **Required permissions:**
 * `dms:UpdateConversionConfiguration`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const modifyConversionConfiguration: API.OperationMethod<ModifyConversionConfigurationMessage & RegionInput, ModifyConversionConfigurationResponse, ModifyConversionConfigurationError, Credentials | HttpClient.HttpClient>;
export type ModifyDataMigrationError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies an existing DMS data migration.
 */
export declare const modifyDataMigration: API.OperationMethod<ModifyDataMigrationMessage & RegionInput, ModifyDataMigrationResponse, ModifyDataMigrationError, Credentials | HttpClient.HttpClient>;
export type ModifyDataProviderError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified data provider using the provided settings.
 *
 * **Required permissions:**
 * `dms:UpdateDataProvider`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * You must remove the data provider from all migration projects before you can modify
 * it.
 */
export declare const modifyDataProvider: API.OperationMethod<ModifyDataProviderMessage & RegionInput, ModifyDataProviderResponse, ModifyDataProviderError, Credentials | HttpClient.HttpClient>;
export type ModifyEndpointError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified endpoint.
 *
 * For a MySQL source or target endpoint, don't explicitly specify the database using
 * the `DatabaseName` request parameter on the `ModifyEndpoint` API
 * call. Specifying `DatabaseName` when you modify a MySQL endpoint replicates
 * all the task tables to this single database. For MySQL endpoints, you specify the
 * database only when you specify the schema in the table-mapping rules of the DMS
 * task.
 */
export declare const modifyEndpoint: API.OperationMethod<ModifyEndpointMessage & RegionInput, ModifyEndpointResponse, ModifyEndpointError, Credentials | HttpClient.HttpClient>;
export type ModifyEventSubscriptionError = AccessDeniedFault | KMSAccessDeniedFault | KMSDisabledFault | KMSInvalidStateFault | KMSNotFoundFault | KMSThrottlingFault | ResourceNotFoundFault | ResourceQuotaExceededFault | SNSInvalidTopicFault | SNSNoAuthorizationFault | CommonErrors;
/**
 * Modifies an existing DMS event notification subscription.
 */
export declare const modifyEventSubscription: API.OperationMethod<ModifyEventSubscriptionMessage & RegionInput, ModifyEventSubscriptionResponse, ModifyEventSubscriptionError, Credentials | HttpClient.HttpClient>;
export type ModifyInstanceProfileError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified instance profile using the provided parameters.
 *
 * **Required permissions:**
 * `dms:UpdateInstanceProfile`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * All migration projects associated with the instance profile must be deleted or
 * modified before you can modify the instance profile.
 */
export declare const modifyInstanceProfile: API.OperationMethod<ModifyInstanceProfileMessage & RegionInput, ModifyInstanceProfileResponse, ModifyInstanceProfileError, Credentials | HttpClient.HttpClient>;
export type ModifyMigrationProjectError = AccessDeniedFault | FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified migration project using the provided parameters.
 *
 * **Required permissions:**
 * `dms:UpdateMigrationProject`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 *
 * The migration project must be closed before you can modify it.
 */
export declare const modifyMigrationProject: API.OperationMethod<ModifyMigrationProjectMessage & RegionInput, ModifyMigrationProjectResponse, ModifyMigrationProjectError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationConfigError = AccessDeniedFault | InvalidResourceStateFault | InvalidSubnet | KMSKeyNotAccessibleFault | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies an existing DMS Serverless replication configuration that you can use to
 * start a replication. This command includes input validation and logic to check the state of
 * any replication that uses this configuration. You can only modify a replication
 * configuration before any replication that uses it has started. As soon as you have
 * initially started a replication with a given configuiration, you can't modify that
 * configuration, even if you stop it.
 *
 * Other run statuses that allow you to run this command include FAILED and CREATED. A
 * provisioning state that allows you to run this command is FAILED_PROVISION.
 */
export declare const modifyReplicationConfig: API.OperationMethod<ModifyReplicationConfigMessage & RegionInput, ModifyReplicationConfigResponse, ModifyReplicationConfigError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationInstanceError = AccessDeniedFault | InsufficientResourceCapacityFault | InvalidResourceStateFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | StorageQuotaExceededFault | UpgradeDependencyFailureFault | InvalidParameterValueException | InvalidReplicationInstanceClass | CommonErrors;
/**
 * Modifies the replication instance to apply new settings. You can change one or more
 * parameters by specifying these parameters and the new values in the request.
 *
 * Some settings are applied during the maintenance window.
 */
export declare const modifyReplicationInstance: API.OperationMethod<ModifyReplicationInstanceMessage & RegionInput, ModifyReplicationInstanceResponse, ModifyReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationSubnetGroupError = AccessDeniedFault | InvalidSubnet | ReplicationSubnetGroupDoesNotCoverEnoughAZs | ResourceNotFoundFault | ResourceQuotaExceededFault | SubnetAlreadyInUse | CommonErrors;
/**
 * Modifies the settings for the specified replication subnet group.
 */
export declare const modifyReplicationSubnetGroup: API.OperationMethod<ModifyReplicationSubnetGroupMessage & RegionInput, ModifyReplicationSubnetGroupResponse, ModifyReplicationSubnetGroupError, Credentials | HttpClient.HttpClient>;
export type ModifyReplicationTaskError = InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | CommonErrors;
/**
 * Modifies the specified replication task.
 *
 * You can't modify the task endpoints. The task must be stopped before you can modify it.
 *
 * For more information about DMS tasks, see Working with Migration Tasks in the
 * *Database Migration Service User Guide*.
 */
export declare const modifyReplicationTask: API.OperationMethod<ModifyReplicationTaskMessage & RegionInput, ModifyReplicationTaskResponse, ModifyReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type MoveReplicationTaskError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Moves a replication task from its current replication instance to a different target
 * replication instance using the specified parameters. The target replication instance must
 * be created with the same or later DMS version as the current replication instance.
 */
export declare const moveReplicationTask: API.OperationMethod<MoveReplicationTaskMessage & RegionInput, MoveReplicationTaskResponse, MoveReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type RebootReplicationInstanceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Reboots a replication instance. Rebooting results in a momentary outage, until the
 * replication instance becomes available again.
 */
export declare const rebootReplicationInstance: API.OperationMethod<RebootReplicationInstanceMessage & RegionInput, RebootReplicationInstanceResponse, RebootReplicationInstanceError, Credentials | HttpClient.HttpClient>;
export type RefreshSchemasError = InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Populates the schema for the specified endpoint. This is an asynchronous operation and
 * can take several minutes. You can check the status of this operation by calling the
 * DescribeRefreshSchemasStatus operation.
 */
export declare const refreshSchemas: API.OperationMethod<RefreshSchemasMessage & RegionInput, RefreshSchemasResponse, RefreshSchemasError, Credentials | HttpClient.HttpClient>;
export type ReloadReplicationTablesError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Reloads the target database table with the source data for a given DMS Serverless
 * replication configuration.
 *
 * You can only use this operation with a task in the RUNNING state, otherwise the service
 * will throw an `InvalidResourceStateFault` exception.
 */
export declare const reloadReplicationTables: API.OperationMethod<ReloadReplicationTablesMessage & RegionInput, ReloadReplicationTablesResponse, ReloadReplicationTablesError, Credentials | HttpClient.HttpClient>;
export type ReloadTablesError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Reloads the target database table with the source data.
 *
 * You can only use this operation with a task in the `RUNNING` state, otherwise
 * the service will throw an `InvalidResourceStateFault` exception.
 */
export declare const reloadTables: API.OperationMethod<ReloadTablesMessage & RegionInput, ReloadTablesResponse, ReloadTablesError, Credentials | HttpClient.HttpClient>;
export type RemoveTagsFromResourceError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Removes metadata tags from an DMS resource, including replication instance, endpoint,
 * subnet group, and migration task. For more information, see
 * `Tag`
 * data type
 * description.
 */
export declare const removeTagsFromResource: API.OperationMethod<RemoveTagsFromResourceMessage & RegionInput, RemoveTagsFromResourceResponse, RemoveTagsFromResourceError, Credentials | HttpClient.HttpClient>;
export type RunFleetAdvisorLsaAnalysisError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Runs large-scale assessment (LSA) analysis on every Fleet Advisor collector in your account.
 */
export declare const runFleetAdvisorLsaAnalysis: API.OperationMethod<RunFleetAdvisorLsaAnalysisRequest & RegionInput, RunFleetAdvisorLsaAnalysisResponse, RunFleetAdvisorLsaAnalysisError, Credentials | HttpClient.HttpClient>;
export type StartDataMigrationError = FailedDependencyFault | InvalidOperationFault | InvalidResourceStateFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Starts the specified data migration.
 */
export declare const startDataMigration: API.OperationMethod<StartDataMigrationMessage & RegionInput, StartDataMigrationResponse, StartDataMigrationError, Credentials | HttpClient.HttpClient>;
export type StartExtensionPackAssociationError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues the installation of the extension pack on your target database. If other
 * requests created by `Start*` operations are already in the migration project's
 * queue, the installation begins after they complete.
 *
 * This operation requires a non-virtual target data provider.
 *
 * If the extension pack already exists, the operation reinstalls it. To ensure
 * compatibility, reconvert your database objects if the version has changed since your last
 * conversion. For more information, see Using extension packs in DMS Schema Conversion.
 *
 * To check the status of the request, call
 * DescribeExtensionPackAssociations using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:AssociateExtensionPack`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startExtensionPackAssociation: API.OperationMethod<StartExtensionPackAssociationMessage & RegionInput, StartExtensionPackAssociationResponse, StartExtensionPackAssociationError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelAssessmentError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an assessment of the selected source metadata models (database objects such as
 * tables, views, and procedures) to evaluate conversion complexity to the target database
 * format. If other requests created by `Start*` operations are already in the
 * migration project's queue, the assessment begins after they complete.
 *
 * The assessment request loads metadata models that are not yet in the metadata tree, but
 * does not reload metadata models that are already present. If your source database has
 * changed since the metadata was loaded, refresh the affected metadata models with
 * StartMetadataModelImport before calling this operation.
 *
 * To check the status of the assessment request, call
 * DescribeMetadataModelAssessments using the returned
 * `RequestIdentifier` as a filter.
 *
 * To export the conversion assessment report after the request completes successfully,
 * call ExportMetadataModelAssessment.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelAssessment`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelAssessment: API.OperationMethod<StartMetadataModelAssessmentMessage & RegionInput, StartMetadataModelAssessmentResponse, StartMetadataModelAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelConversionError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues a conversion of the selected source metadata models (database objects such as
 * tables, views, and procedures) to the target database format. If other requests created
 * by `Start*` operations are already in the migration project's queue, the
 * conversion begins after they complete.
 *
 * The conversion request loads metadata models that are not yet in the metadata tree, but
 * does not reload metadata models that are already present. If your source database has
 * changed since the metadata was loaded, refresh the affected metadata models with
 * StartMetadataModelImport before calling this operation.
 *
 * If converted objects already exist in the target metadata tree, the conversion
 * overwrites them, including any manual edits.
 *
 * To check the status of the conversion request, call
 * DescribeMetadataModelConversions using the returned
 * `RequestIdentifier` as a filter.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelConversion with the returned
 * `RequestIdentifier`.
 *
 * After the conversion completes successfully:
 *
 * - To export a post-conversion assessment report, call
 * ExportMetadataModelAssessment.
 *
 * - To retrieve converted code, use any of the following
 * options:
 *
 * - DescribeMetadataModel and
 * DescribeMetadataModelChildren - navigate the target metadata
 * tree and retrieve converted definitions.
 *
 * - StartMetadataModelExportAsScript - export as data definition
 * language (DDL) scripts to your Amazon S3 bucket.
 *
 * - StartMetadataModelExportToTarget - apply directly to your
 * target database.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelConversion`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelConversion: API.OperationMethod<StartMetadataModelConversionMessage & RegionInput, StartMetadataModelConversionResponse, StartMetadataModelConversionError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelCreationError = AccessDeniedFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Queues the creation of a metadata model in the source metadata tree. If other requests
 * created by `Start*` operations are already in the migration project's queue, the
 * creation begins after they complete.
 *
 * This operation supports only Microsoft SQL Server to Aurora PostgreSQL and
 * Microsoft SQL Server to Amazon RDS for PostgreSQL conversion paths.
 *
 * To check the status of the creation request, call
 * DescribeMetadataModelCreations using the returned
 * `RequestIdentifier` as a filter.
 *
 * To cancel a queued or in-progress request, call
 * CancelMetadataModelCreation with the returned
 * `RequestIdentifier`.
 *
 * Calling
 * StartMetadataModelImport with `Refresh` deletes metadata models
 * created by this operation.
 *
 * After the creation completes successfully:
 *
 * - To evaluate conversion complexity, call
 * StartMetadataModelAssessment.
 *
 * - To convert to the target database format, call
 * StartMetadataModelConversion.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelCreation`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelCreation: API.OperationMethod<StartMetadataModelCreationMessage & RegionInput, StartMetadataModelCreationResponse, StartMetadataModelCreationError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelExportAsScriptError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an export of metadata models (database objects such as tables, views, and
 * procedures) as a data definition language (DDL) script. The script is stored as a ZIP
 * archive in the Amazon S3 bucket associated with the migration project. If other requests
 * created by `Start*` operations are already in the migration project's queue,
 * the export begins after they complete.
 *
 * When exporting from the target metadata tree, the export applies only to metadata
 * models created by conversion. Metadata models imported from the database are
 * skipped.
 *
 * To check the status of the export request, call
 * DescribeMetadataModelExportsAsScript using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelExportAsScripts`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelExportAsScript: API.OperationMethod<StartMetadataModelExportAsScriptMessage & RegionInput, StartMetadataModelExportAsScriptResponse, StartMetadataModelExportAsScriptError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelExportToTargetError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an export of the selected converted metadata models (database objects such as
 * tables, views, and procedures) to your target database. If other requests created by
 * `Start*` operations are already in the migration project's queue, the export
 * begins after they complete.
 *
 * This operation requires a non-virtual target data provider.
 *
 * The export applies only metadata models created by conversion. Metadata models
 * imported from the database are skipped.
 *
 * If objects with the same name already exist on the target database, the export
 * overwrites them.
 *
 * The operation installs the extension pack on the target database. For more
 * information, see Using extension packs in DMS Schema Conversion.
 *
 * To check the status of the export request, call
 * DescribeMetadataModelExportsToTarget using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelExportToTarget`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelExportToTarget: API.OperationMethod<StartMetadataModelExportToTargetMessage & RegionInput, StartMetadataModelExportToTargetResponse, StartMetadataModelExportToTargetError, Credentials | HttpClient.HttpClient>;
export type StartMetadataModelImportError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | ResourceQuotaExceededFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Queues an import of metadata models (database objects such as tables, views, and
 * procedures) from your data provider into the metadata tree. If other requests created
 * by `Start*` operations are already in the migration project's queue, the
 * import begins after they complete.
 *
 * To check the status of the import request, call
 * DescribeMetadataModelImports using the returned
 * `RequestIdentifier` as a filter.
 *
 * **Required permissions:**
 * `dms:StartMetadataModelImport`. For more information, see
 * Actions, resources, and condition keys for Database Migration Service.
 */
export declare const startMetadataModelImport: API.OperationMethod<StartMetadataModelImportMessage & RegionInput, StartMetadataModelImportResponse, StartMetadataModelImportError, Credentials | HttpClient.HttpClient>;
export type StartRecommendationsError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * End of support notice: On May 20, 2026, Amazon Web Services will end support for Amazon Web Services DMS Fleet Advisor;. After May 20, 2026, you will no longer be able to access the Amazon Web Services DMS Fleet Advisor; console or Amazon Web Services DMS Fleet Advisor; resources. For more information, see Amazon Web Services DMS Fleet Advisor end of support.
 *
 * Starts the analysis of your source database to provide recommendations of target
 * engines.
 *
 * You can create recommendations for multiple source databases using BatchStartRecommendations.
 */
export declare const startRecommendations: API.OperationMethod<StartRecommendationsRequest & RegionInput, StartRecommendationsResponse, StartRecommendationsError, Credentials | HttpClient.HttpClient>;
export type StartReplicationError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * For a given DMS Serverless replication configuration, DMS connects to the source
 * endpoint and collects the metadata to analyze the replication workload. Using this
 * metadata, DMS then computes and provisions the required capacity and starts replicating
 * to the target endpoint using the server resources that DMS has provisioned for the DMS
 * Serverless replication.
 */
export declare const startReplication: API.OperationMethod<StartReplicationMessage & RegionInput, StartReplicationResponse, StartReplicationError, Credentials | HttpClient.HttpClient>;
export type StartReplicationTaskError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Starts the replication task.
 *
 * For more information about DMS tasks, see Working with Migration Tasks in the
 * *Database Migration Service User Guide.*
 */
export declare const startReplicationTask: API.OperationMethod<StartReplicationTaskMessage & RegionInput, StartReplicationTaskResponse, StartReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type StartReplicationTaskAssessmentError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Starts the replication task assessment for unsupported data types in the source
 * database.
 *
 * You can only use this operation for a task if the following conditions are true:
 *
 * - The task must be in the `stopped` state.
 *
 * - The task must have successful connections to the source and target.
 *
 * If either of these conditions are not met, an `InvalidResourceStateFault`
 * error will result.
 *
 * For information about DMS task assessments, see Creating a task assessment report in the Database Migration Service User
 * Guide.
 */
export declare const startReplicationTaskAssessment: API.OperationMethod<StartReplicationTaskAssessmentMessage & RegionInput, StartReplicationTaskAssessmentResponse, StartReplicationTaskAssessmentError, Credentials | HttpClient.HttpClient>;
export type StartReplicationTaskAssessmentRunError = AccessDeniedFault | InvalidResourceStateFault | KMSAccessDeniedFault | KMSDisabledFault | KMSFault | KMSInvalidStateFault | KMSKeyNotAccessibleFault | KMSNotFoundFault | ResourceAlreadyExistsFault | ResourceNotFoundFault | S3AccessDeniedFault | S3ResourceNotFoundFault | CommonErrors;
/**
 * Starts a new premigration assessment run for one or more individual assessments of a
 * migration task.
 *
 * The assessments that you can specify depend on the source and target database engine and
 * the migration type defined for the given task. To run this operation, your migration task
 * must already be created. After you run this operation, you can review the status of each
 * individual assessment. You can also run the migration task manually after the assessment
 * run and its individual assessments complete.
 */
export declare const startReplicationTaskAssessmentRun: API.OperationMethod<StartReplicationTaskAssessmentRunMessage & RegionInput, StartReplicationTaskAssessmentRunResponse, StartReplicationTaskAssessmentRunError, Credentials | HttpClient.HttpClient>;
export type StopDataMigrationError = FailedDependencyFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Stops the specified data migration.
 */
export declare const stopDataMigration: API.OperationMethod<StopDataMigrationMessage & RegionInput, StopDataMigrationResponse, StopDataMigrationError, Credentials | HttpClient.HttpClient>;
export type StopReplicationError = AccessDeniedFault | InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * For a given DMS Serverless replication configuration, DMS stops any and all ongoing
 * DMS Serverless replications. This command doesn't deprovision the stopped
 * replications.
 */
export declare const stopReplication: API.OperationMethod<StopReplicationMessage & RegionInput, StopReplicationResponse, StopReplicationError, Credentials | HttpClient.HttpClient>;
export type StopReplicationTaskError = InvalidResourceStateFault | ResourceNotFoundFault | CommonErrors;
/**
 * Stops the replication task.
 */
export declare const stopReplicationTask: API.OperationMethod<StopReplicationTaskMessage & RegionInput, StopReplicationTaskResponse, StopReplicationTaskError, Credentials | HttpClient.HttpClient>;
export type TestConnectionError = AccessDeniedFault | InvalidResourceStateFault | KMSKeyNotAccessibleFault | ResourceNotFoundFault | ResourceQuotaExceededFault | CommonErrors;
/**
 * Tests the connection between the replication instance and the endpoint.
 */
export declare const testConnection: API.OperationMethod<TestConnectionMessage & RegionInput, TestConnectionResponse, TestConnectionError, Credentials | HttpClient.HttpClient>;
export type UpdateSubscriptionsToEventBridgeError = AccessDeniedFault | InvalidResourceStateFault | CommonErrors;
/**
 * Migrates 10 active and enabled Amazon SNS subscriptions at a time and converts them to
 * corresponding Amazon EventBridge rules. By default, this operation migrates subscriptions
 * only when all your replication instance versions are 3.4.5 or higher. If any replication
 * instances are from versions earlier than 3.4.5, the operation raises an error and tells you
 * to upgrade these instances to version 3.4.5 or higher. To enable migration regardless of
 * version, set the `Force` option to true. However, if you don't upgrade instances
 * earlier than version 3.4.5, some types of events might not be available when you use Amazon
 * EventBridge.
 *
 * To call this operation, make sure that you have certain permissions added to your user
 * account. For more information, see Migrating event subscriptions to Amazon EventBridge in the
 * *Amazon Web Services Database Migration Service User Guide*.
 */
export declare const updateSubscriptionsToEventBridge: API.OperationMethod<UpdateSubscriptionsToEventBridgeMessage & RegionInput, UpdateSubscriptionsToEventBridgeResponse, UpdateSubscriptionsToEventBridgeError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=database-migration-service.d.ts.map