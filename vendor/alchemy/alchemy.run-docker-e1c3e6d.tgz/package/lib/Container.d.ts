import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Duration from "effect/Duration";
import * as Effect from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as Path from "effect/Path";
import type { PlatformError } from "effect/PlatformError";
import * as Redacted from "effect/Redacted";
import { Docker } from "./Docker.ts";
import type { Providers } from "./Providers.ts";
export interface ContainerProps {
    /** Image reference or Docker image resource. */
    image: Container.Image;
    /** Docker context name or context resource. */
    context?: Docker.ContextRef;
    /**
     * Container name.
     *
     * @default Generated from stack, stage, logical id, and instance id.
     */
    name?: string;
    /** Command to run in the container. */
    command?: string[];
    /** Override the image's executable (`--entrypoint`); arguments belong in `command`. */
    entrypoint?: string;
    /** Absolute working directory for the container process. */
    workingDirectory?: string;
    /** Container image platform, e.g. `"linux/amd64"`; requires host support. */
    platform?: string;
    /** Container environment variables. Use Redacted for secrets. */
    environment?: Record<string, string | Redacted.Redacted<string>>;
    /** Hostname inside the container. Changing it recreates the container. */
    hostname?: string;
    /** Custom DNS server IP addresses. Docker defaults apply when omitted. */
    dns?: string[];
    /** DNS search domains; applied at container creation. */
    dnsSearch?: string[];
    /** Resolver options, for example `["ndots:1"]`; applied at creation. */
    dnsOptions?: string[];
    /**
     * Paths to Docker env files, forwarded in the declared order as repeated
     * `--env-file` options. Explicit `environment` values are forwarded after
     * these files and take precedence in Docker. Editing a file's contents
     * replaces the container on the next deploy. Only a digest of the contents
     * is kept, on the container's own label; neither contents nor digest are
     * written to Alchemy state. Docker itself exposes the resolved values
     * through `docker inspect`, so treat env files as secrets.
     */
    envFiles?: string[];
    /** Host/container port mappings. */
    ports?: Container.PortMapping[];
    /** Volume or bind mounts. */
    volumes?: Container.VolumeMapping[];
    /** Restart policy. */
    restart?: "no" | "always" | "on-failure" | "unless-stopped";
    /**
     * Container labels. Alchemy's internal ownership labels are added
     * automatically; the `alchemy::` prefix is reserved.
     */
    labels?: Record<string, string>;
    /**
     * Grace period before Docker forcefully kills the container after stopping
     * it.
     */
    stopTimeout?: Duration.Input;
    /**
     * Managed network attachments. When set, Docker creates the container on
     * the first network rather than implicitly joining the default `bridge`.
     * Other endpoints are connected before the container starts.
     */
    networks?: Container.NetworkMapping[];
    /**
     * Network namespace. Use `{ container: id }` to share another container's
     * namespace. Container-shared networking cannot set a hostname, custom DNS,
     * extra hosts, published ports or separate network attachments.
     */
    networkMode?: Container.NetworkMode;
    /** IPC namespace selection, e.g. `"private"`, `"host"` or `"container:<id>"`. */
    ipcNamespace?: string;
    /** PID namespace selection, e.g. `"host"` or `"container:<id>"`. Omit for the private default. */
    pidNamespace?: string;
    /** Namespace-scoped kernel settings. Docker rejects unsupported or host-wide sysctls. */
    sysctls?: Record<string, string>;
    /** Linux capabilities to add, for example `SYS_ADMIN`. */
    capAdd?: string[];
    /** Linux capabilities to drop, for example `["ALL"]`. */
    capDrop?: string[];
    /** Hard memory limit in Docker's byte-suffix format, e.g. `"512m"`. */
    memory?: string;
    /**
     * Size of `/dev/shm`, e.g. `"256m"`; separate from the container memory limit.
     * Requires a private or shareable IPC namespace; host/container IPC shares
     * another namespace's memory and cannot be resized by this container.
     */
    sharedMemorySize?: string;
    /**
     * Combined memory-plus-swap limit in Docker's byte-suffix format.
     * Requires `memory`. Set to the same value to disable swap, or `"-1"`
     * to allow unlimited swap (subject to the host).
     */
    memorySwap?: string;
    /** Soft memory limit under contention, e.g. `"256m"`. */
    memoryReservation?: string;
    /** CPU quota, in cores (e.g. `0.5` limits to half a CPU). */
    cpus?: number;
    /** Maximum number of processes and threads in the container. */
    pidsLimit?: number;
    /** Mount the container's root filesystem read-only. Writable paths need a volume or tmpfs. */
    readOnlyRootFilesystem?: boolean;
    /** Prevent processes from gaining additional privileges through exec. */
    noNewPrivileges?: boolean;
    /** Disable Docker's default isolation safeguards; use only for trusted workloads. @default false */
    privileged?: boolean;
    /** Run Docker's init process to forward signals and reap child processes. */
    init?: boolean;
    /** Runtime user, e.g. `"1000:1000"` or `"app"`. Omit to keep the image's user. */
    user?: string;
    /** Keep standard input open when the container is not attached. @default false */
    keepStdinOpen?: boolean;
    /** Allocate a pseudo-terminal for the main process. @default false */
    allocatePseudoTerminal?: boolean;
    /** Request GPU devices, e.g. `"all"` or `"device=0"`; requires a GPU-capable runtime. */
    gpuDevices?: string;
    /**
     * Seccomp JSON profile path on the Docker CLI host, or `"builtin"` to
     * select Docker's default policy. `"unconfined"` explicitly disables it.
     * Changes to a profile file's contents recreate the container.
     */
    seccompProfile?: string;
    /**
     * Name of a preloaded AppArmor profile, e.g. `"docker-default"`.
     * Requires AppArmor support on the target host. `"unconfined"` disables it.
     */
    appArmorProfile?: string;
    /** Docker user-namespace mode. `"host"` opts out of daemon user remapping. */
    userNamespace?: string;
    /** Supplementary Linux group names or numeric GIDs. */
    groupAdd?: string[];
    /** Per-process resource limits. `-1` represents unlimited. */
    ulimits?: Record<string, Container.Ulimit>;
    /** Docker log driver, e.g. `"local"`, `"json-file"`, or `"none"`. */
    logDriver?: string;
    /** Driver-specific settings, such as `{ "max-size": "10m", "max-file": "3" }`. */
    logOptions?: Record<string, string>;
    /** Relative OOM score adjustment on Linux, from -1000 to 1000. */
    oomScoreAdjustment?: number;
    /** Stop signal, e.g. `"SIGTERM"` or `"SIGINT"`. */
    stopSignal?: string;
    /** Writable in-memory mounts, including size and POSIX mode controls. */
    tmpfs?: Container.TmpfsMount[];
    /** Host devices to expose to the container. */
    devices?: Container.DeviceMapping[];
    /**
     * Extra `/etc/hosts` entries, each `hostname:address`. Docker's
     * `host-gateway` alias resolves to the host machine, so
     * `"host.docker.internal:host-gateway"` reaches services listening on the
     * developer's machine from inside the container.
     *
     * On Linux `host-gateway` is the bridge gateway address, so those packets
     * traverse the host's `INPUT` chain — under a default-deny firewall the
     * name resolves and the connection then times out. See the Host Access
     * examples.
     */
    extraHosts?: string[];
    /** Remove the container when it exits. @default false */
    removeOnExit?: boolean;
    /** Start the container after creation/reconciliation. @default false */
    start?: boolean;
    /** Docker healthcheck configuration. */
    healthcheck?: Container.Healthcheck;
}
export declare namespace Container {
    type Status = "created" | "running" | "paused" | "restarting" | "removing" | "exited" | "dead";
    type Image = string | {
        imageRef: string;
        imageId?: string;
    };
    interface PortMapping {
        /** External port on the host. */
        external: number | string;
        /** Internal port inside the container. */
        internal: number | string;
        /** Protocol used for the mapping. @default "tcp" */
        protocol?: "tcp" | "udp";
    }
    interface VolumeMapping {
        /** Host path or named volume source. */
        hostPath: string;
        /** Container path. */
        containerPath: string;
        /** Mount read-only. @default false */
        readOnly?: boolean;
    }
    interface TmpfsMount {
        /** Absolute mount target in the container, e.g. `"/tmp"`. */
        path: string;
        /** Docker byte-suffix size, e.g. `"32m"`. Omit for the engine default. */
        size?: string;
        /** POSIX mode as a number, e.g. `0o1777` for a sticky world-writable directory. */
        mode?: number;
    }
    interface Ulimit {
        /** Process soft limit. `-1` means unlimited. */
        soft: number;
        /** Process hard limit. `-1` means unlimited. */
        hard: number;
    }
    interface NetworkMapping {
        /** Network name or ID. */
        name: string;
        /** Network aliases for the container. */
        aliases?: string[];
        /** Static IPv4 address from the referenced network's subnet. */
        ipv4Address?: string;
        /** Static IPv6 address; the referenced network must have IPv6 enabled. */
        ipv6Address?: string;
        /** Default gateway preference for this attachment. @default 0 */
        gatewayPriority?: number;
        /** Driver options for this endpoint, not the underlying Docker.Network. */
        driverOpts?: Record<string, string>;
    }
    type NetworkMode = string | {
        container: string;
    };
    interface DeviceMapping {
        /** Host device path. */
        hostPath: string;
        /** Container device path. */
        containerPath: string;
        /** Cgroup permissions. @default "rwm" */
        permissions?: string;
    }
    interface Healthcheck {
        /**
         * Command to run for health checks. A string runs in the container's
         * shell. An array follows Docker's healthcheck `Test` form:
         * `["CMD-SHELL", "pg_isready -U app"]`, `["CMD", "pg_isready", "-U", "app"]`,
         * or `["NONE"]` to disable the image's healthcheck.
         */
        cmd: string[] | string;
        /** Time between checks. */
        interval?: Duration.Input;
        /** Maximum time a check may run. */
        timeout?: Duration.Input;
        /** Consecutive failures before unhealthy. */
        retries?: number;
        /** Startup grace period. */
        startPeriod?: Duration.Input;
        /** Check interval during startup. Requires Docker API 1.44+. */
        startInterval?: Duration.Input;
    }
}
export interface Container extends Resource<"Docker.Container", ContainerProps, {
    /** Docker container id. */
    id: string;
    /** Docker container name. */
    name: string;
    /** Docker container state. */
    status: Container.Status;
    /** Creation timestamp in milliseconds since epoch. */
    createdAt: number;
    /** Image reference used to create the container. */
    imageRef: string;
    /**
     * Map of internal container ports to their bound host ports.
     * Format: `"80/tcp" -> 8080`.
     */
    ports: Record<string, number>;
    /** Configured network namespace, when reported by Docker. */
    networkMode?: string;
    /** Added Linux capabilities, when reported by Docker. */
    capAdd?: string[];
    /** Configured host devices, when reported by Docker. */
    devices?: Container.DeviceMapping[];
}, never, Providers, ContainerLookup> {
}
/**
 * Props for {@link Container.lookup}: find a container this stack
 * doesn't manage by its name.
 */
export interface ContainerLookup {
    /** Container name. */
    name: string;
    /**
     * Docker context the engine is reached through.
     * @default the current context
     */
    context?: string;
}
/**
 * A Docker container managed through the active Docker context.
 *
 * This resource creates, starts, stops, inspects, and removes containers through
 * the Docker CLI. It is not interchangeable with `Cloudflare.Container`, which
 * manages Cloudflare's container platform; use pushed image references to bridge
 * Docker-built images into cloud container runtimes.
 *
 *
 * ### Running Containers
 * **Example:** Nginx with a published port
 * ```typescript
 * const nginx = yield* Docker.Container("nginx", {
 *   image: "nginx:alpine",
 *   ports: [{ external: 8080, internal: 80 }],
 *   start: true,
 * });
 * ```
 *
 * ### Secret Environment
 * **Example:** Redacted env var
 * ```typescript
 * const password = yield* Config.Redacted("POSTGRES_PASSWORD");
 * const db = yield* Docker.Container("postgres", {
 *   image: "postgres:18-alpine",
 *   environment: {
 *     POSTGRES_PASSWORD: password,
 *   },
 *   start: true,
 * });
 * ```
 *
 * ### Environment Files
 * **Example:** Layered Docker env files
 * ```typescript
 * const app = yield* Docker.Container("app", {
 *   image: "ghcr.io/acme/app:latest",
 *   envFiles: ["./config/base.env", "./config/production.env"],
 *   // Explicit values are passed after env files and take precedence.
 *   environment: { LOG_LEVEL: "info" },
 * });
 * ```
 *
 * Editing an env file replaces the container on the next deploy, as does
 * adopting a container that uses env files (once, so later edits are tracked).
 * Alchemy reads
 * the files at plan time but keeps only a digest of their contents, on the
 * container's own label; neither the values nor the digest are written to
 * Alchemy state. Docker exposes the resolved values through `docker inspect`,
 * so treat env files as secrets.
 *
 * ### Networks and Volumes
 * **Example:** PostgreSQL with persistent storage
 * ```typescript
 * const network = yield* Docker.Network("app-network");
 * const data = yield* Docker.Volume("postgres-data");
 * const postgresName = "app-postgres";
 * yield* Docker.Container("postgres", {
 *   name: postgresName,
 *   image: "postgres:18-alpine",
 *   ports: [{ external: 15432, internal: 5432 }],
 *   volumes: [{ hostPath: data.name, containerPath: "/var/lib/postgresql/data" }],
 *   networks: [{ name: network.name, aliases: ["postgres"] }],
 *   start: true,
 * });
 * const runtime = yield* Docker.inspectContainer(postgresName);
 * ```
 *
 * ### Configured network endpoints
 * `Docker.Network` owns subnets, IPAM and driver settings for the shared network.
 * The container declares only its own attachment: alias, optional static IP,
 * gateway priority and endpoint driver options. Docker allocates IPs when omitted.
 *
 * **Example:** Attach to a dual-stack network with a fixed address
 * ```typescript
 * const network = yield* Docker.Network("backend", {
 *   enableIPv6: true,
 *   ipam: { config: [
 *     { subnet: "10.51.0.0/24" },
 *     { subnet: "fd51:3456:789a::/64" },
 *   ] },
 * });
 * yield* Docker.Container("api", {
 *   image: "nginx:alpine",
 *   hostname: "api",
 *   networks: [{
 *     name: network.name,
 *     aliases: ["api"],
 *     ipv4Address: "10.51.0.10",
 *     ipv6Address: "fd51:3456:789a::10",
 *     gatewayPriority: 1,
 *   }],
 *   start: true,
 * });
 * ```
 *
 * Declaring `networks` without `networkMode` attaches only the listed networks:
 * Docker's implicit default `bridge` is not added. On legacy/adopted containers,
 * Alchemy detaches that implicit bridge while keeping externally added networks.
 * Omitting both options retains Docker's ordinary default networking.
 * Each attachment must refer to a distinct Docker network, even when the
 * same network is referenced once by name and again by ID.
 *
 * Network attachment changes reconnect only the managed endpoint without
 * replacing the container. Docker can temporarily interrupt traffic during
 * reconnection. If Docker rejects an update, Alchemy attempts to restore the
 * previously observed attachment; restoration can also fail if Docker refuses
 * it, so the update is not atomic. Alchemy leaves
 * externally attached networks untouched. `hostname`, `dns`, `dnsSearch` and
 * `dnsOptions` are creation-time settings and changes replace the container.
 * Invalid options fail with `InvalidContainerOptions`, whose `path` identifies
 * the rejected configuration property before replacement.
 *
 * ### Host Access
 * `extraHosts` writes lines into the container's `/etc/hosts`; it changes name
 * resolution and nothing else. Docker's `host-gateway` alias resolves to the
 * host machine, which is how a container reaches a service on the developer's
 * loopback.
 *
 * On Linux `host-gateway` is the Docker bridge gateway (typically
 * `172.17.0.1`), so a container's packets to it arrive on the host's `INPUT`
 * chain. Under a default-deny firewall — ufw ships
 * `DEFAULT_INPUT_POLICY="DROP"` — the hostname resolves correctly and the
 * connection then times out, which reads like an application bug rather than a
 * firewall one. Allow the bridge subnet to fix it:
 * `sudo ufw allow from 172.16.0.0/12`.
 *
 * **Example:** Reach a service on the developer's machine
 * ```typescript
 * const api = yield* Docker.Container("api", {
 *   image: "ghcr.io/acme/api:latest",
 *   // `host-gateway` resolves to the host machine, so a database listening
 *   // on the developer's loopback is reachable from inside the container.
 *   extraHosts: ["host.docker.internal:host-gateway"],
 *   environment: {
 *     DATABASE_URL: "postgres://postgres@host.docker.internal:5432/app",
 *   },
 *   start: true,
 * });
 * ```
 *
 * **Example:** Pin a hostname to a fixed address
 * ```typescript
 * const api = yield* Docker.Container("api", {
 *   image: "ghcr.io/acme/api:latest",
 *   // Any `hostname:address` pair — host access is just the common case.
 *   extraHosts: ["service.example:192.0.2.10"],
 *   start: true,
 * });
 * ```
 *
 * ### Runtime Options
 * **Example:** Allocate shared memory for PostgreSQL
 * ```typescript
 * const password = yield* Alchemy.makeRandom("DatabasePassword", { bytes: 16 });
 * yield* Docker.Container("db", {
 *   image: "postgres:18-alpine",
 *   environment: { POSTGRES_PASSWORD: password },
 *   sharedMemorySize: "256m", // --shm-size, not the container memory limit
 *   start: true,
 * });
 * ```
 *
 * **Example:** Configure process, platform, and namespace settings
 * ```typescript
 * yield* Docker.Container("job", {
 *   image: "alpine:3.22",
 *   platform: "linux/amd64",
 *   entrypoint: "/bin/sh",
 *   command: ["-c", "echo ready"],
 *   workingDirectory: "/workspace",
 *   ipcNamespace: "private",
 *   sysctls: { "net.ipv4.ip_unprivileged_port_start": "1024" },
 * });
 * ```
 *
 * **Example:** Contain a background worker
 * ```typescript
 * const worker = yield* Docker.Container("worker", {
 *   image: "oven/bun:1",
 *   memory: "512m",
 *   memorySwap: "512m",
 *   memoryReservation: "256m",
 *   cpus: 0.5,
 *   pidsLimit: 128,
 *   readOnlyRootFilesystem: true,
 *   capDrop: ["ALL"],
 *   noNewPrivileges: true,
 *   init: true,
 *   user: "1000:1000",
 *   tmpfs: [{ path: "/tmp", size: "32m", mode: 0o1777 }],
 * });
 * ```
 *
 * **Example:** Customize confinement, process limits, and log rotation
 * ```typescript
 * const api = yield* Docker.Container("api", {
 *   image: "ghcr.io/acme/api:latest",
 *   seccompProfile: "./security/api-seccomp.json", // client-side JSON; edits roll the container
 *   appArmorProfile: "my-loaded-profile",          // must already be loaded on the host
 *   groupAdd: ["1000"],
 *   ulimits: { nofile: { soft: 1024, hard: 4096 } },
 *   logDriver: "local",
 *   logOptions: { "max-size": "10m", "max-file": "3" },
 *   oomScoreAdjustment: 200,
 *   stopSignal: "SIGTERM",
 * });
 * ```
 *
 * **Example:** Share a donor container's network namespace
 * ```typescript
 * const donor = yield* Docker.Container("donor", { image: "redis:alpine" });
 * const sidecar = yield* Docker.Container("sidecar", {
 *   image: "busybox:latest",
 *   networkMode: { container: donor.id },
 * });
 * ```
 *
 * **Example:** Add capabilities and devices
 * ```typescript
 * const worker = yield* Docker.Container("worker", {
 *   image: "ubuntu:latest",
 *   capAdd: ["SYS_ADMIN"],
 *   devices: [{ hostPath: "/dev/fuse", containerPath: "/dev/fuse" }],
 * });
 * ```
 *
 * **Example:** Publish on any free host port
 * ```typescript
 * const api = yield* Docker.Container("api", {
 *   image: "ghcr.io/acme/api:latest",
 *   // `external: 0` lets Docker choose; the assigned port is reported back.
 *   ports: [{ external: 0, internal: 3000 }],
 *   start: true,
 * });
 * const hostPort = api.ports["3000/tcp"];
 * ```
 *
 * ### Traefik
 * **Example:** Route a container through Traefik
 * ```typescript
 * const api = yield* Docker.Container("api", {
 *   image: "ghcr.io/acme/api:latest",
 *   networks: [{ name: "traefik" }],
 *   labels: {
 *     "traefik.enable": "true",
 *     "traefik.http.routers.api.rule": "Host(`api.example.com`)",
 *     "traefik.http.services.api.loadbalancer.server.port": "3000",
 *   },
 *   stopTimeout: "30 seconds",
 *   start: true,
 * });
 * ```
 *
 * **Example:** Use a Docker.Context resource
 * ```typescript
 * const remote = yield* Docker.Context("remote", {
 *   name: "remote-build",
 *   docker: "host=ssh://docker@example.com",
 * });
 *
 * const api = yield* Docker.Container("api", {
 *   image: "nginx:alpine",
 *   context: remote,
 * });
 * ```
 *
 * ### Looking up an existing container
 * `Container.lookup` references a container Alchemy doesn't manage (created with
 * the Docker CLI, Compose or another stack). It is read during plan/deploy,
 * never created, updated or removed.
 *
 * **Example:** Reference an existing container
 * ```typescript
 * const db = Docker.Container.lookup({ name: "postgres" });
 * ```
 *
 * @resource
 * @product Container
 */
export declare const Container: import("alchemy/Resource").ResourceClass<Container>;
/**
 * Inspect a Docker container by name and return normalized runtime details.
 *
 * This is a small public wrapper around Docker's raw inspect output. It returns
 * the stable data Alchemy callers typically need, including bound host ports.
 */
export declare const inspectContainer: (name: string, context?: Docker.ContextRef) => Effect.Effect<Container["Attributes"], PlatformError, Docker>;
export declare const ContainerProvider: () => import("effect/Layer").Layer<Provider.Provider<Container>, never, Docker | FileSystem.FileSystem | Path.Path | import("alchemy/Stack").Stack | import("alchemy/Stage").Stage>;
declare const InvalidContainerOptions_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "InvalidContainerOptions";
} & Readonly<A>;
/**
 * Raised before Docker is called when a container's options cannot be
 * combined, e.g. sharing another container's network namespace while
 * publishing ports.
 */
export declare class InvalidContainerOptions extends InvalidContainerOptions_base<{
    /** Property path in the declared Docker.Container configuration. */
    readonly path: string;
    readonly message: string;
}> {
}
export {};
//# sourceMappingURL=Container.d.ts.map