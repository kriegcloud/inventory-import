import * as API from "@distilled.cloud/core/api";
import { type GithubOpError, type GithubOpContext } from "../protocol.ts";
export type { GithubOpError, GithubOpContext };
/** The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied. */
export type CreateCampaignRequestManagersList = Array<string>;
/** The slugs of the teams to set as the campaign managers. */
export type CreateCampaignRequestTeamManagersList = Array<string>;
/** The alert numbers */
export type CreateCampaignRequestCodeScanningAlertsItemAlertNumbersList = Array<number>;
export interface CreateCampaignRequestCodeScanningAlertsItem {
    /** The repository id */
    repository_id: number;
    /** The alert numbers */
    alert_numbers: CreateCampaignRequestCodeScanningAlertsItemAlertNumbersList;
}
/** The code scanning alerts to include in this campaign */
export type CreateCampaignRequestCodeScanningAlertsList = Array<CreateCampaignRequestCodeScanningAlertsItem>;
export interface CreateCampaignRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The name of the campaign */
    name: string;
    /** A description for the campaign */
    description: string;
    /** The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied. */
    managers?: CreateCampaignRequestManagersList | undefined;
    /** The slugs of the teams to set as the campaign managers. */
    team_managers?: CreateCampaignRequestTeamManagersList | undefined;
    /** The end date and time of the campaign. The date must be in the future. */
    ends_at: string;
    /** The contact link of the campaign. Must be a URI. */
    contact_link?: string | null | undefined;
    /** The code scanning alerts to include in this campaign */
    code_scanning_alerts?: CreateCampaignRequestCodeScanningAlertsList | null | undefined;
    /** If true, will automatically generate issues for the campaign. The default is false. */
    generate_issues?: boolean | undefined;
}
/** A GitHub user. */
export interface SimpleUser {
    name?: string | null | undefined;
    email?: string | null | undefined;
    login: string;
    id: number;
    node_id: string;
    avatar_url: string;
    gravatar_id: string | null;
    url: string;
    html_url: string;
    followers_url: string;
    following_url: string;
    gists_url: string;
    starred_url: string;
    subscriptions_url: string;
    organizations_url: string;
    repos_url: string;
    events_url: string;
    received_events_url: string;
    type: string;
    site_admin: boolean;
    starred_at?: string | undefined;
    user_view_type?: string | undefined;
}
/** The campaign managers */
export type CampaignSummaryManagersList = Array<SimpleUser>;
export interface TeamPermissions {
    pull: boolean;
    triage: boolean;
    push: boolean;
    maintain: boolean;
    admin: boolean;
}
/** The ownership type of the team */
export type TeamType = "enterprise" | "organization";
/** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
export type TeamAccessSource = "direct" | "organization" | "enterprise";
/** The ownership type of the team */
export type NullableTeamSimpleType = "enterprise" | "organization";
/** Groups of organization members that gives permissions on specified repositories. */
export interface NullableTeamSimple {
    /** Unique identifier of the team */
    id: number;
    node_id: string;
    /** URL for the team */
    url: string;
    members_url: string;
    /** Name of the team */
    name: string;
    /** Description of the team */
    description: string | null;
    /** Permission that the team will have for its repositories */
    permission: string;
    /** The level of privacy this team should have */
    privacy?: string | undefined;
    /** The notification setting the team has set */
    notification_setting?: string | undefined;
    html_url: string;
    repositories_url: string;
    slug: string;
    /** Distinguished Name (DN) that team maps to within LDAP environment */
    ldap_dn?: string | undefined;
    /** The ownership type of the team */
    type: NullableTeamSimpleType;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
}
/** Groups of organization members that gives permissions on specified repositories. */
export interface Team {
    id: number;
    node_id: string;
    name: string;
    slug: string;
    description: string | null;
    privacy?: string | undefined;
    notification_setting?: string | undefined;
    permission: string;
    permissions?: TeamPermissions | undefined;
    url: string;
    html_url: string;
    members_url: string;
    repositories_url: string;
    /** The ownership type of the team */
    type: TeamType;
    /** How the team's access to the repository was granted. This property is only present when the team is returned in a repository context, such as `GET /repos/{owner}/{repo}/teams`. */
    access_source?: TeamAccessSource | undefined;
    /** Unique identifier of the organization to which this team belongs */
    organization_id?: number | undefined;
    /** Unique identifier of the enterprise to which this team belongs */
    enterprise_id?: number | undefined;
    parent: NullableTeamSimple | null;
}
/** The campaign team managers */
export type CampaignSummaryTeamManagersList = Array<Team>;
/** Indicates whether a campaign is open or closed */
export type CampaignState = "open" | "closed";
export interface CampaignSummaryAlertStats {
    /** The number of open alerts */
    open_count: number;
    /** The number of closed alerts */
    closed_count: number;
    /** The number of in-progress alerts */
    in_progress_count: number;
}
/** The campaign metadata and alert stats. */
export interface CampaignSummary {
    /** The number of the newly created campaign */
    number: number;
    /** The date and time the campaign was created, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    created_at: string;
    /** The date and time the campaign was last updated, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    updated_at: string;
    /** The campaign name */
    name?: string | undefined;
    /** The campaign description */
    description: string;
    /** The campaign managers */
    managers: CampaignSummaryManagersList;
    /** The campaign team managers */
    team_managers?: CampaignSummaryTeamManagersList | undefined;
    /** The date and time the campaign was published, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    published_at?: string | undefined;
    /** The date and time the campaign has ended, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    ends_at: string;
    /** The date and time the campaign was closed, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. Will be null if the campaign is still open. */
    closed_at?: string | null | undefined;
    state: CampaignState;
    /** The contact link of the campaign. */
    contact_link: string | null;
    alert_stats?: CampaignSummaryAlertStats | undefined;
}
export interface DeleteCampaignRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The campaign number. */
    campaign_number: number;
}
export interface DeleteCampaignResponse {
}
export interface GetCampaignSummaryRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The campaign number. */
    campaign_number: number;
}
export type ListOrgCampaignsRequestDirection = "asc" | "desc";
export type ListOrgCampaignsRequestSort = "created" | "updated" | "ends_at" | "published";
export interface ListOrgCampaignsRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    page?: number | undefined;
    /** The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." */
    per_page?: number | undefined;
    /** The direction to sort the results by. */
    direction?: ListOrgCampaignsRequestDirection | (string & {}) | undefined;
    /** If specified, only campaigns with this state will be returned. */
    state?: CampaignState | (string & {}) | undefined;
    /** The property by which to sort the results. */
    sort?: ListOrgCampaignsRequestSort | (string & {}) | undefined;
}
export type ListOrgCampaignsResponseBodyList = Array<CampaignSummary>;
export type ListOrgCampaignsResponse = ListOrgCampaignsResponseBodyList;
/** The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied. */
export type UpdateCampaignRequestManagersList = Array<string>;
/** The slugs of the teams to set as the campaign managers. */
export type UpdateCampaignRequestTeamManagersList = Array<string>;
export interface UpdateCampaignRequest {
    /** The organization name. The name is not case sensitive. */
    org: string;
    /** The campaign number. */
    campaign_number: number;
    /** The name of the campaign */
    name?: string | undefined;
    /** A description for the campaign */
    description?: string | undefined;
    /** The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied. */
    managers?: UpdateCampaignRequestManagersList | undefined;
    /** The slugs of the teams to set as the campaign managers. */
    team_managers?: UpdateCampaignRequestTeamManagersList | undefined;
    /** The end date and time of the campaign, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ. */
    ends_at?: string | undefined;
    /** The contact link of the campaign. Must be a URI. */
    contact_link?: string | null | undefined;
    state?: CampaignState | (string & {}) | undefined;
}
export type CreateCampaignError = GithubOpError;
/** Create a campaign for an organization Create a campaign for an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. Fine-grained tokens must have the "Code scanning alerts" repository permissions (read) on all repositories included in the campaign. */
export declare const createCampaign: API.OperationMethod<CreateCampaignRequest, CampaignSummary, CreateCampaignError, GithubOpContext>;
export type DeleteCampaignError = GithubOpError;
/** Delete a campaign for an organization Deletes a campaign in an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. */
export declare const deleteCampaign: API.OperationMethod<DeleteCampaignRequest, DeleteCampaignResponse, DeleteCampaignError, GithubOpContext>;
export type GetCampaignSummaryError = GithubOpError;
/** Get a campaign for an organization Gets a campaign for an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. */
export declare const getCampaignSummary: API.OperationMethod<GetCampaignSummaryRequest, CampaignSummary, GetCampaignSummaryError, GithubOpContext>;
export type ListOrgCampaignsError = GithubOpError;
/** List campaigns for an organization Lists campaigns in an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. */
export declare const listOrgCampaigns: API.PaginatedOperationMethod<ListOrgCampaignsRequest, ListOrgCampaignsResponse, ListOrgCampaignsError, GithubOpContext, CampaignSummary>;
export type UpdateCampaignError = GithubOpError;
/** Update a campaign Updates a campaign in an organization. The authenticated user must be an owner or security manager for the organization to use this endpoint. OAuth app tokens and personal access tokens (classic) need the `security_events` scope to use this endpoint. */
export declare const updateCampaign: API.OperationMethod<UpdateCampaignRequest, CampaignSummary, UpdateCampaignError, GithubOpContext>;
//# sourceMappingURL=campaigns.d.ts.map