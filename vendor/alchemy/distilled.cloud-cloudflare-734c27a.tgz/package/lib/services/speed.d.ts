import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import { ResultInfo } from "../pagination.ts";
import { type CloudflareOpError, type CloudflareOpContext } from "../protocol.ts";
export type { CloudflareOpError, CloudflareOpContext };
declare const Forbidden_base: S.TaggedErrorClass<"Forbidden", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class Forbidden extends /*@__PURE__*/ Forbidden_base {
}
declare const TestScheduleAlreadyExists_base: S.TaggedErrorClass<"TestScheduleAlreadyExists", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TestScheduleAlreadyExists extends /*@__PURE__*/ TestScheduleAlreadyExists_base {
}
declare const TestScheduleNotFound_base: S.TaggedErrorClass<"TestScheduleNotFound", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TestScheduleNotFound extends /*@__PURE__*/ TestScheduleNotFound_base {
}
declare const TestScheduleQuotaReached_base: S.TaggedErrorClass<"TestScheduleQuotaReached", {
    readonly code: any;
    readonly message: any;
    readonly body: any;
    readonly headers: any;
}>;
export declare class TestScheduleQuotaReached extends /*@__PURE__*/ TestScheduleQuotaReached_base {
}
export type PagesTestsCreateRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface CreatePageTestRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: PagesTestsCreateRequestRegion | (string & {}) | undefined;
}
export type PagesTestsCreateResponseDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesTestsCreateResponseDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesTestsCreateResponseDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsCreateResponseDesktopReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesTestsCreateResponseDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesTestsCreateResponseDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesTestsCreateResponseDesktopReportDeviceType | null | undefined;
    error?: PagesTestsCreateResponseDesktopReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesTestsCreateResponseDesktopReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesTestsCreateResponseMobileReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesTestsCreateResponseMobileReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesTestsCreateResponseMobileReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsCreateResponseMobileReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesTestsCreateResponseMobileReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesTestsCreateResponseMobileReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesTestsCreateResponseMobileReportDeviceType | null | undefined;
    error?: PagesTestsCreateResponseMobileReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesTestsCreateResponseMobileReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesTestsCreateResponseRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface PagesTestsCreateResponseRegion {
    label?: string | null | undefined;
    /** A test region. */
    value?: PagesTestsCreateResponseRegionValue | null | undefined;
}
export type PagesTestsCreateResponseScheduleFrequency = "DAILY" | "WEEKLY";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreatePageTestResponse {
    /** UUID. */
    id?: string | null | undefined;
    date?: string | null | undefined;
    /** The Lighthouse report. */
    desktopReport?: PagesTestsCreateResponseDesktopReport | null | undefined;
    /** The Lighthouse report. */
    mobileReport?: PagesTestsCreateResponseMobileReport | null | undefined;
    /** A test region with a label. */
    region?: PagesTestsCreateResponseRegion | null | undefined;
    /** The frequency of the test. */
    scheduleFrequency?: PagesTestsCreateResponseScheduleFrequency | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export type ScheduleCreateRequestFrequency = "DAILY" | "WEEKLY";
export type ScheduleCreateRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface CreateScheduleRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** The frequency of the scheduled test. Defaults to WEEKLY for free plans, DAILY for paid plans. */
    frequency?: ScheduleCreateRequestFrequency | (string & {}) | undefined;
    /** A test region. */
    region?: ScheduleCreateRequestRegion | (string & {}) | undefined;
}
export type ScheduleCreateResponseScheduleFrequency = "DAILY" | "WEEKLY";
export type ScheduleCreateResponseScheduleRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface ScheduleCreateResponseSchedule {
    /** The frequency of the test. */
    frequency?: ScheduleCreateResponseScheduleFrequency | null | undefined;
    /** A test region. */
    region?: ScheduleCreateResponseScheduleRegion | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export type ScheduleCreateResponseTestDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export type ScheduleCreateResponseTestDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface ScheduleCreateResponseTestDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: ScheduleCreateResponseTestDesktopReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type ScheduleCreateResponseTestDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface ScheduleCreateResponseTestDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: ScheduleCreateResponseTestDesktopReportDeviceType | null | undefined;
    error?: ScheduleCreateResponseTestDesktopReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: ScheduleCreateResponseTestDesktopReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type ScheduleCreateResponseTestMobileReportDeviceType = "DESKTOP" | "MOBILE";
export type ScheduleCreateResponseTestMobileReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface ScheduleCreateResponseTestMobileReportError {
    /** The error code of the Lighthouse result. */
    code?: ScheduleCreateResponseTestMobileReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type ScheduleCreateResponseTestMobileReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface ScheduleCreateResponseTestMobileReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: ScheduleCreateResponseTestMobileReportDeviceType | null | undefined;
    error?: ScheduleCreateResponseTestMobileReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: ScheduleCreateResponseTestMobileReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type ScheduleCreateResponseTestRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface ScheduleCreateResponseTestRegion {
    label?: string | null | undefined;
    /** A test region. */
    value?: ScheduleCreateResponseTestRegionValue | null | undefined;
}
export type ScheduleCreateResponseTestScheduleFrequency = "DAILY" | "WEEKLY";
export interface ScheduleCreateResponseTest {
    /** UUID. */
    id?: string | null | undefined;
    date?: string | null | undefined;
    /** The Lighthouse report. */
    desktopReport?: ScheduleCreateResponseTestDesktopReport | null | undefined;
    /** The Lighthouse report. */
    mobileReport?: ScheduleCreateResponseTestMobileReport | null | undefined;
    /** A test region with a label. */
    region?: ScheduleCreateResponseTestRegion | null | undefined;
    /** The frequency of the test. */
    scheduleFrequency?: ScheduleCreateResponseTestScheduleFrequency | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface CreateScheduleResponse {
    /** The test schedule. */
    schedule?: ScheduleCreateResponseSchedule | null | undefined;
    test?: ScheduleCreateResponseTest | null | undefined;
}
export type PagesTestsDeleteRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface DeletePageTestRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: PagesTestsDeleteRequestRegion | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeletePageTestResponse {
    /** Number of items affected. */
    count?: number | null | undefined;
}
export type ScheduleDeleteRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface DeleteScheduleRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: ScheduleDeleteRequestRegion | (string & {}) | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface DeleteScheduleResponse {
    /** Number of items affected. */
    count?: number | null | undefined;
}
export interface GetPageTestRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    testId: string;
}
export type PagesTestsGetResponseDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesTestsGetResponseDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesTestsGetResponseDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsGetResponseDesktopReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesTestsGetResponseDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesTestsGetResponseDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesTestsGetResponseDesktopReportDeviceType | null | undefined;
    error?: PagesTestsGetResponseDesktopReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesTestsGetResponseDesktopReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesTestsGetResponseMobileReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesTestsGetResponseMobileReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesTestsGetResponseMobileReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsGetResponseMobileReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesTestsGetResponseMobileReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesTestsGetResponseMobileReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesTestsGetResponseMobileReportDeviceType | null | undefined;
    error?: PagesTestsGetResponseMobileReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesTestsGetResponseMobileReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesTestsGetResponseRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface PagesTestsGetResponseRegion {
    label?: string | null | undefined;
    /** A test region. */
    value?: PagesTestsGetResponseRegionValue | null | undefined;
}
export type PagesTestsGetResponseScheduleFrequency = "DAILY" | "WEEKLY";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetPageTestResponse {
    /** UUID. */
    id?: string | null | undefined;
    date?: string | null | undefined;
    /** The Lighthouse report. */
    desktopReport?: PagesTestsGetResponseDesktopReport | null | undefined;
    /** The Lighthouse report. */
    mobileReport?: PagesTestsGetResponseMobileReport | null | undefined;
    /** A test region with a label. */
    region?: PagesTestsGetResponseRegion | null | undefined;
    /** The frequency of the test. */
    scheduleFrequency?: PagesTestsGetResponseScheduleFrequency | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export type ScheduleGetRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface GetScheduleRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** A test region. */
    region?: ScheduleGetRequestRegion | (string & {}) | undefined;
}
export type ScheduleGetResponseFrequency = "DAILY" | "WEEKLY";
export type ScheduleGetResponseRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface GetScheduleResponse {
    /** The frequency of the test. */
    frequency?: ScheduleGetResponseFrequency | null | undefined;
    /** A test region. */
    region?: ScheduleGetResponseRegion | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export interface ListAvailabilitiesRequest {
    /** Identifier. */
    zoneId: string;
}
export interface AvailabilitiesListResponseQuotaQuotasPerPlanValue {
    business?: number | null | undefined;
    enterprise?: number | null | undefined;
    free?: number | null | undefined;
    pro?: number | null | undefined;
}
export interface AvailabilitiesListResponseQuotaQuotasPerPlan {
    /** Counts per account plan. */
    value?: AvailabilitiesListResponseQuotaQuotasPerPlanValue | null | undefined;
}
export type AvailabilitiesListResponseQuotaScheduleQuotasPerPlanValue = AvailabilitiesListResponseQuotaQuotasPerPlanValue;
export type AvailabilitiesListResponseQuotaScheduleQuotasPerPlan = AvailabilitiesListResponseQuotaQuotasPerPlan;
export interface AvailabilitiesListResponseQuota {
    /** Cloudflare plan. */
    plan?: string | null | undefined;
    /** The number of tests available per plan. */
    quotasPerPlan?: AvailabilitiesListResponseQuotaQuotasPerPlan | null | undefined;
    /** The number of remaining schedules available. */
    remainingSchedules?: number | null | undefined;
    /** The number of remaining tests available. */
    remainingTests?: number | null | undefined;
    /** The number of schedules available per plan. */
    scheduleQuotasPerPlan?: AvailabilitiesListResponseQuotaQuotasPerPlan | null | undefined;
}
export type AvailabilitiesListResponseRegionsItemValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface AvailabilitiesListResponseRegionsItem {
    label?: string | null | undefined;
    /** A test region. */
    value?: AvailabilitiesListResponseRegionsItemValue | null | undefined;
}
export type AvailabilitiesListResponseRegionsList = Array<AvailabilitiesListResponseRegionsItem>;
export type AvailabilitiesListResponseRegionsPerPlanBusinessItemValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface AvailabilitiesListResponseRegionsPerPlanBusinessItem {
    label?: string | null | undefined;
    /** A test region. */
    value?: AvailabilitiesListResponseRegionsPerPlanBusinessItemValue | null | undefined;
}
export type AvailabilitiesListResponseRegionsPerPlanBusinessList = Array<AvailabilitiesListResponseRegionsPerPlanBusinessItem>;
export type AvailabilitiesListResponseRegionsPerPlanEnterpriseItemValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface AvailabilitiesListResponseRegionsPerPlanEnterpriseItem {
    label?: string | null | undefined;
    /** A test region. */
    value?: AvailabilitiesListResponseRegionsPerPlanEnterpriseItemValue | null | undefined;
}
export type AvailabilitiesListResponseRegionsPerPlanEnterpriseList = Array<AvailabilitiesListResponseRegionsPerPlanEnterpriseItem>;
export type AvailabilitiesListResponseRegionsPerPlanFreeItemValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface AvailabilitiesListResponseRegionsPerPlanFreeItem {
    label?: string | null | undefined;
    /** A test region. */
    value?: AvailabilitiesListResponseRegionsPerPlanFreeItemValue | null | undefined;
}
export type AvailabilitiesListResponseRegionsPerPlanFreeList = Array<AvailabilitiesListResponseRegionsPerPlanFreeItem>;
export type AvailabilitiesListResponseRegionsPerPlanProItemValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface AvailabilitiesListResponseRegionsPerPlanProItem {
    label?: string | null | undefined;
    /** A test region. */
    value?: AvailabilitiesListResponseRegionsPerPlanProItemValue | null | undefined;
}
export type AvailabilitiesListResponseRegionsPerPlanProList = Array<AvailabilitiesListResponseRegionsPerPlanProItem>;
export interface AvailabilitiesListResponseRegionsPerPlan {
    business?: AvailabilitiesListResponseRegionsPerPlanBusinessList | null | undefined;
    enterprise?: AvailabilitiesListResponseRegionsPerPlanEnterpriseList | null | undefined;
    free?: AvailabilitiesListResponseRegionsPerPlanFreeList | null | undefined;
    pro?: AvailabilitiesListResponseRegionsPerPlanProList | null | undefined;
}
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface ListAvailabilitiesResponse {
    quota?: AvailabilitiesListResponseQuota | null | undefined;
    regions?: AvailabilitiesListResponseRegionsList | null | undefined;
    /** Available regions. */
    regionsPerPlan?: AvailabilitiesListResponseRegionsPerPlan | null | undefined;
}
export interface ListPagesRequest {
    /** Identifier. */
    zoneId: string;
}
export type PagesListResultItemRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface PagesListResultItemRegion {
    label?: string | null | undefined;
    /** A test region. */
    value?: PagesListResultItemRegionValue | null | undefined;
}
export type PagesListResultItemScheduleFrequency = "DAILY" | "WEEKLY";
export type PagesListResultItemTestsItemDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesListResultItemTestsItemDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesListResultItemTestsItemDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesListResultItemTestsItemDesktopReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesListResultItemTestsItemDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesListResultItemTestsItemDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesListResultItemTestsItemDesktopReportDeviceType | null | undefined;
    error?: PagesListResultItemTestsItemDesktopReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesListResultItemTestsItemDesktopReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesListResultItemTestsItemMobileReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesListResultItemTestsItemMobileReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesListResultItemTestsItemMobileReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesListResultItemTestsItemMobileReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesListResultItemTestsItemMobileReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesListResultItemTestsItemMobileReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesListResultItemTestsItemMobileReportDeviceType | null | undefined;
    error?: PagesListResultItemTestsItemMobileReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesListResultItemTestsItemMobileReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesListResultItemTestsItemRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface PagesListResultItemTestsItemRegion {
    label?: string | null | undefined;
    /** A test region. */
    value?: PagesListResultItemTestsItemRegionValue | null | undefined;
}
export type PagesListResultItemTestsItemScheduleFrequency = "DAILY" | "WEEKLY";
export interface PagesListResultItemTestsItem {
    /** UUID. */
    id?: string | null | undefined;
    date?: string | null | undefined;
    /** The Lighthouse report. */
    desktopReport?: PagesListResultItemTestsItemDesktopReport | null | undefined;
    /** The Lighthouse report. */
    mobileReport?: PagesListResultItemTestsItemMobileReport | null | undefined;
    /** A test region with a label. */
    region?: PagesListResultItemTestsItemRegion | null | undefined;
    /** The frequency of the test. */
    scheduleFrequency?: PagesListResultItemTestsItemScheduleFrequency | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export type PagesListResultItemTestsList = Array<PagesListResultItemTestsItem>;
export interface PagesListResultItem {
    /** A test region with a label. */
    region?: PagesListResultItemRegion | null | undefined;
    /** The frequency of the test. */
    scheduleFrequency?: PagesListResultItemScheduleFrequency | null | undefined;
    tests?: PagesListResultItemTestsList | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export type PagesListResultList = Array<PagesListResultItem>;
export interface ListPagesResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PagesListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type PagesTestsListRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface ListPageTestsRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    page?: number | undefined;
    perPage?: number | undefined;
    /** A test region. */
    region?: PagesTestsListRequestRegion | (string & {}) | undefined;
}
export type PagesTestsListResultItemDesktopReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesTestsListResultItemDesktopReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesTestsListResultItemDesktopReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsListResultItemDesktopReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesTestsListResultItemDesktopReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesTestsListResultItemDesktopReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesTestsListResultItemDesktopReportDeviceType | null | undefined;
    error?: PagesTestsListResultItemDesktopReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesTestsListResultItemDesktopReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesTestsListResultItemMobileReportDeviceType = "DESKTOP" | "MOBILE";
export type PagesTestsListResultItemMobileReportErrorCode = "NOT_REACHABLE" | "DNS_FAILURE" | "NOT_HTML" | "LIGHTHOUSE_TIMEOUT" | "UNKNOWN";
export interface PagesTestsListResultItemMobileReportError {
    /** The error code of the Lighthouse result. */
    code?: PagesTestsListResultItemMobileReportErrorCode | null | undefined;
    /** Detailed error message. */
    detail?: string | null | undefined;
    /** The final URL displayed to the user. */
    finalDisplayedUrl?: string | null | undefined;
}
export type PagesTestsListResultItemMobileReportState = "RUNNING" | "COMPLETE" | "FAILED";
export interface PagesTestsListResultItemMobileReport {
    /** Cumulative Layout Shift. */
    cls?: number | null | undefined;
    /** The type of device. */
    deviceType?: PagesTestsListResultItemMobileReportDeviceType | null | undefined;
    error?: PagesTestsListResultItemMobileReportError | null | undefined;
    /** First Contentful Paint. */
    fcp?: number | null | undefined;
    /** The URL to the full Lighthouse JSON report. */
    jsonReportUrl?: string | null | undefined;
    /** Largest Contentful Paint. */
    lcp?: number | null | undefined;
    /** The Lighthouse performance score. */
    performanceScore?: number | null | undefined;
    /** Speed Index. */
    si?: number | null | undefined;
    /** The state of the Lighthouse report. */
    state?: PagesTestsListResultItemMobileReportState | null | undefined;
    /** Total Blocking Time. */
    tbt?: number | null | undefined;
    /** Time To First Byte. */
    ttfb?: number | null | undefined;
    /** Time To Interactive. */
    tti?: number | null | undefined;
}
export type PagesTestsListResultItemRegionValue = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface PagesTestsListResultItemRegion {
    label?: string | null | undefined;
    /** A test region. */
    value?: PagesTestsListResultItemRegionValue | null | undefined;
}
export type PagesTestsListResultItemScheduleFrequency = "DAILY" | "WEEKLY";
export interface PagesTestsListResultItem {
    /** UUID. */
    id?: string | null | undefined;
    date?: string | null | undefined;
    /** The Lighthouse report. */
    desktopReport?: PagesTestsListResultItemDesktopReport | null | undefined;
    /** The Lighthouse report. */
    mobileReport?: PagesTestsListResultItemMobileReport | null | undefined;
    /** A test region with a label. */
    region?: PagesTestsListResultItemRegion | null | undefined;
    /** The frequency of the test. */
    scheduleFrequency?: PagesTestsListResultItemScheduleFrequency | null | undefined;
    /** A URL. */
    url?: string | null | undefined;
}
export type PagesTestsListResultList = Array<PagesTestsListResultItem>;
export interface ListPageTestsResponse {
    /** The unwrapped `result` payload of the v4 response envelope. */
    result: PagesTestsListResultList;
    /** Pagination info from the envelope's `result_info`. */
    resultInfo?: ResultInfo | null | undefined;
}
export type PagesTrendRequestDeviceType = "DESKTOP" | "MOBILE";
export type PagesTrendRequestRegion = "asia-east1" | "asia-northeast1" | "asia-northeast2" | "asia-south1" | "asia-southeast1" | "australia-southeast1" | "europe-north1" | "europe-southwest1" | "europe-west1" | "europe-west2" | "europe-west3" | "europe-west4" | "europe-west8" | "europe-west9" | "me-west1" | "southamerica-east1" | "us-central1" | "us-east1" | "us-east4" | "us-south1" | "us-west1";
export interface TrendPageRequest {
    /** Identifier. */
    zoneId: string;
    /** A URL. */
    url: string;
    /** The type of device. */
    deviceType: PagesTrendRequestDeviceType | (string & {});
    /** A comma-separated list of metrics to include in the results. */
    metrics: string;
    /** A test region. */
    region: PagesTrendRequestRegion | (string & {});
    start: string;
    /** The timezone of the start and end timestamps. */
    tz: string;
    end?: string | undefined;
}
export type PagesTrendResponseClsList = Array<number>;
export type PagesTrendResponseFcpList = Array<number>;
export type PagesTrendResponseLcpList = Array<number>;
export type PagesTrendResponsePerformanceScoreList = Array<number>;
export type PagesTrendResponseSiList = Array<number>;
export type PagesTrendResponseTbtList = Array<number>;
export type PagesTrendResponseTtfbList = Array<number>;
export type PagesTrendResponseTtiList = Array<number>;
/** Unwrapped `result` payload of the Cloudflare v4 response envelope. */
export interface TrendPageResponse {
    /** Cumulative Layout Shift trend. */
    cls?: PagesTrendResponseClsList | null | undefined;
    /** First Contentful Paint trend. */
    fcp?: PagesTrendResponseFcpList | null | undefined;
    /** Largest Contentful Paint trend. */
    lcp?: PagesTrendResponseLcpList | null | undefined;
    /** The Lighthouse score trend. */
    performanceScore?: PagesTrendResponsePerformanceScoreList | null | undefined;
    /** Speed Index trend. */
    si?: PagesTrendResponseSiList | null | undefined;
    /** Total Blocking Time trend. */
    tbt?: PagesTrendResponseTbtList | null | undefined;
    /** Time To First Byte trend. */
    ttfb?: PagesTrendResponseTtfbList | null | undefined;
    /** Time To Interactive trend. */
    tti?: PagesTrendResponseTtiList | null | undefined;
}
export type CreatePageTestError = CloudflareOpError;
/** Starts a test for a specific webpage, in a specific region. */
export declare const createPageTest: API.OperationMethod<CreatePageTestRequest, CreatePageTestResponse, CreatePageTestError, CloudflareOpContext>;
export type CreateScheduleError = TestScheduleAlreadyExists | TestScheduleQuotaReached | Forbidden | CloudflareOpError;
/** Creates a scheduled test for a page. */
export declare const createSchedule: API.OperationMethod<CreateScheduleRequest, CreateScheduleResponse, CreateScheduleError, CloudflareOpContext>;
export type DeletePageTestError = CloudflareOpError;
/** Deletes all tests for a specific webpage from a specific region. Deleted tests are still counted as part of the quota. */
export declare const deletePageTest: API.OperationMethod<DeletePageTestRequest, DeletePageTestResponse, DeletePageTestError, CloudflareOpContext>;
export type DeleteScheduleError = TestScheduleNotFound | Forbidden | CloudflareOpError;
/** Deletes a scheduled test for a page. */
export declare const deleteSchedule: API.OperationMethod<DeleteScheduleRequest, DeleteScheduleResponse, DeleteScheduleError, CloudflareOpContext>;
export type GetPageTestError = CloudflareOpError;
/** Retrieves the result of a specific test. */
export declare const getPageTest: API.OperationMethod<GetPageTestRequest, GetPageTestResponse, GetPageTestError, CloudflareOpContext>;
export type GetScheduleError = TestScheduleNotFound | Forbidden | CloudflareOpError;
/** Retrieves the test schedule for a page in a specific region. */
export declare const getSchedule: API.OperationMethod<GetScheduleRequest, GetScheduleResponse, GetScheduleError, CloudflareOpContext>;
export type ListAvailabilitiesError = CloudflareOpError;
/** Retrieves quota for all plans, as well as the current zone quota. */
export declare const listAvailabilities: API.OperationMethod<ListAvailabilitiesRequest, ListAvailabilitiesResponse, ListAvailabilitiesError, CloudflareOpContext>;
export type ListPagesError = CloudflareOpError;
/** Lists all webpages which have been tested. */
export declare const listPages: API.PaginatedOperationMethod<ListPagesRequest, ListPagesResponse, ListPagesError, CloudflareOpContext, PagesListResultItem>;
export type ListPageTestsError = CloudflareOpError;
/** Test history (list of tests) for a specific webpage. */
export declare const listPageTests: API.PaginatedOperationMethod<ListPageTestsRequest, ListPageTestsResponse, ListPageTestsError, CloudflareOpContext, PagesTestsListResultItem>;
export type TrendPageError = CloudflareOpError;
/** Lists the core web vital metrics trend over time for a specific page. */
export declare const trendPage: API.OperationMethod<TrendPageRequest, TrendPageResponse, TrendPageError, CloudflareOpContext>;
//# sourceMappingURL=speed.d.ts.map