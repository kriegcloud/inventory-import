import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ExecutionRoleNotAssumable_base: S.TaggedErrorClass<"ExecutionRoleNotAssumable", {
    readonly message: any;
}>;
export declare class ExecutionRoleNotAssumable extends /*@__PURE__*/ ExecutionRoleNotAssumable_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type Name = string;
export type ScheduleGroupName = string;
export type ScheduleExpression = string;
export type StartDate = Date;
export type EndDate = Date;
export type Description = string;
export type ScheduleExpressionTimezone = string;
export type ScheduleState = string;
export type KmsKeyArn = string;
export type TargetArn = string;
export type RoleArn = string;
export type ResourceArn = string;
export interface DeadLetterConfig {
    Arn?: string | undefined;
}
export type MaximumEventAgeInSeconds = number;
export type MaximumRetryAttempts = number;
export interface RetryPolicy {
    MaximumEventAgeInSeconds?: number | undefined;
    MaximumRetryAttempts?: number | undefined;
}
export type TargetInput = string;
export type TaskDefinitionArn = string;
export type TaskCount = number;
export type LaunchType = string;
export type Subnet = string;
export type Subnets = string[];
export type SecurityGroup = string;
export type SecurityGroups = string[];
export type AssignPublicIp = string;
export interface AwsVpcConfiguration {
    Subnets: string[];
    SecurityGroups?: string[] | undefined;
    AssignPublicIp?: string | undefined;
}
export interface NetworkConfiguration {
    awsvpcConfiguration?: AwsVpcConfiguration | undefined;
}
export type PlatformVersion = string;
export type Group = string;
export type CapacityProvider = string;
export type CapacityProviderStrategyItemWeight = number;
export type CapacityProviderStrategyItemBase = number;
export interface CapacityProviderStrategyItem {
    capacityProvider: string;
    weight?: number | undefined;
    base?: number | undefined;
}
export type CapacityProviderStrategy = CapacityProviderStrategyItem[];
export type EnableECSManagedTags = boolean;
export type EnableExecuteCommand = boolean;
export type PlacementConstraintType = string;
export type PlacementConstraintExpression = string;
export interface PlacementConstraint {
    type?: string | undefined;
    expression?: string | undefined;
}
export type PlacementConstraints = PlacementConstraint[];
export type PlacementStrategyType = string;
export type PlacementStrategyField = string;
export interface PlacementStrategy {
    type?: string | undefined;
    field?: string | undefined;
}
export type PlacementStrategies = PlacementStrategy[];
export type PropagateTags = string;
export type ReferenceId = string;
export type TagKey = string;
export type TagValue = string;
export type TagMap = {
    [key: string]: string | undefined;
};
export type Tags = {
    [key: string]: string | undefined;
}[];
export interface EcsParameters {
    TaskDefinitionArn: string;
    TaskCount?: number | undefined;
    LaunchType?: string | undefined;
    NetworkConfiguration?: NetworkConfiguration | undefined;
    PlatformVersion?: string | undefined;
    Group?: string | undefined;
    CapacityProviderStrategy?: CapacityProviderStrategyItem[] | undefined;
    EnableECSManagedTags?: boolean | undefined;
    EnableExecuteCommand?: boolean | undefined;
    PlacementConstraints?: PlacementConstraint[] | undefined;
    PlacementStrategy?: PlacementStrategy[] | undefined;
    PropagateTags?: string | undefined;
    ReferenceId?: string | undefined;
    Tags?: {
        [key: string]: string | undefined;
    }[] | undefined;
}
export type DetailType = string;
export type Source = string;
export interface EventBridgeParameters {
    DetailType: string;
    Source: string;
}
export interface EventBridgePutEventsV2Parameters {
    DetailType: string;
    Source: string;
}
export type EventBridgeMetadataKey = string;
export type EventBridgeMetadataValue = string;
export type EventBridgeMetadataMap = {
    [key: string]: string | undefined;
};
export interface EventBridgePutRawEventsParameters {
    Metadata?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type TargetPartitionKey = string;
export interface KinesisParameters {
    PartitionKey: string;
}
export type SageMakerPipelineParameterName = string;
export type SageMakerPipelineParameterValue = string;
export interface SageMakerPipelineParameter {
    Name: string;
    Value: string;
}
export type SageMakerPipelineParameterList = SageMakerPipelineParameter[];
export interface SageMakerPipelineParameters {
    PipelineParameterList?: SageMakerPipelineParameter[] | undefined;
}
export type MessageGroupId = string;
export interface SqsParameters {
    MessageGroupId?: string | undefined;
}
export interface Target {
    Arn: string;
    RoleArn: string;
    DeadLetterConfig?: DeadLetterConfig | undefined;
    RetryPolicy?: RetryPolicy | undefined;
    Input?: string | undefined;
    EcsParameters?: EcsParameters | undefined;
    EventBridgeParameters?: EventBridgeParameters | undefined;
    EventBridgePutEventsV2Parameters?: EventBridgePutEventsV2Parameters | undefined;
    EventBridgePutRawEventsParameters?: EventBridgePutRawEventsParameters | undefined;
    KinesisParameters?: KinesisParameters | undefined;
    SageMakerPipelineParameters?: SageMakerPipelineParameters | undefined;
    SqsParameters?: SqsParameters | undefined;
}
export type FlexibleTimeWindowMode = string;
export type MaximumWindowInMinutes = number;
export interface FlexibleTimeWindow {
    Mode: string;
    MaximumWindowInMinutes?: number | undefined;
}
export type ClientToken = string;
export type ActionAfterCompletion = string;
export interface CreateScheduleInput {
    Name: string;
    GroupName?: string | undefined;
    ScheduleExpression: string;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    Description?: string | undefined;
    ScheduleExpressionTimezone?: string | undefined;
    State?: string | undefined;
    KmsKeyArn?: string | undefined;
    Target: Target;
    FlexibleTimeWindow: FlexibleTimeWindow;
    ClientToken?: string | undefined;
    ActionAfterCompletion?: string | undefined;
}
export type ScheduleArn = string;
export interface CreateScheduleOutput {
    ScheduleArn: string;
}
export interface Tag {
    Key: string;
    Value: string;
}
export type TagList = Tag[];
export interface CreateScheduleGroupInput {
    Name: string;
    Tags?: Tag[] | undefined;
    ClientToken?: string | undefined;
}
export type ScheduleGroupArn = string;
export interface CreateScheduleGroupOutput {
    ScheduleGroupArn: string;
}
export interface DeleteScheduleInput {
    Name: string;
    GroupName?: string | undefined;
    ClientToken?: string | undefined;
}
export interface DeleteScheduleOutput {
}
export interface DeleteScheduleGroupInput {
    Name: string;
    ClientToken?: string | undefined;
}
export interface DeleteScheduleGroupOutput {
}
export interface GetScheduleInput {
    Name: string;
    GroupName?: string | undefined;
}
export type CreationDate = Date;
export type LastModificationDate = Date;
export interface GetScheduleOutput {
    Arn?: string | undefined;
    GroupName?: string | undefined;
    Name?: string | undefined;
    ScheduleExpression?: string | undefined;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    Description?: string | undefined;
    ScheduleExpressionTimezone?: string | undefined;
    State?: string | undefined;
    CreationDate?: Date | undefined;
    LastModificationDate?: Date | undefined;
    KmsKeyArn?: string | undefined;
    Target?: Target | undefined;
    FlexibleTimeWindow?: FlexibleTimeWindow | undefined;
    ActionAfterCompletion?: string | undefined;
}
export interface GetScheduleGroupInput {
    Name: string;
}
export type ScheduleGroupState = string;
export interface GetScheduleGroupOutput {
    Arn?: string | undefined;
    Name?: string | undefined;
    State?: string | undefined;
    CreationDate?: Date | undefined;
    LastModificationDate?: Date | undefined;
}
export type ScheduleGroupNamePrefix = string;
export type NextToken = string;
export type MaxResults = number;
export interface ListScheduleGroupsInput {
    NamePrefix?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ScheduleGroupSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
    State?: string | undefined;
    CreationDate?: Date | undefined;
    LastModificationDate?: Date | undefined;
}
export type ScheduleGroupList = ScheduleGroupSummary[];
export interface ListScheduleGroupsOutput {
    NextToken?: string | undefined;
    ScheduleGroups: ScheduleGroupSummary[];
}
export type NamePrefix = string;
export interface ListSchedulesInput {
    GroupName?: string | undefined;
    NamePrefix?: string | undefined;
    State?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface TargetSummary {
    Arn: string;
}
export interface ScheduleSummary {
    Arn?: string | undefined;
    Name?: string | undefined;
    GroupName?: string | undefined;
    State?: string | undefined;
    CreationDate?: Date | undefined;
    LastModificationDate?: Date | undefined;
    Target?: TargetSummary | undefined;
}
export type ScheduleList = ScheduleSummary[];
export interface ListSchedulesOutput {
    NextToken?: string | undefined;
    Schedules: ScheduleSummary[];
}
export type TagResourceArn = string;
export interface ListTagsForResourceInput {
    ResourceArn: string;
}
export interface ListTagsForResourceOutput {
    Tags?: Tag[] | undefined;
}
export interface TagResourceInput {
    ResourceArn: string;
    Tags: Tag[];
}
export interface TagResourceOutput {
}
export type TagKeyList = string[];
export interface UntagResourceInput {
    ResourceArn: string;
    TagKeys: string[];
}
export interface UntagResourceOutput {
}
export interface UpdateScheduleInput {
    Name: string;
    GroupName?: string | undefined;
    ScheduleExpression: string;
    StartDate?: Date | undefined;
    EndDate?: Date | undefined;
    Description?: string | undefined;
    ScheduleExpressionTimezone?: string | undefined;
    State?: string | undefined;
    KmsKeyArn?: string | undefined;
    Target: Target;
    FlexibleTimeWindow: FlexibleTimeWindow;
    ClientToken?: string | undefined;
    ActionAfterCompletion?: string | undefined;
}
export interface UpdateScheduleOutput {
    ScheduleArn: string;
}
export type CreateScheduleError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ExecutionRoleNotAssumable | CommonErrors;
/**
 * Creates the specified schedule.
 */
export declare const createSchedule: API.OperationMethod<CreateScheduleInput & RegionInput, CreateScheduleOutput, CreateScheduleError, Credentials | HttpClient.HttpClient>;
export type CreateScheduleGroupError = ConflictException | InternalServerException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates the specified schedule group.
 */
export declare const createScheduleGroup: API.OperationMethod<CreateScheduleGroupInput & RegionInput, CreateScheduleGroupOutput, CreateScheduleGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduleError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified schedule.
 */
export declare const deleteSchedule: API.OperationMethod<DeleteScheduleInput & RegionInput, DeleteScheduleOutput, DeleteScheduleError, Credentials | HttpClient.HttpClient>;
export type DeleteScheduleGroupError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes the specified schedule group. Deleting a schedule group results in EventBridge Scheduler deleting all schedules associated with the group. When you delete a group, it remains in a `DELETING` state until all of its associated schedules are deleted. Schedules associated with the group that are set to run while the schedule group is in the process of being deleted might continue to invoke their targets until the schedule group and its associated schedules are deleted.
 *
 * This operation is eventually consistent.
 */
export declare const deleteScheduleGroup: API.OperationMethod<DeleteScheduleGroupInput & RegionInput, DeleteScheduleGroupOutput, DeleteScheduleGroupError, Credentials | HttpClient.HttpClient>;
export type GetScheduleError = InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified schedule.
 */
export declare const getSchedule: API.OperationMethod<GetScheduleInput & RegionInput, GetScheduleOutput, GetScheduleError, Credentials | HttpClient.HttpClient>;
export type GetScheduleGroupError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves the specified schedule group.
 */
export declare const getScheduleGroup: API.OperationMethod<GetScheduleGroupInput & RegionInput, GetScheduleGroupOutput, GetScheduleGroupError, Credentials | HttpClient.HttpClient>;
export type ListScheduleGroupsError = InternalServerException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of your schedule groups.
 */
export declare const listScheduleGroups: API.PaginatedOperationMethod<ListScheduleGroupsInput & RegionInput, ListScheduleGroupsOutput, ListScheduleGroupsError, Credentials | HttpClient.HttpClient, ScheduleGroupSummary>;
export type ListSchedulesError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a paginated list of your EventBridge Scheduler schedules.
 */
export declare const listSchedules: API.PaginatedOperationMethod<ListSchedulesInput & RegionInput, ListSchedulesOutput, ListSchedulesError, Credentials | HttpClient.HttpClient, ScheduleSummary>;
export type ListTagsForResourceError = InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists the tags associated with the Scheduler resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceInput & RegionInput, ListTagsForResourceOutput, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Assigns one or more tags (key-value pairs) to the specified EventBridge Scheduler resource. You can only assign tags to schedule groups.
 */
export declare const tagResource: API.OperationMethod<TagResourceInput & RegionInput, TagResourceOutput, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Removes one or more tags from the specified EventBridge Scheduler schedule group.
 */
export declare const untagResource: API.OperationMethod<UntagResourceInput & RegionInput, UntagResourceOutput, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateScheduleError = ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | ExecutionRoleNotAssumable | CommonErrors;
/**
 * Updates the specified schedule. When you call `UpdateSchedule`, EventBridge Scheduler uses all values, including empty values, specified in the request and overrides the existing schedule. This is by design. This means that if you do not set an optional field in your request, that field will be set to its system-default value after the update.
 *
 * Before calling this operation, we recommend that you call the `GetSchedule` API operation and make a note of all optional parameters for your `UpdateSchedule` call.
 */
export declare const updateSchedule: API.OperationMethod<UpdateScheduleInput & RegionInput, UpdateScheduleOutput, UpdateScheduleError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=scheduler.d.ts.map