import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import type * as Exit from "effect/Exit";
import * as Layer from "effect/Layer";
import type { BaseRuntimeContext } from "../RuntimeContext.ts";
import type { EventLifetime } from "./EventLifetime.ts";
export { WorkerEnvironment } from "./WorkerEnvironment.ts";
/**
 * The isolate-lifetime artifacts produced by a single layer build: the built
 * service Context, the resolved export for this entrypoint, the user's
 * RPC shape (a thunk — the shape is only populated once `serve` has run),
 * and the telemetry Layer override registered during init (a thunk for the
 * same reason).
 */
export interface WorkerBuild<Export = any, Runtime = WorkerRuntimeContextLike> {
    readonly context: Context.Context<any>;
    readonly runtimeContext: Runtime;
    readonly export: Export;
    readonly shape: () => Record<string, any>;
    readonly telemetry: () => Layer.Layer<never, any, any> | undefined;
}
/** The runtime-context surface the bridges read off the built `Self` service. */
export interface WorkerRuntimeContextLike extends BaseRuntimeContext {
    readonly exports: Effect.Effect<Record<string, any>>;
    readonly shape: () => Record<string, any>;
}
/**
 * `pin` registers an in-flight build promise with the calling event
 * (`ctx.waitUntil` / `state.waitUntil`). Every awaiting event must pin:
 * workerd schedules a promise's continuations back into its origin request
 * context and *drops* them if that context has ended
 * (`handle_cross_request_promise_resolution`), so the origin event must be
 * kept alive until the build settles or concurrent cold-start requests
 * would hang.
 */
export type Pin = (promise: Promise<unknown>) => unknown;
/** The engine-supplied half of a shared build. */
export interface SharedBuildOptions {
    /**
     * The platform services (file system, path, http client, logger, …) the
     * user's init closure and handlers run against.
     */
    readonly platform: Layer.Layer<any>;
    /** The runtime environment record — workerd `env`. */
    readonly env: Effect.Effect<Record<string, unknown>>;
    /**
     * Engine-specific services layered under the entrypoint (e.g. the
     * workerd execution context and account services), built from the
     * resolved environment record.
     */
    readonly extra?: ((env: Record<string, unknown>) => Layer.Layer<any>) | undefined;
}
export type SharedBuild = (pin: Pin) => Promise<Context.Context<any>>;
export declare const getSharedBuild: (entrypoint: object, stack: {
    name: string;
    stage: string;
}, options: SharedBuildOptions) => SharedBuild;
/**
 * Resolve one named export (`default`, a Durable Object class, a Workflow
 * class) against the shared build; memoized so listener assembly and the
 * captured services context resolve once per export. Same success-only
 * memoization contract as the shared build.
 */
export declare const getWorkerExport: <Export = any, Runtime = WorkerRuntimeContextLike>({ entrypoint, stack, exportName, }: {
    entrypoint: object;
    stack: {
        name: string;
        stage: string;
    };
    exportName: string;
}, options: SharedBuildOptions) => {
    build: (pin: Pin) => Promise<WorkerBuild<Export, Runtime>>;
};
/**
 * Encode an RPC call's exit for the wire: a `Stream` success becomes a
 * stream envelope (keeping the request scope open until the stream settles),
 * a typed failure becomes an error envelope, and a defect is thrown.
 */
export declare const handleRpcExit: (exit: Exit.Exit<any, any>, lifetime?: EventLifetime["Service"]) => Promise<any>;
//# sourceMappingURL=Worker.d.ts.map