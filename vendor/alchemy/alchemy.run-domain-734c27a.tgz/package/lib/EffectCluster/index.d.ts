import type { PoolLayer } from "@alchemy.run/effect-cluster/Pool";
import type { Providers } from "@alchemy.run/effect-cluster/Providers";
import type * as Cause from "effect/Cause";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as Layer from "effect/Layer";
import { WorkflowEngine } from "effect/workflow";
import type { Platform } from "../Platform.ts";
import { type Retention } from "./internal.ts";
export type { Retention } from "./internal.ts";
declare const DomainClassNotHosted_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "Cluster.DomainClassNotHosted";
} & Readonly<A>;
/** A Domain host entity was asked for an object of a class it doesn't host. */
export declare class DomainClassNotHosted extends DomainClassNotHosted_base<{
    readonly message: string;
}> {
}
declare const DomainEngineNotStarted_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => Cause.YieldableError & {
    readonly _tag: "Cluster.DomainEngineNotStarted";
} & Readonly<A>;
/** A saga's workflow engine was used before the runner joined the cluster. */
export declare class DomainEngineNotStarted extends DomainEngineNotStarted_base<{
    readonly message: string;
}> {
}
/**
 * Effect Cluster's engine, as a model's sagas register on it. Each step of a
 * run gets its own sequence of command ids (`CurrentActivity`), as on the
 * other hosts: a step that runs again, after a retry or when its runner died,
 * sends the same commands, and they commit once. Effect Cluster runs a step
 * with the context it was called with, so the step sees it.
 *
 * @internal
 */
export declare const sagaEngine: (engine: WorkflowEngine.WorkflowEngine["Service"]) => WorkflowEngine.WorkflowEngine["Service"];
/** Options for {@link layerEntities}. */
export interface EntitiesOptions<PoolReq> {
    /** The entity that hosts the model: its type in the cluster. */
    readonly name: string;
    /**
     * The module that exports the model's Layer (the one this platform is
     * provided to), usually `import.meta.url`. The pool's runners load it to
     * run the model.
     */
    readonly main: string;
    /**
     * The export of {@link main} that holds the model's Layer.
     * @default "default"
     */
    readonly handler?: string;
    /** The pool whose runners run the model, e.g. `ClusterDocker.SwarmPool("Default")`. */
    readonly pool: PoolLayer<PoolReq>;
    /**
     * How long the host keeps rows that only dedupe needs: command receipts,
     * policy delivery marks, cancelled scheduled commands, and Effect
     * Cluster's processed messages to the entity. Every runner sweeps them
     * each `interval`. Only pools with a cluster database sweep: on
     * `ClusterCloudflare.DurableObjectPool`, each instance keeps these rows in
     * its own storage, and they are kept.
     *
     * @default { receipts: "30 days", deliveries: "7 days", cancelled: "7 days", messages: "7 days", interval: "1 hour" }
     */
    readonly retention?: Retention;
}
/**
 * Host a domain model on Effect Cluster entities. Provide it to the model's
 * Layer, as `Domain.InMemory` or `DomainCloudflare.layerDurableObjects()` would be, in
 * every runtime that serves the model: a container, a Lambda, a Worker.
 *
 * The model's aggregate instances, view keys, policies and projection keys
 * are entity ids of one entity, `name`, each named after what it holds
 * (`Bank.AccountAggregate/a-1`). Built in a caller, the Layer deploys that
 * entity to `pool` and reaches it through the pool's gateway. The pool's
 * runners load the model's Layer from `main`, and there the same Layer
 * hosts the entity.
 *
 * Commands to one aggregate instance run one at a time, through each
 * instance's input gate. Every instance's events, state and outbox live in
 * the cluster's Postgres, in one table, and commit together. Scheduled
 * commands and retries are persisted messages delivered when they are due.
 * The model's sagas run on Effect Cluster's workflow engine. Over
 * `Domain.protocolWebSocket`, the caller holds a live read's WebSocket and
 * the instance that owns the key pushes every commit to it, over a
 * streamed call through the pool's gateway. On
 * `ClusterCloudflare.DurableObjectPool`, called from a Worker, the
 * instance's Durable Object holds the WebSocket instead, and hibernates
 * between commits. Over `Domain.protocolHttp`, live reads are streamed
 * responses that poll the owning instance.
 *
 * ### Hosting a model on Effect Cluster
 * **Example:** The model's Layer, served from a container
 * ```typescript
 * import * as Docker from "@alchemy.run/docker";
 * import * as ClusterDocker from "@alchemy.run/effect-cluster/Docker";
 * import * as DomainCluster from "@alchemy.run/domain/EffectCluster";
 * import * as Effect from "effect/Effect";
 * import * as Layer from "effect/Layer";
 * import { Bank, BankHandlers } from "./Bank.model.ts";
 * import { CustomerApi } from "./CustomerApi.api.ts";
 *
 * const Database = ClusterDocker.Database("Cluster");
 * const Default = ClusterDocker.SwarmPool("Default", { replicas: 2 }).pipe(
 *   Layer.provide(Database),
 * );
 *
 * export const BankLive = Bank.layer(BankHandlers).pipe(
 *   Layer.provide(
 *     DomainCluster.layerEntities({
 *       name: "Bank",
 *       main: import.meta.url,
 *       handler: "BankLive",
 *       pool: Default,
 *     }),
 *   ),
 * );
 *
 * export default class BankApi extends Docker.Service<BankApi>()(
 *   "BankApi",
 *   { main: import.meta.url, port: 3000 },
 *   Effect.gen(function* () {
 *     const api = yield* CustomerApi;
 *     return { fetch: api.fetch };
 *   }).pipe(Effect.provide(BankLive)),
 * ) {}
 * ```
 *
 * @layer
 * @provides Domain.Platform
 * @provides WorkflowEngine
 */
export declare const layerEntities: <PoolReq>(options: EntitiesOptions<PoolReq>) => Layer.Layer<Platform | WorkflowEngine.WorkflowEngine | SecureRandom.SecureRandom, never, PoolReq | Providers>;
//# sourceMappingURL=index.d.ts.map