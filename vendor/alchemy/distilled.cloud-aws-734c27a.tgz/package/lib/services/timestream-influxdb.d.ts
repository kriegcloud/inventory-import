import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
    readonly resourceId: any;
    readonly resourceType: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
    readonly retryAfterSeconds: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
    readonly reason: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type DbBackupName = string;
export type DbResourceId = string;
export type RetentionDays = number;
export type TagKey = string;
export type TagValue = string;
export type RequestTagMap = {
    [key: string]: string | undefined;
};
export interface CreateDbBackupInput {
    name: string;
    dbResourceId: string;
    retentionDays?: number | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DbBackupId = string;
export type Arn = string;
export type DbBackupStatus = "IN_PROGRESS" | "COMPLETED" | "FAILED" | "DELETING" | "DELETED" | (string & {});
export type DbBackupType = "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "CUSTOM_SCHEDULE" | "ON_DEMAND" | "CONTINUOUS" | (string & {});
export type EngineType = "INFLUXDB_V2" | "INFLUXDB_V3_CORE" | "INFLUXDB_V3_ENTERPRISE" | (string & {});
export type ResourceDeploymentType = "SINGLE_AZ" | "WITH_MULTIAZ_STANDBY" | "MULTI_NODE_READ_REPLICAS" | (string & {});
export type KmsKeyId = string;
export interface ClusterConfiguration {
    ingestQueryInstances?: number | undefined;
    queryOnlyInstances?: number | undefined;
    dedicatedCompactor?: boolean | undefined;
}
export type InstanceMode = "PRIMARY" | "STANDBY" | "REPLICA" | "INGEST" | "QUERY" | "COMPACT" | "PROCESS" | (string & {});
export type InstanceModeList = InstanceMode[];
export type DbInstanceType = "db.influx.medium" | "db.influx.large" | "db.influx.xlarge" | "db.influx.2xlarge" | "db.influx.4xlarge" | "db.influx.8xlarge" | "db.influx.12xlarge" | "db.influx.16xlarge" | "db.influx.24xlarge" | (string & {});
export interface NodeGroup {
    instanceModes: InstanceMode[];
    instanceType: DbInstanceType;
    count: number;
}
export type NodeGroupList = NodeGroup[];
export interface InfluxDBv3EnterpriseDeploymentConfiguration {
    nodeGroups: NodeGroup[];
}
export type DeploymentConfiguration = {
    InfluxDBv3Enterprise: InfluxDBv3EnterpriseDeploymentConfiguration;
};
export type DbParameterGroupId = string;
export interface S3Configuration {
    bucketName: string;
    enabled: boolean;
}
export interface LogDeliveryConfiguration {
    s3Configuration: S3Configuration;
}
export type FailoverMode = "AUTOMATIC" | "NO_FAILOVER" | (string & {});
export type DbStorageType = "InfluxIOIncludedT1" | "InfluxIOIncludedT2" | "InfluxIOIncludedT3" | (string & {});
export type AllocatedStorage = number;
export type VpcSubnetId = string;
export type VpcSubnetIdList = string[];
export type VpcSecurityGroupId = string;
export type VpcSecurityGroupIdList = string[];
export type NetworkType = "IPV4" | "DUAL" | (string & {});
export type IanaTimezone = string;
export type MaintenanceWindow = string;
export interface MaintenanceSchedule {
    timezone: string;
    preferredMaintenanceWindow: string;
}
export interface CreateDbBackupOutput {
    id: string;
    name?: string | undefined;
    arn: string;
    status?: DbBackupStatus | undefined;
    createdAt?: Date | undefined;
    expiresAfter?: string | undefined;
    dbResourceId?: string | undefined;
    type?: DbBackupType | undefined;
    engineType?: EngineType | undefined;
    deploymentType?: ResourceDeploymentType | undefined;
    kmsKeyId?: string | undefined;
    clusterConfiguration?: ClusterConfiguration | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    dbParameterGroupId?: string | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    failoverMode?: FailoverMode | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    vpcSubnetIds?: string[] | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    publiclyAccessible?: boolean | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
}
export type DbClusterName = string;
export type Username = string | redacted.Redacted<string>;
export type Password = string | redacted.Redacted<string>;
export type Organization = string;
export type Bucket = string;
export type Port = number;
export type DbParameterGroupIdentifier = string;
export type ClusterDeploymentType = "MULTI_NODE_READ_REPLICAS" | (string & {});
export type AutomatedDbBackupType = "HOURLY" | "DAILY" | "WEEKLY" | "MONTHLY" | "CUSTOM_SCHEDULE" | "CONTINUOUS" | (string & {});
export type AutomatedBackupRetentionDays = number;
export type AwsCronSchedule = string;
export interface DbBackupConfiguration {
    type: AutomatedDbBackupType;
    retentionDays: number;
    enabled: boolean;
    customSchedule?: string | undefined;
}
export type DbBackupConfigurationInputList = DbBackupConfiguration[];
export interface CreateDbClusterInput {
    name: string;
    username?: string | redacted.Redacted<string> | undefined;
    password?: string | redacted.Redacted<string> | undefined;
    organization?: string | undefined;
    bucket?: string | undefined;
    port?: number | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    networkType?: NetworkType | undefined;
    publiclyAccessible?: boolean | undefined;
    vpcSubnetIds: string[];
    vpcSecurityGroupIds: string[];
    deploymentType?: ClusterDeploymentType | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    failoverMode?: FailoverMode | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    dbBackupConfigurations?: DbBackupConfiguration[] | undefined;
    kmsKeyId?: string | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DbClusterId = string;
export type ClusterStatus = "CREATING" | "UPDATING" | "DELETING" | "AVAILABLE" | "FAILED" | "DELETED" | "MAINTENANCE" | "UPDATING_INSTANCE_TYPE" | "REBOOTING" | "REBOOT_FAILED" | "PARTIALLY_AVAILABLE" | "RESTORING" | "RESTORE_FAILED" | (string & {});
export interface CreateDbClusterOutput {
    dbClusterId?: string | undefined;
    dbClusterStatus?: ClusterStatus | undefined;
}
export type DbInstanceName = string;
export type DeploymentType = "SINGLE_AZ" | "WITH_MULTIAZ_STANDBY" | (string & {});
export interface CreateDbInstanceInput {
    name: string;
    username?: string | redacted.Redacted<string> | undefined;
    password: string | redacted.Redacted<string>;
    organization?: string | undefined;
    bucket?: string | undefined;
    dbInstanceType: DbInstanceType;
    vpcSubnetIds: string[];
    vpcSecurityGroupIds: string[];
    publiclyAccessible?: boolean | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage: number;
    dbParameterGroupIdentifier?: string | undefined;
    deploymentType?: DeploymentType | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbBackupConfigurations?: DbBackupConfiguration[] | undefined;
    kmsKeyId?: string | undefined;
}
export type DbInstanceId = string;
export type Status = "CREATING" | "AVAILABLE" | "DELETING" | "MODIFYING" | "UPDATING" | "DELETED" | "FAILED" | "UPDATING_DEPLOYMENT_TYPE" | "UPDATING_INSTANCE_TYPE" | "MAINTENANCE" | "REBOOTING" | "REBOOT_FAILED" | "RESTORING" | "RESTORE_FAILED" | (string & {});
export interface DbBackupConfigurationOutput {
    type: AutomatedDbBackupType;
    retentionDays: number;
    enabled: boolean;
    customSchedule?: string | undefined;
    nextAutomatedBackupTime?: Date | undefined;
}
export type DbBackupConfigurationOutputList = DbBackupConfigurationOutput[];
export interface CreateDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    availabilityZone?: string | undefined;
    secondaryAvailabilityZone?: string | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    dbClusterId?: string | undefined;
    instanceMode?: InstanceMode | undefined;
    instanceModes?: InstanceMode[] | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    lastMaintenanceTime?: Date | undefined;
    nextMaintenanceTime?: Date | undefined;
    dbBackupConfigurations?: DbBackupConfigurationOutput[] | undefined;
    kmsKeyId?: string | undefined;
}
export type DbParameterGroupName = string;
export type LogLevel = "debug" | "info" | "error" | (string & {});
export type TracingType = "log" | "jaeger" | "disabled" | (string & {});
export type DurationType = "hours" | "minutes" | "seconds" | "milliseconds" | "days" | (string & {});
export interface Duration {
    durationType: DurationType;
    value: number;
}
export interface InfluxDBv2Parameters {
    fluxLogEnabled?: boolean | undefined;
    logLevel?: LogLevel | undefined;
    noTasks?: boolean | undefined;
    queryConcurrency?: number | undefined;
    queryQueueSize?: number | undefined;
    tracingType?: TracingType | undefined;
    metricsDisabled?: boolean | undefined;
    httpIdleTimeout?: Duration | undefined;
    httpReadHeaderTimeout?: Duration | undefined;
    httpReadTimeout?: Duration | undefined;
    httpWriteTimeout?: Duration | undefined;
    influxqlMaxSelectBuckets?: number | undefined;
    influxqlMaxSelectPoint?: number | undefined;
    influxqlMaxSelectSeries?: number | undefined;
    pprofDisabled?: boolean | undefined;
    queryInitialMemoryBytes?: number | undefined;
    queryMaxMemoryBytes?: number | undefined;
    queryMemoryBytes?: number | undefined;
    sessionLength?: number | undefined;
    sessionRenewDisabled?: boolean | undefined;
    storageCacheMaxMemorySize?: number | undefined;
    storageCacheSnapshotMemorySize?: number | undefined;
    storageCacheSnapshotWriteColdDuration?: Duration | undefined;
    storageCompactFullWriteColdDuration?: Duration | undefined;
    storageCompactThroughputBurst?: number | undefined;
    storageMaxConcurrentCompactions?: number | undefined;
    storageMaxIndexLogFileSize?: number | undefined;
    storageNoValidateFieldSize?: boolean | undefined;
    storageRetentionCheckInterval?: Duration | undefined;
    storageSeriesFileMaxConcurrentSnapshotCompactions?: number | undefined;
    storageSeriesIdSetCacheSize?: number | undefined;
    storageWalMaxConcurrentWrites?: number | undefined;
    storageWalMaxWriteDelay?: Duration | undefined;
    uiDisabled?: boolean | undefined;
}
export type LogFormats = "full" | (string & {});
export type DataFusionRuntimeType = "multi-thread" | "multi-thread-alt" | (string & {});
export type PercentOrAbsoluteLong = {
    percent: string;
    absolute?: undefined;
} | {
    percent?: undefined;
    absolute: number;
};
export type PluginRepositorySecretArn = string;
export interface InfluxDBv3CoreParameters {
    queryFileLimit?: number | undefined;
    queryLogSize?: number | undefined;
    logFilter?: string | undefined;
    logFormat?: LogFormats | undefined;
    dataFusionNumThreads?: number | undefined;
    dataFusionRuntimeType?: DataFusionRuntimeType | undefined;
    dataFusionRuntimeDisableLifoSlot?: boolean | undefined;
    dataFusionRuntimeEventInterval?: number | undefined;
    dataFusionRuntimeGlobalQueueInterval?: number | undefined;
    dataFusionRuntimeMaxBlockingThreads?: number | undefined;
    dataFusionRuntimeMaxIoEventsPerTick?: number | undefined;
    dataFusionRuntimeThreadKeepAlive?: Duration | undefined;
    dataFusionRuntimeThreadPriority?: number | undefined;
    dataFusionMaxParquetFanout?: number | undefined;
    dataFusionUseCachedParquetLoader?: boolean | undefined;
    dataFusionConfig?: string | undefined;
    maxHttpRequestSize?: number | undefined;
    forceSnapshotMemThreshold?: PercentOrAbsoluteLong | undefined;
    walSnapshotSize?: number | undefined;
    walMaxWriteBufferSize?: number | undefined;
    snapshottedWalFilesToKeep?: number | undefined;
    preemptiveCacheAge?: Duration | undefined;
    parquetMemCachePrunePercentage?: number | undefined;
    parquetMemCachePruneInterval?: Duration | undefined;
    disableParquetMemCache?: boolean | undefined;
    parquetMemCacheQueryPathDuration?: Duration | undefined;
    lastCacheEvictionInterval?: Duration | undefined;
    distinctCacheEvictionInterval?: Duration | undefined;
    gen1Duration?: Duration | undefined;
    execMemPoolBytes?: PercentOrAbsoluteLong | undefined;
    parquetMemCacheSize?: PercentOrAbsoluteLong | undefined;
    walReplayFailOnError?: boolean | undefined;
    walReplayConcurrencyLimit?: number | undefined;
    tableIndexCacheMaxEntries?: number | undefined;
    tableIndexCacheConcurrencyLimit?: number | undefined;
    gen1LookbackDuration?: Duration | undefined;
    retentionCheckInterval?: Duration | undefined;
    deleteGracePeriod?: Duration | undefined;
    hardDeleteDefaultDuration?: Duration | undefined;
    pluginRepositoryUrl?: string | undefined;
    pluginRepositorySecretArn?: string | undefined;
}
export interface InfluxDBv3EnterpriseParameters {
    queryFileLimit?: number | undefined;
    queryLogSize?: number | undefined;
    logFilter?: string | undefined;
    logFormat?: LogFormats | undefined;
    dataFusionNumThreads?: number | undefined;
    dataFusionRuntimeType?: DataFusionRuntimeType | undefined;
    dataFusionRuntimeDisableLifoSlot?: boolean | undefined;
    dataFusionRuntimeEventInterval?: number | undefined;
    dataFusionRuntimeGlobalQueueInterval?: number | undefined;
    dataFusionRuntimeMaxBlockingThreads?: number | undefined;
    dataFusionRuntimeMaxIoEventsPerTick?: number | undefined;
    dataFusionRuntimeThreadKeepAlive?: Duration | undefined;
    dataFusionRuntimeThreadPriority?: number | undefined;
    dataFusionMaxParquetFanout?: number | undefined;
    dataFusionUseCachedParquetLoader?: boolean | undefined;
    dataFusionConfig?: string | undefined;
    maxHttpRequestSize?: number | undefined;
    forceSnapshotMemThreshold?: PercentOrAbsoluteLong | undefined;
    walSnapshotSize?: number | undefined;
    walMaxWriteBufferSize?: number | undefined;
    snapshottedWalFilesToKeep?: number | undefined;
    preemptiveCacheAge?: Duration | undefined;
    parquetMemCachePrunePercentage?: number | undefined;
    parquetMemCachePruneInterval?: Duration | undefined;
    disableParquetMemCache?: boolean | undefined;
    parquetMemCacheQueryPathDuration?: Duration | undefined;
    lastCacheEvictionInterval?: Duration | undefined;
    distinctCacheEvictionInterval?: Duration | undefined;
    gen1Duration?: Duration | undefined;
    execMemPoolBytes?: PercentOrAbsoluteLong | undefined;
    parquetMemCacheSize?: PercentOrAbsoluteLong | undefined;
    walReplayFailOnError?: boolean | undefined;
    walReplayConcurrencyLimit?: number | undefined;
    tableIndexCacheMaxEntries?: number | undefined;
    tableIndexCacheConcurrencyLimit?: number | undefined;
    gen1LookbackDuration?: Duration | undefined;
    retentionCheckInterval?: Duration | undefined;
    deleteGracePeriod?: Duration | undefined;
    hardDeleteDefaultDuration?: Duration | undefined;
    pluginRepositoryUrl?: string | undefined;
    pluginRepositorySecretArn?: string | undefined;
    ingestQueryInstances?: number | undefined;
    queryOnlyInstances?: number | undefined;
    dedicatedCompactor?: boolean | undefined;
    compactionRowLimit?: number | undefined;
    compactionMaxNumFilesPerPlan?: number | undefined;
    compactionGen2Duration?: Duration | undefined;
    compactionMultipliers?: string | undefined;
    compactionCleanupWait?: Duration | undefined;
    compactionCheckInterval?: Duration | undefined;
    lastValueCacheDisableFromHistory?: boolean | undefined;
    distinctValueCacheDisableFromHistory?: boolean | undefined;
    replicationInterval?: Duration | undefined;
    catalogSyncInterval?: Duration | undefined;
    upgradePachaTree?: boolean | undefined;
    walBufferSize?: number | undefined;
    snapshotSize?: PercentOrAbsoluteLong | undefined;
    snapshotDuration?: Duration | undefined;
}
export type Parameters = {
    InfluxDBv2: InfluxDBv2Parameters;
    InfluxDBv3Core?: undefined;
    InfluxDBv3Enterprise?: undefined;
} | {
    InfluxDBv2?: undefined;
    InfluxDBv3Core: InfluxDBv3CoreParameters;
    InfluxDBv3Enterprise?: undefined;
} | {
    InfluxDBv2?: undefined;
    InfluxDBv3Core?: undefined;
    InfluxDBv3Enterprise: InfluxDBv3EnterpriseParameters;
};
export interface CreateDbParameterGroupInput {
    name: string;
    description?: string | undefined;
    parameters?: Parameters | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface CreateDbParameterGroupOutput {
    id: string;
    name: string;
    arn: string;
    description?: string | undefined;
    parameters?: Parameters | undefined;
}
export interface DeleteDbBackupInput {
    identifier: string;
}
export interface DeleteDbBackupOutput {
    id: string;
    name?: string | undefined;
    arn: string;
    status?: DbBackupStatus | undefined;
    createdAt?: Date | undefined;
    expiresAfter?: string | undefined;
    dbResourceId?: string | undefined;
    type?: DbBackupType | undefined;
    engineType?: EngineType | undefined;
    deploymentType?: ResourceDeploymentType | undefined;
    kmsKeyId?: string | undefined;
    clusterConfiguration?: ClusterConfiguration | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    dbParameterGroupId?: string | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    failoverMode?: FailoverMode | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    vpcSubnetIds?: string[] | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    publiclyAccessible?: boolean | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
}
export interface DeleteDbClusterInput {
    dbClusterId: string;
    retainAutomatedBackups?: boolean | undefined;
}
export interface DeleteDbClusterOutput {
    dbClusterStatus?: ClusterStatus | undefined;
}
export type DbInstanceIdentifier = string;
export interface DeleteDbInstanceInput {
    identifier: string;
    retainAutomatedBackups?: boolean | undefined;
}
export interface DeleteDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    availabilityZone?: string | undefined;
    secondaryAvailabilityZone?: string | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    dbClusterId?: string | undefined;
    instanceMode?: InstanceMode | undefined;
    instanceModes?: InstanceMode[] | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    lastMaintenanceTime?: Date | undefined;
    nextMaintenanceTime?: Date | undefined;
    dbBackupConfigurations?: DbBackupConfigurationOutput[] | undefined;
    kmsKeyId?: string | undefined;
}
export interface GetDbBackupInput {
    identifier: string;
}
export interface GetDbBackupOutput {
    id: string;
    name?: string | undefined;
    arn: string;
    status?: DbBackupStatus | undefined;
    createdAt?: Date | undefined;
    expiresAfter?: string | undefined;
    dbResourceId?: string | undefined;
    type?: DbBackupType | undefined;
    engineType?: EngineType | undefined;
    deploymentType?: ResourceDeploymentType | undefined;
    kmsKeyId?: string | undefined;
    clusterConfiguration?: ClusterConfiguration | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    dbParameterGroupId?: string | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    failoverMode?: FailoverMode | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    vpcSubnetIds?: string[] | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    publiclyAccessible?: boolean | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
}
export interface GetDbClusterInput {
    dbClusterId: string;
}
export interface GetDbClusterOutput {
    id: string;
    name: string;
    arn: string;
    status?: ClusterStatus | undefined;
    endpoint?: string | undefined;
    readerEndpoint?: string | undefined;
    port?: number | undefined;
    deploymentType?: ClusterDeploymentType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    networkType?: NetworkType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    engineType?: EngineType | undefined;
    publiclyAccessible?: boolean | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    effectiveDbParameterGroupIdentifier?: string | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    lastMaintenanceTime?: Date | undefined;
    nextMaintenanceTime?: Date | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    vpcSubnetIds?: string[] | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    failoverMode?: FailoverMode | undefined;
    clusterConfiguration?: ClusterConfiguration | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    dbBackupConfigurations?: DbBackupConfigurationOutput[] | undefined;
    kmsKeyId?: string | undefined;
}
export interface GetDbInstanceInput {
    identifier: string;
}
export interface GetDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    availabilityZone?: string | undefined;
    secondaryAvailabilityZone?: string | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    dbClusterId?: string | undefined;
    instanceMode?: InstanceMode | undefined;
    instanceModes?: InstanceMode[] | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    lastMaintenanceTime?: Date | undefined;
    nextMaintenanceTime?: Date | undefined;
    dbBackupConfigurations?: DbBackupConfigurationOutput[] | undefined;
    kmsKeyId?: string | undefined;
}
export interface GetDbParameterGroupInput {
    identifier: string;
}
export interface GetDbParameterGroupOutput {
    id: string;
    name: string;
    arn: string;
    description?: string | undefined;
    parameters?: Parameters | undefined;
}
export type NextToken = string;
export type MaxResults = number;
export interface ListDbBackupsInput {
    dbResourceId?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DbBackupSummary {
    id: string;
    name?: string | undefined;
    arn: string;
    status?: DbBackupStatus | undefined;
    createdAt?: Date | undefined;
    expiresAfter?: string | undefined;
    dbResourceId?: string | undefined;
    type?: DbBackupType | undefined;
    engineType?: EngineType | undefined;
    deploymentType?: ResourceDeploymentType | undefined;
    kmsKeyId?: string | undefined;
}
export type DbBackupSummaryList = DbBackupSummary[];
export interface ListDbBackupsOutput {
    items: DbBackupSummary[];
    nextToken?: string | undefined;
}
export interface ListDbClustersInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DbClusterSummary {
    id: string;
    name: string;
    arn: string;
    status?: ClusterStatus | undefined;
    endpoint?: string | undefined;
    readerEndpoint?: string | undefined;
    port?: number | undefined;
    deploymentType?: ClusterDeploymentType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    networkType?: NetworkType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    engineType?: EngineType | undefined;
}
export type DbClusterSummaryList = DbClusterSummary[];
export interface ListDbClustersOutput {
    items: DbClusterSummary[];
    nextToken?: string | undefined;
}
export interface ListDbInstancesInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DbInstanceSummary {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
}
export type DbInstanceSummaryList = DbInstanceSummary[];
export interface ListDbInstancesOutput {
    items: DbInstanceSummary[];
    nextToken?: string | undefined;
}
export interface ListDbInstancesForClusterInput {
    dbClusterId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DbInstanceForClusterSummary {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
    instanceMode?: InstanceMode | undefined;
    instanceModes?: InstanceMode[] | undefined;
}
export type DbInstanceForClusterSummaryList = DbInstanceForClusterSummary[];
export interface ListDbInstancesForClusterOutput {
    items: DbInstanceForClusterSummary[];
    nextToken?: string | undefined;
}
export interface ListDbParameterGroupsInput {
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DbParameterGroupSummary {
    id: string;
    name: string;
    arn: string;
    description?: string | undefined;
}
export type DbParameterGroupSummaryList = DbParameterGroupSummary[];
export interface ListDbParameterGroupsOutput {
    items: DbParameterGroupSummary[];
    nextToken?: string | undefined;
}
export interface ListTagsForResourceRequest {
    resourceArn: string;
}
export type ResponseTagMap = {
    [key: string]: string | undefined;
};
export interface ListTagsForResourceResponse {
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type DbInstanceIdList = string[];
export interface RebootDbClusterInput {
    dbClusterId: string;
    instanceIds?: string[] | undefined;
}
export interface RebootDbClusterOutput {
    dbClusterStatus?: ClusterStatus | undefined;
}
export interface RebootDbInstanceInput {
    identifier: string;
}
export interface RebootDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    availabilityZone?: string | undefined;
    secondaryAvailabilityZone?: string | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    dbClusterId?: string | undefined;
    instanceMode?: InstanceMode | undefined;
    instanceModes?: InstanceMode[] | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    lastMaintenanceTime?: Date | undefined;
    nextMaintenanceTime?: Date | undefined;
    dbBackupConfigurations?: DbBackupConfigurationOutput[] | undefined;
    kmsKeyId?: string | undefined;
}
export type DbResourceName = string;
export type RestoreMode = "NEW_RESOURCE" | "REPLACE_EXISTING" | (string & {});
export interface RestoreFromDbBackupInput {
    name: string;
    dbBackupId: string;
    restoreToTime?: Date | undefined;
    restoreMode?: RestoreMode | undefined;
    vpcSubnetIds?: string[] | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    publiclyAccessible?: boolean | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    tags?: {
        [key: string]: string | undefined;
    } | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    deploymentType?: ResourceDeploymentType | undefined;
    dbBackupConfigurations?: DbBackupConfiguration[] | undefined;
    kmsKeyId?: string | undefined;
}
export type RestoreStatus = "RESTORING" | (string & {});
export type ResourceType = "DB_INSTANCE" | "DB_CLUSTER" | (string & {});
export interface RestoreFromDbBackupOutput {
    restoredDbResourceId?: string | undefined;
    restoreStatus?: RestoreStatus | undefined;
    resourceType?: ResourceType | undefined;
    engineType?: EngineType | undefined;
    deploymentType?: ResourceDeploymentType | undefined;
}
export interface TagResourceRequest {
    resourceArn: string;
    tags: {
        [key: string]: string | undefined;
    };
}
export interface TagResourceResponse {
}
export type TagKeys = string[];
export interface UntagResourceRequest {
    resourceArn: string;
    tagKeys: string[];
}
export interface UntagResourceResponse {
}
export interface UpdateDbClusterInput {
    dbClusterId: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    port?: number | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    deploymentConfiguration?: DeploymentConfiguration | undefined;
    failoverMode?: FailoverMode | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    dbBackupConfigurations?: DbBackupConfiguration[] | undefined;
}
export interface UpdateDbClusterOutput {
    dbClusterStatus?: ClusterStatus | undefined;
}
export interface UpdateDbInstanceInput {
    identifier: string;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    port?: number | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    deploymentType?: DeploymentType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    dbBackupConfigurations?: DbBackupConfiguration[] | undefined;
}
export interface UpdateDbInstanceOutput {
    id: string;
    name: string;
    arn: string;
    status?: Status | undefined;
    endpoint?: string | undefined;
    port?: number | undefined;
    networkType?: NetworkType | undefined;
    dbInstanceType?: DbInstanceType | undefined;
    dbStorageType?: DbStorageType | undefined;
    allocatedStorage?: number | undefined;
    deploymentType?: DeploymentType | undefined;
    vpcSubnetIds: string[];
    publiclyAccessible?: boolean | undefined;
    vpcSecurityGroupIds?: string[] | undefined;
    dbParameterGroupIdentifier?: string | undefined;
    availabilityZone?: string | undefined;
    secondaryAvailabilityZone?: string | undefined;
    logDeliveryConfiguration?: LogDeliveryConfiguration | undefined;
    influxAuthParametersSecretArn?: string | undefined;
    dbClusterId?: string | undefined;
    instanceMode?: InstanceMode | undefined;
    instanceModes?: InstanceMode[] | undefined;
    maintenanceSchedule?: MaintenanceSchedule | undefined;
    lastMaintenanceTime?: Date | undefined;
    nextMaintenanceTime?: Date | undefined;
    dbBackupConfigurations?: DbBackupConfigurationOutput[] | undefined;
    kmsKeyId?: string | undefined;
}
export type ValidationExceptionReason = "FIELD_VALIDATION_FAILED" | "OTHER" | (string & {});
export type CreateDbBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new on-demand backup of a Timestream for InfluxDB resource.
 */
export declare const createDbBackup: API.OperationMethod<CreateDbBackupInput & RegionInput, CreateDbBackupOutput, CreateDbBackupError, Credentials | HttpClient.HttpClient>;
export type CreateDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Timestream for InfluxDB cluster.
 */
export declare const createDbCluster: API.OperationMethod<CreateDbClusterInput & RegionInput, CreateDbClusterOutput, CreateDbClusterError, Credentials | HttpClient.HttpClient>;
export type CreateDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Timestream for InfluxDB DB instance.
 */
export declare const createDbInstance: API.OperationMethod<CreateDbInstanceInput & RegionInput, CreateDbInstanceOutput, CreateDbInstanceError, Credentials | HttpClient.HttpClient>;
export type CreateDbParameterGroupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a new Timestream for InfluxDB DB parameter group to associate with DB instances.
 */
export declare const createDbParameterGroup: API.OperationMethod<CreateDbParameterGroupInput & RegionInput, CreateDbParameterGroupOutput, CreateDbParameterGroupError, Credentials | HttpClient.HttpClient>;
export type DeleteDbBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Timestream for InfluxDB backup.
 */
export declare const deleteDbBackup: API.OperationMethod<DeleteDbBackupInput & RegionInput, DeleteDbBackupOutput, DeleteDbBackupError, Credentials | HttpClient.HttpClient>;
export type DeleteDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Timestream for InfluxDB cluster.
 */
export declare const deleteDbCluster: API.OperationMethod<DeleteDbClusterInput & RegionInput, DeleteDbClusterOutput, DeleteDbClusterError, Credentials | HttpClient.HttpClient>;
export type DeleteDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Timestream for InfluxDB DB instance.
 */
export declare const deleteDbInstance: API.OperationMethod<DeleteDbInstanceInput & RegionInput, DeleteDbInstanceOutput, DeleteDbInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDbBackupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specific Timestream for InfluxDB backup.
 */
export declare const getDbBackup: API.OperationMethod<GetDbBackupInput & RegionInput, GetDbBackupOutput, GetDbBackupError, Credentials | HttpClient.HttpClient>;
export type GetDbClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves information about a Timestream for InfluxDB cluster.
 */
export declare const getDbCluster: API.OperationMethod<GetDbClusterInput & RegionInput, GetDbClusterOutput, GetDbClusterError, Credentials | HttpClient.HttpClient>;
export type GetDbInstanceError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a Timestream for InfluxDB DB instance.
 */
export declare const getDbInstance: API.OperationMethod<GetDbInstanceInput & RegionInput, GetDbInstanceOutput, GetDbInstanceError, Credentials | HttpClient.HttpClient>;
export type GetDbParameterGroupError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a Timestream for InfluxDB DB parameter group.
 */
export declare const getDbParameterGroup: API.OperationMethod<GetDbParameterGroupInput & RegionInput, GetDbParameterGroupOutput, GetDbParameterGroupError, Credentials | HttpClient.HttpClient>;
export type ListDbBackupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB backups.
 */
export declare const listDbBackups: API.PaginatedOperationMethod<ListDbBackupsInput & RegionInput, ListDbBackupsOutput, ListDbBackupsError, Credentials | HttpClient.HttpClient, DbBackupSummary>;
export type ListDbClustersError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB DB clusters.
 */
export declare const listDbClusters: API.PaginatedOperationMethod<ListDbClustersInput & RegionInput, ListDbClustersOutput, ListDbClustersError, Credentials | HttpClient.HttpClient, DbClusterSummary>;
export type ListDbInstancesError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB DB instances.
 */
export declare const listDbInstances: API.PaginatedOperationMethod<ListDbInstancesInput & RegionInput, ListDbInstancesOutput, ListDbInstancesError, Credentials | HttpClient.HttpClient, DbInstanceSummary>;
export type ListDbInstancesForClusterError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB clusters.
 */
export declare const listDbInstancesForCluster: API.PaginatedOperationMethod<ListDbInstancesForClusterInput & RegionInput, ListDbInstancesForClusterOutput, ListDbInstancesForClusterError, Credentials | HttpClient.HttpClient, DbInstanceForClusterSummary>;
export type ListDbParameterGroupsError = AccessDeniedException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns a list of Timestream for InfluxDB DB parameter groups.
 */
export declare const listDbParameterGroups: API.PaginatedOperationMethod<ListDbParameterGroupsInput & RegionInput, ListDbParameterGroupsOutput, ListDbParameterGroupsError, Credentials | HttpClient.HttpClient, DbParameterGroupSummary>;
export type ListTagsForResourceError = ResourceNotFoundException | CommonErrors;
/**
 * A list of tags applied to the resource.
 */
export declare const listTagsForResource: API.OperationMethod<ListTagsForResourceRequest & RegionInput, ListTagsForResourceResponse, ListTagsForResourceError, Credentials | HttpClient.HttpClient>;
export type RebootDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots a Timestream for InfluxDB cluster.
 */
export declare const rebootDbCluster: API.OperationMethod<RebootDbClusterInput & RegionInput, RebootDbClusterOutput, RebootDbClusterError, Credentials | HttpClient.HttpClient>;
export type RebootDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Reboots a Timestream for InfluxDB instance.
 */
export declare const rebootDbInstance: API.OperationMethod<RebootDbInstanceInput & RegionInput, RebootDbInstanceOutput, RebootDbInstanceError, Credentials | HttpClient.HttpClient>;
export type RestoreFromDbBackupError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Restores a Timestream for InfluxDB resource from a backup. By default, a new resource is created. You can optionally restore to the same resource using the REPLACE_EXISTING restore mode.
 */
export declare const restoreFromDbBackup: API.OperationMethod<RestoreFromDbBackupInput & RegionInput, RestoreFromDbBackupOutput, RestoreFromDbBackupError, Credentials | HttpClient.HttpClient>;
export type TagResourceError = ResourceNotFoundException | ServiceQuotaExceededException | CommonErrors;
/**
 * Tags are composed of a Key/Value pairs. You can use tags to categorize and track your Timestream for InfluxDB resources.
 */
export declare const tagResource: API.OperationMethod<TagResourceRequest & RegionInput, TagResourceResponse, TagResourceError, Credentials | HttpClient.HttpClient>;
export type UntagResourceError = ResourceNotFoundException | CommonErrors;
/**
 * Removes the tag from the specified resource.
 */
export declare const untagResource: API.OperationMethod<UntagResourceRequest & RegionInput, UntagResourceResponse, UntagResourceError, Credentials | HttpClient.HttpClient>;
export type UpdateDbClusterError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Timestream for InfluxDB cluster.
 */
export declare const updateDbCluster: API.OperationMethod<UpdateDbClusterInput & RegionInput, UpdateDbClusterOutput, UpdateDbClusterError, Credentials | HttpClient.HttpClient>;
export type UpdateDbInstanceError = AccessDeniedException | ConflictException | InternalServerException | ResourceNotFoundException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Updates a Timestream for InfluxDB DB instance.
 */
export declare const updateDbInstance: API.OperationMethod<UpdateDbInstanceInput & RegionInput, UpdateDbInstanceOutput, UpdateDbInstanceError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=timestream-influxdb.d.ts.map