import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials as Creds } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const ClusterNotFound_base: S.TaggedErrorClass<"ClusterNotFound", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class ClusterNotFound extends /*@__PURE__*/ ClusterNotFound_base {
}
declare const EmrInstanceProfileNotReady_base: S.TaggedErrorClass<"EmrInstanceProfileNotReady", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class EmrInstanceProfileNotReady extends /*@__PURE__*/ EmrInstanceProfileNotReady_base {
}
declare const InternalServerError_base: S.TaggedErrorClass<"InternalServerError", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ServerError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class InternalServerError extends /*@__PURE__*/ InternalServerError_base {
}
declare const InternalServerException_base: S.TaggedErrorClass<"InternalServerException", {
    readonly message: any;
}>;
export declare class InternalServerException extends /*@__PURE__*/ InternalServerException_base {
}
declare const InvalidRequestException_base: S.TaggedErrorClass<"InvalidRequestException", {
    readonly ErrorCode: any;
    readonly message: any;
}>;
export declare class InvalidRequestException extends /*@__PURE__*/ InvalidRequestException_base {
}
declare const JobFlowNotFound_base: S.TaggedErrorClass<"JobFlowNotFound", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class JobFlowNotFound extends /*@__PURE__*/ JobFlowNotFound_base {
}
declare const SecurityConfigurationAlreadyExists_base: S.TaggedErrorClass<"SecurityConfigurationAlreadyExists", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AlreadyExistsError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class SecurityConfigurationAlreadyExists extends /*@__PURE__*/ SecurityConfigurationAlreadyExists_base {
}
declare const SecurityConfigurationNotFound_base: S.TaggedErrorClass<"SecurityConfigurationNotFound", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class SecurityConfigurationNotFound extends /*@__PURE__*/ SecurityConfigurationNotFound_base {
}
declare const StudioNotFound_base: S.TaggedErrorClass<"StudioNotFound", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        NotFoundError: true;
    };
});
export declare class StudioNotFound extends /*@__PURE__*/ StudioNotFound_base {
}
declare const StudioServiceRoleMissingS3Access_base: S.TaggedErrorClass<"StudioServiceRoleMissingS3Access", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class StudioServiceRoleMissingS3Access extends /*@__PURE__*/ StudioServiceRoleMissingS3Access_base {
}
declare const StudioServiceRoleNotAssumable_base: S.TaggedErrorClass<"StudioServiceRoleNotAssumable", {
    readonly ErrorCode: any;
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class StudioServiceRoleNotAssumable extends /*@__PURE__*/ StudioServiceRoleNotAssumable_base {
}
export type XmlStringMaxLen256 = string;
export type InstanceFleetType = "MASTER" | "CORE" | "TASK" | (string & {});
export type WholeNumber = number;
export type InstanceType = string;
export type NonNegativeDouble = number;
export type ThroughputVal = number;
export interface VolumeSpecification {
    VolumeType?: string | undefined;
    Iops?: number | undefined;
    SizeInGB?: number | undefined;
    Throughput?: number | undefined;
}
export interface EbsBlockDeviceConfig {
    VolumeSpecification?: VolumeSpecification | undefined;
    VolumesPerInstance?: number | undefined;
}
export type EbsBlockDeviceConfigList = EbsBlockDeviceConfig[];
export interface EbsConfiguration {
    EbsBlockDeviceConfigs?: EbsBlockDeviceConfig[] | undefined;
    EbsOptimized?: boolean | undefined;
}
export type StringMap = {
    [key: string]: string | undefined;
};
export interface Configuration {
    Classification?: string | undefined;
    Configurations?: Configuration[] | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ConfigurationList = Configuration[];
export interface InstanceTypeConfig {
    InstanceType?: string | undefined;
    WeightedCapacity?: number | undefined;
    BidPrice?: string | undefined;
    BidPriceAsPercentageOfOnDemandPrice?: number | undefined;
    EbsConfiguration?: EbsConfiguration | undefined;
    Configurations?: Configuration[] | undefined;
    CustomAmiId?: string | undefined;
    Priority?: number | undefined;
}
export type InstanceTypeConfigList = InstanceTypeConfig[];
export type SpotProvisioningTimeoutAction = "SWITCH_TO_ON_DEMAND" | "TERMINATE_CLUSTER" | (string & {});
export type SpotProvisioningAllocationStrategy = "capacity-optimized" | "price-capacity-optimized" | "lowest-price" | "diversified" | "capacity-optimized-prioritized" | (string & {});
export interface SpotProvisioningSpecification {
    TimeoutDurationMinutes?: number | undefined;
    TimeoutAction?: SpotProvisioningTimeoutAction | undefined;
    BlockDurationMinutes?: number | undefined;
    AllocationStrategy?: SpotProvisioningAllocationStrategy | undefined;
}
export type OnDemandProvisioningAllocationStrategy = "lowest-price" | "prioritized" | (string & {});
export type OnDemandCapacityReservationUsageStrategy = "use-capacity-reservations-first" | (string & {});
export type OnDemandCapacityReservationPreference = "open" | "none" | (string & {});
export interface OnDemandCapacityReservationOptions {
    UsageStrategy?: OnDemandCapacityReservationUsageStrategy | undefined;
    CapacityReservationPreference?: OnDemandCapacityReservationPreference | undefined;
    CapacityReservationResourceGroupArn?: string | undefined;
}
export interface OnDemandProvisioningSpecification {
    AllocationStrategy?: OnDemandProvisioningAllocationStrategy | undefined;
    CapacityReservationOptions?: OnDemandCapacityReservationOptions | undefined;
}
export interface InstanceFleetProvisioningSpecifications {
    SpotSpecification?: SpotProvisioningSpecification | undefined;
    OnDemandSpecification?: OnDemandProvisioningSpecification | undefined;
}
export interface SpotResizingSpecification {
    TimeoutDurationMinutes?: number | undefined;
    AllocationStrategy?: SpotProvisioningAllocationStrategy | undefined;
}
export interface OnDemandResizingSpecification {
    TimeoutDurationMinutes?: number | undefined;
    AllocationStrategy?: OnDemandProvisioningAllocationStrategy | undefined;
    CapacityReservationOptions?: OnDemandCapacityReservationOptions | undefined;
}
export interface InstanceFleetResizingSpecifications {
    SpotResizeSpecification?: SpotResizingSpecification | undefined;
    OnDemandResizeSpecification?: OnDemandResizingSpecification | undefined;
}
export interface InstanceFleetConfig {
    Name?: string | undefined;
    InstanceFleetType?: InstanceFleetType | undefined;
    TargetOnDemandCapacity?: number | undefined;
    TargetSpotCapacity?: number | undefined;
    InstanceTypeConfigs?: InstanceTypeConfig[] | undefined;
    LaunchSpecifications?: InstanceFleetProvisioningSpecifications | undefined;
    ResizeSpecifications?: InstanceFleetResizingSpecifications | undefined;
    Context?: string | undefined;
}
export interface AddInstanceFleetInput {
    ClusterId?: string | undefined;
    InstanceFleet?: InstanceFleetConfig | undefined;
}
export type InstanceFleetId = string;
export type ArnType = string;
export interface AddInstanceFleetOutput {
    ClusterId?: string | undefined;
    InstanceFleetId?: string | undefined;
    ClusterArn?: string | undefined;
}
export type MarketType = "ON_DEMAND" | "SPOT" | (string & {});
export type InstanceRoleType = "MASTER" | "CORE" | "TASK" | (string & {});
export interface ScalingConstraints {
    MinCapacity?: number | undefined;
    MaxCapacity?: number | undefined;
}
export type AdjustmentType = "CHANGE_IN_CAPACITY" | "PERCENT_CHANGE_IN_CAPACITY" | "EXACT_CAPACITY" | (string & {});
export interface SimpleScalingPolicyConfiguration {
    AdjustmentType?: AdjustmentType | undefined;
    ScalingAdjustment?: number | undefined;
    CoolDown?: number | undefined;
}
export interface ScalingAction {
    Market?: MarketType | undefined;
    SimpleScalingPolicyConfiguration?: SimpleScalingPolicyConfiguration | undefined;
}
export type ComparisonOperator = "GREATER_THAN_OR_EQUAL" | "GREATER_THAN" | "LESS_THAN" | "LESS_THAN_OR_EQUAL" | (string & {});
export type Statistic = "SAMPLE_COUNT" | "AVERAGE" | "SUM" | "MINIMUM" | "MAXIMUM" | (string & {});
export type Unit = "NONE" | "SECONDS" | "MICRO_SECONDS" | "MILLI_SECONDS" | "BYTES" | "KILO_BYTES" | "MEGA_BYTES" | "GIGA_BYTES" | "TERA_BYTES" | "BITS" | "KILO_BITS" | "MEGA_BITS" | "GIGA_BITS" | "TERA_BITS" | "PERCENT" | "COUNT" | "BYTES_PER_SECOND" | "KILO_BYTES_PER_SECOND" | "MEGA_BYTES_PER_SECOND" | "GIGA_BYTES_PER_SECOND" | "TERA_BYTES_PER_SECOND" | "BITS_PER_SECOND" | "KILO_BITS_PER_SECOND" | "MEGA_BITS_PER_SECOND" | "GIGA_BITS_PER_SECOND" | "TERA_BITS_PER_SECOND" | "COUNT_PER_SECOND" | (string & {});
export interface MetricDimension {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type MetricDimensionList = MetricDimension[];
export interface CloudWatchAlarmDefinition {
    ComparisonOperator?: ComparisonOperator | undefined;
    EvaluationPeriods?: number | undefined;
    MetricName?: string | undefined;
    Namespace?: string | undefined;
    Period?: number | undefined;
    Statistic?: Statistic | undefined;
    Threshold?: number | undefined;
    Unit?: Unit | undefined;
    Dimensions?: MetricDimension[] | undefined;
}
export interface ScalingTrigger {
    CloudWatchAlarmDefinition?: CloudWatchAlarmDefinition | undefined;
}
export interface ScalingRule {
    Name?: string | undefined;
    Description?: string | undefined;
    Action?: ScalingAction | undefined;
    Trigger?: ScalingTrigger | undefined;
}
export type ScalingRuleList = ScalingRule[];
export interface AutoScalingPolicy {
    Constraints?: ScalingConstraints | undefined;
    Rules?: ScalingRule[] | undefined;
}
export interface InstanceGroupConfig {
    Name?: string | undefined;
    Market?: MarketType | undefined;
    InstanceRole?: InstanceRoleType | undefined;
    BidPrice?: string | undefined;
    InstanceType?: string | undefined;
    InstanceCount?: number | undefined;
    Configurations?: Configuration[] | undefined;
    EbsConfiguration?: EbsConfiguration | undefined;
    AutoScalingPolicy?: AutoScalingPolicy | undefined;
    CustomAmiId?: string | undefined;
}
export type InstanceGroupConfigList = InstanceGroupConfig[];
export interface AddInstanceGroupsInput {
    InstanceGroups?: InstanceGroupConfig[] | undefined;
    JobFlowId?: string | undefined;
}
export type InstanceGroupIdsList = string[];
export interface AddInstanceGroupsOutput {
    JobFlowId?: string | undefined;
    InstanceGroupIds?: string[] | undefined;
    ClusterArn?: string | undefined;
}
export type ActionOnFailure = "TERMINATE_JOB_FLOW" | "TERMINATE_CLUSTER" | "CANCEL_AND_WAIT" | "CONTINUE" | (string & {});
export type XmlString = string;
export interface KeyValue {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type KeyValueList = KeyValue[];
export type XmlStringList = string[];
export interface HadoopJarStepConfig {
    Properties?: KeyValue[] | undefined;
    Jar?: string | undefined;
    MainClass?: string | undefined;
    Args?: string[] | undefined;
}
export interface S3MonitoringConfiguration {
    LogUri?: string | undefined;
    EncryptionKeyArn?: string | undefined;
}
export interface StepMonitoringConfiguration {
    S3MonitoringConfiguration?: S3MonitoringConfiguration | undefined;
}
export interface StepConfig {
    Name?: string | undefined;
    ActionOnFailure?: ActionOnFailure | undefined;
    HadoopJarStep?: HadoopJarStepConfig | undefined;
    StepMonitoringConfiguration?: StepMonitoringConfiguration | undefined;
}
export type StepConfigList = StepConfig[];
export interface AddJobFlowStepsInput {
    JobFlowId?: string | undefined;
    Steps?: StepConfig[] | undefined;
    ExecutionRoleArn?: string | undefined;
}
export type StepIdsList = string[];
export interface AddJobFlowStepsOutput {
    StepIds?: string[] | undefined;
}
export type ResourceId = string;
export interface Tag {
    Key?: string | undefined;
    Value?: string | undefined;
}
export type TagList = Tag[];
export type ClusterId = string;
export interface AddTagsInput {
    ResourceId?: string | undefined;
    Tags?: Tag[] | undefined;
    ClusterId?: string | undefined;
}
export interface AddTagsOutput {
}
export type StepCancellationOption = "SEND_INTERRUPT" | "TERMINATE_PROCESS" | (string & {});
export interface CancelStepsInput {
    ClusterId?: string | undefined;
    StepIds?: string[] | undefined;
    StepCancellationOption?: StepCancellationOption | undefined;
}
export type StepId = string;
export type CancelStepsRequestStatus = "SUBMITTED" | "FAILED" | (string & {});
export interface CancelStepsInfo {
    StepId?: string | undefined;
    Status?: CancelStepsRequestStatus | undefined;
    Reason?: string | undefined;
}
export type CancelStepsInfoList = CancelStepsInfo[];
export interface CancelStepsOutput {
    CancelStepsInfoList?: CancelStepsInfo[] | undefined;
}
export interface EMRContainersConfig {
    JobRunId?: string | undefined;
}
export type ProfilerType = "SHS" | "TEZUI" | "YTS" | (string & {});
export interface CreatePersistentAppUIInput {
    TargetResourceArn?: string | undefined;
    EMRContainersConfig?: EMRContainersConfig | undefined;
    Tags?: Tag[] | undefined;
    XReferer?: string | undefined;
    ProfilerType?: ProfilerType | undefined;
}
export interface CreatePersistentAppUIOutput {
    PersistentAppUIId?: string | undefined;
    RuntimeRoleEnabledCluster?: boolean | undefined;
}
export interface CreateSecurityConfigurationInput {
    Name?: string | undefined;
    SecurityConfiguration?: string | undefined;
}
export interface CreateSecurityConfigurationOutput {
    Name: string;
    CreationDateTime: Date;
}
export type AuthMode = "SSO" | "IAM" | (string & {});
export type SubnetIdList = string[];
export type IdcUserAssignment = "REQUIRED" | "OPTIONAL" | (string & {});
export interface CreateStudioInput {
    Name?: string | undefined;
    Description?: string | undefined;
    AuthMode?: AuthMode | undefined;
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    ServiceRole?: string | undefined;
    UserRole?: string | undefined;
    WorkspaceSecurityGroupId?: string | undefined;
    EngineSecurityGroupId?: string | undefined;
    DefaultS3Location?: string | undefined;
    IdpAuthUrl?: string | undefined;
    IdpRelayStateParameterName?: string | undefined;
    Tags?: Tag[] | undefined;
    TrustedIdentityPropagationEnabled?: boolean | undefined;
    IdcUserAssignment?: IdcUserAssignment | undefined;
    IdcInstanceArn?: string | undefined;
    EncryptionKeyArn?: string | undefined;
}
export interface CreateStudioOutput {
    StudioId?: string | undefined;
    Url?: string | undefined;
}
export type IdentityType = "USER" | "GROUP" | (string & {});
export interface CreateStudioSessionMappingInput {
    StudioId?: string | undefined;
    IdentityId?: string | undefined;
    IdentityName?: string | undefined;
    IdentityType?: IdentityType | undefined;
    SessionPolicyArn?: string | undefined;
}
export interface CreateStudioSessionMappingResponse {
}
export interface DeleteSecurityConfigurationInput {
    Name?: string | undefined;
}
export interface DeleteSecurityConfigurationOutput {
}
export interface DeleteStudioInput {
    StudioId?: string | undefined;
}
export interface DeleteStudioResponse {
}
export interface DeleteStudioSessionMappingInput {
    StudioId?: string | undefined;
    IdentityId?: string | undefined;
    IdentityName?: string | undefined;
    IdentityType?: IdentityType | undefined;
}
export interface DeleteStudioSessionMappingResponse {
}
export interface DescribeClusterInput {
    ClusterId?: string | undefined;
}
export type ClusterState = "STARTING" | "BOOTSTRAPPING" | "RUNNING" | "WAITING" | "TERMINATING" | "TERMINATED" | "TERMINATED_WITH_ERRORS" | (string & {});
export type ClusterStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "INSTANCE_FLEET_TIMEOUT" | "BOOTSTRAP_FAILURE" | "USER_REQUEST" | "STEP_FAILURE" | "ALL_STEPS_COMPLETED" | (string & {});
export interface ClusterStateChangeReason {
    Code?: ClusterStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface ClusterTimeline {
    CreationDateTime?: Date | undefined;
    ReadyDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
}
export type ErrorData = {
    [key: string]: string | undefined;
}[];
export interface ErrorDetail {
    ErrorCode?: string | undefined;
    ErrorData?: {
        [key: string]: string | undefined;
    }[] | undefined;
    ErrorMessage?: string | undefined;
}
export type ErrorDetailList = ErrorDetail[];
export interface ClusterStatus {
    State?: ClusterState | undefined;
    StateChangeReason?: ClusterStateChangeReason | undefined;
    Timeline?: ClusterTimeline | undefined;
    ErrorDetails?: ErrorDetail[] | undefined;
}
export type XmlStringMaxLen256List = string[];
export type StringList = string[];
export interface Ec2InstanceAttributes {
    Ec2KeyName?: string | undefined;
    Ec2SubnetId?: string | undefined;
    RequestedEc2SubnetIds?: string[] | undefined;
    Ec2AvailabilityZone?: string | undefined;
    RequestedEc2AvailabilityZones?: string[] | undefined;
    IamInstanceProfile?: string | undefined;
    EmrManagedMasterSecurityGroup?: string | undefined;
    EmrManagedSlaveSecurityGroup?: string | undefined;
    ServiceAccessSecurityGroup?: string | undefined;
    AdditionalMasterSecurityGroups?: string[] | undefined;
    AdditionalSlaveSecurityGroups?: string[] | undefined;
}
export type InstanceCollectionType = "INSTANCE_FLEET" | "INSTANCE_GROUP" | (string & {});
export interface Application {
    Name?: string | undefined;
    Version?: string | undefined;
    Args?: string[] | undefined;
    AdditionalInfo?: {
        [key: string]: string | undefined;
    } | undefined;
}
export type ApplicationList = Application[];
export type ScaleDownBehavior = "TERMINATE_AT_INSTANCE_HOUR" | "TERMINATE_AT_TASK_COMPLETION" | (string & {});
export type RepoUpgradeOnBoot = "SECURITY" | "NONE" | (string & {});
export interface KerberosAttributes {
    Realm?: string | undefined;
    KdcAdminPassword?: string | redacted.Redacted<string> | undefined;
    CrossRealmTrustPrincipalPassword?: string | redacted.Redacted<string> | undefined;
    ADDomainJoinUser?: string | undefined;
    ADDomainJoinPassword?: string | redacted.Redacted<string> | undefined;
}
export type OptionalArnType = string;
export type PlacementGroupStrategy = "SPREAD" | "PARTITION" | "CLUSTER" | "NONE" | (string & {});
export interface PlacementGroupConfig {
    InstanceRole?: InstanceRoleType | undefined;
    PlacementStrategy?: PlacementGroupStrategy | undefined;
}
export type PlacementGroupConfigList = PlacementGroupConfig[];
export type LogTypesMap = {
    [key: string]: string[] | undefined;
};
export interface CloudWatchLogConfiguration {
    Enabled?: boolean | undefined;
    LogGroupName?: string | undefined;
    LogStreamNamePrefix?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    LogTypes?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export type LogType = "system-logs" | "application-logs" | "persistent-ui-logs" | (string & {});
export type LogUploadPolicyValue = "emr-managed" | "on-customer-s3only" | "disabled" | (string & {});
export type LogTypeMap = {
    [key in LogType]?: LogUploadPolicyValue | undefined;
};
export interface S3LoggingConfiguration {
    LogTypeUploadPolicy?: {
        [key: string]: LogUploadPolicyValue | undefined;
    } | undefined;
}
export interface MonitoringConfiguration {
    CloudWatchLogConfiguration?: CloudWatchLogConfiguration | undefined;
    S3LoggingConfiguration?: S3LoggingConfiguration | undefined;
}
export interface Cluster {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: ClusterStatus | undefined;
    Ec2InstanceAttributes?: Ec2InstanceAttributes | undefined;
    InstanceCollectionType?: InstanceCollectionType | undefined;
    LogUri?: string | undefined;
    LogEncryptionKmsKeyId?: string | undefined;
    RequestedAmiVersion?: string | undefined;
    RunningAmiVersion?: string | undefined;
    ReleaseLabel?: string | undefined;
    AutoTerminate?: boolean | undefined;
    TerminationProtected?: boolean | undefined;
    UnhealthyNodeReplacement?: boolean | undefined;
    VisibleToAllUsers?: boolean | undefined;
    Applications?: Application[] | undefined;
    Tags?: Tag[] | undefined;
    ServiceRole?: string | undefined;
    NormalizedInstanceHours?: number | undefined;
    MasterPublicDnsName?: string | undefined;
    Configurations?: Configuration[] | undefined;
    SecurityConfiguration?: string | undefined;
    AutoScalingRole?: string | undefined;
    ScaleDownBehavior?: ScaleDownBehavior | undefined;
    CustomAmiId?: string | undefined;
    EbsRootVolumeSize?: number | undefined;
    RepoUpgradeOnBoot?: RepoUpgradeOnBoot | undefined;
    KerberosAttributes?: KerberosAttributes | undefined;
    ClusterArn?: string | undefined;
    OutpostArn?: string | undefined;
    StepConcurrencyLevel?: number | undefined;
    PlacementGroups?: PlacementGroupConfig[] | undefined;
    OSReleaseLabel?: string | undefined;
    EbsRootVolumeIops?: number | undefined;
    EbsRootVolumeThroughput?: number | undefined;
    ExtendedSupport?: boolean | undefined;
    MonitoringConfiguration?: MonitoringConfiguration | undefined;
    SessionEnabled?: boolean | undefined;
}
export interface DescribeClusterOutput {
    Cluster?: (Cluster & {
        KerberosAttributes: KerberosAttributes & {
            Realm: XmlStringMaxLen256;
            KdcAdminPassword: XmlStringMaxLen256;
        };
        PlacementGroups: (PlacementGroupConfig & {
            InstanceRole: InstanceRoleType;
        })[];
        MonitoringConfiguration: MonitoringConfiguration & {
            CloudWatchLogConfiguration: CloudWatchLogConfiguration & {
                Enabled: boolean;
            };
        };
    }) | undefined;
}
export type JobFlowExecutionState = "STARTING" | "BOOTSTRAPPING" | "RUNNING" | "WAITING" | "SHUTTING_DOWN" | "TERMINATED" | "COMPLETED" | "FAILED" | (string & {});
export type JobFlowExecutionStateList = JobFlowExecutionState[];
export interface DescribeJobFlowsInput {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    JobFlowIds?: string[] | undefined;
    JobFlowStates?: JobFlowExecutionState[] | undefined;
}
export interface JobFlowExecutionStatusDetail {
    State?: JobFlowExecutionState | undefined;
    CreationDateTime?: Date | undefined;
    StartDateTime?: Date | undefined;
    ReadyDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
    LastStateChangeReason?: string | undefined;
}
export type InstanceGroupState = "PROVISIONING" | "BOOTSTRAPPING" | "RUNNING" | "RECONFIGURING" | "RESIZING" | "SUSPENDED" | "TERMINATING" | "TERMINATED" | "ARRESTED" | "SHUTTING_DOWN" | "ENDED" | (string & {});
export interface InstanceGroupDetail {
    InstanceGroupId?: string | undefined;
    Name?: string | undefined;
    Market?: MarketType | undefined;
    InstanceRole?: InstanceRoleType | undefined;
    BidPrice?: string | undefined;
    InstanceType?: string | undefined;
    InstanceRequestCount?: number | undefined;
    InstanceRunningCount?: number | undefined;
    State?: InstanceGroupState | undefined;
    LastStateChangeReason?: string | undefined;
    CreationDateTime?: Date | undefined;
    StartDateTime?: Date | undefined;
    ReadyDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
    CustomAmiId?: string | undefined;
}
export type InstanceGroupDetailList = InstanceGroupDetail[];
export interface PlacementType {
    AvailabilityZone?: string | undefined;
    AvailabilityZones?: string[] | undefined;
}
export interface JobFlowInstancesDetail {
    MasterInstanceType?: string | undefined;
    MasterPublicDnsName?: string | undefined;
    MasterInstanceId?: string | undefined;
    SlaveInstanceType?: string | undefined;
    InstanceCount?: number | undefined;
    InstanceGroups?: InstanceGroupDetail[] | undefined;
    NormalizedInstanceHours?: number | undefined;
    Ec2KeyName?: string | undefined;
    Ec2SubnetId?: string | undefined;
    Placement?: PlacementType | undefined;
    KeepJobFlowAliveWhenNoSteps?: boolean | undefined;
    TerminationProtected?: boolean | undefined;
    UnhealthyNodeReplacement?: boolean | undefined;
    HadoopVersion?: string | undefined;
}
export type StepExecutionState = "PENDING" | "RUNNING" | "CONTINUE" | "COMPLETED" | "CANCELLED" | "FAILED" | "INTERRUPTED" | (string & {});
export interface StepExecutionStatusDetail {
    State?: StepExecutionState | undefined;
    CreationDateTime?: Date | undefined;
    StartDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
    LastStateChangeReason?: string | undefined;
}
export interface StepDetail {
    StepConfig?: StepConfig | undefined;
    ExecutionStatusDetail?: StepExecutionStatusDetail | undefined;
}
export type StepDetailList = StepDetail[];
export interface ScriptBootstrapActionConfig {
    Path?: string | undefined;
    Args?: string[] | undefined;
}
export interface BootstrapActionConfig {
    Name?: string | undefined;
    ScriptBootstrapAction?: ScriptBootstrapActionConfig | undefined;
}
export interface BootstrapActionDetail {
    BootstrapActionConfig?: BootstrapActionConfig | undefined;
}
export type BootstrapActionDetailList = BootstrapActionDetail[];
export type SupportedProductsList = string[];
export interface JobFlowDetail {
    JobFlowId?: string | undefined;
    Name?: string | undefined;
    LogUri?: string | undefined;
    LogEncryptionKmsKeyId?: string | undefined;
    AmiVersion?: string | undefined;
    ExecutionStatusDetail?: JobFlowExecutionStatusDetail | undefined;
    Instances?: JobFlowInstancesDetail | undefined;
    Steps?: StepDetail[] | undefined;
    BootstrapActions?: BootstrapActionDetail[] | undefined;
    SupportedProducts?: string[] | undefined;
    VisibleToAllUsers?: boolean | undefined;
    JobFlowRole?: string | undefined;
    ServiceRole?: string | undefined;
    AutoScalingRole?: string | undefined;
    ScaleDownBehavior?: ScaleDownBehavior | undefined;
}
export type JobFlowDetailList = JobFlowDetail[];
export interface DescribeJobFlowsOutput {
    JobFlows?: (JobFlowDetail & {
        JobFlowId: XmlStringMaxLen256;
        Name: XmlStringMaxLen256;
        ExecutionStatusDetail: JobFlowExecutionStatusDetail & {
            State: JobFlowExecutionState;
            CreationDateTime: Date;
        };
        Instances: JobFlowInstancesDetail & {
            MasterInstanceType: InstanceType;
            SlaveInstanceType: InstanceType;
            InstanceCount: number;
            InstanceGroups: (InstanceGroupDetail & {
                Market: MarketType;
                InstanceRole: InstanceRoleType;
                InstanceType: InstanceType;
                InstanceRequestCount: number;
                InstanceRunningCount: number;
                State: InstanceGroupState;
                CreationDateTime: Date;
            })[];
        };
        Steps: (StepDetail & {
            StepConfig: StepConfig & {
                Name: XmlStringMaxLen256;
                HadoopJarStep: HadoopJarStepConfig & {
                    Jar: XmlString;
                };
            };
            ExecutionStatusDetail: StepExecutionStatusDetail & {
                State: StepExecutionState;
                CreationDateTime: Date;
            };
        })[];
        BootstrapActions: (BootstrapActionDetail & {
            BootstrapActionConfig: BootstrapActionConfig & {
                Name: XmlStringMaxLen256;
                ScriptBootstrapAction: ScriptBootstrapActionConfig & {
                    Path: XmlString;
                };
            };
        })[];
    })[] | undefined;
}
export interface DescribeNotebookExecutionInput {
    NotebookExecutionId?: string | undefined;
}
export type ExecutionEngineType = "EMR" | (string & {});
export type IAMRoleArn = string;
export interface ExecutionEngineConfig {
    Id?: string | undefined;
    Type?: ExecutionEngineType | undefined;
    MasterInstanceSecurityGroupId?: string | undefined;
    ExecutionRoleArn?: string | undefined;
}
export type NotebookExecutionStatus = "START_PENDING" | "STARTING" | "RUNNING" | "FINISHING" | "FINISHED" | "FAILING" | "FAILED" | "STOP_PENDING" | "STOPPING" | "STOPPED" | (string & {});
export type UriString = string;
export interface NotebookS3LocationForOutput {
    Bucket?: string | undefined;
    Key?: string | undefined;
}
export interface OutputNotebookS3LocationForOutput {
    Bucket?: string | undefined;
    Key?: string | undefined;
}
export type OutputNotebookFormat = "HTML" | (string & {});
export type EnvironmentVariablesMap = {
    [key: string]: string | undefined;
};
export interface NotebookExecution {
    NotebookExecutionId?: string | undefined;
    EditorId?: string | undefined;
    ExecutionEngine?: ExecutionEngineConfig | undefined;
    NotebookExecutionName?: string | undefined;
    NotebookParams?: string | undefined;
    Status?: NotebookExecutionStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    Arn?: string | undefined;
    OutputNotebookURI?: string | undefined;
    LastStateChangeReason?: string | undefined;
    NotebookInstanceSecurityGroupId?: string | undefined;
    Tags?: Tag[] | undefined;
    NotebookS3Location?: NotebookS3LocationForOutput | undefined;
    OutputNotebookS3Location?: OutputNotebookS3LocationForOutput | undefined;
    OutputNotebookFormat?: OutputNotebookFormat | undefined;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface DescribeNotebookExecutionOutput {
    NotebookExecution?: (NotebookExecution & {
        ExecutionEngine: ExecutionEngineConfig & {
            Id: XmlStringMaxLen256;
        };
    }) | undefined;
}
export interface DescribePersistentAppUIInput {
    PersistentAppUIId?: string | undefined;
}
export type PersistentAppUIType = "SHS" | "TEZ" | "YTS" | (string & {});
export type PersistentAppUITypeList = PersistentAppUIType[];
export interface PersistentAppUI {
    PersistentAppUIId?: string | undefined;
    PersistentAppUITypeList?: PersistentAppUIType[] | undefined;
    PersistentAppUIStatus?: string | undefined;
    AuthorId?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
    LastStateChangeReason?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface DescribePersistentAppUIOutput {
    PersistentAppUI?: PersistentAppUI | undefined;
}
export type MaxResultsNumber = number;
export interface DescribeReleaseLabelInput {
    ReleaseLabel?: string | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface SimplifiedApplication {
    Name?: string | undefined;
    Version?: string | undefined;
}
export type SimplifiedApplicationList = SimplifiedApplication[];
export interface OSRelease {
    Label?: string | undefined;
}
export type OSReleaseList = OSRelease[];
export interface DescribeReleaseLabelOutput {
    ReleaseLabel?: string | undefined;
    Applications?: SimplifiedApplication[] | undefined;
    NextToken?: string | undefined;
    AvailableOSReleases?: OSRelease[] | undefined;
}
export interface DescribeSecurityConfigurationInput {
    Name?: string | undefined;
}
export interface DescribeSecurityConfigurationOutput {
    Name?: string | undefined;
    SecurityConfiguration?: string | undefined;
    CreationDateTime?: Date | undefined;
}
export interface DescribeStepInput {
    ClusterId?: string | undefined;
    StepId?: string | undefined;
}
export interface HadoopStepConfig {
    Jar?: string | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
    MainClass?: string | undefined;
    Args?: string[] | undefined;
}
export type StepState = "PENDING" | "CANCEL_PENDING" | "RUNNING" | "COMPLETED" | "CANCELLED" | "FAILED" | "INTERRUPTED" | (string & {});
export type StepStateChangeReasonCode = "NONE" | (string & {});
export interface StepStateChangeReason {
    Code?: StepStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface FailureDetails {
    Reason?: string | undefined;
    Message?: string | undefined;
    LogFile?: string | undefined;
}
export interface StepTimeline {
    CreationDateTime?: Date | undefined;
    StartDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
}
export interface StepStatus {
    State?: StepState | undefined;
    StateChangeReason?: StepStateChangeReason | undefined;
    FailureDetails?: FailureDetails | undefined;
    Timeline?: StepTimeline | undefined;
}
export interface StepAdditionalInfo {
    ResourceManagerApplicationIds?: string[] | undefined;
    ResourceManager?: string | undefined;
}
export interface Step {
    Id?: string | undefined;
    Name?: string | undefined;
    Config?: HadoopStepConfig | undefined;
    ActionOnFailure?: ActionOnFailure | undefined;
    Status?: StepStatus | undefined;
    ExecutionRoleArn?: string | undefined;
    LogUri?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    AdditionalInfo?: StepAdditionalInfo | undefined;
}
export interface DescribeStepOutput {
    Step?: Step | undefined;
}
export interface DescribeStudioInput {
    StudioId?: string | undefined;
}
export interface Studio {
    StudioId?: string | undefined;
    StudioArn?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    AuthMode?: AuthMode | undefined;
    VpcId?: string | undefined;
    SubnetIds?: string[] | undefined;
    ServiceRole?: string | undefined;
    UserRole?: string | undefined;
    WorkspaceSecurityGroupId?: string | undefined;
    EngineSecurityGroupId?: string | undefined;
    Url?: string | undefined;
    CreationTime?: Date | undefined;
    DefaultS3Location?: string | undefined;
    IdpAuthUrl?: string | undefined;
    IdpRelayStateParameterName?: string | undefined;
    Tags?: Tag[] | undefined;
    IdcInstanceArn?: string | undefined;
    TrustedIdentityPropagationEnabled?: boolean | undefined;
    IdcUserAssignment?: IdcUserAssignment | undefined;
    EncryptionKeyArn?: string | undefined;
}
export interface DescribeStudioOutput {
    Studio?: Studio | undefined;
}
export interface GetAutoTerminationPolicyInput {
    ClusterId?: string | undefined;
}
export interface AutoTerminationPolicy {
    IdleTimeout?: number | undefined;
}
export interface GetAutoTerminationPolicyOutput {
    AutoTerminationPolicy?: AutoTerminationPolicy | undefined;
}
export interface GetBlockPublicAccessConfigurationInput {
}
export type Port = number;
export interface PortRange {
    MinRange?: number | undefined;
    MaxRange?: number | undefined;
}
export type PortRanges = PortRange[];
export interface BlockPublicAccessConfiguration {
    BlockPublicSecurityGroupRules?: boolean | undefined;
    PermittedPublicSecurityGroupRuleRanges?: PortRange[] | undefined;
    Classification?: string | undefined;
    Configurations?: Configuration[] | undefined;
    Properties?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface BlockPublicAccessConfigurationMetadata {
    CreationDateTime?: Date | undefined;
    CreatedByArn?: string | undefined;
}
export interface GetBlockPublicAccessConfigurationOutput {
    BlockPublicAccessConfiguration: BlockPublicAccessConfiguration & {
        BlockPublicSecurityGroupRules: boolean;
        PermittedPublicSecurityGroupRuleRanges: (PortRange & {
            MinRange: Port;
        })[];
    };
    BlockPublicAccessConfigurationMetadata: BlockPublicAccessConfigurationMetadata & {
        CreationDateTime: Date;
        CreatedByArn: ArnType;
    };
}
export interface GetClusterSessionCredentialsInput {
    ClusterId?: string | undefined;
    ExecutionRoleArn?: string | undefined;
}
export interface UsernamePassword {
    Username?: string | undefined;
    Password?: string | redacted.Redacted<string> | undefined;
}
export type Credentials = {
    UsernamePassword: UsernamePassword;
};
export interface GetClusterSessionCredentialsOutput {
    Credentials?: Credentials | undefined;
    ExpiresAt?: Date | undefined;
}
export interface GetManagedScalingPolicyInput {
    ClusterId?: string | undefined;
}
export type ComputeLimitsUnitType = "InstanceFleetUnits" | "Instances" | "VCPU" | (string & {});
export interface ComputeLimits {
    UnitType?: ComputeLimitsUnitType | undefined;
    MinimumCapacityUnits?: number | undefined;
    MaximumCapacityUnits?: number | undefined;
    MaximumOnDemandCapacityUnits?: number | undefined;
    MaximumCoreCapacityUnits?: number | undefined;
}
export type UtilizationPerformanceIndexInteger = number;
export type ScalingStrategy = "DEFAULT" | "ADVANCED" | (string & {});
export interface ManagedScalingPolicy {
    ComputeLimits?: ComputeLimits | undefined;
    UtilizationPerformanceIndex?: number | undefined;
    ScalingStrategy?: ScalingStrategy | undefined;
}
export interface GetManagedScalingPolicyOutput {
    ManagedScalingPolicy?: (ManagedScalingPolicy & {
        ComputeLimits: ComputeLimits & {
            UnitType: ComputeLimitsUnitType;
            MinimumCapacityUnits: number;
            MaximumCapacityUnits: number;
        };
    }) | undefined;
}
export type OnClusterAppUIType = "SparkHistoryServer" | "YarnTimelineService" | "TezUI" | "ApplicationMaster" | "JobHistoryServer" | "ResourceManager" | (string & {});
export interface GetOnClusterAppUIPresignedURLInput {
    ClusterId?: string | undefined;
    OnClusterAppUIType?: OnClusterAppUIType | undefined;
    ApplicationId?: string | undefined;
    DryRun?: boolean | undefined;
    ExecutionRoleArn?: string | undefined;
}
export interface GetOnClusterAppUIPresignedURLOutput {
    PresignedURLReady?: boolean | undefined;
    PresignedURL?: string | undefined;
}
export interface GetPersistentAppUIPresignedURLInput {
    PersistentAppUIId?: string | undefined;
    PersistentAppUIType?: PersistentAppUIType | undefined;
    ApplicationId?: string | undefined;
    AuthProxyCall?: boolean | undefined;
    ExecutionRoleArn?: string | undefined;
}
export interface GetPersistentAppUIPresignedURLOutput {
    PresignedURLReady?: boolean | undefined;
    PresignedURL?: string | undefined;
}
export type SessionId = string;
export interface GetSessionInput {
    ClusterId?: string | undefined;
    SessionId?: string | undefined;
}
export type SessionState = "SUBMITTED" | "STARTING" | "STARTED" | "IDLE" | "BUSY" | "TERMINATING" | "TERMINATED" | "FAILED" | (string & {});
export interface SessionCloudWatchLoggingConfiguration {
    Enabled?: boolean | undefined;
    LogGroup?: string | undefined;
    LogStreamNamePrefix?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    LogTypes?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface SessionManagedLoggingConfiguration {
    Enabled?: boolean | undefined;
    EncryptionKeyArn?: string | undefined;
}
export interface SessionS3LoggingConfiguration {
    Enabled?: boolean | undefined;
    LogUri?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    LogTypes?: {
        [key: string]: string[] | undefined;
    } | undefined;
}
export interface SessionMonitoringConfiguration {
    CloudWatchLoggingConfiguration?: SessionCloudWatchLoggingConfiguration | undefined;
    ManagedLoggingConfiguration?: SessionManagedLoggingConfiguration | undefined;
    S3LoggingConfiguration?: SessionS3LoggingConfiguration | undefined;
}
export interface Session {
    Id?: string | undefined;
    ClusterId?: string | undefined;
    Name?: string | undefined;
    Arn?: string | undefined;
    State?: SessionState | undefined;
    StateChangeReason?: string | undefined;
    ReleaseLabel?: string | undefined;
    ExecutionRoleArn?: string | undefined;
    AccountId?: string | undefined;
    CreatedAt?: Date | undefined;
    UpdatedAt?: Date | undefined;
    StartedAt?: Date | undefined;
    EndedAt?: Date | undefined;
    IdleSince?: Date | undefined;
    EngineConfigurations?: Configuration[] | undefined;
    MonitoringConfiguration?: SessionMonitoringConfiguration | undefined;
    SessionIdleTimeoutInMinutes?: number | undefined;
    ServerUrl?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface GetSessionOutput {
    Session: Session & {
        Id: SessionId;
        ClusterId: ClusterId;
        Arn: ArnType;
        State: SessionState;
    };
}
export interface GetSessionEndpointInput {
    ClusterId?: string | undefined;
    SessionId?: string | undefined;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface GetSessionEndpointOutput {
    Endpoint: string;
    AuthToken?: string | redacted.Redacted<string> | undefined;
    AuthTokenExpirationTime?: Date | undefined;
    Credentials?: Credentials | undefined;
}
export interface GetStudioSessionMappingInput {
    StudioId?: string | undefined;
    IdentityId?: string | undefined;
    IdentityName?: string | undefined;
    IdentityType?: IdentityType | undefined;
}
export interface SessionMappingDetail {
    StudioId?: string | undefined;
    IdentityId?: string | undefined;
    IdentityName?: string | undefined;
    IdentityType?: IdentityType | undefined;
    SessionPolicyArn?: string | undefined;
    CreationTime?: Date | undefined;
    LastModifiedTime?: Date | undefined;
}
export interface GetStudioSessionMappingOutput {
    SessionMapping?: SessionMappingDetail | undefined;
}
export type Marker = string;
export interface ListBootstrapActionsInput {
    ClusterId?: string | undefined;
    Marker?: string | undefined;
}
export interface Command {
    Name?: string | undefined;
    ScriptPath?: string | undefined;
    Args?: string[] | undefined;
}
export type CommandList = Command[];
export interface ListBootstrapActionsOutput {
    BootstrapActions?: Command[] | undefined;
    Marker?: string | undefined;
}
export type ClusterStateList = ClusterState[];
export interface ListClustersInput {
    CreatedAfter?: Date | undefined;
    CreatedBefore?: Date | undefined;
    ClusterStates?: ClusterState[] | undefined;
    Marker?: string | undefined;
}
export interface ClusterSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: ClusterStatus | undefined;
    NormalizedInstanceHours?: number | undefined;
    ClusterArn?: string | undefined;
    OutpostArn?: string | undefined;
}
export type ClusterSummaryList = ClusterSummary[];
export interface ListClustersOutput {
    Clusters?: ClusterSummary[] | undefined;
    Marker?: string | undefined;
}
export interface ListInstanceFleetsInput {
    ClusterId?: string | undefined;
    Marker?: string | undefined;
}
export type InstanceFleetState = "PROVISIONING" | "BOOTSTRAPPING" | "RUNNING" | "RESIZING" | "RECONFIGURING" | "SUSPENDED" | "TERMINATING" | "TERMINATED" | (string & {});
export type InstanceFleetStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "CLUSTER_TERMINATED" | (string & {});
export interface InstanceFleetStateChangeReason {
    Code?: InstanceFleetStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface InstanceFleetTimeline {
    CreationDateTime?: Date | undefined;
    ReadyDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
}
export interface InstanceFleetStatus {
    State?: InstanceFleetState | undefined;
    StateChangeReason?: InstanceFleetStateChangeReason | undefined;
    Timeline?: InstanceFleetTimeline | undefined;
}
export interface EbsBlockDevice {
    VolumeSpecification?: VolumeSpecification | undefined;
    Device?: string | undefined;
}
export type EbsBlockDeviceList = EbsBlockDevice[];
export interface InstanceTypeSpecification {
    InstanceType?: string | undefined;
    WeightedCapacity?: number | undefined;
    BidPrice?: string | undefined;
    BidPriceAsPercentageOfOnDemandPrice?: number | undefined;
    Configurations?: Configuration[] | undefined;
    EbsBlockDevices?: EbsBlockDevice[] | undefined;
    EbsOptimized?: boolean | undefined;
    CustomAmiId?: string | undefined;
    Priority?: number | undefined;
}
export type InstanceTypeSpecificationList = InstanceTypeSpecification[];
export interface InstanceFleet {
    Id?: string | undefined;
    Name?: string | undefined;
    Status?: InstanceFleetStatus | undefined;
    InstanceFleetType?: InstanceFleetType | undefined;
    TargetOnDemandCapacity?: number | undefined;
    TargetSpotCapacity?: number | undefined;
    ProvisionedOnDemandCapacity?: number | undefined;
    ProvisionedSpotCapacity?: number | undefined;
    InstanceTypeSpecifications?: InstanceTypeSpecification[] | undefined;
    LaunchSpecifications?: InstanceFleetProvisioningSpecifications | undefined;
    ResizeSpecifications?: InstanceFleetResizingSpecifications | undefined;
    Context?: string | undefined;
}
export type InstanceFleetList = InstanceFleet[];
export interface ListInstanceFleetsOutput {
    InstanceFleets?: (InstanceFleet & {
        InstanceTypeSpecifications: (InstanceTypeSpecification & {
            EbsBlockDevices: (EbsBlockDevice & {
                VolumeSpecification: VolumeSpecification & {
                    VolumeType: string;
                    SizeInGB: number;
                };
            })[];
        })[];
        LaunchSpecifications: InstanceFleetProvisioningSpecifications & {
            SpotSpecification: SpotProvisioningSpecification & {
                TimeoutDurationMinutes: WholeNumber;
                TimeoutAction: SpotProvisioningTimeoutAction;
            };
            OnDemandSpecification: OnDemandProvisioningSpecification & {
                AllocationStrategy: OnDemandProvisioningAllocationStrategy;
            };
        };
    })[] | undefined;
    Marker?: string | undefined;
}
export interface ListInstanceGroupsInput {
    ClusterId?: string | undefined;
    Marker?: string | undefined;
}
export type InstanceGroupId = string;
export type InstanceGroupType = "MASTER" | "CORE" | "TASK" | (string & {});
export type InstanceGroupStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "CLUSTER_TERMINATED" | (string & {});
export interface InstanceGroupStateChangeReason {
    Code?: InstanceGroupStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface InstanceGroupTimeline {
    CreationDateTime?: Date | undefined;
    ReadyDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
}
export interface InstanceGroupStatus {
    State?: InstanceGroupState | undefined;
    StateChangeReason?: InstanceGroupStateChangeReason | undefined;
    Timeline?: InstanceGroupTimeline | undefined;
}
export type InstanceId = string;
export type EC2InstanceIdsList = string[];
export interface InstanceResizePolicy {
    InstancesToTerminate?: string[] | undefined;
    InstancesToProtect?: string[] | undefined;
    InstanceTerminationTimeout?: number | undefined;
}
export interface ShrinkPolicy {
    DecommissionTimeout?: number | undefined;
    InstanceResizePolicy?: InstanceResizePolicy | undefined;
}
export type AutoScalingPolicyState = "PENDING" | "ATTACHING" | "ATTACHED" | "DETACHING" | "DETACHED" | "FAILED" | (string & {});
export type AutoScalingPolicyStateChangeReasonCode = "USER_REQUEST" | "PROVISION_FAILURE" | "CLEANUP_FAILURE" | (string & {});
export interface AutoScalingPolicyStateChangeReason {
    Code?: AutoScalingPolicyStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface AutoScalingPolicyStatus {
    State?: AutoScalingPolicyState | undefined;
    StateChangeReason?: AutoScalingPolicyStateChangeReason | undefined;
}
export interface AutoScalingPolicyDescription {
    Status?: AutoScalingPolicyStatus | undefined;
    Constraints?: ScalingConstraints | undefined;
    Rules?: ScalingRule[] | undefined;
}
export interface InstanceGroup {
    Id?: string | undefined;
    Name?: string | undefined;
    Market?: MarketType | undefined;
    InstanceGroupType?: InstanceGroupType | undefined;
    BidPrice?: string | undefined;
    InstanceType?: string | undefined;
    RequestedInstanceCount?: number | undefined;
    RunningInstanceCount?: number | undefined;
    Status?: InstanceGroupStatus | undefined;
    Configurations?: Configuration[] | undefined;
    ConfigurationsVersion?: number | undefined;
    LastSuccessfullyAppliedConfigurations?: Configuration[] | undefined;
    LastSuccessfullyAppliedConfigurationsVersion?: number | undefined;
    EbsBlockDevices?: EbsBlockDevice[] | undefined;
    EbsOptimized?: boolean | undefined;
    ShrinkPolicy?: ShrinkPolicy | undefined;
    AutoScalingPolicy?: AutoScalingPolicyDescription | undefined;
    CustomAmiId?: string | undefined;
}
export type InstanceGroupList = InstanceGroup[];
export interface ListInstanceGroupsOutput {
    InstanceGroups?: (InstanceGroup & {
        EbsBlockDevices: (EbsBlockDevice & {
            VolumeSpecification: VolumeSpecification & {
                VolumeType: string;
                SizeInGB: number;
            };
        })[];
        AutoScalingPolicy: AutoScalingPolicyDescription & {
            Constraints: ScalingConstraints & {
                MinCapacity: number;
                MaxCapacity: number;
            };
            Rules: (ScalingRule & {
                Name: string;
                Action: ScalingAction & {
                    SimpleScalingPolicyConfiguration: SimpleScalingPolicyConfiguration & {
                        ScalingAdjustment: number;
                    };
                };
                Trigger: ScalingTrigger & {
                    CloudWatchAlarmDefinition: CloudWatchAlarmDefinition & {
                        ComparisonOperator: ComparisonOperator;
                        MetricName: string;
                        Period: number;
                        Threshold: NonNegativeDouble;
                    };
                };
            })[];
        };
    })[] | undefined;
    Marker?: string | undefined;
}
export type InstanceGroupTypeList = InstanceGroupType[];
export type InstanceState = "AWAITING_FULFILLMENT" | "PROVISIONING" | "BOOTSTRAPPING" | "RUNNING" | "TERMINATED" | (string & {});
export type InstanceStateList = InstanceState[];
export interface ListInstancesInput {
    ClusterId?: string | undefined;
    InstanceGroupId?: string | undefined;
    InstanceGroupTypes?: InstanceGroupType[] | undefined;
    InstanceFleetId?: string | undefined;
    InstanceFleetType?: InstanceFleetType | undefined;
    InstanceStates?: InstanceState[] | undefined;
    Marker?: string | undefined;
}
export type InstanceStateChangeReasonCode = "INTERNAL_ERROR" | "VALIDATION_ERROR" | "INSTANCE_FAILURE" | "BOOTSTRAP_FAILURE" | "CLUSTER_TERMINATED" | (string & {});
export interface InstanceStateChangeReason {
    Code?: InstanceStateChangeReasonCode | undefined;
    Message?: string | undefined;
}
export interface InstanceTimeline {
    CreationDateTime?: Date | undefined;
    ReadyDateTime?: Date | undefined;
    EndDateTime?: Date | undefined;
}
export interface InstanceStatus {
    State?: InstanceState | undefined;
    StateChangeReason?: InstanceStateChangeReason | undefined;
    Timeline?: InstanceTimeline | undefined;
}
export interface EbsVolume {
    Device?: string | undefined;
    VolumeId?: string | undefined;
}
export type EbsVolumeList = EbsVolume[];
export interface Instance {
    Id?: string | undefined;
    Ec2InstanceId?: string | undefined;
    PublicDnsName?: string | undefined;
    PublicIpAddress?: string | undefined;
    PrivateDnsName?: string | undefined;
    PrivateIpAddress?: string | undefined;
    Status?: InstanceStatus | undefined;
    InstanceGroupId?: string | undefined;
    InstanceFleetId?: string | undefined;
    Market?: MarketType | undefined;
    InstanceType?: string | undefined;
    EbsVolumes?: EbsVolume[] | undefined;
}
export type InstanceList = Instance[];
export interface ListInstancesOutput {
    Instances?: Instance[] | undefined;
    Marker?: string | undefined;
}
export interface ListNotebookExecutionsInput {
    EditorId?: string | undefined;
    Status?: NotebookExecutionStatus | undefined;
    From?: Date | undefined;
    To?: Date | undefined;
    Marker?: string | undefined;
    ExecutionEngineId?: string | undefined;
}
export interface NotebookExecutionSummary {
    NotebookExecutionId?: string | undefined;
    EditorId?: string | undefined;
    NotebookExecutionName?: string | undefined;
    Status?: NotebookExecutionStatus | undefined;
    StartTime?: Date | undefined;
    EndTime?: Date | undefined;
    NotebookS3Location?: NotebookS3LocationForOutput | undefined;
    ExecutionEngineId?: string | undefined;
}
export type NotebookExecutionSummaryList = NotebookExecutionSummary[];
export interface ListNotebookExecutionsOutput {
    NotebookExecutions?: NotebookExecutionSummary[] | undefined;
    Marker?: string | undefined;
}
export interface ReleaseLabelFilter {
    Prefix?: string | undefined;
    Application?: string | undefined;
}
export interface ListReleaseLabelsInput {
    Filters?: ReleaseLabelFilter | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export interface ListReleaseLabelsOutput {
    ReleaseLabels?: string[] | undefined;
    NextToken?: string | undefined;
}
export interface ListSecurityConfigurationsInput {
    Marker?: string | undefined;
}
export interface SecurityConfigurationSummary {
    Name?: string | undefined;
    CreationDateTime?: Date | undefined;
}
export type SecurityConfigurationList = SecurityConfigurationSummary[];
export interface ListSecurityConfigurationsOutput {
    SecurityConfigurations?: SecurityConfigurationSummary[] | undefined;
    Marker?: string | undefined;
}
export type SessionStateList = SessionState[];
export interface ListSessionsInput {
    ClusterId?: string | undefined;
    SessionStates?: SessionState[] | undefined;
    NextToken?: string | undefined;
    MaxResults?: number | undefined;
}
export type SessionList = Session[];
export interface ListSessionsOutput {
    Sessions?: (Session & {
        Id: SessionId;
        ClusterId: ClusterId;
        Arn: ArnType;
        State: SessionState;
    })[] | undefined;
    NextToken?: string | undefined;
}
export type StepStateList = StepState[];
export interface ListStepsInput {
    ClusterId?: string | undefined;
    StepStates?: StepState[] | undefined;
    StepIds?: string[] | undefined;
    Marker?: string | undefined;
}
export interface StepSummary {
    Id?: string | undefined;
    Name?: string | undefined;
    Config?: HadoopStepConfig | undefined;
    ActionOnFailure?: ActionOnFailure | undefined;
    Status?: StepStatus | undefined;
    LogUri?: string | undefined;
    EncryptionKeyArn?: string | undefined;
    AdditionalInfo?: StepAdditionalInfo | undefined;
}
export type StepSummaryList = StepSummary[];
export interface ListStepsOutput {
    Steps?: StepSummary[] | undefined;
    Marker?: string | undefined;
}
export interface ListStudiosInput {
    Marker?: string | undefined;
}
export interface StudioSummary {
    StudioId?: string | undefined;
    Name?: string | undefined;
    VpcId?: string | undefined;
    Description?: string | undefined;
    Url?: string | undefined;
    AuthMode?: AuthMode | undefined;
    CreationTime?: Date | undefined;
}
export type StudioSummaryList = StudioSummary[];
export interface ListStudiosOutput {
    Studios?: StudioSummary[] | undefined;
    Marker?: string | undefined;
}
export interface ListStudioSessionMappingsInput {
    StudioId?: string | undefined;
    IdentityType?: IdentityType | undefined;
    Marker?: string | undefined;
}
export interface SessionMappingSummary {
    StudioId?: string | undefined;
    IdentityId?: string | undefined;
    IdentityName?: string | undefined;
    IdentityType?: IdentityType | undefined;
    SessionPolicyArn?: string | undefined;
    CreationTime?: Date | undefined;
}
export type SessionMappingSummaryList = SessionMappingSummary[];
export interface ListStudioSessionMappingsOutput {
    SessionMappings?: SessionMappingSummary[] | undefined;
    Marker?: string | undefined;
}
export interface ListSupportedInstanceTypesInput {
    ReleaseLabel?: string | undefined;
    Marker?: string | undefined;
}
export interface SupportedInstanceType {
    Type?: string | undefined;
    MemoryGB?: number | undefined;
    StorageGB?: number | undefined;
    VCPU?: number | undefined;
    Is64BitsOnly?: boolean | undefined;
    InstanceFamilyId?: string | undefined;
    EbsOptimizedAvailable?: boolean | undefined;
    EbsOptimizedByDefault?: boolean | undefined;
    NumberOfDisks?: number | undefined;
    EbsStorageOnly?: boolean | undefined;
    Architecture?: string | undefined;
}
export type SupportedInstanceTypesList = SupportedInstanceType[];
export interface ListSupportedInstanceTypesOutput {
    SupportedInstanceTypes?: SupportedInstanceType[] | undefined;
    Marker?: string | undefined;
}
export interface ModifyClusterInput {
    ClusterId?: string | undefined;
    StepConcurrencyLevel?: number | undefined;
    ExtendedSupport?: boolean | undefined;
}
export interface ModifyClusterOutput {
    StepConcurrencyLevel?: number | undefined;
    ExtendedSupport?: boolean | undefined;
}
export interface InstanceFleetModifyConfig {
    InstanceFleetId?: string | undefined;
    TargetOnDemandCapacity?: number | undefined;
    TargetSpotCapacity?: number | undefined;
    ResizeSpecifications?: InstanceFleetResizingSpecifications | undefined;
    InstanceTypeConfigs?: InstanceTypeConfig[] | undefined;
    Context?: string | undefined;
}
export interface ModifyInstanceFleetInput {
    ClusterId?: string | undefined;
    InstanceFleet?: InstanceFleetModifyConfig | undefined;
}
export interface ModifyInstanceFleetResponse {
}
export type EC2InstanceIdsToTerminateList = string[];
export type ReconfigurationType = "OVERWRITE" | "MERGE" | (string & {});
export interface InstanceGroupModifyConfig {
    InstanceGroupId?: string | undefined;
    InstanceCount?: number | undefined;
    EC2InstanceIdsToTerminate?: string[] | undefined;
    ShrinkPolicy?: ShrinkPolicy | undefined;
    ReconfigurationType?: ReconfigurationType | undefined;
    Configurations?: Configuration[] | undefined;
}
export type InstanceGroupModifyConfigList = InstanceGroupModifyConfig[];
export interface ModifyInstanceGroupsInput {
    ClusterId?: string | undefined;
    InstanceGroups?: InstanceGroupModifyConfig[] | undefined;
}
export interface ModifyInstanceGroupsResponse {
}
export interface PutAutoScalingPolicyInput {
    ClusterId?: string | undefined;
    InstanceGroupId?: string | undefined;
    AutoScalingPolicy?: AutoScalingPolicy | undefined;
}
export interface PutAutoScalingPolicyOutput {
    ClusterId?: string | undefined;
    InstanceGroupId?: string | undefined;
    AutoScalingPolicy?: (AutoScalingPolicyDescription & {
        Constraints: ScalingConstraints & {
            MinCapacity: number;
            MaxCapacity: number;
        };
        Rules: (ScalingRule & {
            Name: string;
            Action: ScalingAction & {
                SimpleScalingPolicyConfiguration: SimpleScalingPolicyConfiguration & {
                    ScalingAdjustment: number;
                };
            };
            Trigger: ScalingTrigger & {
                CloudWatchAlarmDefinition: CloudWatchAlarmDefinition & {
                    ComparisonOperator: ComparisonOperator;
                    MetricName: string;
                    Period: number;
                    Threshold: NonNegativeDouble;
                };
            };
        })[];
    }) | undefined;
    ClusterArn?: string | undefined;
}
export interface PutAutoTerminationPolicyInput {
    ClusterId?: string | undefined;
    AutoTerminationPolicy?: AutoTerminationPolicy | undefined;
}
export interface PutAutoTerminationPolicyOutput {
}
export interface PutBlockPublicAccessConfigurationInput {
    BlockPublicAccessConfiguration?: BlockPublicAccessConfiguration | undefined;
}
export interface PutBlockPublicAccessConfigurationOutput {
}
export interface PutManagedScalingPolicyInput {
    ClusterId?: string | undefined;
    ManagedScalingPolicy?: ManagedScalingPolicy | undefined;
}
export interface PutManagedScalingPolicyOutput {
}
export interface RemoveAutoScalingPolicyInput {
    ClusterId?: string | undefined;
    InstanceGroupId?: string | undefined;
}
export interface RemoveAutoScalingPolicyOutput {
}
export interface RemoveAutoTerminationPolicyInput {
    ClusterId?: string | undefined;
}
export interface RemoveAutoTerminationPolicyOutput {
}
export interface RemoveManagedScalingPolicyInput {
    ClusterId?: string | undefined;
}
export interface RemoveManagedScalingPolicyOutput {
}
export interface RemoveTagsInput {
    ResourceId?: string | undefined;
    TagKeys?: string[] | undefined;
    ClusterId?: string | undefined;
}
export interface RemoveTagsOutput {
}
export type InstanceFleetConfigList = InstanceFleetConfig[];
export type SecurityGroupsList = string[];
export interface JobFlowInstancesConfig {
    MasterInstanceType?: string | undefined;
    SlaveInstanceType?: string | undefined;
    InstanceCount?: number | undefined;
    InstanceGroups?: InstanceGroupConfig[] | undefined;
    InstanceFleets?: InstanceFleetConfig[] | undefined;
    Ec2KeyName?: string | undefined;
    Placement?: PlacementType | undefined;
    KeepJobFlowAliveWhenNoSteps?: boolean | undefined;
    TerminationProtected?: boolean | undefined;
    UnhealthyNodeReplacement?: boolean | undefined;
    HadoopVersion?: string | undefined;
    Ec2SubnetId?: string | undefined;
    Ec2SubnetIds?: string[] | undefined;
    EmrManagedMasterSecurityGroup?: string | undefined;
    EmrManagedSlaveSecurityGroup?: string | undefined;
    ServiceAccessSecurityGroup?: string | undefined;
    AdditionalMasterSecurityGroups?: string[] | undefined;
    AdditionalSlaveSecurityGroups?: string[] | undefined;
}
export type BootstrapActionConfigList = BootstrapActionConfig[];
export interface SupportedProductConfig {
    Name?: string | undefined;
    Args?: string[] | undefined;
}
export type NewSupportedProductsList = SupportedProductConfig[];
export interface RunJobFlowInput {
    Name?: string | undefined;
    LogUri?: string | undefined;
    LogEncryptionKmsKeyId?: string | undefined;
    AdditionalInfo?: string | undefined;
    AmiVersion?: string | undefined;
    ReleaseLabel?: string | undefined;
    Instances?: JobFlowInstancesConfig | undefined;
    Steps?: StepConfig[] | undefined;
    StepExecutionRoleArn?: string | undefined;
    BootstrapActions?: BootstrapActionConfig[] | undefined;
    SupportedProducts?: string[] | undefined;
    NewSupportedProducts?: SupportedProductConfig[] | undefined;
    Applications?: Application[] | undefined;
    Configurations?: Configuration[] | undefined;
    VisibleToAllUsers?: boolean | undefined;
    JobFlowRole?: string | undefined;
    ServiceRole?: string | undefined;
    Tags?: Tag[] | undefined;
    SecurityConfiguration?: string | undefined;
    AutoScalingRole?: string | undefined;
    ScaleDownBehavior?: ScaleDownBehavior | undefined;
    CustomAmiId?: string | undefined;
    EbsRootVolumeSize?: number | undefined;
    RepoUpgradeOnBoot?: RepoUpgradeOnBoot | undefined;
    KerberosAttributes?: KerberosAttributes | undefined;
    StepConcurrencyLevel?: number | undefined;
    ManagedScalingPolicy?: ManagedScalingPolicy | undefined;
    PlacementGroupConfigs?: PlacementGroupConfig[] | undefined;
    AutoTerminationPolicy?: AutoTerminationPolicy | undefined;
    OSReleaseLabel?: string | undefined;
    EbsRootVolumeIops?: number | undefined;
    EbsRootVolumeThroughput?: number | undefined;
    ExtendedSupport?: boolean | undefined;
    MonitoringConfiguration?: MonitoringConfiguration | undefined;
    SessionEnabled?: boolean | undefined;
}
export interface RunJobFlowOutput {
    JobFlowId?: string | undefined;
    ClusterArn?: string | undefined;
}
export interface SetKeepJobFlowAliveWhenNoStepsInput {
    JobFlowIds?: string[] | undefined;
    KeepJobFlowAliveWhenNoSteps?: boolean | undefined;
}
export interface SetKeepJobFlowAliveWhenNoStepsResponse {
}
export interface SetTerminationProtectionInput {
    JobFlowIds?: string[] | undefined;
    TerminationProtected?: boolean | undefined;
}
export interface SetTerminationProtectionResponse {
}
export interface SetUnhealthyNodeReplacementInput {
    JobFlowIds?: string[] | undefined;
    UnhealthyNodeReplacement?: boolean | undefined;
}
export interface SetUnhealthyNodeReplacementResponse {
}
export interface SetVisibleToAllUsersInput {
    JobFlowIds?: string[] | undefined;
    VisibleToAllUsers?: boolean | undefined;
}
export interface SetVisibleToAllUsersResponse {
}
export interface NotebookS3LocationFromInput {
    Bucket?: string | undefined;
    Key?: string | undefined;
}
export interface OutputNotebookS3LocationFromInput {
    Bucket?: string | undefined;
    Key?: string | undefined;
}
export interface StartNotebookExecutionInput {
    EditorId?: string | undefined;
    RelativePath?: string | undefined;
    NotebookExecutionName?: string | undefined;
    NotebookParams?: string | undefined;
    ExecutionEngine?: ExecutionEngineConfig | undefined;
    ServiceRole?: string | undefined;
    NotebookInstanceSecurityGroupId?: string | undefined;
    Tags?: Tag[] | undefined;
    NotebookS3Location?: NotebookS3LocationFromInput | undefined;
    OutputNotebookS3Location?: OutputNotebookS3LocationFromInput | undefined;
    OutputNotebookFormat?: OutputNotebookFormat | undefined;
    EnvironmentVariables?: {
        [key: string]: string | undefined;
    } | undefined;
}
export interface StartNotebookExecutionOutput {
    NotebookExecutionId?: string | undefined;
}
export type ClientRequestToken = string;
export interface StartSessionInput {
    Name?: string | undefined;
    ClusterId?: string | undefined;
    ExecutionRoleArn?: string | undefined;
    EngineConfigurations?: Configuration[] | undefined;
    MonitoringConfiguration?: SessionMonitoringConfiguration | undefined;
    SessionIdleTimeoutInMinutes?: number | undefined;
    ClientRequestToken?: string | undefined;
    Tags?: Tag[] | undefined;
}
export interface StartSessionOutput {
    Id: string;
    ClusterId?: string | undefined;
    Arn?: string | undefined;
    AccountId?: string | undefined;
    State?: SessionState | undefined;
}
export interface StopNotebookExecutionInput {
    NotebookExecutionId?: string | undefined;
}
export interface StopNotebookExecutionResponse {
}
export interface TerminateJobFlowsInput {
    JobFlowIds?: string[] | undefined;
}
export interface TerminateJobFlowsResponse {
}
export interface TerminateSessionInput {
    ClusterId?: string | undefined;
    SessionId?: string | undefined;
}
export interface TerminateSessionOutput {
    ClusterId: string;
    SessionId: string;
    State: SessionState;
}
export interface UpdateStudioInput {
    StudioId?: string | undefined;
    Name?: string | undefined;
    Description?: string | undefined;
    SubnetIds?: string[] | undefined;
    DefaultS3Location?: string | undefined;
    EncryptionKeyArn?: string | undefined;
}
export interface UpdateStudioResponse {
}
export interface UpdateStudioSessionMappingInput {
    StudioId?: string | undefined;
    IdentityId?: string | undefined;
    IdentityName?: string | undefined;
    IdentityType?: IdentityType | undefined;
    SessionPolicyArn?: string | undefined;
}
export interface UpdateStudioSessionMappingResponse {
}
export type ErrorMessage = string;
export type ErrorCode = string;
export type AddInstanceFleetError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Adds an instance fleet to a running cluster.
 *
 * The instance fleet configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x.
 */
export declare const addInstanceFleet: API.OperationMethod<AddInstanceFleetInput & RegionInput, AddInstanceFleetOutput, AddInstanceFleetError, Creds | HttpClient.HttpClient>;
export type AddInstanceGroupsError = InternalServerError | CommonErrors;
/**
 * Adds one or more instance groups to a running cluster.
 */
export declare const addInstanceGroups: API.OperationMethod<AddInstanceGroupsInput & RegionInput, AddInstanceGroupsOutput, AddInstanceGroupsError, Creds | HttpClient.HttpClient>;
export type AddJobFlowStepsError = InternalServerError | CommonErrors;
/**
 * AddJobFlowSteps adds new steps to a running cluster. A maximum of 256 steps are allowed
 * in each job flow.
 *
 * If your cluster is long-running (such as a Hive data warehouse) or complex, you may
 * require more than 256 steps to process your data. You can bypass the 256-step limitation in
 * various ways, including using SSH to connect to the master node and submitting queries
 * directly to the software running on the master node, such as Hive and Hadoop.
 *
 * A step specifies the location of a JAR file stored either on the master node of the
 * cluster or in Amazon S3. Each step is performed by the main function of the main
 * class of the JAR file. The main class can be specified either in the manifest of the JAR or
 * by using the MainFunction parameter of the step.
 *
 * Amazon EMR executes each step in the order listed. For a step to be considered
 * complete, the main function must exit with a zero exit code and all Hadoop jobs started
 * while the step was running must have completed and run successfully.
 *
 * You can only add steps to a cluster that is in one of the following states: STARTING,
 * BOOTSTRAPPING, RUNNING, or WAITING.
 *
 * The string values passed into `HadoopJarStep` object cannot exceed a total
 * of 10240 characters.
 */
export declare const addJobFlowSteps: API.OperationMethod<AddJobFlowStepsInput & RegionInput, AddJobFlowStepsOutput, AddJobFlowStepsError, Creds | HttpClient.HttpClient>;
export type AddTagsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Adds tags to an Amazon EMR resource, such as a cluster or an Amazon EMR
 * Studio. Tags make it easier to associate resources in various ways, such as grouping
 * clusters to track your Amazon EMR resource allocation costs. For more information,
 * see Tag
 * Clusters.
 */
export declare const addTags: API.OperationMethod<AddTagsInput & RegionInput, AddTagsOutput, AddTagsError, Creds | HttpClient.HttpClient>;
export type CancelStepsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Cancels a pending step or steps in a running cluster. Available only in Amazon EMR versions 4.8.0 and later, excluding version 5.0.0. A maximum of 256 steps are allowed in
 * each CancelSteps request. CancelSteps is idempotent but asynchronous; it does not guarantee
 * that a step will be canceled, even if the request is successfully submitted. When you use
 * Amazon EMR releases 5.28.0 and later, you can cancel steps that are in a
 * `PENDING` or `RUNNING` state. In earlier versions of Amazon EMR, you can only cancel steps that are in a `PENDING` state.
 */
export declare const cancelSteps: API.OperationMethod<CancelStepsInput & RegionInput, CancelStepsOutput, CancelStepsError, Creds | HttpClient.HttpClient>;
export type CreatePersistentAppUIError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates a persistent application user interface.
 */
export declare const createPersistentAppUI: API.OperationMethod<CreatePersistentAppUIInput & RegionInput, CreatePersistentAppUIOutput, CreatePersistentAppUIError, Creds | HttpClient.HttpClient>;
export type CreateSecurityConfigurationError = InternalServerException | InvalidRequestException | SecurityConfigurationAlreadyExists | CommonErrors;
/**
 * Creates a security configuration, which is stored in the service and can be specified
 * when a cluster is created.
 */
export declare const createSecurityConfiguration: API.OperationMethod<CreateSecurityConfigurationInput & RegionInput, CreateSecurityConfigurationOutput, CreateSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type CreateStudioError = InternalServerException | InvalidRequestException | StudioServiceRoleNotAssumable | StudioServiceRoleMissingS3Access | CommonErrors;
/**
 * Creates a new Amazon EMR Studio.
 */
export declare const createStudio: API.OperationMethod<CreateStudioInput & RegionInput, CreateStudioOutput, CreateStudioError, Creds | HttpClient.HttpClient>;
export type CreateStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Maps a user or group to the Amazon EMR Studio specified by
 * `StudioId`, and applies a session policy to refine Studio permissions for that
 * user or group. Use `CreateStudioSessionMapping` to assign users to a Studio when
 * you use IAM Identity Center authentication. For instructions on how to assign users to a
 * Studio when you use IAM authentication, see Assign a user or group to your EMR Studio.
 */
export declare const createStudioSessionMapping: API.OperationMethod<CreateStudioSessionMappingInput & RegionInput, CreateStudioSessionMappingResponse, CreateStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export type DeleteSecurityConfigurationError = InternalServerException | InvalidRequestException | SecurityConfigurationNotFound | CommonErrors;
/**
 * Deletes a security configuration.
 */
export declare const deleteSecurityConfiguration: API.OperationMethod<DeleteSecurityConfigurationInput & RegionInput, DeleteSecurityConfigurationOutput, DeleteSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DeleteStudioError = InternalServerException | InvalidRequestException | StudioNotFound | CommonErrors;
/**
 * Removes an Amazon EMR Studio from the Studio metadata store.
 */
export declare const deleteStudio: API.OperationMethod<DeleteStudioInput & RegionInput, DeleteStudioResponse, DeleteStudioError, Creds | HttpClient.HttpClient>;
export type DeleteStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Removes a user or group from an Amazon EMR Studio.
 */
export declare const deleteStudioSessionMapping: API.OperationMethod<DeleteStudioSessionMappingInput & RegionInput, DeleteStudioSessionMappingResponse, DeleteStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export type DescribeClusterError = InternalServerException | InvalidRequestException | ClusterNotFound | CommonErrors;
/**
 * Provides cluster-level details including status, hardware and software configuration,
 * VPC settings, and so on.
 */
export declare const describeCluster: API.OperationMethod<DescribeClusterInput & RegionInput, DescribeClusterOutput, DescribeClusterError, Creds | HttpClient.HttpClient>;
export type DescribeJobFlowsError = InternalServerError | CommonErrors;
/**
 * This API is no longer supported and will eventually be removed. We recommend you use
 * ListClusters, DescribeCluster, ListSteps, ListInstanceGroups and ListBootstrapActions instead.
 *
 * DescribeJobFlows returns a list of job flows that match all of the supplied parameters.
 * The parameters can include a list of job flow IDs, job flow states, and restrictions on job
 * flow creation date and time.
 *
 * Regardless of supplied parameters, only job flows created within the last two months are
 * returned.
 *
 * If no parameters are supplied, then job flows matching either of the following criteria
 * are returned:
 *
 * - Job flows created and completed in the last two weeks
 *
 * - Job flows created within the last two months that are in one of the following
 * states: `RUNNING`, `WAITING`, `SHUTTING_DOWN`,
 * `STARTING`
 *
 * Amazon EMR can return a maximum of 512 job flow descriptions.
 */
export declare const describeJobFlows: API.OperationMethod<DescribeJobFlowsInput & RegionInput, DescribeJobFlowsOutput, DescribeJobFlowsError, Creds | HttpClient.HttpClient>;
export type DescribeNotebookExecutionError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Provides details of a notebook execution.
 */
export declare const describeNotebookExecution: API.OperationMethod<DescribeNotebookExecutionInput & RegionInput, DescribeNotebookExecutionOutput, DescribeNotebookExecutionError, Creds | HttpClient.HttpClient>;
export type DescribePersistentAppUIError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Describes a persistent application user interface.
 */
export declare const describePersistentAppUI: API.OperationMethod<DescribePersistentAppUIInput & RegionInput, DescribePersistentAppUIOutput, DescribePersistentAppUIError, Creds | HttpClient.HttpClient>;
export type DescribeReleaseLabelError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides Amazon EMR release label details, such as the releases available the
 * Region where the API request is run, and the available applications for a specific Amazon EMR release label. Can also list Amazon EMR releases that support a
 * specified version of Spark.
 */
export declare const describeReleaseLabel: API.OperationMethod<DescribeReleaseLabelInput & RegionInput, DescribeReleaseLabelOutput, DescribeReleaseLabelError, Creds | HttpClient.HttpClient>;
export type DescribeSecurityConfigurationError = InternalServerException | InvalidRequestException | SecurityConfigurationNotFound | CommonErrors;
/**
 * Provides the details of a security configuration by returning the configuration
 * JSON.
 */
export declare const describeSecurityConfiguration: API.OperationMethod<DescribeSecurityConfigurationInput & RegionInput, DescribeSecurityConfigurationOutput, DescribeSecurityConfigurationError, Creds | HttpClient.HttpClient>;
export type DescribeStepError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides more detail about the cluster step.
 */
export declare const describeStep: API.OperationMethod<DescribeStepInput & RegionInput, DescribeStepOutput, DescribeStepError, Creds | HttpClient.HttpClient>;
export type DescribeStudioError = InternalServerException | InvalidRequestException | StudioNotFound | CommonErrors;
/**
 * Returns details for the specified Amazon EMR Studio including ID, Name, VPC,
 * Studio access URL, and so on.
 */
export declare const describeStudio: API.OperationMethod<DescribeStudioInput & RegionInput, DescribeStudioOutput, DescribeStudioError, Creds | HttpClient.HttpClient>;
export type GetAutoTerminationPolicyError = CommonErrors;
/**
 * Returns the auto-termination policy for an Amazon EMR cluster.
 */
export declare const getAutoTerminationPolicy: API.OperationMethod<GetAutoTerminationPolicyInput & RegionInput, GetAutoTerminationPolicyOutput, GetAutoTerminationPolicyError, Creds | HttpClient.HttpClient>;
export type GetBlockPublicAccessConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the Amazon EMR block public access configuration for your Amazon Web Services account in the current Region. For more information see Configure Block
 * Public Access for Amazon EMR in the Amazon EMR
 * Management Guide.
 */
export declare const getBlockPublicAccessConfiguration: API.OperationMethod<GetBlockPublicAccessConfigurationInput & RegionInput, GetBlockPublicAccessConfigurationOutput, GetBlockPublicAccessConfigurationError, Creds | HttpClient.HttpClient>;
export type GetClusterSessionCredentialsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Provides temporary, HTTP basic credentials that are associated with a given runtime
 * IAM role and used by a cluster with fine-grained access control
 * activated. You can use these credentials to connect to cluster endpoints that support
 * username and password authentication.
 */
export declare const getClusterSessionCredentials: API.OperationMethod<GetClusterSessionCredentialsInput & RegionInput, GetClusterSessionCredentialsOutput, GetClusterSessionCredentialsError, Creds | HttpClient.HttpClient>;
export type GetManagedScalingPolicyError = CommonErrors;
/**
 * Fetches the attached managed scaling policy for an Amazon EMR cluster.
 */
export declare const getManagedScalingPolicy: API.OperationMethod<GetManagedScalingPolicyInput & RegionInput, GetManagedScalingPolicyOutput, GetManagedScalingPolicyError, Creds | HttpClient.HttpClient>;
export type GetOnClusterAppUIPresignedURLError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * The presigned URL properties for the cluster's application user interface.
 */
export declare const getOnClusterAppUIPresignedURL: API.OperationMethod<GetOnClusterAppUIPresignedURLInput & RegionInput, GetOnClusterAppUIPresignedURLOutput, GetOnClusterAppUIPresignedURLError, Creds | HttpClient.HttpClient>;
export type GetPersistentAppUIPresignedURLError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * The presigned URL properties for the cluster's application user interface.
 */
export declare const getPersistentAppUIPresignedURL: API.OperationMethod<GetPersistentAppUIPresignedURLInput & RegionInput, GetPersistentAppUIPresignedURLOutput, GetPersistentAppUIPresignedURLError, Creds | HttpClient.HttpClient>;
export type GetSessionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns detailed information about a session.
 */
export declare const getSession: API.OperationMethod<GetSessionInput & RegionInput, GetSessionOutput, GetSessionError, Creds | HttpClient.HttpClient>;
export type GetSessionEndpointError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns the Spark Connect endpoint URL and a time-limited authentication token for the specified session. Use the endpoint and token to connect a PySpark client to the session. Call this operation again when the token expires to obtain a new one.
 */
export declare const getSessionEndpoint: API.OperationMethod<GetSessionEndpointInput & RegionInput, GetSessionEndpointOutput, GetSessionEndpointError, Creds | HttpClient.HttpClient>;
export type GetStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Fetches mapping details for the specified Amazon EMR Studio and identity (user
 * or group).
 */
export declare const getStudioSessionMapping: API.OperationMethod<GetStudioSessionMappingInput & RegionInput, GetStudioSessionMappingOutput, GetStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export type ListBootstrapActionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides information about the bootstrap actions associated with a cluster.
 */
export declare const listBootstrapActions: API.PaginatedOperationMethod<ListBootstrapActionsInput & RegionInput, ListBootstrapActionsOutput, ListBootstrapActionsError, Creds | HttpClient.HttpClient, Command>;
export type ListClustersError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides the status of all clusters visible to this Amazon Web Services account. Allows
 * you to filter the list of clusters based on certain criteria; for example, filtering by
 * cluster creation date and time or by status. This call returns a maximum of 50 clusters in
 * unsorted order per call, but returns a marker to track the paging of the cluster list
 * across multiple ListClusters calls.
 */
export declare const listClusters: API.PaginatedOperationMethod<ListClustersInput & RegionInput, ListClustersOutput, ListClustersError, Creds | HttpClient.HttpClient, ClusterSummary>;
export type ListInstanceFleetsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists all available details about the instance fleets in a cluster.
 *
 * The instance fleet configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x versions.
 */
export declare const listInstanceFleets: API.PaginatedOperationMethod<ListInstanceFleetsInput & RegionInput, ListInstanceFleetsOutput, ListInstanceFleetsError, Creds | HttpClient.HttpClient, InstanceFleet>;
export type ListInstanceGroupsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides all available details about the instance groups in a cluster.
 */
export declare const listInstanceGroups: API.PaginatedOperationMethod<ListInstanceGroupsInput & RegionInput, ListInstanceGroupsOutput, ListInstanceGroupsError, Creds | HttpClient.HttpClient, InstanceGroup>;
export type ListInstancesError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides information for all active Amazon EC2 instances and Amazon EC2
 * instances terminated in the last 30 days, up to a maximum of 2,000. Amazon EC2
 * instances in any of the following states are considered active: AWAITING_FULFILLMENT,
 * PROVISIONING, BOOTSTRAPPING, RUNNING.
 */
export declare const listInstances: API.PaginatedOperationMethod<ListInstancesInput & RegionInput, ListInstancesOutput, ListInstancesError, Creds | HttpClient.HttpClient, Instance>;
export type ListNotebookExecutionsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Provides summaries of all notebook executions. You can filter the list based on multiple
 * criteria such as status, time range, and editor id. Returns a maximum of 50 notebook
 * executions and a marker to track the paging of a longer notebook execution list across
 * multiple `ListNotebookExecutions` calls.
 */
export declare const listNotebookExecutions: API.PaginatedOperationMethod<ListNotebookExecutionsInput & RegionInput, ListNotebookExecutionsOutput, ListNotebookExecutionsError, Creds | HttpClient.HttpClient, NotebookExecutionSummary>;
export type ListReleaseLabelsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Retrieves release labels of Amazon EMR services in the Region where the API is
 * called.
 */
export declare const listReleaseLabels: API.PaginatedOperationMethod<ListReleaseLabelsInput & RegionInput, ListReleaseLabelsOutput, ListReleaseLabelsError, Creds | HttpClient.HttpClient, unknown>;
export type ListSecurityConfigurationsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists all the security configurations visible to this account, providing their creation
 * dates and times, and their names. This call returns a maximum of 50 clusters per call, but
 * returns a marker to track the paging of the cluster list across multiple
 * ListSecurityConfigurations calls.
 */
export declare const listSecurityConfigurations: API.PaginatedOperationMethod<ListSecurityConfigurationsInput & RegionInput, ListSecurityConfigurationsOutput, ListSecurityConfigurationsError, Creds | HttpClient.HttpClient, SecurityConfigurationSummary>;
export type ListSessionsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Lists the sessions on a cluster. You can filter the results by session state. Newer sessions are returned first.
 */
export declare const listSessions: API.PaginatedOperationMethod<ListSessionsInput & RegionInput, ListSessionsOutput, ListSessionsError, Creds | HttpClient.HttpClient, Session>;
export type ListStepsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Provides a list of steps for the cluster in reverse order unless you specify
 * `stepIds` with the request or filter by `StepStates`. You can
 * specify a maximum of 10 `stepIDs`. The CLI automatically
 * paginates results to return a list greater than 50 steps. To return more than 50 steps
 * using the CLI, specify a `Marker`, which is a pagination token
 * that indicates the next set of steps to retrieve.
 */
export declare const listSteps: API.PaginatedOperationMethod<ListStepsInput & RegionInput, ListStepsOutput, ListStepsError, Creds | HttpClient.HttpClient, StepSummary>;
export type ListStudiosError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Returns a list of all Amazon EMR Studios associated with the Amazon Web Services account. The list includes details such as ID, Studio Access URL, and
 * creation time for each Studio.
 */
export declare const listStudios: API.PaginatedOperationMethod<ListStudiosInput & RegionInput, ListStudiosOutput, ListStudiosError, Creds | HttpClient.HttpClient, StudioSummary>;
export type ListStudioSessionMappingsError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Returns a list of all user or group session mappings for the Amazon EMR Studio
 * specified by `StudioId`.
 */
export declare const listStudioSessionMappings: API.PaginatedOperationMethod<ListStudioSessionMappingsInput & RegionInput, ListStudioSessionMappingsOutput, ListStudioSessionMappingsError, Creds | HttpClient.HttpClient, SessionMappingSummary>;
export type ListSupportedInstanceTypesError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * A list of the instance types that Amazon EMR supports. You can filter the
 * list by Amazon Web Services Region and Amazon EMR release.
 */
export declare const listSupportedInstanceTypes: API.PaginatedOperationMethod<ListSupportedInstanceTypesInput & RegionInput, ListSupportedInstanceTypesOutput, ListSupportedInstanceTypesError, Creds | HttpClient.HttpClient, unknown>;
export type ModifyClusterError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Modifies the number of steps that can be executed concurrently for the cluster specified
 * using ClusterID.
 */
export declare const modifyCluster: API.OperationMethod<ModifyClusterInput & RegionInput, ModifyClusterOutput, ModifyClusterError, Creds | HttpClient.HttpClient>;
export type ModifyInstanceFleetError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Modifies the target On-Demand and target Spot capacities for the instance fleet with the
 * specified InstanceFleetID within the cluster specified using ClusterID. The call either
 * succeeds or fails atomically.
 *
 * The instance fleet configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x versions.
 */
export declare const modifyInstanceFleet: API.OperationMethod<ModifyInstanceFleetInput & RegionInput, ModifyInstanceFleetResponse, ModifyInstanceFleetError, Creds | HttpClient.HttpClient>;
export type ModifyInstanceGroupsError = InternalServerError | CommonErrors;
/**
 * ModifyInstanceGroups modifies the number of nodes and configuration settings of an
 * instance group. The input parameters include the new target instance count for the group
 * and the instance group ID. The call will either succeed or fail atomically.
 */
export declare const modifyInstanceGroups: API.OperationMethod<ModifyInstanceGroupsInput & RegionInput, ModifyInstanceGroupsResponse, ModifyInstanceGroupsError, Creds | HttpClient.HttpClient>;
export type PutAutoScalingPolicyError = CommonErrors;
/**
 * Creates or updates an automatic scaling policy for a core instance group or task
 * instance group in an Amazon EMR cluster. The automatic scaling policy defines how
 * an instance group dynamically adds and terminates Amazon EC2 instances in response
 * to the value of a CloudWatch metric.
 */
export declare const putAutoScalingPolicy: API.OperationMethod<PutAutoScalingPolicyInput & RegionInput, PutAutoScalingPolicyOutput, PutAutoScalingPolicyError, Creds | HttpClient.HttpClient>;
export type PutAutoTerminationPolicyError = CommonErrors;
/**
 * Auto-termination is supported in Amazon EMR releases 5.30.0 and 6.1.0 and
 * later. For more information, see Using an
 * auto-termination policy.
 *
 * Creates or updates an auto-termination policy for an Amazon EMR cluster. An
 * auto-termination policy defines the amount of idle time in seconds after which a cluster
 * automatically terminates. For alternative cluster termination options, see Control
 * cluster termination.
 */
export declare const putAutoTerminationPolicy: API.OperationMethod<PutAutoTerminationPolicyInput & RegionInput, PutAutoTerminationPolicyOutput, PutAutoTerminationPolicyError, Creds | HttpClient.HttpClient>;
export type PutBlockPublicAccessConfigurationError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates or updates an Amazon EMR block public access configuration for your
 * Amazon Web Services account in the current Region. For more information see Configure Block
 * Public Access for Amazon EMR in the Amazon EMR
 * Management Guide.
 */
export declare const putBlockPublicAccessConfiguration: API.OperationMethod<PutBlockPublicAccessConfigurationInput & RegionInput, PutBlockPublicAccessConfigurationOutput, PutBlockPublicAccessConfigurationError, Creds | HttpClient.HttpClient>;
export type PutManagedScalingPolicyError = CommonErrors;
/**
 * Creates or updates a managed scaling policy for an Amazon EMR cluster. The
 * managed scaling policy defines the limits for resources, such as Amazon EC2
 * instances that can be added or terminated from a cluster. The policy only applies to the
 * core and task nodes. The master node cannot be scaled after initial configuration.
 */
export declare const putManagedScalingPolicy: API.OperationMethod<PutManagedScalingPolicyInput & RegionInput, PutManagedScalingPolicyOutput, PutManagedScalingPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveAutoScalingPolicyError = CommonErrors;
/**
 * Removes an automatic scaling policy from a specified instance group within an Amazon EMR cluster.
 */
export declare const removeAutoScalingPolicy: API.OperationMethod<RemoveAutoScalingPolicyInput & RegionInput, RemoveAutoScalingPolicyOutput, RemoveAutoScalingPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveAutoTerminationPolicyError = CommonErrors;
/**
 * Removes an auto-termination policy from an Amazon EMR cluster.
 */
export declare const removeAutoTerminationPolicy: API.OperationMethod<RemoveAutoTerminationPolicyInput & RegionInput, RemoveAutoTerminationPolicyOutput, RemoveAutoTerminationPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveManagedScalingPolicyError = CommonErrors;
/**
 * Removes a managed scaling policy from a specified Amazon EMR cluster.
 */
export declare const removeManagedScalingPolicy: API.OperationMethod<RemoveManagedScalingPolicyInput & RegionInput, RemoveManagedScalingPolicyOutput, RemoveManagedScalingPolicyError, Creds | HttpClient.HttpClient>;
export type RemoveTagsError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Removes tags from an Amazon EMR resource, such as a cluster or Amazon EMR Studio. Tags make it easier to associate resources in various ways, such as grouping
 * clusters to track your Amazon EMR resource allocation costs. For more information,
 * see Tag
 * Clusters.
 *
 * The following example removes the stack tag with value Prod from a cluster:
 */
export declare const removeTags: API.OperationMethod<RemoveTagsInput & RegionInput, RemoveTagsOutput, RemoveTagsError, Creds | HttpClient.HttpClient>;
export type RunJobFlowError = InternalServerError | EmrInstanceProfileNotReady | CommonErrors;
/**
 * RunJobFlow creates and starts running a new cluster (job flow). The cluster runs the
 * steps specified. After the steps complete, the cluster stops and the HDFS partition is
 * lost. To prevent loss of data, configure the last step of the job flow to store results in
 * Amazon S3. If the JobFlowInstancesConfig
 * `KeepJobFlowAliveWhenNoSteps` parameter is set to `TRUE`, the cluster
 * transitions to the WAITING state rather than shutting down after the steps have completed.
 *
 * For additional protection, you can set the JobFlowInstancesConfig
 * `TerminationProtected` parameter to `TRUE` to lock the cluster and
 * prevent it from being terminated by API call, user intervention, or in the event of a job
 * flow error.
 *
 * A maximum of 256 steps are allowed in each job flow.
 *
 * If your cluster is long-running (such as a Hive data warehouse) or complex, you may
 * require more than 256 steps to process your data. You can bypass the 256-step limitation in
 * various ways, including using the SSH shell to connect to the master node and submitting
 * queries directly to the software running on the master node, such as Hive and
 * Hadoop.
 *
 * For long-running clusters, we recommend that you periodically store your results.
 *
 * The instance fleets configuration is available only in Amazon EMR releases
 * 4.8.0 and later, excluding 5.0.x versions. The RunJobFlow request can contain
 * InstanceFleets parameters or InstanceGroups parameters, but not both.
 */
export declare const runJobFlow: API.OperationMethod<RunJobFlowInput & RegionInput, RunJobFlowOutput, RunJobFlowError, Creds | HttpClient.HttpClient>;
export type SetKeepJobFlowAliveWhenNoStepsError = InternalServerError | CommonErrors;
/**
 * You can use the `SetKeepJobFlowAliveWhenNoSteps` to configure a cluster (job flow) to terminate after the step execution, i.e., all your
 * steps are executed. If you want a transient cluster that shuts down after the last of the current executing steps are completed,
 * you can configure `SetKeepJobFlowAliveWhenNoSteps` to false. If you want a long running cluster, configure `SetKeepJobFlowAliveWhenNoSteps` to true.
 *
 * For more information, see Managing Cluster Termination in the *Amazon EMR Management Guide*.
 */
export declare const setKeepJobFlowAliveWhenNoSteps: API.OperationMethod<SetKeepJobFlowAliveWhenNoStepsInput & RegionInput, SetKeepJobFlowAliveWhenNoStepsResponse, SetKeepJobFlowAliveWhenNoStepsError, Creds | HttpClient.HttpClient>;
export type SetTerminationProtectionError = InternalServerError | JobFlowNotFound | CommonErrors;
/**
 * SetTerminationProtection locks a cluster (job flow) so the Amazon EC2 instances
 * in the cluster cannot be terminated by user intervention, an API call, or in the event of a
 * job-flow error. The cluster still terminates upon successful completion of the job flow.
 * Calling `SetTerminationProtection` on a cluster is similar to calling the
 * Amazon EC2
 * `DisableAPITermination` API on all Amazon EC2 instances in a
 * cluster.
 *
 * `SetTerminationProtection` is used to prevent accidental termination of a
 * cluster and to ensure that in the event of an error, the instances persist so that you can
 * recover any data stored in their ephemeral instance storage.
 *
 * To terminate a cluster that has been locked by setting
 * `SetTerminationProtection` to `true`, you must first unlock the
 * job flow by a subsequent call to `SetTerminationProtection` in which you set the
 * value to `false`.
 *
 * For more information, see Managing Cluster
 * Termination in the *Amazon EMR Management Guide*.
 */
export declare const setTerminationProtection: API.OperationMethod<SetTerminationProtectionInput & RegionInput, SetTerminationProtectionResponse, SetTerminationProtectionError, Creds | HttpClient.HttpClient>;
export type SetUnhealthyNodeReplacementError = InternalServerError | CommonErrors;
/**
 * Specify whether to enable unhealthy node replacement, which lets Amazon EMR gracefully
 * replace core nodes on a cluster if any nodes become unhealthy. For example, a node becomes
 * unhealthy if disk usage is above 90%. If unhealthy node replacement is on and `TerminationProtected` are off,
 * Amazon EMR immediately terminates the unhealthy core nodes. To use unhealthy node replacement
 * and retain unhealthy core nodes, use to turn on
 * termination protection. In such cases, Amazon EMR adds
 * the unhealthy nodes to a denylist, reducing job interruptions and failures.
 *
 * If unhealthy node replacement is on, Amazon EMR
 * notifies YARN and other applications on the cluster to stop scheduling tasks
 * with these nodes, moves the data, and then terminates the nodes.
 *
 * For more information, see graceful
 * node replacement in the *Amazon EMR Management Guide*.
 */
export declare const setUnhealthyNodeReplacement: API.OperationMethod<SetUnhealthyNodeReplacementInput & RegionInput, SetUnhealthyNodeReplacementResponse, SetUnhealthyNodeReplacementError, Creds | HttpClient.HttpClient>;
export type SetVisibleToAllUsersError = InternalServerError | CommonErrors;
/**
 * The SetVisibleToAllUsers parameter is no longer supported. Your cluster may be
 * visible to all users in your account. To restrict cluster access using an IAM policy, see Identity and Access
 * Management for Amazon EMR.
 *
 * Sets the Cluster$VisibleToAllUsers value for an Amazon EMR
 * cluster. When `true`, IAM principals in the Amazon Web Services account can perform Amazon EMR cluster actions that their IAM policies allow. When `false`, only the IAM
 * principal that created the cluster and the Amazon Web Services account root user can perform
 * Amazon EMR actions on the cluster, regardless of IAM permissions
 * policies attached to other IAM principals.
 *
 * This action works on running clusters. When you create a cluster, use the RunJobFlowInput$VisibleToAllUsers parameter.
 *
 * For more information, see Understanding the Amazon EMR Cluster VisibleToAllUsers Setting in the
 * *Amazon EMR Management Guide*.
 */
export declare const setVisibleToAllUsers: API.OperationMethod<SetVisibleToAllUsersInput & RegionInput, SetVisibleToAllUsersResponse, SetVisibleToAllUsersError, Creds | HttpClient.HttpClient>;
export type StartNotebookExecutionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Starts a notebook execution.
 */
export declare const startNotebookExecution: API.OperationMethod<StartNotebookExecutionInput & RegionInput, StartNotebookExecutionOutput, StartNotebookExecutionError, Creds | HttpClient.HttpClient>;
export type StartSessionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Creates and starts a new Spark Connect session on the specified cluster. The cluster must be in the `RUNNING` or `WAITING` state and have sessions enabled. This operation is supported in Amazon EMR Spark 8.0.0 and later.
 */
export declare const startSession: API.OperationMethod<StartSessionInput & RegionInput, StartSessionOutput, StartSessionError, Creds | HttpClient.HttpClient>;
export type StopNotebookExecutionError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Stops a notebook execution.
 */
export declare const stopNotebookExecution: API.OperationMethod<StopNotebookExecutionInput & RegionInput, StopNotebookExecutionResponse, StopNotebookExecutionError, Creds | HttpClient.HttpClient>;
export type TerminateJobFlowsError = InternalServerError | JobFlowNotFound | CommonErrors;
/**
 * TerminateJobFlows shuts a list of clusters (job flows) down. When a job flow is shut
 * down, any step not yet completed is canceled and the Amazon EC2 instances on which
 * the cluster is running are stopped. Any log files not already saved are uploaded to Amazon S3 if a LogUri was specified when the cluster was created.
 *
 * The maximum number of clusters allowed is 10. The call to `TerminateJobFlows`
 * is asynchronous. Depending on the configuration of the cluster, it may take up to 1-5
 * minutes for the cluster to completely terminate and release allocated resources, such as
 * Amazon EC2 instances.
 */
export declare const terminateJobFlows: API.OperationMethod<TerminateJobFlowsInput & RegionInput, TerminateJobFlowsResponse, TerminateJobFlowsError, Creds | HttpClient.HttpClient>;
export type TerminateSessionError = InternalServerException | InvalidRequestException | CommonErrors;
/**
 * Terminates an active session. After you call this operation, the session enters the `TERMINATING` state and then transitions to `TERMINATED`.
 */
export declare const terminateSession: API.OperationMethod<TerminateSessionInput & RegionInput, TerminateSessionOutput, TerminateSessionError, Creds | HttpClient.HttpClient>;
export type UpdateStudioError = InternalServerException | InvalidRequestException | StudioNotFound | CommonErrors;
/**
 * Updates an Amazon EMR Studio configuration, including attributes such as name,
 * description, and subnets.
 */
export declare const updateStudio: API.OperationMethod<UpdateStudioInput & RegionInput, UpdateStudioResponse, UpdateStudioError, Creds | HttpClient.HttpClient>;
export type UpdateStudioSessionMappingError = InternalServerError | InvalidRequestException | CommonErrors;
/**
 * Updates the session policy attached to the user or group for the specified Amazon EMR Studio.
 */
export declare const updateStudioSessionMapping: API.OperationMethod<UpdateStudioSessionMappingInput & RegionInput, UpdateStudioSessionMappingResponse, UpdateStudioSessionMappingError, Creds | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=emr.d.ts.map