import * as alerting from "@distilled.cloud/cloudflare/alerting";
import * as Provider from "alchemy/Provider";
import { Resource } from "alchemy/Resource";
import * as Redacted from "effect/Redacted";
import { CloudflareEnvironment } from "../CloudflareEnvironment.ts";
import type { Providers } from "../Providers.ts";
declare const WebhookUnexpectedResponse_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "WebhookUnexpectedResponse";
} & Readonly<A>;
export declare class WebhookUnexpectedResponse extends WebhookUnexpectedResponse_base<{
    readonly message: string;
    readonly cause?: unknown;
}> {
}
declare const TypeId: "Cloudflare.Alerting.Webhook";
type TypeId = typeof TypeId;
/**
 * Webhook destination endpoint type, inferred by Cloudflare from the URL.
 */
export type NotificationWebhookType = "datadog" | "discord" | "feishu" | "gchat" | "generic" | "opsgenie" | "slack" | "splunk" | (string & {});
export interface NotificationWebhookProps {
    /**
     * Name of the webhook destination. Included in the request body when a
     * notification is dispatched. If omitted, a unique name is generated.
     * Mutable — renames are applied in place.
     * @default ${app}-${id}-${stage}-${suffix}
     */
    name?: string;
    /**
     * The POST endpoint Cloudflare calls when dispatching a notification.
     * Cloudflare sends a test request on create/update; the endpoint must
     * respond with a 2xx or the operation fails with `WebhookTestFailed`.
     * Mutable — updated in place.
     */
    url: string;
    /**
     * Optional secret sent in the `cf-webhook-auth` header on every
     * notification dispatch (for generic webhooks). Write-only: Cloudflare
     * never returns it, so drift cannot be observed — the secret is re-sent
     * whenever the prop value changes.
     */
    secret?: Redacted.Redacted<string>;
}
export interface NotificationWebhookAttributes {
    /** Cloudflare-assigned webhook destination UUID. */
    webhookId: string;
    /** Account that owns this webhook destination. */
    accountId: string;
    /** Name of the webhook destination. */
    name: string;
    /** The POST endpoint called when dispatching a notification. */
    url: string;
    /** Endpoint type inferred by Cloudflare from the URL (e.g. `generic`, `slack`). */
    type: NotificationWebhookType | undefined;
    /** ISO8601 creation timestamp. */
    createdAt: string | undefined;
}
export type NotificationWebhook = Resource<TypeId, NotificationWebhookProps, NotificationWebhookAttributes, never, Providers, NotificationWebhookLookup>;
/**
 * Props for {@link NotificationWebhook.lookup}: find a webhook destination
 * this stack doesn't manage, by its id or its name.
 */
export type NotificationWebhookLookup = {
    /**
     * The id of the existing webhook destination.
     */
    webhookId: string;
} | {
    /**
     * The name of the existing webhook destination. Names are not unique;
     * the first destination with this exact name is used.
     */
    name: string;
};
/**
 * A Cloudflare Notifications webhook destination.
 *
 * Webhook destinations receive alert notifications dispatched by
 * {@link NotificationPolicy | notification policies}. Cloudflare sends a
 * test POST to the URL when the webhook is created or updated, so the
 * endpoint must be live and respond with a 2xx.
 * ### Creating a Webhook destination
 * **Example:** Generic webhook with a generated name
 * ```typescript
 * const webhook = yield* Cloudflare.Alerting.NotificationWebhook("AlertsHook", {
 *   url: "https://alerts.example.com/cf",
 * });
 * ```
 *
 * **Example:** Webhook with an auth secret
 * The secret is sent in the `cf-webhook-auth` header on every dispatch.
 * ```typescript
 * const webhook = yield* Cloudflare.Alerting.NotificationWebhook("AlertsHook", {
 *   name: "production-alerts",
 *   url: "https://alerts.example.com/cf",
 *   secret: yield* Config.Redacted("WEBHOOK_SECRET"),
 * });
 * ```
 *
 * ### Using with a Notification policy
 * **Example:** Dispatch policy notifications to the webhook
 * ```typescript
 * yield* Cloudflare.Alerting.NotificationPolicy("SslAlerts", {
 *   alertType: "universal_ssl_event_type",
 *   mechanisms: { webhooks: [{ id: webhook.webhookId }] },
 * });
 * ```
 *
 * ### Looking up an existing webhook
 * `NotificationWebhook.lookup` references a destination Alchemy doesn't
 * manage (created in the dashboard or by another stack), found by
 * `webhookId` or `name`. It is read during plan/deploy and never created,
 * updated or deleted.
 *
 * **Example:** Send a new policy to an existing destination
 * ```typescript
 * const pager = Cloudflare.Alerting.NotificationWebhook.lookup({ name: "pager" });
 * yield* Cloudflare.Alerting.NotificationPolicy("SslAlerts", {
 *   alertType: "universal_ssl_event_type",
 *   mechanisms: { webhooks: [{ id: pager.webhookId }] },
 * });
 * ```
 *
 * @see https://developers.cloudflare.com/notifications/get-started/configure-webhooks/
 *
 * @resource
 * @product Alerting
 * @category Observability & Analytics
 */
export declare const NotificationWebhook: import("alchemy").ResourceClass<NotificationWebhook>;
/**
 * Returns true if the given value is a NotificationWebhook resource.
 */
export declare const isNotificationWebhook: (value: unknown) => value is NotificationWebhook;
export declare const NotificationWebhookProvider: () => import("effect/Layer").Layer<Provider.Provider<NotificationWebhook>, never, CloudflareEnvironment | import("alchemy").Stack | import("alchemy").Stage | alerting.CloudflareOpContext>;
export {};
//# sourceMappingURL=Webhook.d.ts.map