import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const InternalServiceException_base: S.TaggedErrorClass<"InternalServiceException", {
    readonly message: any;
}>;
export declare class InternalServiceException extends /*@__PURE__*/ InternalServiceException_base {
}
export type DeviceName = string;
export type DeviceFleetName = string;
export interface GetDeploymentsRequest {
    DeviceName?: string | undefined;
    DeviceFleetName?: string | undefined;
}
export type EntityName = string;
export type DeploymentType = "Model" | (string & {});
export type FailureHandlingPolicy = "ROLLBACK_ON_FAILURE" | "DO_NOTHING" | (string & {});
export type S3Uri = string;
export type ChecksumType = "SHA1" | (string & {});
export type ChecksumString = string;
export interface Checksum {
    Type?: ChecksumType | undefined;
    Sum?: string | undefined;
}
export type ModelState = "DEPLOY" | "UNDEPLOY" | (string & {});
export interface Definition {
    ModelHandle?: string | undefined;
    S3Url?: string | undefined;
    Checksum?: Checksum | undefined;
    State?: ModelState | undefined;
}
export type Definitions = Definition[];
export interface EdgeDeployment {
    DeploymentName?: string | undefined;
    Type?: DeploymentType | undefined;
    FailureHandlingPolicy?: FailureHandlingPolicy | undefined;
    Definitions?: Definition[] | undefined;
}
export type EdgeDeployments = EdgeDeployment[];
export interface GetDeploymentsResult {
    Deployments?: EdgeDeployment[] | undefined;
}
export interface GetDeviceRegistrationRequest {
    DeviceName?: string | undefined;
    DeviceFleetName?: string | undefined;
}
export type DeviceRegistration = string;
export type CacheTTLSeconds = string;
export interface GetDeviceRegistrationResult {
    DeviceRegistration?: string | undefined;
    CacheTTL?: string | undefined;
}
export type Dimension = string;
export type Metric = string;
export type Value = number;
export interface EdgeMetric {
    Dimension?: string | undefined;
    MetricName?: string | undefined;
    Value?: number | undefined;
    Timestamp?: Date | undefined;
}
export type EdgeMetrics = EdgeMetric[];
export type ModelName = string;
export type Version = string;
export interface Model {
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    LatestSampleTime?: Date | undefined;
    LatestInference?: Date | undefined;
    ModelMetrics?: EdgeMetric[] | undefined;
}
export type Models = Model[];
export type DeploymentStatus = "SUCCESS" | "FAIL" | (string & {});
export interface DeploymentModel {
    ModelHandle?: string | undefined;
    ModelName?: string | undefined;
    ModelVersion?: string | undefined;
    DesiredState?: ModelState | undefined;
    State?: ModelState | undefined;
    Status?: DeploymentStatus | undefined;
    StatusReason?: string | undefined;
    RollbackFailureReason?: string | undefined;
}
export type DeploymentModels = DeploymentModel[];
export interface DeploymentResult {
    DeploymentName?: string | undefined;
    DeploymentStatus?: string | undefined;
    DeploymentStatusMessage?: string | undefined;
    DeploymentStartTime?: Date | undefined;
    DeploymentEndTime?: Date | undefined;
    DeploymentModels?: DeploymentModel[] | undefined;
}
export interface SendHeartbeatRequest {
    AgentMetrics?: EdgeMetric[] | undefined;
    Models?: Model[] | undefined;
    AgentVersion?: string | undefined;
    DeviceName?: string | undefined;
    DeviceFleetName?: string | undefined;
    DeploymentResult?: DeploymentResult | undefined;
}
export interface SendHeartbeatResponse {
}
export type ErrorMessage = string;
export type GetDeploymentsError = InternalServiceException | CommonErrors;
/**
 * Use to get the active deployments from a device.
 */
export declare const getDeployments: API.OperationMethod<GetDeploymentsRequest & RegionInput, GetDeploymentsResult, GetDeploymentsError, Credentials | HttpClient.HttpClient>;
export type GetDeviceRegistrationError = InternalServiceException | CommonErrors;
/**
 * Use to check if a device is registered with SageMaker Edge Manager.
 */
export declare const getDeviceRegistration: API.OperationMethod<GetDeviceRegistrationRequest & RegionInput, GetDeviceRegistrationResult, GetDeviceRegistrationError, Credentials | HttpClient.HttpClient>;
export type SendHeartbeatError = InternalServiceException | CommonErrors;
/**
 * Use to get the current status of devices registered on SageMaker Edge Manager.
 */
export declare const sendHeartbeat: API.OperationMethod<SendHeartbeatRequest & RegionInput, SendHeartbeatResponse, SendHeartbeatError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=sagemaker-edge.d.ts.map