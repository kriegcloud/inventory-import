import * as API from "@distilled.cloud/core/api";
import * as S from "@distilled.cloud/core/schema-lite";
import type * as HttpClient from "effect/http/HttpClient";
import type * as redacted from "effect/Redacted";
import type { Credentials } from "../credentials.ts";
import type { CommonErrors } from "../errors.ts";
import type { RegionInput } from "../region.ts";
declare const AccessDeniedException_base: S.TaggedErrorClass<"AccessDeniedException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        AuthError: true;
    };
});
export declare class AccessDeniedException extends /*@__PURE__*/ AccessDeniedException_base {
}
declare const ConflictException_base: S.TaggedErrorClass<"ConflictException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ConflictError: true;
    };
});
export declare class ConflictException extends /*@__PURE__*/ ConflictException_base {
}
declare const ResourceNotFoundException_base: S.TaggedErrorClass<"ResourceNotFoundException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ResourceNotFoundException extends /*@__PURE__*/ ResourceNotFoundException_base {
}
declare const ServiceQuotaExceededException_base: S.TaggedErrorClass<"ServiceQuotaExceededException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        QuotaError: true;
    };
});
export declare class ServiceQuotaExceededException extends /*@__PURE__*/ ServiceQuotaExceededException_base {
}
declare const ThrottlingException_base: S.TaggedErrorClass<"ThrottlingException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        ThrottlingError: true;
    };
}) & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        RetryableError: true;
    };
});
export declare class ThrottlingException extends /*@__PURE__*/ ThrottlingException_base {
}
declare const ValidationException_base: S.TaggedErrorClass<"ValidationException", {
    readonly message: any;
}> & (new (...args: any[]) => {
    "@distilled.cloud/error/categories": {
        BadRequestError: true;
    };
});
export declare class ValidationException extends /*@__PURE__*/ ValidationException_base {
}
export type AccessTokenName = string;
export interface CreateAccessTokenRequest {
    name: string;
    expiresTime?: Date | undefined;
}
export type AccessTokenSecret = string | redacted.Redacted<string>;
export type AccessTokenId = string;
export interface CreateAccessTokenResponse {
    secret: string | redacted.Redacted<string>;
    name: string;
    expiresTime: Date;
    accessTokenId: string;
}
export type NameString = string;
export type SourceRepositoryNameString = string;
export type SourceRepositoryBranchString = string;
export interface RepositoryInput {
    repositoryName: string;
    branchName?: string | undefined;
}
export type RepositoriesInput = RepositoryInput[];
export type ClientToken = string;
export interface IdeConfiguration {
    runtime?: string | undefined;
    name?: string | undefined;
}
export type IdeConfigurationList = IdeConfiguration[];
export type InstanceType = string;
export type InactivityTimeoutMinutes = number;
export interface PersistentStorageConfiguration {
    sizeInGiB: number;
}
export interface CreateDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    repositories?: RepositoryInput[] | undefined;
    clientToken?: string | undefined;
    alias?: string | undefined;
    ides?: IdeConfiguration[] | undefined;
    instanceType: string;
    inactivityTimeoutMinutes?: number | undefined;
    persistentStorage: PersistentStorageConfiguration;
    vpcConnectionName?: string | undefined;
}
export type Uuid = string;
export interface CreateDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    vpcConnectionName?: string | undefined;
}
export type ProjectDisplayName = string;
export type ProjectDescription = string;
export interface CreateProjectRequest {
    spaceName: string;
    displayName: string;
    description?: string | undefined;
}
export interface CreateProjectResponse {
    spaceName?: string | undefined;
    name: string;
    displayName?: string | undefined;
    description?: string | undefined;
}
export type SourceRepositoryDescriptionString = string;
export interface CreateSourceRepositoryRequest {
    spaceName: string;
    projectName: string;
    name: string;
    description?: string | undefined;
}
export interface CreateSourceRepositoryResponse {
    spaceName: string;
    projectName: string;
    name: string;
    description?: string | undefined;
}
export interface CreateSourceRepositoryBranchRequest {
    spaceName: string;
    projectName: string;
    sourceRepositoryName: string;
    name: string;
    headCommitId?: string | undefined;
}
export type SourceRepositoryBranchRefString = string;
export interface CreateSourceRepositoryBranchResponse {
    ref?: string | undefined;
    name?: string | undefined;
    lastUpdatedTime?: Date | undefined;
    headCommitId?: string | undefined;
}
export interface DeleteAccessTokenRequest {
    id: string;
}
export interface DeleteAccessTokenResponse {
}
export interface DeleteDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
}
export interface DeleteDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
}
export interface DeleteProjectRequest {
    spaceName: string;
    name: string;
}
export interface DeleteProjectResponse {
    spaceName: string;
    name: string;
    displayName?: string | undefined;
}
export interface DeleteSourceRepositoryRequest {
    spaceName: string;
    projectName: string;
    name: string;
}
export interface DeleteSourceRepositoryResponse {
    spaceName: string;
    projectName: string;
    name: string;
}
export interface DeleteSpaceRequest {
    name: string;
}
export interface DeleteSpaceResponse {
    name: string;
    displayName?: string | undefined;
}
export interface GetDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
}
export type DevEnvironmentStatus = string;
export type StatusReason = string;
export interface DevEnvironmentRepositorySummary {
    repositoryName: string;
    branchName?: string | undefined;
}
export type DevEnvironmentRepositorySummaries = DevEnvironmentRepositorySummary[];
export interface Ide {
    runtime?: string | undefined;
    name?: string | undefined;
}
export type Ides = Ide[];
export interface PersistentStorage {
    sizeInGiB: number;
}
export interface GetDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    lastUpdatedTime: Date;
    creatorId: string;
    status: string;
    statusReason?: string | undefined;
    repositories: DevEnvironmentRepositorySummary[];
    alias?: string | undefined;
    ides?: Ide[] | undefined;
    instanceType: string;
    inactivityTimeoutMinutes: number;
    persistentStorage: PersistentStorage;
    vpcConnectionName?: string | undefined;
}
export interface GetProjectRequest {
    spaceName: string;
    name: string;
}
export interface GetProjectResponse {
    spaceName?: string | undefined;
    name: string;
    displayName?: string | undefined;
    description?: string | undefined;
}
export interface GetSourceRepositoryRequest {
    spaceName: string;
    projectName: string;
    name: string;
}
export interface GetSourceRepositoryResponse {
    spaceName: string;
    projectName: string;
    name: string;
    description?: string | undefined;
    lastUpdatedTime: Date;
    createdTime: Date;
}
export interface GetSourceRepositoryCloneUrlsRequest {
    spaceName: string;
    projectName: string;
    sourceRepositoryName: string;
}
export interface GetSourceRepositoryCloneUrlsResponse {
    https: string;
}
export interface GetSpaceRequest {
    name: string;
}
export type RegionString = string;
export interface GetSpaceResponse {
    name: string;
    regionName: string;
    displayName?: string | undefined;
    description?: string | undefined;
}
export interface GetSubscriptionRequest {
    spaceName: string;
}
export interface GetSubscriptionResponse {
    subscriptionType?: string | undefined;
    awsAccountName?: string | undefined;
    pendingSubscriptionType?: string | undefined;
    pendingSubscriptionStartTime?: Date | undefined;
}
export interface GetUserDetailsRequest {
    id?: string | undefined;
    userName?: string | undefined;
}
export interface EmailAddress {
    email?: string | undefined;
    verified?: boolean | undefined;
}
export interface GetUserDetailsResponse {
    userId?: string | undefined;
    userName?: string | undefined;
    displayName?: string | undefined;
    primaryEmail?: EmailAddress | undefined;
    version?: string | undefined;
}
export interface GetWorkflowRequest {
    spaceName: string;
    id: string;
    projectName: string;
}
export interface WorkflowDefinition {
    path: string;
}
export type WorkflowRunMode = string;
export type WorkflowStatus = string;
export interface GetWorkflowResponse {
    spaceName: string;
    projectName: string;
    id: string;
    name: string;
    sourceRepositoryName?: string | undefined;
    sourceBranchName?: string | undefined;
    definition: WorkflowDefinition;
    createdTime: Date;
    lastUpdatedTime: Date;
    runMode: string;
    status: string;
}
export interface GetWorkflowRunRequest {
    spaceName: string;
    id: string;
    projectName: string;
}
export type WorkflowRunStatus = string;
export interface WorkflowRunStatusReason {
}
export type WorkflowRunStatusReasons = WorkflowRunStatusReason[];
export interface GetWorkflowRunResponse {
    spaceName: string;
    projectName: string;
    id: string;
    workflowId: string;
    status: string;
    statusReasons?: WorkflowRunStatusReason[] | undefined;
    startTime: Date;
    endTime?: Date | undefined;
    lastUpdatedTime: Date;
}
export interface ListAccessTokensRequest {
    maxResults?: number | undefined;
    nextToken?: string | undefined;
}
export interface AccessTokenSummary {
    id: string;
    name: string;
    expiresTime?: Date | undefined;
}
export type AccessTokenSummaries = AccessTokenSummary[];
export interface ListAccessTokensResponse {
    items: AccessTokenSummary[];
    nextToken?: string | undefined;
}
export type StringList = string[];
export interface Filter {
    key: string;
    values: string[];
    comparisonOperator?: string | undefined;
}
export type Filters = Filter[];
export interface ListDevEnvironmentsRequest {
    spaceName: string;
    projectName?: string | undefined;
    filters?: Filter[] | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DevEnvironmentSummary {
    spaceName?: string | undefined;
    projectName?: string | undefined;
    id: string;
    lastUpdatedTime: Date;
    creatorId: string;
    status: string;
    statusReason?: string | undefined;
    repositories: DevEnvironmentRepositorySummary[];
    alias?: string | undefined;
    ides?: Ide[] | undefined;
    instanceType: string;
    inactivityTimeoutMinutes: number;
    persistentStorage: PersistentStorage;
    vpcConnectionName?: string | undefined;
}
export type DevEnvironmentSummaryList = DevEnvironmentSummary[];
export interface ListDevEnvironmentsResponse {
    items: DevEnvironmentSummary[];
    nextToken?: string | undefined;
}
export interface ListDevEnvironmentSessionsRequest {
    spaceName: string;
    projectName: string;
    devEnvironmentId: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface DevEnvironmentSessionSummary {
    spaceName: string;
    projectName: string;
    devEnvironmentId: string;
    startedTime: Date;
    id: string;
}
export type DevEnvironmentSessionsSummaryList = DevEnvironmentSessionSummary[];
export interface ListDevEnvironmentSessionsResponse {
    items: DevEnvironmentSessionSummary[];
    nextToken?: string | undefined;
}
export interface ListEventLogsRequest {
    spaceName: string;
    startTime: Date;
    endTime: Date;
    eventName?: string | undefined;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type OperationType = string;
export type UserType = string;
export interface UserIdentity {
    userType: string;
    principalId: string;
    userName?: string | undefined;
    awsAccountId?: string | undefined;
}
export interface ProjectInformation {
    name?: string | undefined;
    projectId?: string | undefined;
}
export interface EventPayload {
    contentType?: string | undefined;
    data?: string | undefined;
}
export interface EventLogEntry {
    id: string;
    eventName: string;
    eventType: string;
    eventCategory: string;
    eventSource: string;
    eventTime: Date;
    operationType: string;
    userIdentity: UserIdentity;
    projectInformation?: ProjectInformation | undefined;
    requestId?: string | undefined;
    requestPayload?: EventPayload | undefined;
    responsePayload?: EventPayload | undefined;
    errorCode?: string | undefined;
    sourceIpAddress?: string | undefined;
    userAgent?: string | undefined;
}
export type EventLogEntries = EventLogEntry[];
export interface ListEventLogsResponse {
    nextToken?: string | undefined;
    items: EventLogEntry[];
}
export type FilterKey = string;
export type ComparisonOperator = string;
export interface ProjectListFilter {
    key: string;
    values: string[];
    comparisonOperator?: string | undefined;
}
export type ProjectListFilters = ProjectListFilter[];
export interface ListProjectsRequest {
    spaceName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    filters?: ProjectListFilter[] | undefined;
}
export interface ProjectSummary {
    name: string;
    displayName?: string | undefined;
    description?: string | undefined;
}
export type ProjectSummaries = ProjectSummary[];
export interface ListProjectsResponse {
    nextToken?: string | undefined;
    items?: ProjectSummary[] | undefined;
}
export interface ListSourceRepositoriesRequest {
    spaceName: string;
    projectName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export type SourceRepositoryIdString = string;
export interface ListSourceRepositoriesItem {
    id: string;
    name: string;
    description?: string | undefined;
    lastUpdatedTime: Date;
    createdTime: Date;
}
export type ListSourceRepositoriesItems = ListSourceRepositoriesItem[];
export interface ListSourceRepositoriesResponse {
    items?: ListSourceRepositoriesItem[] | undefined;
    nextToken?: string | undefined;
}
export interface ListSourceRepositoryBranchesRequest {
    spaceName: string;
    projectName: string;
    sourceRepositoryName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
}
export interface ListSourceRepositoryBranchesItem {
    ref?: string | undefined;
    name?: string | undefined;
    lastUpdatedTime?: Date | undefined;
    headCommitId?: string | undefined;
}
export type ListSourceRepositoryBranchesItems = ListSourceRepositoryBranchesItem[];
export interface ListSourceRepositoryBranchesResponse {
    nextToken?: string | undefined;
    items: ListSourceRepositoryBranchesItem[];
}
export interface ListSpacesRequest {
    nextToken?: string | undefined;
}
export interface SpaceSummary {
    name: string;
    regionName: string;
    displayName?: string | undefined;
    description?: string | undefined;
}
export type SpaceSummaries = SpaceSummary[];
export interface ListSpacesResponse {
    nextToken?: string | undefined;
    items?: SpaceSummary[] | undefined;
}
export interface WorkflowRunSortCriteria {
}
export type WorkflowRunSortCriteriaList = WorkflowRunSortCriteria[];
export interface ListWorkflowRunsRequest {
    spaceName: string;
    workflowId?: string | undefined;
    projectName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortBy?: WorkflowRunSortCriteria[] | undefined;
}
export interface WorkflowRunSummary {
    id: string;
    workflowId: string;
    workflowName: string;
    status: string;
    statusReasons?: WorkflowRunStatusReason[] | undefined;
    startTime: Date;
    endTime?: Date | undefined;
    lastUpdatedTime: Date;
}
export type WorkflowRunSummaries = WorkflowRunSummary[];
export interface ListWorkflowRunsResponse {
    nextToken?: string | undefined;
    items?: WorkflowRunSummary[] | undefined;
}
export interface WorkflowSortCriteria {
}
export type WorkflowSortCriteriaList = WorkflowSortCriteria[];
export interface ListWorkflowsRequest {
    spaceName: string;
    projectName: string;
    nextToken?: string | undefined;
    maxResults?: number | undefined;
    sortBy?: WorkflowSortCriteria[] | undefined;
}
export interface WorkflowDefinitionSummary {
    path: string;
}
export interface WorkflowSummary {
    id: string;
    name: string;
    sourceRepositoryName: string;
    sourceBranchName: string;
    definition: WorkflowDefinitionSummary;
    createdTime: Date;
    lastUpdatedTime: Date;
    runMode: string;
    status: string;
}
export type WorkflowSummaries = WorkflowSummary[];
export interface ListWorkflowsResponse {
    nextToken?: string | undefined;
    items?: WorkflowSummary[] | undefined;
}
export interface StartDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
    ides?: IdeConfiguration[] | undefined;
    instanceType?: string | undefined;
    inactivityTimeoutMinutes?: number | undefined;
}
export interface StartDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    status: string;
}
export type DevEnvironmentSessionType = string;
export type ExecuteCommandSessionConfigurationArguments = string[];
export interface ExecuteCommandSessionConfiguration {
    command: string;
    arguments?: string[] | undefined;
}
export interface DevEnvironmentSessionConfiguration {
    sessionType: string;
    executeCommandSessionConfiguration?: ExecuteCommandSessionConfiguration | undefined;
}
export interface StartDevEnvironmentSessionRequest {
    spaceName: string;
    projectName: string;
    id: string;
    sessionConfiguration: DevEnvironmentSessionConfiguration;
}
export type SensitiveString = string | redacted.Redacted<string>;
export interface DevEnvironmentAccessDetails {
    streamUrl: string | redacted.Redacted<string>;
    tokenValue: string | redacted.Redacted<string>;
}
export interface StartDevEnvironmentSessionResponse {
    accessDetails: DevEnvironmentAccessDetails;
    sessionId?: string | undefined;
    spaceName: string;
    projectName: string;
    id: string;
}
export interface StartWorkflowRunRequest {
    spaceName: string;
    projectName: string;
    workflowId: string;
    clientToken?: string | undefined;
}
export interface StartWorkflowRunResponse {
    spaceName: string;
    projectName: string;
    id: string;
    workflowId: string;
}
export interface StopDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
}
export interface StopDevEnvironmentResponse {
    spaceName: string;
    projectName: string;
    id: string;
    status: string;
}
export interface StopDevEnvironmentSessionRequest {
    spaceName: string;
    projectName: string;
    id: string;
    sessionId: string;
}
export interface StopDevEnvironmentSessionResponse {
    spaceName: string;
    projectName: string;
    id: string;
    sessionId: string;
}
export interface UpdateDevEnvironmentRequest {
    spaceName: string;
    projectName: string;
    id: string;
    alias?: string | undefined;
    ides?: IdeConfiguration[] | undefined;
    instanceType?: string | undefined;
    inactivityTimeoutMinutes?: number | undefined;
    clientToken?: string | undefined;
}
export interface UpdateDevEnvironmentResponse {
    id: string;
    spaceName: string;
    projectName: string;
    alias?: string | undefined;
    ides?: IdeConfiguration[] | undefined;
    instanceType?: string | undefined;
    inactivityTimeoutMinutes?: number | undefined;
    clientToken?: string | undefined;
}
export interface UpdateProjectRequest {
    spaceName: string;
    name: string;
    description?: string | undefined;
}
export interface UpdateProjectResponse {
    spaceName?: string | undefined;
    name?: string | undefined;
    displayName?: string | undefined;
    description?: string | undefined;
}
export type SpaceDescription = string;
export interface UpdateSpaceRequest {
    name: string;
    description?: string | undefined;
}
export interface UpdateSpaceResponse {
    name?: string | undefined;
    displayName?: string | undefined;
    description?: string | undefined;
}
export interface VerifySessionRequest {
}
export interface VerifySessionResponse {
    identity?: string | undefined;
}
export type CreateAccessTokenError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a personal access token (PAT) for the current user. A personal access token (PAT) is similar to a password.
 * It is associated with your user identity for use across all spaces and projects in Amazon CodeCatalyst. You use PATs to access CodeCatalyst
 * from resources that include integrated development environments (IDEs) and Git-based source repositories.
 * PATs represent you in Amazon CodeCatalyst and you can manage them in your user settings.For more information, see
 * Managing personal access tokens in Amazon CodeCatalyst.
 */
export declare const createAccessToken: API.OperationMethod<CreateAccessTokenRequest & RegionInput, CreateAccessTokenResponse, CreateAccessTokenError, Credentials | HttpClient.HttpClient>;
export type CreateDevEnvironmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a Dev Environment in Amazon CodeCatalyst, a cloud-based development environment that you can use to quickly work on the code stored
 * in the source repositories of your project.
 *
 * When created in the Amazon CodeCatalyst console, by default a Dev Environment is configured to have a 2 core processor, 4GB of RAM, and 16GB of persistent storage. None of these
 * defaults apply to a Dev Environment created programmatically.
 */
export declare const createDevEnvironment: API.OperationMethod<CreateDevEnvironmentRequest & RegionInput, CreateDevEnvironmentResponse, CreateDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type CreateProjectError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a project in a specified space.
 */
export declare const createProject: API.OperationMethod<CreateProjectRequest & RegionInput, CreateProjectResponse, CreateProjectError, Credentials | HttpClient.HttpClient>;
export type CreateSourceRepositoryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates an empty Git-based source repository in a specified project. The repository is
 * created with an initial empty commit with a default branch named `main`.
 */
export declare const createSourceRepository: API.OperationMethod<CreateSourceRepositoryRequest & RegionInput, CreateSourceRepositoryResponse, CreateSourceRepositoryError, Credentials | HttpClient.HttpClient>;
export type CreateSourceRepositoryBranchError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Creates a branch in a specified source repository in Amazon CodeCatalyst.
 *
 * This API only creates a branch in a source repository hosted in Amazon CodeCatalyst. You cannot use this API to create a branch in a linked repository.
 */
export declare const createSourceRepositoryBranch: API.OperationMethod<CreateSourceRepositoryBranchRequest & RegionInput, CreateSourceRepositoryBranchResponse, CreateSourceRepositoryBranchError, Credentials | HttpClient.HttpClient>;
export type DeleteAccessTokenError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a specified personal access token (PAT). A personal access token can only be deleted by the user who created it.
 */
export declare const deleteAccessToken: API.OperationMethod<DeleteAccessTokenRequest & RegionInput, DeleteAccessTokenResponse, DeleteAccessTokenError, Credentials | HttpClient.HttpClient>;
export type DeleteDevEnvironmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a Dev Environment.
 */
export declare const deleteDevEnvironment: API.OperationMethod<DeleteDevEnvironmentRequest & RegionInput, DeleteDevEnvironmentResponse, DeleteDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type DeleteProjectError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a project in a space.
 */
export declare const deleteProject: API.OperationMethod<DeleteProjectRequest & RegionInput, DeleteProjectResponse, DeleteProjectError, Credentials | HttpClient.HttpClient>;
export type DeleteSourceRepositoryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a source repository in Amazon CodeCatalyst. You cannot use this API to delete a linked repository. It can only be used to delete a Amazon CodeCatalyst source repository.
 */
export declare const deleteSourceRepository: API.OperationMethod<DeleteSourceRepositoryRequest & RegionInput, DeleteSourceRepositoryResponse, DeleteSourceRepositoryError, Credentials | HttpClient.HttpClient>;
export type DeleteSpaceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Deletes a space.
 *
 * Deleting a space cannot be undone. Additionally, since space names must be unique across Amazon CodeCatalyst, you cannot reuse names of deleted spaces.
 */
export declare const deleteSpace: API.OperationMethod<DeleteSpaceRequest & RegionInput, DeleteSpaceResponse, DeleteSpaceError, Credentials | HttpClient.HttpClient>;
export type GetDevEnvironmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a Dev Environment for a source repository in a project. Dev Environments are specific to the user who creates them.
 */
export declare const getDevEnvironment: API.OperationMethod<GetDevEnvironmentRequest & RegionInput, GetDevEnvironmentResponse, GetDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type GetProjectError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a project.
 */
export declare const getProject: API.OperationMethod<GetProjectRequest & RegionInput, GetProjectResponse, GetProjectError, Credentials | HttpClient.HttpClient>;
export type GetSourceRepositoryError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a source repository.
 */
export declare const getSourceRepository: API.OperationMethod<GetSourceRepositoryRequest & RegionInput, GetSourceRepositoryResponse, GetSourceRepositoryError, Credentials | HttpClient.HttpClient>;
export type GetSourceRepositoryCloneUrlsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the URLs that can be used with a Git client to clone a source
 * repository.
 */
export declare const getSourceRepositoryCloneUrls: API.OperationMethod<GetSourceRepositoryCloneUrlsRequest & RegionInput, GetSourceRepositoryCloneUrlsResponse, GetSourceRepositoryCloneUrlsError, Credentials | HttpClient.HttpClient>;
export type GetSpaceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about an space.
 */
export declare const getSpace: API.OperationMethod<GetSpaceRequest & RegionInput, GetSpaceResponse, GetSpaceError, Credentials | HttpClient.HttpClient>;
export type GetSubscriptionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about the Amazon Web Services account used for billing purposes
 * and the billing plan for the space.
 */
export declare const getSubscription: API.OperationMethod<GetSubscriptionRequest & RegionInput, GetSubscriptionResponse, GetSubscriptionError, Credentials | HttpClient.HttpClient>;
export type GetUserDetailsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a user.
 */
export declare const getUserDetails: API.OperationMethod<GetUserDetailsRequest & RegionInput, GetUserDetailsResponse, GetUserDetailsError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a workflow.
 */
export declare const getWorkflow: API.OperationMethod<GetWorkflowRequest & RegionInput, GetWorkflowResponse, GetWorkflowError, Credentials | HttpClient.HttpClient>;
export type GetWorkflowRunError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Returns information about a specified run of a workflow.
 */
export declare const getWorkflowRun: API.OperationMethod<GetWorkflowRunRequest & RegionInput, GetWorkflowRunResponse, GetWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type ListAccessTokensError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Lists all personal access tokens (PATs) associated with the user who calls the API. You can only list PATs associated with your Amazon Web Services Builder ID.
 */
export declare const listAccessTokens: API.PaginatedOperationMethod<ListAccessTokensRequest & RegionInput, ListAccessTokensResponse, ListAccessTokensError, Credentials | HttpClient.HttpClient, AccessTokenSummary>;
export type ListDevEnvironmentsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of Dev Environments in a project.
 */
export declare const listDevEnvironments: API.PaginatedOperationMethod<ListDevEnvironmentsRequest & RegionInput, ListDevEnvironmentsResponse, ListDevEnvironmentsError, Credentials | HttpClient.HttpClient, DevEnvironmentSummary>;
export type ListDevEnvironmentSessionsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of active sessions for a Dev Environment in a project.
 */
export declare const listDevEnvironmentSessions: API.PaginatedOperationMethod<ListDevEnvironmentSessionsRequest & RegionInput, ListDevEnvironmentSessionsResponse, ListDevEnvironmentSessionsError, Credentials | HttpClient.HttpClient, DevEnvironmentSessionSummary>;
export type ListEventLogsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of events that occurred during a specific time in a space. You can
 * use these events to audit user and system activity in a space. For more information, see
 * Monitoring in the *Amazon CodeCatalyst User Guide*.
 *
 * ListEventLogs guarantees events for the last 30 days in a given space. You can also
 * view and retrieve a list of management events over the last 90 days for Amazon CodeCatalyst in the
 * CloudTrail console by viewing Event history, or by creating a trail to create
 * and maintain a record of events that extends past 90 days. For more information, see Working with CloudTrail Event History and Working with
 * CloudTrail trails.
 */
export declare const listEventLogs: API.PaginatedOperationMethod<ListEventLogsRequest & RegionInput, ListEventLogsResponse, ListEventLogsError, Credentials | HttpClient.HttpClient, EventLogEntry>;
export type ListProjectsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of projects.
 */
export declare const listProjects: API.PaginatedOperationMethod<ListProjectsRequest & RegionInput, ListProjectsResponse, ListProjectsError, Credentials | HttpClient.HttpClient, ProjectSummary>;
export type ListSourceRepositoriesError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of source repositories in a project.
 */
export declare const listSourceRepositories: API.PaginatedOperationMethod<ListSourceRepositoriesRequest & RegionInput, ListSourceRepositoriesResponse, ListSourceRepositoriesError, Credentials | HttpClient.HttpClient, ListSourceRepositoriesItem>;
export type ListSourceRepositoryBranchesError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of branches in a specified source repository.
 */
export declare const listSourceRepositoryBranches: API.PaginatedOperationMethod<ListSourceRepositoryBranchesRequest & RegionInput, ListSourceRepositoryBranchesResponse, ListSourceRepositoryBranchesError, Credentials | HttpClient.HttpClient, ListSourceRepositoryBranchesItem>;
export type ListSpacesError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of spaces.
 */
export declare const listSpaces: API.PaginatedOperationMethod<ListSpacesRequest & RegionInput, ListSpacesResponse, ListSpacesError, Credentials | HttpClient.HttpClient, SpaceSummary>;
export type ListWorkflowRunsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of workflow runs of a specified workflow.
 */
export declare const listWorkflowRuns: API.PaginatedOperationMethod<ListWorkflowRunsRequest & RegionInput, ListWorkflowRunsResponse, ListWorkflowRunsError, Credentials | HttpClient.HttpClient, WorkflowRunSummary>;
export type ListWorkflowsError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Retrieves a list of workflows in a specified project.
 */
export declare const listWorkflows: API.PaginatedOperationMethod<ListWorkflowsRequest & RegionInput, ListWorkflowsResponse, ListWorkflowsError, Credentials | HttpClient.HttpClient, WorkflowSummary>;
export type StartDevEnvironmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a specified Dev Environment and puts it into an active state.
 */
export declare const startDevEnvironment: API.OperationMethod<StartDevEnvironmentRequest & RegionInput, StartDevEnvironmentResponse, StartDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type StartDevEnvironmentSessionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Starts a session for a specified Dev Environment.
 */
export declare const startDevEnvironmentSession: API.OperationMethod<StartDevEnvironmentSessionRequest & RegionInput, StartDevEnvironmentSessionResponse, StartDevEnvironmentSessionError, Credentials | HttpClient.HttpClient>;
export type StartWorkflowRunError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Begins a run of a specified workflow.
 */
export declare const startWorkflowRun: API.OperationMethod<StartWorkflowRunRequest & RegionInput, StartWorkflowRunResponse, StartWorkflowRunError, Credentials | HttpClient.HttpClient>;
export type StopDevEnvironmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Pauses a specified Dev Environment and places it in a non-running state. Stopped Dev Environments do not consume compute minutes.
 */
export declare const stopDevEnvironment: API.OperationMethod<StopDevEnvironmentRequest & RegionInput, StopDevEnvironmentResponse, StopDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type StopDevEnvironmentSessionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Stops a session for a specified Dev Environment.
 */
export declare const stopDevEnvironmentSession: API.OperationMethod<StopDevEnvironmentSessionRequest & RegionInput, StopDevEnvironmentSessionResponse, StopDevEnvironmentSessionError, Credentials | HttpClient.HttpClient>;
export type UpdateDevEnvironmentError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes one or more values for a Dev Environment. Updating certain values of the Dev Environment will cause a restart.
 */
export declare const updateDevEnvironment: API.OperationMethod<UpdateDevEnvironmentRequest & RegionInput, UpdateDevEnvironmentResponse, UpdateDevEnvironmentError, Credentials | HttpClient.HttpClient>;
export type UpdateProjectError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes one or more values for a project.
 */
export declare const updateProject: API.OperationMethod<UpdateProjectRequest & RegionInput, UpdateProjectResponse, UpdateProjectError, Credentials | HttpClient.HttpClient>;
export type UpdateSpaceError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Changes one or more values for a space.
 */
export declare const updateSpace: API.OperationMethod<UpdateSpaceRequest & RegionInput, UpdateSpaceResponse, UpdateSpaceError, Credentials | HttpClient.HttpClient>;
export type VerifySessionError = AccessDeniedException | ConflictException | ResourceNotFoundException | ServiceQuotaExceededException | ThrottlingException | ValidationException | CommonErrors;
/**
 * Verifies whether the calling user has a valid Amazon CodeCatalyst login and session. If successful, this returns the ID of the user in Amazon CodeCatalyst.
 */
export declare const verifySession: API.OperationMethod<VerifySessionRequest & RegionInput, VerifySessionResponse, VerifySessionError, Credentials | HttpClient.HttpClient>;
export {};
//# sourceMappingURL=codecatalyst.d.ts.map